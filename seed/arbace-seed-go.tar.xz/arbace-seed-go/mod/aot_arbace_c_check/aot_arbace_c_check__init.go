//line aot_arbace_c_check__init.ae:1
package aot_arbace_c_check

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_check__init_part0_A_Unit0__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_c_check__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_check__init_part0_A_const_1) }
//line :1:1
func A_arbace_c_check__init_part0_A_Unit1__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_c_check__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_2)) }
//line :1:1
func A_arbace_c_check__init_part0_A_Unit2__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c_check_eval1876000004_loading__1927001464__auto____1876000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c_check_eval1876000004_loading__1927001464__auto____1876000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_419, false, nil); A_arbace_c_check_eval1876000004_loading__1927001464__auto____1876000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_c_check__init_part0_A_Unit3__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c_check__init_part0_A_const_1)).Equals_O__Z(A_arbace_c_check__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c_check_eval1876000008_fn__1876000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c_check_eval1876000008_fn__1876000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_420, false, nil); A_arbace_c_check_eval1876000008_fn__1876000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_c_check__init_part0_A_Init__O() any { A_arbace_c_check__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_c_check__init_part0_A_Load__O() any { A_arbace_c_check__init_part0_A_Init(); A_arbace_c_check__init_part0_A_Unit0__O(); A_arbace_c_check__init_part0_A_Unit1__O(); A_arbace_c_check__init_part0_A_Unit2__O(); A_arbace_c_check__init_part0_A_Unit3__O(); A_arbace_c_check__init_part0_A_Unit4__O(); A_arbace_c_check__init_part0_A_Unit5__O(); A_arbace_c_check__init_part0_A_Unit6__O(); A_arbace_c_check__init_part0_A_Unit7__O(); A_arbace_c_check__init_part0_A_Unit8__O(); A_arbace_c_check__init_part0_A_Unit9__O(); A_arbace_c_check__init_part0_A_Unit10__O(); A_arbace_c_check__init_part0_A_Unit11__O(); A_arbace_c_check__init_part0_A_Unit12__O(); A_arbace_c_check__init_part0_A_Unit13__O(); A_arbace_c_check__init_part0_A_Unit14__O(); A_arbace_c_check__init_part0_A_Unit15__O(); A_arbace_c_check__init_part0_A_Unit16__O(); A_arbace_c_check__init_part0_A_Unit17__O(); A_arbace_c_check__init_part0_A_Unit18__O(); A_arbace_c_check__init_part0_A_Unit19__O(); A_arbace_c_check__init_part0_A_Unit20__O(); A_arbace_c_check__init_part0_A_Unit21__O(); A_arbace_c_check__init_part0_A_Unit22__O(); A_arbace_c_check__init_part0_A_Unit23__O(); A_arbace_c_check__init_part0_A_Unit24__O(); A_arbace_c_check__init_part0_A_Unit25__O(); A_arbace_c_check__init_part0_A_Unit26__O(); A_arbace_c_check__init_part0_A_Unit27__O(); A_arbace_c_check__init_part0_A_Unit28__O(); A_arbace_c_check__init_part0_A_Unit29__O(); A_arbace_c_check__init_part0_A_Unit30__O(); A_arbace_c_check__init_part0_A_Unit31__O(); A_arbace_c_check__init_part0_A_Unit32__O(); A_arbace_c_check__init_part0_A_Unit33__O(); A_arbace_c_check__init_part0_A_Unit34__O(); A_arbace_c_check__init_part0_A_Unit35__O(); A_arbace_c_check__init_part0_A_Unit36__O(); A_arbace_c_check__init_part0_A_Unit37__O(); A_arbace_c_check__init_part0_A_Unit38__O(); A_arbace_c_check__init_part0_A_Unit39__O(); A_arbace_c_check__init_part0_A_Unit40__O(); A_arbace_c_check__init_part0_A_Unit41__O(); A_arbace_c_check__init_part0_A_Unit42__O(); A_arbace_c_check__init_part0_A_Unit43__O(); A_arbace_c_check__init_part0_A_Unit44__O(); A_arbace_c_check__init_part0_A_Unit45__O(); A_arbace_c_check__init_part0_A_Unit46__O(); A_arbace_c_check__init_part0_A_Unit47__O(); A_arbace_c_check__init_part0_A_Unit48__O(); A_arbace_c_check__init_part0_A_Unit49__O(); A_arbace_c_check__init_part0_A_Unit50__O(); A_arbace_c_check__init_part0_A_Unit51__O(); A_arbace_c_check__init_part0_A_Unit52__O(); A_arbace_c_check__init_part0_A_Unit53__O(); A_arbace_c_check__init_part0_A_Unit54__O(); A_arbace_c_check__init_part0_A_Unit55__O(); A_arbace_c_check__init_part0_A_Unit56__O(); A_arbace_c_check__init_part0_A_Unit57__O(); A_arbace_c_check__init_part0_A_Unit58__O(); A_arbace_c_check__init_part0_A_Unit59__O(); A_arbace_c_check__init_part0_A_Unit60__O(); A_arbace_c_check__init_part0_A_Unit61__O(); A_arbace_c_check__init_part0_A_Unit62__O(); A_arbace_c_check__init_part0_A_Unit63__O(); A_arbace_c_check__init_part0_A_Unit64__O(); A_arbace_c_check__init_part0_A_Unit65__O(); A_arbace_c_check__init_part0_A_Unit66__O(); A_arbace_c_check__init_part0_A_Unit67__O(); A_arbace_c_check__init_part0_A_Unit68__O(); A_arbace_c_check__init_part0_A_Unit69__O(); A_arbace_c_check__init_part0_A_Unit70__O(); A_arbace_c_check__init_part0_A_Unit71__O(); A_arbace_c_check__init_part0_A_Unit72__O(); A_arbace_c_check__init_part0_A_Unit73__O(); A_arbace_c_check__init_part0_A_Unit74__O(); A_arbace_c_check__init_part0_A_Unit75__O(); A_arbace_c_check__init_part0_A_Unit76__O(); A_arbace_c_check__init_part0_A_Unit77__O(); A_arbace_c_check__init_part0_A_Unit78__O(); A_arbace_c_check__init_part0_A_Unit79__O(); A_arbace_c_check__init_part0_A_Unit80__O(); A_arbace_c_check__init_part0_A_Unit81__O(); A_arbace_c_check__init_part0_A_Unit82__O(); A_arbace_c_check__init_part0_A_Unit83__O(); A_arbace_c_check__init_part0_A_Unit84__O(); A_arbace_c_check__init_part0_A_Unit85__O(); A_arbace_c_check__init_part0_A_Unit86__O(); A_arbace_c_check__init_part0_A_Unit87__O(); A_arbace_c_check__init_part0_A_Unit88__O(); A_arbace_c_check__init_part0_A_Unit89__O(); A_arbace_c_check__init_part0_A_Unit90__O(); A_arbace_c_check__init_part0_A_Unit91__O(); A_arbace_c_check__init_part0_A_Unit92__O(); A_arbace_c_check__init_part0_A_Unit93__O(); A_arbace_c_check__init_part0_A_Unit94__O(); A_arbace_c_check__init_part0_A_Unit95__O(); A_arbace_c_check__init_part0_A_Unit96__O(); A_arbace_c_check__init_part0_A_Unit97__O(); A_arbace_c_check__init_part0_A_Unit98__O(); A_arbace_c_check__init_part0_A_Unit99__O(); return nil }



func A_arbace_c_check__init_A_Load__O() any { jrt.StartCheck(); A_arbace_c_check__init_part0_A_Init__O(); A_arbace_c_check__init_part1_A_Init__O(); A_arbace_c_check__init_part2_A_Init__O(); A_arbace_c_check__init_part0_A_Load__O(); A_arbace_c_check__init_part1_A_Load__O(); A_arbace_c_check__init_part2_A_Load__O(); return nil }



















func A_arbace_c_check__init_part0_A_Unit4__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); return A_arbace_c_check__init_part0_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }




func A_arbace_c_check__init_part0_A_Unit5__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); A_arbace_c_check__init_part0_A_const_5.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_5; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_6)); return A_arbace_c_check__init_part0_A_const_5.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_check__init_part0_A_Unit6__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); A_arbace_c_check__init_part0_A_const_7.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_8); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_9)); return A_arbace_c_check__init_part0_A_const_7.SetDynamic_Z__Var(true).Ref() }


func A_arbace_c_check__init_part0_A_Unit7__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); A_arbace_c_check__init_part0_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_11)); return A_arbace_c_check__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_check__init_part0_A_Unit8__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_c_check_fn__1876000014_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c_check_fn__1876000014_A_fn_class; if


	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_421, false, nil); A_arbace_c_check_fn__1876000014_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); /*line :35:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_13)); return A_arbace_c_check__init_part0_A_const_12.SetDynamic_Z__Var(true).Ref() }



func A_arbace_c_check__init_part0_A_Unit9__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); A_arbace_c_check__init_part0_A_const_14.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_15)); return A_arbace_c_check__init_part0_A_const_14.SetDynamic_Z__Var(true).Ref() }


func A_arbace_c_check__init_part0_A_Unit10__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_c_check__init_part0_A_const_16.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_17)); return A_arbace_c_check__init_part0_A_const_16.SetDynamic_Z__Var(true).Ref() }


func A_arbace_c_check__init_part0_A_Unit11__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); A_arbace_c_check__init_part0_A_const_18.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_19)); return A_arbace_c_check__init_part0_A_const_18.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_check__init_part0_A_Unit12__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_c_check_cx_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c_check_cx_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_422, false, nil); A_arbace_c_check_cx_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_21)); return A_arbace_c_check__init_part0_A_const_20 }

func A_arbace_c_check__init_part0_A_Unit13__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c_check_ann_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c_check_ann_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_423, false, nil); A_arbace_c_check_ann_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_23)); return A_arbace_c_check__init_part0_A_const_22 }








func A_arbace_c_check__init_part0_A_Unit14__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c_check_feat_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c_check_feat_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_424, false, nil); A_arbace_c_check_feat_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_25)); return A_arbace_c_check__init_part0_A_const_24 }





func A_arbace_c_check__init_part0_A_Unit15__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c_check_err_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c_check_err_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_425, false, nil); A_arbace_c_check_err_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_27)); return A_arbace_c_check__init_part0_A_const_26 }






func A_arbace_c_check__init_part0_A_Unit16__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c_check_pedwarn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c_check_pedwarn_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_426, false, nil); A_arbace_c_check_pedwarn_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_29)); return A_arbace_c_check__init_part0_A_const_28 }









func A_arbace_c_check__init_part0_A_Unit17__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(81, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_c_check_line_of_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c_check_line_of_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_427, false, nil); A_arbace_c_check_line_of_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_31)); return A_arbace_c_check__init_part0_A_const_30 }

func A_arbace_c_check__init_part0_A_Unit18__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_c_check_record_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c_check_record_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_428, false, nil); A_arbace_c_check_record_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_33)); return A_arbace_c_check__init_part0_A_const_32 }







func A_arbace_c_check__init_part0_A_Unit19__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_34; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__22 any = A_arbace_c_check_at_line_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c_check_at_line_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_429, true, nil); A_arbace_c_check_at_line_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__22, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_35)); return A_arbace_c_check__init_part0_A_const_34 }
//line :91:1
func A_arbace_c_check__init_part0_A_Unit20__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); A_arbace_c_check__init_part0_A_const_34.SetMacro__V(); return nil }
//line :91:1
func A_arbace_c_check__init_part0_A_Unit21__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); return A_arbace_c_check__init_part0_A_const_34 }


func A_arbace_c_check__init_part0_A_Unit22__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c_check_std_num_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c_check_std_num_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_430, false, nil); A_arbace_c_check_std_num_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_37)); return A_arbace_c_check__init_part0_A_const_36 }




func A_arbace_c_check__init_part0_A_Unit23__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(99, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c_check_c23_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c_check_c23_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_431, false, nil); A_arbace_c_check_c23_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_39)); return A_arbace_c_check__init_part0_A_const_38 }
func A_arbace_c_check__init_part0_A_Unit24__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(100, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c_check_c99_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c_check_c99_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_432, false, nil); A_arbace_c_check_c99_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_41)); return A_arbace_c_check__init_part0_A_const_40 }

func A_arbace_c_check__init_part0_A_Unit25__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c_check_pedwarn_c2y_BANG__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c_check_pedwarn_c2y_BANG__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_433, false, nil); A_arbace_c_check_pedwarn_c2y_BANG__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_43)); return A_arbace_c_check__init_part0_A_const_42 }







func A_arbace_c_check__init_part0_A_Unit26__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c_check_bit_field_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c_check_bit_field_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_434, false, nil); A_arbace_c_check_bit_field_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_45)); return A_arbace_c_check__init_part0_A_const_44 }





func A_arbace_c_check__init_part0_A_Unit27__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); A_arbace_c_check__init_part0_A_const_46.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_47); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_46; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_48)); return A_arbace_c_check__init_part0_A_const_46 }
func A_arbace_c_check__init_part0_A_Unit28__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); A_arbace_c_check__init_part0_A_const_49.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_50); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_51)); return A_arbace_c_check__init_part0_A_const_49 }
func A_arbace_c_check__init_part0_A_Unit29__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(118, 1); A_arbace_c_check__init_part0_A_const_52.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_53); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_54)); return A_arbace_c_check__init_part0_A_const_52 }
func A_arbace_c_check__init_part0_A_Unit30__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(119, 1); A_arbace_c_check__init_part0_A_const_55.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_56); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_55; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_57)); return A_arbace_c_check__init_part0_A_const_55 }
func A_arbace_c_check__init_part0_A_Unit31__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); A_arbace_c_check__init_part0_A_const_58.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_59); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_58; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_60)); return A_arbace_c_check__init_part0_A_const_58 }
func A_arbace_c_check__init_part0_A_Unit32__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); A_arbace_c_check__init_part0_A_const_61.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_62); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_61; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_63)); return A_arbace_c_check__init_part0_A_const_61 }
func A_arbace_c_check__init_part0_A_Unit33__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); A_arbace_c_check__init_part0_A_const_64.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_65); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_66)); return A_arbace_c_check__init_part0_A_const_64 }
func A_arbace_c_check__init_part0_A_Unit34__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); A_arbace_c_check__init_part0_A_const_67.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_68); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_67; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_69)); return A_arbace_c_check__init_part0_A_const_67 }
func A_arbace_c_check__init_part0_A_Unit35__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); A_arbace_c_check__init_part0_A_const_70.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_71); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_70; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_72)); return A_arbace_c_check__init_part0_A_const_70 }
func A_arbace_c_check__init_part0_A_Unit36__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); A_arbace_c_check__init_part0_A_const_73.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_74); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_73; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_75)); return A_arbace_c_check__init_part0_A_const_73 }
func A_arbace_c_check__init_part0_A_Unit37__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); A_arbace_c_check__init_part0_A_const_76.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_77); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_78)); return A_arbace_c_check__init_part0_A_const_76 }
func A_arbace_c_check__init_part0_A_Unit38__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(127, 1); A_arbace_c_check__init_part0_A_const_79.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_80); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_79; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_81)); return A_arbace_c_check__init_part0_A_const_79 }

func A_arbace_c_check__init_part0_A_Unit39__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(129, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c_check_ptr_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c_check_ptr_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_435, false, nil); A_arbace_c_check_ptr_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_83)); return A_arbace_c_check__init_part0_A_const_82 }
func A_arbace_c_check__init_part0_A_Unit40__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c_check_arr_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c_check_arr_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_436, false, nil); A_arbace_c_check_arr_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_85)); return A_arbace_c_check__init_part0_A_const_84 }

func A_arbace_c_check__init_part0_A_Unit41__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); A_arbace_c_check__init_part0_A_const_86.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_87); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_88)); return A_arbace_c_check__init_part0_A_const_86 }










func A_arbace_c_check__init_part0_A_Unit42__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); A_arbace_c_check__init_part0_A_const_89.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_90); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_89; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_91)); return A_arbace_c_check__init_part0_A_const_89 }





func A_arbace_c_check__init_part0_A_Unit43__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); A_arbace_c_check__init_part0_A_const_92.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_93); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_92; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_94)); return A_arbace_c_check__init_part0_A_const_92 }



func A_arbace_c_check__init_part0_A_Unit44__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(153, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c_check_float_tie_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c_check_float_tie_A_fn_class; if

	fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_437, false, nil); A_arbace_c_check_float_tie_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); /*line :153:1*/tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_96)); return A_arbace_c_check__init_part0_A_const_95 }



func A_arbace_c_check__init_part0_A_Unit45__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_c_check_unq_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c_check_unq_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_438, false, nil); A_arbace_c_check_unq_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_98)); return A_arbace_c_check__init_part0_A_const_97 }
func A_arbace_c_check__init_part0_A_Unit46__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_c_check_qual_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c_check_qual_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_439, false, nil); A_arbace_c_check_qual_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_100)); return A_arbace_c_check__init_part0_A_const_99 }
func A_arbace_c_check__init_part0_A_Unit47__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(159, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_c_check_quals_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c_check_quals_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_440, false, nil); A_arbace_c_check_quals_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_102)); return A_arbace_c_check__init_part0_A_const_101 }

func A_arbace_c_check__init_part0_A_Unit48__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_c_check_char_signed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c_check_char_signed_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_441, false, nil); A_arbace_c_check_char_signed_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_104)); return A_arbace_c_check__init_part0_A_const_103 }

func A_arbace_c_check__init_part0_A_Unit49__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(163, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_c_check_enum_under_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c_check_enum_under_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_442, false, nil); A_arbace_c_check_enum_under_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_106)); return A_arbace_c_check__init_part0_A_const_105 }




func A_arbace_c_check__init_part0_A_Unit50__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_c_check_int_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c_check_int_type_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_443, false, nil); A_arbace_c_check_int_type_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_108)); return A_arbace_c_check__init_part0_A_const_107 }
func A_arbace_c_check__init_part0_A_Unit51__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(169, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_c_check_float_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c_check_float_type_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_444, false, nil); A_arbace_c_check_float_type_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_110)); return A_arbace_c_check__init_part0_A_const_109 }
func A_arbace_c_check__init_part0_A_Unit52__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(170, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_c_check_complex_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_c_check_complex_type_QMARK__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_445, false, nil); A_arbace_c_check_complex_type_QMARK__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_112)); return A_arbace_c_check__init_part0_A_const_111 }
func A_arbace_c_check__init_part0_A_Unit53__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_c_check_arith_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c_check_arith_type_QMARK__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_446, false, nil); A_arbace_c_check_arith_type_QMARK__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_114)); return A_arbace_c_check__init_part0_A_const_113 }
func A_arbace_c_check__init_part0_A_Unit54__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_c_check_ptr_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_c_check_ptr_type_QMARK__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_447, false, nil); A_arbace_c_check_ptr_type_QMARK__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_116)); return A_arbace_c_check__init_part0_A_const_115 }
func A_arbace_c_check__init_part0_A_Unit55__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_c_check_scalar_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_c_check_scalar_type_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_448, false, nil); A_arbace_c_check_scalar_type_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_118)); return A_arbace_c_check__init_part0_A_const_117 }
func A_arbace_c_check__init_part0_A_Unit56__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_c_check_record_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_c_check_record_type_QMARK__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_449, false, nil); A_arbace_c_check_record_type_QMARK__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_120)); return A_arbace_c_check__init_part0_A_const_119 }
func A_arbace_c_check__init_part0_A_Unit57__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_c_check_void_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c_check_void_type_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_450, false, nil); A_arbace_c_check_void_type_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_122)); return A_arbace_c_check__init_part0_A_const_121 }

func A_arbace_c_check__init_part0_A_Unit58__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_c_check_int_bits_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c_check_int_bits_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_451, false, nil); A_arbace_c_check_int_bits_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_124)); return A_arbace_c_check__init_part0_A_const_123 }








func A_arbace_c_check__init_part0_A_Unit59__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(186, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_c_check_rank_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_c_check_rank_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_452, false, nil); A_arbace_c_check_rank_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_126)); return A_arbace_c_check__init_part0_A_const_125 }





func A_arbace_c_check__init_part0_A_Unit60__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_c_check_wrap_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_c_check_wrap_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_453, false, nil); A_arbace_c_check_wrap_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_128)); return A_arbace_c_check__init_part0_A_const_127 }












func A_arbace_c_check__init_part0_A_Unit61__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_c_check_ldouble_size_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c_check_ldouble_size_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_454, false, nil); A_arbace_c_check_ldouble_size_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_130)); return A_arbace_c_check__init_part0_A_const_129 }

func A_arbace_c_check__init_part0_A_Unit62__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_131; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_132)); return A_arbace_c_check__init_part0_A_const_131 }
//line :207:1
func A_arbace_c_check__init_part0_A_Unit63__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_133; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_134)); return A_arbace_c_check__init_part0_A_const_133 }
//line :207:1
func A_arbace_c_check__init_part0_A_Unit64__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_135; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_136)); return A_arbace_c_check__init_part0_A_const_135 }
//line :207:1
func A_arbace_c_check__init_part0_A_Unit65__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_137; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_138)); return A_arbace_c_check__init_part0_A_const_137 }

func A_arbace_c_check__init_part0_A_Unit66__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_c_check_bitint_size_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_c_check_bitint_size_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_455, false, nil); A_arbace_c_check_bitint_size_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_140)); return A_arbace_c_check__init_part0_A_const_139 }

func A_arbace_c_check__init_part0_A_Unit67__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(211, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_c_check_size_of_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_c_check_size_of_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_456, false, nil); A_arbace_c_check_size_of_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_141)); return A_arbace_c_check__init_part0_A_const_131 }





















func A_arbace_c_check__init_part0_A_Unit68__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(233, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_142; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_143)); return A_arbace_c_check__init_part0_A_const_142 }

func A_arbace_c_check__init_part0_A_Unit69__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_c_check_align_of_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c_check_align_of_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_457, false, nil); A_arbace_c_check_align_of_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_144)); return A_arbace_c_check__init_part0_A_const_133 }




func A_arbace_c_check__init_part0_A_Unit70__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(240, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_c_check_align_of_STAR__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c_check_align_of_STAR__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_458, false, nil); A_arbace_c_check_align_of_STAR__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_145)); return A_arbace_c_check__init_part0_A_const_142 }












func A_arbace_c_check__init_part0_A_Unit71__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_c_check_rec_of_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_c_check_rec_of_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_459, false, nil); A_arbace_c_check_rec_of_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_147)); return A_arbace_c_check__init_part0_A_const_146 }

func A_arbace_c_check__init_part0_A_Unit72__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_c_check_tstr_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_c_check_tstr_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_460, false, nil); A_arbace_c_check_tstr_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_149)); return A_arbace_c_check__init_part0_A_const_148 }








































func A_arbace_c_check__init_part0_A_Unit73__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(296, 1); A_arbace_c_check__init_part0_A_const_150.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_8); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_150; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_151)); return A_arbace_c_check__init_part0_A_const_150.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_check__init_part0_A_Unit74__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_152; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_153)); return A_arbace_c_check__init_part0_A_const_152 }

func A_arbace_c_check__init_part0_A_Unit75__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_c_check_mcompat_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_c_check_mcompat_QMARK__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_461, false, nil); A_arbace_c_check_mcompat_QMARK__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_155)); return A_arbace_c_check__init_part0_A_const_154 }
















func A_arbace_c_check__init_part0_A_Unit76__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(317, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_c_check_union_param_match_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_c_check_union_param_match_QMARK__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_462, false, nil); A_arbace_c_check_union_param_match_QMARK__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_157)); return A_arbace_c_check__init_part0_A_const_156 }













func A_arbace_c_check__init_part0_A_Unit77__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(331, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_c_check_compatible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_c_check_compatible_QMARK__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_463, false, nil); A_arbace_c_check_compatible_QMARK__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_158)); return A_arbace_c_check__init_part0_A_const_152 }









































func A_arbace_c_check__init_part0_A_Unit78__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(373, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_c_check_decay_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_c_check_decay_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_464, false, nil); A_arbace_c_check_decay_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_160)); return A_arbace_c_check__init_part0_A_const_159 }







func A_arbace_c_check__init_part0_A_Unit79__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_c_check_promote_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_c_check_promote_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_465, false, nil); A_arbace_c_check_promote_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_162)); return A_arbace_c_check__init_part0_A_const_161 }
















func A_arbace_c_check__init_part0_A_Unit80__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(398, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_c_check_unsigned_of_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_c_check_unsigned_of_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_466, false, nil); A_arbace_c_check_unsigned_of_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_164)); return A_arbace_c_check__init_part0_A_const_163 }





func A_arbace_c_check__init_part0_A_Unit81__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(404, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_c_check_float_of_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_c_check_float_of_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_467, false, nil); A_arbace_c_check_float_of_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_166)); return A_arbace_c_check__init_part0_A_const_165 }

func A_arbace_c_check__init_part0_A_Unit82__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(406, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_167; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_c_check_usual_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_c_check_usual_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_468, false, nil); A_arbace_c_check_usual_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_168)); return A_arbace_c_check__init_part0_A_const_167 }


































func A_arbace_c_check__init_part0_A_Unit83__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(441, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_c_check_push_scope_BANG__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_c_check_push_scope_BANG__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_469, false, nil); A_arbace_c_check_push_scope_BANG__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_170)); return A_arbace_c_check__init_part0_A_const_169 }
func A_arbace_c_check__init_part0_A_Unit84__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(442, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_c_check_pop_scope_BANG__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_c_check_pop_scope_BANG__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_470, false, nil); A_arbace_c_check_pop_scope_BANG__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_172)); return A_arbace_c_check__init_part0_A_const_171 }
func A_arbace_c_check__init_part0_A_Unit85__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(443, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_173; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_c_check_top_scope_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c_check_top_scope_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_471, false, nil); A_arbace_c_check_top_scope_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_174)); return A_arbace_c_check__init_part0_A_const_173 }
func A_arbace_c_check__init_part0_A_Unit86__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(444, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_c_check_file_scope_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_c_check_file_scope_QMARK__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_472, false, nil); A_arbace_c_check_file_scope_QMARK__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_176)); return A_arbace_c_check__init_part0_A_const_175 }

func A_arbace_c_check__init_part0_A_Unit87__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(446, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_177; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__110 any = A_arbace_c_check_with_scope_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_c_check_with_scope_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_473, true, nil); A_arbace_c_check_with_scope_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__110, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_178)); return A_arbace_c_check__init_part0_A_const_177 }
//line :446:1
func A_arbace_c_check__init_part0_A_Unit88__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(446, 1); A_arbace_c_check__init_part0_A_const_177.SetMacro__V(); return nil }
//line :446:1
func A_arbace_c_check__init_part0_A_Unit89__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(446, 1); return A_arbace_c_check__init_part0_A_const_177 }


func A_arbace_c_check__init_part0_A_Unit90__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(449, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_179; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_c_check_lookup_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_c_check_lookup_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_474, false, nil); A_arbace_c_check_lookup_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_180)); return A_arbace_c_check__init_part0_A_const_179 }







func A_arbace_c_check__init_part0_A_Unit91__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(457, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_181; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_c_check_lookup_tag_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_c_check_lookup_tag_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_475, false, nil); A_arbace_c_check_lookup_tag_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_182)); return A_arbace_c_check__init_part0_A_const_181 }





func A_arbace_c_check__init_part0_A_Unit92__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(463, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_183; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_c_check_declare_BANG__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_c_check_declare_BANG__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_476, false, nil); A_arbace_c_check_declare_BANG__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_184)); return A_arbace_c_check__init_part0_A_const_183 }

func A_arbace_c_check__init_part0_A_Unit93__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_185; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_c_check_file_declare_BANG__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_c_check_file_declare_BANG__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_477, false, nil); A_arbace_c_check_file_declare_BANG__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_186)); return A_arbace_c_check__init_part0_A_const_185 }





func A_arbace_c_check__init_part0_A_Unit94__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_187; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_c_check_ident_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_c_check_ident_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_478, false, nil); A_arbace_c_check_ident_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_188)); return A_arbace_c_check__init_part0_A_const_187 }







func A_arbace_c_check__init_part0_A_Unit95__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(479, 1); A_arbace_c_check__init_part0_A_const_189.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_190); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_189; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_191)); return A_arbace_c_check__init_part0_A_const_189 }


func A_arbace_c_check__init_part0_A_Unit96__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(482, 1); A_arbace_c_check__init_part0_A_const_192.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_193); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_192; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_194)); return A_arbace_c_check__init_part0_A_const_192 }




func A_arbace_c_check__init_part0_A_Unit97__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(487, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_195; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_c_check_attr_items_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_c_check_attr_items_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_479, false, nil); A_arbace_c_check_attr_items_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_195; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_196)); return A_arbace_c_check__init_part0_A_const_195 }















func A_arbace_c_check__init_part0_A_Unit98__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(503, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_197; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__124 any = A_arbace_c_check_attrs_of_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_c_check_attrs_of_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_480, true, nil); A_arbace_c_check_attrs_of_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__124, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part0_A_const_197; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_198)); return A_arbace_c_check__init_part0_A_const_197 }

func A_arbace_c_check__init_part0_A_Unit99__O() any { A_arbace_c_check__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(505, 1); A_arbace_c_check__init_part0_A_const_199.BindRoot_O__V(A_arbace_c_check__init_part0_A_const_200); var tmp1 *lang.Var = A_arbace_c_check__init_part0_A_const_199; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part0_A_const_201)); return A_arbace_c_check__init_part0_A_const_199 }

func A_arbace_c_check__init_part1_A_Unit100__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_0; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_1)); return A_arbace_c_check__init_part1_A_const_0 }
//line :507:1
func A_arbace_c_check__init_part1_A_Unit101__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_3)); return A_arbace_c_check__init_part1_A_const_2 }
//line :507:1
func A_arbace_c_check__init_part1_A_Unit102__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_5)); return A_arbace_c_check__init_part1_A_const_4 }
//line :507:1
func A_arbace_c_check__init_part1_A_Unit103__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_7)); return A_arbace_c_check__init_part1_A_const_6 }
//line :507:1
func A_arbace_c_check__init_part1_A_Init__O() any { A_arbace_c_check__init_part1_A_Init(); return nil }
//line :507:1
func A_arbace_c_check__init_part1_A_Load__O() any { A_arbace_c_check__init_part1_A_Init(); A_arbace_c_check__init_part1_A_Unit100__O(); A_arbace_c_check__init_part1_A_Unit101__O(); A_arbace_c_check__init_part1_A_Unit102__O(); A_arbace_c_check__init_part1_A_Unit103__O(); A_arbace_c_check__init_part1_A_Unit104__O(); A_arbace_c_check__init_part1_A_Unit105__O(); A_arbace_c_check__init_part1_A_Unit106__O(); A_arbace_c_check__init_part1_A_Unit107__O(); A_arbace_c_check__init_part1_A_Unit108__O(); A_arbace_c_check__init_part1_A_Unit109__O(); A_arbace_c_check__init_part1_A_Unit110__O(); A_arbace_c_check__init_part1_A_Unit111__O(); A_arbace_c_check__init_part1_A_Unit112__O(); A_arbace_c_check__init_part1_A_Unit113__O(); A_arbace_c_check__init_part1_A_Unit114__O(); A_arbace_c_check__init_part1_A_Unit115__O(); A_arbace_c_check__init_part1_A_Unit116__O(); A_arbace_c_check__init_part1_A_Unit117__O(); A_arbace_c_check__init_part1_A_Unit118__O(); A_arbace_c_check__init_part1_A_Unit119__O(); A_arbace_c_check__init_part1_A_Unit120__O(); A_arbace_c_check__init_part1_A_Unit121__O(); A_arbace_c_check__init_part1_A_Unit122__O(); A_arbace_c_check__init_part1_A_Unit123__O(); A_arbace_c_check__init_part1_A_Unit124__O(); A_arbace_c_check__init_part1_A_Unit125__O(); A_arbace_c_check__init_part1_A_Unit126__O(); A_arbace_c_check__init_part1_A_Unit127__O(); A_arbace_c_check__init_part1_A_Unit128__O(); A_arbace_c_check__init_part1_A_Unit129__O(); A_arbace_c_check__init_part1_A_Unit130__O(); A_arbace_c_check__init_part1_A_Unit131__O(); A_arbace_c_check__init_part1_A_Unit132__O(); A_arbace_c_check__init_part1_A_Unit133__O(); A_arbace_c_check__init_part1_A_Unit134__O(); A_arbace_c_check__init_part1_A_Unit135__O(); A_arbace_c_check__init_part1_A_Unit136__O(); A_arbace_c_check__init_part1_A_Unit137__O(); A_arbace_c_check__init_part1_A_Unit138__O(); A_arbace_c_check__init_part1_A_Unit139__O(); A_arbace_c_check__init_part1_A_Unit140__O(); A_arbace_c_check__init_part1_A_Unit141__O(); A_arbace_c_check__init_part1_A_Unit142__O(); A_arbace_c_check__init_part1_A_Unit143__O(); A_arbace_c_check__init_part1_A_Unit144__O(); A_arbace_c_check__init_part1_A_Unit145__O(); A_arbace_c_check__init_part1_A_Unit146__O(); A_arbace_c_check__init_part1_A_Unit147__O(); A_arbace_c_check__init_part1_A_Unit148__O(); A_arbace_c_check__init_part1_A_Unit149__O(); A_arbace_c_check__init_part1_A_Unit150__O(); A_arbace_c_check__init_part1_A_Unit151__O(); A_arbace_c_check__init_part1_A_Unit152__O(); A_arbace_c_check__init_part1_A_Unit153__O(); A_arbace_c_check__init_part1_A_Unit154__O(); A_arbace_c_check__init_part1_A_Unit155__O(); A_arbace_c_check__init_part1_A_Unit156__O(); A_arbace_c_check__init_part1_A_Unit157__O(); A_arbace_c_check__init_part1_A_Unit158__O(); A_arbace_c_check__init_part1_A_Unit159__O(); A_arbace_c_check__init_part1_A_Unit160__O(); A_arbace_c_check__init_part1_A_Unit161__O(); A_arbace_c_check__init_part1_A_Unit162__O(); A_arbace_c_check__init_part1_A_Unit163__O(); A_arbace_c_check__init_part1_A_Unit164__O(); A_arbace_c_check__init_part1_A_Unit165__O(); A_arbace_c_check__init_part1_A_Unit166__O(); A_arbace_c_check__init_part1_A_Unit167__O(); A_arbace_c_check__init_part1_A_Unit168__O(); A_arbace_c_check__init_part1_A_Unit169__O(); A_arbace_c_check__init_part1_A_Unit170__O(); A_arbace_c_check__init_part1_A_Unit171__O(); A_arbace_c_check__init_part1_A_Unit172__O(); A_arbace_c_check__init_part1_A_Unit173__O(); A_arbace_c_check__init_part1_A_Unit174__O(); A_arbace_c_check__init_part1_A_Unit175__O(); A_arbace_c_check__init_part1_A_Unit176__O(); A_arbace_c_check__init_part1_A_Unit177__O(); A_arbace_c_check__init_part1_A_Unit178__O(); A_arbace_c_check__init_part1_A_Unit179__O(); A_arbace_c_check__init_part1_A_Unit180__O(); A_arbace_c_check__init_part1_A_Unit181__O(); A_arbace_c_check__init_part1_A_Unit182__O(); A_arbace_c_check__init_part1_A_Unit183__O(); A_arbace_c_check__init_part1_A_Unit184__O(); A_arbace_c_check__init_part1_A_Unit185__O(); A_arbace_c_check__init_part1_A_Unit186__O(); A_arbace_c_check__init_part1_A_Unit187__O(); A_arbace_c_check__init_part1_A_Unit188__O(); A_arbace_c_check__init_part1_A_Unit189__O(); A_arbace_c_check__init_part1_A_Unit190__O(); A_arbace_c_check__init_part1_A_Unit191__O(); A_arbace_c_check__init_part1_A_Unit192__O(); A_arbace_c_check__init_part1_A_Unit193__O(); A_arbace_c_check__init_part1_A_Unit194__O(); A_arbace_c_check__init_part1_A_Unit195__O(); A_arbace_c_check__init_part1_A_Unit196__O(); A_arbace_c_check__init_part1_A_Unit197__O(); A_arbace_c_check__init_part1_A_Unit198__O(); A_arbace_c_check__init_part1_A_Unit199__O(); return nil }

func A_arbace_c_check__init_part1_A_Unit104__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(509, 1); A_arbace_c_check__init_part1_A_const_8.BindRoot_O__V(A_arbace_c_check__init_part1_A_const_9); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_10)); return A_arbace_c_check__init_part1_A_const_8 }
func A_arbace_c_check__init_part1_A_Unit105__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(510, 1); A_arbace_c_check__init_part1_A_const_11.BindRoot_O__V(A_arbace_c_check__init_part1_A_const_12); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_13)); return A_arbace_c_check__init_part1_A_const_11 }

func A_arbace_c_check__init_part1_A_Unit106__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(512, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c_check_std_attr_check_BANG__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c_check_std_attr_check_BANG__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_482, false, nil); A_arbace_c_check_std_attr_check_BANG__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_15)); return A_arbace_c_check__init_part1_A_const_14 }

















func A_arbace_c_check__init_part1_A_Unit107__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(530, 1); A_arbace_c_check__init_part1_A_const_16.BindRoot_O__V(A_arbace_c_check__init_part1_A_const_17); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_18)); return A_arbace_c_check__init_part1_A_const_16 }
func A_arbace_c_check__init_part1_A_Unit108__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); A_arbace_c_check__init_part1_A_const_19.BindRoot_O__V(A_arbace_c_check__init_part1_A_const_20); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_19; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_21)); return A_arbace_c_check__init_part1_A_const_19 }

func A_arbace_c_check__init_part1_A_Unit109__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(533, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c_check_std_names_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c_check_std_names_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_483, false, nil); A_arbace_c_check_std_names_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_23)); return A_arbace_c_check__init_part1_A_const_22 }




func A_arbace_c_check__init_part1_A_Unit110__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(538, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_c_check_ignored_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c_check_ignored_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_484, false, nil); A_arbace_c_check_ignored_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_25)); return A_arbace_c_check__init_part1_A_const_24 }





func A_arbace_c_check__init_part1_A_Unit111__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(544, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_c_check_std_attr_misc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c_check_std_attr_misc_BANG__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_485, false, nil); A_arbace_c_check_std_attr_misc_BANG__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_27)); return A_arbace_c_check__init_part1_A_const_26 }







func A_arbace_c_check__init_part1_A_Unit112__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c_check_tag_attrs_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c_check_tag_attrs_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_486, false, nil); A_arbace_c_check_tag_attrs_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_29)); return A_arbace_c_check__init_part1_A_const_28 }









func A_arbace_c_check__init_part1_A_Unit113__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(562, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c_check_type_pos_attrs_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c_check_type_pos_attrs_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_487, false, nil); A_arbace_c_check_type_pos_attrs_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_31)); return A_arbace_c_check__init_part1_A_const_30 }








func A_arbace_c_check__init_part1_A_Unit114__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(571, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c_check_base_fn_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c_check_base_fn_type_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_488, false, nil); A_arbace_c_check_base_fn_type_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_33)); return A_arbace_c_check__init_part1_A_const_32 }







func A_arbace_c_check__init_part1_A_Unit115__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(579, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c_check_decl_position_attrs_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c_check_decl_position_attrs_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_489, false, nil); A_arbace_c_check_decl_position_attrs_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_35)); return A_arbace_c_check__init_part1_A_const_34 }

















func A_arbace_c_check__init_part1_A_Unit116__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(597, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_c_check_attr_args_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c_check_attr_args_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_490, false, nil); A_arbace_c_check_attr_args_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_37)); return A_arbace_c_check__init_part1_A_const_36 }













func A_arbace_c_check__init_part1_A_Unit117__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(611, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_c_check_assoc_in_mode_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c_check_assoc_in_mode_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_491, false, nil); A_arbace_c_check_assoc_in_mode_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_39)); return A_arbace_c_check__init_part1_A_const_38 }




func A_arbace_c_check__init_part1_A_Unit118__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(616, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_c_check_vectorize_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c_check_vectorize_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_492, false, nil); A_arbace_c_check_vectorize_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_41)); return A_arbace_c_check__init_part1_A_const_40 }





























func A_arbace_c_check__init_part1_A_Unit119__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(646, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c_check_aligned_value_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c_check_aligned_value_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_493, false, nil); A_arbace_c_check_aligned_value_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_43)); return A_arbace_c_check__init_part1_A_const_42 }









func A_arbace_c_check__init_part1_A_Unit120__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(656, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c_check_big_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c_check_big_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_494, false, nil); A_arbace_c_check_big_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_45)); return A_arbace_c_check__init_part1_A_const_44 }

func A_arbace_c_check__init_part1_A_Unit121__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(658, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c_check_num_val_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c_check_num_val_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_495, false, nil); A_arbace_c_check_num_val_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_47)); return A_arbace_c_check__init_part1_A_const_46 }




func A_arbace_c_check__init_part1_A_Unit122__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(663, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c_check_new_rec_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c_check_new_rec_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_496, false, nil); A_arbace_c_check_new_rec_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_49)); return A_arbace_c_check__init_part1_A_const_48 }




func A_arbace_c_check__init_part1_A_Unit123__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(668, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c_check_align_up_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c_check_align_up_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_497, false, nil); A_arbace_c_check_align_up_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_51)); return A_arbace_c_check__init_part1_A_const_50 }

func A_arbace_c_check__init_part1_A_Unit124__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(670, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c_check_member_align_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c_check_member_align_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_498, false, nil); A_arbace_c_check_member_align_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_53)); return A_arbace_c_check__init_part1_A_const_52 }







func A_arbace_c_check__init_part1_A_Unit125__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(678, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c_check_layout_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c_check_layout_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_499, false, nil); A_arbace_c_check_layout_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_55)); return A_arbace_c_check__init_part1_A_const_54 }






















































func A_arbace_c_check__init_part1_A_Unit126__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(733, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c_check_member_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c_check_member_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_500, false, nil); A_arbace_c_check_member_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_57)); return A_arbace_c_check__init_part1_A_const_56 }














func A_arbace_c_check__init_part1_A_Unit127__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(748, 1); A_arbace_c_check__init_part1_A_const_58.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_58; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_59)); return A_arbace_c_check__init_part1_A_const_58.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_check__init_part1_A_Unit128__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(750, 1); A_arbace_c_check__init_part1_A_const_60.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_61)); return A_arbace_c_check__init_part1_A_const_60.SetDynamic_Z__Var(true).Ref() }



func A_arbace_c_check__init_part1_A_Unit129__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(754, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_c_check_tag_ref_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c_check_tag_ref_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_501, false, nil); A_arbace_c_check_tag_ref_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_63)); return A_arbace_c_check__init_part1_A_const_62 }








func A_arbace_c_check__init_part1_A_Unit130__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(763, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_65)); return A_arbace_c_check__init_part1_A_const_64 }
//line :763:1
func A_arbace_c_check__init_part1_A_Unit131__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(763, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_67)); return A_arbace_c_check__init_part1_A_const_66 }

func A_arbace_c_check__init_part1_A_Unit132__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(765, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_c_check_int_mode_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c_check_int_mode_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_502, false, nil); A_arbace_c_check_int_mode_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_69)); return A_arbace_c_check__init_part1_A_const_68 }




func A_arbace_c_check__init_part1_A_Unit133__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(770, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_c_check_int_mode_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c_check_int_mode_QMARK__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_503, false, nil); A_arbace_c_check_int_mode_QMARK__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_71)); return A_arbace_c_check__init_part1_A_const_70 }

func A_arbace_c_check__init_part1_A_Unit134__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(772, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_c_check_mode_precision_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c_check_mode_precision_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_504, false, nil); A_arbace_c_check_mode_precision_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_73)); return A_arbace_c_check__init_part1_A_const_72 }











func A_arbace_c_check__init_part1_A_Unit135__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(784, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_c_check_type_mode_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c_check_type_mode_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_505, false, nil); A_arbace_c_check_type_mode_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_75)); return A_arbace_c_check__init_part1_A_const_74 }













































func A_arbace_c_check__init_part1_A_Unit136__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(830, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_c_check_transparent_ok_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c_check_transparent_ok_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_506, false, nil); A_arbace_c_check_transparent_ok_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_77)); return A_arbace_c_check__init_part1_A_const_76 }












func A_arbace_c_check__init_part1_A_Unit137__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(843, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_c_check_spec_attrs_packed_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c_check_spec_attrs_packed_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_507, false, nil); A_arbace_c_check_spec_attrs_packed_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_79)); return A_arbace_c_check__init_part1_A_const_78 }

func A_arbace_c_check__init_part1_A_Unit138__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(845, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_c_check_bitint_width_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_c_check_bitint_width_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_508, false, nil); A_arbace_c_check_bitint_width_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_81)); return A_arbace_c_check__init_part1_A_const_80 }















func A_arbace_c_check__init_part1_A_Unit139__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(861, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_c_check_parse_type_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c_check_parse_type_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_509, false, nil); A_arbace_c_check_parse_type_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_82)); return A_arbace_c_check__init_part1_A_const_6 }














































































func A_arbace_c_check__init_part1_A_Unit140__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(940, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_c_check_exi_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_c_check_exi_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_510, false, nil); A_arbace_c_check_exi_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_84)); return A_arbace_c_check__init_part1_A_const_83 }







func A_arbace_c_check__init_part1_A_Unit141__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(948, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_c_check_member_forms_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_c_check_member_forms_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_511, false, nil); A_arbace_c_check_member_forms_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_86)); return A_arbace_c_check__init_part1_A_const_85 }































func A_arbace_c_check__init_part1_A_Unit142__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(980, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_88)); return A_arbace_c_check__init_part1_A_const_87 }

func A_arbace_c_check__init_part1_A_Unit143__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(982, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_c_check_type_eq_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_c_check_type_eq_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_512, false, nil); A_arbace_c_check_type_eq_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_90)); return A_arbace_c_check__init_part1_A_const_89 }















func A_arbace_c_check__init_part1_A_Unit144__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(998, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_c_check_vm_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c_check_vm_type_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_513, false, nil); A_arbace_c_check_vm_type_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_92)); return A_arbace_c_check__init_part1_A_const_91 }













func A_arbace_c_check__init_part1_A_Unit145__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1012, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_c_check_vla_struct_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c_check_vla_struct_QMARK__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_514, false, nil); A_arbace_c_check_vla_struct_QMARK__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_94)); return A_arbace_c_check__init_part1_A_const_93 }








func A_arbace_c_check__init_part1_A_Unit146__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1021, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_c_check_rec_same_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_c_check_rec_same_QMARK__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_515, false, nil); A_arbace_c_check_rec_same_QMARK__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_95)); return A_arbace_c_check__init_part1_A_const_87 }














func A_arbace_c_check__init_part1_A_Unit147__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1036, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_c_check_check_struct_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_c_check_check_struct_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_516, false, nil); A_arbace_c_check_check_struct_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_96)); return A_arbace_c_check__init_part1_A_const_64 }























































func A_arbace_c_check__init_part1_A_Unit148__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1092, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_c_check_enum_type_of_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c_check_enum_type_of_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_517, false, nil); A_arbace_c_check_enum_type_of_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_98)); return A_arbace_c_check__init_part1_A_const_97 }










func A_arbace_c_check__init_part1_A_Unit149__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1103, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_c_check_check_enum_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_c_check_check_enum_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_518, false, nil); A_arbace_c_check_check_enum_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_99)); return A_arbace_c_check__init_part1_A_const_66 }



























































































func A_arbace_c_check__init_part1_A_Unit150__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1195, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_100; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__76 any = A_arbace_c_check_res_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_c_check_res_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_519, true, nil); A_arbace_c_check_res_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__76, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_101)); return A_arbace_c_check__init_part1_A_const_100 }

func A_arbace_c_check__init_part1_A_Unit151__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1197, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_c_check_emit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c_check_emit_BANG__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_520, false, nil); A_arbace_c_check_emit_BANG__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_103)); return A_arbace_c_check__init_part1_A_const_102 }









func A_arbace_c_check__init_part1_A_Unit152__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1207, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_c_check_round_sig_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c_check_round_sig_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_521, false, nil); A_arbace_c_check_round_sig_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_105)); return A_arbace_c_check__init_part1_A_const_104 }












func A_arbace_c_check__init_part1_A_Unit153__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1220, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_c_check_round_to_format_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_c_check_round_to_format_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_522, false, nil); A_arbace_c_check_round_to_format_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_107)); return A_arbace_c_check__init_part1_A_const_106 }









func A_arbace_c_check__init_part1_A_Unit154__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1230, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_c_check_round_exact_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_c_check_round_exact_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_523, false, nil); A_arbace_c_check_round_exact_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_109)); return A_arbace_c_check__init_part1_A_const_108 }




















func A_arbace_c_check__init_part1_A_Unit155__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1251, 1); A_arbace_c_check__init_part1_A_const_110.BindRoot_O__V(A_arbace_c_check__init_part1_A_const_111); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_110; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_112)); return A_arbace_c_check__init_part1_A_const_110 }





func A_arbace_c_check__init_part1_A_Unit156__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1257, 1); A_arbace_c_check__init_part1_A_const_113.BindRoot_O__V(A_arbace_c_check__init_part1_A_const_114); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_113; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_115)); return A_arbace_c_check__init_part1_A_const_113 }



func A_arbace_c_check__init_part1_A_Unit157__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1261, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_c_check_exact_of_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_c_check_exact_of_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_524, false, nil); A_arbace_c_check_exact_of_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_117)); return A_arbace_c_check__init_part1_A_const_116 }







func A_arbace_c_check__init_part1_A_Unit158__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1269, 1); A_arbace_c_check__init_part1_A_const_118.BindRoot_O__V(A_arbace_c_check__init_part1_A_const_119); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_118; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_120)); return A_arbace_c_check__init_part1_A_const_118 }




func A_arbace_c_check__init_part1_A_Unit159__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1274, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_c_check_fits_binary_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_c_check_fits_binary_QMARK__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_525, false, nil); A_arbace_c_check_fits_binary_QMARK__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_122)); return A_arbace_c_check__init_part1_A_const_121 }







func A_arbace_c_check__init_part1_A_Unit160__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1282, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_c_check_round_big_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_c_check_round_big_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_526, false, nil); A_arbace_c_check_round_big_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_124)); return A_arbace_c_check__init_part1_A_const_123 }








func A_arbace_c_check__init_part1_A_Unit161__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1291, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_c_check_float_of_exact_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_c_check_float_of_exact_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_527, false, nil); A_arbace_c_check_float_of_exact_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_126)); return A_arbace_c_check__init_part1_A_const_125 }








func A_arbace_c_check__init_part1_A_Unit162__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1300, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_c_check_eval_type_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_c_check_eval_type_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_528, false, nil); A_arbace_c_check_eval_type_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_128)); return A_arbace_c_check__init_part1_A_const_127 }





func A_arbace_c_check__init_part1_A_Unit163__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1306, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_c_check_conv_val_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_c_check_conv_val_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_529, false, nil); A_arbace_c_check_conv_val_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_130)); return A_arbace_c_check__init_part1_A_const_129 }























func A_arbace_c_check__init_part1_A_Unit164__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1330, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_c_check_lit_type_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_c_check_lit_type_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_530, false, nil); A_arbace_c_check_lit_type_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_132)); return A_arbace_c_check__init_part1_A_const_131 }














func A_arbace_c_check__init_part1_A_Unit165__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1345, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_c_check_byte_string_len_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_c_check_byte_string_len_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_531, false, nil); A_arbace_c_check_byte_string_len_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_134)); return A_arbace_c_check__init_part1_A_const_133 }


func A_arbace_c_check__init_part1_A_Unit166__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1348, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_c_check_code_unit_count_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_c_check_code_unit_count_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_532, false, nil); A_arbace_c_check_code_unit_count_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_136)); return A_arbace_c_check__init_part1_A_const_135 }









func A_arbace_c_check__init_part1_A_Unit167__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_0; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_137)); return A_arbace_c_check__init_part1_A_const_0 }
//line :1358:1
func A_arbace_c_check__init_part1_A_Unit168__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_138; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_139)); return A_arbace_c_check__init_part1_A_const_138 }
//line :1358:1
func A_arbace_c_check__init_part1_A_Unit169__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_140; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_141)); return A_arbace_c_check__init_part1_A_const_140 }
//line :1358:1
func A_arbace_c_check__init_part1_A_Unit170__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_142; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_143)); return A_arbace_c_check__init_part1_A_const_142 }
//line :1358:1
func A_arbace_c_check__init_part1_A_Unit171__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_144; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_145)); return A_arbace_c_check__init_part1_A_const_144 }
//line :1358:1
func A_arbace_c_check__init_part1_A_Unit172__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_146; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_147)); return A_arbace_c_check__init_part1_A_const_146 }

func A_arbace_c_check__init_part1_A_Unit173__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1360, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_c_check_arith_result_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_c_check_arith_result_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_533, false, nil); A_arbace_c_check_arith_result_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_149)); return A_arbace_c_check__init_part1_A_const_148 }


func A_arbace_c_check__init_part1_A_Unit174__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1363, 1); A_arbace_c_check__init_part1_A_const_150.BindRoot_O__V(A_arbace_c_check__init_part1_A_const_151); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_150; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_152)); return A_arbace_c_check__init_part1_A_const_150 }

func A_arbace_c_check__init_part1_A_Unit175__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1365, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_153; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_c_check_int_op_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c_check_int_op_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_534, false, nil); A_arbace_c_check_int_op_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_154)); return A_arbace_c_check__init_part1_A_const_153 }
















func A_arbace_c_check__init_part1_A_Unit176__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1382, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_155; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_c_check_float_op_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_c_check_float_op_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_535, false, nil); A_arbace_c_check_float_op_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_156)); return A_arbace_c_check__init_part1_A_const_155 }




func A_arbace_c_check__init_part1_A_Unit177__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1387, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_157; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_c_check_cmp_val_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_c_check_cmp_val_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_536, false, nil); A_arbace_c_check_cmp_val_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_158)); return A_arbace_c_check__init_part1_A_const_157 }





func A_arbace_c_check__init_part1_A_Unit178__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1393, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_c_check_null_const_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_c_check_null_const_QMARK__A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_537, false, nil); A_arbace_c_check_null_const_QMARK__A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_160)); return A_arbace_c_check__init_part1_A_const_159 }




func A_arbace_c_check__init_part1_A_Unit179__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1398, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_c_check_null_const_npc_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_c_check_null_const_npc_QMARK__A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_538, false, nil); A_arbace_c_check_null_const_npc_QMARK__A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_162)); return A_arbace_c_check__init_part1_A_const_161 }





func A_arbace_c_check__init_part1_A_Unit180__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1404, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_c_check_binary_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_c_check_binary_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_539, false, nil); A_arbace_c_check_binary_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_164)); return A_arbace_c_check__init_part1_A_const_163 }



















































































func A_arbace_c_check__init_part1_A_Unit181__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1488, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_c_check_unq_elem_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_c_check_unq_elem_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_540, false, nil); A_arbace_c_check_unq_elem_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_166)); return A_arbace_c_check__init_part1_A_const_165 }




func A_arbace_c_check__init_part1_A_Unit182__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1493, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_167; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_168)); return A_arbace_c_check__init_part1_A_const_167 }

func A_arbace_c_check__init_part1_A_Unit183__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1495, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_c_check_compatible_ptr_targets_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_c_check_compatible_ptr_targets_QMARK__A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_541, false, nil); A_arbace_c_check_compatible_ptr_targets_QMARK__A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_170)); return A_arbace_c_check__init_part1_A_const_169 }








func A_arbace_c_check__init_part1_A_Unit184__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1504, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_c_check_cond_type_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_c_check_cond_type_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_542, false, nil); A_arbace_c_check_cond_type_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_172)); return A_arbace_c_check__init_part1_A_const_171 }
































func A_arbace_c_check__init_part1_A_Unit185__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1537, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_173; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_c_check_callee_fn_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_c_check_callee_fn_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_543, false, nil); A_arbace_c_check_callee_fn_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_174)); return A_arbace_c_check__init_part1_A_const_173 }





func A_arbace_c_check__init_part1_A_Unit186__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1543, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_c_check_implicit_fn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_c_check_implicit_fn_BANG__A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_544, false, nil); A_arbace_c_check_implicit_fn_BANG__A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_176)); return A_arbace_c_check__init_part1_A_const_175 }





func A_arbace_c_check__init_part1_A_Unit187__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1549, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_177; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_c_check_head_name_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_c_check_head_name_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_545, false, nil); A_arbace_c_check_head_name_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_178)); return A_arbace_c_check__init_part1_A_const_177 }

func A_arbace_c_check__init_part1_A_Unit188__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1551, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_179; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_c_check_ident_expr_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_c_check_ident_expr_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_546, false, nil); A_arbace_c_check_ident_expr_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_180)); return A_arbace_c_check__init_part1_A_const_179 }















func A_arbace_c_check__init_part1_A_Unit189__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1567, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_181; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_c_check_deref_type_A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_c_check_deref_type_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_547, false, nil); A_arbace_c_check_deref_type_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_182)); return A_arbace_c_check__init_part1_A_const_181 }



func A_arbace_c_check__init_part1_A_Unit190__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1571, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_183; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_c_check_member_of_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_c_check_member_of_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_548, false, nil); A_arbace_c_check_member_of_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_184)); return A_arbace_c_check__init_part1_A_const_183 }


















func A_arbace_c_check__init_part1_A_Unit191__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1590, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_185; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_c_check_bit_fold_A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_c_check_bit_fold_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_549, false, nil); A_arbace_c_check_bit_fold_A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_186)); return A_arbace_c_check__init_part1_A_const_185 }







































func A_arbace_c_check__init_part1_A_Unit192__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1630, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_187; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_c_check_overflow_fold_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_c_check_overflow_fold_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_550, false, nil); A_arbace_c_check_overflow_fold_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_188)); return A_arbace_c_check__init_part1_A_const_187 }











func A_arbace_c_check__init_part1_A_Unit193__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1642, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_189; var tmp2 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp3 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); var tmp4 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp5 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); var tmp6 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp7 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp8 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp9 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp10 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); var tmp11 any; var root_139 any = A_arbace_c_check__init_part1_A_const_192.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, A_arbace_c_check_ptr_A_fn_class); var ifn_141 lang.IFn; if



	linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); if linked_140 == nil { tmp11 = ifn_141.Invoke_O__O(arg_142) } else { tmp11 = linked_140.(*A_arbace_c_check_ptr_A).Invoke_O_O__O(root_139, arg_142) }; var tmp12 any = tmp11; var tmp13 any = /*line :1642:1*/A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp14 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp15 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); var tmp16 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp17 any; var root_143 any = A_arbace_c_check__init_part1_A_const_192.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, A_arbace_c_check_ptr_A_fn_class); var ifn_145 lang.IFn; if



	linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); if linked_144 == nil { tmp17 = ifn_145.Invoke_O__O(arg_146) } else { tmp17 = linked_144.(*A_arbace_c_check_ptr_A).Invoke_O_O__O(root_143, arg_146) }; var tmp18 any = tmp17; var tmp19 any = /*line :1642:1*/A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp20 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp21 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp22 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp23 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp24 any = A_arbace_c_check__init_part1_A_const_193.GetRawRoot__O(); var tmp25 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp26 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp27 any; var root_147 any = A_arbace_c_check__init_part1_A_const_192.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, A_arbace_c_check_ptr_A_fn_class); var ifn_149 lang.IFn; if


	linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); if linked_148 == nil { tmp27 = ifn_149.Invoke_O__O(arg_150) } else { tmp27 = linked_148.(*A_arbace_c_check_ptr_A).Invoke_O_O__O(root_147, arg_150) }; var tmp28 any = tmp27; var tmp29 any = /*line :1642:1*/A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp30 any; var root_151 any = A_arbace_c_check__init_part1_A_const_192.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, A_arbace_c_check_ptr_A_fn_class); var ifn_153 lang.IFn; if



	linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); if linked_152 == nil { tmp30 = ifn_153.Invoke_O__O(arg_154) } else { tmp30 = linked_152.(*A_arbace_c_check_ptr_A).Invoke_O_O__O(root_151, arg_154) }; var tmp31 any = tmp30; var tmp32 any; var root_155 any = /*line :1642:1*/A_arbace_c_check__init_part1_A_const_192.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, A_arbace_c_check_ptr_A_fn_class); var ifn_157 lang.IFn; if




	linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); if linked_156 == nil { tmp32 = ifn_157.Invoke_O__O(arg_158) } else { tmp32 = linked_156.(*A_arbace_c_check_ptr_A).Invoke_O_O__O(root_155, arg_158) }; var tmp33 any = tmp32; var tmp34 any = /*line :1642:1*/A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp35 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp36 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp37 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp38 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp39 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp40 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); var tmp41 any; var root_159 any = A_arbace_c_check__init_part1_A_const_192.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, A_arbace_c_check_ptr_A_fn_class); var ifn_161 lang.IFn; if




	linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); if linked_160 == nil { tmp41 = ifn_161.Invoke_O__O(arg_162) } else { tmp41 = linked_160.(*A_arbace_c_check_ptr_A).Invoke_O_O__O(root_159, arg_162) }; var tmp42 any = tmp41; var tmp43 any = /*line :1642:1*/A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp44 any = A_arbace_c_check__init_part1_A_const_194.GetRawRoot__O(); var tmp45 any = A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp46 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); var tmp47 any; var root_163 any = A_arbace_c_check__init_part1_A_const_192.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, A_arbace_c_check_ptr_A_fn_class); var ifn_165 lang.IFn; if


	linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); if linked_164 == nil { tmp47 = ifn_165.Invoke_O__O(arg_166) } else { tmp47 = linked_164.(*A_arbace_c_check_ptr_A).Invoke_O_O__O(root_163, arg_166) }; var tmp48 any = tmp47; var tmp49 any = /*line :1642:1*/A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(); var tmp50 any; var root_167 any = A_arbace_c_check__init_part1_A_const_192.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, A_arbace_c_check_ptr_A_fn_class); var ifn_169 lang.IFn; if












	linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(); if linked_168 == nil { tmp50 = ifn_169.Invoke_O__O(arg_170) } else { tmp50 = linked_168.(*A_arbace_c_check_ptr_A).Invoke_O_O__O(root_167, arg_170) }; /*line :1642:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_551, tmp2, Lit_552, tmp3, Lit_553, tmp4, Lit_554, tmp5, Lit_555, tmp6, Lit_556, tmp7, Lit_557, tmp8, Lit_558, tmp9, Lit_559, tmp10, Lit_560, tmp12, Lit_561, tmp13, Lit_562, tmp14, Lit_563, tmp15, Lit_564, tmp16, Lit_565, tmp18, Lit_68, tmp19, Lit_566, tmp20, Lit_567, tmp21, Lit_568, tmp22, Lit_569, tmp23, Lit_89, tmp24, Lit_570, tmp25, Lit_571, tmp26, Lit_572, tmp28, Lit_573, tmp29, Lit_574, tmp31, Lit_575, tmp33, Lit_576, tmp34, Lit_577, tmp35, Lit_578, tmp36, Lit_579, tmp37, Lit_580, tmp38, Lit_581, tmp39, Lit_582, tmp40, Lit_583, tmp42, Lit_584, tmp43, Lit_83, nil, Lit_585, tmp44, Lit_586, tmp45, Lit_587, tmp46, Lit_588, tmp48, Lit_589, tmp49, Lit_590, tmp50, Lit_591, A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(), Lit_592, A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O(), Lit_593, A_arbace_c_check__init_part1_A_const_191.GetRawRoot__O(), Lit_594, A_arbace_c_check__init_part1_A_const_190.GetRawRoot__O()))); var tmp51 *lang.Var = A_arbace_c_check__init_part1_A_const_189; tmp51.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_195)); return A_arbace_c_check__init_part1_A_const_189 }














func A_arbace_c_check__init_part1_A_Unit194__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1657, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_196; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_197)); return A_arbace_c_check__init_part1_A_const_196 }
//line :1657:1
func A_arbace_c_check__init_part1_A_Unit195__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1657, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_198; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_199)); return A_arbace_c_check__init_part1_A_const_198 }
//line :1657:1
func A_arbace_c_check__init_part1_A_Unit196__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1657, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_200; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_201)); return A_arbace_c_check__init_part1_A_const_200 }
//line :1657:1
func A_arbace_c_check__init_part1_A_Unit197__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1657, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_83; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_202)); return A_arbace_c_check__init_part1_A_const_83 }

func A_arbace_c_check__init_part1_A_Unit198__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1659, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_203; var tmp2 *lang.Compiler_AOTFn; var fnbody__172 any = A_arbace_c_check_fn__1876000493_A_New(); var tmp3 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_c_check_fn__1876000493_A_fn_class; if



	fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_595, false, nil); A_arbace_c_check_fn__1876000493_A_fn_class = fncls__171d; tmp3 = fncls__171d } else { tmp3 = fncls__171 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__172, tmp3, nil); /*line :1659:1*/tmp1.BindRoot_O__V(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_203; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_204)); return A_arbace_c_check__init_part1_A_const_203 }




















func A_arbace_c_check__init_part1_A_Unit199__O() any { A_arbace_c_check__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1680, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part1_A_const_205; var tmp2 *lang.Compiler_AOTFn; var fnbody__174 any = A_arbace_c_check_call_A_New(); var tmp3 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_c_check_call_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_596, false, nil); A_arbace_c_check_call_A_fn_class = fncls__173d; tmp3 = fncls__173d } else { tmp3 = fncls__173 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__174, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part1_A_const_205; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part1_A_const_206)); return A_arbace_c_check__init_part1_A_const_205 }
































func A_arbace_c_check__init_part2_A_Unit200__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1713, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c_check_call_builtin_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c_check_call_builtin_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_598, false, nil); A_arbace_c_check_call_builtin_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_1)); return A_arbace_c_check__init_part2_A_const_0 }
//line :1713:1
func A_arbace_c_check__init_part2_A_Init__O() any { A_arbace_c_check__init_part2_A_Init(); return nil }
//line :1713:1
func A_arbace_c_check__init_part2_A_Load__O() any { A_arbace_c_check__init_part2_A_Init(); A_arbace_c_check__init_part2_A_Unit200__O(); A_arbace_c_check__init_part2_A_Unit201__O(); A_arbace_c_check__init_part2_A_Unit202__O(); A_arbace_c_check__init_part2_A_Unit203__O(); A_arbace_c_check__init_part2_A_Unit204__O(); A_arbace_c_check__init_part2_A_Unit205__O(); A_arbace_c_check__init_part2_A_Unit206__O(); A_arbace_c_check__init_part2_A_Unit207__O(); A_arbace_c_check__init_part2_A_Unit208__O(); A_arbace_c_check__init_part2_A_Unit209__O(); A_arbace_c_check__init_part2_A_Unit210__O(); A_arbace_c_check__init_part2_A_Unit211__O(); A_arbace_c_check__init_part2_A_Unit212__O(); A_arbace_c_check__init_part2_A_Unit213__O(); A_arbace_c_check__init_part2_A_Unit214__O(); A_arbace_c_check__init_part2_A_Unit215__O(); A_arbace_c_check__init_part2_A_Unit216__O(); A_arbace_c_check__init_part2_A_Unit217__O(); A_arbace_c_check__init_part2_A_Unit218__O(); A_arbace_c_check__init_part2_A_Unit219__O(); A_arbace_c_check__init_part2_A_Unit220__O(); A_arbace_c_check__init_part2_A_Unit221__O(); A_arbace_c_check__init_part2_A_Unit222__O(); A_arbace_c_check__init_part2_A_Unit223__O(); A_arbace_c_check__init_part2_A_Unit224__O(); A_arbace_c_check__init_part2_A_Unit225__O(); A_arbace_c_check__init_part2_A_Unit226__O(); A_arbace_c_check__init_part2_A_Unit227__O(); A_arbace_c_check__init_part2_A_Unit228__O(); A_arbace_c_check__init_part2_A_Unit229__O(); A_arbace_c_check__init_part2_A_Unit230__O(); A_arbace_c_check__init_part2_A_Unit231__O(); A_arbace_c_check__init_part2_A_Unit232__O(); A_arbace_c_check__init_part2_A_Unit233__O(); A_arbace_c_check__init_part2_A_Unit234__O(); A_arbace_c_check__init_part2_A_Unit235__O(); A_arbace_c_check__init_part2_A_Unit236__O(); A_arbace_c_check__init_part2_A_Unit237__O(); A_arbace_c_check__init_part2_A_Unit238__O(); A_arbace_c_check__init_part2_A_Unit239__O(); A_arbace_c_check__init_part2_A_Unit240__O(); A_arbace_c_check__init_part2_A_Unit241__O(); A_arbace_c_check__init_part2_A_Unit242__O(); A_arbace_c_check__init_part2_A_Unit243__O(); A_arbace_c_check__init_part2_A_Unit244__O(); A_arbace_c_check__init_part2_A_Unit245__O(); A_arbace_c_check__init_part2_A_Unit246__O(); A_arbace_c_check__init_part2_A_Unit247__O(); A_arbace_c_check__init_part2_A_Unit248__O(); A_arbace_c_check__init_part2_A_Unit249__O(); A_arbace_c_check__init_part2_A_Unit250__O(); A_arbace_c_check__init_part2_A_Unit251__O(); A_arbace_c_check__init_part2_A_Unit252__O(); A_arbace_c_check__init_part2_A_Unit253__O(); A_arbace_c_check__init_part2_A_Unit254__O(); return nil }








































































func A_arbace_c_check__init_part2_A_Unit201__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1786, 1); A_arbace_c_check__init_part2_A_const_2.BindRoot_O__V(A_arbace_c_check__init_part2_A_const_3); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_4)); return A_arbace_c_check__init_part2_A_const_2 }

func A_arbace_c_check__init_part2_A_Unit202__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1788, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_5; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c_check_lit_form_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c_check_lit_form_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_599, false, nil); A_arbace_c_check_lit_form_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_6)); return A_arbace_c_check__init_part2_A_const_5 }


























func A_arbace_c_check__init_part2_A_Unit203__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1815, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_c_check_incomplete_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c_check_incomplete_type_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_600, false, nil); A_arbace_c_check_incomplete_type_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_8)); return A_arbace_c_check__init_part2_A_const_7 }








func A_arbace_c_check__init_part2_A_Unit204__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1824, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_c_check_sizeof_res_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c_check_sizeof_res_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_601, false, nil); A_arbace_c_check_sizeof_res_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_10)); return A_arbace_c_check__init_part2_A_const_9 }



func A_arbace_c_check__init_part2_A_Unit205__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1828, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c_check_vla_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c_check_vla_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_602, false, nil); A_arbace_c_check_vla_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_12)); return A_arbace_c_check__init_part2_A_const_11 }

func A_arbace_c_check__init_part2_A_Unit206__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1830, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c_check_generic_select_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c_check_generic_select_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_603, false, nil); A_arbace_c_check_generic_select_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_14)); return A_arbace_c_check__init_part2_A_const_13 }



























func A_arbace_c_check__init_part2_A_Unit207__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1858, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c_check_init_count_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c_check_init_count_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_604, false, nil); A_arbace_c_check_init_count_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_16)); return A_arbace_c_check__init_part2_A_const_15 }















































func A_arbace_c_check__init_part2_A_Unit208__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1906, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_18)); return A_arbace_c_check__init_part2_A_const_17 }

func A_arbace_c_check__init_part2_A_Unit209__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1908, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c_check_check_init_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c_check_check_init_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_605, false, nil); A_arbace_c_check_check_init_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_20)); return A_arbace_c_check__init_part2_A_const_19 }


















func A_arbace_c_check__init_part2_A_Unit210__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1927, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_c_check_unq_STAR__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c_check_unq_STAR__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_606, false, nil); A_arbace_c_check_unq_STAR__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_22)); return A_arbace_c_check__init_part2_A_const_21 }




func A_arbace_c_check__init_part2_A_Unit211__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1932, 1); A_arbace_c_check__init_part2_A_const_23.BindRoot_O__V(A_arbace_c_check__init_part2_A_const_24); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_23; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_25)); return A_arbace_c_check__init_part2_A_const_23 }



func A_arbace_c_check__init_part2_A_Unit212__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1936, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_c_check_ptr_conv_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c_check_ptr_conv_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_607, false, nil); A_arbace_c_check_ptr_conv_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_26)); return A_arbace_c_check__init_part2_A_const_17 }































func A_arbace_c_check__init_part2_A_Unit213__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1968, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_c_check_assign_check_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c_check_assign_check_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_608, false, nil); A_arbace_c_check_assign_check_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_28)); return A_arbace_c_check__init_part2_A_const_27 }



func A_arbace_c_check__init_part2_A_Unit214__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1972, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c_check_nested_arrow_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c_check_nested_arrow_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_609, false, nil); A_arbace_c_check_nested_arrow_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_30)); return A_arbace_c_check__init_part2_A_const_29 }



func A_arbace_c_check__init_part2_A_Unit215__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1976, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_31; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_32)); return A_arbace_c_check__init_part2_A_const_31 }

func A_arbace_c_check__init_part2_A_Unit216__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1978, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c_check_ex_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c_check_ex_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_610, false, nil); A_arbace_c_check_ex_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_34)); return A_arbace_c_check__init_part2_A_const_33 }




func A_arbace_c_check__init_part2_A_Unit217__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1983, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c_check_ex_STAR__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c_check_ex_STAR__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_611, false, nil); A_arbace_c_check_ex_STAR__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_35)); return A_arbace_c_check__init_part2_A_const_31 }



































































































































































func A_arbace_c_check__init_part2_A_Unit218__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2147, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c_check_binary_index_type_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c_check_binary_index_type_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_612, false, nil); A_arbace_c_check_binary_index_type_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_37)); return A_arbace_c_check__init_part2_A_const_36 }





func A_arbace_c_check__init_part2_A_Unit219__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2153, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c_check_const_int_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c_check_const_int_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_613, false, nil); A_arbace_c_check_const_int_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_39)); return A_arbace_c_check__init_part2_A_const_38 }











func A_arbace_c_check__init_part2_A_Unit220__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2165, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c_check_storage_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c_check_storage_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_614, false, nil); A_arbace_c_check_storage_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_41)); return A_arbace_c_check__init_part2_A_const_40 }


func A_arbace_c_check__init_part2_A_Unit221__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2168, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c_check_linkage_of_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c_check_linkage_of_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_615, false, nil); A_arbace_c_check_linkage_of_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_43)); return A_arbace_c_check__init_part2_A_const_42 }











func A_arbace_c_check__init_part2_A_Unit222__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2180, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c_check_lname_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c_check_lname_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_616, false, nil); A_arbace_c_check_lname_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_45)); return A_arbace_c_check__init_part2_A_const_44 }

func A_arbace_c_check__init_part2_A_Unit223__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2182, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_c_check_complete_array_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c_check_complete_array_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_617, false, nil); A_arbace_c_check_complete_array_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_47)); return A_arbace_c_check__init_part2_A_const_46 }




func A_arbace_c_check__init_part2_A_Unit224__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2187, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_c_check_composite_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c_check_composite_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_618, false, nil); A_arbace_c_check_composite_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_49)); return A_arbace_c_check__init_part2_A_const_48 }





















func A_arbace_c_check__init_part2_A_Unit225__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2209, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_c_check_declare_object_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c_check_declare_object_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_619, false, nil); A_arbace_c_check_declare_object_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_51)); return A_arbace_c_check__init_part2_A_const_50 }






































func A_arbace_c_check__init_part2_A_Unit226__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2248, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_c_check_auto_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c_check_auto_type_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_620, false, nil); A_arbace_c_check_auto_type_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_53)); return A_arbace_c_check__init_part2_A_const_52 }


func A_arbace_c_check__init_part2_A_Unit227__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2251, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_c_check_string_bytes_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c_check_string_bytes_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_621, false, nil); A_arbace_c_check_string_bytes_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_55)); return A_arbace_c_check__init_part2_A_const_54 }













func A_arbace_c_check__init_part2_A_Unit228__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2265, 1); A_arbace_c_check__init_part2_A_const_56.BindRoot_O__V(A_arbace_c_check__init_part2_A_const_57); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_56; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_58)); return A_arbace_c_check__init_part2_A_const_56 }



func A_arbace_c_check__init_part2_A_Unit229__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2269, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_c_check_round_dec_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c_check_round_dec_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_622, false, nil); A_arbace_c_check_round_dec_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_60)); return A_arbace_c_check__init_part2_A_const_59 }






func A_arbace_c_check__init_part2_A_Unit230__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2276, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_c_check_dec_fits_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c_check_dec_fits_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_623, false, nil); A_arbace_c_check_dec_fits_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_62)); return A_arbace_c_check__init_part2_A_const_61 }











func A_arbace_c_check__init_part2_A_Unit231__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2288, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_c_check_constexpr_float_bad_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_c_check_constexpr_float_bad_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_624, false, nil); A_arbace_c_check_constexpr_float_bad_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_64)); return A_arbace_c_check__init_part2_A_const_63 }













































func A_arbace_c_check__init_part2_A_Unit232__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2334, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_c_check_constexpr_check_BANG__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c_check_constexpr_check_BANG__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_625, false, nil); A_arbace_c_check_constexpr_check_BANG__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_66)); return A_arbace_c_check__init_part2_A_const_65 }

























func A_arbace_c_check__init_part2_A_Unit233__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2360, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_c_check_check_var_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_c_check_check_var_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_626, false, nil); A_arbace_c_check_check_var_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_68)); return A_arbace_c_check__init_part2_A_const_67 }























































func A_arbace_c_check__init_part2_A_Unit234__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2416, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_c_check_params_of_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_c_check_params_of_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_627, false, nil); A_arbace_c_check_params_of_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_70)); return A_arbace_c_check__init_part2_A_const_69 }



















func A_arbace_c_check__init_part2_A_Unit235__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2436, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_72)); return A_arbace_c_check__init_part2_A_const_71 }

func A_arbace_c_check__init_part2_A_Unit236__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2438, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_c_check_asm_operands_BANG__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_c_check_asm_operands_BANG__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_628, false, nil); A_arbace_c_check_asm_operands_BANG__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_74)); return A_arbace_c_check__init_part2_A_const_73 }










func A_arbace_c_check__init_part2_A_Unit237__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2449, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_c_check_check_defn_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c_check_check_defn_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_629, false, nil); A_arbace_c_check_check_defn_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_76)); return A_arbace_c_check__init_part2_A_const_75 }
























func A_arbace_c_check__init_part2_A_Unit238__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2474, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_c_check_check_declare_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c_check_check_declare_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_630, false, nil); A_arbace_c_check_check_declare_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_78)); return A_arbace_c_check__init_part2_A_const_77 }










func A_arbace_c_check__init_part2_A_Unit239__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2485, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_c_check_check_typedef_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_c_check_check_typedef_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_631, false, nil); A_arbace_c_check_check_typedef_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_80)); return A_arbace_c_check__init_part2_A_const_79 }























func A_arbace_c_check__init_part2_A_Unit240__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2509, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_c_check_check_decl_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_c_check_check_decl_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_632, false, nil); A_arbace_c_check_check_decl_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_82)); return A_arbace_c_check__init_part2_A_const_81 }



























func A_arbace_c_check__init_part2_A_Unit241__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2537, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_c_check_decl_form_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c_check_decl_form_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_633, false, nil); A_arbace_c_check_decl_form_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_84)); return A_arbace_c_check__init_part2_A_const_83 }

func A_arbace_c_check__init_part2_A_Unit242__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2539, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_c_check_let_bindings_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_c_check_let_bindings_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_634, false, nil); A_arbace_c_check_let_bindings_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_86)); return A_arbace_c_check__init_part2_A_const_85 }









func A_arbace_c_check__init_part2_A_Unit243__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2549, 1); A_arbace_c_check__init_part2_A_const_87.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_88)); return A_arbace_c_check__init_part2_A_const_87.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_check__init_part2_A_Unit244__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2551, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_c_check_attr_decl_check_BANG__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_c_check_attr_decl_check_BANG__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_635, false, nil); A_arbace_c_check_attr_decl_check_BANG__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_90)); return A_arbace_c_check__init_part2_A_const_89 }
















func A_arbace_c_check__init_part2_A_Unit245__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2568, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_c_check_stmt_attrs_BANG__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c_check_stmt_attrs_BANG__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_636, false, nil); A_arbace_c_check_stmt_attrs_BANG__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_92)); return A_arbace_c_check__init_part2_A_const_91 }












func A_arbace_c_check__init_part2_A_Unit246__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2581, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_c_check_check_block_items_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c_check_check_block_items_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_637, false, nil); A_arbace_c_check_check_block_items_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_94)); return A_arbace_c_check__init_part2_A_const_93 }









func A_arbace_c_check__init_part2_A_Unit247__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2591, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_c_check_cond_expr_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_c_check_cond_expr_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_638, false, nil); A_arbace_c_check_cond_expr_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_96)); return A_arbace_c_check__init_part2_A_const_95 }

func A_arbace_c_check__init_part2_A_Unit248__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2593, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_c_check_check_stmt_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_c_check_check_stmt_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_639, false, nil); A_arbace_c_check_check_stmt_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_97)); return A_arbace_c_check__init_part2_A_const_71 }





































































func A_arbace_c_check__init_part2_A_Unit249__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2663, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_c_check_pragma_pack_BANG__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_c_check_pragma_pack_BANG__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_640, false, nil); A_arbace_c_check_pragma_pack_BANG__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_99)); return A_arbace_c_check__init_part2_A_const_98 }











func A_arbace_c_check__init_part2_A_Unit250__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2675, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_101)); return A_arbace_c_check__init_part2_A_const_100 }

func A_arbace_c_check__init_part2_A_Unit251__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2677, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_c_check_check_forms_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_c_check_check_forms_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_641, false, nil); A_arbace_c_check_check_forms_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_103)); return A_arbace_c_check__init_part2_A_const_102 }


func A_arbace_c_check__init_part2_A_Unit252__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2680, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_c_check_check_top_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_c_check_check_top_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_642, false, nil); A_arbace_c_check_check_top_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_104)); return A_arbace_c_check__init_part2_A_const_100 }
















































func A_arbace_c_check__init_part2_A_Unit253__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2729, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_c_check_new_cx_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_c_check_new_cx_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_643, false, nil); A_arbace_c_check_new_cx_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_106)); return A_arbace_c_check__init_part2_A_const_105 }





func A_arbace_c_check__init_part2_A_Unit254__O() any { A_arbace_c_check__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2735, 1); var tmp1 *lang.Var = A_arbace_c_check__init_part2_A_const_107; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__94 any = A_arbace_c_check_check_unit_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_c_check_check_unit_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_644, true, nil); A_arbace_c_check_check_unit_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__94, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_check__init_part2_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_check__init_part2_A_const_108)); return A_arbace_c_check__init_part2_A_const_107 }



type A_arbace_c_check__init_A struct{ jrt.Object }

func A_arbace_c_check__init_A_New() *A_arbace_c_check__init_A { t := &A_arbace_c_check__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c_check__init_A) Ctor() {}

func (t *A_arbace_c_check__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_check__init_A) GetClass__Class() *jrt.Class { return A_arbace_c_check__init_A_class }

func (t *A_arbace_c_check__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_check__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_check__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_check__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_check__init_A); return ok }

func A_arbace_c_check__init_A_Cast(x any) *A_arbace_c_check__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_check__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_check__init_A_class)) }; return v }



type A_arbace_c_check__init_part0_A struct{ jrt.Object }

var A_arbace_c_check__init_part0_A_const_pool *jrt.RefArray

var A_arbace_c_check__init_part0_A_const_0 *lang.Var

var A_arbace_c_check__init_part0_A_const_1 any

var A_arbace_c_check__init_part0_A_const_2 any

var A_arbace_c_check__init_part0_A_const_3 any

var A_arbace_c_check__init_part0_A_const_4 *lang.Var

var A_arbace_c_check__init_part0_A_const_5 *lang.Var

var A_arbace_c_check__init_part0_A_const_6 any

var A_arbace_c_check__init_part0_A_const_7 *lang.Var

var A_arbace_c_check__init_part0_A_const_8 any

var A_arbace_c_check__init_part0_A_const_9 any

var A_arbace_c_check__init_part0_A_const_10 *lang.Var

var A_arbace_c_check__init_part0_A_const_11 any

var A_arbace_c_check__init_part0_A_const_12 *lang.Var

var A_arbace_c_check__init_part0_A_const_13 any

var A_arbace_c_check__init_part0_A_const_14 *lang.Var

var A_arbace_c_check__init_part0_A_const_15 any

var A_arbace_c_check__init_part0_A_const_16 *lang.Var

var A_arbace_c_check__init_part0_A_const_17 any

var A_arbace_c_check__init_part0_A_const_18 *lang.Var

var A_arbace_c_check__init_part0_A_const_19 any

var A_arbace_c_check__init_part0_A_const_20 *lang.Var

var A_arbace_c_check__init_part0_A_const_21 any

var A_arbace_c_check__init_part0_A_const_22 *lang.Var

var A_arbace_c_check__init_part0_A_const_23 any

var A_arbace_c_check__init_part0_A_const_24 *lang.Var

var A_arbace_c_check__init_part0_A_const_25 any

var A_arbace_c_check__init_part0_A_const_26 *lang.Var

var A_arbace_c_check__init_part0_A_const_27 any

var A_arbace_c_check__init_part0_A_const_28 *lang.Var

var A_arbace_c_check__init_part0_A_const_29 any

var A_arbace_c_check__init_part0_A_const_30 *lang.Var

var A_arbace_c_check__init_part0_A_const_31 any

var A_arbace_c_check__init_part0_A_const_32 *lang.Var

var A_arbace_c_check__init_part0_A_const_33 any

var A_arbace_c_check__init_part0_A_const_34 *lang.Var

var A_arbace_c_check__init_part0_A_const_35 any

var A_arbace_c_check__init_part0_A_const_36 *lang.Var

var A_arbace_c_check__init_part0_A_const_37 any

var A_arbace_c_check__init_part0_A_const_38 *lang.Var

var A_arbace_c_check__init_part0_A_const_39 any

var A_arbace_c_check__init_part0_A_const_40 *lang.Var

var A_arbace_c_check__init_part0_A_const_41 any

var A_arbace_c_check__init_part0_A_const_42 *lang.Var

var A_arbace_c_check__init_part0_A_const_43 any

var A_arbace_c_check__init_part0_A_const_44 *lang.Var

var A_arbace_c_check__init_part0_A_const_45 any

var A_arbace_c_check__init_part0_A_const_46 *lang.Var

var A_arbace_c_check__init_part0_A_const_47 any

var A_arbace_c_check__init_part0_A_const_48 any

var A_arbace_c_check__init_part0_A_const_49 *lang.Var

var A_arbace_c_check__init_part0_A_const_50 any

var A_arbace_c_check__init_part0_A_const_51 any

var A_arbace_c_check__init_part0_A_const_52 *lang.Var

var A_arbace_c_check__init_part0_A_const_53 any

var A_arbace_c_check__init_part0_A_const_54 any

var A_arbace_c_check__init_part0_A_const_55 *lang.Var

var A_arbace_c_check__init_part0_A_const_56 any

var A_arbace_c_check__init_part0_A_const_57 any

var A_arbace_c_check__init_part0_A_const_58 *lang.Var

var A_arbace_c_check__init_part0_A_const_59 any

var A_arbace_c_check__init_part0_A_const_60 any

var A_arbace_c_check__init_part0_A_const_61 *lang.Var

var A_arbace_c_check__init_part0_A_const_62 any

var A_arbace_c_check__init_part0_A_const_63 any

var A_arbace_c_check__init_part0_A_const_64 *lang.Var

var A_arbace_c_check__init_part0_A_const_65 any

var A_arbace_c_check__init_part0_A_const_66 any

var A_arbace_c_check__init_part0_A_const_67 *lang.Var

var A_arbace_c_check__init_part0_A_const_68 any

var A_arbace_c_check__init_part0_A_const_69 any

var A_arbace_c_check__init_part0_A_const_70 *lang.Var

var A_arbace_c_check__init_part0_A_const_71 any

var A_arbace_c_check__init_part0_A_const_72 any

var A_arbace_c_check__init_part0_A_const_73 *lang.Var

var A_arbace_c_check__init_part0_A_const_74 any

var A_arbace_c_check__init_part0_A_const_75 any

var A_arbace_c_check__init_part0_A_const_76 *lang.Var

var A_arbace_c_check__init_part0_A_const_77 any

var A_arbace_c_check__init_part0_A_const_78 any

var A_arbace_c_check__init_part0_A_const_79 *lang.Var

var A_arbace_c_check__init_part0_A_const_80 any

var A_arbace_c_check__init_part0_A_const_81 any

var A_arbace_c_check__init_part0_A_const_82 *lang.Var

var A_arbace_c_check__init_part0_A_const_83 any

var A_arbace_c_check__init_part0_A_const_84 *lang.Var

var A_arbace_c_check__init_part0_A_const_85 any

var A_arbace_c_check__init_part0_A_const_86 *lang.Var

var A_arbace_c_check__init_part0_A_const_87 any

var A_arbace_c_check__init_part0_A_const_88 any

var A_arbace_c_check__init_part0_A_const_89 *lang.Var

var A_arbace_c_check__init_part0_A_const_90 any

var A_arbace_c_check__init_part0_A_const_91 any

var A_arbace_c_check__init_part0_A_const_92 *lang.Var

var A_arbace_c_check__init_part0_A_const_93 any

var A_arbace_c_check__init_part0_A_const_94 any

var A_arbace_c_check__init_part0_A_const_95 *lang.Var

var A_arbace_c_check__init_part0_A_const_96 any

var A_arbace_c_check__init_part0_A_const_97 *lang.Var

var A_arbace_c_check__init_part0_A_const_98 any

var A_arbace_c_check__init_part0_A_const_99 *lang.Var

var A_arbace_c_check__init_part0_A_const_100 any

var A_arbace_c_check__init_part0_A_const_101 *lang.Var

var A_arbace_c_check__init_part0_A_const_102 any

var A_arbace_c_check__init_part0_A_const_103 *lang.Var

var A_arbace_c_check__init_part0_A_const_104 any

var A_arbace_c_check__init_part0_A_const_105 *lang.Var

var A_arbace_c_check__init_part0_A_const_106 any

var A_arbace_c_check__init_part0_A_const_107 *lang.Var

var A_arbace_c_check__init_part0_A_const_108 any

var A_arbace_c_check__init_part0_A_const_109 *lang.Var

var A_arbace_c_check__init_part0_A_const_110 any

var A_arbace_c_check__init_part0_A_const_111 *lang.Var

var A_arbace_c_check__init_part0_A_const_112 any

var A_arbace_c_check__init_part0_A_const_113 *lang.Var

var A_arbace_c_check__init_part0_A_const_114 any

var A_arbace_c_check__init_part0_A_const_115 *lang.Var

var A_arbace_c_check__init_part0_A_const_116 any

var A_arbace_c_check__init_part0_A_const_117 *lang.Var

var A_arbace_c_check__init_part0_A_const_118 any

var A_arbace_c_check__init_part0_A_const_119 *lang.Var

var A_arbace_c_check__init_part0_A_const_120 any

var A_arbace_c_check__init_part0_A_const_121 *lang.Var

var A_arbace_c_check__init_part0_A_const_122 any

var A_arbace_c_check__init_part0_A_const_123 *lang.Var

var A_arbace_c_check__init_part0_A_const_124 any

var A_arbace_c_check__init_part0_A_const_125 *lang.Var

var A_arbace_c_check__init_part0_A_const_126 any

var A_arbace_c_check__init_part0_A_const_127 *lang.Var

var A_arbace_c_check__init_part0_A_const_128 any

var A_arbace_c_check__init_part0_A_const_129 *lang.Var

var A_arbace_c_check__init_part0_A_const_130 any

var A_arbace_c_check__init_part0_A_const_131 *lang.Var

var A_arbace_c_check__init_part0_A_const_132 any

var A_arbace_c_check__init_part0_A_const_133 *lang.Var

var A_arbace_c_check__init_part0_A_const_134 any

var A_arbace_c_check__init_part0_A_const_135 *lang.Var

var A_arbace_c_check__init_part0_A_const_136 any

var A_arbace_c_check__init_part0_A_const_137 *lang.Var

var A_arbace_c_check__init_part0_A_const_138 any

var A_arbace_c_check__init_part0_A_const_139 *lang.Var

var A_arbace_c_check__init_part0_A_const_140 any

var A_arbace_c_check__init_part0_A_const_141 any

var A_arbace_c_check__init_part0_A_const_142 *lang.Var

var A_arbace_c_check__init_part0_A_const_143 any

var A_arbace_c_check__init_part0_A_const_144 any

var A_arbace_c_check__init_part0_A_const_145 any

var A_arbace_c_check__init_part0_A_const_146 *lang.Var

var A_arbace_c_check__init_part0_A_const_147 any

var A_arbace_c_check__init_part0_A_const_148 *lang.Var

var A_arbace_c_check__init_part0_A_const_149 any

var A_arbace_c_check__init_part0_A_const_150 *lang.Var

var A_arbace_c_check__init_part0_A_const_151 any

var A_arbace_c_check__init_part0_A_const_152 *lang.Var

var A_arbace_c_check__init_part0_A_const_153 any

var A_arbace_c_check__init_part0_A_const_154 *lang.Var

var A_arbace_c_check__init_part0_A_const_155 any

var A_arbace_c_check__init_part0_A_const_156 *lang.Var

var A_arbace_c_check__init_part0_A_const_157 any

var A_arbace_c_check__init_part0_A_const_158 any

var A_arbace_c_check__init_part0_A_const_159 *lang.Var

var A_arbace_c_check__init_part0_A_const_160 any

var A_arbace_c_check__init_part0_A_const_161 *lang.Var

var A_arbace_c_check__init_part0_A_const_162 any

var A_arbace_c_check__init_part0_A_const_163 *lang.Var

var A_arbace_c_check__init_part0_A_const_164 any

var A_arbace_c_check__init_part0_A_const_165 *lang.Var

var A_arbace_c_check__init_part0_A_const_166 any

var A_arbace_c_check__init_part0_A_const_167 *lang.Var

var A_arbace_c_check__init_part0_A_const_168 any

var A_arbace_c_check__init_part0_A_const_169 *lang.Var

var A_arbace_c_check__init_part0_A_const_170 any

var A_arbace_c_check__init_part0_A_const_171 *lang.Var

var A_arbace_c_check__init_part0_A_const_172 any

var A_arbace_c_check__init_part0_A_const_173 *lang.Var

var A_arbace_c_check__init_part0_A_const_174 any

var A_arbace_c_check__init_part0_A_const_175 *lang.Var

var A_arbace_c_check__init_part0_A_const_176 any

var A_arbace_c_check__init_part0_A_const_177 *lang.Var

var A_arbace_c_check__init_part0_A_const_178 any

var A_arbace_c_check__init_part0_A_const_179 *lang.Var

var A_arbace_c_check__init_part0_A_const_180 any

var A_arbace_c_check__init_part0_A_const_181 *lang.Var

var A_arbace_c_check__init_part0_A_const_182 any

var A_arbace_c_check__init_part0_A_const_183 *lang.Var

var A_arbace_c_check__init_part0_A_const_184 any

var A_arbace_c_check__init_part0_A_const_185 *lang.Var

var A_arbace_c_check__init_part0_A_const_186 any

var A_arbace_c_check__init_part0_A_const_187 *lang.Var

var A_arbace_c_check__init_part0_A_const_188 any

var A_arbace_c_check__init_part0_A_const_189 *lang.Var

var A_arbace_c_check__init_part0_A_const_190 any

var A_arbace_c_check__init_part0_A_const_191 any

var A_arbace_c_check__init_part0_A_const_192 *lang.Var

var A_arbace_c_check__init_part0_A_const_193 any

var A_arbace_c_check__init_part0_A_const_194 any

var A_arbace_c_check__init_part0_A_const_195 *lang.Var

var A_arbace_c_check__init_part0_A_const_196 any

var A_arbace_c_check__init_part0_A_const_197 *lang.Var

var A_arbace_c_check__init_part0_A_const_198 any

var A_arbace_c_check__init_part0_A_const_199 *lang.Var

var A_arbace_c_check__init_part0_A_const_200 any

var A_arbace_c_check__init_part0_A_const_201 any

var A_arbace_c_check__init_part0_A_init jrt.ClassInit

func A_arbace_c_check__init_part0_A_Init() { if !A_arbace_c_check__init_part0_A_init.Done() { A_arbace_c_check__init_part0_A_init.Run(A_arbace_c_check__init_part0_A_clinit) } }

func A_arbace_c_check__init_part0_A_clinit() { A_arbace_c_check__init_part0_A_clinit_p0(); A_arbace_c_check__init_part0_A_clinit_p1(); A_arbace_c_check__init_part0_A_clinit_p2(); A_arbace_c_check__init_part0_A_clinit_p3(); A_arbace_c_check__init_part0_A_clinit_p4(); A_arbace_c_check__init_part0_A_clinit_p5(); A_arbace_c_check__init_part0_A_clinit_p6(); A_arbace_c_check__init_part0_A_clinit_p7(); A_arbace_c_check__init_part0_A_clinit_p8(); A_arbace_c_check__init_part0_A_clinit_p9(); A_arbace_c_check__init_part0_A_clinit_p10(); A_arbace_c_check__init_part0_A_clinit_p11(); A_arbace_c_check__init_part0_A_clinit_p12(); A_arbace_c_check__init_part0_A_clinit_p13(); A_arbace_c_check__init_part0_A_clinit_p14(); A_arbace_c_check__init_part0_A_clinit_p15() }

func A_arbace_c_check__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_check__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_418, 325); A_arbace_c_check__init_part0_A_const_0 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[123]); A_arbace_c_check__init_part0_A_const_1 = A_arbace_c_check__init_part0_A_const_pool.A[124]; A_arbace_c_check__init_part0_A_const_2 = A_arbace_c_check__init_part0_A_const_pool.A[125]; A_arbace_c_check__init_part0_A_const_3 = A_arbace_c_check__init_part0_A_const_pool.A[126]; A_arbace_c_check__init_part0_A_const_4 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[127]); A_arbace_c_check__init_part0_A_const_5 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[128]); A_arbace_c_check__init_part0_A_const_6 = A_arbace_c_check__init_part0_A_const_pool.A[129]; A_arbace_c_check__init_part0_A_const_7 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[130]); A_arbace_c_check__init_part0_A_const_8 = A_arbace_c_check__init_part0_A_const_pool.A[131]; A_arbace_c_check__init_part0_A_const_9 = A_arbace_c_check__init_part0_A_const_pool.A[132]; A_arbace_c_check__init_part0_A_const_10 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[133]); A_arbace_c_check__init_part0_A_const_11 = A_arbace_c_check__init_part0_A_const_pool.A[134]; A_arbace_c_check__init_part0_A_const_12 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[135]) }

func A_arbace_c_check__init_part0_A_clinit_p1() { A_arbace_c_check__init_part0_A_const_13 = A_arbace_c_check__init_part0_A_const_pool.A[136]; A_arbace_c_check__init_part0_A_const_14 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[137]); A_arbace_c_check__init_part0_A_const_15 = A_arbace_c_check__init_part0_A_const_pool.A[138]; A_arbace_c_check__init_part0_A_const_16 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[139]); A_arbace_c_check__init_part0_A_const_17 = A_arbace_c_check__init_part0_A_const_pool.A[140]; A_arbace_c_check__init_part0_A_const_18 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[141]); A_arbace_c_check__init_part0_A_const_19 = A_arbace_c_check__init_part0_A_const_pool.A[142]; A_arbace_c_check__init_part0_A_const_20 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[143]); A_arbace_c_check__init_part0_A_const_21 = A_arbace_c_check__init_part0_A_const_pool.A[144]; A_arbace_c_check__init_part0_A_const_22 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[145]); A_arbace_c_check__init_part0_A_const_23 = A_arbace_c_check__init_part0_A_const_pool.A[146]; A_arbace_c_check__init_part0_A_const_24 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[147]); A_arbace_c_check__init_part0_A_const_25 = A_arbace_c_check__init_part0_A_const_pool.A[148] }

func A_arbace_c_check__init_part0_A_clinit_p2() { A_arbace_c_check__init_part0_A_const_26 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[149]); A_arbace_c_check__init_part0_A_const_27 = A_arbace_c_check__init_part0_A_const_pool.A[150]; A_arbace_c_check__init_part0_A_const_28 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[151]); A_arbace_c_check__init_part0_A_const_29 = A_arbace_c_check__init_part0_A_const_pool.A[152]; A_arbace_c_check__init_part0_A_const_30 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[153]); A_arbace_c_check__init_part0_A_const_31 = A_arbace_c_check__init_part0_A_const_pool.A[154]; A_arbace_c_check__init_part0_A_const_32 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[155]); A_arbace_c_check__init_part0_A_const_33 = A_arbace_c_check__init_part0_A_const_pool.A[156]; A_arbace_c_check__init_part0_A_const_34 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[157]); A_arbace_c_check__init_part0_A_const_35 = A_arbace_c_check__init_part0_A_const_pool.A[158]; A_arbace_c_check__init_part0_A_const_36 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[159]); A_arbace_c_check__init_part0_A_const_37 = A_arbace_c_check__init_part0_A_const_pool.A[160]; A_arbace_c_check__init_part0_A_const_38 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[161]) }

func A_arbace_c_check__init_part0_A_clinit_p3() { A_arbace_c_check__init_part0_A_const_39 = A_arbace_c_check__init_part0_A_const_pool.A[162]; A_arbace_c_check__init_part0_A_const_40 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[163]); A_arbace_c_check__init_part0_A_const_41 = A_arbace_c_check__init_part0_A_const_pool.A[164]; A_arbace_c_check__init_part0_A_const_42 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[165]); A_arbace_c_check__init_part0_A_const_43 = A_arbace_c_check__init_part0_A_const_pool.A[166]; A_arbace_c_check__init_part0_A_const_44 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[167]); A_arbace_c_check__init_part0_A_const_45 = A_arbace_c_check__init_part0_A_const_pool.A[168]; A_arbace_c_check__init_part0_A_const_46 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[169]); A_arbace_c_check__init_part0_A_const_47 = A_arbace_c_check__init_part0_A_const_pool.A[170]; A_arbace_c_check__init_part0_A_const_48 = A_arbace_c_check__init_part0_A_const_pool.A[171]; A_arbace_c_check__init_part0_A_const_49 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[172]); A_arbace_c_check__init_part0_A_const_50 = A_arbace_c_check__init_part0_A_const_pool.A[173]; A_arbace_c_check__init_part0_A_const_51 = A_arbace_c_check__init_part0_A_const_pool.A[174]; A_arbace_c_check__init_part0_A_const_52 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[175]) }

func A_arbace_c_check__init_part0_A_clinit_p4() { A_arbace_c_check__init_part0_A_const_53 = A_arbace_c_check__init_part0_A_const_pool.A[176]; A_arbace_c_check__init_part0_A_const_54 = A_arbace_c_check__init_part0_A_const_pool.A[177]; A_arbace_c_check__init_part0_A_const_55 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[178]); A_arbace_c_check__init_part0_A_const_56 = A_arbace_c_check__init_part0_A_const_pool.A[179]; A_arbace_c_check__init_part0_A_const_57 = A_arbace_c_check__init_part0_A_const_pool.A[180]; A_arbace_c_check__init_part0_A_const_58 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[181]); A_arbace_c_check__init_part0_A_const_59 = A_arbace_c_check__init_part0_A_const_pool.A[182]; A_arbace_c_check__init_part0_A_const_60 = A_arbace_c_check__init_part0_A_const_pool.A[183]; A_arbace_c_check__init_part0_A_const_61 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[184]); A_arbace_c_check__init_part0_A_const_62 = A_arbace_c_check__init_part0_A_const_pool.A[185]; A_arbace_c_check__init_part0_A_const_63 = A_arbace_c_check__init_part0_A_const_pool.A[186]; A_arbace_c_check__init_part0_A_const_64 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[187]); A_arbace_c_check__init_part0_A_const_65 = A_arbace_c_check__init_part0_A_const_pool.A[188]; A_arbace_c_check__init_part0_A_const_66 = A_arbace_c_check__init_part0_A_const_pool.A[189] }

func A_arbace_c_check__init_part0_A_clinit_p5() { A_arbace_c_check__init_part0_A_const_67 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[190]); A_arbace_c_check__init_part0_A_const_68 = A_arbace_c_check__init_part0_A_const_pool.A[191]; A_arbace_c_check__init_part0_A_const_69 = A_arbace_c_check__init_part0_A_const_pool.A[192]; A_arbace_c_check__init_part0_A_const_70 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[193]); A_arbace_c_check__init_part0_A_const_71 = A_arbace_c_check__init_part0_A_const_pool.A[194]; A_arbace_c_check__init_part0_A_const_72 = A_arbace_c_check__init_part0_A_const_pool.A[195]; A_arbace_c_check__init_part0_A_const_73 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[196]); A_arbace_c_check__init_part0_A_const_74 = A_arbace_c_check__init_part0_A_const_pool.A[197]; A_arbace_c_check__init_part0_A_const_75 = A_arbace_c_check__init_part0_A_const_pool.A[198]; A_arbace_c_check__init_part0_A_const_76 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[199]); A_arbace_c_check__init_part0_A_const_77 = A_arbace_c_check__init_part0_A_const_pool.A[200]; A_arbace_c_check__init_part0_A_const_78 = A_arbace_c_check__init_part0_A_const_pool.A[201]; A_arbace_c_check__init_part0_A_const_79 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[202]); A_arbace_c_check__init_part0_A_const_80 = A_arbace_c_check__init_part0_A_const_pool.A[203] }

func A_arbace_c_check__init_part0_A_clinit_p6() { A_arbace_c_check__init_part0_A_const_81 = A_arbace_c_check__init_part0_A_const_pool.A[204]; A_arbace_c_check__init_part0_A_const_82 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[205]); A_arbace_c_check__init_part0_A_const_83 = A_arbace_c_check__init_part0_A_const_pool.A[206]; A_arbace_c_check__init_part0_A_const_84 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[207]); A_arbace_c_check__init_part0_A_const_85 = A_arbace_c_check__init_part0_A_const_pool.A[208]; A_arbace_c_check__init_part0_A_const_86 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[209]); A_arbace_c_check__init_part0_A_const_87 = A_arbace_c_check__init_part0_A_const_pool.A[210]; A_arbace_c_check__init_part0_A_const_88 = A_arbace_c_check__init_part0_A_const_pool.A[211]; A_arbace_c_check__init_part0_A_const_89 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[212]); A_arbace_c_check__init_part0_A_const_90 = A_arbace_c_check__init_part0_A_const_pool.A[213]; A_arbace_c_check__init_part0_A_const_91 = A_arbace_c_check__init_part0_A_const_pool.A[214]; A_arbace_c_check__init_part0_A_const_92 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[215]); A_arbace_c_check__init_part0_A_const_93 = A_arbace_c_check__init_part0_A_const_pool.A[216]; A_arbace_c_check__init_part0_A_const_94 = A_arbace_c_check__init_part0_A_const_pool.A[217] }

func A_arbace_c_check__init_part0_A_clinit_p7() { A_arbace_c_check__init_part0_A_const_95 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[218]); A_arbace_c_check__init_part0_A_const_96 = A_arbace_c_check__init_part0_A_const_pool.A[219]; A_arbace_c_check__init_part0_A_const_97 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[220]); A_arbace_c_check__init_part0_A_const_98 = A_arbace_c_check__init_part0_A_const_pool.A[221]; A_arbace_c_check__init_part0_A_const_99 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[222]); A_arbace_c_check__init_part0_A_const_100 = A_arbace_c_check__init_part0_A_const_pool.A[223]; A_arbace_c_check__init_part0_A_const_101 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[224]); A_arbace_c_check__init_part0_A_const_102 = A_arbace_c_check__init_part0_A_const_pool.A[225]; A_arbace_c_check__init_part0_A_const_103 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[226]); A_arbace_c_check__init_part0_A_const_104 = A_arbace_c_check__init_part0_A_const_pool.A[227]; A_arbace_c_check__init_part0_A_const_105 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[228]); A_arbace_c_check__init_part0_A_const_106 = A_arbace_c_check__init_part0_A_const_pool.A[229]; A_arbace_c_check__init_part0_A_const_107 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[230]) }

func A_arbace_c_check__init_part0_A_clinit_p8() { A_arbace_c_check__init_part0_A_const_108 = A_arbace_c_check__init_part0_A_const_pool.A[231]; A_arbace_c_check__init_part0_A_const_109 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[232]); A_arbace_c_check__init_part0_A_const_110 = A_arbace_c_check__init_part0_A_const_pool.A[233]; A_arbace_c_check__init_part0_A_const_111 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[234]); A_arbace_c_check__init_part0_A_const_112 = A_arbace_c_check__init_part0_A_const_pool.A[235]; A_arbace_c_check__init_part0_A_const_113 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[236]); A_arbace_c_check__init_part0_A_const_114 = A_arbace_c_check__init_part0_A_const_pool.A[237]; A_arbace_c_check__init_part0_A_const_115 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[238]); A_arbace_c_check__init_part0_A_const_116 = A_arbace_c_check__init_part0_A_const_pool.A[239]; A_arbace_c_check__init_part0_A_const_117 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[240]); A_arbace_c_check__init_part0_A_const_118 = A_arbace_c_check__init_part0_A_const_pool.A[241]; A_arbace_c_check__init_part0_A_const_119 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[242]); A_arbace_c_check__init_part0_A_const_120 = A_arbace_c_check__init_part0_A_const_pool.A[243] }

func A_arbace_c_check__init_part0_A_clinit_p9() { A_arbace_c_check__init_part0_A_const_121 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[244]); A_arbace_c_check__init_part0_A_const_122 = A_arbace_c_check__init_part0_A_const_pool.A[245]; A_arbace_c_check__init_part0_A_const_123 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[246]); A_arbace_c_check__init_part0_A_const_124 = A_arbace_c_check__init_part0_A_const_pool.A[247]; A_arbace_c_check__init_part0_A_const_125 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[248]); A_arbace_c_check__init_part0_A_const_126 = A_arbace_c_check__init_part0_A_const_pool.A[249]; A_arbace_c_check__init_part0_A_const_127 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[250]); A_arbace_c_check__init_part0_A_const_128 = A_arbace_c_check__init_part0_A_const_pool.A[251]; A_arbace_c_check__init_part0_A_const_129 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[252]); A_arbace_c_check__init_part0_A_const_130 = A_arbace_c_check__init_part0_A_const_pool.A[253]; A_arbace_c_check__init_part0_A_const_131 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[254]); A_arbace_c_check__init_part0_A_const_132 = A_arbace_c_check__init_part0_A_const_pool.A[255]; A_arbace_c_check__init_part0_A_const_133 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[256]) }

func A_arbace_c_check__init_part0_A_clinit_p10() { A_arbace_c_check__init_part0_A_const_134 = A_arbace_c_check__init_part0_A_const_pool.A[257]; A_arbace_c_check__init_part0_A_const_135 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[258]); A_arbace_c_check__init_part0_A_const_136 = A_arbace_c_check__init_part0_A_const_pool.A[259]; A_arbace_c_check__init_part0_A_const_137 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[260]); A_arbace_c_check__init_part0_A_const_138 = A_arbace_c_check__init_part0_A_const_pool.A[261]; A_arbace_c_check__init_part0_A_const_139 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[262]); A_arbace_c_check__init_part0_A_const_140 = A_arbace_c_check__init_part0_A_const_pool.A[263]; A_arbace_c_check__init_part0_A_const_141 = A_arbace_c_check__init_part0_A_const_pool.A[264]; A_arbace_c_check__init_part0_A_const_142 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[265]); A_arbace_c_check__init_part0_A_const_143 = A_arbace_c_check__init_part0_A_const_pool.A[266]; A_arbace_c_check__init_part0_A_const_144 = A_arbace_c_check__init_part0_A_const_pool.A[267]; A_arbace_c_check__init_part0_A_const_145 = A_arbace_c_check__init_part0_A_const_pool.A[268]; A_arbace_c_check__init_part0_A_const_146 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[269]); A_arbace_c_check__init_part0_A_const_147 = A_arbace_c_check__init_part0_A_const_pool.A[270] }

func A_arbace_c_check__init_part0_A_clinit_p11() { A_arbace_c_check__init_part0_A_const_148 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[271]); A_arbace_c_check__init_part0_A_const_149 = A_arbace_c_check__init_part0_A_const_pool.A[272]; A_arbace_c_check__init_part0_A_const_150 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[273]); A_arbace_c_check__init_part0_A_const_151 = A_arbace_c_check__init_part0_A_const_pool.A[274]; A_arbace_c_check__init_part0_A_const_152 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[275]); A_arbace_c_check__init_part0_A_const_153 = A_arbace_c_check__init_part0_A_const_pool.A[276]; A_arbace_c_check__init_part0_A_const_154 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[277]); A_arbace_c_check__init_part0_A_const_155 = A_arbace_c_check__init_part0_A_const_pool.A[278]; A_arbace_c_check__init_part0_A_const_156 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[279]); A_arbace_c_check__init_part0_A_const_157 = A_arbace_c_check__init_part0_A_const_pool.A[280]; A_arbace_c_check__init_part0_A_const_158 = A_arbace_c_check__init_part0_A_const_pool.A[281]; A_arbace_c_check__init_part0_A_const_159 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[282]); A_arbace_c_check__init_part0_A_const_160 = A_arbace_c_check__init_part0_A_const_pool.A[283] }

func A_arbace_c_check__init_part0_A_clinit_p12() { A_arbace_c_check__init_part0_A_const_161 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[284]); A_arbace_c_check__init_part0_A_const_162 = A_arbace_c_check__init_part0_A_const_pool.A[285]; A_arbace_c_check__init_part0_A_const_163 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[286]); A_arbace_c_check__init_part0_A_const_164 = A_arbace_c_check__init_part0_A_const_pool.A[287]; A_arbace_c_check__init_part0_A_const_165 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[288]); A_arbace_c_check__init_part0_A_const_166 = A_arbace_c_check__init_part0_A_const_pool.A[289]; A_arbace_c_check__init_part0_A_const_167 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[290]); A_arbace_c_check__init_part0_A_const_168 = A_arbace_c_check__init_part0_A_const_pool.A[291]; A_arbace_c_check__init_part0_A_const_169 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[292]); A_arbace_c_check__init_part0_A_const_170 = A_arbace_c_check__init_part0_A_const_pool.A[293]; A_arbace_c_check__init_part0_A_const_171 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[294]); A_arbace_c_check__init_part0_A_const_172 = A_arbace_c_check__init_part0_A_const_pool.A[295]; A_arbace_c_check__init_part0_A_const_173 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[296]) }

func A_arbace_c_check__init_part0_A_clinit_p13() { A_arbace_c_check__init_part0_A_const_174 = A_arbace_c_check__init_part0_A_const_pool.A[297]; A_arbace_c_check__init_part0_A_const_175 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[298]); A_arbace_c_check__init_part0_A_const_176 = A_arbace_c_check__init_part0_A_const_pool.A[299]; A_arbace_c_check__init_part0_A_const_177 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[300]); A_arbace_c_check__init_part0_A_const_178 = A_arbace_c_check__init_part0_A_const_pool.A[301]; A_arbace_c_check__init_part0_A_const_179 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[302]); A_arbace_c_check__init_part0_A_const_180 = A_arbace_c_check__init_part0_A_const_pool.A[303]; A_arbace_c_check__init_part0_A_const_181 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[304]); A_arbace_c_check__init_part0_A_const_182 = A_arbace_c_check__init_part0_A_const_pool.A[305]; A_arbace_c_check__init_part0_A_const_183 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[306]); A_arbace_c_check__init_part0_A_const_184 = A_arbace_c_check__init_part0_A_const_pool.A[307]; A_arbace_c_check__init_part0_A_const_185 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[308]); A_arbace_c_check__init_part0_A_const_186 = A_arbace_c_check__init_part0_A_const_pool.A[309] }

func A_arbace_c_check__init_part0_A_clinit_p14() { A_arbace_c_check__init_part0_A_const_187 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[310]); A_arbace_c_check__init_part0_A_const_188 = A_arbace_c_check__init_part0_A_const_pool.A[311]; A_arbace_c_check__init_part0_A_const_189 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[312]); A_arbace_c_check__init_part0_A_const_190 = A_arbace_c_check__init_part0_A_const_pool.A[313]; A_arbace_c_check__init_part0_A_const_191 = A_arbace_c_check__init_part0_A_const_pool.A[314]; A_arbace_c_check__init_part0_A_const_192 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[315]); A_arbace_c_check__init_part0_A_const_193 = A_arbace_c_check__init_part0_A_const_pool.A[316]; A_arbace_c_check__init_part0_A_const_194 = A_arbace_c_check__init_part0_A_const_pool.A[317]; A_arbace_c_check__init_part0_A_const_195 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[318]); A_arbace_c_check__init_part0_A_const_196 = A_arbace_c_check__init_part0_A_const_pool.A[319]; A_arbace_c_check__init_part0_A_const_197 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[320]); A_arbace_c_check__init_part0_A_const_198 = A_arbace_c_check__init_part0_A_const_pool.A[321]; A_arbace_c_check__init_part0_A_const_199 = lang.Var_Cast(A_arbace_c_check__init_part0_A_const_pool.A[322]); A_arbace_c_check__init_part0_A_const_200 = A_arbace_c_check__init_part0_A_const_pool.A[323] }

func A_arbace_c_check__init_part0_A_clinit_p15() { A_arbace_c_check__init_part0_A_const_201 = A_arbace_c_check__init_part0_A_const_pool.A[324] }

func A_arbace_c_check__init_part0_A_New() *A_arbace_c_check__init_part0_A { A_arbace_c_check__init_part0_A_Init(); t := &A_arbace_c_check__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_c_check__init_part0_A) Ctor() {}

func (t *A_arbace_c_check__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_check__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_c_check__init_part0_A_class }

func (t *A_arbace_c_check__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_check__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_check__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_check__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_check__init_part0_A); return ok }

func A_arbace_c_check__init_part0_A_Cast(x any) *A_arbace_c_check__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_check__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_check__init_part0_A_class)) }; return v }



type A_arbace_c_check__init_part1_A struct{ jrt.Object }

var A_arbace_c_check__init_part1_A_const_pool *jrt.RefArray

var A_arbace_c_check__init_part1_A_const_0 *lang.Var

var A_arbace_c_check__init_part1_A_const_1 any

var A_arbace_c_check__init_part1_A_const_2 *lang.Var

var A_arbace_c_check__init_part1_A_const_3 any

var A_arbace_c_check__init_part1_A_const_4 *lang.Var

var A_arbace_c_check__init_part1_A_const_5 any

var A_arbace_c_check__init_part1_A_const_6 *lang.Var

var A_arbace_c_check__init_part1_A_const_7 any

var A_arbace_c_check__init_part1_A_const_8 *lang.Var

var A_arbace_c_check__init_part1_A_const_9 any

var A_arbace_c_check__init_part1_A_const_10 any

var A_arbace_c_check__init_part1_A_const_11 *lang.Var

var A_arbace_c_check__init_part1_A_const_12 any

var A_arbace_c_check__init_part1_A_const_13 any

var A_arbace_c_check__init_part1_A_const_14 *lang.Var

var A_arbace_c_check__init_part1_A_const_15 any

var A_arbace_c_check__init_part1_A_const_16 *lang.Var

var A_arbace_c_check__init_part1_A_const_17 any

var A_arbace_c_check__init_part1_A_const_18 any

var A_arbace_c_check__init_part1_A_const_19 *lang.Var

var A_arbace_c_check__init_part1_A_const_20 any

var A_arbace_c_check__init_part1_A_const_21 any

var A_arbace_c_check__init_part1_A_const_22 *lang.Var

var A_arbace_c_check__init_part1_A_const_23 any

var A_arbace_c_check__init_part1_A_const_24 *lang.Var

var A_arbace_c_check__init_part1_A_const_25 any

var A_arbace_c_check__init_part1_A_const_26 *lang.Var

var A_arbace_c_check__init_part1_A_const_27 any

var A_arbace_c_check__init_part1_A_const_28 *lang.Var

var A_arbace_c_check__init_part1_A_const_29 any

var A_arbace_c_check__init_part1_A_const_30 *lang.Var

var A_arbace_c_check__init_part1_A_const_31 any

var A_arbace_c_check__init_part1_A_const_32 *lang.Var

var A_arbace_c_check__init_part1_A_const_33 any

var A_arbace_c_check__init_part1_A_const_34 *lang.Var

var A_arbace_c_check__init_part1_A_const_35 any

var A_arbace_c_check__init_part1_A_const_36 *lang.Var

var A_arbace_c_check__init_part1_A_const_37 any

var A_arbace_c_check__init_part1_A_const_38 *lang.Var

var A_arbace_c_check__init_part1_A_const_39 any

var A_arbace_c_check__init_part1_A_const_40 *lang.Var

var A_arbace_c_check__init_part1_A_const_41 any

var A_arbace_c_check__init_part1_A_const_42 *lang.Var

var A_arbace_c_check__init_part1_A_const_43 any

var A_arbace_c_check__init_part1_A_const_44 *lang.Var

var A_arbace_c_check__init_part1_A_const_45 any

var A_arbace_c_check__init_part1_A_const_46 *lang.Var

var A_arbace_c_check__init_part1_A_const_47 any

var A_arbace_c_check__init_part1_A_const_48 *lang.Var

var A_arbace_c_check__init_part1_A_const_49 any

var A_arbace_c_check__init_part1_A_const_50 *lang.Var

var A_arbace_c_check__init_part1_A_const_51 any

var A_arbace_c_check__init_part1_A_const_52 *lang.Var

var A_arbace_c_check__init_part1_A_const_53 any

var A_arbace_c_check__init_part1_A_const_54 *lang.Var

var A_arbace_c_check__init_part1_A_const_55 any

var A_arbace_c_check__init_part1_A_const_56 *lang.Var

var A_arbace_c_check__init_part1_A_const_57 any

var A_arbace_c_check__init_part1_A_const_58 *lang.Var

var A_arbace_c_check__init_part1_A_const_59 any

var A_arbace_c_check__init_part1_A_const_60 *lang.Var

var A_arbace_c_check__init_part1_A_const_61 any

var A_arbace_c_check__init_part1_A_const_62 *lang.Var

var A_arbace_c_check__init_part1_A_const_63 any

var A_arbace_c_check__init_part1_A_const_64 *lang.Var

var A_arbace_c_check__init_part1_A_const_65 any

var A_arbace_c_check__init_part1_A_const_66 *lang.Var

var A_arbace_c_check__init_part1_A_const_67 any

var A_arbace_c_check__init_part1_A_const_68 *lang.Var

var A_arbace_c_check__init_part1_A_const_69 any

var A_arbace_c_check__init_part1_A_const_70 *lang.Var

var A_arbace_c_check__init_part1_A_const_71 any

var A_arbace_c_check__init_part1_A_const_72 *lang.Var

var A_arbace_c_check__init_part1_A_const_73 any

var A_arbace_c_check__init_part1_A_const_74 *lang.Var

var A_arbace_c_check__init_part1_A_const_75 any

var A_arbace_c_check__init_part1_A_const_76 *lang.Var

var A_arbace_c_check__init_part1_A_const_77 any

var A_arbace_c_check__init_part1_A_const_78 *lang.Var

var A_arbace_c_check__init_part1_A_const_79 any

var A_arbace_c_check__init_part1_A_const_80 *lang.Var

var A_arbace_c_check__init_part1_A_const_81 any

var A_arbace_c_check__init_part1_A_const_82 any

var A_arbace_c_check__init_part1_A_const_83 *lang.Var

var A_arbace_c_check__init_part1_A_const_84 any

var A_arbace_c_check__init_part1_A_const_85 *lang.Var

var A_arbace_c_check__init_part1_A_const_86 any

var A_arbace_c_check__init_part1_A_const_87 *lang.Var

var A_arbace_c_check__init_part1_A_const_88 any

var A_arbace_c_check__init_part1_A_const_89 *lang.Var

var A_arbace_c_check__init_part1_A_const_90 any

var A_arbace_c_check__init_part1_A_const_91 *lang.Var

var A_arbace_c_check__init_part1_A_const_92 any

var A_arbace_c_check__init_part1_A_const_93 *lang.Var

var A_arbace_c_check__init_part1_A_const_94 any

var A_arbace_c_check__init_part1_A_const_95 any

var A_arbace_c_check__init_part1_A_const_96 any

var A_arbace_c_check__init_part1_A_const_97 *lang.Var

var A_arbace_c_check__init_part1_A_const_98 any

var A_arbace_c_check__init_part1_A_const_99 any

var A_arbace_c_check__init_part1_A_const_100 *lang.Var

var A_arbace_c_check__init_part1_A_const_101 any

var A_arbace_c_check__init_part1_A_const_102 *lang.Var

var A_arbace_c_check__init_part1_A_const_103 any

var A_arbace_c_check__init_part1_A_const_104 *lang.Var

var A_arbace_c_check__init_part1_A_const_105 any

var A_arbace_c_check__init_part1_A_const_106 *lang.Var

var A_arbace_c_check__init_part1_A_const_107 any

var A_arbace_c_check__init_part1_A_const_108 *lang.Var

var A_arbace_c_check__init_part1_A_const_109 any

var A_arbace_c_check__init_part1_A_const_110 *lang.Var

var A_arbace_c_check__init_part1_A_const_111 any

var A_arbace_c_check__init_part1_A_const_112 any

var A_arbace_c_check__init_part1_A_const_113 *lang.Var

var A_arbace_c_check__init_part1_A_const_114 any

var A_arbace_c_check__init_part1_A_const_115 any

var A_arbace_c_check__init_part1_A_const_116 *lang.Var

var A_arbace_c_check__init_part1_A_const_117 any

var A_arbace_c_check__init_part1_A_const_118 *lang.Var

var A_arbace_c_check__init_part1_A_const_119 any

var A_arbace_c_check__init_part1_A_const_120 any

var A_arbace_c_check__init_part1_A_const_121 *lang.Var

var A_arbace_c_check__init_part1_A_const_122 any

var A_arbace_c_check__init_part1_A_const_123 *lang.Var

var A_arbace_c_check__init_part1_A_const_124 any

var A_arbace_c_check__init_part1_A_const_125 *lang.Var

var A_arbace_c_check__init_part1_A_const_126 any

var A_arbace_c_check__init_part1_A_const_127 *lang.Var

var A_arbace_c_check__init_part1_A_const_128 any

var A_arbace_c_check__init_part1_A_const_129 *lang.Var

var A_arbace_c_check__init_part1_A_const_130 any

var A_arbace_c_check__init_part1_A_const_131 *lang.Var

var A_arbace_c_check__init_part1_A_const_132 any

var A_arbace_c_check__init_part1_A_const_133 *lang.Var

var A_arbace_c_check__init_part1_A_const_134 any

var A_arbace_c_check__init_part1_A_const_135 *lang.Var

var A_arbace_c_check__init_part1_A_const_136 any

var A_arbace_c_check__init_part1_A_const_137 any

var A_arbace_c_check__init_part1_A_const_138 *lang.Var

var A_arbace_c_check__init_part1_A_const_139 any

var A_arbace_c_check__init_part1_A_const_140 *lang.Var

var A_arbace_c_check__init_part1_A_const_141 any

var A_arbace_c_check__init_part1_A_const_142 *lang.Var

var A_arbace_c_check__init_part1_A_const_143 any

var A_arbace_c_check__init_part1_A_const_144 *lang.Var

var A_arbace_c_check__init_part1_A_const_145 any

var A_arbace_c_check__init_part1_A_const_146 *lang.Var

var A_arbace_c_check__init_part1_A_const_147 any

var A_arbace_c_check__init_part1_A_const_148 *lang.Var

var A_arbace_c_check__init_part1_A_const_149 any

var A_arbace_c_check__init_part1_A_const_150 *lang.Var

var A_arbace_c_check__init_part1_A_const_151 any

var A_arbace_c_check__init_part1_A_const_152 any

var A_arbace_c_check__init_part1_A_const_153 *lang.Var

var A_arbace_c_check__init_part1_A_const_154 any

var A_arbace_c_check__init_part1_A_const_155 *lang.Var

var A_arbace_c_check__init_part1_A_const_156 any

var A_arbace_c_check__init_part1_A_const_157 *lang.Var

var A_arbace_c_check__init_part1_A_const_158 any

var A_arbace_c_check__init_part1_A_const_159 *lang.Var

var A_arbace_c_check__init_part1_A_const_160 any

var A_arbace_c_check__init_part1_A_const_161 *lang.Var

var A_arbace_c_check__init_part1_A_const_162 any

var A_arbace_c_check__init_part1_A_const_163 *lang.Var

var A_arbace_c_check__init_part1_A_const_164 any

var A_arbace_c_check__init_part1_A_const_165 *lang.Var

var A_arbace_c_check__init_part1_A_const_166 any

var A_arbace_c_check__init_part1_A_const_167 *lang.Var

var A_arbace_c_check__init_part1_A_const_168 any

var A_arbace_c_check__init_part1_A_const_169 *lang.Var

var A_arbace_c_check__init_part1_A_const_170 any

var A_arbace_c_check__init_part1_A_const_171 *lang.Var

var A_arbace_c_check__init_part1_A_const_172 any

var A_arbace_c_check__init_part1_A_const_173 *lang.Var

var A_arbace_c_check__init_part1_A_const_174 any

var A_arbace_c_check__init_part1_A_const_175 *lang.Var

var A_arbace_c_check__init_part1_A_const_176 any

var A_arbace_c_check__init_part1_A_const_177 *lang.Var

var A_arbace_c_check__init_part1_A_const_178 any

var A_arbace_c_check__init_part1_A_const_179 *lang.Var

var A_arbace_c_check__init_part1_A_const_180 any

var A_arbace_c_check__init_part1_A_const_181 *lang.Var

var A_arbace_c_check__init_part1_A_const_182 any

var A_arbace_c_check__init_part1_A_const_183 *lang.Var

var A_arbace_c_check__init_part1_A_const_184 any

var A_arbace_c_check__init_part1_A_const_185 *lang.Var

var A_arbace_c_check__init_part1_A_const_186 any

var A_arbace_c_check__init_part1_A_const_187 *lang.Var

var A_arbace_c_check__init_part1_A_const_188 any

var A_arbace_c_check__init_part1_A_const_189 *lang.Var

var A_arbace_c_check__init_part1_A_const_190 *lang.Var

var A_arbace_c_check__init_part1_A_const_191 *lang.Var

var A_arbace_c_check__init_part1_A_const_192 *lang.Var

var A_arbace_c_check__init_part1_A_const_193 *lang.Var

var A_arbace_c_check__init_part1_A_const_194 *lang.Var

var A_arbace_c_check__init_part1_A_const_195 any

var A_arbace_c_check__init_part1_A_const_196 *lang.Var

var A_arbace_c_check__init_part1_A_const_197 any

var A_arbace_c_check__init_part1_A_const_198 *lang.Var

var A_arbace_c_check__init_part1_A_const_199 any

var A_arbace_c_check__init_part1_A_const_200 *lang.Var

var A_arbace_c_check__init_part1_A_const_201 any

var A_arbace_c_check__init_part1_A_const_202 any

var A_arbace_c_check__init_part1_A_const_203 *lang.Var

var A_arbace_c_check__init_part1_A_const_204 any

var A_arbace_c_check__init_part1_A_const_205 *lang.Var

var A_arbace_c_check__init_part1_A_const_206 any

var A_arbace_c_check__init_part1_A_init jrt.ClassInit

func A_arbace_c_check__init_part1_A_Init() { if !A_arbace_c_check__init_part1_A_init.Done() { A_arbace_c_check__init_part1_A_init.Run(A_arbace_c_check__init_part1_A_clinit) } }

func A_arbace_c_check__init_part1_A_clinit() { A_arbace_c_check__init_part1_A_clinit_p0(); A_arbace_c_check__init_part1_A_clinit_p1(); A_arbace_c_check__init_part1_A_clinit_p2(); A_arbace_c_check__init_part1_A_clinit_p3(); A_arbace_c_check__init_part1_A_clinit_p4(); A_arbace_c_check__init_part1_A_clinit_p5(); A_arbace_c_check__init_part1_A_clinit_p6(); A_arbace_c_check__init_part1_A_clinit_p7(); A_arbace_c_check__init_part1_A_clinit_p8(); A_arbace_c_check__init_part1_A_clinit_p9(); A_arbace_c_check__init_part1_A_clinit_p10(); A_arbace_c_check__init_part1_A_clinit_p11() }

func A_arbace_c_check__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_check__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_481, 276); A_arbace_c_check__init_part1_A_const_0 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[75]); A_arbace_c_check__init_part1_A_const_1 = A_arbace_c_check__init_part1_A_const_pool.A[76]; A_arbace_c_check__init_part1_A_const_2 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[77]); A_arbace_c_check__init_part1_A_const_3 = A_arbace_c_check__init_part1_A_const_pool.A[78]; A_arbace_c_check__init_part1_A_const_4 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[79]); A_arbace_c_check__init_part1_A_const_5 = A_arbace_c_check__init_part1_A_const_pool.A[80]; A_arbace_c_check__init_part1_A_const_6 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[81]); A_arbace_c_check__init_part1_A_const_7 = A_arbace_c_check__init_part1_A_const_pool.A[82]; A_arbace_c_check__init_part1_A_const_8 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[83]); A_arbace_c_check__init_part1_A_const_9 = A_arbace_c_check__init_part1_A_const_pool.A[84]; A_arbace_c_check__init_part1_A_const_10 = A_arbace_c_check__init_part1_A_const_pool.A[85]; A_arbace_c_check__init_part1_A_const_11 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[86]); A_arbace_c_check__init_part1_A_const_12 = A_arbace_c_check__init_part1_A_const_pool.A[87] }

func A_arbace_c_check__init_part1_A_clinit_p1() { A_arbace_c_check__init_part1_A_const_13 = A_arbace_c_check__init_part1_A_const_pool.A[88]; A_arbace_c_check__init_part1_A_const_14 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[89]); A_arbace_c_check__init_part1_A_const_15 = A_arbace_c_check__init_part1_A_const_pool.A[90]; A_arbace_c_check__init_part1_A_const_16 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[91]); A_arbace_c_check__init_part1_A_const_17 = A_arbace_c_check__init_part1_A_const_pool.A[92]; A_arbace_c_check__init_part1_A_const_18 = A_arbace_c_check__init_part1_A_const_pool.A[93]; A_arbace_c_check__init_part1_A_const_19 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[94]); A_arbace_c_check__init_part1_A_const_20 = A_arbace_c_check__init_part1_A_const_pool.A[95]; A_arbace_c_check__init_part1_A_const_21 = A_arbace_c_check__init_part1_A_const_pool.A[96]; A_arbace_c_check__init_part1_A_const_22 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[97]); A_arbace_c_check__init_part1_A_const_23 = A_arbace_c_check__init_part1_A_const_pool.A[98]; A_arbace_c_check__init_part1_A_const_24 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[99]); A_arbace_c_check__init_part1_A_const_25 = A_arbace_c_check__init_part1_A_const_pool.A[100]; A_arbace_c_check__init_part1_A_const_26 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[101]) }

func A_arbace_c_check__init_part1_A_clinit_p2() { A_arbace_c_check__init_part1_A_const_27 = A_arbace_c_check__init_part1_A_const_pool.A[102]; A_arbace_c_check__init_part1_A_const_28 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[103]); A_arbace_c_check__init_part1_A_const_29 = A_arbace_c_check__init_part1_A_const_pool.A[104]; A_arbace_c_check__init_part1_A_const_30 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[105]); A_arbace_c_check__init_part1_A_const_31 = A_arbace_c_check__init_part1_A_const_pool.A[106]; A_arbace_c_check__init_part1_A_const_32 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[107]); A_arbace_c_check__init_part1_A_const_33 = A_arbace_c_check__init_part1_A_const_pool.A[108]; A_arbace_c_check__init_part1_A_const_34 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[109]); A_arbace_c_check__init_part1_A_const_35 = A_arbace_c_check__init_part1_A_const_pool.A[110]; A_arbace_c_check__init_part1_A_const_36 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[111]); A_arbace_c_check__init_part1_A_const_37 = A_arbace_c_check__init_part1_A_const_pool.A[112]; A_arbace_c_check__init_part1_A_const_38 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[113]); A_arbace_c_check__init_part1_A_const_39 = A_arbace_c_check__init_part1_A_const_pool.A[114] }

func A_arbace_c_check__init_part1_A_clinit_p3() { A_arbace_c_check__init_part1_A_const_40 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[115]); A_arbace_c_check__init_part1_A_const_41 = A_arbace_c_check__init_part1_A_const_pool.A[116]; A_arbace_c_check__init_part1_A_const_42 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[117]); A_arbace_c_check__init_part1_A_const_43 = A_arbace_c_check__init_part1_A_const_pool.A[118]; A_arbace_c_check__init_part1_A_const_44 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[119]); A_arbace_c_check__init_part1_A_const_45 = A_arbace_c_check__init_part1_A_const_pool.A[120]; A_arbace_c_check__init_part1_A_const_46 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[121]); A_arbace_c_check__init_part1_A_const_47 = A_arbace_c_check__init_part1_A_const_pool.A[122]; A_arbace_c_check__init_part1_A_const_48 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[123]); A_arbace_c_check__init_part1_A_const_49 = A_arbace_c_check__init_part1_A_const_pool.A[124]; A_arbace_c_check__init_part1_A_const_50 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[125]); A_arbace_c_check__init_part1_A_const_51 = A_arbace_c_check__init_part1_A_const_pool.A[126]; A_arbace_c_check__init_part1_A_const_52 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[127]) }

func A_arbace_c_check__init_part1_A_clinit_p4() { A_arbace_c_check__init_part1_A_const_53 = A_arbace_c_check__init_part1_A_const_pool.A[128]; A_arbace_c_check__init_part1_A_const_54 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[129]); A_arbace_c_check__init_part1_A_const_55 = A_arbace_c_check__init_part1_A_const_pool.A[130]; A_arbace_c_check__init_part1_A_const_56 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[131]); A_arbace_c_check__init_part1_A_const_57 = A_arbace_c_check__init_part1_A_const_pool.A[132]; A_arbace_c_check__init_part1_A_const_58 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[133]); A_arbace_c_check__init_part1_A_const_59 = A_arbace_c_check__init_part1_A_const_pool.A[134]; A_arbace_c_check__init_part1_A_const_60 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[135]); A_arbace_c_check__init_part1_A_const_61 = A_arbace_c_check__init_part1_A_const_pool.A[136]; A_arbace_c_check__init_part1_A_const_62 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[137]); A_arbace_c_check__init_part1_A_const_63 = A_arbace_c_check__init_part1_A_const_pool.A[138]; A_arbace_c_check__init_part1_A_const_64 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[139]); A_arbace_c_check__init_part1_A_const_65 = A_arbace_c_check__init_part1_A_const_pool.A[140] }

func A_arbace_c_check__init_part1_A_clinit_p5() { A_arbace_c_check__init_part1_A_const_66 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[141]); A_arbace_c_check__init_part1_A_const_67 = A_arbace_c_check__init_part1_A_const_pool.A[142]; A_arbace_c_check__init_part1_A_const_68 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[143]); A_arbace_c_check__init_part1_A_const_69 = A_arbace_c_check__init_part1_A_const_pool.A[144]; A_arbace_c_check__init_part1_A_const_70 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[145]); A_arbace_c_check__init_part1_A_const_71 = A_arbace_c_check__init_part1_A_const_pool.A[146]; A_arbace_c_check__init_part1_A_const_72 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[147]); A_arbace_c_check__init_part1_A_const_73 = A_arbace_c_check__init_part1_A_const_pool.A[148]; A_arbace_c_check__init_part1_A_const_74 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[149]); A_arbace_c_check__init_part1_A_const_75 = A_arbace_c_check__init_part1_A_const_pool.A[150]; A_arbace_c_check__init_part1_A_const_76 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[151]); A_arbace_c_check__init_part1_A_const_77 = A_arbace_c_check__init_part1_A_const_pool.A[152]; A_arbace_c_check__init_part1_A_const_78 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[153]) }

func A_arbace_c_check__init_part1_A_clinit_p6() { A_arbace_c_check__init_part1_A_const_79 = A_arbace_c_check__init_part1_A_const_pool.A[154]; A_arbace_c_check__init_part1_A_const_80 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[155]); A_arbace_c_check__init_part1_A_const_81 = A_arbace_c_check__init_part1_A_const_pool.A[156]; A_arbace_c_check__init_part1_A_const_82 = A_arbace_c_check__init_part1_A_const_pool.A[157]; A_arbace_c_check__init_part1_A_const_83 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[158]); A_arbace_c_check__init_part1_A_const_84 = A_arbace_c_check__init_part1_A_const_pool.A[159]; A_arbace_c_check__init_part1_A_const_85 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[160]); A_arbace_c_check__init_part1_A_const_86 = A_arbace_c_check__init_part1_A_const_pool.A[161]; A_arbace_c_check__init_part1_A_const_87 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[162]); A_arbace_c_check__init_part1_A_const_88 = A_arbace_c_check__init_part1_A_const_pool.A[163]; A_arbace_c_check__init_part1_A_const_89 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[164]); A_arbace_c_check__init_part1_A_const_90 = A_arbace_c_check__init_part1_A_const_pool.A[165]; A_arbace_c_check__init_part1_A_const_91 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[166]); A_arbace_c_check__init_part1_A_const_92 = A_arbace_c_check__init_part1_A_const_pool.A[167] }

func A_arbace_c_check__init_part1_A_clinit_p7() { A_arbace_c_check__init_part1_A_const_93 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[168]); A_arbace_c_check__init_part1_A_const_94 = A_arbace_c_check__init_part1_A_const_pool.A[169]; A_arbace_c_check__init_part1_A_const_95 = A_arbace_c_check__init_part1_A_const_pool.A[170]; A_arbace_c_check__init_part1_A_const_96 = A_arbace_c_check__init_part1_A_const_pool.A[171]; A_arbace_c_check__init_part1_A_const_97 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[172]); A_arbace_c_check__init_part1_A_const_98 = A_arbace_c_check__init_part1_A_const_pool.A[173]; A_arbace_c_check__init_part1_A_const_99 = A_arbace_c_check__init_part1_A_const_pool.A[174]; A_arbace_c_check__init_part1_A_const_100 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[175]); A_arbace_c_check__init_part1_A_const_101 = A_arbace_c_check__init_part1_A_const_pool.A[176]; A_arbace_c_check__init_part1_A_const_102 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[177]); A_arbace_c_check__init_part1_A_const_103 = A_arbace_c_check__init_part1_A_const_pool.A[178]; A_arbace_c_check__init_part1_A_const_104 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[179]); A_arbace_c_check__init_part1_A_const_105 = A_arbace_c_check__init_part1_A_const_pool.A[180]; A_arbace_c_check__init_part1_A_const_106 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[181]) }

func A_arbace_c_check__init_part1_A_clinit_p8() { A_arbace_c_check__init_part1_A_const_107 = A_arbace_c_check__init_part1_A_const_pool.A[182]; A_arbace_c_check__init_part1_A_const_108 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[183]); A_arbace_c_check__init_part1_A_const_109 = A_arbace_c_check__init_part1_A_const_pool.A[184]; A_arbace_c_check__init_part1_A_const_110 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[185]); A_arbace_c_check__init_part1_A_const_111 = A_arbace_c_check__init_part1_A_const_pool.A[186]; A_arbace_c_check__init_part1_A_const_112 = A_arbace_c_check__init_part1_A_const_pool.A[187]; A_arbace_c_check__init_part1_A_const_113 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[188]); A_arbace_c_check__init_part1_A_const_114 = A_arbace_c_check__init_part1_A_const_pool.A[189]; A_arbace_c_check__init_part1_A_const_115 = A_arbace_c_check__init_part1_A_const_pool.A[190]; A_arbace_c_check__init_part1_A_const_116 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[191]); A_arbace_c_check__init_part1_A_const_117 = A_arbace_c_check__init_part1_A_const_pool.A[192]; A_arbace_c_check__init_part1_A_const_118 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[193]); A_arbace_c_check__init_part1_A_const_119 = A_arbace_c_check__init_part1_A_const_pool.A[194]; A_arbace_c_check__init_part1_A_const_120 = A_arbace_c_check__init_part1_A_const_pool.A[195] }

func A_arbace_c_check__init_part1_A_clinit_p9() { A_arbace_c_check__init_part1_A_const_121 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[196]); A_arbace_c_check__init_part1_A_const_122 = A_arbace_c_check__init_part1_A_const_pool.A[197]; A_arbace_c_check__init_part1_A_const_123 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[198]); A_arbace_c_check__init_part1_A_const_124 = A_arbace_c_check__init_part1_A_const_pool.A[199]; A_arbace_c_check__init_part1_A_const_125 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[200]); A_arbace_c_check__init_part1_A_const_126 = A_arbace_c_check__init_part1_A_const_pool.A[201]; A_arbace_c_check__init_part1_A_const_127 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[202]); A_arbace_c_check__init_part1_A_const_128 = A_arbace_c_check__init_part1_A_const_pool.A[203]; A_arbace_c_check__init_part1_A_const_129 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[204]); A_arbace_c_check__init_part1_A_const_130 = A_arbace_c_check__init_part1_A_const_pool.A[205]; A_arbace_c_check__init_part1_A_const_131 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[206]); A_arbace_c_check__init_part1_A_const_132 = A_arbace_c_check__init_part1_A_const_pool.A[207]; A_arbace_c_check__init_part1_A_const_133 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[208]) }

func A_arbace_c_check__init_part1_A_clinit_p10() { A_arbace_c_check__init_part1_A_const_134 = A_arbace_c_check__init_part1_A_const_pool.A[209]; A_arbace_c_check__init_part1_A_const_135 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[210]); A_arbace_c_check__init_part1_A_const_136 = A_arbace_c_check__init_part1_A_const_pool.A[211]; A_arbace_c_check__init_part1_A_const_137 = A_arbace_c_check__init_part1_A_const_pool.A[212]; A_arbace_c_check__init_part1_A_const_138 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[213]); A_arbace_c_check__init_part1_A_const_139 = A_arbace_c_check__init_part1_A_const_pool.A[214]; A_arbace_c_check__init_part1_A_const_140 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[215]); A_arbace_c_check__init_part1_A_const_141 = A_arbace_c_check__init_part1_A_const_pool.A[216]; A_arbace_c_check__init_part1_A_const_142 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[217]); A_arbace_c_check__init_part1_A_const_143 = A_arbace_c_check__init_part1_A_const_pool.A[218]; A_arbace_c_check__init_part1_A_const_144 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[219]); A_arbace_c_check__init_part1_A_const_145 = A_arbace_c_check__init_part1_A_const_pool.A[220] }

func A_arbace_c_check__init_part1_A_clinit_p11() { var tmp1 *lang.Var; A_arbace_c_check__init_part0_A_Init(); tmp1 = A_arbace_c_check__init_part0_A_const_137; A_arbace_c_check__init_part1_A_const_146 = tmp1; A_arbace_c_check__init_part1_A_const_147 = A_arbace_c_check__init_part1_A_const_pool.A[221]; A_arbace_c_check__init_part1_A_const_148 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[222]); A_arbace_c_check__init_part1_A_const_149 = A_arbace_c_check__init_part1_A_const_pool.A[223]; A_arbace_c_check__init_part1_A_const_150 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[224]); A_arbace_c_check__init_part1_A_const_151 = A_arbace_c_check__init_part1_A_const_pool.A[225]; A_arbace_c_check__init_part1_A_const_152 = A_arbace_c_check__init_part1_A_const_pool.A[226]; A_arbace_c_check__init_part1_A_const_153 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[227]); A_arbace_c_check__init_part1_A_const_154 = A_arbace_c_check__init_part1_A_const_pool.A[228]; A_arbace_c_check__init_part1_A_const_155 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[229]); A_arbace_c_check__init_part1_A_const_156 = A_arbace_c_check__init_part1_A_const_pool.A[230]; A_arbace_c_check__init_part1_A_const_157 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[231]); A_arbace_c_check__init_part1_A_const_158 = A_arbace_c_check__init_part1_A_const_pool.A[232]; A_arbace_c_check__init_part1_A_const_159 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[233]); A_arbace_c_check__init_part1_A_const_160 = A_arbace_c_check__init_part1_A_const_pool.A[234]; A_arbace_c_check__init_part1_A_const_161 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[235]); A_arbace_c_check__init_part1_A_const_162 = A_arbace_c_check__init_part1_A_const_pool.A[236]; A_arbace_c_check__init_part1_A_const_163 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[237]); A_arbace_c_check__init_part1_A_const_164 = A_arbace_c_check__init_part1_A_const_pool.A[238]; A_arbace_c_check__init_part1_A_const_165 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[239]); A_arbace_c_check__init_part1_A_const_166 = A_arbace_c_check__init_part1_A_const_pool.A[240]; A_arbace_c_check__init_part1_A_const_167 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[241]); A_arbace_c_check__init_part1_A_const_168 = A_arbace_c_check__init_part1_A_const_pool.A[242]; A_arbace_c_check__init_part1_A_const_169 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[243]); A_arbace_c_check__init_part1_A_const_170 = A_arbace_c_check__init_part1_A_const_pool.A[244]; A_arbace_c_check__init_part1_A_const_171 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[245]); A_arbace_c_check__init_part1_A_const_172 = A_arbace_c_check__init_part1_A_const_pool.A[246]; A_arbace_c_check__init_part1_A_const_173 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[247]); A_arbace_c_check__init_part1_A_const_174 = A_arbace_c_check__init_part1_A_const_pool.A[248]; A_arbace_c_check__init_part1_A_const_175 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[249]); A_arbace_c_check__init_part1_A_const_176 = A_arbace_c_check__init_part1_A_const_pool.A[250]; A_arbace_c_check__init_part1_A_const_177 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[251]); A_arbace_c_check__init_part1_A_const_178 = A_arbace_c_check__init_part1_A_const_pool.A[252]; A_arbace_c_check__init_part1_A_const_179 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[253]); A_arbace_c_check__init_part1_A_const_180 = A_arbace_c_check__init_part1_A_const_pool.A[254]; A_arbace_c_check__init_part1_A_const_181 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[255]); A_arbace_c_check__init_part1_A_const_182 = A_arbace_c_check__init_part1_A_const_pool.A[256]; A_arbace_c_check__init_part1_A_const_183 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[257]); A_arbace_c_check__init_part1_A_const_184 = A_arbace_c_check__init_part1_A_const_pool.A[258]; A_arbace_c_check__init_part1_A_const_185 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[259]); A_arbace_c_check__init_part1_A_const_186 = A_arbace_c_check__init_part1_A_const_pool.A[260]; A_arbace_c_check__init_part1_A_const_187 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[261]); A_arbace_c_check__init_part1_A_const_188 = A_arbace_c_check__init_part1_A_const_pool.A[262]; A_arbace_c_check__init_part1_A_const_189 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[263]); var tmp2 *lang.Var; A_arbace_c_check__init_part0_A_Init(); tmp2 = A_arbace_c_check__init_part0_A_const_55; A_arbace_c_check__init_part1_A_const_190 = tmp2; var tmp3 *lang.Var; A_arbace_c_check__init_part0_A_Init(); tmp3 = A_arbace_c_check__init_part0_A_const_46; A_arbace_c_check__init_part1_A_const_191 = tmp3; var tmp4 *lang.Var; A_arbace_c_check__init_part0_A_Init(); tmp4 = A_arbace_c_check__init_part0_A_const_82; A_arbace_c_check__init_part1_A_const_192 = tmp4; var tmp5 *lang.Var; A_arbace_c_check__init_part0_A_Init(); tmp5 = A_arbace_c_check__init_part0_A_const_73; A_arbace_c_check__init_part1_A_const_193 = tmp5; var tmp6 *lang.Var; A_arbace_c_check__init_part0_A_Init(); tmp6 = A_arbace_c_check__init_part0_A_const_64; A_arbace_c_check__init_part1_A_const_194 = tmp6; A_arbace_c_check__init_part1_A_const_195 = A_arbace_c_check__init_part1_A_const_pool.A[264]; A_arbace_c_check__init_part1_A_const_196 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[265]); A_arbace_c_check__init_part1_A_const_197 = A_arbace_c_check__init_part1_A_const_pool.A[266]; A_arbace_c_check__init_part1_A_const_198 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[267]); A_arbace_c_check__init_part1_A_const_199 = A_arbace_c_check__init_part1_A_const_pool.A[268]; A_arbace_c_check__init_part1_A_const_200 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[269]); A_arbace_c_check__init_part1_A_const_201 = A_arbace_c_check__init_part1_A_const_pool.A[270]; A_arbace_c_check__init_part1_A_const_202 = A_arbace_c_check__init_part1_A_const_pool.A[271]; A_arbace_c_check__init_part1_A_const_203 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[272]); A_arbace_c_check__init_part1_A_const_204 = A_arbace_c_check__init_part1_A_const_pool.A[273]; A_arbace_c_check__init_part1_A_const_205 = lang.Var_Cast(A_arbace_c_check__init_part1_A_const_pool.A[274]); A_arbace_c_check__init_part1_A_const_206 = A_arbace_c_check__init_part1_A_const_pool.A[275] }

func A_arbace_c_check__init_part1_A_New() *A_arbace_c_check__init_part1_A { A_arbace_c_check__init_part1_A_Init(); t := &A_arbace_c_check__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_c_check__init_part1_A) Ctor() {}

func (t *A_arbace_c_check__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_check__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_c_check__init_part1_A_class }

func (t *A_arbace_c_check__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_check__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_check__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_check__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_check__init_part1_A); return ok }

func A_arbace_c_check__init_part1_A_Cast(x any) *A_arbace_c_check__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_check__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_check__init_part1_A_class)) }; return v }



type A_arbace_c_check__init_part2_A struct{ jrt.Object }

var A_arbace_c_check__init_part2_A_const_pool *jrt.RefArray

var A_arbace_c_check__init_part2_A_const_0 *lang.Var

var A_arbace_c_check__init_part2_A_const_1 any

var A_arbace_c_check__init_part2_A_const_2 *lang.Var

var A_arbace_c_check__init_part2_A_const_3 any

var A_arbace_c_check__init_part2_A_const_4 any

var A_arbace_c_check__init_part2_A_const_5 *lang.Var

var A_arbace_c_check__init_part2_A_const_6 any

var A_arbace_c_check__init_part2_A_const_7 *lang.Var

var A_arbace_c_check__init_part2_A_const_8 any

var A_arbace_c_check__init_part2_A_const_9 *lang.Var

var A_arbace_c_check__init_part2_A_const_10 any

var A_arbace_c_check__init_part2_A_const_11 *lang.Var

var A_arbace_c_check__init_part2_A_const_12 any

var A_arbace_c_check__init_part2_A_const_13 *lang.Var

var A_arbace_c_check__init_part2_A_const_14 any

var A_arbace_c_check__init_part2_A_const_15 *lang.Var

var A_arbace_c_check__init_part2_A_const_16 any

var A_arbace_c_check__init_part2_A_const_17 *lang.Var

var A_arbace_c_check__init_part2_A_const_18 any

var A_arbace_c_check__init_part2_A_const_19 *lang.Var

var A_arbace_c_check__init_part2_A_const_20 any

var A_arbace_c_check__init_part2_A_const_21 *lang.Var

var A_arbace_c_check__init_part2_A_const_22 any

var A_arbace_c_check__init_part2_A_const_23 *lang.Var

var A_arbace_c_check__init_part2_A_const_24 any

var A_arbace_c_check__init_part2_A_const_25 any

var A_arbace_c_check__init_part2_A_const_26 any

var A_arbace_c_check__init_part2_A_const_27 *lang.Var

var A_arbace_c_check__init_part2_A_const_28 any

var A_arbace_c_check__init_part2_A_const_29 *lang.Var

var A_arbace_c_check__init_part2_A_const_30 any

var A_arbace_c_check__init_part2_A_const_31 *lang.Var

var A_arbace_c_check__init_part2_A_const_32 any

var A_arbace_c_check__init_part2_A_const_33 *lang.Var

var A_arbace_c_check__init_part2_A_const_34 any

var A_arbace_c_check__init_part2_A_const_35 any

var A_arbace_c_check__init_part2_A_const_36 *lang.Var

var A_arbace_c_check__init_part2_A_const_37 any

var A_arbace_c_check__init_part2_A_const_38 *lang.Var

var A_arbace_c_check__init_part2_A_const_39 any

var A_arbace_c_check__init_part2_A_const_40 *lang.Var

var A_arbace_c_check__init_part2_A_const_41 any

var A_arbace_c_check__init_part2_A_const_42 *lang.Var

var A_arbace_c_check__init_part2_A_const_43 any

var A_arbace_c_check__init_part2_A_const_44 *lang.Var

var A_arbace_c_check__init_part2_A_const_45 any

var A_arbace_c_check__init_part2_A_const_46 *lang.Var

var A_arbace_c_check__init_part2_A_const_47 any

var A_arbace_c_check__init_part2_A_const_48 *lang.Var

var A_arbace_c_check__init_part2_A_const_49 any

var A_arbace_c_check__init_part2_A_const_50 *lang.Var

var A_arbace_c_check__init_part2_A_const_51 any

var A_arbace_c_check__init_part2_A_const_52 *lang.Var

var A_arbace_c_check__init_part2_A_const_53 any

var A_arbace_c_check__init_part2_A_const_54 *lang.Var

var A_arbace_c_check__init_part2_A_const_55 any

var A_arbace_c_check__init_part2_A_const_56 *lang.Var

var A_arbace_c_check__init_part2_A_const_57 any

var A_arbace_c_check__init_part2_A_const_58 any

var A_arbace_c_check__init_part2_A_const_59 *lang.Var

var A_arbace_c_check__init_part2_A_const_60 any

var A_arbace_c_check__init_part2_A_const_61 *lang.Var

var A_arbace_c_check__init_part2_A_const_62 any

var A_arbace_c_check__init_part2_A_const_63 *lang.Var

var A_arbace_c_check__init_part2_A_const_64 any

var A_arbace_c_check__init_part2_A_const_65 *lang.Var

var A_arbace_c_check__init_part2_A_const_66 any

var A_arbace_c_check__init_part2_A_const_67 *lang.Var

var A_arbace_c_check__init_part2_A_const_68 any

var A_arbace_c_check__init_part2_A_const_69 *lang.Var

var A_arbace_c_check__init_part2_A_const_70 any

var A_arbace_c_check__init_part2_A_const_71 *lang.Var

var A_arbace_c_check__init_part2_A_const_72 any

var A_arbace_c_check__init_part2_A_const_73 *lang.Var

var A_arbace_c_check__init_part2_A_const_74 any

var A_arbace_c_check__init_part2_A_const_75 *lang.Var

var A_arbace_c_check__init_part2_A_const_76 any

var A_arbace_c_check__init_part2_A_const_77 *lang.Var

var A_arbace_c_check__init_part2_A_const_78 any

var A_arbace_c_check__init_part2_A_const_79 *lang.Var

var A_arbace_c_check__init_part2_A_const_80 any

var A_arbace_c_check__init_part2_A_const_81 *lang.Var

var A_arbace_c_check__init_part2_A_const_82 any

var A_arbace_c_check__init_part2_A_const_83 *lang.Var

var A_arbace_c_check__init_part2_A_const_84 any

var A_arbace_c_check__init_part2_A_const_85 *lang.Var

var A_arbace_c_check__init_part2_A_const_86 any

var A_arbace_c_check__init_part2_A_const_87 *lang.Var

var A_arbace_c_check__init_part2_A_const_88 any

var A_arbace_c_check__init_part2_A_const_89 *lang.Var

var A_arbace_c_check__init_part2_A_const_90 any

var A_arbace_c_check__init_part2_A_const_91 *lang.Var

var A_arbace_c_check__init_part2_A_const_92 any

var A_arbace_c_check__init_part2_A_const_93 *lang.Var

var A_arbace_c_check__init_part2_A_const_94 any

var A_arbace_c_check__init_part2_A_const_95 *lang.Var

var A_arbace_c_check__init_part2_A_const_96 any

var A_arbace_c_check__init_part2_A_const_97 any

var A_arbace_c_check__init_part2_A_const_98 *lang.Var

var A_arbace_c_check__init_part2_A_const_99 any

var A_arbace_c_check__init_part2_A_const_100 *lang.Var

var A_arbace_c_check__init_part2_A_const_101 any

var A_arbace_c_check__init_part2_A_const_102 *lang.Var

var A_arbace_c_check__init_part2_A_const_103 any

var A_arbace_c_check__init_part2_A_const_104 any

var A_arbace_c_check__init_part2_A_const_105 *lang.Var

var A_arbace_c_check__init_part2_A_const_106 any

var A_arbace_c_check__init_part2_A_const_107 *lang.Var

var A_arbace_c_check__init_part2_A_const_108 any

var A_arbace_c_check__init_part2_A_init jrt.ClassInit

func A_arbace_c_check__init_part2_A_Init() { if !A_arbace_c_check__init_part2_A_init.Done() { A_arbace_c_check__init_part2_A_init.Run(A_arbace_c_check__init_part2_A_clinit) } }

func A_arbace_c_check__init_part2_A_clinit() { A_arbace_c_check__init_part2_A_clinit_p0(); A_arbace_c_check__init_part2_A_clinit_p1() }

func A_arbace_c_check__init_part2_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_check__init_part2_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_597, 189) }

func A_arbace_c_check__init_part2_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp1 = A_arbace_c_check__init_part1_A_const_140; A_arbace_c_check__init_part2_A_const_0 = tmp1; A_arbace_c_check__init_part2_A_const_1 = A_arbace_c_check__init_part2_A_const_pool.A[91]; A_arbace_c_check__init_part2_A_const_2 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[92]); A_arbace_c_check__init_part2_A_const_3 = A_arbace_c_check__init_part2_A_const_pool.A[93]; A_arbace_c_check__init_part2_A_const_4 = A_arbace_c_check__init_part2_A_const_pool.A[94]; A_arbace_c_check__init_part2_A_const_5 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[95]); A_arbace_c_check__init_part2_A_const_6 = A_arbace_c_check__init_part2_A_const_pool.A[96]; A_arbace_c_check__init_part2_A_const_7 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[97]); A_arbace_c_check__init_part2_A_const_8 = A_arbace_c_check__init_part2_A_const_pool.A[98]; A_arbace_c_check__init_part2_A_const_9 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[99]); A_arbace_c_check__init_part2_A_const_10 = A_arbace_c_check__init_part2_A_const_pool.A[100]; var tmp2 *lang.Var; A_arbace_c_check__init_part0_A_Init(); tmp2 = A_arbace_c_check__init_part0_A_const_137; A_arbace_c_check__init_part2_A_const_11 = tmp2; A_arbace_c_check__init_part2_A_const_12 = A_arbace_c_check__init_part2_A_const_pool.A[101]; A_arbace_c_check__init_part2_A_const_13 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[102]); A_arbace_c_check__init_part2_A_const_14 = A_arbace_c_check__init_part2_A_const_pool.A[103]; A_arbace_c_check__init_part2_A_const_15 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[104]); A_arbace_c_check__init_part2_A_const_16 = A_arbace_c_check__init_part2_A_const_pool.A[105]; var tmp3 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp3 = A_arbace_c_check__init_part1_A_const_196; A_arbace_c_check__init_part2_A_const_17 = tmp3; A_arbace_c_check__init_part2_A_const_18 = A_arbace_c_check__init_part2_A_const_pool.A[106]; var tmp4 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp4 = A_arbace_c_check__init_part1_A_const_138; A_arbace_c_check__init_part2_A_const_19 = tmp4; A_arbace_c_check__init_part2_A_const_20 = A_arbace_c_check__init_part2_A_const_pool.A[107]; A_arbace_c_check__init_part2_A_const_21 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[108]); A_arbace_c_check__init_part2_A_const_22 = A_arbace_c_check__init_part2_A_const_pool.A[109]; var tmp5 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp5 = A_arbace_c_check__init_part1_A_const_167; A_arbace_c_check__init_part2_A_const_23 = tmp5; A_arbace_c_check__init_part2_A_const_24 = A_arbace_c_check__init_part2_A_const_pool.A[110]; A_arbace_c_check__init_part2_A_const_25 = A_arbace_c_check__init_part2_A_const_pool.A[111]; A_arbace_c_check__init_part2_A_const_26 = A_arbace_c_check__init_part2_A_const_pool.A[112]; A_arbace_c_check__init_part2_A_const_27 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[113]); A_arbace_c_check__init_part2_A_const_28 = A_arbace_c_check__init_part2_A_const_pool.A[114]; A_arbace_c_check__init_part2_A_const_29 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[115]); A_arbace_c_check__init_part2_A_const_30 = A_arbace_c_check__init_part2_A_const_pool.A[116]; A_arbace_c_check__init_part2_A_const_31 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[117]); A_arbace_c_check__init_part2_A_const_32 = A_arbace_c_check__init_part2_A_const_pool.A[118]; var tmp6 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp6 = A_arbace_c_check__init_part1_A_const_0; A_arbace_c_check__init_part2_A_const_33 = tmp6; A_arbace_c_check__init_part2_A_const_34 = A_arbace_c_check__init_part2_A_const_pool.A[119]; A_arbace_c_check__init_part2_A_const_35 = A_arbace_c_check__init_part2_A_const_pool.A[120]; var tmp7 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp7 = A_arbace_c_check__init_part1_A_const_144; A_arbace_c_check__init_part2_A_const_36 = tmp7; A_arbace_c_check__init_part2_A_const_37 = A_arbace_c_check__init_part2_A_const_pool.A[121]; var tmp8 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp8 = A_arbace_c_check__init_part1_A_const_2; A_arbace_c_check__init_part2_A_const_38 = tmp8; A_arbace_c_check__init_part2_A_const_39 = A_arbace_c_check__init_part2_A_const_pool.A[122]; A_arbace_c_check__init_part2_A_const_40 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[123]); A_arbace_c_check__init_part2_A_const_41 = A_arbace_c_check__init_part2_A_const_pool.A[124]; A_arbace_c_check__init_part2_A_const_42 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[125]); A_arbace_c_check__init_part2_A_const_43 = A_arbace_c_check__init_part2_A_const_pool.A[126]; A_arbace_c_check__init_part2_A_const_44 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[127]); A_arbace_c_check__init_part2_A_const_45 = A_arbace_c_check__init_part2_A_const_pool.A[128]; A_arbace_c_check__init_part2_A_const_46 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[129]); A_arbace_c_check__init_part2_A_const_47 = A_arbace_c_check__init_part2_A_const_pool.A[130]; A_arbace_c_check__init_part2_A_const_48 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[131]); A_arbace_c_check__init_part2_A_const_49 = A_arbace_c_check__init_part2_A_const_pool.A[132]; A_arbace_c_check__init_part2_A_const_50 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[133]); A_arbace_c_check__init_part2_A_const_51 = A_arbace_c_check__init_part2_A_const_pool.A[134]; A_arbace_c_check__init_part2_A_const_52 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[135]); A_arbace_c_check__init_part2_A_const_53 = A_arbace_c_check__init_part2_A_const_pool.A[136]; A_arbace_c_check__init_part2_A_const_54 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[137]); A_arbace_c_check__init_part2_A_const_55 = A_arbace_c_check__init_part2_A_const_pool.A[138]; A_arbace_c_check__init_part2_A_const_56 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[139]); A_arbace_c_check__init_part2_A_const_57 = A_arbace_c_check__init_part2_A_const_pool.A[140]; A_arbace_c_check__init_part2_A_const_58 = A_arbace_c_check__init_part2_A_const_pool.A[141]; A_arbace_c_check__init_part2_A_const_59 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[142]); A_arbace_c_check__init_part2_A_const_60 = A_arbace_c_check__init_part2_A_const_pool.A[143]; A_arbace_c_check__init_part2_A_const_61 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[144]); A_arbace_c_check__init_part2_A_const_62 = A_arbace_c_check__init_part2_A_const_pool.A[145]; A_arbace_c_check__init_part2_A_const_63 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[146]); A_arbace_c_check__init_part2_A_const_64 = A_arbace_c_check__init_part2_A_const_pool.A[147]; var tmp9 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp9 = A_arbace_c_check__init_part1_A_const_198; A_arbace_c_check__init_part2_A_const_65 = tmp9; A_arbace_c_check__init_part2_A_const_66 = A_arbace_c_check__init_part2_A_const_pool.A[148]; A_arbace_c_check__init_part2_A_const_67 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[149]); A_arbace_c_check__init_part2_A_const_68 = A_arbace_c_check__init_part2_A_const_pool.A[150]; A_arbace_c_check__init_part2_A_const_69 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[151]); A_arbace_c_check__init_part2_A_const_70 = A_arbace_c_check__init_part2_A_const_pool.A[152]; A_arbace_c_check__init_part2_A_const_71 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[153]); A_arbace_c_check__init_part2_A_const_72 = A_arbace_c_check__init_part2_A_const_pool.A[154]; A_arbace_c_check__init_part2_A_const_73 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[155]); A_arbace_c_check__init_part2_A_const_74 = A_arbace_c_check__init_part2_A_const_pool.A[156]; A_arbace_c_check__init_part2_A_const_75 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[157]); A_arbace_c_check__init_part2_A_const_76 = A_arbace_c_check__init_part2_A_const_pool.A[158]; A_arbace_c_check__init_part2_A_const_77 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[159]); A_arbace_c_check__init_part2_A_const_78 = A_arbace_c_check__init_part2_A_const_pool.A[160]; A_arbace_c_check__init_part2_A_const_79 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[161]); A_arbace_c_check__init_part2_A_const_80 = A_arbace_c_check__init_part2_A_const_pool.A[162]; A_arbace_c_check__init_part2_A_const_81 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[163]); A_arbace_c_check__init_part2_A_const_82 = A_arbace_c_check__init_part2_A_const_pool.A[164]; A_arbace_c_check__init_part2_A_const_83 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[165]); A_arbace_c_check__init_part2_A_const_84 = A_arbace_c_check__init_part2_A_const_pool.A[166]; A_arbace_c_check__init_part2_A_const_85 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[167]); A_arbace_c_check__init_part2_A_const_86 = A_arbace_c_check__init_part2_A_const_pool.A[168]; A_arbace_c_check__init_part2_A_const_87 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[169]); A_arbace_c_check__init_part2_A_const_88 = A_arbace_c_check__init_part2_A_const_pool.A[170]; var tmp10 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp10 = A_arbace_c_check__init_part1_A_const_200; A_arbace_c_check__init_part2_A_const_89 = tmp10; A_arbace_c_check__init_part2_A_const_90 = A_arbace_c_check__init_part2_A_const_pool.A[171]; A_arbace_c_check__init_part2_A_const_91 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[172]); A_arbace_c_check__init_part2_A_const_92 = A_arbace_c_check__init_part2_A_const_pool.A[173]; var tmp11 *lang.Var; A_arbace_c_check__init_part1_A_Init(); tmp11 = A_arbace_c_check__init_part1_A_const_142; A_arbace_c_check__init_part2_A_const_93 = tmp11; A_arbace_c_check__init_part2_A_const_94 = A_arbace_c_check__init_part2_A_const_pool.A[174]; A_arbace_c_check__init_part2_A_const_95 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[175]); A_arbace_c_check__init_part2_A_const_96 = A_arbace_c_check__init_part2_A_const_pool.A[176]; A_arbace_c_check__init_part2_A_const_97 = A_arbace_c_check__init_part2_A_const_pool.A[177]; A_arbace_c_check__init_part2_A_const_98 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[178]); A_arbace_c_check__init_part2_A_const_99 = A_arbace_c_check__init_part2_A_const_pool.A[179]; A_arbace_c_check__init_part2_A_const_100 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[180]); A_arbace_c_check__init_part2_A_const_101 = A_arbace_c_check__init_part2_A_const_pool.A[181]; A_arbace_c_check__init_part2_A_const_102 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[182]); A_arbace_c_check__init_part2_A_const_103 = A_arbace_c_check__init_part2_A_const_pool.A[183]; A_arbace_c_check__init_part2_A_const_104 = A_arbace_c_check__init_part2_A_const_pool.A[184]; A_arbace_c_check__init_part2_A_const_105 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[185]); A_arbace_c_check__init_part2_A_const_106 = A_arbace_c_check__init_part2_A_const_pool.A[186]; A_arbace_c_check__init_part2_A_const_107 = lang.Var_Cast(A_arbace_c_check__init_part2_A_const_pool.A[187]); A_arbace_c_check__init_part2_A_const_108 = A_arbace_c_check__init_part2_A_const_pool.A[188] }

func A_arbace_c_check__init_part2_A_New() *A_arbace_c_check__init_part2_A { A_arbace_c_check__init_part2_A_Init(); t := &A_arbace_c_check__init_part2_A{}; t.Ctor(); return t }

func (t *A_arbace_c_check__init_part2_A) Ctor() {}

func (t *A_arbace_c_check__init_part2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_check__init_part2_A) GetClass__Class() *jrt.Class { return A_arbace_c_check__init_part2_A_class }

func (t *A_arbace_c_check__init_part2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_check__init_part2_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_check__init_part2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_check__init_part2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_check__init_part2_A); return ok }

func A_arbace_c_check__init_part2_A_Cast(x any) *A_arbace_c_check__init_part2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_check__init_part2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_check__init_part2_A_class)) }; return v }
