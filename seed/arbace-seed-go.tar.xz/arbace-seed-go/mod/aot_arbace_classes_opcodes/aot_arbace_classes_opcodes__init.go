//line aot_arbace_classes_opcodes__init.ae:1
package aot_arbace_classes_opcodes

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_opcodes__init_A_Unit0__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_classes_opcodes__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_classes_opcodes__init_A_const_1) }
//line :1:1
func A_arbace_classes_opcodes__init_A_Unit1__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_classes_opcodes__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_2)) }
//line :1:1
func A_arbace_classes_opcodes__init_A_Unit2__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_New(); var tmp2 *jrt.Class; A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_Init(); tmp2 = A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_opcodes__init_A_Unit3__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_opcodes__init_A_const_1)).Equals_O__Z(A_arbace_classes_opcodes__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_opcodes_eval228000008_fn__228000009_A_New(); var tmp2 *jrt.Class; A_arbace_classes_opcodes_eval228000008_fn__228000009_A_Init(); tmp2 = A_arbace_classes_opcodes_eval228000008_fn__228000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_opcodes__init_A_Load__O() any { A_arbace_classes_opcodes__init_A_Init(); A_arbace_classes_opcodes__init_A_Unit0__O(); A_arbace_classes_opcodes__init_A_Unit1__O(); A_arbace_classes_opcodes__init_A_Unit2__O(); A_arbace_classes_opcodes__init_A_Unit3__O(); A_arbace_classes_opcodes__init_A_Unit4__O(); A_arbace_classes_opcodes__init_A_Unit5__O(); A_arbace_classes_opcodes__init_A_Unit6__O(); A_arbace_classes_opcodes__init_A_Unit7__O(); A_arbace_classes_opcodes__init_A_Unit8__O(); A_arbace_classes_opcodes__init_A_Unit9__O(); A_arbace_classes_opcodes__init_A_Unit10__O(); A_arbace_classes_opcodes__init_A_Unit11__O(); A_arbace_classes_opcodes__init_A_Unit12__O(); A_arbace_classes_opcodes__init_A_Unit13__O(); A_arbace_classes_opcodes__init_A_Unit14__O(); A_arbace_classes_opcodes__init_A_Unit15__O(); A_arbace_classes_opcodes__init_A_Unit16__O(); A_arbace_classes_opcodes__init_A_Unit17__O(); A_arbace_classes_opcodes__init_A_Unit18__O(); A_arbace_classes_opcodes__init_A_Unit19__O(); A_arbace_classes_opcodes__init_A_Unit20__O(); A_arbace_classes_opcodes__init_A_Unit21__O(); A_arbace_classes_opcodes__init_A_Unit22__O(); A_arbace_classes_opcodes__init_A_Unit23__O(); A_arbace_classes_opcodes__init_A_Unit24__O(); A_arbace_classes_opcodes__init_A_Unit25__O(); A_arbace_classes_opcodes__init_A_Unit26__O(); A_arbace_classes_opcodes__init_A_Unit27__O(); A_arbace_classes_opcodes__init_A_Unit28__O(); return nil }



func A_arbace_classes_opcodes__init_A_Unit4__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_4; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(1)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_5)); return A_arbace_classes_opcodes__init_A_const_4.Ref() }
func A_arbace_classes_opcodes__init_A_Unit5__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(10, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_6; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(2)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_6; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_7)); return A_arbace_classes_opcodes__init_A_const_6.Ref() }
func A_arbace_classes_opcodes__init_A_Unit6__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_8; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(4)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_8; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_9)); return A_arbace_classes_opcodes__init_A_const_8.Ref() }
func A_arbace_classes_opcodes__init_A_Unit7__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_10; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(8)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_10; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_11)); return A_arbace_classes_opcodes__init_A_const_10.Ref() }
func A_arbace_classes_opcodes__init_A_Unit8__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_12; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(16)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_12; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_13)); return A_arbace_classes_opcodes__init_A_const_12.Ref() }
func A_arbace_classes_opcodes__init_A_Unit9__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_14; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_14; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_15)); return A_arbace_classes_opcodes__init_A_const_14.Ref() }
func A_arbace_classes_opcodes__init_A_Unit10__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_16; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_16; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_17)); return A_arbace_classes_opcodes__init_A_const_16.Ref() }
func A_arbace_classes_opcodes__init_A_Unit11__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(16, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_18; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_18; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_19)); return A_arbace_classes_opcodes__init_A_const_18.Ref() }
func A_arbace_classes_opcodes__init_A_Unit12__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_20; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_20; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_21)); return A_arbace_classes_opcodes__init_A_const_20.Ref() }
func A_arbace_classes_opcodes__init_A_Unit13__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_22; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(64)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_22; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_23)); return A_arbace_classes_opcodes__init_A_const_22.Ref() }
func A_arbace_classes_opcodes__init_A_Unit14__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_24; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(64)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_24; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_25)); return A_arbace_classes_opcodes__init_A_const_24.Ref() }
func A_arbace_classes_opcodes__init_A_Unit15__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_26; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(64)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_26; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_27)); return A_arbace_classes_opcodes__init_A_const_26.Ref() }
func A_arbace_classes_opcodes__init_A_Unit16__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_28; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(128)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_28; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_29)); return A_arbace_classes_opcodes__init_A_const_28.Ref() }
func A_arbace_classes_opcodes__init_A_Unit17__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_30; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(128)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_30; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_31)); return A_arbace_classes_opcodes__init_A_const_30.Ref() }
func A_arbace_classes_opcodes__init_A_Unit18__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_32; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(256)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_32; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_33)); return A_arbace_classes_opcodes__init_A_const_32.Ref() }
func A_arbace_classes_opcodes__init_A_Unit19__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_34; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(512)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_34; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_35)); return A_arbace_classes_opcodes__init_A_const_34.Ref() }
func A_arbace_classes_opcodes__init_A_Unit20__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_36; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(1024)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_36; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_37)); return A_arbace_classes_opcodes__init_A_const_36.Ref() }
func A_arbace_classes_opcodes__init_A_Unit21__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_38; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(2048)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_38; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_39)); return A_arbace_classes_opcodes__init_A_const_38.Ref() }
func A_arbace_classes_opcodes__init_A_Unit22__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_40; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(4096)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_40; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_41)); return A_arbace_classes_opcodes__init_A_const_40.Ref() }
func A_arbace_classes_opcodes__init_A_Unit23__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_42; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(8192)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_42; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_43)); return A_arbace_classes_opcodes__init_A_const_42.Ref() }
func A_arbace_classes_opcodes__init_A_Unit24__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_44; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(16384)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_44; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_45)); return A_arbace_classes_opcodes__init_A_const_44.Ref() }
func A_arbace_classes_opcodes__init_A_Unit25__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_46; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32768)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_46; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_47)); return A_arbace_classes_opcodes__init_A_const_46.Ref() }
func A_arbace_classes_opcodes__init_A_Unit26__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(31, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_48; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32768)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_48; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_49)); return A_arbace_classes_opcodes__init_A_const_48.Ref() }
func A_arbace_classes_opcodes__init_A_Unit27__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_50; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(65536)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_50; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_51)); return A_arbace_classes_opcodes__init_A_const_50.Ref() }
func A_arbace_classes_opcodes__init_A_Unit28__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_52; jrt.NN(tmp1).BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(131072)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_52; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_53)); return A_arbace_classes_opcodes__init_A_const_52.Ref() }


































type A_arbace_classes_opcodes__init_A struct{ jrt.Object }

var A_arbace_classes_opcodes__init_A_const_0 *lang.Var

var A_arbace_classes_opcodes__init_A_const_1 any

var A_arbace_classes_opcodes__init_A_const_2 any

var A_arbace_classes_opcodes__init_A_const_3 any

var A_arbace_classes_opcodes__init_A_const_4 *lang.Var

var A_arbace_classes_opcodes__init_A_const_5 any

var A_arbace_classes_opcodes__init_A_const_6 *lang.Var

var A_arbace_classes_opcodes__init_A_const_7 any

var A_arbace_classes_opcodes__init_A_const_8 *lang.Var

var A_arbace_classes_opcodes__init_A_const_9 any

var A_arbace_classes_opcodes__init_A_const_10 *lang.Var

var A_arbace_classes_opcodes__init_A_const_11 any

var A_arbace_classes_opcodes__init_A_const_12 *lang.Var

var A_arbace_classes_opcodes__init_A_const_13 any

var A_arbace_classes_opcodes__init_A_const_14 *lang.Var

var A_arbace_classes_opcodes__init_A_const_15 any

var A_arbace_classes_opcodes__init_A_const_16 *lang.Var

var A_arbace_classes_opcodes__init_A_const_17 any

var A_arbace_classes_opcodes__init_A_const_18 *lang.Var

var A_arbace_classes_opcodes__init_A_const_19 any

var A_arbace_classes_opcodes__init_A_const_20 *lang.Var

var A_arbace_classes_opcodes__init_A_const_21 any

var A_arbace_classes_opcodes__init_A_const_22 *lang.Var

var A_arbace_classes_opcodes__init_A_const_23 any

var A_arbace_classes_opcodes__init_A_const_24 *lang.Var

var A_arbace_classes_opcodes__init_A_const_25 any

var A_arbace_classes_opcodes__init_A_const_26 *lang.Var

var A_arbace_classes_opcodes__init_A_const_27 any

var A_arbace_classes_opcodes__init_A_const_28 *lang.Var

var A_arbace_classes_opcodes__init_A_const_29 any

var A_arbace_classes_opcodes__init_A_const_30 *lang.Var

var A_arbace_classes_opcodes__init_A_const_31 any

var A_arbace_classes_opcodes__init_A_const_32 *lang.Var

var A_arbace_classes_opcodes__init_A_const_33 any

var A_arbace_classes_opcodes__init_A_const_34 *lang.Var

var A_arbace_classes_opcodes__init_A_const_35 any

var A_arbace_classes_opcodes__init_A_const_36 *lang.Var

var A_arbace_classes_opcodes__init_A_const_37 any

var A_arbace_classes_opcodes__init_A_const_38 *lang.Var

var A_arbace_classes_opcodes__init_A_const_39 any

var A_arbace_classes_opcodes__init_A_const_40 *lang.Var

var A_arbace_classes_opcodes__init_A_const_41 any

var A_arbace_classes_opcodes__init_A_const_42 *lang.Var

var A_arbace_classes_opcodes__init_A_const_43 any

var A_arbace_classes_opcodes__init_A_const_44 *lang.Var

var A_arbace_classes_opcodes__init_A_const_45 any

var A_arbace_classes_opcodes__init_A_const_46 *lang.Var

var A_arbace_classes_opcodes__init_A_const_47 any

var A_arbace_classes_opcodes__init_A_const_48 *lang.Var

var A_arbace_classes_opcodes__init_A_const_49 any

var A_arbace_classes_opcodes__init_A_const_50 *lang.Var

var A_arbace_classes_opcodes__init_A_const_51 any

var A_arbace_classes_opcodes__init_A_const_52 *lang.Var

var A_arbace_classes_opcodes__init_A_const_53 any

var A_arbace_classes_opcodes__init_A_init jrt.ClassInit

func A_arbace_classes_opcodes__init_A_Init() { if !A_arbace_classes_opcodes__init_A_init.Done() { A_arbace_classes_opcodes__init_A_init.Run(A_arbace_classes_opcodes__init_A_clinit) } }

func A_arbace_classes_opcodes__init_A_clinit() { A_arbace_classes_opcodes__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_classes_opcodes__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_classes_opcodes__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7)); A_arbace_classes_opcodes__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_opcodes__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_5, Lit_12); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_classes_opcodes__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(9).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_5, Lit_18); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_classes_opcodes__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_5, Lit_19); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_classes_opcodes__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(11).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_5, Lit_20); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_classes_opcodes__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_5, Lit_21); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_classes_opcodes__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_5, Lit_22); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_classes_opcodes__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_5, Lit_23); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_classes_opcodes__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_classes_opcodes__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_5, Lit_25); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_classes_opcodes__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_5, Lit_26); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_classes_opcodes__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_5, Lit_27); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_classes_opcodes__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_5, Lit_28); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_classes_opcodes__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_5, Lit_29); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_classes_opcodes__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_5, Lit_30); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_classes_opcodes__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_5, Lit_31); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_classes_opcodes__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_classes_opcodes__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_classes_opcodes__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_5, Lit_34); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_classes_opcodes__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_5, Lit_35); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_classes_opcodes__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_5, Lit_36); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_classes_opcodes__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_5, Lit_37); var tmp61 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp62 *jrt.Boolean; jrt.Boolean_Init(); tmp62 = jrt.Boolean_TRUE; var tmp63 any = tmp62.Ref(); A_arbace_classes_opcodes__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp61, tmp63, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_5, Lit_38); var tmp64 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp65 *jrt.Boolean; jrt.Boolean_Init(); tmp65 = jrt.Boolean_TRUE; var tmp66 any = tmp65.Ref(); A_arbace_classes_opcodes__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp64, tmp66, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_5, Lit_39); var tmp67 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_TRUE; var tmp69 any = tmp68.Ref(); A_arbace_classes_opcodes__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp67, tmp69, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(31).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_5, Lit_40); var tmp70 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp71 *jrt.Boolean; jrt.Boolean_Init(); tmp71 = jrt.Boolean_TRUE; var tmp72 any = tmp71.Ref(); A_arbace_classes_opcodes__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp70, tmp72, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)); A_arbace_classes_opcodes__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_5, Lit_41); var tmp73 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(); var tmp74 *jrt.Boolean; jrt.Boolean_Init(); tmp74 = jrt.Boolean_TRUE; var tmp75 any = tmp74.Ref(); A_arbace_classes_opcodes__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp73, tmp75, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17)) }

func A_arbace_classes_opcodes__init_A_New() *A_arbace_classes_opcodes__init_A { A_arbace_classes_opcodes__init_A_Init(); t := &A_arbace_classes_opcodes__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes__init_A) Ctor() {}

func (t *A_arbace_classes_opcodes__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes__init_A_class }

func (t *A_arbace_classes_opcodes__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes__init_A); return ok }

func A_arbace_classes_opcodes__init_A_Cast(x any) *A_arbace_classes_opcodes__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes__init_A_class)) }; return v }
