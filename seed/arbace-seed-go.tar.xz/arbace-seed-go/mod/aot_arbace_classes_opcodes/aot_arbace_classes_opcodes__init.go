//line aot_arbace_classes_opcodes__init.ae:1
package aot_arbace_classes_opcodes

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_opcodes__init_A_Unit0__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_classes_opcodes__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_opcodes__init_A_const_1) }
//line :1:1
func A_arbace_classes_opcodes__init_A_Unit1__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_classes_opcodes__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_2)) }
//line :1:1
func A_arbace_classes_opcodes__init_A_Unit2__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_opcodes__init_A_Unit3__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_opcodes__init_A_const_1)).Equals_O__Z(A_arbace_classes_opcodes__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_opcodes_eval228000008_fn__228000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_opcodes_eval228000008_fn__228000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_classes_opcodes_eval228000008_fn__228000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_opcodes__init_A_Load__O() any { A_arbace_classes_opcodes__init_A_Init(); A_arbace_classes_opcodes__init_A_Unit0__O(); A_arbace_classes_opcodes__init_A_Unit1__O(); A_arbace_classes_opcodes__init_A_Unit2__O(); A_arbace_classes_opcodes__init_A_Unit3__O(); A_arbace_classes_opcodes__init_A_Unit4__O(); A_arbace_classes_opcodes__init_A_Unit5__O(); A_arbace_classes_opcodes__init_A_Unit6__O(); A_arbace_classes_opcodes__init_A_Unit7__O(); A_arbace_classes_opcodes__init_A_Unit8__O(); A_arbace_classes_opcodes__init_A_Unit9__O(); A_arbace_classes_opcodes__init_A_Unit10__O(); A_arbace_classes_opcodes__init_A_Unit11__O(); A_arbace_classes_opcodes__init_A_Unit12__O(); A_arbace_classes_opcodes__init_A_Unit13__O(); A_arbace_classes_opcodes__init_A_Unit14__O(); A_arbace_classes_opcodes__init_A_Unit15__O(); A_arbace_classes_opcodes__init_A_Unit16__O(); A_arbace_classes_opcodes__init_A_Unit17__O(); A_arbace_classes_opcodes__init_A_Unit18__O(); A_arbace_classes_opcodes__init_A_Unit19__O(); A_arbace_classes_opcodes__init_A_Unit20__O(); A_arbace_classes_opcodes__init_A_Unit21__O(); A_arbace_classes_opcodes__init_A_Unit22__O(); A_arbace_classes_opcodes__init_A_Unit23__O(); A_arbace_classes_opcodes__init_A_Unit24__O(); A_arbace_classes_opcodes__init_A_Unit25__O(); A_arbace_classes_opcodes__init_A_Unit26__O(); A_arbace_classes_opcodes__init_A_Unit27__O(); A_arbace_classes_opcodes__init_A_Unit28__O(); return nil }



func A_arbace_classes_opcodes__init_A_Unit4__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_4; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(1)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_5)); return A_arbace_classes_opcodes__init_A_const_4 }
func A_arbace_classes_opcodes__init_A_Unit5__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(10, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_6; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(2)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_6; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_7)); return A_arbace_classes_opcodes__init_A_const_6 }
func A_arbace_classes_opcodes__init_A_Unit6__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_8; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(4)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_8; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_9)); return A_arbace_classes_opcodes__init_A_const_8 }
func A_arbace_classes_opcodes__init_A_Unit7__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_10; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(8)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_10; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_11)); return A_arbace_classes_opcodes__init_A_const_10 }
func A_arbace_classes_opcodes__init_A_Unit8__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_12; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(16)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_13)); return A_arbace_classes_opcodes__init_A_const_12 }
func A_arbace_classes_opcodes__init_A_Unit9__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_14; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_14; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_15)); return A_arbace_classes_opcodes__init_A_const_14 }
func A_arbace_classes_opcodes__init_A_Unit10__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_16; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_16; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_17)); return A_arbace_classes_opcodes__init_A_const_16 }
func A_arbace_classes_opcodes__init_A_Unit11__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(16, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_18; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_18; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_19)); return A_arbace_classes_opcodes__init_A_const_18 }
func A_arbace_classes_opcodes__init_A_Unit12__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_20; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_20; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_21)); return A_arbace_classes_opcodes__init_A_const_20 }
func A_arbace_classes_opcodes__init_A_Unit13__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_22; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(64)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_22; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_23)); return A_arbace_classes_opcodes__init_A_const_22 }
func A_arbace_classes_opcodes__init_A_Unit14__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_24; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(64)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_24; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_25)); return A_arbace_classes_opcodes__init_A_const_24 }
func A_arbace_classes_opcodes__init_A_Unit15__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_26; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(64)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_26; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_27)); return A_arbace_classes_opcodes__init_A_const_26 }
func A_arbace_classes_opcodes__init_A_Unit16__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_28; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(128)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_28; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_29)); return A_arbace_classes_opcodes__init_A_const_28 }
func A_arbace_classes_opcodes__init_A_Unit17__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_30; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(128)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_30; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_31)); return A_arbace_classes_opcodes__init_A_const_30 }
func A_arbace_classes_opcodes__init_A_Unit18__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_32; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(256)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_32; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_33)); return A_arbace_classes_opcodes__init_A_const_32 }
func A_arbace_classes_opcodes__init_A_Unit19__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_34; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(512)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_34; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_35)); return A_arbace_classes_opcodes__init_A_const_34 }
func A_arbace_classes_opcodes__init_A_Unit20__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_36; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(1024)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_36; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_37)); return A_arbace_classes_opcodes__init_A_const_36 }
func A_arbace_classes_opcodes__init_A_Unit21__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_38; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(2048)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_38; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_39)); return A_arbace_classes_opcodes__init_A_const_38 }
func A_arbace_classes_opcodes__init_A_Unit22__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_40; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(4096)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_40; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_41)); return A_arbace_classes_opcodes__init_A_const_40 }
func A_arbace_classes_opcodes__init_A_Unit23__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_42; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(8192)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_42; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_43)); return A_arbace_classes_opcodes__init_A_const_42 }
func A_arbace_classes_opcodes__init_A_Unit24__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_44; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(16384)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_44; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_45)); return A_arbace_classes_opcodes__init_A_const_44 }
func A_arbace_classes_opcodes__init_A_Unit25__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_46; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32768)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_46; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_47)); return A_arbace_classes_opcodes__init_A_const_46 }
func A_arbace_classes_opcodes__init_A_Unit26__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(31, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_48; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(32768)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_48; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_49)); return A_arbace_classes_opcodes__init_A_const_48 }
func A_arbace_classes_opcodes__init_A_Unit27__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_50; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(65536)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_50; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_51)); return A_arbace_classes_opcodes__init_A_const_50 }
func A_arbace_classes_opcodes__init_A_Unit28__O() any { A_arbace_classes_opcodes__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_classes_opcodes__init_A_const_52; tmp1.BindRoot_O__V(jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(131072)).Ref()); var tmp2 *lang.Var = A_arbace_classes_opcodes__init_A_const_52; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_opcodes__init_A_const_53)); return A_arbace_classes_opcodes__init_A_const_52 }


































type A_arbace_classes_opcodes__init_A struct{ jrt.Object }

var A_arbace_classes_opcodes__init_A_const_pool *jrt.RefArray

var A_arbace_classes_opcodes__init_A_const_0 *lang.Var

var A_arbace_classes_opcodes__init_A_const_1 any

var A_arbace_classes_opcodes__init_A_const_2 any

var A_arbace_classes_opcodes__init_A_const_3 any

var A_arbace_classes_opcodes__init_A_const_4 *lang.Var

var A_arbace_classes_opcodes__init_A_const_5 any

var A_arbace_classes_opcodes__init_A_const_6 *lang.Var

var A_arbace_classes_opcodes__init_A_const_7 any

var A_arbace_classes_opcodes__init_A_const_8 *lang.Var

var A_arbace_classes_opcodes__init_A_const_9 any

var A_arbace_classes_opcodes__init_A_const_10 *lang.Var

var A_arbace_classes_opcodes__init_A_const_11 any

var A_arbace_classes_opcodes__init_A_const_12 *lang.Var

var A_arbace_classes_opcodes__init_A_const_13 any

var A_arbace_classes_opcodes__init_A_const_14 *lang.Var

var A_arbace_classes_opcodes__init_A_const_15 any

var A_arbace_classes_opcodes__init_A_const_16 *lang.Var

var A_arbace_classes_opcodes__init_A_const_17 any

var A_arbace_classes_opcodes__init_A_const_18 *lang.Var

var A_arbace_classes_opcodes__init_A_const_19 any

var A_arbace_classes_opcodes__init_A_const_20 *lang.Var

var A_arbace_classes_opcodes__init_A_const_21 any

var A_arbace_classes_opcodes__init_A_const_22 *lang.Var

var A_arbace_classes_opcodes__init_A_const_23 any

var A_arbace_classes_opcodes__init_A_const_24 *lang.Var

var A_arbace_classes_opcodes__init_A_const_25 any

var A_arbace_classes_opcodes__init_A_const_26 *lang.Var

var A_arbace_classes_opcodes__init_A_const_27 any

var A_arbace_classes_opcodes__init_A_const_28 *lang.Var

var A_arbace_classes_opcodes__init_A_const_29 any

var A_arbace_classes_opcodes__init_A_const_30 *lang.Var

var A_arbace_classes_opcodes__init_A_const_31 any

var A_arbace_classes_opcodes__init_A_const_32 *lang.Var

var A_arbace_classes_opcodes__init_A_const_33 any

var A_arbace_classes_opcodes__init_A_const_34 *lang.Var

var A_arbace_classes_opcodes__init_A_const_35 any

var A_arbace_classes_opcodes__init_A_const_36 *lang.Var

var A_arbace_classes_opcodes__init_A_const_37 any

var A_arbace_classes_opcodes__init_A_const_38 *lang.Var

var A_arbace_classes_opcodes__init_A_const_39 any

var A_arbace_classes_opcodes__init_A_const_40 *lang.Var

var A_arbace_classes_opcodes__init_A_const_41 any

var A_arbace_classes_opcodes__init_A_const_42 *lang.Var

var A_arbace_classes_opcodes__init_A_const_43 any

var A_arbace_classes_opcodes__init_A_const_44 *lang.Var

var A_arbace_classes_opcodes__init_A_const_45 any

var A_arbace_classes_opcodes__init_A_const_46 *lang.Var

var A_arbace_classes_opcodes__init_A_const_47 any

var A_arbace_classes_opcodes__init_A_const_48 *lang.Var

var A_arbace_classes_opcodes__init_A_const_49 any

var A_arbace_classes_opcodes__init_A_const_50 *lang.Var

var A_arbace_classes_opcodes__init_A_const_51 any

var A_arbace_classes_opcodes__init_A_const_52 *lang.Var

var A_arbace_classes_opcodes__init_A_const_53 any

var A_arbace_classes_opcodes__init_A_init jrt.ClassInit

func A_arbace_classes_opcodes__init_A_Init() { if !A_arbace_classes_opcodes__init_A_init.Done() { A_arbace_classes_opcodes__init_A_init.Run(A_arbace_classes_opcodes__init_A_clinit) } }

func A_arbace_classes_opcodes__init_A_clinit() { A_arbace_classes_opcodes__init_A_clinit_p0(); A_arbace_classes_opcodes__init_A_clinit_p1(); A_arbace_classes_opcodes__init_A_clinit_p2(); A_arbace_classes_opcodes__init_A_clinit_p3(); A_arbace_classes_opcodes__init_A_clinit_p4() }

func A_arbace_classes_opcodes__init_A_clinit_p0() { A_arbace_classes_opcodes__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_1, 60); A_arbace_classes_opcodes__init_A_const_0 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[6]); A_arbace_classes_opcodes__init_A_const_1 = A_arbace_classes_opcodes__init_A_const_pool.A[7]; A_arbace_classes_opcodes__init_A_const_2 = A_arbace_classes_opcodes__init_A_const_pool.A[8]; A_arbace_classes_opcodes__init_A_const_3 = A_arbace_classes_opcodes__init_A_const_pool.A[9]; A_arbace_classes_opcodes__init_A_const_4 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[10]); A_arbace_classes_opcodes__init_A_const_5 = A_arbace_classes_opcodes__init_A_const_pool.A[11]; A_arbace_classes_opcodes__init_A_const_6 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[12]); A_arbace_classes_opcodes__init_A_const_7 = A_arbace_classes_opcodes__init_A_const_pool.A[13]; A_arbace_classes_opcodes__init_A_const_8 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[14]); A_arbace_classes_opcodes__init_A_const_9 = A_arbace_classes_opcodes__init_A_const_pool.A[15]; A_arbace_classes_opcodes__init_A_const_10 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[16]); A_arbace_classes_opcodes__init_A_const_11 = A_arbace_classes_opcodes__init_A_const_pool.A[17]; A_arbace_classes_opcodes__init_A_const_12 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[18]) }

func A_arbace_classes_opcodes__init_A_clinit_p1() { A_arbace_classes_opcodes__init_A_const_13 = A_arbace_classes_opcodes__init_A_const_pool.A[19]; A_arbace_classes_opcodes__init_A_const_14 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[20]); A_arbace_classes_opcodes__init_A_const_15 = A_arbace_classes_opcodes__init_A_const_pool.A[21]; A_arbace_classes_opcodes__init_A_const_16 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[22]); A_arbace_classes_opcodes__init_A_const_17 = A_arbace_classes_opcodes__init_A_const_pool.A[23]; A_arbace_classes_opcodes__init_A_const_18 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[24]); A_arbace_classes_opcodes__init_A_const_19 = A_arbace_classes_opcodes__init_A_const_pool.A[25]; A_arbace_classes_opcodes__init_A_const_20 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[26]); A_arbace_classes_opcodes__init_A_const_21 = A_arbace_classes_opcodes__init_A_const_pool.A[27]; A_arbace_classes_opcodes__init_A_const_22 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[28]); A_arbace_classes_opcodes__init_A_const_23 = A_arbace_classes_opcodes__init_A_const_pool.A[29]; A_arbace_classes_opcodes__init_A_const_24 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[30]); A_arbace_classes_opcodes__init_A_const_25 = A_arbace_classes_opcodes__init_A_const_pool.A[31] }

func A_arbace_classes_opcodes__init_A_clinit_p2() { A_arbace_classes_opcodes__init_A_const_26 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[32]); A_arbace_classes_opcodes__init_A_const_27 = A_arbace_classes_opcodes__init_A_const_pool.A[33]; A_arbace_classes_opcodes__init_A_const_28 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[34]); A_arbace_classes_opcodes__init_A_const_29 = A_arbace_classes_opcodes__init_A_const_pool.A[35]; A_arbace_classes_opcodes__init_A_const_30 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[36]); A_arbace_classes_opcodes__init_A_const_31 = A_arbace_classes_opcodes__init_A_const_pool.A[37]; A_arbace_classes_opcodes__init_A_const_32 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[38]); A_arbace_classes_opcodes__init_A_const_33 = A_arbace_classes_opcodes__init_A_const_pool.A[39]; A_arbace_classes_opcodes__init_A_const_34 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[40]); A_arbace_classes_opcodes__init_A_const_35 = A_arbace_classes_opcodes__init_A_const_pool.A[41]; A_arbace_classes_opcodes__init_A_const_36 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[42]); A_arbace_classes_opcodes__init_A_const_37 = A_arbace_classes_opcodes__init_A_const_pool.A[43]; A_arbace_classes_opcodes__init_A_const_38 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[44]) }

func A_arbace_classes_opcodes__init_A_clinit_p3() { A_arbace_classes_opcodes__init_A_const_39 = A_arbace_classes_opcodes__init_A_const_pool.A[45]; A_arbace_classes_opcodes__init_A_const_40 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[46]); A_arbace_classes_opcodes__init_A_const_41 = A_arbace_classes_opcodes__init_A_const_pool.A[47]; A_arbace_classes_opcodes__init_A_const_42 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[48]); A_arbace_classes_opcodes__init_A_const_43 = A_arbace_classes_opcodes__init_A_const_pool.A[49]; A_arbace_classes_opcodes__init_A_const_44 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[50]); A_arbace_classes_opcodes__init_A_const_45 = A_arbace_classes_opcodes__init_A_const_pool.A[51]; A_arbace_classes_opcodes__init_A_const_46 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[52]); A_arbace_classes_opcodes__init_A_const_47 = A_arbace_classes_opcodes__init_A_const_pool.A[53]; A_arbace_classes_opcodes__init_A_const_48 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[54]); A_arbace_classes_opcodes__init_A_const_49 = A_arbace_classes_opcodes__init_A_const_pool.A[55]; A_arbace_classes_opcodes__init_A_const_50 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[56]); A_arbace_classes_opcodes__init_A_const_51 = A_arbace_classes_opcodes__init_A_const_pool.A[57] }

func A_arbace_classes_opcodes__init_A_clinit_p4() { A_arbace_classes_opcodes__init_A_const_52 = lang.Var_Cast(A_arbace_classes_opcodes__init_A_const_pool.A[58]); A_arbace_classes_opcodes__init_A_const_53 = A_arbace_classes_opcodes__init_A_const_pool.A[59] }

func A_arbace_classes_opcodes__init_A_New() *A_arbace_classes_opcodes__init_A { A_arbace_classes_opcodes__init_A_Init(); t := &A_arbace_classes_opcodes__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes__init_A) Ctor() {}

func (t *A_arbace_classes_opcodes__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes__init_A_class }

func (t *A_arbace_classes_opcodes__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes__init_A); return ok }

func A_arbace_classes_opcodes__init_A_Cast(x any) *A_arbace_classes_opcodes__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes__init_A_class)) }; return v }
