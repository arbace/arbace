//line a2g_strings.ae:1
package aot_arbace_classes_opcodes

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_6 *jrt.String = jrt.Intern("doc")

var Lit_7 *jrt.String = jrt.Intern("The JVM's access and property flags (JVMS §4.1, §4.5, §4.6, §4.7.6, §4.7.25), the values of\n  ASM's Opcodes/ACC_* (arbace.asm.Opcodes until 2026-10-12; ASM left main with the bytecode back\n  end, doc/STANDALONE-NOTES.md, S4): a class info's and a member's :flags in the class forms'\n  analysis (arbace.classes) and a2g. Required with the alias Opcodes, so that Opcodes/ACC_PUBLIC\n  reads as before. Each is an int (an Integer, as the interface's static fields were), a\n  constant the compiler inlines.")

var Lit_8 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.opcodes$eval228000004$loading__1927001464__auto____228000005")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.opcodes$eval228000008$fn__228000009")

var Lit_11 *jrt.String = jrt.Intern("in-ns")

var Lit_12 *jrt.String = jrt.Intern("ACC_PUBLIC")

var Lit_13 *jrt.String = jrt.Intern("const")

var Lit_14 *jrt.String = jrt.Intern("line")

var Lit_15 *jrt.String = jrt.Intern("column")

var Lit_16 *jrt.String = jrt.Intern("file")

var Lit_17 *jrt.String = jrt.Intern("arbace/classes/opcodes.ae")

var Lit_18 *jrt.String = jrt.Intern("ACC_PRIVATE")

var Lit_19 *jrt.String = jrt.Intern("ACC_PROTECTED")

var Lit_20 *jrt.String = jrt.Intern("ACC_STATIC")

var Lit_21 *jrt.String = jrt.Intern("ACC_FINAL")

var Lit_22 *jrt.String = jrt.Intern("ACC_SUPER")

var Lit_23 *jrt.String = jrt.Intern("ACC_SYNCHRONIZED")

var Lit_24 *jrt.String = jrt.Intern("ACC_OPEN")

var Lit_25 *jrt.String = jrt.Intern("ACC_TRANSITIVE")

var Lit_26 *jrt.String = jrt.Intern("ACC_VOLATILE")

var Lit_27 *jrt.String = jrt.Intern("ACC_BRIDGE")

var Lit_28 *jrt.String = jrt.Intern("ACC_STATIC_PHASE")

var Lit_29 *jrt.String = jrt.Intern("ACC_VARARGS")

var Lit_30 *jrt.String = jrt.Intern("ACC_TRANSIENT")

var Lit_31 *jrt.String = jrt.Intern("ACC_NATIVE")

var Lit_32 *jrt.String = jrt.Intern("ACC_INTERFACE")

var Lit_33 *jrt.String = jrt.Intern("ACC_ABSTRACT")

var Lit_34 *jrt.String = jrt.Intern("ACC_STRICT")

var Lit_35 *jrt.String = jrt.Intern("ACC_SYNTHETIC")

var Lit_36 *jrt.String = jrt.Intern("ACC_ANNOTATION")

var Lit_37 *jrt.String = jrt.Intern("ACC_ENUM")

var Lit_38 *jrt.String = jrt.Intern("ACC_MANDATED")

var Lit_39 *jrt.String = jrt.Intern("ACC_MODULE")

var Lit_40 *jrt.String = jrt.Intern("ACC_RECORD")

var Lit_41 *jrt.String = jrt.Intern("ACC_DEPRECATED")
