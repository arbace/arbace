//line aot_arbace_classes_opcodes.ae:1
package aot_arbace_classes_opcodes

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_New() *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A { A_arbace_classes_opcodes_A_Init(); t := &A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_classes_opcodes_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_opcodes_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_New() *A_arbace_classes_opcodes_eval228000008_fn__228000009_A { A_arbace_classes_opcodes_A_Init(); t := &A_arbace_classes_opcodes_eval228000008_fn__228000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_opcodes_A_const_2.GetRawRoot__O()); var tmp2 any; var root_5 any = A_arbace_classes_opcodes_A_const_3.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_classes_opcodes_A_const_4; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_5, arg_8) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_opcodes_A_const_5.GetRawRoot__O(), A_arbace_classes_opcodes_A_const_6) }


















type A_arbace_classes_opcodes_A struct{ jrt.Object }

var A_arbace_classes_opcodes_A_const_pool *jrt.RefArray

var A_arbace_classes_opcodes_A_const_0 *lang.Var

var A_arbace_classes_opcodes_A_const_1 any

var A_arbace_classes_opcodes_A_const_2 *lang.Var

var A_arbace_classes_opcodes_A_const_3 *lang.Var

var A_arbace_classes_opcodes_A_const_4 *lang.Var

var A_arbace_classes_opcodes_A_const_5 *lang.Var

var A_arbace_classes_opcodes_A_const_6 any

var A_arbace_classes_opcodes_A_init jrt.ClassInit

func A_arbace_classes_opcodes_A_Init() { if !A_arbace_classes_opcodes_A_init.Done() { A_arbace_classes_opcodes_A_init.Run(A_arbace_classes_opcodes_A_clinit) } }

func A_arbace_classes_opcodes_A_clinit() { jrt.StartCheck(); A_arbace_classes_opcodes_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 9); A_arbace_classes_opcodes_A_const_0 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[2]); A_arbace_classes_opcodes_A_const_1 = A_arbace_classes_opcodes_A_const_pool.A[3]; A_arbace_classes_opcodes_A_const_2 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[4]); A_arbace_classes_opcodes_A_const_3 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[5]); A_arbace_classes_opcodes_A_const_4 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[6]); A_arbace_classes_opcodes_A_const_5 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[7]); A_arbace_classes_opcodes_A_const_6 = A_arbace_classes_opcodes_A_const_pool.A[8] }

func A_arbace_classes_opcodes_A_New() *A_arbace_classes_opcodes_A { A_arbace_classes_opcodes_A_Init(); t := &A_arbace_classes_opcodes_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes_A) Ctor() {}

func (t *A_arbace_classes_opcodes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_A_class }

func (t *A_arbace_classes_opcodes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_A); return ok }

func A_arbace_classes_opcodes_A_Cast(x any) *A_arbace_classes_opcodes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000004_A struct{ jrt.Object }

func A_arbace_classes_opcodes_eval228000004_A_New() *A_arbace_classes_opcodes_eval228000004_A { t := &A_arbace_classes_opcodes_eval228000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes_eval228000004_A) Ctor() {}

func (t *A_arbace_classes_opcodes_eval228000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_eval228000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_eval228000004_A_class }

func (t *A_arbace_classes_opcodes_eval228000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_eval228000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_eval228000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_eval228000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_eval228000004_A); return ok }

func A_arbace_classes_opcodes_eval228000004_A_Cast(x any) *A_arbace_classes_opcodes_eval228000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_eval228000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_eval228000004_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A struct{ j2g_header uint64 }

var A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_fn_class *jrt.Class



type A_arbace_classes_opcodes_eval228000008_A struct{ jrt.Object }

func A_arbace_classes_opcodes_eval228000008_A_New() *A_arbace_classes_opcodes_eval228000008_A { t := &A_arbace_classes_opcodes_eval228000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes_eval228000008_A) Ctor() {}

func (t *A_arbace_classes_opcodes_eval228000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_eval228000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_eval228000008_A_class }

func (t *A_arbace_classes_opcodes_eval228000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_eval228000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_eval228000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_eval228000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_eval228000008_A); return ok }

func A_arbace_classes_opcodes_eval228000008_A_Cast(x any) *A_arbace_classes_opcodes_eval228000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_eval228000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_eval228000008_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000008_fn__228000009_A struct{ j2g_header uint64 }

var A_arbace_classes_opcodes_eval228000008_fn__228000009_A_fn_class *jrt.Class
