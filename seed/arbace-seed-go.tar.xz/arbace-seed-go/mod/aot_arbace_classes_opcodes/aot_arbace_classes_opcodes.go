//line aot_arbace_classes_opcodes.ae:1
package aot_arbace_classes_opcodes

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_New() *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A { A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_Init(); t := &A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_classes_opcodes_A_Init(); tmp4 = A_arbace_classes_opcodes_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_classes_opcodes_A_Init(); tmp6 = A_arbace_classes_opcodes_A_const_1; tmp3 = tmp5.Invoke_O__O(tmp6) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :1:1
func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_New() *A_arbace_classes_opcodes_eval228000008_fn__228000009_A { A_arbace_classes_opcodes_eval228000008_fn__228000009_A_Init(); t := &A_arbace_classes_opcodes_eval228000008_fn__228000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_opcodes_A_Init(); tmp1 = A_arbace_classes_opcodes_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_opcodes_A_Init(); tmp3 = A_arbace_classes_opcodes_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_opcodes_A_Init(); tmp5 = A_arbace_classes_opcodes_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_classes_opcodes_A_Init(); tmp7 = A_arbace_classes_opcodes_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_classes_opcodes_A_Init(); tmp9 = A_arbace_classes_opcodes_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }


















type A_arbace_classes_opcodes_A struct{ jrt.Object }

var A_arbace_classes_opcodes_A_const_0 *lang.Var

var A_arbace_classes_opcodes_A_const_1 any

var A_arbace_classes_opcodes_A_const_2 *lang.Var

var A_arbace_classes_opcodes_A_const_3 *lang.Var

var A_arbace_classes_opcodes_A_const_4 *lang.Var

var A_arbace_classes_opcodes_A_const_5 any

var A_arbace_classes_opcodes_A_const_6 *lang.Var

var A_arbace_classes_opcodes_A_init jrt.ClassInit

func A_arbace_classes_opcodes_A_Init() { if !A_arbace_classes_opcodes_A_init.Done() { A_arbace_classes_opcodes_A_init.Run(A_arbace_classes_opcodes_A_clinit) } }

func A_arbace_classes_opcodes_A_clinit() { A_arbace_classes_opcodes_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_classes_opcodes_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_opcodes_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_classes_opcodes_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_classes_opcodes_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_classes_opcodes_A_const_5 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_classes_opcodes_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8) }

func A_arbace_classes_opcodes_A_New() *A_arbace_classes_opcodes_A { A_arbace_classes_opcodes_A_Init(); t := &A_arbace_classes_opcodes_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes_A) Ctor() {}

func (t *A_arbace_classes_opcodes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_A_class }

func (t *A_arbace_classes_opcodes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_A); return ok }

func A_arbace_classes_opcodes_A_Cast(x any) *A_arbace_classes_opcodes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000004_A struct{ jrt.Object }

func A_arbace_classes_opcodes_eval228000004_A_New() *A_arbace_classes_opcodes_eval228000004_A { t := &A_arbace_classes_opcodes_eval228000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes_eval228000004_A) Ctor() {}

func (t *A_arbace_classes_opcodes_eval228000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_eval228000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_eval228000004_A_class }

func (t *A_arbace_classes_opcodes_eval228000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_eval228000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_eval228000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_eval228000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_eval228000004_A); return ok }

func A_arbace_classes_opcodes_eval228000004_A_Cast(x any) *A_arbace_classes_opcodes_eval228000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_eval228000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_eval228000004_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A struct{ jrt.Object }

func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_fn_class *jrt.Class

var A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_init jrt.ClassInit

func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_Init() { if !A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_init.Done() { A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_init.Run(A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_clinit) } }

func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_clinit() { A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_9, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_class }

func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A); return ok }

func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_Cast(x any) *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000008_A struct{ jrt.Object }

func A_arbace_classes_opcodes_eval228000008_A_New() *A_arbace_classes_opcodes_eval228000008_A { t := &A_arbace_classes_opcodes_eval228000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes_eval228000008_A) Ctor() {}

func (t *A_arbace_classes_opcodes_eval228000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_eval228000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_eval228000008_A_class }

func (t *A_arbace_classes_opcodes_eval228000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_eval228000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_eval228000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_eval228000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_eval228000008_A); return ok }

func A_arbace_classes_opcodes_eval228000008_A_Cast(x any) *A_arbace_classes_opcodes_eval228000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_eval228000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_eval228000008_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000008_fn__228000009_A struct{ jrt.Object }

func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_opcodes_eval228000008_fn__228000009_A_fn_class *jrt.Class

var A_arbace_classes_opcodes_eval228000008_fn__228000009_A_init jrt.ClassInit

func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_Init() { if !A_arbace_classes_opcodes_eval228000008_fn__228000009_A_init.Done() { A_arbace_classes_opcodes_eval228000008_fn__228000009_A_init.Run(A_arbace_classes_opcodes_eval228000008_fn__228000009_A_clinit) } }

func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_clinit() { A_arbace_classes_opcodes_eval228000008_fn__228000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_10, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_eval228000008_fn__228000009_A_class }

func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_eval228000008_fn__228000009_A); return ok }

func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_Cast(x any) *A_arbace_classes_opcodes_eval228000008_fn__228000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_eval228000008_fn__228000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_eval228000008_fn__228000009_A_class)) }; return v }
