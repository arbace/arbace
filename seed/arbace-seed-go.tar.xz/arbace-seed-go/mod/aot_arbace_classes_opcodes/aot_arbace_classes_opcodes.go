//line aot_arbace_classes_opcodes.ae:1
package aot_arbace_classes_opcodes

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_New() *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A { A_arbace_classes_opcodes_A_Init(); t := &A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp3 = lang.IFn_Cast(A_arbace_classes_opcodes_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_opcodes_A_const_1); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_New() *A_arbace_classes_opcodes_eval228000008_fn__228000009_A { A_arbace_classes_opcodes_A_Init(); t := &A_arbace_classes_opcodes_eval228000008_fn__228000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_opcodes_eval228000008_fn__228000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_classes_opcodes_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_opcodes_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_opcodes_A_const_6), A_arbace_classes_opcodes_A_const_4.GetRawRoot__O(), A_arbace_classes_opcodes_A_const_5) }


















type A_arbace_classes_opcodes_A struct{ jrt.Object }

var A_arbace_classes_opcodes_A_const_pool *jrt.RefArray

var A_arbace_classes_opcodes_A_const_0 *lang.Var

var A_arbace_classes_opcodes_A_const_1 any

var A_arbace_classes_opcodes_A_const_2 *lang.Var

var A_arbace_classes_opcodes_A_const_3 *lang.Var

var A_arbace_classes_opcodes_A_const_4 *lang.Var

var A_arbace_classes_opcodes_A_const_5 any

var A_arbace_classes_opcodes_A_const_6 *lang.Var

var A_arbace_classes_opcodes_A_init jrt.ClassInit

func A_arbace_classes_opcodes_A_Init() { if !A_arbace_classes_opcodes_A_init.Done() { A_arbace_classes_opcodes_A_init.Run(A_arbace_classes_opcodes_A_clinit) } }

func A_arbace_classes_opcodes_A_clinit() { A_arbace_classes_opcodes_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 9); A_arbace_classes_opcodes_A_const_0 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[2]); A_arbace_classes_opcodes_A_const_1 = A_arbace_classes_opcodes_A_const_pool.A[3]; A_arbace_classes_opcodes_A_const_2 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[4]); A_arbace_classes_opcodes_A_const_3 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[5]); A_arbace_classes_opcodes_A_const_4 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[6]); A_arbace_classes_opcodes_A_const_5 = A_arbace_classes_opcodes_A_const_pool.A[7]; A_arbace_classes_opcodes_A_const_6 = lang.Var_Cast(A_arbace_classes_opcodes_A_const_pool.A[8]) }

func A_arbace_classes_opcodes_A_New() *A_arbace_classes_opcodes_A { A_arbace_classes_opcodes_A_Init(); t := &A_arbace_classes_opcodes_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes_A) Ctor() {}

func (t *A_arbace_classes_opcodes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_A_class }

func (t *A_arbace_classes_opcodes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_A); return ok }

func A_arbace_classes_opcodes_A_Cast(x any) *A_arbace_classes_opcodes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000004_A struct{ jrt.Object }

func A_arbace_classes_opcodes_eval228000004_A_New() *A_arbace_classes_opcodes_eval228000004_A { t := &A_arbace_classes_opcodes_eval228000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes_eval228000004_A) Ctor() {}

func (t *A_arbace_classes_opcodes_eval228000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_eval228000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_eval228000004_A_class }

func (t *A_arbace_classes_opcodes_eval228000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_eval228000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_eval228000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_eval228000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_eval228000004_A); return ok }

func A_arbace_classes_opcodes_eval228000004_A_Cast(x any) *A_arbace_classes_opcodes_eval228000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_eval228000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_eval228000004_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A struct{ j2g_header uint64 }

var A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_fn_class *jrt.Class



type A_arbace_classes_opcodes_eval228000008_A struct{ jrt.Object }

func A_arbace_classes_opcodes_eval228000008_A_New() *A_arbace_classes_opcodes_eval228000008_A { t := &A_arbace_classes_opcodes_eval228000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_opcodes_eval228000008_A) Ctor() {}

func (t *A_arbace_classes_opcodes_eval228000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_opcodes_eval228000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_opcodes_eval228000008_A_class }

func (t *A_arbace_classes_opcodes_eval228000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_opcodes_eval228000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_opcodes_eval228000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_opcodes_eval228000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_opcodes_eval228000008_A); return ok }

func A_arbace_classes_opcodes_eval228000008_A_Cast(x any) *A_arbace_classes_opcodes_eval228000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_opcodes_eval228000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_opcodes_eval228000008_A_class)) }; return v }



type A_arbace_classes_opcodes_eval228000008_fn__228000009_A struct{ j2g_header uint64 }

var A_arbace_classes_opcodes_eval228000008_fn__228000009_A_fn_class *jrt.Class
