//line a2g_classes.ae:1
package aot_arbace_classes_opcodes

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_classes_opcodes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_opcodes_A_New()}; return nil }

var A_arbace_classes_opcodes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_opcodes_A_new}

var A_arbace_classes_opcodes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.opcodes", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_opcodes.A_arbace_classes_opcodes_A"})

func init() { i := A_arbace_classes_opcodes_A_class.Info(); i.IsInstance = A_arbace_classes_opcodes_A_InstanceOf; i.Init = A_arbace_classes_opcodes_A_Init; i.Table = A_arbace_classes_opcodes_A_members; jrt.RegisterGoType(A_arbace_classes_opcodes_A_class, reflect.TypeFor[A_arbace_classes_opcodes_A]()) }

func A_arbace_classes_opcodes_eval228000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_opcodes_eval228000004_A_New()}; return nil }

var A_arbace_classes_opcodes_eval228000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_opcodes_eval228000004_A_new}

var A_arbace_classes_opcodes_eval228000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.opcodes$eval228000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_opcodes_A_class, Simple: "eval228000004", Go: "arbace/aot_arbace_classes_opcodes.A_arbace_classes_opcodes_eval228000004_A"})

func init() { i := A_arbace_classes_opcodes_eval228000004_A_class.Info(); i.IsInstance = A_arbace_classes_opcodes_eval228000004_A_InstanceOf; i.Table = A_arbace_classes_opcodes_eval228000004_A_members; jrt.RegisterGoType(A_arbace_classes_opcodes_eval228000004_A_class, reflect.TypeFor[A_arbace_classes_opcodes_eval228000004_A]()) }

func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_New()}; return nil }

func A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_fn_class)}; return nil }

var A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_invoke, New: A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_new, Get: A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_get}

var A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.opcodes$eval228000004$loading__1927001464__auto____228000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_opcodes_eval228000004_A_class, Simple: "loading__1927001464__auto____228000005", Go: "arbace/aot_arbace_classes_opcodes.A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A", Source: "opcodes.ae"})

func init() { i := A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_class.Info(); i.IsInstance = A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_InstanceOf; i.Init = A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_Init; i.Table = A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_members; jrt.RegisterGoType(A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A_class, reflect.TypeFor[A_arbace_classes_opcodes_eval228000004_loading__1927001464__auto____228000005_A]()) }

func A_arbace_classes_opcodes_eval228000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_opcodes_eval228000008_A_New()}; return nil }

var A_arbace_classes_opcodes_eval228000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_opcodes_eval228000008_A_new}

var A_arbace_classes_opcodes_eval228000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.opcodes$eval228000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_opcodes_A_class, Simple: "eval228000008", Go: "arbace/aot_arbace_classes_opcodes.A_arbace_classes_opcodes_eval228000008_A"})

func init() { i := A_arbace_classes_opcodes_eval228000008_A_class.Info(); i.IsInstance = A_arbace_classes_opcodes_eval228000008_A_InstanceOf; i.Table = A_arbace_classes_opcodes_eval228000008_A_members; jrt.RegisterGoType(A_arbace_classes_opcodes_eval228000008_A_class, reflect.TypeFor[A_arbace_classes_opcodes_eval228000008_A]()) }

func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_opcodes_eval228000008_fn__228000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_opcodes_eval228000008_fn__228000009_A_New()}; return nil }

func A_arbace_classes_opcodes_eval228000008_fn__228000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_opcodes_eval228000008_fn__228000009_A_fn_class)}; return nil }

var A_arbace_classes_opcodes_eval228000008_fn__228000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_opcodes_eval228000008_fn__228000009_A_invoke, New: A_arbace_classes_opcodes_eval228000008_fn__228000009_A_new, Get: A_arbace_classes_opcodes_eval228000008_fn__228000009_A_get}

var A_arbace_classes_opcodes_eval228000008_fn__228000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.opcodes$eval228000008$fn__228000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_opcodes_eval228000008_A_class, Simple: "fn__228000009", Go: "arbace/aot_arbace_classes_opcodes.A_arbace_classes_opcodes_eval228000008_fn__228000009_A", Source: "opcodes.ae"})

func init() { i := A_arbace_classes_opcodes_eval228000008_fn__228000009_A_class.Info(); i.IsInstance = A_arbace_classes_opcodes_eval228000008_fn__228000009_A_InstanceOf; i.Init = A_arbace_classes_opcodes_eval228000008_fn__228000009_A_Init; i.Table = A_arbace_classes_opcodes_eval228000008_fn__228000009_A_members; jrt.RegisterGoType(A_arbace_classes_opcodes_eval228000008_fn__228000009_A_class, reflect.TypeFor[A_arbace_classes_opcodes_eval228000008_fn__228000009_A]()) }

func A_arbace_classes_opcodes__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_opcodes__init_A_Load__O(); case 1: return A_arbace_classes_opcodes__init_A_Unit0__O(); case 2: return A_arbace_classes_opcodes__init_A_Unit1__O(); case 3: return A_arbace_classes_opcodes__init_A_Unit10__O(); case 4: return A_arbace_classes_opcodes__init_A_Unit11__O(); case 5: return A_arbace_classes_opcodes__init_A_Unit12__O(); case 6: return A_arbace_classes_opcodes__init_A_Unit13__O(); case 7: return A_arbace_classes_opcodes__init_A_Unit14__O(); case 8: return A_arbace_classes_opcodes__init_A_Unit15__O(); case 9: return A_arbace_classes_opcodes__init_A_Unit16__O(); case 10: return A_arbace_classes_opcodes__init_A_Unit17__O(); case 11: return A_arbace_classes_opcodes__init_A_Unit18__O(); case 12: return A_arbace_classes_opcodes__init_A_Unit19__O(); case 13: return A_arbace_classes_opcodes__init_A_Unit2__O(); case 14: return A_arbace_classes_opcodes__init_A_Unit20__O(); case 15: return A_arbace_classes_opcodes__init_A_Unit21__O(); case 16: return A_arbace_classes_opcodes__init_A_Unit22__O(); case 17: return A_arbace_classes_opcodes__init_A_Unit23__O(); case 18: return A_arbace_classes_opcodes__init_A_Unit24__O(); case 19: return A_arbace_classes_opcodes__init_A_Unit25__O(); case 20: return A_arbace_classes_opcodes__init_A_Unit26__O(); case 21: return A_arbace_classes_opcodes__init_A_Unit27__O(); case 22: return A_arbace_classes_opcodes__init_A_Unit28__O(); case 23: return A_arbace_classes_opcodes__init_A_Unit3__O(); case 24: return A_arbace_classes_opcodes__init_A_Unit4__O(); case 25: return A_arbace_classes_opcodes__init_A_Unit5__O(); case 26: return A_arbace_classes_opcodes__init_A_Unit6__O(); case 27: return A_arbace_classes_opcodes__init_A_Unit7__O(); case 28: return A_arbace_classes_opcodes__init_A_Unit8__O(); case 29: return A_arbace_classes_opcodes__init_A_Unit9__O()}; return nil }

func A_arbace_classes_opcodes__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_opcodes__init_A_New()}; return nil }

var A_arbace_classes_opcodes__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_opcodes__init_A_invoke, New: A_arbace_classes_opcodes__init_A_new}

var A_arbace_classes_opcodes__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.opcodes__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_opcodes.A_arbace_classes_opcodes__init_A", Source: "opcodes.ae"})

func init() { i := A_arbace_classes_opcodes__init_A_class.Info(); i.IsInstance = A_arbace_classes_opcodes__init_A_InstanceOf; i.Init = A_arbace_classes_opcodes__init_A_Init; i.Table = A_arbace_classes_opcodes__init_A_members; jrt.RegisterGoType(A_arbace_classes_opcodes__init_A_class, reflect.TypeFor[A_arbace_classes_opcodes__init_A]()) }
