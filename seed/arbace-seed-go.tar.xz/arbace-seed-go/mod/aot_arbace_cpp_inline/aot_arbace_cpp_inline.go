//line aot_arbace_cpp_inline.ae:1
package aot_arbace_cpp_inline

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)





func A_arbace_cpp_inline_eval113000004_loading__1927001464__auto____113000005_A_New() *A_arbace_cpp_inline_eval113000004_loading__1927001464__auto____113000005_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_eval113000004_loading__1927001464__auto____113000005_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_cpp_inline_eval113000004_loading__1927001464__auto____113000005_A) Ctor() {}
//line :14:1
func (t *A_arbace_cpp_inline_eval113000004_loading__1927001464__auto____113000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_cpp_inline_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_inline_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_cpp_inline_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_inline_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :14:1
func A_arbace_cpp_inline_eval113000008_fn__113000009_A_New() *A_arbace_cpp_inline_eval113000008_fn__113000009_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_eval113000008_fn__113000009_A{}; t.Ctor(); return t }
//line :14:1
func (t *A_arbace_cpp_inline_eval113000008_fn__113000009_A) Ctor() {}
//line :14:1
func (t *A_arbace_cpp_inline_eval113000008_fn__113000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_cpp_inline_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_cpp_inline_A_const_7.GetRawRoot__O(), A_arbace_cpp_inline_A_const_8) }





















func A_arbace_cpp_inline_gname_A_New() *A_arbace_cpp_inline_gname_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_gname_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_cpp_inline_gname_A) Ctor() {}
//line :36:1
func (t *A_arbace_cpp_inline_gname_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_19 any = A_arbace_cpp_inline_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_21 lang.IFn
	if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = x__0; if linked_20 == nil { and__1927000168__auto____2 = ifn_21.Invoke_O__O(arg_22) } else { and__1927000168__auto____2 = linked_20.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_19, arg_22) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any; var root_23 any = A_arbace_cpp_inline_A_const_10.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = x__0; if linked_24 == nil { tmp2 = ifn_25.Invoke_O__O(arg_26) } else { tmp2 = linked_24.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_23, arg_26) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_32, tmp2)).Ref() } else { tmp1 = and__1927000168__auto____2 }
//line :39:1
	if jrt.J2g_Truth(tmp1) {
		var root_27 any = A_arbace_cpp_inline_A_const_11.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = x__0; if linked_28 == nil { return ifn_29.Invoke_O__O(arg_30) } else { return linked_28.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_27, arg_30) } } else {
//line :39:1
			var tmp3 any; var and__1927000168__auto____2_2 any; var root_31 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_33 lang.IFn

			if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = x__0; if linked_32 == nil { and__1927000168__auto____2_2 = ifn_33.Invoke_O__O(arg_34) } else { and__1927000168__auto____2_2 = linked_32.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var and__1927000168__auto____3 bool; var tmp4 any = A_arbace_cpp_inline_A_const_13; var tmp5 any; var root_35 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = x__0; if linked_36 == nil { tmp5 = ifn_37.Invoke_O__O(arg_38) } else { tmp5 = linked_36.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_35, arg_38) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5); if and__1927000168__auto____3 { var root_39 any = A_arbace_cpp_inline_A_const_15.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var root_43 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = x__0; if linked_44 == nil { arg_42 = ifn_45.Invoke_O__O(arg_46) } else { arg_42 = linked_44.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_43, arg_46) }; if linked_40 == nil { tmp3 = ifn_41.Invoke_O__O(arg_42) } else { tmp3 = linked_40.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_39, arg_42) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp3 = and__1927000168__auto____2_2 }
//line :39:1
			if jrt.J2g_Truth(tmp3) {

				var root_47 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = x__0; if linked_48 == nil { return ifn_49.Invoke_O__O(arg_50) } else { return linked_48.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_47, arg_50) } } else {
//line :39:1
					if A_arbace_cpp_inline_A_const_17 != nil { return nil } else { return nil
					}
				}
		}
}
func A_arbace_cpp_inline_local_QMARK__A_New() *A_arbace_cpp_inline_local_QMARK__A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_local_QMARK__A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_cpp_inline_local_QMARK__A) Ctor() {}
//line :44:1
func (t *A_arbace_cpp_inline_local_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_51 any = A_arbace_cpp_inline_A_const_9.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = x__0; if linked_52 == nil { and__1927000168__auto____2 = ifn_53.Invoke_O__O(arg_54) } else { and__1927000168__auto____2 = linked_52.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_51, arg_54) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp1 any; var root_55 any = A_arbace_cpp_inline_A_const_10.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = x__0; if linked_56 == nil { tmp1 = ifn_57.Invoke_O__O(arg_58) } else { tmp1 = linked_56.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_55, arg_58) }; and__1927000168__auto____3 = lang.Util_Identical_O_O__Z_NoInit(tmp1, nil); if and__1927000168__auto____3 { var root_59 any = A_arbace_cpp_inline_A_const_18.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var root_64 any = A_arbace_cpp_inline_A_const_11.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = x__0; if linked_65 == nil { arg_62 = ifn_66.Invoke_O__O(arg_67) } else { arg_62 = linked_65.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_64, arg_67) }; var arg_63 any = Lit_60; if linked_60 == nil { return ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { return linked_60.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_59, arg_62, arg_63) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return and__1927000168__auto____2 } }

func A_arbace_cpp_inline_opts_of_A_New() *A_arbace_cpp_inline_opts_of_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_opts_of_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_cpp_inline_opts_of_A) Ctor() {}
//line :46:1
func (t *A_arbace_cpp_inline_opts_of_A) InvokePrim_O_O_J__O(self, x__0 any, n__1 int64) any {


	var root_68 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_cpp_inline_A_const_20.GetRawRoot__O(); var arg_72 any; var root_73 any = A_arbace_cpp_inline_A_const_21.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_73, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 int64 = n__1; var arg_77 any = x__0; if linked_74 == nil { arg_72 = ifn_75.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_76).Ref(), arg_77) } else { arg_72 = linked_74.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_73, arg_76, nil, arg_77) }; if linked_69 == nil { return ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { return linked_69.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_68, arg_71, arg_72) } }
//line :46:1
func (t *A_arbace_cpp_inline_opts_of_A) Invoke_O_O_O__O(self, x__0, p_n__1 any) any { return t.InvokePrim_O_O_J__O(self, x__0, lang.RT_LongCast_O__J_NoInit(p_n__1)) }




func A_arbace_cpp_inline_define_opts_A_New() *A_arbace_cpp_inline_define_opts_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_define_opts_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_cpp_inline_define_opts_A) Ctor() {}
//line :51:1
func (t *A_arbace_cpp_inline_define_opts_A) Invoke_O_O__O(self, d__0 any) any { var vec__113000017__2 any = d__0; var seq__113000018__3 any; var root_78 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = vec__113000017__2; if linked_79 == nil { seq__113000018__3 = ifn_80.Invoke_O__O(arg_81) } else { seq__113000018__3 = linked_79.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_78, arg_81) }; var first__113000019__4 any; var root_82 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = seq__113000018__3; if linked_83 == nil { first__113000019__4 = ifn_84.Invoke_O__O(arg_85) } else { first__113000019__4 = linked_83.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_82, arg_85) }; var seq__113000018__5 any; var root_86 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = seq__113000018__3; if linked_87 == nil { seq__113000018__5 = ifn_88.Invoke_O__O(arg_89) } else { seq__113000018__5 = linked_87.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_86, arg_89) }; var ___6 any = first__113000019__4; var first__113000019__7 any; var root_90 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_92 lang.IFn; _ = ___6; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = seq__113000018__5; if linked_91 == nil { first__113000019__7 = ifn_92.Invoke_O__O(arg_93) } else { first__113000019__7 = linked_91.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_90, arg_93) }; var seq__113000018__8 any; var root_94 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = seq__113000018__5; if linked_95 == nil { seq__113000018__8 = ifn_96.Invoke_O__O(arg_97) } else { seq__113000018__8 = linked_95.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_94, arg_97) }; var ___9 any = first__113000019__7; var first__113000019__10 any; var root_98 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_100 lang.IFn; _ = ___9; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = seq__113000018__8; if linked_99 == nil { first__113000019__10 = ifn_100.Invoke_O__O(arg_101) } else { first__113000019__10 = linked_99.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_98, arg_101) }; var seq__113000018__11 any; var root_102 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = seq__113000018__8; if linked_103 == nil { seq__113000018__11 = ifn_104.Invoke_O__O(arg_105) } else { seq__113000018__11 = linked_103.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_102, arg_105) }; var ___12 any = first__113000019__10; var first__113000019__13 any; var root_106 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_108 lang.IFn; _ = ___12; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = seq__113000018__11; if linked_107 == nil { first__113000019__13 = ifn_108.Invoke_O__O(arg_109) } else { first__113000019__13 = linked_107.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_106, arg_109) }; var seq__113000018__14 any; var root_110 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = seq__113000018__11; if linked_111 == nil { seq__113000018__14 = ifn_112.Invoke_O__O(arg_113) } else { seq__113000018__14 = linked_111.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_110, arg_113) }; var ___15 any = first__113000019__13; var o__16 any = seq__113000018__14; var root_114 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_116 lang.IFn; _ = ___15; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any = A_arbace_cpp_inline_A_const_20.GetRawRoot__O(); var arg_118 any = o__16; if linked_115 == nil { return ifn_116.Invoke_O_O__O(arg_117, arg_118) } else { return linked_115.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_114, arg_117, arg_118) } }

func A_arbace_cpp_inline_set_opt_A_New() *A_arbace_cpp_inline_set_opt_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_set_opt_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_cpp_inline_set_opt_A) Ctor() {}
//line :53:1
func (t *A_arbace_cpp_inline_set_opt_A) Invoke_O_O_O_O__O(self, d__0, k__1, v__2 any) any { var vec__113000021__4 any = d__0; var seq__113000022__5 any; var root_119 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_121 lang.IFn; if


	linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = vec__113000021__4; if linked_120 == nil { seq__113000022__5 = ifn_121.Invoke_O__O(arg_122) } else { seq__113000022__5 = linked_120.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_119, arg_122) }; var first__113000023__6 any; var root_123 any = /*line :53:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_125 lang.IFn; if


	linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = seq__113000022__5; if linked_124 == nil { first__113000023__6 = ifn_125.Invoke_O__O(arg_126) } else { first__113000023__6 = linked_124.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_123, arg_126) }; var seq__113000022__7 any; var root_127 any = /*line :53:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_129 lang.IFn; if


	linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = seq__113000022__5; if linked_128 == nil { seq__113000022__7 = ifn_129.Invoke_O__O(arg_130) } else { seq__113000022__7 = linked_128.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_127, arg_130) }; var h__8 any = first__113000023__6; var first__113000023__9 any; var root_131 any = /*line :53:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_133 lang.IFn; if


	linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = seq__113000022__7; if linked_132 == nil { first__113000023__9 = ifn_133.Invoke_O__O(arg_134) } else { first__113000023__9 = linked_132.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_131, arg_134) }; var seq__113000022__10 any; var root_135 any = /*line :53:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_137 lang.IFn; if


	linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = seq__113000022__7; if linked_136 == nil { seq__113000022__10 = ifn_137.Invoke_O__O(arg_138) } else { seq__113000022__10 = linked_136.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_135, arg_138) }; var nm__11 any = first__113000023__9; var first__113000023__12 any; var root_139 any = /*line :53:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_141 lang.IFn; if


	linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = seq__113000022__10; if linked_140 == nil { first__113000023__12 = ifn_141.Invoke_O__O(arg_142) } else { first__113000023__12 = linked_140.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_139, arg_142) }; var seq__113000022__13 any; var root_143 any = /*line :53:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_145 lang.IFn; if


	linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = seq__113000022__10; if linked_144 == nil { seq__113000022__13 = ifn_145.Invoke_O__O(arg_146) } else { seq__113000022__13 = linked_144.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_143, arg_146) }; var rt__14 any = first__113000023__12; var first__113000023__15 any; var root_147 any = /*line :53:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_149 lang.IFn; if


	linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = seq__113000022__13; if linked_148 == nil { first__113000023__15 = ifn_149.Invoke_O__O(arg_150) } else { first__113000023__15 = linked_148.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_147, arg_150) }; var seq__113000022__16 any; var root_151 any = /*line :53:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_153 lang.IFn; if


	linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = seq__113000022__13; if linked_152 == nil { seq__113000022__16 = ifn_153.Invoke_O__O(arg_154) } else { seq__113000022__16 = linked_152.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_151, arg_154) }; var ps__17 any = first__113000023__15; var o__18 any = seq__113000022__16; var o__19 any; var root_155 any = /*line :53:1*/A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_157 lang.IFn; if



	linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = o__18; if linked_156 == nil { o__19 = ifn_157.Invoke_O__O(arg_158) } else { o__19 = linked_156.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_155, arg_158) }; var i__20 any; var root_159 any = /*line :53:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_161 lang.IFn; if




	linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any; var root_163 any = A_arbace_cpp_inline_A_const_25.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; var fnbody__173 any = A_arbace_cpp_inline_set_opt_fn__113000024_A_New_O(k__1); var tmp1 *jrt.Class; var fncls__172 *jrt.Class = A_arbace_cpp_inline_set_opt_fn__113000024_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__173); A_arbace_cpp_inline_set_opt_fn__113000024_A_fn_class = fncls__172d; tmp1 = fncls__172d } else { tmp1 = fncls__172 }; arg_166 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__173, tmp1, nil); var arg_167 any = o__19; if linked_164 == nil { arg_162 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { arg_162 = linked_164.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }; if linked_160 == nil { i__20 = ifn_161.Invoke_O__O(arg_162) } else { i__20 = linked_160.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_159, arg_162) }; var o__21 any; if
	jrt.J2g_Truth(i__20) { var root_174 any = A_arbace_cpp_inline_A_const_27.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = o__19; var arg_178 any; var na_180 any = i__20; if jrt.Long_InstanceOf(na_180) { var n0_181 int64 = jrt.NN(jrt.Long_Cast(na_180)).LongValue__J(); if n0_181 == 9223372036854775807 { arg_178 = lang.Numbers_Inc_O__Number_NoInit(na_180) } else { arg_178 = jrt.Long_ValueOf_J__Long_NoInit(n0_181 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_180) { var n0_181_2 float64 = jrt.NN(jrt.Double_Cast(na_180)).DoubleValue__D(); arg_178 = jrt.Double_ValueOf_D__Double_NoInit(n0_181_2 + 1.0).Ref() } else { arg_178 = lang.Numbers_Inc_O__Number_NoInit(na_180) } }; var arg_179 any = v__2; if linked_175 == nil { o__21 = ifn_176.Invoke_O_O_O__O(arg_177, arg_178, arg_179) } else { o__21 = linked_175.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_174, arg_177, arg_178, arg_179) } } else { var b__21 int32 = jrt.List_Cast(o__19).IndexOf_O__I(A_arbace_cpp_inline_A_const_28); if lang.Numbers_IsNeg_J__Z_NoInit(int64(b__21)) { o__21 = lang.IFn_Cast(A_arbace_cpp_inline_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(o__19, k__1, v__2) } else { var root_188 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_29.GetRawRoot__O()); var tmp3 any; var root_198 any = A_arbace_cpp_inline_A_const_30.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = o__19; var arg_202 any = A_arbace_cpp_inline_A_const_31; var arg_203 any = jrt.Integer_ValueOf_I__Integer_NoInit(b__21).Ref(); if linked_199 == nil { tmp3 = ifn_200.Invoke_O_O_O__O(arg_201, arg_202, arg_203) } else { tmp3 = linked_199.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_198, arg_201, arg_202, arg_203) }; var tmp4 any = tmp3; var tmp5 any = lang.Tuple_Create_O_O__IPersistentVector(k__1, v__2); var tmp6 any; var root_204 any = A_arbace_cpp_inline_A_const_30.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = o__19; var arg_208 any = jrt.Integer_ValueOf_I__Integer_NoInit(b__21).Ref(); if linked_205 == nil { tmp6 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { tmp6 = linked_205.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; arg_191 = tmp2.Invoke_O_O_O__O(tmp4, tmp5, tmp6); if linked_189 == nil { o__21 = ifn_190.Invoke_O__O(arg_191) } else { o__21 = linked_189.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_188, arg_191) } } }; return /*line :60:1*/ lang.IFn_Cast(A_arbace_cpp_inline_A_const_19.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_cpp_inline_A_const_32.GetRawRoot__O(), h__8, nm__11, rt__14, ps__17, o__21) }
//line :58:1
func A_arbace_cpp_inline_set_opt_fn__113000024_A_New_O(p0 any) *A_arbace_cpp_inline_set_opt_fn__113000024_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_set_opt_fn__113000024_A{}; t.Ctor_O(p0); return t }
//line :58:1
func (t *A_arbace_cpp_inline_set_opt_fn__113000024_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :58:1
func (t *A_arbace_cpp_inline_set_opt_fn__113000024_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { var tmp1 any; var and__1927000168__auto____3 any; var root_168 any = A_arbace_cpp_inline_A_const_26.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_even_QMARK__A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = i__1; if linked_169 == nil { and__1927000168__auto____3 = ifn_170.Invoke_O__O(arg_171) } else { and__1927000168__auto____3 = linked_169.(*aot_arbace_core.A_arbace_core_even_QMARK__A).Invoke_O_O__O(root_168, arg_171) }; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(x__2, t.F_k)).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { return i__1 } else { return nil } }



func A_arbace_cpp_inline_inst_op_A_New() *A_arbace_cpp_inline_inst_op_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inst_op_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_cpp_inline_inst_op_A) Ctor() {}
//line :62:1
func (t *A_arbace_cpp_inline_inst_op_A) Invoke_O_O__O(self, i__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any; var root_218 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = i__0; if linked_219 == nil { and__1927000168__auto____2 = ifn_220.Invoke_O__O(arg_221) } else { and__1927000168__auto____2 = linked_219.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_218, arg_221) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_cpp_inline_A_const_33; var tmp3 any; var root_222 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = i__0; if linked_223 == nil { tmp3 = ifn_224.Invoke_O__O(arg_225) } else { tmp3 = linked_223.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_222, arg_225) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return lang.RT_Nth_O_I__O_NoInit(i__0, lang.RT_IntCast_J__I_NoInit(2)) } else { return i__0
	} }
func A_arbace_cpp_inline_inst_def_A_New() *A_arbace_cpp_inline_inst_def_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inst_def_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_cpp_inline_inst_def_A) Ctor() {}
//line :67:1
func (t *A_arbace_cpp_inline_inst_def_A) Invoke_O_O__O(self, i__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_226 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = i__0; if linked_227 == nil { and__1927000168__auto____2 = ifn_228.Invoke_O__O(arg_229) } else { and__1927000168__auto____2 = linked_227.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_cpp_inline_A_const_34; var tmp3 any; var root_230 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = i__0; if linked_231 == nil { tmp3 = ifn_232.Invoke_O__O(arg_233) } else { tmp3 = linked_231.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_230, arg_233) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_234 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = i__0; if linked_235 == nil { return ifn_236.Invoke_O__O(arg_237) } else { return linked_235.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_234, arg_237) } } else { return nil } }

func A_arbace_cpp_inline_head_A_New() *A_arbace_cpp_inline_head_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_head_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_cpp_inline_head_A) Ctor() {}
//line :69:1
func (t *A_arbace_cpp_inline_head_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_238 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = x__0; if linked_239 == nil { tmp1 = ifn_240.Invoke_O__O(arg_241) } else { tmp1 = linked_239.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_238, arg_241) }; if jrt.J2g_Truth(tmp1) { var root_242 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = x__0; if linked_243 == nil { return ifn_244.Invoke_O__O(arg_245) } else { return linked_243.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_242, arg_245) } } else { return nil } }

func A_arbace_cpp_inline_attrs_have_QMARK__A_New() *A_arbace_cpp_inline_attrs_have_QMARK__A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_attrs_have_QMARK__A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_cpp_inline_attrs_have_QMARK__A) Ctor() {}
//line :71:1
func (t *A_arbace_cpp_inline_attrs_have_QMARK__A) Invoke_O_O_O__O(self, as__0, k__1 any) any { var tmp1 any; var root_246 any = A_arbace_cpp_inline_A_const_35.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, k__1)); var arg_250 any = as__0; if linked_247 == nil { tmp1 = ifn_248.Invoke_O_O__O(arg_249, arg_250) } else { tmp1 = linked_247.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_246, arg_249, arg_250) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }




func A_arbace_cpp_inline_calls_in_A_New() *A_arbace_cpp_inline_calls_in_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_calls_in_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_cpp_inline_calls_in_A) Ctor() {}
//line :76:1
func (t *A_arbace_cpp_inline_calls_in_A) Invoke_O_O__O(self, d__0 any) any { var iter__1927001039__auto____2 any; var fnbody__366 any = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A_New(); var tmp1 *jrt.Class; var fncls__365 *jrt.Class = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A_fn_class; if
										fncls__365 == nil { var fncls__365d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A_fn_class = fncls__365d; tmp1 = fncls__365d } else { tmp1 = fncls__365 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__366, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 *lang.Keyword = A_arbace_cpp_inline_A_const_28; var tmp4 any; var root_367 any = A_arbace_cpp_inline_A_const_50.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, A_arbace_cpp_inline_define_opts_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = d__0; if linked_368 == nil { tmp4 = ifn_369.Invoke_O__O(arg_370) } else { tmp4 = linked_368.(*A_arbace_cpp_inline_define_opts_A).Invoke_O_O__O(root_367, arg_370) }; return tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)) }
//line :77:1
func A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A_New() *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A) Ctor() {}
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A) Invoke_O_O__O(self, s__113000032__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__364 any = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A_New_O_O(self, s__113000032__1); var tmp2 *jrt.Class; var fncls__363 *jrt.Class = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A_fn_class; if fncls__363 == nil { var fncls__363d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__364); A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A_fn_class = fncls__363d; tmp2 = fncls__363d } else { tmp2 = fncls__363 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__364, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :77:1
func A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A{}; t.Ctor_O_O(p0, p1); return t }
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A) Ctor_O_O(c__iter__113000031, c__s__113000032 any) { t.F_iter__113000031 = c__iter__113000031; t.F_s__113000032 = c__s__113000032 }
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A) Invoke_O__O(self any) any { { var s__113000032__1 any; var t_ any = t.F_s__113000032; t.F_s__113000032 = nil; s__113000032__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_251 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = s__113000032__1; if linked_252 == nil { temp__1927000414__auto____2 = ifn_253.Invoke_O__O(arg_254) } else { temp__1927000414__auto____2 = linked_252.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_251, arg_254) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var b__4 any; var root_255 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = xs__1927001018__auto____3; if linked_256 == nil { b__4 = ifn_257.Invoke_O__O(arg_258) } else { b__4 = linked_256.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_255, arg_258) }; var iterys__1927001035__auto____5 any; var fnbody__340 any = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A_New(); var tmp1 *jrt.Class; var fncls__339 *jrt.Class = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A_fn_class; if fncls__339 == nil { var fncls__339d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A_fn_class = fncls__339d; tmp1 = fncls__339d } else { tmp1 = fncls__339 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__340, tmp1, nil); var fs__1927001036__auto____6 any; var root_341 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_345 any = A_arbace_cpp_inline_A_const_21.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_345, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_349 any = b__4; if linked_346 == nil { tmp3 = ifn_347.Invoke_O_O__O(A_arbace_cpp_inline_A_const_49, arg_349) } else { tmp3 = linked_346.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_345, 2, A_arbace_cpp_inline_A_const_49, arg_349) }; arg_344 = tmp2.Invoke_O__O(tmp3); if linked_342 == nil { fs__1927001036__auto____6 = ifn_343.Invoke_O__O(arg_344) } else { fs__1927001036__auto____6 = linked_342.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_341, arg_344) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_350 any = A_arbace_cpp_inline_A_const_29.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = fs__1927001036__auto____6; var arg_354 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__113000031); var tmp5 any; var root_355 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = s__113000032__1; if linked_356 == nil { tmp5 = ifn_357.Invoke_O__O(arg_358) } else { tmp5 = linked_356.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_355, arg_358) }; arg_354 = tmp4.Invoke_O__O(tmp5); if linked_351 == nil { return ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { return linked_351.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_350, arg_353, arg_354) } } else { var tmp6 any; var root_359 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = s__113000032__1; if linked_360 == nil { tmp6 = ifn_361.Invoke_O__O(arg_362) } else { tmp6 = linked_360.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_359, arg_362) }; s__113000032__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :77:1
func A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A_New() *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A) Ctor() {}
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A) Invoke_O_O__O(self, s__113000034__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__338 any = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A_New_O_O(s__113000034__1, self); var tmp2 *jrt.Class; var fncls__337 *jrt.Class = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A_fn_class; if fncls__337 == nil { var fncls__337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__338); A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A_fn_class = fncls__337d; tmp2 = fncls__337d } else { tmp2 = fncls__337 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__338, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :77:1
func A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A{}; t.Ctor_O_O(p0, p1); return t }
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A) Ctor_O_O(c__s__113000034, c__iter__113000033 any) { t.F_s__113000034 = c__s__113000034; t.F_iter__113000033 = c__iter__113000033 }
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A) Invoke_O__O(self any) any { { var s__113000034__1 any; var t_ any = t.F_s__113000034; t.F_s__113000034 = nil; s__113000034__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_259 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = s__113000034__1; if linked_260 == nil { temp__1927000414__auto____2 = ifn_261.Invoke_O__O(arg_262) } else { temp__1927000414__auto____2 = linked_260.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_259, arg_262) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__113000034__3 any = temp__1927000414__auto____2; var tmp1 any; var root_263 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = s__113000034__3; if linked_264 == nil { tmp1 = ifn_265.Invoke_O__O(arg_266) } else { tmp1 = linked_264.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_263, arg_266) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_267 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = s__113000034__3; if linked_268 == nil { c__1927001037__auto____4 = ifn_269.Invoke_O__O(arg_270) } else { c__1927001037__auto____4 = linked_268.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_267, arg_270) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__113000036__6 any; var root_271 any = A_arbace_cpp_inline_A_const_38.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_272 == nil { b__113000036__6 = ifn_273.Invoke_O__O(arg_274) } else { b__113000036__6 = linked_272.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_271, arg_274) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__289 any = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A_New_O_I_O(b__113000036__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__288 *jrt.Class = A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A_fn_class; if fncls__288 == nil { var fncls__288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__289); A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A_fn_class = fncls__288d; tmp3 = fncls__288d } else { tmp3 = fncls__288 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__289, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_290 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any; var root_295 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = b__113000036__6; if linked_296 == nil { arg_293 = ifn_297.Invoke_O__O(arg_298) } else { arg_293 = linked_296.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_295, arg_298) }; var arg_294 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__113000033); var tmp5 any; var root_299 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = s__113000034__3; if linked_300 == nil { tmp5 = ifn_301.Invoke_O__O(arg_302) } else { tmp5 = linked_300.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_299, arg_302) }; arg_294 = tmp4.Invoke_O__O(tmp5); if linked_291 == nil { return ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { return linked_291.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) } } else { var root_303 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var root_308 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = b__113000036__6; if linked_309 == nil { arg_306 = ifn_310.Invoke_O__O(arg_311) } else { arg_306 = linked_309.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_308, arg_311) }; var arg_307 any; if linked_304 == nil { return ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { return linked_304.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) } } } else { var i__4 any; var root_312 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = s__113000034__3; if linked_313 == nil { i__4 = ifn_314.Invoke_O__O(arg_315) } else { i__4 = linked_313.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_312, arg_315) }; var o__5 any; var root_316 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = i__4; if linked_317 == nil { o__5 = ifn_318.Invoke_O__O(arg_319) } else { o__5 = linked_317.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_316, arg_319) }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_46); var tmp7 any; var root_329 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, A_arbace_cpp_inline_head_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = o__5; if linked_330 == nil { tmp7 = ifn_331.Invoke_O__O(arg_332) } else { tmp7 = linked_330.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_329, arg_332) }; if jrt.J2g_Truth(tmp6.Invoke_O__O(tmp7)) { var root_320 any = A_arbace_cpp_inline_A_const_47.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = o__5; var arg_324 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__113000033); var tmp9 any; var root_325 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = s__113000034__3; if linked_326 == nil { tmp9 = ifn_327.Invoke_O__O(arg_328) } else { tmp9 = linked_326.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_325, arg_328) }; arg_324 = tmp8.Invoke_O__O(tmp9); if linked_321 == nil { return ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { return linked_321.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } } else { var tmp10 any; var root_333 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = s__113000034__3; if linked_334 == nil { tmp10 = ifn_335.Invoke_O__O(arg_336) } else { tmp10 = linked_334.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_333, arg_336) }; s__113000034__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :77:1
func A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A) Ctor_O_I_O(c__b__113000036 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__113000036 = c__b__113000036; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :77:1
func (t *A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A) Invoke_O__O(self any) any { { var i__113000035__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__113000035__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__113000035__1)); var o__3 any; var root_275 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = i__2; if linked_276 == nil { o__3 = ifn_277.Invoke_O__O(arg_278) } else { o__3 = linked_276.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_275, arg_278) }; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_40); var tmp3 any; var root_279 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, A_arbace_cpp_inline_head_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = o__3; if linked_280 == nil { tmp3 = ifn_281.Invoke_O__O(arg_282) } else { tmp3 = linked_280.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_279, arg_282) }; if jrt.J2g_Truth(tmp2.Invoke_O__O(tmp3)) { var root_283 any = A_arbace_cpp_inline_A_const_42.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = t.F_b__113000036; var arg_287 any = o__3; if linked_284 == nil { ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { linked_284.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_283, arg_286, arg_287) }; i__113000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000035__1); continue L1 } else { i__113000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000035__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_cpp_inline_viable_QMARK__A_New() *A_arbace_cpp_inline_viable_QMARK__A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_viable_QMARK__A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_cpp_inline_viable_QMARK__A) Ctor() {}
//line :79:1
func (t *A_arbace_cpp_inline_viable_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var vec__113000049__2 any = d__0; var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000049__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nm__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000049__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000049__2, lang.RT_IntCast_J__I_NoInit(2), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000049__2, lang.RT_IntCast_J__I_NoInit(3), nil); var n__7 any; var root_371 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, A_arbace_cpp_inline_gname_A_fn_class); var ifn_373 lang.IFn; _ = ___3; _ = ___5; if
										linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = nm__4; if linked_372 == nil { n__7 = ifn_373.Invoke_O__O(arg_374) } else { n__7 = linked_372.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_371, arg_374) }; var and__1927000168__auto____8 any; var root_375 any = /*line :79:1*/A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_377 lang.IFn; if

	linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any; var root_379 any = A_arbace_cpp_inline_A_const_35.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = A_arbace_cpp_inline_A_const_53; var arg_383 any = ps__6; if linked_380 == nil { arg_378 = ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { arg_378 = linked_380.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) }; if linked_376 == nil { and__1927000168__auto____8 = ifn_377.Invoke_O__O(arg_378) } else { and__1927000168__auto____8 = linked_376.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_375, arg_378) }; if jrt.J2g_Truth(and__1927000168__auto____8) {
		var root_384 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any; var root_388 any = A_arbace_cpp_inline_A_const_35.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any; var fnbody__398 any = A_arbace_cpp_inline_viable_QMARK__fn__113000052_A_New_O(n__7); var tmp1 *jrt.Class; var fncls__397 *jrt.Class = A_arbace_cpp_inline_viable_QMARK__fn__113000052_A_fn_class; if fncls__397 == nil { var fncls__397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__398); A_arbace_cpp_inline_viable_QMARK__fn__113000052_A_fn_class = fncls__397d; tmp1 = fncls__397d } else { tmp1 = fncls__397 }; arg_391 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__398, tmp1, nil); var arg_392 any; var root_399 any = A_arbace_cpp_inline_A_const_54.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, A_arbace_cpp_inline_calls_in_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = d__0; if linked_400 == nil { arg_392 = ifn_401.Invoke_O__O(arg_402) } else { arg_392 = linked_400.(*A_arbace_cpp_inline_calls_in_A).Invoke_O_O__O(root_399, arg_402) }; if linked_389 == nil { arg_387 = ifn_390.Invoke_O_O__O(arg_391, arg_392) } else { arg_387 = linked_389.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_388, arg_391, arg_392) }; if linked_385 == nil { return ifn_386.Invoke_O__O(arg_387) } else { return linked_385.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_384, arg_387) } } else {
//line :81:1
			return and__1927000168__auto____8 } }
func A_arbace_cpp_inline_viable_QMARK__fn__113000052_A_New_O(p0 any) *A_arbace_cpp_inline_viable_QMARK__fn__113000052_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_viable_QMARK__fn__113000052_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_cpp_inline_viable_QMARK__fn__113000052_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :82:1
func (t *A_arbace_cpp_inline_viable_QMARK__fn__113000052_A) Invoke_O_O__O(self, p1__113000048_SHARP___1 any) any { var tmp1 any = t.F_n; var tmp2 any; var root_393 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_cpp_inline_gname_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = lang.RT_Nth_O_I__O_NoInit(p1__113000048_SHARP___1, lang.RT_IntCast_J__I_NoInit(2)); if linked_394 == nil { tmp2 = ifn_395.Invoke_O__O(arg_396) } else { tmp2 = linked_394.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_393, arg_396) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }




func A_arbace_cpp_inline_remap_A_New() *A_arbace_cpp_inline_remap_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_remap_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_cpp_inline_remap_A) Ctor() {}
//line :87:1
func (t *A_arbace_cpp_inline_remap_A) Invoke_O_O_O_O__O(self, x__0, m__1, rn__2 any) any {


	var tmp1 any; var root_403 any = A_arbace_cpp_inline_A_const_55.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, A_arbace_cpp_inline_local_QMARK__A_fn_class); var ifn_405 lang.IFn
	if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = x__0; if linked_404 == nil { tmp1 = ifn_405.Invoke_O__O(arg_406) } else { tmp1 = linked_404.(*A_arbace_cpp_inline_local_QMARK__A).Invoke_O_O__O(root_403, arg_406) }
//line :90:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_407 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = m__1; var arg_411 any = x__0; if linked_408 == nil { tmp2 = ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { tmp2 = linked_408.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_407, arg_410, arg_411) }; if jrt.J2g_Truth(tmp2) { return lang.RT_Get_O_O__O_NoInit(m__1, x__0) } else { return lang.IFn_Cast(rn__2).Invoke_O__O(x__0) } } else {
//line :90:1
			var tmp3 any; var root_412 any = A_arbace_cpp_inline_A_const_57.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_414 lang.IFn

			if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = x__0; if linked_413 == nil { tmp3 = ifn_414.Invoke_O__O(arg_415) } else { tmp3 = linked_413.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_412, arg_415) }
//line :90:1
			if jrt.J2g_Truth(tmp3) {

				var root_416 any = A_arbace_cpp_inline_A_const_58.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any; var fnbody__428 any = A_arbace_cpp_inline_remap_fn__113000057_A_New_O_O(m__1, rn__2); var tmp4 *jrt.Class; var fncls__427 *jrt.Class = A_arbace_cpp_inline_remap_fn__113000057_A_fn_class; if fncls__427 == nil { var fncls__427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__428); A_arbace_cpp_inline_remap_fn__113000057_A_fn_class = fncls__427d; tmp4 = fncls__427d } else { tmp4 = fncls__427 }; arg_419 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__428, tmp4, nil); var arg_420 any = x__0; if linked_417 == nil { return ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { return linked_417.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_416, arg_419, arg_420) } } else {
//line :90:1
					var tmp5 any; var root_429 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_431 lang.IFn


					if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = x__0; if linked_430 == nil { tmp5 = ifn_431.Invoke_O__O(arg_432) } else { tmp5 = linked_430.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_429, arg_432) }
//line :90:1
					if jrt.J2g_Truth(tmp5) {


						var root_433 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = A_arbace_cpp_inline_A_const_32.GetRawRoot__O(); var arg_437 any; var root_438 any = A_arbace_cpp_inline_A_const_60.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any; var fnbody__450 any = A_arbace_cpp_inline_remap_fn__113000059_A_New_O_O(m__1, rn__2); var tmp6 *jrt.Class; var fncls__449 *jrt.Class = A_arbace_cpp_inline_remap_fn__113000059_A_fn_class; if fncls__449 == nil { var fncls__449d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__450); A_arbace_cpp_inline_remap_fn__113000059_A_fn_class = fncls__449d; tmp6 = fncls__449d } else { tmp6 = fncls__449 }; arg_441 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__450, tmp6, nil); var arg_442 any = x__0; if linked_439 == nil { arg_437 = ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { arg_437 = linked_439.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) }; if linked_434 == nil { return ifn_435.Invoke_O_O__O(arg_436, arg_437) } else { return linked_434.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_433, arg_436, arg_437) } } else {
//line :90:1
							if A_arbace_cpp_inline_A_const_17 != nil { return x__0 } else { return nil
							} } } } }
func A_arbace_cpp_inline_remap_fn__113000057_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_remap_fn__113000057_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_remap_fn__113000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :92:1
func (t *A_arbace_cpp_inline_remap_fn__113000057_A) Ctor_O_O(c__m, c__rn any) { t.F_m = c__m; t.F_rn = c__rn }
//line :92:1
func (t *A_arbace_cpp_inline_remap_fn__113000057_A) Invoke_O_O__O(self, p1__113000055_SHARP___1 any) any { var root_421 any = A_arbace_cpp_inline_A_const_59.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, A_arbace_cpp_inline_remap_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = p1__113000055_SHARP___1; var arg_425 any = t.F_m; var arg_426 any = t.F_rn; if linked_422 == nil { return ifn_423.Invoke_O_O_O__O(arg_424, arg_425, arg_426) } else { return linked_422.(*A_arbace_cpp_inline_remap_A).Invoke_O_O_O_O__O(root_421, arg_424, arg_425, arg_426) } }
func A_arbace_cpp_inline_remap_fn__113000059_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_remap_fn__113000059_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_remap_fn__113000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_cpp_inline_remap_fn__113000059_A) Ctor_O_O(c__m, c__rn any) { t.F_m = c__m; t.F_rn = c__rn }
//line :93:1
func (t *A_arbace_cpp_inline_remap_fn__113000059_A) Invoke_O_O__O(self, p1__113000056_SHARP___1 any) any { var root_443 any = A_arbace_cpp_inline_A_const_59.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, A_arbace_cpp_inline_remap_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = p1__113000056_SHARP___1; var arg_447 any = t.F_m; var arg_448 any = t.F_rn; if linked_444 == nil { return ifn_445.Invoke_O_O_O__O(arg_446, arg_447, arg_448) } else { return linked_444.(*A_arbace_cpp_inline_remap_A).Invoke_O_O_O_O__O(root_443, arg_446, arg_447, arg_448) } }


func A_arbace_cpp_inline_may_throw_QMARK__A_New() *A_arbace_cpp_inline_may_throw_QMARK__A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_may_throw_QMARK__A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_cpp_inline_may_throw_QMARK__A) Ctor() {}
//line :96:1
func (t *A_arbace_cpp_inline_may_throw_QMARK__A) Invoke_O_O_O__O(self, o__0, nounwind_fns__1 any) any { var n__3 any; var root_451 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, A_arbace_cpp_inline_gname_A_fn_class); var ifn_453 lang.IFn; if



	linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = lang.RT_Nth_O_I__O_NoInit(o__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_452 == nil { n__3 = ifn_453.Invoke_O__O(arg_454) } else { n__3 = linked_452.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_451, arg_454) }; var os__4 any; var root_455 any = /*line :96:1*/A_arbace_cpp_inline_A_const_61.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_455, A_arbace_cpp_inline_opts_of_A_fn_class); var ifn_457 lang.IFn; if




	linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = o__0; if linked_456 == nil { os__4 = ifn_457.Invoke_O_O__O(arg_458, A_arbace_cpp_inline_A_const_62) } else { os__4 = linked_456.(*A_arbace_cpp_inline_opts_of_A).InvokePrim_O_O_J__O(root_455, arg_458, 4) }; var root_460 any =
	A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any; var or__1927000174__auto____5 any; var root_464 any = A_arbace_cpp_inline_A_const_63.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, A_arbace_cpp_inline_attrs_have_QMARK__A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = A_arbace_cpp_inline_A_const_64.Invoke_O__O(os__4); var arg_468 any = A_arbace_cpp_inline_A_const_65; if linked_465 == nil { or__1927000174__auto____5 = ifn_466.Invoke_O_O__O(arg_467, arg_468) } else { or__1927000174__auto____5 = linked_465.(*A_arbace_cpp_inline_attrs_have_QMARK__A).Invoke_O_O_O__O(root_464, arg_467, arg_468) }; if jrt.J2g_Truth(or__1927000174__auto____5) { arg_463 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var and__1927000168__auto____6 any = n__3
		if jrt.J2g_Truth(and__1927000168__auto____6) { var root_469 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = nounwind_fns__1; var arg_473 any = n__3; if linked_470 == nil { or__1927000174__auto____6 = ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { or__1927000174__auto____6 = linked_470.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_469, arg_472, arg_473) } } else { or__1927000174__auto____6 = and__1927000168__auto____6 }
//line :102:1
		if jrt.J2g_Truth(or__1927000174__auto____6) { arg_463 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 any
			var and__1927000168__auto____7 any = n__3
			if jrt.J2g_Truth(and__1927000168__auto____7) { var root_474 any = A_arbace_cpp_inline_A_const_18.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = n__3; var arg_478 any = Lit_71; if linked_475 == nil { or__1927000174__auto____7 = ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { or__1927000174__auto____7 = linked_475.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_474, arg_477, arg_478) } } else { or__1927000174__auto____7 = and__1927000168__auto____7 }
//line :102:1
			if jrt.J2g_Truth(or__1927000174__auto____7) { arg_463 = or__1927000174__auto____7 } else { var and__1927000168__auto____8 any; var root_479 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_481 lang.IFn


				if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = lang.RT_Nth_O_I__O_NoInit(o__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_480 == nil { and__1927000168__auto____8 = ifn_481.Invoke_O__O(arg_482) } else { and__1927000168__auto____8 = linked_480.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_479, arg_482) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp1 any = A_arbace_cpp_inline_A_const_66; var tmp2 any; var root_483 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = lang.RT_Nth_O_I__O_NoInit(o__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_484 == nil { tmp2 = ifn_485.Invoke_O__O(arg_486) } else { tmp2 = linked_484.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_483, arg_486) }; arg_463 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { arg_463 = and__1927000168__auto____8 } } } }; if /*line :102:1*/ linked_461 == nil { return ifn_462.Invoke_O__O(arg_463) } else { return linked_461.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_460, arg_463) } }











func A_arbace_cpp_inline_inline_site_A_New() *A_arbace_cpp_inline_inline_site_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_cpp_inline_inline_site_A) Ctor() {}
//line :114:1
func (t *A_arbace_cpp_inline_inline_site_A) Invoke_O_O_O_O_O_O_O__O(self, label__0, pre__1, call__2, post__3, d__4, nounwind_fns__5 any) any { var k__7 any; var root_487 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_489 lang.IFn; if





	linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = A_arbace_cpp_inline_A_const_68.GetRawRoot__O(); var arg_491 any = A_arbace_cpp_inline_A_const_69.GetRawRoot__O(); if linked_488 == nil { k__7 = ifn_489.Invoke_O_O__O(arg_490, arg_491) } else { k__7 = linked_488.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_487, arg_490, arg_491) }; var sfx__8 any = /*line :114:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__7)).Ref(); var rn__9 any; var fnbody__501 any = A_arbace_cpp_inline_inline_site_rn__113000074_A_New_O(sfx__8); var tmp1 *jrt.Class; var fncls__500 *jrt.Class = A_arbace_cpp_inline_inline_site_rn__113000074_A_fn_class; if







	fncls__500 == nil { var fncls__500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__501); A_arbace_cpp_inline_inline_site_rn__113000074_A_fn_class = fncls__500d; tmp1 = fncls__500d } else { tmp1 = fncls__500 }; rn__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__501, tmp1, nil); var o__10 any; var root_502 any = /*line :114:1*/A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_504 lang.IFn; if








	linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = call__2; if linked_503 == nil { o__10 = ifn_504.Invoke_O__O(arg_505) } else { o__10 = linked_503.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_502, arg_505) }; var res__11 any; var root_506 any = /*line :114:1*/A_arbace_cpp_inline_A_const_71.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, A_arbace_cpp_inline_inst_def_A_fn_class); var ifn_508 lang.IFn; if









	linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = call__2; if linked_507 == nil { res__11 = ifn_508.Invoke_O__O(arg_509) } else { res__11 = linked_507.(*A_arbace_cpp_inline_inst_def_A).Invoke_O_O__O(root_506, arg_509) }; var invoke_QMARK___12 bool; var tmp2 any = A_arbace_cpp_inline_A_const_72; var tmp3 any; var root_510 any = /*line :114:1*/A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, A_arbace_cpp_inline_head_A_fn_class); var ifn_512 lang.IFn; if










	linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = o__10; if linked_511 == nil { tmp3 = ifn_512.Invoke_O__O(arg_513) } else { tmp3 = linked_511.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_510, arg_513) }; invoke_QMARK___12 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); var vec__113000068__13 any = o__10; var ___14 any = /*line :114:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__113000068__13, lang.RT_IntCast_J__I_NoInit(0), nil); var rt__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000068__13, lang.RT_IntCast_J__I_NoInit(1), nil); var ___16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000068__13, lang.RT_IntCast_J__I_NoInit(2), nil); var args__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000068__13, lang.RT_IntCast_J__I_NoInit(3), nil); var os__18 any; var root_514 any = A_arbace_cpp_inline_A_const_61.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_514, A_arbace_cpp_inline_opts_of_A_fn_class); var ifn_516 lang.IFn; _ = ___14; _ = ___16; if












	linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = o__10; if linked_515 == nil { os__18 = ifn_516.Invoke_O_O__O(arg_517, A_arbace_cpp_inline_A_const_62) } else { os__18 = linked_515.(*A_arbace_cpp_inline_opts_of_A).InvokePrim_O_O_J__O(root_514, arg_517, 4) }; var vec__113000071__19 any = d__4; var ___20 any = /*line :114:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__113000071__19, lang.RT_IntCast_J__I_NoInit(0), nil); var ___21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000071__19, lang.RT_IntCast_J__I_NoInit(1), nil); var crt__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000071__19, lang.RT_IntCast_J__I_NoInit(2), nil); var ps__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000071__19, lang.RT_IntCast_J__I_NoInit(3), nil); var dopts__24 any; var root_519 any = A_arbace_cpp_inline_A_const_50.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, A_arbace_cpp_inline_define_opts_A_fn_class); var ifn_521 lang.IFn; _ = ___20; _ = ___21; _ = crt__22; if














	linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = d__4; if linked_520 == nil { dopts__24 = ifn_521.Invoke_O__O(arg_522) } else { dopts__24 = linked_520.(*A_arbace_cpp_inline_define_opts_A).Invoke_O_O__O(root_519, arg_522) }; var cblocks__25 any = /*line :114:1*/A_arbace_cpp_inline_A_const_28.Invoke_O__O(dopts__24); var byvals__26 any; var root_523 any = A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_525 lang.IFn; if

















	linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = lang.PersistentVector_EMPTY.Ref(); if linked_524 == nil { byvals__26 = ifn_525.Invoke_O__O(arg_526) } else { byvals__26 = linked_524.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_523, arg_526) }; var copies__27 any; var root_527 any = /*line :114:1*/A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_529 lang.IFn; if


















	linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = lang.PersistentVector_EMPTY.Ref(); if linked_528 == nil { copies__27 = ifn_529.Invoke_O__O(arg_530) } else { copies__27 = linked_528.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_527, arg_530) }; var amap__28 any; var root_531 any = /*line :114:1*/A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_533 lang.IFn; if



















	linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_535 any; var root_536 any = A_arbace_cpp_inline_A_const_60.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any; var fnbody__621 any = A_arbace_cpp_inline_inline_site_fn__113000076_A_New_O_O_O(byvals__26, rn__9, copies__27); var tmp4 *jrt.Class; var fncls__620 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000076_A_fn_class; if fncls__620 == nil { var fncls__620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__621); A_arbace_cpp_inline_inline_site_fn__113000076_A_fn_class = fncls__620d; tmp4 = fncls__620d } else { tmp4 = fncls__620 }; arg_539 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__621, tmp4, nil); var arg_540 any = ps__23; var arg_541 any = args__17; if linked_537 == nil { arg_535 = ifn_538.Invoke_O_O_O__O(arg_539, arg_540, arg_541) } else { arg_535 = linked_537.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_536, arg_539, arg_540, arg_541) }; if linked_532 == nil { amap__28 = ifn_533.Invoke_O_O__O(arg_534, arg_535) } else { amap__28 = linked_532.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_531, arg_534, arg_535) }; var entry_label__29 any; var l__29 any; var root_622 any = /*line :114:1*/A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_624 lang.IFn; if






























	linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any; var root_626 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = cblocks__25; if linked_627 == nil { arg_625 = ifn_628.Invoke_O__O(arg_629) } else { arg_625 = linked_627.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_626, arg_629) }; if linked_623 == nil { l__29 = ifn_624.Invoke_O__O(arg_625) } else { l__29 = linked_623.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(l__29) { entry_label__29 = lang.IFn_Cast(rn__9).Invoke_O__O(l__29) } else { var root_630 any = A_arbace_cpp_inline_A_const_70.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, sfx__8)).Ref(); if linked_631 == nil { entry_label__29 = ifn_632.Invoke_O__O(arg_633) } else { entry_label__29 = linked_631.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_630, arg_633) } }; var cl__30 any; var fnbody__635 any = /*line :114:1*/A_arbace_cpp_inline_inline_site_cl__113000082_A_New_O_O(entry_label__29, rn__9); var tmp5 *jrt.Class; var fncls__634 *jrt.Class = A_arbace_cpp_inline_inline_site_cl__113000082_A_fn_class; if































	fncls__634 == nil { var fncls__634d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__635); A_arbace_cpp_inline_inline_site_cl__113000082_A_fn_class = fncls__634d; tmp5 = fncls__634d } else { tmp5 = fncls__634 }; cl__30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__635, tmp5, nil); var cloned__31 any; var root_636 any = /*line :114:1*/A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_638 lang.IFn; if

































	linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any; var root_640 any = A_arbace_cpp_inline_A_const_90.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any; var fnbody__683 any = A_arbace_cpp_inline_inline_site_fn__113000084_A_New_O_O_O_O(entry_label__29, cl__30, rn__9, amap__28); var tmp6 *jrt.Class; var fncls__682 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000084_A_fn_class; if
	fncls__682 == nil { var fncls__682d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__683); A_arbace_cpp_inline_inline_site_fn__113000084_A_fn_class = fncls__682d; tmp6 = fncls__682d } else { tmp6 = fncls__682 }; arg_643 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__683, tmp6, nil); var arg_644 any = cblocks__25; if /*line :148:1*/ linked_641 == nil { arg_639 = ifn_642.Invoke_O_O__O(arg_643, arg_644) } else { arg_639 = linked_641.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_640, arg_643, arg_644) }; if linked_637 == nil { cloned__31 = ifn_638.Invoke_O__O(arg_639) } else { cloned__31 = linked_637.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_636, arg_639) }; var allocas__32 any; var root_684 any = /*line :114:1*/A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_686 lang.IFn; if







































	linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any; var root_688 any = A_arbace_cpp_inline_A_const_91.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any; var fnbody__702 any = A_arbace_cpp_inline_inline_site_fn__113000089_A_New(); var tmp7 *jrt.Class; var fncls__701 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000089_A_fn_class; if fncls__701 == nil { var fncls__701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_cpp_inline_inline_site_fn__113000089_A_fn_class = fncls__701d; tmp7 = fncls__701d } else { tmp7 = fncls__701 }; arg_691 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__702, tmp7, nil); var arg_692 any; var root_703 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any; var root_707 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = cloned__31; if linked_708 == nil { arg_706 = ifn_709.Invoke_O__O(arg_710) } else { arg_706 = linked_708.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_707, arg_710) }; if linked_704 == nil { arg_692 = ifn_705.Invoke_O__O(arg_706) } else { arg_692 = linked_704.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_703, arg_706) }; if linked_689 == nil { arg_687 = ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { arg_687 = linked_689.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) }; if linked_685 == nil { allocas__32 = ifn_686.Invoke_O__O(arg_687) } else { allocas__32 = linked_685.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_684, arg_687) }; var cloned__33 any; var root_711 any = /*line :114:1*/A_arbace_cpp_inline_A_const_27.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_713 lang.IFn; if








































	linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = cloned__31; var arg_715 any = A_arbace_cpp_inline_A_const_31; var arg_716 any; var root_717 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any; var tmp8 any; var root_722 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any; var root_726 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = cloned__31; if linked_727 == nil { arg_725 = ifn_728.Invoke_O__O(arg_729) } else { arg_725 = linked_727.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_726, arg_729) }; if linked_723 == nil { tmp8 = ifn_724.Invoke_O__O(arg_725) } else { tmp8 = linked_723.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_722, arg_725) }; arg_720 = lang.Tuple_Create_O__IPersistentVector(tmp8); var arg_721 any; var root_730 any = A_arbace_cpp_inline_A_const_29.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any; var root_735 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = copies__27; if linked_736 == nil { arg_733 = ifn_737.Invoke_O__O(arg_738) } else { arg_733 = linked_736.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_735, arg_738) }; var arg_734 any; var root_739 any = A_arbace_cpp_inline_A_const_93.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any; var fnbody__753 any = A_arbace_cpp_inline_inline_site_fn__113000091_A_New(); var tmp9 *jrt.Class; var fncls__752 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000091_A_fn_class; if fncls__752 == nil { var fncls__752d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); A_arbace_cpp_inline_inline_site_fn__113000091_A_fn_class = fncls__752d; tmp9 = fncls__752d } else { tmp9 = fncls__752 }; arg_742 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__753, tmp9, nil); var arg_743 any; var root_754 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any; var root_758 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_760 lang.IFn; if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = cloned__31; if linked_759 == nil { arg_757 = ifn_760.Invoke_O__O(arg_761) } else { arg_757 = linked_759.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_758, arg_761) }; if linked_755 == nil { arg_743 = ifn_756.Invoke_O__O(arg_757) } else { arg_743 = linked_755.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_754, arg_757) }; if linked_740 == nil { arg_734 = ifn_741.Invoke_O_O__O(arg_742, arg_743) } else { arg_734 = linked_740.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_739, arg_742, arg_743) }; if linked_731 == nil { arg_721 = ifn_732.Invoke_O_O__O(arg_733, arg_734) } else { arg_721 = linked_731.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_730, arg_733, arg_734) }; if linked_718 == nil { arg_716 = ifn_719.Invoke_O_O__O(arg_720, arg_721) } else { arg_716 = linked_718.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_717, arg_720, arg_721) }; if linked_712 == nil { cloned__33 = ifn_713.Invoke_O_O_O__O(arg_714, arg_715, arg_716) } else { cloned__33 = linked_712.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_711, arg_714, arg_715, arg_716) }; var after__34 any; var root_762 any = /*line :114:1*/A_arbace_cpp_inline_A_const_70.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_764 lang.IFn; if









































	linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_61, nil); var tmp11 any; if jrt.J2g_Truth(label__0) { var root_766 any = A_arbace_cpp_inline_A_const_95.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any; var root_771 any = A_arbace_cpp_inline_A_const_11.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = label__0; if linked_772 == nil { arg_769 = ifn_773.Invoke_O__O(arg_774) } else { arg_769 = linked_772.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_771, arg_774) }; var arg_770 any = A_arbace_cpp_inline_A_const_96; if linked_767 == nil { tmp11 = ifn_768.Invoke_O_O__O(arg_769, arg_770) } else { tmp11 = linked_767.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_766, arg_769, arg_770) } } else { tmp11 = Lit_62 }; arg_765 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, nil, sfx__8)).Ref(); if linked_763 == nil { after__34 = ifn_764.Invoke_O__O(arg_765) } else { after__34 = linked_763.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_762, arg_765) }; var rets__35 any; var root_775 any = /*line :114:1*/A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_777 lang.IFn; if










































	linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any = lang.PersistentVector_EMPTY.Ref(); if linked_776 == nil { rets__35 = ifn_777.Invoke_O__O(arg_778) } else { rets__35 = linked_776.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_775, arg_778) }; var cloned__36 any; var root_779 any = /*line :114:1*/A_arbace_cpp_inline_A_const_58.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_781 lang.IFn; if











































	linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any; var fnbody__830 any = A_arbace_cpp_inline_inline_site_fn__113000094_A_New_O_O(rets__35, after__34); var tmp12 *jrt.Class; var fncls__829 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000094_A_fn_class; if fncls__829 == nil { var fncls__829d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__830); A_arbace_cpp_inline_inline_site_fn__113000094_A_fn_class = fncls__829d; tmp12 = fncls__829d } else { tmp12 = fncls__829 }; arg_782 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__830, tmp12, nil); var arg_783 any = cloned__33; if linked_780 == nil { cloned__36 = ifn_781.Invoke_O_O__O(arg_782, arg_783) } else { cloned__36 = linked_780.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_779, arg_782, arg_783) }; var tmp13 any; var or__1927000174__auto____37 bool =






	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_cpp_inline_A_const_100, rt__15); if or__1927000174__auto____37 { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____37).Ref() } else { var or__1927000174__auto____38 bool = lang.Util_Identical_O_O__Z_NoInit(res__11, nil); if or__1927000174__auto____38 { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____38).Ref() } else { var root_831 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any; var root_835 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = rets__35; if linked_836 == nil { arg_834 = ifn_837.Invoke_O__O(arg_838) } else { arg_834 = linked_836.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_835, arg_838) }; if linked_832 == nil { tmp13 = ifn_833.Invoke_O__O(arg_834) } else { tmp13 = linked_832.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_831, arg_834) } } }; if jrt.J2g_Truth(tmp13) { var phi__37 any; var tmp14 any; var and__1927000168__auto____37 any = res__11
		if jrt.J2g_Truth(and__1927000168__auto____37) { var root_839 any = A_arbace_cpp_inline_A_const_101.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any = A_arbace_cpp_inline_A_const_102; var arg_843 any = rt__15; if linked_840 == nil { tmp14 = ifn_841.Invoke_O_O__O(arg_842, arg_843) } else { tmp14 = linked_840.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_839, arg_842, arg_843) } } else { tmp14 = and__1927000168__auto____37 }; if jrt.J2g_Truth(tmp14) { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp16 any = A_arbace_cpp_inline_A_const_128; var tmp17 any; var root_1117 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = A_arbace_cpp_inline_A_const_32.GetRawRoot__O(); var arg_1121 any = A_arbace_cpp_inline_A_const_129; var arg_1122 any = rt__15; var arg_1123 any; var root_1124 any = A_arbace_cpp_inline_A_const_60.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any; var fnbody__1130 any = A_arbace_cpp_inline_inline_site_fn__113000100_A_New(); var tmp18 *jrt.Class; var fncls__1129 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000100_A_fn_class; if fncls__1129 == nil { var fncls__1129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, nil); A_arbace_cpp_inline_inline_site_fn__113000100_A_fn_class = fncls__1129d; tmp18 = fncls__1129d } else { tmp18 = fncls__1129 }; arg_1127 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1130, tmp18, nil); var arg_1128 any; var root_1131 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = rets__35; if linked_1132 == nil { arg_1128 = ifn_1133.Invoke_O__O(arg_1134) } else { arg_1128 = linked_1132.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1131, arg_1134) }; if linked_1125 == nil { arg_1123 = ifn_1126.Invoke_O_O__O(arg_1127, arg_1128) } else { arg_1123 = linked_1125.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1124, arg_1127, arg_1128) }; if linked_1118 == nil { tmp17 = ifn_1119.Invoke_O_O_O_O__O(arg_1120, arg_1121, arg_1122, arg_1123) } else { tmp17 = linked_1118.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1117, arg_1120, arg_1121, arg_1122, arg_1123) }; phi__37 = tmp15.Invoke_O_O_O__O(tmp16, res__11, tmp17) } else { phi__37 = nil }
//line :165:1
		var tail__38 any


		if invoke_QMARK___12 { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp20 any = A_arbace_cpp_inline_A_const_130; tail__38 = lang.Tuple_Create_O__IPersistentVector(tmp19.Invoke_O_O__O(tmp20, A_arbace_cpp_inline_A_const_110.Invoke_O__O(os__18))) } else { var root_844 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = post__3; if linked_845 == nil { tail__38 = ifn_846.Invoke_O__O(arg_847) } else { tail__38 = linked_845.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_844, arg_847) } }
//line :165:1
		var unwind__39 any = A_arbace_cpp_inline_A_const_103.Invoke_O__O(os__18); var splits__40 any; var root_848 any = A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_850 lang.IFn




		if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_849 == nil { splits__40 = ifn_850.Invoke_O__O(arg_851) } else { splits__40 = linked_849.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_848, arg_851) }
//line :165:1
		var resumes__41 any; var root_852 any = A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_854 lang.IFn





		if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = lang.PersistentVector_EMPTY.Ref(); if linked_853 == nil { resumes__41 = ifn_854.Invoke_O__O(arg_855) } else { resumes__41 = linked_853.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_852, arg_855) }
//line :165:1
		var cloned__42 any; var tmp21 any; var root_856 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_858 lang.IFn






		if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(invoke_QMARK___12).Ref(); if linked_857 == nil { tmp21 = ifn_858.Invoke_O__O(arg_859) } else { tmp21 = linked_857.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_856, arg_859) }; if jrt.J2g_Truth(tmp21) { cloned__42 = cloned__36 } else {

			var root_860 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_104.GetRawRoot__O()); var tmp23 *lang.Compiler_AOTFn; var fnbody__1027 any = A_arbace_cpp_inline_inline_site_fn__113000106_A_New_O_O_O_O(nounwind_fns__5, splits__40, unwind__39, resumes__41); var tmp24 *jrt.Class; var fncls__1026 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000106_A_fn_class
			if fncls__1026 == nil { var fncls__1026d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__1027); A_arbace_cpp_inline_inline_site_fn__113000106_A_fn_class = fncls__1026d; tmp24 = fncls__1026d } else { tmp24 = fncls__1026 }; tmp23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1027, tmp24, nil)
//line :174:1
			arg_863 = tmp22.Invoke_O_O__O(tmp23.Ref(), cloned__36); if linked_861 == nil { cloned__42 = ifn_862.Invoke_O__O(arg_863) } else { cloned__42 = linked_861.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_860, arg_863) } }
//line :165:1
		var tmp25 any = A_arbace_cpp_inline_A_const_117; var tmp26 any; var root_1028 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1030 lang.IFn





























		if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_29.GetRawRoot__O()); var tmp28 any; var root_1038 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = lang.Tuple_Create_O__IPersistentVector(label__0); var arg_1042 any; var root_1043 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any; var root_1048 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = pre__1; if linked_1049 == nil { arg_1046 = ifn_1050.Invoke_O__O(arg_1051) } else { arg_1046 = linked_1049.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1048, arg_1051) }; var arg_1047 any = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_inline_A_const_118, entry_label__29); if linked_1044 == nil { arg_1042 = ifn_1045.Invoke_O_O__O(arg_1046, arg_1047) } else { arg_1042 = linked_1044.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1043, arg_1046, arg_1047) }; if linked_1039 == nil { tmp28 = ifn_1040.Invoke_O_O__O(arg_1041, arg_1042) } else { tmp28 = linked_1039.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1038, arg_1041, arg_1042) }; var tmp29 any = lang.Tuple_Create_O__IPersistentVector(tmp28); var tmp30 any; var root_1052 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1054 lang.IFn

		if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = lang.Tuple_Create_O__IPersistentVector(after__34); var arg_1056 any; var root_1057 any = A_arbace_cpp_inline_A_const_29.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any; if jrt.J2g_Truth(phi__37) { arg_1060 = lang.Tuple_Create_O__IPersistentVector(phi__37) } else { arg_1060 = nil }; var arg_1061 any = tail__38; if linked_1058 == nil { arg_1056 = ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { arg_1056 = linked_1058.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) }; if linked_1053 == nil { tmp30 = ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { tmp30 = linked_1053.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) }
//line :195:1
		arg_1031 = tmp27.Invoke_O_O_O__O(tmp29, cloned__42, lang.Tuple_Create_O__IPersistentVector(tmp30)); if linked_1029 == nil { tmp26 = ifn_1030.Invoke_O__O(arg_1031) } else { tmp26 = linked_1029.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1028, arg_1031) }
//line :165:1
		var tmp31 any = tmp26; var tmp32 any = A_arbace_cpp_inline_A_const_119; var tmp33 any; var root_1062 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1064 lang.IFn
































		if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any; var root_1067 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = byvals__26; if linked_1068 == nil { arg_1065 = ifn_1069.Invoke_O__O(arg_1070) } else { arg_1065 = linked_1068.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1067, arg_1070) }; var arg_1066 any = allocas__32; if linked_1063 == nil { tmp33 = ifn_1064.Invoke_O_O__O(arg_1065, arg_1066) } else { tmp33 = linked_1063.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1062, arg_1065, arg_1066) }
//line :165:1
		var tmp34 any = tmp33; var tmp35 any = A_arbace_cpp_inline_A_const_120; var tmp36 any = A_arbace_cpp_inline_A_const_121; var tmp37 any; var root_1071 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1073 lang.IFn
		if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = splits__40; if linked_1072 == nil { tmp37 = ifn_1073.Invoke_O__O(arg_1074) } else { tmp37 = linked_1072.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1071, arg_1074) }
//line :165:1
		var tmp38 any = tmp37; var tmp39 any = A_arbace_cpp_inline_A_const_122; var tmp40 any; var root_1075 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1077 lang.IFn
		if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = resumes__41; if linked_1076 == nil { tmp40 = ifn_1077.Invoke_O__O(arg_1078) } else { tmp40 = linked_1076.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1075, arg_1078) }
//line :165:1
		var tmp41 any = tmp40; var tmp42 any = A_arbace_cpp_inline_A_const_103; var tmp43 any




































		if invoke_QMARK___12 { tmp43 = unwind__39 } else { tmp43 = nil }
//line :165:1
		var tmp44 any = tmp43; var tmp45 any = A_arbace_cpp_inline_A_const_123; var tmp46 any





































		if invoke_QMARK___12 { var root_1079 any = A_arbace_cpp_inline_A_const_124.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any; var root_1083 any = A_arbace_cpp_inline_A_const_125.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any; var fnbody__1116 any = A_arbace_cpp_inline_inline_site_fn__113000112_A_New(); var tmp47 *jrt.Class; var fncls__1115 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000112_A_fn_class; if fncls__1115 == nil { var fncls__1115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); A_arbace_cpp_inline_inline_site_fn__113000112_A_fn_class = fncls__1115d; tmp47 = fncls__1115d } else { tmp47 = fncls__1115 }; arg_1086 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1116, tmp47, nil); var arg_1087 any = cloned__42; if linked_1084 == nil { arg_1082 = ifn_1085.Invoke_O_O__O(arg_1086, arg_1087) } else { arg_1082 = linked_1084.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1083, arg_1086, arg_1087) }; if linked_1080 == nil { tmp46 = ifn_1081.Invoke_O__O(arg_1082) } else { tmp46 = linked_1080.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1079, arg_1082) } } else { tmp46 = nil }
//line :165:1
		var tmp48 any = tmp46; var tmp49 any = A_arbace_cpp_inline_A_const_127; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp31, tmp32, tmp34, tmp35, after__34, tmp36, tmp38, tmp39, tmp41, tmp42, tmp44, tmp45, tmp48, tmp49, A_arbace_cpp_inline_A_const_127.Invoke_O__O(dopts__24))) } else { return nil } }
//line :122:1
func A_arbace_cpp_inline_inline_site_rn__113000074_A_New_O(p0 any) *A_arbace_cpp_inline_inline_site_rn__113000074_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_rn__113000074_A{}; t.Ctor_O(p0); return t }
//line :122:1
func (t *A_arbace_cpp_inline_inline_site_rn__113000074_A) Ctor_O(c__sfx any) { t.F_sfx = c__sfx }
//line :122:1
func (t *A_arbace_cpp_inline_inline_site_rn__113000074_A) Invoke_O_O__O(self, s__1 any) any { var root_492 any = A_arbace_cpp_inline_A_const_70.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_496 any = A_arbace_cpp_inline_A_const_11.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = s__1; if linked_497 == nil { tmp2 = ifn_498.Invoke_O__O(arg_499) } else { tmp2 = linked_497.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_496, arg_499) }; arg_495 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, t.F_sfx)).Ref(); if linked_493 == nil { return ifn_494.Invoke_O__O(arg_495) } else { return linked_493.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_492, arg_495) } }











func A_arbace_cpp_inline_inline_site_fn__113000076_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_inline_inline_site_fn__113000076_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000076_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :134:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000076_A) Ctor_O_O_O(c__byvals, c__rn, c__copies any) { t.F_byvals = c__byvals; t.F_rn = c__rn; t.F_copies = c__copies }
//line :134:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000076_A) Invoke_O_O_O__O(self, p__1, a__2 any) any { var pn__3 any; var root_542 any = A_arbace_cpp_inline_A_const_75.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_544 lang.IFn; if
													linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = p__1; if linked_543 == nil { pn__3 = ifn_544.Invoke_O__O(arg_545) } else { pn__3 = linked_543.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_542, arg_545) }; var av__4 any; var root_546 any = /*line :134:1*/A_arbace_cpp_inline_A_const_75.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_548 lang.IFn; if
													linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = a__2; if linked_547 == nil { av__4 = ifn_548.Invoke_O__O(arg_549) } else { av__4 = linked_547.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_546, arg_549) }; var bv__5 any; var root_550 any = /*line :134:1*/A_arbace_cpp_inline_A_const_35.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_552 lang.IFn; if

	linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any; var fnbody__568 any = A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A_New(); var tmp1 *jrt.Class; var fncls__567 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A_fn_class; if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A_fn_class = fncls__567d; tmp1 = fncls__567d } else { tmp1 = fncls__567 }; arg_553 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__568, tmp1, nil); var arg_554 any; var root_569 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any; var root_573 any = A_arbace_cpp_inline_A_const_77.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = p__1; if linked_574 == nil { arg_572 = ifn_575.Invoke_O__O(arg_576) } else { arg_572 = linked_574.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_573, arg_576) }; if linked_570 == nil { arg_554 = ifn_571.Invoke_O__O(arg_572) } else { arg_554 = linked_570.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_569, arg_572) }; if linked_551 == nil { bv__5 = ifn_552.Invoke_O_O__O(arg_553, arg_554) } else { bv__5 = linked_551.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_550, arg_553, arg_554) }; if
	jrt.J2g_Truth(bv__5) { var al__6 any; var or__1927000174__auto____6 any; var root_577 any = A_arbace_cpp_inline_A_const_35.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_579 lang.IFn
		if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any; var fnbody__595 any = A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A_New(); var tmp2 *jrt.Class; var fncls__594 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A_fn_class; if fncls__594 == nil { var fncls__594d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A_fn_class = fncls__594d; tmp2 = fncls__594d } else { tmp2 = fncls__594 }; arg_580 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__595, tmp2, nil); var arg_581 any; var root_596 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any; var root_600 any = A_arbace_cpp_inline_A_const_77.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = p__1; if linked_601 == nil { arg_599 = ifn_602.Invoke_O__O(arg_603) } else { arg_599 = linked_601.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_600, arg_603) }; if linked_597 == nil { arg_581 = ifn_598.Invoke_O__O(arg_599) } else { arg_581 = linked_597.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_596, arg_599) }; if linked_578 == nil { or__1927000174__auto____6 = ifn_579.Invoke_O_O__O(arg_580, arg_581) } else { or__1927000174__auto____6 = linked_578.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_577, arg_580, arg_581) }; if jrt.J2g_Truth(or__1927000174__auto____6) { al__6 = or__1927000174__auto____6 } else { al__6 = A_arbace_cpp_inline_A_const_79 }
//line :137:1
		var t__7 any = lang.IFn_Cast(t.F_rn).Invoke_O__O(pn__3); var root_604 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_606 lang.IFn


		if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = t.F_byvals; var arg_608 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp4 any = A_arbace_cpp_inline_A_const_80; var arg_609 any = tmp3.Invoke_O_O_O__O(tmp4, t__7, lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_cpp_inline_A_const_81, bv__5, A_arbace_cpp_inline_A_const_78, al__6)); if linked_605 == nil { ifn_606.Invoke_O_O_O__O(arg_607, arg_608, arg_609) } else { linked_605.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_604, arg_607, arg_608, arg_609) }
		var root_610 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = t.F_copies; var arg_614 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var arg_615 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp6 any = A_arbace_cpp_inline_A_const_82; var tmp7 any = A_arbace_cpp_inline_A_const_83; var tmp8 any = A_arbace_cpp_inline_A_const_84; var tmp9 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_inline_A_const_86, t__7); var tmp10 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_cpp_inline_A_const_87, av__4); var tmp11 any = A_arbace_cpp_inline_A_const_88; var tmp12 any; var root_616 any = A_arbace_cpp_inline_A_const_89.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_616, A_arbace_cpp_inline_bv_size_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = bv__5; if linked_617 == nil { tmp12 = ifn_618.Invoke_O__O(arg_619) } else { tmp12 = jrt.Long_ValueOf_J__Long_NoInit(linked_617.(*A_arbace_cpp_inline_bv_size_A).InvokePrim_O_O__J(root_616, arg_619)).Ref() }; arg_615 = tmp5.Invoke_O_O_O_O__O(tmp6, tmp7, tmp8, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp9, tmp10, lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12), A_arbace_cpp_inline_A_const_85)); if linked_611 == nil { ifn_612.Invoke_O_O_O__O(arg_613, arg_614, arg_615) } else { linked_611.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_610, arg_613, arg_614, arg_615) }
//line :137:1
		return lang.Tuple_Create_O_O__IPersistentVector(pn__3, t__7) } else { return lang.Tuple_Create_O_O__IPersistentVector(pn__3, av__4) } }
//line :136:1
func A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A_New() *A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A) Ctor() {}
//line :136:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A) Invoke_O_O__O(self, p1__113000063_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_555 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = p1__113000063_SHARP___1; if linked_556 == nil { and__1927000168__auto____2 = ifn_557.Invoke_O__O(arg_558) } else { and__1927000168__auto____2 = linked_556.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_555, arg_558) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_cpp_inline_A_const_76; var tmp3 any; var root_559 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = p1__113000063_SHARP___1; if linked_560 == nil { tmp3 = ifn_561.Invoke_O__O(arg_562) } else { tmp3 = linked_560.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_559, arg_562) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_563 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = p1__113000063_SHARP___1; if linked_564 == nil { return ifn_565.Invoke_O__O(arg_566) } else { return linked_564.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_563, arg_566) } } else { return nil } }

func A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A_New() *A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A) Ctor() {}
//line :138:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A) Invoke_O_O__O(self, p1__113000064_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_582 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = p1__113000064_SHARP___1; if linked_583 == nil { and__1927000168__auto____2 = ifn_584.Invoke_O__O(arg_585) } else { and__1927000168__auto____2 = linked_583.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_582, arg_585) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_cpp_inline_A_const_78; var tmp3 any; var root_586 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = p1__113000064_SHARP___1; if linked_587 == nil { tmp3 = ifn_588.Invoke_O__O(arg_589) } else { tmp3 = linked_587.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_586, arg_589) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_590 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = p1__113000064_SHARP___1; if linked_591 == nil { return ifn_592.Invoke_O__O(arg_593) } else { return linked_591.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_590, arg_593) } } else { return nil } }







func A_arbace_cpp_inline_inline_site_cl__113000082_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_inline_site_cl__113000082_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_cl__113000082_A{}; t.Ctor_O_O(p0, p1); return t }
//line :146:1
func (t *A_arbace_cpp_inline_inline_site_cl__113000082_A) Ctor_O_O(c__entry_label, c__rn any) { t.F_entry_label = c__entry_label; t.F_rn = c__rn }
//line :146:1
func (t *A_arbace_cpp_inline_inline_site_cl__113000082_A) Invoke_O_O__O(self, l__1 any) any { if lang.Util_Identical_O_O__Z_NoInit(l__1, nil) { return t.F_entry_label } else { return lang.IFn_Cast(t.F_rn).Invoke_O__O(l__1) } }


func A_arbace_cpp_inline_inline_site_fn__113000084_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_inline_inline_site_fn__113000084_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000084_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :149:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000084_A) Ctor_O_O_O_O(c__entry_label, c__cl, c__rn, c__amap any) { t.F_entry_label = c__entry_label; t.F_cl = c__cl; t.F_rn = c__rn; t.F_amap = c__amap }
//line :149:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000084_A) Invoke_O_O_O__O(self, bi__1, b__2 any) any { var vec__113000085__3 any = b__2; var seq__113000086__4 any; var root_645 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_647 lang.IFn; if
													linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = vec__113000085__3; if linked_646 == nil { seq__113000086__4 = ifn_647.Invoke_O__O(arg_648) } else { seq__113000086__4 = linked_646.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_645, arg_648) }; var first__113000087__5 any; var root_649 any = /*line :149:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_651 lang.IFn; if
													linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = seq__113000086__4; if linked_650 == nil { first__113000087__5 = ifn_651.Invoke_O__O(arg_652) } else { first__113000087__5 = linked_650.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_649, arg_652) }; var seq__113000086__6 any; var root_653 any = /*line :149:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_655 lang.IFn; if
													linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = seq__113000086__4; if linked_654 == nil { seq__113000086__6 = ifn_655.Invoke_O__O(arg_656) } else { seq__113000086__6 = linked_654.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_653, arg_656) }; var ___7 any = first__113000087__5; var first__113000087__8 any; var root_657 any = /*line :149:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_659 lang.IFn; _ = ___7; if
													linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = seq__113000086__6; if linked_658 == nil { first__113000087__8 = ifn_659.Invoke_O__O(arg_660) } else { first__113000087__8 = linked_658.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_657, arg_660) }; var seq__113000086__9 any; var root_661 any = /*line :149:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_663 lang.IFn; if
													linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = seq__113000086__6; if linked_662 == nil { seq__113000086__9 = ifn_663.Invoke_O__O(arg_664) } else { seq__113000086__9 = linked_662.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_661, arg_664) }; var l__10 any = first__113000087__8; var is__11 any = seq__113000086__9; var is__12 any; var root_665 any = /*line :149:1*/A_arbace_cpp_inline_A_const_59.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, A_arbace_cpp_inline_remap_A_fn_class); var ifn_667 lang.IFn; if

	linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any; var root_671 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = is__11; if linked_672 == nil { arg_668 = ifn_673.Invoke_O__O(arg_674) } else { arg_668 = linked_672.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_671, arg_674) }; var arg_669 any = t.F_amap; var arg_670 any = t.F_rn; if linked_666 == nil { is__12 = ifn_667.Invoke_O_O_O__O(arg_668, arg_669, arg_670) } else { is__12 = linked_666.(*A_arbace_cpp_inline_remap_A).Invoke_O_O_O_O__O(root_665, arg_668, arg_669, arg_670) }; var root_675 any =
	A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any; var tmp1 any; var tmp2 bool; var na_680 any = bi__1; if jrt.Long_InstanceOf(na_680) { var n0_681 int64 = jrt.NN(jrt.Long_Cast(na_680)).LongValue__J(); tmp2 = n0_681 == 0 } else { if jrt.Double_InstanceOf(na_680) { var n0_681_2 float64 = jrt.NN(jrt.Double_Cast(na_680)).DoubleValue__D(); tmp2 = n0_681_2 == 0.0 } else { tmp2 = lang.Numbers_IsZero_O__Z_NoInit(na_680) } }; if tmp2 { tmp1 = t.F_entry_label } else { tmp1 = lang.IFn_Cast(t.F_cl).Invoke_O__O(l__10) }; arg_678 = lang.Tuple_Create_O__IPersistentVector(tmp1); var arg_679 any = is__12; if linked_676 == nil { return ifn_677.Invoke_O_O__O(arg_678, arg_679) } else { return linked_676.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_675, arg_678, arg_679) } }

func A_arbace_cpp_inline_inline_site_fn__113000089_A_New() *A_arbace_cpp_inline_inline_site_fn__113000089_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000089_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000089_A) Ctor() {}
//line :154:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000089_A) Invoke_O_O__O(self, p1__113000065_SHARP___1 any) any { var tmp1 any = A_arbace_cpp_inline_A_const_92; var tmp2 any; var root_693 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, A_arbace_cpp_inline_head_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any; var root_697 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = p1__113000065_SHARP___1; if linked_698 == nil { arg_696 = ifn_699.Invoke_O__O(arg_700) } else { arg_696 = linked_698.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_697, arg_700) }; if linked_694 == nil { tmp2 = ifn_695.Invoke_O__O(arg_696) } else { tmp2 = linked_694.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_693, arg_696) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_cpp_inline_inline_site_fn__113000091_A_New() *A_arbace_cpp_inline_inline_site_fn__113000091_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000091_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000091_A) Ctor() {}
//line :155:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000091_A) Invoke_O_O__O(self, p1__113000066_SHARP___1 any) any { var tmp1 any = A_arbace_cpp_inline_A_const_94; var tmp2 any; var root_744 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, A_arbace_cpp_inline_head_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any; var root_748 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = p1__113000066_SHARP___1; if linked_749 == nil { arg_747 = ifn_750.Invoke_O__O(arg_751) } else { arg_747 = linked_749.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_748, arg_751) }; if linked_745 == nil { tmp2 = ifn_746.Invoke_O__O(arg_747) } else { tmp2 = linked_745.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_744, arg_747) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }


func A_arbace_cpp_inline_inline_site_fn__113000094_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_inline_site_fn__113000094_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000094_A{}; t.Ctor_O_O(p0, p1); return t }
//line :158:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000094_A) Ctor_O_O(c__rets, c__after any) { t.F_rets = c__rets; t.F_after = c__after }
//line :158:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000094_A) Invoke_O_O__O(self, p__113000093__1 any) any { var vec__113000095__2 any = p__113000093__1; var seq__113000096__3 any; var root_784 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = vec__113000095__2; if linked_785 == nil { seq__113000096__3 = ifn_786.Invoke_O__O(arg_787) } else { seq__113000096__3 = linked_785.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_784, arg_787) }; var first__113000097__4 any; var root_788 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = seq__113000096__3; if linked_789 == nil { first__113000097__4 = ifn_790.Invoke_O__O(arg_791) } else { first__113000097__4 = linked_789.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_788, arg_791) }; var seq__113000096__5 any; var root_792 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = seq__113000096__3; if linked_793 == nil { seq__113000096__5 = ifn_794.Invoke_O__O(arg_795) } else { seq__113000096__5 = linked_793.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_792, arg_795) }; var l__6 any = first__113000097__4; var is__7 any = seq__113000096__5; var t__8 any; var root_796 any = A_arbace_cpp_inline_A_const_97.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_798 lang.IFn; if
													linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = is__7; if linked_797 == nil { t__8 = ifn_798.Invoke_O__O(arg_799) } else { t__8 = linked_797.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_796, arg_799) }; var tmp1 any = A_arbace_cpp_inline_A_const_98; var tmp2 any; var root_800 any =
													A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, A_arbace_cpp_inline_head_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = t__8; if linked_801 == nil { tmp2 = ifn_802.Invoke_O__O(arg_803) } else { tmp2 = linked_801.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_800, arg_803) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) {
														if lang.Util_Equiv_J_J__Z_NoInit(3, int64(lang.RT_Count_O__I_NoInit(t__8))) { var root_823 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = t.F_rets; var arg_827 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var arg_828 any = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(t__8, lang.RT_IntCast_J__I_NoInit(2)), l__6); if linked_824 == nil { ifn_825.Invoke_O_O_O__O(arg_826, arg_827, arg_828) } else { linked_824.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_823, arg_826, arg_827, arg_828) } }
														var root_804 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = lang.Tuple_Create_O__IPersistentVector(l__6); var arg_808 any; var root_809 any = A_arbace_cpp_inline_A_const_29.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any; var root_814 any = A_arbace_cpp_inline_A_const_77.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = is__7; if linked_815 == nil { arg_812 = ifn_816.Invoke_O__O(arg_817) } else { arg_812 = linked_815.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_814, arg_817) }; var arg_813 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_inline_A_const_99, t.F_after)); if linked_810 == nil { arg_808 = ifn_811.Invoke_O_O__O(arg_812, arg_813) } else { arg_808 = linked_810.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_809, arg_812, arg_813) }; if linked_805 == nil { return ifn_806.Invoke_O_O__O(arg_807, arg_808) } else { return linked_805.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_804, arg_807, arg_808) } } else {
															var root_818 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = lang.Tuple_Create_O__IPersistentVector(l__6); var arg_822 any = is__7; if linked_819 == nil { return ifn_820.Invoke_O_O__O(arg_821, arg_822) } else { return linked_819.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_818, arg_821, arg_822) } } }


func A_arbace_cpp_inline_inline_site_fn__113000100_A_New() *A_arbace_cpp_inline_inline_site_fn__113000100_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000100_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000100_A) Ctor() {}
//line :166:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000100_A) Invoke_O_O__O(self, p__113000099__1 any) any { var vec__113000101__2 any = p__113000099__1; var v__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000101__2, lang.RT_IntCast_J__I_NoInit(0), nil); var l__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000101__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(v__3, l__4) }








func A_arbace_cpp_inline_inline_site_fn__113000106_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_inline_inline_site_fn__113000106_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000106_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :175:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000106_A) Ctor_O_O_O_O(c__nounwind_fns, c__splits, c__unwind, c__resumes any) { t.F_nounwind_fns = c__nounwind_fns; t.F_splits = c__splits; t.F_unwind = c__unwind; t.F_resumes = c__resumes }
//line :175:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000106_A) Invoke_O_O__O(self, p__113000105__1 any) any { { var vec__113000107__2 any = p__113000105__1; var seq__113000108__3 any; var root_869 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = vec__113000107__2; if linked_870 == nil { seq__113000108__3 = ifn_871.Invoke_O__O(arg_872) } else { seq__113000108__3 = linked_870.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_869, arg_872) }; var first__113000109__4 any; var root_873 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = seq__113000108__3; if linked_874 == nil { first__113000109__4 = ifn_875.Invoke_O__O(arg_876) } else { first__113000109__4 = linked_874.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_873, arg_876) }; var seq__113000108__5 any; var root_877 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = seq__113000108__3; if linked_878 == nil { seq__113000108__5 = ifn_879.Invoke_O__O(arg_880) } else { seq__113000108__5 = linked_878.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_877, arg_880) }; var l__6 any = first__113000109__4; var is__7 any = seq__113000108__5; var cur__8 any = l__6; var acc__9 any = lang.PersistentVector_EMPTY.Ref(); var is__10 any = is__7; var out__11 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var temp__1927000408__auto____12 any; var root_881 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_883 lang.IFn



	if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = is__10; if linked_882 == nil { temp__1927000408__auto____12 = ifn_883.Invoke_O__O(arg_884) } else { temp__1927000408__auto____12 = linked_882.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_881, arg_884) }; if jrt.J2g_Truth(temp__1927000408__auto____12) { var i__13 any = temp__1927000408__auto____12; var op__14 any; var root_885 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_887 lang.IFn
		if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = i__13; if linked_886 == nil { op__14 = ifn_887.Invoke_O__O(arg_888) } else { op__14 = linked_886.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_885, arg_888) }
		var tmp1 any; var and__1927000168__auto____15 bool; var tmp2 any = A_arbace_cpp_inline_A_const_105; var tmp3 any; var root_889 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, A_arbace_cpp_inline_head_A_fn_class); var ifn_891 lang.IFn
		if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = op__14; if linked_890 == nil { tmp3 = ifn_891.Invoke_O__O(arg_892) } else { tmp3 = linked_890.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_889, arg_892) }; and__1927000168__auto____15 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if and__1927000168__auto____15 { var and__1927000168__auto____16 any; var root_893 any = A_arbace_cpp_inline_A_const_106.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, A_arbace_cpp_inline_may_throw_QMARK__A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = op__14; var arg_897 any = t.F_nounwind_fns; if linked_894 == nil { and__1927000168__auto____16 = ifn_895.Invoke_O_O__O(arg_896, arg_897) } else { and__1927000168__auto____16 = linked_894.(*A_arbace_cpp_inline_may_throw_QMARK__A).Invoke_O_O_O__O(root_893, arg_896, arg_897) }; if jrt.J2g_Truth(and__1927000168__auto____16) { var root_898 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = is__10; if linked_899 == nil { tmp1 = ifn_900.Invoke_O__O(arg_901) } else { tmp1 = linked_899.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_898, arg_901) } } else { tmp1 = and__1927000168__auto____16 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____15).Ref() }
//line :181:1
		if jrt.J2g_Truth(tmp1) { var nl__15 any; var root_902 any = A_arbace_cpp_inline_A_const_70.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_904 lang.IFn

			if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_69); var tmp5 any; var root_906 any = A_arbace_cpp_inline_A_const_11.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = cur__8; if linked_907 == nil { tmp5 = ifn_908.Invoke_O__O(arg_909) } else { tmp5 = linked_907.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_906, arg_909) }; arg_905 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, nil)).Ref(); if linked_903 == nil { nl__15 = ifn_904.Invoke_O__O(arg_905) } else { nl__15 = linked_903.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_902, arg_905) }
//line :181:1
			var inv__16 any; var root_910 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_912 lang.IFn


			if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = A_arbace_cpp_inline_A_const_32.GetRawRoot__O(); var arg_914 any = A_arbace_cpp_inline_A_const_107; var arg_915 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_29.GetRawRoot__O()); var tmp7 any; var root_922 any = A_arbace_cpp_inline_A_const_108.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = A_arbace_cpp_inline_A_const_109; var arg_926 any; var root_927 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = op__14; if linked_928 == nil { arg_926 = ifn_929.Invoke_O__O(arg_930) } else { arg_926 = linked_928.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_927, arg_930) }; if linked_923 == nil { tmp7 = ifn_924.Invoke_O_O__O(arg_925, arg_926) } else { tmp7 = linked_923.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_922, arg_925, arg_926) }; var tmp8 any = tmp7; var tmp9 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(A_arbace_cpp_inline_A_const_110, nl__15, A_arbace_cpp_inline_A_const_103, t.F_unwind); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_104.GetRawRoot__O()); var tmp11 any = A_arbace_cpp_inline_A_const_111.GetRawRoot__O(); var tmp12 any; var root_936 any = A_arbace_cpp_inline_A_const_112.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_938 lang.IFn
			if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any; var root_941 any = A_arbace_cpp_inline_A_const_61.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_941, A_arbace_cpp_inline_opts_of_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = op__14; if linked_942 == nil { arg_939 = ifn_943.Invoke_O_O__O(arg_944, A_arbace_cpp_inline_A_const_62) } else { arg_939 = linked_942.(*A_arbace_cpp_inline_opts_of_A).InvokePrim_O_O_J__O(root_941, arg_944, 4) }; var arg_940 any = A_arbace_cpp_inline_A_const_113; if linked_937 == nil { tmp12 = ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { tmp12 = linked_937.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }
//line :184:1
			arg_915 = tmp6.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12)); if linked_911 == nil { inv__16 = ifn_912.Invoke_O_O_O__O(arg_913, arg_914, arg_915) } else { inv__16 = linked_911.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_910, arg_913, arg_914, arg_915) }
//line :181:1
			var inv__17 any; var tmp13 any; var root_946 any = A_arbace_cpp_inline_A_const_71.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_cpp_inline_inst_def_A_fn_class); var ifn_948 lang.IFn




			if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = i__13; if linked_947 == nil { tmp13 = ifn_948.Invoke_O__O(arg_949) } else { tmp13 = linked_947.(*A_arbace_cpp_inline_inst_def_A).Invoke_O_O__O(root_946, arg_949) }; if jrt.J2g_Truth(tmp13) { var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp15 any = A_arbace_cpp_inline_A_const_115; var tmp16 any; var root_964 any = A_arbace_cpp_inline_A_const_71.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, A_arbace_cpp_inline_inst_def_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = i__13; if linked_965 == nil { tmp16 = ifn_966.Invoke_O__O(arg_967) } else { tmp16 = linked_965.(*A_arbace_cpp_inline_inst_def_A).Invoke_O_O__O(root_964, arg_967) }; inv__17 = tmp14.Invoke_O_O_O__O(tmp15, tmp16, inv__16) } else { inv__17 = inv__16 }
			var root_968 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = t.F_splits; var arg_972 any = A_arbace_cpp_inline_A_const_27.GetRawRoot__O(); var arg_973 any = cur__8; var arg_974 any = nl__15; if linked_969 == nil { ifn_970.Invoke_O_O_O_O__O(arg_971, arg_972, arg_973, arg_974) } else { linked_969.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_968, arg_971, arg_972, arg_973, arg_974) }
			var tmp17 any = lang.PersistentVector_EMPTY.Ref(); var tmp18 any; var root_975 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = is__10; if linked_976 == nil { tmp18 = ifn_977.Invoke_O__O(arg_978) } else { tmp18 = linked_976.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_975, arg_978) }; var tmp19 any = tmp18; var tmp20 any; var root_979 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = out__11; var arg_983 any; var root_984 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = lang.Tuple_Create_O__IPersistentVector(cur__8); var arg_988 any; var root_989 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = acc__9; var arg_993 any = inv__17; if linked_990 == nil { arg_988 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { arg_988 = linked_990.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_989, arg_992, arg_993) }; if linked_985 == nil { arg_983 = ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { arg_983 = linked_985.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) }; if linked_980 == nil { tmp20 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { tmp20 = linked_980.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }; cur__8, acc__9, is__10, out__11 = nl__15, tmp17, tmp19, tmp20; continue L1 } else {
//line :181:1
				var tmp21 any = A_arbace_cpp_inline_A_const_114; var tmp22 any; var root_950 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, A_arbace_cpp_inline_head_A_fn_class); var ifn_952 lang.IFn







				if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = op__14; if linked_951 == nil { tmp22 = ifn_952.Invoke_O__O(arg_953) } else { tmp22 = linked_951.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_950, arg_953) }
//line :181:1
				if lang.Util_Equiv_O_O__Z_NoInit(tmp21, tmp22) {








					var root_994 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = t.F_resumes; var arg_998 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var arg_999 any = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Nth_O_I__O_NoInit(op__14, lang.RT_IntCast_J__I_NoInit(2)), cur__8); if linked_995 == nil { ifn_996.Invoke_O_O_O__O(arg_997, arg_998, arg_999) } else { linked_995.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_994, arg_997, arg_998, arg_999) }
					var tmp23 any; var root_1000 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = acc__9; var arg_1004 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp25 any = A_arbace_cpp_inline_A_const_116; var tmp26 any; var root_1005 any = A_arbace_cpp_inline_A_const_70.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any; var tmp27 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_46); var tmp28 any; var root_1009 any = A_arbace_cpp_inline_A_const_11.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = t.F_unwind; if linked_1010 == nil { tmp28 = ifn_1011.Invoke_O__O(arg_1012) } else { tmp28 = linked_1010.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1009, arg_1012) }; arg_1008 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp27, jrt.RefArrayOf(jrt.Object_class, tmp28, nil)).Ref(); if linked_1006 == nil { tmp26 = ifn_1007.Invoke_O__O(arg_1008) } else { tmp26 = linked_1006.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1005, arg_1008) }; arg_1004 = tmp24.Invoke_O_O__O(tmp25, tmp26); if linked_1001 == nil { tmp23 = ifn_1002.Invoke_O_O__O(arg_1003, arg_1004) } else { tmp23 = linked_1001.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1000, arg_1003, arg_1004) }; var tmp29 any = tmp23; var tmp30 any; var root_1013 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = is__10; if linked_1014 == nil { tmp30 = ifn_1015.Invoke_O__O(arg_1016) } else { tmp30 = linked_1014.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1013, arg_1016) }; cur__8, acc__9, is__10, out__11 = cur__8, tmp29, tmp30, out__11; continue L1 } else {
//line :181:1
						if A_arbace_cpp_inline_A_const_17 != nil {










							var tmp31 any; var root_1017 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = acc__9; var arg_1021 any = i__13; if linked_1018 == nil { tmp31 = ifn_1019.Invoke_O_O__O(arg_1020, arg_1021) } else { tmp31 = linked_1018.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1017, arg_1020, arg_1021) }; var tmp32 any = tmp31; var tmp33 any; var root_1022 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = is__10; if linked_1023 == nil { tmp33 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp33 = linked_1023.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1022, arg_1025) }; cur__8, acc__9, is__10, out__11 = cur__8, tmp32, tmp33, out__11; continue L1 } else {
//line :181:1
								return nil } } } } else {











									var root_954 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = out__11; var arg_958 any; var root_959 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = lang.Tuple_Create_O__IPersistentVector(cur__8); var arg_963 any = acc__9; if linked_960 == nil { arg_958 = ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { arg_958 = linked_960.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_959, arg_962, arg_963) }; if linked_955 == nil { return ifn_956.Invoke_O_O__O(arg_957, arg_958) } else { return linked_955.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_954, arg_957, arg_958) } } } }; /*line :175:1*/panic("j2g: unreachable") }



























func A_arbace_cpp_inline_inline_site_fn__113000112_A_New() *A_arbace_cpp_inline_inline_site_fn__113000112_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000112_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000112_A) Ctor() {}
//line :203:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000112_A) Invoke_O_O__O(self, p__113000111__1 any) any { var vec__113000113__2 any = p__113000111__1; var seq__113000114__3 any; var root_1088 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = vec__113000113__2; if linked_1089 == nil { seq__113000114__3 = ifn_1090.Invoke_O__O(arg_1091) } else { seq__113000114__3 = linked_1089.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1088, arg_1091) }; var first__113000115__4 any; var root_1092 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = seq__113000114__3; if linked_1093 == nil { first__113000115__4 = ifn_1094.Invoke_O__O(arg_1095) } else { first__113000115__4 = linked_1093.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1092, arg_1095) }; var seq__113000114__5 any; var root_1096 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = seq__113000114__3; if linked_1097 == nil { seq__113000114__5 = ifn_1098.Invoke_O__O(arg_1099) } else { seq__113000114__5 = linked_1097.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1096, arg_1099) }; var l__6 any = first__113000115__4; var is__7 any = seq__113000114__5; var tmp1 any; var root_1100 any = A_arbace_cpp_inline_A_const_35.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any; var fnbody__1114 any = A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A_New(); var tmp2 *jrt.Class; var fncls__1113 *jrt.Class = A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A_fn_class; if fncls__1113 == nil { var fncls__1113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A_fn_class = fncls__1113d; tmp2 = fncls__1113d } else { tmp2 = fncls__1113 }; arg_1103 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1114, tmp2, nil); var arg_1104 any = is__7; if linked_1101 == nil { tmp1 = ifn_1102.Invoke_O_O__O(arg_1103, arg_1104) } else { tmp1 = linked_1101.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1100, arg_1103, arg_1104) }; if jrt.J2g_Truth(tmp1) { return l__6 } else { return nil } }
//line :203:1
func A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A_New() *A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A) Ctor() {}
//line :203:1
func (t *A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A) Invoke_O_O__O(self, p1__113000067_SHARP___1 any) any { var tmp1 any = A_arbace_cpp_inline_A_const_126; var tmp2 any; var root_1105 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, A_arbace_cpp_inline_head_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any; var root_1109 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = p1__113000067_SHARP___1; if linked_1110 == nil { arg_1108 = ifn_1111.Invoke_O__O(arg_1112) } else { arg_1108 = linked_1110.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1109, arg_1112) }; if linked_1106 == nil { tmp2 = ifn_1107.Invoke_O__O(arg_1108) } else { tmp2 = linked_1106.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_1105, arg_1108) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }


func A_arbace_cpp_inline_bv_size_A_New() *A_arbace_cpp_inline_bv_size_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_bv_size_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_cpp_inline_bv_size_A) Ctor() {}
//line :206:1
func (t *A_arbace_cpp_inline_bv_size_A) InvokePrim_O_O__J(self, t__0 any) int64 {


	var tmp1 *jrt.Long; var tmp2 any; var and__1927000168__auto____2 any; var root_1135 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = t__0; if linked_1136 == nil { and__1927000168__auto____2 = ifn_1137.Invoke_O__O(arg_1138) } else { and__1927000168__auto____2 = linked_1136.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1135, arg_1138) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp3 any = A_arbace_cpp_inline_A_const_131; var tmp4 any; var root_1139 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = t__0; if linked_1140 == nil { tmp4 = ifn_1141.Invoke_O__O(arg_1142) } else { tmp4 = linked_1140.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1139, arg_1142) }; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4); if and__1927000168__auto____3 { var tmp5 any = A_arbace_cpp_inline_A_const_132; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, lang.RT_Nth_O_I__O_NoInit(t__0, lang.RT_IntCast_J__I_NoInit(2)))).Ref() } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { tmp2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp2) { var tmp6 any; var root_1143 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = t__0; if linked_1144 == nil { tmp6 = ifn_1145.Invoke_O__O(arg_1146) } else { tmp6 = linked_1144.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1143, arg_1146) }; tmp1 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(tmp6)) } else { var tmp7 any; var root_1147 any = A_arbace_cpp_inline_A_const_133.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_cpp_inline_A_const_134.GetRawRoot__O()).Invoke_O__O(t__0))).Ref(); var arg_1151 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1148 == nil { tmp7 = ifn_1149.Invoke_O_O__O(arg_1150, arg_1151) } else { tmp7 = linked_1148.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1147, arg_1150, arg_1151) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp7))) }; return Up_Long_Number(tmp1).LongValue__J() }
//line :206:1
func (t *A_arbace_cpp_inline_bv_size_A) Invoke_O_O__O(self, t__0 any) any { return jrt.Long_ValueOf_J__Long_NoInit(t.InvokePrim_O_O__J(self, t__0)).Ref() }







func A_arbace_cpp_inline_append_clauses_A_New() *A_arbace_cpp_inline_append_clauses_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_append_clauses_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_cpp_inline_append_clauses_A) Ctor() {}
//line :214:1
func (t *A_arbace_cpp_inline_append_clauses_A) Invoke_O_O_O__O(self, i__0, outer__1 any) any { var op__3 any; var root_1156 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1158 lang.IFn; if


	linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = i__0; if linked_1157 == nil { op__3 = ifn_1158.Invoke_O__O(arg_1159) } else { op__3 = linked_1157.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1156, arg_1159) }; var vec__113000121__4 any = op__3; var seq__113000122__5 any; var root_1160 any = /*line :214:1*/A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1160, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1162 lang.IFn; if


	linked_1161 == nil { ifn_1162 = lang.IFn_Cast(root_1160) } else { ifn_1162 = nil }; var arg_1163 any = vec__113000121__4; if linked_1161 == nil { seq__113000122__5 = ifn_1162.Invoke_O__O(arg_1163) } else { seq__113000122__5 = linked_1161.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1160, arg_1163) }; var first__113000123__6 any; var root_1164 any = /*line :214:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1166 lang.IFn; if


	linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = seq__113000122__5; if linked_1165 == nil { first__113000123__6 = ifn_1166.Invoke_O__O(arg_1167) } else { first__113000123__6 = linked_1165.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1164, arg_1167) }; var seq__113000122__7 any; var root_1168 any = /*line :214:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1170 lang.IFn; if


	linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = seq__113000122__5; if linked_1169 == nil { seq__113000122__7 = ifn_1170.Invoke_O__O(arg_1171) } else { seq__113000122__7 = linked_1169.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1168, arg_1171) }; var ___8 any = first__113000123__6; var first__113000123__9 any; var root_1172 any = /*line :214:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1174 lang.IFn; _ = ___8; if


	linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = seq__113000122__7; if linked_1173 == nil { first__113000123__9 = ifn_1174.Invoke_O__O(arg_1175) } else { first__113000123__9 = linked_1173.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1172, arg_1175) }; var seq__113000122__10 any; var root_1176 any = /*line :214:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1178 lang.IFn; if


	linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = seq__113000122__7; if linked_1177 == nil { seq__113000122__10 = ifn_1178.Invoke_O__O(arg_1179) } else { seq__113000122__10 = linked_1177.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1176, arg_1179) }; var t__11 any = first__113000123__9; var cls__12 any = seq__113000122__10; var vec__113000124__13 any = outer__1; var seq__113000125__14 any; var root_1180 any = /*line :214:1*/A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1182 lang.IFn; if


	linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = vec__113000124__13; if linked_1181 == nil { seq__113000125__14 = ifn_1182.Invoke_O__O(arg_1183) } else { seq__113000125__14 = linked_1181.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1180, arg_1183) }; var first__113000126__15 any; var root_1184 any = /*line :214:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1186 lang.IFn; if


	linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = seq__113000125__14; if linked_1185 == nil { first__113000126__15 = ifn_1186.Invoke_O__O(arg_1187) } else { first__113000126__15 = linked_1185.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1184, arg_1187) }; var seq__113000125__16 any; var root_1188 any = /*line :214:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1190 lang.IFn; if


	linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = seq__113000125__14; if linked_1189 == nil { seq__113000125__16 = ifn_1190.Invoke_O__O(arg_1191) } else { seq__113000125__16 = linked_1189.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1188, arg_1191) }; var ___17 any = first__113000126__15; var first__113000126__18 any; var root_1192 any = /*line :214:1*/A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1194 lang.IFn; _ = ___17; if


	linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = seq__113000125__16; if linked_1193 == nil { first__113000126__18 = ifn_1194.Invoke_O__O(arg_1195) } else { first__113000126__18 = linked_1193.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1192, arg_1195) }; var seq__113000125__19 any; var root_1196 any = /*line :214:1*/A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1198 lang.IFn; if


	linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = seq__113000125__16; if linked_1197 == nil { seq__113000125__19 = ifn_1198.Invoke_O__O(arg_1199) } else { seq__113000125__19 = linked_1197.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1196, arg_1199) }; var ___20 any = first__113000126__18; var ocls__21 any = seq__113000125__19; var cleanup__22 any; var or__1927000174__auto____22 any; var root_1200 any = /*line :214:1*/A_arbace_cpp_inline_A_const_35.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1202 lang.IFn; _ = ___20; if





	linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = A_arbace_cpp_inline_A_const_135; var arg_1204 any = cls__12; if linked_1201 == nil { or__1927000174__auto____22 = ifn_1202.Invoke_O_O__O(arg_1203, arg_1204) } else { or__1927000174__auto____22 = linked_1201.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1200, arg_1203, arg_1204) }; if jrt.J2g_Truth(or__1927000174__auto____22) { cleanup__22 = or__1927000174__auto____22 } else { var root_1205 any = A_arbace_cpp_inline_A_const_35.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = A_arbace_cpp_inline_A_const_136; var arg_1209 any = ocls__21; if linked_1206 == nil { cleanup__22 = ifn_1207.Invoke_O_O__O(arg_1208, arg_1209) } else { cleanup__22 = linked_1206.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1205, arg_1208, arg_1209) } }; var new__23 any; var root_1210 any = /*line :214:1*/A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1212 lang.IFn; if






	linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = A_arbace_cpp_inline_A_const_32.GetRawRoot__O(); var arg_1214 any = A_arbace_cpp_inline_A_const_137; var arg_1215 any = t__11; var arg_1216 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_29.GetRawRoot__O()); var tmp2 any; if jrt.J2g_Truth(cleanup__22) { tmp2 = A_arbace_cpp_inline_A_const_138 } else { tmp2 = nil }; var tmp3 any = tmp2; var tmp4 any; var root_1223 any = A_arbace_cpp_inline_A_const_93.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any = A_arbace_cpp_inline_A_const_139; var arg_1227 any = cls__12; if linked_1224 == nil { tmp4 = ifn_1225.Invoke_O_O__O(arg_1226, arg_1227) } else { tmp4 = linked_1224.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1223, arg_1226, arg_1227) }; var tmp5 any = tmp4; var tmp6 any; var root_1228 any = A_arbace_cpp_inline_A_const_93.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = A_arbace_cpp_inline_A_const_140; var arg_1232 any = ocls__21; if linked_1229 == nil { tmp6 = ifn_1230.Invoke_O_O__O(arg_1231, arg_1232) } else { tmp6 = linked_1229.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1228, arg_1231, arg_1232) }; arg_1216 = tmp1.Invoke_O_O_O__O(tmp3, tmp5, tmp6); if linked_1211 == nil { new__23 = ifn_1212.Invoke_O_O_O_O__O(arg_1213, arg_1214, arg_1215, arg_1216) } else { new__23 = linked_1211.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1210, arg_1213, arg_1214, arg_1215, arg_1216) }; var tmp7 any; var root_1233 any =
	A_arbace_cpp_inline_A_const_71.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, A_arbace_cpp_inline_inst_def_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = i__0; if linked_1234 == nil { tmp7 = ifn_1235.Invoke_O__O(arg_1236) } else { tmp7 = linked_1234.(*A_arbace_cpp_inline_inst_def_A).Invoke_O_O__O(root_1233, arg_1236) }; if jrt.J2g_Truth(tmp7) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp9 any = A_arbace_cpp_inline_A_const_141; var tmp10 any; var root_1237 any = A_arbace_cpp_inline_A_const_71.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, A_arbace_cpp_inline_inst_def_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = i__0; if linked_1238 == nil { tmp10 = ifn_1239.Invoke_O__O(arg_1240) } else { tmp10 = linked_1238.(*A_arbace_cpp_inline_inst_def_A).Invoke_O_O__O(root_1237, arg_1240) }; return tmp8.Invoke_O_O_O__O(tmp9, tmp10, new__23) } else { return new__23 } }

func A_arbace_cpp_inline_inline_into_A_New() *A_arbace_cpp_inline_inline_into_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_cpp_inline_inline_into_A) Ctor() {}
//line :224:1
func (t *A_arbace_cpp_inline_inline_into_A) Invoke_O_O_O_O__O(self, d__0, ai__1, nounwind_fns__2 any) any { var dopts__4 any; var root_1241 any = A_arbace_cpp_inline_A_const_50.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, A_arbace_cpp_inline_define_opts_A_fn_class); var ifn_1243 lang.IFn; if


	linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any = d__0; if linked_1242 == nil { dopts__4 = ifn_1243.Invoke_O__O(arg_1244) } else { dopts__4 = linked_1242.(*A_arbace_cpp_inline_define_opts_A).Invoke_O_O__O(root_1241, arg_1244) }; var blocks__5 any; var root_1245 any = /*line :224:1*/A_arbace_cpp_inline_A_const_58.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1247 lang.IFn; if



	linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any; var fnbody__1276 any = A_arbace_cpp_inline_inline_into_fn__113000132_A_New(); var tmp1 *jrt.Class; var fncls__1275 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000132_A_fn_class; if fncls__1275 == nil { var fncls__1275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_cpp_inline_inline_into_fn__113000132_A_fn_class = fncls__1275d; tmp1 = fncls__1275d } else { tmp1 = fncls__1275 }; arg_1248 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1276, tmp1, nil); var arg_1249 any = A_arbace_cpp_inline_A_const_28.Invoke_O__O(dopts__4); if linked_1246 == nil { blocks__5 = ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { blocks__5 = linked_1246.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) }; var allocas__6 any; var root_1277 any = /*line :224:1*/A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1279 lang.IFn; if




	linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = lang.PersistentVector_EMPTY.Ref(); if linked_1278 == nil { allocas__6 = ifn_1279.Invoke_O__O(arg_1280) } else { allocas__6 = linked_1278.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1277, arg_1280) }; var splits__7 any; var root_1281 any = /*line :224:1*/A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1283 lang.IFn; if





	linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1282 == nil { splits__7 = ifn_1283.Invoke_O__O(arg_1284) } else { splits__7 = linked_1282.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1281, arg_1284) }; var resumes__8 any; var root_1285 any = /*line :224:1*/A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1287 lang.IFn; if






	linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1286 == nil { resumes__8 = ifn_1287.Invoke_O__O(arg_1288) } else { resumes__8 = linked_1286.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1285, arg_1288) }; var outer_pads__9 any; var root_1289 any = /*line :224:1*/A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1291 lang.IFn; if







	linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1290 == nil { outer_pads__9 = ifn_1291.Invoke_O__O(arg_1292) } else { outer_pads__9 = linked_1290.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1289, arg_1292) }; var personality__10 any; var root_1293 any = /*line :224:1*/A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1295 lang.IFn; if








	linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = A_arbace_cpp_inline_A_const_127.Invoke_O__O(dopts__4); if linked_1294 == nil { personality__10 = ifn_1295.Invoke_O__O(arg_1296) } else { personality__10 = linked_1294.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1293, arg_1296) }; var out__11 any; var root_1297 any = /*line :224:1*/A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1299 lang.IFn; if









	linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = lang.PersistentVector_EMPTY.Ref(); if linked_1298 == nil { out__11 = ifn_1299.Invoke_O__O(arg_1300) } else { out__11 = linked_1298.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1297, arg_1300) }; var changed__12 any; var root_1301 any = /*line :224:1*/A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1303 lang.IFn; if










	linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = jrt.Boolean_FALSE.Ref(); if linked_1302 == nil { changed__12 = ifn_1303.Invoke_O__O(arg_1304) } else { changed__12 = linked_1302.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1301, arg_1304) }; var seq_113000137__13 any; var root_1730 any = /*line :224:1*/A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1732 lang.IFn; if












	linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = blocks__5; if linked_1731 == nil { seq_113000137__13 = ifn_1732.Invoke_O__O(arg_1733) } else { seq_113000137__13 = linked_1731.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1730, arg_1733) }; var chunk_113000138__14 any; var count_113000139__15 int64 = 0; var i_113000140__16 int64 = 0; L1:
//line :224:1
	for {












		if lang.Numbers_Lt_J_J__Z_NoInit(i_113000140__16, count_113000139__15) { var b__17 any = lang.Indexed_Cast(chunk_113000138__14).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_113000140__16)); var G__113000144__18_ any = b__17; var vec__113000145__19 any = G__113000144__18_; var seq__113000146__20 any; var root_1750 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1752 lang.IFn
			if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = vec__113000145__19; if linked_1751 == nil { seq__113000146__20 = ifn_1752.Invoke_O__O(arg_1753) } else { seq__113000146__20 = linked_1751.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1750, arg_1753) }
//line :237:1
			var first__113000147__21 any; var root_1754 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1756 lang.IFn
			if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = seq__113000146__20; if linked_1755 == nil { first__113000147__21 = ifn_1756.Invoke_O__O(arg_1757) } else { first__113000147__21 = linked_1755.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1754, arg_1757) }
//line :237:1
			var seq__113000146__22 any; var root_1758 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1760 lang.IFn
			if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = seq__113000146__20; if linked_1759 == nil { seq__113000146__22 = ifn_1760.Invoke_O__O(arg_1761) } else { seq__113000146__22 = linked_1759.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1758, arg_1761) }
//line :237:1
			var l__23 any = first__113000147__21; var is__24 any = seq__113000146__22; var G__113000144__25_ any = G__113000144__18_; _ = l__23; _ = is__24; L2: for { var vec__113000148__26 any = G__113000144__25_; var seq__113000149__27 any; var root_1762 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1764 lang.IFn
				if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = vec__113000148__26; if linked_1763 == nil { seq__113000149__27 = ifn_1764.Invoke_O__O(arg_1765) } else { seq__113000149__27 = linked_1763.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1762, arg_1765) }
//line :237:1
				var first__113000150__28 any; var root_1766 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1768 lang.IFn
				if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = seq__113000149__27; if linked_1767 == nil { first__113000150__28 = ifn_1768.Invoke_O__O(arg_1769) } else { first__113000150__28 = linked_1767.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1766, arg_1769) }
//line :237:1
				var seq__113000149__29 any; var root_1770 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1772 lang.IFn
				if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = seq__113000149__27; if linked_1771 == nil { seq__113000149__29 = ifn_1772.Invoke_O__O(arg_1773) } else { seq__113000149__29 = linked_1771.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1770, arg_1773) }
//line :237:1
				var l__30 any = first__113000150__28; var is__31 any = seq__113000149__29; var i__32 any; var root_1774 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1776 lang.IFn

				if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any; var root_1778 any = A_arbace_cpp_inline_A_const_25.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any; var fnbody__1818 any = A_arbace_cpp_inline_inline_into_fn__113000151_A_New_O_O(d__0, ai__1); var tmp2 *jrt.Class; var fncls__1817 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000151_A_fn_class; if fncls__1817 == nil { var fncls__1817d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__1818); A_arbace_cpp_inline_inline_into_fn__113000151_A_fn_class = fncls__1817d; tmp2 = fncls__1817d } else { tmp2 = fncls__1817 }; arg_1781 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1818, tmp2, nil); var arg_1782 any = is__31; if linked_1779 == nil { arg_1777 = ifn_1780.Invoke_O_O__O(arg_1781, arg_1782) } else { arg_1777 = linked_1779.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_1778, arg_1781, arg_1782) }; if linked_1775 == nil { i__32 = ifn_1776.Invoke_O__O(arg_1777) } else { i__32 = linked_1775.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1774, arg_1777) }
//line :237:1
				var r__33 any






				if jrt.J2g_Truth(i__32) { var v__33 any; var root_1819 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = is__31; if linked_1820 == nil { v__33 = ifn_1821.Invoke_O__O(arg_1822) } else { v__33 = linked_1820.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1819, arg_1822) }; var c__34 any = lang.RT_Nth_O_I__O_NoInit(v__33, lang.RT_IntCast_O__I_NoInit(i__32)); var root_1823 any = A_arbace_cpp_inline_A_const_160.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, A_arbace_cpp_inline_inline_site_A_fn_class); var ifn_1825 lang.IFn
					if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = l__30; var arg_1827 any; var root_1832 any = A_arbace_cpp_inline_A_const_30.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = v__33; var arg_1836 any = A_arbace_cpp_inline_A_const_31; var arg_1837 any = i__32; if linked_1833 == nil { arg_1827 = ifn_1834.Invoke_O_O_O__O(arg_1835, arg_1836, arg_1837) } else { arg_1827 = linked_1833.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_1832, arg_1835, arg_1836, arg_1837) }; var arg_1828 any = c__34; var arg_1829 any; var root_1838 any = A_arbace_cpp_inline_A_const_30.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1840 lang.IFn; if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any = v__33; var arg_1842 any; var na_1843 any = i__32; if jrt.Long_InstanceOf(na_1843) { var n0_1844 int64 = jrt.NN(jrt.Long_Cast(na_1843)).LongValue__J(); if n0_1844 == 9223372036854775807 { arg_1842 = lang.Numbers_Inc_O__Number_NoInit(na_1843) } else { arg_1842 = jrt.Long_ValueOf_J__Long_NoInit(n0_1844 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1843) { var n0_1844_2 float64 = jrt.NN(jrt.Double_Cast(na_1843)).DoubleValue__D(); arg_1842 = jrt.Double_ValueOf_D__Double_NoInit(n0_1844_2 + 1.0).Ref() } else { arg_1842 = lang.Numbers_Inc_O__Number_NoInit(na_1843) } }; if linked_1839 == nil { arg_1829 = ifn_1840.Invoke_O_O__O(arg_1841, arg_1842) } else { arg_1829 = linked_1839.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_1838, arg_1841, arg_1842) }; var arg_1830 any; var tmp3 any; var root_1845 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, A_arbace_cpp_inline_gname_A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any; var tmp4 any; var root_1849 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1851 lang.IFn; if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any = c__34; if linked_1850 == nil { tmp4 = ifn_1851.Invoke_O__O(arg_1852) } else { tmp4 = linked_1850.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1849, arg_1852) }; arg_1848 = lang.RT_Nth_O_I__O_NoInit(tmp4, lang.RT_IntCast_J__I_NoInit(2)); if linked_1846 == nil { tmp3 = ifn_1847.Invoke_O__O(arg_1848) } else { tmp3 = linked_1846.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_1845, arg_1848) }; arg_1830 = lang.RT_Get_O_O__O_NoInit(ai__1, tmp3); var arg_1831 any = nounwind_fns__2; if linked_1824 == nil { r__33 = ifn_1825.Invoke_O_O_O_O_O_O__O(arg_1826, arg_1827, arg_1828, arg_1829, arg_1830, arg_1831) } else { r__33 = linked_1824.(*A_arbace_cpp_inline_inline_site_A).Invoke_O_O_O_O_O_O_O__O(root_1823, arg_1826, arg_1827, arg_1828, arg_1829, arg_1830, arg_1831) } } else {
//line :244:1
						r__33 = nil
					}
				var tmp5 any; var root_1853 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1855 lang.IFn; if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = r__33; if linked_1854 == nil { tmp5 = ifn_1855.Invoke_O__O(arg_1856) } else { tmp5 = linked_1854.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1853, arg_1856) }; if jrt.J2g_Truth(tmp5) {
					var root_1857 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = out__11; var arg_1861 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var arg_1862 any; var root_1863 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1865 lang.IFn; if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any = lang.Tuple_Create_O__IPersistentVector(l__30); var arg_1867 any = is__31; if linked_1864 == nil { arg_1862 = ifn_1865.Invoke_O_O__O(arg_1866, arg_1867) } else { arg_1862 = linked_1864.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1863, arg_1866, arg_1867) }; if linked_1858 == nil { ifn_1859.Invoke_O_O_O__O(arg_1860, arg_1861, arg_1862) } else { linked_1858.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1857, arg_1860, arg_1861, arg_1862) } } else {
						var root_1868 any = A_arbace_cpp_inline_A_const_161.GetRawRoot__O(); var linked_1869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1868, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_1870 lang.IFn; if linked_1869 == nil { ifn_1870 = lang.IFn_Cast(root_1868) } else { ifn_1870 = nil }; var arg_1871 any = changed__12; var arg_1872 any = jrt.Boolean_TRUE.Ref(); if linked_1869 == nil { ifn_1870.Invoke_O_O__O(arg_1871, arg_1872) } else { linked_1869.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_1868, arg_1871, arg_1872) }
						var root_1873 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = allocas__6; var arg_1877 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var arg_1878 any = A_arbace_cpp_inline_A_const_119.Invoke_O__O(r__33); if linked_1874 == nil { ifn_1875.Invoke_O_O_O__O(arg_1876, arg_1877, arg_1878) } else { linked_1874.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1873, arg_1876, arg_1877, arg_1878) }
						var root_1879 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = splits__7; var arg_1883 any = A_arbace_cpp_inline_A_const_162.GetRawRoot__O(); var arg_1884 any = A_arbace_cpp_inline_A_const_121.Invoke_O__O(r__33); var arg_1885 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, l__30, A_arbace_cpp_inline_A_const_120.Invoke_O__O(r__33))); if linked_1880 == nil { ifn_1881.Invoke_O_O_O_O__O(arg_1882, arg_1883, arg_1884, arg_1885) } else { linked_1880.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1879, arg_1882, arg_1883, arg_1884, arg_1885) }
//line :246:1
						var temp__1927000414__auto____34 any = A_arbace_cpp_inline_A_const_103.Invoke_O__O(r__33)




						if jrt.J2g_Truth(temp__1927000414__auto____34) { var u__35 any = temp__1927000414__auto____34; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_67.GetRawRoot__O()); var tmp7 any = A_arbace_cpp_inline_A_const_163.GetRawRoot__O(); var tmp8 any; var root_1927 any = A_arbace_cpp_inline_A_const_164.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1929 lang.IFn
							if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var arg_1931 any = lang.PersistentVector_EMPTY.Ref(); if linked_1928 == nil { tmp8 = ifn_1929.Invoke_O_O__O(arg_1930, arg_1931) } else { tmp8 = linked_1928.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1927, arg_1930, arg_1931) }; tmp6.Invoke_O_O_O_O_O__O(resumes__8, tmp7, u__35, tmp8, A_arbace_cpp_inline_A_const_122.Invoke_O__O(r__33))
//line :251:1
							var seq_113000153__36 any; var root_1886 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1888 lang.IFn

							if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any = A_arbace_cpp_inline_A_const_123.Invoke_O__O(r__33); if linked_1887 == nil { seq_113000153__36 = ifn_1888.Invoke_O__O(arg_1889) } else { seq_113000153__36 = linked_1887.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1886, arg_1889) }
//line :251:1
							var chunk_113000154__37 any; var count_113000155__38 int64 = 0; var i_113000156__39 int64 = 0; L3: for {

								if lang.Numbers_Lt_J_J__Z_NoInit(i_113000156__39, count_113000155__38) { var p__40 any = lang.Indexed_Cast(chunk_113000154__37).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_113000156__39)); var root_1932 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = outer_pads__9; var arg_1936 any = A_arbace_cpp_inline_A_const_27.GetRawRoot__O(); var arg_1937 any = p__40; var arg_1938 any = u__35; if linked_1933 == nil { ifn_1934.Invoke_O_O_O_O__O(arg_1935, arg_1936, arg_1937, arg_1938) } else { linked_1933.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1932, arg_1935, arg_1936, arg_1937, arg_1938) }; seq_113000153__36, chunk_113000154__37, count_113000155__38, i_113000156__39 = seq_113000153__36, chunk_113000154__37, count_113000155__38, lang.Numbers_Unchecked_inc_J__J_NoInit(i_113000156__39); continue L3 } else { var temp__1927000414__auto____40 any; var root_1890 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1892 lang.IFn; if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any = seq_113000153__36; if linked_1891 == nil { temp__1927000414__auto____40 = ifn_1892.Invoke_O__O(arg_1893) } else { temp__1927000414__auto____40 = linked_1891.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1890, arg_1893) }; if jrt.J2g_Truth(temp__1927000414__auto____40) { var seq_113000153__41 any = temp__1927000414__auto____40; var tmp9 any; var root_1894 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1894, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1896 lang.IFn; if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any = seq_113000153__41; if linked_1895 == nil { tmp9 = ifn_1896.Invoke_O__O(arg_1897) } else { tmp9 = linked_1895.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1894, arg_1897) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____42 any; var root_1898 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1898, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1900 lang.IFn; if linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any = seq_113000153__41; if linked_1899 == nil { c__1927000678__auto____42 = ifn_1900.Invoke_O__O(arg_1901) } else { c__1927000678__auto____42 = linked_1899.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1898, arg_1901) }; var tmp10 any; var root_1939 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = seq_113000153__41; if linked_1940 == nil { tmp10 = ifn_1941.Invoke_O__O(arg_1942) } else { tmp10 = linked_1940.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1939, arg_1942) }; seq_113000153__36, chunk_113000154__37, count_113000155__38, i_113000156__39 = tmp10, c__1927000678__auto____42, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____42))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var p__42 any; var root_1902 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1902, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1904 lang.IFn; if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any = seq_113000153__41; if linked_1903 == nil { p__42 = ifn_1904.Invoke_O__O(arg_1905) } else { p__42 = linked_1903.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1902, arg_1905) }; var root_1943 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_1944 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1943, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1945 lang.IFn; if linked_1944 == nil { ifn_1945 = lang.IFn_Cast(root_1943) } else { ifn_1945 = nil }; var arg_1946 any = outer_pads__9; var arg_1947 any = A_arbace_cpp_inline_A_const_27.GetRawRoot__O(); var arg_1948 any = p__42; var arg_1949 any = u__35; if linked_1944 == nil { ifn_1945.Invoke_O_O_O_O__O(arg_1946, arg_1947, arg_1948, arg_1949) } else { linked_1944.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1943, arg_1946, arg_1947, arg_1948, arg_1949) }; var tmp11 any; var root_1950 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1952 lang.IFn; if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = seq_113000153__41; if linked_1951 == nil { tmp11 = ifn_1952.Invoke_O__O(arg_1953) } else { tmp11 = linked_1951.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1950, arg_1953) }; seq_113000153__36, chunk_113000154__37, count_113000155__38, i_113000156__39 = tmp11, nil, 0, 0; continue L3 } } }
//line :251:1
								break L3
							}
						}
						var tmp12 any; var and__1927000168__auto____34 any = A_arbace_cpp_inline_A_const_127.Invoke_O__O(r__33); if jrt.J2g_Truth(and__1927000168__auto____34) { var root_1906 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any; var root_1910 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = personality__10; if linked_1911 == nil { arg_1909 = ifn_1912.Invoke_O__O(arg_1913) } else { arg_1909 = linked_1911.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1910, arg_1913) }; if linked_1907 == nil { tmp12 = ifn_1908.Invoke_O__O(arg_1909) } else { tmp12 = linked_1907.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1906, arg_1909) } } else { tmp12 = and__1927000168__auto____34 }; if jrt.J2g_Truth(tmp12) { var root_1914 any = A_arbace_cpp_inline_A_const_161.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = personality__10; var arg_1918 any = A_arbace_cpp_inline_A_const_127.Invoke_O__O(r__33); if linked_1915 == nil { ifn_1916.Invoke_O_O__O(arg_1917, arg_1918) } else { linked_1915.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_1914, arg_1917, arg_1918) } }
//line :246:1
						var bs__34 any = A_arbace_cpp_inline_A_const_117.Invoke_O__O(r__33); var root_1954 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1956 lang.IFn









						if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any = out__11; var arg_1958 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var arg_1959 any; var root_1960 any = A_arbace_cpp_inline_A_const_77.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = bs__34; if linked_1961 == nil { arg_1959 = ifn_1962.Invoke_O__O(arg_1963) } else { arg_1959 = linked_1961.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_1960, arg_1963) }; if linked_1955 == nil { ifn_1956.Invoke_O_O_O__O(arg_1957, arg_1958, arg_1959) } else { linked_1955.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1954, arg_1957, arg_1958, arg_1959) }
						var tmp13 any; var root_1964 any = A_arbace_cpp_inline_A_const_97.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = bs__34; if linked_1965 == nil { tmp13 = ifn_1966.Invoke_O__O(arg_1967) } else { tmp13 = linked_1965.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_1964, arg_1967) }; G__113000144__25_ = tmp13; continue L2 }
//line :237:1
				break L2 }; seq_113000137__13, chunk_113000138__14, count_113000139__15, i_113000140__16 = seq_113000137__13, chunk_113000138__14, count_113000139__15, lang.Numbers_Unchecked_inc_J__J_NoInit(i_113000140__16); continue L1 } else { var temp__1927000414__auto____17 any; var root_1734 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = seq_113000137__13; if linked_1735 == nil { temp__1927000414__auto____17 = ifn_1736.Invoke_O__O(arg_1737) } else { temp__1927000414__auto____17 = linked_1735.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1734, arg_1737) }; if jrt.J2g_Truth(temp__1927000414__auto____17) { var seq_113000137__18 any = temp__1927000414__auto____17; var tmp14 any; var root_1738 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = seq_113000137__18; if linked_1739 == nil { tmp14 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp14 = linked_1739.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1738, arg_1741) }; if jrt.J2g_Truth(tmp14) { var c__1927000678__auto____19 any; var root_1742 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = seq_113000137__18; if linked_1743 == nil { c__1927000678__auto____19 = ifn_1744.Invoke_O__O(arg_1745) } else { c__1927000678__auto____19 = linked_1743.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1742, arg_1745) }; var tmp15 any; var root_1968 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_1969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1968, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1970 lang.IFn; if linked_1969 == nil { ifn_1970 = lang.IFn_Cast(root_1968) } else { ifn_1970 = nil }; var arg_1971 any = seq_113000137__18; if linked_1969 == nil { tmp15 = ifn_1970.Invoke_O__O(arg_1971) } else { tmp15 = linked_1969.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1968, arg_1971) }; seq_113000137__13, chunk_113000138__14, count_113000139__15, i_113000140__16 = tmp15, c__1927000678__auto____19, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var b__19 any; var root_1746 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = seq_113000137__18; if linked_1747 == nil { b__19 = ifn_1748.Invoke_O__O(arg_1749) } else { b__19 = linked_1747.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1746, arg_1749) }; var G__113000160__20_ any = b__19; var vec__113000161__21 any = G__113000160__20_; var seq__113000162__22 any; var root_1972 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1972, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1974 lang.IFn
					if linked_1973 == nil { ifn_1974 = lang.IFn_Cast(root_1972) } else { ifn_1974 = nil }; var arg_1975 any = vec__113000161__21; if linked_1973 == nil { seq__113000162__22 = ifn_1974.Invoke_O__O(arg_1975) } else { seq__113000162__22 = linked_1973.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1972, arg_1975) }
//line :237:1
					var first__113000163__23 any; var root_1976 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1978 lang.IFn
					if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any = seq__113000162__22; if linked_1977 == nil { first__113000163__23 = ifn_1978.Invoke_O__O(arg_1979) } else { first__113000163__23 = linked_1977.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1976, arg_1979) }
//line :237:1
					var seq__113000162__24 any; var root_1980 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1982 lang.IFn
					if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = seq__113000162__22; if linked_1981 == nil { seq__113000162__24 = ifn_1982.Invoke_O__O(arg_1983) } else { seq__113000162__24 = linked_1981.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1980, arg_1983) }
//line :237:1
					var l__25 any = first__113000163__23; var is__26 any = seq__113000162__24; var G__113000160__27_ any = G__113000160__20_; _ = l__25; _ = is__26; L4: for { var vec__113000164__28 any = G__113000160__27_; var seq__113000165__29 any; var root_1984 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1986 lang.IFn
						if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = vec__113000164__28; if linked_1985 == nil { seq__113000165__29 = ifn_1986.Invoke_O__O(arg_1987) } else { seq__113000165__29 = linked_1985.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1984, arg_1987) }
//line :237:1
						var first__113000166__30 any; var root_1988 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1988, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1990 lang.IFn
						if linked_1989 == nil { ifn_1990 = lang.IFn_Cast(root_1988) } else { ifn_1990 = nil }; var arg_1991 any = seq__113000165__29; if linked_1989 == nil { first__113000166__30 = ifn_1990.Invoke_O__O(arg_1991) } else { first__113000166__30 = linked_1989.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1988, arg_1991) }
//line :237:1
						var seq__113000165__31 any; var root_1992 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1992, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1994 lang.IFn
						if linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any = seq__113000165__29; if linked_1993 == nil { seq__113000165__31 = ifn_1994.Invoke_O__O(arg_1995) } else { seq__113000165__31 = linked_1993.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1992, arg_1995) }
//line :237:1
						var l__32 any = first__113000166__30; var is__33 any = seq__113000165__31; var i__34 any; var root_1996 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1998 lang.IFn

						if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any; var root_2000 any = A_arbace_cpp_inline_A_const_25.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any; var fnbody__2040 any = A_arbace_cpp_inline_inline_into_fn__113000167_A_New_O_O(d__0, ai__1); var tmp16 *jrt.Class; var fncls__2039 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000167_A_fn_class; if fncls__2039 == nil { var fncls__2039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__2040); A_arbace_cpp_inline_inline_into_fn__113000167_A_fn_class = fncls__2039d; tmp16 = fncls__2039d } else { tmp16 = fncls__2039 }; arg_2003 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2040, tmp16, nil); var arg_2004 any = is__33; if linked_2001 == nil { arg_1999 = ifn_2002.Invoke_O_O__O(arg_2003, arg_2004) } else { arg_1999 = linked_2001.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_2000, arg_2003, arg_2004) }; if linked_1997 == nil { i__34 = ifn_1998.Invoke_O__O(arg_1999) } else { i__34 = linked_1997.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1996, arg_1999) }
//line :237:1
						var r__35 any






						if jrt.J2g_Truth(i__34) { var v__35 any; var root_2041 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2043 lang.IFn; if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = is__33; if linked_2042 == nil { v__35 = ifn_2043.Invoke_O__O(arg_2044) } else { v__35 = linked_2042.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2041, arg_2044) }; var c__36 any = lang.RT_Nth_O_I__O_NoInit(v__35, lang.RT_IntCast_O__I_NoInit(i__34)); var root_2045 any = A_arbace_cpp_inline_A_const_160.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, A_arbace_cpp_inline_inline_site_A_fn_class); var ifn_2047 lang.IFn
							if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any = l__32; var arg_2049 any; var root_2054 any = A_arbace_cpp_inline_A_const_30.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = v__35; var arg_2058 any = A_arbace_cpp_inline_A_const_31; var arg_2059 any = i__34; if linked_2055 == nil { arg_2049 = ifn_2056.Invoke_O_O_O__O(arg_2057, arg_2058, arg_2059) } else { arg_2049 = linked_2055.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_2054, arg_2057, arg_2058, arg_2059) }; var arg_2050 any = c__36; var arg_2051 any; var root_2060 any = A_arbace_cpp_inline_A_const_30.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any = v__35; var arg_2064 any; var na_2065 any = i__34; if jrt.Long_InstanceOf(na_2065) { var n0_2066 int64 = jrt.NN(jrt.Long_Cast(na_2065)).LongValue__J(); if n0_2066 == 9223372036854775807 { arg_2064 = lang.Numbers_Inc_O__Number_NoInit(na_2065) } else { arg_2064 = jrt.Long_ValueOf_J__Long_NoInit(n0_2066 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_2065) { var n0_2066_2 float64 = jrt.NN(jrt.Double_Cast(na_2065)).DoubleValue__D(); arg_2064 = jrt.Double_ValueOf_D__Double_NoInit(n0_2066_2 + 1.0).Ref() } else { arg_2064 = lang.Numbers_Inc_O__Number_NoInit(na_2065) } }; if linked_2061 == nil { arg_2051 = ifn_2062.Invoke_O_O__O(arg_2063, arg_2064) } else { arg_2051 = linked_2061.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O__O(root_2060, arg_2063, arg_2064) }; var arg_2052 any; var tmp17 any; var root_2067 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any; var tmp18 any; var root_2071 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = c__36; if linked_2072 == nil { tmp18 = ifn_2073.Invoke_O__O(arg_2074) } else { tmp18 = linked_2072.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_2071, arg_2074) }; arg_2070 = lang.RT_Nth_O_I__O_NoInit(tmp18, lang.RT_IntCast_J__I_NoInit(2)); if linked_2068 == nil { tmp17 = ifn_2069.Invoke_O__O(arg_2070) } else { tmp17 = linked_2068.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2067, arg_2070) }; arg_2052 = lang.RT_Get_O_O__O_NoInit(ai__1, tmp17); var arg_2053 any = nounwind_fns__2; if linked_2046 == nil { r__35 = ifn_2047.Invoke_O_O_O_O_O_O__O(arg_2048, arg_2049, arg_2050, arg_2051, arg_2052, arg_2053) } else { r__35 = linked_2046.(*A_arbace_cpp_inline_inline_site_A).Invoke_O_O_O_O_O_O_O__O(root_2045, arg_2048, arg_2049, arg_2050, arg_2051, arg_2052, arg_2053) } } else {
//line :244:1
								r__35 = nil
							}
						var tmp19 any; var root_2075 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2077 lang.IFn; if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = r__35; if linked_2076 == nil { tmp19 = ifn_2077.Invoke_O__O(arg_2078) } else { tmp19 = linked_2076.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2075, arg_2078) }; if jrt.J2g_Truth(tmp19) {
							var root_2079 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2081 lang.IFn; if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = out__11; var arg_2083 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var arg_2084 any; var root_2085 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2085, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2087 lang.IFn; if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = lang.Tuple_Create_O__IPersistentVector(l__32); var arg_2089 any = is__33; if linked_2086 == nil { arg_2084 = ifn_2087.Invoke_O_O__O(arg_2088, arg_2089) } else { arg_2084 = linked_2086.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2085, arg_2088, arg_2089) }; if linked_2080 == nil { ifn_2081.Invoke_O_O_O__O(arg_2082, arg_2083, arg_2084) } else { linked_2080.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2079, arg_2082, arg_2083, arg_2084) } } else {
								var root_2090 any = A_arbace_cpp_inline_A_const_161.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = changed__12; var arg_2094 any = jrt.Boolean_TRUE.Ref(); if linked_2091 == nil { ifn_2092.Invoke_O_O__O(arg_2093, arg_2094) } else { linked_2091.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_2090, arg_2093, arg_2094) }
								var root_2095 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2095, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2097 lang.IFn; if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any = allocas__6; var arg_2099 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var arg_2100 any = A_arbace_cpp_inline_A_const_119.Invoke_O__O(r__35); if linked_2096 == nil { ifn_2097.Invoke_O_O_O__O(arg_2098, arg_2099, arg_2100) } else { linked_2096.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2095, arg_2098, arg_2099, arg_2100) }
								var root_2101 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2101, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = splits__7; var arg_2105 any = A_arbace_cpp_inline_A_const_162.GetRawRoot__O(); var arg_2106 any = A_arbace_cpp_inline_A_const_121.Invoke_O__O(r__35); var arg_2107 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, l__32, A_arbace_cpp_inline_A_const_120.Invoke_O__O(r__35))); if linked_2102 == nil { ifn_2103.Invoke_O_O_O_O__O(arg_2104, arg_2105, arg_2106, arg_2107) } else { linked_2102.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2101, arg_2104, arg_2105, arg_2106, arg_2107) }
//line :246:1
								var temp__1927000414__auto____36 any = A_arbace_cpp_inline_A_const_103.Invoke_O__O(r__35)




								if jrt.J2g_Truth(temp__1927000414__auto____36) { var u__37 any = temp__1927000414__auto____36; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_67.GetRawRoot__O()); var tmp21 any = A_arbace_cpp_inline_A_const_163.GetRawRoot__O(); var tmp22 any; var root_2149 any = A_arbace_cpp_inline_A_const_164.GetRawRoot__O(); var linked_2150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2149, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_2151 lang.IFn
									if linked_2150 == nil { ifn_2151 = lang.IFn_Cast(root_2149) } else { ifn_2151 = nil }; var arg_2152 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var arg_2153 any = lang.PersistentVector_EMPTY.Ref(); if linked_2150 == nil { tmp22 = ifn_2151.Invoke_O_O__O(arg_2152, arg_2153) } else { tmp22 = linked_2150.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_2149, arg_2152, arg_2153) }; tmp20.Invoke_O_O_O_O_O__O(resumes__8, tmp21, u__37, tmp22, A_arbace_cpp_inline_A_const_122.Invoke_O__O(r__35))
//line :251:1
									var seq_113000169__38 any; var root_2108 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_2109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2108, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2110 lang.IFn

									if linked_2109 == nil { ifn_2110 = lang.IFn_Cast(root_2108) } else { ifn_2110 = nil }; var arg_2111 any = A_arbace_cpp_inline_A_const_123.Invoke_O__O(r__35); if linked_2109 == nil { seq_113000169__38 = ifn_2110.Invoke_O__O(arg_2111) } else { seq_113000169__38 = linked_2109.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2108, arg_2111) }
//line :251:1
									var chunk_113000170__39 any; var count_113000171__40 int64 = 0; var i_113000172__41 int64 = 0; L5: for {

										if lang.Numbers_Lt_J_J__Z_NoInit(i_113000172__41, count_113000171__40) { var p__42_2 any = lang.Indexed_Cast(chunk_113000170__39).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_113000172__41)); var root_2154 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2154, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2156 lang.IFn; if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; var arg_2157 any = outer_pads__9; var arg_2158 any = A_arbace_cpp_inline_A_const_27.GetRawRoot__O(); var arg_2159 any = p__42_2; var arg_2160 any = u__37; if linked_2155 == nil { ifn_2156.Invoke_O_O_O_O__O(arg_2157, arg_2158, arg_2159, arg_2160) } else { linked_2155.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2154, arg_2157, arg_2158, arg_2159, arg_2160) }; seq_113000169__38, chunk_113000170__39, count_113000171__40, i_113000172__41 = seq_113000169__38, chunk_113000170__39, count_113000171__40, lang.Numbers_Unchecked_inc_J__J_NoInit(i_113000172__41); continue L5 } else { var temp__1927000414__auto____42 any; var root_2112 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_2113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2112, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2114 lang.IFn; if linked_2113 == nil { ifn_2114 = lang.IFn_Cast(root_2112) } else { ifn_2114 = nil }; var arg_2115 any = seq_113000169__38; if linked_2113 == nil { temp__1927000414__auto____42 = ifn_2114.Invoke_O__O(arg_2115) } else { temp__1927000414__auto____42 = linked_2113.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2112, arg_2115) }; if jrt.J2g_Truth(temp__1927000414__auto____42) { var seq_113000169__43 any = temp__1927000414__auto____42; var tmp23 any; var root_2116 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2118 lang.IFn; if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any = seq_113000169__43; if linked_2117 == nil { tmp23 = ifn_2118.Invoke_O__O(arg_2119) } else { tmp23 = linked_2117.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2116, arg_2119) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____44 any; var root_2120 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = seq_113000169__43; if linked_2121 == nil { c__1927000678__auto____44 = ifn_2122.Invoke_O__O(arg_2123) } else { c__1927000678__auto____44 = linked_2121.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2120, arg_2123) }; var tmp24 any; var root_2161 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2163 lang.IFn; if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any = seq_113000169__43; if linked_2162 == nil { tmp24 = ifn_2163.Invoke_O__O(arg_2164) } else { tmp24 = linked_2162.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2161, arg_2164) }; seq_113000169__38, chunk_113000170__39, count_113000171__40, i_113000172__41 = tmp24, c__1927000678__auto____44, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____44))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L5 } else { var p__44 any; var root_2124 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_2125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2124, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2126 lang.IFn; if linked_2125 == nil { ifn_2126 = lang.IFn_Cast(root_2124) } else { ifn_2126 = nil }; var arg_2127 any = seq_113000169__43; if linked_2125 == nil { p__44 = ifn_2126.Invoke_O__O(arg_2127) } else { p__44 = linked_2125.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2124, arg_2127) }; var root_2165 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_2166 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2165, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2167 lang.IFn; if linked_2166 == nil { ifn_2167 = lang.IFn_Cast(root_2165) } else { ifn_2167 = nil }; var arg_2168 any = outer_pads__9; var arg_2169 any = A_arbace_cpp_inline_A_const_27.GetRawRoot__O(); var arg_2170 any = p__44; var arg_2171 any = u__37; if linked_2166 == nil { ifn_2167.Invoke_O_O_O_O__O(arg_2168, arg_2169, arg_2170, arg_2171) } else { linked_2166.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2165, arg_2168, arg_2169, arg_2170, arg_2171) }; var tmp25 any; var root_2172 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2174 lang.IFn; if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = seq_113000169__43; if linked_2173 == nil { tmp25 = ifn_2174.Invoke_O__O(arg_2175) } else { tmp25 = linked_2173.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2172, arg_2175) }; seq_113000169__38, chunk_113000170__39, count_113000171__40, i_113000172__41 = tmp25, nil, 0, 0; continue L5 } } }
//line :251:1
										break L5
									}
								}
								var tmp26 any; var and__1927000168__auto____36 any = A_arbace_cpp_inline_A_const_127.Invoke_O__O(r__35); if jrt.J2g_Truth(and__1927000168__auto____36) { var root_2128 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any; var root_2132 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = personality__10; if linked_2133 == nil { arg_2131 = ifn_2134.Invoke_O__O(arg_2135) } else { arg_2131 = linked_2133.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2132, arg_2135) }; if linked_2129 == nil { tmp26 = ifn_2130.Invoke_O__O(arg_2131) } else { tmp26 = linked_2129.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2128, arg_2131) } } else { tmp26 = and__1927000168__auto____36 }; if jrt.J2g_Truth(tmp26) { var root_2136 any = A_arbace_cpp_inline_A_const_161.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_2138 lang.IFn; if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any = personality__10; var arg_2140 any = A_arbace_cpp_inline_A_const_127.Invoke_O__O(r__35); if linked_2137 == nil { ifn_2138.Invoke_O_O__O(arg_2139, arg_2140) } else { linked_2137.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_2136, arg_2139, arg_2140) } }
//line :246:1
								var bs__36 any = A_arbace_cpp_inline_A_const_117.Invoke_O__O(r__35); var root_2176 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2176, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2178 lang.IFn









								if linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any = out__11; var arg_2180 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var arg_2181 any; var root_2182 any = A_arbace_cpp_inline_A_const_77.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_2184 lang.IFn; if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any = bs__36; if linked_2183 == nil { arg_2181 = ifn_2184.Invoke_O__O(arg_2185) } else { arg_2181 = linked_2183.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_2182, arg_2185) }; if linked_2177 == nil { ifn_2178.Invoke_O_O_O__O(arg_2179, arg_2180, arg_2181) } else { linked_2177.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2176, arg_2179, arg_2180, arg_2181) }
								var tmp27 any; var root_2186 any = A_arbace_cpp_inline_A_const_97.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = bs__36; if linked_2187 == nil { tmp27 = ifn_2188.Invoke_O__O(arg_2189) } else { tmp27 = linked_2187.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_2186, arg_2189) }; G__113000160__27_ = tmp27; continue L4 }
//line :237:1
						break L4 }; var tmp28 any; var root_2190 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = seq_113000137__18; if linked_2191 == nil { tmp28 = ifn_2192.Invoke_O__O(arg_2193) } else { tmp28 = linked_2191.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2190, arg_2193) }; seq_113000137__13, chunk_113000138__14, count_113000139__15, i_113000140__16 = tmp28, nil, 0, 0; continue L1 } } }
//line :224:1
		break L1 }; var tmp29 any; var root_1305 any =

































	A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any; var root_1309 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = changed__12; if linked_1310 == nil { arg_1308 = ifn_1311.Invoke_O__O(arg_1312) } else { arg_1308 = linked_1310.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1309, arg_1312) }; if linked_1306 == nil { tmp29 = ifn_1307.Invoke_O__O(arg_1308) } else { tmp29 = linked_1306.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1305, arg_1308) }; if jrt.J2g_Truth(tmp29) { return d__0 } else { var final__13 any; var fnbody__1318 any = A_arbace_cpp_inline_inline_into_final__113000176_A_New_O(splits__7); var tmp30 *jrt.Class
		var fncls__1317 /*line :258:1*/*jrt.Class = A_arbace_cpp_inline_inline_into_final__113000176_A_fn_class

		if fncls__1317 == nil { var fncls__1317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__1318); A_arbace_cpp_inline_inline_into_final__113000176_A_fn_class = fncls__1317d; tmp30 = fncls__1317d } else { tmp30 = fncls__1317 }; final__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1318, tmp30, nil)
//line :258:1
		var bs__14 any; var root_1319 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1321 lang.IFn

		if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = out__11; if linked_1320 == nil { bs__14 = ifn_1321.Invoke_O__O(arg_1322) } else { bs__14 = linked_1320.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1319, arg_1322) }
//line :258:1
		var by_label__15 any; var root_1323 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1325 lang.IFn



		if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1327 any; var root_1328 any = A_arbace_cpp_inline_A_const_60.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any; var fnbody__1338 any = A_arbace_cpp_inline_inline_into_fn__113000178_A_New(); var tmp31 *jrt.Class; var fncls__1337 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000178_A_fn_class; if fncls__1337 == nil { var fncls__1337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_cpp_inline_inline_into_fn__113000178_A_fn_class = fncls__1337d; tmp31 = fncls__1337d } else { tmp31 = fncls__1337 }; arg_1331 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1338, tmp31, nil); var arg_1332 any = bs__14; if linked_1329 == nil { arg_1327 = ifn_1330.Invoke_O_O__O(arg_1331, arg_1332) } else { arg_1327 = linked_1329.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1328, arg_1331, arg_1332) }; if linked_1324 == nil { by_label__15 = ifn_1325.Invoke_O_O__O(arg_1326, arg_1327) } else { by_label__15 = linked_1324.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1323, arg_1326, arg_1327) }
//line :258:1
		var lp_of__16 any; var fnbody__1363 any = A_arbace_cpp_inline_inline_into_lp_of__113000180_A_New_O(by_label__15); var tmp32 *jrt.Class
		var fncls__1362 /*line :258:1*/*jrt.Class = A_arbace_cpp_inline_inline_into_lp_of__113000180_A_fn_class





		if fncls__1362 == nil { var fncls__1362d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__1363); A_arbace_cpp_inline_inline_into_lp_of__113000180_A_fn_class = fncls__1362d; tmp32 = fncls__1362d } else { tmp32 = fncls__1362 }; lp_of__16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1363, tmp32, nil)
//line :258:1
		var bs__17 any; var root_1364 any = A_arbace_cpp_inline_A_const_58.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1366 lang.IFn






		if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any; var fnbody__1444 any = A_arbace_cpp_inline_inline_into_fn__113000185_A_New_O(final__13); var tmp33 *jrt.Class; var fncls__1443 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000185_A_fn_class; if fncls__1443 == nil { var fncls__1443d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__1444); A_arbace_cpp_inline_inline_into_fn__113000185_A_fn_class = fncls__1443d; tmp33 = fncls__1443d } else { tmp33 = fncls__1443 }; arg_1367 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1444, tmp33, nil); var arg_1368 any = bs__14; if linked_1365 == nil { bs__17 = ifn_1366.Invoke_O_O__O(arg_1367, arg_1368) } else { bs__17 = linked_1365.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1364, arg_1367, arg_1368) }
//line :258:1
		var bs__18 any; var root_1445 any = A_arbace_cpp_inline_A_const_58.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1447 lang.IFn




















		if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any; var fnbody__1500 any = A_arbace_cpp_inline_inline_into_fn__113000202_A_New_O_O(lp_of__16, outer_pads__9); var tmp34 *jrt.Class; var fncls__1499 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000202_A_fn_class; if fncls__1499 == nil { var fncls__1499d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1500); A_arbace_cpp_inline_inline_into_fn__113000202_A_fn_class = fncls__1499d; tmp34 = fncls__1499d } else { tmp34 = fncls__1499 }; arg_1448 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1500, tmp34, nil); var arg_1449 any = bs__17; if linked_1446 == nil { bs__18 = ifn_1447.Invoke_O_O__O(arg_1448, arg_1449) } else { bs__18 = linked_1446.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1445, arg_1448, arg_1449) }
//line :258:1
		var bs__19 any; var root_1501 any = A_arbace_cpp_inline_A_const_148.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1503 lang.IFn



























		if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any; var fnbody__1634 any = A_arbace_cpp_inline_inline_into_fn__113000210_A_New_O(final__13); var tmp35 *jrt.Class; var fncls__1633 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000210_A_fn_class
		if fncls__1633 == nil { var fncls__1633d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__1634); A_arbace_cpp_inline_inline_into_fn__113000210_A_fn_class = fncls__1633d; tmp35 = fncls__1633d } else { tmp35 = fncls__1633 }; arg_1504 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1634, tmp35, nil)
//line :286:1
		var arg_1505 any = bs__18; var arg_1506 any; var root_1635 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = resumes__8; if linked_1636 == nil { arg_1506 = ifn_1637.Invoke_O__O(arg_1638) } else { arg_1506 = linked_1636.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1635, arg_1638) }; if linked_1502 == nil { bs__19 = ifn_1503.Invoke_O_O_O__O(arg_1504, arg_1505, arg_1506) } else { bs__19 = linked_1502.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1501, arg_1504, arg_1505, arg_1506) }
//line :258:1
		var vec__113000173__20 any = bs__19; var seq__113000174__21 any; var root_1639 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1641 lang.IFn

		if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = vec__113000173__20; if linked_1640 == nil { seq__113000174__21 = ifn_1641.Invoke_O__O(arg_1642) } else { seq__113000174__21 = linked_1640.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1639, arg_1642) }
//line :258:1
		var first__113000175__22 any; var root_1643 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1645 lang.IFn

		if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = seq__113000174__21; if linked_1644 == nil { first__113000175__22 = ifn_1645.Invoke_O__O(arg_1646) } else { first__113000175__22 = linked_1644.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1643, arg_1646) }
//line :258:1
		var seq__113000174__23 any; var root_1647 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1649 lang.IFn

		if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = seq__113000174__21; if linked_1648 == nil { seq__113000174__23 = ifn_1649.Invoke_O__O(arg_1650) } else { seq__113000174__23 = linked_1648.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1647, arg_1650) }
//line :258:1
		var e__24 any = first__113000175__22; var more__25 any = seq__113000174__23; var body__26 any; var root_1651 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1653 lang.IFn













































		if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any; var root_1655 any = A_arbace_cpp_inline_A_const_47.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1655, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1657 lang.IFn; if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any; var root_1660 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = A_arbace_cpp_inline_A_const_32.GetRawRoot__O(); var arg_1664 any = A_arbace_cpp_inline_A_const_156; var arg_1665 any; var root_1667 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = e__24; if linked_1668 == nil { arg_1665 = ifn_1669.Invoke_O__O(arg_1670) } else { arg_1665 = linked_1668.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1667, arg_1670) }; var arg_1666 any; var root_1671 any = A_arbace_cpp_inline_A_const_29.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any; var root_1676 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = allocas__6; if linked_1677 == nil { arg_1674 = ifn_1678.Invoke_O__O(arg_1679) } else { arg_1674 = linked_1677.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1676, arg_1679) }; var arg_1675 any; var root_1680 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = e__24; if linked_1681 == nil { arg_1675 = ifn_1682.Invoke_O__O(arg_1683) } else { arg_1675 = linked_1681.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1680, arg_1683) }; if linked_1672 == nil { arg_1666 = ifn_1673.Invoke_O_O__O(arg_1674, arg_1675) } else { arg_1666 = linked_1672.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1671, arg_1674, arg_1675) }; if linked_1661 == nil { arg_1658 = ifn_1662.Invoke_O_O_O_O__O(arg_1663, arg_1664, arg_1665, arg_1666) } else { arg_1658 = linked_1661.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1660, arg_1663, arg_1664, arg_1665, arg_1666) }; var arg_1659 any; var root_1684 any = A_arbace_cpp_inline_A_const_60.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1686 lang.IFn
		if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any; var fnbody__1709 any = A_arbace_cpp_inline_inline_into_fn__113000236_A_New(); var tmp36 *jrt.Class; var fncls__1708 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000236_A_fn_class; if fncls__1708 == nil { var fncls__1708d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_cpp_inline_inline_into_fn__113000236_A_fn_class = fncls__1708d; tmp36 = fncls__1708d } else { tmp36 = fncls__1708 }; arg_1687 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1709, tmp36, nil); var arg_1688 any = more__25; if linked_1685 == nil { arg_1659 = ifn_1686.Invoke_O_O__O(arg_1687, arg_1688) } else { arg_1659 = linked_1685.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1684, arg_1687, arg_1688) }
//line :304:1
		if linked_1656 == nil { arg_1654 = ifn_1657.Invoke_O_O__O(arg_1658, arg_1659) } else { arg_1654 = linked_1656.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1655, arg_1658, arg_1659) }; if linked_1652 == nil { body__26 = ifn_1653.Invoke_O__O(arg_1654) } else { body__26 = linked_1652.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1651, arg_1654) }
//line :258:1
		var d__27 any; var root_1710 any = A_arbace_cpp_inline_A_const_158.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, A_arbace_cpp_inline_set_opt_A_fn_class); var ifn_1712 lang.IFn















































		if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = d__0; var arg_1714 any = A_arbace_cpp_inline_A_const_28; var arg_1715 any = body__26; if linked_1711 == nil { d__27 = ifn_1712.Invoke_O_O_O__O(arg_1713, arg_1714, arg_1715) } else { d__27 = linked_1711.(*A_arbace_cpp_inline_set_opt_A).Invoke_O_O_O_O__O(root_1710, arg_1713, arg_1714, arg_1715) }
		var tmp37 any; var root_1716 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1718 lang.IFn; if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = personality__10; if linked_1717 == nil { tmp37 = ifn_1718.Invoke_O__O(arg_1719) } else { tmp37 = linked_1717.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1716, arg_1719) }; if jrt.J2g_Truth(tmp37) { var root_1720 any = A_arbace_cpp_inline_A_const_158.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, A_arbace_cpp_inline_set_opt_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = d__27; var arg_1724 any = A_arbace_cpp_inline_A_const_127; var arg_1725 any; var root_1726 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = personality__10; if linked_1727 == nil { arg_1725 = ifn_1728.Invoke_O__O(arg_1729) } else { arg_1725 = linked_1727.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1726, arg_1729) }; if linked_1721 == nil { return ifn_1722.Invoke_O_O_O__O(arg_1723, arg_1724, arg_1725) } else { return linked_1721.(*A_arbace_cpp_inline_set_opt_A).Invoke_O_O_O_O__O(root_1720, arg_1723, arg_1724, arg_1725) } } else { return d__27 } } }
//line :228:1
func A_arbace_cpp_inline_inline_into_fn__113000132_A_New() *A_arbace_cpp_inline_inline_into_fn__113000132_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000132_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000132_A) Ctor() {}
//line :228:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000132_A) Invoke_O_O__O(self, p__113000131__1 any) any { var vec__113000133__2 any = p__113000131__1; var seq__113000134__3 any; var root_1250 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = vec__113000133__2; if linked_1251 == nil { seq__113000134__3 = ifn_1252.Invoke_O__O(arg_1253) } else { seq__113000134__3 = linked_1251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1250, arg_1253) }; var first__113000135__4 any; var root_1254 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = seq__113000134__3; if linked_1255 == nil { first__113000135__4 = ifn_1256.Invoke_O__O(arg_1257) } else { first__113000135__4 = linked_1255.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1254, arg_1257) }; var seq__113000134__5 any; var root_1258 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = seq__113000134__3; if linked_1259 == nil { seq__113000134__5 = ifn_1260.Invoke_O__O(arg_1261) } else { seq__113000134__5 = linked_1259.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1258, arg_1261) }; var ___6 any = first__113000135__4; var first__113000135__7 any; var root_1262 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1264 lang.IFn; _ = ___6; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = seq__113000134__5; if linked_1263 == nil { first__113000135__7 = ifn_1264.Invoke_O__O(arg_1265) } else { first__113000135__7 = linked_1263.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1262, arg_1265) }; var seq__113000134__8 any; var root_1266 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = seq__113000134__5; if linked_1267 == nil { seq__113000134__8 = ifn_1268.Invoke_O__O(arg_1269) } else { seq__113000134__8 = linked_1267.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1266, arg_1269) }; var l__9 any = first__113000135__7; var is__10 any = seq__113000134__8; var root_1270 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1272 lang.IFn; if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = lang.Tuple_Create_O__IPersistentVector(l__9); var arg_1274 any = is__10; if linked_1271 == nil { return ifn_1272.Invoke_O_O__O(arg_1273, arg_1274) } else { return linked_1271.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1270, arg_1273, arg_1274) } }










func A_arbace_cpp_inline_inline_into_fn__113000151_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_inline_into_fn__113000151_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000151_A{}; t.Ctor_O_O(p0, p1); return t }
//line :239:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000151_A) Ctor_O_O(c__d, c__ai any) { t.F_d = c__d; t.F_ai = c__ai }
//line :239:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000151_A) Invoke_O_O_O__O(self, j__1, x__2 any) any { var o__3 any; var root_1783 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = x__2; if linked_1784 == nil { o__3 = ifn_1785.Invoke_O__O(arg_1786) } else { o__3 = linked_1784.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1783, arg_1786) }; var tmp1 any; var and__1927000168__auto____4 any; var tmp2 lang.IFn =
													lang.IFn_Cast(A_arbace_cpp_inline_A_const_159); var tmp3 any; var root_1813 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, A_arbace_cpp_inline_head_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = o__3; if linked_1814 == nil { tmp3 = ifn_1815.Invoke_O__O(arg_1816) } else { tmp3 = linked_1814.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_1813, arg_1816) }; and__1927000168__auto____4 = tmp2.Invoke_O__O(tmp3); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1787 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = t.F_ai; var arg_1791 any; var root_1792 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, A_arbace_cpp_inline_gname_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = lang.RT_Nth_O_I__O_NoInit(o__3, lang.RT_IntCast_J__I_NoInit(2)); if linked_1793 == nil { arg_1791 = ifn_1794.Invoke_O__O(arg_1795) } else { arg_1791 = linked_1793.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_1792, arg_1795) }; if linked_1788 == nil { and__1927000168__auto____5 = ifn_1789.Invoke_O_O__O(arg_1790, arg_1791) } else { and__1927000168__auto____5 = linked_1788.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1787, arg_1790, arg_1791) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
														var root_1796 any = A_arbace_cpp_inline_A_const_101.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any; var root_1801 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, A_arbace_cpp_inline_gname_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any; var root_1805 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any = t.F_d; if linked_1806 == nil { arg_1804 = ifn_1807.Invoke_O__O(arg_1808) } else { arg_1804 = linked_1806.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1805, arg_1808) }; if linked_1802 == nil { arg_1799 = ifn_1803.Invoke_O__O(arg_1804) } else { arg_1799 = linked_1802.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_1801, arg_1804) }; var arg_1800 any; var root_1809 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, A_arbace_cpp_inline_gname_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = lang.RT_Nth_O_I__O_NoInit(o__3, lang.RT_IntCast_J__I_NoInit(2)); if linked_1810 == nil { arg_1800 = ifn_1811.Invoke_O__O(arg_1812) } else { arg_1800 = linked_1810.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_1809, arg_1812) }; if linked_1797 == nil { tmp1 = ifn_1798.Invoke_O_O__O(arg_1799, arg_1800) } else { tmp1 = linked_1797.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1796, arg_1799, arg_1800) } } else {
//line :240:1
			tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return j__1 } else { return nil } }
//line :239:1
func A_arbace_cpp_inline_inline_into_fn__113000167_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_inline_into_fn__113000167_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000167_A{}; t.Ctor_O_O(p0, p1); return t }
//line :239:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000167_A) Ctor_O_O(c__d, c__ai any) { t.F_d = c__d; t.F_ai = c__ai }
//line :239:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000167_A) Invoke_O_O_O__O(self, j__1, x__2 any) any { var o__3 any; var root_2005 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_2006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2005, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_2007 lang.IFn; if linked_2006 == nil { ifn_2007 = lang.IFn_Cast(root_2005) } else { ifn_2007 = nil }; var arg_2008 any = x__2; if linked_2006 == nil { o__3 = ifn_2007.Invoke_O__O(arg_2008) } else { o__3 = linked_2006.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_2005, arg_2008) }; var tmp1 any; var and__1927000168__auto____4 any; var tmp2 lang.IFn =
													lang.IFn_Cast(A_arbace_cpp_inline_A_const_165); var tmp3 any; var root_2035 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, A_arbace_cpp_inline_head_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = o__3; if linked_2036 == nil { tmp3 = ifn_2037.Invoke_O__O(arg_2038) } else { tmp3 = linked_2036.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2035, arg_2038) }; and__1927000168__auto____4 = tmp2.Invoke_O__O(tmp3); if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_2009 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = t.F_ai; var arg_2013 any; var root_2014 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = lang.RT_Nth_O_I__O_NoInit(o__3, lang.RT_IntCast_J__I_NoInit(2)); if linked_2015 == nil { arg_2013 = ifn_2016.Invoke_O__O(arg_2017) } else { arg_2013 = linked_2015.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2014, arg_2017) }; if linked_2010 == nil { and__1927000168__auto____5 = ifn_2011.Invoke_O_O__O(arg_2012, arg_2013) } else { and__1927000168__auto____5 = linked_2010.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2009, arg_2012, arg_2013) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
														var root_2018 any = A_arbace_cpp_inline_A_const_101.GetRawRoot__O(); var linked_2019 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2018, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2020 lang.IFn; if linked_2019 == nil { ifn_2020 = lang.IFn_Cast(root_2018) } else { ifn_2020 = nil }; var arg_2021 any; var root_2023 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2023, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2025 lang.IFn; if linked_2024 == nil { ifn_2025 = lang.IFn_Cast(root_2023) } else { ifn_2025 = nil }; var arg_2026 any; var root_2027 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = t.F_d; if linked_2028 == nil { arg_2026 = ifn_2029.Invoke_O__O(arg_2030) } else { arg_2026 = linked_2028.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2027, arg_2030) }; if linked_2024 == nil { arg_2021 = ifn_2025.Invoke_O__O(arg_2026) } else { arg_2021 = linked_2024.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2023, arg_2026) }; var arg_2022 any; var root_2031 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = lang.RT_Nth_O_I__O_NoInit(o__3, lang.RT_IntCast_J__I_NoInit(2)); if linked_2032 == nil { arg_2022 = ifn_2033.Invoke_O__O(arg_2034) } else { arg_2022 = linked_2032.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2031, arg_2034) }; if linked_2019 == nil { tmp1 = ifn_2020.Invoke_O_O__O(arg_2021, arg_2022) } else { tmp1 = linked_2019.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2018, arg_2021, arg_2022) } } else {
//line :240:1
			tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return j__1 } else { return nil } }



















func A_arbace_cpp_inline_inline_into_final__113000176_A_New_O(p0 any) *A_arbace_cpp_inline_inline_into_final__113000176_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_final__113000176_A{}; t.Ctor_O(p0); return t }
//line :260:1
func (t *A_arbace_cpp_inline_inline_into_final__113000176_A) Ctor_O(c__splits any) { t.F_splits = c__splits }
//line :260:1
func (t *A_arbace_cpp_inline_inline_into_final__113000176_A) Invoke_O_O__O(self, l__1 any) any { var temp__1927000408__auto____2 any; var tmp1 any; var root_1313 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any = t.F_splits; if linked_1314 == nil { tmp1 = ifn_1315.Invoke_O__O(arg_1316) } else { tmp1 = linked_1314.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1313, arg_1316) }; temp__1927000408__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, l__1); if jrt.J2g_Truth(temp__1927000408__auto____2) { var n__3 any = temp__1927000408__auto____2; return lang.IFn_Cast(self).Invoke_O__O(n__3) } else { return l__1 } }

func A_arbace_cpp_inline_inline_into_fn__113000178_A_New() *A_arbace_cpp_inline_inline_into_fn__113000178_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000178_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000178_A) Ctor() {}
//line :262:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000178_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any; var root_1333 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1333, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1335 lang.IFn; if linked_1334 == nil { ifn_1335 = lang.IFn_Cast(root_1333) } else { ifn_1335 = nil }; var arg_1336 any = b__1; if linked_1334 == nil { tmp1 = ifn_1335.Invoke_O__O(arg_1336) } else { tmp1 = linked_1334.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1333, arg_1336) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, b__1) }

func A_arbace_cpp_inline_inline_into_lp_of__113000180_A_New_O(p0 any) *A_arbace_cpp_inline_inline_into_lp_of__113000180_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_lp_of__113000180_A{}; t.Ctor_O(p0); return t }
//line :264:1
func (t *A_arbace_cpp_inline_inline_into_lp_of__113000180_A) Ctor_O(c__by_label any) { t.F_by_label = c__by_label }
//line :264:1
func (t *A_arbace_cpp_inline_inline_into_lp_of__113000180_A) Invoke_O_O__O(self, u__1 any) any { var root_1339 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any; var root_1343 any = A_arbace_cpp_inline_A_const_91.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any; var fnbody__1357 any = A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A_New(); var tmp1 *jrt.Class; var fncls__1356 *jrt.Class = A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A_fn_class; if fncls__1356 == nil { var fncls__1356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A_fn_class = fncls__1356d; tmp1 = fncls__1356d } else { tmp1 = fncls__1356 }; arg_1346 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1357, tmp1, nil); var arg_1347 any; var root_1358 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = lang.RT_Get_O_O__O_NoInit(t.F_by_label, u__1); if linked_1359 == nil { arg_1347 = ifn_1360.Invoke_O__O(arg_1361) } else { arg_1347 = linked_1359.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1358, arg_1361) }; if linked_1344 == nil { arg_1342 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { arg_1342 = linked_1344.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) }; if linked_1340 == nil { return ifn_1341.Invoke_O__O(arg_1342) } else { return linked_1340.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1339, arg_1342) } }
//line :264:1
func A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A_New() *A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A{}; t.Ctor(); return t }
//line :264:1
func (t *A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A) Ctor() {}
//line :264:1
func (t *A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A) Invoke_O_O__O(self, p1__113000128_SHARP___1 any) any { var tmp1 any = A_arbace_cpp_inline_A_const_142; var tmp2 any; var root_1348 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, A_arbace_cpp_inline_head_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any; var root_1352 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = p1__113000128_SHARP___1; if linked_1353 == nil { arg_1351 = ifn_1354.Invoke_O__O(arg_1355) } else { arg_1351 = linked_1353.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1352, arg_1355) }; if linked_1349 == nil { tmp2 = ifn_1350.Invoke_O__O(arg_1351) } else { tmp2 = linked_1349.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_1348, arg_1351) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() }
func A_arbace_cpp_inline_inline_into_fn__113000185_A_New_O(p0 any) *A_arbace_cpp_inline_inline_into_fn__113000185_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000185_A{}; t.Ctor_O(p0); return t }
//line :265:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000185_A) Ctor_O(c__final any) { t.F_final = c__final }
//line :265:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000185_A) Invoke_O_O__O(self, p__113000184__1 any) any { var vec__113000186__2 any = p__113000184__1; var seq__113000187__3 any; var root_1369 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = vec__113000186__2; if linked_1370 == nil { seq__113000187__3 = ifn_1371.Invoke_O__O(arg_1372) } else { seq__113000187__3 = linked_1370.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1369, arg_1372) }; var first__113000188__4 any; var root_1373 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = seq__113000187__3; if linked_1374 == nil { first__113000188__4 = ifn_1375.Invoke_O__O(arg_1376) } else { first__113000188__4 = linked_1374.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1373, arg_1376) }; var seq__113000187__5 any; var root_1377 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = seq__113000187__3; if linked_1378 == nil { seq__113000187__5 = ifn_1379.Invoke_O__O(arg_1380) } else { seq__113000187__5 = linked_1378.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1377, arg_1380) }; var l__6 any = first__113000188__4; var is__7 any = seq__113000187__5; var root_1381 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1383 lang.IFn; if
													linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = lang.Tuple_Create_O__IPersistentVector(l__6); var arg_1385 any; var root_1386 any = A_arbace_cpp_inline_A_const_60.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1388 lang.IFn; if
													linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any; var fnbody__1442 any = A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A_New_O(t.F_final); var tmp1 *jrt.Class; var fncls__1441 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A_fn_class; if fncls__1441 == nil { var fncls__1441d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__1442); A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A_fn_class = fncls__1441d; tmp1 = fncls__1441d } else { tmp1 = fncls__1441 }; arg_1389 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1442, tmp1, nil); var arg_1390 any = is__7; if linked_1387 == nil { arg_1385 = ifn_1388.Invoke_O_O__O(arg_1389, arg_1390) } else { arg_1385 = linked_1387.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1386, arg_1389, arg_1390) }; if /*line :266:1*/ linked_1382 == nil { return ifn_1383.Invoke_O_O__O(arg_1384, arg_1385) } else { return linked_1382.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1381, arg_1384, arg_1385) } }
func A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A_New_O(p0 any) *A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A{}; t.Ctor_O(p0); return t }
//line :267:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A) Ctor_O(c__final any) { t.F_final = c__final }
//line :267:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A) Invoke_O_O__O(self, i__1 any) any { var op__2 any; var root_1391 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1393 lang.IFn; if
														linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = i__1; if linked_1392 == nil { op__2 = ifn_1393.Invoke_O__O(arg_1394) } else { op__2 = linked_1392.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1391, arg_1394) }; var tmp1 any = A_arbace_cpp_inline_A_const_143; var tmp2 any; var root_1395 any =
														A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, A_arbace_cpp_inline_head_A_fn_class); var ifn_1397 lang.IFn; if

	linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = op__2; if linked_1396 == nil { tmp2 = ifn_1397.Invoke_O__O(arg_1398) } else { tmp2 = linked_1396.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_1395, arg_1398) }; if /*line :269:1*/ lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var vec__113000190__3 any = op__2; var seq__113000191__4 any; var root_1399 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1401 lang.IFn


		if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = vec__113000190__3; if linked_1400 == nil { seq__113000191__4 = ifn_1401.Invoke_O__O(arg_1402) } else { seq__113000191__4 = linked_1400.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1399, arg_1402) }
//line :269:1
		var first__113000192__5 any; var root_1403 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1405 lang.IFn


		if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = seq__113000191__4; if linked_1404 == nil { first__113000192__5 = ifn_1405.Invoke_O__O(arg_1406) } else { first__113000192__5 = linked_1404.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1403, arg_1406) }
//line :269:1
		var seq__113000191__6 any; var root_1407 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1409 lang.IFn


		if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any = seq__113000191__4; if linked_1408 == nil { seq__113000191__6 = ifn_1409.Invoke_O__O(arg_1410) } else { seq__113000191__6 = linked_1408.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1407, arg_1410) }
//line :269:1
		var ___7 any = first__113000192__5; var first__113000192__8 any; var root_1411 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1413 lang.IFn; _ = ___7


		if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = seq__113000191__6; if linked_1412 == nil { first__113000192__8 = ifn_1413.Invoke_O__O(arg_1414) } else { first__113000192__8 = linked_1412.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1411, arg_1414) }
//line :269:1
		var seq__113000191__9 any; var root_1415 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1417 lang.IFn


		if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = seq__113000191__6; if linked_1416 == nil { seq__113000191__9 = ifn_1417.Invoke_O__O(arg_1418) } else { seq__113000191__9 = linked_1416.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1415, arg_1418) }
//line :269:1
		var t__10 any = first__113000192__8; var ins__11 any = seq__113000191__9; var new__12 any; var root_1419 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1421 lang.IFn



		if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = A_arbace_cpp_inline_A_const_32.GetRawRoot__O(); var arg_1423 any = A_arbace_cpp_inline_A_const_144; var arg_1424 any = t__10; var arg_1425 any; var root_1426 any = A_arbace_cpp_inline_A_const_60.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any; var fnbody__1432 any = A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A_New_O(t.F_final); var tmp3 *jrt.Class; var fncls__1431 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A_fn_class; if fncls__1431 == nil { var fncls__1431d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__1432); A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A_fn_class = fncls__1431d; tmp3 = fncls__1431d } else { tmp3 = fncls__1431 }; arg_1429 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1432, tmp3, nil); var arg_1430 any = ins__11; if linked_1427 == nil { arg_1425 = ifn_1428.Invoke_O_O__O(arg_1429, arg_1430) } else { arg_1425 = linked_1427.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1426, arg_1429, arg_1430) }; if linked_1420 == nil { new__12 = ifn_1421.Invoke_O_O_O_O__O(arg_1422, arg_1423, arg_1424, arg_1425) } else { new__12 = linked_1420.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1419, arg_1422, arg_1423, arg_1424, arg_1425) }
		var tmp4 any; var root_1433 any = A_arbace_cpp_inline_A_const_71.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, A_arbace_cpp_inline_inst_def_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = i__1; if linked_1434 == nil { tmp4 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp4 = linked_1434.(*A_arbace_cpp_inline_inst_def_A).Invoke_O_O__O(root_1433, arg_1436) }; if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp6 any = A_arbace_cpp_inline_A_const_145; var tmp7 any; var root_1437 any = A_arbace_cpp_inline_A_const_71.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, A_arbace_cpp_inline_inst_def_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = i__1; if linked_1438 == nil { tmp7 = ifn_1439.Invoke_O__O(arg_1440) } else { tmp7 = linked_1438.(*A_arbace_cpp_inline_inst_def_A).Invoke_O_O__O(root_1437, arg_1440) }; return tmp5.Invoke_O_O_O__O(tmp6, tmp7, new__12) } else { return new__12 } } else {
//line :269:1
			if A_arbace_cpp_inline_A_const_17 != nil { return i__1 } else { return nil } } }



func A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A_New_O(p0 any) *A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A{}; t.Ctor_O(p0); return t }
//line :273:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A) Ctor_O(c__final any) { t.F_final = c__final }
//line :273:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A) Invoke_O_O__O(self, p__113000193__1 any) any { var vec__113000195__2 any = p__113000193__1; var v__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000195__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000195__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(v__3, lang.IFn_Cast(t.F_final).Invoke_O__O(b__4)) }





func A_arbace_cpp_inline_inline_into_fn__113000202_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_inline_into_fn__113000202_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000202_A{}; t.Ctor_O_O(p0, p1); return t }
//line :279:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000202_A) Ctor_O_O(c__lp_of, c__outer_pads any) { t.F_lp_of = c__lp_of; t.F_outer_pads = c__outer_pads }
//line :279:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000202_A) Invoke_O_O__O(self, p__113000201__1 any) any { var vec__113000203__2 any = p__113000201__1; var seq__113000204__3 any; var root_1450 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = vec__113000203__2; if linked_1451 == nil { seq__113000204__3 = ifn_1452.Invoke_O__O(arg_1453) } else { seq__113000204__3 = linked_1451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1450, arg_1453) }; var first__113000205__4 any; var root_1454 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = seq__113000204__3; if linked_1455 == nil { first__113000205__4 = ifn_1456.Invoke_O__O(arg_1457) } else { first__113000205__4 = linked_1455.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1454, arg_1457) }; var seq__113000204__5 any; var root_1458 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = seq__113000204__3; if linked_1459 == nil { seq__113000204__5 = ifn_1460.Invoke_O__O(arg_1461) } else { seq__113000204__5 = linked_1459.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1458, arg_1461) }; var l__6 any = first__113000205__4; var is__7 any = seq__113000204__5; var b__8 any = vec__113000203__2; var temp__1927000408__auto____9 any; var tmp1 any; var root_1462 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1464 lang.IFn; if
													linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = t.F_outer_pads; if linked_1463 == nil { tmp1 = ifn_1464.Invoke_O__O(arg_1465) } else { tmp1 = linked_1463.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1462, arg_1465) }; var tmp2 any = tmp1; var tmp3 any; var root_1466 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = b__8; if linked_1467 == nil { tmp3 = ifn_1468.Invoke_O__O(arg_1469) } else { tmp3 = linked_1467.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1466, arg_1469) }; temp__1927000408__auto____9 = lang.RT_Get_O_O__O_NoInit(tmp2, tmp3); if jrt.J2g_Truth(temp__1927000408__auto____9) { var u__10 any = temp__1927000408__auto____9; var root_1470 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1472 lang.IFn
														if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = lang.Tuple_Create_O__IPersistentVector(l__6); var arg_1474 any; var root_1475 any = A_arbace_cpp_inline_A_const_60.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any; var fnbody__1498 any = A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A_New_O_O(t.F_lp_of, u__10); var tmp4 *jrt.Class; var fncls__1497 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A_fn_class; if fncls__1497 == nil { var fncls__1497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__1498); A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A_fn_class = fncls__1497d; tmp4 = fncls__1497d } else { tmp4 = fncls__1497 }; arg_1478 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1498, tmp4, nil); var arg_1479 any = is__7; if linked_1476 == nil { arg_1474 = ifn_1477.Invoke_O_O__O(arg_1478, arg_1479) } else { arg_1474 = linked_1476.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1475, arg_1478, arg_1479) }; if linked_1471 == nil { return ifn_1472.Invoke_O_O__O(arg_1473, arg_1474) } else { return linked_1471.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1470, arg_1473, arg_1474) } } else {
//line :280:1
			return b__8 } }
func A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A{}; t.Ctor_O_O(p0, p1); return t }
//line :281:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A) Ctor_O_O(c__lp_of, c__u any) { t.F_lp_of = c__lp_of; t.F_u = c__u }
//line :281:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A) Invoke_O_O__O(self, p1__113000129_SHARP___1 any) any { var tmp1 any = A_arbace_cpp_inline_A_const_146; var tmp2 any; var root_1480 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, A_arbace_cpp_inline_head_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any; var root_1484 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = p1__113000129_SHARP___1; if linked_1485 == nil { arg_1483 = ifn_1486.Invoke_O__O(arg_1487) } else { arg_1483 = linked_1485.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1484, arg_1487) }; if linked_1481 == nil { tmp2 = ifn_1482.Invoke_O__O(arg_1483) } else { tmp2 = linked_1481.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_1480, arg_1483) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var root_1488 any = A_arbace_cpp_inline_A_const_147.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, A_arbace_cpp_inline_append_clauses_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = p1__113000129_SHARP___1; var arg_1492 any; var root_1493 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = lang.IFn_Cast(t.F_lp_of).Invoke_O__O(t.F_u); if linked_1494 == nil { arg_1492 = ifn_1495.Invoke_O__O(arg_1496) } else { arg_1492 = linked_1494.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1493, arg_1496) }; if linked_1489 == nil { return ifn_1490.Invoke_O_O__O(arg_1491, arg_1492) } else { return linked_1489.(*A_arbace_cpp_inline_append_clauses_A).Invoke_O_O_O__O(root_1488, arg_1491, arg_1492) } } else { return p1__113000129_SHARP___1 } }





func A_arbace_cpp_inline_inline_into_fn__113000210_A_New_O(p0 any) *A_arbace_cpp_inline_inline_into_fn__113000210_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000210_A{}; t.Ctor_O(p0); return t }
//line :287:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000210_A) Ctor_O(c__final any) { t.F_final = c__final }
//line :287:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000210_A) Invoke_O_O_O__O(self, bs__1, p__113000209__2 any) any { var vec__113000211__3 any = p__113000209__2; var u__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000211__3, lang.RT_IntCast_J__I_NoInit(0), nil); var rs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000211__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1507 any = A_arbace_cpp_inline_A_const_149.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1509 lang.IFn; if
														linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = rs__5; if linked_1508 == nil { tmp1 = ifn_1509.Invoke_O__O(arg_1510) } else { tmp1 = linked_1508.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1507, arg_1510) }; if jrt.J2g_Truth(tmp1) { return bs__1 } else { var body__6 any; var root_1511 any = A_arbace_cpp_inline_A_const_70.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1513 lang.IFn

		if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_46); var tmp3 any; var root_1515 any = A_arbace_cpp_inline_A_const_11.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any = u__4; if linked_1516 == nil { tmp3 = ifn_1517.Invoke_O__O(arg_1518) } else { tmp3 = linked_1516.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1515, arg_1518) }; arg_1514 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref(); if linked_1512 == nil { body__6 = ifn_1513.Invoke_O__O(arg_1514) } else { body__6 = linked_1512.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1511, arg_1514) }
		var root_1519 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1519, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1521 lang.IFn; if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_104.GetRawRoot__O()); var tmp5 *lang.Compiler_AOTFn; var fnbody__1632 any = A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A_New_O_O_O_O(t.F_final, u__4, body__6, rs__5); var tmp6 *jrt.Class; var fncls__1631 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A_fn_class
		if fncls__1631 == nil { var fncls__1631d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__1632); A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A_fn_class = fncls__1631d; tmp6 = fncls__1631d } else { tmp6 = fncls__1631 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1632, tmp6, nil)
//line :291:1
		arg_1522 = tmp4.Invoke_O_O__O(tmp5.Ref(), bs__1); if linked_1520 == nil { return ifn_1521.Invoke_O__O(arg_1522) } else { return linked_1520.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1519, arg_1522) } } }
func A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :292:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A) Ctor_O_O_O_O(c__final, c__u, c__body, c__rs any) { t.F_final = c__final; t.F_u = c__u; t.F_body = c__body; t.F_rs = c__rs }
//line :292:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A) Invoke_O_O__O(self, p__113000214__1 any) any { var vec__113000216__2 any = p__113000214__1; var seq__113000217__3 any; var root_1528 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any = vec__113000216__2; if linked_1529 == nil { seq__113000217__3 = ifn_1530.Invoke_O__O(arg_1531) } else { seq__113000217__3 = linked_1529.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1528, arg_1531) }; var first__113000218__4 any; var root_1532 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any = seq__113000217__3; if linked_1533 == nil { first__113000218__4 = ifn_1534.Invoke_O__O(arg_1535) } else { first__113000218__4 = linked_1533.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1532, arg_1535) }; var seq__113000217__5 any; var root_1536 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = seq__113000217__3; if linked_1537 == nil { seq__113000217__5 = ifn_1538.Invoke_O__O(arg_1539) } else { seq__113000217__5 = linked_1537.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1536, arg_1539) }; var l__6 any = first__113000218__4; var is__7 any = seq__113000217__5; var b__8 any = vec__113000216__2; if
															lang.Util_Equiv_O_O__Z_NoInit(l__6, t.F_u) { var vec__113000219__9 any; var root_1540 any = A_arbace_cpp_inline_A_const_150.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_1542 lang.IFn
																if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any; var fnbody__1559 any = A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A_New(); var tmp1 *jrt.Class; var fncls__1558 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A_fn_class; if fncls__1558 == nil { var fncls__1558d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A_fn_class = fncls__1558d; tmp1 = fncls__1558d } else { tmp1 = fncls__1558 }; arg_1543 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1559, tmp1, nil); var arg_1544 any = is__7; if linked_1541 == nil { vec__113000219__9 = ifn_1542.Invoke_O_O__O(arg_1543, arg_1544) } else { vec__113000219__9 = linked_1541.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_1540, arg_1543, arg_1544) }
//line :293:1
		var pre__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000219__9, lang.RT_IntCast_J__I_NoInit(0), nil); var vec__113000222__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000219__9, lang.RT_IntCast_J__I_NoInit(1), nil); var seq__113000223__12 any; var root_1560 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1562 lang.IFn
		if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = vec__113000222__11; if linked_1561 == nil { seq__113000223__12 = ifn_1562.Invoke_O__O(arg_1563) } else { seq__113000223__12 = linked_1561.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1560, arg_1563) }
//line :293:1
		var first__113000224__13 any; var root_1564 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1566 lang.IFn
		if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = seq__113000223__12; if linked_1565 == nil { first__113000224__13 = ifn_1566.Invoke_O__O(arg_1567) } else { first__113000224__13 = linked_1565.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1564, arg_1567) }
//line :293:1
		var seq__113000223__14 any; var root_1568 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1570 lang.IFn
		if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = seq__113000223__12; if linked_1569 == nil { seq__113000223__14 = ifn_1570.Invoke_O__O(arg_1571) } else { seq__113000223__14 = linked_1569.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1568, arg_1571) }
//line :293:1
		var lp__15 any = first__113000224__13; var post__16 any = seq__113000223__14; var v__17 any; var root_1572 any = A_arbace_cpp_inline_A_const_71.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, A_arbace_cpp_inline_inst_def_A_fn_class); var ifn_1574 lang.IFn

		if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = lp__15; if linked_1573 == nil { v__17 = ifn_1574.Invoke_O__O(arg_1575) } else { v__17 = linked_1573.(*A_arbace_cpp_inline_inst_def_A).Invoke_O_O__O(root_1572, arg_1575) }
//line :293:1
		var v0__18 any; var root_1576 any = A_arbace_cpp_inline_A_const_70.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1578 lang.IFn


		if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_49); var tmp3 any; var root_1580 any = A_arbace_cpp_inline_A_const_11.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = v__17; if linked_1581 == nil { tmp3 = ifn_1582.Invoke_O__O(arg_1583) } else { tmp3 = linked_1581.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_1580, arg_1583) }; arg_1579 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref(); if linked_1577 == nil { v0__18 = ifn_1578.Invoke_O__O(arg_1579) } else { v0__18 = linked_1577.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1576, arg_1579) }
//line :293:1
		var t__19 any; var root_1584 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1584, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1586 lang.IFn



		if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any; var root_1588 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = lp__15; if linked_1589 == nil { arg_1587 = ifn_1590.Invoke_O__O(arg_1591) } else { arg_1587 = linked_1589.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1588, arg_1591) }; if linked_1585 == nil { t__19 = ifn_1586.Invoke_O__O(arg_1587) } else { t__19 = linked_1585.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1584, arg_1587) }
//line :293:1
		var tmp4 any; var root_1592 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1594 lang.IFn




		if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = lang.Tuple_Create_O__IPersistentVector(l__6); var arg_1596 any; var root_1597 any = A_arbace_cpp_inline_A_const_29.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = pre__10; var arg_1601 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp6 any = A_arbace_cpp_inline_A_const_152; var tmp7 any; var root_1602 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = lp__15; if linked_1603 == nil { tmp7 = ifn_1604.Invoke_O__O(arg_1605) } else { tmp7 = linked_1603.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1602, arg_1605) }; arg_1601 = lang.Tuple_Create_O_O__IPersistentVector(tmp5.Invoke_O_O_O__O(tmp6, v0__18, tmp7), lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()).Invoke_O_O__O(A_arbace_cpp_inline_A_const_153, t.F_body)); if linked_1598 == nil { arg_1596 = ifn_1599.Invoke_O_O__O(arg_1600, arg_1601) } else { arg_1596 = linked_1598.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1597, arg_1600, arg_1601) }; if linked_1593 == nil { tmp4 = ifn_1594.Invoke_O_O__O(arg_1595, arg_1596) } else { tmp4 = linked_1593.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1592, arg_1595, arg_1596) }
//line :293:1
		var tmp8 any = tmp4; var tmp9 any; var root_1606 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1608 lang.IFn





		if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = lang.Tuple_Create_O__IPersistentVector(t.F_body); var arg_1610 any; var root_1611 any = A_arbace_cpp_inline_A_const_47.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_32.GetRawRoot__O()); var tmp11 any = A_arbace_cpp_inline_A_const_154; var tmp12 any; var root_1616 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = A_arbace_cpp_inline_A_const_32.GetRawRoot__O(); var arg_1620 any = A_arbace_cpp_inline_A_const_155; var arg_1621 any = t__19; var arg_1622 any = lang.Tuple_Create_O_O__IPersistentVector(v0__18, l__6); var arg_1623 any; var root_1624 any = A_arbace_cpp_inline_A_const_60.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any; var fnbody__1630 any = A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A_New_O(t.F_final); var tmp13 *jrt.Class; var fncls__1629 *jrt.Class = A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A_fn_class; if fncls__1629 == nil { var fncls__1629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__1630); A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A_fn_class = fncls__1629d; tmp13 = fncls__1629d } else { tmp13 = fncls__1629 }; arg_1627 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1630, tmp13, nil); var arg_1628 any = t.F_rs; if linked_1625 == nil { arg_1623 = ifn_1626.Invoke_O_O__O(arg_1627, arg_1628) } else { arg_1623 = linked_1625.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1624, arg_1627, arg_1628) }; if linked_1617 == nil { tmp12 = ifn_1618.Invoke_O_O_O_O_O__O(arg_1619, arg_1620, arg_1621, arg_1622, arg_1623) } else { tmp12 = linked_1617.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1616, arg_1619, arg_1620, arg_1621, arg_1622, arg_1623) }; arg_1614 = tmp10.Invoke_O_O_O__O(tmp11, v__17, tmp12); var arg_1615 any = post__16; if linked_1612 == nil { arg_1610 = ifn_1613.Invoke_O_O__O(arg_1614, arg_1615) } else { arg_1610 = linked_1612.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1611, arg_1614, arg_1615) }; if linked_1607 == nil { tmp9 = ifn_1608.Invoke_O_O__O(arg_1609, arg_1610) } else { tmp9 = linked_1607.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1606, arg_1609, arg_1610) }
//line :293:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) } else { return lang.Tuple_Create_O__IPersistentVector(b__8) } }
func A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A_New() *A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A) Ctor() {}
//line :294:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A) Invoke_O_O__O(self, p1__113000130_SHARP___1 any) any { var root_1545 any = A_arbace_cpp_inline_A_const_101.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = A_arbace_cpp_inline_A_const_151; var arg_1549 any; var root_1550 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, A_arbace_cpp_inline_head_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any; var root_1554 any = A_arbace_cpp_inline_A_const_39.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, A_arbace_cpp_inline_inst_op_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = p1__113000130_SHARP___1; if linked_1555 == nil { arg_1553 = ifn_1556.Invoke_O__O(arg_1557) } else { arg_1553 = linked_1555.(*A_arbace_cpp_inline_inst_op_A).Invoke_O_O__O(root_1554, arg_1557) }; if linked_1551 == nil { arg_1549 = ifn_1552.Invoke_O__O(arg_1553) } else { arg_1549 = linked_1551.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_1550, arg_1553) }; if linked_1546 == nil { return ifn_1547.Invoke_O_O__O(arg_1548, arg_1549) } else { return linked_1546.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1545, arg_1548, arg_1549) } }




func A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A_New_O(p0 any) *A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A) Ctor_O(c__final any) { t.F_final = c__final }
//line :299:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A) Invoke_O_O__O(self, p__113000227__1 any) any { var vec__113000229__2 any = p__113000227__1; var x__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000229__2, lang.RT_IntCast_J__I_NoInit(0), nil); var src__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000229__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(x__3, lang.IFn_Cast(t.F_final).Invoke_O__O(src__4)) }





func A_arbace_cpp_inline_inline_into_fn__113000236_A_New() *A_arbace_cpp_inline_inline_into_fn__113000236_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_inline_into_fn__113000236_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000236_A) Ctor() {}
//line :305:1
func (t *A_arbace_cpp_inline_inline_into_fn__113000236_A) Invoke_O_O__O(self, p__113000235__1 any) any { var vec__113000237__2 any = p__113000235__1; var seq__113000238__3 any; var root_1689 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1689, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1691 lang.IFn; if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = vec__113000237__2; if linked_1690 == nil { seq__113000238__3 = ifn_1691.Invoke_O__O(arg_1692) } else { seq__113000238__3 = linked_1690.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1689, arg_1692) }; var first__113000239__4 any; var root_1693 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = seq__113000238__3; if linked_1694 == nil { first__113000239__4 = ifn_1695.Invoke_O__O(arg_1696) } else { first__113000239__4 = linked_1694.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1693, arg_1696) }; var seq__113000238__5 any; var root_1697 any = A_arbace_cpp_inline_A_const_23.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = seq__113000238__3; if linked_1698 == nil { seq__113000238__5 = ifn_1699.Invoke_O__O(arg_1700) } else { seq__113000238__5 = linked_1698.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1697, arg_1700) }; var l__6 any = first__113000239__4; var is__7 any = seq__113000238__5; var root_1701 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = A_arbace_cpp_inline_A_const_32.GetRawRoot__O(); var arg_1705 any = A_arbace_cpp_inline_A_const_157; var arg_1706 any = l__6; var arg_1707 any = is__7; if linked_1702 == nil { return ifn_1703.Invoke_O_O_O_O__O(arg_1704, arg_1705, arg_1706, arg_1707) } else { return linked_1702.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1701, arg_1704, arg_1705, arg_1706, arg_1707) } }






func A_arbace_cpp_inline_discardable_QMARK__A_New() *A_arbace_cpp_inline_discardable_QMARK__A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_discardable_QMARK__A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_cpp_inline_discardable_QMARK__A) Ctor() {}
//line :312:1
func (t *A_arbace_cpp_inline_discardable_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var root_2194 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2194, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2196 lang.IFn; if linked_2195 == nil { ifn_2196 = lang.IFn_Cast(root_2194) } else { ifn_2196 = nil }; var arg_2197 any = A_arbace_cpp_inline_A_const_166; var arg_2198 any; var tmp1 *lang.Keyword = A_arbace_cpp_inline_A_const_167; var tmp2 any; var root_2199 any = A_arbace_cpp_inline_A_const_50.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2199, A_arbace_cpp_inline_define_opts_A_fn_class); var ifn_2201 lang.IFn; if linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var arg_2202 any = d__0; if linked_2200 == nil { tmp2 = ifn_2201.Invoke_O__O(arg_2202) } else { tmp2 = linked_2200.(*A_arbace_cpp_inline_define_opts_A).Invoke_O_O__O(root_2199, arg_2202) }; arg_2198 = tmp1.Invoke_O__O(tmp2); if linked_2195 == nil { return ifn_2196.Invoke_O_O__O(arg_2197, arg_2198) } else { return linked_2195.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2194, arg_2197, arg_2198) } }

func A_arbace_cpp_inline_mentions_A_New() *A_arbace_cpp_inline_mentions_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_mentions_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_cpp_inline_mentions_A) Ctor() {}
//line :314:1
func (t *A_arbace_cpp_inline_mentions_A) Invoke_O_O_O__O(self, x__0, acc__1 any) any {


	var tmp1 any; var root_2203 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2205 lang.IFn
	if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any = x__0; if linked_2204 == nil { tmp1 = ifn_2205.Invoke_O__O(arg_2206) } else { tmp1 = linked_2204.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2203, arg_2206) }
//line :317:1
	if jrt.J2g_Truth(tmp1) {
		var root_2207 any = A_arbace_cpp_inline_A_const_168.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_2209 lang.IFn; if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = acc__1; var arg_2211 any; var root_2212 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = x__0; if linked_2213 == nil { arg_2211 = ifn_2214.Invoke_O__O(arg_2215) } else { arg_2211 = linked_2213.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2212, arg_2215) }; if linked_2208 == nil { return ifn_2209.Invoke_O_O__O(arg_2210, arg_2211) } else { return linked_2208.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_2207, arg_2210, arg_2211) } } else {
//line :317:1
			var tmp2 any; var or__1927000174__auto____3 any; var root_2216 any = A_arbace_cpp_inline_A_const_57.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2218 lang.IFn

			if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = x__0; if linked_2217 == nil { or__1927000174__auto____3 = ifn_2218.Invoke_O__O(arg_2219) } else { or__1927000174__auto____3 = linked_2217.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2216, arg_2219) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_2220 any = A_arbace_cpp_inline_A_const_12.GetRawRoot__O(); var linked_2221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2220, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_2222 lang.IFn; if linked_2221 == nil { ifn_2222 = lang.IFn_Cast(root_2220) } else { ifn_2222 = nil }; var arg_2223 any = x__0; if linked_2221 == nil { tmp2 = ifn_2222.Invoke_O__O(arg_2223) } else { tmp2 = linked_2221.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_2220, arg_2223) } }
//line :317:1
			if jrt.J2g_Truth(tmp2) {

				var root_2224 any = A_arbace_cpp_inline_A_const_148.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any; var fnbody__2236 any = A_arbace_cpp_inline_mentions_fn__113000243_A_New(); var tmp3 *jrt.Class; var fncls__2235 *jrt.Class = A_arbace_cpp_inline_mentions_fn__113000243_A_fn_class; if fncls__2235 == nil { var fncls__2235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_cpp_inline_mentions_fn__113000243_A_fn_class = fncls__2235d; tmp3 = fncls__2235d } else { tmp3 = fncls__2235 }; arg_2227 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2236, tmp3, nil); var arg_2228 any = acc__1; var arg_2229 any = x__0; if linked_2225 == nil { return ifn_2226.Invoke_O_O_O__O(arg_2227, arg_2228, arg_2229) } else { return linked_2225.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2224, arg_2227, arg_2228, arg_2229) } } else {
//line :317:1
					if A_arbace_cpp_inline_A_const_17 != nil { return acc__1 } else { return nil
					} } } }
func A_arbace_cpp_inline_mentions_fn__113000243_A_New() *A_arbace_cpp_inline_mentions_fn__113000243_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_mentions_fn__113000243_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_cpp_inline_mentions_fn__113000243_A) Ctor() {}
//line :319:1
func (t *A_arbace_cpp_inline_mentions_fn__113000243_A) Invoke_O_O_O__O(self, a__1, y__2 any) any { var root_2230 any = A_arbace_cpp_inline_A_const_169.GetRawRoot__O(); var linked_2231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2230, A_arbace_cpp_inline_mentions_A_fn_class); var ifn_2232 lang.IFn; if linked_2231 == nil { ifn_2232 = lang.IFn_Cast(root_2230) } else { ifn_2232 = nil }; var arg_2233 any = y__2; var arg_2234 any = a__1; if linked_2231 == nil { return ifn_2232.Invoke_O_O__O(arg_2233, arg_2234) } else { return linked_2231.(*A_arbace_cpp_inline_mentions_A).Invoke_O_O_O__O(root_2230, arg_2233, arg_2234) } }


func A_arbace_cpp_inline_always_inline_A_New() *A_arbace_cpp_inline_always_inline_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_cpp_inline_always_inline_A) Ctor() {}
//line :322:1
func (t *A_arbace_cpp_inline_always_inline_A) Invoke_O_O__O(self, forms__0 any) any { { var defines__2 any; var root_2237 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2239 lang.IFn



	if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2241 any; var iter__1927001039__auto____2 any; var fnbody__2331 any = A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A_New(); var tmp1 *jrt.Class; var fncls__2330 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A_fn_class; if fncls__2330 == nil { var fncls__2330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A_fn_class = fncls__2330d; tmp1 = fncls__2330d } else { tmp1 = fncls__2330 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2331, tmp1, nil); arg_2241 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__0); if linked_2238 == nil { defines__2 = ifn_2239.Invoke_O_O__O(arg_2240, arg_2241) } else { defines__2 = linked_2238.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2237, arg_2240, arg_2241) }
//line :322:1
	var ai_names__3 any; var root_2332 any = A_arbace_cpp_inline_A_const_124.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2332, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2334 lang.IFn




	if linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; var arg_2335 any; var iter__1927001039__auto____3 any; var fnbody__2431 any = A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A_New(); var tmp2 *jrt.Class; var fncls__2430 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A_fn_class; if fncls__2430 == nil { var fncls__2430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A_fn_class = fncls__2430d; tmp2 = fncls__2430d } else { tmp2 = fncls__2430 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2431, tmp2, nil); arg_2335 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(defines__2); if linked_2333 == nil { ai_names__3 = ifn_2334.Invoke_O__O(arg_2335) } else { ai_names__3 = linked_2333.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2332, arg_2335) }
	var tmp3 any; var root_2432 any = A_arbace_cpp_inline_A_const_149.GetRawRoot__O(); var linked_2433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2432, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2434 lang.IFn; if linked_2433 == nil { ifn_2434 = lang.IFn_Cast(root_2432) } else { ifn_2434 = nil }; var arg_2435 any = ai_names__3; if linked_2433 == nil { tmp3 = ifn_2434.Invoke_O__O(arg_2435) } else { tmp3 = linked_2433.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2432, arg_2435) }; if jrt.J2g_Truth(tmp3) { return forms__0 } else { var nounwind_fns__4 any; var root_2436 any = A_arbace_cpp_inline_A_const_124.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2436, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2438 lang.IFn

		if linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any; var iter__1927001039__auto____4 any; var fnbody__2581 any = A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A_New(); var tmp4 *jrt.Class; var fncls__2580 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A_fn_class; if fncls__2580 == nil { var fncls__2580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A_fn_class = fncls__2580d; tmp4 = fncls__2580d } else { tmp4 = fncls__2580 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2581, tmp4, nil); arg_2439 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(forms__0); if linked_2437 == nil { nounwind_fns__4 = ifn_2438.Invoke_O__O(arg_2439) } else { nounwind_fns__4 = linked_2437.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2436, arg_2439) }
//line :328:1
		var done__5 any; var root_2582 any = A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_2583 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2582, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2584 lang.IFn






		if linked_2583 == nil { ifn_2584 = lang.IFn_Cast(root_2582) } else { ifn_2584 = nil }; var arg_2585 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2583 == nil { done__5 = ifn_2584.Invoke_O__O(arg_2585) } else { done__5 = linked_2583.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2582, arg_2585) }
//line :328:1
		var busy__6 any; var root_2586 any = A_arbace_cpp_inline_A_const_73.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2586, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_2588 lang.IFn







		if linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_2587 == nil { busy__6 = ifn_2588.Invoke_O__O(arg_2589) } else { busy__6 = linked_2587.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_2586, arg_2589) }
//line :328:1
		var finish__7 any; var fnbody__2750 any = A_arbace_cpp_inline_always_inline_finish__113000285_A_New_O_O_O_O_O(nounwind_fns__4, ai_names__3, busy__6, defines__2, done__5); var tmp5 *jrt.Class
		var fncls__2749 /*line :328:1*/*jrt.Class = A_arbace_cpp_inline_always_inline_finish__113000285_A_fn_class








		if fncls__2749 == nil { var fncls__2749d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__2750); A_arbace_cpp_inline_always_inline_finish__113000285_A_fn_class = fncls__2749d; tmp5 = fncls__2749d } else { tmp5 = fncls__2749 }; finish__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2750, tmp5, nil)
//line :328:1
		var forms__8 any; var root_2751 any = A_arbace_cpp_inline_A_const_58.GetRawRoot__O(); var linked_2752 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2751, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2753 lang.IFn


















		if linked_2752 == nil { ifn_2753 = lang.IFn_Cast(root_2751) } else { ifn_2753 = nil }; var arg_2754 any; var fnbody__2884 any = A_arbace_cpp_inline_always_inline_fn__113000299_A_New_O_O_O(nounwind_fns__4, finish__7, ai_names__3); var tmp6 *jrt.Class; var fncls__2883 *jrt.Class = A_arbace_cpp_inline_always_inline_fn__113000299_A_fn_class; if fncls__2883 == nil { var fncls__2883d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__2884); A_arbace_cpp_inline_always_inline_fn__113000299_A_fn_class = fncls__2883d; tmp6 = fncls__2883d } else { tmp6 = fncls__2883 }; arg_2754 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2884, tmp6, nil); var arg_2755 any = forms__0; if linked_2752 == nil { forms__8 = ifn_2753.Invoke_O_O__O(arg_2754, arg_2755) } else { forms__8 = linked_2752.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2751, arg_2754, arg_2755) }
//line :328:1
		var forms__9 any = forms__8; L1: for { var used__10 any; var root_2885 any = A_arbace_cpp_inline_A_const_181.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_2887 lang.IFn































			if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any; var root_2889 any = A_arbace_cpp_inline_A_const_148.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2891 lang.IFn; if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any; var fnbody__2953 any = A_arbace_cpp_inline_always_inline_fn__113000313_A_New(); var tmp7 *jrt.Class; var fncls__2952 *jrt.Class = A_arbace_cpp_inline_always_inline_fn__113000313_A_fn_class; if fncls__2952 == nil { var fncls__2952d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_cpp_inline_always_inline_fn__113000313_A_fn_class = fncls__2952d; tmp7 = fncls__2952d } else { tmp7 = fncls__2952 }; arg_2892 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2953, tmp7, nil); var arg_2893 any; var root_2954 any = A_arbace_cpp_inline_A_const_183.GetRawRoot__O(); var linked_2955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2954, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_2956 lang.IFn




			if linked_2955 == nil { ifn_2956 = lang.IFn_Cast(root_2954) } else { ifn_2956 = nil }; var arg_2957 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_2955 == nil { arg_2893 = ifn_2956.Invoke_O__O(arg_2957) } else { arg_2893 = linked_2955.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_2954, arg_2957) }
//line :360:1
			var arg_2894 any = forms__9; if linked_2890 == nil { arg_2888 = ifn_2891.Invoke_O_O_O__O(arg_2892, arg_2893, arg_2894) } else { arg_2888 = linked_2890.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2889, arg_2892, arg_2893, arg_2894) }; if linked_2886 == nil { used__10 = ifn_2887.Invoke_O__O(arg_2888) } else { used__10 = linked_2886.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_2885, arg_2888) }
//line :328:1
			var dead__11 any; var root_2958 any = A_arbace_cpp_inline_A_const_124.GetRawRoot__O(); var linked_2959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2958, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2960 lang.IFn





































			if linked_2959 == nil { ifn_2960 = lang.IFn_Cast(root_2958) } else { ifn_2960 = nil }; var arg_2961 any; var iter__1927001039__auto____11 any; var fnbody__3099 any = A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A_New_O_O(ai_names__3, used__10); var tmp8 *jrt.Class; var fncls__3098 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A_fn_class; if fncls__3098 == nil { var fncls__3098d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__3099); A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A_fn_class = fncls__3098d; tmp8 = fncls__3098d } else { tmp8 = fncls__3098 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3099, tmp8, nil); arg_2961 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(forms__9); if linked_2959 == nil { dead__11 = ifn_2960.Invoke_O__O(arg_2961) } else { dead__11 = linked_2959.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2958, arg_2961)
			}

			var tmp9 any; var root_3100 any = A_arbace_cpp_inline_A_const_149.GetRawRoot__O(); var linked_3101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3100, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_3102 lang.IFn; if linked_3101 == nil { ifn_3102 = lang.IFn_Cast(root_3100) } else { ifn_3102 = nil }; var arg_3103 any = dead__11; if linked_3101 == nil { tmp9 = ifn_3102.Invoke_O__O(arg_3103) } else { tmp9 = linked_3101.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_3100, arg_3103) }; if jrt.J2g_Truth(tmp9) { return forms__9 } else {

				var tmp10 any; var root_3104 any = A_arbace_cpp_inline_A_const_24.GetRawRoot__O(); var linked_3105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3104, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3106 lang.IFn; if linked_3105 == nil { ifn_3106 = lang.IFn_Cast(root_3104) } else { ifn_3106 = nil }; var arg_3107 any; var root_3108 any = A_arbace_cpp_inline_A_const_93.GetRawRoot__O(); var linked_3109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3108, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3110 lang.IFn; if linked_3109 == nil { ifn_3110 = lang.IFn_Cast(root_3108) } else { ifn_3110 = nil }; var arg_3111 any; var fnbody__3131 any = A_arbace_cpp_inline_always_inline_fn__113000327_A_New_O(dead__11); var tmp11 *jrt.Class; var fncls__3130 *jrt.Class = A_arbace_cpp_inline_always_inline_fn__113000327_A_fn_class; if fncls__3130 == nil { var fncls__3130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__3131); A_arbace_cpp_inline_always_inline_fn__113000327_A_fn_class = fncls__3130d; tmp11 = fncls__3130d } else { tmp11 = fncls__3130 }; arg_3111 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3131, tmp11, nil); var arg_3112 any = forms__9; if linked_3109 == nil { arg_3107 = ifn_3110.Invoke_O_O__O(arg_3111, arg_3112) } else { arg_3107 = linked_3109.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3108, arg_3111, arg_3112) }; if linked_3105 == nil { tmp10 = ifn_3106.Invoke_O__O(arg_3107) } else { tmp10 = linked_3105.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3104, arg_3107) }; forms__9 = tmp10; continue L1 } } } }; /*line :322:1*/panic("j2g: unreachable") }



func A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A_New() *A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A) Ctor() {}
//line :326:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A) Invoke_O_O__O(self, s__113000250__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2329 any = A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A_New_O_O(self, s__113000250__1); var tmp2 *jrt.Class; var fncls__2328 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A_fn_class; if fncls__2328 == nil { var fncls__2328d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__2329); A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A_fn_class = fncls__2328d; tmp2 = fncls__2328d } else { tmp2 = fncls__2328 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2329, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :326:1
func A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A{}; t.Ctor_O_O(p0, p1); return t }
//line :326:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A) Ctor_O_O(c__iter__113000249, c__s__113000250 any) { t.F_iter__113000249 = c__iter__113000249; t.F_s__113000250 = c__s__113000250 }
//line :326:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A) Invoke_O__O(self any) any { { var s__113000250__1 any; var t_ any = t.F_s__113000250; t.F_s__113000250 = nil; s__113000250__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2242 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_2243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2242, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2244 lang.IFn; if linked_2243 == nil { ifn_2244 = lang.IFn_Cast(root_2242) } else { ifn_2244 = nil }; var arg_2245 any = s__113000250__1; if linked_2243 == nil { temp__1927000414__auto____2 = ifn_2244.Invoke_O__O(arg_2245) } else { temp__1927000414__auto____2 = linked_2243.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2242, arg_2245) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__113000250__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2246 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_2247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2246, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2248 lang.IFn; if linked_2247 == nil { ifn_2248 = lang.IFn_Cast(root_2246) } else { ifn_2248 = nil }; var arg_2249 any = s__113000250__3; if linked_2247 == nil { tmp1 = ifn_2248.Invoke_O__O(arg_2249) } else { tmp1 = linked_2247.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2246, arg_2249) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2250 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_2251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2250, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2252 lang.IFn; if linked_2251 == nil { ifn_2252 = lang.IFn_Cast(root_2250) } else { ifn_2252 = nil }; var arg_2253 any = s__113000250__3; if linked_2251 == nil { c__1927001037__auto____4 = ifn_2252.Invoke_O__O(arg_2253) } else { c__1927001037__auto____4 = linked_2251.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2250, arg_2253) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__113000252__6 any; var root_2254 any = A_arbace_cpp_inline_A_const_38.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2256 lang.IFn; if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2255 == nil { b__113000252__6 = ifn_2256.Invoke_O__O(arg_2257) } else { b__113000252__6 = linked_2255.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2254, arg_2257) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2276 any = A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A_New_O_I_O(b__113000252__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2275 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A_fn_class; if fncls__2275 == nil { var fncls__2275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__2276); A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A_fn_class = fncls__2275d; tmp3 = fncls__2275d } else { tmp3 = fncls__2275 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2276, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2277 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any; var root_2282 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2284 lang.IFn; if linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any = b__113000252__6; if linked_2283 == nil { arg_2280 = ifn_2284.Invoke_O__O(arg_2285) } else { arg_2280 = linked_2283.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2282, arg_2285) }; var arg_2281 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__113000249); var tmp5 any; var root_2286 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2288 lang.IFn; if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any = s__113000250__3; if linked_2287 == nil { tmp5 = ifn_2288.Invoke_O__O(arg_2289) } else { tmp5 = linked_2287.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2286, arg_2289) }; arg_2281 = tmp4.Invoke_O__O(tmp5); if linked_2278 == nil { return ifn_2279.Invoke_O_O__O(arg_2280, arg_2281) } else { return linked_2278.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2277, arg_2280, arg_2281) } } else { var root_2290 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any; var root_2295 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2295, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2297 lang.IFn; if linked_2296 == nil { ifn_2297 = lang.IFn_Cast(root_2295) } else { ifn_2297 = nil }; var arg_2298 any = b__113000252__6; if linked_2296 == nil { arg_2293 = ifn_2297.Invoke_O__O(arg_2298) } else { arg_2293 = linked_2296.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2295, arg_2298) }; var arg_2294 any; if linked_2291 == nil { return ifn_2292.Invoke_O_O__O(arg_2293, arg_2294) } else { return linked_2291.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2290, arg_2293, arg_2294) } } } else { var f__4 any; var root_2299 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2301 lang.IFn; if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any = s__113000250__3; if linked_2300 == nil { f__4 = ifn_2301.Invoke_O__O(arg_2302) } else { f__4 = linked_2300.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2299, arg_2302) }; var tmp6 any = A_arbace_cpp_inline_A_const_170; var tmp7 any; var root_2303 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, A_arbace_cpp_inline_head_A_fn_class); var ifn_2305 lang.IFn; if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any = f__4; if linked_2304 == nil { tmp7 = ifn_2305.Invoke_O__O(arg_2306) } else { tmp7 = linked_2304.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2303, arg_2306) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) { var root_2307 any = A_arbace_cpp_inline_A_const_47.GetRawRoot__O(); var linked_2308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2307, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2309 lang.IFn; if linked_2308 == nil { ifn_2309 = lang.IFn_Cast(root_2307) } else { ifn_2309 = nil }; var arg_2310 any; var tmp8 any; var root_2312 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any; var root_2316 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2318 lang.IFn; if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any = f__4; if linked_2317 == nil { arg_2315 = ifn_2318.Invoke_O__O(arg_2319) } else { arg_2315 = linked_2317.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2316, arg_2319) }; if linked_2313 == nil { tmp8 = ifn_2314.Invoke_O__O(arg_2315) } else { tmp8 = linked_2313.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2312, arg_2315) }; arg_2310 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, f__4); var arg_2311 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__113000249); var tmp10 any; var root_2320 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2320, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any = s__113000250__3; if linked_2321 == nil { tmp10 = ifn_2322.Invoke_O__O(arg_2323) } else { tmp10 = linked_2321.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2320, arg_2323) }; arg_2311 = tmp9.Invoke_O__O(tmp10); if linked_2308 == nil { return ifn_2309.Invoke_O_O__O(arg_2310, arg_2311) } else { return linked_2308.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2307, arg_2310, arg_2311) } } else { var tmp11 any; var root_2324 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2324, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2326 lang.IFn; if linked_2325 == nil { ifn_2326 = lang.IFn_Cast(root_2324) } else { ifn_2326 = nil }; var arg_2327 any = s__113000250__3; if linked_2325 == nil { tmp11 = ifn_2326.Invoke_O__O(arg_2327) } else { tmp11 = linked_2325.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2324, arg_2327) }; s__113000250__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :326:1
func A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :326:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A) Ctor_O_I_O(c__b__113000252 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__113000252 = c__b__113000252; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :326:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A) Invoke_O__O(self any) any { { var i__113000251__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__113000251__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__113000251__1)); var tmp2 any = A_arbace_cpp_inline_A_const_170; var tmp3 any; var root_2258 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, A_arbace_cpp_inline_head_A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = f__2; if linked_2259 == nil { tmp3 = ifn_2260.Invoke_O__O(arg_2261) } else { tmp3 = linked_2259.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2258, arg_2261) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_2262 any = A_arbace_cpp_inline_A_const_42.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = t.F_b__113000252; var arg_2266 any; var tmp4 any; var root_2267 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2267, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2269 lang.IFn; if linked_2268 == nil { ifn_2269 = lang.IFn_Cast(root_2267) } else { ifn_2269 = nil }; var arg_2270 any; var root_2271 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2271, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2273 lang.IFn; if linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any = f__2; if linked_2272 == nil { arg_2270 = ifn_2273.Invoke_O__O(arg_2274) } else { arg_2270 = linked_2272.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2271, arg_2274) }; if linked_2268 == nil { tmp4 = ifn_2269.Invoke_O__O(arg_2270) } else { tmp4 = linked_2268.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2267, arg_2270) }; arg_2266 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, f__2); if linked_2263 == nil { ifn_2264.Invoke_O_O__O(arg_2265, arg_2266) } else { linked_2263.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2262, arg_2265, arg_2266) }; i__113000251__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000251__1); continue L1 } else { i__113000251__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000251__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A_New() *A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A) Ctor() {}
//line :327:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A) Invoke_O_O__O(self, s__113000260__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2429 any = A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A_New_O_O(self, s__113000260__1); var tmp2 *jrt.Class; var fncls__2428 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A_fn_class; if fncls__2428 == nil { var fncls__2428d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__2429); A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A_fn_class = fncls__2428d; tmp2 = fncls__2428d } else { tmp2 = fncls__2428 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2429, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :327:1
func A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A{}; t.Ctor_O_O(p0, p1); return t }
//line :327:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A) Ctor_O_O(c__iter__113000259, c__s__113000260 any) { t.F_iter__113000259 = c__iter__113000259; t.F_s__113000260 = c__s__113000260 }
//line :327:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A) Invoke_O__O(self any) any { { var s__113000260__1 any; var t_ any = t.F_s__113000260; t.F_s__113000260 = nil; s__113000260__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2336 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_2337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2336, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2338 lang.IFn; if linked_2337 == nil { ifn_2338 = lang.IFn_Cast(root_2336) } else { ifn_2338 = nil }; var arg_2339 any = s__113000260__1; if linked_2337 == nil { temp__1927000414__auto____2 = ifn_2338.Invoke_O__O(arg_2339) } else { temp__1927000414__auto____2 = linked_2337.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2336, arg_2339) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__113000260__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2340 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_2341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2340, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2342 lang.IFn; if linked_2341 == nil { ifn_2342 = lang.IFn_Cast(root_2340) } else { ifn_2342 = nil }; var arg_2343 any = s__113000260__3; if linked_2341 == nil { tmp1 = ifn_2342.Invoke_O__O(arg_2343) } else { tmp1 = linked_2341.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2340, arg_2343) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2344 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_2345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2344, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2346 lang.IFn; if linked_2345 == nil { ifn_2346 = lang.IFn_Cast(root_2344) } else { ifn_2346 = nil }; var arg_2347 any = s__113000260__3; if linked_2345 == nil { c__1927001037__auto____4 = ifn_2346.Invoke_O__O(arg_2347) } else { c__1927001037__auto____4 = linked_2345.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2344, arg_2347) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__113000262__6 any; var root_2348 any = A_arbace_cpp_inline_A_const_38.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2349 == nil { b__113000262__6 = ifn_2350.Invoke_O__O(arg_2351) } else { b__113000262__6 = linked_2349.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2348, arg_2351) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2371 any = A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A_New_O_I_O(b__113000262__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2370 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A_fn_class; if fncls__2370 == nil { var fncls__2370d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__2371); A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A_fn_class = fncls__2370d; tmp3 = fncls__2370d } else { tmp3 = fncls__2370 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2371, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2372 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any; var root_2377 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2377, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2379 lang.IFn; if linked_2378 == nil { ifn_2379 = lang.IFn_Cast(root_2377) } else { ifn_2379 = nil }; var arg_2380 any = b__113000262__6; if linked_2378 == nil { arg_2375 = ifn_2379.Invoke_O__O(arg_2380) } else { arg_2375 = linked_2378.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2377, arg_2380) }; var arg_2376 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__113000259); var tmp5 any; var root_2381 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2383 lang.IFn; if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; var arg_2384 any = s__113000260__3; if linked_2382 == nil { tmp5 = ifn_2383.Invoke_O__O(arg_2384) } else { tmp5 = linked_2382.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2381, arg_2384) }; arg_2376 = tmp4.Invoke_O__O(tmp5); if linked_2373 == nil { return ifn_2374.Invoke_O_O__O(arg_2375, arg_2376) } else { return linked_2373.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2372, arg_2375, arg_2376) } } else { var root_2385 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2385, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2387 lang.IFn; if linked_2386 == nil { ifn_2387 = lang.IFn_Cast(root_2385) } else { ifn_2387 = nil }; var arg_2388 any; var root_2390 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2390, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2392 lang.IFn; if linked_2391 == nil { ifn_2392 = lang.IFn_Cast(root_2390) } else { ifn_2392 = nil }; var arg_2393 any = b__113000262__6; if linked_2391 == nil { arg_2388 = ifn_2392.Invoke_O__O(arg_2393) } else { arg_2388 = linked_2391.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2390, arg_2393) }; var arg_2389 any; if linked_2386 == nil { return ifn_2387.Invoke_O_O__O(arg_2388, arg_2389) } else { return linked_2386.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2385, arg_2388, arg_2389) } } } else { var vec__113000270__4 any; var root_2394 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_2395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2394, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2396 lang.IFn; if linked_2395 == nil { ifn_2396 = lang.IFn_Cast(root_2394) } else { ifn_2396 = nil }; var arg_2397 any = s__113000260__3; if linked_2395 == nil { vec__113000270__4 = ifn_2396.Invoke_O__O(arg_2397) } else { vec__113000270__4 = linked_2395.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2394, arg_2397) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000270__4, lang.RT_IntCast_J__I_NoInit(0), nil); var d__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000270__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_2398 any = A_arbace_cpp_inline_A_const_63.GetRawRoot__O(); var linked_2399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2398, A_arbace_cpp_inline_attrs_have_QMARK__A_fn_class); var ifn_2400 lang.IFn; if linked_2399 == nil { ifn_2400 = lang.IFn_Cast(root_2398) } else { ifn_2400 = nil }; var arg_2401 any; var tmp7 *lang.Keyword = A_arbace_cpp_inline_A_const_64; var tmp8 any; var root_2403 any = A_arbace_cpp_inline_A_const_50.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, A_arbace_cpp_inline_define_opts_A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = d__6; if linked_2404 == nil { tmp8 = ifn_2405.Invoke_O__O(arg_2406) } else { tmp8 = linked_2404.(*A_arbace_cpp_inline_define_opts_A).Invoke_O_O__O(root_2403, arg_2406) }; arg_2401 = tmp7.Invoke_O__O(tmp8); var arg_2402 any = A_arbace_cpp_inline_A_const_171; if linked_2399 == nil { tmp6 = ifn_2400.Invoke_O_O__O(arg_2401, arg_2402) } else { tmp6 = linked_2399.(*A_arbace_cpp_inline_attrs_have_QMARK__A).Invoke_O_O_O__O(root_2398, arg_2401, arg_2402) }; if jrt.J2g_Truth(tmp6) { var tmp9 any; var root_2407 any = A_arbace_cpp_inline_A_const_172.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, A_arbace_cpp_inline_viable_QMARK__A_fn_class); var ifn_2409 lang.IFn; if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = d__6; if linked_2408 == nil { tmp9 = ifn_2409.Invoke_O__O(arg_2410) } else { tmp9 = linked_2408.(*A_arbace_cpp_inline_viable_QMARK__A).Invoke_O_O__O(root_2407, arg_2410) }; if jrt.J2g_Truth(tmp9) { var root_2411 any = A_arbace_cpp_inline_A_const_47.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = n__5; var arg_2415 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__113000259); var tmp11 any; var root_2416 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2418 lang.IFn; if linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = s__113000260__3; if linked_2417 == nil { tmp11 = ifn_2418.Invoke_O__O(arg_2419) } else { tmp11 = linked_2417.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2416, arg_2419) }; arg_2415 = tmp10.Invoke_O__O(tmp11); if linked_2412 == nil { return ifn_2413.Invoke_O_O__O(arg_2414, arg_2415) } else { return linked_2412.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2411, arg_2414, arg_2415) } } else { var tmp12 any; var root_2420 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2420, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2422 lang.IFn; if linked_2421 == nil { ifn_2422 = lang.IFn_Cast(root_2420) } else { ifn_2422 = nil }; var arg_2423 any = s__113000260__3; if linked_2421 == nil { tmp12 = ifn_2422.Invoke_O__O(arg_2423) } else { tmp12 = linked_2421.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2420, arg_2423) }; s__113000260__1 = tmp12; continue L1 } } else { var tmp13 any; var root_2424 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2424, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2426 lang.IFn; if linked_2425 == nil { ifn_2426 = lang.IFn_Cast(root_2424) } else { ifn_2426 = nil }; var arg_2427 any = s__113000260__3; if linked_2425 == nil { tmp13 = ifn_2426.Invoke_O__O(arg_2427) } else { tmp13 = linked_2425.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2424, arg_2427) }; s__113000260__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :327:1
func A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A) Ctor_O_I_O(c__b__113000262 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__113000262 = c__b__113000262; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :327:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A) Invoke_O__O(self any) any { { var i__113000261__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__113000261__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__113000266__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__113000261__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000266__2, lang.RT_IntCast_J__I_NoInit(0), nil); var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__113000266__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_2352 any = A_arbace_cpp_inline_A_const_63.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, A_arbace_cpp_inline_attrs_have_QMARK__A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any; var tmp3 *lang.Keyword = A_arbace_cpp_inline_A_const_64; var tmp4 any; var root_2357 any = A_arbace_cpp_inline_A_const_50.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2357, A_arbace_cpp_inline_define_opts_A_fn_class); var ifn_2359 lang.IFn; if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any = d__4; if linked_2358 == nil { tmp4 = ifn_2359.Invoke_O__O(arg_2360) } else { tmp4 = linked_2358.(*A_arbace_cpp_inline_define_opts_A).Invoke_O_O__O(root_2357, arg_2360) }; arg_2355 = tmp3.Invoke_O__O(tmp4); var arg_2356 any = A_arbace_cpp_inline_A_const_171; if linked_2353 == nil { tmp2 = ifn_2354.Invoke_O_O__O(arg_2355, arg_2356) } else { tmp2 = linked_2353.(*A_arbace_cpp_inline_attrs_have_QMARK__A).Invoke_O_O_O__O(root_2352, arg_2355, arg_2356) }; if jrt.J2g_Truth(tmp2) { var tmp5 any; var root_2361 any = A_arbace_cpp_inline_A_const_172.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, A_arbace_cpp_inline_viable_QMARK__A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = d__4; if linked_2362 == nil { tmp5 = ifn_2363.Invoke_O__O(arg_2364) } else { tmp5 = linked_2362.(*A_arbace_cpp_inline_viable_QMARK__A).Invoke_O_O__O(root_2361, arg_2364) }; if jrt.J2g_Truth(tmp5) { var root_2365 any = A_arbace_cpp_inline_A_const_42.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2367 lang.IFn; if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = t.F_b__113000262; var arg_2369 any = n__3; if linked_2366 == nil { ifn_2367.Invoke_O_O__O(arg_2368, arg_2369) } else { linked_2366.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2365, arg_2368, arg_2369) }; i__113000261__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000261__1); continue L1 } else { i__113000261__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000261__1); continue L1 } } else { i__113000261__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000261__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A_New() *A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A) Ctor() {}
//line :330:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A) Invoke_O_O__O(self, s__113000276__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2579 any = A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A_New_O_O(s__113000276__1, self); var tmp2 *jrt.Class; var fncls__2578 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A_fn_class; if fncls__2578 == nil { var fncls__2578d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__2579); A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A_fn_class = fncls__2578d; tmp2 = fncls__2578d } else { tmp2 = fncls__2578 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2579, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :330:1
func A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A{}; t.Ctor_O_O(p0, p1); return t }
//line :330:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A) Ctor_O_O(c__s__113000276, c__iter__113000275 any) { t.F_s__113000276 = c__s__113000276; t.F_iter__113000275 = c__iter__113000275 }
//line :330:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A) Invoke_O__O(self any) any { { var s__113000276__1 any; var t_ any = t.F_s__113000276; t.F_s__113000276 = nil; s__113000276__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2440 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_2441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2440, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2442 lang.IFn; if linked_2441 == nil { ifn_2442 = lang.IFn_Cast(root_2440) } else { ifn_2442 = nil }; var arg_2443 any = s__113000276__1; if linked_2441 == nil { temp__1927000414__auto____2 = ifn_2442.Invoke_O__O(arg_2443) } else { temp__1927000414__auto____2 = linked_2441.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2440, arg_2443) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__113000276__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2444 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_2445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2444, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2446 lang.IFn; if linked_2445 == nil { ifn_2446 = lang.IFn_Cast(root_2444) } else { ifn_2446 = nil }; var arg_2447 any = s__113000276__3; if linked_2445 == nil { tmp1 = ifn_2446.Invoke_O__O(arg_2447) } else { tmp1 = linked_2445.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2444, arg_2447) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2448 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_2449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2448, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2450 lang.IFn; if linked_2449 == nil { ifn_2450 = lang.IFn_Cast(root_2448) } else { ifn_2450 = nil }; var arg_2451 any = s__113000276__3; if linked_2449 == nil { c__1927001037__auto____4 = ifn_2450.Invoke_O__O(arg_2451) } else { c__1927001037__auto____4 = linked_2449.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2448, arg_2451) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__113000278__6 any; var root_2452 any = A_arbace_cpp_inline_A_const_38.GetRawRoot__O(); var linked_2453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2452, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2454 lang.IFn; if linked_2453 == nil { ifn_2454 = lang.IFn_Cast(root_2452) } else { ifn_2454 = nil }; var arg_2455 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2453 == nil { b__113000278__6 = ifn_2454.Invoke_O__O(arg_2455) } else { b__113000278__6 = linked_2453.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2452, arg_2455) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2498 any = A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A_New_O_I_O(b__113000278__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2497 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A_fn_class; if fncls__2497 == nil { var fncls__2497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__2498); A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A_fn_class = fncls__2497d; tmp3 = fncls__2497d } else { tmp3 = fncls__2497 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2498, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2499 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2499, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2501 lang.IFn; if linked_2500 == nil { ifn_2501 = lang.IFn_Cast(root_2499) } else { ifn_2501 = nil }; var arg_2502 any; var root_2504 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2504, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2506 lang.IFn; if linked_2505 == nil { ifn_2506 = lang.IFn_Cast(root_2504) } else { ifn_2506 = nil }; var arg_2507 any = b__113000278__6; if linked_2505 == nil { arg_2502 = ifn_2506.Invoke_O__O(arg_2507) } else { arg_2502 = linked_2505.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2504, arg_2507) }; var arg_2503 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__113000275); var tmp5 any; var root_2508 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_2509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2508, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2510 lang.IFn; if linked_2509 == nil { ifn_2510 = lang.IFn_Cast(root_2508) } else { ifn_2510 = nil }; var arg_2511 any = s__113000276__3; if linked_2509 == nil { tmp5 = ifn_2510.Invoke_O__O(arg_2511) } else { tmp5 = linked_2509.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2508, arg_2511) }; arg_2503 = tmp4.Invoke_O__O(tmp5); if linked_2500 == nil { return ifn_2501.Invoke_O_O__O(arg_2502, arg_2503) } else { return linked_2500.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2499, arg_2502, arg_2503) } } else { var root_2512 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2512, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2514 lang.IFn; if linked_2513 == nil { ifn_2514 = lang.IFn_Cast(root_2512) } else { ifn_2514 = nil }; var arg_2515 any; var root_2517 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2517, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2519 lang.IFn; if linked_2518 == nil { ifn_2519 = lang.IFn_Cast(root_2517) } else { ifn_2519 = nil }; var arg_2520 any = b__113000278__6; if linked_2518 == nil { arg_2515 = ifn_2519.Invoke_O__O(arg_2520) } else { arg_2515 = linked_2518.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2517, arg_2520) }; var arg_2516 any; if linked_2513 == nil { return ifn_2514.Invoke_O_O__O(arg_2515, arg_2516) } else { return linked_2513.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2512, arg_2515, arg_2516) } } } else { var f__4 any; var root_2521 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2523 lang.IFn; if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any = s__113000276__3; if linked_2522 == nil { f__4 = ifn_2523.Invoke_O__O(arg_2524) } else { f__4 = linked_2522.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2521, arg_2524) }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_176); var tmp7 any; var root_2566 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2566, A_arbace_cpp_inline_head_A_fn_class); var ifn_2568 lang.IFn; if linked_2567 == nil { ifn_2568 = lang.IFn_Cast(root_2566) } else { ifn_2568 = nil }; var arg_2569 any = f__4; if linked_2567 == nil { tmp7 = ifn_2568.Invoke_O__O(arg_2569) } else { tmp7 = linked_2567.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2566, arg_2569) }; if jrt.J2g_Truth(tmp6.Invoke_O__O(tmp7)) { var tmp8 any; var root_2525 any = A_arbace_cpp_inline_A_const_63.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2525, A_arbace_cpp_inline_attrs_have_QMARK__A_fn_class); var ifn_2527 lang.IFn
															if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any; var tmp9 *lang.Keyword = A_arbace_cpp_inline_A_const_64; var tmp10 any; var root_2530 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_2531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2530, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2532 lang.IFn; if linked_2531 == nil { ifn_2532 = lang.IFn_Cast(root_2530) } else { ifn_2532 = nil }; var arg_2533 any = A_arbace_cpp_inline_A_const_20.GetRawRoot__O(); var arg_2534 any; var root_2535 any = A_arbace_cpp_inline_A_const_21.GetRawRoot__O(); var linked_2536 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2535, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2537 lang.IFn; if linked_2536 == nil { ifn_2537 = lang.IFn_Cast(root_2535) } else { ifn_2537 = nil }; var arg_2539 any; var tmp11 any = A_arbace_cpp_inline_A_const_174; var tmp12 any; var root_2540 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, A_arbace_cpp_inline_head_A_fn_class); var ifn_2542 lang.IFn; if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any = f__4; if linked_2541 == nil { tmp12 = ifn_2542.Invoke_O__O(arg_2543) } else { tmp12 = linked_2541.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2540, arg_2543) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp11, tmp12) { var root_2544 any = A_arbace_cpp_inline_A_const_93.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2546 lang.IFn; if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any = A_arbace_cpp_inline_A_const_177; var arg_2548 any = f__4; if linked_2545 == nil { arg_2539 = ifn_2546.Invoke_O_O__O(arg_2547, arg_2548) } else { arg_2539 = linked_2545.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2544, arg_2547, arg_2548) } } else { arg_2539 = f__4 }; if linked_2536 == nil { arg_2534 = ifn_2537.Invoke_O_O__O(A_arbace_cpp_inline_A_const_62, arg_2539) } else { arg_2534 = linked_2536.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2535, 4, A_arbace_cpp_inline_A_const_62, arg_2539) }; if linked_2531 == nil { tmp10 = ifn_2532.Invoke_O_O__O(arg_2533, arg_2534) } else { tmp10 = linked_2531.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2530, arg_2533, arg_2534) }; arg_2528 = tmp9.Invoke_O__O(tmp10); var arg_2529 any = A_arbace_cpp_inline_A_const_65; if linked_2526 == nil { tmp8 = ifn_2527.Invoke_O_O__O(arg_2528, arg_2529) } else { tmp8 = linked_2526.(*A_arbace_cpp_inline_attrs_have_QMARK__A).Invoke_O_O_O__O(root_2525, arg_2528, arg_2529) }
//line :330:1
	if jrt.J2g_Truth(tmp8) { var root_2549 any = A_arbace_cpp_inline_A_const_47.GetRawRoot__O(); var linked_2550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2549, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2551 lang.IFn; if linked_2550 == nil { ifn_2551 = lang.IFn_Cast(root_2549) } else { ifn_2551 = nil }; var arg_2552 any; var root_2554 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2554, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2556 lang.IFn

		if linked_2555 == nil { ifn_2556 = lang.IFn_Cast(root_2554) } else { ifn_2556 = nil }; var arg_2557 any; var root_2558 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_2559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2558, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2560 lang.IFn; if linked_2559 == nil { ifn_2560 = lang.IFn_Cast(root_2558) } else { ifn_2560 = nil }; var arg_2561 any = f__4; if linked_2559 == nil { arg_2557 = ifn_2560.Invoke_O__O(arg_2561) } else { arg_2557 = linked_2559.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2558, arg_2561) }; if linked_2555 == nil { arg_2552 = ifn_2556.Invoke_O__O(arg_2557) } else { arg_2552 = linked_2555.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2554, arg_2557) }
//line :330:1
		var arg_2553 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__113000275); var tmp14 any; var root_2562 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2562, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2564 lang.IFn; if linked_2563 == nil { ifn_2564 = lang.IFn_Cast(root_2562) } else { ifn_2564 = nil }; var arg_2565 any = s__113000276__3; if linked_2563 == nil { tmp14 = ifn_2564.Invoke_O__O(arg_2565) } else { tmp14 = linked_2563.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2562, arg_2565) }; arg_2553 = tmp13.Invoke_O__O(tmp14); if linked_2550 == nil { return ifn_2551.Invoke_O_O__O(arg_2552, arg_2553) } else { return linked_2550.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2549, arg_2552, arg_2553) } } else { var tmp15 any; var root_2570 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2570, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2572 lang.IFn; if linked_2571 == nil { ifn_2572 = lang.IFn_Cast(root_2570) } else { ifn_2572 = nil }; var arg_2573 any = s__113000276__3; if linked_2571 == nil { tmp15 = ifn_2572.Invoke_O__O(arg_2573) } else { tmp15 = linked_2571.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2570, arg_2573) }; s__113000276__1 = tmp15; continue L1 } } else { var tmp16 any; var root_2574 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2574, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2576 lang.IFn; if linked_2575 == nil { ifn_2576 = lang.IFn_Cast(root_2574) } else { ifn_2576 = nil }; var arg_2577 any = s__113000276__3; if linked_2575 == nil { tmp16 = ifn_2576.Invoke_O__O(arg_2577) } else { tmp16 = linked_2575.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2574, arg_2577) }; s__113000276__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :330:1
func A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :330:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A) Ctor_O_I_O(c__b__113000278 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__113000278 = c__b__113000278; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :330:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A) Invoke_O__O(self any) any { { var i__113000277__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__113000277__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__113000277__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_173); var tmp3 any; var root_2480 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, A_arbace_cpp_inline_head_A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var arg_2483 any = f__2; if linked_2481 == nil { tmp3 = ifn_2482.Invoke_O__O(arg_2483) } else { tmp3 = linked_2481.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2480, arg_2483) }; if jrt.J2g_Truth(tmp2.Invoke_O__O(tmp3)) { var tmp4 any; var root_2456 any = A_arbace_cpp_inline_A_const_63.GetRawRoot__O(); var linked_2457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2456, A_arbace_cpp_inline_attrs_have_QMARK__A_fn_class); var ifn_2458 lang.IFn
																if linked_2457 == nil { ifn_2458 = lang.IFn_Cast(root_2456) } else { ifn_2458 = nil }; var arg_2459 any; var tmp5 *lang.Keyword = A_arbace_cpp_inline_A_const_64; var tmp6 any; var root_2461 any = A_arbace_cpp_inline_A_const_19.GetRawRoot__O(); var linked_2462 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2461, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2463 lang.IFn; if linked_2462 == nil { ifn_2463 = lang.IFn_Cast(root_2461) } else { ifn_2463 = nil }; var arg_2464 any = A_arbace_cpp_inline_A_const_20.GetRawRoot__O(); var arg_2465 any; var root_2466 any = A_arbace_cpp_inline_A_const_21.GetRawRoot__O(); var linked_2467 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2466, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2468 lang.IFn; if linked_2467 == nil { ifn_2468 = lang.IFn_Cast(root_2466) } else { ifn_2468 = nil }; var arg_2470 any; var tmp7 any = A_arbace_cpp_inline_A_const_174; var tmp8 any; var root_2471 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2471, A_arbace_cpp_inline_head_A_fn_class); var ifn_2473 lang.IFn; if linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any = f__2; if linked_2472 == nil { tmp8 = ifn_2473.Invoke_O__O(arg_2474) } else { tmp8 = linked_2472.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2471, arg_2474) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8) { var root_2475 any = A_arbace_cpp_inline_A_const_93.GetRawRoot__O(); var linked_2476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2475, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2477 lang.IFn; if linked_2476 == nil { ifn_2477 = lang.IFn_Cast(root_2475) } else { ifn_2477 = nil }; var arg_2478 any = A_arbace_cpp_inline_A_const_175; var arg_2479 any = f__2; if linked_2476 == nil { arg_2470 = ifn_2477.Invoke_O_O__O(arg_2478, arg_2479) } else { arg_2470 = linked_2476.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2475, arg_2478, arg_2479) } } else { arg_2470 = f__2 }; if linked_2467 == nil { arg_2465 = ifn_2468.Invoke_O_O__O(A_arbace_cpp_inline_A_const_62, arg_2470) } else { arg_2465 = linked_2467.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2466, 4, A_arbace_cpp_inline_A_const_62, arg_2470) }; if linked_2462 == nil { tmp6 = ifn_2463.Invoke_O_O__O(arg_2464, arg_2465) } else { tmp6 = linked_2462.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2461, arg_2464, arg_2465) }; arg_2459 = tmp5.Invoke_O__O(tmp6); var arg_2460 any = A_arbace_cpp_inline_A_const_65; if linked_2457 == nil { tmp4 = ifn_2458.Invoke_O_O__O(arg_2459, arg_2460) } else { tmp4 = linked_2457.(*A_arbace_cpp_inline_attrs_have_QMARK__A).Invoke_O_O_O__O(root_2456, arg_2459, arg_2460) }
//line :330:1
	if jrt.J2g_Truth(tmp4) { var root_2484 any = A_arbace_cpp_inline_A_const_42.GetRawRoot__O(); var linked_2485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2484, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2486 lang.IFn; if linked_2485 == nil { ifn_2486 = lang.IFn_Cast(root_2484) } else { ifn_2486 = nil }; var arg_2487 any = t.F_b__113000278; var arg_2488 any; var root_2489 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2489, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2491 lang.IFn

		if linked_2490 == nil { ifn_2491 = lang.IFn_Cast(root_2489) } else { ifn_2491 = nil }; var arg_2492 any; var root_2493 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_2494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2493, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2495 lang.IFn; if linked_2494 == nil { ifn_2495 = lang.IFn_Cast(root_2493) } else { ifn_2495 = nil }; var arg_2496 any = f__2; if linked_2494 == nil { arg_2492 = ifn_2495.Invoke_O__O(arg_2496) } else { arg_2492 = linked_2494.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2493, arg_2496) }; if linked_2490 == nil { arg_2488 = ifn_2491.Invoke_O__O(arg_2492) } else { arg_2488 = linked_2490.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2489, arg_2492) }
//line :330:1
		if linked_2485 == nil { ifn_2486.Invoke_O_O__O(arg_2487, arg_2488) } else { linked_2485.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2484, arg_2487, arg_2488) }; i__113000277__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000277__1); continue L1 } else { i__113000277__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000277__1); continue L1 } } else { i__113000277__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000277__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_cpp_inline_always_inline_finish__113000285_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_cpp_inline_always_inline_finish__113000285_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_finish__113000285_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :337:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_A) Ctor_O_O_O_O_O(c__nounwind_fns, c__ai_names, c__busy, c__defines, c__done any) { t.F_nounwind_fns = c__nounwind_fns; t.F_ai_names = c__ai_names; t.F_busy = c__busy; t.F_defines = c__defines; t.F_done = c__done }
//line :337:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_A) Invoke_O_O__O(self, n__1 any) any { var or__1927000174__auto____2 any; var tmp1 any; var root_2590 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2592 lang.IFn; if
													linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any = t.F_done; if linked_2591 == nil { tmp1 = ifn_2592.Invoke_O__O(arg_2593) } else { tmp1 = linked_2591.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2590, arg_2593) }; or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(tmp1, n__1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
														var root_2730 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2730, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2732 lang.IFn; if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any = t.F_busy; var arg_2734 any = A_arbace_cpp_inline_A_const_7.GetRawRoot__O(); var arg_2735 any = n__1; if linked_2731 == nil { ifn_2732.Invoke_O_O_O__O(arg_2733, arg_2734, arg_2735) } else { linked_2731.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2730, arg_2733, arg_2734, arg_2735) }
//line :338:1
		var d__3 any = lang.RT_Get_O_O__O_NoInit(t.F_defines, n__1); var callees__4 any; var root_2594 any = A_arbace_cpp_inline_A_const_124.GetRawRoot__O(); var linked_2595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2594, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2596 lang.IFn


		if linked_2595 == nil { ifn_2596 = lang.IFn_Cast(root_2594) } else { ifn_2596 = nil }; var arg_2597 any; var root_2598 any = A_arbace_cpp_inline_A_const_125.GetRawRoot__O(); var linked_2599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2598, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2600 lang.IFn; if linked_2599 == nil { ifn_2600 = lang.IFn_Cast(root_2598) } else { ifn_2600 = nil }; var arg_2601 any; var fnbody__2608 any = A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A_New(); var tmp2 *jrt.Class; var fncls__2607 *jrt.Class = A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A_fn_class; if fncls__2607 == nil { var fncls__2607d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A_fn_class = fncls__2607d; tmp2 = fncls__2607d } else { tmp2 = fncls__2607 }; arg_2601 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2608, tmp2, nil); var arg_2602 any; var root_2609 any = A_arbace_cpp_inline_A_const_54.GetRawRoot__O(); var linked_2610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2609, A_arbace_cpp_inline_calls_in_A_fn_class); var ifn_2611 lang.IFn; if linked_2610 == nil { ifn_2611 = lang.IFn_Cast(root_2609) } else { ifn_2611 = nil }; var arg_2612 any = d__3; if linked_2610 == nil { arg_2602 = ifn_2611.Invoke_O__O(arg_2612) } else { arg_2602 = linked_2610.(*A_arbace_cpp_inline_calls_in_A).Invoke_O_O__O(root_2609, arg_2612) }; if linked_2599 == nil { arg_2597 = ifn_2600.Invoke_O_O__O(arg_2601, arg_2602) } else { arg_2597 = linked_2599.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2598, arg_2601, arg_2602) }; if linked_2595 == nil { callees__4 = ifn_2596.Invoke_O__O(arg_2597) } else { callees__4 = linked_2595.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2594, arg_2597) }
//line :338:1
		var ai__5 any; var root_2613 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2615 lang.IFn



		if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2617 any; var iter__1927001039__auto____5 any; var fnbody__2723 any = A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A_New_O_O_O(t.F_ai_names, self, t.F_busy); var tmp3 *jrt.Class; var fncls__2722 *jrt.Class = A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A_fn_class; if fncls__2722 == nil { var fncls__2722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__2723); A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A_fn_class = fncls__2722d; tmp3 = fncls__2722d } else { tmp3 = fncls__2722 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2723, tmp3, nil); arg_2617 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(callees__4); if linked_2614 == nil { ai__5 = ifn_2615.Invoke_O_O__O(arg_2616, arg_2617) } else { ai__5 = linked_2614.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2613, arg_2616, arg_2617) }
//line :338:1
		var r__6 any; var root_2724 any = A_arbace_cpp_inline_A_const_178.GetRawRoot__O(); var linked_2725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2724, A_arbace_cpp_inline_inline_into_A_fn_class); var ifn_2726 lang.IFn




		if linked_2725 == nil { ifn_2726 = lang.IFn_Cast(root_2724) } else { ifn_2726 = nil }; var arg_2727 any = d__3; var arg_2728 any = ai__5; var arg_2729 any = t.F_nounwind_fns; if linked_2725 == nil { r__6 = ifn_2726.Invoke_O_O_O__O(arg_2727, arg_2728, arg_2729) } else { r__6 = linked_2725.(*A_arbace_cpp_inline_inline_into_A).Invoke_O_O_O_O__O(root_2724, arg_2727, arg_2728, arg_2729) }
		var root_2736 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_2737 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2736, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2738 lang.IFn; if linked_2737 == nil { ifn_2738 = lang.IFn_Cast(root_2736) } else { ifn_2738 = nil }; var arg_2739 any = t.F_busy; var arg_2740 any = A_arbace_cpp_inline_A_const_179.GetRawRoot__O(); var arg_2741 any = n__1; if linked_2737 == nil { ifn_2738.Invoke_O_O_O__O(arg_2739, arg_2740, arg_2741) } else { linked_2737.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_2736, arg_2739, arg_2740, arg_2741) }
		var root_2742 any = A_arbace_cpp_inline_A_const_67.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any = t.F_done; var arg_2746 any = A_arbace_cpp_inline_A_const_27.GetRawRoot__O(); var arg_2747 any = n__1; var arg_2748 any = r__6; if linked_2743 == nil { ifn_2744.Invoke_O_O_O_O__O(arg_2745, arg_2746, arg_2747, arg_2748) } else { linked_2743.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_2742, arg_2745, arg_2746, arg_2747, arg_2748) }
//line :338:1
		return r__6 } }


func A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A_New() *A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A) Ctor() {}
//line :341:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A) Invoke_O_O__O(self, p1__113000246_SHARP___1 any) any { var root_2603 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2603, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2605 lang.IFn; if linked_2604 == nil { ifn_2605 = lang.IFn_Cast(root_2603) } else { ifn_2605 = nil }; var arg_2606 any = lang.RT_Nth_O_I__O_NoInit(p1__113000246_SHARP___1, lang.RT_IntCast_J__I_NoInit(2)); if linked_2604 == nil { return ifn_2605.Invoke_O__O(arg_2606) } else { return linked_2604.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2603, arg_2606) } }
func A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :342:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A) Ctor_O_O_O(c__ai_names, c__finish, c__busy any) { t.F_ai_names = c__ai_names; t.F_finish = c__finish; t.F_busy = c__busy }
//line :342:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A) Invoke_O_O__O(self, s__113000289__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2721 any = A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A_New_O_O_O_O_O(s__113000289__1, t.F_ai_names, t.F_finish, t.F_busy, self); var tmp2 *jrt.Class; var fncls__2720 *jrt.Class = A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A_fn_class; if fncls__2720 == nil { var fncls__2720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__2721); A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A_fn_class = fncls__2720d; tmp2 = fncls__2720d } else { tmp2 = fncls__2720 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2721, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :342:1
func A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :342:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A) Ctor_O_O_O_O_O(c__s__113000289, c__ai_names, c__finish, c__busy, c__iter__113000288 any) { t.F_s__113000289 = c__s__113000289; t.F_ai_names = c__ai_names; t.F_finish = c__finish; t.F_busy = c__busy; t.F_iter__113000288 = c__iter__113000288 }
//line :342:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A) Invoke_O__O(self any) any { { var s__113000289__1 any; var t_ any = t.F_s__113000289; t.F_s__113000289 = nil; s__113000289__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2618 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_2619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2620 lang.IFn; if linked_2619 == nil { ifn_2620 = lang.IFn_Cast(root_2618) } else { ifn_2620 = nil }; var arg_2621 any = s__113000289__1; if linked_2619 == nil { temp__1927000414__auto____2 = ifn_2620.Invoke_O__O(arg_2621) } else { temp__1927000414__auto____2 = linked_2619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2618, arg_2621) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__113000289__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2622 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any = s__113000289__3; if linked_2623 == nil { tmp1 = ifn_2624.Invoke_O__O(arg_2625) } else { tmp1 = linked_2623.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2622, arg_2625) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2626 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_2627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2626, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2628 lang.IFn; if linked_2627 == nil { ifn_2628 = lang.IFn_Cast(root_2626) } else { ifn_2628 = nil }; var arg_2629 any = s__113000289__3; if linked_2627 == nil { c__1927001037__auto____4 = ifn_2628.Invoke_O__O(arg_2629) } else { c__1927001037__auto____4 = linked_2627.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2626, arg_2629) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__113000291__6 any; var root_2630 any = A_arbace_cpp_inline_A_const_38.GetRawRoot__O(); var linked_2631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2630, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2632 lang.IFn; if linked_2631 == nil { ifn_2632 = lang.IFn_Cast(root_2630) } else { ifn_2632 = nil }; var arg_2633 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2631 == nil { b__113000291__6 = ifn_2632.Invoke_O__O(arg_2633) } else { b__113000291__6 = linked_2631.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2630, arg_2633) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2658 any = A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A_New_O_O_O_O_I_O(b__113000291__6, t.F_ai_names, t.F_finish, t.F_busy, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2657 *jrt.Class = A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A_fn_class; if fncls__2657 == nil { var fncls__2657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__2658); A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A_fn_class = fncls__2657d; tmp3 = fncls__2657d } else { tmp3 = fncls__2657 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2658, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2659 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2659, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2661 lang.IFn; if linked_2660 == nil { ifn_2661 = lang.IFn_Cast(root_2659) } else { ifn_2661 = nil }; var arg_2662 any; var root_2664 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2664, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2666 lang.IFn; if linked_2665 == nil { ifn_2666 = lang.IFn_Cast(root_2664) } else { ifn_2666 = nil }; var arg_2667 any = b__113000291__6; if linked_2665 == nil { arg_2662 = ifn_2666.Invoke_O__O(arg_2667) } else { arg_2662 = linked_2665.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2664, arg_2667) }; var arg_2663 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__113000288); var tmp5 any; var root_2668 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2668, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2670 lang.IFn; if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any = s__113000289__3; if linked_2669 == nil { tmp5 = ifn_2670.Invoke_O__O(arg_2671) } else { tmp5 = linked_2669.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2668, arg_2671) }; arg_2663 = tmp4.Invoke_O__O(tmp5); if linked_2660 == nil { return ifn_2661.Invoke_O_O__O(arg_2662, arg_2663) } else { return linked_2660.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2659, arg_2662, arg_2663) } } else { var root_2672 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2672, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2674 lang.IFn; if linked_2673 == nil { ifn_2674 = lang.IFn_Cast(root_2672) } else { ifn_2674 = nil }; var arg_2675 any; var root_2677 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2677, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2679 lang.IFn; if linked_2678 == nil { ifn_2679 = lang.IFn_Cast(root_2677) } else { ifn_2679 = nil }; var arg_2680 any = b__113000291__6; if linked_2678 == nil { arg_2675 = ifn_2679.Invoke_O__O(arg_2680) } else { arg_2675 = linked_2678.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2677, arg_2680) }; var arg_2676 any; if linked_2673 == nil { return ifn_2674.Invoke_O_O__O(arg_2675, arg_2676) } else { return linked_2673.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2672, arg_2675, arg_2676) } } } else { var c__4 any; var root_2681 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_2682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2681, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2683 lang.IFn; if linked_2682 == nil { ifn_2683 = lang.IFn_Cast(root_2681) } else { ifn_2683 = nil }; var arg_2684 any = s__113000289__3; if linked_2682 == nil { c__4 = ifn_2683.Invoke_O__O(arg_2684) } else { c__4 = linked_2682.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2681, arg_2684) }; var tmp6 any; var root_2685 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2685, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2687 lang.IFn; if linked_2686 == nil { ifn_2687 = lang.IFn_Cast(root_2685) } else { ifn_2687 = nil }; var arg_2688 any = t.F_ai_names; var arg_2689 any = c__4; if linked_2686 == nil { tmp6 = ifn_2687.Invoke_O_O__O(arg_2688, arg_2689) } else { tmp6 = linked_2686.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2685, arg_2688, arg_2689) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_2690 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_2691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2690, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2692 lang.IFn; if linked_2691 == nil { ifn_2692 = lang.IFn_Cast(root_2690) } else { ifn_2692 = nil }; var arg_2693 any; var root_2694 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2694, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2696 lang.IFn; if linked_2695 == nil { ifn_2696 = lang.IFn_Cast(root_2694) } else { ifn_2696 = nil }; var arg_2697 any; var root_2699 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_2700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2699, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2701 lang.IFn; if linked_2700 == nil { ifn_2701 = lang.IFn_Cast(root_2699) } else { ifn_2701 = nil }; var arg_2702 any = t.F_busy; if linked_2700 == nil { arg_2697 = ifn_2701.Invoke_O__O(arg_2702) } else { arg_2697 = linked_2700.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2699, arg_2702) }; var arg_2698 any = c__4; if linked_2695 == nil { arg_2693 = ifn_2696.Invoke_O_O__O(arg_2697, arg_2698) } else { arg_2693 = linked_2695.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2694, arg_2697, arg_2698) }; if linked_2691 == nil { tmp7 = ifn_2692.Invoke_O__O(arg_2693) } else { tmp7 = linked_2691.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2690, arg_2693) }; if jrt.J2g_Truth(tmp7) { var root_2703 any = A_arbace_cpp_inline_A_const_47.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2705 lang.IFn; if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = lang.Tuple_Create_O_O__IPersistentVector(c__4, lang.IFn_Cast(t.F_finish).Invoke_O__O(c__4)); var arg_2707 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__113000288); var tmp9 any; var root_2708 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2708, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2710 lang.IFn; if linked_2709 == nil { ifn_2710 = lang.IFn_Cast(root_2708) } else { ifn_2710 = nil }; var arg_2711 any = s__113000289__3; if linked_2709 == nil { tmp9 = ifn_2710.Invoke_O__O(arg_2711) } else { tmp9 = linked_2709.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2708, arg_2711) }; arg_2707 = tmp8.Invoke_O__O(tmp9); if linked_2704 == nil { return ifn_2705.Invoke_O_O__O(arg_2706, arg_2707) } else { return linked_2704.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2703, arg_2706, arg_2707) } } else { var tmp10 any; var root_2712 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2712, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2714 lang.IFn; if linked_2713 == nil { ifn_2714 = lang.IFn_Cast(root_2712) } else { ifn_2714 = nil }; var arg_2715 any = s__113000289__3; if linked_2713 == nil { tmp10 = ifn_2714.Invoke_O__O(arg_2715) } else { tmp10 = linked_2713.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2712, arg_2715) }; s__113000289__1 = tmp10; continue L1 } } else { var tmp11 any; var root_2716 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2718 lang.IFn; if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = s__113000289__3; if linked_2717 == nil { tmp11 = ifn_2718.Invoke_O__O(arg_2719) } else { tmp11 = linked_2717.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2716, arg_2719) }; s__113000289__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :342:1
func A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :342:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A) Ctor_O_O_O_O_I_O(c__b__113000291, c__ai_names, c__finish, c__busy any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__113000291 = c__b__113000291; t.F_ai_names = c__ai_names; t.F_finish = c__finish; t.F_busy = c__busy; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :342:1
func (t *A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A) Invoke_O__O(self any) any { { var i__113000290__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__113000290__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__113000290__1)); var tmp2 any; var root_2634 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2634, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2636 lang.IFn; if linked_2635 == nil { ifn_2636 = lang.IFn_Cast(root_2634) } else { ifn_2636 = nil }; var arg_2637 any = t.F_ai_names; var arg_2638 any = c__2; if linked_2635 == nil { tmp2 = ifn_2636.Invoke_O_O__O(arg_2637, arg_2638) } else { tmp2 = linked_2635.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2634, arg_2637, arg_2638) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_2639 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_2640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2639, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2641 lang.IFn; if linked_2640 == nil { ifn_2641 = lang.IFn_Cast(root_2639) } else { ifn_2641 = nil }; var arg_2642 any; var root_2643 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2643, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2645 lang.IFn; if linked_2644 == nil { ifn_2645 = lang.IFn_Cast(root_2643) } else { ifn_2645 = nil }; var arg_2646 any; var root_2648 any = A_arbace_cpp_inline_A_const_5.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2648, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var arg_2651 any = t.F_busy; if linked_2649 == nil { arg_2646 = ifn_2650.Invoke_O__O(arg_2651) } else { arg_2646 = linked_2649.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2648, arg_2651) }; var arg_2647 any = c__2; if linked_2644 == nil { arg_2642 = ifn_2645.Invoke_O_O__O(arg_2646, arg_2647) } else { arg_2642 = linked_2644.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2643, arg_2646, arg_2647) }; if linked_2640 == nil { tmp3 = ifn_2641.Invoke_O__O(arg_2642) } else { tmp3 = linked_2640.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2639, arg_2642) }; if jrt.J2g_Truth(tmp3) { var root_2652 any = A_arbace_cpp_inline_A_const_42.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any = t.F_b__113000291; var arg_2656 any = lang.Tuple_Create_O_O__IPersistentVector(c__2, lang.IFn_Cast(t.F_finish).Invoke_O__O(c__2)); if linked_2653 == nil { ifn_2654.Invoke_O_O__O(arg_2655, arg_2656) } else { linked_2653.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2652, arg_2655, arg_2656) }; i__113000290__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000290__1); continue L1 } else { i__113000290__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000290__1); continue L1 } } else { i__113000290__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000290__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_cpp_inline_always_inline_fn__113000299_A_New_O_O_O(p0, p1, p2 any) *A_arbace_cpp_inline_always_inline_fn__113000299_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_fn__113000299_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :347:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_A) Ctor_O_O_O(c__nounwind_fns, c__finish, c__ai_names any) { t.F_nounwind_fns = c__nounwind_fns; t.F_finish = c__finish; t.F_ai_names = c__ai_names }
//line :347:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any = A_arbace_cpp_inline_A_const_180; var tmp2 any; var root_2756 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2756, A_arbace_cpp_inline_head_A_fn_class); var ifn_2758 lang.IFn; if linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any = f__1; if linked_2757 == nil { tmp2 = ifn_2758.Invoke_O__O(arg_2759) } else { tmp2 = linked_2757.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2756, arg_2759) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var n__2 any; var root_2760 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2762 lang.IFn
		if linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any; var root_2764 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; var arg_2767 any = f__1; if linked_2765 == nil { arg_2763 = ifn_2766.Invoke_O__O(arg_2767) } else { arg_2763 = linked_2765.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2764, arg_2767) }; if linked_2761 == nil { n__2 = ifn_2762.Invoke_O__O(arg_2763) } else { n__2 = linked_2761.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2760, arg_2763) }
		var tmp3 any; var root_2768 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2768, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2770 lang.IFn; if linked_2769 == nil { ifn_2770 = lang.IFn_Cast(root_2768) } else { ifn_2770 = nil }; var arg_2771 any = t.F_ai_names; var arg_2772 any = n__2; if linked_2769 == nil { tmp3 = ifn_2770.Invoke_O_O__O(arg_2771, arg_2772) } else { tmp3 = linked_2769.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2768, arg_2771, arg_2772) }; if jrt.J2g_Truth(tmp3) {
			return lang.IFn_Cast(t.F_finish).Invoke_O__O(n__2) } else {
//line :350:1
				var callees__3 any; var root_2773 any = A_arbace_cpp_inline_A_const_124.GetRawRoot__O(); var linked_2774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2773, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2775 lang.IFn

				if linked_2774 == nil { ifn_2775 = lang.IFn_Cast(root_2773) } else { ifn_2775 = nil }; var arg_2776 any; var root_2777 any = A_arbace_cpp_inline_A_const_125.GetRawRoot__O(); var linked_2778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2777, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2779 lang.IFn; if linked_2778 == nil { ifn_2779 = lang.IFn_Cast(root_2777) } else { ifn_2779 = nil }; var arg_2780 any; var fnbody__2787 any = A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A_New(); var tmp4 *jrt.Class; var fncls__2786 *jrt.Class = A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A_fn_class; if fncls__2786 == nil { var fncls__2786d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A_fn_class = fncls__2786d; tmp4 = fncls__2786d } else { tmp4 = fncls__2786 }; arg_2780 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2787, tmp4, nil); var arg_2781 any; var root_2788 any = A_arbace_cpp_inline_A_const_54.GetRawRoot__O(); var linked_2789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2788, A_arbace_cpp_inline_calls_in_A_fn_class); var ifn_2790 lang.IFn; if linked_2789 == nil { ifn_2790 = lang.IFn_Cast(root_2788) } else { ifn_2790 = nil }; var arg_2791 any = f__1; if linked_2789 == nil { arg_2781 = ifn_2790.Invoke_O__O(arg_2791) } else { arg_2781 = linked_2789.(*A_arbace_cpp_inline_calls_in_A).Invoke_O_O__O(root_2788, arg_2791) }; if linked_2778 == nil { arg_2776 = ifn_2779.Invoke_O_O__O(arg_2780, arg_2781) } else { arg_2776 = linked_2778.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2777, arg_2780, arg_2781) }; if linked_2774 == nil { callees__3 = ifn_2775.Invoke_O__O(arg_2776) } else { callees__3 = linked_2774.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2773, arg_2776) }
//line :350:1
				var ai__4 any; var root_2792 any = A_arbace_cpp_inline_A_const_74.GetRawRoot__O(); var linked_2793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2792, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2794 lang.IFn


				if linked_2793 == nil { ifn_2794 = lang.IFn_Cast(root_2792) } else { ifn_2794 = nil }; var arg_2795 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2796 any; var iter__1927001039__auto____4 any; var fnbody__2872 any = A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A_New_O_O(t.F_finish, t.F_ai_names); var tmp5 *jrt.Class; var fncls__2871 *jrt.Class = A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A_fn_class; if fncls__2871 == nil { var fncls__2871d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__2872); A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A_fn_class = fncls__2871d; tmp5 = fncls__2871d } else { tmp5 = fncls__2871 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2872, tmp5, nil); arg_2796 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(callees__3); if linked_2793 == nil { ai__4 = ifn_2794.Invoke_O_O__O(arg_2795, arg_2796) } else { ai__4 = linked_2793.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2792, arg_2795, arg_2796) }
				var tmp6 any; var root_2873 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_2874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2873, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2875 lang.IFn; if linked_2874 == nil { ifn_2875 = lang.IFn_Cast(root_2873) } else { ifn_2875 = nil }; var arg_2876 any = ai__4; if linked_2874 == nil { tmp6 = ifn_2875.Invoke_O__O(arg_2876) } else { tmp6 = linked_2874.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2873, arg_2876) }; if jrt.J2g_Truth(tmp6) { var root_2877 any = A_arbace_cpp_inline_A_const_178.GetRawRoot__O(); var linked_2878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2877, A_arbace_cpp_inline_inline_into_A_fn_class); var ifn_2879 lang.IFn; if linked_2878 == nil { ifn_2879 = lang.IFn_Cast(root_2877) } else { ifn_2879 = nil }; var arg_2880 any = f__1; var arg_2881 any = ai__4; var arg_2882 any = t.F_nounwind_fns; if linked_2878 == nil { return ifn_2879.Invoke_O_O_O__O(arg_2880, arg_2881, arg_2882) } else { return linked_2878.(*A_arbace_cpp_inline_inline_into_A).Invoke_O_O_O_O__O(root_2877, arg_2880, arg_2881, arg_2882) } } else { return f__1 } } } else {
//line :348:1
					return f__1
				}
}

func A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A_New() *A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A) Ctor() {}
//line :352:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A) Invoke_O_O__O(self, p1__113000247_SHARP___1 any) any { var root_2782 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2782, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2784 lang.IFn; if linked_2783 == nil { ifn_2784 = lang.IFn_Cast(root_2782) } else { ifn_2784 = nil }; var arg_2785 any = lang.RT_Nth_O_I__O_NoInit(p1__113000247_SHARP___1, lang.RT_IntCast_J__I_NoInit(2)); if linked_2783 == nil { return ifn_2784.Invoke_O__O(arg_2785) } else { return linked_2783.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2782, arg_2785) } }
func A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :353:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A) Ctor_O_O(c__finish, c__ai_names any) { t.F_finish = c__finish; t.F_ai_names = c__ai_names }
//line :353:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A) Invoke_O_O__O(self, s__113000303__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2870 any = A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A_New_O_O_O_O(self, s__113000303__1, t.F_finish, t.F_ai_names); var tmp2 *jrt.Class; var fncls__2869 *jrt.Class = A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A_fn_class; if fncls__2869 == nil { var fncls__2869d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__2870); A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A_fn_class = fncls__2869d; tmp2 = fncls__2869d } else { tmp2 = fncls__2869 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2870, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :353:1
func A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :353:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A) Ctor_O_O_O_O(c__iter__113000302, c__s__113000303, c__finish, c__ai_names any) { t.F_iter__113000302 = c__iter__113000302; t.F_s__113000303 = c__s__113000303; t.F_finish = c__finish; t.F_ai_names = c__ai_names }
//line :353:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A) Invoke_O__O(self any) any { { var s__113000303__1 any; var t_ any = t.F_s__113000303; t.F_s__113000303 = nil; s__113000303__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2797 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_2798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2797, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2799 lang.IFn; if linked_2798 == nil { ifn_2799 = lang.IFn_Cast(root_2797) } else { ifn_2799 = nil }; var arg_2800 any = s__113000303__1; if linked_2798 == nil { temp__1927000414__auto____2 = ifn_2799.Invoke_O__O(arg_2800) } else { temp__1927000414__auto____2 = linked_2798.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2797, arg_2800) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__113000303__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2801 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_2802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2801, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2803 lang.IFn; if linked_2802 == nil { ifn_2803 = lang.IFn_Cast(root_2801) } else { ifn_2803 = nil }; var arg_2804 any = s__113000303__3; if linked_2802 == nil { tmp1 = ifn_2803.Invoke_O__O(arg_2804) } else { tmp1 = linked_2802.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2801, arg_2804) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2805 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_2806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2805, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2807 lang.IFn; if linked_2806 == nil { ifn_2807 = lang.IFn_Cast(root_2805) } else { ifn_2807 = nil }; var arg_2808 any = s__113000303__3; if linked_2806 == nil { c__1927001037__auto____4 = ifn_2807.Invoke_O__O(arg_2808) } else { c__1927001037__auto____4 = linked_2806.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2805, arg_2808) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__113000305__6 any; var root_2809 any = A_arbace_cpp_inline_A_const_38.GetRawRoot__O(); var linked_2810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2809, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2811 lang.IFn; if linked_2810 == nil { ifn_2811 = lang.IFn_Cast(root_2809) } else { ifn_2811 = nil }; var arg_2812 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2810 == nil { b__113000305__6 = ifn_2811.Invoke_O__O(arg_2812) } else { b__113000305__6 = linked_2810.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2809, arg_2812) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2824 any = A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A_New_O_O_O_I_O(t.F_finish, t.F_ai_names, b__113000305__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2823 *jrt.Class = A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A_fn_class; if fncls__2823 == nil { var fncls__2823d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__2824); A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A_fn_class = fncls__2823d; tmp3 = fncls__2823d } else { tmp3 = fncls__2823 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2824, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2825 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any; var root_2830 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2830, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2832 lang.IFn; if linked_2831 == nil { ifn_2832 = lang.IFn_Cast(root_2830) } else { ifn_2832 = nil }; var arg_2833 any = b__113000305__6; if linked_2831 == nil { arg_2828 = ifn_2832.Invoke_O__O(arg_2833) } else { arg_2828 = linked_2831.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2830, arg_2833) }; var arg_2829 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__113000302); var tmp5 any; var root_2834 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_2835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2834, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2836 lang.IFn; if linked_2835 == nil { ifn_2836 = lang.IFn_Cast(root_2834) } else { ifn_2836 = nil }; var arg_2837 any = s__113000303__3; if linked_2835 == nil { tmp5 = ifn_2836.Invoke_O__O(arg_2837) } else { tmp5 = linked_2835.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2834, arg_2837) }; arg_2829 = tmp4.Invoke_O__O(tmp5); if linked_2826 == nil { return ifn_2827.Invoke_O_O__O(arg_2828, arg_2829) } else { return linked_2826.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2825, arg_2828, arg_2829) } } else { var root_2838 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_2839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2838, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2840 lang.IFn; if linked_2839 == nil { ifn_2840 = lang.IFn_Cast(root_2838) } else { ifn_2840 = nil }; var arg_2841 any; var root_2843 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_2844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2843, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2845 lang.IFn; if linked_2844 == nil { ifn_2845 = lang.IFn_Cast(root_2843) } else { ifn_2845 = nil }; var arg_2846 any = b__113000305__6; if linked_2844 == nil { arg_2841 = ifn_2845.Invoke_O__O(arg_2846) } else { arg_2841 = linked_2844.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2843, arg_2846) }; var arg_2842 any; if linked_2839 == nil { return ifn_2840.Invoke_O_O__O(arg_2841, arg_2842) } else { return linked_2839.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2838, arg_2841, arg_2842) } } } else { var c__4 any; var root_2847 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_2848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2847, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2849 lang.IFn; if linked_2848 == nil { ifn_2849 = lang.IFn_Cast(root_2847) } else { ifn_2849 = nil }; var arg_2850 any = s__113000303__3; if linked_2848 == nil { c__4 = ifn_2849.Invoke_O__O(arg_2850) } else { c__4 = linked_2848.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2847, arg_2850) }; var tmp6 any; var root_2851 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any = t.F_ai_names; var arg_2855 any = c__4; if linked_2852 == nil { tmp6 = ifn_2853.Invoke_O_O__O(arg_2854, arg_2855) } else { tmp6 = linked_2852.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2851, arg_2854, arg_2855) }; if jrt.J2g_Truth(tmp6) { var root_2856 any = A_arbace_cpp_inline_A_const_47.GetRawRoot__O(); var linked_2857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2856, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2858 lang.IFn; if linked_2857 == nil { ifn_2858 = lang.IFn_Cast(root_2856) } else { ifn_2858 = nil }; var arg_2859 any = lang.Tuple_Create_O_O__IPersistentVector(c__4, lang.IFn_Cast(t.F_finish).Invoke_O__O(c__4)); var arg_2860 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__113000302); var tmp8 any; var root_2861 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2861, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2863 lang.IFn; if linked_2862 == nil { ifn_2863 = lang.IFn_Cast(root_2861) } else { ifn_2863 = nil }; var arg_2864 any = s__113000303__3; if linked_2862 == nil { tmp8 = ifn_2863.Invoke_O__O(arg_2864) } else { tmp8 = linked_2862.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2861, arg_2864) }; arg_2860 = tmp7.Invoke_O__O(tmp8); if linked_2857 == nil { return ifn_2858.Invoke_O_O__O(arg_2859, arg_2860) } else { return linked_2857.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2856, arg_2859, arg_2860) } } else { var tmp9 any; var root_2865 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_2866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2865, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2867 lang.IFn; if linked_2866 == nil { ifn_2867 = lang.IFn_Cast(root_2865) } else { ifn_2867 = nil }; var arg_2868 any = s__113000303__3; if linked_2866 == nil { tmp9 = ifn_2867.Invoke_O__O(arg_2868) } else { tmp9 = linked_2866.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2865, arg_2868) }; s__113000303__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :353:1
func A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :353:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A) Ctor_O_O_O_I_O(c__finish, c__ai_names, c__b__113000305 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_finish = c__finish; t.F_ai_names = c__ai_names; t.F_b__113000305 = c__b__113000305; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :353:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A) Invoke_O__O(self any) any { { var i__113000304__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__113000304__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__113000304__1)); var tmp2 any; var root_2813 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2813, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2815 lang.IFn; if linked_2814 == nil { ifn_2815 = lang.IFn_Cast(root_2813) } else { ifn_2815 = nil }; var arg_2816 any = t.F_ai_names; var arg_2817 any = c__2; if linked_2814 == nil { tmp2 = ifn_2815.Invoke_O_O__O(arg_2816, arg_2817) } else { tmp2 = linked_2814.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2813, arg_2816, arg_2817) }; if jrt.J2g_Truth(tmp2) { var root_2818 any = A_arbace_cpp_inline_A_const_42.GetRawRoot__O(); var linked_2819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2818, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2820 lang.IFn; if linked_2819 == nil { ifn_2820 = lang.IFn_Cast(root_2818) } else { ifn_2820 = nil }; var arg_2821 any = t.F_b__113000305; var arg_2822 any = lang.Tuple_Create_O_O__IPersistentVector(c__2, lang.IFn_Cast(t.F_finish).Invoke_O__O(c__2)); if linked_2819 == nil { ifn_2820.Invoke_O_O__O(arg_2821, arg_2822) } else { linked_2819.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2818, arg_2821, arg_2822) }; i__113000304__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000304__1); continue L1 } else { i__113000304__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000304__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_cpp_inline_always_inline_fn__113000313_A_New() *A_arbace_cpp_inline_always_inline_fn__113000313_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_fn__113000313_A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000313_A) Ctor() {}
//line :360:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000313_A) Invoke_O_O_O__O(self, acc__1, f__2 any) any {
	var tmp1 any = A_arbace_cpp_inline_A_const_182; var tmp2 any; var root_2895 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2895, A_arbace_cpp_inline_head_A_fn_class); var ifn_2897 lang.IFn; if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any = f__2; if linked_2896 == nil { tmp2 = ifn_2897.Invoke_O__O(arg_2898) } else { tmp2 = linked_2896.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2895, arg_2898) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { var own__3 any; var root_2899 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2899, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2901 lang.IFn
		if linked_2900 == nil { ifn_2901 = lang.IFn_Cast(root_2899) } else { ifn_2901 = nil }; var arg_2902 any; var root_2903 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_2904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2903, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2905 lang.IFn; if linked_2904 == nil { ifn_2905 = lang.IFn_Cast(root_2903) } else { ifn_2905 = nil }; var arg_2906 any = f__2; if linked_2904 == nil { arg_2902 = ifn_2905.Invoke_O__O(arg_2906) } else { arg_2902 = linked_2904.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2903, arg_2906) }; if linked_2900 == nil { own__3 = ifn_2901.Invoke_O__O(arg_2902) } else { own__3 = linked_2900.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2899, arg_2902) }
		var root_2907 any = A_arbace_cpp_inline_A_const_148.GetRawRoot__O(); var linked_2908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2907, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2909 lang.IFn; if linked_2908 == nil { ifn_2909 = lang.IFn_Cast(root_2907) } else { ifn_2909 = nil }; var arg_2910 any; var fnbody__2919 any = A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A_New_O(own__3); var tmp3 *jrt.Class; var fncls__2918 *jrt.Class = A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A_fn_class; if fncls__2918 == nil { var fncls__2918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__2919); A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A_fn_class = fncls__2918d; tmp3 = fncls__2918d } else { tmp3 = fncls__2918 }; arg_2910 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2919, tmp3, nil); var arg_2911 any = acc__1; var arg_2912 any; var root_2920 any = A_arbace_cpp_inline_A_const_181.GetRawRoot__O(); var linked_2921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2920, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_2922 lang.IFn; if linked_2921 == nil { ifn_2922 = lang.IFn_Cast(root_2920) } else { ifn_2922 = nil }; var arg_2923 any; var root_2924 any = A_arbace_cpp_inline_A_const_169.GetRawRoot__O(); var linked_2925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2924, A_arbace_cpp_inline_mentions_A_fn_class); var ifn_2926 lang.IFn; if linked_2925 == nil { ifn_2926 = lang.IFn_Cast(root_2924) } else { ifn_2926 = nil }; var arg_2927 any; var root_2929 any = A_arbace_cpp_inline_A_const_21.GetRawRoot__O(); var linked_2930 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2929, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2931 lang.IFn; if linked_2930 == nil { ifn_2931 = lang.IFn_Cast(root_2929) } else { ifn_2931 = nil }; var arg_2933 any = f__2; if linked_2930 == nil { arg_2927 = ifn_2931.Invoke_O_O__O(A_arbace_cpp_inline_A_const_49, arg_2933) } else { arg_2927 = linked_2930.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2929, 2, A_arbace_cpp_inline_A_const_49, arg_2933) }; var arg_2928 any; var root_2934 any = A_arbace_cpp_inline_A_const_183.GetRawRoot__O(); var linked_2935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2934, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_2936 lang.IFn; if linked_2935 == nil { ifn_2936 = lang.IFn_Cast(root_2934) } else { ifn_2936 = nil }; var arg_2937 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_2935 == nil { arg_2928 = ifn_2936.Invoke_O__O(arg_2937) } else { arg_2928 = linked_2935.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_2934, arg_2937) }; if linked_2925 == nil { arg_2923 = ifn_2926.Invoke_O_O__O(arg_2927, arg_2928) } else { arg_2923 = linked_2925.(*A_arbace_cpp_inline_mentions_A).Invoke_O_O_O__O(root_2924, arg_2927, arg_2928) }; if linked_2921 == nil { arg_2912 = ifn_2922.Invoke_O__O(arg_2923) } else { arg_2912 = linked_2921.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_2920, arg_2923) }; if linked_2908 == nil { return ifn_2909.Invoke_O_O_O__O(arg_2910, arg_2911, arg_2912) } else { return linked_2908.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2907, arg_2910, arg_2911, arg_2912) } } else {
			var root_2938 any = A_arbace_cpp_inline_A_const_169.GetRawRoot__O(); var linked_2939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2938, A_arbace_cpp_inline_mentions_A_fn_class); var ifn_2940 lang.IFn; if linked_2939 == nil { ifn_2940 = lang.IFn_Cast(root_2938) } else { ifn_2940 = nil }; var arg_2941 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_184); var tmp5 any; var root_2948 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2948, A_arbace_cpp_inline_head_A_fn_class); var ifn_2950 lang.IFn; if linked_2949 == nil { ifn_2950 = lang.IFn_Cast(root_2948) } else { ifn_2950 = nil }; var arg_2951 any = f__2; if linked_2949 == nil { tmp5 = ifn_2950.Invoke_O__O(arg_2951) } else { tmp5 = linked_2949.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2948, arg_2951) }; if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5)) { arg_2941 = lang.PersistentVector_EMPTY.Ref() } else { var root_2943 any = A_arbace_cpp_inline_A_const_21.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2947 any = f__2; if linked_2944 == nil { arg_2941 = ifn_2945.Invoke_O_O__O(A_arbace_cpp_inline_A_const_49, arg_2947) } else { arg_2941 = linked_2944.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2943, 2, A_arbace_cpp_inline_A_const_49, arg_2947) } }; var arg_2942 any = acc__1; if linked_2939 == nil { return ifn_2940.Invoke_O_O__O(arg_2941, arg_2942) } else { return linked_2939.(*A_arbace_cpp_inline_mentions_A).Invoke_O_O_O__O(root_2938, arg_2941, arg_2942) } } }
//line :363:1
func A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A_New_O(p0 any) *A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A{}; t.Ctor_O(p0); return t }
//line :363:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A) Ctor_O(c__own any) { t.F_own = c__own }
//line :363:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A) Invoke_O_O_O__O(self, a__1, n__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(n__2, t.F_own) { return a__1 } else { var root_2913 any = A_arbace_cpp_inline_A_const_168.GetRawRoot__O(); var linked_2914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2913, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_2915 lang.IFn; if linked_2914 == nil { ifn_2915 = lang.IFn_Cast(root_2913) } else { ifn_2915 = nil }; var arg_2916 any = a__1; var arg_2917 any = n__2; if linked_2914 == nil { return ifn_2915.Invoke_O_O__O(arg_2916, arg_2917) } else { return linked_2914.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_2913, arg_2916, arg_2917) } } }


func A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A_New_O_O(p0, p1 any) *A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A{}; t.Ctor_O_O(p0, p1); return t }
//line :366:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A) Ctor_O_O(c__ai_names, c__used any) { t.F_ai_names = c__ai_names; t.F_used = c__used }
//line :366:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A) Invoke_O_O__O(self, s__113000318__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3097 any = A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A_New_O_O_O_O(self, s__113000318__1, t.F_ai_names, t.F_used); var tmp2 *jrt.Class; var fncls__3096 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A_fn_class; if fncls__3096 == nil { var fncls__3096d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__3097); A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A_fn_class = fncls__3096d; tmp2 = fncls__3096d } else { tmp2 = fncls__3096 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3097, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :366:1
func A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :366:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A) Ctor_O_O_O_O(c__iter__113000317, c__s__113000318, c__ai_names, c__used any) { t.F_iter__113000317 = c__iter__113000317; t.F_s__113000318 = c__s__113000318; t.F_ai_names = c__ai_names; t.F_used = c__used }
//line :366:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A) Invoke_O__O(self any) any { { var s__113000318__1 any; var t_ any = t.F_s__113000318; t.F_s__113000318 = nil; s__113000318__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2962 any = A_arbace_cpp_inline_A_const_22.GetRawRoot__O(); var linked_2963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2962, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2964 lang.IFn; if linked_2963 == nil { ifn_2964 = lang.IFn_Cast(root_2962) } else { ifn_2964 = nil }; var arg_2965 any = s__113000318__1; if linked_2963 == nil { temp__1927000414__auto____2 = ifn_2964.Invoke_O__O(arg_2965) } else { temp__1927000414__auto____2 = linked_2963.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2962, arg_2965) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__113000318__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2966 any = A_arbace_cpp_inline_A_const_36.GetRawRoot__O(); var linked_2967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2966, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2968 lang.IFn; if linked_2967 == nil { ifn_2968 = lang.IFn_Cast(root_2966) } else { ifn_2968 = nil }; var arg_2969 any = s__113000318__3; if linked_2967 == nil { tmp1 = ifn_2968.Invoke_O__O(arg_2969) } else { tmp1 = linked_2967.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2966, arg_2969) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2970 any = A_arbace_cpp_inline_A_const_37.GetRawRoot__O(); var linked_2971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2970, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2972 lang.IFn; if linked_2971 == nil { ifn_2972 = lang.IFn_Cast(root_2970) } else { ifn_2972 = nil }; var arg_2973 any = s__113000318__3; if linked_2971 == nil { c__1927001037__auto____4 = ifn_2972.Invoke_O__O(arg_2973) } else { c__1927001037__auto____4 = linked_2971.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2970, arg_2973) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__113000320__6 any; var root_2974 any = A_arbace_cpp_inline_A_const_38.GetRawRoot__O(); var linked_2975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2974, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2976 lang.IFn; if linked_2975 == nil { ifn_2976 = lang.IFn_Cast(root_2974) } else { ifn_2976 = nil }; var arg_2977 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2975 == nil { b__113000320__6 = ifn_2976.Invoke_O__O(arg_2977) } else { b__113000320__6 = linked_2975.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2974, arg_2977) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3014 any = A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A_New_O_O_O_I_O(b__113000320__6, t.F_ai_names, t.F_used, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3013 *jrt.Class = A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A_fn_class; if fncls__3013 == nil { var fncls__3013d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__3014); A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A_fn_class = fncls__3013d; tmp3 = fncls__3013d } else { tmp3 = fncls__3013 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3014, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3015 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_3016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3015, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3017 lang.IFn; if linked_3016 == nil { ifn_3017 = lang.IFn_Cast(root_3015) } else { ifn_3017 = nil }; var arg_3018 any; var root_3020 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_3021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3020, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3022 lang.IFn; if linked_3021 == nil { ifn_3022 = lang.IFn_Cast(root_3020) } else { ifn_3022 = nil }; var arg_3023 any = b__113000320__6; if linked_3021 == nil { arg_3018 = ifn_3022.Invoke_O__O(arg_3023) } else { arg_3018 = linked_3021.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3020, arg_3023) }; var arg_3019 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__113000317); var tmp5 any; var root_3024 any = A_arbace_cpp_inline_A_const_45.GetRawRoot__O(); var linked_3025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3024, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3026 lang.IFn; if linked_3025 == nil { ifn_3026 = lang.IFn_Cast(root_3024) } else { ifn_3026 = nil }; var arg_3027 any = s__113000318__3; if linked_3025 == nil { tmp5 = ifn_3026.Invoke_O__O(arg_3027) } else { tmp5 = linked_3025.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3024, arg_3027) }; arg_3019 = tmp4.Invoke_O__O(tmp5); if linked_3016 == nil { return ifn_3017.Invoke_O_O__O(arg_3018, arg_3019) } else { return linked_3016.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3015, arg_3018, arg_3019) } } else { var root_3028 any = A_arbace_cpp_inline_A_const_43.GetRawRoot__O(); var linked_3029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3028, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3030 lang.IFn; if linked_3029 == nil { ifn_3030 = lang.IFn_Cast(root_3028) } else { ifn_3030 = nil }; var arg_3031 any; var root_3033 any = A_arbace_cpp_inline_A_const_44.GetRawRoot__O(); var linked_3034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3033, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3035 lang.IFn; if linked_3034 == nil { ifn_3035 = lang.IFn_Cast(root_3033) } else { ifn_3035 = nil }; var arg_3036 any = b__113000320__6; if linked_3034 == nil { arg_3031 = ifn_3035.Invoke_O__O(arg_3036) } else { arg_3031 = linked_3034.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3033, arg_3036) }; var arg_3032 any; if linked_3029 == nil { return ifn_3030.Invoke_O_O__O(arg_3031, arg_3032) } else { return linked_3029.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3028, arg_3031, arg_3032) } } } else { var f__4 any; var root_3037 any = A_arbace_cpp_inline_A_const_14.GetRawRoot__O(); var linked_3038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3037, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3039 lang.IFn; if linked_3038 == nil { ifn_3039 = lang.IFn_Cast(root_3037) } else { ifn_3039 = nil }; var arg_3040 any = s__113000318__3; if linked_3038 == nil { f__4 = ifn_3039.Invoke_O__O(arg_3040) } else { f__4 = linked_3038.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3037, arg_3040) }; var tmp6 any = A_arbace_cpp_inline_A_const_185; var tmp7 any; var root_3041 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_3042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3041, A_arbace_cpp_inline_head_A_fn_class); var ifn_3043 lang.IFn; if linked_3042 == nil { ifn_3043 = lang.IFn_Cast(root_3041) } else { ifn_3043 = nil }; var arg_3044 any = f__4; if linked_3042 == nil { tmp7 = ifn_3043.Invoke_O__O(arg_3044) } else { tmp7 = linked_3042.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_3041, arg_3044) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, tmp7) { var n__5 any; var root_3045 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_3046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3045, A_arbace_cpp_inline_gname_A_fn_class); var ifn_3047 lang.IFn; if linked_3046 == nil { ifn_3047 = lang.IFn_Cast(root_3045) } else { ifn_3047 = nil }; var arg_3048 any; var root_3049 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_3050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3049, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3051 lang.IFn; if linked_3050 == nil { ifn_3051 = lang.IFn_Cast(root_3049) } else { ifn_3051 = nil }; var arg_3052 any = f__4; if linked_3050 == nil { arg_3048 = ifn_3051.Invoke_O__O(arg_3052) } else { arg_3048 = linked_3050.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3049, arg_3052) }; if linked_3046 == nil { n__5 = ifn_3047.Invoke_O__O(arg_3048) } else { n__5 = linked_3046.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_3045, arg_3048) }; var tmp8 any; var root_3053 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_3054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3053, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3055 lang.IFn
															if linked_3054 == nil { ifn_3055 = lang.IFn_Cast(root_3053) } else { ifn_3055 = nil }; var arg_3056 any = t.F_ai_names; var arg_3057 any = n__5; if linked_3054 == nil { tmp8 = ifn_3055.Invoke_O_O__O(arg_3056, arg_3057) } else { tmp8 = linked_3054.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3053, arg_3056, arg_3057) }
//line :366:1
	if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_3058 any = A_arbace_cpp_inline_A_const_186.GetRawRoot__O(); var linked_3059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3058, A_arbace_cpp_inline_discardable_QMARK__A_fn_class); var ifn_3060 lang.IFn
		if linked_3059 == nil { ifn_3060 = lang.IFn_Cast(root_3058) } else { ifn_3060 = nil }; var arg_3061 any = f__4; if linked_3059 == nil { tmp9 = ifn_3060.Invoke_O__O(arg_3061) } else { tmp9 = linked_3059.(*A_arbace_cpp_inline_discardable_QMARK__A).Invoke_O_O__O(root_3058, arg_3061) }
//line :366:1
		if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_3062 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_3063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3062, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3064 lang.IFn
			if linked_3063 == nil { ifn_3064 = lang.IFn_Cast(root_3062) } else { ifn_3064 = nil }; var arg_3065 any; var root_3066 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_3067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3066, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3068 lang.IFn; if linked_3067 == nil { ifn_3068 = lang.IFn_Cast(root_3066) } else { ifn_3068 = nil }; var arg_3069 any = t.F_used; var arg_3070 any = n__5; if linked_3067 == nil { arg_3065 = ifn_3068.Invoke_O_O__O(arg_3069, arg_3070) } else { arg_3065 = linked_3067.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3066, arg_3069, arg_3070) }; if linked_3063 == nil { tmp10 = ifn_3064.Invoke_O__O(arg_3065) } else { tmp10 = linked_3063.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3062, arg_3065) }
//line :366:1
			if jrt.J2g_Truth(tmp10) { var root_3071 any = A_arbace_cpp_inline_A_const_47.GetRawRoot__O(); var linked_3072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3071, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3073 lang.IFn; if linked_3072 == nil { ifn_3073 = lang.IFn_Cast(root_3071) } else { ifn_3073 = nil }; var arg_3074 any = n__5; var arg_3075 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__113000317); var tmp12 any; var root_3076 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3078 lang.IFn; if linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any = s__113000318__3; if linked_3077 == nil { tmp12 = ifn_3078.Invoke_O__O(arg_3079) } else { tmp12 = linked_3077.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3076, arg_3079) }; arg_3075 = tmp11.Invoke_O__O(tmp12); if linked_3072 == nil { return ifn_3073.Invoke_O_O__O(arg_3074, arg_3075) } else { return linked_3072.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3071, arg_3074, arg_3075) } } else { var tmp13 any; var root_3080 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_3081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3080, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3082 lang.IFn; if linked_3081 == nil { ifn_3082 = lang.IFn_Cast(root_3080) } else { ifn_3082 = nil }; var arg_3083 any = s__113000318__3; if linked_3081 == nil { tmp13 = ifn_3082.Invoke_O__O(arg_3083) } else { tmp13 = linked_3081.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3080, arg_3083) }; s__113000318__1 = tmp13; continue L1 } } else { var tmp14 any; var root_3084 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_3085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3084, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3086 lang.IFn; if linked_3085 == nil { ifn_3086 = lang.IFn_Cast(root_3084) } else { ifn_3086 = nil }; var arg_3087 any = s__113000318__3; if linked_3085 == nil { tmp14 = ifn_3086.Invoke_O__O(arg_3087) } else { tmp14 = linked_3085.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3084, arg_3087) }; s__113000318__1 = tmp14; continue L1 } } else { var tmp15 any; var root_3088 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_3089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3088, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3090 lang.IFn; if linked_3089 == nil { ifn_3090 = lang.IFn_Cast(root_3088) } else { ifn_3090 = nil }; var arg_3091 any = s__113000318__3; if linked_3089 == nil { tmp15 = ifn_3090.Invoke_O__O(arg_3091) } else { tmp15 = linked_3089.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3088, arg_3091) }; s__113000318__1 = tmp15; continue L1 } } else { var tmp16 any; var root_3092 any = A_arbace_cpp_inline_A_const_48.GetRawRoot__O(); var linked_3093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3092, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3094 lang.IFn; if linked_3093 == nil { ifn_3094 = lang.IFn_Cast(root_3092) } else { ifn_3094 = nil }; var arg_3095 any = s__113000318__3; if linked_3093 == nil { tmp16 = ifn_3094.Invoke_O__O(arg_3095) } else { tmp16 = linked_3093.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3092, arg_3095) }; s__113000318__1 = tmp16; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :366:1
func A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :366:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A) Ctor_O_O_O_I_O(c__b__113000320, c__ai_names, c__used any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__113000320 = c__b__113000320; t.F_ai_names = c__ai_names; t.F_used = c__used; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :366:1
func (t *A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A) Invoke_O__O(self any) any { { var i__113000319__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__113000319__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__113000319__1)); var tmp2 any = A_arbace_cpp_inline_A_const_185; var tmp3 any; var root_2978 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_2979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2978, A_arbace_cpp_inline_head_A_fn_class); var ifn_2980 lang.IFn; if linked_2979 == nil { ifn_2980 = lang.IFn_Cast(root_2978) } else { ifn_2980 = nil }; var arg_2981 any = f__2; if linked_2979 == nil { tmp3 = ifn_2980.Invoke_O__O(arg_2981) } else { tmp3 = linked_2979.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_2978, arg_2981) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var n__3 any; var root_2982 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_2983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2982, A_arbace_cpp_inline_gname_A_fn_class); var ifn_2984 lang.IFn; if linked_2983 == nil { ifn_2984 = lang.IFn_Cast(root_2982) } else { ifn_2984 = nil }; var arg_2985 any; var root_2986 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_2987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2986, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2988 lang.IFn; if linked_2987 == nil { ifn_2988 = lang.IFn_Cast(root_2986) } else { ifn_2988 = nil }; var arg_2989 any = f__2; if linked_2987 == nil { arg_2985 = ifn_2988.Invoke_O__O(arg_2989) } else { arg_2985 = linked_2987.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2986, arg_2989) }; if linked_2983 == nil { n__3 = ifn_2984.Invoke_O__O(arg_2985) } else { n__3 = linked_2983.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_2982, arg_2985) }; var tmp4 any; var root_2990 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_2991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2990, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2992 lang.IFn
																if linked_2991 == nil { ifn_2992 = lang.IFn_Cast(root_2990) } else { ifn_2992 = nil }; var arg_2993 any = t.F_ai_names; var arg_2994 any = n__3; if linked_2991 == nil { tmp4 = ifn_2992.Invoke_O_O__O(arg_2993, arg_2994) } else { tmp4 = linked_2991.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2990, arg_2993, arg_2994) }
//line :366:1
	if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_2995 any = A_arbace_cpp_inline_A_const_186.GetRawRoot__O(); var linked_2996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2995, A_arbace_cpp_inline_discardable_QMARK__A_fn_class); var ifn_2997 lang.IFn
		if linked_2996 == nil { ifn_2997 = lang.IFn_Cast(root_2995) } else { ifn_2997 = nil }; var arg_2998 any = f__2; if linked_2996 == nil { tmp5 = ifn_2997.Invoke_O__O(arg_2998) } else { tmp5 = linked_2996.(*A_arbace_cpp_inline_discardable_QMARK__A).Invoke_O_O__O(root_2995, arg_2998) }
//line :366:1
		if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_2999 any = A_arbace_cpp_inline_A_const_52.GetRawRoot__O(); var linked_3000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2999, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3001 lang.IFn
			if linked_3000 == nil { ifn_3001 = lang.IFn_Cast(root_2999) } else { ifn_3001 = nil }; var arg_3002 any; var root_3003 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3005 lang.IFn; if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any = t.F_used; var arg_3007 any = n__3; if linked_3004 == nil { arg_3002 = ifn_3005.Invoke_O_O__O(arg_3006, arg_3007) } else { arg_3002 = linked_3004.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3003, arg_3006, arg_3007) }; if linked_3000 == nil { tmp6 = ifn_3001.Invoke_O__O(arg_3002) } else { tmp6 = linked_3000.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2999, arg_3002) }
//line :366:1
			if jrt.J2g_Truth(tmp6) { var root_3008 any = A_arbace_cpp_inline_A_const_42.GetRawRoot__O(); var linked_3009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3008, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3010 lang.IFn; if linked_3009 == nil { ifn_3010 = lang.IFn_Cast(root_3008) } else { ifn_3010 = nil }; var arg_3011 any = t.F_b__113000320; var arg_3012 any = n__3; if linked_3009 == nil { ifn_3010.Invoke_O_O__O(arg_3011, arg_3012) } else { linked_3009.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3008, arg_3011, arg_3012) }; i__113000319__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000319__1); continue L1 } else { i__113000319__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000319__1); continue L1 } } else { i__113000319__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000319__1); continue L1 } } else { i__113000319__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000319__1); continue L1 } } else { i__113000319__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__113000319__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_cpp_inline_always_inline_fn__113000327_A_New_O(p0 any) *A_arbace_cpp_inline_always_inline_fn__113000327_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_always_inline_fn__113000327_A{}; t.Ctor_O(p0); return t }
//line :371:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000327_A) Ctor_O(c__dead any) { t.F_dead = c__dead }
//line :371:1
func (t *A_arbace_cpp_inline_always_inline_fn__113000327_A) Invoke_O_O__O(self, p1__113000248_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_inline_A_const_187); var tmp2 any; var root_3126 any = A_arbace_cpp_inline_A_const_41.GetRawRoot__O(); var linked_3127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3126, A_arbace_cpp_inline_head_A_fn_class); var ifn_3128 lang.IFn; if linked_3127 == nil { ifn_3128 = lang.IFn_Cast(root_3126) } else { ifn_3128 = nil }; var arg_3129 any = p1__113000248_SHARP___1; if linked_3127 == nil { tmp2 = ifn_3128.Invoke_O__O(arg_3129) } else { tmp2 = linked_3127.(*A_arbace_cpp_inline_head_A).Invoke_O_O__O(root_3126, arg_3129) }; and__1927000168__auto____2 = tmp1.Invoke_O__O(tmp2); if jrt.J2g_Truth(and__1927000168__auto____2) { var root_3113 any = A_arbace_cpp_inline_A_const_56.GetRawRoot__O(); var linked_3114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3113, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3115 lang.IFn; if linked_3114 == nil { ifn_3115 = lang.IFn_Cast(root_3113) } else { ifn_3115 = nil }; var arg_3116 any = t.F_dead; var arg_3117 any; var root_3118 any = A_arbace_cpp_inline_A_const_51.GetRawRoot__O(); var linked_3119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3118, A_arbace_cpp_inline_gname_A_fn_class); var ifn_3120 lang.IFn; if linked_3119 == nil { ifn_3120 = lang.IFn_Cast(root_3118) } else { ifn_3120 = nil }; var arg_3121 any; var root_3122 any = A_arbace_cpp_inline_A_const_16.GetRawRoot__O(); var linked_3123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3122, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3124 lang.IFn; if linked_3123 == nil { ifn_3124 = lang.IFn_Cast(root_3122) } else { ifn_3124 = nil }; var arg_3125 any = p1__113000248_SHARP___1; if linked_3123 == nil { arg_3121 = ifn_3124.Invoke_O__O(arg_3125) } else { arg_3121 = linked_3123.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3122, arg_3125) }; if linked_3119 == nil { arg_3117 = ifn_3120.Invoke_O__O(arg_3121) } else { arg_3117 = linked_3119.(*A_arbace_cpp_inline_gname_A).Invoke_O_O__O(root_3118, arg_3121) }; if linked_3114 == nil { return ifn_3115.Invoke_O_O__O(arg_3116, arg_3117) } else { return linked_3114.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3113, arg_3116, arg_3117) } } else { return and__1927000168__auto____2 } }






















































































































































































type A_arbace_cpp_inline_A struct{ jrt.Object }

var A_arbace_cpp_inline_A_const_pool *jrt.RefArray

var A_arbace_cpp_inline_A_const_0 *lang.Var

var A_arbace_cpp_inline_A_const_1 any

var A_arbace_cpp_inline_A_const_2 *lang.Var

var A_arbace_cpp_inline_A_const_3 any

var A_arbace_cpp_inline_A_const_4 *lang.Var

var A_arbace_cpp_inline_A_const_5 *lang.Var

var A_arbace_cpp_inline_A_const_6 *lang.Var

var A_arbace_cpp_inline_A_const_7 *lang.Var

var A_arbace_cpp_inline_A_const_8 any

var A_arbace_cpp_inline_A_const_9 *lang.Var

var A_arbace_cpp_inline_A_const_10 *lang.Var

var A_arbace_cpp_inline_A_const_11 *lang.Var

var A_arbace_cpp_inline_A_const_12 *lang.Var

var A_arbace_cpp_inline_A_const_13 any

var A_arbace_cpp_inline_A_const_14 *lang.Var

var A_arbace_cpp_inline_A_const_15 *lang.Var

var A_arbace_cpp_inline_A_const_16 *lang.Var

var A_arbace_cpp_inline_A_const_17 *lang.Keyword

var A_arbace_cpp_inline_A_const_18 *lang.Var

var A_arbace_cpp_inline_A_const_19 *lang.Var

var A_arbace_cpp_inline_A_const_20 *lang.Var

var A_arbace_cpp_inline_A_const_21 *lang.Var

var A_arbace_cpp_inline_A_const_22 *lang.Var

var A_arbace_cpp_inline_A_const_23 *lang.Var

var A_arbace_cpp_inline_A_const_24 *lang.Var

var A_arbace_cpp_inline_A_const_25 *lang.Var

var A_arbace_cpp_inline_A_const_26 *lang.Var

var A_arbace_cpp_inline_A_const_27 *lang.Var

var A_arbace_cpp_inline_A_const_28 *lang.Keyword

var A_arbace_cpp_inline_A_const_29 *lang.Var

var A_arbace_cpp_inline_A_const_30 *lang.Var

var A_arbace_cpp_inline_A_const_31 any

var A_arbace_cpp_inline_A_const_32 *lang.Var

var A_arbace_cpp_inline_A_const_33 any

var A_arbace_cpp_inline_A_const_34 any

var A_arbace_cpp_inline_A_const_35 *lang.Var

var A_arbace_cpp_inline_A_const_36 *lang.Var

var A_arbace_cpp_inline_A_const_37 *lang.Var

var A_arbace_cpp_inline_A_const_38 *lang.Var

var A_arbace_cpp_inline_A_const_39 *lang.Var

var A_arbace_cpp_inline_A_const_40 any

var A_arbace_cpp_inline_A_const_41 *lang.Var

var A_arbace_cpp_inline_A_const_42 *lang.Var

var A_arbace_cpp_inline_A_const_43 *lang.Var

var A_arbace_cpp_inline_A_const_44 *lang.Var

var A_arbace_cpp_inline_A_const_45 *lang.Var

var A_arbace_cpp_inline_A_const_46 any

var A_arbace_cpp_inline_A_const_47 *lang.Var

var A_arbace_cpp_inline_A_const_48 *lang.Var

var A_arbace_cpp_inline_A_const_49 any

var A_arbace_cpp_inline_A_const_50 *lang.Var

var A_arbace_cpp_inline_A_const_51 *lang.Var

var A_arbace_cpp_inline_A_const_52 *lang.Var

var A_arbace_cpp_inline_A_const_53 any

var A_arbace_cpp_inline_A_const_54 *lang.Var

var A_arbace_cpp_inline_A_const_55 *lang.Var

var A_arbace_cpp_inline_A_const_56 *lang.Var

var A_arbace_cpp_inline_A_const_57 *lang.Var

var A_arbace_cpp_inline_A_const_58 *lang.Var

var A_arbace_cpp_inline_A_const_59 *lang.Var

var A_arbace_cpp_inline_A_const_60 *lang.Var

var A_arbace_cpp_inline_A_const_61 *lang.Var

var A_arbace_cpp_inline_A_const_62 any

var A_arbace_cpp_inline_A_const_63 *lang.Var

var A_arbace_cpp_inline_A_const_64 *lang.Keyword

var A_arbace_cpp_inline_A_const_65 *lang.Keyword

var A_arbace_cpp_inline_A_const_66 any

var A_arbace_cpp_inline_A_const_67 *lang.Var

var A_arbace_cpp_inline_A_const_68 *lang.Var

var A_arbace_cpp_inline_A_const_69 *lang.Var

var A_arbace_cpp_inline_A_const_70 *lang.Var

var A_arbace_cpp_inline_A_const_71 *lang.Var

var A_arbace_cpp_inline_A_const_72 any

var A_arbace_cpp_inline_A_const_73 *lang.Var

var A_arbace_cpp_inline_A_const_74 *lang.Var

var A_arbace_cpp_inline_A_const_75 *lang.Var

var A_arbace_cpp_inline_A_const_76 *lang.Keyword

var A_arbace_cpp_inline_A_const_77 *lang.Var

var A_arbace_cpp_inline_A_const_78 *lang.Keyword

var A_arbace_cpp_inline_A_const_79 any

var A_arbace_cpp_inline_A_const_80 any

var A_arbace_cpp_inline_A_const_81 any

var A_arbace_cpp_inline_A_const_82 any

var A_arbace_cpp_inline_A_const_83 any

var A_arbace_cpp_inline_A_const_84 any

var A_arbace_cpp_inline_A_const_85 any

var A_arbace_cpp_inline_A_const_86 any

var A_arbace_cpp_inline_A_const_87 any

var A_arbace_cpp_inline_A_const_88 any

var A_arbace_cpp_inline_A_const_89 *lang.Var

var A_arbace_cpp_inline_A_const_90 *lang.Var

var A_arbace_cpp_inline_A_const_91 *lang.Var

var A_arbace_cpp_inline_A_const_92 any

var A_arbace_cpp_inline_A_const_93 *lang.Var

var A_arbace_cpp_inline_A_const_94 any

var A_arbace_cpp_inline_A_const_95 *lang.Var

var A_arbace_cpp_inline_A_const_96 any

var A_arbace_cpp_inline_A_const_97 *lang.Var

var A_arbace_cpp_inline_A_const_98 any

var A_arbace_cpp_inline_A_const_99 any

var A_arbace_cpp_inline_A_const_100 any

var A_arbace_cpp_inline_A_const_101 *lang.Var

var A_arbace_cpp_inline_A_const_102 any

var A_arbace_cpp_inline_A_const_103 *lang.Keyword

var A_arbace_cpp_inline_A_const_104 *lang.Var

var A_arbace_cpp_inline_A_const_105 any

var A_arbace_cpp_inline_A_const_106 *lang.Var

var A_arbace_cpp_inline_A_const_107 any

var A_arbace_cpp_inline_A_const_108 *lang.Var

var A_arbace_cpp_inline_A_const_109 any

var A_arbace_cpp_inline_A_const_110 *lang.Keyword

var A_arbace_cpp_inline_A_const_111 *lang.Var

var A_arbace_cpp_inline_A_const_112 *lang.Var

var A_arbace_cpp_inline_A_const_113 *lang.Keyword

var A_arbace_cpp_inline_A_const_114 any

var A_arbace_cpp_inline_A_const_115 any

var A_arbace_cpp_inline_A_const_116 any

var A_arbace_cpp_inline_A_const_117 *lang.Keyword

var A_arbace_cpp_inline_A_const_118 any

var A_arbace_cpp_inline_A_const_119 *lang.Keyword

var A_arbace_cpp_inline_A_const_120 *lang.Keyword

var A_arbace_cpp_inline_A_const_121 *lang.Keyword

var A_arbace_cpp_inline_A_const_122 *lang.Keyword

var A_arbace_cpp_inline_A_const_123 *lang.Keyword

var A_arbace_cpp_inline_A_const_124 *lang.Var

var A_arbace_cpp_inline_A_const_125 *lang.Var

var A_arbace_cpp_inline_A_const_126 any

var A_arbace_cpp_inline_A_const_127 *lang.Keyword

var A_arbace_cpp_inline_A_const_128 any

var A_arbace_cpp_inline_A_const_129 any

var A_arbace_cpp_inline_A_const_130 any

var A_arbace_cpp_inline_A_const_131 any

var A_arbace_cpp_inline_A_const_132 any

var A_arbace_cpp_inline_A_const_133 *lang.Var

var A_arbace_cpp_inline_A_const_134 *lang.Var

var A_arbace_cpp_inline_A_const_135 any

var A_arbace_cpp_inline_A_const_136 any

var A_arbace_cpp_inline_A_const_137 any

var A_arbace_cpp_inline_A_const_138 any

var A_arbace_cpp_inline_A_const_139 any

var A_arbace_cpp_inline_A_const_140 any

var A_arbace_cpp_inline_A_const_141 any

var A_arbace_cpp_inline_A_const_142 any

var A_arbace_cpp_inline_A_const_143 any

var A_arbace_cpp_inline_A_const_144 any

var A_arbace_cpp_inline_A_const_145 any

var A_arbace_cpp_inline_A_const_146 any

var A_arbace_cpp_inline_A_const_147 *lang.Var

var A_arbace_cpp_inline_A_const_148 *lang.Var

var A_arbace_cpp_inline_A_const_149 *lang.Var

var A_arbace_cpp_inline_A_const_150 *lang.Var

var A_arbace_cpp_inline_A_const_151 any

var A_arbace_cpp_inline_A_const_152 any

var A_arbace_cpp_inline_A_const_153 any

var A_arbace_cpp_inline_A_const_154 any

var A_arbace_cpp_inline_A_const_155 any

var A_arbace_cpp_inline_A_const_156 any

var A_arbace_cpp_inline_A_const_157 any

var A_arbace_cpp_inline_A_const_158 *lang.Var

var A_arbace_cpp_inline_A_const_159 any

var A_arbace_cpp_inline_A_const_160 *lang.Var

var A_arbace_cpp_inline_A_const_161 *lang.Var

var A_arbace_cpp_inline_A_const_162 *lang.Var

var A_arbace_cpp_inline_A_const_163 *lang.Var

var A_arbace_cpp_inline_A_const_164 *lang.Var

var A_arbace_cpp_inline_A_const_165 any

var A_arbace_cpp_inline_A_const_166 any

var A_arbace_cpp_inline_A_const_167 *lang.Keyword

var A_arbace_cpp_inline_A_const_168 *lang.Var

var A_arbace_cpp_inline_A_const_169 *lang.Var

var A_arbace_cpp_inline_A_const_170 any

var A_arbace_cpp_inline_A_const_171 *lang.Keyword

var A_arbace_cpp_inline_A_const_172 *lang.Var

var A_arbace_cpp_inline_A_const_173 any

var A_arbace_cpp_inline_A_const_174 any

var A_arbace_cpp_inline_A_const_175 any

var A_arbace_cpp_inline_A_const_176 any

var A_arbace_cpp_inline_A_const_177 any

var A_arbace_cpp_inline_A_const_178 *lang.Var

var A_arbace_cpp_inline_A_const_179 *lang.Var

var A_arbace_cpp_inline_A_const_180 any

var A_arbace_cpp_inline_A_const_181 *lang.Var

var A_arbace_cpp_inline_A_const_182 any

var A_arbace_cpp_inline_A_const_183 *lang.Var

var A_arbace_cpp_inline_A_const_184 any

var A_arbace_cpp_inline_A_const_185 any

var A_arbace_cpp_inline_A_const_186 *lang.Var

var A_arbace_cpp_inline_A_const_187 any

var A_arbace_cpp_inline_A_init jrt.ClassInit

func A_arbace_cpp_inline_A_Init() { if !A_arbace_cpp_inline_A_init.Done() { A_arbace_cpp_inline_A_init.Run(A_arbace_cpp_inline_A_clinit) } }

func A_arbace_cpp_inline_A_clinit() { A_arbace_cpp_inline_A_clinit_p0(); A_arbace_cpp_inline_A_clinit_p1(); A_arbace_cpp_inline_A_clinit_p2(); A_arbace_cpp_inline_A_clinit_p3(); A_arbace_cpp_inline_A_clinit_p4(); A_arbace_cpp_inline_A_clinit_p5(); A_arbace_cpp_inline_A_clinit_p6(); A_arbace_cpp_inline_A_clinit_p7(); A_arbace_cpp_inline_A_clinit_p8(); A_arbace_cpp_inline_A_clinit_p9(); A_arbace_cpp_inline_A_clinit_p10(); A_arbace_cpp_inline_A_clinit_p11(); A_arbace_cpp_inline_A_clinit_p12(); A_arbace_cpp_inline_A_clinit_p13(); A_arbace_cpp_inline_A_clinit_p14() }

func A_arbace_cpp_inline_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_inline_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 239); A_arbace_cpp_inline_A_const_0 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[51]); A_arbace_cpp_inline_A_const_1 = A_arbace_cpp_inline_A_const_pool.A[52]; A_arbace_cpp_inline_A_const_2 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[53]); A_arbace_cpp_inline_A_const_3 = A_arbace_cpp_inline_A_const_pool.A[54]; A_arbace_cpp_inline_A_const_4 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[55]); A_arbace_cpp_inline_A_const_5 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[56]); A_arbace_cpp_inline_A_const_6 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[57]); A_arbace_cpp_inline_A_const_7 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[58]); A_arbace_cpp_inline_A_const_8 = A_arbace_cpp_inline_A_const_pool.A[59]; A_arbace_cpp_inline_A_const_9 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[60]); A_arbace_cpp_inline_A_const_10 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[61]); A_arbace_cpp_inline_A_const_11 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[62]) }

func A_arbace_cpp_inline_A_clinit_p1() { A_arbace_cpp_inline_A_const_12 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[63]); A_arbace_cpp_inline_A_const_13 = A_arbace_cpp_inline_A_const_pool.A[64]; A_arbace_cpp_inline_A_const_14 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[65]); A_arbace_cpp_inline_A_const_15 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[66]); A_arbace_cpp_inline_A_const_16 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[67]); A_arbace_cpp_inline_A_const_17 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[68]); A_arbace_cpp_inline_A_const_18 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[69]); A_arbace_cpp_inline_A_const_19 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[70]); A_arbace_cpp_inline_A_const_20 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[71]); A_arbace_cpp_inline_A_const_21 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[72]); A_arbace_cpp_inline_A_const_22 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[73]); A_arbace_cpp_inline_A_const_23 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[74]) }

func A_arbace_cpp_inline_A_clinit_p2() { A_arbace_cpp_inline_A_const_24 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[75]); A_arbace_cpp_inline_A_const_25 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[76]); A_arbace_cpp_inline_A_const_26 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[77]); A_arbace_cpp_inline_A_const_27 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[78]); A_arbace_cpp_inline_A_const_28 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[79]); A_arbace_cpp_inline_A_const_29 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[80]); A_arbace_cpp_inline_A_const_30 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[81]); A_arbace_cpp_inline_A_const_31 = A_arbace_cpp_inline_A_const_pool.A[82]; A_arbace_cpp_inline_A_const_32 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[83]); A_arbace_cpp_inline_A_const_33 = A_arbace_cpp_inline_A_const_pool.A[84]; A_arbace_cpp_inline_A_const_34 = A_arbace_cpp_inline_A_const_pool.A[85]; A_arbace_cpp_inline_A_const_35 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[86]) }

func A_arbace_cpp_inline_A_clinit_p3() { A_arbace_cpp_inline_A_const_36 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[87]); A_arbace_cpp_inline_A_const_37 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[88]); A_arbace_cpp_inline_A_const_38 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[89]); A_arbace_cpp_inline_A_const_39 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[90]); A_arbace_cpp_inline_A_const_40 = A_arbace_cpp_inline_A_const_pool.A[91]; A_arbace_cpp_inline_A_const_41 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[92]); A_arbace_cpp_inline_A_const_42 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[93]); A_arbace_cpp_inline_A_const_43 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[94]); A_arbace_cpp_inline_A_const_44 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[95]); A_arbace_cpp_inline_A_const_45 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[96]); A_arbace_cpp_inline_A_const_46 = A_arbace_cpp_inline_A_const_pool.A[97]; A_arbace_cpp_inline_A_const_47 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[98]) }

func A_arbace_cpp_inline_A_clinit_p4() { A_arbace_cpp_inline_A_const_48 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[99]); A_arbace_cpp_inline_A_const_49 = A_arbace_cpp_inline_A_const_pool.A[100]; A_arbace_cpp_inline_A_const_50 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[101]); A_arbace_cpp_inline_A_const_51 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[102]); A_arbace_cpp_inline_A_const_52 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[103]); A_arbace_cpp_inline_A_const_53 = A_arbace_cpp_inline_A_const_pool.A[104]; A_arbace_cpp_inline_A_const_54 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[105]); A_arbace_cpp_inline_A_const_55 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[106]); A_arbace_cpp_inline_A_const_56 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[107]); A_arbace_cpp_inline_A_const_57 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[108]); A_arbace_cpp_inline_A_const_58 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[109]); A_arbace_cpp_inline_A_const_59 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[110]) }

func A_arbace_cpp_inline_A_clinit_p5() { A_arbace_cpp_inline_A_const_60 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[111]); A_arbace_cpp_inline_A_const_61 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[112]); A_arbace_cpp_inline_A_const_62 = A_arbace_cpp_inline_A_const_pool.A[113]; A_arbace_cpp_inline_A_const_63 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[114]); A_arbace_cpp_inline_A_const_64 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[115]); A_arbace_cpp_inline_A_const_65 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[116]); A_arbace_cpp_inline_A_const_66 = A_arbace_cpp_inline_A_const_pool.A[117]; A_arbace_cpp_inline_A_const_67 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[118]); A_arbace_cpp_inline_A_const_68 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[119]); A_arbace_cpp_inline_A_const_69 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[120]); A_arbace_cpp_inline_A_const_70 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[121]); A_arbace_cpp_inline_A_const_71 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[122]) }

func A_arbace_cpp_inline_A_clinit_p6() { A_arbace_cpp_inline_A_const_72 = A_arbace_cpp_inline_A_const_pool.A[123]; A_arbace_cpp_inline_A_const_73 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[124]); A_arbace_cpp_inline_A_const_74 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[125]); A_arbace_cpp_inline_A_const_75 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[126]); A_arbace_cpp_inline_A_const_76 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[127]); A_arbace_cpp_inline_A_const_77 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[128]); A_arbace_cpp_inline_A_const_78 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[129]); A_arbace_cpp_inline_A_const_79 = A_arbace_cpp_inline_A_const_pool.A[130]; A_arbace_cpp_inline_A_const_80 = A_arbace_cpp_inline_A_const_pool.A[131]; A_arbace_cpp_inline_A_const_81 = A_arbace_cpp_inline_A_const_pool.A[132]; A_arbace_cpp_inline_A_const_82 = A_arbace_cpp_inline_A_const_pool.A[133]; A_arbace_cpp_inline_A_const_83 = A_arbace_cpp_inline_A_const_pool.A[134]; A_arbace_cpp_inline_A_const_84 = A_arbace_cpp_inline_A_const_pool.A[135]; A_arbace_cpp_inline_A_const_85 = A_arbace_cpp_inline_A_const_pool.A[136] }

func A_arbace_cpp_inline_A_clinit_p7() { A_arbace_cpp_inline_A_const_86 = A_arbace_cpp_inline_A_const_pool.A[137]; A_arbace_cpp_inline_A_const_87 = A_arbace_cpp_inline_A_const_pool.A[138]; A_arbace_cpp_inline_A_const_88 = A_arbace_cpp_inline_A_const_pool.A[139]; A_arbace_cpp_inline_A_const_89 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[140]); A_arbace_cpp_inline_A_const_90 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[141]); A_arbace_cpp_inline_A_const_91 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[142]); A_arbace_cpp_inline_A_const_92 = A_arbace_cpp_inline_A_const_pool.A[143]; A_arbace_cpp_inline_A_const_93 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[144]); A_arbace_cpp_inline_A_const_94 = A_arbace_cpp_inline_A_const_pool.A[145]; A_arbace_cpp_inline_A_const_95 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[146]); A_arbace_cpp_inline_A_const_96 = A_arbace_cpp_inline_A_const_pool.A[147]; A_arbace_cpp_inline_A_const_97 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[148]); A_arbace_cpp_inline_A_const_98 = A_arbace_cpp_inline_A_const_pool.A[149]; A_arbace_cpp_inline_A_const_99 = A_arbace_cpp_inline_A_const_pool.A[150] }

func A_arbace_cpp_inline_A_clinit_p8() { A_arbace_cpp_inline_A_const_100 = A_arbace_cpp_inline_A_const_pool.A[151]; A_arbace_cpp_inline_A_const_101 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[152]); A_arbace_cpp_inline_A_const_102 = A_arbace_cpp_inline_A_const_pool.A[153]; A_arbace_cpp_inline_A_const_103 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[154]); A_arbace_cpp_inline_A_const_104 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[155]); A_arbace_cpp_inline_A_const_105 = A_arbace_cpp_inline_A_const_pool.A[156]; A_arbace_cpp_inline_A_const_106 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[157]); A_arbace_cpp_inline_A_const_107 = A_arbace_cpp_inline_A_const_pool.A[158]; A_arbace_cpp_inline_A_const_108 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[159]); A_arbace_cpp_inline_A_const_109 = A_arbace_cpp_inline_A_const_pool.A[160]; A_arbace_cpp_inline_A_const_110 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[161]); A_arbace_cpp_inline_A_const_111 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[162]); A_arbace_cpp_inline_A_const_112 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[163]) }

func A_arbace_cpp_inline_A_clinit_p9() { A_arbace_cpp_inline_A_const_113 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[164]); A_arbace_cpp_inline_A_const_114 = A_arbace_cpp_inline_A_const_pool.A[165]; A_arbace_cpp_inline_A_const_115 = A_arbace_cpp_inline_A_const_pool.A[166]; A_arbace_cpp_inline_A_const_116 = A_arbace_cpp_inline_A_const_pool.A[167]; A_arbace_cpp_inline_A_const_117 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[168]); A_arbace_cpp_inline_A_const_118 = A_arbace_cpp_inline_A_const_pool.A[169]; A_arbace_cpp_inline_A_const_119 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[170]); A_arbace_cpp_inline_A_const_120 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[171]); A_arbace_cpp_inline_A_const_121 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[172]); A_arbace_cpp_inline_A_const_122 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[173]); A_arbace_cpp_inline_A_const_123 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[174]); A_arbace_cpp_inline_A_const_124 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[175]); A_arbace_cpp_inline_A_const_125 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[176]) }

func A_arbace_cpp_inline_A_clinit_p10() { A_arbace_cpp_inline_A_const_126 = A_arbace_cpp_inline_A_const_pool.A[177]; A_arbace_cpp_inline_A_const_127 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[178]); A_arbace_cpp_inline_A_const_128 = A_arbace_cpp_inline_A_const_pool.A[179]; A_arbace_cpp_inline_A_const_129 = A_arbace_cpp_inline_A_const_pool.A[180]; A_arbace_cpp_inline_A_const_130 = A_arbace_cpp_inline_A_const_pool.A[181]; A_arbace_cpp_inline_A_const_131 = A_arbace_cpp_inline_A_const_pool.A[182]; A_arbace_cpp_inline_A_const_132 = A_arbace_cpp_inline_A_const_pool.A[183]; A_arbace_cpp_inline_A_const_133 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[184]); A_arbace_cpp_inline_A_const_134 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[185]); A_arbace_cpp_inline_A_const_135 = A_arbace_cpp_inline_A_const_pool.A[186]; A_arbace_cpp_inline_A_const_136 = A_arbace_cpp_inline_A_const_pool.A[187]; A_arbace_cpp_inline_A_const_137 = A_arbace_cpp_inline_A_const_pool.A[188]; A_arbace_cpp_inline_A_const_138 = A_arbace_cpp_inline_A_const_pool.A[189]; A_arbace_cpp_inline_A_const_139 = A_arbace_cpp_inline_A_const_pool.A[190]; A_arbace_cpp_inline_A_const_140 = A_arbace_cpp_inline_A_const_pool.A[191] }

func A_arbace_cpp_inline_A_clinit_p11() { A_arbace_cpp_inline_A_const_141 = A_arbace_cpp_inline_A_const_pool.A[192]; A_arbace_cpp_inline_A_const_142 = A_arbace_cpp_inline_A_const_pool.A[193]; A_arbace_cpp_inline_A_const_143 = A_arbace_cpp_inline_A_const_pool.A[194]; A_arbace_cpp_inline_A_const_144 = A_arbace_cpp_inline_A_const_pool.A[195]; A_arbace_cpp_inline_A_const_145 = A_arbace_cpp_inline_A_const_pool.A[196]; A_arbace_cpp_inline_A_const_146 = A_arbace_cpp_inline_A_const_pool.A[197]; A_arbace_cpp_inline_A_const_147 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[198]); A_arbace_cpp_inline_A_const_148 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[199]); A_arbace_cpp_inline_A_const_149 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[200]); A_arbace_cpp_inline_A_const_150 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[201]); A_arbace_cpp_inline_A_const_151 = A_arbace_cpp_inline_A_const_pool.A[202]; A_arbace_cpp_inline_A_const_152 = A_arbace_cpp_inline_A_const_pool.A[203]; A_arbace_cpp_inline_A_const_153 = A_arbace_cpp_inline_A_const_pool.A[204]; A_arbace_cpp_inline_A_const_154 = A_arbace_cpp_inline_A_const_pool.A[205] }

func A_arbace_cpp_inline_A_clinit_p12() { A_arbace_cpp_inline_A_const_155 = A_arbace_cpp_inline_A_const_pool.A[206]; A_arbace_cpp_inline_A_const_156 = A_arbace_cpp_inline_A_const_pool.A[207]; A_arbace_cpp_inline_A_const_157 = A_arbace_cpp_inline_A_const_pool.A[208]; A_arbace_cpp_inline_A_const_158 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[209]); A_arbace_cpp_inline_A_const_159 = A_arbace_cpp_inline_A_const_pool.A[210]; A_arbace_cpp_inline_A_const_160 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[211]); A_arbace_cpp_inline_A_const_161 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[212]); A_arbace_cpp_inline_A_const_162 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[213]); A_arbace_cpp_inline_A_const_163 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[214]); A_arbace_cpp_inline_A_const_164 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[215]); A_arbace_cpp_inline_A_const_165 = A_arbace_cpp_inline_A_const_pool.A[216]; A_arbace_cpp_inline_A_const_166 = A_arbace_cpp_inline_A_const_pool.A[217]; A_arbace_cpp_inline_A_const_167 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[218]) }

func A_arbace_cpp_inline_A_clinit_p13() { A_arbace_cpp_inline_A_const_168 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[219]); A_arbace_cpp_inline_A_const_169 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[220]); A_arbace_cpp_inline_A_const_170 = A_arbace_cpp_inline_A_const_pool.A[221]; A_arbace_cpp_inline_A_const_171 = lang.Keyword_Cast(A_arbace_cpp_inline_A_const_pool.A[222]); A_arbace_cpp_inline_A_const_172 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[223]); A_arbace_cpp_inline_A_const_173 = A_arbace_cpp_inline_A_const_pool.A[224]; A_arbace_cpp_inline_A_const_174 = A_arbace_cpp_inline_A_const_pool.A[225]; A_arbace_cpp_inline_A_const_175 = A_arbace_cpp_inline_A_const_pool.A[226]; A_arbace_cpp_inline_A_const_176 = A_arbace_cpp_inline_A_const_pool.A[227]; A_arbace_cpp_inline_A_const_177 = A_arbace_cpp_inline_A_const_pool.A[228]; A_arbace_cpp_inline_A_const_178 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[229]); A_arbace_cpp_inline_A_const_179 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[230]); A_arbace_cpp_inline_A_const_180 = A_arbace_cpp_inline_A_const_pool.A[231] }

func A_arbace_cpp_inline_A_clinit_p14() { A_arbace_cpp_inline_A_const_181 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[232]); A_arbace_cpp_inline_A_const_182 = A_arbace_cpp_inline_A_const_pool.A[233]; A_arbace_cpp_inline_A_const_183 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[234]); A_arbace_cpp_inline_A_const_184 = A_arbace_cpp_inline_A_const_pool.A[235]; A_arbace_cpp_inline_A_const_185 = A_arbace_cpp_inline_A_const_pool.A[236]; A_arbace_cpp_inline_A_const_186 = lang.Var_Cast(A_arbace_cpp_inline_A_const_pool.A[237]); A_arbace_cpp_inline_A_const_187 = A_arbace_cpp_inline_A_const_pool.A[238] }

func A_arbace_cpp_inline_A_New() *A_arbace_cpp_inline_A { A_arbace_cpp_inline_A_Init(); t := &A_arbace_cpp_inline_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_inline_A) Ctor() {}

func (t *A_arbace_cpp_inline_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_inline_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_inline_A_class }

func (t *A_arbace_cpp_inline_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_inline_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_inline_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_inline_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_inline_A); return ok }

func A_arbace_cpp_inline_A_Cast(x any) *A_arbace_cpp_inline_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_inline_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_inline_A_class)) }; return v }



type A_arbace_cpp_inline_always_inline_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_always_inline_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_finish__113000285_A struct{ j2g_header uint64; F_nounwind_fns, F_ai_names, F_busy, F_defines, F_done any }

var A_arbace_cpp_inline_always_inline_finish__113000285_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_always_inline_finish__113000285_fn__113000286_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A struct{ j2g_header uint64; F_ai_names, F_finish, F_busy any }

var A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A struct{ j2g_header uint64; F_s__113000289, F_ai_names, F_finish, F_busy, F_iter__113000288 any }

var A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A struct{ j2g_header uint64; F_b__113000291, F_ai_names, F_finish, F_busy any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_inline_always_inline_finish__113000285_iter__113000288__113000292_fn__113000293_fn__113000294_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_fn__113000299_A struct{ j2g_header uint64; F_nounwind_fns, F_finish, F_ai_names any }

var A_arbace_cpp_inline_always_inline_fn__113000299_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_always_inline_fn__113000299_fn__113000300_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A struct{ j2g_header uint64; F_finish, F_ai_names any }

var A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A struct{ j2g_header uint64; F_iter__113000302, F_s__113000303, F_finish, F_ai_names any }

var A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A struct{ j2g_header uint64; F_finish, F_ai_names, F_b__113000305 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_inline_always_inline_fn__113000299_iter__113000302__113000306_fn__113000307_fn__113000308_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_fn__113000313_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_always_inline_fn__113000313_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A struct{ j2g_header uint64; F_own any }

var A_arbace_cpp_inline_always_inline_fn__113000313_fn__113000314_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_fn__113000327_A struct{ j2g_header uint64; F_dead any }

var A_arbace_cpp_inline_always_inline_fn__113000327_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_always_inline_iter__113000249__113000253_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A struct{ j2g_header uint64; F_iter__113000249, F_s__113000250 any }

var A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A struct{ j2g_header uint64; F_b__113000252 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_inline_always_inline_iter__113000249__113000253_fn__113000254_fn__113000255_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_always_inline_iter__113000259__113000263_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A struct{ j2g_header uint64; F_iter__113000259, F_s__113000260 any }

var A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A struct{ j2g_header uint64; F_b__113000262 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_inline_always_inline_iter__113000259__113000263_fn__113000264_fn__113000265_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_always_inline_iter__113000275__113000279_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A struct{ j2g_header uint64; F_s__113000276, F_iter__113000275 any }

var A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A struct{ j2g_header uint64; F_b__113000278 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_inline_always_inline_iter__113000275__113000279_fn__113000280_fn__113000281_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A struct{ j2g_header uint64; F_ai_names, F_used any }

var A_arbace_cpp_inline_always_inline_iter__113000317__113000321_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A struct{ j2g_header uint64; F_iter__113000317, F_s__113000318, F_ai_names, F_used any }

var A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_A_fn_class *jrt.Class



type A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A struct{ j2g_header uint64; F_b__113000320, F_ai_names, F_used any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_inline_always_inline_iter__113000317__113000321_fn__113000322_fn__113000323_A_fn_class *jrt.Class



type A_arbace_cpp_inline_append_clauses_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_append_clauses_A_fn_class *jrt.Class



type A_arbace_cpp_inline_attrs_have_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_attrs_have_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_inline_bv_size_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_bv_size_A_fn_class *jrt.Class



type A_arbace_cpp_inline_calls_in_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_calls_in_A_fn_class *jrt.Class



type A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_calls_in_iter__113000031__113000037_A_fn_class *jrt.Class



type A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A struct{ j2g_header uint64; F_iter__113000031, F_s__113000032 any }

var A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_A_fn_class *jrt.Class



type A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_A_fn_class *jrt.Class



type A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A struct{ j2g_header uint64; F_s__113000034, F_iter__113000033 any }

var A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_A_fn_class *jrt.Class



type A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A struct{ j2g_header uint64; F_b__113000036 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_cpp_inline_calls_in_iter__113000031__113000037_fn__113000038_iter__113000033__113000039_fn__113000040_fn__113000041_A_fn_class *jrt.Class



type A_arbace_cpp_inline_define_opts_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_define_opts_A_fn_class *jrt.Class



type A_arbace_cpp_inline_discardable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_discardable_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_inline_eval113000004_A struct{ jrt.Object }

func A_arbace_cpp_inline_eval113000004_A_New() *A_arbace_cpp_inline_eval113000004_A { t := &A_arbace_cpp_inline_eval113000004_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_inline_eval113000004_A) Ctor() {}

func (t *A_arbace_cpp_inline_eval113000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_inline_eval113000004_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_inline_eval113000004_A_class }

func (t *A_arbace_cpp_inline_eval113000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_inline_eval113000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_inline_eval113000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_inline_eval113000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_inline_eval113000004_A); return ok }

func A_arbace_cpp_inline_eval113000004_A_Cast(x any) *A_arbace_cpp_inline_eval113000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_inline_eval113000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_inline_eval113000004_A_class)) }; return v }



type A_arbace_cpp_inline_eval113000004_loading__1927001464__auto____113000005_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_eval113000004_loading__1927001464__auto____113000005_A_fn_class *jrt.Class



type A_arbace_cpp_inline_eval113000008_A struct{ jrt.Object }

func A_arbace_cpp_inline_eval113000008_A_New() *A_arbace_cpp_inline_eval113000008_A { t := &A_arbace_cpp_inline_eval113000008_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_inline_eval113000008_A) Ctor() {}

func (t *A_arbace_cpp_inline_eval113000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_inline_eval113000008_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_inline_eval113000008_A_class }

func (t *A_arbace_cpp_inline_eval113000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_inline_eval113000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_inline_eval113000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_inline_eval113000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_inline_eval113000008_A); return ok }

func A_arbace_cpp_inline_eval113000008_A_Cast(x any) *A_arbace_cpp_inline_eval113000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_inline_eval113000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_inline_eval113000008_A_class)) }; return v }



type A_arbace_cpp_inline_eval113000008_fn__113000009_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_eval113000008_fn__113000009_A_fn_class *jrt.Class



type A_arbace_cpp_inline_gname_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_gname_A_fn_class *jrt.Class



type A_arbace_cpp_inline_head_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_head_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_into_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_final__113000176_A struct{ j2g_header uint64; F_splits any }

var A_arbace_cpp_inline_inline_into_final__113000176_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000132_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_into_fn__113000132_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000151_A struct{ j2g_header uint64; F_d, F_ai any }

var A_arbace_cpp_inline_inline_into_fn__113000151_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000167_A struct{ j2g_header uint64; F_d, F_ai any }

var A_arbace_cpp_inline_inline_into_fn__113000167_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000178_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_into_fn__113000178_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000185_A struct{ j2g_header uint64; F_final any }

var A_arbace_cpp_inline_inline_into_fn__113000185_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A struct{ j2g_header uint64; F_final any }

var A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A struct{ j2g_header uint64; F_final any }

var A_arbace_cpp_inline_inline_into_fn__113000185_fn__113000189_fn__113000194_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000202_A struct{ j2g_header uint64; F_lp_of, F_outer_pads any }

var A_arbace_cpp_inline_inline_into_fn__113000202_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A struct{ j2g_header uint64; F_lp_of, F_u any }

var A_arbace_cpp_inline_inline_into_fn__113000202_fn__113000206_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000210_A struct{ j2g_header uint64; F_final any }

var A_arbace_cpp_inline_inline_into_fn__113000210_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A struct{ j2g_header uint64; F_final, F_u, F_body, F_rs any }

var A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000225_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A struct{ j2g_header uint64; F_final any }

var A_arbace_cpp_inline_inline_into_fn__113000210_fn__113000215_fn__113000228_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_fn__113000236_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_into_fn__113000236_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_lp_of__113000180_A struct{ j2g_header uint64; F_by_label any }

var A_arbace_cpp_inline_inline_into_lp_of__113000180_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_into_lp_of__113000180_fn__113000181_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_site_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_cl__113000082_A struct{ j2g_header uint64; F_entry_label, F_rn any }

var A_arbace_cpp_inline_inline_site_cl__113000082_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000076_A struct{ j2g_header uint64; F_byvals, F_rn, F_copies any }

var A_arbace_cpp_inline_inline_site_fn__113000076_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000077_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_site_fn__113000076_fn__113000079_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000084_A struct{ j2g_header uint64; F_entry_label, F_cl, F_rn, F_amap any }

var A_arbace_cpp_inline_inline_site_fn__113000084_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000089_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_site_fn__113000089_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000091_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_site_fn__113000091_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000094_A struct{ j2g_header uint64; F_rets, F_after any }

var A_arbace_cpp_inline_inline_site_fn__113000094_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000100_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_site_fn__113000100_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000106_A struct{ j2g_header uint64; F_nounwind_fns, F_splits, F_unwind, F_resumes any }

var A_arbace_cpp_inline_inline_site_fn__113000106_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000112_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_site_fn__113000112_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inline_site_fn__113000112_fn__113000116_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inline_site_rn__113000074_A struct{ j2g_header uint64; F_sfx any }

var A_arbace_cpp_inline_inline_site_rn__113000074_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inst_def_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inst_def_A_fn_class *jrt.Class



type A_arbace_cpp_inline_inst_op_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_inst_op_A_fn_class *jrt.Class



type A_arbace_cpp_inline_local_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_local_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_inline_may_throw_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_may_throw_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_inline_mentions_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_mentions_A_fn_class *jrt.Class



type A_arbace_cpp_inline_mentions_fn__113000243_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_mentions_fn__113000243_A_fn_class *jrt.Class



type A_arbace_cpp_inline_opts_of_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_opts_of_A_fn_class *jrt.Class



type A_arbace_cpp_inline_remap_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_remap_A_fn_class *jrt.Class



type A_arbace_cpp_inline_remap_fn__113000057_A struct{ j2g_header uint64; F_m, F_rn any }

var A_arbace_cpp_inline_remap_fn__113000057_A_fn_class *jrt.Class



type A_arbace_cpp_inline_remap_fn__113000059_A struct{ j2g_header uint64; F_m, F_rn any }

var A_arbace_cpp_inline_remap_fn__113000059_A_fn_class *jrt.Class



type A_arbace_cpp_inline_set_opt_A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_set_opt_A_fn_class *jrt.Class



type A_arbace_cpp_inline_set_opt_fn__113000024_A struct{ j2g_header uint64; F_k any }

var A_arbace_cpp_inline_set_opt_fn__113000024_A_fn_class *jrt.Class



type A_arbace_cpp_inline_viable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_cpp_inline_viable_QMARK__A_fn_class *jrt.Class



type A_arbace_cpp_inline_viable_QMARK__fn__113000052_A struct{ j2g_header uint64; F_n any }

var A_arbace_cpp_inline_viable_QMARK__fn__113000052_A_fn_class *jrt.Class
