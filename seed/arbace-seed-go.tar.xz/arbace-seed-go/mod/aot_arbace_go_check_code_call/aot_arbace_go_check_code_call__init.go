//line aot_arbace_go_check_code_call__init.ae:1
package aot_arbace_go_check_code_call

import (
	"arbace/aot_arbace_go_check_code"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_code_call__init_A_Unit0__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_code_call__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_code_call__init_A_const_1) }



func A_arbace_go_check_code_call__init_A_Unit1__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_2; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_obj_node_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_obj_node_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); aot_arbace_go_check_code.A_arbace_go_check_code_obj_node_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_3)); return A_arbace_go_check_code_call__init_A_const_2 }
//line :5:1
func A_arbace_go_check_code_call__init_A_Load__O() any { A_arbace_go_check_code_call__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_code_call__init_A_Unit0__O(); A_arbace_go_check_code_call__init_A_Unit1__O(); A_arbace_go_check_code_call__init_A_Unit2__O(); A_arbace_go_check_code_call__init_A_Unit3__O(); A_arbace_go_check_code_call__init_A_Unit4__O(); A_arbace_go_check_code_call__init_A_Unit5__O(); A_arbace_go_check_code_call__init_A_Unit6__O(); A_arbace_go_check_code_call__init_A_Unit7__O(); A_arbace_go_check_code_call__init_A_Unit8__O(); A_arbace_go_check_code_call__init_A_Unit9__O(); A_arbace_go_check_code_call__init_A_Unit10__O(); A_arbace_go_check_code_call__init_A_Unit11__O(); A_arbace_go_check_code_call__init_A_Unit12__O(); A_arbace_go_check_code_call__init_A_Unit13__O(); A_arbace_go_check_code_call__init_A_Unit14__O(); A_arbace_go_check_code_call__init_A_Unit15__O(); A_arbace_go_check_code_call__init_A_Unit16__O(); A_arbace_go_check_code_call__init_A_Unit17__O(); A_arbace_go_check_code_call__init_A_Unit18__O(); A_arbace_go_check_code_call__init_A_Unit19__O(); A_arbace_go_check_code_call__init_A_Unit20__O(); A_arbace_go_check_code_call__init_A_Unit21__O(); A_arbace_go_check_code_call__init_A_Unit22__O(); A_arbace_go_check_code_call__init_A_Unit23__O(); A_arbace_go_check_code_call__init_A_Unit24__O(); A_arbace_go_check_code_call__init_A_Unit25__O(); A_arbace_go_check_code_call__init_A_Unit26__O(); A_arbace_go_check_code_call__init_A_Unit27__O(); A_arbace_go_check_code_call__init_A_Unit28__O(); A_arbace_go_check_code_call__init_A_Unit29__O(); A_arbace_go_check_code_call__init_A_Unit30__O(); A_arbace_go_check_code_call__init_A_Unit31__O(); A_arbace_go_check_code_call__init_A_Unit32__O(); A_arbace_go_check_code_call__init_A_Unit33__O(); A_arbace_go_check_code_call__init_A_Unit34__O(); A_arbace_go_check_code_call__init_A_Unit35__O(); A_arbace_go_check_code_call__init_A_Unit36__O(); A_arbace_go_check_code_call__init_A_Unit37__O(); A_arbace_go_check_code_call__init_A_Unit38__O(); A_arbace_go_check_code_call__init_A_Unit39__O(); A_arbace_go_check_code_call__init_A_Unit40__O(); A_arbace_go_check_code_call__init_A_Unit41__O(); A_arbace_go_check_code_call__init_A_Unit42__O(); A_arbace_go_check_code_call__init_A_Unit43__O(); A_arbace_go_check_code_call__init_A_Unit44__O(); A_arbace_go_check_code_call__init_A_Unit45__O(); A_arbace_go_check_code_call__init_A_Unit46__O(); A_arbace_go_check_code_call__init_A_Unit47__O(); A_arbace_go_check_code_call__init_A_Unit48__O(); A_arbace_go_check_code_call__init_A_Unit49__O(); A_arbace_go_check_code_call__init_A_Unit50__O(); A_arbace_go_check_code_call__init_A_Unit51__O(); A_arbace_go_check_code_call__init_A_Unit52__O(); A_arbace_go_check_code_call__init_A_Unit53__O(); A_arbace_go_check_code_call__init_A_Unit54__O(); A_arbace_go_check_code_call__init_A_Unit55__O(); A_arbace_go_check_code_call__init_A_Unit56__O(); A_arbace_go_check_code_call__init_A_Unit57__O(); A_arbace_go_check_code_call__init_A_Unit58__O(); A_arbace_go_check_code_call__init_A_Unit59__O(); A_arbace_go_check_code_call__init_A_Unit60__O(); A_arbace_go_check_code_call__init_A_Unit61__O(); A_arbace_go_check_code_call__init_A_Unit62__O(); A_arbace_go_check_code_call__init_A_Unit63__O(); A_arbace_go_check_code_call__init_A_Unit64__O(); A_arbace_go_check_code_call__init_A_Unit65__O(); A_arbace_go_check_code_call__init_A_Unit66__O(); A_arbace_go_check_code_call__init_A_Unit67__O(); A_arbace_go_check_code_call__init_A_Unit68__O(); A_arbace_go_check_code_call__init_A_Unit69__O(); A_arbace_go_check_code_call__init_A_Unit70__O(); A_arbace_go_check_code_call__init_A_Unit71__O(); return nil }








































func A_arbace_go_check_code_call__init_A_Unit2__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_4; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_ident_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_ident_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); aot_arbace_go_check_code.A_arbace_go_check_code_ident_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_5)); return A_arbace_go_check_code_call__init_A_const_4 }














func A_arbace_go_check_code_call__init_A_Unit3__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_6; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_literal_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_literal_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); aot_arbace_go_check_code.A_arbace_go_check_code_literal_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_7)); return A_arbace_go_check_code_call__init_A_const_6 }























func A_arbace_go_check_code_call__init_A_Unit4__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_8; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_byte_string_value_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_byte_string_value_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); aot_arbace_go_check_code.A_arbace_go_check_code_byte_string_value_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_9)); return A_arbace_go_check_code_call__init_A_const_8 }




func A_arbace_go_check_code_call__init_A_Unit5__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_10; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_literal_form_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_literal_form_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); aot_arbace_go_check_code.A_arbace_go_check_code_literal_form_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_11)); return A_arbace_go_check_code_call__init_A_const_10 }










func A_arbace_go_check_code_call__init_A_Unit6__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_12; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_tail_str_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_tail_str_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); aot_arbace_go_check_code.A_arbace_go_check_code_tail_str_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_13)); return A_arbace_go_check_code_call__init_A_const_12 }

func A_arbace_go_check_code_call__init_A_Unit7__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_14; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_lookup_error_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_lookup_error_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); aot_arbace_go_check_code.A_arbace_go_check_code_lookup_error_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_15)); return A_arbace_go_check_code_call__init_A_const_14 }
























func A_arbace_go_check_code_call__init_A_Unit8__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_16; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_via_names_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_via_names_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); aot_arbace_go_check_code.A_arbace_go_check_code_via_names_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_17)); return A_arbace_go_check_code_call__init_A_const_16 }

func A_arbace_go_check_code_call__init_A_Unit9__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_18; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_path_derefs_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_path_derefs_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); aot_arbace_go_check_code.A_arbace_go_check_code_path_derefs_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_19)); return A_arbace_go_check_code_call__init_A_const_18 }














func A_arbace_go_check_code_call__init_A_Unit10__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_20; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_verify_via_BANG__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_verify_via_BANG__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); aot_arbace_go_check_code.A_arbace_go_check_code_verify_via_BANG__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_21)); return A_arbace_go_check_code_call__init_A_const_20 }










func A_arbace_go_check_code_call__init_A_Unit11__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_22; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_method_data_of_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_method_data_of_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); aot_arbace_go_check_code.A_arbace_go_check_code_method_data_of_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_23)); return A_arbace_go_check_code_call__init_A_const_22 }




func A_arbace_go_check_code_call__init_A_Unit12__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_25)); return A_arbace_go_check_code_call__init_A_const_24 }

func A_arbace_go_check_code_call__init_A_Unit13__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(163, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_26; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_select_expr_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_select_expr_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); aot_arbace_go_check_code.A_arbace_go_check_code_select_expr_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_27)); return A_arbace_go_check_code_call__init_A_const_26 }




func A_arbace_go_check_code_call__init_A_Unit14__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_24; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_select_expr_STAR__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_select_expr_STAR__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); aot_arbace_go_check_code.A_arbace_go_check_code_select_expr_STAR__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_28)); return A_arbace_go_check_code_call__init_A_const_24 }









































































func A_arbace_go_check_code_call__init_A_Unit15__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(242, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_29; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_30)); return A_arbace_go_check_code_call__init_A_const_29 }

func A_arbace_go_check_code_call__init_A_Unit16__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(244, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_31; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_method_expr_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_method_expr_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); aot_arbace_go_check_code.A_arbace_go_check_code_method_expr_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_32)); return A_arbace_go_check_code_call__init_A_const_31 }





func A_arbace_go_check_code_call__init_A_Unit17__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(250, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_29; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_method_expr_STAR__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_method_expr_STAR__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); aot_arbace_go_check_code.A_arbace_go_check_code_method_expr_STAR__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_33)); return A_arbace_go_check_code_call__init_A_const_29 }







































func A_arbace_go_check_code_call__init_A_Unit18__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(290, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_34; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_has_call_or_recv_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_has_call_or_recv_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); aot_arbace_go_check_code.A_arbace_go_check_code_has_call_or_recv_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_35)); return A_arbace_go_check_code_call__init_A_const_34 }










func A_arbace_go_check_code_call__init_A_Unit19__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(301, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_36; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_index_value_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_index_value_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, true); aot_arbace_go_check_code.A_arbace_go_check_code_index_value_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_37)); return A_arbace_go_check_code_call__init_A_const_36 }























func A_arbace_go_check_code_call__init_A_Unit20__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(325, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_38; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_tparam_index_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_tparam_index_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); aot_arbace_go_check_code.A_arbace_go_check_code_tparam_index_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_39)); return A_arbace_go_check_code_call__init_A_const_38 }




























func A_arbace_go_check_code_call__init_A_Unit21__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(354, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_41)); return A_arbace_go_check_code_call__init_A_const_40 }

func A_arbace_go_check_code_call__init_A_Unit22__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(356, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_42; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_index_expr_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_index_expr_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); aot_arbace_go_check_code.A_arbace_go_check_code_index_expr_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_43)); return A_arbace_go_check_code_call__init_A_const_42 }





func A_arbace_go_check_code_call__init_A_Unit23__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(362, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_40; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_index_expr_STAR__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_index_expr_STAR__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); aot_arbace_go_check_code.A_arbace_go_check_code_index_expr_STAR__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_44)); return A_arbace_go_check_code_call__init_A_const_40 }









































func A_arbace_go_check_code_call__init_A_Unit24__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(404, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_45; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_slice_expr_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_slice_expr_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); aot_arbace_go_check_code.A_arbace_go_check_code_slice_expr_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_46)); return A_arbace_go_check_code_call__init_A_const_45 }

















































func A_arbace_go_check_code_call__init_A_Unit25__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(454, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_47; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_type_assert_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_type_assert_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); aot_arbace_go_check_code.A_arbace_go_check_code_type_assert_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_48)); return A_arbace_go_check_code_call__init_A_const_47 }




















func A_arbace_go_check_code_call__init_A_Unit26__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(475, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_49; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_receive_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_receive_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); aot_arbace_go_check_code.A_arbace_go_check_code_receive_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_50)); return A_arbace_go_check_code_call__init_A_const_49 }











func A_arbace_go_check_code_call__init_A_Unit27__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(487, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_51; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_mark_addressed_BANG__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_mark_addressed_BANG__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); aot_arbace_go_check_code.A_arbace_go_check_code_mark_addressed_BANG__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_52)); return A_arbace_go_check_code_call__init_A_const_51 }








func A_arbace_go_check_code_call__init_A_Unit28__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(496, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_53; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_address_of_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_address_of_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); aot_arbace_go_check_code.A_arbace_go_check_code_address_of_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_54)); return A_arbace_go_check_code_call__init_A_const_53 }










func A_arbace_go_check_code_call__init_A_Unit29__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_55; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_indirect_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_indirect_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); aot_arbace_go_check_code.A_arbace_go_check_code_indirect_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_56)); return A_arbace_go_check_code_call__init_A_const_55 }














func A_arbace_go_check_code_call__init_A_Unit30__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(522, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_57; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_elided_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_elided_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); aot_arbace_go_check_code.A_arbace_go_check_code_elided_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_58)); return A_arbace_go_check_code_call__init_A_const_57 }

func A_arbace_go_check_code_call__init_A_Unit31__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(524, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_59; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_element_value_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_element_value_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); aot_arbace_go_check_code.A_arbace_go_check_code_element_value_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_60)); return A_arbace_go_check_code_call__init_A_const_59 }












func A_arbace_go_check_code_call__init_A_Unit32__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(537, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_61; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_key_val_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_key_val_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); aot_arbace_go_check_code.A_arbace_go_check_code_key_val_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_62)); return A_arbace_go_check_code_call__init_A_const_61 }









func A_arbace_go_check_code_call__init_A_Unit33__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(547, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_63; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_indexed_elements_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_indexed_elements_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); aot_arbace_go_check_code.A_arbace_go_check_code_indexed_elements_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_64)); return A_arbace_go_check_code_call__init_A_const_63 }


























func A_arbace_go_check_code_call__init_A_Unit34__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(574, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_65; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_66)); return A_arbace_go_check_code_call__init_A_const_65 }

func A_arbace_go_check_code_call__init_A_Unit35__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(576, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_65; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_composite_lit_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_composite_lit_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); aot_arbace_go_check_code.A_arbace_go_check_code_composite_lit_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_67)); return A_arbace_go_check_code_call__init_A_const_65 }


























































































































































































func A_arbace_go_check_code_call__init_A_Unit36__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(763, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_68; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_tuple_types_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_tuple_types_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); aot_arbace_go_check_code.A_arbace_go_check_code_tuple_types_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_69)); return A_arbace_go_check_code_call__init_A_const_68 }

func A_arbace_go_check_code_call__init_A_Unit37__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(765, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_70; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_results_type_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_results_type_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); aot_arbace_go_check_code.A_arbace_go_check_code_results_type_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_71)); return A_arbace_go_check_code_call__init_A_const_70 }


func A_arbace_go_check_code_call__init_A_Unit38__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(768, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_72; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_spread_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_spread_QMARK__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); aot_arbace_go_check_code.A_arbace_go_check_code_spread_QMARK__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_73)); return A_arbace_go_check_code_call__init_A_const_72 }

func A_arbace_go_check_code_call__init_A_Unit39__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(770, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_74; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_generic_fn_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_generic_fn_QMARK__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); aot_arbace_go_check_code.A_arbace_go_check_code_generic_fn_QMARK__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_75)); return A_arbace_go_check_code_call__init_A_const_74 }




func A_arbace_go_check_code_call__init_A_Unit40__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(775, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_76; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_types_str_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_types_str_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); aot_arbace_go_check_code.A_arbace_go_check_code_types_str_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_77)); return A_arbace_go_check_code_call__init_A_const_76 }

func A_arbace_go_check_code_call__init_A_Unit41__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(777, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_78; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_inst_say_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_inst_say_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); aot_arbace_go_check_code.A_arbace_go_check_code_inst_say_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_79)); return A_arbace_go_check_code_call__init_A_const_78 }





func A_arbace_go_check_code_call__init_A_Unit42__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(783, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_80; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_record_inst_BANG__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_record_inst_BANG__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); aot_arbace_go_check_code.A_arbace_go_check_code_record_inst_BANG__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_81)); return A_arbace_go_check_code_call__init_A_const_80 }














func A_arbace_go_check_code_call__init_A_Unit43__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(798, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_82; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_instantiate_fn_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_instantiate_fn_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); aot_arbace_go_check_code.A_arbace_go_check_code_instantiate_fn_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_83)); return A_arbace_go_check_code_call__init_A_const_82 }










func A_arbace_go_check_code_call__init_A_Unit44__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(809, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_84; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_func_inst_target_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_func_inst_target_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); aot_arbace_go_check_code.A_arbace_go_check_code_func_inst_target_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_85)); return A_arbace_go_check_code_call__init_A_const_84 }













func A_arbace_go_check_code_call__init_A_Unit45__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(823, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_72; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_spread_QMARK___1_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_spread_QMARK___1_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); aot_arbace_go_check_code.A_arbace_go_check_code_spread_QMARK___1_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_86)); return A_arbace_go_check_code_call__init_A_const_72 }

func A_arbace_go_check_code_call__init_A_Unit46__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(825, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_87; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_call_args_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_call_args_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); aot_arbace_go_check_code.A_arbace_go_check_code_call_args_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_88)); return A_arbace_go_check_code_call__init_A_const_87 }


























































































func A_arbace_go_check_code_call__init_A_Unit47__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(916, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_89; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_call_kind_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_call_kind_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); aot_arbace_go_check_code.A_arbace_go_check_code_call_kind_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_90)); return A_arbace_go_check_code_call__init_A_const_89 }










func A_arbace_go_check_code_call__init_A_Unit48__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(927, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_91; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_92)); return A_arbace_go_check_code_call__init_A_const_91 }

func A_arbace_go_check_code_call__init_A_Unit49__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(929, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_93; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_call_sig_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_call_sig_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); aot_arbace_go_check_code.A_arbace_go_check_code_call_sig_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_94)); return A_arbace_go_check_code_call__init_A_const_93 }






func A_arbace_go_check_code_call__init_A_Unit50__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(936, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_95; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_finish_call_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_finish_call_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); aot_arbace_go_check_code.A_arbace_go_check_code_finish_call_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_96)); return A_arbace_go_check_code_call__init_A_const_95 }







func A_arbace_go_check_code_call__init_A_Unit51__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(944, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_97; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_call_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_call_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); aot_arbace_go_check_code.A_arbace_go_check_code_call_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_98)); return A_arbace_go_check_code_call__init_A_const_97 }


























func A_arbace_go_check_code_call__init_A_Unit52__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(971, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_99; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_method_call_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_method_call_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); aot_arbace_go_check_code.A_arbace_go_check_code_method_call_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_100)); return A_arbace_go_check_code_call__init_A_const_99 }
















func A_arbace_go_check_code_call__init_A_Unit53__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(988, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_101; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_arg_nodes_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); aot_arbace_go_check_code.A_arbace_go_check_code_arg_nodes_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_102)); return A_arbace_go_check_code_call__init_A_const_101 }

func A_arbace_go_check_code_call__init_A_Unit54__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(990, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_103; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_array_ptr_deref_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_array_ptr_deref_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); aot_arbace_go_check_code.A_arbace_go_check_code_array_ptr_deref_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_104)); return A_arbace_go_check_code_call__init_A_const_103 }




func A_arbace_go_check_code_call__init_A_Unit55__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(995, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_105; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_slice_elem_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_slice_elem_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); aot_arbace_go_check_code.A_arbace_go_check_code_slice_elem_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_106)); return A_arbace_go_check_code_call__init_A_const_105 }







func A_arbace_go_check_code_call__init_A_Unit56__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1003, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_107; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_string_or_bytes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_string_or_bytes_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); aot_arbace_go_check_code.A_arbace_go_check_code_string_or_bytes_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_108)); return A_arbace_go_check_code_call__init_A_const_107 }






func A_arbace_go_check_code_call__init_A_Unit57__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1010, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_109; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_has_var_size_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_has_var_size_QMARK__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); aot_arbace_go_check_code.A_arbace_go_check_code_has_var_size_QMARK__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_110)); return A_arbace_go_check_code_call__init_A_const_109 }











func A_arbace_go_check_code_call__init_A_Unit58__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1022, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_111; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_offsetof_value_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_offsetof_value_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); aot_arbace_go_check_code.A_arbace_go_check_code_offsetof_value_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_112)); return A_arbace_go_check_code_call__init_A_const_111 }


















func A_arbace_go_check_code_call__init_A_Unit59__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1041, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_91; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_builtin_call_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_builtin_call_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); aot_arbace_go_check_code.A_arbace_go_check_code_builtin_call_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_113)); return A_arbace_go_check_code_call__init_A_const_91 }





























































































































































































































































































































































































func A_arbace_go_check_code_call__init_A_Unit60__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1423, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_114; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_inst_expr_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_inst_expr_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); aot_arbace_go_check_code.A_arbace_go_check_code_inst_expr_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_115)); return A_arbace_go_check_code_call__init_A_const_114 }


























func A_arbace_go_check_code_call__init_A_Unit61__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1450, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_116; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_func_lit_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_func_lit_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); aot_arbace_go_check_code.A_arbace_go_check_code_func_lit_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_117)); return A_arbace_go_check_code_call__init_A_const_116 }







func A_arbace_go_check_code_call__init_A_Unit62__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1458, 1); A_arbace_go_check_code_call__init_A_const_118.BindRoot_O__V(A_arbace_go_check_code_call__init_A_const_119); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_118; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_120)); return A_arbace_go_check_code_call__init_A_const_118 }

func A_arbace_go_check_code_call__init_A_Unit63__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1460, 1); A_arbace_go_check_code_call__init_A_const_121.BindRoot_O__V(A_arbace_go_check_code_call__init_A_const_122); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_121; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_123)); return A_arbace_go_check_code_call__init_A_const_121 }



func A_arbace_go_check_code_call__init_A_Unit64__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1464, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_124; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_raw_qualified_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_raw_qualified_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); aot_arbace_go_check_code.A_arbace_go_check_code_raw_qualified_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_125)); return A_arbace_go_check_code_call__init_A_const_124 }










func A_arbace_go_check_code_call__init_A_Unit65__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1475, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_126; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_pkg_name_obj_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_pkg_name_obj_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); aot_arbace_go_check_code.A_arbace_go_check_code_pkg_name_obj_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_127)); return A_arbace_go_check_code_call__init_A_const_126 }






func A_arbace_go_check_code_call__init_A_Unit66__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1482, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_128; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_raw_select_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_raw_select_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); aot_arbace_go_check_code.A_arbace_go_check_code_raw_select_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_129)); return A_arbace_go_check_code_call__init_A_const_128 }













func A_arbace_go_check_code_call__init_A_Unit67__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1496, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_130; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_raw_type_name_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_raw_type_name_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); aot_arbace_go_check_code.A_arbace_go_check_code_raw_type_name_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_131)); return A_arbace_go_check_code_call__init_A_const_130 }

















func A_arbace_go_check_code_call__init_A_Unit68__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1514, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_132; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_raw_index_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_raw_index_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); aot_arbace_go_check_code.A_arbace_go_check_code_raw_index_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_133)); return A_arbace_go_check_code_call__init_A_const_132 }


























func A_arbace_go_check_code_call__init_A_Unit69__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1541, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_134; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_raw_expr_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_raw_expr_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); aot_arbace_go_check_code.A_arbace_go_check_code_raw_expr_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_135)); return A_arbace_go_check_code_call__init_A_const_134 }












func A_arbace_go_check_code_call__init_A_Unit70__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1554, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_136; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_expr_dispatch_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_expr_dispatch_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); aot_arbace_go_check_code.A_arbace_go_check_code_expr_dispatch_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_137)); return A_arbace_go_check_code_call__init_A_const_136 }

































































func A_arbace_go_check_code_call__init_A_Unit71__O() any { A_arbace_go_check_code_call__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1620, 1); var tmp1 *lang.Var = A_arbace_go_check_code_call__init_A_const_138; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_expr_internal_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_expr_internal_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); aot_arbace_go_check_code.A_arbace_go_check_code_expr_internal_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_call__init_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_call__init_A_const_139)); return A_arbace_go_check_code_call__init_A_const_138 }



type A_arbace_go_check_code_call__init_A struct{ jrt.Object }

var A_arbace_go_check_code_call__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_code_call__init_A_const_0 *lang.Var

var A_arbace_go_check_code_call__init_A_const_1 any

var A_arbace_go_check_code_call__init_A_const_2 *lang.Var

var A_arbace_go_check_code_call__init_A_const_3 any

var A_arbace_go_check_code_call__init_A_const_4 *lang.Var

var A_arbace_go_check_code_call__init_A_const_5 any

var A_arbace_go_check_code_call__init_A_const_6 *lang.Var

var A_arbace_go_check_code_call__init_A_const_7 any

var A_arbace_go_check_code_call__init_A_const_8 *lang.Var

var A_arbace_go_check_code_call__init_A_const_9 any

var A_arbace_go_check_code_call__init_A_const_10 *lang.Var

var A_arbace_go_check_code_call__init_A_const_11 any

var A_arbace_go_check_code_call__init_A_const_12 *lang.Var

var A_arbace_go_check_code_call__init_A_const_13 any

var A_arbace_go_check_code_call__init_A_const_14 *lang.Var

var A_arbace_go_check_code_call__init_A_const_15 any

var A_arbace_go_check_code_call__init_A_const_16 *lang.Var

var A_arbace_go_check_code_call__init_A_const_17 any

var A_arbace_go_check_code_call__init_A_const_18 *lang.Var

var A_arbace_go_check_code_call__init_A_const_19 any

var A_arbace_go_check_code_call__init_A_const_20 *lang.Var

var A_arbace_go_check_code_call__init_A_const_21 any

var A_arbace_go_check_code_call__init_A_const_22 *lang.Var

var A_arbace_go_check_code_call__init_A_const_23 any

var A_arbace_go_check_code_call__init_A_const_24 *lang.Var

var A_arbace_go_check_code_call__init_A_const_25 any

var A_arbace_go_check_code_call__init_A_const_26 *lang.Var

var A_arbace_go_check_code_call__init_A_const_27 any

var A_arbace_go_check_code_call__init_A_const_28 any

var A_arbace_go_check_code_call__init_A_const_29 *lang.Var

var A_arbace_go_check_code_call__init_A_const_30 any

var A_arbace_go_check_code_call__init_A_const_31 *lang.Var

var A_arbace_go_check_code_call__init_A_const_32 any

var A_arbace_go_check_code_call__init_A_const_33 any

var A_arbace_go_check_code_call__init_A_const_34 *lang.Var

var A_arbace_go_check_code_call__init_A_const_35 any

var A_arbace_go_check_code_call__init_A_const_36 *lang.Var

var A_arbace_go_check_code_call__init_A_const_37 any

var A_arbace_go_check_code_call__init_A_const_38 *lang.Var

var A_arbace_go_check_code_call__init_A_const_39 any

var A_arbace_go_check_code_call__init_A_const_40 *lang.Var

var A_arbace_go_check_code_call__init_A_const_41 any

var A_arbace_go_check_code_call__init_A_const_42 *lang.Var

var A_arbace_go_check_code_call__init_A_const_43 any

var A_arbace_go_check_code_call__init_A_const_44 any

var A_arbace_go_check_code_call__init_A_const_45 *lang.Var

var A_arbace_go_check_code_call__init_A_const_46 any

var A_arbace_go_check_code_call__init_A_const_47 *lang.Var

var A_arbace_go_check_code_call__init_A_const_48 any

var A_arbace_go_check_code_call__init_A_const_49 *lang.Var

var A_arbace_go_check_code_call__init_A_const_50 any

var A_arbace_go_check_code_call__init_A_const_51 *lang.Var

var A_arbace_go_check_code_call__init_A_const_52 any

var A_arbace_go_check_code_call__init_A_const_53 *lang.Var

var A_arbace_go_check_code_call__init_A_const_54 any

var A_arbace_go_check_code_call__init_A_const_55 *lang.Var

var A_arbace_go_check_code_call__init_A_const_56 any

var A_arbace_go_check_code_call__init_A_const_57 *lang.Var

var A_arbace_go_check_code_call__init_A_const_58 any

var A_arbace_go_check_code_call__init_A_const_59 *lang.Var

var A_arbace_go_check_code_call__init_A_const_60 any

var A_arbace_go_check_code_call__init_A_const_61 *lang.Var

var A_arbace_go_check_code_call__init_A_const_62 any

var A_arbace_go_check_code_call__init_A_const_63 *lang.Var

var A_arbace_go_check_code_call__init_A_const_64 any

var A_arbace_go_check_code_call__init_A_const_65 *lang.Var

var A_arbace_go_check_code_call__init_A_const_66 any

var A_arbace_go_check_code_call__init_A_const_67 any

var A_arbace_go_check_code_call__init_A_const_68 *lang.Var

var A_arbace_go_check_code_call__init_A_const_69 any

var A_arbace_go_check_code_call__init_A_const_70 *lang.Var

var A_arbace_go_check_code_call__init_A_const_71 any

var A_arbace_go_check_code_call__init_A_const_72 *lang.Var

var A_arbace_go_check_code_call__init_A_const_73 any

var A_arbace_go_check_code_call__init_A_const_74 *lang.Var

var A_arbace_go_check_code_call__init_A_const_75 any

var A_arbace_go_check_code_call__init_A_const_76 *lang.Var

var A_arbace_go_check_code_call__init_A_const_77 any

var A_arbace_go_check_code_call__init_A_const_78 *lang.Var

var A_arbace_go_check_code_call__init_A_const_79 any

var A_arbace_go_check_code_call__init_A_const_80 *lang.Var

var A_arbace_go_check_code_call__init_A_const_81 any

var A_arbace_go_check_code_call__init_A_const_82 *lang.Var

var A_arbace_go_check_code_call__init_A_const_83 any

var A_arbace_go_check_code_call__init_A_const_84 *lang.Var

var A_arbace_go_check_code_call__init_A_const_85 any

var A_arbace_go_check_code_call__init_A_const_86 any

var A_arbace_go_check_code_call__init_A_const_87 *lang.Var

var A_arbace_go_check_code_call__init_A_const_88 any

var A_arbace_go_check_code_call__init_A_const_89 *lang.Var

var A_arbace_go_check_code_call__init_A_const_90 any

var A_arbace_go_check_code_call__init_A_const_91 *lang.Var

var A_arbace_go_check_code_call__init_A_const_92 any

var A_arbace_go_check_code_call__init_A_const_93 *lang.Var

var A_arbace_go_check_code_call__init_A_const_94 any

var A_arbace_go_check_code_call__init_A_const_95 *lang.Var

var A_arbace_go_check_code_call__init_A_const_96 any

var A_arbace_go_check_code_call__init_A_const_97 *lang.Var

var A_arbace_go_check_code_call__init_A_const_98 any

var A_arbace_go_check_code_call__init_A_const_99 *lang.Var

var A_arbace_go_check_code_call__init_A_const_100 any

var A_arbace_go_check_code_call__init_A_const_101 *lang.Var

var A_arbace_go_check_code_call__init_A_const_102 any

var A_arbace_go_check_code_call__init_A_const_103 *lang.Var

var A_arbace_go_check_code_call__init_A_const_104 any

var A_arbace_go_check_code_call__init_A_const_105 *lang.Var

var A_arbace_go_check_code_call__init_A_const_106 any

var A_arbace_go_check_code_call__init_A_const_107 *lang.Var

var A_arbace_go_check_code_call__init_A_const_108 any

var A_arbace_go_check_code_call__init_A_const_109 *lang.Var

var A_arbace_go_check_code_call__init_A_const_110 any

var A_arbace_go_check_code_call__init_A_const_111 *lang.Var

var A_arbace_go_check_code_call__init_A_const_112 any

var A_arbace_go_check_code_call__init_A_const_113 any

var A_arbace_go_check_code_call__init_A_const_114 *lang.Var

var A_arbace_go_check_code_call__init_A_const_115 any

var A_arbace_go_check_code_call__init_A_const_116 *lang.Var

var A_arbace_go_check_code_call__init_A_const_117 any

var A_arbace_go_check_code_call__init_A_const_118 *lang.Var

var A_arbace_go_check_code_call__init_A_const_119 any

var A_arbace_go_check_code_call__init_A_const_120 any

var A_arbace_go_check_code_call__init_A_const_121 *lang.Var

var A_arbace_go_check_code_call__init_A_const_122 any

var A_arbace_go_check_code_call__init_A_const_123 any

var A_arbace_go_check_code_call__init_A_const_124 *lang.Var

var A_arbace_go_check_code_call__init_A_const_125 any

var A_arbace_go_check_code_call__init_A_const_126 *lang.Var

var A_arbace_go_check_code_call__init_A_const_127 any

var A_arbace_go_check_code_call__init_A_const_128 *lang.Var

var A_arbace_go_check_code_call__init_A_const_129 any

var A_arbace_go_check_code_call__init_A_const_130 *lang.Var

var A_arbace_go_check_code_call__init_A_const_131 any

var A_arbace_go_check_code_call__init_A_const_132 *lang.Var

var A_arbace_go_check_code_call__init_A_const_133 any

var A_arbace_go_check_code_call__init_A_const_134 *lang.Var

var A_arbace_go_check_code_call__init_A_const_135 any

var A_arbace_go_check_code_call__init_A_const_136 *lang.Var

var A_arbace_go_check_code_call__init_A_const_137 any

var A_arbace_go_check_code_call__init_A_const_138 *lang.Var

var A_arbace_go_check_code_call__init_A_const_139 any

var A_arbace_go_check_code_call__init_A_init jrt.ClassInit

func A_arbace_go_check_code_call__init_A_Init() { if !A_arbace_go_check_code_call__init_A_init.Done() { A_arbace_go_check_code_call__init_A_init.Run(A_arbace_go_check_code_call__init_A_clinit) } }

func A_arbace_go_check_code_call__init_A_clinit() { A_arbace_go_check_code_call__init_A_clinit_p0(); A_arbace_go_check_code_call__init_A_clinit_p1(); A_arbace_go_check_code_call__init_A_clinit_p2(); A_arbace_go_check_code_call__init_A_clinit_p3(); A_arbace_go_check_code_call__init_A_clinit_p4(); A_arbace_go_check_code_call__init_A_clinit_p5(); A_arbace_go_check_code_call__init_A_clinit_p6(); A_arbace_go_check_code_call__init_A_clinit_p7(); A_arbace_go_check_code_call__init_A_clinit_p8(); A_arbace_go_check_code_call__init_A_clinit_p9(); A_arbace_go_check_code_call__init_A_clinit_p10() }

func A_arbace_go_check_code_call__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_code_call__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 196); A_arbace_go_check_code_call__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[56]); A_arbace_go_check_code_call__init_A_const_1 = A_arbace_go_check_code_call__init_A_const_pool.A[57]; A_arbace_go_check_code_call__init_A_const_2 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[58]); A_arbace_go_check_code_call__init_A_const_3 = A_arbace_go_check_code_call__init_A_const_pool.A[59]; A_arbace_go_check_code_call__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[60]); A_arbace_go_check_code_call__init_A_const_5 = A_arbace_go_check_code_call__init_A_const_pool.A[61]; A_arbace_go_check_code_call__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[62]); A_arbace_go_check_code_call__init_A_const_7 = A_arbace_go_check_code_call__init_A_const_pool.A[63]; A_arbace_go_check_code_call__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[64]); A_arbace_go_check_code_call__init_A_const_9 = A_arbace_go_check_code_call__init_A_const_pool.A[65]; A_arbace_go_check_code_call__init_A_const_10 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[66]); A_arbace_go_check_code_call__init_A_const_11 = A_arbace_go_check_code_call__init_A_const_pool.A[67] }

func A_arbace_go_check_code_call__init_A_clinit_p1() { A_arbace_go_check_code_call__init_A_const_12 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[68]); A_arbace_go_check_code_call__init_A_const_13 = A_arbace_go_check_code_call__init_A_const_pool.A[69]; A_arbace_go_check_code_call__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[70]); A_arbace_go_check_code_call__init_A_const_15 = A_arbace_go_check_code_call__init_A_const_pool.A[71]; A_arbace_go_check_code_call__init_A_const_16 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[72]); A_arbace_go_check_code_call__init_A_const_17 = A_arbace_go_check_code_call__init_A_const_pool.A[73]; A_arbace_go_check_code_call__init_A_const_18 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[74]); A_arbace_go_check_code_call__init_A_const_19 = A_arbace_go_check_code_call__init_A_const_pool.A[75]; A_arbace_go_check_code_call__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[76]); A_arbace_go_check_code_call__init_A_const_21 = A_arbace_go_check_code_call__init_A_const_pool.A[77]; A_arbace_go_check_code_call__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[78]); A_arbace_go_check_code_call__init_A_const_23 = A_arbace_go_check_code_call__init_A_const_pool.A[79]; A_arbace_go_check_code_call__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[80]) }

func A_arbace_go_check_code_call__init_A_clinit_p2() { A_arbace_go_check_code_call__init_A_const_25 = A_arbace_go_check_code_call__init_A_const_pool.A[81]; A_arbace_go_check_code_call__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[82]); A_arbace_go_check_code_call__init_A_const_27 = A_arbace_go_check_code_call__init_A_const_pool.A[83]; A_arbace_go_check_code_call__init_A_const_28 = A_arbace_go_check_code_call__init_A_const_pool.A[84]; A_arbace_go_check_code_call__init_A_const_29 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[85]); A_arbace_go_check_code_call__init_A_const_30 = A_arbace_go_check_code_call__init_A_const_pool.A[86]; A_arbace_go_check_code_call__init_A_const_31 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[87]); A_arbace_go_check_code_call__init_A_const_32 = A_arbace_go_check_code_call__init_A_const_pool.A[88]; A_arbace_go_check_code_call__init_A_const_33 = A_arbace_go_check_code_call__init_A_const_pool.A[89]; A_arbace_go_check_code_call__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[90]); A_arbace_go_check_code_call__init_A_const_35 = A_arbace_go_check_code_call__init_A_const_pool.A[91]; A_arbace_go_check_code_call__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[92]); A_arbace_go_check_code_call__init_A_const_37 = A_arbace_go_check_code_call__init_A_const_pool.A[93]; A_arbace_go_check_code_call__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[94]) }

func A_arbace_go_check_code_call__init_A_clinit_p3() { A_arbace_go_check_code_call__init_A_const_39 = A_arbace_go_check_code_call__init_A_const_pool.A[95]; A_arbace_go_check_code_call__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[96]); A_arbace_go_check_code_call__init_A_const_41 = A_arbace_go_check_code_call__init_A_const_pool.A[97]; A_arbace_go_check_code_call__init_A_const_42 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[98]); A_arbace_go_check_code_call__init_A_const_43 = A_arbace_go_check_code_call__init_A_const_pool.A[99]; A_arbace_go_check_code_call__init_A_const_44 = A_arbace_go_check_code_call__init_A_const_pool.A[100]; A_arbace_go_check_code_call__init_A_const_45 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[101]); A_arbace_go_check_code_call__init_A_const_46 = A_arbace_go_check_code_call__init_A_const_pool.A[102]; A_arbace_go_check_code_call__init_A_const_47 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[103]); A_arbace_go_check_code_call__init_A_const_48 = A_arbace_go_check_code_call__init_A_const_pool.A[104]; A_arbace_go_check_code_call__init_A_const_49 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[105]); A_arbace_go_check_code_call__init_A_const_50 = A_arbace_go_check_code_call__init_A_const_pool.A[106]; A_arbace_go_check_code_call__init_A_const_51 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[107]); A_arbace_go_check_code_call__init_A_const_52 = A_arbace_go_check_code_call__init_A_const_pool.A[108] }

func A_arbace_go_check_code_call__init_A_clinit_p4() { A_arbace_go_check_code_call__init_A_const_53 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[109]); A_arbace_go_check_code_call__init_A_const_54 = A_arbace_go_check_code_call__init_A_const_pool.A[110]; A_arbace_go_check_code_call__init_A_const_55 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[111]); A_arbace_go_check_code_call__init_A_const_56 = A_arbace_go_check_code_call__init_A_const_pool.A[112]; A_arbace_go_check_code_call__init_A_const_57 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[113]); A_arbace_go_check_code_call__init_A_const_58 = A_arbace_go_check_code_call__init_A_const_pool.A[114]; A_arbace_go_check_code_call__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[115]); A_arbace_go_check_code_call__init_A_const_60 = A_arbace_go_check_code_call__init_A_const_pool.A[116]; A_arbace_go_check_code_call__init_A_const_61 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[117]); A_arbace_go_check_code_call__init_A_const_62 = A_arbace_go_check_code_call__init_A_const_pool.A[118]; A_arbace_go_check_code_call__init_A_const_63 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[119]); A_arbace_go_check_code_call__init_A_const_64 = A_arbace_go_check_code_call__init_A_const_pool.A[120]; A_arbace_go_check_code_call__init_A_const_65 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[121]) }

func A_arbace_go_check_code_call__init_A_clinit_p5() { A_arbace_go_check_code_call__init_A_const_66 = A_arbace_go_check_code_call__init_A_const_pool.A[122]; A_arbace_go_check_code_call__init_A_const_67 = A_arbace_go_check_code_call__init_A_const_pool.A[123]; A_arbace_go_check_code_call__init_A_const_68 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[124]); A_arbace_go_check_code_call__init_A_const_69 = A_arbace_go_check_code_call__init_A_const_pool.A[125]; A_arbace_go_check_code_call__init_A_const_70 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[126]); A_arbace_go_check_code_call__init_A_const_71 = A_arbace_go_check_code_call__init_A_const_pool.A[127]; A_arbace_go_check_code_call__init_A_const_72 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[128]); A_arbace_go_check_code_call__init_A_const_73 = A_arbace_go_check_code_call__init_A_const_pool.A[129]; A_arbace_go_check_code_call__init_A_const_74 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[130]); A_arbace_go_check_code_call__init_A_const_75 = A_arbace_go_check_code_call__init_A_const_pool.A[131]; A_arbace_go_check_code_call__init_A_const_76 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[132]); A_arbace_go_check_code_call__init_A_const_77 = A_arbace_go_check_code_call__init_A_const_pool.A[133]; A_arbace_go_check_code_call__init_A_const_78 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[134]); A_arbace_go_check_code_call__init_A_const_79 = A_arbace_go_check_code_call__init_A_const_pool.A[135] }

func A_arbace_go_check_code_call__init_A_clinit_p6() { A_arbace_go_check_code_call__init_A_const_80 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[136]); A_arbace_go_check_code_call__init_A_const_81 = A_arbace_go_check_code_call__init_A_const_pool.A[137]; A_arbace_go_check_code_call__init_A_const_82 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[138]); A_arbace_go_check_code_call__init_A_const_83 = A_arbace_go_check_code_call__init_A_const_pool.A[139]; A_arbace_go_check_code_call__init_A_const_84 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[140]); A_arbace_go_check_code_call__init_A_const_85 = A_arbace_go_check_code_call__init_A_const_pool.A[141]; A_arbace_go_check_code_call__init_A_const_86 = A_arbace_go_check_code_call__init_A_const_pool.A[142]; A_arbace_go_check_code_call__init_A_const_87 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[143]); A_arbace_go_check_code_call__init_A_const_88 = A_arbace_go_check_code_call__init_A_const_pool.A[144]; A_arbace_go_check_code_call__init_A_const_89 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[145]); A_arbace_go_check_code_call__init_A_const_90 = A_arbace_go_check_code_call__init_A_const_pool.A[146]; A_arbace_go_check_code_call__init_A_const_91 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[147]); A_arbace_go_check_code_call__init_A_const_92 = A_arbace_go_check_code_call__init_A_const_pool.A[148] }

func A_arbace_go_check_code_call__init_A_clinit_p7() { A_arbace_go_check_code_call__init_A_const_93 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[149]); A_arbace_go_check_code_call__init_A_const_94 = A_arbace_go_check_code_call__init_A_const_pool.A[150]; A_arbace_go_check_code_call__init_A_const_95 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[151]); A_arbace_go_check_code_call__init_A_const_96 = A_arbace_go_check_code_call__init_A_const_pool.A[152]; A_arbace_go_check_code_call__init_A_const_97 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[153]); A_arbace_go_check_code_call__init_A_const_98 = A_arbace_go_check_code_call__init_A_const_pool.A[154]; A_arbace_go_check_code_call__init_A_const_99 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[155]); A_arbace_go_check_code_call__init_A_const_100 = A_arbace_go_check_code_call__init_A_const_pool.A[156]; A_arbace_go_check_code_call__init_A_const_101 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[157]); A_arbace_go_check_code_call__init_A_const_102 = A_arbace_go_check_code_call__init_A_const_pool.A[158]; A_arbace_go_check_code_call__init_A_const_103 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[159]); A_arbace_go_check_code_call__init_A_const_104 = A_arbace_go_check_code_call__init_A_const_pool.A[160]; A_arbace_go_check_code_call__init_A_const_105 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[161]) }

func A_arbace_go_check_code_call__init_A_clinit_p8() { A_arbace_go_check_code_call__init_A_const_106 = A_arbace_go_check_code_call__init_A_const_pool.A[162]; A_arbace_go_check_code_call__init_A_const_107 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[163]); A_arbace_go_check_code_call__init_A_const_108 = A_arbace_go_check_code_call__init_A_const_pool.A[164]; A_arbace_go_check_code_call__init_A_const_109 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[165]); A_arbace_go_check_code_call__init_A_const_110 = A_arbace_go_check_code_call__init_A_const_pool.A[166]; A_arbace_go_check_code_call__init_A_const_111 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[167]); A_arbace_go_check_code_call__init_A_const_112 = A_arbace_go_check_code_call__init_A_const_pool.A[168]; A_arbace_go_check_code_call__init_A_const_113 = A_arbace_go_check_code_call__init_A_const_pool.A[169]; A_arbace_go_check_code_call__init_A_const_114 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[170]); A_arbace_go_check_code_call__init_A_const_115 = A_arbace_go_check_code_call__init_A_const_pool.A[171]; A_arbace_go_check_code_call__init_A_const_116 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[172]); A_arbace_go_check_code_call__init_A_const_117 = A_arbace_go_check_code_call__init_A_const_pool.A[173]; A_arbace_go_check_code_call__init_A_const_118 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[174]); A_arbace_go_check_code_call__init_A_const_119 = A_arbace_go_check_code_call__init_A_const_pool.A[175] }

func A_arbace_go_check_code_call__init_A_clinit_p9() { A_arbace_go_check_code_call__init_A_const_120 = A_arbace_go_check_code_call__init_A_const_pool.A[176]; A_arbace_go_check_code_call__init_A_const_121 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[177]); A_arbace_go_check_code_call__init_A_const_122 = A_arbace_go_check_code_call__init_A_const_pool.A[178]; A_arbace_go_check_code_call__init_A_const_123 = A_arbace_go_check_code_call__init_A_const_pool.A[179]; A_arbace_go_check_code_call__init_A_const_124 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[180]); A_arbace_go_check_code_call__init_A_const_125 = A_arbace_go_check_code_call__init_A_const_pool.A[181]; A_arbace_go_check_code_call__init_A_const_126 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[182]); A_arbace_go_check_code_call__init_A_const_127 = A_arbace_go_check_code_call__init_A_const_pool.A[183]; A_arbace_go_check_code_call__init_A_const_128 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[184]); A_arbace_go_check_code_call__init_A_const_129 = A_arbace_go_check_code_call__init_A_const_pool.A[185]; A_arbace_go_check_code_call__init_A_const_130 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[186]); A_arbace_go_check_code_call__init_A_const_131 = A_arbace_go_check_code_call__init_A_const_pool.A[187]; A_arbace_go_check_code_call__init_A_const_132 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[188]); A_arbace_go_check_code_call__init_A_const_133 = A_arbace_go_check_code_call__init_A_const_pool.A[189] }

func A_arbace_go_check_code_call__init_A_clinit_p10() { A_arbace_go_check_code_call__init_A_const_134 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[190]); A_arbace_go_check_code_call__init_A_const_135 = A_arbace_go_check_code_call__init_A_const_pool.A[191]; A_arbace_go_check_code_call__init_A_const_136 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[192]); A_arbace_go_check_code_call__init_A_const_137 = A_arbace_go_check_code_call__init_A_const_pool.A[193]; A_arbace_go_check_code_call__init_A_const_138 = lang.Var_Cast(A_arbace_go_check_code_call__init_A_const_pool.A[194]); A_arbace_go_check_code_call__init_A_const_139 = A_arbace_go_check_code_call__init_A_const_pool.A[195] }

func A_arbace_go_check_code_call__init_A_New() *A_arbace_go_check_code_call__init_A { A_arbace_go_check_code_call__init_A_Init(); t := &A_arbace_go_check_code_call__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_code_call__init_A) Ctor() {}

func (t *A_arbace_go_check_code_call__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_code_call__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_code_call__init_A_class }

func (t *A_arbace_go_check_code_call__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_code_call__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_code_call__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_code_call__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_code_call__init_A); return ok }

func A_arbace_go_check_code_call__init_A_Cast(x any) *A_arbace_go_check_code_call__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_code_call__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_code_call__init_A_class)) }; return v }
