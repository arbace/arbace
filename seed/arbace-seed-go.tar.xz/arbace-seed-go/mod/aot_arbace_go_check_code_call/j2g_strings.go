//line j2g_strings.ae:1
package aot_arbace_go_check_code_call

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn20,arbace.go.check.codekn7,privatekn8,arglistsyn2,cxyn1,fyn1,xkn3,dockn4,linekn6,columnkn4,fileyn5,partsyn1,hkn3,tagyn6,Stringyn2,tyyn3,altkn7,dynamicyn1,ryn4,pathyn1,myn6,x-formyn2,nmyn5,call?yn1,nyn7,max-lenyn4,whatyn1,&kn4,keysyn14,allow-negativeyn3,if*yn2,tfyn2,vfyn9,elem-typeyn5,elemsyn6,lengthkn8,declaredyn4,hintyn2,rsyn1,ayn3,tysyn5,targsyn9,inferred?yn3,sigyn7,contextyn10,callee-stryn6,calleeyn9,arg-formsyn4,argsyn2,cfyn2,xfyn1,uyn4,baseyn6,unsafev11,arbace.core5,in-nsR0,v20,arbace.go.check.code8,obj-nodem12,R1,TR2,L1,V3,R3,R4,R5,R6,s47,The node of an identifier resolved to object x.R7,i5,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code5,identm10,R2,L1,V2,R3,R4,R6,s24,A name in an expression.R7,i46,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code7,literalm10,R2,L1,V1,R4,R6,s39,A literal form's constant node, or nil.R7,i61,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code17,byte-string-valuem10,R2,L1,V1,R10,R6,s36,The value of (byte-string part ...).R7,i76,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code12,literal-formm10,R2,L1,V2,R4,R11,R6,s73,A literal list form (rune n), (imaginary x), (byte-string ...): its node.R7,i81,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code8,tail-strm10,R1,TR2,L1,V1,Myn1,sm2,R12,R13,R7,i92,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code12,lookup-errorm10,R2,L1,V3,R14,Myn3,selm2,R12,R13,R15,R6,s119,types2's lookupError: why name is not a field or method of ty, given what a lookup ignoring\n  case found (alt, or nil).R7,i94,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code8,cx-flagsm10,R16,TR7,i118,R8,i1,R9,s28,arbace/go/check/code_call.aeR6,s81,{:annotated bool}: whether the package's forms carry the converter's annotations.v20,arbace.go.check.code9,via-namesm10,R1,TR2,L1,V1,R17,R7,i120,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,path-derefsm10,R2,L1,V2,R14,R18,R6,s143,The implicit dereferences of a field selection along its path: for each step, whether a\n  pointer is dereferenced before the field is selected.R7,i122,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,verify-via!m10,R2,L1,V2,R4,R17,R6,s70,Compares the selection's embedded path with the form's :go/via (§3.6).R7,i137,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code14,method-data-ofm12,R1,TR2,L1,V1,R19,R6,s90,The data of a method (resolving its declaration): {:name :pkg :type :ptr-recv :recv-type}.R7,i148,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,select-exprm10,R2,L1,V5,R3,R4,R20,R21,R22,R6,s69,x.name: a field, a method value (or a method for a call: call? true).R7,i153,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,method-exprm10,R2,L1,V2,R3,R4,R6,s60,(method-expr T M): the method as a function of its receiver.R7,i219,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code17,has-call-or-recv?m12,R1,TR2,L1,V1,R23,R6,s109,Whether a node contains a function call or a channel receive (len and cap of arrays are\n  then not constant).R7,i257,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,index-valuem10,R2,L1,V6,R3,R4,R24,R25,R26,m2,R27,V1,R28,R6,s132,An index operand: an integer, constant ones non-negative and below max when given\n  (go/types' index): [node constant-value-or-nil].R7,i268,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code12,tparam-indexm12,R1,TR2,L1,V4,R3,R4,R5,R29,R6,s146,x[i] of a type parameter's value (go/types' indexExpr): every type of its type set indexable\n  alike, the same element type (and maps' key types).R7,i292,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code10,index-exprm10,R2,L1,V2,R3,R4,R6,s11,(aget x i).R7,i321,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code10,slice-exprm10,R2,L1,V2,R3,R4,R6,s26,(subslice x lo? hi? max?).R7,i364,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,type-assertm10,R2,L1,V2,R3,R4,R6,s13,(assert T x).R7,i414,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code7,receivem8,R2,L1,V2,R3,R4,R7,i435,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code15,mark-addressed!m10,R2,L1,V1,R23,R6,s88,Marks the variable at the root of an addressable operand as addressed (for the builder).R7,i447,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code10,address-ofm8,R2,L1,V2,R3,R4,R7,i456,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code8,indirectm8,R2,L1,V2,R3,R4,R7,i467,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code7,elided?m10,R1,TR2,L1,V1,R30,R7,i482,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code13,element-valuem12,R1,TR2,L1,V3,R3,R31,R32,R6,s151,An element of a composite literal: elided literal types take the element type (pointer\n  element types make &T{}; a type parameter's by its core type).R7,i484,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code7,key-valm12,R1,TR2,L1,V1,R23,R6,s64,go/types' keyVal: a comparable representation of a constant key.R7,i497,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code16,indexed-elementsm12,R1,TR2,L1,V5,R3,R4,R33,R32,R34,R6,s85,The elements of an array or slice literal: [nodes max-index] (go/types' indexedElts).R7,i507,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code13,composite-litm8,R35,TR7,i532,R8,i1,R9,s28,arbace/go/check/code_call.aem10,R2,L1,V3,R3,R4,R36,R6,s91,(lit T element*), T a type form or _ (elided: hint, the element type of the outer literal).R7,i534,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,tuple-typesm10,R1,TR2,L1,V1,R14,R7,i647,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code12,results-typem10,R1,TR2,L1,V1,R37,R7,i649,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code7,spread?m10,R1,TR2,L1,V1,R38,R7,i652,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,generic-fn?m10,R2,L1,V1,R23,R6,s80,Whether node n is a generic function's (or method's) value not instantiated yet.R7,i654,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code9,types-strm10,R1,TR2,L1,V1,R39,R7,i659,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code8,inst-saym10,R2,L1,V2,R3,R4,R6,s94,The type arguments the converter's :inst on form f says (§3.6, SPEC.md §5.5), checked, or nil.R7,i661,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code12,record-inst!m12,R1,TR2,L1,V3,R23,R40,R41,R6,s184,Compares the converter's :inst of a generic function's instance with its type arguments the\n  checker computed (inferred?: some of them inferred, which the converter always annotates).R7,i667,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code14,instantiate-fnm10,R2,L1,V3,R23,R40,R41,R6,s231,Generic function (or method) node n instantiated with targs (one per type parameter): its\n  signature substituted, the instantiation verified after the declaration (go/types'\n  instantiateSignature), the converter's :inst compared.R7,i679,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code16,func-inst-targetm10,R2,L1,V4,R3,R23,R42,R43,R6,s173,go/types' funcInst with a target: generic function node n assigned to a variable of function\n  type sig (reverse inference, go1.21), instantiated, or invalid after an error.R7,i690,R8,i1,R9,s28,arbace/go/check/code_call.aem10,R1,TR2,L1,V1,R38,R7,i704,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code9,call-argsm10,R2,L1,V6,R3,R4,R44,R45,R42,R46,R6,s303,The arguments of a call of callee node (its signature sig: [:func ps rs variadic]), checked\n  and assigned to its parameters (go/types' genericExprList and arguments): {:args :callee},\n  the callee and generic function arguments instantiated, their missing type arguments\n  inferred; nil after an error.R7,i706,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code9,call-kindm10,R2,L1,V1,R45,R6,s45,The kind of a call by its callee node (§3.7).R7,i786,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code12,builtin-callm8,R35,TR7,i797,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code8,call-sigm10,R2,L1,V1,R14,R6,s110,The signature a callee of type ty has: its underlying function type (a type parameter's\n  common one), or nil.R7,i799,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,finish-callm12,R1,TR2,L1,V3,R4,R45,R47,R6,s48,The call node of callee (instantiated) and args.R7,i806,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code4,callm10,R2,L1,V4,R3,R4,R48,R46,R6,s49,A call form: callee form cf, arguments arg-forms.R7,i814,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code11,method-callm10,R2,L1,V5,R3,R4,R21,R49,R46,R6,s15,(.M x args...).R7,i837,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code9,arg-nodesm10,R1,TR2,L1,V2,R3,R46,R7,i854,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code15,array-ptr-derefm10,R1,TR2,L1,V1,R50,R7,i856,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code10,slice-elemm12,R1,TR2,L1,V1,R14,R6,s92,go/types' sliceElem: the element type every type of ty's type set shares as a slice, or nil.R7,i861,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code16,string-or-bytes?m12,R1,TR2,L1,V1,R14,R6,s81,Whether every type of ty's type set is a string or []byte, one at least a string.R7,i869,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code13,has-var-size?m10,R2,L1,V1,R14,R6,s72,go/types' hasVarSize: whether the size of ty depends on type parameters.R7,i876,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code14,offsetof-valuem10,R2,L1,V2,R51,R18,R6,s141,unsafe.Offsetof's value of the field at path (an embedded path, field indexes) of struct type\n  base, or nil when the path crosses a pointer.R7,i888,R8,i1,R9,s28,arbace/go/check/code_call.aem10,R2,L1,V5,R3,R4,R21,R46,R52,R6,s55,A call of builtin nm (unsafe: one of package unsafe's).R7,i904,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code9,inst-exprm10,R2,L1,V2,R3,R4,R6,s143,(inst F T...): a generic function's instance, partial when it lacks type arguments (inferred\n  at its call or assignment), or a generic type's.R7,i1237,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code8,func-litm10,R2,L1,V2,R3,R4,R6,s27,(fn params results? body*).R7,i1264,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code13,expr-dispatchm8,R2,L1,V3,R3,R4,R36,R7,i1272,R8,i1,R9,s28,arbace/go/check/code_call.aev20,arbace.go.check.code13,expr-internalm10,R2,L1,V3,R3,R4,R36,R6,s101,An expression, type or builtin of any mode; hint: the element type for an elided\n  composite literal.R7,i1330,R8,i1,R9,s28,arbace/go/check/code_call.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.code$obj_node")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.code$ident")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check.code$literal")

var Lit_4 *jrt.String = jrt.Intern("arbace.go.check.code$byte_string_value")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.code$literal_form")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.code$tail_str")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.check.code$lookup_error")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.check.code$via_names")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.code$path_derefs")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check.code$verify_via_BANG_")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.check.code$method_data_of")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.code$select_expr")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.code$method_expr")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.code$has_call_or_recv_QMARK_")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.code$index_value")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.code$tparam_index")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.check.code$index_expr")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.code$slice_expr")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.check.code$type_assert")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.check.code$receive")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.code$mark_addressed_BANG_")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.check.code$address_of")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.code$indirect")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.check.code$elided_QMARK_")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.code$element_value")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.check.code$key_val")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check.code$indexed_elements")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.code$composite_lit")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check.code$tuple_types")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check.code$results_type")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check.code$spread_QMARK_")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check.code$generic_fn_QMARK_")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check.code$types_str")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.code$inst_say")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.code$record_inst_BANG_")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check.code$instantiate_fn")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.code$func_inst_target")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check.code$spread_QMARK___1")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check.code$call_args")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.code$call_kind")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.code$call_sig")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check.code$finish_call")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check.code$call")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check.code$method_call")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check.code$arg_nodes")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.code$array_ptr_deref")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.check.code$slice_elem")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.check.code$string_or_bytes_QMARK_")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check.code$has_var_size_QMARK_")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.code$offsetof_value")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.code$builtin_call")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.check.code$inst_expr")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check.code$func_lit")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.code$expr_dispatch")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check.code$expr_internal")
