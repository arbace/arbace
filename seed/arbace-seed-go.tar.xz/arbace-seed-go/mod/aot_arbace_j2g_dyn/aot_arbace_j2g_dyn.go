//line aot_arbace_j2g_dyn.ae:1
package aot_arbace_j2g_dyn

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_New() *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyn_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyn_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyn_A_const_1, A_arbace_j2g_dyn_A_const_2, A_arbace_j2g_dyn_A_const_3, A_arbace_j2g_dyn_A_const_4, A_arbace_j2g_dyn_A_const_5, A_arbace_j2g_dyn_A_const_6, A_arbace_j2g_dyn_A_const_7, A_arbace_j2g_dyn_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyn_eval711000008_fn__711000009_A_New() *A_arbace_j2g_dyn_eval711000008_fn__711000009_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000008_fn__711000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_11.GetRawRoot__O()); var tmp2 any; var root_22 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_dyn_A_const_13; if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_22, arg_25) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(), A_arbace_j2g_dyn_A_const_15) }























func A_arbace_j2g_dyn_tag_A_New() *A_arbace_j2g_dyn_tag_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_tag_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_26 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = sym__0; var arg_30 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyn_A_const_17, type__1)); if linked_27 == nil { return ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { return linked_27.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) } }










func A_arbace_j2g_dyn_roots_A_New() *A_arbace_j2g_dyn_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_dyn_roots_A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_dyn_roots_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New(); var tmp2 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class; if


	fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class = fncls__89d; tmp2 = fncls__89d } else { tmp2 = fncls__89 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()) }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New() *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Invoke_O_O__O(self, s__711000014__1 any) any { var tmp1 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(self, s__711000014__1); var tmp2 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class = fncls__88d; tmp2 = fncls__88d } else { tmp2 = fncls__88 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Ctor_O_O(c__iter__711000013, c__s__711000014 any) { t.F_iter__711000013 = c__iter__711000013; t.F_s__711000014 = c__s__711000014 }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Invoke_O__O(self any) any { { var s__711000014__1 any; var t_ any = t.F_s__711000014; t.F_s__711000014 = nil; s__711000014__1 = t_; for { var temp__1927000414__auto____2 any; var root_31 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__711000014__1; if linked_32 == nil { temp__1927000414__auto____2 = ifn_33.Invoke_O__O(arg_34) } else { temp__1927000414__auto____2 = linked_32.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_35 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__711000014__3; if linked_36 == nil { tmp1 = ifn_37.Invoke_O__O(arg_38) } else { tmp1 = linked_36.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_35, arg_38) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_39 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = s__711000014__3; if linked_40 == nil { c__1927001037__auto____4 = ifn_41.Invoke_O__O(arg_42) } else { c__1927001037__auto____4 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_39, arg_42) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000016__6 any; var root_43 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_44 == nil { b__711000016__6 = ifn_45.Invoke_O__O(arg_46) } else { b__711000016__6 = linked_44.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_43, arg_46) }; var tmp2 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(b__711000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_53 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any; var root_58 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = b__711000016__6; if linked_59 == nil { arg_56 = ifn_60.Invoke_O__O(arg_61) } else { arg_56 = linked_59.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_58, arg_61) }; var arg_57 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp5 any; var root_62 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = s__711000014__3; if linked_63 == nil { tmp5 = ifn_64.Invoke_O__O(arg_65) } else { tmp5 = linked_63.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_62, arg_65) }; arg_57 = tmp4.Invoke_O__O(tmp5); if linked_54 == nil { return ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { return linked_54.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) } } else { var root_66 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var root_71 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = b__711000016__6; if linked_72 == nil { arg_69 = ifn_73.Invoke_O__O(arg_74) } else { arg_69 = linked_72.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_71, arg_74) }; var arg_70 any; if linked_67 == nil { return ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { return linked_67.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) } } } else { var vec__711000024__4 any; var root_75 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = s__711000014__3; if linked_76 == nil { vec__711000024__4 = ifn_77.Invoke_O__O(arg_78) } else { vec__711000024__4 = linked_76.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_75, arg_78) }; var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_79 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_16, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()); var arg_83 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp7 any; var root_84 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = s__711000014__3; if linked_85 == nil { tmp7 = ifn_86.Invoke_O__O(arg_87) } else { tmp7 = linked_85.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_84, arg_87) }; arg_83 = tmp6.Invoke_O__O(tmp7); if linked_80 == nil { return ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { return linked_80.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Ctor_O_I_O(c__b__711000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000016 = c__b__711000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Invoke_O__O(self any) any { { var i__711000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_47 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = t.F_b__711000016; var arg_51 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_16, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref()); if linked_48 == nil { ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { linked_48.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; i__711000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000015__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_enabled_QMARK__A_New() *A_arbace_j2g_dyn_enabled_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_enabled_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_90 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_90, arg_93)
	} }
func A_arbace_j2g_dyn_public_QMARK__A_New() *A_arbace_j2g_dyn_public_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_public_QMARK__A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Ctor() {}
//line :47:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_94 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var tmp1 int64; var na_98 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_33; var tmp3 any; var root_100 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = n__0; if linked_101 == nil { tmp3 = ifn_102.Invoke_O__O(arg_103) } else { tmp3 = linked_101.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_100, arg_103) }; na_98 = tmp2.Invoke_O__O(tmp3); var na_99 int64 = 1; if jrt.Long_InstanceOf(na_98) { var n0_104 int64 = jrt.NN(jrt.Long_Cast(na_98)).LongValue__J(); var n1_105 int64 = na_99; tmp1 = n0_104 & n1_105 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_98, na_99) }; arg_97 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_95 == nil { return ifn_96.Invoke_O__O(arg_97) } else { return linked_95.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_94, arg_97) } }

func A_arbace_j2g_dyn_interfaces_A_New() *A_arbace_j2g_dyn_interfaces_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_dyn_interfaces_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_dyn_interfaces_A) Invoke_O_O__O(self, T__0_ any) any { var base__2 any; var root_107 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_109 lang.IFn; if




	linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any; var tmp1 any = A_arbace_j2g_dyn_interfaces_fn__711000034_A_New(); var tmp2 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class = fncls__158d; tmp2 = fncls__158d } else { tmp2 = fncls__158 }; arg_110 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_111 any; var root_159 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_161 lang.IFn; if






	linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = T__0_; var arg_163 any; var root_164 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any; var tmp3 any = A_arbace_j2g_dyn_interfaces_fn__711000036_A_New(); var tmp4 *jrt.Class; var fncls__182 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class; if fncls__182 == nil { var fncls__182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class = fncls__182d; tmp4 = fncls__182d } else { tmp4 = fncls__182 }; arg_167 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_168 any; var root_183 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_185 lang.IFn; if


	linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any; var root_187 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var tmp5 *lang.Keyword = A_arbace_j2g_dyn_A_const_51; var arg_190 any = tmp5.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); if linked_188 == nil { arg_186 = ifn_189.Invoke_O__O(arg_190) } else { arg_186 = linked_188.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_187, arg_190) }; if linked_184 == nil { arg_168 = ifn_185.Invoke_O__O(arg_186) } else { arg_168 = linked_184.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_183, arg_186) }; if /*line :61:1*/ linked_165 == nil { arg_163 = ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { arg_163 = linked_165.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }; if linked_160 == nil { arg_111 = ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { arg_111 = linked_160.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }; if /*line :54:1*/ linked_108 == nil { base__2 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { base__2 = linked_108.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }; var root_191 any =










	A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any; var root_195 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var root_199 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = base__2; var arg_203 any; var iter__1927001039__auto____3 any; var tmp6 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New(); var tmp7 *jrt.Class; var fncls__323 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class; if
	fncls__323 == nil { var fncls__323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class = fncls__323d; tmp7 = fncls__323d } else { tmp7 = fncls__323 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_203 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(base__2); if /*line :65:1*/ linked_200 == nil { arg_198 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { arg_198 = linked_200.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; if linked_196 == nil { arg_194 = ifn_197.Invoke_O__O(arg_198) } else { arg_194 = linked_196.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_195, arg_198) }; if linked_192 == nil { return ifn_193.Invoke_O__O(arg_194) } else { return linked_192.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_191, arg_194) } }
//line :54:1
func A_arbace_j2g_dyn_interfaces_fn__711000034_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000034_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000034_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Ctor() {}
//line :54:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Invoke_O_O__O(self, p1__711000032_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_112 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = p1__711000032_SHARP___1; if linked_113 == nil { and__1927000168__auto____2 = ifn_114.Invoke_O__O(arg_115) } else { and__1927000168__auto____2 = linked_113.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_116 any = A_arbace_j2g_dyn_A_const_37.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, A_arbace_j2g_dyn_public_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = p1__711000032_SHARP___1; if linked_117 == nil { and__1927000168__auto____3 = ifn_118.Invoke_O__O(arg_119) } else { and__1927000168__auto____3 = linked_117.(*A_arbace_j2g_dyn_public_QMARK__A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_120 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_122 lang.IFn

	if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any; var root_124 any = A_arbace_j2g_dyn_A_const_38.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var root_128 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = p1__711000032_SHARP___1; if linked_129 == nil { arg_127 = ifn_130.Invoke_O__O(arg_131) } else { arg_127 = linked_129.(*aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_128, arg_131) }; if linked_125 == nil { arg_123 = ifn_126.Invoke_O__O(arg_127) } else { arg_123 = linked_125.(*aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A).Invoke_O_O__O(root_124, arg_127) }; if linked_121 == nil { and__1927000168__auto____4 = ifn_122.Invoke_O__O(arg_123) } else { and__1927000168__auto____4 = linked_121.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_120, arg_123) }
//line :54:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_132 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_134 lang.IFn



		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; var root_136 any = A_arbace_j2g_dyn_A_const_40.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = p1__711000032_SHARP___1; var arg_140 any = Lit_114; if linked_137 == nil { arg_135 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { arg_135 = linked_137.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; if linked_133 == nil { and__1927000168__auto____5 = ifn_134.Invoke_O__O(arg_135) } else { and__1927000168__auto____5 = linked_133.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_132, arg_135) }
//line :54:1
		if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp1 int64; var na_141 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_33; var tmp3 any; var root_143 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_145 lang.IFn




			if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = p1__711000032_SHARP___1; if linked_144 == nil { tmp3 = ifn_145.Invoke_O__O(arg_146) } else { tmp3 = linked_144.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_143, arg_146) }; na_141 = tmp2.Invoke_O__O(tmp3); var na_142 int64 = 8192; if jrt.Long_InstanceOf(na_141) { var n0_147 int64 = jrt.NN(jrt.Long_Cast(na_141)).LongValue__J(); var n1_148 int64 = na_142; tmp1 = n0_147 & n1_148 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_141, na_142) }; and__1927000168__auto____6 = lang.Numbers_IsZero_J__Z_NoInit(tmp1)
//line :54:1
			if and__1927000168__auto____6 {





				var root_150 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any; var root_154 any = A_arbace_j2g_dyn_A_const_41.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = p1__711000032_SHARP___1; if linked_155 == nil { arg_153 = ifn_156.Invoke_O__O(arg_157) } else { arg_153 = linked_155.(*aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A).Invoke_O_O__O(root_154, arg_157) }; if linked_151 == nil { return ifn_152.Invoke_O__O(arg_153) } else { return linked_151.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_150, arg_153) } } else {
//line :54:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_dyn_interfaces_fn__711000036_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000036_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000036_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Ctor() {}
//line :61:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Invoke_O_O__O(self, p1__711000033_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_169 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = p1__711000033_SHARP___1; if linked_170 == nil { and__1927000168__auto____2 = ifn_171.Invoke_O__O(arg_172) } else { and__1927000168__auto____2 = linked_170.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(and__1927000168__auto____2) {

	var root_173 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var tmp1 *lang.Keyword = A_arbace_j2g_dyn_A_const_45; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_176 any = tmp1.Invoke_O__O(tmp2.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O())); var arg_177 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20); var tmp4 any; var root_178 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = p1__711000033_SHARP___1; if linked_179 == nil { tmp4 = ifn_180.Invoke_O__O(arg_181) } else { tmp4 = linked_179.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_178, arg_181) }; arg_177 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil)).Ref(); if linked_174 == nil { return ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { return linked_174.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_173, arg_176, arg_177) } } else {
//line :61:1
		return and__1927000168__auto____2 } }




func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New() *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Ctor() {}
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Invoke_O_O__O(self, s__711000039__1 any) any { var tmp1 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(self, s__711000039__1); var tmp2 *jrt.Class; var fncls__322 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class; if fncls__322 == nil { var fncls__322d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class = fncls__322d; tmp2 = fncls__322d } else { tmp2 = fncls__322 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Ctor_O_O(c__iter__711000038, c__s__711000039 any) { t.F_iter__711000038 = c__iter__711000038; t.F_s__711000039 = c__s__711000039 }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Invoke_O__O(self any) any { { var s__711000039__1 any; var t_ any = t.F_s__711000039; t.F_s__711000039 = nil; s__711000039__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_204 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = s__711000039__1; if linked_205 == nil { temp__1927000414__auto____2 = ifn_206.Invoke_O__O(arg_207) } else { temp__1927000414__auto____2 = linked_205.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_208 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = xs__1927001018__auto____3; if linked_209 == nil { n__4 = ifn_210.Invoke_O__O(arg_211) } else { n__4 = linked_209.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_208, arg_211) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(n__4); var tmp2 *jrt.Class; var fncls__300 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class; if fncls__300 == nil { var fncls__300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class = fncls__300d; tmp2 = fncls__300d } else { tmp2 = fncls__300 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_301 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_305 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = n__4; if linked_306 == nil { tmp4 = ifn_307.Invoke_O__O(arg_308) } else { tmp4 = linked_306.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_305, arg_308) }; arg_304 = tmp3.Invoke_O__O(tmp4); if linked_302 == nil { fs__1927001036__auto____6 = ifn_303.Invoke_O__O(arg_304) } else { fs__1927001036__auto____6 = linked_302.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_301, arg_304) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_309 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = fs__1927001036__auto____6; var arg_313 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000038); var tmp6 any; var root_314 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = s__711000039__1; if linked_315 == nil { tmp6 = ifn_316.Invoke_O__O(arg_317) } else { tmp6 = linked_315.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_314, arg_317) }; arg_313 = tmp5.Invoke_O__O(tmp6); if linked_310 == nil { return ifn_311.Invoke_O_O__O(arg_312, arg_313) } else { return linked_310.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_309, arg_312, arg_313) } } else { var tmp7 any; var root_318 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = s__711000039__1; if linked_319 == nil { tmp7 = ifn_320.Invoke_O__O(arg_321) } else { tmp7 = linked_319.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_318, arg_321) }; s__711000039__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(p0 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Invoke_O_O__O(self, s__711000041__1 any) any { var tmp1 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(s__711000041__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__299 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class; if fncls__299 == nil { var fncls__299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class = fncls__299d; tmp2 = fncls__299d } else { tmp2 = fncls__299 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Ctor_O_O_O(c__s__711000041, c__n, c__iter__711000040 any) { t.F_s__711000041 = c__s__711000041; t.F_n = c__n; t.F_iter__711000040 = c__iter__711000040 }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Invoke_O__O(self any) any { { var s__711000041__1 any; var t_ any = t.F_s__711000041; t.F_s__711000041 = nil; s__711000041__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_212 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = s__711000041__1; if linked_213 == nil { temp__1927000414__auto____2 = ifn_214.Invoke_O__O(arg_215) } else { temp__1927000414__auto____2 = linked_213.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_212, arg_215) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000041__3 any = temp__1927000414__auto____2; var tmp1 any; var root_216 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = s__711000041__3; if linked_217 == nil { tmp1 = ifn_218.Invoke_O__O(arg_219) } else { tmp1 = linked_217.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_216, arg_219) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_220 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = s__711000041__3; if linked_221 == nil { c__1927001037__auto____4 = ifn_222.Invoke_O__O(arg_223) } else { c__1927001037__auto____4 = linked_221.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_220, arg_223) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000043__6 any; var root_224 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_225 == nil { b__711000043__6 = ifn_226.Invoke_O__O(arg_227) } else { b__711000043__6 = linked_225.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_224, arg_227) }; var tmp2 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(t.F_n, b__711000043__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__246 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class; if fncls__246 == nil { var fncls__246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class = fncls__246d; tmp3 = fncls__246d } else { tmp3 = fncls__246 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_247 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any; var root_252 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = b__711000043__6; if linked_253 == nil { arg_250 = ifn_254.Invoke_O__O(arg_255) } else { arg_250 = linked_253.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_252, arg_255) }; var arg_251 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp5 any; var root_256 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = s__711000041__3; if linked_257 == nil { tmp5 = ifn_258.Invoke_O__O(arg_259) } else { tmp5 = linked_257.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_256, arg_259) }; arg_251 = tmp4.Invoke_O__O(tmp5); if linked_248 == nil { return ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { return linked_248.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_247, arg_250, arg_251) } } else { var root_260 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var root_265 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = b__711000043__6; if linked_266 == nil { arg_263 = ifn_267.Invoke_O__O(arg_268) } else { arg_263 = linked_266.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_265, arg_268) }; var arg_264 any; if linked_261 == nil { return ifn_262.Invoke_O_O__O(arg_263, arg_264) } else { return linked_261.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_260, arg_263, arg_264) } } } else { var s__4 any; var root_269 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = s__711000041__3; if linked_270 == nil { s__4 = ifn_271.Invoke_O__O(arg_272) } else { s__4 = linked_270.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_269, arg_272) }; var tmp6 any; var and__1927000168__auto____5 any; var root_273 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_275 lang.IFn
																			if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__4; var arg_277 any = t.F_n; if linked_274 == nil { and__1927000168__auto____5 = ifn_275.Invoke_O_O__O(arg_276, arg_277) } else { and__1927000168__auto____5 = linked_274.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_273, arg_276, arg_277) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_278 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = s__4; if linked_279 == nil { and__1927000168__auto____6 = ifn_280.Invoke_O__O(arg_281) } else { and__1927000168__auto____6 = linked_279.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_278, arg_281) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_282 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = s__4; if linked_283 == nil { tmp6 = ifn_284.Invoke_O__O(arg_285) } else { tmp6 = linked_283.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_282, arg_285) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :66:1
	if jrt.J2g_Truth(tmp6) { var root_286 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = s__4; var arg_290 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp8 any; var root_291 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = s__711000041__3; if linked_292 == nil { tmp8 = ifn_293.Invoke_O__O(arg_294) } else { tmp8 = linked_292.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_291, arg_294) }; arg_290 = tmp7.Invoke_O__O(tmp8); if linked_287 == nil { return ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { return linked_287.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_286, arg_289, arg_290) } } else { var tmp9 any; var root_295 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = s__711000041__3; if linked_296 == nil { tmp9 = ifn_297.Invoke_O__O(arg_298) } else { tmp9 = linked_296.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_295, arg_298) }; s__711000041__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Ctor_O_O_I_O(c__n, c__b__711000043 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000043 = c__b__711000043; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Invoke_O__O(self any) any { { var i__711000042__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000042__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000042__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_228 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_230 lang.IFn
																					if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = s__2; var arg_232 any = t.F_n; if linked_229 == nil { and__1927000168__auto____3 = ifn_230.Invoke_O_O__O(arg_231, arg_232) } else { and__1927000168__auto____3 = linked_229.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_228, arg_231, arg_232) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_233 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = s__2; if linked_234 == nil { and__1927000168__auto____4 = ifn_235.Invoke_O__O(arg_236) } else { and__1927000168__auto____4 = linked_234.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_233, arg_236) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_237 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = s__2; if linked_238 == nil { tmp2 = ifn_239.Invoke_O__O(arg_240) } else { tmp2 = linked_238.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_237, arg_240) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :66:1
	if jrt.J2g_Truth(tmp2) { var root_241 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = t.F_b__711000043; var arg_245 any = s__2; if linked_242 == nil { ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { linked_242.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }; i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } else { i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_slot_keys_A_New() *A_arbace_j2g_dyn_slot_keys_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Ctor() {}
//line :70:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Invoke_O_O__O(self, ifaces__0 any) any { var ks__2 any; var root_324 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_326 lang.IFn; if


	linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_328 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New(); var tmp2 *jrt.Class; var fncls__433 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class; if fncls__433 == nil { var fncls__433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class = fncls__433d; tmp2 = fncls__433d } else { tmp2 = fncls__433 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_331 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(ifaces__0); if linked_329 == nil { arg_327 = ifn_330.Invoke_O__O(arg_331) } else { arg_327 = linked_329.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_328, arg_331) }; if linked_325 == nil { ks__2 = ifn_326.Invoke_O__O(arg_327) } else { ks__2 = linked_325.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_324, arg_327) }; var root_434 any =
	A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any; var root_438 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(); var arg_442 any = ks__2; if linked_439 == nil { arg_437 = ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { arg_437 = linked_439.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) }; if linked_435 == nil { return ifn_436.Invoke_O__O(arg_437) } else { return linked_435.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_434, arg_437) } }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Invoke_O_O__O(self, s__711000056__1 any) any { var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(s__711000056__1, self); var tmp2 *jrt.Class; var fncls__432 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class; if fncls__432 == nil { var fncls__432d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class = fncls__432d; tmp2 = fncls__432d } else { tmp2 = fncls__432 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Ctor_O_O(c__s__711000056, c__iter__711000055 any) { t.F_s__711000056 = c__s__711000056; t.F_iter__711000055 = c__iter__711000055 }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Invoke_O__O(self any) any { { var s__711000056__1 any; var t_ any = t.F_s__711000056; t.F_s__711000056 = nil; s__711000056__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_332 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = s__711000056__1; if linked_333 == nil { temp__1927000414__auto____2 = ifn_334.Invoke_O__O(arg_335) } else { temp__1927000414__auto____2 = linked_333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_332, arg_335) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var j__4 any; var root_336 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = xs__1927001018__auto____3; if linked_337 == nil { j__4 = ifn_338.Invoke_O__O(arg_339) } else { j__4 = linked_337.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_336, arg_339) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New(); var tmp2 *jrt.Class; var fncls__410 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class; if fncls__410 == nil { var fncls__410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class = fncls__410d; tmp2 = fncls__410d } else { tmp2 = fncls__410 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_411 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_415 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = j__4; if linked_416 == nil { tmp4 = ifn_417.Invoke_O__O(arg_418) } else { tmp4 = linked_416.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_415, arg_418) }; arg_414 = tmp3.Invoke_O__O(tmp4); if linked_412 == nil { fs__1927001036__auto____6 = ifn_413.Invoke_O__O(arg_414) } else { fs__1927001036__auto____6 = linked_412.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_411, arg_414) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_419 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = fs__1927001036__auto____6; var arg_423 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000055); var tmp6 any; var root_424 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = s__711000056__1; if linked_425 == nil { tmp6 = ifn_426.Invoke_O__O(arg_427) } else { tmp6 = linked_425.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_424, arg_427) }; arg_423 = tmp5.Invoke_O__O(tmp6); if linked_420 == nil { return ifn_421.Invoke_O_O__O(arg_422, arg_423) } else { return linked_420.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_419, arg_422, arg_423) } } else { var tmp7 any; var root_428 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = s__711000056__1; if linked_429 == nil { tmp7 = ifn_430.Invoke_O__O(arg_431) } else { tmp7 = linked_429.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_428, arg_431) }; s__711000056__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Invoke_O_O__O(self, s__711000058__1 any) any { var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(self, s__711000058__1); var tmp2 *jrt.Class; var fncls__409 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class; if fncls__409 == nil { var fncls__409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class = fncls__409d; tmp2 = fncls__409d } else { tmp2 = fncls__409 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Ctor_O_O(c__iter__711000057, c__s__711000058 any) { t.F_iter__711000057 = c__iter__711000057; t.F_s__711000058 = c__s__711000058 }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Invoke_O__O(self any) any { { var s__711000058__1 any; var t_ any = t.F_s__711000058; t.F_s__711000058 = nil; s__711000058__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_340 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = s__711000058__1; if linked_341 == nil { temp__1927000414__auto____2 = ifn_342.Invoke_O__O(arg_343) } else { temp__1927000414__auto____2 = linked_341.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_340, arg_343) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000058__3 any = temp__1927000414__auto____2; var tmp1 any; var root_344 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = s__711000058__3; if linked_345 == nil { tmp1 = ifn_346.Invoke_O__O(arg_347) } else { tmp1 = linked_345.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_344, arg_347) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_348 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = s__711000058__3; if linked_349 == nil { c__1927001037__auto____4 = ifn_350.Invoke_O__O(arg_351) } else { c__1927001037__auto____4 = linked_349.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_348, arg_351) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000060__6 any; var root_352 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_353 == nil { b__711000060__6 = ifn_354.Invoke_O__O(arg_355) } else { b__711000060__6 = linked_353.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_352, arg_355) }; var tmp2 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(b__711000060__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__365 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class; if fncls__365 == nil { var fncls__365d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class = fncls__365d; tmp3 = fncls__365d } else { tmp3 = fncls__365 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_366 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any; var root_371 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = b__711000060__6; if linked_372 == nil { arg_369 = ifn_373.Invoke_O__O(arg_374) } else { arg_369 = linked_372.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_371, arg_374) }; var arg_370 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp5 any; var root_375 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = s__711000058__3; if linked_376 == nil { tmp5 = ifn_377.Invoke_O__O(arg_378) } else { tmp5 = linked_376.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_375, arg_378) }; arg_370 = tmp4.Invoke_O__O(tmp5); if linked_367 == nil { return ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { return linked_367.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) } } else { var root_379 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any; var root_384 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = b__711000060__6; if linked_385 == nil { arg_382 = ifn_386.Invoke_O__O(arg_387) } else { arg_382 = linked_385.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_384, arg_387) }; var arg_383 any; if linked_380 == nil { return ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { return linked_380.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) } } } else { var vec__711000070__4 any; var root_388 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = s__711000058__3; if linked_389 == nil { vec__711000070__4 = ifn_390.Invoke_O__O(arg_391) } else { vec__711000070__4 = linked_389.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_388, arg_391) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_392 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_394 lang.IFn; _ = ___6; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__5); if linked_393 == nil { tmp6 = ifn_394.Invoke_O__O(arg_395) } else { tmp6 = linked_393.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_392, arg_395) }; if jrt.J2g_Truth(tmp6) { var root_396 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = k__5; var arg_400 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp8 any; var root_401 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = s__711000058__3; if linked_402 == nil { tmp8 = ifn_403.Invoke_O__O(arg_404) } else { tmp8 = linked_402.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_401, arg_404) }; arg_400 = tmp7.Invoke_O__O(tmp8); if linked_397 == nil { return ifn_398.Invoke_O_O__O(arg_399, arg_400) } else { return linked_397.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_396, arg_399, arg_400) } } else { var tmp9 any; var root_405 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = s__711000058__3; if linked_406 == nil { tmp9 = ifn_407.Invoke_O__O(arg_408) } else { tmp9 = linked_406.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_405, arg_408) }; s__711000058__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Ctor_O_I_O(c__b__711000060 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000060 = c__b__711000060; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Invoke_O__O(self any) any { { var i__711000059__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000059__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000066__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000059__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_356 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_358 lang.IFn; _ = ___4; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__3); if linked_357 == nil { tmp2 = ifn_358.Invoke_O__O(arg_359) } else { tmp2 = linked_357.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_356, arg_359) }; if jrt.J2g_Truth(tmp2) { var root_360 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = t.F_b__711000060; var arg_364 any = k__3; if linked_361 == nil { ifn_362.Invoke_O_O__O(arg_363, arg_364) } else { linked_361.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_360, arg_363, arg_364) }; i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } else { i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_declarers_A_New() *A_arbace_j2g_dyn_declarers_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_j2g_dyn_declarers_A) Ctor() {}
//line :78:1
func (t *A_arbace_j2g_dyn_declarers_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var vec__711000078__3 any; var root_443 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_445 lang.IFn; if




	linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); if linked_444 == nil { vec__711000078__3 = ifn_445.Invoke_O__O(arg_446) } else { vec__711000078__3 = linked_444.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_443, arg_446) }; var i__4 any = /*line :78:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; if





	lang.Util_Identical_O_O__Z_NoInit(i__4, ifaces__0) { tmp1 = ix__5 } else { var lockee__1927000360__auto____6 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var tmp2 any = A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(ifaces__0, lockee__1927000360__auto____6); var tmp3 *jrt.Class
		var fncls__580 /*line :84:1*/*jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class

		if fncls__580 == nil { var fncls__580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class = fncls__580d; tmp3 = fncls__580d } else { tmp3 = fncls__580 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }; return /*line :84:1*/ lang.RT_Get_O_O__O_NoInit(tmp1, k__1) }

func A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Ctor_O_O(c__ifaces, c__lockee__1927000360__auto__ any) { t.F_ifaces = c__ifaces; t.F_lockee__1927000360__auto__ = c__lockee__1927000360__auto__ }
//line :86:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Invoke_O__O(self any) any { var locklocal__1927000361__auto____3 any; var t_ any = t.F_lockee__1927000360__auto__; t.F_lockee__1927000360__auto__ = nil; locklocal__1927000361__auto____3 = t_; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____3); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__711000082__6 any; var root_447 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_449 lang.IFn
										if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); if linked_448 == nil { vec__711000082__6 = ifn_449.Invoke_O__O(arg_450) } else { vec__711000082__6 = linked_448.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_447, arg_450) }
//line :86:1
	var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(1), nil)

	if lang.Util_Identical_O_O__Z_NoInit(i__7, t.F_ifaces) { tmp1 = ix__8 } else { var ix__9 any; var root_451 any = A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_453 lang.IFn

		if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any; var tmp2 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New(); var tmp3 *jrt.Class; var fncls__574 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class; if fncls__574 == nil { var fncls__574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class = fncls__574d; tmp3 = fncls__574d } else { tmp3 = fncls__574 }; arg_454 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_455 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_456 any = t.F_ifaces; if linked_452 == nil { ix__9 = ifn_453.Invoke_O_O_O__O(arg_454, arg_455, arg_456) } else { ix__9 = linked_452.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_451, arg_454, arg_455, arg_456)
		}




		var root_575 any = A_arbace_j2g_dyn_A_const_67.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var arg_579 any; var tmp4 any; var t__2 any = t.F_ifaces; t.F_ifaces = nil; tmp4 = t__2; arg_579 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, ix__9); if linked_576 == nil { ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { linked_576.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_575, arg_578, arg_579) }
//line :88:1
		tmp1 = ix__9 } }; return nil }(); /*line :86:1*/lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____3); if tmp5 != nil { panic(tmp5) }; return tmp1 }



func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Invoke_O_O_O__O(self, ix__1, j__2 any) any {
	var root_457 any = A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(j__2); var tmp2 *jrt.Class; var fncls__475 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class; if fncls__475 == nil { var fncls__475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class = fncls__475d; tmp2 = fncls__475d } else { tmp2 = fncls__475 }; arg_460 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_461 any = ix__1; var arg_462 any; var root_476 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_478 lang.IFn

	if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New(); var tmp4 *jrt.Class; var fncls__569 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class; if fncls__569 == nil { var fncls__569d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class = fncls__569d; tmp4 = fncls__569d } else { tmp4 = fncls__569 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp6 any; var root_570 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = j__2; if linked_571 == nil { tmp6 = ifn_572.Invoke_O__O(arg_573) } else { tmp6 = linked_571.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_570, arg_573) }; arg_479 = tmp5.Invoke_O__O(tmp6); if linked_477 == nil { arg_462 = ifn_478.Invoke_O__O(arg_479) } else { arg_462 = linked_477.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_476, arg_479) }
//line :91:1
	if linked_458 == nil { return ifn_459.Invoke_O_O_O__O(arg_460, arg_461, arg_462) } else { return linked_458.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_457, arg_460, arg_461, arg_462) } }
//line :91:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(p0 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A{}; t.Ctor_O(p0); return t }
//line :91:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Ctor_O(c__j any) { t.F_j = c__j }
//line :91:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Invoke_O_O_O__O(self, ix__1, kk__2 any) any { var root_463 any = A_arbace_j2g_dyn_A_const_62.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = ix__1; var arg_467 any = kk__2; var arg_468 any; var root_470 any = A_arbace_j2g_dyn_A_const_63.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(); var arg_474 any = lang.PersistentVector_EMPTY.Ref(); if linked_471 == nil { arg_468 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { arg_468 = linked_471.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; var arg_469 any = t.F_j; if linked_464 == nil { return ifn_465.Invoke_O_O_O_O__O(arg_466, arg_467, arg_468, arg_469) } else { return linked_464.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_463, arg_466, arg_467, arg_468, arg_469) } }

func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Invoke_O_O__O(self, s__711000089__1 any) any { var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(s__711000089__1, self); var tmp2 *jrt.Class; var fncls__568 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class; if fncls__568 == nil { var fncls__568d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class = fncls__568d; tmp2 = fncls__568d } else { tmp2 = fncls__568 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Ctor_O_O(c__s__711000089, c__iter__711000088 any) { t.F_s__711000089 = c__s__711000089; t.F_iter__711000088 = c__iter__711000088 }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Invoke_O__O(self any) any { { var s__711000089__1 any; var t_ any = t.F_s__711000089; t.F_s__711000089 = nil; s__711000089__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_480 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = s__711000089__1; if linked_481 == nil { temp__1927000414__auto____2 = ifn_482.Invoke_O__O(arg_483) } else { temp__1927000414__auto____2 = linked_481.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_480, arg_483) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_484 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = xs__1927001018__auto____3; if linked_485 == nil { c__4 = ifn_486.Invoke_O__O(arg_487) } else { c__4 = linked_485.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_484, arg_487) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New(); var tmp2 *jrt.Class; var fncls__546 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class; if fncls__546 == nil { var fncls__546d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class = fncls__546d; tmp2 = fncls__546d } else { tmp2 = fncls__546 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_547 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_551 any = A_arbace_j2g_dyn_A_const_66.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = c__4; if linked_552 == nil { tmp4 = ifn_553.Invoke_O__O(arg_554) } else { tmp4 = linked_552.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_551, arg_554) }; arg_550 = tmp3.Invoke_O__O(tmp4); if linked_548 == nil { fs__1927001036__auto____6 = ifn_549.Invoke_O__O(arg_550) } else { fs__1927001036__auto____6 = linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_555 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = fs__1927001036__auto____6; var arg_559 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000088); var tmp6 any; var root_560 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = s__711000089__1; if linked_561 == nil { tmp6 = ifn_562.Invoke_O__O(arg_563) } else { tmp6 = linked_561.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_560, arg_563) }; arg_559 = tmp5.Invoke_O__O(tmp6); if linked_556 == nil { return ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { return linked_556.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_555, arg_558, arg_559) } } else { var tmp7 any; var root_564 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__711000089__1; if linked_565 == nil { tmp7 = ifn_566.Invoke_O__O(arg_567) } else { tmp7 = linked_565.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_564, arg_567) }; s__711000089__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Invoke_O_O__O(self, s__711000091__1 any) any { var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(self, s__711000091__1); var tmp2 *jrt.Class; var fncls__545 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class; if fncls__545 == nil { var fncls__545d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class = fncls__545d; tmp2 = fncls__545d } else { tmp2 = fncls__545 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Ctor_O_O(c__iter__711000090, c__s__711000091 any) { t.F_iter__711000090 = c__iter__711000090; t.F_s__711000091 = c__s__711000091 }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Invoke_O__O(self any) any { { var s__711000091__1 any; var t_ any = t.F_s__711000091; t.F_s__711000091 = nil; s__711000091__1 = t_; for { var temp__1927000414__auto____2 any; var root_488 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = s__711000091__1; if linked_489 == nil { temp__1927000414__auto____2 = ifn_490.Invoke_O__O(arg_491) } else { temp__1927000414__auto____2 = linked_489.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_488, arg_491) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000091__3 any = temp__1927000414__auto____2; var tmp1 any; var root_492 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = s__711000091__3; if linked_493 == nil { tmp1 = ifn_494.Invoke_O__O(arg_495) } else { tmp1 = linked_493.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_492, arg_495) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_496 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = s__711000091__3; if linked_497 == nil { c__1927001037__auto____4 = ifn_498.Invoke_O__O(arg_499) } else { c__1927001037__auto____4 = linked_497.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_496, arg_499) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000093__6 any; var root_500 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_501 == nil { b__711000093__6 = ifn_502.Invoke_O__O(arg_503) } else { b__711000093__6 = linked_501.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_500, arg_503) }; var tmp2 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(b__711000093__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__509 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class; if fncls__509 == nil { var fncls__509d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class = fncls__509d; tmp3 = fncls__509d } else { tmp3 = fncls__509 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_510 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any; var root_515 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = b__711000093__6; if linked_516 == nil { arg_513 = ifn_517.Invoke_O__O(arg_518) } else { arg_513 = linked_516.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_515, arg_518) }; var arg_514 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp5 any; var root_519 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = s__711000091__3; if linked_520 == nil { tmp5 = ifn_521.Invoke_O__O(arg_522) } else { tmp5 = linked_520.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_519, arg_522) }; arg_514 = tmp4.Invoke_O__O(tmp5); if linked_511 == nil { return ifn_512.Invoke_O_O__O(arg_513, arg_514) } else { return linked_511.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_510, arg_513, arg_514) } } else { var root_523 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var root_528 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = b__711000093__6; if linked_529 == nil { arg_526 = ifn_530.Invoke_O__O(arg_531) } else { arg_526 = linked_529.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_528, arg_531) }; var arg_527 any; if linked_524 == nil { return ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { return linked_524.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) } } } else { var mm__4 any; var root_532 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = s__711000091__3; if linked_533 == nil { mm__4 = ifn_534.Invoke_O__O(arg_535) } else { mm__4 = linked_533.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_532, arg_535) }; var root_536 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4)); var arg_540 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp7 any; var root_541 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = s__711000091__3; if linked_542 == nil { tmp7 = ifn_543.Invoke_O__O(arg_544) } else { tmp7 = linked_542.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_541, arg_544) }; arg_540 = tmp6.Invoke_O__O(tmp7); if linked_537 == nil { return ifn_538.Invoke_O_O__O(arg_539, arg_540) } else { return linked_537.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_536, arg_539, arg_540) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Ctor_O_I_O(c__b__711000093 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000093 = c__b__711000093; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Invoke_O__O(self any) any { { var i__711000092__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000092__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000092__1)); var root_504 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = t.F_b__711000093; var arg_508 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2)); if linked_505 == nil { ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { linked_505.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) }; i__711000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000092__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_dyn_defaults_for_A_New() *A_arbace_j2g_dyn_defaults_for_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var cands__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(k__1); var tmp2 *jrt.Class; var fncls__699 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class; if


	fncls__699 == nil { var fncls__699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class = fncls__699d; tmp2 = fncls__699d } else { tmp2 = fncls__699 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_710 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, A_arbace_j2g_dyn_declarers_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = ifaces__0; var arg_714 any = k__1; if linked_711 == nil { tmp4 = ifn_712.Invoke_O_O__O(arg_713, arg_714) } else { tmp4 = linked_711.(*A_arbace_j2g_dyn_declarers_A).Invoke_O_O_O__O(root_710, arg_713, arg_714) }; cands__3 = tmp3.Invoke_O__O(tmp4); var root_700 any =



	A_arbace_j2g_dyn_A_const_76.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any; var tmp5 any = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New(); var tmp6 *jrt.Class; var fncls__709 *jrt.Class = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class; if fncls__709 == nil { var fncls__709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class = fncls__709d; tmp6 = fncls__709d } else { tmp6 = fncls__709 }; arg_703 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_704 any = cands__3; if linked_701 == nil { return ifn_702.Invoke_O_O__O(arg_703, arg_704) } else { return linked_701.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_700, arg_703, arg_704) } }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(p0 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Invoke_O_O__O(self, s__711000108__1 any) any { var tmp1 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(self, t.F_k, s__711000108__1); var tmp2 *jrt.Class; var fncls__698 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class; if fncls__698 == nil { var fncls__698d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class = fncls__698d; tmp2 = fncls__698d } else { tmp2 = fncls__698 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Ctor_O_O_O(c__iter__711000107, c__k, c__s__711000108 any) { t.F_iter__711000107 = c__iter__711000107; t.F_k = c__k; t.F_s__711000108 = c__s__711000108 }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Invoke_O__O(self any) any { { var s__711000108__1 any; var t_ any = t.F_s__711000108; t.F_s__711000108 = nil; s__711000108__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_581 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = s__711000108__1; if linked_582 == nil { temp__1927000414__auto____2 = ifn_583.Invoke_O__O(arg_584) } else { temp__1927000414__auto____2 = linked_582.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_581, arg_584) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000108__3 any = temp__1927000414__auto____2; var tmp1 any; var root_585 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = s__711000108__3; if linked_586 == nil { tmp1 = ifn_587.Invoke_O__O(arg_588) } else { tmp1 = linked_586.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_585, arg_588) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_589 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = s__711000108__3; if linked_590 == nil { c__1927001037__auto____4 = ifn_591.Invoke_O__O(arg_592) } else { c__1927001037__auto____4 = linked_590.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_589, arg_592) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000110__6 any; var root_593 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_594 == nil { b__711000110__6 = ifn_595.Invoke_O__O(arg_596) } else { b__711000110__6 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_593, arg_596) }; var tmp2 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(t.F_k, b__711000110__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__630 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class; if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class = fncls__630d; tmp3 = fncls__630d } else { tmp3 = fncls__630 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_631 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any; var root_636 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = b__711000110__6; if linked_637 == nil { arg_634 = ifn_638.Invoke_O__O(arg_639) } else { arg_634 = linked_637.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_636, arg_639) }; var arg_635 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp5 any; var root_640 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = s__711000108__3; if linked_641 == nil { tmp5 = ifn_642.Invoke_O__O(arg_643) } else { tmp5 = linked_641.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_640, arg_643) }; arg_635 = tmp4.Invoke_O__O(tmp5); if linked_632 == nil { return ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { return linked_632.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_631, arg_634, arg_635) } } else { var root_644 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any; var root_649 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = b__711000110__6; if linked_650 == nil { arg_647 = ifn_651.Invoke_O__O(arg_652) } else { arg_647 = linked_650.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_649, arg_652) }; var arg_648 any; if linked_645 == nil { return ifn_646.Invoke_O_O__O(arg_647, arg_648) } else { return linked_645.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_644, arg_647, arg_648) } } } else { var j__4 any; var root_653 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = s__711000108__3; if linked_654 == nil { j__4 = ifn_655.Invoke_O__O(arg_656) } else { j__4 = linked_654.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_653, arg_656) }; var impl__5 any; var root_657 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_659 lang.IFn
														if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = j__4; var arg_661 any = t.F_k; if linked_658 == nil { impl__5 = ifn_659.Invoke_O_O__O(arg_660, arg_661) } else { impl__5 = linked_658.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_657, arg_660, arg_661) }
//line :103:1
	var tmp6 any
	var and__1927000168__auto____6 any = impl__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp7 any = A_arbace_j2g_dyn_A_const_69; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__5)); if and__1927000168__auto____7 { var root_662 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__5); if linked_663 == nil { tmp6 = ifn_664.Invoke_O__O(arg_665) } else { tmp6 = linked_663.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_662, arg_665) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = and__1927000168__auto____6 }
//line :103:1
	if jrt.J2g_Truth(tmp6) { var root_666 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any; var tmp8 any; var root_671 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_673 lang.IFn


		if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = A_arbace_j2g_dyn_A_const_73; var arg_675 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__5); var arg_676 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp10 any; var root_677 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any; var root_682 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = t.F_k; if linked_683 == nil { arg_680 = ifn_684.Invoke_O__O(arg_685) } else { arg_680 = linked_683.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_682, arg_685) }; var arg_681 any; var root_686 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = t.F_k; if linked_687 == nil { arg_681 = ifn_688.Invoke_O__O(arg_689) } else { arg_681 = linked_687.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_686, arg_689) }; if linked_678 == nil { tmp10 = ifn_679.Invoke_O_O__O(arg_680, arg_681) } else { tmp10 = linked_678.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_677, arg_680, arg_681) }; arg_676 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_672 == nil { tmp8 = ifn_673.Invoke_O_O_O__O(arg_674, arg_675, arg_676) } else { tmp8 = linked_672.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_671, arg_674, arg_675, arg_676) }
//line :103:1
		arg_669 = lang.Tuple_Create_O_O__IPersistentVector(j__4, tmp8); var arg_670 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp12 any; var root_690 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = s__711000108__3; if linked_691 == nil { tmp12 = ifn_692.Invoke_O__O(arg_693) } else { tmp12 = linked_691.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_690, arg_693) }; arg_670 = tmp11.Invoke_O__O(tmp12); if linked_667 == nil { return ifn_668.Invoke_O_O__O(arg_669, arg_670) } else { return linked_667.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_666, arg_669, arg_670) } } else { var tmp13 any; var root_694 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = s__711000108__3; if linked_695 == nil { tmp13 = ifn_696.Invoke_O__O(arg_697) } else { tmp13 = linked_695.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_694, arg_697) }; s__711000108__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Ctor_O_O_I_O(c__k, c__b__711000110 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_b__711000110 = c__b__711000110; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Invoke_O__O(self any) any { { var i__711000109__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000109__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000109__1)); var impl__3 any; var root_597 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_599 lang.IFn
																if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = j__2; var arg_601 any = t.F_k; if linked_598 == nil { impl__3 = ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { impl__3 = linked_598.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }
//line :103:1
	var tmp2 any
	var and__1927000168__auto____4 any = impl__3
	if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp3 any = A_arbace_j2g_dyn_A_const_69; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__3)); if and__1927000168__auto____5 { var root_602 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__3); if linked_603 == nil { tmp2 = ifn_604.Invoke_O__O(arg_605) } else { tmp2 = linked_603.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_602, arg_605) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = and__1927000168__auto____4 }
//line :103:1
	if jrt.J2g_Truth(tmp2) { var root_606 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = t.F_b__711000110; var arg_610 any; var tmp4 any; var root_611 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_613 lang.IFn


		if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = A_arbace_j2g_dyn_A_const_73; var arg_615 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__3); var arg_616 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp6 any; var root_617 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any; var root_622 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = t.F_k; if linked_623 == nil { arg_620 = ifn_624.Invoke_O__O(arg_625) } else { arg_620 = linked_623.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_622, arg_625) }; var arg_621 any; var root_626 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = t.F_k; if linked_627 == nil { arg_621 = ifn_628.Invoke_O__O(arg_629) } else { arg_621 = linked_627.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_626, arg_629) }; if linked_618 == nil { tmp6 = ifn_619.Invoke_O_O__O(arg_620, arg_621) } else { tmp6 = linked_618.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_617, arg_620, arg_621) }; arg_616 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_612 == nil { tmp4 = ifn_613.Invoke_O_O_O__O(arg_614, arg_615, arg_616) } else { tmp4 = linked_612.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_611, arg_614, arg_615, arg_616) }
//line :103:1
		arg_610 = lang.Tuple_Create_O_O__IPersistentVector(j__2, tmp4); if linked_607 == nil { ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { linked_607.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) }; i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } else { i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New() *A_arbace_j2g_dyn_defaults_for_fn__711000118_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_fn__711000118_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Ctor() {}
//line :107:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Invoke_O_O__O(self, p__711000117__1 any) any { var vec__711000119__2 any = p__711000117__1; var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000119__2, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_705 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = j__3; if linked_706 == nil { tmp1 = ifn_707.Invoke_O__O(arg_708) } else { tmp1 = linked_706.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_705, arg_708) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp1)))).Ref() }

func A_arbace_j2g_dyn_box_arg_A_New() *A_arbace_j2g_dyn_box_arg_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_box_arg_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_dyn_box_arg_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_dyn_box_arg_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {


	var tmp1 any; var root_715 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = d__1; if linked_716 == nil { tmp1 = ifn_717.Invoke_O__O(arg_718) } else { tmp1 = linked_716.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_715, arg_718) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_82, p__0) } else { var tmp2 any; var root_719 any = A_arbace_j2g_dyn_A_const_80.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_721 lang.IFn
		if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = d__1; if linked_720 == nil { tmp2 = ifn_721.Invoke_O__O(arg_722) } else { tmp2 = linked_720.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_719, arg_722) }
//line :112:1
		if jrt.J2g_Truth(tmp2) {
			return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_83, p__0) } else {
//line :112:1
				if A_arbace_j2g_dyn_A_const_81 != nil { return p__0 } else { return nil
				}
			}
	} }
func A_arbace_j2g_dyn_convert_result_A_New() *A_arbace_j2g_dyn_convert_result_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_dyn_convert_result_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_dyn_convert_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_10) { return r__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1)) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any; var root_776 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = A_arbace_j2g_dyn_A_const_73; var arg_780 any = Lit_16; var arg_781 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp4 any; var root_782 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_784 lang.IFn; if linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1); var arg_786 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref(); if linked_783 == nil { tmp4 = ifn_784.Invoke_O_O__O(arg_785, arg_786) } else { tmp4 = linked_783.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_782, arg_785, arg_786) }; arg_781 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_777 == nil { tmp2 = ifn_778.Invoke_O_O_O__O(arg_779, arg_780, arg_781) } else { tmp2 = linked_777.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_776, arg_779, arg_780, arg_781) }; return tmp1.Invoke_O_O__O(tmp2, r__0) } else {
//line :119:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_84).Invoke_O__O(d__1)) {


				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_94; var tmp7 any; var root_787 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = A_arbace_j2g_dyn_A_const_73; var arg_791 any = d__1; if linked_788 == nil { tmp7 = ifn_789.Invoke_O_O__O(arg_790, arg_791) } else { tmp7 = linked_788.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_787, arg_790, arg_791) }; var tmp8 any = tmp7; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_96; var tmp11 any
				if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_18) { tmp11 = A_arbace_j2g_dyn_A_const_97 } else { tmp11 = A_arbace_j2g_dyn_A_const_98 }
//line :122:1
				return tmp5.Invoke_O_O_O__O(tmp6, tmp8, tmp9.Invoke_O_O_O__O(tmp10, tmp11, r__0)) } else {
//line :119:1
					var tmp12 any; var root_723 any = A_arbace_j2g_dyn_A_const_85.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_725 lang.IFn




					if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = d__1; if linked_724 == nil { tmp12 = ifn_725.Invoke_O__O(arg_726) } else { tmp12 = linked_724.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_723, arg_726) }
//line :119:1
					if jrt.J2g_Truth(tmp12) {




						var root_727 any = A_arbace_j2g_dyn_A_const_86.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = A_arbace_j2g_dyn_A_const_73; var arg_731 any = A_arbace_j2g_dyn_A_const_87; var arg_732 any = r__0; var arg_733 any = d__1; var arg_734 any; var e__3 any; var root_735 any = A_arbace_j2g_dyn_A_const_88.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_737 lang.IFn
						if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = d__1; if linked_736 == nil { e__3 = ifn_737.Invoke_O__O(arg_738) } else { e__3 = linked_736.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_735, arg_738) }
						var tmp13 any; var root_739 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = e__3; if linked_740 == nil { tmp13 = ifn_741.Invoke_O__O(arg_742) } else { tmp13 = linked_740.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_739, arg_742) }; if jrt.J2g_Truth(tmp13) { arg_734 = nil } else {
							var tmp14 any = A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(e__3); var tmp15 *jrt.Class; var fncls__775 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class; if fncls__775 == nil { var fncls__775d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class = fncls__775d; tmp15 = fncls__775d } else { tmp15 = fncls__775 }; arg_734 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O() }
//line :124:1
						if linked_728 == nil { return ifn_729.Invoke_O_O_O_O_O__O(arg_730, arg_731, arg_732, arg_733, arg_734) } else { return linked_728.(*aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A).Invoke_O_O_O_O_O_O__O(root_727, arg_730, arg_731, arg_732, arg_733, arg_734) } } else {
//line :119:1
							if A_arbace_j2g_dyn_A_const_81 != nil {












								var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any; var root_792 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = A_arbace_j2g_dyn_A_const_73; var arg_796 any; var root_798 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = d__1; if linked_799 == nil { arg_796 = ifn_800.Invoke_O__O(arg_801) } else { arg_796 = linked_799.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_798, arg_801) }; var arg_797 any = Lit_20; if linked_793 == nil { tmp17 = ifn_794.Invoke_O_O_O__O(arg_795, arg_796, arg_797) } else { tmp17 = linked_793.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_792, arg_795, arg_796, arg_797) }; return tmp16.Invoke_O_O__O(tmp17, r__0) } else {
//line :119:1
									return nil
								}
						}
				}
		}
	}
}

func A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(p0 any) *A_arbace_j2g_dyn_convert_result_fn__711000126_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :127:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Invoke_O__O(self any) any { { var e__1 any; var t_ any = t.F_e; t.F_e = nil; e__1 = t_; var n__2 int64 = 0; L1: for { var tmp1 any; var root_743 any = A_arbace_j2g_dyn_A_const_85.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = e__1; if linked_744 == nil { tmp1 = ifn_745.Invoke_O__O(arg_746) } else { tmp1 = linked_744.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_743, arg_746) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_771 any = A_arbace_j2g_dyn_A_const_88.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = e__1; if linked_772 == nil { tmp2 = ifn_773.Invoke_O__O(arg_774) } else { tmp2 = linked_772.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_771, arg_774) }; e__1, n__2 = tmp2, lang.Numbers_Inc_J__J_NoInit(n__2); continue L1 } else {
											var tmp3 any; var root_747 any = A_arbace_j2g_dyn_A_const_89.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any; var tmp4 any = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New(); var tmp5 *jrt.Class; var fncls__752 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class; if fncls__752 == nil { var fncls__752d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class = fncls__752d; tmp5 = fncls__752d } else { tmp5 = fncls__752 }; arg_750 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_751 any; var tmp6 any; var root_753 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = e__1; if linked_754 == nil { tmp6 = ifn_755.Invoke_O__O(arg_756) } else { tmp6 = linked_754.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_753, arg_756) }; if jrt.J2g_Truth(tmp6) {
												var root_757 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_92.GetRawRoot__O()).Invoke_O__O(e__1))).Ref(); if linked_758 == nil { arg_751 = ifn_759.Invoke_O__O(arg_760) } else { arg_751 = linked_758.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_757, arg_760) } } else {
													var root_761 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = A_arbace_j2g_dyn_A_const_73; var arg_765 any; var root_767 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = e__1; if linked_768 == nil { arg_765 = ifn_769.Invoke_O__O(arg_770) } else { arg_765 = linked_768.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_767, arg_770) }; var arg_766 any = Lit_23; if linked_762 == nil { arg_751 = ifn_763.Invoke_O_O_O__O(arg_764, arg_765, arg_766) } else { arg_751 = linked_762.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_761, arg_764, arg_765, arg_766) } }
//line :128:1
	if linked_748 == nil { tmp3 = ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { tmp3 = linked_748.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_747, arg_750, arg_751) }; return lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(n__2)) } } }; /*line :127:1*/panic("j2g: unreachable") }
func A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New() *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Ctor() {}
//line :128:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Invoke_O_O__O(self, p1__711000125_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_90, p1__711000125_SHARP___1) }





func A_arbace_j2g_dyn_call_impl_A_New() *A_arbace_j2g_dyn_call_impl_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_call_impl_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_j2g_dyn_call_impl_A) Ctor() {}
//line :134:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O_O__O(self, this__0, args__1 any) any { var n__3 int64 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(args__1))); if





	lang.Numbers_Lte_J_J__Z_NoInit(n__3, 20) {
		var root_802 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_806 any; var root_810 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp2 any; var root_814 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = Lit_9; var arg_818 any; var root_819 any = A_arbace_j2g_dyn_A_const_100.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any; var root_824 any = A_arbace_j2g_dyn_A_const_101.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref(); var arg_828 any = Lit_10; if linked_825 == nil { arg_822 = ifn_826.Invoke_O_O__O(arg_827, arg_828) } else { arg_822 = linked_825.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_824, arg_827, arg_828) }; var arg_823 any = Lit_10; if linked_820 == nil { arg_818 = ifn_821.Invoke_O_O__O(arg_822, arg_823) } else { arg_818 = linked_820.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_819, arg_822, arg_823) }; if linked_815 == nil { tmp2 = ifn_816.Invoke_O_O__O(arg_817, arg_818) } else { tmp2 = linked_815.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_814, arg_817, arg_818) }; arg_813 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_811 == nil { arg_806 = ifn_812.Invoke_O__O(arg_813) } else { arg_806 = linked_811.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_810, arg_813) }; var arg_807 any = A_arbace_j2g_dyn_A_const_102; var arg_808 any = this__0; var arg_809 any = args__1; if linked_803 == nil { return ifn_804.Invoke_O_O_O_O_O__O(arg_805, arg_806, arg_807, arg_808, arg_809) } else { return linked_803.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_802, arg_805, arg_806, arg_807, arg_808, arg_809) } } else {

			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyn_A_const_103; var tmp5 any = A_arbace_j2g_dyn_A_const_104; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_105; var tmp8 any; var root_829 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_833 any = A_arbace_j2g_dyn_A_const_106; var arg_834 any = A_arbace_j2g_dyn_A_const_107; var arg_835 any = this__0; var arg_836 any = args__1; if linked_830 == nil { tmp8 = ifn_831.Invoke_O_O_O_O_O__O(arg_832, arg_833, arg_834, arg_835, arg_836) } else { tmp8 = linked_830.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_829, arg_832, arg_833, arg_834, arg_835, arg_836) }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8)) } }
//line :134:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O__O(self, args__0 any) any {


	var root_837 any = A_arbace_j2g_dyn_A_const_108.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = A_arbace_j2g_dyn_A_const_109; var arg_841 any = args__0; if linked_838 == nil { return ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { return linked_838.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_837, arg_840, arg_841)
	}
}







func A_arbace_j2g_dyn_abstract_text_A_New() *A_arbace_j2g_dyn_abstract_text_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Ctor() {}
//line :147:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Invoke_O_O_O__O(self, ifaces__0, p__711000134__1 any) any { var vec__711000135__3 any = p__711000134__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000135__3; var vec__711000138__7 any; var root_842 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_844 lang.IFn; if



	linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = desc__5; if linked_843 == nil { vec__711000138__7 = ifn_844.Invoke_O__O(arg_845) } else { vec__711000138__7 = linked_843.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_842, arg_845) }; var ps__8 any = /*line :147:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(1), nil); var declares_QMARK___10 any; var tmp1 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(name__4, desc__5); var tmp2 *jrt.Class; var fncls__856 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class; if




	fncls__856 == nil { var fncls__856d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class = fncls__856d; tmp2 = fncls__856d } else { tmp2 = fncls__856 }; declares_QMARK___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var j__11 any; var or__1927000174__auto____11 any; var root_857 any = /*line :147:1*/A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_859 lang.IFn; if





	linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_861 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = declares_QMARK___10; var arg_865 any = ifaces__0; if linked_862 == nil { arg_860 = ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { arg_860 = linked_862.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_861, arg_864, arg_865) }; if linked_858 == nil { or__1927000174__auto____11 = ifn_859.Invoke_O__O(arg_860) } else { or__1927000174__auto____11 = linked_858.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_857, arg_860) }; if jrt.J2g_Truth(or__1927000174__auto____11) { j__11 = or__1927000174__auto____11 } else {
		var root_866 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var root_870 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any; var tmp3 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(k__6); var tmp4 *jrt.Class; var fncls__885 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class; if fncls__885 == nil { var fncls__885d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class = fncls__885d; tmp4 = fncls__885d } else { tmp4 = fncls__885 }; arg_873 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_874 any = ifaces__0; if linked_871 == nil { arg_869 = ifn_872.Invoke_O_O__O(arg_873, arg_874) } else { arg_869 = linked_871.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_870, arg_873, arg_874) }; if linked_867 == nil { j__11 = ifn_868.Invoke_O__O(arg_869) } else { j__11 = linked_867.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_866, arg_869) } }; var tmp5 /*line :155:1*/*jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp6 any; var root_886 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = r__9; if linked_887 == nil { tmp6 = ifn_888.Invoke_O__O(arg_889) } else { tmp6 = linked_887.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_886, arg_889) }; var tmp7 any = tmp6; var tmp8 any; var root_890 any = A_arbace_j2g_dyn_A_const_115.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = Lit_3; var arg_894 any; var root_895 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var arg_899 any = ps__8; if linked_896 == nil { arg_894 = ifn_897.Invoke_O_O__O(arg_898, arg_899) } else { arg_894 = linked_896.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_895, arg_898, arg_899) }; if linked_891 == nil { tmp8 = ifn_892.Invoke_O_O__O(arg_893, arg_894) } else { tmp8 = linked_891.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_890, arg_893, arg_894) }; var tmp9 any = tmp8; var tmp10 *jrt.String; if
	jrt.J2g_Truth(j__11) { var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil); var tmp12 any; var root_900 any = A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = j__11; var arg_904 any = Lit_5; var arg_905 any = Lit_6; if linked_901 == nil { tmp12 = ifn_902.Invoke_O_O_O__O(arg_903, arg_904, arg_905) } else { tmp12 = linked_901.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_900, arg_903, arg_904, arg_905) }; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)) } else { tmp10 = nil }; return /*line :155:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, name__4, nil, tmp9, nil, tmp10.Ref(), nil)).Ref() }
//line :152:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A{}; t.Ctor_O_O(p0, p1); return t }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Invoke_O_O__O(self, j__1 any) any { var root_846 any = A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var tmp1 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(t.F_name, t.F_desc); var tmp2 *jrt.Class; var fncls__851 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class; if fncls__851 == nil { var fncls__851d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class = fncls__851d; tmp2 = fncls__851d } else { tmp2 = fncls__851 }; arg_849 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_850 any; var tmp3 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp4 any; var root_852 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = j__1; if linked_853 == nil { tmp4 = ifn_854.Invoke_O__O(arg_855) } else { tmp4 = linked_853.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_852, arg_855) }; arg_850 = tmp3.Invoke_O__O(tmp4); if linked_847 == nil { return ifn_848.Invoke_O_O__O(arg_849, arg_850) } else { return linked_847.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_846, arg_849, arg_850) } }
//line :152:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Invoke_O_O__O(self, p1__711000132_SHARP___1 any) any { var tmp1 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(p1__711000132_SHARP___1)); if and__1927000168__auto____2 { var tmp2 any = t.F_desc; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_dyn_A_const_65.Invoke_O__O(p1__711000132_SHARP___1))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :154:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Invoke_O_O__O(self, p1__711000133_SHARP___1 any) any { var root_875 any = A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any; var tmp1 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(t.F_k); var tmp2 *jrt.Class; var fncls__880 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class; if fncls__880 == nil { var fncls__880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class = fncls__880d; tmp2 = fncls__880d } else { tmp2 = fncls__880 }; arg_878 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_879 any; var root_881 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = p1__711000133_SHARP___1; if linked_882 == nil { arg_879 = ifn_883.Invoke_O__O(arg_884) } else { arg_879 = linked_882.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_881, arg_884) }; if linked_876 == nil { return ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { return linked_876.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) } }
//line :154:1
func A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :154:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Invoke_O_O__O(self, p__711000146__1 any) any { var vec__711000148__2 any = p__711000146__1; var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(kk__3, t.F_k)).Ref() }



func A_arbace_j2g_dyn_iface_fallback_A_New() *A_arbace_j2g_dyn_iface_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Ctor() {}
//line :158:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O_O__O(self, ifaces__0, p__711000154__1, pn__2, r__3, core_QMARK___4 any) any { var vec__711000155__6 any = p__711000154__1; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000155__6; var root_906 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_908 lang.IFn; _ = name__7; _ = desc__8; if





	linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any; var iter__1927001039__auto____10 any; var tmp1 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(r__3, pn__2, core_QMARK___4); var tmp2 *jrt.Class; var fncls__1019 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class; if
	fncls__1019 == nil { var fncls__1019d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class = fncls__1019d; tmp2 = fncls__1019d } else { tmp2 = fncls__1019 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp4 any; var root_1020 any = A_arbace_j2g_dyn_A_const_129.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, A_arbace_j2g_dyn_defaults_for_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = ifaces__0; var arg_1024 any = k__9; if linked_1021 == nil { tmp4 = ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { tmp4 = linked_1021.(*A_arbace_j2g_dyn_defaults_for_A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) }; arg_909 = tmp3.Invoke_O__O(tmp4); var arg_910 any; var tmp5 lang.IFn = /*line :164:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_130; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_131; var tmp9 any = A_arbace_j2g_dyn_A_const_132; var tmp10 any; var root_1025 any = A_arbace_j2g_dyn_A_const_133.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, A_arbace_j2g_dyn_abstract_text_A_fn_class); var ifn_1027 lang.IFn; if




	linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = ifaces__0; var arg_1029 any = k__9; if linked_1026 == nil { tmp10 = ifn_1027.Invoke_O_O__O(arg_1028, arg_1029) } else { tmp10 = linked_1026.(*A_arbace_j2g_dyn_abstract_text_A).Invoke_O_O_O__O(root_1025, arg_1028, arg_1029) }; arg_910 = /*line :164:1*/lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10))); if linked_907 == nil { return ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { return linked_907.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_906, arg_909, arg_910) } }
//line :158:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O__O(self, ifaces__0, k__1, pn__2, r__3 any) any {



	var root_1030 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any = ifaces__0; var arg_1034 any = k__1; var arg_1035 any = pn__2; var arg_1036 any = r__3; var arg_1037 any = jrt.Boolean_FALSE.Ref(); if linked_1031 == nil { return ifn_1032.Invoke_O_O_O_O_O__O(arg_1033, arg_1034, arg_1035, arg_1036, arg_1037) } else { return linked_1031.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1030, arg_1033, arg_1034, arg_1035, arg_1036, arg_1037)
	}
}
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Ctor_O_O_O(c__r, c__pn, c__core_QMARK_ any) { t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Invoke_O_O__O(self, s__711000159__1 any) any { var tmp1 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(self, s__711000159__1, t.F_r, t.F_pn, t.F_core_QMARK_); var tmp2 *jrt.Class; var fncls__1018 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class; if fncls__1018 == nil { var fncls__1018d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class = fncls__1018d; tmp2 = fncls__1018d } else { tmp2 = fncls__1018 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :165:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Ctor_O_O_O_O_O(c__iter__711000158, c__s__711000159, c__r, c__pn, c__core_QMARK_ any) { t.F_iter__711000158 = c__iter__711000158; t.F_s__711000159 = c__s__711000159; t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Invoke_O__O(self any) any { { var s__711000159__1 any; var t_ any = t.F_s__711000159; t.F_s__711000159 = nil; s__711000159__1 = t_; for { var temp__1927000414__auto____2 any; var root_911 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = s__711000159__1; if linked_912 == nil { temp__1927000414__auto____2 = ifn_913.Invoke_O__O(arg_914) } else { temp__1927000414__auto____2 = linked_912.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_911, arg_914) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000159__3 any = temp__1927000414__auto____2; var tmp1 any; var root_915 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = s__711000159__3; if linked_916 == nil { tmp1 = ifn_917.Invoke_O__O(arg_918) } else { tmp1 = linked_916.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_915, arg_918) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_919 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = s__711000159__3; if linked_920 == nil { c__1927001037__auto____4 = ifn_921.Invoke_O__O(arg_922) } else { c__1927001037__auto____4 = linked_920.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_919, arg_922) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000161__6 any; var root_923 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_924 == nil { b__711000161__6 = ifn_925.Invoke_O__O(arg_926) } else { b__711000161__6 = linked_924.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_923, arg_926) }; var tmp2 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(b__711000161__6, t.F_r, t.F_pn, size__1927001038__auto____5, t.F_core_QMARK_, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__957 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class; if fncls__957 == nil { var fncls__957d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class = fncls__957d; tmp3 = fncls__957d } else { tmp3 = fncls__957 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_958 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any; var root_963 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = b__711000161__6; if linked_964 == nil { arg_961 = ifn_965.Invoke_O__O(arg_966) } else { arg_961 = linked_964.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_963, arg_966) }; var arg_962 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp5 any; var root_967 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = s__711000159__3; if linked_968 == nil { tmp5 = ifn_969.Invoke_O__O(arg_970) } else { tmp5 = linked_968.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_967, arg_970) }; arg_962 = tmp4.Invoke_O__O(tmp5); if linked_959 == nil { return ifn_960.Invoke_O_O__O(arg_961, arg_962) } else { return linked_959.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_958, arg_961, arg_962) } } else { var root_971 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var root_976 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = b__711000161__6; if linked_977 == nil { arg_974 = ifn_978.Invoke_O__O(arg_979) } else { arg_974 = linked_977.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_976, arg_979) }; var arg_975 any; if linked_972 == nil { return ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { return linked_972.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) } } } else { var vec__711000169__4 any; var root_980 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = s__711000159__3; if linked_981 == nil { vec__711000169__4 = ifn_982.Invoke_O__O(arg_983) } else { vec__711000169__4 = linked_981.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_980, arg_983) }; var j__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(1), nil); var this__7 any
														if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_119; var tmp8 any; var root_1013 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = A_arbace_j2g_dyn_A_const_73; var arg_1017 any = j__5; if linked_1014 == nil { tmp8 = ifn_1015.Invoke_O_O__O(arg_1016, arg_1017) } else { tmp8 = linked_1014.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_1013, arg_1016, arg_1017) }; this__7 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, A_arbace_j2g_dyn_A_const_128) } else { this__7 = A_arbace_j2g_dyn_A_const_118 }
//line :165:1
	var root_984 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_121; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyn_A_const_122; var tmp13 any = A_arbace_j2g_dyn_A_const_123; var tmp14 any; var root_989 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_991 lang.IFn

	if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = A_arbace_j2g_dyn_A_const_73; var arg_993 any = j__5; var arg_994 any = Lit_23; if linked_990 == nil { tmp14 = ifn_991.Invoke_O_O_O__O(arg_992, arg_993, arg_994) } else { tmp14 = linked_990.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_989, arg_992, arg_993, arg_994) }; var tmp15 any = tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14); var tmp16 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_15, t.F_r) { var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_124; var tmp19 any; var root_995 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_999 any = fsym__6; var arg_1000 any = this__7; var arg_1001 any = t.F_pn; if linked_996 == nil { tmp19 = ifn_997.Invoke_O_O_O_O__O(arg_998, arg_999, arg_1000, arg_1001) } else { tmp19 = linked_996.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_995, arg_998, arg_999, arg_1000, arg_1001) }; tmp16 = tmp17.Invoke_O_O_O__O(tmp18, tmp19, A_arbace_j2g_dyn_A_const_127) } else { var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyn_A_const_126; var tmp22 any; var root_1002 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1006 any = fsym__6; var arg_1007 any = this__7; var arg_1008 any = t.F_pn; if linked_1003 == nil { tmp22 = ifn_1004.Invoke_O_O_O_O__O(arg_1005, arg_1006, arg_1007, arg_1008) } else { tmp22 = linked_1003.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1002, arg_1005, arg_1006, arg_1007, arg_1008) }; tmp16 = tmp20.Invoke_O_O__O(tmp21, tmp22) }
//line :167:1
	arg_987 = tmp9.Invoke_O_O_O__O(tmp10, tmp15, tmp16)
//line :165:1
	var arg_988 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp24 any; var root_1009 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = s__711000159__3; if linked_1010 == nil { tmp24 = ifn_1011.Invoke_O__O(arg_1012) } else { tmp24 = linked_1010.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1009, arg_1012) }; arg_988 = tmp23.Invoke_O__O(tmp24); if linked_985 == nil { return ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { return linked_985.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :165:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Ctor_O_O_O_I_O_O(c__b__711000161, c__r, c__pn any, c__size__1927001038__auto__ int32, c__core_QMARK_, c__c__1927001037__auto__ any) { t.F_b__711000161 = c__b__711000161; t.F_r = c__r; t.F_pn = c__pn; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_core_QMARK_ = c__core_QMARK_; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Invoke_O__O(self any) any { { var i__711000160__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000160__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000165__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000160__1)); var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(1), nil); var this__5 any
																if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_119; var tmp4 any; var root_927 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = A_arbace_j2g_dyn_A_const_73; var arg_931 any = j__3; if linked_928 == nil { tmp4 = ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { tmp4 = linked_928.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_927, arg_930, arg_931) }; this__5 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_j2g_dyn_A_const_120) } else { this__5 = A_arbace_j2g_dyn_A_const_118 }
//line :165:1
	var root_932 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = t.F_b__711000161; var arg_936 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_121; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_122; var tmp9 any = A_arbace_j2g_dyn_A_const_123; var tmp10 any; var root_937 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_939 lang.IFn

	if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = A_arbace_j2g_dyn_A_const_73; var arg_941 any = j__3; var arg_942 any = Lit_23; if linked_938 == nil { tmp10 = ifn_939.Invoke_O_O_O__O(arg_940, arg_941, arg_942) } else { tmp10 = linked_938.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_937, arg_940, arg_941, arg_942) }; var tmp11 any = tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10); var tmp12 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_15, t.F_r) { var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyn_A_const_124; var tmp15 any; var root_943 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_947 any = fsym__4; var arg_948 any = this__5; var arg_949 any = t.F_pn; if linked_944 == nil { tmp15 = ifn_945.Invoke_O_O_O_O__O(arg_946, arg_947, arg_948, arg_949) } else { tmp15 = linked_944.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_943, arg_946, arg_947, arg_948, arg_949) }; tmp12 = tmp13.Invoke_O_O_O__O(tmp14, tmp15, A_arbace_j2g_dyn_A_const_125) } else { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_126; var tmp18 any; var root_950 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_954 any = fsym__4; var arg_955 any = this__5; var arg_956 any = t.F_pn; if linked_951 == nil { tmp18 = ifn_952.Invoke_O_O_O_O__O(arg_953, arg_954, arg_955, arg_956) } else { tmp18 = linked_951.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_950, arg_953, arg_954, arg_955, arg_956) }; tmp12 = tmp16.Invoke_O_O__O(tmp17, tmp18) }
//line :167:1
	arg_936 = tmp5.Invoke_O_O_O__O(tmp6, tmp11, tmp12)
//line :165:1
	if linked_933 == nil { ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { linked_933.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_932, arg_935, arg_936) }; i__711000160__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000160__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyn_method_form_A_New() *A_arbace_j2g_dyn_method_form_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_j2g_dyn_method_form_A) Ctor() {}
//line :171:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O_O__O(self, recv__0, i__1, p__711000177__2, fallback__3, this__4 any) any { var vec__711000180__6 any = p__711000177__2; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000180__6; var vec__711000183__10 any; var root_1038 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1040 lang.IFn; _ = k__9; if






	linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = desc__8; if linked_1039 == nil { vec__711000183__10 = ifn_1040.Invoke_O__O(arg_1041) } else { vec__711000183__10 = linked_1039.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1038, arg_1041) }; var ps__11 any = /*line :171:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_1042 any = A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1044 lang.IFn; if







	linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any; var iter__1927001039__auto____13 any; var tmp1 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New(); var tmp2 *jrt.Class; var fncls__1112 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class; if fncls__1112 == nil { var fncls__1112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class = fncls__1112d; tmp2 = fncls__1112d } else { tmp2 = fncls__1112 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp4 any; var root_1113 any = A_arbace_j2g_dyn_A_const_135.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__11)).Ref(); if linked_1114 == nil { tmp4 = ifn_1115.Invoke_O__O(arg_1116) } else { tmp4 = linked_1114.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1113, arg_1116) }; arg_1045 = tmp3.Invoke_O__O(tmp4); if linked_1043 == nil { pn__13 = ifn_1044.Invoke_O__O(arg_1045) } else { pn__13 = linked_1043.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1042, arg_1045) }; var base__14 any; var root_1117 any = /*line :171:1*/A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1119 lang.IFn; if








	linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = name__7; var arg_1121 any = desc__8; if linked_1118 == nil { base__14 = ifn_1119.Invoke_O_O__O(arg_1120, arg_1121) } else { base__14 = linked_1118.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1117, arg_1120, arg_1121) }; var params__15 any; var root_1122 any = /*line :171:1*/A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1124 lang.IFn; if









	linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any; var root_1126 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any; var root_1131 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = A_arbace_j2g_dyn_A_const_137; var arg_1135 any = recv__0; if linked_1132 == nil { arg_1129 = ifn_1133.Invoke_O_O__O(arg_1134, arg_1135) } else { arg_1129 = linked_1132.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1131, arg_1134, arg_1135) }; var arg_1130 any; var root_1136 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any; var tmp5 any = A_arbace_j2g_dyn_method_form_fn__711000196_A_New(); var tmp6 *jrt.Class; var fncls__1152 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class; if fncls__1152 == nil { var fncls__1152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class = fncls__1152d; tmp6 = fncls__1152d } else { tmp6 = fncls__1152 }; arg_1139 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1140 any = pn__13; var arg_1141 any = ps__11; if linked_1137 == nil { arg_1130 = ifn_1138.Invoke_O_O_O__O(arg_1139, arg_1140, arg_1141) } else { arg_1130 = linked_1137.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1136, arg_1139, arg_1140, arg_1141) }; if linked_1127 == nil { arg_1125 = ifn_1128.Invoke_O_O__O(arg_1129, arg_1130) } else { arg_1125 = linked_1127.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1126, arg_1129, arg_1130) }; if linked_1123 == nil { params__15 = ifn_1124.Invoke_O__O(arg_1125) } else { params__15 = linked_1123.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1122, arg_1125) }; var params__16 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_15, r__12) { params__16 = params__15 } else { var root_1153 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = params__15; var arg_1157 any; var tmp7 any = A_arbace_j2g_dyn_A_const_17; var tmp8 any; var root_1158 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = A_arbace_j2g_dyn_A_const_73; var arg_1162 any = r__12; if linked_1159 == nil { tmp8 = ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { tmp8 = linked_1159.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) }; arg_1157 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)); if linked_1154 == nil { params__16 = ifn_1155.Invoke_O_O__O(arg_1156, arg_1157) } else { params__16 = linked_1154.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1153, arg_1156, arg_1157) } }; var call__17 any; var root_1163 any = /*line :171:1*/A_arbace_j2g_dyn_A_const_108.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_1165 lang.IFn; if











	linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = this__4; var arg_1167 any; var root_1168 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var arg_1172 any = pn__13; var arg_1173 any = ps__11; if linked_1169 == nil { arg_1167 = ifn_1170.Invoke_O_O_O__O(arg_1171, arg_1172, arg_1173) } else { arg_1167 = linked_1169.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1168, arg_1171, arg_1172, arg_1173) }; if linked_1164 == nil { call__17 = ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { call__17 = linked_1164.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) }; var tmp9 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_99.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var tmp11 any = A_arbace_j2g_dyn_A_const_139; var tmp12 any; var root_1183 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = base__14; if linked_1184 == nil { tmp12 = ifn_1185.Invoke_O__O(arg_1186) } else { tmp12 = linked_1184.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1183, arg_1186) }; var tmp13 any = tmp12; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyn_A_const_140; var tmp16 any = A_arbace_j2g_dyn_A_const_141; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_142; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_dyn_A_const_143; var tmp21 any = lang.Tuple_Create_O_O__IPersistentVector(tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_144, A_arbace_j2g_dyn_A_const_145)), i__1)); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyn_A_const_146; var tmp24 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_147, A_arbace_j2g_dyn_A_const_148, nil); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyn_A_const_149; var tmp27 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_150, call__17); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyn_A_const_151; var tmp30 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_153, A_arbace_j2g_dyn_A_const_154, A_arbace_j2g_dyn_A_const_155); var tmp31 any; if




	lang.Util_Equiv_O_O__Z_NoInit(Lit_15, r__12) { tmp31 = A_arbace_j2g_dyn_A_const_152 } else { var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_dyn_A_const_156; var tmp34 any; var root_1187 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, A_arbace_j2g_dyn_convert_result_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = A_arbace_j2g_dyn_A_const_158; var arg_1191 any = r__12; if linked_1188 == nil { tmp34 = ifn_1189.Invoke_O_O__O(arg_1190, arg_1191) } else { tmp34 = linked_1188.(*A_arbace_j2g_dyn_convert_result_A).Invoke_O_O_O__O(root_1187, arg_1190, arg_1191) }; tmp31 = tmp32.Invoke_O_O__O(tmp33, tmp34) }; return /*line :184:1*/ tmp9.Invoke_O_O_O_O_O_O__O(tmp10, tmp11, tmp13, params__16, tmp14.Invoke_O_O_O__O(tmp15, tmp21, tmp22.Invoke_O_O_O__O(tmp23, tmp24, tmp25.Invoke_O_O_O__O(tmp26, tmp27, tmp28.Invoke_O_O_O__O(tmp29, tmp30, tmp31)))), lang.IFn_Cast(fallback__3).Invoke_O_O__O(pn__13, r__12)) }
//line :171:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O__O(self, recv__0, i__1, k__2, fallback__3 any) any {




	var root_1192 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = recv__0; var arg_1196 any = i__1; var arg_1197 any = k__2; var arg_1198 any = fallback__3; var arg_1199 any = A_arbace_j2g_dyn_A_const_160; if linked_1193 == nil { return ifn_1194.Invoke_O_O_O_O_O__O(arg_1195, arg_1196, arg_1197, arg_1198, arg_1199) } else { return linked_1193.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1192, arg_1195, arg_1196, arg_1197, arg_1198, arg_1199) } }
//line :171:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O__O(self, ifaces__0, i__1, k__2 any) any {



	var root_1200 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = A_arbace_j2g_dyn_A_const_161; var arg_1204 any = i__1; var arg_1205 any = k__2; var arg_1206 any; var tmp1 any = A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(k__2, ifaces__0); var tmp2 *jrt.Class; var fncls__1216 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class; if fncls__1216 == nil { var fncls__1216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class = fncls__1216d; tmp2 = fncls__1216d } else { tmp2 = fncls__1216 }; arg_1206 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1207 any = A_arbace_j2g_dyn_A_const_162; if linked_1201 == nil { return ifn_1202.Invoke_O_O_O_O_O__O(arg_1203, arg_1204, arg_1205, arg_1206, arg_1207) } else { return linked_1201.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1200, arg_1203, arg_1204, arg_1205, arg_1206, arg_1207) } }
//line :175:1
func A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_fn__711000178_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000178_A{}; t.Ctor_O_O(p0, p1); return t }
//line :175:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :175:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_1208 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = t.F_ifaces; var arg_1212 any = t.F_k; var arg_1213 any = pn__1; var arg_1214 any = r__2; var arg_1215 any = jrt.Boolean_TRUE.Ref(); if linked_1209 == nil { return ifn_1210.Invoke_O_O_O_O_O__O(arg_1211, arg_1212, arg_1213, arg_1214, arg_1215) } else { return linked_1209.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1208, arg_1211, arg_1212, arg_1213, arg_1214, arg_1215) } }



func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New() *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Ctor() {}
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Invoke_O_O__O(self, s__711000187__1 any) any { var tmp1 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(s__711000187__1, self); var tmp2 *jrt.Class; var fncls__1111 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class; if fncls__1111 == nil { var fncls__1111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class = fncls__1111d; tmp2 = fncls__1111d } else { tmp2 = fncls__1111 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :179:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A{}; t.Ctor_O_O(p0, p1); return t }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Ctor_O_O(c__s__711000187, c__iter__711000186 any) { t.F_s__711000187 = c__s__711000187; t.F_iter__711000186 = c__iter__711000186 }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Invoke_O__O(self any) any { { var s__711000187__1 any; var t_ any = t.F_s__711000187; t.F_s__711000187 = nil; s__711000187__1 = t_; for { var temp__1927000414__auto____2 any; var root_1046 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = s__711000187__1; if linked_1047 == nil { temp__1927000414__auto____2 = ifn_1048.Invoke_O__O(arg_1049) } else { temp__1927000414__auto____2 = linked_1047.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1046, arg_1049) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000187__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1050 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = s__711000187__3; if linked_1051 == nil { tmp1 = ifn_1052.Invoke_O__O(arg_1053) } else { tmp1 = linked_1051.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1050, arg_1053) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1054 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = s__711000187__3; if linked_1055 == nil { c__1927001037__auto____4 = ifn_1056.Invoke_O__O(arg_1057) } else { c__1927001037__auto____4 = linked_1055.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1054, arg_1057) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000189__6 any; var root_1058 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1059 == nil { b__711000189__6 = ifn_1060.Invoke_O__O(arg_1061) } else { b__711000189__6 = linked_1059.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1058, arg_1061) }; var tmp2 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(b__711000189__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1071 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class; if fncls__1071 == nil { var fncls__1071d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class = fncls__1071d; tmp3 = fncls__1071d } else { tmp3 = fncls__1071 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1072 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any; var root_1077 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = b__711000189__6; if linked_1078 == nil { arg_1075 = ifn_1079.Invoke_O__O(arg_1080) } else { arg_1075 = linked_1078.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1077, arg_1080) }; var arg_1076 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp5 any; var root_1081 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = s__711000187__3; if linked_1082 == nil { tmp5 = ifn_1083.Invoke_O__O(arg_1084) } else { tmp5 = linked_1082.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1081, arg_1084) }; arg_1076 = tmp4.Invoke_O__O(tmp5); if linked_1073 == nil { return ifn_1074.Invoke_O_O__O(arg_1075, arg_1076) } else { return linked_1073.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1072, arg_1075, arg_1076) } } else { var root_1085 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any; var root_1090 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = b__711000189__6; if linked_1091 == nil { arg_1088 = ifn_1092.Invoke_O__O(arg_1093) } else { arg_1088 = linked_1091.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1090, arg_1093) }; var arg_1089 any; if linked_1086 == nil { return ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { return linked_1086.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) } } } else { var j__4 any; var root_1094 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = s__711000187__3; if linked_1095 == nil { j__4 = ifn_1096.Invoke_O__O(arg_1097) } else { j__4 = linked_1095.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1094, arg_1097) }; var root_1098 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any; var root_1103 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_124, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__4)).Ref(); if linked_1104 == nil { arg_1101 = ifn_1105.Invoke_O__O(arg_1106) } else { arg_1101 = linked_1104.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1103, arg_1106) }; var arg_1102 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp7 any; var root_1107 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = s__711000187__3; if linked_1108 == nil { tmp7 = ifn_1109.Invoke_O__O(arg_1110) } else { tmp7 = linked_1108.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1107, arg_1110) }; arg_1102 = tmp6.Invoke_O__O(tmp7); if linked_1099 == nil { return ifn_1100.Invoke_O_O__O(arg_1101, arg_1102) } else { return linked_1099.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1098, arg_1101, arg_1102) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :179:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Ctor_O_I_O(c__b__711000189 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000189 = c__b__711000189; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Invoke_O__O(self any) any { { var i__711000188__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000188__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000188__1)); var root_1062 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = t.F_b__711000189; var arg_1066 any; var root_1067 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_124, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__2)).Ref(); if linked_1068 == nil { arg_1066 = ifn_1069.Invoke_O__O(arg_1070) } else { arg_1066 = linked_1068.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1067, arg_1070) }; if linked_1063 == nil { ifn_1064.Invoke_O_O__O(arg_1065, arg_1066) } else { linked_1063.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1062, arg_1065, arg_1066) }; i__711000188__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000188__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_method_form_fn__711000196_A_New() *A_arbace_j2g_dyn_method_form_fn__711000196_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000196_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Ctor() {}
//line :181:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Invoke_O_O_O__O(self, p1__711000175_SHARP___1, p2__711000176_SHARP___2 any) any { var root_1142 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = p1__711000175_SHARP___1; var arg_1146 any; var root_1147 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = A_arbace_j2g_dyn_A_const_73; var arg_1151 any = p2__711000176_SHARP___2; if linked_1148 == nil { arg_1146 = ifn_1149.Invoke_O_O__O(arg_1150, arg_1151) } else { arg_1146 = linked_1148.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1147, arg_1150, arg_1151) }; if linked_1143 == nil { return ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { return linked_1143.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) } }










func A_arbace_j2g_dyn_native_name_A_New() *A_arbace_j2g_dyn_native_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_native_name_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_dyn_native_name_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_dyn_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil, Lit_125); var tmp2 any; var root_1217 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); if linked_1218 == nil { tmp2 = ifn_1219.Invoke_O__O(arg_1220) } else { tmp2 = linked_1218.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1217, arg_1220) }; var tmp3 any = tmp2; var tmp4 any; var root_1221 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = mname__0; var arg_1225 any = desc__1; if linked_1222 == nil { tmp4 = ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { tmp4 = linked_1222.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref()
}























func A_arbace_j2g_dyn_proxy_classes_A_New() *A_arbace_j2g_dyn_proxy_classes_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Ctor() {}
//line :218:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Invoke_O_O__O(self, T__0_ any) any {



	var root_1226 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any; var tmp1 any = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(T__0_); var tmp2 *jrt.Class; var fncls__1268 *jrt.Class = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class; if fncls__1268 == nil { var fncls__1268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class = fncls__1268d; tmp2 = fncls__1268d } else { tmp2 = fncls__1268 }; arg_1229 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1230 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); if linked_1227 == nil { return ifn_1228.Invoke_O_O__O(arg_1229, arg_1230) } else { return linked_1227.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1226, arg_1229, arg_1230) } }
//line :222:1
func A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_fn__711000201_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Ctor_O(c__T any) { t.F_T = c__T }
//line :222:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Invoke_O_O__O(self, p1__711000200_SHARP___1 any) any { var and__1927000168__auto____2 any; var or__1927000174__auto____2 any; var root_1231 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = t.F_T; var arg_1235 any = p1__711000200_SHARP___1; if linked_1232 == nil { or__1927000174__auto____2 = ifn_1233.Invoke_O_O__O(arg_1234, arg_1235) } else { or__1927000174__auto____2 = linked_1232.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1231, arg_1234, arg_1235) }; if jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { var root_1236 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = p1__711000200_SHARP___1; if linked_1237 == nil { and__1927000168__auto____2 = ifn_1238.Invoke_O__O(arg_1239) } else { and__1927000168__auto____2 = linked_1237.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1236, arg_1239) } }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1240 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = p1__711000200_SHARP___1; if linked_1241 == nil { and__1927000168__auto____3 = ifn_1242.Invoke_O__O(arg_1243) } else { and__1927000168__auto____3 = linked_1241.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_1240, arg_1243) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1244 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1246 lang.IFn
														if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any; var root_1248 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = p1__711000200_SHARP___1; if linked_1249 == nil { arg_1247 = ifn_1250.Invoke_O__O(arg_1251) } else { arg_1247 = linked_1249.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1248, arg_1251) }; if linked_1245 == nil { and__1927000168__auto____4 = ifn_1246.Invoke_O__O(arg_1247) } else { and__1927000168__auto____4 = linked_1245.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1244, arg_1247) }
//line :222:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1252 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1254 lang.IFn
		if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any; var root_1256 any = A_arbace_j2g_dyn_A_const_163.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1256, aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_1258 lang.IFn; if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = p1__711000200_SHARP___1; if linked_1257 == nil { arg_1255 = ifn_1258.Invoke_O__O(arg_1259) } else { arg_1255 = linked_1257.(*aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_1256, arg_1259) }; if linked_1253 == nil { and__1927000168__auto____5 = ifn_1254.Invoke_O__O(arg_1255) } else { and__1927000168__auto____5 = linked_1253.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1252, arg_1255) }
//line :222:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_1260 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1262 lang.IFn; if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any; var root_1264 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = p1__711000200_SHARP___1; if linked_1265 == nil { arg_1263 = ifn_1266.Invoke_O__O(arg_1267) } else { arg_1263 = linked_1265.(*aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_1264, arg_1267) }; if linked_1261 == nil { return ifn_1262.Invoke_O__O(arg_1263) } else { return linked_1261.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1260, arg_1263) } } else {
//line :222:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_j2g_dyn_sub_name_A_New() *A_arbace_j2g_dyn_sub_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_name_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_j2g_dyn_sub_name_A) Ctor() {}
//line :226:1
func (t *A_arbace_j2g_dyn_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_166, nil); var tmp2 any; var root_1269 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = n__0; if linked_1270 == nil { tmp2 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp2 = linked_1270.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1269, arg_1272) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyn_proxy_roots_A_New() *A_arbace_j2g_dyn_proxy_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_A{}; t.Ctor(); return t }
//line :228:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Ctor() {}
//line :228:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New(); var tmp2 *jrt.Class; var fncls__1476 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class; if



	fncls__1476 == nil { var fncls__1476d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class = fncls__1476d; tmp2 = fncls__1476d } else { tmp2 = fncls__1476 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_165.GetRawRoot__O()) }
//line :232:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New() *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Ctor() {}
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Invoke_O_O__O(self, s__711000206__1 any) any { var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(self, s__711000206__1); var tmp2 *jrt.Class; var fncls__1475 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class; if fncls__1475 == nil { var fncls__1475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class = fncls__1475d; tmp2 = fncls__1475d } else { tmp2 = fncls__1475 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :232:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A{}; t.Ctor_O_O(p0, p1); return t }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Ctor_O_O(c__iter__711000205, c__s__711000206 any) { t.F_iter__711000205 = c__iter__711000205; t.F_s__711000206 = c__s__711000206 }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Invoke_O__O(self any) any { { var s__711000206__1 any; var t_ any = t.F_s__711000206; t.F_s__711000206 = nil; s__711000206__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1273 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = s__711000206__1; if linked_1274 == nil { temp__1927000414__auto____2 = ifn_1275.Invoke_O__O(arg_1276) } else { temp__1927000414__auto____2 = linked_1274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1273, arg_1276) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1277 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = xs__1927001018__auto____3; if linked_1278 == nil { n__4 = ifn_1279.Invoke_O__O(arg_1280) } else { n__4 = linked_1278.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1277, arg_1280) }; var tmp1 any; var and__1927000168__auto____5 any; var root_1281 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1283 lang.IFn
														if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = n__4; if linked_1282 == nil { and__1927000168__auto____5 = ifn_1283.Invoke_O__O(arg_1284) } else { and__1927000168__auto____5 = linked_1282.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1281, arg_1284) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1285 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any; var root_1289 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = n__4; if linked_1290 == nil { arg_1288 = ifn_1291.Invoke_O__O(arg_1292) } else { arg_1288 = linked_1290.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1289, arg_1292) }; if linked_1286 == nil { tmp1 = ifn_1287.Invoke_O__O(arg_1288) } else { tmp1 = linked_1286.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1285, arg_1288) } } else { tmp1 = and__1927000168__auto____5 }
//line :232:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(n__4); var tmp3 *jrt.Class; var fncls__1449 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class; if fncls__1449 == nil { var fncls__1449d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class = fncls__1449d; tmp3 = fncls__1449d } else { tmp3 = fncls__1449 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1450 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var root_1454 any = A_arbace_j2g_dyn_A_const_168.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1456 lang.IFn

		if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = n__4; if linked_1455 == nil { tmp5 = ifn_1456.Invoke_O__O(arg_1457) } else { tmp5 = linked_1455.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1454, arg_1457) }
//line :232:1
		arg_1453 = tmp4.Invoke_O__O(tmp5); if linked_1451 == nil { fs__1927001036__auto____6 = ifn_1452.Invoke_O__O(arg_1453) } else { fs__1927001036__auto____6 = linked_1451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1450, arg_1453) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1458 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = fs__1927001036__auto____6; var arg_1462 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000205); var tmp7 any; var root_1463 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = s__711000206__1; if linked_1464 == nil { tmp7 = ifn_1465.Invoke_O__O(arg_1466) } else { tmp7 = linked_1464.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1463, arg_1466) }; arg_1462 = tmp6.Invoke_O__O(tmp7); if linked_1459 == nil { return ifn_1460.Invoke_O_O__O(arg_1461, arg_1462) } else { return linked_1459.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1458, arg_1461, arg_1462) } } else { var tmp8 any; var root_1467 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = s__711000206__1; if linked_1468 == nil { tmp8 = ifn_1469.Invoke_O__O(arg_1470) } else { tmp8 = linked_1468.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1467, arg_1470) }; s__711000206__1 = tmp8; continue L1 } } else { var tmp9 any; var root_1471 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = s__711000206__1; if linked_1472 == nil { tmp9 = ifn_1473.Invoke_O__O(arg_1474) } else { tmp9 = linked_1472.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1471, arg_1474) }; s__711000206__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :232:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A{}; t.Ctor_O(p0); return t }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Invoke_O_O__O(self, s__711000208__1 any) any { var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(self, t.F_n, s__711000208__1); var tmp2 *jrt.Class; var fncls__1448 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class; if fncls__1448 == nil { var fncls__1448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class = fncls__1448d; tmp2 = fncls__1448d } else { tmp2 = fncls__1448 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :232:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Ctor_O_O_O(c__iter__711000207, c__n, c__s__711000208 any) { t.F_iter__711000207 = c__iter__711000207; t.F_n = c__n; t.F_s__711000208 = c__s__711000208 }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Invoke_O__O(self any) any { { var s__711000208__1 any; var t_ any = t.F_s__711000208; t.F_s__711000208 = nil; s__711000208__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1293 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = s__711000208__1; if linked_1294 == nil { temp__1927000414__auto____2 = ifn_1295.Invoke_O__O(arg_1296) } else { temp__1927000414__auto____2 = linked_1294.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1293, arg_1296) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_1297 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = xs__1927001018__auto____3; if linked_1298 == nil { c__4 = ifn_1299.Invoke_O__O(arg_1300) } else { c__4 = linked_1298.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1297, arg_1300) }; var tmp1 any
																			var and__1927000168__auto____5 any = c__4

	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1301 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = c__4; var arg_1305 any = Lit_98; if linked_1302 == nil { and__1927000168__auto____6 = ifn_1303.Invoke_O_O__O(arg_1304, arg_1305) } else { and__1927000168__auto____6 = linked_1302.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1301, arg_1304, arg_1305) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1306 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = c__4; if linked_1307 == nil { tmp1 = ifn_1308.Invoke_O__O(arg_1309) } else { tmp1 = linked_1307.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1306, arg_1309) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }
//line :232:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(t.F_n, c__4); var tmp3 *jrt.Class; var fncls__1422 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class; if fncls__1422 == nil { var fncls__1422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class = fncls__1422d; tmp3 = fncls__1422d } else { tmp3 = fncls__1422 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1423 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp6 any; var root_1427 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1429 lang.IFn



		if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = c__4; if linked_1428 == nil { tmp6 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp6 = linked_1428.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1427, arg_1430) }
//line :232:1
		arg_1426 = tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6)); if linked_1424 == nil { fs__1927001036__auto____6 = ifn_1425.Invoke_O__O(arg_1426) } else { fs__1927001036__auto____6 = linked_1424.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1423, arg_1426) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1431 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = fs__1927001036__auto____6; var arg_1435 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000207); var tmp8 any; var root_1436 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = s__711000208__1; if linked_1437 == nil { tmp8 = ifn_1438.Invoke_O__O(arg_1439) } else { tmp8 = linked_1437.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1436, arg_1439) }; arg_1435 = tmp7.Invoke_O__O(tmp8); if linked_1432 == nil { return ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { return linked_1432.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) } } else { var tmp9 any; var root_1440 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = s__711000208__1; if linked_1441 == nil { tmp9 = ifn_1442.Invoke_O__O(arg_1443) } else { tmp9 = linked_1441.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1440, arg_1443) }; s__711000208__1 = tmp9; continue L1 } } else { var tmp10 any; var root_1444 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = s__711000208__1; if linked_1445 == nil { tmp10 = ifn_1446.Invoke_O__O(arg_1447) } else { tmp10 = linked_1445.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1444, arg_1447) }; s__711000208__1 = tmp10; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :232:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A{}; t.Ctor_O_O(p0, p1); return t }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Ctor_O_O(c__n, c__c any) { t.F_n = c__n; t.F_c = c__c }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Invoke_O_O__O(self, s__711000210__1 any) any { var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(s__711000210__1, t.F_n, self, t.F_c); var tmp2 *jrt.Class; var fncls__1421 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class; if fncls__1421 == nil { var fncls__1421d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class = fncls__1421d; tmp2 = fncls__1421d } else { tmp2 = fncls__1421 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :232:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Ctor_O_O_O_O(c__s__711000210, c__n, c__iter__711000209, c__c any) { t.F_s__711000210 = c__s__711000210; t.F_n = c__n; t.F_iter__711000209 = c__iter__711000209; t.F_c = c__c }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Invoke_O__O(self any) any { { var s__711000210__1 any; var t_ any = t.F_s__711000210; t.F_s__711000210 = nil; s__711000210__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1310 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = s__711000210__1; if linked_1311 == nil { temp__1927000414__auto____2 = ifn_1312.Invoke_O__O(arg_1313) } else { temp__1927000414__auto____2 = linked_1311.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1310, arg_1313) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000210__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1314 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = s__711000210__3; if linked_1315 == nil { tmp1 = ifn_1316.Invoke_O__O(arg_1317) } else { tmp1 = linked_1315.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1314, arg_1317) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1318 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = s__711000210__3; if linked_1319 == nil { c__1927001037__auto____4 = ifn_1320.Invoke_O__O(arg_1321) } else { c__1927001037__auto____4 = linked_1319.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1318, arg_1321) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000212__6 any; var root_1322 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1323 == nil { b__711000212__6 = ifn_1324.Invoke_O__O(arg_1325) } else { b__711000212__6 = linked_1323.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1322, arg_1325) }; var tmp2 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(t.F_n, b__711000212__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__1352 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class; if fncls__1352 == nil { var fncls__1352d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class = fncls__1352d; tmp3 = fncls__1352d } else { tmp3 = fncls__1352 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1353 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any; var root_1358 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = b__711000212__6; if linked_1359 == nil { arg_1356 = ifn_1360.Invoke_O__O(arg_1361) } else { arg_1356 = linked_1359.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1358, arg_1361) }; var arg_1357 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp5 any; var root_1362 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = s__711000210__3; if linked_1363 == nil { tmp5 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp5 = linked_1363.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1362, arg_1365) }; arg_1357 = tmp4.Invoke_O__O(tmp5); if linked_1354 == nil { return ifn_1355.Invoke_O_O__O(arg_1356, arg_1357) } else { return linked_1354.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1353, arg_1356, arg_1357) } } else { var root_1366 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any; var root_1371 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1371, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1373 lang.IFn; if linked_1372 == nil { ifn_1373 = lang.IFn_Cast(root_1371) } else { ifn_1373 = nil }; var arg_1374 any = b__711000212__6; if linked_1372 == nil { arg_1369 = ifn_1373.Invoke_O__O(arg_1374) } else { arg_1369 = linked_1372.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1371, arg_1374) }; var arg_1370 any; if linked_1367 == nil { return ifn_1368.Invoke_O_O__O(arg_1369, arg_1370) } else { return linked_1367.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1366, arg_1369, arg_1370) } } } else { var mm__4 any; var root_1375 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = s__711000210__3; if linked_1376 == nil { mm__4 = ifn_1377.Invoke_O__O(arg_1378) } else { mm__4 = linked_1376.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1375, arg_1378) }; var tmp6 any; var root_1379 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1381 lang.IFn




	if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any; var root_1383 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = mm__4; if linked_1384 == nil { arg_1382 = ifn_1385.Invoke_O__O(arg_1386) } else { arg_1382 = linked_1384.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1383, arg_1386) }; if linked_1380 == nil { tmp6 = ifn_1381.Invoke_O__O(arg_1382) } else { tmp6 = linked_1380.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1379, arg_1382) }
//line :232:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4))





		if or__1927000174__auto____5 { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1387 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any; var root_1391 any = A_arbace_j2g_dyn_A_const_167.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = mm__4; if linked_1392 == nil { arg_1390 = ifn_1393.Invoke_O__O(arg_1394) } else { arg_1390 = linked_1392.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1391, arg_1394) }; if linked_1388 == nil { tmp7 = ifn_1389.Invoke_O__O(arg_1390) } else { tmp7 = linked_1388.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1387, arg_1390) } }
//line :232:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____5_2 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var root_1395 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1395, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = Lit_29; var arg_1399 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_1396 == nil { tmp8 = ifn_1397.Invoke_O_O__O(arg_1398, arg_1399) } else { tmp8 = linked_1396.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1395, arg_1398, arg_1399) } }
//line :232:1
			if jrt.J2g_Truth(tmp8) { var root_1400 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var tmp9 any = t.F_c; var arg_1403 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4)); var arg_1404 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp11 any; var root_1405 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = s__711000210__3; if linked_1406 == nil { tmp11 = ifn_1407.Invoke_O__O(arg_1408) } else { tmp11 = linked_1406.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1405, arg_1408) }; arg_1404 = tmp10.Invoke_O__O(tmp11); if linked_1401 == nil { return ifn_1402.Invoke_O_O__O(arg_1403, arg_1404) } else { return linked_1401.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1400, arg_1403, arg_1404) } } else { var tmp12 any; var root_1409 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1411 lang.IFn; if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = s__711000210__3; if linked_1410 == nil { tmp12 = ifn_1411.Invoke_O__O(arg_1412) } else { tmp12 = linked_1410.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1409, arg_1412) }; s__711000210__1 = tmp12; continue L1 } } else { var tmp13 any; var root_1413 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = s__711000210__3; if linked_1414 == nil { tmp13 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp13 = linked_1414.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1413, arg_1416) }; s__711000210__1 = tmp13; continue L1 } } else { var tmp14 any; var root_1417 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = s__711000210__3; if linked_1418 == nil { tmp14 = ifn_1419.Invoke_O__O(arg_1420) } else { tmp14 = linked_1418.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1417, arg_1420) }; s__711000210__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :232:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Ctor_O_O_I_O_O(c__n, c__b__711000212 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__c any) { t.F_n = c__n; t.F_b__711000212 = c__b__711000212; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :232:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Invoke_O__O(self any) any { { var i__711000211__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000211__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000211__1)); var tmp2 any; var root_1326 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1328 lang.IFn




	if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any; var root_1330 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = mm__2; if linked_1331 == nil { arg_1329 = ifn_1332.Invoke_O__O(arg_1333) } else { arg_1329 = linked_1331.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1330, arg_1333) }; if linked_1327 == nil { tmp2 = ifn_1328.Invoke_O__O(arg_1329) } else { tmp2 = linked_1327.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1326, arg_1329) }
//line :232:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2))





		if or__1927000174__auto____3 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1334 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any; var root_1338 any = A_arbace_j2g_dyn_A_const_167.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = mm__2; if linked_1339 == nil { arg_1337 = ifn_1340.Invoke_O__O(arg_1341) } else { arg_1337 = linked_1339.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1338, arg_1341) }; if linked_1335 == nil { tmp3 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp3 = linked_1335.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1334, arg_1337) } }
//line :232:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____3_2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var root_1342 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = Lit_29; var arg_1346 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_1343 == nil { tmp4 = ifn_1344.Invoke_O_O__O(arg_1345, arg_1346) } else { tmp4 = linked_1343.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1342, arg_1345, arg_1346) } }
//line :232:1
			if jrt.J2g_Truth(tmp4) { var root_1347 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1349 lang.IFn; if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = t.F_b__711000212; var tmp5 any = t.F_c; var arg_1351 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2)); if linked_1348 == nil { ifn_1349.Invoke_O_O__O(arg_1350, arg_1351) } else { linked_1348.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1347, arg_1350, arg_1351) }; i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_j2g_dyn_object_fallback_A_New() *A_arbace_j2g_dyn_object_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_object_fallback_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Ctor() {}
//line :242:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Invoke_O_O_O_O__O(self, n__0, k__1, pn__2 any) any { var impl__4 any; var root_1477 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1479 lang.IFn; if



	linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = n__0; var arg_1481 any = k__1; if linked_1478 == nil { impl__4 = ifn_1479.Invoke_O_O__O(arg_1480, arg_1481) } else { impl__4 = linked_1478.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1477, arg_1480, arg_1481) }; var base__5 any; var root_1482 any = /*line :242:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1484 lang.IFn; if




	linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var arg_1486 any = k__1; if linked_1483 == nil { base__5 = ifn_1484.Invoke_O_O__O(arg_1485, arg_1486) } else { base__5 = linked_1483.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1482, arg_1485, arg_1486) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_169); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__4))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_170; var tmp4 any; var root_1487 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1489 lang.IFn
		if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1491 any; var root_1495 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__5)).Ref(); if linked_1496 == nil { arg_1491 = ifn_1497.Invoke_O__O(arg_1498) } else { arg_1491 = linked_1496.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1495, arg_1498) }; var arg_1492 any = A_arbace_j2g_dyn_A_const_171; var arg_1493 any = A_arbace_j2g_dyn_A_const_172; var arg_1494 any = pn__2; if linked_1488 == nil { tmp4 = ifn_1489.Invoke_O_O_O_O_O__O(arg_1490, arg_1491, arg_1492, arg_1493, arg_1494) } else { tmp4 = linked_1488.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1487, arg_1490, arg_1491, arg_1492, arg_1493, arg_1494) }
//line :248:1
		return lang.Tuple_Create_O__IPersistentVector(tmp2.Invoke_O_O__O(tmp3, tmp4)) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_173; var tmp7 any; var G__711000228__6_ any; var root_1499 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1501 lang.IFn

			if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = k__1; if linked_1500 == nil { G__711000228__6_ = ifn_1501.Invoke_O__O(arg_1502) } else { G__711000228__6_ = linked_1500.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1499, arg_1502) }; L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__711000228__6_) >> 1 & 3 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_126) { tmp7 = A_arbace_j2g_dyn_A_const_174; break L1 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_127) { tmp7 = A_arbace_j2g_dyn_A_const_175; break L1 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_128) {


				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_176; var tmp10 any = A_arbace_j2g_dyn_A_const_177; var tmp11 any; var root_1504 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1506 lang.IFn; if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = pn__2; if linked_1505 == nil { tmp11 = ifn_1506.Invoke_O__O(arg_1507) } else { tmp11 = linked_1505.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1504, arg_1507) }; tmp7 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11)
//line :250:1
				break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_129, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__711000228__6_)))))}
//line :248:1
			return lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O_O__O(tmp6, tmp7)) } }






func A_arbace_j2g_dyn_class_fallback_A_New() *A_arbace_j2g_dyn_class_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Ctor() {}
//line :255:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Invoke_O_O_O_O_O__O(self, n__0, p__711000230__1, pn__2, r__3 any) any { var vec__711000231__5 any = p__711000230__1; var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__711000231__5; var impl__9 any; var root_1508 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1510 lang.IFn; if



	linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = n__0; var arg_1512 any = k__8; if linked_1509 == nil { impl__9 = ifn_1510.Invoke_O_O__O(arg_1511, arg_1512) } else { impl__9 = linked_1509.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1508, arg_1511, arg_1512) }; var base__10 any; var root_1513 any = /*line :255:1*/A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1515 lang.IFn; if




	linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = name__6; var arg_1517 any = desc__7; if linked_1514 == nil { base__10 = ifn_1515.Invoke_O_O__O(arg_1516, arg_1517) } else { base__10 = linked_1514.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1513, arg_1516, arg_1517) }; var ret__11 any; var tmp1 any = /*line :255:1*/A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(r__3); var tmp2 *jrt.Class; var fncls__1518 *jrt.Class = A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class; if





	fncls__1518 == nil { var fncls__1518d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class = fncls__1518d; tmp2 = fncls__1518d } else { tmp2 = fncls__1518 }; ret__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var G__711000236__12_ any = /*line :255:1*/A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__9); switch






	lang.Util_Hash_O__I_NoInit(G__711000236__12_) >> 4 & 3 { case 0: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_69) {

		var tmp3 lang.IFn = lang.IFn_Cast(ret__11); var tmp4 any; var root_1524 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1528 any; var root_1531 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = A_arbace_j2g_dyn_A_const_73; var arg_1535 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__9); var arg_1536 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1532 == nil { arg_1528 = ifn_1533.Invoke_O_O_O__O(arg_1534, arg_1535, arg_1536) } else { arg_1528 = linked_1532.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1531, arg_1534, arg_1535, arg_1536) }; var arg_1529 any = A_arbace_j2g_dyn_A_const_182; var arg_1530 any = pn__2; if linked_1525 == nil { tmp4 = ifn_1526.Invoke_O_O_O_O__O(arg_1527, arg_1528, arg_1529, arg_1530) } else { tmp4 = linked_1525.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1524, arg_1527, arg_1528, arg_1529, arg_1530) }; return tmp3.Invoke_O__O(tmp4) }
//line :262:1
	case 1: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_179) {
		var tmp5 lang.IFn = lang.IFn_Cast(ret__11); var tmp6 any; var root_1537 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1541 any; var root_1545 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1546 == nil { arg_1541 = ifn_1547.Invoke_O__O(arg_1548) } else { arg_1541 = linked_1546.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1545, arg_1548) }; var arg_1542 any = A_arbace_j2g_dyn_A_const_183; var arg_1543 any = A_arbace_j2g_dyn_A_const_184; var arg_1544 any = pn__2; if linked_1538 == nil { tmp6 = ifn_1539.Invoke_O_O_O_O_O__O(arg_1540, arg_1541, arg_1542, arg_1543, arg_1544) } else { tmp6 = linked_1538.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1537, arg_1540, arg_1541, arg_1542, arg_1543, arg_1544) }; return tmp5.Invoke_O__O(tmp6) }
//line :262:1
	case 2: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_180) {
		var tmp7 lang.IFn = lang.IFn_Cast(ret__11); var tmp8 any; var root_1549 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1553 any; var root_1557 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1558 == nil { arg_1553 = ifn_1559.Invoke_O__O(arg_1560) } else { arg_1553 = linked_1558.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1557, arg_1560) }; var arg_1554 any = A_arbace_j2g_dyn_A_const_183; var arg_1555 any = A_arbace_j2g_dyn_A_const_184; var arg_1556 any = pn__2; if linked_1550 == nil { tmp8 = ifn_1551.Invoke_O_O_O_O_O__O(arg_1552, arg_1553, arg_1554, arg_1555, arg_1556) } else { tmp8 = linked_1550.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1549, arg_1552, arg_1553, arg_1554, arg_1555, arg_1556) }; return tmp7.Invoke_O__O(tmp8) }
//line :262:1
	case 3: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_181) {


		var tmp9 lang.IFn = lang.IFn_Cast(ret__11); var tmp10 any; var root_1561 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1565 any; var root_1568 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1569 == nil { arg_1565 = ifn_1570.Invoke_O__O(arg_1571) } else { arg_1565 = linked_1569.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1568, arg_1571) }; var arg_1566 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any; var root_1572 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp14 any; var root_1576 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1578 lang.IFn; if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any = n__0; if linked_1577 == nil { tmp14 = ifn_1578.Invoke_O__O(arg_1579) } else { tmp14 = linked_1577.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1576, arg_1579) }; arg_1575 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1573 == nil { tmp12 = ifn_1574.Invoke_O__O(arg_1575) } else { tmp12 = linked_1573.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1572, arg_1575) }; arg_1566 = tmp11.Invoke_O_O__O(tmp12, A_arbace_j2g_dyn_A_const_185); var arg_1567 any = pn__2; if linked_1562 == nil { tmp10 = ifn_1563.Invoke_O_O_O_O__O(arg_1564, arg_1565, arg_1566, arg_1567) } else { tmp10 = linked_1562.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1561, arg_1564, arg_1565, arg_1566, arg_1567) }; return tmp9.Invoke_O__O(tmp10) }
//line :262:1
	default:}; var vec__711000237__13 any; var root_1520 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1522 lang.IFn; if



	linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = desc__7; if linked_1521 == nil { vec__711000237__13 = ifn_1522.Invoke_O__O(arg_1523) } else { vec__711000237__13 = linked_1521.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1520, arg_1523) }; var ps__14 any = /*line :262:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(0), nil); var rr__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_dyn_A_const_186; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_187; var tmp19 any = A_arbace_j2g_dyn_A_const_188; var tmp20 *jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns21:)' of abstract class ns1:.", []*jrt.Class{jrt.String_class}); var tmp21 any; var root_1580 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1582 lang.IFn; if




	linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = rr__15; if linked_1581 == nil { tmp21 = ifn_1582.Invoke_O__O(arg_1583) } else { tmp21 = linked_1581.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1580, arg_1583) }; var tmp22 any = tmp21; var tmp23 any; var root_1584 any = /*line :262:1*/A_arbace_j2g_dyn_A_const_115.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1584, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1586 lang.IFn; if





	linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any = Lit_3; var arg_1588 any; var root_1589 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var arg_1593 any = ps__14; if linked_1590 == nil { arg_1588 = ifn_1591.Invoke_O_O__O(arg_1592, arg_1593) } else { arg_1588 = linked_1590.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1589, arg_1592, arg_1593) }; if linked_1585 == nil { tmp23 = ifn_1586.Invoke_O_O__O(arg_1587, arg_1588) } else { tmp23 = linked_1585.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1584, arg_1587, arg_1588) }; var tmp24 any = tmp23; var tmp25 any; var root_1594 any = /*line :262:1*/A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1596 lang.IFn; if






	linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any = n__0; var arg_1598 any = Lit_5; var arg_1599 any = Lit_6; if linked_1595 == nil { tmp25 = ifn_1596.Invoke_O_O_O__O(arg_1597, arg_1598, arg_1599) } else { tmp25 = linked_1595.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1594, arg_1597, arg_1598, arg_1599) }; return /*line :262:1*/ lang.Tuple_Create_O__IPersistentVector(tmp15.Invoke_O_O__O(tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp22, nil, name__6, nil, tmp24, nil, tmp25, nil)).Ref()))) }
//line :261:1
func A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(p0 any) *A_arbace_j2g_dyn_class_fallback_ret__711000234_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_ret__711000234_A{}; t.Ctor_O(p0); return t }
//line :261:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :261:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Invoke_O_O__O(self, call__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(Lit_15, t.F_r) { return lang.Tuple_Create_O__IPersistentVector(call__1) } else { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_178, call__1)) } }









func A_arbace_j2g_dyn_ctor_infos_A_New() *A_arbace_j2g_dyn_ctor_infos_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Ctor() {}
//line :271:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_1600 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_1601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1600, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_1602 lang.IFn; if


	linked_1601 == nil { ifn_1602 = lang.IFn_Cast(root_1600) } else { ifn_1602 = nil }; var arg_1603 any = n__0; if linked_1601 == nil { g__2 = ifn_1602.Invoke_O__O(arg_1603) } else { g__2 = linked_1601.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_1600, arg_1603) }; var arg_conv__3 any; var tmp1 any = /*line :271:1*/A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New(); var tmp2 *jrt.Class; var fncls__1618 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class; if



	fncls__1618 == nil { var fncls__1618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class = fncls__1618d; tmp2 = fncls__1618d } else { tmp2 = fncls__1618 }; arg_conv__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var root_1622 any =


	A_arbace_j2g_dyn_A_const_194.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_195.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_196, A_arbace_j2g_dyn_A_const_197); if linked_1623 == nil { ifn_1624.Invoke_O__O(arg_1625) } else { linked_1623.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1622, arg_1625) }; var tmp3 any; tmp21 := /*line :271:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_198; var tmp6 any; var root_1631 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1631, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1633 lang.IFn; if linked_1632 == nil { ifn_1633 = lang.IFn_Cast(root_1631) } else { ifn_1633 = nil }; var arg_1634 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_1632 == nil { tmp6 = ifn_1633.Invoke_O__O(arg_1634) } else { tmp6 = linked_1632.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1631, arg_1634) }; var tmp7 any = tmp6; var tmp8 any; var root_1635 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any; var tmp9 any; var root_1640 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = A_arbace_j2g_dyn_A_const_199; var arg_1644 any = A_arbace_j2g_dyn_A_const_200; if linked_1641 == nil { tmp9 = ifn_1642.Invoke_O_O__O(arg_1643, arg_1644) } else { tmp9 = linked_1641.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1640, arg_1643, arg_1644) }; arg_1638 = lang.Tuple_Create_O__IPersistentVector(tmp9); var arg_1639 any = A_arbace_j2g_dyn_A_const_201; if linked_1636 == nil { tmp8 = ifn_1637.Invoke_O_O__O(arg_1638, arg_1639) } else { tmp8 = linked_1636.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1635, arg_1638, arg_1639) }; var tmp10 any = tmp8; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyn_A_const_202; var tmp13 any; var root_1645 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1647 lang.IFn

			if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1649 any = A_arbace_j2g_dyn_A_const_203; var arg_1650 any = A_arbace_j2g_dyn_A_const_204; var arg_1651 any; var iter__1927001039__auto____6 any; var tmp14 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(g__2, n__0, arg_conv__3); var tmp15 *jrt.Class; var fncls__2002 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class
			if fncls__2002 == nil { var fncls__2002d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class = fncls__2002d; tmp15 = fncls__2002d } else { tmp15 = fncls__2002 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp17 any; var tmp18 any; var root_2003 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2003, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2005 lang.IFn; if linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any = n__0; if linked_2004 == nil { tmp18 = ifn_2005.Invoke_O__O(arg_2006) } else { tmp18 = linked_2004.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2003, arg_2006) }; if jrt.J2g_Truth(tmp18) { var root_2007 any = A_arbace_j2g_dyn_A_const_66.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = n__0; if linked_2008 == nil { tmp17 = ifn_2009.Invoke_O__O(arg_2010) } else { tmp17 = linked_2008.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2007, arg_2010) } } else { var tmp19 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp20 any; var root_2011 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = n__0; if linked_2012 == nil { tmp20 = ifn_2013.Invoke_O__O(arg_2014) } else { tmp20 = linked_2012.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2011, arg_2014) }; tmp17 = tmp19.Invoke_O__O(tmp20) }; arg_1651 = tmp16.Invoke_O__O(tmp17)
//line :281:1
			if linked_1646 == nil { tmp13 = ifn_1647.Invoke_O_O_O_O__O(arg_1648, arg_1649, arg_1650, arg_1651) } else { tmp13 = linked_1646.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1645, arg_1648, arg_1649, arg_1650, arg_1651) }
//line :279:1
			tmp3 = tmp4.Invoke_O_O_O_O__O(tmp5, tmp7, tmp10, tmp11.Invoke_O_O__O(tmp12, tmp13)) }
//line :271:1
		return nil }(); var root_1619 any = A_arbace_j2g_dyn_A_const_193.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1621 lang.IFn; if






	linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; if linked_1620 == nil { ifn_1621.Invoke__O() } else { linked_1620.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1619) }; if /*line :271:1*/ tmp21 != nil { panic(tmp21) }; return tmp3 }



func A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New() *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Ctor() {}
//line :275:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Invoke_O_O_O__O(self, d__1, x__2 any) any { var tmp1 any; var root_1604 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = d__1; if linked_1605 == nil { tmp1 = ifn_1606.Invoke_O__O(arg_1607) } else { tmp1 = linked_1605.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1604, arg_1607) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_190; var tmp4 any; var root_1608 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = A_arbace_j2g_dyn_A_const_73; var arg_1612 any = d__1; if linked_1609 == nil { tmp4 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { tmp4 = linked_1609.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) }; return tmp2.Invoke_O_O_O__O(tmp3, tmp4, x__2) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_10) { return x__2 } else { if A_arbace_j2g_dyn_A_const_81 != nil {

	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_191; var tmp8 any = A_arbace_j2g_dyn_A_const_192; var tmp9 any; var root_1613 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = A_arbace_j2g_dyn_A_const_73; var arg_1617 any = d__1; if linked_1614 == nil { tmp9 = ifn_1615.Invoke_O_O__O(arg_1616, arg_1617) } else { tmp9 = linked_1614.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1613, arg_1616, arg_1617) }; return tmp5.Invoke_O_O__O(tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9), x__2) } else {
//line :275:1
		return nil } } } }






func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :282:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Ctor_O_O_O(c__g, c__n, c__arg_conv any) { t.F_g = c__g; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :282:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Invoke_O_O__O(self, s__711000244__1 any) any { var tmp1 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(self, t.F_g, s__711000244__1, t.F_n, t.F_arg_conv); var tmp2 *jrt.Class; var fncls__2001 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class; if fncls__2001 == nil { var fncls__2001d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class = fncls__2001d; tmp2 = fncls__2001d } else { tmp2 = fncls__2001 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :282:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :282:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Ctor_O_O_O_O_O(c__iter__711000243, c__g, c__s__711000244, c__n, c__arg_conv any) { t.F_iter__711000243 = c__iter__711000243; t.F_g = c__g; t.F_s__711000244 = c__s__711000244; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :282:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Invoke_O__O(self any) any { { var s__711000244__1 any; var t_ any = t.F_s__711000244; t.F_s__711000244 = nil; s__711000244__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1652 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = s__711000244__1; if linked_1653 == nil { temp__1927000414__auto____2 = ifn_1654.Invoke_O__O(arg_1655) } else { temp__1927000414__auto____2 = linked_1653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1652, arg_1655) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000244__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1656 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = s__711000244__3; if linked_1657 == nil { tmp1 = ifn_1658.Invoke_O__O(arg_1659) } else { tmp1 = linked_1657.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1656, arg_1659) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1660 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = s__711000244__3; if linked_1661 == nil { c__1927001037__auto____4 = ifn_1662.Invoke_O__O(arg_1663) } else { c__1927001037__auto____4 = linked_1661.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1660, arg_1663) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000246__6 any; var root_1664 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1665 == nil { b__711000246__6 = ifn_1666.Invoke_O__O(arg_1667) } else { b__711000246__6 = linked_1665.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1664, arg_1667) }; var tmp2 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(t.F_g, t.F_n, b__711000246__6, t.F_arg_conv, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1813 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class; if fncls__1813 == nil { var fncls__1813d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class = fncls__1813d; tmp3 = fncls__1813d } else { tmp3 = fncls__1813 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1814 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1816 lang.IFn; if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any; var root_1819 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = b__711000246__6; if linked_1820 == nil { arg_1817 = ifn_1821.Invoke_O__O(arg_1822) } else { arg_1817 = linked_1820.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1819, arg_1822) }; var arg_1818 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp5 any; var root_1823 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = s__711000244__3; if linked_1824 == nil { tmp5 = ifn_1825.Invoke_O__O(arg_1826) } else { tmp5 = linked_1824.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1823, arg_1826) }; arg_1818 = tmp4.Invoke_O__O(tmp5); if linked_1815 == nil { return ifn_1816.Invoke_O_O__O(arg_1817, arg_1818) } else { return linked_1815.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1814, arg_1817, arg_1818) } } else { var root_1827 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any; var root_1832 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = b__711000246__6; if linked_1833 == nil { arg_1830 = ifn_1834.Invoke_O__O(arg_1835) } else { arg_1830 = linked_1833.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1832, arg_1835) }; var arg_1831 any; if linked_1828 == nil { return ifn_1829.Invoke_O_O__O(arg_1830, arg_1831) } else { return linked_1828.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1827, arg_1830, arg_1831) } } } else { var mm__4 any; var root_1836 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = s__711000244__3; if linked_1837 == nil { mm__4 = ifn_1838.Invoke_O__O(arg_1839) } else { mm__4 = linked_1837.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1836, arg_1839) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1840 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any; var root_1844 any = A_arbace_j2g_dyn_A_const_167.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = mm__4; if linked_1845 == nil { arg_1843 = ifn_1846.Invoke_O__O(arg_1847) } else { arg_1843 = linked_1845.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1844, arg_1847) }; if linked_1841 == nil { and__1927000168__auto____6 = ifn_1842.Invoke_O__O(arg_1843) } else { and__1927000168__auto____6 = linked_1841.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1840, arg_1843) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1848 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1849 == nil { tmp6 = ifn_1850.Invoke_O__O(arg_1851) } else { tmp6 = linked_1849.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1848, arg_1851) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :282:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_1852 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1854 lang.IFn

		if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any; var root_1856 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = t.F_n; if linked_1857 == nil { arg_1855 = ifn_1858.Invoke_O__O(arg_1859) } else { arg_1855 = linked_1857.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1856, arg_1859) }; if linked_1853 == nil { or__1927000174__auto____5 = ifn_1854.Invoke_O__O(arg_1855) } else { or__1927000174__auto____5 = linked_1853.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1852, arg_1855) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_1860 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any; var root_1865 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_1868 any = tmp8.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_1869 any; var root_1870 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = t.F_n; if linked_1871 == nil { arg_1869 = ifn_1872.Invoke_O__O(arg_1873) } else { arg_1869 = linked_1871.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1870, arg_1873) }; if linked_1866 == nil { arg_1863 = ifn_1867.Invoke_O_O__O(arg_1868, arg_1869) } else { arg_1863 = linked_1866.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1865, arg_1868, arg_1869) }; var arg_1864 any; var root_1874 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1874, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var arg_1877 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1875 == nil { arg_1864 = ifn_1876.Invoke_O__O(arg_1877) } else { arg_1864 = linked_1875.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1874, arg_1877) }; if linked_1861 == nil { tmp7 = ifn_1862.Invoke_O_O__O(arg_1863, arg_1864) } else { tmp7 = linked_1861.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1860, arg_1863, arg_1864) } }
//line :282:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_1878 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1878, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1880 lang.IFn



			if linked_1879 == nil { ifn_1880 = lang.IFn_Cast(root_1878) } else { ifn_1880 = nil }; var arg_1881 any = t.F_n; if linked_1879 == nil { tmp9 = ifn_1880.Invoke_O__O(arg_1881) } else { tmp9 = linked_1879.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1878, arg_1881) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4) } else { var root_1882 any = A_arbace_j2g_dyn_A_const_208.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1882, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1884 lang.IFn; if linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1885 any = t.F_n; var arg_1886 any = mm__4; if linked_1883 == nil { real__5 = ifn_1884.Invoke_O_O__O(arg_1885, arg_1886) } else { real__5 = linked_1883.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1882, arg_1885, arg_1886) } }
//line :282:1
			var vec__711000259__6 any; var root_1887 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1889 lang.IFn




			if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1888 == nil { vec__711000259__6 = ifn_1889.Invoke_O__O(arg_1890) } else { vec__711000259__6 = linked_1888.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1887, arg_1890) }
//line :282:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000262__9 any; var root_1891 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1893 lang.IFn; _ = ___8





			if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = real__5; if linked_1892 == nil { vec__711000262__9 = ifn_1893.Invoke_O__O(arg_1894) } else { vec__711000262__9 = linked_1892.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1891, arg_1894) }
//line :282:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_1895 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_209; var tmp12 any = A_arbace_j2g_dyn_A_const_210; var tmp13 any = A_arbace_j2g_dyn_A_const_211; var tmp14 any; var tmp15 any; var root_1900 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1900, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1902 lang.IFn








				if linked_1901 == nil { ifn_1902 = lang.IFn_Cast(root_1900) } else { ifn_1902 = nil }; var arg_1903 any = ps__7; if linked_1901 == nil { tmp15 = ifn_1902.Invoke_O__O(arg_1903) } else { tmp15 = linked_1901.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1900, arg_1903) }; if jrt.J2g_Truth(tmp15) { var root_1904 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1904, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1908 any = A_arbace_j2g_dyn_A_const_212; var arg_1909 any = A_arbace_j2g_dyn_A_const_238; var arg_1910 any; var root_1911 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1913 lang.IFn; if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = A_arbace_j2g_dyn_A_const_214.GetRawRoot__O(); var arg_1915 any = ps__7; if linked_1912 == nil { arg_1910 = ifn_1913.Invoke_O_O__O(arg_1914, arg_1915) } else { arg_1910 = linked_1912.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1911, arg_1914, arg_1915) }; if linked_1905 == nil { tmp14 = ifn_1906.Invoke_O_O_O_O__O(arg_1907, arg_1908, arg_1909, arg_1910) } else { tmp14 = linked_1905.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1904, arg_1907, arg_1908, arg_1909, arg_1910) } } else { tmp14 = nil }
//line :290:1
				var tmp16 any = tmp14; var tmp17 any = A_arbace_j2g_dyn_A_const_215; var tmp18 any = A_arbace_j2g_dyn_A_const_216; var tmp19 any = A_arbace_j2g_dyn_A_const_217; var tmp20 any; var root_1916 any = A_arbace_j2g_dyn_A_const_218.GetRawRoot__O(); var linked_1917 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1916, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1918 lang.IFn


				if linked_1917 == nil { ifn_1918 = lang.IFn_Cast(root_1916) } else { ifn_1918 = nil }; var arg_1919 any = A_arbace_j2g_dyn_A_const_219; var arg_1920 any; var root_1922 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any; var tmp21 any; var root_1927 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1929 lang.IFn; if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = A_arbace_j2g_dyn_A_const_220; var arg_1931 any = A_arbace_j2g_dyn_A_const_239; if linked_1928 == nil { tmp21 = ifn_1929.Invoke_O_O__O(arg_1930, arg_1931) } else { tmp21 = linked_1928.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1927, arg_1930, arg_1931) }; arg_1925 = lang.Tuple_Create_O__IPersistentVector(tmp21); var arg_1926 any = A_arbace_j2g_dyn_A_const_240; if linked_1923 == nil { arg_1920 = ifn_1924.Invoke_O_O__O(arg_1925, arg_1926) } else { arg_1920 = linked_1923.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1922, arg_1925, arg_1926) }; var arg_1921 any; var root_1932 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1934 lang.IFn
				if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any; var tmp22 any; var or__1927000174__auto____12 any; var root_1937 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1939 lang.IFn
				if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = t.F_n; if linked_1938 == nil { or__1927000174__auto____12 = ifn_1939.Invoke_O__O(arg_1940) } else { or__1927000174__auto____12 = linked_1938.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1937, arg_1940) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp22 = or__1927000174__auto____12 } else { var root_1941 any = A_arbace_j2g_dyn_A_const_223.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = t.F_n; if linked_1942 == nil { tmp22 = ifn_1943.Invoke_O__O(arg_1944) } else { tmp22 = linked_1942.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1941, arg_1944) } }; if jrt.J2g_Truth(tmp22) { arg_1935 = nil } else { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp24 any; var root_1945 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any = A_arbace_j2g_dyn_A_const_73; var arg_1949 any = t.F_n; var arg_1950 any = Lit_30; if linked_1946 == nil { tmp24 = ifn_1947.Invoke_O_O_O__O(arg_1948, arg_1949, arg_1950) } else { tmp24 = linked_1946.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1945, arg_1948, arg_1949, arg_1950) }; arg_1935 = lang.Tuple_Create_O__IPersistentVector(tmp23.Invoke_O__O(tmp24)) }
//line :294:1
				var arg_1936 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyn_A_const_224; var tmp27 any = A_arbace_j2g_dyn_A_const_233; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyn_A_const_234; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_dyn_A_const_235; var tmp32 any; var root_1981 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1983 lang.IFn

				if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any = t.F_g; if linked_1982 == nil { tmp32 = ifn_1983.Invoke_O__O(arg_1984) } else { tmp32 = linked_1982.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1981, arg_1984) }
//line :294:1
				var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28.Invoke_O_O__O(tmp29, tmp30.Invoke_O_O_O_O__O(tmp31, tmp32, A_arbace_j2g_dyn_A_const_236, A_arbace_j2g_dyn_A_const_243))); var tmp34 any = A_arbace_j2g_dyn_A_const_241; var tmp35 any = A_arbace_j2g_dyn_A_const_242; var tmp36 any; var root_1951 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1953 lang.IFn




				if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1955 any; var root_1959 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp38 any; var root_1963 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1965 lang.IFn; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any = real__5; if linked_1964 == nil { tmp38 = ifn_1965.Invoke_O__O(arg_1966) } else { tmp38 = linked_1964.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1963, arg_1966) }; arg_1962 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_1960 == nil { arg_1955 = ifn_1961.Invoke_O__O(arg_1962) } else { arg_1955 = linked_1960.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1959, arg_1962) }; var arg_1956 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp40 any; var root_1967 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1967, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1969 lang.IFn
				if linked_1968 == nil { ifn_1969 = lang.IFn_Cast(root_1967) } else { ifn_1969 = nil }; var arg_1970 any; var tmp41 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp42 any; var root_1971 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any = t.F_n; if linked_1972 == nil { tmp42 = ifn_1973.Invoke_O__O(arg_1974) } else { tmp42 = linked_1972.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1971, arg_1974) }; arg_1970 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp41, jrt.RefArrayOf(jrt.Object_class, nil, tmp42)).Ref(); if linked_1968 == nil { tmp40 = ifn_1969.Invoke_O__O(arg_1970) } else { tmp40 = linked_1968.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1967, arg_1970) }; arg_1956 = tmp39.Invoke_O_O__O(tmp40, A_arbace_j2g_dyn_A_const_227)
//line :299:1
				var arg_1957 any = A_arbace_j2g_dyn_A_const_228; var arg_1958 any; var root_1975 any = A_arbace_j2g_dyn_A_const_229.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1975, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1977 lang.IFn

				if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any; var tmp43 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(t.F_arg_conv); var tmp44 *jrt.Class; var fncls__1980 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class; if fncls__1980 == nil { var fncls__1980d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class = fncls__1980d; tmp44 = fncls__1980d } else { tmp44 = fncls__1980 }; arg_1978 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil); var arg_1979 any = ps__7; if linked_1976 == nil { arg_1958 = ifn_1977.Invoke_O_O__O(arg_1978, arg_1979) } else { arg_1958 = linked_1976.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1975, arg_1978, arg_1979) }
//line :299:1
				if linked_1952 == nil { tmp36 = ifn_1953.Invoke_O_O_O_O_O__O(arg_1954, arg_1955, arg_1956, arg_1957, arg_1958) } else { tmp36 = linked_1952.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1951, arg_1954, arg_1955, arg_1956, arg_1957, arg_1958) }
//line :294:1
				arg_1936 = lang.Tuple_Create_O__IPersistentVector(tmp25.Invoke_O_O_O_O_O_O__O(tmp26, tmp33, tmp34, tmp35, tmp36, A_arbace_j2g_dyn_A_const_232)); if linked_1933 == nil { arg_1921 = ifn_1934.Invoke_O_O__O(arg_1935, arg_1936) } else { arg_1921 = linked_1933.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1932, arg_1935, arg_1936) }
//line :293:1
				if linked_1917 == nil { tmp20 = ifn_1918.Invoke_O_O_O__O(arg_1919, arg_1920, arg_1921) } else { tmp20 = linked_1917.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1916, arg_1919, arg_1920, arg_1921) }
//line :290:1
				arg_1898 = tmp10.Invoke_O_O_O_O_O_O_O_O__O(tmp11, tmp12, tmp13, tmp16, tmp17, tmp18, tmp19, tmp20)
//line :282:1
				var arg_1899 any; var tmp45 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp46 any; var root_1985 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1987 lang.IFn; if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = s__711000244__3; if linked_1986 == nil { tmp46 = ifn_1987.Invoke_O__O(arg_1988) } else { tmp46 = linked_1986.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1985, arg_1988) }; arg_1899 = tmp45.Invoke_O__O(tmp46); if linked_1896 == nil { return ifn_1897.Invoke_O_O__O(arg_1898, arg_1899) } else { return linked_1896.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1895, arg_1898, arg_1899) } } else { var tmp47 any; var root_1989 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = s__711000244__3; if linked_1990 == nil { tmp47 = ifn_1991.Invoke_O__O(arg_1992) } else { tmp47 = linked_1990.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1989, arg_1992) }; s__711000244__1 = tmp47; continue L1 } } else { var tmp48 any; var root_1993 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = s__711000244__3; if linked_1994 == nil { tmp48 = ifn_1995.Invoke_O__O(arg_1996) } else { tmp48 = linked_1994.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1993, arg_1996) }; s__711000244__1 = tmp48; continue L1 } } else { var tmp49 any; var root_1997 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1999 lang.IFn; if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = s__711000244__3; if linked_1998 == nil { tmp49 = ifn_1999.Invoke_O__O(arg_2000) } else { tmp49 = linked_1998.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1997, arg_2000) }; s__711000244__1 = tmp49; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :282:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :282:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Ctor_O_O_O_O_I_O(c__g, c__n, c__b__711000246, c__arg_conv any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_g = c__g; t.F_n = c__n; t.F_b__711000246 = c__b__711000246; t.F_arg_conv = c__arg_conv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :282:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Invoke_O__O(self any) any { { var i__711000245__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000245__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000245__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1668 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any; var root_1672 any = A_arbace_j2g_dyn_A_const_167.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = mm__2; if linked_1673 == nil { arg_1671 = ifn_1674.Invoke_O__O(arg_1675) } else { arg_1671 = linked_1673.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1672, arg_1675) }; if linked_1669 == nil { and__1927000168__auto____4 = ifn_1670.Invoke_O__O(arg_1671) } else { and__1927000168__auto____4 = linked_1669.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1668, arg_1671) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1676 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1677 == nil { tmp2 = ifn_1678.Invoke_O__O(arg_1679) } else { tmp2 = linked_1677.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1676, arg_1679) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :282:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_1680 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1682 lang.IFn

		if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any; var root_1684 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = t.F_n; if linked_1685 == nil { arg_1683 = ifn_1686.Invoke_O__O(arg_1687) } else { arg_1683 = linked_1685.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1684, arg_1687) }; if linked_1681 == nil { or__1927000174__auto____3 = ifn_1682.Invoke_O__O(arg_1683) } else { or__1927000174__auto____3 = linked_1681.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1680, arg_1683) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_1688 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any; var root_1693 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_1696 any = tmp4.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_1697 any; var root_1698 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1698, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1700 lang.IFn; if linked_1699 == nil { ifn_1700 = lang.IFn_Cast(root_1698) } else { ifn_1700 = nil }; var arg_1701 any = t.F_n; if linked_1699 == nil { arg_1697 = ifn_1700.Invoke_O__O(arg_1701) } else { arg_1697 = linked_1699.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1698, arg_1701) }; if linked_1694 == nil { arg_1691 = ifn_1695.Invoke_O_O__O(arg_1696, arg_1697) } else { arg_1691 = linked_1694.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1693, arg_1696, arg_1697) }; var arg_1692 any; var root_1702 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1704 lang.IFn; if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1703 == nil { arg_1692 = ifn_1704.Invoke_O__O(arg_1705) } else { arg_1692 = linked_1703.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1702, arg_1705) }; if linked_1689 == nil { tmp3 = ifn_1690.Invoke_O_O__O(arg_1691, arg_1692) } else { tmp3 = linked_1689.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1688, arg_1691, arg_1692) } }
//line :282:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_1706 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1708 lang.IFn



			if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = t.F_n; if linked_1707 == nil { tmp5 = ifn_1708.Invoke_O__O(arg_1709) } else { tmp5 = linked_1707.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1706, arg_1709) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2) } else { var root_1710 any = A_arbace_j2g_dyn_A_const_208.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1712 lang.IFn; if linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = t.F_n; var arg_1714 any = mm__2; if linked_1711 == nil { real__3 = ifn_1712.Invoke_O_O__O(arg_1713, arg_1714) } else { real__3 = linked_1711.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1710, arg_1713, arg_1714) } }
//line :282:1
			var vec__711000250__4 any; var root_1715 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1717 lang.IFn




			if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1716 == nil { vec__711000250__4 = ifn_1717.Invoke_O__O(arg_1718) } else { vec__711000250__4 = linked_1716.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1715, arg_1718) }
//line :282:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000253__7 any; var root_1719 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1721 lang.IFn; _ = ___6





			if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = real__3; if linked_1720 == nil { vec__711000253__7 = ifn_1721.Invoke_O__O(arg_1722) } else { vec__711000253__7 = linked_1720.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1719, arg_1722) }
//line :282:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_1723 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = t.F_b__711000246; var arg_1727 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_209; var tmp8 any = A_arbace_j2g_dyn_A_const_210; var tmp9 any = A_arbace_j2g_dyn_A_const_211; var tmp10 any; var tmp11 any; var root_1728 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1730 lang.IFn








				if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = ps__5; if linked_1729 == nil { tmp11 = ifn_1730.Invoke_O__O(arg_1731) } else { tmp11 = linked_1729.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1728, arg_1731) }; if jrt.J2g_Truth(tmp11) { var root_1732 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1736 any = A_arbace_j2g_dyn_A_const_212; var arg_1737 any = A_arbace_j2g_dyn_A_const_213; var arg_1738 any; var root_1739 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = A_arbace_j2g_dyn_A_const_214.GetRawRoot__O(); var arg_1743 any = ps__5; if linked_1740 == nil { arg_1738 = ifn_1741.Invoke_O_O__O(arg_1742, arg_1743) } else { arg_1738 = linked_1740.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1739, arg_1742, arg_1743) }; if linked_1733 == nil { tmp10 = ifn_1734.Invoke_O_O_O_O__O(arg_1735, arg_1736, arg_1737, arg_1738) } else { tmp10 = linked_1733.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1732, arg_1735, arg_1736, arg_1737, arg_1738) } } else { tmp10 = nil }
//line :290:1
				var tmp12 any = tmp10; var tmp13 any = A_arbace_j2g_dyn_A_const_215; var tmp14 any = A_arbace_j2g_dyn_A_const_216; var tmp15 any = A_arbace_j2g_dyn_A_const_217; var tmp16 any; var root_1744 any = A_arbace_j2g_dyn_A_const_218.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1746 lang.IFn


				if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = A_arbace_j2g_dyn_A_const_219; var arg_1748 any; var root_1750 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any; var tmp17 any; var root_1755 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1755, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1757 lang.IFn; if linked_1756 == nil { ifn_1757 = lang.IFn_Cast(root_1755) } else { ifn_1757 = nil }; var arg_1758 any = A_arbace_j2g_dyn_A_const_220; var arg_1759 any = A_arbace_j2g_dyn_A_const_221; if linked_1756 == nil { tmp17 = ifn_1757.Invoke_O_O__O(arg_1758, arg_1759) } else { tmp17 = linked_1756.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1755, arg_1758, arg_1759) }; arg_1753 = lang.Tuple_Create_O__IPersistentVector(tmp17); var arg_1754 any = A_arbace_j2g_dyn_A_const_222; if linked_1751 == nil { arg_1748 = ifn_1752.Invoke_O_O__O(arg_1753, arg_1754) } else { arg_1748 = linked_1751.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1750, arg_1753, arg_1754) }; var arg_1749 any; var root_1760 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1760, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1762 lang.IFn
				if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any; var tmp18 any; var or__1927000174__auto____10 any; var root_1765 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1767 lang.IFn
				if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = t.F_n; if linked_1766 == nil { or__1927000174__auto____10 = ifn_1767.Invoke_O__O(arg_1768) } else { or__1927000174__auto____10 = linked_1766.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1765, arg_1768) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp18 = or__1927000174__auto____10 } else { var root_1769 any = A_arbace_j2g_dyn_A_const_223.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = t.F_n; if linked_1770 == nil { tmp18 = ifn_1771.Invoke_O__O(arg_1772) } else { tmp18 = linked_1770.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1769, arg_1772) } }; if jrt.J2g_Truth(tmp18) { arg_1763 = nil } else { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp20 any; var root_1773 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = A_arbace_j2g_dyn_A_const_73; var arg_1777 any = t.F_n; var arg_1778 any = Lit_30; if linked_1774 == nil { tmp20 = ifn_1775.Invoke_O_O_O__O(arg_1776, arg_1777, arg_1778) } else { tmp20 = linked_1774.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1773, arg_1776, arg_1777, arg_1778) }; arg_1763 = lang.Tuple_Create_O__IPersistentVector(tmp19.Invoke_O__O(tmp20)) }
//line :294:1
				var arg_1764 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyn_A_const_224; var tmp23 any = A_arbace_j2g_dyn_A_const_233; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyn_A_const_234; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_235; var tmp28 any; var root_1809 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1811 lang.IFn

				if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = t.F_g; if linked_1810 == nil { tmp28 = ifn_1811.Invoke_O__O(arg_1812) } else { tmp28 = linked_1810.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1809, arg_1812) }
//line :294:1
				var tmp29 any = lang.Tuple_Create_O_O__IPersistentVector(tmp23, tmp24.Invoke_O_O__O(tmp25, tmp26.Invoke_O_O_O_O__O(tmp27, tmp28, A_arbace_j2g_dyn_A_const_236, A_arbace_j2g_dyn_A_const_237))); var tmp30 any = A_arbace_j2g_dyn_A_const_225; var tmp31 any = A_arbace_j2g_dyn_A_const_226; var tmp32 any; var root_1779 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1781 lang.IFn




				if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1783 any; var root_1787 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp34 any; var root_1791 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = real__3; if linked_1792 == nil { tmp34 = ifn_1793.Invoke_O__O(arg_1794) } else { tmp34 = linked_1792.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1791, arg_1794) }; arg_1790 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, nil, tmp34)).Ref(); if linked_1788 == nil { arg_1783 = ifn_1789.Invoke_O__O(arg_1790) } else { arg_1783 = linked_1788.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1787, arg_1790) }; var arg_1784 any; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp36 any; var root_1795 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1797 lang.IFn
				if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp38 any; var root_1799 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = t.F_n; if linked_1800 == nil { tmp38 = ifn_1801.Invoke_O__O(arg_1802) } else { tmp38 = linked_1800.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1799, arg_1802) }; arg_1798 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_1796 == nil { tmp36 = ifn_1797.Invoke_O__O(arg_1798) } else { tmp36 = linked_1796.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1795, arg_1798) }; arg_1784 = tmp35.Invoke_O_O__O(tmp36, A_arbace_j2g_dyn_A_const_227)
//line :299:1
				var arg_1785 any = A_arbace_j2g_dyn_A_const_228; var arg_1786 any; var root_1803 any = A_arbace_j2g_dyn_A_const_229.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1805 lang.IFn

				if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any; var tmp39 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(t.F_arg_conv); var tmp40 *jrt.Class; var fncls__1808 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class; if fncls__1808 == nil { var fncls__1808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class = fncls__1808d; tmp40 = fncls__1808d } else { tmp40 = fncls__1808 }; arg_1806 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil); var arg_1807 any = ps__5; if linked_1804 == nil { arg_1786 = ifn_1805.Invoke_O_O__O(arg_1806, arg_1807) } else { arg_1786 = linked_1804.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1803, arg_1806, arg_1807) }
//line :299:1
				if linked_1780 == nil { tmp32 = ifn_1781.Invoke_O_O_O_O_O__O(arg_1782, arg_1783, arg_1784, arg_1785, arg_1786) } else { tmp32 = linked_1780.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1779, arg_1782, arg_1783, arg_1784, arg_1785, arg_1786) }
//line :294:1
				arg_1764 = lang.Tuple_Create_O__IPersistentVector(tmp21.Invoke_O_O_O_O_O_O__O(tmp22, tmp29, tmp30, tmp31, tmp32, A_arbace_j2g_dyn_A_const_232)); if linked_1761 == nil { arg_1749 = ifn_1762.Invoke_O_O__O(arg_1763, arg_1764) } else { arg_1749 = linked_1761.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1760, arg_1763, arg_1764) }
//line :293:1
				if linked_1745 == nil { tmp16 = ifn_1746.Invoke_O_O_O__O(arg_1747, arg_1748, arg_1749) } else { tmp16 = linked_1745.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1744, arg_1747, arg_1748, arg_1749) }
//line :290:1
				arg_1727 = tmp6.Invoke_O_O_O_O_O_O_O_O__O(tmp7, tmp8, tmp9, tmp12, tmp13, tmp14, tmp15, tmp16)
//line :282:1
				if linked_1724 == nil { ifn_1725.Invoke_O_O__O(arg_1726, arg_1727) } else { linked_1724.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1723, arg_1726, arg_1727) }; i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


















func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A{}; t.Ctor_O(p0); return t }
//line :301:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :301:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_230, A_arbace_j2g_dyn_A_const_231, i__1)) }
//line :301:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A{}; t.Ctor_O(p0); return t }
//line :301:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :301:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_230, A_arbace_j2g_dyn_A_const_231, i__1)) }


func A_arbace_j2g_dyn_go_method_names_A_New() *A_arbace_j2g_dyn_go_method_names_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Ctor() {}
//line :304:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Invoke_O_O__O(self, n__0 any) any {




	var root_2015 any = A_arbace_j2g_dyn_A_const_244.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2017 lang.IFn; if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_2019 any; var root_2020 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2022 lang.IFn
	if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New(); var tmp2 *jrt.Class; var fncls__2245 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class
	if fncls__2245 == nil { var fncls__2245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class = fncls__2245d; tmp2 = fncls__2245d } else { tmp2 = fncls__2245 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_2246 any = A_arbace_j2g_dyn_A_const_168.GetRawRoot__O(); var linked_2247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2246, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_2248 lang.IFn; if linked_2247 == nil { ifn_2248 = lang.IFn_Cast(root_2246) } else { ifn_2248 = nil }; var arg_2249 any = n__0; if linked_2247 == nil { tmp4 = ifn_2248.Invoke_O__O(arg_2249) } else { tmp4 = linked_2247.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_2246, arg_2249) }; arg_2023 = tmp3.Invoke_O__O(tmp4)
//line :310:1
	var arg_2024 any; var iter__1927001039__auto____2_2 any; var tmp5 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(n__0); var tmp6 *jrt.Class
	var fncls__2338 /*line :310:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class








	if fncls__2338 == nil { var fncls__2338d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class = fncls__2338d; tmp6 = fncls__2338d } else { tmp6 = fncls__2338 }; iter__1927001039__auto____2_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2_2); var tmp8 any; var root_2339 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = n__0; if linked_2340 == nil { tmp8 = ifn_2341.Invoke_O__O(arg_2342) } else { tmp8 = linked_2340.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_2339, arg_2342) }; arg_2024 = tmp7.Invoke_O__O(tmp8)
//line :310:1
	if linked_2021 == nil { arg_2019 = ifn_2022.Invoke_O_O__O(arg_2023, arg_2024) } else { arg_2019 = linked_2021.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2020, arg_2023, arg_2024) }
//line :309:1
	if linked_2016 == nil { return ifn_2017.Invoke_O_O__O(arg_2018, arg_2019) } else { return linked_2016.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2015, arg_2018, arg_2019)
	} }
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Ctor() {}
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Invoke_O_O__O(self, s__711000271__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(self, s__711000271__1); var tmp2 *jrt.Class; var fncls__2244 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class; if fncls__2244 == nil { var fncls__2244d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class = fncls__2244d; tmp2 = fncls__2244d } else { tmp2 = fncls__2244 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :311:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Ctor_O_O(c__iter__711000270, c__s__711000271 any) { t.F_iter__711000270 = c__iter__711000270; t.F_s__711000271 = c__s__711000271 }
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Invoke_O__O(self any) any { { var s__711000271__1 any; var t_ any = t.F_s__711000271; t.F_s__711000271 = nil; s__711000271__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2025 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = s__711000271__1; if linked_2026 == nil { temp__1927000414__auto____2 = ifn_2027.Invoke_O__O(arg_2028) } else { temp__1927000414__auto____2 = linked_2026.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2025, arg_2028) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_2029 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2029, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2031 lang.IFn; if linked_2030 == nil { ifn_2031 = lang.IFn_Cast(root_2029) } else { ifn_2031 = nil }; var arg_2032 any = xs__1927001018__auto____3; if linked_2030 == nil { c__4 = ifn_2031.Invoke_O__O(arg_2032) } else { c__4 = linked_2030.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2029, arg_2032) }; var tmp1 any; var and__1927000168__auto____5 any = c__4
														if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2033 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2033, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2035 lang.IFn; if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any = c__4; var arg_2037 any = Lit_98; if linked_2034 == nil { tmp1 = ifn_2035.Invoke_O_O__O(arg_2036, arg_2037) } else { tmp1 = linked_2034.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2033, arg_2036, arg_2037) } } else { tmp1 = and__1927000168__auto____5 }
//line :311:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New(); var tmp3 *jrt.Class; var fncls__2096 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class; if fncls__2096 == nil { var fncls__2096d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class = fncls__2096d; tmp3 = fncls__2096d } else { tmp3 = fncls__2096 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_2097 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2097, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2099 lang.IFn; if linked_2098 == nil { ifn_2099 = lang.IFn_Cast(root_2097) } else { ifn_2099 = nil }; var arg_2100 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var tmp6 any; var root_2101 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2103 lang.IFn

		if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = c__4; if linked_2102 == nil { tmp6 = ifn_2103.Invoke_O__O(arg_2104) } else { tmp6 = linked_2102.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2101, arg_2104) }; if jrt.J2g_Truth(tmp6) {
			var root_2105 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_2107 lang.IFn; if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var tmp7 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_2108 any = tmp7.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_2109 any; var root_2110 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2112 lang.IFn; if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; var arg_2113 any = c__4; if linked_2111 == nil { arg_2109 = ifn_2112.Invoke_O__O(arg_2113) } else { arg_2109 = linked_2111.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2110, arg_2113) }; if linked_2106 == nil { tmp5 = ifn_2107.Invoke_O_O__O(arg_2108, arg_2109) } else { tmp5 = linked_2106.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_2105, arg_2108, arg_2109) } } else {
//line :313:1
				var iter__1927001039__auto____6 any; var tmp8 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New(); var tmp9 *jrt.Class
				var fncls__2222 /*line :313:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class

				if fncls__2222 == nil { var fncls__2222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class = fncls__2222d; tmp9 = fncls__2222d } else { tmp9 = fncls__2222 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp11 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp12 any; var root_2223 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_2224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2223, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2225 lang.IFn; if linked_2224 == nil { ifn_2225 = lang.IFn_Cast(root_2223) } else { ifn_2225 = nil }; var arg_2226 any = c__4; if linked_2224 == nil { tmp12 = ifn_2225.Invoke_O__O(arg_2226) } else { tmp12 = linked_2224.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2223, arg_2226) }; tmp5 = tmp10.Invoke_O__O(tmp11.Invoke_O__O(tmp12)) }
//line :311:1
		arg_2100 = tmp4.Invoke_O__O(tmp5); if linked_2098 == nil { fs__1927001036__auto____6 = ifn_2099.Invoke_O__O(arg_2100) } else { fs__1927001036__auto____6 = linked_2098.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2097, arg_2100) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2227 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2228 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2227, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2229 lang.IFn; if linked_2228 == nil { ifn_2229 = lang.IFn_Cast(root_2227) } else { ifn_2229 = nil }; var arg_2230 any = fs__1927001036__auto____6; var arg_2231 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000270); var tmp14 any; var root_2232 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2232, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2234 lang.IFn; if linked_2233 == nil { ifn_2234 = lang.IFn_Cast(root_2232) } else { ifn_2234 = nil }; var arg_2235 any = s__711000271__1; if linked_2233 == nil { tmp14 = ifn_2234.Invoke_O__O(arg_2235) } else { tmp14 = linked_2233.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2232, arg_2235) }; arg_2231 = tmp13.Invoke_O__O(tmp14); if linked_2228 == nil { return ifn_2229.Invoke_O_O__O(arg_2230, arg_2231) } else { return linked_2228.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2227, arg_2230, arg_2231) } } else { var tmp15 any; var root_2236 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2236, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2238 lang.IFn; if linked_2237 == nil { ifn_2238 = lang.IFn_Cast(root_2236) } else { ifn_2238 = nil }; var arg_2239 any = s__711000271__1; if linked_2237 == nil { tmp15 = ifn_2238.Invoke_O__O(arg_2239) } else { tmp15 = linked_2237.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2236, arg_2239) }; s__711000271__1 = tmp15; continue L1 } } else { var tmp16 any; var root_2240 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2240, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2242 lang.IFn; if linked_2241 == nil { ifn_2242 = lang.IFn_Cast(root_2240) } else { ifn_2242 = nil }; var arg_2243 any = s__711000271__1; if linked_2241 == nil { tmp16 = ifn_2242.Invoke_O__O(arg_2243) } else { tmp16 = linked_2241.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2240, arg_2243) }; s__711000271__1 = tmp16; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :311:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Ctor() {}
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Invoke_O_O__O(self, s__711000273__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(s__711000273__1, self); var tmp2 *jrt.Class; var fncls__2095 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class; if fncls__2095 == nil { var fncls__2095d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class = fncls__2095d; tmp2 = fncls__2095d } else { tmp2 = fncls__2095 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :311:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A{}; t.Ctor_O_O(p0, p1); return t }
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Ctor_O_O(c__s__711000273, c__iter__711000272 any) { t.F_s__711000273 = c__s__711000273; t.F_iter__711000272 = c__iter__711000272 }
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Invoke_O__O(self any) any { { var s__711000273__1 any; var t_ any = t.F_s__711000273; t.F_s__711000273 = nil; s__711000273__1 = t_; for { var temp__1927000414__auto____2 any; var root_2038 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2040 lang.IFn; if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2041 any = s__711000273__1; if linked_2039 == nil { temp__1927000414__auto____2 = ifn_2040.Invoke_O__O(arg_2041) } else { temp__1927000414__auto____2 = linked_2039.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2038, arg_2041) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000273__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2042 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any = s__711000273__3; if linked_2043 == nil { tmp1 = ifn_2044.Invoke_O__O(arg_2045) } else { tmp1 = linked_2043.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2042, arg_2045) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2046 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2046, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2048 lang.IFn; if linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = s__711000273__3; if linked_2047 == nil { c__1927001037__auto____4 = ifn_2048.Invoke_O__O(arg_2049) } else { c__1927001037__auto____4 = linked_2047.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2046, arg_2049) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000275__6 any; var root_2050 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2050, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2052 lang.IFn; if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2051 == nil { b__711000275__6 = ifn_2052.Invoke_O__O(arg_2053) } else { b__711000275__6 = linked_2051.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2050, arg_2053) }; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(b__711000275__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2059 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class; if fncls__2059 == nil { var fncls__2059d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class = fncls__2059d; tmp3 = fncls__2059d } else { tmp3 = fncls__2059 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2060 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any; var root_2065 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = b__711000275__6; if linked_2066 == nil { arg_2063 = ifn_2067.Invoke_O__O(arg_2068) } else { arg_2063 = linked_2066.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2065, arg_2068) }; var arg_2064 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp5 any; var root_2069 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2071 lang.IFn; if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any = s__711000273__3; if linked_2070 == nil { tmp5 = ifn_2071.Invoke_O__O(arg_2072) } else { tmp5 = linked_2070.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2069, arg_2072) }; arg_2064 = tmp4.Invoke_O__O(tmp5); if linked_2061 == nil { return ifn_2062.Invoke_O_O__O(arg_2063, arg_2064) } else { return linked_2061.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2060, arg_2063, arg_2064) } } else { var root_2073 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2073, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2075 lang.IFn; if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any; var root_2078 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = b__711000275__6; if linked_2079 == nil { arg_2076 = ifn_2080.Invoke_O__O(arg_2081) } else { arg_2076 = linked_2079.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2078, arg_2081) }; var arg_2077 any; if linked_2074 == nil { return ifn_2075.Invoke_O_O__O(arg_2076, arg_2077) } else { return linked_2074.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2073, arg_2076, arg_2077) } } } else { var nme__4 any; var root_2082 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = s__711000273__3; if linked_2083 == nil { nme__4 = ifn_2084.Invoke_O__O(arg_2085) } else { nme__4 = linked_2083.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2082, arg_2085) }; var root_2086 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2088 lang.IFn; if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any = nme__4; var arg_2090 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp7 any; var root_2091 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2093 lang.IFn; if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any = s__711000273__3; if linked_2092 == nil { tmp7 = ifn_2093.Invoke_O__O(arg_2094) } else { tmp7 = linked_2092.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2091, arg_2094) }; arg_2090 = tmp6.Invoke_O__O(tmp7); if linked_2087 == nil { return ifn_2088.Invoke_O_O__O(arg_2089, arg_2090) } else { return linked_2087.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2086, arg_2089, arg_2090) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :311:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Ctor_O_I_O(c__b__711000275 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000275 = c__b__711000275; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :311:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Invoke_O__O(self any) any { { var i__711000274__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000274__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nme__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000274__1)); var root_2054 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = t.F_b__711000275; var arg_2058 any = nme__2; if linked_2055 == nil { ifn_2056.Invoke_O_O__O(arg_2057, arg_2058) } else { linked_2055.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2054, arg_2057, arg_2058) }; i__711000274__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000274__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Ctor() {}
//line :315:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Invoke_O_O__O(self, s__711000285__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(s__711000285__1, self); var tmp2 *jrt.Class; var fncls__2221 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class; if fncls__2221 == nil { var fncls__2221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class = fncls__2221d; tmp2 = fncls__2221d } else { tmp2 = fncls__2221 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :315:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A{}; t.Ctor_O_O(p0, p1); return t }
//line :315:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Ctor_O_O(c__s__711000285, c__iter__711000284 any) { t.F_s__711000285 = c__s__711000285; t.F_iter__711000284 = c__iter__711000284 }
//line :315:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Invoke_O__O(self any) any { { var s__711000285__1 any; var t_ any = t.F_s__711000285; t.F_s__711000285 = nil; s__711000285__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2114 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = s__711000285__1; if linked_2115 == nil { temp__1927000414__auto____2 = ifn_2116.Invoke_O__O(arg_2117) } else { temp__1927000414__auto____2 = linked_2115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2114, arg_2117) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000285__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2118 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2120 lang.IFn; if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any = s__711000285__3; if linked_2119 == nil { tmp1 = ifn_2120.Invoke_O__O(arg_2121) } else { tmp1 = linked_2119.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2118, arg_2121) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2122 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2124 lang.IFn; if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any = s__711000285__3; if linked_2123 == nil { c__1927001037__auto____4 = ifn_2124.Invoke_O__O(arg_2125) } else { c__1927001037__auto____4 = linked_2123.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2122, arg_2125) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000287__6 any; var root_2126 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2127 == nil { b__711000287__6 = ifn_2128.Invoke_O__O(arg_2129) } else { b__711000287__6 = linked_2127.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2126, arg_2129) }; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(b__711000287__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2158 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class; if fncls__2158 == nil { var fncls__2158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class = fncls__2158d; tmp3 = fncls__2158d } else { tmp3 = fncls__2158 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2159 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any; var root_2164 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2164, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2166 lang.IFn; if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var arg_2167 any = b__711000287__6; if linked_2165 == nil { arg_2162 = ifn_2166.Invoke_O__O(arg_2167) } else { arg_2162 = linked_2165.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2164, arg_2167) }; var arg_2163 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp5 any; var root_2168 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2168, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2170 lang.IFn; if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any = s__711000285__3; if linked_2169 == nil { tmp5 = ifn_2170.Invoke_O__O(arg_2171) } else { tmp5 = linked_2169.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2168, arg_2171) }; arg_2163 = tmp4.Invoke_O__O(tmp5); if linked_2160 == nil { return ifn_2161.Invoke_O_O__O(arg_2162, arg_2163) } else { return linked_2160.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2159, arg_2162, arg_2163) } } else { var root_2172 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2174 lang.IFn; if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any; var root_2177 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = b__711000287__6; if linked_2178 == nil { arg_2175 = ifn_2179.Invoke_O__O(arg_2180) } else { arg_2175 = linked_2178.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2177, arg_2180) }; var arg_2176 any; if linked_2173 == nil { return ifn_2174.Invoke_O_O__O(arg_2175, arg_2176) } else { return linked_2173.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2172, arg_2175, arg_2176) } } } else { var mm__4 any; var root_2181 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any = s__711000285__3; if linked_2182 == nil { mm__4 = ifn_2183.Invoke_O__O(arg_2184) } else { mm__4 = linked_2182.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2181, arg_2184) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2185 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2187 lang.IFn
																				if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any; var root_2189 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_2190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2189, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2191 lang.IFn; if linked_2190 == nil { ifn_2191 = lang.IFn_Cast(root_2189) } else { ifn_2191 = nil }; var arg_2192 any = mm__4; if linked_2190 == nil { arg_2188 = ifn_2191.Invoke_O__O(arg_2192) } else { arg_2188 = linked_2190.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2189, arg_2192) }; if linked_2186 == nil { and__1927000168__auto____5 = ifn_2187.Invoke_O__O(arg_2188) } else { and__1927000168__auto____5 = linked_2186.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2185, arg_2188) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2193 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2193, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = Lit_29; var arg_2197 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_2194 == nil { and__1927000168__auto____6 = ifn_2195.Invoke_O_O__O(arg_2196, arg_2197) } else { and__1927000168__auto____6 = linked_2194.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2193, arg_2196, arg_2197) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2198 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2198, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2200 lang.IFn; if linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var arg_2201 any = Lit_105; var arg_2202 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_2199 == nil { tmp6 = ifn_2200.Invoke_O_O__O(arg_2201, arg_2202) } else { tmp6 = linked_2199.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2198, arg_2201, arg_2202) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :315:1
	if jrt.J2g_Truth(tmp6) { var root_2203 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any; var root_2208 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2210 lang.IFn

		if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); var arg_2212 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_2209 == nil { arg_2206 = ifn_2210.Invoke_O_O__O(arg_2211, arg_2212) } else { arg_2206 = linked_2209.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2208, arg_2211, arg_2212) }
//line :315:1
		var arg_2207 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp8 any; var root_2213 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2213, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2215 lang.IFn; if linked_2214 == nil { ifn_2215 = lang.IFn_Cast(root_2213) } else { ifn_2215 = nil }; var arg_2216 any = s__711000285__3; if linked_2214 == nil { tmp8 = ifn_2215.Invoke_O__O(arg_2216) } else { tmp8 = linked_2214.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2213, arg_2216) }; arg_2207 = tmp7.Invoke_O__O(tmp8); if linked_2204 == nil { return ifn_2205.Invoke_O_O__O(arg_2206, arg_2207) } else { return linked_2204.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2203, arg_2206, arg_2207) } } else { var tmp9 any; var root_2217 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2217, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2219 lang.IFn; if linked_2218 == nil { ifn_2219 = lang.IFn_Cast(root_2217) } else { ifn_2219 = nil }; var arg_2220 any = s__711000285__3; if linked_2218 == nil { tmp9 = ifn_2219.Invoke_O__O(arg_2220) } else { tmp9 = linked_2218.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2217, arg_2220) }; s__711000285__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :315:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :315:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Ctor_O_I_O(c__b__711000287 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000287 = c__b__711000287; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :315:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Invoke_O__O(self any) any { { var i__711000286__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000286__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000286__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2130 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2132 lang.IFn
																					if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any; var root_2134 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = mm__2; if linked_2135 == nil { arg_2133 = ifn_2136.Invoke_O__O(arg_2137) } else { arg_2133 = linked_2135.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2134, arg_2137) }; if linked_2131 == nil { and__1927000168__auto____3 = ifn_2132.Invoke_O__O(arg_2133) } else { and__1927000168__auto____3 = linked_2131.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2130, arg_2133) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_2138 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2138, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2140 lang.IFn; if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = Lit_29; var arg_2142 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_2139 == nil { and__1927000168__auto____4 = ifn_2140.Invoke_O_O__O(arg_2141, arg_2142) } else { and__1927000168__auto____4 = linked_2139.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2138, arg_2141, arg_2142) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_2143 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = Lit_105; var arg_2147 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_2144 == nil { tmp2 = ifn_2145.Invoke_O_O__O(arg_2146, arg_2147) } else { tmp2 = linked_2144.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2143, arg_2146, arg_2147) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :315:1
	if jrt.J2g_Truth(tmp2) { var root_2148 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any = t.F_b__711000287; var arg_2152 any; var root_2153 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2153, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2155 lang.IFn

		if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); var arg_2157 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_2154 == nil { arg_2152 = ifn_2155.Invoke_O_O__O(arg_2156, arg_2157) } else { arg_2152 = linked_2154.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2153, arg_2156, arg_2157) }
//line :315:1
		if linked_2149 == nil { ifn_2150.Invoke_O_O__O(arg_2151, arg_2152) } else { linked_2149.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2148, arg_2151, arg_2152) }; i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } else { i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(p0 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A{}; t.Ctor_O(p0); return t }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Invoke_O_O__O(self, s__711000297__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(s__711000297__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__2337 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class; if fncls__2337 == nil { var fncls__2337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class = fncls__2337d; tmp2 = fncls__2337d } else { tmp2 = fncls__2337 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :319:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Ctor_O_O_O(c__s__711000297, c__n, c__iter__711000296 any) { t.F_s__711000297 = c__s__711000297; t.F_n = c__n; t.F_iter__711000296 = c__iter__711000296 }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Invoke_O__O(self any) any { { var s__711000297__1 any; var t_ any = t.F_s__711000297; t.F_s__711000297 = nil; s__711000297__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2250 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2252 lang.IFn; if linked_2251 == nil { ifn_2252 = lang.IFn_Cast(root_2250) } else { ifn_2252 = nil }; var arg_2253 any = s__711000297__1; if linked_2251 == nil { temp__1927000414__auto____2 = ifn_2252.Invoke_O__O(arg_2253) } else { temp__1927000414__auto____2 = linked_2251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2250, arg_2253) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000297__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2254 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2256 lang.IFn; if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any = s__711000297__3; if linked_2255 == nil { tmp1 = ifn_2256.Invoke_O__O(arg_2257) } else { tmp1 = linked_2255.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2254, arg_2257) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2258 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = s__711000297__3; if linked_2259 == nil { c__1927001037__auto____4 = ifn_2260.Invoke_O__O(arg_2261) } else { c__1927001037__auto____4 = linked_2259.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2258, arg_2261) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000299__6 any; var root_2262 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2263 == nil { b__711000299__6 = ifn_2264.Invoke_O__O(arg_2265) } else { b__711000299__6 = linked_2263.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2262, arg_2265) }; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(t.F_n, b__711000299__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2284 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class; if fncls__2284 == nil { var fncls__2284d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class = fncls__2284d; tmp3 = fncls__2284d } else { tmp3 = fncls__2284 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2285 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any; var root_2290 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = b__711000299__6; if linked_2291 == nil { arg_2288 = ifn_2292.Invoke_O__O(arg_2293) } else { arg_2288 = linked_2291.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2290, arg_2293) }; var arg_2289 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp5 any; var root_2294 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2294, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2296 lang.IFn; if linked_2295 == nil { ifn_2296 = lang.IFn_Cast(root_2294) } else { ifn_2296 = nil }; var arg_2297 any = s__711000297__3; if linked_2295 == nil { tmp5 = ifn_2296.Invoke_O__O(arg_2297) } else { tmp5 = linked_2295.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2294, arg_2297) }; arg_2289 = tmp4.Invoke_O__O(tmp5); if linked_2286 == nil { return ifn_2287.Invoke_O_O__O(arg_2288, arg_2289) } else { return linked_2286.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2285, arg_2288, arg_2289) } } else { var root_2298 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2298, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2300 lang.IFn; if linked_2299 == nil { ifn_2300 = lang.IFn_Cast(root_2298) } else { ifn_2300 = nil }; var arg_2301 any; var root_2303 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2305 lang.IFn; if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any = b__711000299__6; if linked_2304 == nil { arg_2301 = ifn_2305.Invoke_O__O(arg_2306) } else { arg_2301 = linked_2304.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2303, arg_2306) }; var arg_2302 any; if linked_2299 == nil { return ifn_2300.Invoke_O_O__O(arg_2301, arg_2302) } else { return linked_2299.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2298, arg_2301, arg_2302) } } } else { var j__4 any; var root_2307 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2307, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2309 lang.IFn; if linked_2308 == nil { ifn_2309 = lang.IFn_Cast(root_2307) } else { ifn_2309 = nil }; var arg_2310 any = s__711000297__3; if linked_2308 == nil { j__4 = ifn_2309.Invoke_O__O(arg_2310) } else { j__4 = linked_2308.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2307, arg_2310) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2311 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2311, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2313 lang.IFn; if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = j__4; var arg_2315 any = t.F_n; if linked_2312 == nil { and__1927000168__auto____5 = ifn_2313.Invoke_O_O__O(arg_2314, arg_2315) } else { and__1927000168__auto____5 = linked_2312.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2311, arg_2314, arg_2315) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2316 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2318 lang.IFn; if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any = j__4; if linked_2317 == nil { tmp6 = ifn_2318.Invoke_O__O(arg_2319) } else { tmp6 = linked_2317.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2316, arg_2319) } } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_2320 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2320, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp8 any; var root_2325 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2327 lang.IFn
														if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = j__4; if linked_2326 == nil { tmp8 = ifn_2327.Invoke_O__O(arg_2328) } else { tmp8 = linked_2326.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2325, arg_2328) }; arg_2323 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :319:1
	var arg_2324 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp10 any; var root_2329 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2329, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2331 lang.IFn; if linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any = s__711000297__3; if linked_2330 == nil { tmp10 = ifn_2331.Invoke_O__O(arg_2332) } else { tmp10 = linked_2330.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2329, arg_2332) }; arg_2324 = tmp9.Invoke_O__O(tmp10); if linked_2321 == nil { return ifn_2322.Invoke_O_O__O(arg_2323, arg_2324) } else { return linked_2321.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2320, arg_2323, arg_2324) } } else { var tmp11 any; var root_2333 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2333, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2335 lang.IFn; if linked_2334 == nil { ifn_2335 = lang.IFn_Cast(root_2333) } else { ifn_2335 = nil }; var arg_2336 any = s__711000297__3; if linked_2334 == nil { tmp11 = ifn_2335.Invoke_O__O(arg_2336) } else { tmp11 = linked_2334.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2333, arg_2336) }; s__711000297__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :319:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Ctor_O_O_I_O(c__n, c__b__711000299 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000299 = c__b__711000299; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Invoke_O__O(self any) any { { var i__711000298__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000298__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000298__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2266 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2266, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2268 lang.IFn; if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = j__2; var arg_2270 any = t.F_n; if linked_2267 == nil { and__1927000168__auto____3 = ifn_2268.Invoke_O_O__O(arg_2269, arg_2270) } else { and__1927000168__auto____3 = linked_2267.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2266, arg_2269, arg_2270) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2271 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2271, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2273 lang.IFn; if linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any = j__2; if linked_2272 == nil { tmp2 = ifn_2273.Invoke_O__O(arg_2274) } else { tmp2 = linked_2272.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2271, arg_2274) } } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_2275 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2277 lang.IFn; if linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var arg_2278 any = t.F_b__711000299; var arg_2279 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp4 any; var root_2280 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2280, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2282 lang.IFn
																if linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any = j__2; if linked_2281 == nil { tmp4 = ifn_2282.Invoke_O__O(arg_2283) } else { tmp4 = linked_2281.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2280, arg_2283) }; arg_2279 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :319:1
	if linked_2276 == nil { ifn_2277.Invoke_O_O__O(arg_2278, arg_2279) } else { linked_2276.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2275, arg_2278, arg_2279) }; i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } else { i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_sub_forms_A_New() *A_arbace_j2g_dyn_sub_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Ctor() {}
//line :322:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Invoke_O_O_O_O__O(self, n__0, ifaces__1, dyn_keys__2 any) any { var g__4 any; var root_2343 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_2345 lang.IFn; if






	linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = n__0; if linked_2344 == nil { g__4 = ifn_2345.Invoke_O__O(arg_2346) } else { g__4 = linked_2344.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_2343, arg_2346) }; var recv__5 any; var tmp1 lang.IFn = /*line :322:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_287; var tmp3 any; var root_2876 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2878 lang.IFn; if







	linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any = g__4; if linked_2877 == nil { tmp3 = ifn_2878.Invoke_O__O(arg_2879) } else { tmp3 = linked_2877.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2876, arg_2879) }; recv__5 = tmp1.Invoke_O_O__O(tmp2, tmp3); var own__6 any; var root_2347 any = /*line :322:1*/A_arbace_j2g_dyn_A_const_244.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2349 lang.IFn; if








	linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2351 any; var iter__1927001039__auto____6 any; var tmp4 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New(); var tmp5 *jrt.Class; var fncls__2422 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class; if fncls__2422 == nil { var fncls__2422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class = fncls__2422d; tmp5 = fncls__2422d } else { tmp5 = fncls__2422 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp7 any; var root_2423 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2423, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_2425 lang.IFn; if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 any = n__0; if linked_2424 == nil { tmp7 = ifn_2425.Invoke_O__O(arg_2426) } else { tmp7 = linked_2424.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_2423, arg_2426) }; arg_2351 = tmp6.Invoke_O__O(tmp7); if linked_2348 == nil { own__6 = ifn_2349.Invoke_O_O__O(arg_2350, arg_2351) } else { own__6 = linked_2348.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2347, arg_2350, arg_2351) }; var dyn_set__7 any; var root_2427 any = /*line :322:1*/A_arbace_j2g_dyn_A_const_245.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2429 lang.IFn; if









	linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = dyn_keys__2; if linked_2428 == nil { dyn_set__7 = ifn_2429.Invoke_O__O(arg_2430) } else { dyn_set__7 = linked_2428.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2427, arg_2430) }; var ks__8 any; var root_2431 any = /*line :322:1*/A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2431, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2433 lang.IFn; if










	linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any; var root_2435 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any = dyn_keys__2; var arg_2439 any; var root_2440 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_2441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2440, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2442 lang.IFn; if linked_2441 == nil { ifn_2442 = lang.IFn_Cast(root_2440) } else { ifn_2442 = nil }; var arg_2443 any; var root_2444 any = A_arbace_j2g_dyn_A_const_246.GetRawRoot__O(); var linked_2445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2444, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2446 lang.IFn; if linked_2445 == nil { ifn_2446 = lang.IFn_Cast(root_2444) } else { ifn_2446 = nil }; var arg_2447 any = dyn_set__7; var arg_2448 any; var root_2449 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_2450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2449, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2451 lang.IFn; if linked_2450 == nil { ifn_2451 = lang.IFn_Cast(root_2449) } else { ifn_2451 = nil }; var arg_2452 any = own__6; if linked_2450 == nil { arg_2448 = ifn_2451.Invoke_O__O(arg_2452) } else { arg_2448 = linked_2450.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2449, arg_2452) }; if linked_2445 == nil { arg_2443 = ifn_2446.Invoke_O_O__O(arg_2447, arg_2448) } else { arg_2443 = linked_2445.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2444, arg_2447, arg_2448) }; if linked_2441 == nil { arg_2439 = ifn_2442.Invoke_O__O(arg_2443) } else { arg_2439 = linked_2441.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2440, arg_2443) }; if linked_2436 == nil { arg_2434 = ifn_2437.Invoke_O_O__O(arg_2438, arg_2439) } else { arg_2434 = linked_2436.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2435, arg_2438, arg_2439) }; if linked_2432 == nil { ks__8 = ifn_2433.Invoke_O__O(arg_2434) } else { ks__8 = linked_2432.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2431, arg_2434) }; var clash__9 any; var root_2453 any = /*line :322:1*/A_arbace_j2g_dyn_A_const_247.GetRawRoot__O(); var linked_2454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2453, A_arbace_j2g_dyn_go_method_names_A_fn_class); var ifn_2455 lang.IFn; if











	linked_2454 == nil { ifn_2455 = lang.IFn_Cast(root_2453) } else { ifn_2455 = nil }; var arg_2456 any = n__0; if linked_2454 == nil { clash__9 = ifn_2455.Invoke_O__O(arg_2456) } else { clash__9 = linked_2454.(*A_arbace_j2g_dyn_go_method_names_A).Invoke_O_O__O(root_2453, arg_2456) }; var slots__10 any; var root_2457 any = /*line :322:1*/A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2457, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2459 lang.IFn; if












	linked_2458 == nil { ifn_2459 = lang.IFn_Cast(root_2457) } else { ifn_2459 = nil }; var arg_2460 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_93, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2458 == nil { slots__10 = ifn_2459.Invoke_O__O(arg_2460) } else { slots__10 = linked_2458.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2457, arg_2460) }; var tmp8 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_42.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_248; var tmp11 *jrt.RefArray = jrt.ConstRefArray("[0,7,s12:---- DynSub_ns13:: proxies of ns2:, ns8: methods", []*jrt.Class{jrt.String_class}); var tmp12 any; var root_2469 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2469, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2471 lang.IFn; if
	linked_2470 == nil { ifn_2471 = lang.IFn_Cast(root_2469) } else { ifn_2471 = nil }; var arg_2472 any = n__0; if linked_2470 == nil { tmp12 = ifn_2471.Invoke_O__O(arg_2472) } else { tmp12 = linked_2470.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2469, arg_2472) }; var tmp13 any = tmp12; var tmp14 any; var root_2473 any = /*line :336:1*/A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_2474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2473, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2475 lang.IFn; if
	linked_2474 == nil { ifn_2475 = lang.IFn_Cast(root_2473) } else { ifn_2475 = nil }; var arg_2476 any = n__0; var arg_2477 any = Lit_5; var arg_2478 any = Lit_6; if linked_2474 == nil { tmp14 = ifn_2475.Invoke_O_O_O__O(arg_2476, arg_2477, arg_2478) } else { tmp14 = linked_2474.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2473, arg_2476, arg_2477, arg_2478) }; var tmp15 any = /*line :336:1*/tmp9.Invoke_O_O__O(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil, tmp14, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__8)).Ref(), nil)).Ref()); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_249; var tmp18 any; var root_2479 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2479, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2481 lang.IFn; if


	linked_2480 == nil { ifn_2481 = lang.IFn_Cast(root_2479) } else { ifn_2481 = nil }; var arg_2482 any = g__4; if linked_2480 == nil { tmp18 = ifn_2481.Invoke_O__O(arg_2482) } else { tmp18 = linked_2480.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2479, arg_2482) }; var tmp19 any = tmp18; var tmp20 /*line :336:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_147, nil, Lit_148); var tmp21 any; var root_2483 any = A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_2484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2483, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2485 lang.IFn; if



	linked_2484 == nil { ifn_2485 = lang.IFn_Cast(root_2483) } else { ifn_2485 = nil }; var arg_2486 any = n__0; var arg_2487 any = Lit_5; var arg_2488 any = Lit_6; if linked_2484 == nil { tmp21 = ifn_2485.Invoke_O_O_O__O(arg_2486, arg_2487, arg_2488) } else { tmp21 = linked_2484.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2483, arg_2486, arg_2487, arg_2488) }; var tmp22 any = /*line :336:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, g__4, nil, tmp21, nil)).Ref(); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_dyn_A_const_250; var tmp25 any; var root_2489 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_2490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2489, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2491 lang.IFn; if





	linked_2490 == nil { ifn_2491 = lang.IFn_Cast(root_2489) } else { ifn_2491 = nil }; var arg_2492 any = A_arbace_j2g_dyn_A_const_73; var arg_2493 any = n__0; if linked_2490 == nil { tmp25 = ifn_2491.Invoke_O_O__O(arg_2492, arg_2493) } else { tmp25 = linked_2490.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_2489, arg_2492, arg_2493) }; var tmp26 any = /*line :336:1*/tmp16.Invoke_O_O_O_O__O(tmp17, tmp19, tmp22, tmp23.Invoke_O_O_O__O(tmp24, tmp25, A_arbace_j2g_dyn_A_const_251)); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp28 any = A_arbace_j2g_dyn_A_const_252; var tmp29 any; var root_2494 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2496 lang.IFn; if






	linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any = slots__10; var arg_2498 any = A_arbace_j2g_dyn_A_const_253; if linked_2495 == nil { tmp29 = ifn_2496.Invoke_O_O__O(arg_2497, arg_2498) } else { tmp29 = linked_2495.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2494, arg_2497, arg_2498) }; var tmp30 any = tmp29; var tmp31 any; var root_2499 any = /*line :336:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2500 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2499, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2501 lang.IFn; if







	linked_2500 == nil { ifn_2501 = lang.IFn_Cast(root_2499) } else { ifn_2501 = nil }; var arg_2502 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2503 any = A_arbace_j2g_dyn_A_const_254; var arg_2504 any = A_arbace_j2g_dyn_A_const_255; var arg_2505 any; var root_2506 any = A_arbace_j2g_dyn_A_const_229.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2508 lang.IFn; if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any; var tmp32 any = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New(); var tmp33 *jrt.Class; var fncls__2511 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class; if fncls__2511 == nil { var fncls__2511d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class = fncls__2511d; tmp33 = fncls__2511d } else { tmp33 = fncls__2511 }; arg_2509 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var arg_2510 any = ks__8; if linked_2507 == nil { arg_2505 = ifn_2508.Invoke_O_O__O(arg_2509, arg_2510) } else { arg_2505 = linked_2507.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2506, arg_2509, arg_2510) }; if linked_2500 == nil { tmp31 = ifn_2501.Invoke_O_O_O_O__O(arg_2502, arg_2503, arg_2504, arg_2505) } else { tmp31 = linked_2500.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2499, arg_2502, arg_2503, arg_2504, arg_2505) }; var tmp34 any = /*line :336:1*/tmp27.Invoke_O_O_O__O(tmp28, tmp30, tmp31); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp36 any = A_arbace_j2g_dyn_A_const_256; var tmp37 any; var root_2512 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2512, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2514 lang.IFn; if








	linked_2513 == nil { ifn_2514 = lang.IFn_Cast(root_2512) } else { ifn_2514 = nil }; var arg_2515 any; var root_2517 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2517, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2519 lang.IFn; if linked_2518 == nil { ifn_2519 = lang.IFn_Cast(root_2517) } else { ifn_2519 = nil }; var arg_2520 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2518 == nil { arg_2515 = ifn_2519.Invoke_O__O(arg_2520) } else { arg_2515 = linked_2518.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2517, arg_2520) }; var arg_2516 any = A_arbace_j2g_dyn_A_const_257; if linked_2513 == nil { tmp37 = ifn_2514.Invoke_O_O__O(arg_2515, arg_2516) } else { tmp37 = linked_2513.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2512, arg_2515, arg_2516) }; var tmp38 any = tmp37; var tmp39 any; var root_2521 any = /*line :336:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2523 lang.IFn; if









	linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2525 any = A_arbace_j2g_dyn_A_const_258; var arg_2526 any = A_arbace_j2g_dyn_A_const_259; var arg_2527 any; var iter__1927001039__auto____11 any; var tmp40 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New(); var tmp41 *jrt.Class; var fncls__2586 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class; if fncls__2586 == nil { var fncls__2586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class = fncls__2586d; tmp41 = fncls__2586d } else { tmp41 = fncls__2586 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); var tmp42 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11); var tmp43 any; var root_2587 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_2588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2587, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2589 lang.IFn; if linked_2588 == nil { ifn_2589 = lang.IFn_Cast(root_2587) } else { ifn_2589 = nil }; var arg_2590 any; var root_2591 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_2592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2591, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2593 lang.IFn; if linked_2592 == nil { ifn_2593 = lang.IFn_Cast(root_2591) } else { ifn_2593 = nil }; var arg_2594 any = own__6; if linked_2592 == nil { arg_2590 = ifn_2593.Invoke_O__O(arg_2594) } else { arg_2590 = linked_2592.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2591, arg_2594) }; if linked_2588 == nil { tmp43 = ifn_2589.Invoke_O__O(arg_2590) } else { tmp43 = linked_2588.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2587, arg_2590) }; arg_2527 = tmp42.Invoke_O__O(tmp43); if linked_2522 == nil { tmp39 = ifn_2523.Invoke_O_O_O_O__O(arg_2524, arg_2525, arg_2526, arg_2527) } else { tmp39 = linked_2522.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2521, arg_2524, arg_2525, arg_2526, arg_2527) }; var tmp44 any = /*line :336:1*/tmp35.Invoke_O_O_O__O(tmp36, tmp38, tmp39); var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp46 any = A_arbace_j2g_dyn_A_const_260; var tmp47 any = A_arbace_j2g_dyn_A_const_261; var tmp48 any; var root_2595 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2595, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2597 lang.IFn; if










	linked_2596 == nil { ifn_2597 = lang.IFn_Cast(root_2595) } else { ifn_2597 = nil }; var arg_2598 any; var tmp49 any; var root_2600 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2602 lang.IFn; if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = A_arbace_j2g_dyn_A_const_262; var arg_2604 any = recv__5; if linked_2601 == nil { tmp49 = ifn_2602.Invoke_O_O__O(arg_2603, arg_2604) } else { tmp49 = linked_2601.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2600, arg_2603, arg_2604) }; arg_2598 = lang.Tuple_Create_O__IPersistentVector(tmp49); var arg_2599 any = A_arbace_j2g_dyn_A_const_263; if linked_2596 == nil { tmp48 = ifn_2597.Invoke_O_O__O(arg_2598, arg_2599) } else { tmp48 = linked_2596.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2595, arg_2598, arg_2599) }; var tmp50 any = /*line :336:1*/tmp45.Invoke_O_O_O_O_O__O(tmp46, tmp47, tmp48, A_arbace_j2g_dyn_A_const_264, A_arbace_j2g_dyn_A_const_265); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp52 any = A_arbace_j2g_dyn_A_const_266; var tmp53 any = A_arbace_j2g_dyn_A_const_267; var tmp54 any; var root_2605 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2605, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2607 lang.IFn; if











	linked_2606 == nil { ifn_2607 = lang.IFn_Cast(root_2605) } else { ifn_2607 = nil }; var arg_2608 any; var tmp55 any; var root_2610 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2610, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2612 lang.IFn; if linked_2611 == nil { ifn_2612 = lang.IFn_Cast(root_2610) } else { ifn_2612 = nil }; var arg_2613 any = A_arbace_j2g_dyn_A_const_268; var arg_2614 any = recv__5; if linked_2611 == nil { tmp55 = ifn_2612.Invoke_O_O__O(arg_2613, arg_2614) } else { tmp55 = linked_2611.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2610, arg_2613, arg_2614) }; arg_2608 = lang.Tuple_Create_O__IPersistentVector(tmp55); var arg_2609 any = A_arbace_j2g_dyn_A_const_269; if linked_2606 == nil { tmp54 = ifn_2607.Invoke_O_O__O(arg_2608, arg_2609) } else { tmp54 = linked_2606.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2605, arg_2608, arg_2609) }; var tmp56 any = /*line :336:1*/tmp51.Invoke_O_O_O_O__O(tmp52, tmp53, tmp54, A_arbace_j2g_dyn_A_const_270); var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp58 any = A_arbace_j2g_dyn_A_const_271; var tmp59 any = A_arbace_j2g_dyn_A_const_272; var tmp60 any; var root_2615 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2615, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2617 lang.IFn; if












	linked_2616 == nil { ifn_2617 = lang.IFn_Cast(root_2615) } else { ifn_2617 = nil }; var arg_2618 any; var tmp61 any; var root_2620 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any = A_arbace_j2g_dyn_A_const_273; var arg_2624 any = recv__5; if linked_2621 == nil { tmp61 = ifn_2622.Invoke_O_O__O(arg_2623, arg_2624) } else { tmp61 = linked_2621.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2620, arg_2623, arg_2624) }; arg_2618 = lang.Tuple_Create_O__IPersistentVector(tmp61); var arg_2619 any = A_arbace_j2g_dyn_A_const_274; if linked_2616 == nil { tmp60 = ifn_2617.Invoke_O_O__O(arg_2618, arg_2619) } else { tmp60 = linked_2616.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2615, arg_2618, arg_2619) }; var tmp62 any = /*line :336:1*/tmp57.Invoke_O_O_O_O__O(tmp58, tmp59, tmp60, A_arbace_j2g_dyn_A_const_275); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_dyn_A_const_276; var tmp65 any = A_arbace_j2g_dyn_A_const_277; var tmp66 any; var root_2625 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2625, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2627 lang.IFn; if













	linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any; var tmp67 any; var root_2630 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2630, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2632 lang.IFn; if linked_2631 == nil { ifn_2632 = lang.IFn_Cast(root_2630) } else { ifn_2632 = nil }; var arg_2633 any = A_arbace_j2g_dyn_A_const_278; var arg_2634 any = recv__5; if linked_2631 == nil { tmp67 = ifn_2632.Invoke_O_O__O(arg_2633, arg_2634) } else { tmp67 = linked_2631.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2630, arg_2633, arg_2634) }; arg_2628 = lang.Tuple_Create_O__IPersistentVector(tmp67); var arg_2629 any = A_arbace_j2g_dyn_A_const_279; if linked_2626 == nil { tmp66 = ifn_2627.Invoke_O_O__O(arg_2628, arg_2629) } else { tmp66 = linked_2626.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2625, arg_2628, arg_2629) }; var tmp68 any = /*line :336:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp26, tmp34, tmp44, tmp50, tmp56, tmp62, tmp63.Invoke_O_O_O_O__O(tmp64, tmp65, tmp66, A_arbace_j2g_dyn_A_const_280))); var tmp69 any; var iter__1927001039__auto____11_2 any; var tmp70 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(recv__5, n__0); var tmp71 *jrt.Class; var fncls__2721 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class; if














	fncls__2721 == nil { var fncls__2721d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class = fncls__2721d; tmp71 = fncls__2721d } else { tmp71 = fncls__2721 }; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp70, tmp71, nil); var tmp72 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11_2); var tmp73 any; var root_2722 any = A_arbace_j2g_dyn_A_const_135.GetRawRoot__O(); var linked_2723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2722, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2724 lang.IFn; if linked_2723 == nil { ifn_2724 = lang.IFn_Cast(root_2722) } else { ifn_2724 = nil }; var arg_2725 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O())).Ref(); if linked_2723 == nil { tmp73 = ifn_2724.Invoke_O__O(arg_2725) } else { tmp73 = linked_2723.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2722, arg_2725) }; tmp69 = tmp72.Invoke_O__O(tmp73); var tmp74 any = tmp69; var tmp75 any; var iter__1927001039__auto____11_3 any; var tmp76 any = /*line :336:1*/A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(recv__5, clash__9); var tmp77 *jrt.Class; var fncls__2814 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class; if

















	fncls__2814 == nil { var fncls__2814d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class = fncls__2814d; tmp77 = fncls__2814d } else { tmp77 = fncls__2814 }; iter__1927001039__auto____11_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp76, tmp77, nil); tmp75 = lang.IFn_Cast(iter__1927001039__auto____11_3).Invoke_O__O(ifaces__1); var tmp78 any = tmp75; var tmp79 any; var root_2815 any = /*line :336:1*/A_arbace_j2g_dyn_A_const_284.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_2817 lang.IFn; if



















	linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any; var tmp80 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(own__6, recv__5, clash__9, ifaces__1, n__0); var tmp81 *jrt.Class; var fncls__2871 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class; if fncls__2871 == nil { var fncls__2871d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class = fncls__2871d; tmp81 = fncls__2871d } else { tmp81 = fncls__2871 }; arg_2818 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp80, tmp81, nil); var arg_2819 any = ks__8; if linked_2816 == nil { tmp79 = ifn_2817.Invoke_O_O__O(arg_2818, arg_2819) } else { tmp79 = linked_2816.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_2815, arg_2818, arg_2819) }; var tmp82 any = tmp79; var tmp83 any; var root_2872 any = /*line :336:1*/A_arbace_j2g_dyn_A_const_286.GetRawRoot__O(); var linked_2873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2872, A_arbace_j2g_dyn_ctor_infos_A_fn_class); var ifn_2874 lang.IFn; if


























	linked_2873 == nil { ifn_2874 = lang.IFn_Cast(root_2872) } else { ifn_2874 = nil }; var arg_2875 any = n__0; if linked_2873 == nil { tmp83 = ifn_2874.Invoke_O__O(arg_2875) } else { tmp83 = linked_2873.(*A_arbace_j2g_dyn_ctor_infos_A).Invoke_O_O__O(root_2872, arg_2875) }; return /*line :336:1*/ tmp8.Invoke_O_O_O_O_O__O(tmp68, tmp74, tmp78, tmp82, lang.Tuple_Create_O__IPersistentVector(tmp83)) }
//line :331:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Ctor() {}
//line :331:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Invoke_O_O__O(self, s__711000308__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(self, s__711000308__1); var tmp2 *jrt.Class; var fncls__2421 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class; if fncls__2421 == nil { var fncls__2421d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class = fncls__2421d; tmp2 = fncls__2421d } else { tmp2 = fncls__2421 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :331:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A{}; t.Ctor_O_O(p0, p1); return t }
//line :331:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Ctor_O_O(c__iter__711000307, c__s__711000308 any) { t.F_iter__711000307 = c__iter__711000307; t.F_s__711000308 = c__s__711000308 }
//line :331:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Invoke_O__O(self any) any { { var s__711000308__1 any; var t_ any = t.F_s__711000308; t.F_s__711000308 = nil; s__711000308__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2352 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = s__711000308__1; if linked_2353 == nil { temp__1927000414__auto____2 = ifn_2354.Invoke_O__O(arg_2355) } else { temp__1927000414__auto____2 = linked_2353.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2352, arg_2355) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000308__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2356 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = s__711000308__3; if linked_2357 == nil { tmp1 = ifn_2358.Invoke_O__O(arg_2359) } else { tmp1 = linked_2357.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2356, arg_2359) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2360 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2360, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2362 lang.IFn; if linked_2361 == nil { ifn_2362 = lang.IFn_Cast(root_2360) } else { ifn_2362 = nil }; var arg_2363 any = s__711000308__3; if linked_2361 == nil { c__1927001037__auto____4 = ifn_2362.Invoke_O__O(arg_2363) } else { c__1927001037__auto____4 = linked_2361.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2360, arg_2363) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000310__6 any; var root_2364 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2364, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2366 lang.IFn; if linked_2365 == nil { ifn_2366 = lang.IFn_Cast(root_2364) } else { ifn_2366 = nil }; var arg_2367 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2365 == nil { b__711000310__6 = ifn_2366.Invoke_O__O(arg_2367) } else { b__711000310__6 = linked_2365.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2364, arg_2367) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(b__711000310__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2377 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class; if fncls__2377 == nil { var fncls__2377d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class = fncls__2377d; tmp3 = fncls__2377d } else { tmp3 = fncls__2377 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2378 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2378, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2380 lang.IFn; if linked_2379 == nil { ifn_2380 = lang.IFn_Cast(root_2378) } else { ifn_2380 = nil }; var arg_2381 any; var root_2383 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2385 lang.IFn; if linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any = b__711000310__6; if linked_2384 == nil { arg_2381 = ifn_2385.Invoke_O__O(arg_2386) } else { arg_2381 = linked_2384.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2383, arg_2386) }; var arg_2382 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp5 any; var root_2387 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; var arg_2390 any = s__711000308__3; if linked_2388 == nil { tmp5 = ifn_2389.Invoke_O__O(arg_2390) } else { tmp5 = linked_2388.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2387, arg_2390) }; arg_2382 = tmp4.Invoke_O__O(tmp5); if linked_2379 == nil { return ifn_2380.Invoke_O_O__O(arg_2381, arg_2382) } else { return linked_2379.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2378, arg_2381, arg_2382) } } else { var root_2391 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2393 lang.IFn; if linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any; var root_2396 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2396, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2398 lang.IFn; if linked_2397 == nil { ifn_2398 = lang.IFn_Cast(root_2396) } else { ifn_2398 = nil }; var arg_2399 any = b__711000310__6; if linked_2397 == nil { arg_2394 = ifn_2398.Invoke_O__O(arg_2399) } else { arg_2394 = linked_2397.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2396, arg_2399) }; var arg_2395 any; if linked_2392 == nil { return ifn_2393.Invoke_O_O__O(arg_2394, arg_2395) } else { return linked_2392.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2391, arg_2394, arg_2395) } } } else { var vec__711000318__4 any; var root_2400 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2400, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2402 lang.IFn; if linked_2401 == nil { ifn_2402 = lang.IFn_Cast(root_2400) } else { ifn_2402 = nil }; var arg_2403 any = s__711000308__3; if linked_2401 == nil { vec__711000318__4 = ifn_2402.Invoke_O__O(arg_2403) } else { vec__711000318__4 = linked_2401.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2400, arg_2403) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_2404 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2404, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2406 lang.IFn; if linked_2405 == nil { ifn_2406 = lang.IFn_Cast(root_2404) } else { ifn_2406 = nil }; var arg_2407 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__5); if linked_2405 == nil { tmp6 = ifn_2406.Invoke_O__O(arg_2407) } else { tmp6 = linked_2405.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2404, arg_2407) }; if jrt.J2g_Truth(tmp6) { var root_2408 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2408, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2410 lang.IFn; if linked_2409 == nil { ifn_2410 = lang.IFn_Cast(root_2408) } else { ifn_2410 = nil }; var arg_2411 any = lang.Tuple_Create_O_O__IPersistentVector(k__5, mm__6); var arg_2412 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp8 any; var root_2413 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2413, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2415 lang.IFn; if linked_2414 == nil { ifn_2415 = lang.IFn_Cast(root_2413) } else { ifn_2415 = nil }; var arg_2416 any = s__711000308__3; if linked_2414 == nil { tmp8 = ifn_2415.Invoke_O__O(arg_2416) } else { tmp8 = linked_2414.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2413, arg_2416) }; arg_2412 = tmp7.Invoke_O__O(tmp8); if linked_2409 == nil { return ifn_2410.Invoke_O_O__O(arg_2411, arg_2412) } else { return linked_2409.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2408, arg_2411, arg_2412) } } else { var tmp9 any; var root_2417 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2417, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2419 lang.IFn; if linked_2418 == nil { ifn_2419 = lang.IFn_Cast(root_2417) } else { ifn_2419 = nil }; var arg_2420 any = s__711000308__3; if linked_2418 == nil { tmp9 = ifn_2419.Invoke_O__O(arg_2420) } else { tmp9 = linked_2418.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2417, arg_2420) }; s__711000308__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :331:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :331:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Ctor_O_I_O(c__b__711000310 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000310 = c__b__711000310; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :331:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Invoke_O__O(self any) any { { var i__711000309__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000309__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000314__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000309__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_2368 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2368, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__3); if linked_2369 == nil { tmp2 = ifn_2370.Invoke_O__O(arg_2371) } else { tmp2 = linked_2369.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2368, arg_2371) }; if jrt.J2g_Truth(tmp2) { var root_2372 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = t.F_b__711000310; var arg_2376 any = lang.Tuple_Create_O_O__IPersistentVector(k__3, mm__4); if linked_2373 == nil { ifn_2374.Invoke_O_O__O(arg_2375, arg_2376) } else { linked_2373.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2372, arg_2375, arg_2376) }; i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } else { i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New() *A_arbace_j2g_dyn_sub_forms_fn__711000324_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000324_A{}; t.Ctor(); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Ctor() {}
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Invoke_O_O_O__O(self, i__1, p__711000323__2 any) any { var vec__711000325__3 any = p__711000323__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }

func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Ctor() {}
//line :346:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Invoke_O_O__O(self, s__711000330__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(s__711000330__1, self); var tmp2 *jrt.Class; var fncls__2585 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class; if fncls__2585 == nil { var fncls__2585d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class = fncls__2585d; tmp2 = fncls__2585d } else { tmp2 = fncls__2585 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :346:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :346:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Ctor_O_O(c__s__711000330, c__iter__711000329 any) { t.F_s__711000330 = c__s__711000330; t.F_iter__711000329 = c__iter__711000329 }
//line :346:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Invoke_O__O(self any) any { { var s__711000330__1 any; var t_ any = t.F_s__711000330; t.F_s__711000330 = nil; s__711000330__1 = t_; for { var temp__1927000414__auto____2 any; var root_2528 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2528, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2530 lang.IFn; if linked_2529 == nil { ifn_2530 = lang.IFn_Cast(root_2528) } else { ifn_2530 = nil }; var arg_2531 any = s__711000330__1; if linked_2529 == nil { temp__1927000414__auto____2 = ifn_2530.Invoke_O__O(arg_2531) } else { temp__1927000414__auto____2 = linked_2529.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2528, arg_2531) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000330__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2532 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2532, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2534 lang.IFn; if linked_2533 == nil { ifn_2534 = lang.IFn_Cast(root_2532) } else { ifn_2534 = nil }; var arg_2535 any = s__711000330__3; if linked_2533 == nil { tmp1 = ifn_2534.Invoke_O__O(arg_2535) } else { tmp1 = linked_2533.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2532, arg_2535) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2536 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2538 lang.IFn; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any = s__711000330__3; if linked_2537 == nil { c__1927001037__auto____4 = ifn_2538.Invoke_O__O(arg_2539) } else { c__1927001037__auto____4 = linked_2537.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2536, arg_2539) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000332__6 any; var root_2540 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2542 lang.IFn; if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2541 == nil { b__711000332__6 = ifn_2542.Invoke_O__O(arg_2543) } else { b__711000332__6 = linked_2541.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2540, arg_2543) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(b__711000332__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2549 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class; if fncls__2549 == nil { var fncls__2549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class = fncls__2549d; tmp3 = fncls__2549d } else { tmp3 = fncls__2549 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2550 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2550, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2552 lang.IFn; if linked_2551 == nil { ifn_2552 = lang.IFn_Cast(root_2550) } else { ifn_2552 = nil }; var arg_2553 any; var root_2555 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2557 lang.IFn; if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = b__711000332__6; if linked_2556 == nil { arg_2553 = ifn_2557.Invoke_O__O(arg_2558) } else { arg_2553 = linked_2556.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2555, arg_2558) }; var arg_2554 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp5 any; var root_2559 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2561 lang.IFn; if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any = s__711000330__3; if linked_2560 == nil { tmp5 = ifn_2561.Invoke_O__O(arg_2562) } else { tmp5 = linked_2560.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2559, arg_2562) }; arg_2554 = tmp4.Invoke_O__O(tmp5); if linked_2551 == nil { return ifn_2552.Invoke_O_O__O(arg_2553, arg_2554) } else { return linked_2551.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2550, arg_2553, arg_2554) } } else { var root_2563 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2565 lang.IFn; if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any; var root_2568 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = b__711000332__6; if linked_2569 == nil { arg_2566 = ifn_2570.Invoke_O__O(arg_2571) } else { arg_2566 = linked_2569.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2568, arg_2571) }; var arg_2567 any; if linked_2564 == nil { return ifn_2565.Invoke_O_O__O(arg_2566, arg_2567) } else { return linked_2564.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2563, arg_2566, arg_2567) } } } else { var vec__711000340__4 any; var root_2572 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2574 lang.IFn; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = s__711000330__3; if linked_2573 == nil { vec__711000340__4 = ifn_2574.Invoke_O__O(arg_2575) } else { vec__711000340__4 = linked_2573.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2572, arg_2575) }; var nme__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2576 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__5, desc__6)).Ref(), nme__5); var arg_2580 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp7 any; var root_2581 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2583 lang.IFn; if linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any = s__711000330__3; if linked_2582 == nil { tmp7 = ifn_2583.Invoke_O__O(arg_2584) } else { tmp7 = linked_2582.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2581, arg_2584) }; arg_2580 = tmp6.Invoke_O__O(tmp7); if linked_2577 == nil { return ifn_2578.Invoke_O_O__O(arg_2579, arg_2580) } else { return linked_2577.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2576, arg_2579, arg_2580) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :346:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :346:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Ctor_O_I_O(c__b__711000332 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000332 = c__b__711000332; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :346:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Invoke_O__O(self any) any { { var i__711000331__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000331__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000336__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000331__1)); var nme__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2544 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2546 lang.IFn; if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any = t.F_b__711000332; var arg_2548 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__3, desc__4)).Ref(), nme__3); if linked_2545 == nil { ifn_2546.Invoke_O_O__O(arg_2547, arg_2548) } else { linked_2545.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2544, arg_2547, arg_2548) }; i__711000331__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000331__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Invoke_O_O__O(self, s__711000346__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(t.F_recv, self, s__711000346__1, t.F_n); var tmp2 *jrt.Class; var fncls__2720 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class; if fncls__2720 == nil { var fncls__2720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class = fncls__2720d; tmp2 = fncls__2720d } else { tmp2 = fncls__2720 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :351:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Ctor_O_O_O_O(c__recv, c__iter__711000345, c__s__711000346, c__n any) { t.F_recv = c__recv; t.F_iter__711000345 = c__iter__711000345; t.F_s__711000346 = c__s__711000346; t.F_n = c__n }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Invoke_O__O(self any) any { { var s__711000346__1 any; var t_ any = t.F_s__711000346; t.F_s__711000346 = nil; s__711000346__1 = t_; for { var temp__1927000414__auto____2 any; var root_2635 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2635, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2637 lang.IFn; if linked_2636 == nil { ifn_2637 = lang.IFn_Cast(root_2635) } else { ifn_2637 = nil }; var arg_2638 any = s__711000346__1; if linked_2636 == nil { temp__1927000414__auto____2 = ifn_2637.Invoke_O__O(arg_2638) } else { temp__1927000414__auto____2 = linked_2636.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2635, arg_2638) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000346__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2639 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2639, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2641 lang.IFn; if linked_2640 == nil { ifn_2641 = lang.IFn_Cast(root_2639) } else { ifn_2641 = nil }; var arg_2642 any = s__711000346__3; if linked_2640 == nil { tmp1 = ifn_2641.Invoke_O__O(arg_2642) } else { tmp1 = linked_2640.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2639, arg_2642) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2643 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2643, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2645 lang.IFn; if linked_2644 == nil { ifn_2645 = lang.IFn_Cast(root_2643) } else { ifn_2645 = nil }; var arg_2646 any = s__711000346__3; if linked_2644 == nil { c__1927001037__auto____4 = ifn_2645.Invoke_O__O(arg_2646) } else { c__1927001037__auto____4 = linked_2644.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2643, arg_2646) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000348__6 any; var root_2647 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2647, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2649 lang.IFn; if linked_2648 == nil { ifn_2649 = lang.IFn_Cast(root_2647) } else { ifn_2649 = nil }; var arg_2650 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2648 == nil { b__711000348__6 = ifn_2649.Invoke_O__O(arg_2650) } else { b__711000348__6 = linked_2648.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2647, arg_2650) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(t.F_recv, t.F_n, b__711000348__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2670 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class; if fncls__2670 == nil { var fncls__2670d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class = fncls__2670d; tmp3 = fncls__2670d } else { tmp3 = fncls__2670 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2671 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2671, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2673 lang.IFn; if linked_2672 == nil { ifn_2673 = lang.IFn_Cast(root_2671) } else { ifn_2673 = nil }; var arg_2674 any; var root_2676 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2676, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2678 lang.IFn; if linked_2677 == nil { ifn_2678 = lang.IFn_Cast(root_2676) } else { ifn_2678 = nil }; var arg_2679 any = b__711000348__6; if linked_2677 == nil { arg_2674 = ifn_2678.Invoke_O__O(arg_2679) } else { arg_2674 = linked_2677.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2676, arg_2679) }; var arg_2675 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp5 any; var root_2680 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2680, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2682 lang.IFn; if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; var arg_2683 any = s__711000346__3; if linked_2681 == nil { tmp5 = ifn_2682.Invoke_O__O(arg_2683) } else { tmp5 = linked_2681.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2680, arg_2683) }; arg_2675 = tmp4.Invoke_O__O(tmp5); if linked_2672 == nil { return ifn_2673.Invoke_O_O__O(arg_2674, arg_2675) } else { return linked_2672.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2671, arg_2674, arg_2675) } } else { var root_2684 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2686 lang.IFn; if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any; var root_2689 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2689, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2691 lang.IFn; if linked_2690 == nil { ifn_2691 = lang.IFn_Cast(root_2689) } else { ifn_2691 = nil }; var arg_2692 any = b__711000348__6; if linked_2690 == nil { arg_2687 = ifn_2691.Invoke_O__O(arg_2692) } else { arg_2687 = linked_2690.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2689, arg_2692) }; var arg_2688 any; if linked_2685 == nil { return ifn_2686.Invoke_O_O__O(arg_2687, arg_2688) } else { return linked_2685.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2684, arg_2687, arg_2688) } } } else { var i__4 any; var root_2693 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2693, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2695 lang.IFn; if linked_2694 == nil { ifn_2695 = lang.IFn_Cast(root_2693) } else { ifn_2695 = nil }; var arg_2696 any = s__711000346__3; if linked_2694 == nil { i__4 = ifn_2695.Invoke_O__O(arg_2696) } else { i__4 = linked_2694.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2693, arg_2696) }; var k__5 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__4)); var root_2697 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2697, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2699 lang.IFn; if linked_2698 == nil { ifn_2699 = lang.IFn_Cast(root_2697) } else { ifn_2699 = nil }; var arg_2700 any; var root_2702 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2704 lang.IFn

	if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any = t.F_recv; var arg_2706 any = i__4; var arg_2707 any = k__5; var arg_2708 any; var tmp6 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(k__5, t.F_n); var tmp7 *jrt.Class; var fncls__2715 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class; if fncls__2715 == nil { var fncls__2715d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class = fncls__2715d; tmp7 = fncls__2715d } else { tmp7 = fncls__2715 }; arg_2708 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2703 == nil { arg_2700 = ifn_2704.Invoke_O_O_O_O__O(arg_2705, arg_2706, arg_2707, arg_2708) } else { arg_2700 = linked_2703.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2702, arg_2705, arg_2706, arg_2707, arg_2708) }
//line :351:1
	var arg_2701 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp9 any; var root_2716 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2718 lang.IFn; if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = s__711000346__3; if linked_2717 == nil { tmp9 = ifn_2718.Invoke_O__O(arg_2719) } else { tmp9 = linked_2717.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2716, arg_2719) }; arg_2701 = tmp8.Invoke_O__O(tmp9); if linked_2698 == nil { return ifn_2699.Invoke_O_O__O(arg_2700, arg_2701) } else { return linked_2698.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2697, arg_2700, arg_2701) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :351:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Ctor_O_O_O_I_O(c__recv, c__n, c__b__711000348 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_n = c__n; t.F_b__711000348 = c__b__711000348; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Invoke_O__O(self any) any { { var i__711000347__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000347__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000347__1)); var k__3 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__2)); var root_2651 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2651, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2653 lang.IFn; if linked_2652 == nil { ifn_2653 = lang.IFn_Cast(root_2651) } else { ifn_2653 = nil }; var arg_2654 any = t.F_b__711000348; var arg_2655 any; var root_2656 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_2657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2656, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2658 lang.IFn

	if linked_2657 == nil { ifn_2658 = lang.IFn_Cast(root_2656) } else { ifn_2658 = nil }; var arg_2659 any = t.F_recv; var arg_2660 any = i__2; var arg_2661 any = k__3; var arg_2662 any; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(k__3, t.F_n); var tmp3 *jrt.Class; var fncls__2669 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class; if fncls__2669 == nil { var fncls__2669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class = fncls__2669d; tmp3 = fncls__2669d } else { tmp3 = fncls__2669 }; arg_2662 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_2657 == nil { arg_2655 = ifn_2658.Invoke_O_O_O_O__O(arg_2659, arg_2660, arg_2661, arg_2662) } else { arg_2655 = linked_2657.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2656, arg_2659, arg_2660, arg_2661, arg_2662) }
//line :351:1
	if linked_2652 == nil { ifn_2653.Invoke_O_O__O(arg_2654, arg_2655) } else { linked_2652.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2651, arg_2654, arg_2655) }; i__711000347__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000347__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A{}; t.Ctor_O_O(p0, p1); return t }
//line :353:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :353:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2663 any = A_arbace_j2g_dyn_A_const_281.GetRawRoot__O(); var linked_2664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2663, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2665 lang.IFn; if linked_2664 == nil { ifn_2665 = lang.IFn_Cast(root_2663) } else { ifn_2665 = nil }; var arg_2666 any = t.F_n; var arg_2667 any = t.F_k; var arg_2668 any = pn__1; if linked_2664 == nil { return ifn_2665.Invoke_O_O_O__O(arg_2666, arg_2667, arg_2668) } else { return linked_2664.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2663, arg_2666, arg_2667, arg_2668) } }
//line :353:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A{}; t.Ctor_O_O(p0, p1); return t }
//line :353:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :353:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2709 any = A_arbace_j2g_dyn_A_const_281.GetRawRoot__O(); var linked_2710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2709, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2711 lang.IFn; if linked_2710 == nil { ifn_2711 = lang.IFn_Cast(root_2709) } else { ifn_2711 = nil }; var arg_2712 any = t.F_n; var arg_2713 any = t.F_k; var arg_2714 any = pn__1; if linked_2710 == nil { return ifn_2711.Invoke_O_O_O__O(arg_2712, arg_2713, arg_2714) } else { return linked_2710.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2709, arg_2712, arg_2713, arg_2714) } }
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Ctor_O_O(c__recv, c__clash any) { t.F_recv = c__recv; t.F_clash = c__clash }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Invoke_O_O__O(self, s__711000360__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(s__711000360__1, t.F_recv, t.F_clash, self); var tmp2 *jrt.Class; var fncls__2813 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class; if fncls__2813 == nil { var fncls__2813d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class = fncls__2813d; tmp2 = fncls__2813d } else { tmp2 = fncls__2813 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :354:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Ctor_O_O_O_O(c__s__711000360, c__recv, c__clash, c__iter__711000359 any) { t.F_s__711000360 = c__s__711000360; t.F_recv = c__recv; t.F_clash = c__clash; t.F_iter__711000359 = c__iter__711000359 }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Invoke_O__O(self any) any { { var s__711000360__1 any; var t_ any = t.F_s__711000360; t.F_s__711000360 = nil; s__711000360__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2726 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2726, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2728 lang.IFn; if linked_2727 == nil { ifn_2728 = lang.IFn_Cast(root_2726) } else { ifn_2728 = nil }; var arg_2729 any = s__711000360__1; if linked_2727 == nil { temp__1927000414__auto____2 = ifn_2728.Invoke_O__O(arg_2729) } else { temp__1927000414__auto____2 = linked_2727.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2726, arg_2729) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000360__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2730 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2730, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2732 lang.IFn; if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any = s__711000360__3; if linked_2731 == nil { tmp1 = ifn_2732.Invoke_O__O(arg_2733) } else { tmp1 = linked_2731.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2730, arg_2733) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2734 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2734, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2736 lang.IFn; if linked_2735 == nil { ifn_2736 = lang.IFn_Cast(root_2734) } else { ifn_2736 = nil }; var arg_2737 any = s__711000360__3; if linked_2735 == nil { c__1927001037__auto____4 = ifn_2736.Invoke_O__O(arg_2737) } else { c__1927001037__auto____4 = linked_2735.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2734, arg_2737) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000362__6 any; var root_2738 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2738, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2740 lang.IFn; if linked_2739 == nil { ifn_2740 = lang.IFn_Cast(root_2738) } else { ifn_2740 = nil }; var arg_2741 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2739 == nil { b__711000362__6 = ifn_2740.Invoke_O__O(arg_2741) } else { b__711000362__6 = linked_2739.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2738, arg_2741) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(t.F_recv, t.F_clash, b__711000362__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2760 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class; if fncls__2760 == nil { var fncls__2760d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class = fncls__2760d; tmp3 = fncls__2760d } else { tmp3 = fncls__2760 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2761 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2761, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2763 lang.IFn; if linked_2762 == nil { ifn_2763 = lang.IFn_Cast(root_2761) } else { ifn_2763 = nil }; var arg_2764 any; var root_2766 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2768 lang.IFn; if linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any = b__711000362__6; if linked_2767 == nil { arg_2764 = ifn_2768.Invoke_O__O(arg_2769) } else { arg_2764 = linked_2767.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2766, arg_2769) }; var arg_2765 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp5 any; var root_2770 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2770, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2772 lang.IFn; if linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any = s__711000360__3; if linked_2771 == nil { tmp5 = ifn_2772.Invoke_O__O(arg_2773) } else { tmp5 = linked_2771.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2770, arg_2773) }; arg_2765 = tmp4.Invoke_O__O(tmp5); if linked_2762 == nil { return ifn_2763.Invoke_O_O__O(arg_2764, arg_2765) } else { return linked_2762.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2761, arg_2764, arg_2765) } } else { var root_2774 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2774, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2776 lang.IFn; if linked_2775 == nil { ifn_2776 = lang.IFn_Cast(root_2774) } else { ifn_2776 = nil }; var arg_2777 any; var root_2779 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2779, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2781 lang.IFn; if linked_2780 == nil { ifn_2781 = lang.IFn_Cast(root_2779) } else { ifn_2781 = nil }; var arg_2782 any = b__711000362__6; if linked_2780 == nil { arg_2777 = ifn_2781.Invoke_O__O(arg_2782) } else { arg_2777 = linked_2780.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2779, arg_2782) }; var arg_2778 any; if linked_2775 == nil { return ifn_2776.Invoke_O_O__O(arg_2777, arg_2778) } else { return linked_2775.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2774, arg_2777, arg_2778) } } } else { var j__4 any; var root_2783 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2783, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2785 lang.IFn; if linked_2784 == nil { ifn_2785 = lang.IFn_Cast(root_2783) } else { ifn_2785 = nil }; var arg_2786 any = s__711000360__3; if linked_2784 == nil { j__4 = ifn_2785.Invoke_O__O(arg_2786) } else { j__4 = linked_2784.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2783, arg_2786) }; var mk__5 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp7 any; var root_2787 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2787, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2789 lang.IFn; if linked_2788 == nil { ifn_2789 = lang.IFn_Cast(root_2787) } else { ifn_2789 = nil }; var arg_2790 any = j__4; if linked_2788 == nil { tmp7 = ifn_2789.Invoke_O__O(arg_2790) } else { tmp7 = linked_2788.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2787, arg_2790) }; mk__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__5)) { var root_2791 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2791, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2793 lang.IFn; if linked_2792 == nil { ifn_2793 = lang.IFn_Cast(root_2791) } else { ifn_2793 = nil }; var arg_2794 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_282; var tmp10 any; var root_2796 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2796, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2798 lang.IFn
														if linked_2797 == nil { ifn_2798 = lang.IFn_Cast(root_2796) } else { ifn_2798 = nil }; var arg_2799 any = mk__5; if linked_2797 == nil { tmp10 = ifn_2798.Invoke_O__O(arg_2799) } else { tmp10 = linked_2797.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2796, arg_2799) }; var tmp11 any = tmp10; var tmp12 any; var root_2800 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2800, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2802 lang.IFn; if linked_2801 == nil { ifn_2802 = lang.IFn_Cast(root_2800) } else { ifn_2802 = nil }; var arg_2803 any = A_arbace_j2g_dyn_A_const_283; var arg_2804 any = t.F_recv; if linked_2801 == nil { tmp12 = ifn_2802.Invoke_O_O__O(arg_2803, arg_2804) } else { tmp12 = linked_2801.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2800, arg_2803, arg_2804) }; arg_2794 = tmp8.Invoke_O_O_O__O(tmp9, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12))
//line :354:1
	var arg_2795 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp14 any; var root_2805 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2805, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2807 lang.IFn; if linked_2806 == nil { ifn_2807 = lang.IFn_Cast(root_2805) } else { ifn_2807 = nil }; var arg_2808 any = s__711000360__3; if linked_2806 == nil { tmp14 = ifn_2807.Invoke_O__O(arg_2808) } else { tmp14 = linked_2806.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2805, arg_2808) }; arg_2795 = tmp13.Invoke_O__O(tmp14); if linked_2792 == nil { return ifn_2793.Invoke_O_O__O(arg_2794, arg_2795) } else { return linked_2792.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2791, arg_2794, arg_2795) } } else { var tmp15 any; var root_2809 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2809, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2811 lang.IFn; if linked_2810 == nil { ifn_2811 = lang.IFn_Cast(root_2809) } else { ifn_2811 = nil }; var arg_2812 any = s__711000360__3; if linked_2810 == nil { tmp15 = ifn_2811.Invoke_O__O(arg_2812) } else { tmp15 = linked_2810.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2809, arg_2812) }; s__711000360__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :354:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Ctor_O_O_O_I_O(c__recv, c__clash, c__b__711000362 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_clash = c__clash; t.F_b__711000362 = c__b__711000362; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Invoke_O__O(self any) any { { var i__711000361__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000361__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000361__1)); var mk__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp3 any; var root_2742 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any = j__2; if linked_2743 == nil { tmp3 = ifn_2744.Invoke_O__O(arg_2745) } else { tmp3 = linked_2743.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2742, arg_2745) }; mk__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__3)) { var root_2746 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2746, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2748 lang.IFn; if linked_2747 == nil { ifn_2748 = lang.IFn_Cast(root_2746) } else { ifn_2748 = nil }; var arg_2749 any = t.F_b__711000362; var arg_2750 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_282; var tmp6 any; var root_2751 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2751, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2753 lang.IFn
															if linked_2752 == nil { ifn_2753 = lang.IFn_Cast(root_2751) } else { ifn_2753 = nil }; var arg_2754 any = mk__3; if linked_2752 == nil { tmp6 = ifn_2753.Invoke_O__O(arg_2754) } else { tmp6 = linked_2752.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2751, arg_2754) }; var tmp7 any = tmp6; var tmp8 any; var root_2755 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2755, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2757 lang.IFn; if linked_2756 == nil { ifn_2757 = lang.IFn_Cast(root_2755) } else { ifn_2757 = nil }; var arg_2758 any = A_arbace_j2g_dyn_A_const_283; var arg_2759 any = t.F_recv; if linked_2756 == nil { tmp8 = ifn_2757.Invoke_O_O__O(arg_2758, arg_2759) } else { tmp8 = linked_2756.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2755, arg_2758, arg_2759) }; arg_2750 = tmp4.Invoke_O_O_O__O(tmp5, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8))
//line :354:1
	if linked_2747 == nil { ifn_2748.Invoke_O_O__O(arg_2749, arg_2750) } else { linked_2747.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2746, arg_2749, arg_2750) }; i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } else { i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :356:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Ctor_O_O_O_O_O(c__own, c__recv, c__clash, c__ifaces, c__n any) { t.F_own = c__own; t.F_recv = c__recv; t.F_clash = c__clash; t.F_ifaces = c__ifaces; t.F_n = c__n }
//line :356:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Invoke_O_O_O__O(self, i__1, p__711000369__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, p__711000369__2) } else { var vec__711000371__3 any = p__711000369__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000371__3; var tmp1 any; var and__1927000168__auto____7 bool; var na_2820 any = i__1; var na_2821 int64 = int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()))
														if jrt.Long_InstanceOf(na_2820) { var n0_2822 int64 = jrt.NN(jrt.Long_Cast(na_2820)).LongValue__J(); var n1_2823 int64 = na_2821; and__1927000168__auto____7 = n0_2822 >= n1_2823 } else { and__1927000168__auto____7 = lang.Numbers_Gte_O_J__Z_NoInit(na_2820, na_2821) }; if and__1927000168__auto____7 { var or__1927000174__auto____8 any = lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)
															if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_clash); var tmp3 any; var root_2848 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2848, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2850 lang.IFn; if linked_2849 == nil { ifn_2850 = lang.IFn_Cast(root_2848) } else { ifn_2850 = nil }; var arg_2851 any = nme__4; var arg_2852 any = desc__5; if linked_2849 == nil { tmp3 = ifn_2850.Invoke_O_O__O(arg_2851, arg_2852) } else { tmp3 = linked_2849.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2848, arg_2851, arg_2852) }; tmp1 = tmp2.Invoke_O__O(tmp3) } } else {
//line :357:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				var root_2825 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any = t.F_recv; var arg_2829 any = i__1; var arg_2830 any = k__6; var arg_2831 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)) {
					var tmp4 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(k__6, t.F_n); var tmp5 *jrt.Class; var fncls__2839 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class; if fncls__2839 == nil { var fncls__2839d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class = fncls__2839d; tmp5 = fncls__2839d } else { tmp5 = fncls__2839 }; arg_2831 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) } else {
						var tmp6 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(k__6, t.F_ifaces); var tmp7 *jrt.Class; var fncls__2847 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class; if fncls__2847 == nil { var fncls__2847d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class = fncls__2847d; tmp7 = fncls__2847d } else { tmp7 = fncls__2847 }; arg_2831 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) }
//line :359:1
				if linked_2826 == nil { return ifn_2827.Invoke_O_O_O_O__O(arg_2828, arg_2829, arg_2830, arg_2831) } else { return linked_2826.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2825, arg_2828, arg_2829, arg_2830, arg_2831) } } else {
//line :357:1
					return nil } } }
//line :356:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, p__711000369__2 any) any { var vec__711000371__3 any = p__711000369__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000371__3; var tmp1 any; var and__1927000168__auto____7 bool; var na_2853 int64 = int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O())); var n0_2854 int64 = i__1_l; var n1_2855 int64 = na_2853; and__1927000168__auto____7 =
																	n0_2854 >= n1_2855; if and__1927000168__auto____7 { var or__1927000174__auto____8 any = lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)
																		if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_clash); var tmp3 any; var root_2866 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2866, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2868 lang.IFn; if linked_2867 == nil { ifn_2868 = lang.IFn_Cast(root_2866) } else { ifn_2868 = nil }; var arg_2869 any = nme__4; var arg_2870 any = desc__5; if linked_2867 == nil { tmp3 = ifn_2868.Invoke_O_O__O(arg_2869, arg_2870) } else { tmp3 = linked_2867.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2866, arg_2869, arg_2870) }; tmp1 = tmp2.Invoke_O__O(tmp3) } } else {
//line :357:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				var root_2857 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_2858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2857, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2859 lang.IFn; if linked_2858 == nil { ifn_2859 = lang.IFn_Cast(root_2857) } else { ifn_2859 = nil }; var arg_2860 any = t.F_recv; var arg_2861 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_2861 = i__1_b } else { arg_2861 = i__1_b }; var arg_2862 any = k__6; var arg_2863 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)) {
					var tmp4 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(k__6, t.F_n); var tmp5 *jrt.Class; var fncls__2864 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class; if fncls__2864 == nil { var fncls__2864d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class = fncls__2864d; tmp5 = fncls__2864d } else { tmp5 = fncls__2864 }; arg_2863 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) } else {
						var tmp6 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(k__6, t.F_ifaces); var tmp7 *jrt.Class; var fncls__2865 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class; if fncls__2865 == nil { var fncls__2865d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class = fncls__2865d; tmp7 = fncls__2865d } else { tmp7 = fncls__2865 }; arg_2863 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) }
//line :359:1
				if linked_2858 == nil { return ifn_2859.Invoke_O_O_O_O__O(arg_2860, arg_2861, arg_2862, arg_2863) } else { return linked_2858.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2857, arg_2860, arg_2861, arg_2862, arg_2863) } } else {
//line :357:1
					return nil } }


func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A{}; t.Ctor_O_O(p0, p1); return t }
//line :360:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :360:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2832 any = A_arbace_j2g_dyn_A_const_285.GetRawRoot__O(); var linked_2833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2832, A_arbace_j2g_dyn_class_fallback_A_fn_class); var ifn_2834 lang.IFn; if linked_2833 == nil { ifn_2834 = lang.IFn_Cast(root_2832) } else { ifn_2834 = nil }; var arg_2835 any = t.F_n; var arg_2836 any = t.F_k; var arg_2837 any = pn__1; var arg_2838 any = r__2; if linked_2833 == nil { return ifn_2834.Invoke_O_O_O_O__O(arg_2835, arg_2836, arg_2837, arg_2838) } else { return linked_2833.(*A_arbace_j2g_dyn_class_fallback_A).Invoke_O_O_O_O_O__O(root_2832, arg_2835, arg_2836, arg_2837, arg_2838) } }
func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A{}; t.Ctor_O_O(p0, p1); return t }
//line :361:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :361:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2840 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2840, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_2842 lang.IFn; if linked_2841 == nil { ifn_2842 = lang.IFn_Cast(root_2840) } else { ifn_2842 = nil }; var arg_2843 any = t.F_ifaces; var arg_2844 any = t.F_k; var arg_2845 any = pn__1; var arg_2846 any = r__2; if linked_2841 == nil { return ifn_2842.Invoke_O_O_O_O__O(arg_2843, arg_2844, arg_2845, arg_2846) } else { return linked_2841.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O__O(root_2840, arg_2843, arg_2844, arg_2845, arg_2846) } }

















func A_arbace_j2g_dyn_fn_field_native_A_New() *A_arbace_j2g_dyn_fn_field_native_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_fn_field_native_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Ctor() {}
//line :379:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Invoke_O__O(self any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_288; var tmp3 any; var root_2880 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2880, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2882 lang.IFn; if linked_2881 == nil { ifn_2882 = lang.IFn_Cast(root_2880) } else { ifn_2882 = nil }; var arg_2883 any; var root_2884 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_2885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2884, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_2886 lang.IFn; if linked_2885 == nil { ifn_2886 = lang.IFn_Cast(root_2884) } else { ifn_2886 = nil }; var arg_2887 any = Lit_45; var arg_2888 any = Lit_46; if linked_2885 == nil { arg_2883 = ifn_2886.Invoke_O_O__O(arg_2887, arg_2888) } else { arg_2883 = linked_2885.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_2884, arg_2887, arg_2888) }; if linked_2881 == nil { tmp3 = ifn_2882.Invoke_O__O(arg_2883) } else { tmp3 = linked_2881.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2880, arg_2883) }; var tmp4 any = tmp3; var tmp5 any; var root_2889 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2891 lang.IFn
	if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any = A_arbace_j2g_dyn_A_const_291; var arg_2893 any = A_arbace_j2g_dyn_A_const_292; if linked_2890 == nil { tmp5 = ifn_2891.Invoke_O_O__O(arg_2892, arg_2893) } else { tmp5 = linked_2890.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2889, arg_2892, arg_2893) }
//line :384:1
	var tmp6 any = tmp5; var tmp7 any; var root_2894 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2894, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2896 lang.IFn
	if linked_2895 == nil { ifn_2896 = lang.IFn_Cast(root_2894) } else { ifn_2896 = nil }; var arg_2897 any = A_arbace_j2g_dyn_A_const_293; var arg_2898 any = A_arbace_j2g_dyn_A_const_294; if linked_2895 == nil { tmp7 = ifn_2896.Invoke_O_O__O(arg_2897, arg_2898) } else { tmp7 = linked_2895.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2894, arg_2897, arg_2898) }
//line :384:1
	var tmp8 any = tmp7; var tmp9 any; var root_2899 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2899, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2901 lang.IFn
	if linked_2900 == nil { ifn_2901 = lang.IFn_Cast(root_2899) } else { ifn_2901 = nil }; var arg_2902 any = A_arbace_j2g_dyn_A_const_295; var arg_2903 any = A_arbace_j2g_dyn_A_const_296; if linked_2900 == nil { tmp9 = ifn_2901.Invoke_O_O__O(arg_2902, arg_2903) } else { tmp9 = linked_2900.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2899, arg_2902, arg_2903) }
//line :384:1
	var tmp10 any = tmp9; var tmp11 any; var root_2904 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2904, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2906 lang.IFn
	if linked_2905 == nil { ifn_2906 = lang.IFn_Cast(root_2904) } else { ifn_2906 = nil }; var arg_2907 any = A_arbace_j2g_dyn_A_const_297; var arg_2908 any = A_arbace_j2g_dyn_A_const_298; if linked_2905 == nil { tmp11 = ifn_2906.Invoke_O_O__O(arg_2907, arg_2908) } else { tmp11 = linked_2905.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2904, arg_2907, arg_2908) }
//line :384:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp10, tmp11), A_arbace_j2g_dyn_A_const_290)
}








func A_arbace_j2g_dyn_forms_A_New() *A_arbace_j2g_dyn_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_A{}; t.Ctor(); return t }
//line :394:1
func (t *A_arbace_j2g_dyn_forms_A) Ctor() {}
//line :394:1
func (t *A_arbace_j2g_dyn_forms_A) Invoke_O_O__O(self, T__0_ any) any { var ifaces__2 any; var root_2909 any = A_arbace_j2g_dyn_A_const_299.GetRawRoot__O(); var linked_2910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2909, A_arbace_j2g_dyn_interfaces_A_fn_class); var ifn_2911 lang.IFn; if


	linked_2910 == nil { ifn_2911 = lang.IFn_Cast(root_2909) } else { ifn_2911 = nil }; var arg_2912 any = T__0_; if linked_2910 == nil { ifaces__2 = ifn_2911.Invoke_O__O(arg_2912) } else { ifaces__2 = linked_2910.(*A_arbace_j2g_dyn_interfaces_A).Invoke_O_O__O(root_2909, arg_2912) }; var ks__3 any; var root_2913 any = /*line :394:1*/A_arbace_j2g_dyn_A_const_300.GetRawRoot__O(); var linked_2914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2913, A_arbace_j2g_dyn_slot_keys_A_fn_class); var ifn_2915 lang.IFn; if



	linked_2914 == nil { ifn_2915 = lang.IFn_Cast(root_2913) } else { ifn_2915 = nil }; var arg_2916 any = ifaces__2; if linked_2914 == nil { ks__3 = ifn_2915.Invoke_O__O(arg_2916) } else { ks__3 = linked_2914.(*A_arbace_j2g_dyn_slot_keys_A).Invoke_O_O__O(root_2913, arg_2916) }; var n__4 int32 = /*line :394:1*/lang.RT_Count_O__I_NoInit(ks__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_42.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_321; var tmp4 any = tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_47, nil, Lit_48, nil, Lit_49), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ifaces__2)).Ref(), nil, jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref(), nil)).Ref()); var tmp5 any = A_arbace_j2g_dyn_A_const_301; var tmp6 any = A_arbace_j2g_dyn_A_const_302; var tmp7 any = A_arbace_j2g_dyn_A_const_303; var tmp8 any = A_arbace_j2g_dyn_A_const_304; var tmp9 any = A_arbace_j2g_dyn_A_const_305; var tmp10 any = A_arbace_j2g_dyn_A_const_306; var tmp11 any = A_arbace_j2g_dyn_A_const_307; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_dyn_A_const_322; var tmp14 any; var root_2925 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2925, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2927 lang.IFn; if



































	linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any = A_arbace_j2g_dyn_A_const_323; var arg_2929 any = A_arbace_j2g_dyn_A_const_324; if linked_2926 == nil { tmp14 = ifn_2927.Invoke_O_O__O(arg_2928, arg_2929) } else { tmp14 = linked_2926.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2925, arg_2928, arg_2929) }; var tmp15 any = tmp14; var tmp16 any; var root_2930 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2931 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2930, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2932 lang.IFn; if






























	linked_2931 == nil { ifn_2932 = lang.IFn_Cast(root_2930) } else { ifn_2932 = nil }; var arg_2933 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2934 any = A_arbace_j2g_dyn_A_const_325; var arg_2935 any = A_arbace_j2g_dyn_A_const_326; var arg_2936 any; var root_2937 any = A_arbace_j2g_dyn_A_const_229.GetRawRoot__O(); var linked_2938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2937, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2939 lang.IFn; if linked_2938 == nil { ifn_2939 = lang.IFn_Cast(root_2937) } else { ifn_2939 = nil }; var arg_2940 any; var tmp17 any = A_arbace_j2g_dyn_forms_fn__711000383_A_New(); var tmp18 *jrt.Class; var fncls__2942 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000383_A_fn_class; if fncls__2942 == nil { var fncls__2942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_dyn_forms_fn__711000383_A_fn_class = fncls__2942d; tmp18 = fncls__2942d } else { tmp18 = fncls__2942 }; arg_2940 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_2941 any = ks__3; if linked_2938 == nil { arg_2936 = ifn_2939.Invoke_O_O__O(arg_2940, arg_2941) } else { arg_2936 = linked_2938.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2937, arg_2940, arg_2941) }; if linked_2931 == nil { tmp16 = ifn_2932.Invoke_O_O_O_O__O(arg_2933, arg_2934, arg_2935, arg_2936) } else { tmp16 = linked_2931.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2930, arg_2933, arg_2934, arg_2935, arg_2936) }; var tmp19 any = /*line :400:1*/tmp12.Invoke_O_O_O__O(tmp13, tmp15, tmp16); var tmp20 any = A_arbace_j2g_dyn_A_const_308; var tmp21 any = A_arbace_j2g_dyn_A_const_309; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyn_A_const_327; var tmp24 any = A_arbace_j2g_dyn_A_const_328; var tmp25 any; var root_2943 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2945 lang.IFn; if











































	linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any; var tmp26 any; var root_2948 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2948, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2950 lang.IFn; if linked_2949 == nil { ifn_2950 = lang.IFn_Cast(root_2948) } else { ifn_2950 = nil }; var arg_2951 any = A_arbace_j2g_dyn_A_const_329; var arg_2952 any = A_arbace_j2g_dyn_A_const_330; if linked_2949 == nil { tmp26 = ifn_2950.Invoke_O_O__O(arg_2951, arg_2952) } else { tmp26 = linked_2949.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2948, arg_2951, arg_2952) }; var tmp27 any = tmp26; var tmp28 any; var root_2953 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2953, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2955 lang.IFn; if linked_2954 == nil { ifn_2955 = lang.IFn_Cast(root_2953) } else { ifn_2955 = nil }; var arg_2956 any = A_arbace_j2g_dyn_A_const_331; var arg_2957 any = A_arbace_j2g_dyn_A_const_332; if linked_2954 == nil { tmp28 = ifn_2955.Invoke_O_O__O(arg_2956, arg_2957) } else { tmp28 = linked_2954.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2953, arg_2956, arg_2957) }; arg_2946 = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28); var arg_2947 any = A_arbace_j2g_dyn_A_const_333; if linked_2944 == nil { tmp25 = ifn_2945.Invoke_O_O__O(arg_2946, arg_2947) } else { tmp25 = linked_2944.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2943, arg_2946, arg_2947) }; var tmp29 any = tmp25; var tmp30 any; var root_2958 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2959 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2958, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2960 lang.IFn; if












































	linked_2959 == nil { ifn_2960 = lang.IFn_Cast(root_2958) } else { ifn_2960 = nil }; var arg_2961 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2962 any = A_arbace_j2g_dyn_A_const_334; var arg_2963 any = A_arbace_j2g_dyn_A_const_335; var arg_2964 any; var root_2965 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2966 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2965, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2967 lang.IFn; if
	linked_2966 == nil { ifn_2967 = lang.IFn_Cast(root_2965) } else { ifn_2967 = nil }; var arg_2968 any; var iter__1927001039__auto____5 any; var tmp31 any = A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_New(); var tmp32 *jrt.Class; var fncls__3050 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_fn_class; if
	fncls__3050 == nil { var fncls__3050d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_fn_class = fncls__3050d; tmp32 = fncls__3050d } else { tmp32 = fncls__3050 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var tmp33 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp34 any; var root_3051 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_3052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3051, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3053 lang.IFn; if linked_3052 == nil { ifn_3053 = lang.IFn_Cast(root_3051) } else { ifn_3053 = nil }; var arg_3054 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); if linked_3052 == nil { tmp34 = ifn_3053.Invoke_O__O(arg_3054) } else { tmp34 = linked_3052.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3051, arg_3054) }; arg_2968 = tmp33.Invoke_O__O(tmp34); var arg_2969 any = A_arbace_j2g_dyn_A_const_339; if /*line :446:1*/ linked_2966 == nil { arg_2964 = ifn_2967.Invoke_O_O__O(arg_2968, arg_2969) } else { arg_2964 = linked_2966.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2965, arg_2968, arg_2969) }; if /*line :445:1*/ linked_2959 == nil { tmp30 = ifn_2960.Invoke_O_O_O_O__O(arg_2961, arg_2962, arg_2963, arg_2964) } else { tmp30 = linked_2959.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2958, arg_2961, arg_2962, arg_2963, arg_2964) }; var tmp35 any = /*line :400:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp19, tmp20, tmp21, tmp22.Invoke_O_O_O_O_O_O__O(tmp23, tmp24, Lit_51, tmp29, tmp30, A_arbace_j2g_dyn_A_const_340), A_arbace_j2g_dyn_A_const_310, A_arbace_j2g_dyn_A_const_311, A_arbace_j2g_dyn_A_const_312, A_arbace_j2g_dyn_A_const_313, A_arbace_j2g_dyn_A_const_314, A_arbace_j2g_dyn_A_const_315, A_arbace_j2g_dyn_A_const_316, A_arbace_j2g_dyn_A_const_317, A_arbace_j2g_dyn_A_const_318, A_arbace_j2g_dyn_A_const_319, A_arbace_j2g_dyn_A_const_320)); var tmp36 any; var iter__1927001039__auto____5_2 any; var tmp37 any = A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_New(); var tmp38 *jrt.Class; var fncls__3139 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_fn_class; if























































































	fncls__3139 == nil { var fncls__3139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_fn_class = fncls__3139d; tmp38 = fncls__3139d } else { tmp38 = fncls__3139 }; iter__1927001039__auto____5_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil); tmp36 = lang.IFn_Cast(iter__1927001039__auto____5_2).Invoke_O__O(ifaces__2); var tmp39 any = tmp36; var tmp40 any; var nobj__5 int32 = /*line :400:1*/lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_345.GetRawRoot__O()); var tmp42 any; var root_3146 any = A_arbace_j2g_dyn_A_const_346.GetRawRoot__O(); var linked_3147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3146, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_3148 lang.IFn; if


























































































	linked_3147 == nil { ifn_3148 = lang.IFn_Cast(root_3146) } else { ifn_3148 = nil }; if linked_3147 == nil { tmp42 = ifn_3148.Invoke__O() } else { tmp42 = linked_3147.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_3146) }; var tmp43 any = tmp42; var tmp44 any = A_arbace_j2g_dyn_forms_fn__711000414_A_New_O_O(ks__3, ifaces__2); var tmp45 *jrt.Class; var fncls__3155 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000414_A_fn_class; if fncls__3155 == nil { var fncls__3155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_dyn_forms_fn__711000414_A_fn_class = fncls__3155d; tmp45 = fncls__3155d } else { tmp45 = fncls__3155 }; var tmp46 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil); var tmp47 any; var root_3156 any = A_arbace_j2g_dyn_A_const_135.GetRawRoot__O(); var linked_3157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3156, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3158 lang.IFn; if linked_3157 == nil { ifn_3158 = lang.IFn_Cast(root_3156) } else { ifn_3158 = nil }; var arg_3159 any = jrt.Integer_ValueOf_I__Integer_NoInit(nobj__5).Ref(); var arg_3160 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__3)).Ref(); if linked_3157 == nil { tmp47 = ifn_3158.Invoke_O_O__O(arg_3159, arg_3160) } else { tmp47 = linked_3157.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_3156, arg_3159, arg_3160) }; tmp40 = tmp41.Invoke_O_O_O__O(tmp43, tmp46, tmp47); var tmp48 any = tmp40; var tmp49 lang.IFn = /*line :400:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp50 any = A_arbace_j2g_dyn_A_const_356; var tmp51 any; var root_3164 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3164, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3166 lang.IFn; if




























































































	linked_3165 == nil { ifn_3166 = lang.IFn_Cast(root_3164) } else { ifn_3166 = nil }; var arg_3167 any; var root_3168 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3168, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3170 lang.IFn; if linked_3169 == nil { ifn_3170 = lang.IFn_Cast(root_3168) } else { ifn_3170 = nil }; var arg_3171 any = Lit_55; var arg_3172 any = Lit_56; if linked_3169 == nil { arg_3167 = ifn_3170.Invoke_O_O__O(arg_3171, arg_3172) } else { arg_3167 = linked_3169.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3168, arg_3171, arg_3172) }; if linked_3165 == nil { tmp51 = ifn_3166.Invoke_O__O(arg_3167) } else { tmp51 = linked_3165.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3164, arg_3167) }; var tmp52 any = tmp51; var tmp53 any; var root_3173 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3173, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3175 lang.IFn; if





























































































	linked_3174 == nil { ifn_3175 = lang.IFn_Cast(root_3173) } else { ifn_3175 = nil }; var arg_3176 any; var tmp54 any; var root_3178 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3178, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3180 lang.IFn; if linked_3179 == nil { ifn_3180 = lang.IFn_Cast(root_3178) } else { ifn_3180 = nil }; var arg_3181 any = A_arbace_j2g_dyn_A_const_357; var arg_3182 any = A_arbace_j2g_dyn_A_const_358; if linked_3179 == nil { tmp54 = ifn_3180.Invoke_O_O__O(arg_3181, arg_3182) } else { tmp54 = linked_3179.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3178, arg_3181, arg_3182) }; var tmp55 any = tmp54; var tmp56 any; var root_3183 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3183, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3185 lang.IFn; if linked_3184 == nil { ifn_3185 = lang.IFn_Cast(root_3183) } else { ifn_3185 = nil }; var arg_3186 any = A_arbace_j2g_dyn_A_const_359; var arg_3187 any = A_arbace_j2g_dyn_A_const_360; if linked_3184 == nil { tmp56 = ifn_3185.Invoke_O_O__O(arg_3186, arg_3187) } else { tmp56 = linked_3184.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3183, arg_3186, arg_3187) }; var tmp57 any = tmp56; var tmp58 any; var root_3188 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3188, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3190 lang.IFn; if linked_3189 == nil { ifn_3190 = lang.IFn_Cast(root_3188) } else { ifn_3190 = nil }; var arg_3191 any = A_arbace_j2g_dyn_A_const_361; var arg_3192 any = A_arbace_j2g_dyn_A_const_362; if linked_3189 == nil { tmp58 = ifn_3190.Invoke_O_O__O(arg_3191, arg_3192) } else { tmp58 = linked_3189.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3188, arg_3191, arg_3192) }; arg_3176 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp55, tmp57, tmp58); var arg_3177 any = A_arbace_j2g_dyn_A_const_363; if linked_3174 == nil { tmp53 = ifn_3175.Invoke_O_O__O(arg_3176, arg_3177) } else { tmp53 = linked_3174.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3173, arg_3176, arg_3177) }; var tmp59 lang.IFn = /*line :400:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp60 any = A_arbace_j2g_dyn_A_const_364; var tmp61 any = A_arbace_j2g_dyn_A_const_368; var tmp62 any = A_arbace_j2g_dyn_A_const_369; var tmp63 any = A_arbace_j2g_dyn_A_const_370; var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp65 any = A_arbace_j2g_dyn_A_const_371; var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp67 any = A_arbace_j2g_dyn_A_const_372; var tmp68 any = A_arbace_j2g_dyn_A_const_373; var tmp69 any = A_arbace_j2g_dyn_A_const_374; var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp71 any = A_arbace_j2g_dyn_A_const_381; var tmp72 any = A_arbace_j2g_dyn_A_const_382; var tmp73 any = tmp49.Invoke_O_O_O_O__O(tmp50, tmp52, tmp53, tmp59.Invoke_O_O_O_O_O__O(tmp60, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp61, tmp62, tmp63, tmp64.Invoke_O_O__O(tmp65, tmp66.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp67, tmp68, tmp69, tmp70.Invoke_O_O_O__O(tmp71, tmp72, jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref()), A_arbace_j2g_dyn_A_const_375, A_arbace_j2g_dyn_A_const_376, A_arbace_j2g_dyn_A_const_377, A_arbace_j2g_dyn_A_const_378, A_arbace_j2g_dyn_A_const_379, A_arbace_j2g_dyn_A_const_380))), A_arbace_j2g_dyn_A_const_365, A_arbace_j2g_dyn_A_const_366, A_arbace_j2g_dyn_A_const_367)); var tmp74 any = A_arbace_j2g_dyn_A_const_347; var tmp75 any = A_arbace_j2g_dyn_A_const_348; var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp77 any = A_arbace_j2g_dyn_A_const_383; var tmp78 any; var root_3193 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3193, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3195 lang.IFn; if



































































































































	linked_3194 == nil { ifn_3195 = lang.IFn_Cast(root_3193) } else { ifn_3195 = nil }; var arg_3196 any; var root_3197 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3197, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3199 lang.IFn; if linked_3198 == nil { ifn_3199 = lang.IFn_Cast(root_3197) } else { ifn_3199 = nil }; var arg_3200 any = Lit_57; var arg_3201 any = Lit_58; if linked_3198 == nil { arg_3196 = ifn_3199.Invoke_O_O__O(arg_3200, arg_3201) } else { arg_3196 = linked_3198.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3197, arg_3200, arg_3201) }; if linked_3194 == nil { tmp78 = ifn_3195.Invoke_O__O(arg_3196) } else { tmp78 = linked_3194.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3193, arg_3196) }; var tmp79 any = tmp78; var tmp80 any; var root_3202 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3202, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3204 lang.IFn; if




































































































































	linked_3203 == nil { ifn_3204 = lang.IFn_Cast(root_3202) } else { ifn_3204 = nil }; var arg_3205 any = A_arbace_j2g_dyn_A_const_385; var arg_3206 any = A_arbace_j2g_dyn_A_const_386; if linked_3203 == nil { tmp80 = ifn_3204.Invoke_O_O__O(arg_3205, arg_3206) } else { tmp80 = linked_3203.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3202, arg_3205, arg_3206) }; var tmp81 any = tmp80; var tmp82 any; var root_3207 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3207, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3209 lang.IFn; if




































































































































	linked_3208 == nil { ifn_3209 = lang.IFn_Cast(root_3207) } else { ifn_3209 = nil }; var arg_3210 any = A_arbace_j2g_dyn_A_const_387; var arg_3211 any = A_arbace_j2g_dyn_A_const_388; if linked_3208 == nil { tmp82 = ifn_3209.Invoke_O_O__O(arg_3210, arg_3211) } else { tmp82 = linked_3208.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3207, arg_3210, arg_3211) }; var tmp83 any = tmp82; var tmp84 any; var root_3212 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3212, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3214 lang.IFn; if




































































































































	linked_3213 == nil { ifn_3214 = lang.IFn_Cast(root_3212) } else { ifn_3214 = nil }; var arg_3215 any = A_arbace_j2g_dyn_A_const_389; var arg_3216 any = A_arbace_j2g_dyn_A_const_390; if linked_3213 == nil { tmp84 = ifn_3214.Invoke_O_O__O(arg_3215, arg_3216) } else { tmp84 = linked_3213.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3212, arg_3215, arg_3216) }; var tmp85 any = tmp84; var tmp86 any; var root_3217 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3217, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3219 lang.IFn; if




































































































































	linked_3218 == nil { ifn_3219 = lang.IFn_Cast(root_3217) } else { ifn_3219 = nil }; var arg_3220 any = A_arbace_j2g_dyn_A_const_391; var arg_3221 any = A_arbace_j2g_dyn_A_const_392; if linked_3218 == nil { tmp86 = ifn_3219.Invoke_O_O__O(arg_3220, arg_3221) } else { tmp86 = linked_3218.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3217, arg_3220, arg_3221) }; var tmp87 any = tmp86; var tmp88 any; var root_3222 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3222, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3224 lang.IFn; if




































































































































	linked_3223 == nil { ifn_3224 = lang.IFn_Cast(root_3222) } else { ifn_3224 = nil }; var arg_3225 any = A_arbace_j2g_dyn_A_const_393; var arg_3226 any = A_arbace_j2g_dyn_A_const_394; if linked_3223 == nil { tmp88 = ifn_3224.Invoke_O_O__O(arg_3225, arg_3226) } else { tmp88 = linked_3223.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3222, arg_3225, arg_3226) }; var tmp89 any = /*line :400:1*/tmp76.Invoke_O_O_O_O__O(tmp77, tmp79, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp81, tmp83, tmp85, tmp87, tmp88), A_arbace_j2g_dyn_A_const_384); var tmp90 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp91 any = A_arbace_j2g_dyn_A_const_395; var tmp92 any; var root_3227 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3227, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3229 lang.IFn; if
































































































































































	linked_3228 == nil { ifn_3229 = lang.IFn_Cast(root_3227) } else { ifn_3229 = nil }; var arg_3230 any; var root_3231 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3231, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3233 lang.IFn; if linked_3232 == nil { ifn_3233 = lang.IFn_Cast(root_3231) } else { ifn_3233 = nil }; var arg_3234 any = Lit_59; var arg_3235 any = Lit_58; if linked_3232 == nil { arg_3230 = ifn_3233.Invoke_O_O__O(arg_3234, arg_3235) } else { arg_3230 = linked_3232.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3231, arg_3234, arg_3235) }; if linked_3228 == nil { tmp92 = ifn_3229.Invoke_O__O(arg_3230) } else { tmp92 = linked_3228.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3227, arg_3230) }; var tmp93 any = tmp92; var tmp94 any; var root_3236 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3236, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3238 lang.IFn; if

































































































































































	linked_3237 == nil { ifn_3238 = lang.IFn_Cast(root_3236) } else { ifn_3238 = nil }; var arg_3239 any = A_arbace_j2g_dyn_A_const_397; var arg_3240 any = A_arbace_j2g_dyn_A_const_398; if linked_3237 == nil { tmp94 = ifn_3238.Invoke_O_O__O(arg_3239, arg_3240) } else { tmp94 = linked_3237.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3236, arg_3239, arg_3240) }; var tmp95 any = tmp94; var tmp96 any; var root_3241 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3241, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3243 lang.IFn; if

































































































































































	linked_3242 == nil { ifn_3243 = lang.IFn_Cast(root_3241) } else { ifn_3243 = nil }; var arg_3244 any = A_arbace_j2g_dyn_A_const_399; var arg_3245 any = A_arbace_j2g_dyn_A_const_400; if linked_3242 == nil { tmp96 = ifn_3243.Invoke_O_O__O(arg_3244, arg_3245) } else { tmp96 = linked_3242.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3241, arg_3244, arg_3245) }; var tmp97 any = tmp96; var tmp98 any; var root_3246 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3246, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3248 lang.IFn; if

































































































































































	linked_3247 == nil { ifn_3248 = lang.IFn_Cast(root_3246) } else { ifn_3248 = nil }; var arg_3249 any = A_arbace_j2g_dyn_A_const_401; var arg_3250 any = A_arbace_j2g_dyn_A_const_402; if linked_3247 == nil { tmp98 = ifn_3248.Invoke_O_O__O(arg_3249, arg_3250) } else { tmp98 = linked_3247.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3246, arg_3249, arg_3250) }; var tmp99 any = tmp98; var tmp100 any; var root_3251 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3251, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3253 lang.IFn; if

































































































































































	linked_3252 == nil { ifn_3253 = lang.IFn_Cast(root_3251) } else { ifn_3253 = nil }; var arg_3254 any = A_arbace_j2g_dyn_A_const_403; var arg_3255 any = A_arbace_j2g_dyn_A_const_404; if linked_3252 == nil { tmp100 = ifn_3253.Invoke_O_O__O(arg_3254, arg_3255) } else { tmp100 = linked_3252.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3251, arg_3254, arg_3255) }; var tmp101 any = tmp100; var tmp102 any; var root_3256 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3256, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3258 lang.IFn; if

































































































































































	linked_3257 == nil { ifn_3258 = lang.IFn_Cast(root_3256) } else { ifn_3258 = nil }; var arg_3259 any = A_arbace_j2g_dyn_A_const_405; var arg_3260 any = A_arbace_j2g_dyn_A_const_406; if linked_3257 == nil { tmp102 = ifn_3258.Invoke_O_O__O(arg_3259, arg_3260) } else { tmp102 = linked_3257.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3256, arg_3259, arg_3260) }; var tmp103 any = /*line :400:1*/tmp90.Invoke_O_O_O_O__O(tmp91, tmp93, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp95, tmp97, tmp99, tmp101, tmp102), A_arbace_j2g_dyn_A_const_396); var tmp104 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp105 any = A_arbace_j2g_dyn_A_const_407; var tmp106 any; var root_3261 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3261, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3263 lang.IFn; if









































































































































































	linked_3262 == nil { ifn_3263 = lang.IFn_Cast(root_3261) } else { ifn_3263 = nil }; var arg_3264 any; var root_3265 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3265, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3267 lang.IFn; if linked_3266 == nil { ifn_3267 = lang.IFn_Cast(root_3265) } else { ifn_3267 = nil }; var arg_3268 any = Lit_60; var arg_3269 any = Lit_61; if linked_3266 == nil { arg_3264 = ifn_3267.Invoke_O_O__O(arg_3268, arg_3269) } else { arg_3264 = linked_3266.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3265, arg_3268, arg_3269) }; if linked_3262 == nil { tmp106 = ifn_3263.Invoke_O__O(arg_3264) } else { tmp106 = linked_3262.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3261, arg_3264) }; var tmp107 any = tmp106; var tmp108 any; var root_3270 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3270, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3272 lang.IFn; if










































































































































































	linked_3271 == nil { ifn_3272 = lang.IFn_Cast(root_3270) } else { ifn_3272 = nil }; var arg_3273 any = A_arbace_j2g_dyn_A_const_409; var arg_3274 any = A_arbace_j2g_dyn_A_const_410; if linked_3271 == nil { tmp108 = ifn_3272.Invoke_O_O__O(arg_3273, arg_3274) } else { tmp108 = linked_3271.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3270, arg_3273, arg_3274) }; var tmp109 any = tmp108; var tmp110 any; var root_3275 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3275, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3277 lang.IFn; if










































































































































































	linked_3276 == nil { ifn_3277 = lang.IFn_Cast(root_3275) } else { ifn_3277 = nil }; var arg_3278 any = A_arbace_j2g_dyn_A_const_411; var arg_3279 any = A_arbace_j2g_dyn_A_const_412; if linked_3276 == nil { tmp110 = ifn_3277.Invoke_O_O__O(arg_3278, arg_3279) } else { tmp110 = linked_3276.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3275, arg_3278, arg_3279) }; var tmp111 any = tmp110; var tmp112 any; var root_3280 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3280, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3282 lang.IFn; if










































































































































































	linked_3281 == nil { ifn_3282 = lang.IFn_Cast(root_3280) } else { ifn_3282 = nil }; var arg_3283 any = A_arbace_j2g_dyn_A_const_413; var arg_3284 any = A_arbace_j2g_dyn_A_const_414; if linked_3281 == nil { tmp112 = ifn_3282.Invoke_O_O__O(arg_3283, arg_3284) } else { tmp112 = linked_3281.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3280, arg_3283, arg_3284) }; var tmp113 any = /*line :400:1*/tmp104.Invoke_O_O_O_O__O(tmp105, tmp107, lang.Tuple_Create_O_O_O__IPersistentVector(tmp109, tmp111, tmp112), A_arbace_j2g_dyn_A_const_408); var tmp114 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp115 any = A_arbace_j2g_dyn_A_const_415; var tmp116 any; var root_3285 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3285, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3287 lang.IFn; if
























































































































































































	linked_3286 == nil { ifn_3287 = lang.IFn_Cast(root_3285) } else { ifn_3287 = nil }; var arg_3288 any; var root_3289 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3289, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3291 lang.IFn; if linked_3290 == nil { ifn_3291 = lang.IFn_Cast(root_3289) } else { ifn_3291 = nil }; var arg_3292 any = Lit_62; var arg_3293 any = Lit_63; if linked_3290 == nil { arg_3288 = ifn_3291.Invoke_O_O__O(arg_3292, arg_3293) } else { arg_3288 = linked_3290.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3289, arg_3292, arg_3293) }; if linked_3286 == nil { tmp116 = ifn_3287.Invoke_O__O(arg_3288) } else { tmp116 = linked_3286.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3285, arg_3288) }; var tmp117 any = tmp116; var tmp118 any; var root_3294 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3294, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3296 lang.IFn; if

























































































































































































	linked_3295 == nil { ifn_3296 = lang.IFn_Cast(root_3294) } else { ifn_3296 = nil }; var arg_3297 any; var tmp119 any; var root_3299 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3299, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3301 lang.IFn; if linked_3300 == nil { ifn_3301 = lang.IFn_Cast(root_3299) } else { ifn_3301 = nil }; var arg_3302 any = A_arbace_j2g_dyn_A_const_416; var arg_3303 any = A_arbace_j2g_dyn_A_const_417; if linked_3300 == nil { tmp119 = ifn_3301.Invoke_O_O__O(arg_3302, arg_3303) } else { tmp119 = linked_3300.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3299, arg_3302, arg_3303) }; var tmp120 any = tmp119; var tmp121 any; var root_3304 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3304, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3306 lang.IFn; if linked_3305 == nil { ifn_3306 = lang.IFn_Cast(root_3304) } else { ifn_3306 = nil }; var arg_3307 any = A_arbace_j2g_dyn_A_const_418; var arg_3308 any = A_arbace_j2g_dyn_A_const_419; if linked_3305 == nil { tmp121 = ifn_3306.Invoke_O_O__O(arg_3307, arg_3308) } else { tmp121 = linked_3305.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3304, arg_3307, arg_3308) }; arg_3297 = lang.Tuple_Create_O_O__IPersistentVector(tmp120, tmp121); var arg_3298 any = A_arbace_j2g_dyn_A_const_420; if linked_3295 == nil { tmp118 = ifn_3296.Invoke_O_O__O(arg_3297, arg_3298) } else { tmp118 = linked_3295.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3294, arg_3297, arg_3298) }; var tmp122 any = /*line :400:1*/tmp114.Invoke_O_O_O_O__O(tmp115, tmp117, tmp118, A_arbace_j2g_dyn_A_const_421); var tmp123 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp124 any = A_arbace_j2g_dyn_A_const_422; var tmp125 any; var root_3309 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3309, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3311 lang.IFn; if




































































































































































































	linked_3310 == nil { ifn_3311 = lang.IFn_Cast(root_3309) } else { ifn_3311 = nil }; var arg_3312 any; var root_3313 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3313, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3315 lang.IFn; if linked_3314 == nil { ifn_3315 = lang.IFn_Cast(root_3313) } else { ifn_3315 = nil }; var arg_3316 any = Lit_64; var arg_3317 any = Lit_65; if linked_3314 == nil { arg_3312 = ifn_3315.Invoke_O_O__O(arg_3316, arg_3317) } else { arg_3312 = linked_3314.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3313, arg_3316, arg_3317) }; if linked_3310 == nil { tmp125 = ifn_3311.Invoke_O__O(arg_3312) } else { tmp125 = linked_3310.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3309, arg_3312) }; var tmp126 any = tmp125; var tmp127 any; var root_3318 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3318, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3320 lang.IFn; if





































































































































































































	linked_3319 == nil { ifn_3320 = lang.IFn_Cast(root_3318) } else { ifn_3320 = nil }; var arg_3321 any = A_arbace_j2g_dyn_A_const_424; var arg_3322 any = A_arbace_j2g_dyn_A_const_425; if linked_3319 == nil { tmp127 = ifn_3320.Invoke_O_O__O(arg_3321, arg_3322) } else { tmp127 = linked_3319.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3318, arg_3321, arg_3322) }; var tmp128 any = tmp127; var tmp129 any; var root_3323 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3323, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3325 lang.IFn; if





































































































































































































	linked_3324 == nil { ifn_3325 = lang.IFn_Cast(root_3323) } else { ifn_3325 = nil }; var arg_3326 any = A_arbace_j2g_dyn_A_const_426; var arg_3327 any = A_arbace_j2g_dyn_A_const_427; if linked_3324 == nil { tmp129 = ifn_3325.Invoke_O_O__O(arg_3326, arg_3327) } else { tmp129 = linked_3324.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3323, arg_3326, arg_3327) }; var tmp130 any = tmp129; var tmp131 any; var root_3328 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3328, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3330 lang.IFn; if





































































































































































































	linked_3329 == nil { ifn_3330 = lang.IFn_Cast(root_3328) } else { ifn_3330 = nil }; var arg_3331 any = A_arbace_j2g_dyn_A_const_428; var arg_3332 any = A_arbace_j2g_dyn_A_const_429; if linked_3329 == nil { tmp131 = ifn_3330.Invoke_O_O__O(arg_3331, arg_3332) } else { tmp131 = linked_3329.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3328, arg_3331, arg_3332) }; var tmp132 any = tmp131; var tmp133 any; var root_3333 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3333, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3335 lang.IFn; if





































































































































































































	linked_3334 == nil { ifn_3335 = lang.IFn_Cast(root_3333) } else { ifn_3335 = nil }; var arg_3336 any = A_arbace_j2g_dyn_A_const_430; var arg_3337 any = A_arbace_j2g_dyn_A_const_431; if linked_3334 == nil { tmp133 = ifn_3335.Invoke_O_O__O(arg_3336, arg_3337) } else { tmp133 = linked_3334.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3333, arg_3336, arg_3337) }; var tmp134 any = /*line :400:1*/tmp123.Invoke_O_O_O_O__O(tmp124, tmp126, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp128, tmp130, tmp132, tmp133), A_arbace_j2g_dyn_A_const_423); var tmp135 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp136 any = A_arbace_j2g_dyn_A_const_432; var tmp137 any; var root_3338 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3338, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3340 lang.IFn; if





















































































































































































































	linked_3339 == nil { ifn_3340 = lang.IFn_Cast(root_3338) } else { ifn_3340 = nil }; var arg_3341 any; var root_3342 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3342, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3344 lang.IFn; if linked_3343 == nil { ifn_3344 = lang.IFn_Cast(root_3342) } else { ifn_3344 = nil }; var arg_3345 any = Lit_66; var arg_3346 any = Lit_67; if linked_3343 == nil { arg_3341 = ifn_3344.Invoke_O_O__O(arg_3345, arg_3346) } else { arg_3341 = linked_3343.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3342, arg_3345, arg_3346) }; if linked_3339 == nil { tmp137 = ifn_3340.Invoke_O__O(arg_3341) } else { tmp137 = linked_3339.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3338, arg_3341) }; var tmp138 any = tmp137; var tmp139 any; var root_3347 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3347, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3349 lang.IFn; if






















































































































































































































	linked_3348 == nil { ifn_3349 = lang.IFn_Cast(root_3347) } else { ifn_3349 = nil }; var arg_3350 any; var tmp140 any; var root_3352 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3352, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3354 lang.IFn; if linked_3353 == nil { ifn_3354 = lang.IFn_Cast(root_3352) } else { ifn_3354 = nil }; var arg_3355 any = A_arbace_j2g_dyn_A_const_433; var arg_3356 any = A_arbace_j2g_dyn_A_const_434; if linked_3353 == nil { tmp140 = ifn_3354.Invoke_O_O__O(arg_3355, arg_3356) } else { tmp140 = linked_3353.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3352, arg_3355, arg_3356) }; var tmp141 any = tmp140; var tmp142 any; var root_3357 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3357, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3359 lang.IFn; if linked_3358 == nil { ifn_3359 = lang.IFn_Cast(root_3357) } else { ifn_3359 = nil }; var arg_3360 any = A_arbace_j2g_dyn_A_const_435; var arg_3361 any = A_arbace_j2g_dyn_A_const_436; if linked_3358 == nil { tmp142 = ifn_3359.Invoke_O_O__O(arg_3360, arg_3361) } else { tmp142 = linked_3358.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3357, arg_3360, arg_3361) }; arg_3350 = lang.Tuple_Create_O_O__IPersistentVector(tmp141, tmp142); var arg_3351 any = A_arbace_j2g_dyn_A_const_437; if linked_3348 == nil { tmp139 = ifn_3349.Invoke_O_O__O(arg_3350, arg_3351) } else { tmp139 = linked_3348.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3347, arg_3350, arg_3351) }; var tmp143 any = /*line :400:1*/tmp135.Invoke_O_O_O_O__O(tmp136, tmp138, tmp139, A_arbace_j2g_dyn_A_const_438); var tmp144 any; var root_3161 any = A_arbace_j2g_dyn_A_const_349.GetRawRoot__O(); var linked_3162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3161, A_arbace_j2g_dyn_fn_field_native_A_fn_class); var ifn_3163 lang.IFn; if



























































































































































































































	linked_3162 == nil { ifn_3163 = lang.IFn_Cast(root_3161) } else { ifn_3163 = nil }; if linked_3162 == nil { tmp144 = ifn_3163.Invoke__O() } else { tmp144 = linked_3162.(*A_arbace_j2g_dyn_fn_field_native_A).Invoke_O__O(root_3161) }; var tmp145 any = tmp144; var tmp146 any = A_arbace_j2g_dyn_A_const_350; var tmp147 any = A_arbace_j2g_dyn_A_const_351; var tmp148 lang.IFn = /*line :400:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp149 any = A_arbace_j2g_dyn_A_const_439; var tmp150 any; var root_3362 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3362, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3364 lang.IFn; if








































































































































































































































	linked_3363 == nil { ifn_3364 = lang.IFn_Cast(root_3362) } else { ifn_3364 = nil }; var arg_3365 any; var root_3366 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3366, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3368 lang.IFn; if linked_3367 == nil { ifn_3368 = lang.IFn_Cast(root_3366) } else { ifn_3368 = nil }; var arg_3369 any = Lit_68; var arg_3370 any = Lit_69; if linked_3367 == nil { arg_3365 = ifn_3368.Invoke_O_O__O(arg_3369, arg_3370) } else { arg_3365 = linked_3367.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3366, arg_3369, arg_3370) }; if linked_3363 == nil { tmp150 = ifn_3364.Invoke_O__O(arg_3365) } else { tmp150 = linked_3363.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3362, arg_3365) }; var tmp151 any = tmp150; var tmp152 any; var root_3371 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3371, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3373 lang.IFn; if









































































































































































































































	linked_3372 == nil { ifn_3373 = lang.IFn_Cast(root_3371) } else { ifn_3373 = nil }; var arg_3374 any = A_arbace_j2g_dyn_A_const_441; var arg_3375 any = A_arbace_j2g_dyn_A_const_442; if linked_3372 == nil { tmp152 = ifn_3373.Invoke_O_O__O(arg_3374, arg_3375) } else { tmp152 = linked_3372.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3371, arg_3374, arg_3375) }; var tmp153 any = tmp152; var tmp154 any; var root_3376 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3376, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3378 lang.IFn; if









































































































































































































































	linked_3377 == nil { ifn_3378 = lang.IFn_Cast(root_3376) } else { ifn_3378 = nil }; var arg_3379 any = A_arbace_j2g_dyn_A_const_443; var arg_3380 any = A_arbace_j2g_dyn_A_const_444; if linked_3377 == nil { tmp154 = ifn_3378.Invoke_O_O__O(arg_3379, arg_3380) } else { tmp154 = linked_3377.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3376, arg_3379, arg_3380) }; var tmp155 any = /*line :400:1*/tmp148.Invoke_O_O_O_O__O(tmp149, tmp151, lang.Tuple_Create_O_O__IPersistentVector(tmp153, tmp154), A_arbace_j2g_dyn_A_const_440); var tmp156 any = A_arbace_j2g_dyn_A_const_352; var tmp157 any = A_arbace_j2g_dyn_A_const_353.GetRawRoot__O(); var tmp158 any = A_arbace_j2g_dyn_A_const_354; var tmp159 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp160 any = A_arbace_j2g_dyn_A_const_445; var tmp161 any; var root_3381 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3381, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3383 lang.IFn; if































































































































































































































































	linked_3382 == nil { ifn_3383 = lang.IFn_Cast(root_3381) } else { ifn_3383 = nil }; var arg_3384 any; var root_3385 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3385, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3387 lang.IFn; if linked_3386 == nil { ifn_3387 = lang.IFn_Cast(root_3385) } else { ifn_3387 = nil }; var arg_3388 any = Lit_70; var arg_3389 any = Lit_71; if linked_3386 == nil { arg_3384 = ifn_3387.Invoke_O_O__O(arg_3388, arg_3389) } else { arg_3384 = linked_3386.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3385, arg_3388, arg_3389) }; if linked_3382 == nil { tmp161 = ifn_3383.Invoke_O__O(arg_3384) } else { tmp161 = linked_3382.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3381, arg_3384) }; var tmp162 any = tmp161; var tmp163 any; var root_3390 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3390, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3392 lang.IFn; if
































































































































































































































































	linked_3391 == nil { ifn_3392 = lang.IFn_Cast(root_3390) } else { ifn_3392 = nil }; var arg_3393 any; var tmp164 any; var root_3395 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3395, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3397 lang.IFn; if linked_3396 == nil { ifn_3397 = lang.IFn_Cast(root_3395) } else { ifn_3397 = nil }; var arg_3398 any = A_arbace_j2g_dyn_A_const_446; var arg_3399 any = A_arbace_j2g_dyn_A_const_447; if linked_3396 == nil { tmp164 = ifn_3397.Invoke_O_O__O(arg_3398, arg_3399) } else { tmp164 = linked_3396.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3395, arg_3398, arg_3399) }; var tmp165 any = tmp164; var tmp166 any; var root_3400 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3400, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3402 lang.IFn; if linked_3401 == nil { ifn_3402 = lang.IFn_Cast(root_3400) } else { ifn_3402 = nil }; var arg_3403 any = A_arbace_j2g_dyn_A_const_448; var arg_3404 any = A_arbace_j2g_dyn_A_const_449; if linked_3401 == nil { tmp166 = ifn_3402.Invoke_O_O__O(arg_3403, arg_3404) } else { tmp166 = linked_3401.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3400, arg_3403, arg_3404) }; arg_3393 = lang.Tuple_Create_O_O__IPersistentVector(tmp165, tmp166); var arg_3394 any = A_arbace_j2g_dyn_A_const_450; if linked_3391 == nil { tmp163 = ifn_3392.Invoke_O_O__O(arg_3393, arg_3394) } else { tmp163 = linked_3391.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3390, arg_3393, arg_3394) }; var tmp167 any = /*line :400:1*/tmp159.Invoke_O_O_O_O__O(tmp160, tmp162, tmp163, A_arbace_j2g_dyn_A_const_451); var tmp168 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp169 any = A_arbace_j2g_dyn_A_const_452; var tmp170 any; var root_3405 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3405, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3407 lang.IFn; if





































































































































































































































































	linked_3406 == nil { ifn_3407 = lang.IFn_Cast(root_3405) } else { ifn_3407 = nil }; var arg_3408 any; var root_3409 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3409, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3411 lang.IFn; if linked_3410 == nil { ifn_3411 = lang.IFn_Cast(root_3409) } else { ifn_3411 = nil }; var arg_3412 any = Lit_72; var arg_3413 any = Lit_73; if linked_3410 == nil { arg_3408 = ifn_3411.Invoke_O_O__O(arg_3412, arg_3413) } else { arg_3408 = linked_3410.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3409, arg_3412, arg_3413) }; if linked_3406 == nil { tmp170 = ifn_3407.Invoke_O__O(arg_3408) } else { tmp170 = linked_3406.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3405, arg_3408) }; var tmp171 any = tmp170; var tmp172 any; var root_3414 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3414, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3416 lang.IFn; if






































































































































































































































































	linked_3415 == nil { ifn_3416 = lang.IFn_Cast(root_3414) } else { ifn_3416 = nil }; var arg_3417 any; var tmp173 any; var root_3419 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3419, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3421 lang.IFn; if linked_3420 == nil { ifn_3421 = lang.IFn_Cast(root_3419) } else { ifn_3421 = nil }; var arg_3422 any = A_arbace_j2g_dyn_A_const_453; var arg_3423 any = A_arbace_j2g_dyn_A_const_454; if linked_3420 == nil { tmp173 = ifn_3421.Invoke_O_O__O(arg_3422, arg_3423) } else { tmp173 = linked_3420.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3419, arg_3422, arg_3423) }; var tmp174 any = tmp173; var tmp175 any; var root_3424 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3424, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3426 lang.IFn; if linked_3425 == nil { ifn_3426 = lang.IFn_Cast(root_3424) } else { ifn_3426 = nil }; var arg_3427 any = A_arbace_j2g_dyn_A_const_455; var arg_3428 any = A_arbace_j2g_dyn_A_const_456; if linked_3425 == nil { tmp175 = ifn_3426.Invoke_O_O__O(arg_3427, arg_3428) } else { tmp175 = linked_3425.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3424, arg_3427, arg_3428) }; arg_3417 = lang.Tuple_Create_O_O__IPersistentVector(tmp174, tmp175); var arg_3418 any = A_arbace_j2g_dyn_A_const_457; if linked_3415 == nil { tmp172 = ifn_3416.Invoke_O_O__O(arg_3417, arg_3418) } else { tmp172 = linked_3415.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3414, arg_3417, arg_3418) }; var tmp176 any = /*line :400:1*/tmp168.Invoke_O_O_O_O__O(tmp169, tmp171, tmp172, A_arbace_j2g_dyn_A_const_458); var tmp177 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp178 any = A_arbace_j2g_dyn_A_const_459; var tmp179 any; var root_3429 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3429, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3431 lang.IFn; if








































































































































































































































































	linked_3430 == nil { ifn_3431 = lang.IFn_Cast(root_3429) } else { ifn_3431 = nil }; var arg_3432 any; var root_3433 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3433, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3435 lang.IFn; if linked_3434 == nil { ifn_3435 = lang.IFn_Cast(root_3433) } else { ifn_3435 = nil }; var arg_3436 any = Lit_74; var arg_3437 any = Lit_75; if linked_3434 == nil { arg_3432 = ifn_3435.Invoke_O_O__O(arg_3436, arg_3437) } else { arg_3432 = linked_3434.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3433, arg_3436, arg_3437) }; if linked_3430 == nil { tmp179 = ifn_3431.Invoke_O__O(arg_3432) } else { tmp179 = linked_3430.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3429, arg_3432) }; var tmp180 any = tmp179; var tmp181 any; var root_3438 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3438, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3440 lang.IFn; if









































































































































































































































































	linked_3439 == nil { ifn_3440 = lang.IFn_Cast(root_3438) } else { ifn_3440 = nil }; var arg_3441 any = A_arbace_j2g_dyn_A_const_461; var arg_3442 any = A_arbace_j2g_dyn_A_const_462; if linked_3439 == nil { tmp181 = ifn_3440.Invoke_O_O__O(arg_3441, arg_3442) } else { tmp181 = linked_3439.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3438, arg_3441, arg_3442) }; var tmp182 any = tmp181; var tmp183 any; var root_3443 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3443, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3445 lang.IFn; if









































































































































































































































































	linked_3444 == nil { ifn_3445 = lang.IFn_Cast(root_3443) } else { ifn_3445 = nil }; var arg_3446 any = A_arbace_j2g_dyn_A_const_463; var arg_3447 any = A_arbace_j2g_dyn_A_const_464; if linked_3444 == nil { tmp183 = ifn_3445.Invoke_O_O__O(arg_3446, arg_3447) } else { tmp183 = linked_3444.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3443, arg_3446, arg_3447) }; var tmp184 any = tmp183; var tmp185 any; var root_3448 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3448, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3450 lang.IFn; if









































































































































































































































































	linked_3449 == nil { ifn_3450 = lang.IFn_Cast(root_3448) } else { ifn_3450 = nil }; var arg_3451 any = A_arbace_j2g_dyn_A_const_465; var arg_3452 any = A_arbace_j2g_dyn_A_const_466; if linked_3449 == nil { tmp185 = ifn_3450.Invoke_O_O__O(arg_3451, arg_3452) } else { tmp185 = linked_3449.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3448, arg_3451, arg_3452) }; var tmp186 any = /*line :400:1*/tmp177.Invoke_O_O_O_O__O(tmp178, tmp180, lang.Tuple_Create_O_O_O__IPersistentVector(tmp182, tmp184, tmp185), A_arbace_j2g_dyn_A_const_460); var tmp187 any = A_arbace_j2g_dyn_A_const_355; var tmp188 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp189 any = A_arbace_j2g_dyn_A_const_467; var tmp190 any; var root_3453 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3453, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3455 lang.IFn; if


















































































































































































































































































	linked_3454 == nil { ifn_3455 = lang.IFn_Cast(root_3453) } else { ifn_3455 = nil }; var arg_3456 any; var root_3457 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3457, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3459 lang.IFn; if linked_3458 == nil { ifn_3459 = lang.IFn_Cast(root_3457) } else { ifn_3459 = nil }; var arg_3460 any = Lit_76; var arg_3461 any = Lit_77; if linked_3458 == nil { arg_3456 = ifn_3459.Invoke_O_O__O(arg_3460, arg_3461) } else { arg_3456 = linked_3458.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3457, arg_3460, arg_3461) }; if linked_3454 == nil { tmp190 = ifn_3455.Invoke_O__O(arg_3456) } else { tmp190 = linked_3454.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3453, arg_3456) }; var tmp191 any = tmp190; var tmp192 any; var root_3462 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3462, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3464 lang.IFn; if





















































































































































































































































































	linked_3463 == nil { ifn_3464 = lang.IFn_Cast(root_3462) } else { ifn_3464 = nil }; var arg_3465 any = A_arbace_j2g_dyn_A_const_469; var arg_3466 any = A_arbace_j2g_dyn_A_const_470; if linked_3463 == nil { tmp192 = ifn_3464.Invoke_O_O__O(arg_3465, arg_3466) } else { tmp192 = linked_3463.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3462, arg_3465, arg_3466) }; var tmp193 any = tmp192; var tmp194 any; var root_3467 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3467, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3469 lang.IFn; if





















































































































































































































































































	linked_3468 == nil { ifn_3469 = lang.IFn_Cast(root_3467) } else { ifn_3469 = nil }; var arg_3470 any = A_arbace_j2g_dyn_A_const_471; var arg_3471 any = A_arbace_j2g_dyn_A_const_472; if linked_3468 == nil { tmp194 = ifn_3469.Invoke_O_O__O(arg_3470, arg_3471) } else { tmp194 = linked_3468.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3467, arg_3470, arg_3471) }; var tmp195 any = /*line :400:1*/tmp188.Invoke_O_O_O_O_O__O(tmp189, tmp191, Lit_78, lang.Tuple_Create_O_O__IPersistentVector(tmp193, tmp194), A_arbace_j2g_dyn_A_const_468); var tmp196 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp197 any = A_arbace_j2g_dyn_A_const_473; var tmp198 any; var root_3472 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3472, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3474 lang.IFn; if



























































































































































































































































































	linked_3473 == nil { ifn_3474 = lang.IFn_Cast(root_3472) } else { ifn_3474 = nil }; var arg_3475 any; var root_3476 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3476, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3478 lang.IFn; if linked_3477 == nil { ifn_3478 = lang.IFn_Cast(root_3476) } else { ifn_3478 = nil }; var arg_3479 any = Lit_79; var arg_3480 any = Lit_80; if linked_3477 == nil { arg_3475 = ifn_3478.Invoke_O_O__O(arg_3479, arg_3480) } else { arg_3475 = linked_3477.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3476, arg_3479, arg_3480) }; if linked_3473 == nil { tmp198 = ifn_3474.Invoke_O__O(arg_3475) } else { tmp198 = linked_3473.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3472, arg_3475) }; var tmp199 any = tmp198; var tmp200 any; var root_3481 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3481, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3483 lang.IFn; if




























































































































































































































































































	linked_3482 == nil { ifn_3483 = lang.IFn_Cast(root_3481) } else { ifn_3483 = nil }; var arg_3484 any = lang.PersistentVector_EMPTY.Ref(); var arg_3485 any = A_arbace_j2g_dyn_A_const_474; if linked_3482 == nil { tmp200 = ifn_3483.Invoke_O_O__O(arg_3484, arg_3485) } else { tmp200 = linked_3482.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3481, arg_3484, arg_3485) }; var tmp201 any = /*line :400:1*/tmp196.Invoke_O_O_O_O__O(tmp197, tmp199, tmp200, A_arbace_j2g_dyn_A_const_475); var tmp202 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp203 any = A_arbace_j2g_dyn_A_const_476; var tmp204 any = A_arbace_j2g_dyn_A_const_477; var tmp205 any; var root_3616 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3616, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3618 lang.IFn; if
































































































































































































































































































	linked_3617 == nil { ifn_3618 = lang.IFn_Cast(root_3616) } else { ifn_3618 = nil }; var arg_3619 any = A_arbace_j2g_dyn_A_const_486; var arg_3620 any = A_arbace_j2g_dyn_A_const_487; if linked_3617 == nil { tmp205 = ifn_3618.Invoke_O_O__O(arg_3619, arg_3620) } else { tmp205 = linked_3617.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3616, arg_3619, arg_3620) }; var tmp206 any = /*line :400:1*/lang.Tuple_Create_O__IPersistentVector(tmp205); var tmp207 any = A_arbace_j2g_dyn_A_const_478; var tmp208 any = A_arbace_j2g_dyn_A_const_479; var tmp209 any; var root_3486 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_3487 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3486, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3488 lang.IFn; if

































































































































































































































































































	linked_3487 == nil { ifn_3488 = lang.IFn_Cast(root_3486) } else { ifn_3488 = nil }; var arg_3489 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_3490 any = A_arbace_j2g_dyn_A_const_480; var arg_3491 any = A_arbace_j2g_dyn_A_const_481; var arg_3492 any; var iter__1927001039__auto____5_3 any; var tmp210 any = A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_New(); var tmp211 *jrt.Class; var fncls__3611 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_fn_class; if
	fncls__3611 == nil { var fncls__3611d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_fn_class = fncls__3611d; tmp211 = fncls__3611d } else { tmp211 = fncls__3611 }; iter__1927001039__auto____5_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp210, tmp211, nil); var tmp212 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5_3); var tmp213 any; var root_3612 any = A_arbace_j2g_dyn_A_const_484.GetRawRoot__O(); var linked_3613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3612, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3614 lang.IFn; if linked_3613 == nil { ifn_3614 = lang.IFn_Cast(root_3612) } else { ifn_3614 = nil }; var arg_3615 any = T__0_; if linked_3613 == nil { tmp213 = ifn_3614.Invoke_O__O(arg_3615) } else { tmp213 = linked_3613.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3612, arg_3615) }; arg_3492 = tmp212.Invoke_O__O(tmp213); if /*line :690:1*/ linked_3487 == nil { tmp209 = ifn_3488.Invoke_O_O_O_O__O(arg_3489, arg_3490, arg_3491, arg_3492) } else { tmp209 = linked_3487.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3486, arg_3489, arg_3490, arg_3491, arg_3492) }; var tmp214 any = /*line :400:1*/tmp202.Invoke_O_O_O_O_O_O_O_O__O(tmp203, tmp204, Lit_81, tmp206, tmp207, tmp208, tmp209, A_arbace_j2g_dyn_A_const_485); var tmp215 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp216 any = A_arbace_j2g_dyn_A_const_488; var tmp217 any; var root_3621 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3621, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3623 lang.IFn; if







































































































































































































































































































	linked_3622 == nil { ifn_3623 = lang.IFn_Cast(root_3621) } else { ifn_3623 = nil }; var arg_3624 any; var root_3625 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3625, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3627 lang.IFn; if linked_3626 == nil { ifn_3627 = lang.IFn_Cast(root_3625) } else { ifn_3627 = nil }; var arg_3628 any = Lit_83; var arg_3629 any = Lit_84; if linked_3626 == nil { arg_3624 = ifn_3627.Invoke_O_O__O(arg_3628, arg_3629) } else { arg_3624 = linked_3626.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3625, arg_3628, arg_3629) }; if linked_3622 == nil { tmp217 = ifn_3623.Invoke_O__O(arg_3624) } else { tmp217 = linked_3622.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3621, arg_3624) }; var tmp218 any = tmp217; var tmp219 any; var root_3630 any = /*line :400:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3630, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3632 lang.IFn; if








































































































































































































































































































	linked_3631 == nil { ifn_3632 = lang.IFn_Cast(root_3630) } else { ifn_3632 = nil }; var arg_3633 any; var tmp220 any; var root_3635 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3635, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3637 lang.IFn; if linked_3636 == nil { ifn_3637 = lang.IFn_Cast(root_3635) } else { ifn_3637 = nil }; var arg_3638 any = A_arbace_j2g_dyn_A_const_489; var arg_3639 any = A_arbace_j2g_dyn_A_const_490; if linked_3636 == nil { tmp220 = ifn_3637.Invoke_O_O__O(arg_3638, arg_3639) } else { tmp220 = linked_3636.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3635, arg_3638, arg_3639) }; var tmp221 any = tmp220; var tmp222 any; var root_3640 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3640, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3642 lang.IFn; if linked_3641 == nil { ifn_3642 = lang.IFn_Cast(root_3640) } else { ifn_3642 = nil }; var arg_3643 any = A_arbace_j2g_dyn_A_const_491; var arg_3644 any = A_arbace_j2g_dyn_A_const_492; if linked_3641 == nil { tmp222 = ifn_3642.Invoke_O_O__O(arg_3643, arg_3644) } else { tmp222 = linked_3641.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3640, arg_3643, arg_3644) }; var tmp223 any = tmp222; var tmp224 any; var root_3645 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3645, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3647 lang.IFn; if linked_3646 == nil { ifn_3647 = lang.IFn_Cast(root_3645) } else { ifn_3647 = nil }; var arg_3648 any = A_arbace_j2g_dyn_A_const_493; var arg_3649 any = A_arbace_j2g_dyn_A_const_494; if linked_3646 == nil { tmp224 = ifn_3647.Invoke_O_O__O(arg_3648, arg_3649) } else { tmp224 = linked_3646.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3645, arg_3648, arg_3649) }; arg_3633 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp221, tmp223, tmp224); var arg_3634 any = A_arbace_j2g_dyn_A_const_495; if linked_3631 == nil { tmp219 = ifn_3632.Invoke_O_O__O(arg_3633, arg_3634) } else { tmp219 = linked_3631.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3630, arg_3633, arg_3634) }; var tmp225 any = tmp219; var tmp226 lang.IFn = /*line :400:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp227 any = A_arbace_j2g_dyn_A_const_497; var tmp228 any = A_arbace_j2g_dyn_A_const_498; var tmp229 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp230 any = A_arbace_j2g_dyn_A_const_499; var tmp231 any = A_arbace_j2g_dyn_A_const_504; var tmp232 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp233 any; var root_3650 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3650, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3652 lang.IFn; if











































































































































































































































































































	linked_3651 == nil { ifn_3652 = lang.IFn_Cast(root_3650) } else { ifn_3652 = nil }; var arg_3653 any; var root_3654 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3654, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3656 lang.IFn; if linked_3655 == nil { ifn_3656 = lang.IFn_Cast(root_3654) } else { ifn_3656 = nil }; var arg_3657 any = Lit_55; var arg_3658 any = Lit_56; if linked_3655 == nil { arg_3653 = ifn_3656.Invoke_O_O__O(arg_3657, arg_3658) } else { arg_3653 = linked_3655.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3654, arg_3657, arg_3658) }; if linked_3651 == nil { tmp233 = ifn_3652.Invoke_O__O(arg_3653) } else { tmp233 = linked_3651.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3650, arg_3653) }; var tmp234 any = /*line :400:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp73, tmp74, tmp75, tmp89, tmp103, tmp113, tmp122, tmp134, tmp143, tmp145, tmp146, tmp147, tmp155, tmp156, tmp157, tmp158, tmp167, tmp176, tmp186, tmp187, tmp195, tmp201, tmp214, tmp215.Invoke_O_O_O_O_O__O(tmp216, tmp218, tmp225, tmp226.Invoke_O_O_O__O(tmp227, tmp228, tmp229.Invoke_O_O_O_O_O_O__O(tmp230, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp231, tmp232.Invoke_O_O_O_O__O(tmp233, A_arbace_j2g_dyn_A_const_509, A_arbace_j2g_dyn_A_const_510, A_arbace_j2g_dyn_A_const_511), A_arbace_j2g_dyn_A_const_505, A_arbace_j2g_dyn_A_const_506, A_arbace_j2g_dyn_A_const_507, A_arbace_j2g_dyn_A_const_508), A_arbace_j2g_dyn_A_const_500, A_arbace_j2g_dyn_A_const_501, A_arbace_j2g_dyn_A_const_502, A_arbace_j2g_dyn_A_const_503)), A_arbace_j2g_dyn_A_const_496))); var tmp235 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_512.GetRawRoot__O()); var tmp236 any = A_arbace_j2g_dyn_forms_fn__711000426_A_New_O_O(ks__3, ifaces__2); var tmp237 *jrt.Class; var fncls__3670 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000426_A_fn_class; if












































































































































































































































































































































	fncls__3670 == nil { var fncls__3670d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_j2g_dyn_forms_fn__711000426_A_fn_class = fncls__3670d; tmp237 = fncls__3670d } else { tmp237 = fncls__3670 }; var tmp238 any = /*line :400:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp236, tmp237, nil); var tmp239 any; var root_3671 any = A_arbace_j2g_dyn_A_const_484.GetRawRoot__O(); var linked_3672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3671, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3673 lang.IFn; if












































































































































































































































































































































	linked_3672 == nil { ifn_3673 = lang.IFn_Cast(root_3671) } else { ifn_3673 = nil }; var arg_3674 any = T__0_; if linked_3672 == nil { tmp239 = ifn_3673.Invoke_O__O(arg_3674) } else { tmp239 = linked_3672.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3671, arg_3674) }; return /*line :400:1*/ tmp1.Invoke_O_O_O_O_O__O(tmp35, tmp39, tmp48, tmp234, tmp235.Invoke_O_O__O(tmp238, tmp239)) }






























func A_arbace_j2g_dyn_forms_fn__711000383_A_New() *A_arbace_j2g_dyn_forms_fn__711000383_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000383_A{}; t.Ctor(); return t }
//line :431:1
func (t *A_arbace_j2g_dyn_forms_fn__711000383_A) Ctor() {}
//line :431:1
func (t *A_arbace_j2g_dyn_forms_fn__711000383_A) Invoke_O_O_O__O(self, i__1, p__711000382__2 any) any { var vec__711000384__3 any = p__711000382__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000384__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000384__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }















func A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_New() *A_arbace_j2g_dyn_forms_iter__711000388__711000392_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000388__711000392_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_A) Ctor() {}
//line :447:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_A) Invoke_O_O__O(self, s__711000389__1 any) any { var tmp1 any = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_New_O_O(self, s__711000389__1); var tmp2 *jrt.Class; var fncls__3049 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_fn_class; if fncls__3049 == nil { var fncls__3049d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_fn_class = fncls__3049d; tmp2 = fncls__3049d } else { tmp2 = fncls__3049 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :447:1
func A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A{}; t.Ctor_O_O(p0, p1); return t }
//line :447:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A) Ctor_O_O(c__iter__711000388, c__s__711000389 any) { t.F_iter__711000388 = c__iter__711000388; t.F_s__711000389 = c__s__711000389 }
//line :447:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A) Invoke_O__O(self any) any { { var s__711000389__1 any; var t_ any = t.F_s__711000389; t.F_s__711000389 = nil; s__711000389__1 = t_; for { var temp__1927000414__auto____2 any; var root_2970 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2970, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2972 lang.IFn; if linked_2971 == nil { ifn_2972 = lang.IFn_Cast(root_2970) } else { ifn_2972 = nil }; var arg_2973 any = s__711000389__1; if linked_2971 == nil { temp__1927000414__auto____2 = ifn_2972.Invoke_O__O(arg_2973) } else { temp__1927000414__auto____2 = linked_2971.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2970, arg_2973) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000389__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2974 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2974, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2976 lang.IFn; if linked_2975 == nil { ifn_2976 = lang.IFn_Cast(root_2974) } else { ifn_2976 = nil }; var arg_2977 any = s__711000389__3; if linked_2975 == nil { tmp1 = ifn_2976.Invoke_O__O(arg_2977) } else { tmp1 = linked_2975.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2974, arg_2977) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2978 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2978, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2980 lang.IFn; if linked_2979 == nil { ifn_2980 = lang.IFn_Cast(root_2978) } else { ifn_2980 = nil }; var arg_2981 any = s__711000389__3; if linked_2979 == nil { c__1927001037__auto____4 = ifn_2980.Invoke_O__O(arg_2981) } else { c__1927001037__auto____4 = linked_2979.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2978, arg_2981) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000391__6 any; var root_2982 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2982, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2984 lang.IFn; if linked_2983 == nil { ifn_2984 = lang.IFn_Cast(root_2982) } else { ifn_2984 = nil }; var arg_2985 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2983 == nil { b__711000391__6 = ifn_2984.Invoke_O__O(arg_2985) } else { b__711000391__6 = linked_2983.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2982, arg_2985) }; var tmp2 any = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_New_O_I_O(b__711000391__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3002 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_fn_class; if fncls__3002 == nil { var fncls__3002d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_fn_class = fncls__3002d; tmp3 = fncls__3002d } else { tmp3 = fncls__3002 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3003 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3005 lang.IFn; if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any; var root_3008 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3008, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3010 lang.IFn; if linked_3009 == nil { ifn_3010 = lang.IFn_Cast(root_3008) } else { ifn_3010 = nil }; var arg_3011 any = b__711000391__6; if linked_3009 == nil { arg_3006 = ifn_3010.Invoke_O__O(arg_3011) } else { arg_3006 = linked_3009.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3008, arg_3011) }; var arg_3007 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000388); var tmp5 any; var root_3012 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3012, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3014 lang.IFn; if linked_3013 == nil { ifn_3014 = lang.IFn_Cast(root_3012) } else { ifn_3014 = nil }; var arg_3015 any = s__711000389__3; if linked_3013 == nil { tmp5 = ifn_3014.Invoke_O__O(arg_3015) } else { tmp5 = linked_3013.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3012, arg_3015) }; arg_3007 = tmp4.Invoke_O__O(tmp5); if linked_3004 == nil { return ifn_3005.Invoke_O_O__O(arg_3006, arg_3007) } else { return linked_3004.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3003, arg_3006, arg_3007) } } else { var root_3016 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3016, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3018 lang.IFn; if linked_3017 == nil { ifn_3018 = lang.IFn_Cast(root_3016) } else { ifn_3018 = nil }; var arg_3019 any; var root_3021 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3021, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3023 lang.IFn; if linked_3022 == nil { ifn_3023 = lang.IFn_Cast(root_3021) } else { ifn_3023 = nil }; var arg_3024 any = b__711000391__6; if linked_3022 == nil { arg_3019 = ifn_3023.Invoke_O__O(arg_3024) } else { arg_3019 = linked_3022.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3021, arg_3024) }; var arg_3020 any; if linked_3017 == nil { return ifn_3018.Invoke_O_O__O(arg_3019, arg_3020) } else { return linked_3017.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3016, arg_3019, arg_3020) } } } else { var vec__711000399__4 any; var root_3025 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3025, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3027 lang.IFn; if linked_3026 == nil { ifn_3027 = lang.IFn_Cast(root_3025) } else { ifn_3027 = nil }; var arg_3028 any = s__711000389__3; if linked_3026 == nil { vec__711000399__4 = ifn_3027.Invoke_O__O(arg_3028) } else { vec__711000399__4 = linked_3026.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3025, arg_3028) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000399__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000399__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3029 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3029, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3031 lang.IFn; if linked_3030 == nil { ifn_3031 = lang.IFn_Cast(root_3029) } else { ifn_3031 = nil }; var arg_3032 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_336; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(d__5); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_337; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any; var root_3034 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3034, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3036 lang.IFn
													if linked_3035 == nil { ifn_3036 = lang.IFn_Cast(root_3034) } else { ifn_3036 = nil }; var arg_3037 any = A_arbace_j2g_dyn_A_const_73; var arg_3038 any = Lit_16; var arg_3039 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp14 any; var root_3040 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_3042 lang.IFn; if linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any = nme__6; var arg_3044 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__5)).Ref(); if linked_3041 == nil { tmp14 = ifn_3042.Invoke_O_O__O(arg_3043, arg_3044) } else { tmp14 = linked_3041.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_3040, arg_3043, arg_3044) }; arg_3039 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3035 == nil { tmp12 = ifn_3036.Invoke_O_O_O__O(arg_3037, arg_3038, arg_3039) } else { tmp12 = linked_3035.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3034, arg_3037, arg_3038, arg_3039) }; arg_3032 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(tmp12, A_arbace_j2g_dyn_A_const_338)))
//line :447:1
	var arg_3033 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__711000388); var tmp16 any; var root_3045 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3045, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3047 lang.IFn; if linked_3046 == nil { ifn_3047 = lang.IFn_Cast(root_3045) } else { ifn_3047 = nil }; var arg_3048 any = s__711000389__3; if linked_3046 == nil { tmp16 = ifn_3047.Invoke_O__O(arg_3048) } else { tmp16 = linked_3046.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3045, arg_3048) }; arg_3033 = tmp15.Invoke_O__O(tmp16); if linked_3030 == nil { return ifn_3031.Invoke_O_O__O(arg_3032, arg_3033) } else { return linked_3030.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3029, arg_3032, arg_3033) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :447:1
func A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :447:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A) Ctor_O_I_O(c__b__711000391 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000391 = c__b__711000391; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :447:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A) Invoke_O__O(self any) any { { var i__711000390__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000390__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000395__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000390__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000395__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000395__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2986 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2986, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2988 lang.IFn; if linked_2987 == nil { ifn_2988 = lang.IFn_Cast(root_2986) } else { ifn_2988 = nil }; var arg_2989 any = t.F_b__711000391; var arg_2990 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_336; var tmp4 any = lang.Tuple_Create_O__IPersistentVector(d__3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_337; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any; var root_2991 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_2992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2991, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2993 lang.IFn
															if linked_2992 == nil { ifn_2993 = lang.IFn_Cast(root_2991) } else { ifn_2993 = nil }; var arg_2994 any = A_arbace_j2g_dyn_A_const_73; var arg_2995 any = Lit_16; var arg_2996 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp10 any; var root_2997 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2999 lang.IFn; if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var arg_3000 any = nme__4; var arg_3001 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3)).Ref(); if linked_2998 == nil { tmp10 = ifn_2999.Invoke_O_O__O(arg_3000, arg_3001) } else { tmp10 = linked_2998.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2997, arg_3000, arg_3001) }; arg_2996 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_2992 == nil { tmp8 = ifn_2993.Invoke_O_O_O__O(arg_2994, arg_2995, arg_2996) } else { tmp8 = linked_2992.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_2991, arg_2994, arg_2995, arg_2996) }; arg_2990 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, A_arbace_j2g_dyn_A_const_338)))
//line :447:1
	if linked_2987 == nil { ifn_2988.Invoke_O_O__O(arg_2989, arg_2990) } else { linked_2987.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2986, arg_2989, arg_2990) }; i__711000390__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000390__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








































func A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_New() *A_arbace_j2g_dyn_forms_iter__711000404__711000408_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000404__711000408_A{}; t.Ctor(); return t }
//line :488:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_A) Ctor() {}
//line :488:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_A) Invoke_O_O__O(self, s__711000405__1 any) any { var tmp1 any = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_New_O_O(self, s__711000405__1); var tmp2 *jrt.Class; var fncls__3138 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_fn_class; if fncls__3138 == nil { var fncls__3138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_fn_class = fncls__3138d; tmp2 = fncls__3138d } else { tmp2 = fncls__3138 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :488:1
func A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A{}; t.Ctor_O_O(p0, p1); return t }
//line :488:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A) Ctor_O_O(c__iter__711000404, c__s__711000405 any) { t.F_iter__711000404 = c__iter__711000404; t.F_s__711000405 = c__s__711000405 }
//line :488:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A) Invoke_O__O(self any) any { { var s__711000405__1 any; var t_ any = t.F_s__711000405; t.F_s__711000405 = nil; s__711000405__1 = t_; for { var temp__1927000414__auto____2 any; var root_3055 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3055, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3057 lang.IFn; if linked_3056 == nil { ifn_3057 = lang.IFn_Cast(root_3055) } else { ifn_3057 = nil }; var arg_3058 any = s__711000405__1; if linked_3056 == nil { temp__1927000414__auto____2 = ifn_3057.Invoke_O__O(arg_3058) } else { temp__1927000414__auto____2 = linked_3056.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3055, arg_3058) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000405__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3059 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3059, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3061 lang.IFn; if linked_3060 == nil { ifn_3061 = lang.IFn_Cast(root_3059) } else { ifn_3061 = nil }; var arg_3062 any = s__711000405__3; if linked_3060 == nil { tmp1 = ifn_3061.Invoke_O__O(arg_3062) } else { tmp1 = linked_3060.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3059, arg_3062) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3063 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3063, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3065 lang.IFn; if linked_3064 == nil { ifn_3065 = lang.IFn_Cast(root_3063) } else { ifn_3065 = nil }; var arg_3066 any = s__711000405__3; if linked_3064 == nil { c__1927001037__auto____4 = ifn_3065.Invoke_O__O(arg_3066) } else { c__1927001037__auto____4 = linked_3064.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3063, arg_3066) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000407__6 any; var root_3067 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3067, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3069 lang.IFn; if linked_3068 == nil { ifn_3069 = lang.IFn_Cast(root_3067) } else { ifn_3069 = nil }; var arg_3070 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3068 == nil { b__711000407__6 = ifn_3069.Invoke_O__O(arg_3070) } else { b__711000407__6 = linked_3068.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3067, arg_3070) }; var tmp2 any = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_New_O_I_O(b__711000407__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3089 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_fn_class; if fncls__3089 == nil { var fncls__3089d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_fn_class = fncls__3089d; tmp3 = fncls__3089d } else { tmp3 = fncls__3089 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3090 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3090, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3092 lang.IFn; if linked_3091 == nil { ifn_3092 = lang.IFn_Cast(root_3090) } else { ifn_3092 = nil }; var arg_3093 any; var root_3095 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3095, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3097 lang.IFn; if linked_3096 == nil { ifn_3097 = lang.IFn_Cast(root_3095) } else { ifn_3097 = nil }; var arg_3098 any = b__711000407__6; if linked_3096 == nil { arg_3093 = ifn_3097.Invoke_O__O(arg_3098) } else { arg_3093 = linked_3096.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3095, arg_3098) }; var arg_3094 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000404); var tmp5 any; var root_3099 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3101 lang.IFn; if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any = s__711000405__3; if linked_3100 == nil { tmp5 = ifn_3101.Invoke_O__O(arg_3102) } else { tmp5 = linked_3100.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3099, arg_3102) }; arg_3094 = tmp4.Invoke_O__O(tmp5); if linked_3091 == nil { return ifn_3092.Invoke_O_O__O(arg_3093, arg_3094) } else { return linked_3091.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3090, arg_3093, arg_3094) } } else { var root_3103 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3103, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3105 lang.IFn; if linked_3104 == nil { ifn_3105 = lang.IFn_Cast(root_3103) } else { ifn_3105 = nil }; var arg_3106 any; var root_3108 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3108, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3110 lang.IFn; if linked_3109 == nil { ifn_3110 = lang.IFn_Cast(root_3108) } else { ifn_3110 = nil }; var arg_3111 any = b__711000407__6; if linked_3109 == nil { arg_3106 = ifn_3110.Invoke_O__O(arg_3111) } else { arg_3106 = linked_3109.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3108, arg_3111) }; var arg_3107 any; if linked_3104 == nil { return ifn_3105.Invoke_O_O__O(arg_3106, arg_3107) } else { return linked_3104.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3103, arg_3106, arg_3107) } } } else { var j__4 any; var root_3112 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3112, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3114 lang.IFn; if linked_3113 == nil { ifn_3114 = lang.IFn_Cast(root_3112) } else { ifn_3114 = nil }; var arg_3115 any = s__711000405__3; if linked_3113 == nil { j__4 = ifn_3114.Invoke_O__O(arg_3115) } else { j__4 = linked_3113.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3112, arg_3115) }; var root_3116 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3116, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3118 lang.IFn; if linked_3117 == nil { ifn_3118 = lang.IFn_Cast(root_3116) } else { ifn_3118 = nil }; var arg_3119 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_341; var tmp8 any; var root_3121 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3121, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3123 lang.IFn; if linked_3122 == nil { ifn_3123 = lang.IFn_Cast(root_3121) } else { ifn_3123 = nil }; var arg_3124 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp10 any; var root_3125 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_3126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3125, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3127 lang.IFn; if linked_3126 == nil { ifn_3127 = lang.IFn_Cast(root_3125) } else { ifn_3127 = nil }; var arg_3128 any = j__4; if linked_3126 == nil { tmp10 = ifn_3127.Invoke_O__O(arg_3128) } else { tmp10 = linked_3126.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3125, arg_3128) }; arg_3124 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3122 == nil { tmp8 = ifn_3123.Invoke_O__O(arg_3124) } else { tmp8 = linked_3122.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3121, arg_3124) }; var tmp11 any = tmp8; var tmp12 any; var root_3129 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3129, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3131 lang.IFn; if linked_3130 == nil { ifn_3131 = lang.IFn_Cast(root_3129) } else { ifn_3131 = nil }; var arg_3132 any = A_arbace_j2g_dyn_A_const_342; var arg_3133 any = A_arbace_j2g_dyn_A_const_344; if linked_3130 == nil { tmp12 = ifn_3131.Invoke_O_O__O(arg_3132, arg_3133) } else { tmp12 = linked_3130.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3129, arg_3132, arg_3133) }; arg_3119 = tmp6.Invoke_O_O_O__O(tmp7, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12)); var arg_3120 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000404); var tmp14 any; var root_3134 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3134, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3136 lang.IFn; if linked_3135 == nil { ifn_3136 = lang.IFn_Cast(root_3134) } else { ifn_3136 = nil }; var arg_3137 any = s__711000405__3; if linked_3135 == nil { tmp14 = ifn_3136.Invoke_O__O(arg_3137) } else { tmp14 = linked_3135.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3134, arg_3137) }; arg_3120 = tmp13.Invoke_O__O(tmp14); if linked_3117 == nil { return ifn_3118.Invoke_O_O__O(arg_3119, arg_3120) } else { return linked_3117.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3116, arg_3119, arg_3120) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :488:1
func A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :488:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A) Ctor_O_I_O(c__b__711000407 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000407 = c__b__711000407; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :488:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A) Invoke_O__O(self any) any { { var i__711000406__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000406__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000406__1)); var root_3071 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3071, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3073 lang.IFn; if linked_3072 == nil { ifn_3073 = lang.IFn_Cast(root_3071) } else { ifn_3073 = nil }; var arg_3074 any = t.F_b__711000407; var arg_3075 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_341; var tmp4 any; var root_3076 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3078 lang.IFn; if linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp6 any; var root_3080 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_3081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3080, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3082 lang.IFn; if linked_3081 == nil { ifn_3082 = lang.IFn_Cast(root_3080) } else { ifn_3082 = nil }; var arg_3083 any = j__2; if linked_3081 == nil { tmp6 = ifn_3082.Invoke_O__O(arg_3083) } else { tmp6 = linked_3081.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3080, arg_3083) }; arg_3079 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_3077 == nil { tmp4 = ifn_3078.Invoke_O__O(arg_3079) } else { tmp4 = linked_3077.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3076, arg_3079) }; var tmp7 any = tmp4; var tmp8 any; var root_3084 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3084, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3086 lang.IFn; if linked_3085 == nil { ifn_3086 = lang.IFn_Cast(root_3084) } else { ifn_3086 = nil }; var arg_3087 any = A_arbace_j2g_dyn_A_const_342; var arg_3088 any = A_arbace_j2g_dyn_A_const_343; if linked_3085 == nil { tmp8 = ifn_3086.Invoke_O_O__O(arg_3087, arg_3088) } else { tmp8 = linked_3085.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3084, arg_3087, arg_3088) }; arg_3075 = tmp2.Invoke_O_O_O__O(tmp3, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8)); if linked_3072 == nil { ifn_3073.Invoke_O_O__O(arg_3074, arg_3075) } else { linked_3072.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3071, arg_3074, arg_3075) }; i__711000406__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000406__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_forms_fn__711000414_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000414_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000414_A{}; t.Ctor_O_O(p0, p1); return t }
//line :491:1
func (t *A_arbace_j2g_dyn_forms_fn__711000414_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :491:1
func (t *A_arbace_j2g_dyn_forms_fn__711000414_A) Invoke_O_O__O(self, i__1 any) any { var root_3149 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_3150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3149, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_3151 lang.IFn; if linked_3150 == nil { ifn_3151 = lang.IFn_Cast(root_3149) } else { ifn_3151 = nil }; var arg_3152 any = t.F_ifaces; var arg_3153 any = i__1; var tmp1 any = t.F_ks; var arg_3154 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(i__1)); if linked_3150 == nil { return ifn_3151.Invoke_O_O_O__O(arg_3152, arg_3153, arg_3154) } else { return linked_3150.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O__O(root_3149, arg_3152, arg_3153, arg_3154) } }







































































































































































































func A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_New() *A_arbace_j2g_dyn_forms_iter__711000416__711000420_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000416__711000420_A{}; t.Ctor(); return t }
//line :691:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_A) Ctor() {}
//line :691:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_A) Invoke_O_O__O(self, s__711000417__1 any) any { var tmp1 any = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_New_O_O(self, s__711000417__1); var tmp2 *jrt.Class; var fncls__3610 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_fn_class; if fncls__3610 == nil { var fncls__3610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_fn_class = fncls__3610d; tmp2 = fncls__3610d } else { tmp2 = fncls__3610 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :691:1
func A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A{}; t.Ctor_O_O(p0, p1); return t }
//line :691:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A) Ctor_O_O(c__iter__711000416, c__s__711000417 any) { t.F_iter__711000416 = c__iter__711000416; t.F_s__711000417 = c__s__711000417 }
//line :691:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A) Invoke_O__O(self any) any { { var s__711000417__1 any; var t_ any = t.F_s__711000417; t.F_s__711000417 = nil; s__711000417__1 = t_; for { var temp__1927000414__auto____2 any; var root_3493 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3493, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3495 lang.IFn; if linked_3494 == nil { ifn_3495 = lang.IFn_Cast(root_3493) } else { ifn_3495 = nil }; var arg_3496 any = s__711000417__1; if linked_3494 == nil { temp__1927000414__auto____2 = ifn_3495.Invoke_O__O(arg_3496) } else { temp__1927000414__auto____2 = linked_3494.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3493, arg_3496) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000417__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3497 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3497, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3499 lang.IFn; if linked_3498 == nil { ifn_3499 = lang.IFn_Cast(root_3497) } else { ifn_3499 = nil }; var arg_3500 any = s__711000417__3; if linked_3498 == nil { tmp1 = ifn_3499.Invoke_O__O(arg_3500) } else { tmp1 = linked_3498.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3497, arg_3500) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3501 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3501, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3503 lang.IFn; if linked_3502 == nil { ifn_3503 = lang.IFn_Cast(root_3501) } else { ifn_3503 = nil }; var arg_3504 any = s__711000417__3; if linked_3502 == nil { c__1927001037__auto____4 = ifn_3503.Invoke_O__O(arg_3504) } else { c__1927001037__auto____4 = linked_3502.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3501, arg_3504) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000419__6 any; var root_3505 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3505, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3507 lang.IFn; if linked_3506 == nil { ifn_3507 = lang.IFn_Cast(root_3505) } else { ifn_3507 = nil }; var arg_3508 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3506 == nil { b__711000419__6 = ifn_3507.Invoke_O__O(arg_3508) } else { b__711000419__6 = linked_3506.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3505, arg_3508) }; var tmp2 any = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_New_O_I_O(b__711000419__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3544 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_fn_class; if fncls__3544 == nil { var fncls__3544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_fn_class = fncls__3544d; tmp3 = fncls__3544d } else { tmp3 = fncls__3544 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3545 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3545, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3547 lang.IFn; if linked_3546 == nil { ifn_3547 = lang.IFn_Cast(root_3545) } else { ifn_3547 = nil }; var arg_3548 any; var root_3550 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3550, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3552 lang.IFn; if linked_3551 == nil { ifn_3552 = lang.IFn_Cast(root_3550) } else { ifn_3552 = nil }; var arg_3553 any = b__711000419__6; if linked_3551 == nil { arg_3548 = ifn_3552.Invoke_O__O(arg_3553) } else { arg_3548 = linked_3551.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3550, arg_3553) }; var arg_3549 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000416); var tmp5 any; var root_3554 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3554, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3556 lang.IFn; if linked_3555 == nil { ifn_3556 = lang.IFn_Cast(root_3554) } else { ifn_3556 = nil }; var arg_3557 any = s__711000417__3; if linked_3555 == nil { tmp5 = ifn_3556.Invoke_O__O(arg_3557) } else { tmp5 = linked_3555.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3554, arg_3557) }; arg_3549 = tmp4.Invoke_O__O(tmp5); if linked_3546 == nil { return ifn_3547.Invoke_O_O__O(arg_3548, arg_3549) } else { return linked_3546.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3545, arg_3548, arg_3549) } } else { var root_3558 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3558, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3560 lang.IFn; if linked_3559 == nil { ifn_3560 = lang.IFn_Cast(root_3558) } else { ifn_3560 = nil }; var arg_3561 any; var root_3563 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3563, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3565 lang.IFn; if linked_3564 == nil { ifn_3565 = lang.IFn_Cast(root_3563) } else { ifn_3565 = nil }; var arg_3566 any = b__711000419__6; if linked_3564 == nil { arg_3561 = ifn_3565.Invoke_O__O(arg_3566) } else { arg_3561 = linked_3564.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3563, arg_3566) }; var arg_3562 any; if linked_3559 == nil { return ifn_3560.Invoke_O_O__O(arg_3561, arg_3562) } else { return linked_3559.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3558, arg_3561, arg_3562) } } } else { var p__4 any; var root_3567 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3567, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3569 lang.IFn; if linked_3568 == nil { ifn_3569 = lang.IFn_Cast(root_3567) } else { ifn_3569 = nil }; var arg_3570 any = s__711000417__3; if linked_3568 == nil { p__4 = ifn_3569.Invoke_O__O(arg_3570) } else { p__4 = linked_3568.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3567, arg_3570) }; var root_3571 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3571, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3573 lang.IFn; if linked_3572 == nil { ifn_3573 = lang.IFn_Cast(root_3571) } else { ifn_3573 = nil }; var arg_3574 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_482; var tmp8 any; var root_3576 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3576, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3578 lang.IFn
													if linked_3577 == nil { ifn_3578 = lang.IFn_Cast(root_3576) } else { ifn_3578 = nil }; var arg_3579 any = A_arbace_j2g_dyn_A_const_73; var arg_3580 any = p__4; var arg_3581 any = Lit_23; if linked_3577 == nil { tmp8 = ifn_3578.Invoke_O_O_O__O(arg_3579, arg_3580, arg_3581) } else { tmp8 = linked_3577.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3576, arg_3579, arg_3580, arg_3581) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_483; var tmp12 any; var root_3582 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3582, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3584 lang.IFn
													if linked_3583 == nil { ifn_3584 = lang.IFn_Cast(root_3582) } else { ifn_3584 = nil }; var arg_3585 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_93, nil); var tmp14 any; var root_3586 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3586, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3588 lang.IFn; if linked_3587 == nil { ifn_3588 = lang.IFn_Cast(root_3586) } else { ifn_3588 = nil }; var arg_3589 any = p__4; if linked_3587 == nil { tmp14 = ifn_3588.Invoke_O__O(arg_3589) } else { tmp14 = linked_3587.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3586, arg_3589) }; arg_3585 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3583 == nil { tmp12 = ifn_3584.Invoke_O__O(arg_3585) } else { tmp12 = linked_3583.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3582, arg_3585) }
//line :692:1
	var tmp15 any = tmp12; var tmp16 any; var root_3590 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3590, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3592 lang.IFn
	if linked_3591 == nil { ifn_3592 = lang.IFn_Cast(root_3590) } else { ifn_3592 = nil }; var arg_3593 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp18 any; var root_3594 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3594, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3596 lang.IFn; if linked_3595 == nil { ifn_3596 = lang.IFn_Cast(root_3594) } else { ifn_3596 = nil }; var arg_3597 any = p__4; if linked_3595 == nil { tmp18 = ifn_3596.Invoke_O__O(arg_3597) } else { tmp18 = linked_3595.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3594, arg_3597) }; arg_3593 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3591 == nil { tmp16 = ifn_3592.Invoke_O__O(arg_3593) } else { tmp16 = linked_3591.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3590, arg_3593) }
//line :692:1
	var tmp19 any = tmp16; var tmp20 any; var root_3598 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3598, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3600 lang.IFn

	if linked_3599 == nil { ifn_3600 = lang.IFn_Cast(root_3598) } else { ifn_3600 = nil }; var arg_3601 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_94, nil); var tmp22 any; var root_3602 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3602, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3604 lang.IFn; if linked_3603 == nil { ifn_3604 = lang.IFn_Cast(root_3602) } else { ifn_3604 = nil }; var arg_3605 any = p__4; if linked_3603 == nil { tmp22 = ifn_3604.Invoke_O__O(arg_3605) } else { tmp22 = linked_3603.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3602, arg_3605) }; arg_3601 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref(); if linked_3599 == nil { tmp20 = ifn_3600.Invoke_O__O(arg_3601) } else { tmp20 = linked_3599.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3598, arg_3601) }
//line :692:1
	arg_3574 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp15, tmp19, tmp20))
//line :691:1
	var arg_3575 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000416); var tmp24 any; var root_3606 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3606, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3608 lang.IFn; if linked_3607 == nil { ifn_3608 = lang.IFn_Cast(root_3606) } else { ifn_3608 = nil }; var arg_3609 any = s__711000417__3; if linked_3607 == nil { tmp24 = ifn_3608.Invoke_O__O(arg_3609) } else { tmp24 = linked_3607.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3606, arg_3609) }; arg_3575 = tmp23.Invoke_O__O(tmp24); if linked_3572 == nil { return ifn_3573.Invoke_O_O__O(arg_3574, arg_3575) } else { return linked_3572.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3571, arg_3574, arg_3575) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :691:1
func A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :691:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A) Ctor_O_I_O(c__b__711000419 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000419 = c__b__711000419; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :691:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A) Invoke_O__O(self any) any { { var i__711000418__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000418__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000418__1)); var root_3509 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3509, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3511 lang.IFn; if linked_3510 == nil { ifn_3511 = lang.IFn_Cast(root_3509) } else { ifn_3511 = nil }; var arg_3512 any = t.F_b__711000419; var arg_3513 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_482; var tmp4 any; var root_3514 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3514, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3516 lang.IFn
															if linked_3515 == nil { ifn_3516 = lang.IFn_Cast(root_3514) } else { ifn_3516 = nil }; var arg_3517 any = A_arbace_j2g_dyn_A_const_73; var arg_3518 any = p__2; var arg_3519 any = Lit_23; if linked_3515 == nil { tmp4 = ifn_3516.Invoke_O_O_O__O(arg_3517, arg_3518, arg_3519) } else { tmp4 = linked_3515.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3514, arg_3517, arg_3518, arg_3519) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_483; var tmp8 any; var root_3520 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3520, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3522 lang.IFn
															if linked_3521 == nil { ifn_3522 = lang.IFn_Cast(root_3520) } else { ifn_3522 = nil }; var arg_3523 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_93, nil); var tmp10 any; var root_3524 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3524, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3526 lang.IFn; if linked_3525 == nil { ifn_3526 = lang.IFn_Cast(root_3524) } else { ifn_3526 = nil }; var arg_3527 any = p__2; if linked_3525 == nil { tmp10 = ifn_3526.Invoke_O__O(arg_3527) } else { tmp10 = linked_3525.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3524, arg_3527) }; arg_3523 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3521 == nil { tmp8 = ifn_3522.Invoke_O__O(arg_3523) } else { tmp8 = linked_3521.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3520, arg_3523) }
//line :692:1
	var tmp11 any = tmp8; var tmp12 any; var root_3528 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3528, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3530 lang.IFn
	if linked_3529 == nil { ifn_3530 = lang.IFn_Cast(root_3528) } else { ifn_3530 = nil }; var arg_3531 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp14 any; var root_3532 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3532, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3534 lang.IFn; if linked_3533 == nil { ifn_3534 = lang.IFn_Cast(root_3532) } else { ifn_3534 = nil }; var arg_3535 any = p__2; if linked_3533 == nil { tmp14 = ifn_3534.Invoke_O__O(arg_3535) } else { tmp14 = linked_3533.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3532, arg_3535) }; arg_3531 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3529 == nil { tmp12 = ifn_3530.Invoke_O__O(arg_3531) } else { tmp12 = linked_3529.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3528, arg_3531) }
//line :692:1
	var tmp15 any = tmp12; var tmp16 any; var root_3536 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3536, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3538 lang.IFn

	if linked_3537 == nil { ifn_3538 = lang.IFn_Cast(root_3536) } else { ifn_3538 = nil }; var arg_3539 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_94, nil); var tmp18 any; var root_3540 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3540, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3542 lang.IFn; if linked_3541 == nil { ifn_3542 = lang.IFn_Cast(root_3540) } else { ifn_3542 = nil }; var arg_3543 any = p__2; if linked_3541 == nil { tmp18 = ifn_3542.Invoke_O__O(arg_3543) } else { tmp18 = linked_3541.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3540, arg_3543) }; arg_3539 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3537 == nil { tmp16 = ifn_3538.Invoke_O__O(arg_3539) } else { tmp16 = linked_3537.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3536, arg_3539) }
//line :692:1
	arg_3513 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp11, tmp15, tmp16))
//line :691:1
	if linked_3510 == nil { ifn_3511.Invoke_O_O__O(arg_3512, arg_3513) } else { linked_3510.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3509, arg_3512, arg_3513) }; i__711000418__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000418__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































func A_arbace_j2g_dyn_forms_fn__711000426_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000426_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000426_A{}; t.Ctor_O_O(p0, p1); return t }
//line :733:1
func (t *A_arbace_j2g_dyn_forms_fn__711000426_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :733:1
func (t *A_arbace_j2g_dyn_forms_fn__711000426_A) Invoke_O_O__O(self, p1__711000381_SHARP___1 any) any { var root_3664 any = A_arbace_j2g_dyn_A_const_513.GetRawRoot__O(); var linked_3665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3664, A_arbace_j2g_dyn_sub_forms_A_fn_class); var ifn_3666 lang.IFn; if linked_3665 == nil { ifn_3666 = lang.IFn_Cast(root_3664) } else { ifn_3666 = nil }; var arg_3667 any = p1__711000381_SHARP___1; var arg_3668 any = t.F_ifaces; var arg_3669 any = t.F_ks; if linked_3665 == nil { return ifn_3666.Invoke_O_O_O__O(arg_3667, arg_3668, arg_3669) } else { return linked_3665.(*A_arbace_j2g_dyn_sub_forms_A).Invoke_O_O_O_O__O(root_3664, arg_3667, arg_3668, arg_3669) } }








































type A_arbace_j2g_dyn_A struct{ jrt.Object }

var A_arbace_j2g_dyn_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyn_A_const_0 *lang.Var

var A_arbace_j2g_dyn_A_const_1 any

var A_arbace_j2g_dyn_A_const_2 any

var A_arbace_j2g_dyn_A_const_3 any

var A_arbace_j2g_dyn_A_const_4 any

var A_arbace_j2g_dyn_A_const_5 any

var A_arbace_j2g_dyn_A_const_6 any

var A_arbace_j2g_dyn_A_const_7 any

var A_arbace_j2g_dyn_A_const_8 any

var A_arbace_j2g_dyn_A_const_9 *lang.Var

var A_arbace_j2g_dyn_A_const_10 any

var A_arbace_j2g_dyn_A_const_11 *lang.Var

var A_arbace_j2g_dyn_A_const_12 *lang.Var

var A_arbace_j2g_dyn_A_const_13 *lang.Var

var A_arbace_j2g_dyn_A_const_14 *lang.Var

var A_arbace_j2g_dyn_A_const_15 any

var A_arbace_j2g_dyn_A_const_16 *lang.Var

var A_arbace_j2g_dyn_A_const_17 *lang.Keyword

var A_arbace_j2g_dyn_A_const_18 *lang.Var

var A_arbace_j2g_dyn_A_const_19 *lang.Var

var A_arbace_j2g_dyn_A_const_20 *lang.Var

var A_arbace_j2g_dyn_A_const_21 *lang.Var

var A_arbace_j2g_dyn_A_const_22 *lang.Var

var A_arbace_j2g_dyn_A_const_23 *lang.Var

var A_arbace_j2g_dyn_A_const_24 *lang.Var

var A_arbace_j2g_dyn_A_const_25 *lang.Var

var A_arbace_j2g_dyn_A_const_26 *lang.Var

var A_arbace_j2g_dyn_A_const_27 *lang.Var

var A_arbace_j2g_dyn_A_const_28 *lang.Var

var A_arbace_j2g_dyn_A_const_29 *lang.Var

var A_arbace_j2g_dyn_A_const_30 *lang.Var

var A_arbace_j2g_dyn_A_const_31 *lang.Var

var A_arbace_j2g_dyn_A_const_32 *lang.Var

var A_arbace_j2g_dyn_A_const_33 *lang.Keyword

var A_arbace_j2g_dyn_A_const_34 *lang.Var

var A_arbace_j2g_dyn_A_const_35 *lang.Var

var A_arbace_j2g_dyn_A_const_36 *lang.Var

var A_arbace_j2g_dyn_A_const_37 *lang.Var

var A_arbace_j2g_dyn_A_const_38 *lang.Var

var A_arbace_j2g_dyn_A_const_39 *lang.Var

var A_arbace_j2g_dyn_A_const_40 *lang.Var

var A_arbace_j2g_dyn_A_const_41 *lang.Var

var A_arbace_j2g_dyn_A_const_42 *lang.Var

var A_arbace_j2g_dyn_A_const_43 *lang.Var

var A_arbace_j2g_dyn_A_const_44 *lang.Var

var A_arbace_j2g_dyn_A_const_45 *lang.Keyword

var A_arbace_j2g_dyn_A_const_46 *lang.Keyword

var A_arbace_j2g_dyn_A_const_47 *lang.Var

var A_arbace_j2g_dyn_A_const_48 *lang.Var

var A_arbace_j2g_dyn_A_const_49 *lang.Var

var A_arbace_j2g_dyn_A_const_50 *lang.Var

var A_arbace_j2g_dyn_A_const_51 *lang.Keyword

var A_arbace_j2g_dyn_A_const_52 *lang.Var

var A_arbace_j2g_dyn_A_const_53 *lang.Var

var A_arbace_j2g_dyn_A_const_54 *lang.Var

var A_arbace_j2g_dyn_A_const_55 *lang.Var

var A_arbace_j2g_dyn_A_const_56 *lang.Var

var A_arbace_j2g_dyn_A_const_57 *lang.Var

var A_arbace_j2g_dyn_A_const_58 *lang.Var

var A_arbace_j2g_dyn_A_const_59 *lang.Var

var A_arbace_j2g_dyn_A_const_60 *lang.Var

var A_arbace_j2g_dyn_A_const_61 *lang.Var

var A_arbace_j2g_dyn_A_const_62 *lang.Var

var A_arbace_j2g_dyn_A_const_63 *lang.Var

var A_arbace_j2g_dyn_A_const_64 *lang.Keyword

var A_arbace_j2g_dyn_A_const_65 *lang.Keyword

var A_arbace_j2g_dyn_A_const_66 *lang.Var

var A_arbace_j2g_dyn_A_const_67 *lang.Var

var A_arbace_j2g_dyn_A_const_68 *lang.Var

var A_arbace_j2g_dyn_A_const_69 *lang.Keyword

var A_arbace_j2g_dyn_A_const_70 *lang.Keyword

var A_arbace_j2g_dyn_A_const_71 *lang.Keyword

var A_arbace_j2g_dyn_A_const_72 *lang.Var

var A_arbace_j2g_dyn_A_const_73 *lang.Keyword

var A_arbace_j2g_dyn_A_const_74 *lang.Var

var A_arbace_j2g_dyn_A_const_75 *lang.Var

var A_arbace_j2g_dyn_A_const_76 *lang.Var

var A_arbace_j2g_dyn_A_const_77 *lang.Var

var A_arbace_j2g_dyn_A_const_78 *lang.Var

var A_arbace_j2g_dyn_A_const_79 *lang.Var

var A_arbace_j2g_dyn_A_const_80 *lang.Var

var A_arbace_j2g_dyn_A_const_81 *lang.Keyword

var A_arbace_j2g_dyn_A_const_82 any

var A_arbace_j2g_dyn_A_const_83 any

var A_arbace_j2g_dyn_A_const_84 any

var A_arbace_j2g_dyn_A_const_85 *lang.Var

var A_arbace_j2g_dyn_A_const_86 *lang.Var

var A_arbace_j2g_dyn_A_const_87 *lang.Keyword

var A_arbace_j2g_dyn_A_const_88 *lang.Var

var A_arbace_j2g_dyn_A_const_89 *lang.Var

var A_arbace_j2g_dyn_A_const_90 any

var A_arbace_j2g_dyn_A_const_91 *lang.Var

var A_arbace_j2g_dyn_A_const_92 *lang.Var

var A_arbace_j2g_dyn_A_const_93 *lang.Var

var A_arbace_j2g_dyn_A_const_94 any

var A_arbace_j2g_dyn_A_const_95 *lang.Var

var A_arbace_j2g_dyn_A_const_96 any

var A_arbace_j2g_dyn_A_const_97 any

var A_arbace_j2g_dyn_A_const_98 any

var A_arbace_j2g_dyn_A_const_99 *lang.Var

var A_arbace_j2g_dyn_A_const_100 *lang.Var

var A_arbace_j2g_dyn_A_const_101 *lang.Var

var A_arbace_j2g_dyn_A_const_102 any

var A_arbace_j2g_dyn_A_const_103 any

var A_arbace_j2g_dyn_A_const_104 any

var A_arbace_j2g_dyn_A_const_105 any

var A_arbace_j2g_dyn_A_const_106 any

var A_arbace_j2g_dyn_A_const_107 any

var A_arbace_j2g_dyn_A_const_108 *lang.Var

var A_arbace_j2g_dyn_A_const_109 any

var A_arbace_j2g_dyn_A_const_110 *lang.Var

var A_arbace_j2g_dyn_A_const_111 *lang.Var

var A_arbace_j2g_dyn_A_const_112 *lang.Keyword

var A_arbace_j2g_dyn_A_const_113 *lang.Var

var A_arbace_j2g_dyn_A_const_114 *lang.Var

var A_arbace_j2g_dyn_A_const_115 *lang.Var

var A_arbace_j2g_dyn_A_const_116 *lang.Var

var A_arbace_j2g_dyn_A_const_117 *lang.Var

var A_arbace_j2g_dyn_A_const_118 any

var A_arbace_j2g_dyn_A_const_119 any

var A_arbace_j2g_dyn_A_const_120 any

var A_arbace_j2g_dyn_A_const_121 any

var A_arbace_j2g_dyn_A_const_122 any

var A_arbace_j2g_dyn_A_const_123 any

var A_arbace_j2g_dyn_A_const_124 any

var A_arbace_j2g_dyn_A_const_125 any

var A_arbace_j2g_dyn_A_const_126 any

var A_arbace_j2g_dyn_A_const_127 any

var A_arbace_j2g_dyn_A_const_128 any

var A_arbace_j2g_dyn_A_const_129 *lang.Var

var A_arbace_j2g_dyn_A_const_130 any

var A_arbace_j2g_dyn_A_const_131 any

var A_arbace_j2g_dyn_A_const_132 any

var A_arbace_j2g_dyn_A_const_133 *lang.Var

var A_arbace_j2g_dyn_A_const_134 *lang.Var

var A_arbace_j2g_dyn_A_const_135 *lang.Var

var A_arbace_j2g_dyn_A_const_136 *lang.Var

var A_arbace_j2g_dyn_A_const_137 any

var A_arbace_j2g_dyn_A_const_138 *lang.Var

var A_arbace_j2g_dyn_A_const_139 any

var A_arbace_j2g_dyn_A_const_140 any

var A_arbace_j2g_dyn_A_const_141 any

var A_arbace_j2g_dyn_A_const_142 any

var A_arbace_j2g_dyn_A_const_143 any

var A_arbace_j2g_dyn_A_const_144 any

var A_arbace_j2g_dyn_A_const_145 any

var A_arbace_j2g_dyn_A_const_146 any

var A_arbace_j2g_dyn_A_const_147 any

var A_arbace_j2g_dyn_A_const_148 any

var A_arbace_j2g_dyn_A_const_149 any

var A_arbace_j2g_dyn_A_const_150 any

var A_arbace_j2g_dyn_A_const_151 any

var A_arbace_j2g_dyn_A_const_152 any

var A_arbace_j2g_dyn_A_const_153 any

var A_arbace_j2g_dyn_A_const_154 any

var A_arbace_j2g_dyn_A_const_155 any

var A_arbace_j2g_dyn_A_const_156 any

var A_arbace_j2g_dyn_A_const_157 *lang.Var

var A_arbace_j2g_dyn_A_const_158 any

var A_arbace_j2g_dyn_A_const_159 *lang.Var

var A_arbace_j2g_dyn_A_const_160 any

var A_arbace_j2g_dyn_A_const_161 any

var A_arbace_j2g_dyn_A_const_162 any

var A_arbace_j2g_dyn_A_const_163 *lang.Var

var A_arbace_j2g_dyn_A_const_164 *lang.Var

var A_arbace_j2g_dyn_A_const_165 *lang.Var

var A_arbace_j2g_dyn_A_const_166 *lang.Var

var A_arbace_j2g_dyn_A_const_167 *lang.Var

var A_arbace_j2g_dyn_A_const_168 *lang.Var

var A_arbace_j2g_dyn_A_const_169 any

var A_arbace_j2g_dyn_A_const_170 any

var A_arbace_j2g_dyn_A_const_171 any

var A_arbace_j2g_dyn_A_const_172 any

var A_arbace_j2g_dyn_A_const_173 any

var A_arbace_j2g_dyn_A_const_174 any

var A_arbace_j2g_dyn_A_const_175 any

var A_arbace_j2g_dyn_A_const_176 any

var A_arbace_j2g_dyn_A_const_177 any

var A_arbace_j2g_dyn_A_const_178 any

var A_arbace_j2g_dyn_A_const_179 *lang.Keyword

var A_arbace_j2g_dyn_A_const_180 *lang.Keyword

var A_arbace_j2g_dyn_A_const_181 *lang.Keyword

var A_arbace_j2g_dyn_A_const_182 any

var A_arbace_j2g_dyn_A_const_183 any

var A_arbace_j2g_dyn_A_const_184 any

var A_arbace_j2g_dyn_A_const_185 any

var A_arbace_j2g_dyn_A_const_186 any

var A_arbace_j2g_dyn_A_const_187 any

var A_arbace_j2g_dyn_A_const_188 any

var A_arbace_j2g_dyn_A_const_189 *lang.Var

var A_arbace_j2g_dyn_A_const_190 any

var A_arbace_j2g_dyn_A_const_191 any

var A_arbace_j2g_dyn_A_const_192 any

var A_arbace_j2g_dyn_A_const_193 *lang.Var

var A_arbace_j2g_dyn_A_const_194 *lang.Var

var A_arbace_j2g_dyn_A_const_195 *lang.Var

var A_arbace_j2g_dyn_A_const_196 *lang.Var

var A_arbace_j2g_dyn_A_const_197 any

var A_arbace_j2g_dyn_A_const_198 any

var A_arbace_j2g_dyn_A_const_199 any

var A_arbace_j2g_dyn_A_const_200 any

var A_arbace_j2g_dyn_A_const_201 any

var A_arbace_j2g_dyn_A_const_202 any

var A_arbace_j2g_dyn_A_const_203 any

var A_arbace_j2g_dyn_A_const_204 any

var A_arbace_j2g_dyn_A_const_205 *lang.Var

var A_arbace_j2g_dyn_A_const_206 *lang.Var

var A_arbace_j2g_dyn_A_const_207 *lang.Var

var A_arbace_j2g_dyn_A_const_208 *lang.Var

var A_arbace_j2g_dyn_A_const_209 any

var A_arbace_j2g_dyn_A_const_210 any

var A_arbace_j2g_dyn_A_const_211 *lang.Keyword

var A_arbace_j2g_dyn_A_const_212 any

var A_arbace_j2g_dyn_A_const_213 any

var A_arbace_j2g_dyn_A_const_214 *lang.Var

var A_arbace_j2g_dyn_A_const_215 *lang.Keyword

var A_arbace_j2g_dyn_A_const_216 any

var A_arbace_j2g_dyn_A_const_217 *lang.Keyword

var A_arbace_j2g_dyn_A_const_218 *lang.Var

var A_arbace_j2g_dyn_A_const_219 any

var A_arbace_j2g_dyn_A_const_220 any

var A_arbace_j2g_dyn_A_const_221 any

var A_arbace_j2g_dyn_A_const_222 any

var A_arbace_j2g_dyn_A_const_223 *lang.Var

var A_arbace_j2g_dyn_A_const_224 any

var A_arbace_j2g_dyn_A_const_225 any

var A_arbace_j2g_dyn_A_const_226 any

var A_arbace_j2g_dyn_A_const_227 any

var A_arbace_j2g_dyn_A_const_228 any

var A_arbace_j2g_dyn_A_const_229 *lang.Var

var A_arbace_j2g_dyn_A_const_230 any

var A_arbace_j2g_dyn_A_const_231 any

var A_arbace_j2g_dyn_A_const_232 any

var A_arbace_j2g_dyn_A_const_233 any

var A_arbace_j2g_dyn_A_const_234 any

var A_arbace_j2g_dyn_A_const_235 any

var A_arbace_j2g_dyn_A_const_236 *lang.Keyword

var A_arbace_j2g_dyn_A_const_237 any

var A_arbace_j2g_dyn_A_const_238 any

var A_arbace_j2g_dyn_A_const_239 any

var A_arbace_j2g_dyn_A_const_240 any

var A_arbace_j2g_dyn_A_const_241 any

var A_arbace_j2g_dyn_A_const_242 any

var A_arbace_j2g_dyn_A_const_243 any

var A_arbace_j2g_dyn_A_const_244 *lang.Var

var A_arbace_j2g_dyn_A_const_245 *lang.Var

var A_arbace_j2g_dyn_A_const_246 *lang.Var

var A_arbace_j2g_dyn_A_const_247 *lang.Var

var A_arbace_j2g_dyn_A_const_248 any

var A_arbace_j2g_dyn_A_const_249 any

var A_arbace_j2g_dyn_A_const_250 any

var A_arbace_j2g_dyn_A_const_251 any

var A_arbace_j2g_dyn_A_const_252 any

var A_arbace_j2g_dyn_A_const_253 any

var A_arbace_j2g_dyn_A_const_254 any

var A_arbace_j2g_dyn_A_const_255 any

var A_arbace_j2g_dyn_A_const_256 any

var A_arbace_j2g_dyn_A_const_257 any

var A_arbace_j2g_dyn_A_const_258 any

var A_arbace_j2g_dyn_A_const_259 any

var A_arbace_j2g_dyn_A_const_260 any

var A_arbace_j2g_dyn_A_const_261 any

var A_arbace_j2g_dyn_A_const_262 any

var A_arbace_j2g_dyn_A_const_263 any

var A_arbace_j2g_dyn_A_const_264 any

var A_arbace_j2g_dyn_A_const_265 any

var A_arbace_j2g_dyn_A_const_266 any

var A_arbace_j2g_dyn_A_const_267 any

var A_arbace_j2g_dyn_A_const_268 any

var A_arbace_j2g_dyn_A_const_269 any

var A_arbace_j2g_dyn_A_const_270 any

var A_arbace_j2g_dyn_A_const_271 any

var A_arbace_j2g_dyn_A_const_272 any

var A_arbace_j2g_dyn_A_const_273 any

var A_arbace_j2g_dyn_A_const_274 any

var A_arbace_j2g_dyn_A_const_275 any

var A_arbace_j2g_dyn_A_const_276 any

var A_arbace_j2g_dyn_A_const_277 any

var A_arbace_j2g_dyn_A_const_278 any

var A_arbace_j2g_dyn_A_const_279 any

var A_arbace_j2g_dyn_A_const_280 any

var A_arbace_j2g_dyn_A_const_281 *lang.Var

var A_arbace_j2g_dyn_A_const_282 any

var A_arbace_j2g_dyn_A_const_283 any

var A_arbace_j2g_dyn_A_const_284 *lang.Var

var A_arbace_j2g_dyn_A_const_285 *lang.Var

var A_arbace_j2g_dyn_A_const_286 *lang.Var

var A_arbace_j2g_dyn_A_const_287 any

var A_arbace_j2g_dyn_A_const_288 any

var A_arbace_j2g_dyn_A_const_289 *lang.Var

var A_arbace_j2g_dyn_A_const_290 any

var A_arbace_j2g_dyn_A_const_291 any

var A_arbace_j2g_dyn_A_const_292 any

var A_arbace_j2g_dyn_A_const_293 any

var A_arbace_j2g_dyn_A_const_294 any

var A_arbace_j2g_dyn_A_const_295 any

var A_arbace_j2g_dyn_A_const_296 any

var A_arbace_j2g_dyn_A_const_297 any

var A_arbace_j2g_dyn_A_const_298 any

var A_arbace_j2g_dyn_A_const_299 *lang.Var

var A_arbace_j2g_dyn_A_const_300 *lang.Var

var A_arbace_j2g_dyn_A_const_301 any

var A_arbace_j2g_dyn_A_const_302 any

var A_arbace_j2g_dyn_A_const_303 any

var A_arbace_j2g_dyn_A_const_304 any

var A_arbace_j2g_dyn_A_const_305 any

var A_arbace_j2g_dyn_A_const_306 any

var A_arbace_j2g_dyn_A_const_307 any

var A_arbace_j2g_dyn_A_const_308 any

var A_arbace_j2g_dyn_A_const_309 any

var A_arbace_j2g_dyn_A_const_310 any

var A_arbace_j2g_dyn_A_const_311 any

var A_arbace_j2g_dyn_A_const_312 any

var A_arbace_j2g_dyn_A_const_313 any

var A_arbace_j2g_dyn_A_const_314 any

var A_arbace_j2g_dyn_A_const_315 any

var A_arbace_j2g_dyn_A_const_316 any

var A_arbace_j2g_dyn_A_const_317 any

var A_arbace_j2g_dyn_A_const_318 any

var A_arbace_j2g_dyn_A_const_319 any

var A_arbace_j2g_dyn_A_const_320 any

var A_arbace_j2g_dyn_A_const_321 any

var A_arbace_j2g_dyn_A_const_322 any

var A_arbace_j2g_dyn_A_const_323 any

var A_arbace_j2g_dyn_A_const_324 any

var A_arbace_j2g_dyn_A_const_325 any

var A_arbace_j2g_dyn_A_const_326 any

var A_arbace_j2g_dyn_A_const_327 any

var A_arbace_j2g_dyn_A_const_328 any

var A_arbace_j2g_dyn_A_const_329 any

var A_arbace_j2g_dyn_A_const_330 any

var A_arbace_j2g_dyn_A_const_331 any

var A_arbace_j2g_dyn_A_const_332 any

var A_arbace_j2g_dyn_A_const_333 any

var A_arbace_j2g_dyn_A_const_334 any

var A_arbace_j2g_dyn_A_const_335 any

var A_arbace_j2g_dyn_A_const_336 any

var A_arbace_j2g_dyn_A_const_337 any

var A_arbace_j2g_dyn_A_const_338 any

var A_arbace_j2g_dyn_A_const_339 any

var A_arbace_j2g_dyn_A_const_340 any

var A_arbace_j2g_dyn_A_const_341 any

var A_arbace_j2g_dyn_A_const_342 any

var A_arbace_j2g_dyn_A_const_343 any

var A_arbace_j2g_dyn_A_const_344 any

var A_arbace_j2g_dyn_A_const_345 *lang.Var

var A_arbace_j2g_dyn_A_const_346 *lang.Var

var A_arbace_j2g_dyn_A_const_347 any

var A_arbace_j2g_dyn_A_const_348 any

var A_arbace_j2g_dyn_A_const_349 *lang.Var

var A_arbace_j2g_dyn_A_const_350 any

var A_arbace_j2g_dyn_A_const_351 any

var A_arbace_j2g_dyn_A_const_352 any

var A_arbace_j2g_dyn_A_const_353 *lang.Var

var A_arbace_j2g_dyn_A_const_354 any

var A_arbace_j2g_dyn_A_const_355 any

var A_arbace_j2g_dyn_A_const_356 any

var A_arbace_j2g_dyn_A_const_357 any

var A_arbace_j2g_dyn_A_const_358 any

var A_arbace_j2g_dyn_A_const_359 any

var A_arbace_j2g_dyn_A_const_360 any

var A_arbace_j2g_dyn_A_const_361 any

var A_arbace_j2g_dyn_A_const_362 any

var A_arbace_j2g_dyn_A_const_363 any

var A_arbace_j2g_dyn_A_const_364 any

var A_arbace_j2g_dyn_A_const_365 any

var A_arbace_j2g_dyn_A_const_366 any

var A_arbace_j2g_dyn_A_const_367 any

var A_arbace_j2g_dyn_A_const_368 any

var A_arbace_j2g_dyn_A_const_369 any

var A_arbace_j2g_dyn_A_const_370 any

var A_arbace_j2g_dyn_A_const_371 any

var A_arbace_j2g_dyn_A_const_372 any

var A_arbace_j2g_dyn_A_const_373 any

var A_arbace_j2g_dyn_A_const_374 *lang.Keyword

var A_arbace_j2g_dyn_A_const_375 *lang.Keyword

var A_arbace_j2g_dyn_A_const_376 any

var A_arbace_j2g_dyn_A_const_377 *lang.Keyword

var A_arbace_j2g_dyn_A_const_378 any

var A_arbace_j2g_dyn_A_const_379 *lang.Keyword

var A_arbace_j2g_dyn_A_const_380 any

var A_arbace_j2g_dyn_A_const_381 any

var A_arbace_j2g_dyn_A_const_382 any

var A_arbace_j2g_dyn_A_const_383 any

var A_arbace_j2g_dyn_A_const_384 any

var A_arbace_j2g_dyn_A_const_385 any

var A_arbace_j2g_dyn_A_const_386 any

var A_arbace_j2g_dyn_A_const_387 any

var A_arbace_j2g_dyn_A_const_388 any

var A_arbace_j2g_dyn_A_const_389 any

var A_arbace_j2g_dyn_A_const_390 any

var A_arbace_j2g_dyn_A_const_391 any

var A_arbace_j2g_dyn_A_const_392 any

var A_arbace_j2g_dyn_A_const_393 any

var A_arbace_j2g_dyn_A_const_394 any

var A_arbace_j2g_dyn_A_const_395 any

var A_arbace_j2g_dyn_A_const_396 any

var A_arbace_j2g_dyn_A_const_397 any

var A_arbace_j2g_dyn_A_const_398 any

var A_arbace_j2g_dyn_A_const_399 any

var A_arbace_j2g_dyn_A_const_400 any

var A_arbace_j2g_dyn_A_const_401 any

var A_arbace_j2g_dyn_A_const_402 any

var A_arbace_j2g_dyn_A_const_403 any

var A_arbace_j2g_dyn_A_const_404 any

var A_arbace_j2g_dyn_A_const_405 any

var A_arbace_j2g_dyn_A_const_406 any

var A_arbace_j2g_dyn_A_const_407 any

var A_arbace_j2g_dyn_A_const_408 any

var A_arbace_j2g_dyn_A_const_409 any

var A_arbace_j2g_dyn_A_const_410 any

var A_arbace_j2g_dyn_A_const_411 any

var A_arbace_j2g_dyn_A_const_412 any

var A_arbace_j2g_dyn_A_const_413 any

var A_arbace_j2g_dyn_A_const_414 any

var A_arbace_j2g_dyn_A_const_415 any

var A_arbace_j2g_dyn_A_const_416 any

var A_arbace_j2g_dyn_A_const_417 any

var A_arbace_j2g_dyn_A_const_418 any

var A_arbace_j2g_dyn_A_const_419 any

var A_arbace_j2g_dyn_A_const_420 any

var A_arbace_j2g_dyn_A_const_421 any

var A_arbace_j2g_dyn_A_const_422 any

var A_arbace_j2g_dyn_A_const_423 any

var A_arbace_j2g_dyn_A_const_424 any

var A_arbace_j2g_dyn_A_const_425 any

var A_arbace_j2g_dyn_A_const_426 any

var A_arbace_j2g_dyn_A_const_427 any

var A_arbace_j2g_dyn_A_const_428 any

var A_arbace_j2g_dyn_A_const_429 any

var A_arbace_j2g_dyn_A_const_430 any

var A_arbace_j2g_dyn_A_const_431 any

var A_arbace_j2g_dyn_A_const_432 any

var A_arbace_j2g_dyn_A_const_433 any

var A_arbace_j2g_dyn_A_const_434 any

var A_arbace_j2g_dyn_A_const_435 any

var A_arbace_j2g_dyn_A_const_436 any

var A_arbace_j2g_dyn_A_const_437 any

var A_arbace_j2g_dyn_A_const_438 any

var A_arbace_j2g_dyn_A_const_439 any

var A_arbace_j2g_dyn_A_const_440 any

var A_arbace_j2g_dyn_A_const_441 any

var A_arbace_j2g_dyn_A_const_442 any

var A_arbace_j2g_dyn_A_const_443 any

var A_arbace_j2g_dyn_A_const_444 any

var A_arbace_j2g_dyn_A_const_445 any

var A_arbace_j2g_dyn_A_const_446 any

var A_arbace_j2g_dyn_A_const_447 any

var A_arbace_j2g_dyn_A_const_448 any

var A_arbace_j2g_dyn_A_const_449 any

var A_arbace_j2g_dyn_A_const_450 any

var A_arbace_j2g_dyn_A_const_451 any

var A_arbace_j2g_dyn_A_const_452 any

var A_arbace_j2g_dyn_A_const_453 any

var A_arbace_j2g_dyn_A_const_454 any

var A_arbace_j2g_dyn_A_const_455 any

var A_arbace_j2g_dyn_A_const_456 any

var A_arbace_j2g_dyn_A_const_457 any

var A_arbace_j2g_dyn_A_const_458 any

var A_arbace_j2g_dyn_A_const_459 any

var A_arbace_j2g_dyn_A_const_460 any

var A_arbace_j2g_dyn_A_const_461 any

var A_arbace_j2g_dyn_A_const_462 any

var A_arbace_j2g_dyn_A_const_463 any

var A_arbace_j2g_dyn_A_const_464 any

var A_arbace_j2g_dyn_A_const_465 any

var A_arbace_j2g_dyn_A_const_466 any

var A_arbace_j2g_dyn_A_const_467 any

var A_arbace_j2g_dyn_A_const_468 any

var A_arbace_j2g_dyn_A_const_469 any

var A_arbace_j2g_dyn_A_const_470 any

var A_arbace_j2g_dyn_A_const_471 any

var A_arbace_j2g_dyn_A_const_472 any

var A_arbace_j2g_dyn_A_const_473 any

var A_arbace_j2g_dyn_A_const_474 any

var A_arbace_j2g_dyn_A_const_475 any

var A_arbace_j2g_dyn_A_const_476 any

var A_arbace_j2g_dyn_A_const_477 any

var A_arbace_j2g_dyn_A_const_478 *lang.Keyword

var A_arbace_j2g_dyn_A_const_479 any

var A_arbace_j2g_dyn_A_const_480 any

var A_arbace_j2g_dyn_A_const_481 any

var A_arbace_j2g_dyn_A_const_482 any

var A_arbace_j2g_dyn_A_const_483 any

var A_arbace_j2g_dyn_A_const_484 *lang.Var

var A_arbace_j2g_dyn_A_const_485 any

var A_arbace_j2g_dyn_A_const_486 any

var A_arbace_j2g_dyn_A_const_487 any

var A_arbace_j2g_dyn_A_const_488 any

var A_arbace_j2g_dyn_A_const_489 any

var A_arbace_j2g_dyn_A_const_490 any

var A_arbace_j2g_dyn_A_const_491 any

var A_arbace_j2g_dyn_A_const_492 any

var A_arbace_j2g_dyn_A_const_493 any

var A_arbace_j2g_dyn_A_const_494 any

var A_arbace_j2g_dyn_A_const_495 any

var A_arbace_j2g_dyn_A_const_496 any

var A_arbace_j2g_dyn_A_const_497 any

var A_arbace_j2g_dyn_A_const_498 any

var A_arbace_j2g_dyn_A_const_499 any

var A_arbace_j2g_dyn_A_const_500 any

var A_arbace_j2g_dyn_A_const_501 any

var A_arbace_j2g_dyn_A_const_502 any

var A_arbace_j2g_dyn_A_const_503 any

var A_arbace_j2g_dyn_A_const_504 any

var A_arbace_j2g_dyn_A_const_505 any

var A_arbace_j2g_dyn_A_const_506 any

var A_arbace_j2g_dyn_A_const_507 any

var A_arbace_j2g_dyn_A_const_508 any

var A_arbace_j2g_dyn_A_const_509 any

var A_arbace_j2g_dyn_A_const_510 any

var A_arbace_j2g_dyn_A_const_511 any

var A_arbace_j2g_dyn_A_const_512 *lang.Var

var A_arbace_j2g_dyn_A_const_513 *lang.Var

var A_arbace_j2g_dyn_A_init jrt.ClassInit

func A_arbace_j2g_dyn_A_Init() { if !A_arbace_j2g_dyn_A_init.Done() { A_arbace_j2g_dyn_A_init.Run(A_arbace_j2g_dyn_A_clinit) } }

func A_arbace_j2g_dyn_A_clinit() { A_arbace_j2g_dyn_A_clinit_p0(); A_arbace_j2g_dyn_A_clinit_p1(); A_arbace_j2g_dyn_A_clinit_p2(); A_arbace_j2g_dyn_A_clinit_p3(); A_arbace_j2g_dyn_A_clinit_p4(); A_arbace_j2g_dyn_A_clinit_p5(); A_arbace_j2g_dyn_A_clinit_p6(); A_arbace_j2g_dyn_A_clinit_p7(); A_arbace_j2g_dyn_A_clinit_p8(); A_arbace_j2g_dyn_A_clinit_p9(); A_arbace_j2g_dyn_A_clinit_p10(); A_arbace_j2g_dyn_A_clinit_p11(); A_arbace_j2g_dyn_A_clinit_p12(); A_arbace_j2g_dyn_A_clinit_p13(); A_arbace_j2g_dyn_A_clinit_p14(); A_arbace_j2g_dyn_A_clinit_p15(); A_arbace_j2g_dyn_A_clinit_p16(); A_arbace_j2g_dyn_A_clinit_p17(); A_arbace_j2g_dyn_A_clinit_p18(); A_arbace_j2g_dyn_A_clinit_p19(); A_arbace_j2g_dyn_A_clinit_p20(); A_arbace_j2g_dyn_A_clinit_p21(); A_arbace_j2g_dyn_A_clinit_p22(); A_arbace_j2g_dyn_A_clinit_p23(); A_arbace_j2g_dyn_A_clinit_p24(); A_arbace_j2g_dyn_A_clinit_p25(); A_arbace_j2g_dyn_A_clinit_p26(); A_arbace_j2g_dyn_A_clinit_p27(); A_arbace_j2g_dyn_A_clinit_p28(); A_arbace_j2g_dyn_A_clinit_p29(); A_arbace_j2g_dyn_A_clinit_p30(); A_arbace_j2g_dyn_A_clinit_p31(); A_arbace_j2g_dyn_A_clinit_p32(); A_arbace_j2g_dyn_A_clinit_p33(); A_arbace_j2g_dyn_A_clinit_p34(); A_arbace_j2g_dyn_A_clinit_p35() }

func A_arbace_j2g_dyn_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 778); A_arbace_j2g_dyn_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[264]); A_arbace_j2g_dyn_A_const_1 = A_arbace_j2g_dyn_A_const_pool.A[265]; A_arbace_j2g_dyn_A_const_2 = A_arbace_j2g_dyn_A_const_pool.A[266]; A_arbace_j2g_dyn_A_const_3 = A_arbace_j2g_dyn_A_const_pool.A[267]; A_arbace_j2g_dyn_A_const_4 = A_arbace_j2g_dyn_A_const_pool.A[268]; A_arbace_j2g_dyn_A_const_5 = A_arbace_j2g_dyn_A_const_pool.A[269]; A_arbace_j2g_dyn_A_const_6 = A_arbace_j2g_dyn_A_const_pool.A[270]; A_arbace_j2g_dyn_A_const_7 = A_arbace_j2g_dyn_A_const_pool.A[271]; A_arbace_j2g_dyn_A_const_8 = A_arbace_j2g_dyn_A_const_pool.A[272]; A_arbace_j2g_dyn_A_const_9 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[273]); A_arbace_j2g_dyn_A_const_10 = A_arbace_j2g_dyn_A_const_pool.A[274]; A_arbace_j2g_dyn_A_const_11 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[275]); A_arbace_j2g_dyn_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[276]) }

func A_arbace_j2g_dyn_A_clinit_p1() { A_arbace_j2g_dyn_A_const_13 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[277]); A_arbace_j2g_dyn_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[278]); A_arbace_j2g_dyn_A_const_15 = A_arbace_j2g_dyn_A_const_pool.A[279]; A_arbace_j2g_dyn_A_const_16 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[280]); A_arbace_j2g_dyn_A_const_17 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[281]); A_arbace_j2g_dyn_A_const_18 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[282]); A_arbace_j2g_dyn_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[283]); A_arbace_j2g_dyn_A_const_20 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[284]); A_arbace_j2g_dyn_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[285]); A_arbace_j2g_dyn_A_const_22 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[286]); A_arbace_j2g_dyn_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[287]); A_arbace_j2g_dyn_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[288]) }

func A_arbace_j2g_dyn_A_clinit_p2() { A_arbace_j2g_dyn_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[289]); A_arbace_j2g_dyn_A_const_26 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[290]); A_arbace_j2g_dyn_A_const_27 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[291]); A_arbace_j2g_dyn_A_const_28 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[292]); A_arbace_j2g_dyn_A_const_29 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[293]); A_arbace_j2g_dyn_A_const_30 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[294]); A_arbace_j2g_dyn_A_const_31 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[295]); A_arbace_j2g_dyn_A_const_32 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[296]); A_arbace_j2g_dyn_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[297]); A_arbace_j2g_dyn_A_const_34 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[298]); A_arbace_j2g_dyn_A_const_35 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[299]); A_arbace_j2g_dyn_A_const_36 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[300]) }

func A_arbace_j2g_dyn_A_clinit_p3() { A_arbace_j2g_dyn_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[301]); A_arbace_j2g_dyn_A_const_38 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[302]); A_arbace_j2g_dyn_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[303]); A_arbace_j2g_dyn_A_const_40 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[304]); A_arbace_j2g_dyn_A_const_41 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[305]); A_arbace_j2g_dyn_A_const_42 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[306]); A_arbace_j2g_dyn_A_const_43 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[307]); A_arbace_j2g_dyn_A_const_44 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[308]); A_arbace_j2g_dyn_A_const_45 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[309]); A_arbace_j2g_dyn_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[310]); A_arbace_j2g_dyn_A_const_47 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[311]); A_arbace_j2g_dyn_A_const_48 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[312]) }

func A_arbace_j2g_dyn_A_clinit_p4() { A_arbace_j2g_dyn_A_const_49 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[313]); A_arbace_j2g_dyn_A_const_50 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[314]); A_arbace_j2g_dyn_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[315]); A_arbace_j2g_dyn_A_const_52 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[316]); A_arbace_j2g_dyn_A_const_53 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[317]); A_arbace_j2g_dyn_A_const_54 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[318]); A_arbace_j2g_dyn_A_const_55 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[319]); A_arbace_j2g_dyn_A_const_56 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[320]); A_arbace_j2g_dyn_A_const_57 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[321]); A_arbace_j2g_dyn_A_const_58 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[322]); A_arbace_j2g_dyn_A_const_59 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[323]); A_arbace_j2g_dyn_A_const_60 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[324]) }

func A_arbace_j2g_dyn_A_clinit_p5() { A_arbace_j2g_dyn_A_const_61 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[325]); A_arbace_j2g_dyn_A_const_62 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[326]); A_arbace_j2g_dyn_A_const_63 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[327]); A_arbace_j2g_dyn_A_const_64 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[328]); A_arbace_j2g_dyn_A_const_65 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[329]); A_arbace_j2g_dyn_A_const_66 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[330]); A_arbace_j2g_dyn_A_const_67 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[331]); A_arbace_j2g_dyn_A_const_68 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[332]); A_arbace_j2g_dyn_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[333]); A_arbace_j2g_dyn_A_const_70 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[334]); A_arbace_j2g_dyn_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[335]); A_arbace_j2g_dyn_A_const_72 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[336]) }

func A_arbace_j2g_dyn_A_clinit_p6() { A_arbace_j2g_dyn_A_const_73 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[337]); A_arbace_j2g_dyn_A_const_74 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[338]); A_arbace_j2g_dyn_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[339]); A_arbace_j2g_dyn_A_const_76 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[340]); A_arbace_j2g_dyn_A_const_77 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[341]); A_arbace_j2g_dyn_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[342]); A_arbace_j2g_dyn_A_const_79 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[343]); A_arbace_j2g_dyn_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[344]); A_arbace_j2g_dyn_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[345]); A_arbace_j2g_dyn_A_const_82 = A_arbace_j2g_dyn_A_const_pool.A[346]; A_arbace_j2g_dyn_A_const_83 = A_arbace_j2g_dyn_A_const_pool.A[347]; A_arbace_j2g_dyn_A_const_84 = A_arbace_j2g_dyn_A_const_pool.A[348] }

func A_arbace_j2g_dyn_A_clinit_p7() { A_arbace_j2g_dyn_A_const_85 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[349]); A_arbace_j2g_dyn_A_const_86 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[350]); A_arbace_j2g_dyn_A_const_87 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[351]); A_arbace_j2g_dyn_A_const_88 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[352]); A_arbace_j2g_dyn_A_const_89 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[353]); A_arbace_j2g_dyn_A_const_90 = A_arbace_j2g_dyn_A_const_pool.A[354]; A_arbace_j2g_dyn_A_const_91 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[355]); A_arbace_j2g_dyn_A_const_92 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[356]); A_arbace_j2g_dyn_A_const_93 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[357]); A_arbace_j2g_dyn_A_const_94 = A_arbace_j2g_dyn_A_const_pool.A[358]; A_arbace_j2g_dyn_A_const_95 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[359]); A_arbace_j2g_dyn_A_const_96 = A_arbace_j2g_dyn_A_const_pool.A[360]; A_arbace_j2g_dyn_A_const_97 = A_arbace_j2g_dyn_A_const_pool.A[361] }

func A_arbace_j2g_dyn_A_clinit_p8() { A_arbace_j2g_dyn_A_const_98 = A_arbace_j2g_dyn_A_const_pool.A[362]; A_arbace_j2g_dyn_A_const_99 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[363]); A_arbace_j2g_dyn_A_const_100 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[364]); A_arbace_j2g_dyn_A_const_101 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[365]); A_arbace_j2g_dyn_A_const_102 = A_arbace_j2g_dyn_A_const_pool.A[366]; A_arbace_j2g_dyn_A_const_103 = A_arbace_j2g_dyn_A_const_pool.A[367]; A_arbace_j2g_dyn_A_const_104 = A_arbace_j2g_dyn_A_const_pool.A[368]; A_arbace_j2g_dyn_A_const_105 = A_arbace_j2g_dyn_A_const_pool.A[369]; A_arbace_j2g_dyn_A_const_106 = A_arbace_j2g_dyn_A_const_pool.A[370]; A_arbace_j2g_dyn_A_const_107 = A_arbace_j2g_dyn_A_const_pool.A[371]; A_arbace_j2g_dyn_A_const_108 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[372]); A_arbace_j2g_dyn_A_const_109 = A_arbace_j2g_dyn_A_const_pool.A[373]; A_arbace_j2g_dyn_A_const_110 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[374]); A_arbace_j2g_dyn_A_const_111 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[375]) }

func A_arbace_j2g_dyn_A_clinit_p9() { A_arbace_j2g_dyn_A_const_112 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[376]); A_arbace_j2g_dyn_A_const_113 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[377]); A_arbace_j2g_dyn_A_const_114 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[378]); A_arbace_j2g_dyn_A_const_115 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[379]); A_arbace_j2g_dyn_A_const_116 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[380]); A_arbace_j2g_dyn_A_const_117 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[381]); A_arbace_j2g_dyn_A_const_118 = A_arbace_j2g_dyn_A_const_pool.A[382]; A_arbace_j2g_dyn_A_const_119 = A_arbace_j2g_dyn_A_const_pool.A[383]; A_arbace_j2g_dyn_A_const_120 = A_arbace_j2g_dyn_A_const_pool.A[384]; A_arbace_j2g_dyn_A_const_121 = A_arbace_j2g_dyn_A_const_pool.A[385]; A_arbace_j2g_dyn_A_const_122 = A_arbace_j2g_dyn_A_const_pool.A[386]; A_arbace_j2g_dyn_A_const_123 = A_arbace_j2g_dyn_A_const_pool.A[387]; A_arbace_j2g_dyn_A_const_124 = A_arbace_j2g_dyn_A_const_pool.A[388]; A_arbace_j2g_dyn_A_const_125 = A_arbace_j2g_dyn_A_const_pool.A[389] }

func A_arbace_j2g_dyn_A_clinit_p10() { A_arbace_j2g_dyn_A_const_126 = A_arbace_j2g_dyn_A_const_pool.A[390]; A_arbace_j2g_dyn_A_const_127 = A_arbace_j2g_dyn_A_const_pool.A[391]; A_arbace_j2g_dyn_A_const_128 = A_arbace_j2g_dyn_A_const_pool.A[392]; A_arbace_j2g_dyn_A_const_129 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[393]); A_arbace_j2g_dyn_A_const_130 = A_arbace_j2g_dyn_A_const_pool.A[394]; A_arbace_j2g_dyn_A_const_131 = A_arbace_j2g_dyn_A_const_pool.A[395]; A_arbace_j2g_dyn_A_const_132 = A_arbace_j2g_dyn_A_const_pool.A[396]; A_arbace_j2g_dyn_A_const_133 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[397]); A_arbace_j2g_dyn_A_const_134 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[398]); A_arbace_j2g_dyn_A_const_135 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[399]); A_arbace_j2g_dyn_A_const_136 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[400]); A_arbace_j2g_dyn_A_const_137 = A_arbace_j2g_dyn_A_const_pool.A[401]; A_arbace_j2g_dyn_A_const_138 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[402]); A_arbace_j2g_dyn_A_const_139 = A_arbace_j2g_dyn_A_const_pool.A[403] }

func A_arbace_j2g_dyn_A_clinit_p11() { A_arbace_j2g_dyn_A_const_140 = A_arbace_j2g_dyn_A_const_pool.A[404]; A_arbace_j2g_dyn_A_const_141 = A_arbace_j2g_dyn_A_const_pool.A[405]; A_arbace_j2g_dyn_A_const_142 = A_arbace_j2g_dyn_A_const_pool.A[406]; A_arbace_j2g_dyn_A_const_143 = A_arbace_j2g_dyn_A_const_pool.A[407]; A_arbace_j2g_dyn_A_const_144 = A_arbace_j2g_dyn_A_const_pool.A[408]; A_arbace_j2g_dyn_A_const_145 = A_arbace_j2g_dyn_A_const_pool.A[409]; A_arbace_j2g_dyn_A_const_146 = A_arbace_j2g_dyn_A_const_pool.A[410]; A_arbace_j2g_dyn_A_const_147 = A_arbace_j2g_dyn_A_const_pool.A[411]; A_arbace_j2g_dyn_A_const_148 = A_arbace_j2g_dyn_A_const_pool.A[412]; A_arbace_j2g_dyn_A_const_149 = A_arbace_j2g_dyn_A_const_pool.A[413]; A_arbace_j2g_dyn_A_const_150 = A_arbace_j2g_dyn_A_const_pool.A[414]; A_arbace_j2g_dyn_A_const_151 = A_arbace_j2g_dyn_A_const_pool.A[415]; A_arbace_j2g_dyn_A_const_152 = A_arbace_j2g_dyn_A_const_pool.A[416]; A_arbace_j2g_dyn_A_const_153 = A_arbace_j2g_dyn_A_const_pool.A[417]; A_arbace_j2g_dyn_A_const_154 = A_arbace_j2g_dyn_A_const_pool.A[418]; A_arbace_j2g_dyn_A_const_155 = A_arbace_j2g_dyn_A_const_pool.A[419] }

func A_arbace_j2g_dyn_A_clinit_p12() { A_arbace_j2g_dyn_A_const_156 = A_arbace_j2g_dyn_A_const_pool.A[420]; A_arbace_j2g_dyn_A_const_157 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[421]); A_arbace_j2g_dyn_A_const_158 = A_arbace_j2g_dyn_A_const_pool.A[422]; A_arbace_j2g_dyn_A_const_159 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[423]); A_arbace_j2g_dyn_A_const_160 = A_arbace_j2g_dyn_A_const_pool.A[424]; A_arbace_j2g_dyn_A_const_161 = A_arbace_j2g_dyn_A_const_pool.A[425]; A_arbace_j2g_dyn_A_const_162 = A_arbace_j2g_dyn_A_const_pool.A[426]; A_arbace_j2g_dyn_A_const_163 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[427]); A_arbace_j2g_dyn_A_const_164 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[428]); A_arbace_j2g_dyn_A_const_165 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[429]); A_arbace_j2g_dyn_A_const_166 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[430]); A_arbace_j2g_dyn_A_const_167 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[431]); A_arbace_j2g_dyn_A_const_168 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[432]) }

func A_arbace_j2g_dyn_A_clinit_p13() { A_arbace_j2g_dyn_A_const_169 = A_arbace_j2g_dyn_A_const_pool.A[433]; A_arbace_j2g_dyn_A_const_170 = A_arbace_j2g_dyn_A_const_pool.A[434]; A_arbace_j2g_dyn_A_const_171 = A_arbace_j2g_dyn_A_const_pool.A[435]; A_arbace_j2g_dyn_A_const_172 = A_arbace_j2g_dyn_A_const_pool.A[436]; A_arbace_j2g_dyn_A_const_173 = A_arbace_j2g_dyn_A_const_pool.A[437]; A_arbace_j2g_dyn_A_const_174 = A_arbace_j2g_dyn_A_const_pool.A[438]; A_arbace_j2g_dyn_A_const_175 = A_arbace_j2g_dyn_A_const_pool.A[439]; A_arbace_j2g_dyn_A_const_176 = A_arbace_j2g_dyn_A_const_pool.A[440]; A_arbace_j2g_dyn_A_const_177 = A_arbace_j2g_dyn_A_const_pool.A[441]; A_arbace_j2g_dyn_A_const_178 = A_arbace_j2g_dyn_A_const_pool.A[442]; A_arbace_j2g_dyn_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[443]); A_arbace_j2g_dyn_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[444]); A_arbace_j2g_dyn_A_const_181 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[445]); A_arbace_j2g_dyn_A_const_182 = A_arbace_j2g_dyn_A_const_pool.A[446]; A_arbace_j2g_dyn_A_const_183 = A_arbace_j2g_dyn_A_const_pool.A[447] }

func A_arbace_j2g_dyn_A_clinit_p14() { A_arbace_j2g_dyn_A_const_184 = A_arbace_j2g_dyn_A_const_pool.A[448]; A_arbace_j2g_dyn_A_const_185 = A_arbace_j2g_dyn_A_const_pool.A[449]; A_arbace_j2g_dyn_A_const_186 = A_arbace_j2g_dyn_A_const_pool.A[450]; A_arbace_j2g_dyn_A_const_187 = A_arbace_j2g_dyn_A_const_pool.A[451]; A_arbace_j2g_dyn_A_const_188 = A_arbace_j2g_dyn_A_const_pool.A[452]; A_arbace_j2g_dyn_A_const_189 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[453]); A_arbace_j2g_dyn_A_const_190 = A_arbace_j2g_dyn_A_const_pool.A[454]; A_arbace_j2g_dyn_A_const_191 = A_arbace_j2g_dyn_A_const_pool.A[455]; A_arbace_j2g_dyn_A_const_192 = A_arbace_j2g_dyn_A_const_pool.A[456]; A_arbace_j2g_dyn_A_const_193 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[457]); A_arbace_j2g_dyn_A_const_194 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[458]); A_arbace_j2g_dyn_A_const_195 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[459]); A_arbace_j2g_dyn_A_const_196 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[460]); A_arbace_j2g_dyn_A_const_197 = A_arbace_j2g_dyn_A_const_pool.A[461] }

func A_arbace_j2g_dyn_A_clinit_p15() { A_arbace_j2g_dyn_A_const_198 = A_arbace_j2g_dyn_A_const_pool.A[462]; A_arbace_j2g_dyn_A_const_199 = A_arbace_j2g_dyn_A_const_pool.A[463]; A_arbace_j2g_dyn_A_const_200 = A_arbace_j2g_dyn_A_const_pool.A[464]; A_arbace_j2g_dyn_A_const_201 = A_arbace_j2g_dyn_A_const_pool.A[465]; A_arbace_j2g_dyn_A_const_202 = A_arbace_j2g_dyn_A_const_pool.A[466]; A_arbace_j2g_dyn_A_const_203 = A_arbace_j2g_dyn_A_const_pool.A[467]; A_arbace_j2g_dyn_A_const_204 = A_arbace_j2g_dyn_A_const_pool.A[468]; A_arbace_j2g_dyn_A_const_205 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[469]); A_arbace_j2g_dyn_A_const_206 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[470]); A_arbace_j2g_dyn_A_const_207 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[471]); A_arbace_j2g_dyn_A_const_208 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[472]); A_arbace_j2g_dyn_A_const_209 = A_arbace_j2g_dyn_A_const_pool.A[473]; A_arbace_j2g_dyn_A_const_210 = A_arbace_j2g_dyn_A_const_pool.A[474]; A_arbace_j2g_dyn_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[475]) }

func A_arbace_j2g_dyn_A_clinit_p16() { A_arbace_j2g_dyn_A_const_212 = A_arbace_j2g_dyn_A_const_pool.A[476]; A_arbace_j2g_dyn_A_const_213 = A_arbace_j2g_dyn_A_const_pool.A[477]; A_arbace_j2g_dyn_A_const_214 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[478]); A_arbace_j2g_dyn_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[479]); A_arbace_j2g_dyn_A_const_216 = A_arbace_j2g_dyn_A_const_pool.A[480]; A_arbace_j2g_dyn_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[481]); A_arbace_j2g_dyn_A_const_218 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[482]); A_arbace_j2g_dyn_A_const_219 = A_arbace_j2g_dyn_A_const_pool.A[483]; A_arbace_j2g_dyn_A_const_220 = A_arbace_j2g_dyn_A_const_pool.A[484]; A_arbace_j2g_dyn_A_const_221 = A_arbace_j2g_dyn_A_const_pool.A[485]; A_arbace_j2g_dyn_A_const_222 = A_arbace_j2g_dyn_A_const_pool.A[486]; A_arbace_j2g_dyn_A_const_223 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[487]); A_arbace_j2g_dyn_A_const_224 = A_arbace_j2g_dyn_A_const_pool.A[488]; A_arbace_j2g_dyn_A_const_225 = A_arbace_j2g_dyn_A_const_pool.A[489] }

func A_arbace_j2g_dyn_A_clinit_p17() { A_arbace_j2g_dyn_A_const_226 = A_arbace_j2g_dyn_A_const_pool.A[490]; A_arbace_j2g_dyn_A_const_227 = A_arbace_j2g_dyn_A_const_pool.A[491]; A_arbace_j2g_dyn_A_const_228 = A_arbace_j2g_dyn_A_const_pool.A[492]; A_arbace_j2g_dyn_A_const_229 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[493]); A_arbace_j2g_dyn_A_const_230 = A_arbace_j2g_dyn_A_const_pool.A[494]; A_arbace_j2g_dyn_A_const_231 = A_arbace_j2g_dyn_A_const_pool.A[495]; A_arbace_j2g_dyn_A_const_232 = A_arbace_j2g_dyn_A_const_pool.A[496]; A_arbace_j2g_dyn_A_const_233 = A_arbace_j2g_dyn_A_const_pool.A[497]; A_arbace_j2g_dyn_A_const_234 = A_arbace_j2g_dyn_A_const_pool.A[498]; A_arbace_j2g_dyn_A_const_235 = A_arbace_j2g_dyn_A_const_pool.A[499]; A_arbace_j2g_dyn_A_const_236 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[500]); A_arbace_j2g_dyn_A_const_237 = A_arbace_j2g_dyn_A_const_pool.A[501]; A_arbace_j2g_dyn_A_const_238 = A_arbace_j2g_dyn_A_const_pool.A[502]; A_arbace_j2g_dyn_A_const_239 = A_arbace_j2g_dyn_A_const_pool.A[503]; A_arbace_j2g_dyn_A_const_240 = A_arbace_j2g_dyn_A_const_pool.A[504] }

func A_arbace_j2g_dyn_A_clinit_p18() { A_arbace_j2g_dyn_A_const_241 = A_arbace_j2g_dyn_A_const_pool.A[505]; A_arbace_j2g_dyn_A_const_242 = A_arbace_j2g_dyn_A_const_pool.A[506]; A_arbace_j2g_dyn_A_const_243 = A_arbace_j2g_dyn_A_const_pool.A[507]; A_arbace_j2g_dyn_A_const_244 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[508]); A_arbace_j2g_dyn_A_const_245 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[509]); A_arbace_j2g_dyn_A_const_246 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[510]); A_arbace_j2g_dyn_A_const_247 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[511]); A_arbace_j2g_dyn_A_const_248 = A_arbace_j2g_dyn_A_const_pool.A[512]; A_arbace_j2g_dyn_A_const_249 = A_arbace_j2g_dyn_A_const_pool.A[513]; A_arbace_j2g_dyn_A_const_250 = A_arbace_j2g_dyn_A_const_pool.A[514]; A_arbace_j2g_dyn_A_const_251 = A_arbace_j2g_dyn_A_const_pool.A[515]; A_arbace_j2g_dyn_A_const_252 = A_arbace_j2g_dyn_A_const_pool.A[516]; A_arbace_j2g_dyn_A_const_253 = A_arbace_j2g_dyn_A_const_pool.A[517]; A_arbace_j2g_dyn_A_const_254 = A_arbace_j2g_dyn_A_const_pool.A[518] }

func A_arbace_j2g_dyn_A_clinit_p19() { A_arbace_j2g_dyn_A_const_255 = A_arbace_j2g_dyn_A_const_pool.A[519]; A_arbace_j2g_dyn_A_const_256 = A_arbace_j2g_dyn_A_const_pool.A[520]; A_arbace_j2g_dyn_A_const_257 = A_arbace_j2g_dyn_A_const_pool.A[521]; A_arbace_j2g_dyn_A_const_258 = A_arbace_j2g_dyn_A_const_pool.A[522]; A_arbace_j2g_dyn_A_const_259 = A_arbace_j2g_dyn_A_const_pool.A[523]; A_arbace_j2g_dyn_A_const_260 = A_arbace_j2g_dyn_A_const_pool.A[524]; A_arbace_j2g_dyn_A_const_261 = A_arbace_j2g_dyn_A_const_pool.A[525]; A_arbace_j2g_dyn_A_const_262 = A_arbace_j2g_dyn_A_const_pool.A[526]; A_arbace_j2g_dyn_A_const_263 = A_arbace_j2g_dyn_A_const_pool.A[527]; A_arbace_j2g_dyn_A_const_264 = A_arbace_j2g_dyn_A_const_pool.A[528]; A_arbace_j2g_dyn_A_const_265 = A_arbace_j2g_dyn_A_const_pool.A[529]; A_arbace_j2g_dyn_A_const_266 = A_arbace_j2g_dyn_A_const_pool.A[530]; A_arbace_j2g_dyn_A_const_267 = A_arbace_j2g_dyn_A_const_pool.A[531]; A_arbace_j2g_dyn_A_const_268 = A_arbace_j2g_dyn_A_const_pool.A[532]; A_arbace_j2g_dyn_A_const_269 = A_arbace_j2g_dyn_A_const_pool.A[533]; A_arbace_j2g_dyn_A_const_270 = A_arbace_j2g_dyn_A_const_pool.A[534] }

func A_arbace_j2g_dyn_A_clinit_p20() { A_arbace_j2g_dyn_A_const_271 = A_arbace_j2g_dyn_A_const_pool.A[535]; A_arbace_j2g_dyn_A_const_272 = A_arbace_j2g_dyn_A_const_pool.A[536]; A_arbace_j2g_dyn_A_const_273 = A_arbace_j2g_dyn_A_const_pool.A[537]; A_arbace_j2g_dyn_A_const_274 = A_arbace_j2g_dyn_A_const_pool.A[538]; A_arbace_j2g_dyn_A_const_275 = A_arbace_j2g_dyn_A_const_pool.A[539]; A_arbace_j2g_dyn_A_const_276 = A_arbace_j2g_dyn_A_const_pool.A[540]; A_arbace_j2g_dyn_A_const_277 = A_arbace_j2g_dyn_A_const_pool.A[541]; A_arbace_j2g_dyn_A_const_278 = A_arbace_j2g_dyn_A_const_pool.A[542]; A_arbace_j2g_dyn_A_const_279 = A_arbace_j2g_dyn_A_const_pool.A[543]; A_arbace_j2g_dyn_A_const_280 = A_arbace_j2g_dyn_A_const_pool.A[544]; A_arbace_j2g_dyn_A_const_281 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[545]); A_arbace_j2g_dyn_A_const_282 = A_arbace_j2g_dyn_A_const_pool.A[546]; A_arbace_j2g_dyn_A_const_283 = A_arbace_j2g_dyn_A_const_pool.A[547]; A_arbace_j2g_dyn_A_const_284 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[548]); A_arbace_j2g_dyn_A_const_285 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[549]) }

func A_arbace_j2g_dyn_A_clinit_p21() { A_arbace_j2g_dyn_A_const_286 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[550]); A_arbace_j2g_dyn_A_const_287 = A_arbace_j2g_dyn_A_const_pool.A[551]; A_arbace_j2g_dyn_A_const_288 = A_arbace_j2g_dyn_A_const_pool.A[552]; A_arbace_j2g_dyn_A_const_289 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[553]); A_arbace_j2g_dyn_A_const_290 = A_arbace_j2g_dyn_A_const_pool.A[554]; A_arbace_j2g_dyn_A_const_291 = A_arbace_j2g_dyn_A_const_pool.A[555]; A_arbace_j2g_dyn_A_const_292 = A_arbace_j2g_dyn_A_const_pool.A[556]; A_arbace_j2g_dyn_A_const_293 = A_arbace_j2g_dyn_A_const_pool.A[557]; A_arbace_j2g_dyn_A_const_294 = A_arbace_j2g_dyn_A_const_pool.A[558]; A_arbace_j2g_dyn_A_const_295 = A_arbace_j2g_dyn_A_const_pool.A[559]; A_arbace_j2g_dyn_A_const_296 = A_arbace_j2g_dyn_A_const_pool.A[560]; A_arbace_j2g_dyn_A_const_297 = A_arbace_j2g_dyn_A_const_pool.A[561]; A_arbace_j2g_dyn_A_const_298 = A_arbace_j2g_dyn_A_const_pool.A[562]; A_arbace_j2g_dyn_A_const_299 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[563]) }

func A_arbace_j2g_dyn_A_clinit_p22() { A_arbace_j2g_dyn_A_const_300 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[564]); A_arbace_j2g_dyn_A_const_301 = A_arbace_j2g_dyn_A_const_pool.A[565]; A_arbace_j2g_dyn_A_const_302 = A_arbace_j2g_dyn_A_const_pool.A[566]; A_arbace_j2g_dyn_A_const_303 = A_arbace_j2g_dyn_A_const_pool.A[567]; A_arbace_j2g_dyn_A_const_304 = A_arbace_j2g_dyn_A_const_pool.A[568]; A_arbace_j2g_dyn_A_const_305 = A_arbace_j2g_dyn_A_const_pool.A[569]; A_arbace_j2g_dyn_A_const_306 = A_arbace_j2g_dyn_A_const_pool.A[570]; A_arbace_j2g_dyn_A_const_307 = A_arbace_j2g_dyn_A_const_pool.A[571]; A_arbace_j2g_dyn_A_const_308 = A_arbace_j2g_dyn_A_const_pool.A[572]; A_arbace_j2g_dyn_A_const_309 = A_arbace_j2g_dyn_A_const_pool.A[573]; A_arbace_j2g_dyn_A_const_310 = A_arbace_j2g_dyn_A_const_pool.A[574]; A_arbace_j2g_dyn_A_const_311 = A_arbace_j2g_dyn_A_const_pool.A[575]; A_arbace_j2g_dyn_A_const_312 = A_arbace_j2g_dyn_A_const_pool.A[576]; A_arbace_j2g_dyn_A_const_313 = A_arbace_j2g_dyn_A_const_pool.A[577]; A_arbace_j2g_dyn_A_const_314 = A_arbace_j2g_dyn_A_const_pool.A[578] }

func A_arbace_j2g_dyn_A_clinit_p23() { A_arbace_j2g_dyn_A_const_315 = A_arbace_j2g_dyn_A_const_pool.A[579]; A_arbace_j2g_dyn_A_const_316 = A_arbace_j2g_dyn_A_const_pool.A[580]; A_arbace_j2g_dyn_A_const_317 = A_arbace_j2g_dyn_A_const_pool.A[581]; A_arbace_j2g_dyn_A_const_318 = A_arbace_j2g_dyn_A_const_pool.A[582]; A_arbace_j2g_dyn_A_const_319 = A_arbace_j2g_dyn_A_const_pool.A[583]; A_arbace_j2g_dyn_A_const_320 = A_arbace_j2g_dyn_A_const_pool.A[584]; A_arbace_j2g_dyn_A_const_321 = A_arbace_j2g_dyn_A_const_pool.A[585]; A_arbace_j2g_dyn_A_const_322 = A_arbace_j2g_dyn_A_const_pool.A[586]; A_arbace_j2g_dyn_A_const_323 = A_arbace_j2g_dyn_A_const_pool.A[587]; A_arbace_j2g_dyn_A_const_324 = A_arbace_j2g_dyn_A_const_pool.A[588]; A_arbace_j2g_dyn_A_const_325 = A_arbace_j2g_dyn_A_const_pool.A[589]; A_arbace_j2g_dyn_A_const_326 = A_arbace_j2g_dyn_A_const_pool.A[590]; A_arbace_j2g_dyn_A_const_327 = A_arbace_j2g_dyn_A_const_pool.A[591]; A_arbace_j2g_dyn_A_const_328 = A_arbace_j2g_dyn_A_const_pool.A[592]; A_arbace_j2g_dyn_A_const_329 = A_arbace_j2g_dyn_A_const_pool.A[593]; A_arbace_j2g_dyn_A_const_330 = A_arbace_j2g_dyn_A_const_pool.A[594] }

func A_arbace_j2g_dyn_A_clinit_p24() { A_arbace_j2g_dyn_A_const_331 = A_arbace_j2g_dyn_A_const_pool.A[595]; A_arbace_j2g_dyn_A_const_332 = A_arbace_j2g_dyn_A_const_pool.A[596]; A_arbace_j2g_dyn_A_const_333 = A_arbace_j2g_dyn_A_const_pool.A[597]; A_arbace_j2g_dyn_A_const_334 = A_arbace_j2g_dyn_A_const_pool.A[598]; A_arbace_j2g_dyn_A_const_335 = A_arbace_j2g_dyn_A_const_pool.A[599]; A_arbace_j2g_dyn_A_const_336 = A_arbace_j2g_dyn_A_const_pool.A[600]; A_arbace_j2g_dyn_A_const_337 = A_arbace_j2g_dyn_A_const_pool.A[601]; A_arbace_j2g_dyn_A_const_338 = A_arbace_j2g_dyn_A_const_pool.A[602]; A_arbace_j2g_dyn_A_const_339 = A_arbace_j2g_dyn_A_const_pool.A[603]; A_arbace_j2g_dyn_A_const_340 = A_arbace_j2g_dyn_A_const_pool.A[604]; A_arbace_j2g_dyn_A_const_341 = A_arbace_j2g_dyn_A_const_pool.A[605]; A_arbace_j2g_dyn_A_const_342 = A_arbace_j2g_dyn_A_const_pool.A[606]; A_arbace_j2g_dyn_A_const_343 = A_arbace_j2g_dyn_A_const_pool.A[607]; A_arbace_j2g_dyn_A_const_344 = A_arbace_j2g_dyn_A_const_pool.A[608]; A_arbace_j2g_dyn_A_const_345 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[609]) }

func A_arbace_j2g_dyn_A_clinit_p25() { A_arbace_j2g_dyn_A_const_346 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[610]); A_arbace_j2g_dyn_A_const_347 = A_arbace_j2g_dyn_A_const_pool.A[611]; A_arbace_j2g_dyn_A_const_348 = A_arbace_j2g_dyn_A_const_pool.A[612]; A_arbace_j2g_dyn_A_const_349 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[613]); A_arbace_j2g_dyn_A_const_350 = A_arbace_j2g_dyn_A_const_pool.A[614]; A_arbace_j2g_dyn_A_const_351 = A_arbace_j2g_dyn_A_const_pool.A[615]; A_arbace_j2g_dyn_A_const_352 = A_arbace_j2g_dyn_A_const_pool.A[616]; A_arbace_j2g_dyn_A_const_353 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[617]); A_arbace_j2g_dyn_A_const_354 = A_arbace_j2g_dyn_A_const_pool.A[618]; A_arbace_j2g_dyn_A_const_355 = A_arbace_j2g_dyn_A_const_pool.A[619]; A_arbace_j2g_dyn_A_const_356 = A_arbace_j2g_dyn_A_const_pool.A[620]; A_arbace_j2g_dyn_A_const_357 = A_arbace_j2g_dyn_A_const_pool.A[621]; A_arbace_j2g_dyn_A_const_358 = A_arbace_j2g_dyn_A_const_pool.A[622]; A_arbace_j2g_dyn_A_const_359 = A_arbace_j2g_dyn_A_const_pool.A[623]; A_arbace_j2g_dyn_A_const_360 = A_arbace_j2g_dyn_A_const_pool.A[624] }

func A_arbace_j2g_dyn_A_clinit_p26() { A_arbace_j2g_dyn_A_const_361 = A_arbace_j2g_dyn_A_const_pool.A[625]; A_arbace_j2g_dyn_A_const_362 = A_arbace_j2g_dyn_A_const_pool.A[626]; A_arbace_j2g_dyn_A_const_363 = A_arbace_j2g_dyn_A_const_pool.A[627]; A_arbace_j2g_dyn_A_const_364 = A_arbace_j2g_dyn_A_const_pool.A[628]; A_arbace_j2g_dyn_A_const_365 = A_arbace_j2g_dyn_A_const_pool.A[629]; A_arbace_j2g_dyn_A_const_366 = A_arbace_j2g_dyn_A_const_pool.A[630]; A_arbace_j2g_dyn_A_const_367 = A_arbace_j2g_dyn_A_const_pool.A[631]; A_arbace_j2g_dyn_A_const_368 = A_arbace_j2g_dyn_A_const_pool.A[632]; A_arbace_j2g_dyn_A_const_369 = A_arbace_j2g_dyn_A_const_pool.A[633]; A_arbace_j2g_dyn_A_const_370 = A_arbace_j2g_dyn_A_const_pool.A[634]; A_arbace_j2g_dyn_A_const_371 = A_arbace_j2g_dyn_A_const_pool.A[635]; A_arbace_j2g_dyn_A_const_372 = A_arbace_j2g_dyn_A_const_pool.A[636]; A_arbace_j2g_dyn_A_const_373 = A_arbace_j2g_dyn_A_const_pool.A[637]; A_arbace_j2g_dyn_A_const_374 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[638]); A_arbace_j2g_dyn_A_const_375 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[639]) }

func A_arbace_j2g_dyn_A_clinit_p27() { A_arbace_j2g_dyn_A_const_376 = A_arbace_j2g_dyn_A_const_pool.A[640]; A_arbace_j2g_dyn_A_const_377 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[641]); A_arbace_j2g_dyn_A_const_378 = A_arbace_j2g_dyn_A_const_pool.A[642]; A_arbace_j2g_dyn_A_const_379 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[643]); A_arbace_j2g_dyn_A_const_380 = A_arbace_j2g_dyn_A_const_pool.A[644]; A_arbace_j2g_dyn_A_const_381 = A_arbace_j2g_dyn_A_const_pool.A[645]; A_arbace_j2g_dyn_A_const_382 = A_arbace_j2g_dyn_A_const_pool.A[646]; A_arbace_j2g_dyn_A_const_383 = A_arbace_j2g_dyn_A_const_pool.A[647]; A_arbace_j2g_dyn_A_const_384 = A_arbace_j2g_dyn_A_const_pool.A[648]; A_arbace_j2g_dyn_A_const_385 = A_arbace_j2g_dyn_A_const_pool.A[649]; A_arbace_j2g_dyn_A_const_386 = A_arbace_j2g_dyn_A_const_pool.A[650]; A_arbace_j2g_dyn_A_const_387 = A_arbace_j2g_dyn_A_const_pool.A[651]; A_arbace_j2g_dyn_A_const_388 = A_arbace_j2g_dyn_A_const_pool.A[652]; A_arbace_j2g_dyn_A_const_389 = A_arbace_j2g_dyn_A_const_pool.A[653]; A_arbace_j2g_dyn_A_const_390 = A_arbace_j2g_dyn_A_const_pool.A[654] }

func A_arbace_j2g_dyn_A_clinit_p28() { A_arbace_j2g_dyn_A_const_391 = A_arbace_j2g_dyn_A_const_pool.A[655]; A_arbace_j2g_dyn_A_const_392 = A_arbace_j2g_dyn_A_const_pool.A[656]; A_arbace_j2g_dyn_A_const_393 = A_arbace_j2g_dyn_A_const_pool.A[657]; A_arbace_j2g_dyn_A_const_394 = A_arbace_j2g_dyn_A_const_pool.A[658]; A_arbace_j2g_dyn_A_const_395 = A_arbace_j2g_dyn_A_const_pool.A[659]; A_arbace_j2g_dyn_A_const_396 = A_arbace_j2g_dyn_A_const_pool.A[660]; A_arbace_j2g_dyn_A_const_397 = A_arbace_j2g_dyn_A_const_pool.A[661]; A_arbace_j2g_dyn_A_const_398 = A_arbace_j2g_dyn_A_const_pool.A[662]; A_arbace_j2g_dyn_A_const_399 = A_arbace_j2g_dyn_A_const_pool.A[663]; A_arbace_j2g_dyn_A_const_400 = A_arbace_j2g_dyn_A_const_pool.A[664]; A_arbace_j2g_dyn_A_const_401 = A_arbace_j2g_dyn_A_const_pool.A[665]; A_arbace_j2g_dyn_A_const_402 = A_arbace_j2g_dyn_A_const_pool.A[666]; A_arbace_j2g_dyn_A_const_403 = A_arbace_j2g_dyn_A_const_pool.A[667]; A_arbace_j2g_dyn_A_const_404 = A_arbace_j2g_dyn_A_const_pool.A[668]; A_arbace_j2g_dyn_A_const_405 = A_arbace_j2g_dyn_A_const_pool.A[669]; A_arbace_j2g_dyn_A_const_406 = A_arbace_j2g_dyn_A_const_pool.A[670] }

func A_arbace_j2g_dyn_A_clinit_p29() { A_arbace_j2g_dyn_A_const_407 = A_arbace_j2g_dyn_A_const_pool.A[671]; A_arbace_j2g_dyn_A_const_408 = A_arbace_j2g_dyn_A_const_pool.A[672]; A_arbace_j2g_dyn_A_const_409 = A_arbace_j2g_dyn_A_const_pool.A[673]; A_arbace_j2g_dyn_A_const_410 = A_arbace_j2g_dyn_A_const_pool.A[674]; A_arbace_j2g_dyn_A_const_411 = A_arbace_j2g_dyn_A_const_pool.A[675]; A_arbace_j2g_dyn_A_const_412 = A_arbace_j2g_dyn_A_const_pool.A[676]; A_arbace_j2g_dyn_A_const_413 = A_arbace_j2g_dyn_A_const_pool.A[677]; A_arbace_j2g_dyn_A_const_414 = A_arbace_j2g_dyn_A_const_pool.A[678]; A_arbace_j2g_dyn_A_const_415 = A_arbace_j2g_dyn_A_const_pool.A[679]; A_arbace_j2g_dyn_A_const_416 = A_arbace_j2g_dyn_A_const_pool.A[680]; A_arbace_j2g_dyn_A_const_417 = A_arbace_j2g_dyn_A_const_pool.A[681]; A_arbace_j2g_dyn_A_const_418 = A_arbace_j2g_dyn_A_const_pool.A[682]; A_arbace_j2g_dyn_A_const_419 = A_arbace_j2g_dyn_A_const_pool.A[683]; A_arbace_j2g_dyn_A_const_420 = A_arbace_j2g_dyn_A_const_pool.A[684]; A_arbace_j2g_dyn_A_const_421 = A_arbace_j2g_dyn_A_const_pool.A[685]; A_arbace_j2g_dyn_A_const_422 = A_arbace_j2g_dyn_A_const_pool.A[686] }

func A_arbace_j2g_dyn_A_clinit_p30() { A_arbace_j2g_dyn_A_const_423 = A_arbace_j2g_dyn_A_const_pool.A[687]; A_arbace_j2g_dyn_A_const_424 = A_arbace_j2g_dyn_A_const_pool.A[688]; A_arbace_j2g_dyn_A_const_425 = A_arbace_j2g_dyn_A_const_pool.A[689]; A_arbace_j2g_dyn_A_const_426 = A_arbace_j2g_dyn_A_const_pool.A[690]; A_arbace_j2g_dyn_A_const_427 = A_arbace_j2g_dyn_A_const_pool.A[691]; A_arbace_j2g_dyn_A_const_428 = A_arbace_j2g_dyn_A_const_pool.A[692]; A_arbace_j2g_dyn_A_const_429 = A_arbace_j2g_dyn_A_const_pool.A[693]; A_arbace_j2g_dyn_A_const_430 = A_arbace_j2g_dyn_A_const_pool.A[694]; A_arbace_j2g_dyn_A_const_431 = A_arbace_j2g_dyn_A_const_pool.A[695]; A_arbace_j2g_dyn_A_const_432 = A_arbace_j2g_dyn_A_const_pool.A[696]; A_arbace_j2g_dyn_A_const_433 = A_arbace_j2g_dyn_A_const_pool.A[697]; A_arbace_j2g_dyn_A_const_434 = A_arbace_j2g_dyn_A_const_pool.A[698]; A_arbace_j2g_dyn_A_const_435 = A_arbace_j2g_dyn_A_const_pool.A[699]; A_arbace_j2g_dyn_A_const_436 = A_arbace_j2g_dyn_A_const_pool.A[700]; A_arbace_j2g_dyn_A_const_437 = A_arbace_j2g_dyn_A_const_pool.A[701]; A_arbace_j2g_dyn_A_const_438 = A_arbace_j2g_dyn_A_const_pool.A[702] }

func A_arbace_j2g_dyn_A_clinit_p31() { A_arbace_j2g_dyn_A_const_439 = A_arbace_j2g_dyn_A_const_pool.A[703]; A_arbace_j2g_dyn_A_const_440 = A_arbace_j2g_dyn_A_const_pool.A[704]; A_arbace_j2g_dyn_A_const_441 = A_arbace_j2g_dyn_A_const_pool.A[705]; A_arbace_j2g_dyn_A_const_442 = A_arbace_j2g_dyn_A_const_pool.A[706]; A_arbace_j2g_dyn_A_const_443 = A_arbace_j2g_dyn_A_const_pool.A[707]; A_arbace_j2g_dyn_A_const_444 = A_arbace_j2g_dyn_A_const_pool.A[708]; A_arbace_j2g_dyn_A_const_445 = A_arbace_j2g_dyn_A_const_pool.A[709]; A_arbace_j2g_dyn_A_const_446 = A_arbace_j2g_dyn_A_const_pool.A[710]; A_arbace_j2g_dyn_A_const_447 = A_arbace_j2g_dyn_A_const_pool.A[711]; A_arbace_j2g_dyn_A_const_448 = A_arbace_j2g_dyn_A_const_pool.A[712]; A_arbace_j2g_dyn_A_const_449 = A_arbace_j2g_dyn_A_const_pool.A[713]; A_arbace_j2g_dyn_A_const_450 = A_arbace_j2g_dyn_A_const_pool.A[714]; A_arbace_j2g_dyn_A_const_451 = A_arbace_j2g_dyn_A_const_pool.A[715]; A_arbace_j2g_dyn_A_const_452 = A_arbace_j2g_dyn_A_const_pool.A[716]; A_arbace_j2g_dyn_A_const_453 = A_arbace_j2g_dyn_A_const_pool.A[717]; A_arbace_j2g_dyn_A_const_454 = A_arbace_j2g_dyn_A_const_pool.A[718] }

func A_arbace_j2g_dyn_A_clinit_p32() { A_arbace_j2g_dyn_A_const_455 = A_arbace_j2g_dyn_A_const_pool.A[719]; A_arbace_j2g_dyn_A_const_456 = A_arbace_j2g_dyn_A_const_pool.A[720]; A_arbace_j2g_dyn_A_const_457 = A_arbace_j2g_dyn_A_const_pool.A[721]; A_arbace_j2g_dyn_A_const_458 = A_arbace_j2g_dyn_A_const_pool.A[722]; A_arbace_j2g_dyn_A_const_459 = A_arbace_j2g_dyn_A_const_pool.A[723]; A_arbace_j2g_dyn_A_const_460 = A_arbace_j2g_dyn_A_const_pool.A[724]; A_arbace_j2g_dyn_A_const_461 = A_arbace_j2g_dyn_A_const_pool.A[725]; A_arbace_j2g_dyn_A_const_462 = A_arbace_j2g_dyn_A_const_pool.A[726]; A_arbace_j2g_dyn_A_const_463 = A_arbace_j2g_dyn_A_const_pool.A[727]; A_arbace_j2g_dyn_A_const_464 = A_arbace_j2g_dyn_A_const_pool.A[728]; A_arbace_j2g_dyn_A_const_465 = A_arbace_j2g_dyn_A_const_pool.A[729]; A_arbace_j2g_dyn_A_const_466 = A_arbace_j2g_dyn_A_const_pool.A[730]; A_arbace_j2g_dyn_A_const_467 = A_arbace_j2g_dyn_A_const_pool.A[731]; A_arbace_j2g_dyn_A_const_468 = A_arbace_j2g_dyn_A_const_pool.A[732]; A_arbace_j2g_dyn_A_const_469 = A_arbace_j2g_dyn_A_const_pool.A[733]; A_arbace_j2g_dyn_A_const_470 = A_arbace_j2g_dyn_A_const_pool.A[734] }

func A_arbace_j2g_dyn_A_clinit_p33() { A_arbace_j2g_dyn_A_const_471 = A_arbace_j2g_dyn_A_const_pool.A[735]; A_arbace_j2g_dyn_A_const_472 = A_arbace_j2g_dyn_A_const_pool.A[736]; A_arbace_j2g_dyn_A_const_473 = A_arbace_j2g_dyn_A_const_pool.A[737]; A_arbace_j2g_dyn_A_const_474 = A_arbace_j2g_dyn_A_const_pool.A[738]; A_arbace_j2g_dyn_A_const_475 = A_arbace_j2g_dyn_A_const_pool.A[739]; A_arbace_j2g_dyn_A_const_476 = A_arbace_j2g_dyn_A_const_pool.A[740]; A_arbace_j2g_dyn_A_const_477 = A_arbace_j2g_dyn_A_const_pool.A[741]; A_arbace_j2g_dyn_A_const_478 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[742]); A_arbace_j2g_dyn_A_const_479 = A_arbace_j2g_dyn_A_const_pool.A[743]; A_arbace_j2g_dyn_A_const_480 = A_arbace_j2g_dyn_A_const_pool.A[744]; A_arbace_j2g_dyn_A_const_481 = A_arbace_j2g_dyn_A_const_pool.A[745]; A_arbace_j2g_dyn_A_const_482 = A_arbace_j2g_dyn_A_const_pool.A[746]; A_arbace_j2g_dyn_A_const_483 = A_arbace_j2g_dyn_A_const_pool.A[747]; A_arbace_j2g_dyn_A_const_484 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[748]); A_arbace_j2g_dyn_A_const_485 = A_arbace_j2g_dyn_A_const_pool.A[749] }

func A_arbace_j2g_dyn_A_clinit_p34() { A_arbace_j2g_dyn_A_const_486 = A_arbace_j2g_dyn_A_const_pool.A[750]; A_arbace_j2g_dyn_A_const_487 = A_arbace_j2g_dyn_A_const_pool.A[751]; A_arbace_j2g_dyn_A_const_488 = A_arbace_j2g_dyn_A_const_pool.A[752]; A_arbace_j2g_dyn_A_const_489 = A_arbace_j2g_dyn_A_const_pool.A[753]; A_arbace_j2g_dyn_A_const_490 = A_arbace_j2g_dyn_A_const_pool.A[754]; A_arbace_j2g_dyn_A_const_491 = A_arbace_j2g_dyn_A_const_pool.A[755]; A_arbace_j2g_dyn_A_const_492 = A_arbace_j2g_dyn_A_const_pool.A[756]; A_arbace_j2g_dyn_A_const_493 = A_arbace_j2g_dyn_A_const_pool.A[757]; A_arbace_j2g_dyn_A_const_494 = A_arbace_j2g_dyn_A_const_pool.A[758]; A_arbace_j2g_dyn_A_const_495 = A_arbace_j2g_dyn_A_const_pool.A[759]; A_arbace_j2g_dyn_A_const_496 = A_arbace_j2g_dyn_A_const_pool.A[760]; A_arbace_j2g_dyn_A_const_497 = A_arbace_j2g_dyn_A_const_pool.A[761]; A_arbace_j2g_dyn_A_const_498 = A_arbace_j2g_dyn_A_const_pool.A[762]; A_arbace_j2g_dyn_A_const_499 = A_arbace_j2g_dyn_A_const_pool.A[763]; A_arbace_j2g_dyn_A_const_500 = A_arbace_j2g_dyn_A_const_pool.A[764]; A_arbace_j2g_dyn_A_const_501 = A_arbace_j2g_dyn_A_const_pool.A[765] }

func A_arbace_j2g_dyn_A_clinit_p35() { A_arbace_j2g_dyn_A_const_502 = A_arbace_j2g_dyn_A_const_pool.A[766]; A_arbace_j2g_dyn_A_const_503 = A_arbace_j2g_dyn_A_const_pool.A[767]; A_arbace_j2g_dyn_A_const_504 = A_arbace_j2g_dyn_A_const_pool.A[768]; A_arbace_j2g_dyn_A_const_505 = A_arbace_j2g_dyn_A_const_pool.A[769]; A_arbace_j2g_dyn_A_const_506 = A_arbace_j2g_dyn_A_const_pool.A[770]; A_arbace_j2g_dyn_A_const_507 = A_arbace_j2g_dyn_A_const_pool.A[771]; A_arbace_j2g_dyn_A_const_508 = A_arbace_j2g_dyn_A_const_pool.A[772]; A_arbace_j2g_dyn_A_const_509 = A_arbace_j2g_dyn_A_const_pool.A[773]; A_arbace_j2g_dyn_A_const_510 = A_arbace_j2g_dyn_A_const_pool.A[774]; A_arbace_j2g_dyn_A_const_511 = A_arbace_j2g_dyn_A_const_pool.A[775]; A_arbace_j2g_dyn_A_const_512 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[776]); A_arbace_j2g_dyn_A_const_513 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[777]) }

func A_arbace_j2g_dyn_A_New() *A_arbace_j2g_dyn_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_A) Ctor() {}

func (t *A_arbace_j2g_dyn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_A_class }

func (t *A_arbace_j2g_dyn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_A); return ok }

func A_arbace_j2g_dyn_A_Cast(x any) *A_arbace_j2g_dyn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_A_class)) }; return v }



type A_arbace_j2g_dyn_abstract_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_abstract_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_box_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_box_arg_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_call_impl_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_call_impl_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_class_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_ret__711000234_A struct{ j2g_header uint64; F_r any }

var A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_A struct{ j2g_header uint64; F_e any }

var A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A struct{ j2g_header uint64; F_g, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A struct{ j2g_header uint64; F_iter__711000243, F_g, F_s__711000244, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A struct{ j2g_header uint64; F_g, F_n, F_b__711000246, F_arg_conv any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_A struct{ j2g_header uint64; F_ifaces, F_lockee__1927000360__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A struct{ j2g_header uint64; F_j any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A struct{ j2g_header uint64; F_s__711000089, F_iter__711000088 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A struct{ j2g_header uint64; F_iter__711000090, F_s__711000091 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A struct{ j2g_header uint64; F_b__711000093 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_fn__711000118_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A struct{ j2g_header uint64; F_iter__711000107, F_k, F_s__711000108 any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A struct{ j2g_header uint64; F_k, F_b__711000110 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000004_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000004_A_New() *A_arbace_j2g_dyn_eval711000004_A { t := &A_arbace_j2g_dyn_eval711000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000004_A_class }

func (t *A_arbace_j2g_dyn_eval711000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); return ok }

func A_arbace_j2g_dyn_eval711000004_A_Cast(x any) *A_arbace_j2g_dyn_eval711000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000004_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000008_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000008_A_New() *A_arbace_j2g_dyn_eval711000008_A { t := &A_arbace_j2g_dyn_eval711000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000008_A_class }

func (t *A_arbace_j2g_dyn_eval711000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); return ok }

func A_arbace_j2g_dyn_eval711000008_A_Cast(x any) *A_arbace_j2g_dyn_eval711000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000008_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000008_fn__711000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000008_fn__711000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_fn_field_native_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_fn_field_native_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000383_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_fn__711000383_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000414_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000414_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000426_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000426_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000388__711000392_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A struct{ j2g_header uint64; F_iter__711000388, F_s__711000389 any }

var A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A struct{ j2g_header uint64; F_b__711000391 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000404__711000408_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A struct{ j2g_header uint64; F_iter__711000404, F_s__711000405 any }

var A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A struct{ j2g_header uint64; F_b__711000407 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000416__711000420_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A struct{ j2g_header uint64; F_iter__711000416, F_s__711000417 any }

var A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A struct{ j2g_header uint64; F_b__711000419 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A struct{ j2g_header uint64; F_iter__711000270, F_s__711000271 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A struct{ j2g_header uint64; F_s__711000273, F_iter__711000272 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A struct{ j2g_header uint64; F_b__711000275 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A struct{ j2g_header uint64; F_s__711000285, F_iter__711000284 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A struct{ j2g_header uint64; F_b__711000287 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A struct{ j2g_header uint64; F_s__711000297, F_n, F_iter__711000296 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A struct{ j2g_header uint64; F_n, F_b__711000299 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_iface_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A struct{ j2g_header uint64; F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A struct{ j2g_header uint64; F_iter__711000158, F_s__711000159, F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A struct{ j2g_header uint64; F_b__711000161, F_r, F_pn any; F_size__1927001038__auto__ int32; F_core_QMARK_, F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000034_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000036_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A struct{ j2g_header uint64; F_iter__711000038, F_s__711000039 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A struct{ j2g_header uint64; F_s__711000041, F_n, F_iter__711000040 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A struct{ j2g_header uint64; F_n, F_b__711000043 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000178_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000196_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A struct{ j2g_header uint64; F_s__711000187, F_iter__711000186 any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A struct{ j2g_header uint64; F_b__711000189 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_object_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_object_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_classes_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_fn__711000201_A struct{ j2g_header uint64; F_T any }

var A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A struct{ j2g_header uint64; F_iter__711000205, F_s__711000206 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A struct{ j2g_header uint64; F_iter__711000207, F_n, F_s__711000208 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A struct{ j2g_header uint64; F_n, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A struct{ j2g_header uint64; F_s__711000210, F_n, F_iter__711000209, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A struct{ j2g_header uint64; F_n, F_b__711000212 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_public_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_public_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A struct{ j2g_header uint64; F_iter__711000013, F_s__711000014 any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A struct{ j2g_header uint64; F_b__711000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A struct{ j2g_header uint64; F_s__711000056, F_iter__711000055 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A struct{ j2g_header uint64; F_iter__711000057, F_s__711000058 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A struct{ j2g_header uint64; F_b__711000060 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000324_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_A struct{ j2g_header uint64; F_own, F_recv, F_clash, F_ifaces, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A struct{ j2g_header uint64; F_iter__711000307, F_s__711000308 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A struct{ j2g_header uint64; F_b__711000310 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A struct{ j2g_header uint64; F_s__711000330, F_iter__711000329 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A struct{ j2g_header uint64; F_b__711000332 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A struct{ j2g_header uint64; F_recv, F_iter__711000345, F_s__711000346, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A struct{ j2g_header uint64; F_recv, F_n, F_b__711000348 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A struct{ j2g_header uint64; F_recv, F_clash any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A struct{ j2g_header uint64; F_s__711000360, F_recv, F_clash, F_iter__711000359 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A struct{ j2g_header uint64; F_recv, F_clash, F_b__711000362 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_tag_A_fn_class *jrt.Class
