//line aot_arbace_j2g_dyn.ae:1
package aot_arbace_j2g_dyn

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_New() *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyn_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyn_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyn_A_const_1, A_arbace_j2g_dyn_A_const_2, A_arbace_j2g_dyn_A_const_3, A_arbace_j2g_dyn_A_const_4, A_arbace_j2g_dyn_A_const_5, A_arbace_j2g_dyn_A_const_6, A_arbace_j2g_dyn_A_const_7, A_arbace_j2g_dyn_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyn_eval711000008_fn__711000009_A_New() *A_arbace_j2g_dyn_eval711000008_fn__711000009_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000008_fn__711000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_11.GetRawRoot__O()); var tmp2 any; var root_22 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_dyn_A_const_13; if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_22, arg_25) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(), A_arbace_j2g_dyn_A_const_15) }























func A_arbace_j2g_dyn_tag_A_New() *A_arbace_j2g_dyn_tag_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_tag_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_26 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = sym__0; var arg_30 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyn_A_const_17, type__1)); if linked_27 == nil { return ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { return linked_27.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) } }














func A_arbace_j2g_dyn_roots_A_New() *A_arbace_j2g_dyn_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_j2g_dyn_roots_A) Ctor() {}
//line :40:1
func (t *A_arbace_j2g_dyn_roots_A) Invoke_O__O(self any) any {



	var root_31 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; var iter__1927001039__auto____1 any; var fnbody__97 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New(); var tmp1 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class
	if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, nil); A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class = fncls__96d; tmp1 = fncls__96d } else { tmp1 = fncls__96 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__97, tmp1, nil); arg_34 = lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_30.GetRawRoot__O())
//line :44:1
	var arg_35 any; var tmp2 any; var root_98 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_100 lang.IFn


	if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any; var root_102 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); if linked_103 == nil { arg_101 = ifn_104.Invoke_O__O(arg_105) } else { arg_101 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; if linked_99 == nil { tmp2 = ifn_100.Invoke_O__O(arg_101) } else { tmp2 = linked_99.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_98, arg_101) }; if jrt.J2g_Truth(tmp2) { arg_35 = lang.Tuple_Create_O__IPersistentVector(A_arbace_j2g_dyn_A_const_32.GetRawRoot__O()) } else { arg_35 = nil }
//line :44:1
	if linked_32 == nil { return ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { return linked_32.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_31, arg_34, arg_35) } }
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New() *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Ctor() {}
//line :45:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Invoke_O_O__O(self, s__711000014__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__95 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(self, s__711000014__1); var tmp2 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, fnbody__95); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class = fncls__94d; tmp2 = fncls__94d } else { tmp2 = fncls__94 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__95, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :45:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :45:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Ctor_O_O(c__iter__711000013, c__s__711000014 any) { t.F_iter__711000013 = c__iter__711000013; t.F_s__711000014 = c__s__711000014 }
//line :45:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Invoke_O__O(self any) any { { var s__711000014__1 any; var t_ any = t.F_s__711000014; t.F_s__711000014 = nil; s__711000014__1 = t_; for { var temp__1927000414__auto____2 any; var root_36 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = s__711000014__1; if linked_37 == nil { temp__1927000414__auto____2 = ifn_38.Invoke_O__O(arg_39) } else { temp__1927000414__auto____2 = linked_37.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_36, arg_39) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_40 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = s__711000014__3; if linked_41 == nil { tmp1 = ifn_42.Invoke_O__O(arg_43) } else { tmp1 = linked_41.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_44 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = s__711000014__3; if linked_45 == nil { c__1927001037__auto____4 = ifn_46.Invoke_O__O(arg_47) } else { c__1927001037__auto____4 = linked_45.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_44, arg_47) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000016__6 any; var root_48 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_49 == nil { b__711000016__6 = ifn_50.Invoke_O__O(arg_51) } else { b__711000016__6 = linked_49.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_48, arg_51) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(b__711000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, fnbody__58); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_59 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var root_64 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = b__711000016__6; if linked_65 == nil { arg_62 = ifn_66.Invoke_O__O(arg_67) } else { arg_62 = linked_65.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_64, arg_67) }; var arg_63 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp5 any; var root_68 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = s__711000014__3; if linked_69 == nil { tmp5 = ifn_70.Invoke_O__O(arg_71) } else { tmp5 = linked_69.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_68, arg_71) }; arg_63 = tmp4.Invoke_O__O(tmp5); if linked_60 == nil { return ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { return linked_60.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) } } else { var root_72 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any; var root_77 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = b__711000016__6; if linked_78 == nil { arg_75 = ifn_79.Invoke_O__O(arg_80) } else { arg_75 = linked_78.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_77, arg_80) }; var arg_76 any; if linked_73 == nil { return ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { return linked_73.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_72, arg_75, arg_76) } } } else { var vec__711000024__4 any; var root_81 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = s__711000014__3; if linked_82 == nil { vec__711000024__4 = ifn_83.Invoke_O__O(arg_84) } else { vec__711000024__4 = linked_82.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_81, arg_84) }; var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_85 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_18, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()); var arg_89 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp7 any; var root_90 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = s__711000014__3; if linked_91 == nil { tmp7 = ifn_92.Invoke_O__O(arg_93) } else { tmp7 = linked_91.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_90, arg_93) }; arg_89 = tmp6.Invoke_O__O(tmp7); if linked_86 == nil { return ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { return linked_86.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :45:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :45:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Ctor_O_I_O(c__b__711000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000016 = c__b__711000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :45:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Invoke_O__O(self any) any { { var i__711000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_52 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = t.F_b__711000016; var arg_56 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_18, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref()); if linked_53 == nil { ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { linked_53.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; i__711000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000015__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_enabled_QMARK__A_New() *A_arbace_j2g_dyn_enabled_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_enabled_QMARK__A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Ctor() {}
//line :50:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_106 any = A_arbace_j2g_dyn_A_const_33.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); if linked_107 == nil { return ifn_108.Invoke_O__O(arg_109) } else { return linked_107.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_106, arg_109)
	} }
func A_arbace_j2g_dyn_public_QMARK__A_New() *A_arbace_j2g_dyn_public_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_public_QMARK__A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Ctor() {}
//line :55:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_110 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var tmp1 int64; var na_114 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_36; var tmp3 any; var root_116 any = A_arbace_j2g_dyn_A_const_37.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = n__0; if linked_117 == nil { tmp3 = ifn_118.Invoke_O__O(arg_119) } else { tmp3 = linked_117.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_116, arg_119) }; na_114 = tmp2.Invoke_O__O(tmp3); var na_115 int64 = 1; if jrt.Long_InstanceOf(na_114) { var n0_120 int64 = jrt.NN(jrt.Long_Cast(na_114)).LongValue__J(); var n1_121 int64 = na_115; tmp1 = n0_120 & n1_121 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_114, na_115) }; arg_113 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_111 == nil { return ifn_112.Invoke_O__O(arg_113) } else { return linked_111.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_110, arg_113) } }

func A_arbace_j2g_dyn_interfaces_A_New() *A_arbace_j2g_dyn_interfaces_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_j2g_dyn_interfaces_A) Ctor() {}
//line :57:1
func (t *A_arbace_j2g_dyn_interfaces_A) Invoke_O_O__O(self, T__0_ any) any { var base__2 any; var root_123 any = A_arbace_j2g_dyn_A_const_38.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_125 lang.IFn; if






	linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var fnbody__179 any = A_arbace_j2g_dyn_interfaces_fn__711000034_A_New(); var tmp1 *jrt.Class; var fncls__178 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class; if fncls__178 == nil { var fncls__178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, nil); A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class = fncls__178d; tmp1 = fncls__178d } else { tmp1 = fncls__178 }; arg_126 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__179, tmp1, nil); var arg_127 any; var root_180 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_182 lang.IFn; if






	linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = T__0_; var arg_184 any; var root_185 any = A_arbace_j2g_dyn_A_const_38.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any; var fnbody__204 any = A_arbace_j2g_dyn_interfaces_fn__711000036_A_New(); var tmp2 *jrt.Class; var fncls__203 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class; if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, nil); A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class = fncls__203d; tmp2 = fncls__203d } else { tmp2 = fncls__203 }; arg_188 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__204, tmp2, nil); var arg_189 any; var root_205 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_207 lang.IFn; if


	linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any; var root_209 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_dyn_A_const_54; var arg_212 any = tmp3.Invoke_O__O(A_arbace_j2g_dyn_A_const_50.Get__O()); if linked_210 == nil { arg_208 = ifn_211.Invoke_O__O(arg_212) } else { arg_208 = linked_210.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_209, arg_212) }; if linked_206 == nil { arg_189 = ifn_207.Invoke_O__O(arg_208) } else { arg_189 = linked_206.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_205, arg_208) }; if /*line :71:1*/ linked_186 == nil { arg_184 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { arg_184 = linked_186.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_185, arg_188, arg_189) }; if linked_181 == nil { arg_127 = ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { arg_127 = linked_181.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_180, arg_183, arg_184) }; if /*line :64:1*/ linked_124 == nil { base__2 = ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { base__2 = linked_124.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_123, arg_126, arg_127) }; var root_213 any =










	A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any; var root_217 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var root_221 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = base__2; var arg_225 any; var iter__1927001039__auto____3 any; var fnbody__350 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New(); var tmp4 *jrt.Class; var fncls__349 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class; if
	fncls__349 == nil { var fncls__349d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class = fncls__349d; tmp4 = fncls__349d } else { tmp4 = fncls__349 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__350, tmp4, nil); arg_225 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(base__2); if /*line :75:1*/ linked_222 == nil { arg_220 = ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { arg_220 = linked_222.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) }; if linked_218 == nil { arg_216 = ifn_219.Invoke_O__O(arg_220) } else { arg_216 = linked_218.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_217, arg_220) }; if linked_214 == nil { return ifn_215.Invoke_O__O(arg_216) } else { return linked_214.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_213, arg_216) } }
//line :64:1
func A_arbace_j2g_dyn_interfaces_fn__711000034_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000034_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000034_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Ctor() {}
//line :64:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Invoke_O_O__O(self, p1__711000032_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_128 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = p1__711000032_SHARP___1; if linked_129 == nil { and__1927000168__auto____2 = ifn_130.Invoke_O__O(arg_131) } else { and__1927000168__auto____2 = linked_129.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_128, arg_131) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var or__1927000174__auto____3 any; var root_132 any = A_arbace_j2g_dyn_A_const_40.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_j2g_dyn_public_QMARK__A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = p1__711000032_SHARP___1; if linked_133 == nil { or__1927000174__auto____3 = ifn_134.Invoke_O__O(arg_135) } else { or__1927000174__auto____3 = linked_133.(*A_arbace_j2g_dyn_public_QMARK__A).Invoke_O_O__O(root_132, arg_135) }; if jrt.J2g_Truth(or__1927000174__auto____3) { and__1927000168__auto____3 = or__1927000174__auto____3 } else { var root_136 any = A_arbace_j2g_dyn_A_const_41.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_j2g_names.A_arbace_j2g_names_own_class_QMARK__A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = p1__711000032_SHARP___1; if linked_137 == nil { and__1927000168__auto____3 = ifn_138.Invoke_O__O(arg_139) } else { and__1927000168__auto____3 = linked_137.(*aot_arbace_j2g_names.A_arbace_j2g_names_own_class_QMARK__A).Invoke_O_O__O(root_136, arg_139) } }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_140 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_142 lang.IFn

	if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any; var root_144 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any; var root_148 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = p1__711000032_SHARP___1; if linked_149 == nil { arg_147 = ifn_150.Invoke_O__O(arg_151) } else { arg_147 = linked_149.(*aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_148, arg_151) }; if linked_145 == nil { arg_143 = ifn_146.Invoke_O__O(arg_147) } else { arg_143 = linked_145.(*aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A).Invoke_O_O__O(root_144, arg_147) }; if linked_141 == nil { and__1927000168__auto____4 = ifn_142.Invoke_O__O(arg_143) } else { and__1927000168__auto____4 = linked_141.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_140, arg_143) }
//line :64:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_152 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_154 lang.IFn



		if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any; var root_156 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = p1__711000032_SHARP___1; var arg_160 any = Lit_82; if linked_157 == nil { arg_155 = ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { arg_155 = linked_157.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_156, arg_159, arg_160) }; if linked_153 == nil { and__1927000168__auto____5 = ifn_154.Invoke_O__O(arg_155) } else { and__1927000168__auto____5 = linked_153.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_152, arg_155) }
//line :64:1
		if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp1 int64; var na_161 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_36; var tmp3 any; var root_163 any = A_arbace_j2g_dyn_A_const_37.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_165 lang.IFn




			if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = p1__711000032_SHARP___1; if linked_164 == nil { tmp3 = ifn_165.Invoke_O__O(arg_166) } else { tmp3 = linked_164.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_163, arg_166) }; na_161 = tmp2.Invoke_O__O(tmp3); var na_162 int64 = 8192; if jrt.Long_InstanceOf(na_161) { var n0_167 int64 = jrt.NN(jrt.Long_Cast(na_161)).LongValue__J(); var n1_168 int64 = na_162; tmp1 = n0_167 & n1_168 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_161, na_162) }; and__1927000168__auto____6 = lang.Numbers_IsZero_J__Z_NoInit(tmp1)
//line :64:1
			if and__1927000168__auto____6 {





				var root_170 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any; var root_174 any = A_arbace_j2g_dyn_A_const_45.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = p1__711000032_SHARP___1; if linked_175 == nil { arg_173 = ifn_176.Invoke_O__O(arg_177) } else { arg_173 = linked_175.(*aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A).Invoke_O_O__O(root_174, arg_177) }; if linked_171 == nil { return ifn_172.Invoke_O__O(arg_173) } else { return linked_171.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_170, arg_173) } } else {
//line :64:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_dyn_interfaces_fn__711000036_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000036_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000036_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Ctor() {}
//line :71:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Invoke_O_O__O(self, p1__711000033_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_190 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = p1__711000033_SHARP___1; if linked_191 == nil { and__1927000168__auto____2 = ifn_192.Invoke_O__O(arg_193) } else { and__1927000168__auto____2 = linked_191.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_190, arg_193) }; if jrt.J2g_Truth(and__1927000168__auto____2) {

	var root_194 any = A_arbace_j2g_dyn_A_const_47.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var tmp1 *lang.Keyword = A_arbace_j2g_dyn_A_const_48; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_49; var arg_197 any = tmp1.Invoke_O__O(tmp2.Invoke_O__O(A_arbace_j2g_dyn_A_const_50.Get__O())); var arg_198 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_22); var tmp4 any; var root_199 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = p1__711000033_SHARP___1; if linked_200 == nil { tmp4 = ifn_201.Invoke_O__O(arg_202) } else { tmp4 = linked_200.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_199, arg_202) }; arg_198 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil)).Ref(); if linked_195 == nil { return ifn_196.Invoke_O_O__O(arg_197, arg_198) } else { return linked_195.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_194, arg_197, arg_198) } } else {
//line :71:1
		return and__1927000168__auto____2 } }




func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New() *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Ctor() {}
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Invoke_O_O__O(self, s__711000039__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__348 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(self, s__711000039__1); var tmp2 *jrt.Class; var fncls__347 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class; if fncls__347 == nil { var fncls__347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__348); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class = fncls__347d; tmp2 = fncls__347d } else { tmp2 = fncls__347 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__348, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :76:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Ctor_O_O(c__iter__711000038, c__s__711000039 any) { t.F_iter__711000038 = c__iter__711000038; t.F_s__711000039 = c__s__711000039 }
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Invoke_O__O(self any) any { { var s__711000039__1 any; var t_ any = t.F_s__711000039; t.F_s__711000039 = nil; s__711000039__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_226 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = s__711000039__1; if linked_227 == nil { temp__1927000414__auto____2 = ifn_228.Invoke_O__O(arg_229) } else { temp__1927000414__auto____2 = linked_227.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_230 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = xs__1927001018__auto____3; if linked_231 == nil { n__4 = ifn_232.Invoke_O__O(arg_233) } else { n__4 = linked_231.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_230, arg_233) }; var iterys__1927001035__auto____5 any; var fnbody__325 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(n__4); var tmp1 *jrt.Class; var fncls__324 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class; if fncls__324 == nil { var fncls__324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__325); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class = fncls__324d; tmp1 = fncls__324d } else { tmp1 = fncls__324 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__325, tmp1, nil); var fs__1927001036__auto____6 any; var root_326 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_330 any = A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = n__4; if linked_331 == nil { tmp3 = ifn_332.Invoke_O__O(arg_333) } else { tmp3 = linked_331.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_330, arg_333) }; arg_329 = tmp2.Invoke_O__O(tmp3); if linked_327 == nil { fs__1927001036__auto____6 = ifn_328.Invoke_O__O(arg_329) } else { fs__1927001036__auto____6 = linked_327.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_326, arg_329) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_334 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = fs__1927001036__auto____6; var arg_338 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000038); var tmp5 any; var root_339 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = s__711000039__1; if linked_340 == nil { tmp5 = ifn_341.Invoke_O__O(arg_342) } else { tmp5 = linked_340.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_339, arg_342) }; arg_338 = tmp4.Invoke_O__O(tmp5); if linked_335 == nil { return ifn_336.Invoke_O_O__O(arg_337, arg_338) } else { return linked_335.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_334, arg_337, arg_338) } } else { var tmp6 any; var root_343 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = s__711000039__1; if linked_344 == nil { tmp6 = ifn_345.Invoke_O__O(arg_346) } else { tmp6 = linked_344.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_343, arg_346) }; s__711000039__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :76:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(p0 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A{}; t.Ctor_O(p0); return t }
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Invoke_O_O__O(self, s__711000041__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__323 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(s__711000041__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__322 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class; if fncls__322 == nil { var fncls__322d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__323); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class = fncls__322d; tmp2 = fncls__322d } else { tmp2 = fncls__322 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__323, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :76:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Ctor_O_O_O(c__s__711000041, c__n, c__iter__711000040 any) { t.F_s__711000041 = c__s__711000041; t.F_n = c__n; t.F_iter__711000040 = c__iter__711000040 }
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Invoke_O__O(self any) any { { var s__711000041__1 any; var t_ any = t.F_s__711000041; t.F_s__711000041 = nil; s__711000041__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_234 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = s__711000041__1; if linked_235 == nil { temp__1927000414__auto____2 = ifn_236.Invoke_O__O(arg_237) } else { temp__1927000414__auto____2 = linked_235.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_234, arg_237) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000041__3 any = temp__1927000414__auto____2; var tmp1 any; var root_238 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = s__711000041__3; if linked_239 == nil { tmp1 = ifn_240.Invoke_O__O(arg_241) } else { tmp1 = linked_239.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_238, arg_241) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_242 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = s__711000041__3; if linked_243 == nil { c__1927001037__auto____4 = ifn_244.Invoke_O__O(arg_245) } else { c__1927001037__auto____4 = linked_243.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_242, arg_245) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000043__6 any; var root_246 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_247 == nil { b__711000043__6 = ifn_248.Invoke_O__O(arg_249) } else { b__711000043__6 = linked_247.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_246, arg_249) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__269 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(t.F_n, b__711000043__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__268 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class; if fncls__268 == nil { var fncls__268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__269); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class = fncls__268d; tmp3 = fncls__268d } else { tmp3 = fncls__268 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__269, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_270 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any; var root_275 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = b__711000043__6; if linked_276 == nil { arg_273 = ifn_277.Invoke_O__O(arg_278) } else { arg_273 = linked_276.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_275, arg_278) }; var arg_274 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp5 any; var root_279 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = s__711000041__3; if linked_280 == nil { tmp5 = ifn_281.Invoke_O__O(arg_282) } else { tmp5 = linked_280.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_279, arg_282) }; arg_274 = tmp4.Invoke_O__O(tmp5); if linked_271 == nil { return ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { return linked_271.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) } } else { var root_283 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any; var root_288 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = b__711000043__6; if linked_289 == nil { arg_286 = ifn_290.Invoke_O__O(arg_291) } else { arg_286 = linked_289.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_288, arg_291) }; var arg_287 any; if linked_284 == nil { return ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { return linked_284.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_283, arg_286, arg_287) } } } else { var s__4 any; var root_292 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = s__711000041__3; if linked_293 == nil { s__4 = ifn_294.Invoke_O__O(arg_295) } else { s__4 = linked_293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_292, arg_295) }; var tmp6 any; var and__1927000168__auto____5 any; var root_296 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_298 lang.IFn
																			if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = s__4; var arg_300 any = t.F_n; if linked_297 == nil { and__1927000168__auto____5 = ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { and__1927000168__auto____5 = linked_297.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_296, arg_299, arg_300) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_301 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = s__4; if linked_302 == nil { and__1927000168__auto____6 = ifn_303.Invoke_O__O(arg_304) } else { and__1927000168__auto____6 = linked_302.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_301, arg_304) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_305 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = s__4; if linked_306 == nil { tmp6 = ifn_307.Invoke_O__O(arg_308) } else { tmp6 = linked_306.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_305, arg_308) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :76:1
	if jrt.J2g_Truth(tmp6) { var root_309 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = s__4; var arg_313 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp8 any; var root_314 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = s__711000041__3; if linked_315 == nil { tmp8 = ifn_316.Invoke_O__O(arg_317) } else { tmp8 = linked_315.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_314, arg_317) }; arg_313 = tmp7.Invoke_O__O(tmp8); if linked_310 == nil { return ifn_311.Invoke_O_O__O(arg_312, arg_313) } else { return linked_310.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_309, arg_312, arg_313) } } else { var tmp9 any; var root_318 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = s__711000041__3; if linked_319 == nil { tmp9 = ifn_320.Invoke_O__O(arg_321) } else { tmp9 = linked_319.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_318, arg_321) }; s__711000041__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :76:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Ctor_O_O_I_O(c__n, c__b__711000043 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000043 = c__b__711000043; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :76:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Invoke_O__O(self any) any { { var i__711000042__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000042__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000042__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_250 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_252 lang.IFn
																					if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = s__2; var arg_254 any = t.F_n; if linked_251 == nil { and__1927000168__auto____3 = ifn_252.Invoke_O_O__O(arg_253, arg_254) } else { and__1927000168__auto____3 = linked_251.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_250, arg_253, arg_254) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_255 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = s__2; if linked_256 == nil { and__1927000168__auto____4 = ifn_257.Invoke_O__O(arg_258) } else { and__1927000168__auto____4 = linked_256.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_255, arg_258) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_259 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = s__2; if linked_260 == nil { tmp2 = ifn_261.Invoke_O__O(arg_262) } else { tmp2 = linked_260.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_259, arg_262) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :76:1
	if jrt.J2g_Truth(tmp2) { var root_263 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = t.F_b__711000043; var arg_267 any = s__2; if linked_264 == nil { ifn_265.Invoke_O_O__O(arg_266, arg_267) } else { linked_264.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_263, arg_266, arg_267) }; i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } else { i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_slot_keys_A_New() *A_arbace_j2g_dyn_slot_keys_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Ctor() {}
//line :80:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Invoke_O_O__O(self, ifaces__0 any) any { var ks__2 any; var root_351 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_353 lang.IFn; if


	linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any; var root_355 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any; var iter__1927001039__auto____2 any; var fnbody__465 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New(); var tmp1 *jrt.Class; var fncls__464 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class; if fncls__464 == nil { var fncls__464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, nil); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class = fncls__464d; tmp1 = fncls__464d } else { tmp1 = fncls__464 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__465, tmp1, nil); arg_358 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(ifaces__0); if linked_356 == nil { arg_354 = ifn_357.Invoke_O__O(arg_358) } else { arg_354 = linked_356.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_355, arg_358) }; if linked_352 == nil { ks__2 = ifn_353.Invoke_O__O(arg_354) } else { ks__2 = linked_352.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_351, arg_354) }; var root_466 any =
	A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any; var root_470 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = A_arbace_j2g_dyn_A_const_62.GetRawRoot__O(); var arg_474 any = ks__2; if linked_471 == nil { arg_469 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { arg_469 = linked_471.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; if linked_467 == nil { return ifn_468.Invoke_O__O(arg_469) } else { return linked_467.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_466, arg_469) } }
//line :83:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Invoke_O_O__O(self, s__711000056__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__463 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(s__711000056__1, self); var tmp2 *jrt.Class; var fncls__462 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class; if fncls__462 == nil { var fncls__462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, fnbody__463); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class = fncls__462d; tmp2 = fncls__462d } else { tmp2 = fncls__462 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__463, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :83:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A{}; t.Ctor_O_O(p0, p1); return t }
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Ctor_O_O(c__s__711000056, c__iter__711000055 any) { t.F_s__711000056 = c__s__711000056; t.F_iter__711000055 = c__iter__711000055 }
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Invoke_O__O(self any) any { { var s__711000056__1 any; var t_ any = t.F_s__711000056; t.F_s__711000056 = nil; s__711000056__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_359 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = s__711000056__1; if linked_360 == nil { temp__1927000414__auto____2 = ifn_361.Invoke_O__O(arg_362) } else { temp__1927000414__auto____2 = linked_360.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_359, arg_362) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var j__4 any; var root_363 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = xs__1927001018__auto____3; if linked_364 == nil { j__4 = ifn_365.Invoke_O__O(arg_366) } else { j__4 = linked_364.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_363, arg_366) }; var iterys__1927001035__auto____5 any; var fnbody__440 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New(); var tmp1 *jrt.Class; var fncls__439 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class; if fncls__439 == nil { var fncls__439d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, nil); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class = fncls__439d; tmp1 = fncls__439d } else { tmp1 = fncls__439 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__440, tmp1, nil); var fs__1927001036__auto____6 any; var root_441 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_445 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = j__4; if linked_446 == nil { tmp3 = ifn_447.Invoke_O__O(arg_448) } else { tmp3 = linked_446.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_445, arg_448) }; arg_444 = tmp2.Invoke_O__O(tmp3); if linked_442 == nil { fs__1927001036__auto____6 = ifn_443.Invoke_O__O(arg_444) } else { fs__1927001036__auto____6 = linked_442.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_441, arg_444) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_449 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = fs__1927001036__auto____6; var arg_453 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000055); var tmp5 any; var root_454 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = s__711000056__1; if linked_455 == nil { tmp5 = ifn_456.Invoke_O__O(arg_457) } else { tmp5 = linked_455.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_454, arg_457) }; arg_453 = tmp4.Invoke_O__O(tmp5); if linked_450 == nil { return ifn_451.Invoke_O_O__O(arg_452, arg_453) } else { return linked_450.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_449, arg_452, arg_453) } } else { var tmp6 any; var root_458 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = s__711000056__1; if linked_459 == nil { tmp6 = ifn_460.Invoke_O__O(arg_461) } else { tmp6 = linked_459.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_458, arg_461) }; s__711000056__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :83:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Ctor() {}
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Invoke_O_O__O(self, s__711000058__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__438 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(self, s__711000058__1); var tmp2 *jrt.Class; var fncls__437 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class; if fncls__437 == nil { var fncls__437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, fnbody__438); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class = fncls__437d; tmp2 = fncls__437d } else { tmp2 = fncls__437 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__438, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :83:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A{}; t.Ctor_O_O(p0, p1); return t }
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Ctor_O_O(c__iter__711000057, c__s__711000058 any) { t.F_iter__711000057 = c__iter__711000057; t.F_s__711000058 = c__s__711000058 }
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Invoke_O__O(self any) any { { var s__711000058__1 any; var t_ any = t.F_s__711000058; t.F_s__711000058 = nil; s__711000058__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_367 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = s__711000058__1; if linked_368 == nil { temp__1927000414__auto____2 = ifn_369.Invoke_O__O(arg_370) } else { temp__1927000414__auto____2 = linked_368.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_367, arg_370) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000058__3 any = temp__1927000414__auto____2; var tmp1 any; var root_371 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = s__711000058__3; if linked_372 == nil { tmp1 = ifn_373.Invoke_O__O(arg_374) } else { tmp1 = linked_372.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_371, arg_374) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_375 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = s__711000058__3; if linked_376 == nil { c__1927001037__auto____4 = ifn_377.Invoke_O__O(arg_378) } else { c__1927001037__auto____4 = linked_376.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_375, arg_378) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000060__6 any; var root_379 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_380 == nil { b__711000060__6 = ifn_381.Invoke_O__O(arg_382) } else { b__711000060__6 = linked_380.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_379, arg_382) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__393 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(b__711000060__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__392 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class; if fncls__392 == nil { var fncls__392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, fnbody__393); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class = fncls__392d; tmp3 = fncls__392d } else { tmp3 = fncls__392 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__393, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_394 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any; var root_399 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = b__711000060__6; if linked_400 == nil { arg_397 = ifn_401.Invoke_O__O(arg_402) } else { arg_397 = linked_400.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_399, arg_402) }; var arg_398 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp5 any; var root_403 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = s__711000058__3; if linked_404 == nil { tmp5 = ifn_405.Invoke_O__O(arg_406) } else { tmp5 = linked_404.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_403, arg_406) }; arg_398 = tmp4.Invoke_O__O(tmp5); if linked_395 == nil { return ifn_396.Invoke_O_O__O(arg_397, arg_398) } else { return linked_395.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_394, arg_397, arg_398) } } else { var root_407 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any; var root_412 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = b__711000060__6; if linked_413 == nil { arg_410 = ifn_414.Invoke_O__O(arg_415) } else { arg_410 = linked_413.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_412, arg_415) }; var arg_411 any; if linked_408 == nil { return ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { return linked_408.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) } } } else { var vec__711000070__4 any; var root_416 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = s__711000058__3; if linked_417 == nil { vec__711000070__4 = ifn_418.Invoke_O__O(arg_419) } else { vec__711000070__4 = linked_417.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_416, arg_419) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_420 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_422 lang.IFn; _ = ___6; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()).Invoke_O__O(k__5); if linked_421 == nil { tmp6 = ifn_422.Invoke_O__O(arg_423) } else { tmp6 = linked_421.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_420, arg_423) }; if jrt.J2g_Truth(tmp6) { var root_424 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = k__5; var arg_428 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp8 any; var root_429 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = s__711000058__3; if linked_430 == nil { tmp8 = ifn_431.Invoke_O__O(arg_432) } else { tmp8 = linked_430.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_429, arg_432) }; arg_428 = tmp7.Invoke_O__O(tmp8); if linked_425 == nil { return ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { return linked_425.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_424, arg_427, arg_428) } } else { var tmp9 any; var root_433 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = s__711000058__3; if linked_434 == nil { tmp9 = ifn_435.Invoke_O__O(arg_436) } else { tmp9 = linked_434.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_433, arg_436) }; s__711000058__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :83:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Ctor_O_I_O(c__b__711000060 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000060 = c__b__711000060; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :83:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Invoke_O__O(self any) any { { var i__711000059__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000059__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000066__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000059__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_383 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_385 lang.IFn; _ = ___4; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()).Invoke_O__O(k__3); if linked_384 == nil { tmp2 = ifn_385.Invoke_O__O(arg_386) } else { tmp2 = linked_384.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_383, arg_386) }; if jrt.J2g_Truth(tmp2) { var root_387 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = t.F_b__711000060; var arg_391 any = k__3; if linked_388 == nil { ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { linked_388.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } else { i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_declarers_A_New() *A_arbace_j2g_dyn_declarers_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_j2g_dyn_declarers_A) Ctor() {}
//line :88:1
func (t *A_arbace_j2g_dyn_declarers_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var vec__711000078__3 any; var root_475 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_477 lang.IFn; if




	linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = A_arbace_j2g_dyn_A_const_63.GetRawRoot__O(); if linked_476 == nil { vec__711000078__3 = ifn_477.Invoke_O__O(arg_478) } else { vec__711000078__3 = linked_476.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_475, arg_478) }; var i__4 any = /*line :88:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; if





	lang.Util_Identical_O_O__Z_NoInit(i__4, ifaces__0) { tmp1 = ix__5 } else { var lockee__1927000360__auto____6 any = A_arbace_j2g_dyn_A_const_63.GetRawRoot__O(); var tmp2 *lang.Compiler_AOTFn; var fnbody__620 any = A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(ifaces__0, lockee__1927000360__auto____6); var tmp3 *jrt.Class
		var fncls__619 /*line :94:1*/*jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class

		if fncls__619 == nil { var fncls__619d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__620); A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class = fncls__619d; tmp3 = fncls__619d } else { tmp3 = fncls__619 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__620, tmp3, nil); tmp1 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O() }; return /*line :94:1*/ lang.RT_Get_O_O__O_NoInit(tmp1, k__1) }

func A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :96:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Ctor_O_O(c__ifaces, c__lockee__1927000360__auto__ any) { t.F_ifaces = c__ifaces; t.F_lockee__1927000360__auto__ = c__lockee__1927000360__auto__ }
//line :96:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Invoke_O__O(self any) any { var locklocal__1927000361__auto____3 any; var t_ any = t.F_lockee__1927000360__auto__; t.F_lockee__1927000360__auto__ = nil; locklocal__1927000361__auto____3 = t_; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____3); var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__711000082__6 any; var root_479 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_481 lang.IFn
										if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = A_arbace_j2g_dyn_A_const_63.GetRawRoot__O(); if linked_480 == nil { vec__711000082__6 = ifn_481.Invoke_O__O(arg_482) } else { vec__711000082__6 = linked_480.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_479, arg_482) }
//line :96:1
	var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(1), nil)

	if lang.Util_Identical_O_O__Z_NoInit(i__7, t.F_ifaces) { tmp1 = ix__8 } else { var ix__9 any; var root_483 any = A_arbace_j2g_dyn_A_const_64.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_485 lang.IFn

		if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var fnbody__613 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New(); var tmp2 *jrt.Class; var fncls__612 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class; if fncls__612 == nil { var fncls__612d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class = fncls__612d; tmp2 = fncls__612d } else { tmp2 = fncls__612 }; arg_486 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__613, tmp2, nil); var arg_487 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_488 any = t.F_ifaces; if linked_484 == nil { ix__9 = ifn_485.Invoke_O_O_O__O(arg_486, arg_487, arg_488) } else { ix__9 = linked_484.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_483, arg_486, arg_487, arg_488)
		}




		var root_614 any = A_arbace_j2g_dyn_A_const_70.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = A_arbace_j2g_dyn_A_const_63.GetRawRoot__O(); var arg_618 any; var tmp3 any; var t__2 any = t.F_ifaces; t.F_ifaces = nil; tmp3 = t__2; arg_618 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, ix__9); if linked_615 == nil { ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { linked_615.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }
//line :98:1
		tmp1 = ix__9 } }; return nil }(); /*line :96:1*/lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____3); if tmp4 != nil { panic(tmp4) }; return tmp1 }



func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Invoke_O_O_O__O(self, ix__1, j__2 any) any {
	var root_489 any = A_arbace_j2g_dyn_A_const_64.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any; var fnbody__508 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(j__2); var tmp1 *jrt.Class; var fncls__507 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class; if fncls__507 == nil { var fncls__507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__508); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class = fncls__507d; tmp1 = fncls__507d } else { tmp1 = fncls__507 }; arg_492 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__508, tmp1, nil); var arg_493 any = ix__1; var arg_494 any; var root_509 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_511 lang.IFn

	if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any; var iter__1927001039__auto____3 any; var fnbody__607 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New(); var tmp2 *jrt.Class; var fncls__606 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class; if fncls__606 == nil { var fncls__606d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class = fncls__606d; tmp2 = fncls__606d } else { tmp2 = fncls__606 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__607, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_608 any = A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = j__2; if linked_609 == nil { tmp4 = ifn_610.Invoke_O__O(arg_611) } else { tmp4 = linked_609.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_608, arg_611) }; arg_512 = tmp3.Invoke_O__O(tmp4); if linked_510 == nil { arg_494 = ifn_511.Invoke_O__O(arg_512) } else { arg_494 = linked_510.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_509, arg_512) }
//line :101:1
	if linked_490 == nil { return ifn_491.Invoke_O_O_O__O(arg_492, arg_493, arg_494) } else { return linked_490.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_489, arg_492, arg_493, arg_494) } }
//line :101:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(p0 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A{}; t.Ctor_O(p0); return t }
//line :101:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Ctor_O(c__j any) { t.F_j = c__j }
//line :101:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Invoke_O_O_O__O(self, ix__1, kk__2 any) any { var root_495 any = A_arbace_j2g_dyn_A_const_65.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = ix__1; var arg_499 any = kk__2; var arg_500 any; var root_502 any = A_arbace_j2g_dyn_A_const_66.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(); var arg_506 any = lang.PersistentVector_EMPTY.Ref(); if linked_503 == nil { arg_500 = ifn_504.Invoke_O_O__O(arg_505, arg_506) } else { arg_500 = linked_503.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_502, arg_505, arg_506) }; var arg_501 any = t.F_j; if linked_496 == nil { return ifn_497.Invoke_O_O_O_O__O(arg_498, arg_499, arg_500, arg_501) } else { return linked_496.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_495, arg_498, arg_499, arg_500, arg_501) } }

func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Ctor() {}
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Invoke_O_O__O(self, s__711000089__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__605 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(s__711000089__1, self); var tmp2 *jrt.Class; var fncls__604 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class; if fncls__604 == nil { var fncls__604d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__605); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class = fncls__604d; tmp2 = fncls__604d } else { tmp2 = fncls__604 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__605, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :103:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Ctor_O_O(c__s__711000089, c__iter__711000088 any) { t.F_s__711000089 = c__s__711000089; t.F_iter__711000088 = c__iter__711000088 }
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Invoke_O__O(self any) any { { var s__711000089__1 any; var t_ any = t.F_s__711000089; t.F_s__711000089 = nil; s__711000089__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_513 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = s__711000089__1; if linked_514 == nil { temp__1927000414__auto____2 = ifn_515.Invoke_O__O(arg_516) } else { temp__1927000414__auto____2 = linked_514.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_513, arg_516) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_517 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = xs__1927001018__auto____3; if linked_518 == nil { c__4 = ifn_519.Invoke_O__O(arg_520) } else { c__4 = linked_518.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_517, arg_520) }; var iterys__1927001035__auto____5 any; var fnbody__582 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New(); var tmp1 *jrt.Class; var fncls__581 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class; if fncls__581 == nil { var fncls__581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class = fncls__581d; tmp1 = fncls__581d } else { tmp1 = fncls__581 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__582, tmp1, nil); var fs__1927001036__auto____6 any; var root_583 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_587 any = A_arbace_j2g_dyn_A_const_69.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = c__4; if linked_588 == nil { tmp3 = ifn_589.Invoke_O__O(arg_590) } else { tmp3 = linked_588.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_587, arg_590) }; arg_586 = tmp2.Invoke_O__O(tmp3); if linked_584 == nil { fs__1927001036__auto____6 = ifn_585.Invoke_O__O(arg_586) } else { fs__1927001036__auto____6 = linked_584.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_583, arg_586) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_591 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = fs__1927001036__auto____6; var arg_595 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000088); var tmp5 any; var root_596 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = s__711000089__1; if linked_597 == nil { tmp5 = ifn_598.Invoke_O__O(arg_599) } else { tmp5 = linked_597.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_596, arg_599) }; arg_595 = tmp4.Invoke_O__O(tmp5); if linked_592 == nil { return ifn_593.Invoke_O_O__O(arg_594, arg_595) } else { return linked_592.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_591, arg_594, arg_595) } } else { var tmp6 any; var root_600 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = s__711000089__1; if linked_601 == nil { tmp6 = ifn_602.Invoke_O__O(arg_603) } else { tmp6 = linked_601.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_600, arg_603) }; s__711000089__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :103:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Ctor() {}
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Invoke_O_O__O(self, s__711000091__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__580 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(self, s__711000091__1); var tmp2 *jrt.Class; var fncls__579 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class; if fncls__579 == nil { var fncls__579d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__580); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class = fncls__579d; tmp2 = fncls__579d } else { tmp2 = fncls__579 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__580, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :103:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Ctor_O_O(c__iter__711000090, c__s__711000091 any) { t.F_iter__711000090 = c__iter__711000090; t.F_s__711000091 = c__s__711000091 }
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Invoke_O__O(self any) any { { var s__711000091__1 any; var t_ any = t.F_s__711000091; t.F_s__711000091 = nil; s__711000091__1 = t_; for { var temp__1927000414__auto____2 any; var root_521 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = s__711000091__1; if linked_522 == nil { temp__1927000414__auto____2 = ifn_523.Invoke_O__O(arg_524) } else { temp__1927000414__auto____2 = linked_522.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_521, arg_524) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000091__3 any = temp__1927000414__auto____2; var tmp1 any; var root_525 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = s__711000091__3; if linked_526 == nil { tmp1 = ifn_527.Invoke_O__O(arg_528) } else { tmp1 = linked_526.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_525, arg_528) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_529 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = s__711000091__3; if linked_530 == nil { c__1927001037__auto____4 = ifn_531.Invoke_O__O(arg_532) } else { c__1927001037__auto____4 = linked_530.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_529, arg_532) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000093__6 any; var root_533 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_534 == nil { b__711000093__6 = ifn_535.Invoke_O__O(arg_536) } else { b__711000093__6 = linked_534.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_533, arg_536) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__543 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(b__711000093__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__542 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class; if fncls__542 == nil { var fncls__542d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__543); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class = fncls__542d; tmp3 = fncls__542d } else { tmp3 = fncls__542 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__543, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_544 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any; var root_549 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = b__711000093__6; if linked_550 == nil { arg_547 = ifn_551.Invoke_O__O(arg_552) } else { arg_547 = linked_550.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_549, arg_552) }; var arg_548 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp5 any; var root_553 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = s__711000091__3; if linked_554 == nil { tmp5 = ifn_555.Invoke_O__O(arg_556) } else { tmp5 = linked_554.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_553, arg_556) }; arg_548 = tmp4.Invoke_O__O(tmp5); if linked_545 == nil { return ifn_546.Invoke_O_O__O(arg_547, arg_548) } else { return linked_545.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_544, arg_547, arg_548) } } else { var root_557 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any; var root_562 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = b__711000093__6; if linked_563 == nil { arg_560 = ifn_564.Invoke_O__O(arg_565) } else { arg_560 = linked_563.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_562, arg_565) }; var arg_561 any; if linked_558 == nil { return ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { return linked_558.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_557, arg_560, arg_561) } } } else { var mm__4 any; var root_566 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = s__711000091__3; if linked_567 == nil { mm__4 = ifn_568.Invoke_O__O(arg_569) } else { mm__4 = linked_567.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_566, arg_569) }; var root_570 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__4)); var arg_574 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp7 any; var root_575 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = s__711000091__3; if linked_576 == nil { tmp7 = ifn_577.Invoke_O__O(arg_578) } else { tmp7 = linked_576.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_575, arg_578) }; arg_574 = tmp6.Invoke_O__O(tmp7); if linked_571 == nil { return ifn_572.Invoke_O_O__O(arg_573, arg_574) } else { return linked_571.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_570, arg_573, arg_574) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :103:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Ctor_O_I_O(c__b__711000093 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000093 = c__b__711000093; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :103:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Invoke_O__O(self any) any { { var i__711000092__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000092__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000092__1)); var root_537 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = t.F_b__711000093; var arg_541 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__2)); if linked_538 == nil { ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { linked_538.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_537, arg_540, arg_541) }; i__711000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000092__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_dyn_defaults_for_A_New() *A_arbace_j2g_dyn_defaults_for_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Ctor() {}
//line :110:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var cands__3 any; var iter__1927001039__auto____3 any; var fnbody__742 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(k__1); var tmp1 *jrt.Class; var fncls__741 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class; if


	fncls__741 == nil { var fncls__741d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__742); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class = fncls__741d; tmp1 = fncls__741d } else { tmp1 = fncls__741 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__742, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_754 any = A_arbace_j2g_dyn_A_const_80.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, A_arbace_j2g_dyn_declarers_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = ifaces__0; var arg_758 any = k__1; if linked_755 == nil { tmp3 = ifn_756.Invoke_O_O__O(arg_757, arg_758) } else { tmp3 = linked_755.(*A_arbace_j2g_dyn_declarers_A).Invoke_O_O_O__O(root_754, arg_757, arg_758) }; cands__3 = tmp2.Invoke_O__O(tmp3); var root_743 any =



	A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any; var fnbody__753 any = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New(); var tmp4 *jrt.Class; var fncls__752 *jrt.Class = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class; if fncls__752 == nil { var fncls__752d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class = fncls__752d; tmp4 = fncls__752d } else { tmp4 = fncls__752 }; arg_746 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__753, tmp4, nil); var arg_747 any = cands__3; if linked_744 == nil { return ifn_745.Invoke_O_O__O(arg_746, arg_747) } else { return linked_744.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_743, arg_746, arg_747) } }
//line :113:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(p0 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A{}; t.Ctor_O(p0); return t }
//line :113:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :113:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Invoke_O_O__O(self, s__711000108__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__740 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(self, t.F_k, s__711000108__1); var tmp2 *jrt.Class; var fncls__739 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class; if fncls__739 == nil { var fncls__739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__740); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class = fncls__739d; tmp2 = fncls__739d } else { tmp2 = fncls__739 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__740, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :113:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :113:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Ctor_O_O_O(c__iter__711000107, c__k, c__s__711000108 any) { t.F_iter__711000107 = c__iter__711000107; t.F_k = c__k; t.F_s__711000108 = c__s__711000108 }
//line :113:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Invoke_O__O(self any) any { { var s__711000108__1 any; var t_ any = t.F_s__711000108; t.F_s__711000108 = nil; s__711000108__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_621 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = s__711000108__1; if linked_622 == nil { temp__1927000414__auto____2 = ifn_623.Invoke_O__O(arg_624) } else { temp__1927000414__auto____2 = linked_622.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_621, arg_624) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000108__3 any = temp__1927000414__auto____2; var tmp1 any; var root_625 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = s__711000108__3; if linked_626 == nil { tmp1 = ifn_627.Invoke_O__O(arg_628) } else { tmp1 = linked_626.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_625, arg_628) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_629 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = s__711000108__3; if linked_630 == nil { c__1927001037__auto____4 = ifn_631.Invoke_O__O(arg_632) } else { c__1927001037__auto____4 = linked_630.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_629, arg_632) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000110__6 any; var root_633 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_634 == nil { b__711000110__6 = ifn_635.Invoke_O__O(arg_636) } else { b__711000110__6 = linked_634.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_633, arg_636) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__671 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(t.F_k, b__711000110__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__670 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class; if fncls__670 == nil { var fncls__670d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__671); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class = fncls__670d; tmp3 = fncls__670d } else { tmp3 = fncls__670 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__671, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_672 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any; var root_677 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = b__711000110__6; if linked_678 == nil { arg_675 = ifn_679.Invoke_O__O(arg_680) } else { arg_675 = linked_678.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_677, arg_680) }; var arg_676 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp5 any; var root_681 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = s__711000108__3; if linked_682 == nil { tmp5 = ifn_683.Invoke_O__O(arg_684) } else { tmp5 = linked_682.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_681, arg_684) }; arg_676 = tmp4.Invoke_O__O(tmp5); if linked_673 == nil { return ifn_674.Invoke_O_O__O(arg_675, arg_676) } else { return linked_673.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_672, arg_675, arg_676) } } else { var root_685 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any; var root_690 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = b__711000110__6; if linked_691 == nil { arg_688 = ifn_692.Invoke_O__O(arg_693) } else { arg_688 = linked_691.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_690, arg_693) }; var arg_689 any; if linked_686 == nil { return ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { return linked_686.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_685, arg_688, arg_689) } } } else { var j__4 any; var root_694 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = s__711000108__3; if linked_695 == nil { j__4 = ifn_696.Invoke_O__O(arg_697) } else { j__4 = linked_695.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_694, arg_697) }; var impl__5 any; var root_698 any = A_arbace_j2g_dyn_A_const_71.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_700 lang.IFn
														if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = j__4; var arg_702 any = t.F_k; if linked_699 == nil { impl__5 = ifn_700.Invoke_O_O__O(arg_701, arg_702) } else { impl__5 = linked_699.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_698, arg_701, arg_702) }
//line :113:1
	var tmp6 any
	var and__1927000168__auto____6 any = impl__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp7 any = A_arbace_j2g_dyn_A_const_72; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_j2g_dyn_A_const_73.Invoke_O__O(impl__5)); if and__1927000168__auto____7 { var root_703 any = A_arbace_j2g_dyn_A_const_33.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = A_arbace_j2g_dyn_A_const_74.Invoke_O__O(impl__5); if linked_704 == nil { tmp6 = ifn_705.Invoke_O__O(arg_706) } else { tmp6 = linked_704.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_703, arg_706) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = and__1927000168__auto____6 }
//line :113:1
	if jrt.J2g_Truth(tmp6) { var root_707 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any; var tmp8 any; var root_712 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_714 lang.IFn


		if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = A_arbace_j2g_dyn_A_const_76; var arg_716 any = A_arbace_j2g_dyn_A_const_74.Invoke_O__O(impl__5); var arg_717 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp10 any; var root_718 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any; var root_723 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = t.F_k; if linked_724 == nil { arg_721 = ifn_725.Invoke_O__O(arg_726) } else { arg_721 = linked_724.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_723, arg_726) }; var arg_722 any; var root_727 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = t.F_k; if linked_728 == nil { arg_722 = ifn_729.Invoke_O__O(arg_730) } else { arg_722 = linked_728.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_727, arg_730) }; if linked_719 == nil { tmp10 = ifn_720.Invoke_O_O__O(arg_721, arg_722) } else { tmp10 = linked_719.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_718, arg_721, arg_722) }; arg_717 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_713 == nil { tmp8 = ifn_714.Invoke_O_O_O__O(arg_715, arg_716, arg_717) } else { tmp8 = linked_713.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_712, arg_715, arg_716, arg_717) }
//line :113:1
		arg_710 = lang.Tuple_Create_O_O__IPersistentVector(j__4, tmp8); var arg_711 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp12 any; var root_731 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = s__711000108__3; if linked_732 == nil { tmp12 = ifn_733.Invoke_O__O(arg_734) } else { tmp12 = linked_732.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_731, arg_734) }; arg_711 = tmp11.Invoke_O__O(tmp12); if linked_708 == nil { return ifn_709.Invoke_O_O__O(arg_710, arg_711) } else { return linked_708.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_707, arg_710, arg_711) } } else { var tmp13 any; var root_735 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = s__711000108__3; if linked_736 == nil { tmp13 = ifn_737.Invoke_O__O(arg_738) } else { tmp13 = linked_736.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_735, arg_738) }; s__711000108__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :113:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :113:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Ctor_O_O_I_O(c__k, c__b__711000110 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_b__711000110 = c__b__711000110; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :113:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Invoke_O__O(self any) any { { var i__711000109__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000109__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000109__1)); var impl__3 any; var root_637 any = A_arbace_j2g_dyn_A_const_71.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_639 lang.IFn
																if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = j__2; var arg_641 any = t.F_k; if linked_638 == nil { impl__3 = ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { impl__3 = linked_638.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) }
//line :113:1
	var tmp2 any
	var and__1927000168__auto____4 any = impl__3
	if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp3 any = A_arbace_j2g_dyn_A_const_72; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_dyn_A_const_73.Invoke_O__O(impl__3)); if and__1927000168__auto____5 { var root_642 any = A_arbace_j2g_dyn_A_const_33.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = A_arbace_j2g_dyn_A_const_74.Invoke_O__O(impl__3); if linked_643 == nil { tmp2 = ifn_644.Invoke_O__O(arg_645) } else { tmp2 = linked_643.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_642, arg_645) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = and__1927000168__auto____4 }
//line :113:1
	if jrt.J2g_Truth(tmp2) { var root_646 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = t.F_b__711000110; var arg_650 any; var tmp4 any; var root_651 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_653 lang.IFn


		if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = A_arbace_j2g_dyn_A_const_76; var arg_655 any = A_arbace_j2g_dyn_A_const_74.Invoke_O__O(impl__3); var arg_656 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp6 any; var root_657 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any; var root_662 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = t.F_k; if linked_663 == nil { arg_660 = ifn_664.Invoke_O__O(arg_665) } else { arg_660 = linked_663.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_662, arg_665) }; var arg_661 any; var root_666 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = t.F_k; if linked_667 == nil { arg_661 = ifn_668.Invoke_O__O(arg_669) } else { arg_661 = linked_667.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_666, arg_669) }; if linked_658 == nil { tmp6 = ifn_659.Invoke_O_O__O(arg_660, arg_661) } else { tmp6 = linked_658.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_657, arg_660, arg_661) }; arg_656 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_652 == nil { tmp4 = ifn_653.Invoke_O_O_O__O(arg_654, arg_655, arg_656) } else { tmp4 = linked_652.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_651, arg_654, arg_655, arg_656) }
//line :113:1
		arg_650 = lang.Tuple_Create_O_O__IPersistentVector(j__2, tmp4); if linked_647 == nil { ifn_648.Invoke_O_O__O(arg_649, arg_650) } else { linked_647.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_646, arg_649, arg_650) }; i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } else { i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New() *A_arbace_j2g_dyn_defaults_for_fn__711000118_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_fn__711000118_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Ctor() {}
//line :117:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Invoke_O_O__O(self, p__711000117__1 any) any { var vec__711000119__2 any = p__711000117__1; var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000119__2, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_748 any = A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = j__3; if linked_749 == nil { tmp1 = ifn_750.Invoke_O__O(arg_751) } else { tmp1 = linked_749.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_748, arg_751) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp1)))).Ref() }

func A_arbace_j2g_dyn_box_arg_A_New() *A_arbace_j2g_dyn_box_arg_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_box_arg_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_j2g_dyn_box_arg_A) Ctor() {}
//line :119:1
func (t *A_arbace_j2g_dyn_box_arg_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {


	var tmp1 any; var root_759 any = A_arbace_j2g_dyn_A_const_81.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = d__1; if linked_760 == nil { tmp1 = ifn_761.Invoke_O__O(arg_762) } else { tmp1 = linked_760.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_759, arg_762) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_85, p__0) } else { var tmp2 any; var root_763 any = A_arbace_j2g_dyn_A_const_83.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_765 lang.IFn
		if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = d__1; if linked_764 == nil { tmp2 = ifn_765.Invoke_O__O(arg_766) } else { tmp2 = linked_764.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_763, arg_766) }
//line :122:1
		if jrt.J2g_Truth(tmp2) {
			return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_86, p__0) } else {
//line :122:1
				if A_arbace_j2g_dyn_A_const_84 != nil { return p__0 } else { return nil
				}
			}
	} }
func A_arbace_j2g_dyn_convert_result_A_New() *A_arbace_j2g_dyn_convert_result_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_j2g_dyn_convert_result_A) Ctor() {}
//line :126:1
func (t *A_arbace_j2g_dyn_convert_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_12) { return r__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_30.GetRawRoot__O()).Invoke_O__O(d__1)) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp2 any; var root_822 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = A_arbace_j2g_dyn_A_const_76; var arg_826 any = Lit_18; var arg_827 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp4 any; var root_828 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_30.GetRawRoot__O()).Invoke_O__O(d__1); var arg_832 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref(); if linked_829 == nil { tmp4 = ifn_830.Invoke_O_O__O(arg_831, arg_832) } else { tmp4 = linked_829.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_828, arg_831, arg_832) }; arg_827 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_823 == nil { tmp2 = ifn_824.Invoke_O_O_O__O(arg_825, arg_826, arg_827) } else { tmp2 = linked_823.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_822, arg_825, arg_826, arg_827) }; return tmp1.Invoke_O_O__O(tmp2, r__0) } else {
//line :129:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_87).Invoke_O__O(d__1)) {


				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_97; var tmp7 any; var root_833 any = A_arbace_j2g_dyn_A_const_98.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any = A_arbace_j2g_dyn_A_const_76; var arg_837 any = d__1; if linked_834 == nil { tmp7 = ifn_835.Invoke_O_O__O(arg_836, arg_837) } else { tmp7 = linked_834.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_833, arg_836, arg_837) }; var tmp8 any = tmp7; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_99; var tmp11 any
				if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_20) { tmp11 = A_arbace_j2g_dyn_A_const_100 } else { tmp11 = A_arbace_j2g_dyn_A_const_101 }
//line :132:1
				return tmp5.Invoke_O_O_O__O(tmp6, tmp8, tmp9.Invoke_O_O_O__O(tmp10, tmp11, r__0)) } else {
//line :129:1
					var tmp12 any; var root_767 any = A_arbace_j2g_dyn_A_const_88.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_769 lang.IFn




					if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = d__1; if linked_768 == nil { tmp12 = ifn_769.Invoke_O__O(arg_770) } else { tmp12 = linked_768.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_767, arg_770) }
//line :129:1
					if jrt.J2g_Truth(tmp12) {




						var root_771 any = A_arbace_j2g_dyn_A_const_89.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = A_arbace_j2g_dyn_A_const_76; var arg_775 any = A_arbace_j2g_dyn_A_const_90; var arg_776 any = r__0; var arg_777 any = d__1; var arg_778 any; var e__3 any; var root_779 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_781 lang.IFn
						if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = d__1; if linked_780 == nil { e__3 = ifn_781.Invoke_O__O(arg_782) } else { e__3 = linked_780.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_779, arg_782) }
						var tmp13 any; var root_783 any = A_arbace_j2g_dyn_A_const_81.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = e__3; if linked_784 == nil { tmp13 = ifn_785.Invoke_O__O(arg_786) } else { tmp13 = linked_784.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_783, arg_786) }; if jrt.J2g_Truth(tmp13) { arg_778 = nil } else {
							var tmp14 *lang.Compiler_AOTFn; var fnbody__821 any = A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(e__3); var tmp15 *jrt.Class; var fncls__820 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class; if fncls__820 == nil { var fncls__820d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__821); A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class = fncls__820d; tmp15 = fncls__820d } else { tmp15 = fncls__820 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__821, tmp15, nil); arg_778 = Up_Compiler_AOTFn_IFn(tmp14).Invoke__O() }
//line :134:1
						if linked_772 == nil { return ifn_773.Invoke_O_O_O_O_O__O(arg_774, arg_775, arg_776, arg_777, arg_778) } else { return linked_772.(*aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A).Invoke_O_O_O_O_O_O__O(root_771, arg_774, arg_775, arg_776, arg_777, arg_778) } } else {
//line :129:1
							if A_arbace_j2g_dyn_A_const_84 != nil {












								var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp17 any; var root_838 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = A_arbace_j2g_dyn_A_const_76; var arg_842 any; var root_844 any = A_arbace_j2g_dyn_A_const_96.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = d__1; if linked_845 == nil { arg_842 = ifn_846.Invoke_O__O(arg_847) } else { arg_842 = linked_845.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_844, arg_847) }; var arg_843 any = Lit_22; if linked_839 == nil { tmp17 = ifn_840.Invoke_O_O_O__O(arg_841, arg_842, arg_843) } else { tmp17 = linked_839.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_838, arg_841, arg_842, arg_843) }; return tmp16.Invoke_O_O__O(tmp17, r__0) } else {
//line :129:1
									return nil
								}
						}
				}
		}
	}
}

func A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(p0 any) *A_arbace_j2g_dyn_convert_result_fn__711000126_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :137:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Invoke_O__O(self any) any { { var e__1 any; var t_ any = t.F_e; t.F_e = nil; e__1 = t_; var n__2 int64 = 0; L1: for { var tmp1 any; var root_787 any = A_arbace_j2g_dyn_A_const_88.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = e__1; if linked_788 == nil { tmp1 = ifn_789.Invoke_O__O(arg_790) } else { tmp1 = linked_788.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_787, arg_790) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_816 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = e__1; if linked_817 == nil { tmp2 = ifn_818.Invoke_O__O(arg_819) } else { tmp2 = linked_817.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_816, arg_819) }; e__1, n__2 = tmp2, lang.Numbers_Inc_J__J_NoInit(n__2); continue L1 } else {
											var tmp3 any; var root_791 any = A_arbace_j2g_dyn_A_const_92.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any; var fnbody__797 any = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New(); var tmp4 *jrt.Class; var fncls__796 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class; if fncls__796 == nil { var fncls__796d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class = fncls__796d; tmp4 = fncls__796d } else { tmp4 = fncls__796 }; arg_794 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__797, tmp4, nil); var arg_795 any; var tmp5 any; var root_798 any = A_arbace_j2g_dyn_A_const_81.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = e__1; if linked_799 == nil { tmp5 = ifn_800.Invoke_O__O(arg_801) } else { tmp5 = linked_799.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_798, arg_801) }; if jrt.J2g_Truth(tmp5) {
												var root_802 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_95.GetRawRoot__O()).Invoke_O__O(e__1))).Ref(); if linked_803 == nil { arg_795 = ifn_804.Invoke_O__O(arg_805) } else { arg_795 = linked_803.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_802, arg_805) } } else {
													var root_806 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = A_arbace_j2g_dyn_A_const_76; var arg_810 any; var root_812 any = A_arbace_j2g_dyn_A_const_96.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = e__1; if linked_813 == nil { arg_810 = ifn_814.Invoke_O__O(arg_815) } else { arg_810 = linked_813.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_812, arg_815) }; var arg_811 any = Lit_25; if linked_807 == nil { arg_795 = ifn_808.Invoke_O_O_O__O(arg_809, arg_810, arg_811) } else { arg_795 = linked_807.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_806, arg_809, arg_810, arg_811) } }
//line :138:1
	if linked_792 == nil { tmp3 = ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { tmp3 = linked_792.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_791, arg_794, arg_795) }; return lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(n__2)) } } }; /*line :137:1*/panic("j2g: unreachable") }
func A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New() *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Ctor() {}
//line :138:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Invoke_O_O__O(self, p1__711000125_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_93, p1__711000125_SHARP___1) }





func A_arbace_j2g_dyn_call_impl_A_New() *A_arbace_j2g_dyn_call_impl_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_call_impl_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_j2g_dyn_call_impl_A) Ctor() {}
//line :144:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O_O__O(self, this__0, args__1 any) any { var n__3 int64 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(args__1))); if





	lang.Numbers_Lte_J_J__Z_NoInit(n__3, 20) {
		var root_848 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_852 any; var root_856 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp2 any; var root_860 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = Lit_11; var arg_864 any; var root_865 any = A_arbace_j2g_dyn_A_const_103.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any; var root_870 any = A_arbace_j2g_dyn_A_const_104.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref(); var arg_874 any = Lit_12; if linked_871 == nil { arg_868 = ifn_872.Invoke_O_O__O(arg_873, arg_874) } else { arg_868 = linked_871.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_870, arg_873, arg_874) }; var arg_869 any = Lit_12; if linked_866 == nil { arg_864 = ifn_867.Invoke_O_O__O(arg_868, arg_869) } else { arg_864 = linked_866.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_865, arg_868, arg_869) }; if linked_861 == nil { tmp2 = ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { tmp2 = linked_861.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) }; arg_859 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_857 == nil { arg_852 = ifn_858.Invoke_O__O(arg_859) } else { arg_852 = linked_857.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_856, arg_859) }; var arg_853 any = A_arbace_j2g_dyn_A_const_105; var arg_854 any = this__0; var arg_855 any = args__1; if linked_849 == nil { return ifn_850.Invoke_O_O_O_O_O__O(arg_851, arg_852, arg_853, arg_854, arg_855) } else { return linked_849.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_848, arg_851, arg_852, arg_853, arg_854, arg_855) } } else {

			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyn_A_const_106; var tmp5 any = A_arbace_j2g_dyn_A_const_107; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_108; var tmp8 any; var root_875 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_879 any = A_arbace_j2g_dyn_A_const_109; var arg_880 any = A_arbace_j2g_dyn_A_const_110; var arg_881 any = this__0; var arg_882 any = args__1; if linked_876 == nil { tmp8 = ifn_877.Invoke_O_O_O_O_O__O(arg_878, arg_879, arg_880, arg_881, arg_882) } else { tmp8 = linked_876.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_875, arg_878, arg_879, arg_880, arg_881, arg_882) }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8)) } }
//line :144:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O__O(self, args__0 any) any {


	var root_883 any = A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = A_arbace_j2g_dyn_A_const_112; var arg_887 any = args__0; if linked_884 == nil { return ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { return linked_884.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_883, arg_886, arg_887)
	}
}







func A_arbace_j2g_dyn_abstract_text_A_New() *A_arbace_j2g_dyn_abstract_text_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Ctor() {}
//line :157:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Invoke_O_O_O__O(self, ifaces__0, p__711000134__1 any) any { var vec__711000135__3 any = p__711000134__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000135__3; var vec__711000138__7 any; var root_888 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_890 lang.IFn; if



	linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = desc__5; if linked_889 == nil { vec__711000138__7 = ifn_890.Invoke_O__O(arg_891) } else { vec__711000138__7 = linked_889.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_888, arg_891) }; var ps__8 any = /*line :157:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(1), nil); var declares_QMARK___10 any; var fnbody__904 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(name__4, desc__5); var tmp1 *jrt.Class; var fncls__903 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class; if




	fncls__903 == nil { var fncls__903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__904); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class = fncls__903d; tmp1 = fncls__903d } else { tmp1 = fncls__903 }; declares_QMARK___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__904, tmp1, nil); var j__11 any; var or__1927000174__auto____11 any; var root_905 any = /*line :157:1*/A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_907 lang.IFn; if





	linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any; var root_909 any = A_arbace_j2g_dyn_A_const_38.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = declares_QMARK___10; var arg_913 any = ifaces__0; if linked_910 == nil { arg_908 = ifn_911.Invoke_O_O__O(arg_912, arg_913) } else { arg_908 = linked_910.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_909, arg_912, arg_913) }; if linked_906 == nil { or__1927000174__auto____11 = ifn_907.Invoke_O__O(arg_908) } else { or__1927000174__auto____11 = linked_906.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_905, arg_908) }; if jrt.J2g_Truth(or__1927000174__auto____11) { j__11 = or__1927000174__auto____11 } else {
		var root_914 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any; var root_918 any = A_arbace_j2g_dyn_A_const_38.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any; var fnbody__935 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(k__6); var tmp2 *jrt.Class; var fncls__934 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class; if fncls__934 == nil { var fncls__934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__935); A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class = fncls__934d; tmp2 = fncls__934d } else { tmp2 = fncls__934 }; arg_921 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__935, tmp2, nil); var arg_922 any = ifaces__0; if linked_919 == nil { arg_917 = ifn_920.Invoke_O_O__O(arg_921, arg_922) } else { arg_917 = linked_919.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_918, arg_921, arg_922) }; if linked_915 == nil { j__11 = ifn_916.Invoke_O__O(arg_917) } else { j__11 = linked_915.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_914, arg_917) } }; var tmp3 /*line :165:1*/*jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp4 any; var root_936 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = r__9; if linked_937 == nil { tmp4 = ifn_938.Invoke_O__O(arg_939) } else { tmp4 = linked_937.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_936, arg_939) }; var tmp5 any = tmp4; var tmp6 any; var root_940 any = A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = Lit_3; var arg_944 any; var root_945 any = A_arbace_j2g_dyn_A_const_118.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var arg_949 any = ps__8; if linked_946 == nil { arg_944 = ifn_947.Invoke_O_O__O(arg_948, arg_949) } else { arg_944 = linked_946.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_945, arg_948, arg_949) }; if linked_941 == nil { tmp6 = ifn_942.Invoke_O_O__O(arg_943, arg_944) } else { tmp6 = linked_941.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_940, arg_943, arg_944) }; var tmp7 any = tmp6; var tmp8 *jrt.String; if
	jrt.J2g_Truth(j__11) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil); var tmp10 any; var root_950 any = A_arbace_j2g_dyn_A_const_119.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = j__11; var arg_954 any = Lit_5; var arg_955 any = Lit_6; if linked_951 == nil { tmp10 = ifn_952.Invoke_O_O_O__O(arg_953, arg_954, arg_955) } else { tmp10 = linked_951.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_950, arg_953, arg_954, arg_955) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)) } else { tmp8 = nil }; return /*line :165:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, name__4, nil, tmp7, nil, tmp8.Ref(), nil)).Ref() }
//line :162:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A{}; t.Ctor_O_O(p0, p1); return t }
//line :162:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :162:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Invoke_O_O__O(self, j__1 any) any { var root_892 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any; var fnbody__898 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(t.F_name, t.F_desc); var tmp1 *jrt.Class; var fncls__897 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class; if fncls__897 == nil { var fncls__897d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__898); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class = fncls__897d; tmp1 = fncls__897d } else { tmp1 = fncls__897 }; arg_895 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__898, tmp1, nil); var arg_896 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_115; var tmp3 any; var root_899 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = j__1; if linked_900 == nil { tmp3 = ifn_901.Invoke_O__O(arg_902) } else { tmp3 = linked_900.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_899, arg_902) }; arg_896 = tmp2.Invoke_O__O(tmp3); if linked_893 == nil { return ifn_894.Invoke_O_O__O(arg_895, arg_896) } else { return linked_893.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_892, arg_895, arg_896) } }
//line :162:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :162:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :162:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Invoke_O_O__O(self, p1__711000132_SHARP___1 any) any { var tmp1 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_dyn_A_const_67.Invoke_O__O(p1__711000132_SHARP___1)); if and__1927000168__auto____2 { var tmp2 any = t.F_desc; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_dyn_A_const_68.Invoke_O__O(p1__711000132_SHARP___1))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_A{}; t.Ctor_O(p0); return t }
//line :164:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :164:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Invoke_O_O__O(self, p1__711000133_SHARP___1 any) any { var root_923 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any; var fnbody__929 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(t.F_k); var tmp1 *jrt.Class; var fncls__928 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class; if fncls__928 == nil { var fncls__928d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__929); A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class = fncls__928d; tmp1 = fncls__928d } else { tmp1 = fncls__928 }; arg_926 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__929, tmp1, nil); var arg_927 any; var root_930 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = p1__711000133_SHARP___1; if linked_931 == nil { arg_927 = ifn_932.Invoke_O__O(arg_933) } else { arg_927 = linked_931.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_930, arg_933) }; if linked_924 == nil { return ifn_925.Invoke_O_O__O(arg_926, arg_927) } else { return linked_924.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_923, arg_926, arg_927) } }
//line :164:1
func A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A{}; t.Ctor_O(p0); return t }
//line :164:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :164:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Invoke_O_O__O(self, p__711000146__1 any) any { var vec__711000148__2 any = p__711000146__1; var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(kk__3, t.F_k)).Ref() }



func A_arbace_j2g_dyn_iface_fallback_A_New() *A_arbace_j2g_dyn_iface_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Ctor() {}
//line :168:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O_O__O(self, ifaces__0, p__711000154__1, pn__2, r__3, core_QMARK___4 any) any { var vec__711000155__6 any = p__711000154__1; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000155__6; var root_956 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_958 lang.IFn; _ = name__7; _ = desc__8; if





	linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any; var iter__1927001039__auto____10 any; var fnbody__1072 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(r__3, pn__2, core_QMARK___4); var tmp1 *jrt.Class; var fncls__1071 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class; if
	fncls__1071 == nil { var fncls__1071d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__1072); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class = fncls__1071d; tmp1 = fncls__1071d } else { tmp1 = fncls__1071 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1072, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp3 any; var root_1073 any = A_arbace_j2g_dyn_A_const_131.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, A_arbace_j2g_dyn_defaults_for_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = ifaces__0; var arg_1077 any = k__9; if linked_1074 == nil { tmp3 = ifn_1075.Invoke_O_O__O(arg_1076, arg_1077) } else { tmp3 = linked_1074.(*A_arbace_j2g_dyn_defaults_for_A).Invoke_O_O_O__O(root_1073, arg_1076, arg_1077) }; arg_959 = tmp2.Invoke_O__O(tmp3); var arg_960 any; var tmp4 lang.IFn = /*line :174:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_132; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_133; var tmp8 any = A_arbace_j2g_dyn_A_const_134; var tmp9 any; var root_1078 any = A_arbace_j2g_dyn_A_const_135.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, A_arbace_j2g_dyn_abstract_text_A_fn_class); var ifn_1080 lang.IFn; if




	linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = ifaces__0; var arg_1082 any = k__9; if linked_1079 == nil { tmp9 = ifn_1080.Invoke_O_O__O(arg_1081, arg_1082) } else { tmp9 = linked_1079.(*A_arbace_j2g_dyn_abstract_text_A).Invoke_O_O_O__O(root_1078, arg_1081, arg_1082) }; arg_960 = /*line :174:1*/lang.Tuple_Create_O__IPersistentVector(tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9))); if linked_957 == nil { return ifn_958.Invoke_O_O__O(arg_959, arg_960) } else { return linked_957.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_956, arg_959, arg_960) } }
//line :168:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O__O(self, ifaces__0, k__1, pn__2, r__3 any) any {



	var root_1083 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = ifaces__0; var arg_1087 any = k__1; var arg_1088 any = pn__2; var arg_1089 any = r__3; var arg_1090 any = jrt.Boolean_FALSE.Ref(); if linked_1084 == nil { return ifn_1085.Invoke_O_O_O_O_O__O(arg_1086, arg_1087, arg_1088, arg_1089, arg_1090) } else { return linked_1084.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1083, arg_1086, arg_1087, arg_1088, arg_1089, arg_1090)
	}
}
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :175:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Ctor_O_O_O(c__r, c__pn, c__core_QMARK_ any) { t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :175:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Invoke_O_O__O(self, s__711000159__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1070 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(self, s__711000159__1, t.F_r, t.F_pn, t.F_core_QMARK_); var tmp2 *jrt.Class; var fncls__1069 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class; if fncls__1069 == nil { var fncls__1069d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__1070); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class = fncls__1069d; tmp2 = fncls__1069d } else { tmp2 = fncls__1069 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1070, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :175:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :175:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Ctor_O_O_O_O_O(c__iter__711000158, c__s__711000159, c__r, c__pn, c__core_QMARK_ any) { t.F_iter__711000158 = c__iter__711000158; t.F_s__711000159 = c__s__711000159; t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :175:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Invoke_O__O(self any) any { { var s__711000159__1 any; var t_ any = t.F_s__711000159; t.F_s__711000159 = nil; s__711000159__1 = t_; for { var temp__1927000414__auto____2 any; var root_961 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = s__711000159__1; if linked_962 == nil { temp__1927000414__auto____2 = ifn_963.Invoke_O__O(arg_964) } else { temp__1927000414__auto____2 = linked_962.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_961, arg_964) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000159__3 any = temp__1927000414__auto____2; var tmp1 any; var root_965 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = s__711000159__3; if linked_966 == nil { tmp1 = ifn_967.Invoke_O__O(arg_968) } else { tmp1 = linked_966.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_965, arg_968) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_969 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = s__711000159__3; if linked_970 == nil { c__1927001037__auto____4 = ifn_971.Invoke_O__O(arg_972) } else { c__1927001037__auto____4 = linked_970.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_969, arg_972) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000161__6 any; var root_973 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_974 == nil { b__711000161__6 = ifn_975.Invoke_O__O(arg_976) } else { b__711000161__6 = linked_974.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_973, arg_976) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1008 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(b__711000161__6, t.F_r, t.F_pn, size__1927001038__auto____5, t.F_core_QMARK_, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1007 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class; if fncls__1007 == nil { var fncls__1007d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__1008); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class = fncls__1007d; tmp3 = fncls__1007d } else { tmp3 = fncls__1007 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1008, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1009 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any; var root_1014 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = b__711000161__6; if linked_1015 == nil { arg_1012 = ifn_1016.Invoke_O__O(arg_1017) } else { arg_1012 = linked_1015.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1014, arg_1017) }; var arg_1013 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp5 any; var root_1018 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = s__711000159__3; if linked_1019 == nil { tmp5 = ifn_1020.Invoke_O__O(arg_1021) } else { tmp5 = linked_1019.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1018, arg_1021) }; arg_1013 = tmp4.Invoke_O__O(tmp5); if linked_1010 == nil { return ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { return linked_1010.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) } } else { var root_1022 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any; var root_1027 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = b__711000161__6; if linked_1028 == nil { arg_1025 = ifn_1029.Invoke_O__O(arg_1030) } else { arg_1025 = linked_1028.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1027, arg_1030) }; var arg_1026 any; if linked_1023 == nil { return ifn_1024.Invoke_O_O__O(arg_1025, arg_1026) } else { return linked_1023.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1022, arg_1025, arg_1026) } } } else { var vec__711000169__4 any; var root_1031 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = s__711000159__3; if linked_1032 == nil { vec__711000169__4 = ifn_1033.Invoke_O__O(arg_1034) } else { vec__711000169__4 = linked_1032.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1031, arg_1034) }; var j__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(1), nil); var this__7 any
														if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_121; var tmp8 any; var root_1064 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = A_arbace_j2g_dyn_A_const_76; var arg_1068 any = j__5; if linked_1065 == nil { tmp8 = ifn_1066.Invoke_O_O__O(arg_1067, arg_1068) } else { tmp8 = linked_1065.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_1064, arg_1067, arg_1068) }; this__7 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, A_arbace_j2g_dyn_A_const_130) } else { this__7 = A_arbace_j2g_dyn_A_const_120 }
//line :175:1
	var root_1035 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_123; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyn_A_const_124; var tmp13 any = A_arbace_j2g_dyn_A_const_125; var tmp14 any; var root_1040 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1042 lang.IFn

	if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = A_arbace_j2g_dyn_A_const_76; var arg_1044 any = j__5; var arg_1045 any = Lit_25; if linked_1041 == nil { tmp14 = ifn_1042.Invoke_O_O_O__O(arg_1043, arg_1044, arg_1045) } else { tmp14 = linked_1041.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1040, arg_1043, arg_1044, arg_1045) }; var tmp15 any = tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14); var tmp16 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_17, t.F_r) { var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_126; var tmp19 any; var root_1046 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1050 any = fsym__6; var arg_1051 any = this__7; var arg_1052 any = t.F_pn; if linked_1047 == nil { tmp19 = ifn_1048.Invoke_O_O_O_O__O(arg_1049, arg_1050, arg_1051, arg_1052) } else { tmp19 = linked_1047.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1046, arg_1049, arg_1050, arg_1051, arg_1052) }; tmp16 = tmp17.Invoke_O_O_O__O(tmp18, tmp19, A_arbace_j2g_dyn_A_const_129) } else { var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyn_A_const_128; var tmp22 any; var root_1053 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1057 any = fsym__6; var arg_1058 any = this__7; var arg_1059 any = t.F_pn; if linked_1054 == nil { tmp22 = ifn_1055.Invoke_O_O_O_O__O(arg_1056, arg_1057, arg_1058, arg_1059) } else { tmp22 = linked_1054.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1053, arg_1056, arg_1057, arg_1058, arg_1059) }; tmp16 = tmp20.Invoke_O_O__O(tmp21, tmp22) }
//line :177:1
	arg_1038 = tmp9.Invoke_O_O_O__O(tmp10, tmp15, tmp16)
//line :175:1
	var arg_1039 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp24 any; var root_1060 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = s__711000159__3; if linked_1061 == nil { tmp24 = ifn_1062.Invoke_O__O(arg_1063) } else { tmp24 = linked_1061.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1060, arg_1063) }; arg_1039 = tmp23.Invoke_O__O(tmp24); if linked_1036 == nil { return ifn_1037.Invoke_O_O__O(arg_1038, arg_1039) } else { return linked_1036.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1035, arg_1038, arg_1039) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :175:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :175:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Ctor_O_O_O_I_O_O(c__b__711000161, c__r, c__pn any, c__size__1927001038__auto__ int32, c__core_QMARK_, c__c__1927001037__auto__ any) { t.F_b__711000161 = c__b__711000161; t.F_r = c__r; t.F_pn = c__pn; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_core_QMARK_ = c__core_QMARK_; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :175:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Invoke_O__O(self any) any { { var i__711000160__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000160__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000165__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000160__1)); var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(1), nil); var this__5 any
																if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_121; var tmp4 any; var root_977 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = A_arbace_j2g_dyn_A_const_76; var arg_981 any = j__3; if linked_978 == nil { tmp4 = ifn_979.Invoke_O_O__O(arg_980, arg_981) } else { tmp4 = linked_978.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_977, arg_980, arg_981) }; this__5 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_j2g_dyn_A_const_122) } else { this__5 = A_arbace_j2g_dyn_A_const_120 }
//line :175:1
	var root_982 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = t.F_b__711000161; var arg_986 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_123; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_124; var tmp9 any = A_arbace_j2g_dyn_A_const_125; var tmp10 any; var root_987 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_989 lang.IFn

	if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any = A_arbace_j2g_dyn_A_const_76; var arg_991 any = j__3; var arg_992 any = Lit_25; if linked_988 == nil { tmp10 = ifn_989.Invoke_O_O_O__O(arg_990, arg_991, arg_992) } else { tmp10 = linked_988.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_987, arg_990, arg_991, arg_992) }; var tmp11 any = tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10); var tmp12 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_17, t.F_r) { var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyn_A_const_126; var tmp15 any; var root_993 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_997 any = fsym__4; var arg_998 any = this__5; var arg_999 any = t.F_pn; if linked_994 == nil { tmp15 = ifn_995.Invoke_O_O_O_O__O(arg_996, arg_997, arg_998, arg_999) } else { tmp15 = linked_994.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_993, arg_996, arg_997, arg_998, arg_999) }; tmp12 = tmp13.Invoke_O_O_O__O(tmp14, tmp15, A_arbace_j2g_dyn_A_const_127) } else { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_128; var tmp18 any; var root_1000 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1004 any = fsym__4; var arg_1005 any = this__5; var arg_1006 any = t.F_pn; if linked_1001 == nil { tmp18 = ifn_1002.Invoke_O_O_O_O__O(arg_1003, arg_1004, arg_1005, arg_1006) } else { tmp18 = linked_1001.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1000, arg_1003, arg_1004, arg_1005, arg_1006) }; tmp12 = tmp16.Invoke_O_O__O(tmp17, tmp18) }
//line :177:1
	arg_986 = tmp5.Invoke_O_O_O__O(tmp6, tmp11, tmp12)
//line :175:1
	if linked_983 == nil { ifn_984.Invoke_O_O__O(arg_985, arg_986) } else { linked_983.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_982, arg_985, arg_986) }; i__711000160__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000160__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyn_method_form_A_New() *A_arbace_j2g_dyn_method_form_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_j2g_dyn_method_form_A) Ctor() {}
//line :181:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O_O__O(self, recv__0, i__1, p__711000177__2, fallback__3, this__4 any) any { var vec__711000180__6 any = p__711000177__2; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000180__6; var vec__711000183__10 any; var root_1091 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1093 lang.IFn; _ = k__9; if






	linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = desc__8; if linked_1092 == nil { vec__711000183__10 = ifn_1093.Invoke_O__O(arg_1094) } else { vec__711000183__10 = linked_1092.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1091, arg_1094) }; var ps__11 any = /*line :181:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_1095 any = A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1097 lang.IFn; if







	linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any; var iter__1927001039__auto____13 any; var fnbody__1168 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New(); var tmp1 *jrt.Class; var fncls__1167 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class; if fncls__1167 == nil { var fncls__1167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class = fncls__1167d; tmp1 = fncls__1167d } else { tmp1 = fncls__1167 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1168, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp3 any; var root_1169 any = A_arbace_j2g_dyn_A_const_137.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__11)).Ref(); if linked_1170 == nil { tmp3 = ifn_1171.Invoke_O__O(arg_1172) } else { tmp3 = linked_1170.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1169, arg_1172) }; arg_1098 = tmp2.Invoke_O__O(tmp3); if linked_1096 == nil { pn__13 = ifn_1097.Invoke_O__O(arg_1098) } else { pn__13 = linked_1096.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1095, arg_1098) }; var base__14 any; var root_1173 any = /*line :181:1*/A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1175 lang.IFn; if








	linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = name__7; var arg_1177 any = desc__8; if linked_1174 == nil { base__14 = ifn_1175.Invoke_O_O__O(arg_1176, arg_1177) } else { base__14 = linked_1174.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1173, arg_1176, arg_1177) }; var params__15 any; var root_1178 any = /*line :181:1*/A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1180 lang.IFn; if









	linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any; var root_1182 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any; var root_1187 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = A_arbace_j2g_dyn_A_const_139; var arg_1191 any = recv__0; if linked_1188 == nil { arg_1185 = ifn_1189.Invoke_O_O__O(arg_1190, arg_1191) } else { arg_1185 = linked_1188.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1187, arg_1190, arg_1191) }; var arg_1186 any; var root_1192 any = A_arbace_j2g_dyn_A_const_118.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any; var fnbody__1209 any = A_arbace_j2g_dyn_method_form_fn__711000196_A_New(); var tmp4 *jrt.Class; var fncls__1208 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class; if fncls__1208 == nil { var fncls__1208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class = fncls__1208d; tmp4 = fncls__1208d } else { tmp4 = fncls__1208 }; arg_1195 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1209, tmp4, nil); var arg_1196 any = pn__13; var arg_1197 any = ps__11; if linked_1193 == nil { arg_1186 = ifn_1194.Invoke_O_O_O__O(arg_1195, arg_1196, arg_1197) } else { arg_1186 = linked_1193.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1192, arg_1195, arg_1196, arg_1197) }; if linked_1183 == nil { arg_1181 = ifn_1184.Invoke_O_O__O(arg_1185, arg_1186) } else { arg_1181 = linked_1183.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1182, arg_1185, arg_1186) }; if linked_1179 == nil { params__15 = ifn_1180.Invoke_O__O(arg_1181) } else { params__15 = linked_1179.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1178, arg_1181) }; var params__16 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_17, r__12) { params__16 = params__15 } else { var root_1210 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = params__15; var arg_1214 any; var tmp5 any = A_arbace_j2g_dyn_A_const_17; var tmp6 any; var root_1215 any = A_arbace_j2g_dyn_A_const_98.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = A_arbace_j2g_dyn_A_const_76; var arg_1219 any = r__12; if linked_1216 == nil { tmp6 = ifn_1217.Invoke_O_O__O(arg_1218, arg_1219) } else { tmp6 = linked_1216.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1215, arg_1218, arg_1219) }; arg_1214 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6)); if linked_1211 == nil { params__16 = ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { params__16 = linked_1211.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) } }; var call__17 any; var root_1220 any = /*line :181:1*/A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_1222 lang.IFn; if











	linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = this__4; var arg_1224 any; var root_1225 any = A_arbace_j2g_dyn_A_const_118.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = A_arbace_j2g_dyn_A_const_140.GetRawRoot__O(); var arg_1229 any = pn__13; var arg_1230 any = ps__11; if linked_1226 == nil { arg_1224 = ifn_1227.Invoke_O_O_O__O(arg_1228, arg_1229, arg_1230) } else { arg_1224 = linked_1226.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1225, arg_1228, arg_1229, arg_1230) }; if linked_1221 == nil { call__17 = ifn_1222.Invoke_O_O__O(arg_1223, arg_1224) } else { call__17 = linked_1221.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_1220, arg_1223, arg_1224) }; var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_102.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var tmp9 any = A_arbace_j2g_dyn_A_const_141; var tmp10 any; var root_1240 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = base__14; if linked_1241 == nil { tmp10 = ifn_1242.Invoke_O__O(arg_1243) } else { tmp10 = linked_1241.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1240, arg_1243) }; var tmp11 any = tmp10; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_dyn_A_const_142; var tmp14 any = A_arbace_j2g_dyn_A_const_143; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_dyn_A_const_144; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_145; var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15.Invoke_O_O_O__O(tmp16, tmp17.Invoke_O_O__O(tmp18, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_146, A_arbace_j2g_dyn_A_const_147)), i__1)); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyn_A_const_148; var tmp22 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_149, A_arbace_j2g_dyn_A_const_150, nil); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_dyn_A_const_151; var tmp25 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_152, call__17); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_153; var tmp28 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_155, A_arbace_j2g_dyn_A_const_156, A_arbace_j2g_dyn_A_const_157); var tmp29 any; if




	lang.Util_Equiv_O_O__Z_NoInit(Lit_17, r__12) { tmp29 = A_arbace_j2g_dyn_A_const_154 } else { var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_dyn_A_const_158; var tmp32 any; var root_1244 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, A_arbace_j2g_dyn_convert_result_A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = A_arbace_j2g_dyn_A_const_160; var arg_1248 any = r__12; if linked_1245 == nil { tmp32 = ifn_1246.Invoke_O_O__O(arg_1247, arg_1248) } else { tmp32 = linked_1245.(*A_arbace_j2g_dyn_convert_result_A).Invoke_O_O_O__O(root_1244, arg_1247, arg_1248) }; tmp29 = tmp30.Invoke_O_O__O(tmp31, tmp32) }; return /*line :194:1*/ tmp7.Invoke_O_O_O_O_O_O__O(tmp8, tmp9, tmp11, params__16, tmp12.Invoke_O_O_O__O(tmp13, tmp19, tmp20.Invoke_O_O_O__O(tmp21, tmp22, tmp23.Invoke_O_O_O__O(tmp24, tmp25, tmp26.Invoke_O_O_O__O(tmp27, tmp28, tmp29)))), lang.IFn_Cast(fallback__3).Invoke_O_O__O(pn__13, r__12)) }
//line :181:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O__O(self, recv__0, i__1, k__2, fallback__3 any) any {




	var root_1249 any = A_arbace_j2g_dyn_A_const_161.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = recv__0; var arg_1253 any = i__1; var arg_1254 any = k__2; var arg_1255 any = fallback__3; var arg_1256 any = A_arbace_j2g_dyn_A_const_162; if linked_1250 == nil { return ifn_1251.Invoke_O_O_O_O_O__O(arg_1252, arg_1253, arg_1254, arg_1255, arg_1256) } else { return linked_1250.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1249, arg_1252, arg_1253, arg_1254, arg_1255, arg_1256) } }
//line :181:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O__O(self, ifaces__0, i__1, k__2 any) any {



	var root_1257 any = A_arbace_j2g_dyn_A_const_161.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = A_arbace_j2g_dyn_A_const_163; var arg_1261 any = i__1; var arg_1262 any = k__2; var arg_1263 any; var fnbody__1274 any = A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(k__2, ifaces__0); var tmp1 *jrt.Class; var fncls__1273 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class; if fncls__1273 == nil { var fncls__1273d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__1274); A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class = fncls__1273d; tmp1 = fncls__1273d } else { tmp1 = fncls__1273 }; arg_1263 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1274, tmp1, nil); var arg_1264 any = A_arbace_j2g_dyn_A_const_164; if linked_1258 == nil { return ifn_1259.Invoke_O_O_O_O_O__O(arg_1260, arg_1261, arg_1262, arg_1263, arg_1264) } else { return linked_1258.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1257, arg_1260, arg_1261, arg_1262, arg_1263, arg_1264) } }
//line :185:1
func A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_fn__711000178_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000178_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :185:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_1265 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = t.F_ifaces; var arg_1269 any = t.F_k; var arg_1270 any = pn__1; var arg_1271 any = r__2; var arg_1272 any = jrt.Boolean_TRUE.Ref(); if linked_1266 == nil { return ifn_1267.Invoke_O_O_O_O_O__O(arg_1268, arg_1269, arg_1270, arg_1271, arg_1272) } else { return linked_1266.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1265, arg_1268, arg_1269, arg_1270, arg_1271, arg_1272) } }



func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New() *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Ctor() {}
//line :189:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Invoke_O_O__O(self, s__711000187__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1166 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(s__711000187__1, self); var tmp2 *jrt.Class; var fncls__1165 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class; if fncls__1165 == nil { var fncls__1165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__1166); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class = fncls__1165d; tmp2 = fncls__1165d } else { tmp2 = fncls__1165 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1166, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :189:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A{}; t.Ctor_O_O(p0, p1); return t }
//line :189:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Ctor_O_O(c__s__711000187, c__iter__711000186 any) { t.F_s__711000187 = c__s__711000187; t.F_iter__711000186 = c__iter__711000186 }
//line :189:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Invoke_O__O(self any) any { { var s__711000187__1 any; var t_ any = t.F_s__711000187; t.F_s__711000187 = nil; s__711000187__1 = t_; for { var temp__1927000414__auto____2 any; var root_1099 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = s__711000187__1; if linked_1100 == nil { temp__1927000414__auto____2 = ifn_1101.Invoke_O__O(arg_1102) } else { temp__1927000414__auto____2 = linked_1100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1099, arg_1102) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000187__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1103 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = s__711000187__3; if linked_1104 == nil { tmp1 = ifn_1105.Invoke_O__O(arg_1106) } else { tmp1 = linked_1104.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1103, arg_1106) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1107 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = s__711000187__3; if linked_1108 == nil { c__1927001037__auto____4 = ifn_1109.Invoke_O__O(arg_1110) } else { c__1927001037__auto____4 = linked_1108.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1107, arg_1110) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000189__6 any; var root_1111 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1112 == nil { b__711000189__6 = ifn_1113.Invoke_O__O(arg_1114) } else { b__711000189__6 = linked_1112.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1111, arg_1114) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1125 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(b__711000189__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1124 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class; if fncls__1124 == nil { var fncls__1124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__1125); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class = fncls__1124d; tmp3 = fncls__1124d } else { tmp3 = fncls__1124 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1125, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1126 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any; var root_1131 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = b__711000189__6; if linked_1132 == nil { arg_1129 = ifn_1133.Invoke_O__O(arg_1134) } else { arg_1129 = linked_1132.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1131, arg_1134) }; var arg_1130 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp5 any; var root_1135 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = s__711000187__3; if linked_1136 == nil { tmp5 = ifn_1137.Invoke_O__O(arg_1138) } else { tmp5 = linked_1136.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1135, arg_1138) }; arg_1130 = tmp4.Invoke_O__O(tmp5); if linked_1127 == nil { return ifn_1128.Invoke_O_O__O(arg_1129, arg_1130) } else { return linked_1127.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1126, arg_1129, arg_1130) } } else { var root_1139 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any; var root_1144 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = b__711000189__6; if linked_1145 == nil { arg_1142 = ifn_1146.Invoke_O__O(arg_1147) } else { arg_1142 = linked_1145.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1144, arg_1147) }; var arg_1143 any; if linked_1140 == nil { return ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { return linked_1140.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) } } } else { var j__4 any; var root_1148 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = s__711000187__3; if linked_1149 == nil { j__4 = ifn_1150.Invoke_O__O(arg_1151) } else { j__4 = linked_1149.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1148, arg_1151) }; var root_1152 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any; var root_1157 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_92, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__4)).Ref(); if linked_1158 == nil { arg_1155 = ifn_1159.Invoke_O__O(arg_1160) } else { arg_1155 = linked_1158.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1157, arg_1160) }; var arg_1156 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp7 any; var root_1161 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = s__711000187__3; if linked_1162 == nil { tmp7 = ifn_1163.Invoke_O__O(arg_1164) } else { tmp7 = linked_1162.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1161, arg_1164) }; arg_1156 = tmp6.Invoke_O__O(tmp7); if linked_1153 == nil { return ifn_1154.Invoke_O_O__O(arg_1155, arg_1156) } else { return linked_1153.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1152, arg_1155, arg_1156) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :189:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :189:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Ctor_O_I_O(c__b__711000189 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000189 = c__b__711000189; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :189:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Invoke_O__O(self any) any { { var i__711000188__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000188__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000188__1)); var root_1115 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = t.F_b__711000189; var arg_1119 any; var root_1120 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1122 lang.IFn; if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_92, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__2)).Ref(); if linked_1121 == nil { arg_1119 = ifn_1122.Invoke_O__O(arg_1123) } else { arg_1119 = linked_1121.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1120, arg_1123) }; if linked_1116 == nil { ifn_1117.Invoke_O_O__O(arg_1118, arg_1119) } else { linked_1116.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1115, arg_1118, arg_1119) }; i__711000188__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000188__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_method_form_fn__711000196_A_New() *A_arbace_j2g_dyn_method_form_fn__711000196_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000196_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Ctor() {}
//line :191:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Invoke_O_O_O__O(self, p1__711000175_SHARP___1, p2__711000176_SHARP___2 any) any { var root_1198 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = p1__711000175_SHARP___1; var arg_1202 any; var root_1203 any = A_arbace_j2g_dyn_A_const_98.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = A_arbace_j2g_dyn_A_const_76; var arg_1207 any = p2__711000176_SHARP___2; if linked_1204 == nil { arg_1202 = ifn_1205.Invoke_O_O__O(arg_1206, arg_1207) } else { arg_1202 = linked_1204.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1203, arg_1206, arg_1207) }; if linked_1199 == nil { return ifn_1200.Invoke_O_O__O(arg_1201, arg_1202) } else { return linked_1199.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1198, arg_1201, arg_1202) } }










func A_arbace_j2g_dyn_native_name_A_New() *A_arbace_j2g_dyn_native_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_native_name_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_j2g_dyn_native_name_A) Ctor() {}
//line :202:1
func (t *A_arbace_j2g_dyn_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_116); var tmp2 any; var root_1275 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); if linked_1276 == nil { tmp2 = ifn_1277.Invoke_O__O(arg_1278) } else { tmp2 = linked_1276.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1275, arg_1278) }; var tmp3 any = tmp2; var tmp4 any; var root_1279 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = mname__0; var arg_1283 any = desc__1; if linked_1280 == nil { tmp4 = ifn_1281.Invoke_O_O__O(arg_1282, arg_1283) } else { tmp4 = linked_1280.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1279, arg_1282, arg_1283) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref()
}





















func A_arbace_j2g_dyn_proxy_classes_A_New() *A_arbace_j2g_dyn_proxy_classes_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Ctor() {}
//line :226:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Invoke_O_O__O(self, T__0_ any) any {



	var root_1284 any = A_arbace_j2g_dyn_A_const_38.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any; var fnbody__1327 any = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(T__0_); var tmp1 *jrt.Class; var fncls__1326 *jrt.Class = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class; if fncls__1326 == nil { var fncls__1326d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, fnbody__1327); A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class = fncls__1326d; tmp1 = fncls__1326d } else { tmp1 = fncls__1326 }; arg_1287 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1327, tmp1, nil); var arg_1288 any = A_arbace_j2g_dyn_A_const_167.GetRawRoot__O(); if linked_1285 == nil { return ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { return linked_1285.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) } }
//line :230:1
func A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_fn__711000201_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Ctor_O(c__T any) { t.F_T = c__T }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Invoke_O_O__O(self, p1__711000200_SHARP___1 any) any { var and__1927000168__auto____2 any; var or__1927000174__auto____2 any; var root_1289 any = A_arbace_j2g_dyn_A_const_47.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = t.F_T; var arg_1293 any = p1__711000200_SHARP___1; if linked_1290 == nil { or__1927000174__auto____2 = ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { or__1927000174__auto____2 = linked_1290.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; if jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { var root_1294 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = p1__711000200_SHARP___1; if linked_1295 == nil { and__1927000168__auto____2 = ifn_1296.Invoke_O__O(arg_1297) } else { and__1927000168__auto____2 = linked_1295.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1294, arg_1297) } }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1298 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = p1__711000200_SHARP___1; if linked_1299 == nil { and__1927000168__auto____3 = ifn_1300.Invoke_O__O(arg_1301) } else { and__1927000168__auto____3 = linked_1299.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_1298, arg_1301) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1302 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1304 lang.IFn
														if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any; var root_1306 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = p1__711000200_SHARP___1; if linked_1307 == nil { arg_1305 = ifn_1308.Invoke_O__O(arg_1309) } else { arg_1305 = linked_1307.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1306, arg_1309) }; if linked_1303 == nil { and__1927000168__auto____4 = ifn_1304.Invoke_O__O(arg_1305) } else { and__1927000168__auto____4 = linked_1303.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1302, arg_1305) }
//line :230:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1310 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1312 lang.IFn
		if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any; var root_1314 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = p1__711000200_SHARP___1; if linked_1315 == nil { arg_1313 = ifn_1316.Invoke_O__O(arg_1317) } else { arg_1313 = linked_1315.(*aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_1314, arg_1317) }; if linked_1311 == nil { and__1927000168__auto____5 = ifn_1312.Invoke_O__O(arg_1313) } else { and__1927000168__auto____5 = linked_1311.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1310, arg_1313) }
//line :230:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_1318 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any; var root_1322 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = p1__711000200_SHARP___1; if linked_1323 == nil { arg_1321 = ifn_1324.Invoke_O__O(arg_1325) } else { arg_1321 = linked_1323.(*aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_1322, arg_1325) }; if linked_1319 == nil { return ifn_1320.Invoke_O__O(arg_1321) } else { return linked_1319.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1318, arg_1321) } } else {
//line :230:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_j2g_dyn_sub_name_A_New() *A_arbace_j2g_dyn_sub_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_name_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_j2g_dyn_sub_name_A) Ctor() {}
//line :234:1
func (t *A_arbace_j2g_dyn_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_173, nil); var tmp2 any; var root_1328 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = n__0; if linked_1329 == nil { tmp2 = ifn_1330.Invoke_O__O(arg_1331) } else { tmp2 = linked_1329.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1328, arg_1331) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyn_proxy_roots_A_New() *A_arbace_j2g_dyn_proxy_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Ctor() {}
//line :236:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var fnbody__1542 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New(); var tmp1 *jrt.Class; var fncls__1541 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class; if



	fncls__1541 == nil { var fncls__1541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, nil); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class = fncls__1541d; tmp1 = fncls__1541d } else { tmp1 = fncls__1541 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1542, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_167.GetRawRoot__O()) }
//line :240:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New() *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Invoke_O_O__O(self, s__711000206__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1540 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(self, s__711000206__1); var tmp2 *jrt.Class; var fncls__1539 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class; if fncls__1539 == nil { var fncls__1539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, fnbody__1540); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class = fncls__1539d; tmp2 = fncls__1539d } else { tmp2 = fncls__1539 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1540, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :240:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A{}; t.Ctor_O_O(p0, p1); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Ctor_O_O(c__iter__711000205, c__s__711000206 any) { t.F_iter__711000205 = c__iter__711000205; t.F_s__711000206 = c__s__711000206 }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Invoke_O__O(self any) any { { var s__711000206__1 any; var t_ any = t.F_s__711000206; t.F_s__711000206 = nil; s__711000206__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1332 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = s__711000206__1; if linked_1333 == nil { temp__1927000414__auto____2 = ifn_1334.Invoke_O__O(arg_1335) } else { temp__1927000414__auto____2 = linked_1333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1332, arg_1335) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1336 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = xs__1927001018__auto____3; if linked_1337 == nil { n__4 = ifn_1338.Invoke_O__O(arg_1339) } else { n__4 = linked_1337.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1336, arg_1339) }; var tmp1 any; var and__1927000168__auto____5 any; var root_1340 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1342 lang.IFn
														if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = n__4; if linked_1341 == nil { and__1927000168__auto____5 = ifn_1342.Invoke_O__O(arg_1343) } else { and__1927000168__auto____5 = linked_1341.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1340, arg_1343) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1344 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1344, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1346 lang.IFn; if linked_1345 == nil { ifn_1346 = lang.IFn_Cast(root_1344) } else { ifn_1346 = nil }; var arg_1347 any; var root_1348 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = n__4; if linked_1349 == nil { arg_1347 = ifn_1350.Invoke_O__O(arg_1351) } else { arg_1347 = linked_1349.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1348, arg_1351) }; if linked_1345 == nil { tmp1 = ifn_1346.Invoke_O__O(arg_1347) } else { tmp1 = linked_1345.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1344, arg_1347) } } else { tmp1 = and__1927000168__auto____5 }
//line :240:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__1513 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(n__4); var tmp2 *jrt.Class; var fncls__1512 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class; if fncls__1512 == nil { var fncls__1512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, fnbody__1513); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class = fncls__1512d; tmp2 = fncls__1512d } else { tmp2 = fncls__1512 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1513, tmp2, nil); var fs__1927001036__auto____6 any; var root_1514 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1518 any = A_arbace_j2g_dyn_A_const_170.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1520 lang.IFn

		if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = n__4; if linked_1519 == nil { tmp4 = ifn_1520.Invoke_O__O(arg_1521) } else { tmp4 = linked_1519.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1518, arg_1521) }
//line :240:1
		arg_1517 = tmp3.Invoke_O__O(tmp4); if linked_1515 == nil { fs__1927001036__auto____6 = ifn_1516.Invoke_O__O(arg_1517) } else { fs__1927001036__auto____6 = linked_1515.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1514, arg_1517) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1522 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = fs__1927001036__auto____6; var arg_1526 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000205); var tmp6 any; var root_1527 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = s__711000206__1; if linked_1528 == nil { tmp6 = ifn_1529.Invoke_O__O(arg_1530) } else { tmp6 = linked_1528.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1527, arg_1530) }; arg_1526 = tmp5.Invoke_O__O(tmp6); if linked_1523 == nil { return ifn_1524.Invoke_O_O__O(arg_1525, arg_1526) } else { return linked_1523.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1522, arg_1525, arg_1526) } } else { var tmp7 any; var root_1531 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = s__711000206__1; if linked_1532 == nil { tmp7 = ifn_1533.Invoke_O__O(arg_1534) } else { tmp7 = linked_1532.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1531, arg_1534) }; s__711000206__1 = tmp7; continue L1 } } else { var tmp8 any; var root_1535 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = s__711000206__1; if linked_1536 == nil { tmp8 = ifn_1537.Invoke_O__O(arg_1538) } else { tmp8 = linked_1536.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1535, arg_1538) }; s__711000206__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :240:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A{}; t.Ctor_O(p0); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Invoke_O_O__O(self, s__711000208__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1511 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(self, t.F_n, s__711000208__1); var tmp2 *jrt.Class; var fncls__1510 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class; if fncls__1510 == nil { var fncls__1510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, fnbody__1511); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class = fncls__1510d; tmp2 = fncls__1510d } else { tmp2 = fncls__1510 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1511, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :240:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Ctor_O_O_O(c__iter__711000207, c__n, c__s__711000208 any) { t.F_iter__711000207 = c__iter__711000207; t.F_n = c__n; t.F_s__711000208 = c__s__711000208 }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Invoke_O__O(self any) any { { var s__711000208__1 any; var t_ any = t.F_s__711000208; t.F_s__711000208 = nil; s__711000208__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1352 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = s__711000208__1; if linked_1353 == nil { temp__1927000414__auto____2 = ifn_1354.Invoke_O__O(arg_1355) } else { temp__1927000414__auto____2 = linked_1353.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1352, arg_1355) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_1356 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = xs__1927001018__auto____3; if linked_1357 == nil { c__4 = ifn_1358.Invoke_O__O(arg_1359) } else { c__4 = linked_1357.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1356, arg_1359) }; var tmp1 any
																			var and__1927000168__auto____5 any = c__4

	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1360 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = c__4; var arg_1364 any = Lit_66; if linked_1361 == nil { and__1927000168__auto____6 = ifn_1362.Invoke_O_O__O(arg_1363, arg_1364) } else { and__1927000168__auto____6 = linked_1361.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1360, arg_1363, arg_1364) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1365 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any = c__4; if linked_1366 == nil { tmp1 = ifn_1367.Invoke_O__O(arg_1368) } else { tmp1 = linked_1366.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1365, arg_1368) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }
//line :240:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__1484 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(t.F_n, c__4); var tmp2 *jrt.Class; var fncls__1483 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class; if fncls__1483 == nil { var fncls__1483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, fnbody__1484); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class = fncls__1483d; tmp2 = fncls__1483d } else { tmp2 = fncls__1483 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1484, tmp2, nil); var fs__1927001036__auto____6 any; var root_1485 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 *lang.Keyword = A_arbace_j2g_dyn_A_const_115; var tmp5 any; var root_1489 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1491 lang.IFn



		if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = c__4; if linked_1490 == nil { tmp5 = ifn_1491.Invoke_O__O(arg_1492) } else { tmp5 = linked_1490.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1489, arg_1492) }
//line :240:1
		arg_1488 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)); if linked_1486 == nil { fs__1927001036__auto____6 = ifn_1487.Invoke_O__O(arg_1488) } else { fs__1927001036__auto____6 = linked_1486.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1485, arg_1488) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1493 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = fs__1927001036__auto____6; var arg_1497 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000207); var tmp7 any; var root_1498 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = s__711000208__1; if linked_1499 == nil { tmp7 = ifn_1500.Invoke_O__O(arg_1501) } else { tmp7 = linked_1499.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1498, arg_1501) }; arg_1497 = tmp6.Invoke_O__O(tmp7); if linked_1494 == nil { return ifn_1495.Invoke_O_O__O(arg_1496, arg_1497) } else { return linked_1494.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1493, arg_1496, arg_1497) } } else { var tmp8 any; var root_1502 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = s__711000208__1; if linked_1503 == nil { tmp8 = ifn_1504.Invoke_O__O(arg_1505) } else { tmp8 = linked_1503.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1502, arg_1505) }; s__711000208__1 = tmp8; continue L1 } } else { var tmp9 any; var root_1506 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = s__711000208__1; if linked_1507 == nil { tmp9 = ifn_1508.Invoke_O__O(arg_1509) } else { tmp9 = linked_1507.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1506, arg_1509) }; s__711000208__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :240:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A{}; t.Ctor_O_O(p0, p1); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Ctor_O_O(c__n, c__c any) { t.F_n = c__n; t.F_c = c__c }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Invoke_O_O__O(self, s__711000210__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1482 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(s__711000210__1, t.F_n, self, t.F_c); var tmp2 *jrt.Class; var fncls__1481 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class; if fncls__1481 == nil { var fncls__1481d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, fnbody__1482); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class = fncls__1481d; tmp2 = fncls__1481d } else { tmp2 = fncls__1481 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1482, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :240:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Ctor_O_O_O_O(c__s__711000210, c__n, c__iter__711000209, c__c any) { t.F_s__711000210 = c__s__711000210; t.F_n = c__n; t.F_iter__711000209 = c__iter__711000209; t.F_c = c__c }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Invoke_O__O(self any) any { { var s__711000210__1 any; var t_ any = t.F_s__711000210; t.F_s__711000210 = nil; s__711000210__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1369 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1371 lang.IFn; if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = s__711000210__1; if linked_1370 == nil { temp__1927000414__auto____2 = ifn_1371.Invoke_O__O(arg_1372) } else { temp__1927000414__auto____2 = linked_1370.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1369, arg_1372) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000210__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1373 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = s__711000210__3; if linked_1374 == nil { tmp1 = ifn_1375.Invoke_O__O(arg_1376) } else { tmp1 = linked_1374.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1373, arg_1376) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1377 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1377, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1379 lang.IFn; if linked_1378 == nil { ifn_1379 = lang.IFn_Cast(root_1377) } else { ifn_1379 = nil }; var arg_1380 any = s__711000210__3; if linked_1378 == nil { c__1927001037__auto____4 = ifn_1379.Invoke_O__O(arg_1380) } else { c__1927001037__auto____4 = linked_1378.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1377, arg_1380) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000212__6 any; var root_1381 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1381, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1383 lang.IFn; if linked_1382 == nil { ifn_1383 = lang.IFn_Cast(root_1381) } else { ifn_1383 = nil }; var arg_1384 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1382 == nil { b__711000212__6 = ifn_1383.Invoke_O__O(arg_1384) } else { b__711000212__6 = linked_1382.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1381, arg_1384) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1412 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(t.F_n, b__711000212__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__1411 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class; if fncls__1411 == nil { var fncls__1411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, fnbody__1412); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class = fncls__1411d; tmp3 = fncls__1411d } else { tmp3 = fncls__1411 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1412, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1413 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any; var root_1418 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = b__711000212__6; if linked_1419 == nil { arg_1416 = ifn_1420.Invoke_O__O(arg_1421) } else { arg_1416 = linked_1419.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1418, arg_1421) }; var arg_1417 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp5 any; var root_1422 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = s__711000210__3; if linked_1423 == nil { tmp5 = ifn_1424.Invoke_O__O(arg_1425) } else { tmp5 = linked_1423.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1422, arg_1425) }; arg_1417 = tmp4.Invoke_O__O(tmp5); if linked_1414 == nil { return ifn_1415.Invoke_O_O__O(arg_1416, arg_1417) } else { return linked_1414.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1413, arg_1416, arg_1417) } } else { var root_1426 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any; var root_1431 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = b__711000212__6; if linked_1432 == nil { arg_1429 = ifn_1433.Invoke_O__O(arg_1434) } else { arg_1429 = linked_1432.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1431, arg_1434) }; var arg_1430 any; if linked_1427 == nil { return ifn_1428.Invoke_O_O__O(arg_1429, arg_1430) } else { return linked_1427.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1426, arg_1429, arg_1430) } } } else { var mm__4 any; var root_1435 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1437 lang.IFn; if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any = s__711000210__3; if linked_1436 == nil { mm__4 = ifn_1437.Invoke_O__O(arg_1438) } else { mm__4 = linked_1436.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1435, arg_1438) }; var tmp6 any; var root_1439 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1441 lang.IFn




	if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any; var root_1443 any = A_arbace_j2g_dyn_A_const_168.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = mm__4; if linked_1444 == nil { arg_1442 = ifn_1445.Invoke_O__O(arg_1446) } else { arg_1442 = linked_1444.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1443, arg_1446) }; if linked_1440 == nil { tmp6 = ifn_1441.Invoke_O__O(arg_1442) } else { tmp6 = linked_1440.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1439, arg_1442) }
//line :240:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_35, A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__4))





		if or__1927000174__auto____5 { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1447 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any; var root_1451 any = A_arbace_j2g_dyn_A_const_169.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = mm__4; if linked_1452 == nil { arg_1450 = ifn_1453.Invoke_O__O(arg_1454) } else { arg_1450 = linked_1452.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1451, arg_1454) }; if linked_1448 == nil { tmp7 = ifn_1449.Invoke_O__O(arg_1450) } else { tmp7 = linked_1448.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1447, arg_1450) } }
//line :240:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____5_2 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var root_1455 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = Lit_35; var arg_1459 any = A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__4); if linked_1456 == nil { tmp8 = ifn_1457.Invoke_O_O__O(arg_1458, arg_1459) } else { tmp8 = linked_1456.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1455, arg_1458, arg_1459) } }
//line :240:1
			if jrt.J2g_Truth(tmp8) { var root_1460 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var tmp9 any = t.F_c; var arg_1463 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__4)); var arg_1464 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp11 any; var root_1465 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = s__711000210__3; if linked_1466 == nil { tmp11 = ifn_1467.Invoke_O__O(arg_1468) } else { tmp11 = linked_1466.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1465, arg_1468) }; arg_1464 = tmp10.Invoke_O__O(tmp11); if linked_1461 == nil { return ifn_1462.Invoke_O_O__O(arg_1463, arg_1464) } else { return linked_1461.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1460, arg_1463, arg_1464) } } else { var tmp12 any; var root_1469 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = s__711000210__3; if linked_1470 == nil { tmp12 = ifn_1471.Invoke_O__O(arg_1472) } else { tmp12 = linked_1470.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1469, arg_1472) }; s__711000210__1 = tmp12; continue L1 } } else { var tmp13 any; var root_1473 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = s__711000210__3; if linked_1474 == nil { tmp13 = ifn_1475.Invoke_O__O(arg_1476) } else { tmp13 = linked_1474.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1473, arg_1476) }; s__711000210__1 = tmp13; continue L1 } } else { var tmp14 any; var root_1477 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = s__711000210__3; if linked_1478 == nil { tmp14 = ifn_1479.Invoke_O__O(arg_1480) } else { tmp14 = linked_1478.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1477, arg_1480) }; s__711000210__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :240:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Ctor_O_O_I_O_O(c__n, c__b__711000212 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__c any) { t.F_n = c__n; t.F_b__711000212 = c__b__711000212; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :240:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Invoke_O__O(self any) any { { var i__711000211__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000211__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000211__1)); var tmp2 any; var root_1385 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1387 lang.IFn




	if linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any; var root_1389 any = A_arbace_j2g_dyn_A_const_168.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = mm__2; if linked_1390 == nil { arg_1388 = ifn_1391.Invoke_O__O(arg_1392) } else { arg_1388 = linked_1390.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1389, arg_1392) }; if linked_1386 == nil { tmp2 = ifn_1387.Invoke_O__O(arg_1388) } else { tmp2 = linked_1386.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1385, arg_1388) }
//line :240:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_35, A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__2))





		if or__1927000174__auto____3 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1393 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any; var root_1397 any = A_arbace_j2g_dyn_A_const_169.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any = mm__2; if linked_1398 == nil { arg_1396 = ifn_1399.Invoke_O__O(arg_1400) } else { arg_1396 = linked_1398.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1397, arg_1400) }; if linked_1394 == nil { tmp3 = ifn_1395.Invoke_O__O(arg_1396) } else { tmp3 = linked_1394.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1393, arg_1396) } }
//line :240:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____3_2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var root_1401 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = Lit_35; var arg_1405 any = A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__2); if linked_1402 == nil { tmp4 = ifn_1403.Invoke_O_O__O(arg_1404, arg_1405) } else { tmp4 = linked_1402.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1401, arg_1404, arg_1405) } }
//line :240:1
			if jrt.J2g_Truth(tmp4) { var root_1406 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = t.F_b__711000212; var tmp5 any = t.F_c; var arg_1410 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__2)); if linked_1407 == nil { ifn_1408.Invoke_O_O__O(arg_1409, arg_1410) } else { linked_1407.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1406, arg_1409, arg_1410) }; i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_j2g_dyn_object_fallback_A_New() *A_arbace_j2g_dyn_object_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_object_fallback_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Ctor() {}
//line :250:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Invoke_O_O_O_O__O(self, n__0, k__1, pn__2 any) any { var impl__4 any; var root_1543 any = A_arbace_j2g_dyn_A_const_71.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1545 lang.IFn; if



	linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = n__0; var arg_1547 any = k__1; if linked_1544 == nil { impl__4 = ifn_1545.Invoke_O_O__O(arg_1546, arg_1547) } else { impl__4 = linked_1544.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1543, arg_1546, arg_1547) }; var base__5 any; var root_1548 any = /*line :250:1*/A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1550 lang.IFn; if




	linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var arg_1552 any = k__1; if linked_1549 == nil { base__5 = ifn_1550.Invoke_O_O__O(arg_1551, arg_1552) } else { base__5 = linked_1549.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1548, arg_1551, arg_1552) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_171); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_dyn_A_const_73.Invoke_O__O(impl__4))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_172; var tmp4 any; var root_1553 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1555 lang.IFn
		if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1557 any; var root_1561 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__5)).Ref(); if linked_1562 == nil { arg_1557 = ifn_1563.Invoke_O__O(arg_1564) } else { arg_1557 = linked_1562.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1561, arg_1564) }; var arg_1558 any = A_arbace_j2g_dyn_A_const_173; var arg_1559 any = A_arbace_j2g_dyn_A_const_174; var arg_1560 any = pn__2; if linked_1554 == nil { tmp4 = ifn_1555.Invoke_O_O_O_O_O__O(arg_1556, arg_1557, arg_1558, arg_1559, arg_1560) } else { tmp4 = linked_1554.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1553, arg_1556, arg_1557, arg_1558, arg_1559, arg_1560) }
//line :256:1
		return lang.Tuple_Create_O__IPersistentVector(tmp2.Invoke_O_O__O(tmp3, tmp4)) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_175; var tmp7 any; var G__711000228__6_ any; var root_1565 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1567 lang.IFn

			if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = k__1; if linked_1566 == nil { G__711000228__6_ = ifn_1567.Invoke_O__O(arg_1568) } else { G__711000228__6_ = linked_1566.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1565, arg_1568) }; L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__711000228__6_) >> 1 & 3 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_117) { tmp7 = A_arbace_j2g_dyn_A_const_176; break L1 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_118) { tmp7 = A_arbace_j2g_dyn_A_const_177; break L1 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_119) {


				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_178; var tmp10 any = A_arbace_j2g_dyn_A_const_179; var tmp11 any; var root_1570 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = pn__2; if linked_1571 == nil { tmp11 = ifn_1572.Invoke_O__O(arg_1573) } else { tmp11 = linked_1571.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1570, arg_1573) }; tmp7 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11)
//line :258:1
				break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_120, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__711000228__6_)))))}
//line :256:1
			return lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O_O__O(tmp6, tmp7)) } }






func A_arbace_j2g_dyn_class_fallback_A_New() *A_arbace_j2g_dyn_class_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Ctor() {}
//line :263:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Invoke_O_O_O_O_O__O(self, n__0, p__711000230__1, pn__2, r__3 any) any { var vec__711000231__5 any = p__711000230__1; var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__711000231__5; var impl__9 any; var root_1574 any = A_arbace_j2g_dyn_A_const_71.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1576 lang.IFn; if



	linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = n__0; var arg_1578 any = k__8; if linked_1575 == nil { impl__9 = ifn_1576.Invoke_O_O__O(arg_1577, arg_1578) } else { impl__9 = linked_1575.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1574, arg_1577, arg_1578) }; var base__10 any; var root_1579 any = /*line :263:1*/A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1581 lang.IFn; if




	linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = name__6; var arg_1583 any = desc__7; if linked_1580 == nil { base__10 = ifn_1581.Invoke_O_O__O(arg_1582, arg_1583) } else { base__10 = linked_1580.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1579, arg_1582, arg_1583) }; var ret__11 any; var fnbody__1585 any = /*line :263:1*/A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(r__3); var tmp1 *jrt.Class; var fncls__1584 *jrt.Class = A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class; if





	fncls__1584 == nil { var fncls__1584d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__1585); A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class = fncls__1584d; tmp1 = fncls__1584d } else { tmp1 = fncls__1584 }; ret__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1585, tmp1, nil); var G__711000236__12_ any = /*line :263:1*/A_arbace_j2g_dyn_A_const_73.Invoke_O__O(impl__9); switch






	lang.Util_Hash_O__I_NoInit(G__711000236__12_) >> 4 & 3 { case 0: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_72) {

		var tmp2 lang.IFn = lang.IFn_Cast(ret__11); var tmp3 any; var root_1591 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1595 any; var root_1598 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1600 lang.IFn; if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = A_arbace_j2g_dyn_A_const_76; var arg_1602 any = A_arbace_j2g_dyn_A_const_74.Invoke_O__O(impl__9); var arg_1603 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1599 == nil { arg_1595 = ifn_1600.Invoke_O_O_O__O(arg_1601, arg_1602, arg_1603) } else { arg_1595 = linked_1599.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1598, arg_1601, arg_1602, arg_1603) }; var arg_1596 any = A_arbace_j2g_dyn_A_const_184; var arg_1597 any = pn__2; if linked_1592 == nil { tmp3 = ifn_1593.Invoke_O_O_O_O__O(arg_1594, arg_1595, arg_1596, arg_1597) } else { tmp3 = linked_1592.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1591, arg_1594, arg_1595, arg_1596, arg_1597) }; return tmp2.Invoke_O__O(tmp3) }
//line :270:1
	case 1: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_181) {
		var tmp4 lang.IFn = lang.IFn_Cast(ret__11); var tmp5 any; var root_1604 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1608 any; var root_1612 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1613 == nil { arg_1608 = ifn_1614.Invoke_O__O(arg_1615) } else { arg_1608 = linked_1613.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1612, arg_1615) }; var arg_1609 any = A_arbace_j2g_dyn_A_const_185; var arg_1610 any = A_arbace_j2g_dyn_A_const_186; var arg_1611 any = pn__2; if linked_1605 == nil { tmp5 = ifn_1606.Invoke_O_O_O_O_O__O(arg_1607, arg_1608, arg_1609, arg_1610, arg_1611) } else { tmp5 = linked_1605.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1604, arg_1607, arg_1608, arg_1609, arg_1610, arg_1611) }; return tmp4.Invoke_O__O(tmp5) }
//line :270:1
	case 2: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_182) {
		var tmp6 lang.IFn = lang.IFn_Cast(ret__11); var tmp7 any; var root_1616 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1620 any; var root_1624 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1625 == nil { arg_1620 = ifn_1626.Invoke_O__O(arg_1627) } else { arg_1620 = linked_1625.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1624, arg_1627) }; var arg_1621 any = A_arbace_j2g_dyn_A_const_185; var arg_1622 any = A_arbace_j2g_dyn_A_const_186; var arg_1623 any = pn__2; if linked_1617 == nil { tmp7 = ifn_1618.Invoke_O_O_O_O_O__O(arg_1619, arg_1620, arg_1621, arg_1622, arg_1623) } else { tmp7 = linked_1617.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1616, arg_1619, arg_1620, arg_1621, arg_1622, arg_1623) }; return tmp6.Invoke_O__O(tmp7) }
//line :270:1
	case 3: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_183) {


		var tmp8 lang.IFn = lang.IFn_Cast(ret__11); var tmp9 any; var root_1628 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1632 any; var root_1635 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1637 lang.IFn; if linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1636 == nil { arg_1632 = ifn_1637.Invoke_O__O(arg_1638) } else { arg_1632 = linked_1636.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1635, arg_1638) }; var arg_1633 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp11 any; var root_1639 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil); var tmp13 any; var root_1643 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = n__0; if linked_1644 == nil { tmp13 = ifn_1645.Invoke_O__O(arg_1646) } else { tmp13 = linked_1644.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1643, arg_1646) }; arg_1642 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13)).Ref(); if linked_1640 == nil { tmp11 = ifn_1641.Invoke_O__O(arg_1642) } else { tmp11 = linked_1640.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1639, arg_1642) }; arg_1633 = tmp10.Invoke_O_O__O(tmp11, A_arbace_j2g_dyn_A_const_187); var arg_1634 any = pn__2; if linked_1629 == nil { tmp9 = ifn_1630.Invoke_O_O_O_O__O(arg_1631, arg_1632, arg_1633, arg_1634) } else { tmp9 = linked_1629.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1628, arg_1631, arg_1632, arg_1633, arg_1634) }; return tmp8.Invoke_O__O(tmp9) }
//line :270:1
	default:}; var vec__711000237__13 any; var root_1587 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1589 lang.IFn; if



	linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = desc__7; if linked_1588 == nil { vec__711000237__13 = ifn_1589.Invoke_O__O(arg_1590) } else { vec__711000237__13 = linked_1588.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1587, arg_1590) }; var ps__14 any = /*line :270:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(0), nil); var rr__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyn_A_const_188; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_189; var tmp18 any = A_arbace_j2g_dyn_A_const_190; var tmp19 *jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns21:)' of abstract class ns1:.", []*jrt.Class{jrt.String_class}); var tmp20 any; var root_1647 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1649 lang.IFn; if




	linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = rr__15; if linked_1648 == nil { tmp20 = ifn_1649.Invoke_O__O(arg_1650) } else { tmp20 = linked_1648.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1647, arg_1650) }; var tmp21 any = tmp20; var tmp22 any; var root_1651 any = /*line :270:1*/A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1653 lang.IFn; if





	linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any = Lit_3; var arg_1655 any; var root_1656 any = A_arbace_j2g_dyn_A_const_118.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1658 lang.IFn; if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var arg_1660 any = ps__14; if linked_1657 == nil { arg_1655 = ifn_1658.Invoke_O_O__O(arg_1659, arg_1660) } else { arg_1655 = linked_1657.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1656, arg_1659, arg_1660) }; if linked_1652 == nil { tmp22 = ifn_1653.Invoke_O_O__O(arg_1654, arg_1655) } else { tmp22 = linked_1652.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1651, arg_1654, arg_1655) }; var tmp23 any = tmp22; var tmp24 any; var root_1661 any = /*line :270:1*/A_arbace_j2g_dyn_A_const_119.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1663 lang.IFn; if






	linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any = n__0; var arg_1665 any = Lit_5; var arg_1666 any = Lit_6; if linked_1662 == nil { tmp24 = ifn_1663.Invoke_O_O_O__O(arg_1664, arg_1665, arg_1666) } else { tmp24 = linked_1662.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1661, arg_1664, arg_1665, arg_1666) }; return /*line :270:1*/ lang.Tuple_Create_O__IPersistentVector(tmp14.Invoke_O_O__O(tmp15, tmp16.Invoke_O_O_O__O(tmp17, tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp21, nil, name__6, nil, tmp23, nil, tmp24, nil)).Ref()))) }
//line :269:1
func A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(p0 any) *A_arbace_j2g_dyn_class_fallback_ret__711000234_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_ret__711000234_A{}; t.Ctor_O(p0); return t }
//line :269:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :269:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Invoke_O_O__O(self, call__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(Lit_17, t.F_r) { return lang.Tuple_Create_O__IPersistentVector(call__1) } else { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_180, call__1)) } }









func A_arbace_j2g_dyn_ctor_infos_A_New() *A_arbace_j2g_dyn_ctor_infos_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Ctor() {}
//line :279:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_1667 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_1669 lang.IFn; if


	linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = n__0; if linked_1668 == nil { g__2 = ifn_1669.Invoke_O__O(arg_1670) } else { g__2 = linked_1668.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_1667, arg_1670) }; var arg_conv__3 any; var fnbody__1686 any = /*line :279:1*/A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New(); var tmp1 *jrt.Class; var fncls__1685 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class; if



	fncls__1685 == nil { var fncls__1685d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class = fncls__1685d; tmp1 = fncls__1685d } else { tmp1 = fncls__1685 }; arg_conv__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1686, tmp1, nil); var root_1690 any =


	A_arbace_j2g_dyn_A_const_196.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1692 lang.IFn; if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var arg_1693 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_197.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_198, A_arbace_j2g_dyn_A_const_199); if linked_1691 == nil { ifn_1692.Invoke_O__O(arg_1693) } else { linked_1691.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1690, arg_1693) }; var tmp2 any; tmp19 := /*line :279:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		{ var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyn_A_const_200; var tmp5 any; var root_1699 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_1700 == nil { tmp5 = ifn_1701.Invoke_O__O(arg_1702) } else { tmp5 = linked_1700.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1699, arg_1702) }; var tmp6 any = tmp5; var tmp7 any; var root_1703 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any; var tmp8 any; var root_1708 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = A_arbace_j2g_dyn_A_const_201; var arg_1712 any = A_arbace_j2g_dyn_A_const_202; if linked_1709 == nil { tmp8 = ifn_1710.Invoke_O_O__O(arg_1711, arg_1712) } else { tmp8 = linked_1709.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1708, arg_1711, arg_1712) }; arg_1706 = lang.Tuple_Create_O__IPersistentVector(tmp8); var arg_1707 any = A_arbace_j2g_dyn_A_const_203; if linked_1704 == nil { tmp7 = ifn_1705.Invoke_O_O__O(arg_1706, arg_1707) } else { tmp7 = linked_1704.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1703, arg_1706, arg_1707) }; var tmp9 any = tmp7; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_204; var tmp12 any; var root_1713 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1715 lang.IFn

			if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1717 any = A_arbace_j2g_dyn_A_const_205; var arg_1718 any = A_arbace_j2g_dyn_A_const_206; var arg_1719 any; var iter__1927001039__auto____6 any; var fnbody__2075 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(g__2, n__0, arg_conv__3); var tmp13 *jrt.Class; var fncls__2074 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class
			if fncls__2074 == nil { var fncls__2074d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__2075); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class = fncls__2074d; tmp13 = fncls__2074d } else { tmp13 = fncls__2074 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2075, tmp13, nil); var tmp14 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp15 any; var tmp16 any; var root_2076 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any = n__0; if linked_2077 == nil { tmp16 = ifn_2078.Invoke_O__O(arg_2079) } else { tmp16 = linked_2077.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2076, arg_2079) }; if jrt.J2g_Truth(tmp16) { var root_2080 any = A_arbace_j2g_dyn_A_const_69.GetRawRoot__O(); var linked_2081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2080, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2082 lang.IFn; if linked_2081 == nil { ifn_2082 = lang.IFn_Cast(root_2080) } else { ifn_2082 = nil }; var arg_2083 any = n__0; if linked_2081 == nil { tmp15 = ifn_2082.Invoke_O__O(arg_2083) } else { tmp15 = linked_2081.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2080, arg_2083) } } else { var tmp17 *lang.Keyword = A_arbace_j2g_dyn_A_const_115; var tmp18 any; var root_2084 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2086 lang.IFn; if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any = n__0; if linked_2085 == nil { tmp18 = ifn_2086.Invoke_O__O(arg_2087) } else { tmp18 = linked_2085.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2084, arg_2087) }; tmp15 = tmp17.Invoke_O__O(tmp18) }; arg_1719 = tmp14.Invoke_O__O(tmp15)
//line :289:1
			if linked_1714 == nil { tmp12 = ifn_1715.Invoke_O_O_O_O__O(arg_1716, arg_1717, arg_1718, arg_1719) } else { tmp12 = linked_1714.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1713, arg_1716, arg_1717, arg_1718, arg_1719) }
//line :287:1
			tmp2 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp6, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12)) }
//line :279:1
		return nil }(); var root_1687 any = A_arbace_j2g_dyn_A_const_195.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1689 lang.IFn; if






	linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; if linked_1688 == nil { ifn_1689.Invoke__O() } else { linked_1688.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1687) }; if /*line :279:1*/ tmp19 != nil { panic(tmp19) }; return tmp2 }



func A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New() *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A{}; t.Ctor(); return t }
//line :283:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Ctor() {}
//line :283:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Invoke_O_O_O__O(self, d__1, x__2 any) any { var tmp1 any; var root_1671 any = A_arbace_j2g_dyn_A_const_81.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = d__1; if linked_1672 == nil { tmp1 = ifn_1673.Invoke_O__O(arg_1674) } else { tmp1 = linked_1672.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1671, arg_1674) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_192; var tmp4 any; var root_1675 any = A_arbace_j2g_dyn_A_const_98.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = A_arbace_j2g_dyn_A_const_76; var arg_1679 any = d__1; if linked_1676 == nil { tmp4 = ifn_1677.Invoke_O_O__O(arg_1678, arg_1679) } else { tmp4 = linked_1676.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1675, arg_1678, arg_1679) }; return tmp2.Invoke_O_O_O__O(tmp3, tmp4, x__2) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_12) { return x__2 } else { if A_arbace_j2g_dyn_A_const_84 != nil {

	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_193; var tmp8 any = A_arbace_j2g_dyn_A_const_194; var tmp9 any; var root_1680 any = A_arbace_j2g_dyn_A_const_98.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = A_arbace_j2g_dyn_A_const_76; var arg_1684 any = d__1; if linked_1681 == nil { tmp9 = ifn_1682.Invoke_O_O__O(arg_1683, arg_1684) } else { tmp9 = linked_1681.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1680, arg_1683, arg_1684) }; return tmp5.Invoke_O_O__O(tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9), x__2) } else {
//line :283:1
		return nil } } } }






func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :290:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Ctor_O_O_O(c__g, c__n, c__arg_conv any) { t.F_g = c__g; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :290:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Invoke_O_O__O(self, s__711000244__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2073 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(self, t.F_g, s__711000244__1, t.F_n, t.F_arg_conv); var tmp2 *jrt.Class; var fncls__2072 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class; if fncls__2072 == nil { var fncls__2072d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__2073); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class = fncls__2072d; tmp2 = fncls__2072d } else { tmp2 = fncls__2072 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2073, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :290:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :290:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Ctor_O_O_O_O_O(c__iter__711000243, c__g, c__s__711000244, c__n, c__arg_conv any) { t.F_iter__711000243 = c__iter__711000243; t.F_g = c__g; t.F_s__711000244 = c__s__711000244; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :290:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Invoke_O__O(self any) any { { var s__711000244__1 any; var t_ any = t.F_s__711000244; t.F_s__711000244 = nil; s__711000244__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1720 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = s__711000244__1; if linked_1721 == nil { temp__1927000414__auto____2 = ifn_1722.Invoke_O__O(arg_1723) } else { temp__1927000414__auto____2 = linked_1721.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1720, arg_1723) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000244__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1724 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any = s__711000244__3; if linked_1725 == nil { tmp1 = ifn_1726.Invoke_O__O(arg_1727) } else { tmp1 = linked_1725.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1724, arg_1727) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1728 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = s__711000244__3; if linked_1729 == nil { c__1927001037__auto____4 = ifn_1730.Invoke_O__O(arg_1731) } else { c__1927001037__auto____4 = linked_1729.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1728, arg_1731) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000246__6 any; var root_1732 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1733 == nil { b__711000246__6 = ifn_1734.Invoke_O__O(arg_1735) } else { b__711000246__6 = linked_1733.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1732, arg_1735) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1883 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(t.F_g, t.F_n, b__711000246__6, t.F_arg_conv, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1882 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class; if fncls__1882 == nil { var fncls__1882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__1883); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class = fncls__1882d; tmp3 = fncls__1882d } else { tmp3 = fncls__1882 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1883, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1884 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any; var root_1889 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1891 lang.IFn; if linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any = b__711000246__6; if linked_1890 == nil { arg_1887 = ifn_1891.Invoke_O__O(arg_1892) } else { arg_1887 = linked_1890.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1889, arg_1892) }; var arg_1888 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp5 any; var root_1893 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = s__711000244__3; if linked_1894 == nil { tmp5 = ifn_1895.Invoke_O__O(arg_1896) } else { tmp5 = linked_1894.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1893, arg_1896) }; arg_1888 = tmp4.Invoke_O__O(tmp5); if linked_1885 == nil { return ifn_1886.Invoke_O_O__O(arg_1887, arg_1888) } else { return linked_1885.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1884, arg_1887, arg_1888) } } else { var root_1897 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any; var root_1902 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1902, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1904 lang.IFn; if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any = b__711000246__6; if linked_1903 == nil { arg_1900 = ifn_1904.Invoke_O__O(arg_1905) } else { arg_1900 = linked_1903.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1902, arg_1905) }; var arg_1901 any; if linked_1898 == nil { return ifn_1899.Invoke_O_O__O(arg_1900, arg_1901) } else { return linked_1898.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1897, arg_1900, arg_1901) } } } else { var mm__4 any; var root_1906 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any = s__711000244__3; if linked_1907 == nil { mm__4 = ifn_1908.Invoke_O__O(arg_1909) } else { mm__4 = linked_1907.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1906, arg_1909) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_35, A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1910 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any; var root_1914 any = A_arbace_j2g_dyn_A_const_169.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any = mm__4; if linked_1915 == nil { arg_1913 = ifn_1916.Invoke_O__O(arg_1917) } else { arg_1913 = linked_1915.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1914, arg_1917) }; if linked_1911 == nil { and__1927000168__auto____6 = ifn_1912.Invoke_O__O(arg_1913) } else { and__1927000168__auto____6 = linked_1911.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1910, arg_1913) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1918 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var arg_1921 any = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__4); if linked_1919 == nil { tmp6 = ifn_1920.Invoke_O__O(arg_1921) } else { tmp6 = linked_1919.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1918, arg_1921) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :290:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_1922 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1924 lang.IFn

		if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any; var root_1926 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = t.F_n; if linked_1927 == nil { arg_1925 = ifn_1928.Invoke_O__O(arg_1929) } else { arg_1925 = linked_1927.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1926, arg_1929) }; if linked_1923 == nil { or__1927000174__auto____5 = ifn_1924.Invoke_O__O(arg_1925) } else { or__1927000174__auto____5 = linked_1923.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1922, arg_1925) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_1930 any = A_arbace_j2g_dyn_A_const_47.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any; var root_1935 any = A_arbace_j2g_dyn_A_const_208.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyn_A_const_49; var arg_1938 any = tmp8.Invoke_O__O(A_arbace_j2g_dyn_A_const_50.Get__O()); var arg_1939 any; var root_1940 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1940, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1942 lang.IFn; if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = t.F_n; if linked_1941 == nil { arg_1939 = ifn_1942.Invoke_O__O(arg_1943) } else { arg_1939 = linked_1941.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1940, arg_1943) }; if linked_1936 == nil { arg_1933 = ifn_1937.Invoke_O_O__O(arg_1938, arg_1939) } else { arg_1933 = linked_1936.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1935, arg_1938, arg_1939) }; var arg_1934 any; var root_1944 any = A_arbace_j2g_dyn_A_const_209.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1946 lang.IFn; if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__4); if linked_1945 == nil { arg_1934 = ifn_1946.Invoke_O__O(arg_1947) } else { arg_1934 = linked_1945.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1944, arg_1947) }; if linked_1931 == nil { tmp7 = ifn_1932.Invoke_O_O__O(arg_1933, arg_1934) } else { tmp7 = linked_1931.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1930, arg_1933, arg_1934) } }
//line :290:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_1948 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1950 lang.IFn



			if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any = t.F_n; if linked_1949 == nil { tmp9 = ifn_1950.Invoke_O__O(arg_1951) } else { tmp9 = linked_1949.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1948, arg_1951) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__4) } else { var root_1952 any = A_arbace_j2g_dyn_A_const_210.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = t.F_n; var arg_1956 any = mm__4; if linked_1953 == nil { real__5 = ifn_1954.Invoke_O_O__O(arg_1955, arg_1956) } else { real__5 = linked_1953.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1952, arg_1955, arg_1956) } }
//line :290:1
			var vec__711000259__6 any; var root_1957 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1959 lang.IFn




			if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__4); if linked_1958 == nil { vec__711000259__6 = ifn_1959.Invoke_O__O(arg_1960) } else { vec__711000259__6 = linked_1958.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1957, arg_1960) }
//line :290:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000262__9 any; var root_1961 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1961, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1963 lang.IFn; _ = ___8





			if linked_1962 == nil { ifn_1963 = lang.IFn_Cast(root_1961) } else { ifn_1963 = nil }; var arg_1964 any = real__5; if linked_1962 == nil { vec__711000262__9 = ifn_1963.Invoke_O__O(arg_1964) } else { vec__711000262__9 = linked_1962.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1961, arg_1964) }
//line :290:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_1965 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1965, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1967 lang.IFn; if linked_1966 == nil { ifn_1967 = lang.IFn_Cast(root_1965) } else { ifn_1967 = nil }; var arg_1968 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_211; var tmp12 any = A_arbace_j2g_dyn_A_const_212; var tmp13 any = A_arbace_j2g_dyn_A_const_213; var tmp14 any; var tmp15 any; var root_1970 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1972 lang.IFn








				if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = ps__7; if linked_1971 == nil { tmp15 = ifn_1972.Invoke_O__O(arg_1973) } else { tmp15 = linked_1971.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1970, arg_1973) }; if jrt.J2g_Truth(tmp15) { var root_1974 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1978 any = A_arbace_j2g_dyn_A_const_214; var arg_1979 any = A_arbace_j2g_dyn_A_const_240; var arg_1980 any; var root_1981 any = A_arbace_j2g_dyn_A_const_118.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1983 lang.IFn; if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any = A_arbace_j2g_dyn_A_const_216.GetRawRoot__O(); var arg_1985 any = ps__7; if linked_1982 == nil { arg_1980 = ifn_1983.Invoke_O_O__O(arg_1984, arg_1985) } else { arg_1980 = linked_1982.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1981, arg_1984, arg_1985) }; if linked_1975 == nil { tmp14 = ifn_1976.Invoke_O_O_O_O__O(arg_1977, arg_1978, arg_1979, arg_1980) } else { tmp14 = linked_1975.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1974, arg_1977, arg_1978, arg_1979, arg_1980) } } else { tmp14 = nil }
//line :298:1
				var tmp16 any = tmp14; var tmp17 any = A_arbace_j2g_dyn_A_const_217; var tmp18 any = A_arbace_j2g_dyn_A_const_218; var tmp19 any = A_arbace_j2g_dyn_A_const_219; var tmp20 any; var root_1986 any = A_arbace_j2g_dyn_A_const_220.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1986, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1988 lang.IFn


				if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = A_arbace_j2g_dyn_A_const_221; var arg_1990 any; var root_1992 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1992, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1994 lang.IFn; if linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any; var tmp21 any; var root_1997 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1999 lang.IFn; if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = A_arbace_j2g_dyn_A_const_222; var arg_2001 any = A_arbace_j2g_dyn_A_const_241; if linked_1998 == nil { tmp21 = ifn_1999.Invoke_O_O__O(arg_2000, arg_2001) } else { tmp21 = linked_1998.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1997, arg_2000, arg_2001) }; arg_1995 = lang.Tuple_Create_O__IPersistentVector(tmp21); var arg_1996 any = A_arbace_j2g_dyn_A_const_242; if linked_1993 == nil { arg_1990 = ifn_1994.Invoke_O_O__O(arg_1995, arg_1996) } else { arg_1990 = linked_1993.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1992, arg_1995, arg_1996) }; var arg_1991 any; var root_2002 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2004 lang.IFn
				if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any; var tmp22 any; var or__1927000174__auto____12 any; var root_2007 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2009 lang.IFn
				if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = t.F_n; if linked_2008 == nil { or__1927000174__auto____12 = ifn_2009.Invoke_O__O(arg_2010) } else { or__1927000174__auto____12 = linked_2008.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2007, arg_2010) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp22 = or__1927000174__auto____12 } else { var root_2011 any = A_arbace_j2g_dyn_A_const_225.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = t.F_n; if linked_2012 == nil { tmp22 = ifn_2013.Invoke_O__O(arg_2014) } else { tmp22 = linked_2012.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_2011, arg_2014) } }; if jrt.J2g_Truth(tmp22) { arg_2005 = nil } else { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp24 any; var root_2015 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2017 lang.IFn; if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any = A_arbace_j2g_dyn_A_const_76; var arg_2019 any = t.F_n; var arg_2020 any = Lit_36; if linked_2016 == nil { tmp24 = ifn_2017.Invoke_O_O_O__O(arg_2018, arg_2019, arg_2020) } else { tmp24 = linked_2016.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_2015, arg_2018, arg_2019, arg_2020) }; arg_2005 = lang.Tuple_Create_O__IPersistentVector(tmp23.Invoke_O__O(tmp24)) }
//line :302:1
				var arg_2006 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyn_A_const_226; var tmp27 any = A_arbace_j2g_dyn_A_const_235; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyn_A_const_236; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_dyn_A_const_237; var tmp32 any; var root_2052 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2054 lang.IFn

				if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any = t.F_g; if linked_2053 == nil { tmp32 = ifn_2054.Invoke_O__O(arg_2055) } else { tmp32 = linked_2053.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2052, arg_2055) }
//line :302:1
				var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28.Invoke_O_O__O(tmp29, tmp30.Invoke_O_O_O_O__O(tmp31, tmp32, A_arbace_j2g_dyn_A_const_238, A_arbace_j2g_dyn_A_const_245))); var tmp34 any = A_arbace_j2g_dyn_A_const_243; var tmp35 any = A_arbace_j2g_dyn_A_const_244; var tmp36 any; var root_2021 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2023 lang.IFn




				if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_2025 any; var root_2029 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2029, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2031 lang.IFn; if linked_2030 == nil { ifn_2031 = lang.IFn_Cast(root_2029) } else { ifn_2031 = nil }; var arg_2032 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp38 any; var root_2033 any = A_arbace_j2g_dyn_A_const_209.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2033, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_2035 lang.IFn; if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any = real__5; if linked_2034 == nil { tmp38 = ifn_2035.Invoke_O__O(arg_2036) } else { tmp38 = linked_2034.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_2033, arg_2036) }; arg_2032 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_2030 == nil { arg_2025 = ifn_2031.Invoke_O__O(arg_2032) } else { arg_2025 = linked_2030.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2029, arg_2032) }; var arg_2026 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp40 any; var root_2037 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2039 lang.IFn
				if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any; var tmp41 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil); var tmp42 any; var root_2041 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2041, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2043 lang.IFn; if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = t.F_n; if linked_2042 == nil { tmp42 = ifn_2043.Invoke_O__O(arg_2044) } else { tmp42 = linked_2042.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2041, arg_2044) }; arg_2040 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp41, jrt.RefArrayOf(jrt.Object_class, nil, tmp42)).Ref(); if linked_2038 == nil { tmp40 = ifn_2039.Invoke_O__O(arg_2040) } else { tmp40 = linked_2038.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2037, arg_2040) }; arg_2026 = tmp39.Invoke_O_O__O(tmp40, A_arbace_j2g_dyn_A_const_229)
//line :307:1
				var arg_2027 any = A_arbace_j2g_dyn_A_const_230; var arg_2028 any; var root_2045 any = A_arbace_j2g_dyn_A_const_231.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2047 lang.IFn

				if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any; var fnbody__2051 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(t.F_arg_conv); var tmp43 *jrt.Class; var fncls__2050 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class; if fncls__2050 == nil { var fncls__2050d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__2051); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class = fncls__2050d; tmp43 = fncls__2050d } else { tmp43 = fncls__2050 }; arg_2048 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2051, tmp43, nil); var arg_2049 any = ps__7; if linked_2046 == nil { arg_2028 = ifn_2047.Invoke_O_O__O(arg_2048, arg_2049) } else { arg_2028 = linked_2046.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2045, arg_2048, arg_2049) }
//line :307:1
				if linked_2022 == nil { tmp36 = ifn_2023.Invoke_O_O_O_O_O__O(arg_2024, arg_2025, arg_2026, arg_2027, arg_2028) } else { tmp36 = linked_2022.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_2021, arg_2024, arg_2025, arg_2026, arg_2027, arg_2028) }
//line :302:1
				arg_2006 = lang.Tuple_Create_O__IPersistentVector(tmp25.Invoke_O_O_O_O_O_O__O(tmp26, tmp33, tmp34, tmp35, tmp36, A_arbace_j2g_dyn_A_const_234)); if linked_2003 == nil { arg_1991 = ifn_2004.Invoke_O_O__O(arg_2005, arg_2006) } else { arg_1991 = linked_2003.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2002, arg_2005, arg_2006) }
//line :301:1
				if linked_1987 == nil { tmp20 = ifn_1988.Invoke_O_O_O__O(arg_1989, arg_1990, arg_1991) } else { tmp20 = linked_1987.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1986, arg_1989, arg_1990, arg_1991) }
//line :298:1
				arg_1968 = tmp10.Invoke_O_O_O_O_O_O_O_O__O(tmp11, tmp12, tmp13, tmp16, tmp17, tmp18, tmp19, tmp20)
//line :290:1
				var arg_1969 any; var tmp44 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp45 any; var root_2056 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2058 lang.IFn; if linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any = s__711000244__3; if linked_2057 == nil { tmp45 = ifn_2058.Invoke_O__O(arg_2059) } else { tmp45 = linked_2057.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2056, arg_2059) }; arg_1969 = tmp44.Invoke_O__O(tmp45); if linked_1966 == nil { return ifn_1967.Invoke_O_O__O(arg_1968, arg_1969) } else { return linked_1966.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1965, arg_1968, arg_1969) } } else { var tmp46 any; var root_2060 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any = s__711000244__3; if linked_2061 == nil { tmp46 = ifn_2062.Invoke_O__O(arg_2063) } else { tmp46 = linked_2061.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2060, arg_2063) }; s__711000244__1 = tmp46; continue L1 } } else { var tmp47 any; var root_2064 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2064, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2066 lang.IFn; if linked_2065 == nil { ifn_2066 = lang.IFn_Cast(root_2064) } else { ifn_2066 = nil }; var arg_2067 any = s__711000244__3; if linked_2065 == nil { tmp47 = ifn_2066.Invoke_O__O(arg_2067) } else { tmp47 = linked_2065.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2064, arg_2067) }; s__711000244__1 = tmp47; continue L1 } } else { var tmp48 any; var root_2068 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2070 lang.IFn; if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any = s__711000244__3; if linked_2069 == nil { tmp48 = ifn_2070.Invoke_O__O(arg_2071) } else { tmp48 = linked_2069.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2068, arg_2071) }; s__711000244__1 = tmp48; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :290:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :290:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Ctor_O_O_O_O_I_O(c__g, c__n, c__b__711000246, c__arg_conv any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_g = c__g; t.F_n = c__n; t.F_b__711000246 = c__b__711000246; t.F_arg_conv = c__arg_conv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :290:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Invoke_O__O(self any) any { { var i__711000245__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000245__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000245__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_35, A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1736 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any; var root_1740 any = A_arbace_j2g_dyn_A_const_169.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = mm__2; if linked_1741 == nil { arg_1739 = ifn_1742.Invoke_O__O(arg_1743) } else { arg_1739 = linked_1741.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1740, arg_1743) }; if linked_1737 == nil { and__1927000168__auto____4 = ifn_1738.Invoke_O__O(arg_1739) } else { and__1927000168__auto____4 = linked_1737.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1736, arg_1739) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1744 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__2); if linked_1745 == nil { tmp2 = ifn_1746.Invoke_O__O(arg_1747) } else { tmp2 = linked_1745.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1744, arg_1747) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :290:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_1748 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1750 lang.IFn

		if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any; var root_1752 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = t.F_n; if linked_1753 == nil { arg_1751 = ifn_1754.Invoke_O__O(arg_1755) } else { arg_1751 = linked_1753.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1752, arg_1755) }; if linked_1749 == nil { or__1927000174__auto____3 = ifn_1750.Invoke_O__O(arg_1751) } else { or__1927000174__auto____3 = linked_1749.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1748, arg_1751) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_1756 any = A_arbace_j2g_dyn_A_const_47.GetRawRoot__O(); var linked_1757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1756, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1758 lang.IFn; if linked_1757 == nil { ifn_1758 = lang.IFn_Cast(root_1756) } else { ifn_1758 = nil }; var arg_1759 any; var root_1761 any = A_arbace_j2g_dyn_A_const_208.GetRawRoot__O(); var linked_1762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1761, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1763 lang.IFn; if linked_1762 == nil { ifn_1763 = lang.IFn_Cast(root_1761) } else { ifn_1763 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyn_A_const_49; var arg_1764 any = tmp4.Invoke_O__O(A_arbace_j2g_dyn_A_const_50.Get__O()); var arg_1765 any; var root_1766 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = t.F_n; if linked_1767 == nil { arg_1765 = ifn_1768.Invoke_O__O(arg_1769) } else { arg_1765 = linked_1767.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1766, arg_1769) }; if linked_1762 == nil { arg_1759 = ifn_1763.Invoke_O_O__O(arg_1764, arg_1765) } else { arg_1759 = linked_1762.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1761, arg_1764, arg_1765) }; var arg_1760 any; var root_1770 any = A_arbace_j2g_dyn_A_const_209.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__2); if linked_1771 == nil { arg_1760 = ifn_1772.Invoke_O__O(arg_1773) } else { arg_1760 = linked_1771.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1770, arg_1773) }; if linked_1757 == nil { tmp3 = ifn_1758.Invoke_O_O__O(arg_1759, arg_1760) } else { tmp3 = linked_1757.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1756, arg_1759, arg_1760) } }
//line :290:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_1774 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1776 lang.IFn



			if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = t.F_n; if linked_1775 == nil { tmp5 = ifn_1776.Invoke_O__O(arg_1777) } else { tmp5 = linked_1775.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1774, arg_1777) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__2) } else { var root_1778 any = A_arbace_j2g_dyn_A_const_210.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any = t.F_n; var arg_1782 any = mm__2; if linked_1779 == nil { real__3 = ifn_1780.Invoke_O_O__O(arg_1781, arg_1782) } else { real__3 = linked_1779.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1778, arg_1781, arg_1782) } }
//line :290:1
			var vec__711000250__4 any; var root_1783 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1785 lang.IFn




			if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__2); if linked_1784 == nil { vec__711000250__4 = ifn_1785.Invoke_O__O(arg_1786) } else { vec__711000250__4 = linked_1784.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1783, arg_1786) }
//line :290:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000253__7 any; var root_1787 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1789 lang.IFn; _ = ___6





			if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = real__3; if linked_1788 == nil { vec__711000253__7 = ifn_1789.Invoke_O__O(arg_1790) } else { vec__711000253__7 = linked_1788.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1787, arg_1790) }
//line :290:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_1791 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = t.F_b__711000246; var arg_1795 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_211; var tmp8 any = A_arbace_j2g_dyn_A_const_212; var tmp9 any = A_arbace_j2g_dyn_A_const_213; var tmp10 any; var tmp11 any; var root_1796 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1798 lang.IFn








				if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = ps__5; if linked_1797 == nil { tmp11 = ifn_1798.Invoke_O__O(arg_1799) } else { tmp11 = linked_1797.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1796, arg_1799) }; if jrt.J2g_Truth(tmp11) { var root_1800 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1804 any = A_arbace_j2g_dyn_A_const_214; var arg_1805 any = A_arbace_j2g_dyn_A_const_215; var arg_1806 any; var root_1807 any = A_arbace_j2g_dyn_A_const_118.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1809 lang.IFn; if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any = A_arbace_j2g_dyn_A_const_216.GetRawRoot__O(); var arg_1811 any = ps__5; if linked_1808 == nil { arg_1806 = ifn_1809.Invoke_O_O__O(arg_1810, arg_1811) } else { arg_1806 = linked_1808.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1807, arg_1810, arg_1811) }; if linked_1801 == nil { tmp10 = ifn_1802.Invoke_O_O_O_O__O(arg_1803, arg_1804, arg_1805, arg_1806) } else { tmp10 = linked_1801.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1800, arg_1803, arg_1804, arg_1805, arg_1806) } } else { tmp10 = nil }
//line :298:1
				var tmp12 any = tmp10; var tmp13 any = A_arbace_j2g_dyn_A_const_217; var tmp14 any = A_arbace_j2g_dyn_A_const_218; var tmp15 any = A_arbace_j2g_dyn_A_const_219; var tmp16 any; var root_1812 any = A_arbace_j2g_dyn_A_const_220.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1812, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1814 lang.IFn


				if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any = A_arbace_j2g_dyn_A_const_221; var arg_1816 any; var root_1818 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any; var tmp17 any; var root_1823 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = A_arbace_j2g_dyn_A_const_222; var arg_1827 any = A_arbace_j2g_dyn_A_const_223; if linked_1824 == nil { tmp17 = ifn_1825.Invoke_O_O__O(arg_1826, arg_1827) } else { tmp17 = linked_1824.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1823, arg_1826, arg_1827) }; arg_1821 = lang.Tuple_Create_O__IPersistentVector(tmp17); var arg_1822 any = A_arbace_j2g_dyn_A_const_224; if linked_1819 == nil { arg_1816 = ifn_1820.Invoke_O_O__O(arg_1821, arg_1822) } else { arg_1816 = linked_1819.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1818, arg_1821, arg_1822) }; var arg_1817 any; var root_1828 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1830 lang.IFn
				if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any; var tmp18 any; var or__1927000174__auto____10 any; var root_1833 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1835 lang.IFn
				if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = t.F_n; if linked_1834 == nil { or__1927000174__auto____10 = ifn_1835.Invoke_O__O(arg_1836) } else { or__1927000174__auto____10 = linked_1834.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1833, arg_1836) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp18 = or__1927000174__auto____10 } else { var root_1837 any = A_arbace_j2g_dyn_A_const_225.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = t.F_n; if linked_1838 == nil { tmp18 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp18 = linked_1838.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1837, arg_1840) } }; if jrt.J2g_Truth(tmp18) { arg_1831 = nil } else { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp20 any; var root_1841 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = A_arbace_j2g_dyn_A_const_76; var arg_1845 any = t.F_n; var arg_1846 any = Lit_36; if linked_1842 == nil { tmp20 = ifn_1843.Invoke_O_O_O__O(arg_1844, arg_1845, arg_1846) } else { tmp20 = linked_1842.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1841, arg_1844, arg_1845, arg_1846) }; arg_1831 = lang.Tuple_Create_O__IPersistentVector(tmp19.Invoke_O__O(tmp20)) }
//line :302:1
				var arg_1832 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyn_A_const_226; var tmp23 any = A_arbace_j2g_dyn_A_const_235; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyn_A_const_236; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_237; var tmp28 any; var root_1878 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1878, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1880 lang.IFn

				if linked_1879 == nil { ifn_1880 = lang.IFn_Cast(root_1878) } else { ifn_1880 = nil }; var arg_1881 any = t.F_g; if linked_1879 == nil { tmp28 = ifn_1880.Invoke_O__O(arg_1881) } else { tmp28 = linked_1879.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1878, arg_1881) }
//line :302:1
				var tmp29 any = lang.Tuple_Create_O_O__IPersistentVector(tmp23, tmp24.Invoke_O_O__O(tmp25, tmp26.Invoke_O_O_O_O__O(tmp27, tmp28, A_arbace_j2g_dyn_A_const_238, A_arbace_j2g_dyn_A_const_239))); var tmp30 any = A_arbace_j2g_dyn_A_const_227; var tmp31 any = A_arbace_j2g_dyn_A_const_228; var tmp32 any; var root_1847 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1849 lang.IFn




				if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_1851 any; var root_1855 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1855, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1857 lang.IFn; if linked_1856 == nil { ifn_1857 = lang.IFn_Cast(root_1855) } else { ifn_1857 = nil }; var arg_1858 any; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp34 any; var root_1859 any = A_arbace_j2g_dyn_A_const_209.GetRawRoot__O(); var linked_1860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1859, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1861 lang.IFn; if linked_1860 == nil { ifn_1861 = lang.IFn_Cast(root_1859) } else { ifn_1861 = nil }; var arg_1862 any = real__3; if linked_1860 == nil { tmp34 = ifn_1861.Invoke_O__O(arg_1862) } else { tmp34 = linked_1860.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1859, arg_1862) }; arg_1858 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, nil, tmp34)).Ref(); if linked_1856 == nil { arg_1851 = ifn_1857.Invoke_O__O(arg_1858) } else { arg_1851 = linked_1856.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1855, arg_1858) }; var arg_1852 any; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp36 any; var root_1863 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1865 lang.IFn
				if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil); var tmp38 any; var root_1867 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = t.F_n; if linked_1868 == nil { tmp38 = ifn_1869.Invoke_O__O(arg_1870) } else { tmp38 = linked_1868.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1867, arg_1870) }; arg_1866 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_1864 == nil { tmp36 = ifn_1865.Invoke_O__O(arg_1866) } else { tmp36 = linked_1864.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1863, arg_1866) }; arg_1852 = tmp35.Invoke_O_O__O(tmp36, A_arbace_j2g_dyn_A_const_229)
//line :307:1
				var arg_1853 any = A_arbace_j2g_dyn_A_const_230; var arg_1854 any; var root_1871 any = A_arbace_j2g_dyn_A_const_231.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1871, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1873 lang.IFn

				if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any; var fnbody__1877 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(t.F_arg_conv); var tmp39 *jrt.Class; var fncls__1876 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class; if fncls__1876 == nil { var fncls__1876d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__1877); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class = fncls__1876d; tmp39 = fncls__1876d } else { tmp39 = fncls__1876 }; arg_1874 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1877, tmp39, nil); var arg_1875 any = ps__5; if linked_1872 == nil { arg_1854 = ifn_1873.Invoke_O_O__O(arg_1874, arg_1875) } else { arg_1854 = linked_1872.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1871, arg_1874, arg_1875) }
//line :307:1
				if linked_1848 == nil { tmp32 = ifn_1849.Invoke_O_O_O_O_O__O(arg_1850, arg_1851, arg_1852, arg_1853, arg_1854) } else { tmp32 = linked_1848.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1847, arg_1850, arg_1851, arg_1852, arg_1853, arg_1854) }
//line :302:1
				arg_1832 = lang.Tuple_Create_O__IPersistentVector(tmp21.Invoke_O_O_O_O_O_O__O(tmp22, tmp29, tmp30, tmp31, tmp32, A_arbace_j2g_dyn_A_const_234)); if linked_1829 == nil { arg_1817 = ifn_1830.Invoke_O_O__O(arg_1831, arg_1832) } else { arg_1817 = linked_1829.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1828, arg_1831, arg_1832) }
//line :301:1
				if linked_1813 == nil { tmp16 = ifn_1814.Invoke_O_O_O__O(arg_1815, arg_1816, arg_1817) } else { tmp16 = linked_1813.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1812, arg_1815, arg_1816, arg_1817) }
//line :298:1
				arg_1795 = tmp6.Invoke_O_O_O_O_O_O_O_O__O(tmp7, tmp8, tmp9, tmp12, tmp13, tmp14, tmp15, tmp16)
//line :290:1
				if linked_1792 == nil { ifn_1793.Invoke_O_O__O(arg_1794, arg_1795) } else { linked_1792.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1791, arg_1794, arg_1795) }; i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


















func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A{}; t.Ctor_O(p0); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :309:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_232, A_arbace_j2g_dyn_A_const_233, i__1)) }
//line :309:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A{}; t.Ctor_O(p0); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :309:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_232, A_arbace_j2g_dyn_A_const_233, i__1)) }


func A_arbace_j2g_dyn_go_method_names_A_New() *A_arbace_j2g_dyn_go_method_names_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Ctor() {}
//line :312:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Invoke_O_O__O(self, n__0 any) any {




	var root_2088 any = A_arbace_j2g_dyn_A_const_246.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_2092 any; var root_2093 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2094 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2093, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2095 lang.IFn
	if linked_2094 == nil { ifn_2095 = lang.IFn_Cast(root_2093) } else { ifn_2095 = nil }; var arg_2096 any; var iter__1927001039__auto____2 any; var fnbody__2326 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New(); var tmp1 *jrt.Class; var fncls__2325 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class
	if fncls__2325 == nil { var fncls__2325d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class = fncls__2325d; tmp1 = fncls__2325d } else { tmp1 = fncls__2325 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2326, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_2327 any = A_arbace_j2g_dyn_A_const_170.GetRawRoot__O(); var linked_2328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2327, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_2329 lang.IFn; if linked_2328 == nil { ifn_2329 = lang.IFn_Cast(root_2327) } else { ifn_2329 = nil }; var arg_2330 any = n__0; if linked_2328 == nil { tmp3 = ifn_2329.Invoke_O__O(arg_2330) } else { tmp3 = linked_2328.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_2327, arg_2330) }; arg_2096 = tmp2.Invoke_O__O(tmp3)
//line :318:1
	var arg_2097 any; var iter__1927001039__auto____2_2 any; var fnbody__2422 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(n__0); var tmp4 *jrt.Class
	var fncls__2421 /*line :318:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class








	if fncls__2421 == nil { var fncls__2421d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__2422); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class = fncls__2421d; tmp4 = fncls__2421d } else { tmp4 = fncls__2421 }; iter__1927001039__auto____2_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2422, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2_2); var tmp6 any; var root_2423 any = A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2423, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_2425 lang.IFn; if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 any = n__0; if linked_2424 == nil { tmp6 = ifn_2425.Invoke_O__O(arg_2426) } else { tmp6 = linked_2424.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_2423, arg_2426) }; arg_2097 = tmp5.Invoke_O__O(tmp6)
//line :318:1
	if linked_2094 == nil { arg_2092 = ifn_2095.Invoke_O_O__O(arg_2096, arg_2097) } else { arg_2092 = linked_2094.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2093, arg_2096, arg_2097) }
//line :317:1
	if linked_2089 == nil { return ifn_2090.Invoke_O_O__O(arg_2091, arg_2092) } else { return linked_2089.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2088, arg_2091, arg_2092)
	} }
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Ctor() {}
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Invoke_O_O__O(self, s__711000271__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2324 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(self, s__711000271__1); var tmp2 *jrt.Class; var fncls__2323 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class; if fncls__2323 == nil { var fncls__2323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__2324); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class = fncls__2323d; tmp2 = fncls__2323d } else { tmp2 = fncls__2323 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2324, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :319:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A{}; t.Ctor_O_O(p0, p1); return t }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Ctor_O_O(c__iter__711000270, c__s__711000271 any) { t.F_iter__711000270 = c__iter__711000270; t.F_s__711000271 = c__s__711000271 }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Invoke_O__O(self any) any { { var s__711000271__1 any; var t_ any = t.F_s__711000271; t.F_s__711000271 = nil; s__711000271__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2098 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = s__711000271__1; if linked_2099 == nil { temp__1927000414__auto____2 = ifn_2100.Invoke_O__O(arg_2101) } else { temp__1927000414__auto____2 = linked_2099.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2098, arg_2101) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_2102 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = xs__1927001018__auto____3; if linked_2103 == nil { c__4 = ifn_2104.Invoke_O__O(arg_2105) } else { c__4 = linked_2103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2102, arg_2105) }; var tmp1 any; var and__1927000168__auto____5 any = c__4
														if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2106 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2106, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = c__4; var arg_2110 any = Lit_66; if linked_2107 == nil { tmp1 = ifn_2108.Invoke_O_O__O(arg_2109, arg_2110) } else { tmp1 = linked_2107.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2106, arg_2109, arg_2110) } } else { tmp1 = and__1927000168__auto____5 }
//line :319:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__2172 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New(); var tmp2 *jrt.Class; var fncls__2171 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class; if fncls__2171 == nil { var fncls__2171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class = fncls__2171d; tmp2 = fncls__2171d } else { tmp2 = fncls__2171 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2172, tmp2, nil); var fs__1927001036__auto____6 any; var root_2173 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var tmp5 any; var root_2177 any = A_arbace_j2g_dyn_A_const_46.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2179 lang.IFn

		if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = c__4; if linked_2178 == nil { tmp5 = ifn_2179.Invoke_O__O(arg_2180) } else { tmp5 = linked_2178.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2177, arg_2180) }; if jrt.J2g_Truth(tmp5) {
			var root_2181 any = A_arbace_j2g_dyn_A_const_208.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var tmp6 *lang.Keyword = A_arbace_j2g_dyn_A_const_49; var arg_2184 any = tmp6.Invoke_O__O(A_arbace_j2g_dyn_A_const_50.Get__O()); var arg_2185 any; var root_2186 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = c__4; if linked_2187 == nil { arg_2185 = ifn_2188.Invoke_O__O(arg_2189) } else { arg_2185 = linked_2187.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2186, arg_2189) }; if linked_2182 == nil { tmp4 = ifn_2183.Invoke_O_O__O(arg_2184, arg_2185) } else { tmp4 = linked_2182.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_2181, arg_2184, arg_2185) } } else {
//line :321:1
				var iter__1927001039__auto____6 any; var fnbody__2301 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New(); var tmp7 *jrt.Class
				var fncls__2300 /*line :321:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class

				if fncls__2300 == nil { var fncls__2300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class = fncls__2300d; tmp7 = fncls__2300d } else { tmp7 = fncls__2300 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2301, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp9 *lang.Keyword = A_arbace_j2g_dyn_A_const_115; var tmp10 any; var root_2302 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); var linked_2303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2302, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2304 lang.IFn; if linked_2303 == nil { ifn_2304 = lang.IFn_Cast(root_2302) } else { ifn_2304 = nil }; var arg_2305 any = c__4; if linked_2303 == nil { tmp10 = ifn_2304.Invoke_O__O(arg_2305) } else { tmp10 = linked_2303.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2302, arg_2305) }; tmp4 = tmp8.Invoke_O__O(tmp9.Invoke_O__O(tmp10)) }
//line :319:1
		arg_2176 = tmp3.Invoke_O__O(tmp4); if linked_2174 == nil { fs__1927001036__auto____6 = ifn_2175.Invoke_O__O(arg_2176) } else { fs__1927001036__auto____6 = linked_2174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2173, arg_2176) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2306 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2306, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2308 lang.IFn; if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = fs__1927001036__auto____6; var arg_2310 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__711000270); var tmp12 any; var root_2311 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2311, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2313 lang.IFn; if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = s__711000271__1; if linked_2312 == nil { tmp12 = ifn_2313.Invoke_O__O(arg_2314) } else { tmp12 = linked_2312.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2311, arg_2314) }; arg_2310 = tmp11.Invoke_O__O(tmp12); if linked_2307 == nil { return ifn_2308.Invoke_O_O__O(arg_2309, arg_2310) } else { return linked_2307.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2306, arg_2309, arg_2310) } } else { var tmp13 any; var root_2315 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2315, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2317 lang.IFn; if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any = s__711000271__1; if linked_2316 == nil { tmp13 = ifn_2317.Invoke_O__O(arg_2318) } else { tmp13 = linked_2316.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2315, arg_2318) }; s__711000271__1 = tmp13; continue L1 } } else { var tmp14 any; var root_2319 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2319, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2321 lang.IFn; if linked_2320 == nil { ifn_2321 = lang.IFn_Cast(root_2319) } else { ifn_2321 = nil }; var arg_2322 any = s__711000271__1; if linked_2320 == nil { tmp14 = ifn_2321.Invoke_O__O(arg_2322) } else { tmp14 = linked_2320.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2319, arg_2322) }; s__711000271__1 = tmp14; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :319:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Ctor() {}
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Invoke_O_O__O(self, s__711000273__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2170 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(s__711000273__1, self); var tmp2 *jrt.Class; var fncls__2169 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class; if fncls__2169 == nil { var fncls__2169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__2170); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class = fncls__2169d; tmp2 = fncls__2169d } else { tmp2 = fncls__2169 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2170, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :319:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A{}; t.Ctor_O_O(p0, p1); return t }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Ctor_O_O(c__s__711000273, c__iter__711000272 any) { t.F_s__711000273 = c__s__711000273; t.F_iter__711000272 = c__iter__711000272 }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Invoke_O__O(self any) any { { var s__711000273__1 any; var t_ any = t.F_s__711000273; t.F_s__711000273 = nil; s__711000273__1 = t_; for { var temp__1927000414__auto____2 any; var root_2111 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = s__711000273__1; if linked_2112 == nil { temp__1927000414__auto____2 = ifn_2113.Invoke_O__O(arg_2114) } else { temp__1927000414__auto____2 = linked_2112.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2111, arg_2114) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000273__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2115 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = s__711000273__3; if linked_2116 == nil { tmp1 = ifn_2117.Invoke_O__O(arg_2118) } else { tmp1 = linked_2116.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2115, arg_2118) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2119 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2119, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2121 lang.IFn; if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; var arg_2122 any = s__711000273__3; if linked_2120 == nil { c__1927001037__auto____4 = ifn_2121.Invoke_O__O(arg_2122) } else { c__1927001037__auto____4 = linked_2120.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2119, arg_2122) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000275__6 any; var root_2123 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2125 lang.IFn; if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2124 == nil { b__711000275__6 = ifn_2125.Invoke_O__O(arg_2126) } else { b__711000275__6 = linked_2124.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2123, arg_2126) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2133 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(b__711000275__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2132 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class; if fncls__2132 == nil { var fncls__2132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__2133); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class = fncls__2132d; tmp3 = fncls__2132d } else { tmp3 = fncls__2132 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2133, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2134 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any; var root_2139 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = b__711000275__6; if linked_2140 == nil { arg_2137 = ifn_2141.Invoke_O__O(arg_2142) } else { arg_2137 = linked_2140.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2139, arg_2142) }; var arg_2138 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp5 any; var root_2143 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = s__711000273__3; if linked_2144 == nil { tmp5 = ifn_2145.Invoke_O__O(arg_2146) } else { tmp5 = linked_2144.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2143, arg_2146) }; arg_2138 = tmp4.Invoke_O__O(tmp5); if linked_2135 == nil { return ifn_2136.Invoke_O_O__O(arg_2137, arg_2138) } else { return linked_2135.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2134, arg_2137, arg_2138) } } else { var root_2147 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any; var root_2152 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = b__711000275__6; if linked_2153 == nil { arg_2150 = ifn_2154.Invoke_O__O(arg_2155) } else { arg_2150 = linked_2153.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2152, arg_2155) }; var arg_2151 any; if linked_2148 == nil { return ifn_2149.Invoke_O_O__O(arg_2150, arg_2151) } else { return linked_2148.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2147, arg_2150, arg_2151) } } } else { var nme__4 any; var root_2156 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = s__711000273__3; if linked_2157 == nil { nme__4 = ifn_2158.Invoke_O__O(arg_2159) } else { nme__4 = linked_2157.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2156, arg_2159) }; var root_2160 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2160, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2162 lang.IFn; if linked_2161 == nil { ifn_2162 = lang.IFn_Cast(root_2160) } else { ifn_2162 = nil }; var arg_2163 any = nme__4; var arg_2164 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp7 any; var root_2165 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2165, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2167 lang.IFn; if linked_2166 == nil { ifn_2167 = lang.IFn_Cast(root_2165) } else { ifn_2167 = nil }; var arg_2168 any = s__711000273__3; if linked_2166 == nil { tmp7 = ifn_2167.Invoke_O__O(arg_2168) } else { tmp7 = linked_2166.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2165, arg_2168) }; arg_2164 = tmp6.Invoke_O__O(tmp7); if linked_2161 == nil { return ifn_2162.Invoke_O_O__O(arg_2163, arg_2164) } else { return linked_2161.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2160, arg_2163, arg_2164) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :319:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Ctor_O_I_O(c__b__711000275 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000275 = c__b__711000275; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :319:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Invoke_O__O(self any) any { { var i__711000274__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000274__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nme__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000274__1)); var root_2127 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2127, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2129 lang.IFn; if linked_2128 == nil { ifn_2129 = lang.IFn_Cast(root_2127) } else { ifn_2129 = nil }; var arg_2130 any = t.F_b__711000275; var arg_2131 any = nme__2; if linked_2128 == nil { ifn_2129.Invoke_O_O__O(arg_2130, arg_2131) } else { linked_2128.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2127, arg_2130, arg_2131) }; i__711000274__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000274__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A{}; t.Ctor(); return t }
//line :323:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Ctor() {}
//line :323:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Invoke_O_O__O(self, s__711000285__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2299 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(s__711000285__1, self); var tmp2 *jrt.Class; var fncls__2298 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class; if fncls__2298 == nil { var fncls__2298d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__2299); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class = fncls__2298d; tmp2 = fncls__2298d } else { tmp2 = fncls__2298 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2299, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :323:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Ctor_O_O(c__s__711000285, c__iter__711000284 any) { t.F_s__711000285 = c__s__711000285; t.F_iter__711000284 = c__iter__711000284 }
//line :323:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Invoke_O__O(self any) any { { var s__711000285__1 any; var t_ any = t.F_s__711000285; t.F_s__711000285 = nil; s__711000285__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2190 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = s__711000285__1; if linked_2191 == nil { temp__1927000414__auto____2 = ifn_2192.Invoke_O__O(arg_2193) } else { temp__1927000414__auto____2 = linked_2191.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2190, arg_2193) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000285__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2194 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2194, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2196 lang.IFn; if linked_2195 == nil { ifn_2196 = lang.IFn_Cast(root_2194) } else { ifn_2196 = nil }; var arg_2197 any = s__711000285__3; if linked_2195 == nil { tmp1 = ifn_2196.Invoke_O__O(arg_2197) } else { tmp1 = linked_2195.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2194, arg_2197) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2198 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2198, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2200 lang.IFn; if linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var arg_2201 any = s__711000285__3; if linked_2199 == nil { c__1927001037__auto____4 = ifn_2200.Invoke_O__O(arg_2201) } else { c__1927001037__auto____4 = linked_2199.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2198, arg_2201) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000287__6 any; var root_2202 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2204 lang.IFn; if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2203 == nil { b__711000287__6 = ifn_2204.Invoke_O__O(arg_2205) } else { b__711000287__6 = linked_2203.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2202, arg_2205) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2235 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(b__711000287__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2234 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class; if fncls__2234 == nil { var fncls__2234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__2235); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class = fncls__2234d; tmp3 = fncls__2234d } else { tmp3 = fncls__2234 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2235, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2236 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2236, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2238 lang.IFn; if linked_2237 == nil { ifn_2238 = lang.IFn_Cast(root_2236) } else { ifn_2238 = nil }; var arg_2239 any; var root_2241 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2243 lang.IFn; if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any = b__711000287__6; if linked_2242 == nil { arg_2239 = ifn_2243.Invoke_O__O(arg_2244) } else { arg_2239 = linked_2242.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2241, arg_2244) }; var arg_2240 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp5 any; var root_2245 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2247 lang.IFn; if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; var arg_2248 any = s__711000285__3; if linked_2246 == nil { tmp5 = ifn_2247.Invoke_O__O(arg_2248) } else { tmp5 = linked_2246.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2245, arg_2248) }; arg_2240 = tmp4.Invoke_O__O(tmp5); if linked_2237 == nil { return ifn_2238.Invoke_O_O__O(arg_2239, arg_2240) } else { return linked_2237.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2236, arg_2239, arg_2240) } } else { var root_2249 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any; var root_2254 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2256 lang.IFn; if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any = b__711000287__6; if linked_2255 == nil { arg_2252 = ifn_2256.Invoke_O__O(arg_2257) } else { arg_2252 = linked_2255.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2254, arg_2257) }; var arg_2253 any; if linked_2250 == nil { return ifn_2251.Invoke_O_O__O(arg_2252, arg_2253) } else { return linked_2250.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2249, arg_2252, arg_2253) } } } else { var mm__4 any; var root_2258 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = s__711000285__3; if linked_2259 == nil { mm__4 = ifn_2260.Invoke_O__O(arg_2261) } else { mm__4 = linked_2259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2258, arg_2261) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2262 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2264 lang.IFn
																				if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any; var root_2266 any = A_arbace_j2g_dyn_A_const_168.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2268 lang.IFn; if linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = mm__4; if linked_2267 == nil { arg_2265 = ifn_2268.Invoke_O__O(arg_2269) } else { arg_2265 = linked_2267.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2266, arg_2269) }; if linked_2263 == nil { and__1927000168__auto____5 = ifn_2264.Invoke_O__O(arg_2265) } else { and__1927000168__auto____5 = linked_2263.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2262, arg_2265) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2270 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_2271 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2270, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2272 lang.IFn; if linked_2271 == nil { ifn_2272 = lang.IFn_Cast(root_2270) } else { ifn_2272 = nil }; var arg_2273 any = Lit_35; var arg_2274 any = A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__4); if linked_2271 == nil { and__1927000168__auto____6 = ifn_2272.Invoke_O_O__O(arg_2273, arg_2274) } else { and__1927000168__auto____6 = linked_2271.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2270, arg_2273, arg_2274) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2275 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2277 lang.IFn; if linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var arg_2278 any = Lit_73; var arg_2279 any = A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__4); if linked_2276 == nil { tmp6 = ifn_2277.Invoke_O_O__O(arg_2278, arg_2279) } else { tmp6 = linked_2276.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2275, arg_2278, arg_2279) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :323:1
	if jrt.J2g_Truth(tmp6) { var root_2280 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2280, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2282 lang.IFn; if linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any; var root_2285 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2287 lang.IFn

		if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__4); var arg_2289 any = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__4); if linked_2286 == nil { arg_2283 = ifn_2287.Invoke_O_O__O(arg_2288, arg_2289) } else { arg_2283 = linked_2286.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2285, arg_2288, arg_2289) }
//line :323:1
		var arg_2284 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp8 any; var root_2290 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = s__711000285__3; if linked_2291 == nil { tmp8 = ifn_2292.Invoke_O__O(arg_2293) } else { tmp8 = linked_2291.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2290, arg_2293) }; arg_2284 = tmp7.Invoke_O__O(tmp8); if linked_2281 == nil { return ifn_2282.Invoke_O_O__O(arg_2283, arg_2284) } else { return linked_2281.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2280, arg_2283, arg_2284) } } else { var tmp9 any; var root_2294 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2294, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2296 lang.IFn; if linked_2295 == nil { ifn_2296 = lang.IFn_Cast(root_2294) } else { ifn_2296 = nil }; var arg_2297 any = s__711000285__3; if linked_2295 == nil { tmp9 = ifn_2296.Invoke_O__O(arg_2297) } else { tmp9 = linked_2295.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2294, arg_2297) }; s__711000285__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :323:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :323:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Ctor_O_I_O(c__b__711000287 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000287 = c__b__711000287; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :323:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Invoke_O__O(self any) any { { var i__711000286__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000286__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000286__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2206 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_2207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2206, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2208 lang.IFn
																					if linked_2207 == nil { ifn_2208 = lang.IFn_Cast(root_2206) } else { ifn_2208 = nil }; var arg_2209 any; var root_2210 any = A_arbace_j2g_dyn_A_const_168.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2210, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2212 lang.IFn; if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = mm__2; if linked_2211 == nil { arg_2209 = ifn_2212.Invoke_O__O(arg_2213) } else { arg_2209 = linked_2211.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2210, arg_2213) }; if linked_2207 == nil { and__1927000168__auto____3 = ifn_2208.Invoke_O__O(arg_2209) } else { and__1927000168__auto____3 = linked_2207.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2206, arg_2209) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_2214 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_2215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2214, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2216 lang.IFn; if linked_2215 == nil { ifn_2216 = lang.IFn_Cast(root_2214) } else { ifn_2216 = nil }; var arg_2217 any = Lit_35; var arg_2218 any = A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__2); if linked_2215 == nil { and__1927000168__auto____4 = ifn_2216.Invoke_O_O__O(arg_2217, arg_2218) } else { and__1927000168__auto____4 = linked_2215.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2214, arg_2217, arg_2218) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_2219 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2221 lang.IFn; if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any = Lit_73; var arg_2223 any = A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__2); if linked_2220 == nil { tmp2 = ifn_2221.Invoke_O_O__O(arg_2222, arg_2223) } else { tmp2 = linked_2220.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2219, arg_2222, arg_2223) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :323:1
	if jrt.J2g_Truth(tmp2) { var root_2224 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = t.F_b__711000287; var arg_2228 any; var root_2229 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2231 lang.IFn

		if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = A_arbace_j2g_dyn_A_const_67.Invoke_O__O(mm__2); var arg_2233 any = A_arbace_j2g_dyn_A_const_68.Invoke_O__O(mm__2); if linked_2230 == nil { arg_2228 = ifn_2231.Invoke_O_O__O(arg_2232, arg_2233) } else { arg_2228 = linked_2230.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2229, arg_2232, arg_2233) }
//line :323:1
		if linked_2225 == nil { ifn_2226.Invoke_O_O__O(arg_2227, arg_2228) } else { linked_2225.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2224, arg_2227, arg_2228) }; i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } else { i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(p0 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A{}; t.Ctor_O(p0); return t }
//line :327:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :327:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Invoke_O_O__O(self, s__711000297__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2420 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(s__711000297__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__2419 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class; if fncls__2419 == nil { var fncls__2419d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__2420); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class = fncls__2419d; tmp2 = fncls__2419d } else { tmp2 = fncls__2419 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2420, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :327:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :327:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Ctor_O_O_O(c__s__711000297, c__n, c__iter__711000296 any) { t.F_s__711000297 = c__s__711000297; t.F_n = c__n; t.F_iter__711000296 = c__iter__711000296 }
//line :327:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Invoke_O__O(self any) any { { var s__711000297__1 any; var t_ any = t.F_s__711000297; t.F_s__711000297 = nil; s__711000297__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2331 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2331, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2333 lang.IFn; if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = s__711000297__1; if linked_2332 == nil { temp__1927000414__auto____2 = ifn_2333.Invoke_O__O(arg_2334) } else { temp__1927000414__auto____2 = linked_2332.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2331, arg_2334) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000297__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2335 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = s__711000297__3; if linked_2336 == nil { tmp1 = ifn_2337.Invoke_O__O(arg_2338) } else { tmp1 = linked_2336.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2335, arg_2338) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2339 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = s__711000297__3; if linked_2340 == nil { c__1927001037__auto____4 = ifn_2341.Invoke_O__O(arg_2342) } else { c__1927001037__auto____4 = linked_2340.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2339, arg_2342) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000299__6 any; var root_2343 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2345 lang.IFn; if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2344 == nil { b__711000299__6 = ifn_2345.Invoke_O__O(arg_2346) } else { b__711000299__6 = linked_2344.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2343, arg_2346) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2366 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(t.F_n, b__711000299__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2365 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class; if fncls__2365 == nil { var fncls__2365d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__2366); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class = fncls__2365d; tmp3 = fncls__2365d } else { tmp3 = fncls__2365 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2366, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2367 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2367, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2369 lang.IFn; if linked_2368 == nil { ifn_2369 = lang.IFn_Cast(root_2367) } else { ifn_2369 = nil }; var arg_2370 any; var root_2372 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = b__711000299__6; if linked_2373 == nil { arg_2370 = ifn_2374.Invoke_O__O(arg_2375) } else { arg_2370 = linked_2373.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2372, arg_2375) }; var arg_2371 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp5 any; var root_2376 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = s__711000297__3; if linked_2377 == nil { tmp5 = ifn_2378.Invoke_O__O(arg_2379) } else { tmp5 = linked_2377.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2376, arg_2379) }; arg_2371 = tmp4.Invoke_O__O(tmp5); if linked_2368 == nil { return ifn_2369.Invoke_O_O__O(arg_2370, arg_2371) } else { return linked_2368.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2367, arg_2370, arg_2371) } } else { var root_2380 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2380, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2382 lang.IFn; if linked_2381 == nil { ifn_2382 = lang.IFn_Cast(root_2380) } else { ifn_2382 = nil }; var arg_2383 any; var root_2385 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2385, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2387 lang.IFn; if linked_2386 == nil { ifn_2387 = lang.IFn_Cast(root_2385) } else { ifn_2387 = nil }; var arg_2388 any = b__711000299__6; if linked_2386 == nil { arg_2383 = ifn_2387.Invoke_O__O(arg_2388) } else { arg_2383 = linked_2386.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2385, arg_2388) }; var arg_2384 any; if linked_2381 == nil { return ifn_2382.Invoke_O_O__O(arg_2383, arg_2384) } else { return linked_2381.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2380, arg_2383, arg_2384) } } } else { var j__4 any; var root_2389 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any = s__711000297__3; if linked_2390 == nil { j__4 = ifn_2391.Invoke_O__O(arg_2392) } else { j__4 = linked_2390.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2389, arg_2392) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2393 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = j__4; var arg_2397 any = t.F_n; if linked_2394 == nil { and__1927000168__auto____5 = ifn_2395.Invoke_O_O__O(arg_2396, arg_2397) } else { and__1927000168__auto____5 = linked_2394.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2393, arg_2396, arg_2397) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2398 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_2399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2398, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2400 lang.IFn; if linked_2399 == nil { ifn_2400 = lang.IFn_Cast(root_2398) } else { ifn_2400 = nil }; var arg_2401 any = j__4; if linked_2399 == nil { tmp6 = ifn_2400.Invoke_O__O(arg_2401) } else { tmp6 = linked_2399.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2398, arg_2401) } } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_2402 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2402, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2404 lang.IFn; if linked_2403 == nil { ifn_2404 = lang.IFn_Cast(root_2402) } else { ifn_2404 = nil }; var arg_2405 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp8 any; var root_2407 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2409 lang.IFn
														if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = j__4; if linked_2408 == nil { tmp8 = ifn_2409.Invoke_O__O(arg_2410) } else { tmp8 = linked_2408.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2407, arg_2410) }; arg_2405 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :327:1
	var arg_2406 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp10 any; var root_2411 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = s__711000297__3; if linked_2412 == nil { tmp10 = ifn_2413.Invoke_O__O(arg_2414) } else { tmp10 = linked_2412.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2411, arg_2414) }; arg_2406 = tmp9.Invoke_O__O(tmp10); if linked_2403 == nil { return ifn_2404.Invoke_O_O__O(arg_2405, arg_2406) } else { return linked_2403.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2402, arg_2405, arg_2406) } } else { var tmp11 any; var root_2415 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = s__711000297__3; if linked_2416 == nil { tmp11 = ifn_2417.Invoke_O__O(arg_2418) } else { tmp11 = linked_2416.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2415, arg_2418) }; s__711000297__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :327:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :327:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Ctor_O_O_I_O(c__n, c__b__711000299 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000299 = c__b__711000299; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :327:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Invoke_O__O(self any) any { { var i__711000298__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000298__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000298__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2347 any = A_arbace_j2g_dyn_A_const_56.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = j__2; var arg_2351 any = t.F_n; if linked_2348 == nil { and__1927000168__auto____3 = ifn_2349.Invoke_O_O__O(arg_2350, arg_2351) } else { and__1927000168__auto____3 = linked_2348.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2347, arg_2350, arg_2351) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2352 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = j__2; if linked_2353 == nil { tmp2 = ifn_2354.Invoke_O__O(arg_2355) } else { tmp2 = linked_2353.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2352, arg_2355) } } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_2356 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = t.F_b__711000299; var arg_2360 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp4 any; var root_2361 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2363 lang.IFn
																if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = j__2; if linked_2362 == nil { tmp4 = ifn_2363.Invoke_O__O(arg_2364) } else { tmp4 = linked_2362.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2361, arg_2364) }; arg_2360 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :327:1
	if linked_2357 == nil { ifn_2358.Invoke_O_O__O(arg_2359, arg_2360) } else { linked_2357.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2356, arg_2359, arg_2360) }; i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } else { i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_sub_forms_A_New() *A_arbace_j2g_dyn_sub_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Ctor() {}
//line :330:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Invoke_O_O_O_O__O(self, n__0, ifaces__1, dyn_keys__2 any) any { var g__4 any; var root_2427 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_2429 lang.IFn; if






	linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = n__0; if linked_2428 == nil { g__4 = ifn_2429.Invoke_O__O(arg_2430) } else { g__4 = linked_2428.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_2427, arg_2430) }; var recv__5 any; var tmp1 lang.IFn = /*line :330:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_289; var tmp3 any; var root_2980 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2980, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2982 lang.IFn; if







	linked_2981 == nil { ifn_2982 = lang.IFn_Cast(root_2980) } else { ifn_2982 = nil }; var arg_2983 any = g__4; if linked_2981 == nil { tmp3 = ifn_2982.Invoke_O__O(arg_2983) } else { tmp3 = linked_2981.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2980, arg_2983) }; recv__5 = tmp1.Invoke_O_O__O(tmp2, tmp3); var own__6 any; var root_2431 any = /*line :330:1*/A_arbace_j2g_dyn_A_const_246.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2431, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2433 lang.IFn; if








	linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2435 any; var iter__1927001039__auto____6 any; var fnbody__2509 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New(); var tmp4 *jrt.Class; var fncls__2508 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class; if fncls__2508 == nil { var fncls__2508d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, nil); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class = fncls__2508d; tmp4 = fncls__2508d } else { tmp4 = fncls__2508 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2509, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp6 any; var root_2510 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2510, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_2512 lang.IFn; if linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any = n__0; if linked_2511 == nil { tmp6 = ifn_2512.Invoke_O__O(arg_2513) } else { tmp6 = linked_2511.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_2510, arg_2513) }; arg_2435 = tmp5.Invoke_O__O(tmp6); if linked_2432 == nil { own__6 = ifn_2433.Invoke_O_O__O(arg_2434, arg_2435) } else { own__6 = linked_2432.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2431, arg_2434, arg_2435) }; var dyn_set__7 any; var root_2514 any = /*line :330:1*/A_arbace_j2g_dyn_A_const_247.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2516 lang.IFn; if









	linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = dyn_keys__2; if linked_2515 == nil { dyn_set__7 = ifn_2516.Invoke_O__O(arg_2517) } else { dyn_set__7 = linked_2515.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2514, arg_2517) }; var ks__8 any; var root_2518 any = /*line :330:1*/A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2518, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2520 lang.IFn; if










	linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any; var root_2522 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2523 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2522, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2524 lang.IFn; if linked_2523 == nil { ifn_2524 = lang.IFn_Cast(root_2522) } else { ifn_2524 = nil }; var arg_2525 any = dyn_keys__2; var arg_2526 any; var root_2527 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any; var root_2531 any = A_arbace_j2g_dyn_A_const_248.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = dyn_set__7; var arg_2535 any; var root_2536 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2538 lang.IFn; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any = own__6; if linked_2537 == nil { arg_2535 = ifn_2538.Invoke_O__O(arg_2539) } else { arg_2535 = linked_2537.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2536, arg_2539) }; if linked_2532 == nil { arg_2530 = ifn_2533.Invoke_O_O__O(arg_2534, arg_2535) } else { arg_2530 = linked_2532.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2531, arg_2534, arg_2535) }; if linked_2528 == nil { arg_2526 = ifn_2529.Invoke_O__O(arg_2530) } else { arg_2526 = linked_2528.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2527, arg_2530) }; if linked_2523 == nil { arg_2521 = ifn_2524.Invoke_O_O__O(arg_2525, arg_2526) } else { arg_2521 = linked_2523.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2522, arg_2525, arg_2526) }; if linked_2519 == nil { ks__8 = ifn_2520.Invoke_O__O(arg_2521) } else { ks__8 = linked_2519.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2518, arg_2521) }; var clash__9 any; var root_2540 any = /*line :330:1*/A_arbace_j2g_dyn_A_const_249.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, A_arbace_j2g_dyn_go_method_names_A_fn_class); var ifn_2542 lang.IFn; if











	linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any = n__0; if linked_2541 == nil { clash__9 = ifn_2542.Invoke_O__O(arg_2543) } else { clash__9 = linked_2541.(*A_arbace_j2g_dyn_go_method_names_A).Invoke_O_O__O(root_2540, arg_2543) }; var slots__10 any; var root_2544 any = /*line :330:1*/A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2546 lang.IFn; if












	linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_136, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2545 == nil { slots__10 = ifn_2546.Invoke_O__O(arg_2547) } else { slots__10 = linked_2545.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2544, arg_2547) }; var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_18.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_250; var tmp10 *jrt.RefArray = jrt.ConstRefArray("[0,7,s12:---- DynSub_ns13:: proxies of ns2:, ns8: methods", []*jrt.Class{jrt.String_class}); var tmp11 any; var root_2556 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2558 lang.IFn; if
	linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = n__0; if linked_2557 == nil { tmp11 = ifn_2558.Invoke_O__O(arg_2559) } else { tmp11 = linked_2557.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2556, arg_2559) }; var tmp12 any = tmp11; var tmp13 any; var root_2560 any = /*line :344:1*/A_arbace_j2g_dyn_A_const_119.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2562 lang.IFn; if
	linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = n__0; var arg_2564 any = Lit_5; var arg_2565 any = Lit_6; if linked_2561 == nil { tmp13 = ifn_2562.Invoke_O_O_O__O(arg_2563, arg_2564, arg_2565) } else { tmp13 = linked_2561.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2560, arg_2563, arg_2564, arg_2565) }; var tmp14 any = /*line :344:1*/tmp8.Invoke_O_O__O(tmp9, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil, tmp13, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__8)).Ref(), nil)).Ref()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_dyn_A_const_251; var tmp17 any; var root_2566 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2566, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2568 lang.IFn; if


	linked_2567 == nil { ifn_2568 = lang.IFn_Cast(root_2566) } else { ifn_2568 = nil }; var arg_2569 any = g__4; if linked_2567 == nil { tmp17 = ifn_2568.Invoke_O__O(arg_2569) } else { tmp17 = linked_2567.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2566, arg_2569) }; var tmp18 any = tmp17; var tmp19 /*line :344:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_154, nil, Lit_155); var tmp20 any; var root_2570 any = A_arbace_j2g_dyn_A_const_119.GetRawRoot__O(); var linked_2571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2570, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2572 lang.IFn; if



	linked_2571 == nil { ifn_2572 = lang.IFn_Cast(root_2570) } else { ifn_2572 = nil }; var arg_2573 any = n__0; var arg_2574 any = Lit_5; var arg_2575 any = Lit_6; if linked_2571 == nil { tmp20 = ifn_2572.Invoke_O_O_O__O(arg_2573, arg_2574, arg_2575) } else { tmp20 = linked_2571.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2570, arg_2573, arg_2574, arg_2575) }; var tmp21 any = /*line :344:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, g__4, nil, tmp20, nil)).Ref(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyn_A_const_252; var tmp24 any; var root_2576 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2578 lang.IFn; if





	linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = A_arbace_j2g_dyn_A_const_76; var arg_2580 any = n__0; if linked_2577 == nil { tmp24 = ifn_2578.Invoke_O_O__O(arg_2579, arg_2580) } else { tmp24 = linked_2577.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_2576, arg_2579, arg_2580) }; var tmp25 any = /*line :344:1*/tmp15.Invoke_O_O_O_O__O(tmp16, tmp18, tmp21, tmp22.Invoke_O_O_O__O(tmp23, tmp24, A_arbace_j2g_dyn_A_const_253)); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_254; var tmp28 any; var root_2581 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2583 lang.IFn; if






	linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any = slots__10; var arg_2585 any = A_arbace_j2g_dyn_A_const_255; if linked_2582 == nil { tmp28 = ifn_2583.Invoke_O_O__O(arg_2584, arg_2585) } else { tmp28 = linked_2582.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2581, arg_2584, arg_2585) }; var tmp29 any = tmp28; var tmp30 any; var root_2586 any = /*line :344:1*/A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2586, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2588 lang.IFn; if







	linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_2590 any = A_arbace_j2g_dyn_A_const_256; var arg_2591 any = A_arbace_j2g_dyn_A_const_257; var arg_2592 any; var root_2593 any = A_arbace_j2g_dyn_A_const_231.GetRawRoot__O(); var linked_2594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2593, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2595 lang.IFn; if linked_2594 == nil { ifn_2595 = lang.IFn_Cast(root_2593) } else { ifn_2595 = nil }; var arg_2596 any; var fnbody__2599 any = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New(); var tmp31 *jrt.Class; var fncls__2598 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class; if fncls__2598 == nil { var fncls__2598d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, nil); A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class = fncls__2598d; tmp31 = fncls__2598d } else { tmp31 = fncls__2598 }; arg_2596 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2599, tmp31, nil); var arg_2597 any = ks__8; if linked_2594 == nil { arg_2592 = ifn_2595.Invoke_O_O__O(arg_2596, arg_2597) } else { arg_2592 = linked_2594.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2593, arg_2596, arg_2597) }; if linked_2587 == nil { tmp30 = ifn_2588.Invoke_O_O_O_O__O(arg_2589, arg_2590, arg_2591, arg_2592) } else { tmp30 = linked_2587.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2586, arg_2589, arg_2590, arg_2591, arg_2592) }; var tmp32 any = /*line :344:1*/tmp26.Invoke_O_O_O__O(tmp27, tmp29, tmp30); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp34 any = A_arbace_j2g_dyn_A_const_258; var tmp35 any; var root_2600 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2602 lang.IFn; if








	linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any; var root_2605 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2605, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2607 lang.IFn; if linked_2606 == nil { ifn_2607 = lang.IFn_Cast(root_2605) } else { ifn_2607 = nil }; var arg_2608 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2606 == nil { arg_2603 = ifn_2607.Invoke_O__O(arg_2608) } else { arg_2603 = linked_2606.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2605, arg_2608) }; var arg_2604 any = A_arbace_j2g_dyn_A_const_259; if linked_2601 == nil { tmp35 = ifn_2602.Invoke_O_O__O(arg_2603, arg_2604) } else { tmp35 = linked_2601.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2600, arg_2603, arg_2604) }; var tmp36 any = tmp35; var tmp37 any; var root_2609 any = /*line :344:1*/A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_2610 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2609, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2611 lang.IFn; if









	linked_2610 == nil { ifn_2611 = lang.IFn_Cast(root_2609) } else { ifn_2611 = nil }; var arg_2612 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_2613 any = A_arbace_j2g_dyn_A_const_260; var arg_2614 any = A_arbace_j2g_dyn_A_const_261; var arg_2615 any; var iter__1927001039__auto____11 any; var fnbody__2677 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New(); var tmp38 *jrt.Class; var fncls__2676 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class; if fncls__2676 == nil { var fncls__2676d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, nil); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class = fncls__2676d; tmp38 = fncls__2676d } else { tmp38 = fncls__2676 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2677, tmp38, nil); var tmp39 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11); var tmp40 any; var root_2678 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any; var root_2682 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2682, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2684 lang.IFn; if linked_2683 == nil { ifn_2684 = lang.IFn_Cast(root_2682) } else { ifn_2684 = nil }; var arg_2685 any = own__6; if linked_2683 == nil { arg_2681 = ifn_2684.Invoke_O__O(arg_2685) } else { arg_2681 = linked_2683.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2682, arg_2685) }; if linked_2679 == nil { tmp40 = ifn_2680.Invoke_O__O(arg_2681) } else { tmp40 = linked_2679.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2678, arg_2681) }; arg_2615 = tmp39.Invoke_O__O(tmp40); if linked_2610 == nil { tmp37 = ifn_2611.Invoke_O_O_O_O__O(arg_2612, arg_2613, arg_2614, arg_2615) } else { tmp37 = linked_2610.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2609, arg_2612, arg_2613, arg_2614, arg_2615) }; var tmp41 any = /*line :344:1*/tmp33.Invoke_O_O_O__O(tmp34, tmp36, tmp37); var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp43 any = A_arbace_j2g_dyn_A_const_262; var tmp44 any = A_arbace_j2g_dyn_A_const_263; var tmp45 any; var root_2686 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2686, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2688 lang.IFn; if










	linked_2687 == nil { ifn_2688 = lang.IFn_Cast(root_2686) } else { ifn_2688 = nil }; var arg_2689 any; var tmp46 any; var root_2691 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2693 lang.IFn; if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any = A_arbace_j2g_dyn_A_const_264; var arg_2695 any = recv__5; if linked_2692 == nil { tmp46 = ifn_2693.Invoke_O_O__O(arg_2694, arg_2695) } else { tmp46 = linked_2692.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2691, arg_2694, arg_2695) }; arg_2689 = lang.Tuple_Create_O__IPersistentVector(tmp46); var arg_2690 any = A_arbace_j2g_dyn_A_const_265; if linked_2687 == nil { tmp45 = ifn_2688.Invoke_O_O__O(arg_2689, arg_2690) } else { tmp45 = linked_2687.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2686, arg_2689, arg_2690) }; var tmp47 any = /*line :344:1*/tmp42.Invoke_O_O_O_O_O__O(tmp43, tmp44, tmp45, A_arbace_j2g_dyn_A_const_266, A_arbace_j2g_dyn_A_const_267); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp49 any = A_arbace_j2g_dyn_A_const_268; var tmp50 any = A_arbace_j2g_dyn_A_const_269; var tmp51 any; var root_2696 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2696, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2698 lang.IFn; if











	linked_2697 == nil { ifn_2698 = lang.IFn_Cast(root_2696) } else { ifn_2698 = nil }; var arg_2699 any; var tmp52 any; var root_2701 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2701, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2703 lang.IFn; if linked_2702 == nil { ifn_2703 = lang.IFn_Cast(root_2701) } else { ifn_2703 = nil }; var arg_2704 any = A_arbace_j2g_dyn_A_const_270; var arg_2705 any = recv__5; if linked_2702 == nil { tmp52 = ifn_2703.Invoke_O_O__O(arg_2704, arg_2705) } else { tmp52 = linked_2702.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2701, arg_2704, arg_2705) }; arg_2699 = lang.Tuple_Create_O__IPersistentVector(tmp52); var arg_2700 any = A_arbace_j2g_dyn_A_const_271; if linked_2697 == nil { tmp51 = ifn_2698.Invoke_O_O__O(arg_2699, arg_2700) } else { tmp51 = linked_2697.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2696, arg_2699, arg_2700) }; var tmp53 any = /*line :344:1*/tmp48.Invoke_O_O_O_O__O(tmp49, tmp50, tmp51, A_arbace_j2g_dyn_A_const_272); var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp55 any = A_arbace_j2g_dyn_A_const_273; var tmp56 any = A_arbace_j2g_dyn_A_const_274; var tmp57 any; var root_2706 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2706, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2708 lang.IFn; if












	linked_2707 == nil { ifn_2708 = lang.IFn_Cast(root_2706) } else { ifn_2708 = nil }; var arg_2709 any; var tmp58 any; var root_2711 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = A_arbace_j2g_dyn_A_const_275; var arg_2715 any = recv__5; if linked_2712 == nil { tmp58 = ifn_2713.Invoke_O_O__O(arg_2714, arg_2715) } else { tmp58 = linked_2712.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2711, arg_2714, arg_2715) }; arg_2709 = lang.Tuple_Create_O__IPersistentVector(tmp58); var arg_2710 any = A_arbace_j2g_dyn_A_const_276; if linked_2707 == nil { tmp57 = ifn_2708.Invoke_O_O__O(arg_2709, arg_2710) } else { tmp57 = linked_2707.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2706, arg_2709, arg_2710) }; var tmp59 any = /*line :344:1*/tmp54.Invoke_O_O_O_O__O(tmp55, tmp56, tmp57, A_arbace_j2g_dyn_A_const_277); var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp61 any = A_arbace_j2g_dyn_A_const_278; var tmp62 any = A_arbace_j2g_dyn_A_const_279; var tmp63 any; var root_2716 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2718 lang.IFn; if













	linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any; var tmp64 any; var root_2721 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2723 lang.IFn; if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = A_arbace_j2g_dyn_A_const_280; var arg_2725 any = recv__5; if linked_2722 == nil { tmp64 = ifn_2723.Invoke_O_O__O(arg_2724, arg_2725) } else { tmp64 = linked_2722.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2721, arg_2724, arg_2725) }; arg_2719 = lang.Tuple_Create_O__IPersistentVector(tmp64); var arg_2720 any = A_arbace_j2g_dyn_A_const_281; if linked_2717 == nil { tmp63 = ifn_2718.Invoke_O_O__O(arg_2719, arg_2720) } else { tmp63 = linked_2717.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2716, arg_2719, arg_2720) }; var tmp65 any = /*line :344:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp25, tmp32, tmp41, tmp47, tmp53, tmp59, tmp60.Invoke_O_O_O_O__O(tmp61, tmp62, tmp63, A_arbace_j2g_dyn_A_const_282))); var tmp66 any; var iter__1927001039__auto____11_2 any; var fnbody__2817 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(recv__5, n__0); var tmp67 *jrt.Class; var fncls__2816 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class; if














	fncls__2816 == nil { var fncls__2816d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, fnbody__2817); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class = fncls__2816d; tmp67 = fncls__2816d } else { tmp67 = fncls__2816 }; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2817, tmp67, nil); var tmp68 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11_2); var tmp69 any; var root_2818 any = A_arbace_j2g_dyn_A_const_137.GetRawRoot__O(); var linked_2819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2818, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2820 lang.IFn; if linked_2819 == nil { ifn_2820 = lang.IFn_Cast(root_2818) } else { ifn_2820 = nil }; var arg_2821 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_62.GetRawRoot__O())).Ref(); if linked_2819 == nil { tmp69 = ifn_2820.Invoke_O__O(arg_2821) } else { tmp69 = linked_2819.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2818, arg_2821) }; tmp66 = tmp68.Invoke_O__O(tmp69); var tmp70 any = tmp66; var tmp71 any; var iter__1927001039__auto____11_3 any; var fnbody__2913 any = /*line :344:1*/A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(recv__5, clash__9); var tmp72 *jrt.Class; var fncls__2912 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class; if

















	fncls__2912 == nil { var fncls__2912d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, fnbody__2913); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class = fncls__2912d; tmp72 = fncls__2912d } else { tmp72 = fncls__2912 }; iter__1927001039__auto____11_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2913, tmp72, nil); tmp71 = lang.IFn_Cast(iter__1927001039__auto____11_3).Invoke_O__O(ifaces__1); var tmp73 any = tmp71; var tmp74 any; var root_2914 any = /*line :344:1*/A_arbace_j2g_dyn_A_const_286.GetRawRoot__O(); var linked_2915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2914, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_2916 lang.IFn; if



















	linked_2915 == nil { ifn_2916 = lang.IFn_Cast(root_2914) } else { ifn_2916 = nil }; var arg_2917 any; var fnbody__2975 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(own__6, recv__5, clash__9, ifaces__1, n__0); var tmp75 *jrt.Class; var fncls__2974 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class; if fncls__2974 == nil { var fncls__2974d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, fnbody__2975); A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class = fncls__2974d; tmp75 = fncls__2974d } else { tmp75 = fncls__2974 }; arg_2917 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2975, tmp75, nil); var arg_2918 any = ks__8; if linked_2915 == nil { tmp74 = ifn_2916.Invoke_O_O__O(arg_2917, arg_2918) } else { tmp74 = linked_2915.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_2914, arg_2917, arg_2918) }; var tmp76 any = tmp74; var tmp77 any; var root_2976 any = /*line :344:1*/A_arbace_j2g_dyn_A_const_288.GetRawRoot__O(); var linked_2977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2976, A_arbace_j2g_dyn_ctor_infos_A_fn_class); var ifn_2978 lang.IFn; if


























	linked_2977 == nil { ifn_2978 = lang.IFn_Cast(root_2976) } else { ifn_2978 = nil }; var arg_2979 any = n__0; if linked_2977 == nil { tmp77 = ifn_2978.Invoke_O__O(arg_2979) } else { tmp77 = linked_2977.(*A_arbace_j2g_dyn_ctor_infos_A).Invoke_O_O__O(root_2976, arg_2979) }; return /*line :344:1*/ tmp7.Invoke_O_O_O_O_O__O(tmp65, tmp70, tmp73, tmp76, lang.Tuple_Create_O__IPersistentVector(tmp77)) }
//line :339:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Ctor() {}
//line :339:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Invoke_O_O__O(self, s__711000308__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2507 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(self, s__711000308__1); var tmp2 *jrt.Class; var fncls__2506 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class; if fncls__2506 == nil { var fncls__2506d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_163, false, fnbody__2507); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class = fncls__2506d; tmp2 = fncls__2506d } else { tmp2 = fncls__2506 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2507, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :339:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A{}; t.Ctor_O_O(p0, p1); return t }
//line :339:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Ctor_O_O(c__iter__711000307, c__s__711000308 any) { t.F_iter__711000307 = c__iter__711000307; t.F_s__711000308 = c__s__711000308 }
//line :339:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Invoke_O__O(self any) any { { var s__711000308__1 any; var t_ any = t.F_s__711000308; t.F_s__711000308 = nil; s__711000308__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2436 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2436, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2438 lang.IFn; if linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any = s__711000308__1; if linked_2437 == nil { temp__1927000414__auto____2 = ifn_2438.Invoke_O__O(arg_2439) } else { temp__1927000414__auto____2 = linked_2437.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2436, arg_2439) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000308__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2440 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2440, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2442 lang.IFn; if linked_2441 == nil { ifn_2442 = lang.IFn_Cast(root_2440) } else { ifn_2442 = nil }; var arg_2443 any = s__711000308__3; if linked_2441 == nil { tmp1 = ifn_2442.Invoke_O__O(arg_2443) } else { tmp1 = linked_2441.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2440, arg_2443) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2444 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2444, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2446 lang.IFn; if linked_2445 == nil { ifn_2446 = lang.IFn_Cast(root_2444) } else { ifn_2446 = nil }; var arg_2447 any = s__711000308__3; if linked_2445 == nil { c__1927001037__auto____4 = ifn_2446.Invoke_O__O(arg_2447) } else { c__1927001037__auto____4 = linked_2445.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2444, arg_2447) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000310__6 any; var root_2448 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2448, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2450 lang.IFn; if linked_2449 == nil { ifn_2450 = lang.IFn_Cast(root_2448) } else { ifn_2450 = nil }; var arg_2451 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2449 == nil { b__711000310__6 = ifn_2450.Invoke_O__O(arg_2451) } else { b__711000310__6 = linked_2449.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2448, arg_2451) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2462 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(b__711000310__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2461 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class; if fncls__2461 == nil { var fncls__2461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, fnbody__2462); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class = fncls__2461d; tmp3 = fncls__2461d } else { tmp3 = fncls__2461 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2462, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2463 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any; var root_2468 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2470 lang.IFn; if linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = b__711000310__6; if linked_2469 == nil { arg_2466 = ifn_2470.Invoke_O__O(arg_2471) } else { arg_2466 = linked_2469.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2468, arg_2471) }; var arg_2467 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp5 any; var root_2472 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = s__711000308__3; if linked_2473 == nil { tmp5 = ifn_2474.Invoke_O__O(arg_2475) } else { tmp5 = linked_2473.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2472, arg_2475) }; arg_2467 = tmp4.Invoke_O__O(tmp5); if linked_2464 == nil { return ifn_2465.Invoke_O_O__O(arg_2466, arg_2467) } else { return linked_2464.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2463, arg_2466, arg_2467) } } else { var root_2476 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any; var root_2481 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2481, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2483 lang.IFn; if linked_2482 == nil { ifn_2483 = lang.IFn_Cast(root_2481) } else { ifn_2483 = nil }; var arg_2484 any = b__711000310__6; if linked_2482 == nil { arg_2479 = ifn_2483.Invoke_O__O(arg_2484) } else { arg_2479 = linked_2482.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2481, arg_2484) }; var arg_2480 any; if linked_2477 == nil { return ifn_2478.Invoke_O_O__O(arg_2479, arg_2480) } else { return linked_2477.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2476, arg_2479, arg_2480) } } } else { var vec__711000318__4 any; var root_2485 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any = s__711000308__3; if linked_2486 == nil { vec__711000318__4 = ifn_2487.Invoke_O__O(arg_2488) } else { vec__711000318__4 = linked_2486.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2485, arg_2488) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_2489 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_2490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2489, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2491 lang.IFn; if linked_2490 == nil { ifn_2491 = lang.IFn_Cast(root_2489) } else { ifn_2491 = nil }; var arg_2492 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()).Invoke_O__O(k__5); if linked_2490 == nil { tmp6 = ifn_2491.Invoke_O__O(arg_2492) } else { tmp6 = linked_2490.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2489, arg_2492) }; if jrt.J2g_Truth(tmp6) { var root_2493 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2493, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2495 lang.IFn; if linked_2494 == nil { ifn_2495 = lang.IFn_Cast(root_2493) } else { ifn_2495 = nil }; var arg_2496 any = lang.Tuple_Create_O_O__IPersistentVector(k__5, mm__6); var arg_2497 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp8 any; var root_2498 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2500 lang.IFn; if linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any = s__711000308__3; if linked_2499 == nil { tmp8 = ifn_2500.Invoke_O__O(arg_2501) } else { tmp8 = linked_2499.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2498, arg_2501) }; arg_2497 = tmp7.Invoke_O__O(tmp8); if linked_2494 == nil { return ifn_2495.Invoke_O_O__O(arg_2496, arg_2497) } else { return linked_2494.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2493, arg_2496, arg_2497) } } else { var tmp9 any; var root_2502 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2504 lang.IFn; if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any = s__711000308__3; if linked_2503 == nil { tmp9 = ifn_2504.Invoke_O__O(arg_2505) } else { tmp9 = linked_2503.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2502, arg_2505) }; s__711000308__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :339:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :339:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Ctor_O_I_O(c__b__711000310 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000310 = c__b__711000310; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :339:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Invoke_O__O(self any) any { { var i__711000309__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000309__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000314__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000309__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_2452 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_2453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2452, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2454 lang.IFn; if linked_2453 == nil { ifn_2454 = lang.IFn_Cast(root_2452) } else { ifn_2454 = nil }; var arg_2455 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()).Invoke_O__O(k__3); if linked_2453 == nil { tmp2 = ifn_2454.Invoke_O__O(arg_2455) } else { tmp2 = linked_2453.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2452, arg_2455) }; if jrt.J2g_Truth(tmp2) { var root_2456 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2456, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2458 lang.IFn; if linked_2457 == nil { ifn_2458 = lang.IFn_Cast(root_2456) } else { ifn_2458 = nil }; var arg_2459 any = t.F_b__711000310; var arg_2460 any = lang.Tuple_Create_O_O__IPersistentVector(k__3, mm__4); if linked_2457 == nil { ifn_2458.Invoke_O_O__O(arg_2459, arg_2460) } else { linked_2457.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2456, arg_2459, arg_2460) }; i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } else { i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New() *A_arbace_j2g_dyn_sub_forms_fn__711000324_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000324_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Ctor() {}
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Invoke_O_O_O__O(self, i__1, p__711000323__2 any) any { var vec__711000325__3 any = p__711000323__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }

func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Ctor() {}
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Invoke_O_O__O(self, s__711000330__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2675 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(s__711000330__1, self); var tmp2 *jrt.Class; var fncls__2674 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class; if fncls__2674 == nil { var fncls__2674d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, fnbody__2675); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class = fncls__2674d; tmp2 = fncls__2674d } else { tmp2 = fncls__2674 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2675, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :354:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Ctor_O_O(c__s__711000330, c__iter__711000329 any) { t.F_s__711000330 = c__s__711000330; t.F_iter__711000329 = c__iter__711000329 }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Invoke_O__O(self any) any { { var s__711000330__1 any; var t_ any = t.F_s__711000330; t.F_s__711000330 = nil; s__711000330__1 = t_; for { var temp__1927000414__auto____2 any; var root_2616 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = s__711000330__1; if linked_2617 == nil { temp__1927000414__auto____2 = ifn_2618.Invoke_O__O(arg_2619) } else { temp__1927000414__auto____2 = linked_2617.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2616, arg_2619) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000330__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2620 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any = s__711000330__3; if linked_2621 == nil { tmp1 = ifn_2622.Invoke_O__O(arg_2623) } else { tmp1 = linked_2621.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2620, arg_2623) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2624 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2624, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2626 lang.IFn; if linked_2625 == nil { ifn_2626 = lang.IFn_Cast(root_2624) } else { ifn_2626 = nil }; var arg_2627 any = s__711000330__3; if linked_2625 == nil { c__1927001037__auto____4 = ifn_2626.Invoke_O__O(arg_2627) } else { c__1927001037__auto____4 = linked_2625.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2624, arg_2627) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000332__6 any; var root_2628 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2628, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2630 lang.IFn; if linked_2629 == nil { ifn_2630 = lang.IFn_Cast(root_2628) } else { ifn_2630 = nil }; var arg_2631 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2629 == nil { b__711000332__6 = ifn_2630.Invoke_O__O(arg_2631) } else { b__711000332__6 = linked_2629.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2628, arg_2631) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2638 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(b__711000332__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2637 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class; if fncls__2637 == nil { var fncls__2637d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_166, false, fnbody__2638); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class = fncls__2637d; tmp3 = fncls__2637d } else { tmp3 = fncls__2637 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2638, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2639 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2639, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2641 lang.IFn; if linked_2640 == nil { ifn_2641 = lang.IFn_Cast(root_2639) } else { ifn_2641 = nil }; var arg_2642 any; var root_2644 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2646 lang.IFn; if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any = b__711000332__6; if linked_2645 == nil { arg_2642 = ifn_2646.Invoke_O__O(arg_2647) } else { arg_2642 = linked_2645.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2644, arg_2647) }; var arg_2643 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp5 any; var root_2648 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2648, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var arg_2651 any = s__711000330__3; if linked_2649 == nil { tmp5 = ifn_2650.Invoke_O__O(arg_2651) } else { tmp5 = linked_2649.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2648, arg_2651) }; arg_2643 = tmp4.Invoke_O__O(tmp5); if linked_2640 == nil { return ifn_2641.Invoke_O_O__O(arg_2642, arg_2643) } else { return linked_2640.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2639, arg_2642, arg_2643) } } else { var root_2652 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any; var root_2657 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any = b__711000332__6; if linked_2658 == nil { arg_2655 = ifn_2659.Invoke_O__O(arg_2660) } else { arg_2655 = linked_2658.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2657, arg_2660) }; var arg_2656 any; if linked_2653 == nil { return ifn_2654.Invoke_O_O__O(arg_2655, arg_2656) } else { return linked_2653.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2652, arg_2655, arg_2656) } } } else { var vec__711000340__4 any; var root_2661 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2661, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2663 lang.IFn; if linked_2662 == nil { ifn_2663 = lang.IFn_Cast(root_2661) } else { ifn_2663 = nil }; var arg_2664 any = s__711000330__3; if linked_2662 == nil { vec__711000340__4 = ifn_2663.Invoke_O__O(arg_2664) } else { vec__711000340__4 = linked_2662.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2661, arg_2664) }; var nme__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2665 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__5, desc__6)).Ref(), nme__5); var arg_2669 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp7 any; var root_2670 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = s__711000330__3; if linked_2671 == nil { tmp7 = ifn_2672.Invoke_O__O(arg_2673) } else { tmp7 = linked_2671.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2670, arg_2673) }; arg_2669 = tmp6.Invoke_O__O(tmp7); if linked_2666 == nil { return ifn_2667.Invoke_O_O__O(arg_2668, arg_2669) } else { return linked_2666.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2665, arg_2668, arg_2669) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :354:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Ctor_O_I_O(c__b__711000332 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000332 = c__b__711000332; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Invoke_O__O(self any) any { { var i__711000331__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000331__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000336__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000331__1)); var nme__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2632 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2632, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2634 lang.IFn; if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any = t.F_b__711000332; var arg_2636 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__3, desc__4)).Ref(), nme__3); if linked_2633 == nil { ifn_2634.Invoke_O_O__O(arg_2635, arg_2636) } else { linked_2633.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2632, arg_2635, arg_2636) }; i__711000331__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000331__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Invoke_O_O__O(self, s__711000346__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2815 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(t.F_recv, self, s__711000346__1, t.F_n); var tmp2 *jrt.Class; var fncls__2814 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class; if fncls__2814 == nil { var fncls__2814d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_167, false, fnbody__2815); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class = fncls__2814d; tmp2 = fncls__2814d } else { tmp2 = fncls__2814 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2815, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :359:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Ctor_O_O_O_O(c__recv, c__iter__711000345, c__s__711000346, c__n any) { t.F_recv = c__recv; t.F_iter__711000345 = c__iter__711000345; t.F_s__711000346 = c__s__711000346; t.F_n = c__n }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Invoke_O__O(self any) any { { var s__711000346__1 any; var t_ any = t.F_s__711000346; t.F_s__711000346 = nil; s__711000346__1 = t_; for { var temp__1927000414__auto____2 any; var root_2726 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2726, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2728 lang.IFn; if linked_2727 == nil { ifn_2728 = lang.IFn_Cast(root_2726) } else { ifn_2728 = nil }; var arg_2729 any = s__711000346__1; if linked_2727 == nil { temp__1927000414__auto____2 = ifn_2728.Invoke_O__O(arg_2729) } else { temp__1927000414__auto____2 = linked_2727.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2726, arg_2729) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000346__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2730 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2730, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2732 lang.IFn; if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any = s__711000346__3; if linked_2731 == nil { tmp1 = ifn_2732.Invoke_O__O(arg_2733) } else { tmp1 = linked_2731.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2730, arg_2733) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2734 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2734, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2736 lang.IFn; if linked_2735 == nil { ifn_2736 = lang.IFn_Cast(root_2734) } else { ifn_2736 = nil }; var arg_2737 any = s__711000346__3; if linked_2735 == nil { c__1927001037__auto____4 = ifn_2736.Invoke_O__O(arg_2737) } else { c__1927001037__auto____4 = linked_2735.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2734, arg_2737) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000348__6 any; var root_2738 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2738, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2740 lang.IFn; if linked_2739 == nil { ifn_2740 = lang.IFn_Cast(root_2738) } else { ifn_2740 = nil }; var arg_2741 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2739 == nil { b__711000348__6 = ifn_2740.Invoke_O__O(arg_2741) } else { b__711000348__6 = linked_2739.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2738, arg_2741) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2763 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(t.F_recv, t.F_n, b__711000348__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2762 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class; if fncls__2762 == nil { var fncls__2762d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_168, false, fnbody__2763); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class = fncls__2762d; tmp3 = fncls__2762d } else { tmp3 = fncls__2762 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2763, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2764 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; var arg_2767 any; var root_2769 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2769, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2771 lang.IFn; if linked_2770 == nil { ifn_2771 = lang.IFn_Cast(root_2769) } else { ifn_2771 = nil }; var arg_2772 any = b__711000348__6; if linked_2770 == nil { arg_2767 = ifn_2771.Invoke_O__O(arg_2772) } else { arg_2767 = linked_2770.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2769, arg_2772) }; var arg_2768 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp5 any; var root_2773 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2773, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2775 lang.IFn; if linked_2774 == nil { ifn_2775 = lang.IFn_Cast(root_2773) } else { ifn_2775 = nil }; var arg_2776 any = s__711000346__3; if linked_2774 == nil { tmp5 = ifn_2775.Invoke_O__O(arg_2776) } else { tmp5 = linked_2774.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2773, arg_2776) }; arg_2768 = tmp4.Invoke_O__O(tmp5); if linked_2765 == nil { return ifn_2766.Invoke_O_O__O(arg_2767, arg_2768) } else { return linked_2765.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2764, arg_2767, arg_2768) } } else { var root_2777 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2777, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2779 lang.IFn; if linked_2778 == nil { ifn_2779 = lang.IFn_Cast(root_2777) } else { ifn_2779 = nil }; var arg_2780 any; var root_2782 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2782, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2784 lang.IFn; if linked_2783 == nil { ifn_2784 = lang.IFn_Cast(root_2782) } else { ifn_2784 = nil }; var arg_2785 any = b__711000348__6; if linked_2783 == nil { arg_2780 = ifn_2784.Invoke_O__O(arg_2785) } else { arg_2780 = linked_2783.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2782, arg_2785) }; var arg_2781 any; if linked_2778 == nil { return ifn_2779.Invoke_O_O__O(arg_2780, arg_2781) } else { return linked_2778.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2777, arg_2780, arg_2781) } } } else { var i__4 any; var root_2786 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2786, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2788 lang.IFn; if linked_2787 == nil { ifn_2788 = lang.IFn_Cast(root_2786) } else { ifn_2788 = nil }; var arg_2789 any = s__711000346__3; if linked_2787 == nil { i__4 = ifn_2788.Invoke_O__O(arg_2789) } else { i__4 = linked_2787.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2786, arg_2789) }; var k__5 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_62.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__4)); var root_2790 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2792 lang.IFn; if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; var arg_2793 any; var root_2795 any = A_arbace_j2g_dyn_A_const_161.GetRawRoot__O(); var linked_2796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2795, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2797 lang.IFn

	if linked_2796 == nil { ifn_2797 = lang.IFn_Cast(root_2795) } else { ifn_2797 = nil }; var arg_2798 any = t.F_recv; var arg_2799 any = i__4; var arg_2800 any = k__5; var arg_2801 any; var fnbody__2809 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(k__5, t.F_n); var tmp6 *jrt.Class; var fncls__2808 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class; if fncls__2808 == nil { var fncls__2808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_169, false, fnbody__2809); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class = fncls__2808d; tmp6 = fncls__2808d } else { tmp6 = fncls__2808 }; arg_2801 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2809, tmp6, nil); if linked_2796 == nil { arg_2793 = ifn_2797.Invoke_O_O_O_O__O(arg_2798, arg_2799, arg_2800, arg_2801) } else { arg_2793 = linked_2796.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2795, arg_2798, arg_2799, arg_2800, arg_2801) }
//line :359:1
	var arg_2794 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp8 any; var root_2810 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2810, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2812 lang.IFn; if linked_2811 == nil { ifn_2812 = lang.IFn_Cast(root_2810) } else { ifn_2812 = nil }; var arg_2813 any = s__711000346__3; if linked_2811 == nil { tmp8 = ifn_2812.Invoke_O__O(arg_2813) } else { tmp8 = linked_2811.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2810, arg_2813) }; arg_2794 = tmp7.Invoke_O__O(tmp8); if linked_2791 == nil { return ifn_2792.Invoke_O_O__O(arg_2793, arg_2794) } else { return linked_2791.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2790, arg_2793, arg_2794) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :359:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Ctor_O_O_O_I_O(c__recv, c__n, c__b__711000348 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_n = c__n; t.F_b__711000348 = c__b__711000348; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Invoke_O__O(self any) any { { var i__711000347__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000347__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000347__1)); var k__3 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_62.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__2)); var root_2742 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any = t.F_b__711000348; var arg_2746 any; var root_2747 any = A_arbace_j2g_dyn_A_const_161.GetRawRoot__O(); var linked_2748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2747, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2749 lang.IFn

	if linked_2748 == nil { ifn_2749 = lang.IFn_Cast(root_2747) } else { ifn_2749 = nil }; var arg_2750 any = t.F_recv; var arg_2751 any = i__2; var arg_2752 any = k__3; var arg_2753 any; var fnbody__2761 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(k__3, t.F_n); var tmp2 *jrt.Class; var fncls__2760 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class; if fncls__2760 == nil { var fncls__2760d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, fnbody__2761); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class = fncls__2760d; tmp2 = fncls__2760d } else { tmp2 = fncls__2760 }; arg_2753 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2761, tmp2, nil); if linked_2748 == nil { arg_2746 = ifn_2749.Invoke_O_O_O_O__O(arg_2750, arg_2751, arg_2752, arg_2753) } else { arg_2746 = linked_2748.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2747, arg_2750, arg_2751, arg_2752, arg_2753) }
//line :359:1
	if linked_2743 == nil { ifn_2744.Invoke_O_O__O(arg_2745, arg_2746) } else { linked_2743.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2742, arg_2745, arg_2746) }; i__711000347__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000347__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A{}; t.Ctor_O_O(p0, p1); return t }
//line :361:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :361:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2754 any = A_arbace_j2g_dyn_A_const_283.GetRawRoot__O(); var linked_2755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2754, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2756 lang.IFn; if linked_2755 == nil { ifn_2756 = lang.IFn_Cast(root_2754) } else { ifn_2756 = nil }; var arg_2757 any = t.F_n; var arg_2758 any = t.F_k; var arg_2759 any = pn__1; if linked_2755 == nil { return ifn_2756.Invoke_O_O_O__O(arg_2757, arg_2758, arg_2759) } else { return linked_2755.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2754, arg_2757, arg_2758, arg_2759) } }
//line :361:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A{}; t.Ctor_O_O(p0, p1); return t }
//line :361:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :361:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2802 any = A_arbace_j2g_dyn_A_const_283.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2802, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2804 lang.IFn; if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any = t.F_n; var arg_2806 any = t.F_k; var arg_2807 any = pn__1; if linked_2803 == nil { return ifn_2804.Invoke_O_O_O__O(arg_2805, arg_2806, arg_2807) } else { return linked_2803.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2802, arg_2805, arg_2806, arg_2807) } }
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :362:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Ctor_O_O(c__recv, c__clash any) { t.F_recv = c__recv; t.F_clash = c__clash }
//line :362:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Invoke_O_O__O(self, s__711000360__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2911 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(s__711000360__1, t.F_recv, t.F_clash, self); var tmp2 *jrt.Class; var fncls__2910 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class; if fncls__2910 == nil { var fncls__2910d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, fnbody__2911); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class = fncls__2910d; tmp2 = fncls__2910d } else { tmp2 = fncls__2910 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2911, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :362:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :362:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Ctor_O_O_O_O(c__s__711000360, c__recv, c__clash, c__iter__711000359 any) { t.F_s__711000360 = c__s__711000360; t.F_recv = c__recv; t.F_clash = c__clash; t.F_iter__711000359 = c__iter__711000359 }
//line :362:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Invoke_O__O(self any) any { { var s__711000360__1 any; var t_ any = t.F_s__711000360; t.F_s__711000360 = nil; s__711000360__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2822 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2822, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2824 lang.IFn; if linked_2823 == nil { ifn_2824 = lang.IFn_Cast(root_2822) } else { ifn_2824 = nil }; var arg_2825 any = s__711000360__1; if linked_2823 == nil { temp__1927000414__auto____2 = ifn_2824.Invoke_O__O(arg_2825) } else { temp__1927000414__auto____2 = linked_2823.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2822, arg_2825) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000360__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2826 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2826, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2828 lang.IFn; if linked_2827 == nil { ifn_2828 = lang.IFn_Cast(root_2826) } else { ifn_2828 = nil }; var arg_2829 any = s__711000360__3; if linked_2827 == nil { tmp1 = ifn_2828.Invoke_O__O(arg_2829) } else { tmp1 = linked_2827.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2826, arg_2829) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2830 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2830, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2832 lang.IFn; if linked_2831 == nil { ifn_2832 = lang.IFn_Cast(root_2830) } else { ifn_2832 = nil }; var arg_2833 any = s__711000360__3; if linked_2831 == nil { c__1927001037__auto____4 = ifn_2832.Invoke_O__O(arg_2833) } else { c__1927001037__auto____4 = linked_2831.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2830, arg_2833) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000362__6 any; var root_2834 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2834, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2836 lang.IFn; if linked_2835 == nil { ifn_2836 = lang.IFn_Cast(root_2834) } else { ifn_2836 = nil }; var arg_2837 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2835 == nil { b__711000362__6 = ifn_2836.Invoke_O__O(arg_2837) } else { b__711000362__6 = linked_2835.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2834, arg_2837) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2857 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(t.F_recv, t.F_clash, b__711000362__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2856 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class; if fncls__2856 == nil { var fncls__2856d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_172, false, fnbody__2857); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class = fncls__2856d; tmp3 = fncls__2856d } else { tmp3 = fncls__2856 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2857, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2858 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2858, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2860 lang.IFn; if linked_2859 == nil { ifn_2860 = lang.IFn_Cast(root_2858) } else { ifn_2860 = nil }; var arg_2861 any; var root_2863 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2863, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2865 lang.IFn; if linked_2864 == nil { ifn_2865 = lang.IFn_Cast(root_2863) } else { ifn_2865 = nil }; var arg_2866 any = b__711000362__6; if linked_2864 == nil { arg_2861 = ifn_2865.Invoke_O__O(arg_2866) } else { arg_2861 = linked_2864.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2863, arg_2866) }; var arg_2862 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp5 any; var root_2867 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2867, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2869 lang.IFn; if linked_2868 == nil { ifn_2869 = lang.IFn_Cast(root_2867) } else { ifn_2869 = nil }; var arg_2870 any = s__711000360__3; if linked_2868 == nil { tmp5 = ifn_2869.Invoke_O__O(arg_2870) } else { tmp5 = linked_2868.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2867, arg_2870) }; arg_2862 = tmp4.Invoke_O__O(tmp5); if linked_2859 == nil { return ifn_2860.Invoke_O_O__O(arg_2861, arg_2862) } else { return linked_2859.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2858, arg_2861, arg_2862) } } else { var root_2871 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2871, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2873 lang.IFn; if linked_2872 == nil { ifn_2873 = lang.IFn_Cast(root_2871) } else { ifn_2873 = nil }; var arg_2874 any; var root_2876 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2878 lang.IFn; if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any = b__711000362__6; if linked_2877 == nil { arg_2874 = ifn_2878.Invoke_O__O(arg_2879) } else { arg_2874 = linked_2877.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2876, arg_2879) }; var arg_2875 any; if linked_2872 == nil { return ifn_2873.Invoke_O_O__O(arg_2874, arg_2875) } else { return linked_2872.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2871, arg_2874, arg_2875) } } } else { var j__4 any; var root_2880 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2880, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2882 lang.IFn; if linked_2881 == nil { ifn_2882 = lang.IFn_Cast(root_2880) } else { ifn_2882 = nil }; var arg_2883 any = s__711000360__3; if linked_2881 == nil { j__4 = ifn_2882.Invoke_O__O(arg_2883) } else { j__4 = linked_2881.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2880, arg_2883) }; var mk__5 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp7 any; var root_2884 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_2885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2884, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2886 lang.IFn; if linked_2885 == nil { ifn_2886 = lang.IFn_Cast(root_2884) } else { ifn_2886 = nil }; var arg_2887 any = j__4; if linked_2885 == nil { tmp7 = ifn_2886.Invoke_O__O(arg_2887) } else { tmp7 = linked_2885.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2884, arg_2887) }; mk__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__5)) { var root_2888 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2888, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2890 lang.IFn; if linked_2889 == nil { ifn_2890 = lang.IFn_Cast(root_2888) } else { ifn_2890 = nil }; var arg_2891 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_284; var tmp10 any; var root_2893 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2893, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2895 lang.IFn
														if linked_2894 == nil { ifn_2895 = lang.IFn_Cast(root_2893) } else { ifn_2895 = nil }; var arg_2896 any = mk__5; if linked_2894 == nil { tmp10 = ifn_2895.Invoke_O__O(arg_2896) } else { tmp10 = linked_2894.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2893, arg_2896) }; var tmp11 any = tmp10; var tmp12 any; var root_2897 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2897, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2899 lang.IFn; if linked_2898 == nil { ifn_2899 = lang.IFn_Cast(root_2897) } else { ifn_2899 = nil }; var arg_2900 any = A_arbace_j2g_dyn_A_const_285; var arg_2901 any = t.F_recv; if linked_2898 == nil { tmp12 = ifn_2899.Invoke_O_O__O(arg_2900, arg_2901) } else { tmp12 = linked_2898.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2897, arg_2900, arg_2901) }; arg_2891 = tmp8.Invoke_O_O_O__O(tmp9, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12))
//line :362:1
	var arg_2892 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp14 any; var root_2902 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2902, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2904 lang.IFn; if linked_2903 == nil { ifn_2904 = lang.IFn_Cast(root_2902) } else { ifn_2904 = nil }; var arg_2905 any = s__711000360__3; if linked_2903 == nil { tmp14 = ifn_2904.Invoke_O__O(arg_2905) } else { tmp14 = linked_2903.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2902, arg_2905) }; arg_2892 = tmp13.Invoke_O__O(tmp14); if linked_2889 == nil { return ifn_2890.Invoke_O_O__O(arg_2891, arg_2892) } else { return linked_2889.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2888, arg_2891, arg_2892) } } else { var tmp15 any; var root_2906 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_2907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2906, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2908 lang.IFn; if linked_2907 == nil { ifn_2908 = lang.IFn_Cast(root_2906) } else { ifn_2908 = nil }; var arg_2909 any = s__711000360__3; if linked_2907 == nil { tmp15 = ifn_2908.Invoke_O__O(arg_2909) } else { tmp15 = linked_2907.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2906, arg_2909) }; s__711000360__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :362:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :362:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Ctor_O_O_O_I_O(c__recv, c__clash, c__b__711000362 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_clash = c__clash; t.F_b__711000362 = c__b__711000362; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :362:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Invoke_O__O(self any) any { { var i__711000361__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000361__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000361__1)); var mk__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp3 any; var root_2838 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_2839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2838, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2840 lang.IFn; if linked_2839 == nil { ifn_2840 = lang.IFn_Cast(root_2838) } else { ifn_2840 = nil }; var arg_2841 any = j__2; if linked_2839 == nil { tmp3 = ifn_2840.Invoke_O__O(arg_2841) } else { tmp3 = linked_2839.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2838, arg_2841) }; mk__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__3)) { var root_2842 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2842, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2844 lang.IFn; if linked_2843 == nil { ifn_2844 = lang.IFn_Cast(root_2842) } else { ifn_2844 = nil }; var arg_2845 any = t.F_b__711000362; var arg_2846 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_284; var tmp6 any; var root_2847 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2847, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2849 lang.IFn
															if linked_2848 == nil { ifn_2849 = lang.IFn_Cast(root_2847) } else { ifn_2849 = nil }; var arg_2850 any = mk__3; if linked_2848 == nil { tmp6 = ifn_2849.Invoke_O__O(arg_2850) } else { tmp6 = linked_2848.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2847, arg_2850) }; var tmp7 any = tmp6; var tmp8 any; var root_2851 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any = A_arbace_j2g_dyn_A_const_285; var arg_2855 any = t.F_recv; if linked_2852 == nil { tmp8 = ifn_2853.Invoke_O_O__O(arg_2854, arg_2855) } else { tmp8 = linked_2852.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2851, arg_2854, arg_2855) }; arg_2846 = tmp4.Invoke_O_O_O__O(tmp5, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8))
//line :362:1
	if linked_2843 == nil { ifn_2844.Invoke_O_O__O(arg_2845, arg_2846) } else { linked_2843.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2842, arg_2845, arg_2846) }; i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } else { i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :364:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Ctor_O_O_O_O_O(c__own, c__recv, c__clash, c__ifaces, c__n any) { t.F_own = c__own; t.F_recv = c__recv; t.F_clash = c__clash; t.F_ifaces = c__ifaces; t.F_n = c__n }
//line :364:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Invoke_O_O_O__O(self, i__1, p__711000369__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, p__711000369__2) } else { var vec__711000371__3 any = p__711000369__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000371__3; var tmp1 any; var and__1927000168__auto____7 bool; var na_2919 any = i__1; var na_2920 int64 = int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_62.GetRawRoot__O()))
														if jrt.Long_InstanceOf(na_2919) { var n0_2921 int64 = jrt.NN(jrt.Long_Cast(na_2919)).LongValue__J(); var n1_2922 int64 = na_2920; and__1927000168__auto____7 = n0_2921 >= n1_2922 } else { and__1927000168__auto____7 = lang.Numbers_Gte_O_J__Z_NoInit(na_2919, na_2920) }; if and__1927000168__auto____7 { var or__1927000174__auto____8 any = lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)
															if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_clash); var tmp3 any; var root_2949 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_2950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2949, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2951 lang.IFn; if linked_2950 == nil { ifn_2951 = lang.IFn_Cast(root_2949) } else { ifn_2951 = nil }; var arg_2952 any = nme__4; var arg_2953 any = desc__5; if linked_2950 == nil { tmp3 = ifn_2951.Invoke_O_O__O(arg_2952, arg_2953) } else { tmp3 = linked_2950.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2949, arg_2952, arg_2953) }; tmp1 = tmp2.Invoke_O__O(tmp3) } } else {
//line :365:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				var root_2924 any = A_arbace_j2g_dyn_A_const_161.GetRawRoot__O(); var linked_2925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2924, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2926 lang.IFn; if linked_2925 == nil { ifn_2926 = lang.IFn_Cast(root_2924) } else { ifn_2926 = nil }; var arg_2927 any = t.F_recv; var arg_2928 any = i__1; var arg_2929 any = k__6; var arg_2930 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)) {
					var fnbody__2939 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(k__6, t.F_n); var tmp4 *jrt.Class; var fncls__2938 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class; if fncls__2938 == nil { var fncls__2938d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, fnbody__2939); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class = fncls__2938d; tmp4 = fncls__2938d } else { tmp4 = fncls__2938 }; arg_2930 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2939, tmp4, nil) } else {
						var fnbody__2948 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(k__6, t.F_ifaces); var tmp5 *jrt.Class; var fncls__2947 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class; if fncls__2947 == nil { var fncls__2947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, fnbody__2948); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class = fncls__2947d; tmp5 = fncls__2947d } else { tmp5 = fncls__2947 }; arg_2930 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2948, tmp5, nil) }
//line :367:1
				if linked_2925 == nil { return ifn_2926.Invoke_O_O_O_O__O(arg_2927, arg_2928, arg_2929, arg_2930) } else { return linked_2925.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2924, arg_2927, arg_2928, arg_2929, arg_2930) } } else {
//line :365:1
					return nil } } }
//line :364:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, p__711000369__2 any) any { var vec__711000371__3 any = p__711000369__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000371__3; var tmp1 any; var and__1927000168__auto____7 bool; var na_2954 int64 = int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_62.GetRawRoot__O())); var n0_2955 int64 = i__1_l; var n1_2956 int64 = na_2954; and__1927000168__auto____7 =
																	n0_2955 >= n1_2956; if and__1927000168__auto____7 { var or__1927000174__auto____8 any = lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)
																		if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_clash); var tmp3 any; var root_2969 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_2970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2969, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2971 lang.IFn; if linked_2970 == nil { ifn_2971 = lang.IFn_Cast(root_2969) } else { ifn_2971 = nil }; var arg_2972 any = nme__4; var arg_2973 any = desc__5; if linked_2970 == nil { tmp3 = ifn_2971.Invoke_O_O__O(arg_2972, arg_2973) } else { tmp3 = linked_2970.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2969, arg_2972, arg_2973) }; tmp1 = tmp2.Invoke_O__O(tmp3) } } else {
//line :365:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				var root_2958 any = A_arbace_j2g_dyn_A_const_161.GetRawRoot__O(); var linked_2959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2958, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2960 lang.IFn; if linked_2959 == nil { ifn_2960 = lang.IFn_Cast(root_2958) } else { ifn_2960 = nil }; var arg_2961 any = t.F_recv; var arg_2962 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_2962 = i__1_b } else { arg_2962 = i__1_b }; var arg_2963 any = k__6; var arg_2964 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)) {
					var fnbody__2966 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(k__6, t.F_n); var tmp4 *jrt.Class; var fncls__2965 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class; if fncls__2965 == nil { var fncls__2965d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, fnbody__2966); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class = fncls__2965d; tmp4 = fncls__2965d } else { tmp4 = fncls__2965 }; arg_2964 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2966, tmp4, nil) } else {
						var fnbody__2968 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(k__6, t.F_ifaces); var tmp5 *jrt.Class; var fncls__2967 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class; if fncls__2967 == nil { var fncls__2967d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, fnbody__2968); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class = fncls__2967d; tmp5 = fncls__2967d } else { tmp5 = fncls__2967 }; arg_2964 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2968, tmp5, nil) }
//line :367:1
				if linked_2959 == nil { return ifn_2960.Invoke_O_O_O_O__O(arg_2961, arg_2962, arg_2963, arg_2964) } else { return linked_2959.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2958, arg_2961, arg_2962, arg_2963, arg_2964) } } else {
//line :365:1
					return nil } }


func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A{}; t.Ctor_O_O(p0, p1); return t }
//line :368:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :368:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2931 any = A_arbace_j2g_dyn_A_const_287.GetRawRoot__O(); var linked_2932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2931, A_arbace_j2g_dyn_class_fallback_A_fn_class); var ifn_2933 lang.IFn; if linked_2932 == nil { ifn_2933 = lang.IFn_Cast(root_2931) } else { ifn_2933 = nil }; var arg_2934 any = t.F_n; var arg_2935 any = t.F_k; var arg_2936 any = pn__1; var arg_2937 any = r__2; if linked_2932 == nil { return ifn_2933.Invoke_O_O_O_O__O(arg_2934, arg_2935, arg_2936, arg_2937) } else { return linked_2932.(*A_arbace_j2g_dyn_class_fallback_A).Invoke_O_O_O_O_O__O(root_2931, arg_2934, arg_2935, arg_2936, arg_2937) } }
func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A{}; t.Ctor_O_O(p0, p1); return t }
//line :369:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :369:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2940 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2940, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_2942 lang.IFn; if linked_2941 == nil { ifn_2942 = lang.IFn_Cast(root_2940) } else { ifn_2942 = nil }; var arg_2943 any = t.F_ifaces; var arg_2944 any = t.F_k; var arg_2945 any = pn__1; var arg_2946 any = r__2; if linked_2941 == nil { return ifn_2942.Invoke_O_O_O_O__O(arg_2943, arg_2944, arg_2945, arg_2946) } else { return linked_2941.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O__O(root_2940, arg_2943, arg_2944, arg_2945, arg_2946) } }

















func A_arbace_j2g_dyn_fn_field_native_A_New() *A_arbace_j2g_dyn_fn_field_native_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_fn_field_native_A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Ctor() {}
//line :387:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Invoke_O__O(self any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_290; var tmp3 any; var root_2984 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_2985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2984, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2986 lang.IFn; if linked_2985 == nil { ifn_2986 = lang.IFn_Cast(root_2984) } else { ifn_2986 = nil }; var arg_2987 any; var root_2988 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_2989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2988, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_2990 lang.IFn; if linked_2989 == nil { ifn_2990 = lang.IFn_Cast(root_2988) } else { ifn_2990 = nil }; var arg_2991 any = Lit_55; var arg_2992 any = Lit_56; if linked_2989 == nil { arg_2987 = ifn_2990.Invoke_O_O__O(arg_2991, arg_2992) } else { arg_2987 = linked_2989.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_2988, arg_2991, arg_2992) }; if linked_2985 == nil { tmp3 = ifn_2986.Invoke_O__O(arg_2987) } else { tmp3 = linked_2985.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2984, arg_2987) }; var tmp4 any = tmp3; var tmp5 any; var root_2993 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2993, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2995 lang.IFn
	if linked_2994 == nil { ifn_2995 = lang.IFn_Cast(root_2993) } else { ifn_2995 = nil }; var arg_2996 any = A_arbace_j2g_dyn_A_const_293; var arg_2997 any = A_arbace_j2g_dyn_A_const_294; if linked_2994 == nil { tmp5 = ifn_2995.Invoke_O_O__O(arg_2996, arg_2997) } else { tmp5 = linked_2994.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2993, arg_2996, arg_2997) }
//line :392:1
	var tmp6 any = tmp5; var tmp7 any; var root_2998 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_2999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2998, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3000 lang.IFn
	if linked_2999 == nil { ifn_3000 = lang.IFn_Cast(root_2998) } else { ifn_3000 = nil }; var arg_3001 any = A_arbace_j2g_dyn_A_const_295; var arg_3002 any = A_arbace_j2g_dyn_A_const_296; if linked_2999 == nil { tmp7 = ifn_3000.Invoke_O_O__O(arg_3001, arg_3002) } else { tmp7 = linked_2999.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2998, arg_3001, arg_3002) }
//line :392:1
	var tmp8 any = tmp7; var tmp9 any; var root_3003 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3005 lang.IFn
	if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any = A_arbace_j2g_dyn_A_const_297; var arg_3007 any = A_arbace_j2g_dyn_A_const_298; if linked_3004 == nil { tmp9 = ifn_3005.Invoke_O_O__O(arg_3006, arg_3007) } else { tmp9 = linked_3004.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3003, arg_3006, arg_3007) }
//line :392:1
	var tmp10 any = tmp9; var tmp11 any; var root_3008 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3008, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3010 lang.IFn
	if linked_3009 == nil { ifn_3010 = lang.IFn_Cast(root_3008) } else { ifn_3010 = nil }; var arg_3011 any = A_arbace_j2g_dyn_A_const_299; var arg_3012 any = A_arbace_j2g_dyn_A_const_300; if linked_3009 == nil { tmp11 = ifn_3010.Invoke_O_O__O(arg_3011, arg_3012) } else { tmp11 = linked_3009.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3008, arg_3011, arg_3012) }
//line :392:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp10, tmp11), A_arbace_j2g_dyn_A_const_292)
}








func A_arbace_j2g_dyn_aot_fn_fields_native_A_New() *A_arbace_j2g_dyn_aot_fn_fields_native_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_aot_fn_fields_native_A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_j2g_dyn_aot_fn_fields_native_A) Ctor() {}
//line :402:1
func (t *A_arbace_j2g_dyn_aot_fn_fields_native_A) Invoke_O__O(self any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_301; var tmp3 any; var root_3013 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3013, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3015 lang.IFn; if linked_3014 == nil { ifn_3015 = lang.IFn_Cast(root_3013) } else { ifn_3015 = nil }; var arg_3016 any; var root_3017 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3017, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3019 lang.IFn; if linked_3018 == nil { ifn_3019 = lang.IFn_Cast(root_3017) } else { ifn_3019 = nil }; var arg_3020 any = Lit_9; var arg_3021 any = Lit_10; if linked_3018 == nil { arg_3016 = ifn_3019.Invoke_O_O__O(arg_3020, arg_3021) } else { arg_3016 = linked_3018.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3017, arg_3020, arg_3021) }; if linked_3014 == nil { tmp3 = ifn_3015.Invoke_O__O(arg_3016) } else { tmp3 = linked_3014.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3013, arg_3016) }; var tmp4 any = tmp3; var tmp5 any; var root_3022 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3022, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3024 lang.IFn
	if linked_3023 == nil { ifn_3024 = lang.IFn_Cast(root_3022) } else { ifn_3024 = nil }; var arg_3025 any = A_arbace_j2g_dyn_A_const_303; var arg_3026 any = A_arbace_j2g_dyn_A_const_304; if linked_3023 == nil { tmp5 = ifn_3024.Invoke_O_O__O(arg_3025, arg_3026) } else { tmp5 = linked_3023.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3022, arg_3025, arg_3026) }
//line :406:1
	var tmp6 any = tmp5; var tmp7 any; var root_3027 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3027, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3029 lang.IFn
	if linked_3028 == nil { ifn_3029 = lang.IFn_Cast(root_3027) } else { ifn_3029 = nil }; var arg_3030 any = A_arbace_j2g_dyn_A_const_305; var arg_3031 any = A_arbace_j2g_dyn_A_const_306; if linked_3028 == nil { tmp7 = ifn_3029.Invoke_O_O__O(arg_3030, arg_3031) } else { tmp7 = linked_3028.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3027, arg_3030, arg_3031) }
//line :406:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7), A_arbace_j2g_dyn_A_const_302)
}








func A_arbace_j2g_dyn_dyn_convert_form_A_New() *A_arbace_j2g_dyn_dyn_convert_form_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_dyn_convert_form_A{}; t.Ctor(); return t }
//line :416:1
func (t *A_arbace_j2g_dyn_dyn_convert_form_A) Ctor() {}
//line :416:1
func (t *A_arbace_j2g_dyn_dyn_convert_form_A) Invoke_O__O(self any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_307; var tmp3 any = A_arbace_j2g_dyn_A_const_308; var tmp4 any; var root_3032 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3032, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3034 lang.IFn




	if linked_3033 == nil { ifn_3034 = lang.IFn_Cast(root_3032) } else { ifn_3034 = nil }; var arg_3035 any; var tmp5 any; var root_3037 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3037, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3039 lang.IFn; if linked_3038 == nil { ifn_3039 = lang.IFn_Cast(root_3037) } else { ifn_3039 = nil }; var arg_3040 any = A_arbace_j2g_dyn_A_const_309; var arg_3041 any = A_arbace_j2g_dyn_A_const_310; if linked_3038 == nil { tmp5 = ifn_3039.Invoke_O_O__O(arg_3040, arg_3041) } else { tmp5 = linked_3038.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3037, arg_3040, arg_3041) }; var tmp6 any = tmp5; var tmp7 any; var root_3042 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3042, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3044 lang.IFn; if linked_3043 == nil { ifn_3044 = lang.IFn_Cast(root_3042) } else { ifn_3044 = nil }; var arg_3045 any = A_arbace_j2g_dyn_A_const_311; var arg_3046 any = A_arbace_j2g_dyn_A_const_312; if linked_3043 == nil { tmp7 = ifn_3044.Invoke_O_O__O(arg_3045, arg_3046) } else { tmp7 = linked_3043.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3042, arg_3045, arg_3046) }; arg_3035 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_3036 any = A_arbace_j2g_dyn_A_const_313; if linked_3033 == nil { tmp4 = ifn_3034.Invoke_O_O__O(arg_3035, arg_3036) } else { tmp4 = linked_3033.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3032, arg_3035, arg_3036) }
//line :420:1
	var tmp8 any = tmp4; var tmp9 any = A_arbace_j2g_dyn_A_const_314; var tmp10 any; var root_3047 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_3048 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3047, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3049 lang.IFn






	if linked_3048 == nil { ifn_3049 = lang.IFn_Cast(root_3047) } else { ifn_3049 = nil }; var arg_3050 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_3051 any = A_arbace_j2g_dyn_A_const_315; var arg_3052 any = A_arbace_j2g_dyn_A_const_316; var arg_3053 any; var root_3054 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3055 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3054, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3056 lang.IFn
	if linked_3055 == nil { ifn_3056 = lang.IFn_Cast(root_3054) } else { ifn_3056 = nil }; var arg_3057 any; var iter__1927001039__auto____1 any; var fnbody__3142 any = A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A_New(); var tmp11 *jrt.Class; var fncls__3141 *jrt.Class = A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A_fn_class
	if fncls__3141 == nil { var fncls__3141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A_fn_class = fncls__3141d; tmp11 = fncls__3141d } else { tmp11 = fncls__3141 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3142, tmp11, nil); var tmp12 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____1); var tmp13 any; var root_3143 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_3144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3143, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3145 lang.IFn; if linked_3144 == nil { ifn_3145 = lang.IFn_Cast(root_3143) } else { ifn_3145 = nil }; var arg_3146 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); if linked_3144 == nil { tmp13 = ifn_3145.Invoke_O__O(arg_3146) } else { tmp13 = linked_3144.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3143, arg_3146) }; arg_3057 = tmp12.Invoke_O__O(tmp13)
//line :428:1
	var arg_3058 any = A_arbace_j2g_dyn_A_const_320; if linked_3055 == nil { arg_3053 = ifn_3056.Invoke_O_O__O(arg_3057, arg_3058) } else { arg_3053 = linked_3055.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3054, arg_3057, arg_3058) }
//line :427:1
	if linked_3048 == nil { tmp10 = ifn_3049.Invoke_O_O_O_O__O(arg_3050, arg_3051, arg_3052, arg_3053) } else { tmp10 = linked_3048.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3047, arg_3050, arg_3051, arg_3052, arg_3053) }
//line :420:1
	return tmp1.Invoke_O_O_O_O_O_O_O__O(tmp2, tmp3, Lit_51, tmp8, tmp9, tmp10, A_arbace_j2g_dyn_A_const_321)
}







func A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A_New() *A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A) Ctor() {}
//line :429:1
func (t *A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A) Invoke_O_O__O(self, s__711000383__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3140 any = A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A_New_O_O(s__711000383__1, self); var tmp2 *jrt.Class; var fncls__3139 *jrt.Class = A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A_fn_class; if fncls__3139 == nil { var fncls__3139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__3140); A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A_fn_class = fncls__3139d; tmp2 = fncls__3139d } else { tmp2 = fncls__3139 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3140, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :429:1
func A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A{}; t.Ctor_O_O(p0, p1); return t }
//line :429:1
func (t *A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A) Ctor_O_O(c__s__711000383, c__iter__711000382 any) { t.F_s__711000383 = c__s__711000383; t.F_iter__711000382 = c__iter__711000382 }
//line :429:1
func (t *A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A) Invoke_O__O(self any) any { { var s__711000383__1 any; var t_ any = t.F_s__711000383; t.F_s__711000383 = nil; s__711000383__1 = t_; for { var temp__1927000414__auto____2 any; var root_3059 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3059, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3061 lang.IFn; if linked_3060 == nil { ifn_3061 = lang.IFn_Cast(root_3059) } else { ifn_3061 = nil }; var arg_3062 any = s__711000383__1; if linked_3060 == nil { temp__1927000414__auto____2 = ifn_3061.Invoke_O__O(arg_3062) } else { temp__1927000414__auto____2 = linked_3060.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3059, arg_3062) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000383__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3063 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3063, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3065 lang.IFn; if linked_3064 == nil { ifn_3065 = lang.IFn_Cast(root_3063) } else { ifn_3065 = nil }; var arg_3066 any = s__711000383__3; if linked_3064 == nil { tmp1 = ifn_3065.Invoke_O__O(arg_3066) } else { tmp1 = linked_3064.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3063, arg_3066) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3067 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3067, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3069 lang.IFn; if linked_3068 == nil { ifn_3069 = lang.IFn_Cast(root_3067) } else { ifn_3069 = nil }; var arg_3070 any = s__711000383__3; if linked_3068 == nil { c__1927001037__auto____4 = ifn_3069.Invoke_O__O(arg_3070) } else { c__1927001037__auto____4 = linked_3068.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3067, arg_3070) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000385__6 any; var root_3071 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3071, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3073 lang.IFn; if linked_3072 == nil { ifn_3073 = lang.IFn_Cast(root_3071) } else { ifn_3073 = nil }; var arg_3074 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3072 == nil { b__711000385__6 = ifn_3073.Invoke_O__O(arg_3074) } else { b__711000385__6 = linked_3072.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3071, arg_3074) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3092 any = A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A_New_O_I_O(b__711000385__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3091 *jrt.Class = A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A_fn_class; if fncls__3091 == nil { var fncls__3091d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__3092); A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A_fn_class = fncls__3091d; tmp3 = fncls__3091d } else { tmp3 = fncls__3091 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3092, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3093 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3093, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3095 lang.IFn; if linked_3094 == nil { ifn_3095 = lang.IFn_Cast(root_3093) } else { ifn_3095 = nil }; var arg_3096 any; var root_3098 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3098, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3100 lang.IFn; if linked_3099 == nil { ifn_3100 = lang.IFn_Cast(root_3098) } else { ifn_3100 = nil }; var arg_3101 any = b__711000385__6; if linked_3099 == nil { arg_3096 = ifn_3100.Invoke_O__O(arg_3101) } else { arg_3096 = linked_3099.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3098, arg_3101) }; var arg_3097 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000382); var tmp5 any; var root_3102 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3102, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3104 lang.IFn; if linked_3103 == nil { ifn_3104 = lang.IFn_Cast(root_3102) } else { ifn_3104 = nil }; var arg_3105 any = s__711000383__3; if linked_3103 == nil { tmp5 = ifn_3104.Invoke_O__O(arg_3105) } else { tmp5 = linked_3103.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3102, arg_3105) }; arg_3097 = tmp4.Invoke_O__O(tmp5); if linked_3094 == nil { return ifn_3095.Invoke_O_O__O(arg_3096, arg_3097) } else { return linked_3094.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3093, arg_3096, arg_3097) } } else { var root_3106 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3106, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3108 lang.IFn; if linked_3107 == nil { ifn_3108 = lang.IFn_Cast(root_3106) } else { ifn_3108 = nil }; var arg_3109 any; var root_3111 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3111, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3113 lang.IFn; if linked_3112 == nil { ifn_3113 = lang.IFn_Cast(root_3111) } else { ifn_3113 = nil }; var arg_3114 any = b__711000385__6; if linked_3112 == nil { arg_3109 = ifn_3113.Invoke_O__O(arg_3114) } else { arg_3109 = linked_3112.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3111, arg_3114) }; var arg_3110 any; if linked_3107 == nil { return ifn_3108.Invoke_O_O__O(arg_3109, arg_3110) } else { return linked_3107.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3106, arg_3109, arg_3110) } } } else { var vec__711000393__4 any; var root_3115 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3115, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3117 lang.IFn; if linked_3116 == nil { ifn_3117 = lang.IFn_Cast(root_3115) } else { ifn_3117 = nil }; var arg_3118 any = s__711000383__3; if linked_3116 == nil { vec__711000393__4 = ifn_3117.Invoke_O__O(arg_3118) } else { vec__711000393__4 = linked_3116.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3115, arg_3118) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000393__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000393__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3119 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3119, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3121 lang.IFn; if linked_3120 == nil { ifn_3121 = lang.IFn_Cast(root_3119) } else { ifn_3121 = nil }; var arg_3122 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_317; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(d__5); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_318; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp12 any; var root_3124 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_3125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3124, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3126 lang.IFn
															if linked_3125 == nil { ifn_3126 = lang.IFn_Cast(root_3124) } else { ifn_3126 = nil }; var arg_3127 any = A_arbace_j2g_dyn_A_const_76; var arg_3128 any = Lit_18; var arg_3129 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp14 any; var root_3130 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_3131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3130, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_3132 lang.IFn; if linked_3131 == nil { ifn_3132 = lang.IFn_Cast(root_3130) } else { ifn_3132 = nil }; var arg_3133 any = nme__6; var arg_3134 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__5)).Ref(); if linked_3131 == nil { tmp14 = ifn_3132.Invoke_O_O__O(arg_3133, arg_3134) } else { tmp14 = linked_3131.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_3130, arg_3133, arg_3134) }; arg_3129 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3125 == nil { tmp12 = ifn_3126.Invoke_O_O_O__O(arg_3127, arg_3128, arg_3129) } else { tmp12 = linked_3125.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3124, arg_3127, arg_3128, arg_3129) }; arg_3122 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(tmp12, A_arbace_j2g_dyn_A_const_319)))
//line :429:1
	var arg_3123 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__711000382); var tmp16 any; var root_3135 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_3136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3135, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3137 lang.IFn; if linked_3136 == nil { ifn_3137 = lang.IFn_Cast(root_3135) } else { ifn_3137 = nil }; var arg_3138 any = s__711000383__3; if linked_3136 == nil { tmp16 = ifn_3137.Invoke_O__O(arg_3138) } else { tmp16 = linked_3136.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3135, arg_3138) }; arg_3123 = tmp15.Invoke_O__O(tmp16); if linked_3120 == nil { return ifn_3121.Invoke_O_O__O(arg_3122, arg_3123) } else { return linked_3120.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3119, arg_3122, arg_3123) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :429:1
func A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :429:1
func (t *A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A) Ctor_O_I_O(c__b__711000385 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000385 = c__b__711000385; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :429:1
func (t *A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A) Invoke_O__O(self any) any { { var i__711000384__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000384__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000389__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000384__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000389__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000389__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3075 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3075, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3077 lang.IFn; if linked_3076 == nil { ifn_3077 = lang.IFn_Cast(root_3075) } else { ifn_3077 = nil }; var arg_3078 any = t.F_b__711000385; var arg_3079 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_317; var tmp4 any = lang.Tuple_Create_O__IPersistentVector(d__3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_318; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp8 any; var root_3080 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_3081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3080, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3082 lang.IFn
																if linked_3081 == nil { ifn_3082 = lang.IFn_Cast(root_3080) } else { ifn_3082 = nil }; var arg_3083 any = A_arbace_j2g_dyn_A_const_76; var arg_3084 any = Lit_18; var arg_3085 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp10 any; var root_3086 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_3087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3086, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_3088 lang.IFn; if linked_3087 == nil { ifn_3088 = lang.IFn_Cast(root_3086) } else { ifn_3088 = nil }; var arg_3089 any = nme__4; var arg_3090 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3)).Ref(); if linked_3087 == nil { tmp10 = ifn_3088.Invoke_O_O__O(arg_3089, arg_3090) } else { tmp10 = linked_3087.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_3086, arg_3089, arg_3090) }; arg_3085 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3081 == nil { tmp8 = ifn_3082.Invoke_O_O_O__O(arg_3083, arg_3084, arg_3085) } else { tmp8 = linked_3081.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3080, arg_3083, arg_3084, arg_3085) }; arg_3079 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, A_arbace_j2g_dyn_A_const_319)))
//line :429:1
	if linked_3076 == nil { ifn_3077.Invoke_O_O__O(arg_3078, arg_3079) } else { linked_3076.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3075, arg_3078, arg_3079) }; i__711000384__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000384__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyn_method_impl_native_A_New() *A_arbace_j2g_dyn_method_impl_native_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_impl_native_A{}; t.Ctor(); return t }
//line :435:1
func (t *A_arbace_j2g_dyn_method_impl_native_A) Ctor() {}
//line :435:1
func (t *A_arbace_j2g_dyn_method_impl_native_A) Invoke_O__O(self any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_322; var tmp3 any; var root_3147 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3147, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3149 lang.IFn; if linked_3148 == nil { ifn_3149 = lang.IFn_Cast(root_3147) } else { ifn_3149 = nil }; var arg_3150 any; var root_3151 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3151, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3153 lang.IFn; if linked_3152 == nil { ifn_3153 = lang.IFn_Cast(root_3151) } else { ifn_3153 = nil }; var arg_3154 any = Lit_93; var arg_3155 any = Lit_94; if linked_3152 == nil { arg_3150 = ifn_3153.Invoke_O_O__O(arg_3154, arg_3155) } else { arg_3150 = linked_3152.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3151, arg_3154, arg_3155) }; if linked_3148 == nil { tmp3 = ifn_3149.Invoke_O__O(arg_3150) } else { tmp3 = linked_3148.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3147, arg_3150) }; var tmp4 any = tmp3; var tmp5 any; var root_3156 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3156, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3158 lang.IFn
	if linked_3157 == nil { ifn_3158 = lang.IFn_Cast(root_3156) } else { ifn_3158 = nil }; var arg_3159 any; var tmp6 any; var root_3161 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3161, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3163 lang.IFn; if linked_3162 == nil { ifn_3163 = lang.IFn_Cast(root_3161) } else { ifn_3163 = nil }; var arg_3164 any = A_arbace_j2g_dyn_A_const_323; var arg_3165 any = A_arbace_j2g_dyn_A_const_324; if linked_3162 == nil { tmp6 = ifn_3163.Invoke_O_O__O(arg_3164, arg_3165) } else { tmp6 = linked_3162.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3161, arg_3164, arg_3165) }; var tmp7 any = tmp6; var tmp8 any; var root_3166 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3166, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3168 lang.IFn; if linked_3167 == nil { ifn_3168 = lang.IFn_Cast(root_3166) } else { ifn_3168 = nil }; var arg_3169 any = A_arbace_j2g_dyn_A_const_325; var arg_3170 any = A_arbace_j2g_dyn_A_const_326; if linked_3167 == nil { tmp8 = ifn_3168.Invoke_O_O__O(arg_3169, arg_3170) } else { tmp8 = linked_3167.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3166, arg_3169, arg_3170) }; arg_3159 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8); var arg_3160 any = A_arbace_j2g_dyn_A_const_327; if linked_3157 == nil { tmp5 = ifn_3158.Invoke_O_O__O(arg_3159, arg_3160) } else { tmp5 = linked_3157.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3156, arg_3159, arg_3160) }
//line :441:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, tmp5, A_arbace_j2g_dyn_A_const_328)
}





func A_arbace_j2g_dyn_core_forms_A_New() *A_arbace_j2g_dyn_core_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_core_forms_A{}; t.Ctor(); return t }
//line :448:1
func (t *A_arbace_j2g_dyn_core_forms_A) Ctor() {}
//line :448:1
func (t *A_arbace_j2g_dyn_core_forms_A) Invoke_O_O_O_O__O(self, ifaces__0, ks__1, n__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_350; var tmp3 any = tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ifaces__0)).Ref(), nil, n__2, nil)).Ref()); var tmp4 any = A_arbace_j2g_dyn_A_const_329; var tmp5 any = A_arbace_j2g_dyn_A_const_330; var tmp6 any = A_arbace_j2g_dyn_A_const_331; var tmp7 any = A_arbace_j2g_dyn_A_const_332; var tmp8 any = A_arbace_j2g_dyn_A_const_333; var tmp9 any = A_arbace_j2g_dyn_A_const_334; var tmp10 any = A_arbace_j2g_dyn_A_const_335; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyn_A_const_351; var tmp13 any; var root_3174 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3174, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3176 lang.IFn; if


































	linked_3175 == nil { ifn_3176 = lang.IFn_Cast(root_3174) } else { ifn_3176 = nil }; var arg_3177 any = A_arbace_j2g_dyn_A_const_352; var arg_3178 any = A_arbace_j2g_dyn_A_const_353; if linked_3175 == nil { tmp13 = ifn_3176.Invoke_O_O__O(arg_3177, arg_3178) } else { tmp13 = linked_3175.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3174, arg_3177, arg_3178) }; var tmp14 any = tmp13; var tmp15 any; var root_3179 any = /*line :448:1*/A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_3180 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3179, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3181 lang.IFn; if



































	linked_3180 == nil { ifn_3181 = lang.IFn_Cast(root_3179) } else { ifn_3181 = nil }; var arg_3182 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_3183 any = A_arbace_j2g_dyn_A_const_354; var arg_3184 any = A_arbace_j2g_dyn_A_const_355; var arg_3185 any; var root_3186 any = A_arbace_j2g_dyn_A_const_231.GetRawRoot__O(); var linked_3187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3186, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_3188 lang.IFn; if linked_3187 == nil { ifn_3188 = lang.IFn_Cast(root_3186) } else { ifn_3188 = nil }; var arg_3189 any; var fnbody__3192 any = A_arbace_j2g_dyn_core_forms_fn__711000401_A_New(); var tmp16 *jrt.Class; var fncls__3191 *jrt.Class = A_arbace_j2g_dyn_core_forms_fn__711000401_A_fn_class; if fncls__3191 == nil { var fncls__3191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_j2g_dyn_core_forms_fn__711000401_A_fn_class = fncls__3191d; tmp16 = fncls__3191d } else { tmp16 = fncls__3191 }; arg_3189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3192, tmp16, nil); var arg_3190 any = ks__1; if linked_3187 == nil { arg_3185 = ifn_3188.Invoke_O_O__O(arg_3189, arg_3190) } else { arg_3185 = linked_3187.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_3186, arg_3189, arg_3190) }; if linked_3180 == nil { tmp15 = ifn_3181.Invoke_O_O_O_O__O(arg_3182, arg_3183, arg_3184, arg_3185) } else { tmp15 = linked_3180.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3179, arg_3182, arg_3183, arg_3184, arg_3185) }; var tmp17 any = /*line :448:1*/tmp11.Invoke_O_O_O__O(tmp12, tmp14, tmp15); var tmp18 any = A_arbace_j2g_dyn_A_const_336; var tmp19 any = A_arbace_j2g_dyn_A_const_337; var tmp20 any; var root_3171 any = A_arbace_j2g_dyn_A_const_338.GetRawRoot__O(); var linked_3172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3171, A_arbace_j2g_dyn_dyn_convert_form_A_fn_class); var ifn_3173 lang.IFn; if













































	linked_3172 == nil { ifn_3173 = lang.IFn_Cast(root_3171) } else { ifn_3173 = nil }; if linked_3172 == nil { tmp20 = ifn_3173.Invoke__O() } else { tmp20 = linked_3172.(*A_arbace_j2g_dyn_dyn_convert_form_A).Invoke_O__O(root_3171) }; return /*line :448:1*/ lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp17, tmp18, tmp19, tmp20, A_arbace_j2g_dyn_A_const_339, A_arbace_j2g_dyn_A_const_340, A_arbace_j2g_dyn_A_const_341, A_arbace_j2g_dyn_A_const_342, A_arbace_j2g_dyn_A_const_343, A_arbace_j2g_dyn_A_const_344, A_arbace_j2g_dyn_A_const_345, A_arbace_j2g_dyn_A_const_346, A_arbace_j2g_dyn_A_const_347, A_arbace_j2g_dyn_A_const_348, A_arbace_j2g_dyn_A_const_349)) }



































func A_arbace_j2g_dyn_core_forms_fn__711000401_A_New() *A_arbace_j2g_dyn_core_forms_fn__711000401_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_core_forms_fn__711000401_A{}; t.Ctor(); return t }
//line :484:1
func (t *A_arbace_j2g_dyn_core_forms_fn__711000401_A) Ctor() {}
//line :484:1
func (t *A_arbace_j2g_dyn_core_forms_fn__711000401_A) Invoke_O_O_O__O(self, i__1, p__711000400__2 any) any { var vec__711000402__3 any = p__711000400__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000402__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000402__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }















































func A_arbace_j2g_dyn_dyn_serial_new_form_A_New() *A_arbace_j2g_dyn_dyn_serial_new_form_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_dyn_serial_new_form_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_j2g_dyn_dyn_serial_new_form_A) Ctor() {}
//line :532:1
func (t *A_arbace_j2g_dyn_dyn_serial_new_form_A) Invoke_O__O(self any) any { return A_arbace_j2g_dyn_A_const_356 }








func A_arbace_j2g_dyn_native_forms_A_New() *A_arbace_j2g_dyn_native_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_native_forms_A{}; t.Ctor(); return t }
//line :541:1
func (t *A_arbace_j2g_dyn_native_forms_A) Ctor() {}
//line :541:1
func (t *A_arbace_j2g_dyn_native_forms_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_368; var tmp3 any; var root_3202 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3202, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3204 lang.IFn; if





	linked_3203 == nil { ifn_3204 = lang.IFn_Cast(root_3202) } else { ifn_3204 = nil }; var arg_3205 any; var root_3206 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3206, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3208 lang.IFn; if linked_3207 == nil { ifn_3208 = lang.IFn_Cast(root_3206) } else { ifn_3208 = nil }; var arg_3209 any = Lit_95; var arg_3210 any = Lit_96; if linked_3207 == nil { arg_3205 = ifn_3208.Invoke_O_O__O(arg_3209, arg_3210) } else { arg_3205 = linked_3207.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3206, arg_3209, arg_3210) }; if linked_3203 == nil { tmp3 = ifn_3204.Invoke_O__O(arg_3205) } else { tmp3 = linked_3203.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3202, arg_3205) }; var tmp4 any = tmp3; var tmp5 any; var root_3211 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3211, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3213 lang.IFn; if






	linked_3212 == nil { ifn_3213 = lang.IFn_Cast(root_3211) } else { ifn_3213 = nil }; var arg_3214 any; var tmp6 any; var root_3216 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3216, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3218 lang.IFn; if linked_3217 == nil { ifn_3218 = lang.IFn_Cast(root_3216) } else { ifn_3218 = nil }; var arg_3219 any = A_arbace_j2g_dyn_A_const_369; var arg_3220 any = A_arbace_j2g_dyn_A_const_370; if linked_3217 == nil { tmp6 = ifn_3218.Invoke_O_O__O(arg_3219, arg_3220) } else { tmp6 = linked_3217.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3216, arg_3219, arg_3220) }; var tmp7 any = tmp6; var tmp8 any; var root_3221 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3221, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3223 lang.IFn; if linked_3222 == nil { ifn_3223 = lang.IFn_Cast(root_3221) } else { ifn_3223 = nil }; var arg_3224 any = A_arbace_j2g_dyn_A_const_371; var arg_3225 any = A_arbace_j2g_dyn_A_const_372; if linked_3222 == nil { tmp8 = ifn_3223.Invoke_O_O__O(arg_3224, arg_3225) } else { tmp8 = linked_3222.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3221, arg_3224, arg_3225) }; var tmp9 any = tmp8; var tmp10 any; var root_3226 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3226, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3228 lang.IFn; if linked_3227 == nil { ifn_3228 = lang.IFn_Cast(root_3226) } else { ifn_3228 = nil }; var arg_3229 any = A_arbace_j2g_dyn_A_const_373; var arg_3230 any = A_arbace_j2g_dyn_A_const_374; if linked_3227 == nil { tmp10 = ifn_3228.Invoke_O_O__O(arg_3229, arg_3230) } else { tmp10 = linked_3227.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3226, arg_3229, arg_3230) }; arg_3214 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, tmp9, tmp10); var arg_3215 any = A_arbace_j2g_dyn_A_const_375; if linked_3212 == nil { tmp5 = ifn_3213.Invoke_O_O__O(arg_3214, arg_3215) } else { tmp5 = linked_3212.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3211, arg_3214, arg_3215) }; var tmp11 any = tmp5; var tmp12 lang.IFn = /*line :541:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_dyn_A_const_376; var tmp14 any = A_arbace_j2g_dyn_A_const_381; var tmp15 any = A_arbace_j2g_dyn_A_const_382; var tmp16 any = A_arbace_j2g_dyn_A_const_383; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_384; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_dyn_A_const_385; var tmp21 any = A_arbace_j2g_dyn_A_const_386; var tmp22 any = A_arbace_j2g_dyn_A_const_387; var tmp23 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp14, tmp15, tmp16, tmp17.Invoke_O_O__O(tmp18, tmp19.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp20, tmp21, tmp22, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_394, A_arbace_j2g_dyn_A_const_395, n__0), A_arbace_j2g_dyn_A_const_388, A_arbace_j2g_dyn_A_const_389, A_arbace_j2g_dyn_A_const_390, A_arbace_j2g_dyn_A_const_391, A_arbace_j2g_dyn_A_const_392, A_arbace_j2g_dyn_A_const_393))); var tmp24 any = A_arbace_j2g_dyn_A_const_377; var tmp25 any = A_arbace_j2g_dyn_A_const_378; var tmp26 any; var root_3231 any = A_arbace_j2g_dyn_A_const_379.GetRawRoot__O(); var linked_3232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3231, A_arbace_j2g_dyn_dyn_serial_new_form_A_fn_class); var ifn_3233 lang.IFn; if































	linked_3232 == nil { ifn_3233 = lang.IFn_Cast(root_3231) } else { ifn_3233 = nil }; if linked_3232 == nil { tmp26 = ifn_3233.Invoke__O() } else { tmp26 = linked_3232.(*A_arbace_j2g_dyn_dyn_serial_new_form_A).Invoke_O__O(root_3231) }; var tmp27 any = /*line :541:1*/tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, tmp11, tmp12.Invoke_O_O_O_O_O_O__O(tmp13, tmp23, tmp24, tmp25, tmp26, A_arbace_j2g_dyn_A_const_380)); var tmp28 any = A_arbace_j2g_dyn_A_const_357; var tmp29 any = A_arbace_j2g_dyn_A_const_358; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_dyn_A_const_396; var tmp32 any; var root_3234 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3234, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3236 lang.IFn; if


















































	linked_3235 == nil { ifn_3236 = lang.IFn_Cast(root_3234) } else { ifn_3236 = nil }; var arg_3237 any; var root_3238 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3238, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3240 lang.IFn; if linked_3239 == nil { ifn_3240 = lang.IFn_Cast(root_3238) } else { ifn_3240 = nil }; var arg_3241 any = Lit_97; var arg_3242 any = Lit_98; if linked_3239 == nil { arg_3237 = ifn_3240.Invoke_O_O__O(arg_3241, arg_3242) } else { arg_3237 = linked_3239.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3238, arg_3241, arg_3242) }; if linked_3235 == nil { tmp32 = ifn_3236.Invoke_O__O(arg_3237) } else { tmp32 = linked_3235.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3234, arg_3237) }; var tmp33 any = tmp32; var tmp34 any; var root_3243 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3243, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3245 lang.IFn; if



















































	linked_3244 == nil { ifn_3245 = lang.IFn_Cast(root_3243) } else { ifn_3245 = nil }; var arg_3246 any = A_arbace_j2g_dyn_A_const_398; var arg_3247 any = A_arbace_j2g_dyn_A_const_399; if linked_3244 == nil { tmp34 = ifn_3245.Invoke_O_O__O(arg_3246, arg_3247) } else { tmp34 = linked_3244.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3243, arg_3246, arg_3247) }; var tmp35 any = tmp34; var tmp36 any; var root_3248 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3248, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3250 lang.IFn; if



















































	linked_3249 == nil { ifn_3250 = lang.IFn_Cast(root_3248) } else { ifn_3250 = nil }; var arg_3251 any = A_arbace_j2g_dyn_A_const_400; var arg_3252 any = A_arbace_j2g_dyn_A_const_401; if linked_3249 == nil { tmp36 = ifn_3250.Invoke_O_O__O(arg_3251, arg_3252) } else { tmp36 = linked_3249.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3248, arg_3251, arg_3252) }; var tmp37 any = tmp36; var tmp38 any; var root_3253 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3253, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3255 lang.IFn; if



















































	linked_3254 == nil { ifn_3255 = lang.IFn_Cast(root_3253) } else { ifn_3255 = nil }; var arg_3256 any = A_arbace_j2g_dyn_A_const_402; var arg_3257 any = A_arbace_j2g_dyn_A_const_403; if linked_3254 == nil { tmp38 = ifn_3255.Invoke_O_O__O(arg_3256, arg_3257) } else { tmp38 = linked_3254.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3253, arg_3256, arg_3257) }; var tmp39 any = tmp38; var tmp40 any; var root_3258 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3258, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3260 lang.IFn; if



















































	linked_3259 == nil { ifn_3260 = lang.IFn_Cast(root_3258) } else { ifn_3260 = nil }; var arg_3261 any = A_arbace_j2g_dyn_A_const_404; var arg_3262 any = A_arbace_j2g_dyn_A_const_405; if linked_3259 == nil { tmp40 = ifn_3260.Invoke_O_O__O(arg_3261, arg_3262) } else { tmp40 = linked_3259.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3258, arg_3261, arg_3262) }; var tmp41 any = tmp40; var tmp42 any; var root_3263 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3263, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3265 lang.IFn; if



















































	linked_3264 == nil { ifn_3265 = lang.IFn_Cast(root_3263) } else { ifn_3265 = nil }; var arg_3266 any = A_arbace_j2g_dyn_A_const_406; var arg_3267 any = A_arbace_j2g_dyn_A_const_407; if linked_3264 == nil { tmp42 = ifn_3265.Invoke_O_O__O(arg_3266, arg_3267) } else { tmp42 = linked_3264.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3263, arg_3266, arg_3267) }; var tmp43 any = /*line :541:1*/tmp30.Invoke_O_O_O_O__O(tmp31, tmp33, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp35, tmp37, tmp39, tmp41, tmp42), A_arbace_j2g_dyn_A_const_397); var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp45 any = A_arbace_j2g_dyn_A_const_408; var tmp46 any; var root_3268 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3268, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3270 lang.IFn; if















































































	linked_3269 == nil { ifn_3270 = lang.IFn_Cast(root_3268) } else { ifn_3270 = nil }; var arg_3271 any; var root_3272 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3272, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3274 lang.IFn; if linked_3273 == nil { ifn_3274 = lang.IFn_Cast(root_3272) } else { ifn_3274 = nil }; var arg_3275 any = Lit_99; var arg_3276 any = Lit_98; if linked_3273 == nil { arg_3271 = ifn_3274.Invoke_O_O__O(arg_3275, arg_3276) } else { arg_3271 = linked_3273.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3272, arg_3275, arg_3276) }; if linked_3269 == nil { tmp46 = ifn_3270.Invoke_O__O(arg_3271) } else { tmp46 = linked_3269.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3268, arg_3271) }; var tmp47 any = tmp46; var tmp48 any; var root_3277 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3277, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3279 lang.IFn; if
















































































	linked_3278 == nil { ifn_3279 = lang.IFn_Cast(root_3277) } else { ifn_3279 = nil }; var arg_3280 any = A_arbace_j2g_dyn_A_const_410; var arg_3281 any = A_arbace_j2g_dyn_A_const_411; if linked_3278 == nil { tmp48 = ifn_3279.Invoke_O_O__O(arg_3280, arg_3281) } else { tmp48 = linked_3278.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3277, arg_3280, arg_3281) }; var tmp49 any = tmp48; var tmp50 any; var root_3282 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3282, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3284 lang.IFn; if
















































































	linked_3283 == nil { ifn_3284 = lang.IFn_Cast(root_3282) } else { ifn_3284 = nil }; var arg_3285 any = A_arbace_j2g_dyn_A_const_412; var arg_3286 any = A_arbace_j2g_dyn_A_const_413; if linked_3283 == nil { tmp50 = ifn_3284.Invoke_O_O__O(arg_3285, arg_3286) } else { tmp50 = linked_3283.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3282, arg_3285, arg_3286) }; var tmp51 any = tmp50; var tmp52 any; var root_3287 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3287, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3289 lang.IFn; if
















































































	linked_3288 == nil { ifn_3289 = lang.IFn_Cast(root_3287) } else { ifn_3289 = nil }; var arg_3290 any = A_arbace_j2g_dyn_A_const_414; var arg_3291 any = A_arbace_j2g_dyn_A_const_415; if linked_3288 == nil { tmp52 = ifn_3289.Invoke_O_O__O(arg_3290, arg_3291) } else { tmp52 = linked_3288.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3287, arg_3290, arg_3291) }; var tmp53 any = tmp52; var tmp54 any; var root_3292 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3292, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3294 lang.IFn; if
















































































	linked_3293 == nil { ifn_3294 = lang.IFn_Cast(root_3292) } else { ifn_3294 = nil }; var arg_3295 any = A_arbace_j2g_dyn_A_const_416; var arg_3296 any = A_arbace_j2g_dyn_A_const_417; if linked_3293 == nil { tmp54 = ifn_3294.Invoke_O_O__O(arg_3295, arg_3296) } else { tmp54 = linked_3293.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3292, arg_3295, arg_3296) }; var tmp55 any = tmp54; var tmp56 any; var root_3297 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3297, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3299 lang.IFn; if
















































































	linked_3298 == nil { ifn_3299 = lang.IFn_Cast(root_3297) } else { ifn_3299 = nil }; var arg_3300 any = A_arbace_j2g_dyn_A_const_418; var arg_3301 any = A_arbace_j2g_dyn_A_const_419; if linked_3298 == nil { tmp56 = ifn_3299.Invoke_O_O__O(arg_3300, arg_3301) } else { tmp56 = linked_3298.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3297, arg_3300, arg_3301) }; var tmp57 any = /*line :541:1*/tmp44.Invoke_O_O_O_O__O(tmp45, tmp47, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp49, tmp51, tmp53, tmp55, tmp56), A_arbace_j2g_dyn_A_const_409); var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp59 any = A_arbace_j2g_dyn_A_const_420; var tmp60 any; var root_3302 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3302, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3304 lang.IFn; if
























































































	linked_3303 == nil { ifn_3304 = lang.IFn_Cast(root_3302) } else { ifn_3304 = nil }; var arg_3305 any; var root_3306 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3306, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3308 lang.IFn; if linked_3307 == nil { ifn_3308 = lang.IFn_Cast(root_3306) } else { ifn_3308 = nil }; var arg_3309 any = Lit_100; var arg_3310 any = Lit_101; if linked_3307 == nil { arg_3305 = ifn_3308.Invoke_O_O__O(arg_3309, arg_3310) } else { arg_3305 = linked_3307.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3306, arg_3309, arg_3310) }; if linked_3303 == nil { tmp60 = ifn_3304.Invoke_O__O(arg_3305) } else { tmp60 = linked_3303.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3302, arg_3305) }; var tmp61 any = tmp60; var tmp62 any; var root_3311 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3311, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3313 lang.IFn; if

























































































	linked_3312 == nil { ifn_3313 = lang.IFn_Cast(root_3311) } else { ifn_3313 = nil }; var arg_3314 any = A_arbace_j2g_dyn_A_const_422; var arg_3315 any = A_arbace_j2g_dyn_A_const_423; if linked_3312 == nil { tmp62 = ifn_3313.Invoke_O_O__O(arg_3314, arg_3315) } else { tmp62 = linked_3312.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3311, arg_3314, arg_3315) }; var tmp63 any = tmp62; var tmp64 any; var root_3316 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3316, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3318 lang.IFn; if

























































































	linked_3317 == nil { ifn_3318 = lang.IFn_Cast(root_3316) } else { ifn_3318 = nil }; var arg_3319 any = A_arbace_j2g_dyn_A_const_424; var arg_3320 any = A_arbace_j2g_dyn_A_const_425; if linked_3317 == nil { tmp64 = ifn_3318.Invoke_O_O__O(arg_3319, arg_3320) } else { tmp64 = linked_3317.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3316, arg_3319, arg_3320) }; var tmp65 any = tmp64; var tmp66 any; var root_3321 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3321, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3323 lang.IFn; if

























































































	linked_3322 == nil { ifn_3323 = lang.IFn_Cast(root_3321) } else { ifn_3323 = nil }; var arg_3324 any = A_arbace_j2g_dyn_A_const_426; var arg_3325 any = A_arbace_j2g_dyn_A_const_427; if linked_3322 == nil { tmp66 = ifn_3323.Invoke_O_O__O(arg_3324, arg_3325) } else { tmp66 = linked_3322.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3321, arg_3324, arg_3325) }; var tmp67 any = /*line :541:1*/tmp58.Invoke_O_O_O_O__O(tmp59, tmp61, lang.Tuple_Create_O_O_O__IPersistentVector(tmp63, tmp65, tmp66), A_arbace_j2g_dyn_A_const_421); var tmp68 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp69 any = A_arbace_j2g_dyn_A_const_428; var tmp70 any; var root_3326 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3326, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3328 lang.IFn; if







































































































	linked_3327 == nil { ifn_3328 = lang.IFn_Cast(root_3326) } else { ifn_3328 = nil }; var arg_3329 any; var root_3330 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3330, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3332 lang.IFn; if linked_3331 == nil { ifn_3332 = lang.IFn_Cast(root_3330) } else { ifn_3332 = nil }; var arg_3333 any = Lit_102; var arg_3334 any = Lit_103; if linked_3331 == nil { arg_3329 = ifn_3332.Invoke_O_O__O(arg_3333, arg_3334) } else { arg_3329 = linked_3331.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3330, arg_3333, arg_3334) }; if linked_3327 == nil { tmp70 = ifn_3328.Invoke_O__O(arg_3329) } else { tmp70 = linked_3327.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3326, arg_3329) }; var tmp71 any = tmp70; var tmp72 any; var root_3335 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3335, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3337 lang.IFn; if








































































































	linked_3336 == nil { ifn_3337 = lang.IFn_Cast(root_3335) } else { ifn_3337 = nil }; var arg_3338 any; var tmp73 any; var root_3340 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3340, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3342 lang.IFn; if linked_3341 == nil { ifn_3342 = lang.IFn_Cast(root_3340) } else { ifn_3342 = nil }; var arg_3343 any = A_arbace_j2g_dyn_A_const_429; var arg_3344 any = A_arbace_j2g_dyn_A_const_430; if linked_3341 == nil { tmp73 = ifn_3342.Invoke_O_O__O(arg_3343, arg_3344) } else { tmp73 = linked_3341.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3340, arg_3343, arg_3344) }; var tmp74 any = tmp73; var tmp75 any; var root_3345 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3345, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3347 lang.IFn; if linked_3346 == nil { ifn_3347 = lang.IFn_Cast(root_3345) } else { ifn_3347 = nil }; var arg_3348 any = A_arbace_j2g_dyn_A_const_431; var arg_3349 any = A_arbace_j2g_dyn_A_const_432; if linked_3346 == nil { tmp75 = ifn_3347.Invoke_O_O__O(arg_3348, arg_3349) } else { tmp75 = linked_3346.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3345, arg_3348, arg_3349) }; arg_3338 = lang.Tuple_Create_O_O__IPersistentVector(tmp74, tmp75); var arg_3339 any = A_arbace_j2g_dyn_A_const_433; if linked_3336 == nil { tmp72 = ifn_3337.Invoke_O_O__O(arg_3338, arg_3339) } else { tmp72 = linked_3336.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3335, arg_3338, arg_3339) }; var tmp76 any = /*line :541:1*/tmp68.Invoke_O_O_O_O__O(tmp69, tmp71, tmp72, A_arbace_j2g_dyn_A_const_434); var tmp77 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp78 any = A_arbace_j2g_dyn_A_const_435; var tmp79 any; var root_3350 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3350, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3352 lang.IFn; if





















































































































	linked_3351 == nil { ifn_3352 = lang.IFn_Cast(root_3350) } else { ifn_3352 = nil }; var arg_3353 any; var root_3354 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3354, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3356 lang.IFn; if linked_3355 == nil { ifn_3356 = lang.IFn_Cast(root_3354) } else { ifn_3356 = nil }; var arg_3357 any = Lit_104; var arg_3358 any = Lit_105; if linked_3355 == nil { arg_3353 = ifn_3356.Invoke_O_O__O(arg_3357, arg_3358) } else { arg_3353 = linked_3355.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3354, arg_3357, arg_3358) }; if linked_3351 == nil { tmp79 = ifn_3352.Invoke_O__O(arg_3353) } else { tmp79 = linked_3351.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3350, arg_3353) }; var tmp80 any = tmp79; var tmp81 any; var root_3359 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3359, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3361 lang.IFn; if






















































































































	linked_3360 == nil { ifn_3361 = lang.IFn_Cast(root_3359) } else { ifn_3361 = nil }; var arg_3362 any = A_arbace_j2g_dyn_A_const_437; var arg_3363 any = A_arbace_j2g_dyn_A_const_438; if linked_3360 == nil { tmp81 = ifn_3361.Invoke_O_O__O(arg_3362, arg_3363) } else { tmp81 = linked_3360.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3359, arg_3362, arg_3363) }; var tmp82 any = tmp81; var tmp83 any; var root_3364 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3364, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3366 lang.IFn; if






















































































































	linked_3365 == nil { ifn_3366 = lang.IFn_Cast(root_3364) } else { ifn_3366 = nil }; var arg_3367 any = A_arbace_j2g_dyn_A_const_439; var arg_3368 any = A_arbace_j2g_dyn_A_const_440; if linked_3365 == nil { tmp83 = ifn_3366.Invoke_O_O__O(arg_3367, arg_3368) } else { tmp83 = linked_3365.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3364, arg_3367, arg_3368) }; var tmp84 any = tmp83; var tmp85 any; var root_3369 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3369, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3371 lang.IFn; if






















































































































	linked_3370 == nil { ifn_3371 = lang.IFn_Cast(root_3369) } else { ifn_3371 = nil }; var arg_3372 any = A_arbace_j2g_dyn_A_const_441; var arg_3373 any = A_arbace_j2g_dyn_A_const_442; if linked_3370 == nil { tmp85 = ifn_3371.Invoke_O_O__O(arg_3372, arg_3373) } else { tmp85 = linked_3370.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3369, arg_3372, arg_3373) }; var tmp86 any = tmp85; var tmp87 any; var root_3374 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3374, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3376 lang.IFn; if






















































































































	linked_3375 == nil { ifn_3376 = lang.IFn_Cast(root_3374) } else { ifn_3376 = nil }; var arg_3377 any = A_arbace_j2g_dyn_A_const_443; var arg_3378 any = A_arbace_j2g_dyn_A_const_444; if linked_3375 == nil { tmp87 = ifn_3376.Invoke_O_O__O(arg_3377, arg_3378) } else { tmp87 = linked_3375.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3374, arg_3377, arg_3378) }; var tmp88 any = /*line :541:1*/tmp77.Invoke_O_O_O_O__O(tmp78, tmp80, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp82, tmp84, tmp86, tmp87), A_arbace_j2g_dyn_A_const_436); var tmp89 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp90 any = A_arbace_j2g_dyn_A_const_445; var tmp91 any; var root_3379 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3379, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3381 lang.IFn; if






































































































































	linked_3380 == nil { ifn_3381 = lang.IFn_Cast(root_3379) } else { ifn_3381 = nil }; var arg_3382 any; var root_3383 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3383, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3385 lang.IFn; if linked_3384 == nil { ifn_3385 = lang.IFn_Cast(root_3383) } else { ifn_3385 = nil }; var arg_3386 any = Lit_106; var arg_3387 any = Lit_107; if linked_3384 == nil { arg_3382 = ifn_3385.Invoke_O_O__O(arg_3386, arg_3387) } else { arg_3382 = linked_3384.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3383, arg_3386, arg_3387) }; if linked_3380 == nil { tmp91 = ifn_3381.Invoke_O__O(arg_3382) } else { tmp91 = linked_3380.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3379, arg_3382) }; var tmp92 any = tmp91; var tmp93 any; var root_3388 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3388, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3390 lang.IFn; if







































































































































	linked_3389 == nil { ifn_3390 = lang.IFn_Cast(root_3388) } else { ifn_3390 = nil }; var arg_3391 any; var tmp94 any; var root_3393 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3393, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3395 lang.IFn; if linked_3394 == nil { ifn_3395 = lang.IFn_Cast(root_3393) } else { ifn_3395 = nil }; var arg_3396 any = A_arbace_j2g_dyn_A_const_446; var arg_3397 any = A_arbace_j2g_dyn_A_const_447; if linked_3394 == nil { tmp94 = ifn_3395.Invoke_O_O__O(arg_3396, arg_3397) } else { tmp94 = linked_3394.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3393, arg_3396, arg_3397) }; var tmp95 any = tmp94; var tmp96 any; var root_3398 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3398, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3400 lang.IFn; if linked_3399 == nil { ifn_3400 = lang.IFn_Cast(root_3398) } else { ifn_3400 = nil }; var arg_3401 any = A_arbace_j2g_dyn_A_const_448; var arg_3402 any = A_arbace_j2g_dyn_A_const_449; if linked_3399 == nil { tmp96 = ifn_3400.Invoke_O_O__O(arg_3401, arg_3402) } else { tmp96 = linked_3399.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3398, arg_3401, arg_3402) }; arg_3391 = lang.Tuple_Create_O_O__IPersistentVector(tmp95, tmp96); var arg_3392 any = A_arbace_j2g_dyn_A_const_450; if linked_3389 == nil { tmp93 = ifn_3390.Invoke_O_O__O(arg_3391, arg_3392) } else { tmp93 = linked_3389.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3388, arg_3391, arg_3392) }; var tmp97 any = /*line :541:1*/tmp89.Invoke_O_O_O_O__O(tmp90, tmp92, tmp93, A_arbace_j2g_dyn_A_const_451); var tmp98 any; var root_3193 any = A_arbace_j2g_dyn_A_const_359.GetRawRoot__O(); var linked_3194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3193, A_arbace_j2g_dyn_fn_field_native_A_fn_class); var ifn_3195 lang.IFn; if












































































































































	linked_3194 == nil { ifn_3195 = lang.IFn_Cast(root_3193) } else { ifn_3195 = nil }; if linked_3194 == nil { tmp98 = ifn_3195.Invoke__O() } else { tmp98 = linked_3194.(*A_arbace_j2g_dyn_fn_field_native_A).Invoke_O__O(root_3193) }; var tmp99 any = tmp98; var tmp100 any; var root_3196 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_360.GetRawRoot__O(); var linked_3197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3196, A_arbace_j2g_dyn_aot_fn_fields_native_A_fn_class); var ifn_3198 lang.IFn; if













































































































































	linked_3197 == nil { ifn_3198 = lang.IFn_Cast(root_3196) } else { ifn_3198 = nil }; if linked_3197 == nil { tmp100 = ifn_3198.Invoke__O() } else { tmp100 = linked_3197.(*A_arbace_j2g_dyn_aot_fn_fields_native_A).Invoke_O__O(root_3196) }; var tmp101 any = tmp100; var tmp102 any; var root_3199 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_361.GetRawRoot__O(); var linked_3200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3199, A_arbace_j2g_dyn_method_impl_native_A_fn_class); var ifn_3201 lang.IFn; if














































































































































	linked_3200 == nil { ifn_3201 = lang.IFn_Cast(root_3199) } else { ifn_3201 = nil }; if linked_3200 == nil { tmp102 = ifn_3201.Invoke__O() } else { tmp102 = linked_3200.(*A_arbace_j2g_dyn_method_impl_native_A).Invoke_O__O(root_3199) }; var tmp103 any = tmp102; var tmp104 any = A_arbace_j2g_dyn_A_const_362; var tmp105 any = A_arbace_j2g_dyn_A_const_363; var tmp106 lang.IFn = /*line :541:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp107 any = A_arbace_j2g_dyn_A_const_452; var tmp108 any; var root_3403 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3403, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3405 lang.IFn; if



























































































































































	linked_3404 == nil { ifn_3405 = lang.IFn_Cast(root_3403) } else { ifn_3405 = nil }; var arg_3406 any; var root_3407 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3407, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3409 lang.IFn; if linked_3408 == nil { ifn_3409 = lang.IFn_Cast(root_3407) } else { ifn_3409 = nil }; var arg_3410 any = Lit_108; var arg_3411 any = Lit_109; if linked_3408 == nil { arg_3406 = ifn_3409.Invoke_O_O__O(arg_3410, arg_3411) } else { arg_3406 = linked_3408.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3407, arg_3410, arg_3411) }; if linked_3404 == nil { tmp108 = ifn_3405.Invoke_O__O(arg_3406) } else { tmp108 = linked_3404.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3403, arg_3406) }; var tmp109 any = tmp108; var tmp110 any; var root_3412 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3412, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3414 lang.IFn; if




























































































































































	linked_3413 == nil { ifn_3414 = lang.IFn_Cast(root_3412) } else { ifn_3414 = nil }; var arg_3415 any = A_arbace_j2g_dyn_A_const_454; var arg_3416 any = A_arbace_j2g_dyn_A_const_455; if linked_3413 == nil { tmp110 = ifn_3414.Invoke_O_O__O(arg_3415, arg_3416) } else { tmp110 = linked_3413.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3412, arg_3415, arg_3416) }; var tmp111 any = tmp110; var tmp112 any; var root_3417 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3417, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3419 lang.IFn; if




























































































































































	linked_3418 == nil { ifn_3419 = lang.IFn_Cast(root_3417) } else { ifn_3419 = nil }; var arg_3420 any = A_arbace_j2g_dyn_A_const_456; var arg_3421 any = A_arbace_j2g_dyn_A_const_457; if linked_3418 == nil { tmp112 = ifn_3419.Invoke_O_O__O(arg_3420, arg_3421) } else { tmp112 = linked_3418.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3417, arg_3420, arg_3421) }; var tmp113 any = /*line :541:1*/tmp106.Invoke_O_O_O_O__O(tmp107, tmp109, lang.Tuple_Create_O_O__IPersistentVector(tmp111, tmp112), A_arbace_j2g_dyn_A_const_453); var tmp114 any = A_arbace_j2g_dyn_A_const_364; var tmp115 any = A_arbace_j2g_dyn_A_const_365.GetRawRoot__O(); var tmp116 any = A_arbace_j2g_dyn_A_const_366; var tmp117 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp118 any = A_arbace_j2g_dyn_A_const_458; var tmp119 any; var root_3422 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3422, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3424 lang.IFn; if


















































































































































































	linked_3423 == nil { ifn_3424 = lang.IFn_Cast(root_3422) } else { ifn_3424 = nil }; var arg_3425 any; var root_3426 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3426, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3428 lang.IFn; if linked_3427 == nil { ifn_3428 = lang.IFn_Cast(root_3426) } else { ifn_3428 = nil }; var arg_3429 any = Lit_110; var arg_3430 any = Lit_111; if linked_3427 == nil { arg_3425 = ifn_3428.Invoke_O_O__O(arg_3429, arg_3430) } else { arg_3425 = linked_3427.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3426, arg_3429, arg_3430) }; if linked_3423 == nil { tmp119 = ifn_3424.Invoke_O__O(arg_3425) } else { tmp119 = linked_3423.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3422, arg_3425) }; var tmp120 any = tmp119; var tmp121 any; var root_3431 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3431, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3433 lang.IFn; if



















































































































































































	linked_3432 == nil { ifn_3433 = lang.IFn_Cast(root_3431) } else { ifn_3433 = nil }; var arg_3434 any; var tmp122 any; var root_3436 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3436, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3438 lang.IFn; if linked_3437 == nil { ifn_3438 = lang.IFn_Cast(root_3436) } else { ifn_3438 = nil }; var arg_3439 any = A_arbace_j2g_dyn_A_const_459; var arg_3440 any = A_arbace_j2g_dyn_A_const_460; if linked_3437 == nil { tmp122 = ifn_3438.Invoke_O_O__O(arg_3439, arg_3440) } else { tmp122 = linked_3437.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3436, arg_3439, arg_3440) }; var tmp123 any = tmp122; var tmp124 any; var root_3441 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3441, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3443 lang.IFn; if linked_3442 == nil { ifn_3443 = lang.IFn_Cast(root_3441) } else { ifn_3443 = nil }; var arg_3444 any = A_arbace_j2g_dyn_A_const_461; var arg_3445 any = A_arbace_j2g_dyn_A_const_462; if linked_3442 == nil { tmp124 = ifn_3443.Invoke_O_O__O(arg_3444, arg_3445) } else { tmp124 = linked_3442.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3441, arg_3444, arg_3445) }; arg_3434 = lang.Tuple_Create_O_O__IPersistentVector(tmp123, tmp124); var arg_3435 any = A_arbace_j2g_dyn_A_const_463; if linked_3432 == nil { tmp121 = ifn_3433.Invoke_O_O__O(arg_3434, arg_3435) } else { tmp121 = linked_3432.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3431, arg_3434, arg_3435) }; var tmp125 any = /*line :541:1*/tmp117.Invoke_O_O_O_O__O(tmp118, tmp120, tmp121, A_arbace_j2g_dyn_A_const_464); var tmp126 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp127 any = A_arbace_j2g_dyn_A_const_465; var tmp128 any; var root_3446 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3446, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3448 lang.IFn; if
























































































































































































	linked_3447 == nil { ifn_3448 = lang.IFn_Cast(root_3446) } else { ifn_3448 = nil }; var arg_3449 any; var root_3450 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3450, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3452 lang.IFn; if linked_3451 == nil { ifn_3452 = lang.IFn_Cast(root_3450) } else { ifn_3452 = nil }; var arg_3453 any = Lit_112; var arg_3454 any = Lit_113; if linked_3451 == nil { arg_3449 = ifn_3452.Invoke_O_O__O(arg_3453, arg_3454) } else { arg_3449 = linked_3451.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3450, arg_3453, arg_3454) }; if linked_3447 == nil { tmp128 = ifn_3448.Invoke_O__O(arg_3449) } else { tmp128 = linked_3447.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3446, arg_3449) }; var tmp129 any = tmp128; var tmp130 any; var root_3455 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3455, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3457 lang.IFn; if

























































































































































































	linked_3456 == nil { ifn_3457 = lang.IFn_Cast(root_3455) } else { ifn_3457 = nil }; var arg_3458 any; var tmp131 any; var root_3460 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3460, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3462 lang.IFn; if linked_3461 == nil { ifn_3462 = lang.IFn_Cast(root_3460) } else { ifn_3462 = nil }; var arg_3463 any = A_arbace_j2g_dyn_A_const_466; var arg_3464 any = A_arbace_j2g_dyn_A_const_467; if linked_3461 == nil { tmp131 = ifn_3462.Invoke_O_O__O(arg_3463, arg_3464) } else { tmp131 = linked_3461.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3460, arg_3463, arg_3464) }; var tmp132 any = tmp131; var tmp133 any; var root_3465 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3465, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3467 lang.IFn; if linked_3466 == nil { ifn_3467 = lang.IFn_Cast(root_3465) } else { ifn_3467 = nil }; var arg_3468 any = A_arbace_j2g_dyn_A_const_468; var arg_3469 any = A_arbace_j2g_dyn_A_const_469; if linked_3466 == nil { tmp133 = ifn_3467.Invoke_O_O__O(arg_3468, arg_3469) } else { tmp133 = linked_3466.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3465, arg_3468, arg_3469) }; arg_3458 = lang.Tuple_Create_O_O__IPersistentVector(tmp132, tmp133); var arg_3459 any = A_arbace_j2g_dyn_A_const_470; if linked_3456 == nil { tmp130 = ifn_3457.Invoke_O_O__O(arg_3458, arg_3459) } else { tmp130 = linked_3456.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3455, arg_3458, arg_3459) }; var tmp134 any = /*line :541:1*/tmp126.Invoke_O_O_O_O_O__O(tmp127, tmp129, tmp130, A_arbace_j2g_dyn_A_const_471, A_arbace_j2g_dyn_A_const_472); var tmp135 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp136 any = A_arbace_j2g_dyn_A_const_473; var tmp137 any; var root_3470 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3470, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3472 lang.IFn; if





























































































































































































	linked_3471 == nil { ifn_3472 = lang.IFn_Cast(root_3470) } else { ifn_3472 = nil }; var arg_3473 any; var root_3474 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3474, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3476 lang.IFn; if linked_3475 == nil { ifn_3476 = lang.IFn_Cast(root_3474) } else { ifn_3476 = nil }; var arg_3477 any = Lit_114; var arg_3478 any = Lit_115; if linked_3475 == nil { arg_3473 = ifn_3476.Invoke_O_O__O(arg_3477, arg_3478) } else { arg_3473 = linked_3475.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3474, arg_3477, arg_3478) }; if linked_3471 == nil { tmp137 = ifn_3472.Invoke_O__O(arg_3473) } else { tmp137 = linked_3471.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3470, arg_3473) }; var tmp138 any = tmp137; var tmp139 any; var root_3479 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3479, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3481 lang.IFn; if






























































































































































































	linked_3480 == nil { ifn_3481 = lang.IFn_Cast(root_3479) } else { ifn_3481 = nil }; var arg_3482 any = A_arbace_j2g_dyn_A_const_475; var arg_3483 any = A_arbace_j2g_dyn_A_const_476; if linked_3480 == nil { tmp139 = ifn_3481.Invoke_O_O__O(arg_3482, arg_3483) } else { tmp139 = linked_3480.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3479, arg_3482, arg_3483) }; var tmp140 any = tmp139; var tmp141 any; var root_3484 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3484, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3486 lang.IFn; if






























































































































































































	linked_3485 == nil { ifn_3486 = lang.IFn_Cast(root_3484) } else { ifn_3486 = nil }; var arg_3487 any = A_arbace_j2g_dyn_A_const_477; var arg_3488 any = A_arbace_j2g_dyn_A_const_478; if linked_3485 == nil { tmp141 = ifn_3486.Invoke_O_O__O(arg_3487, arg_3488) } else { tmp141 = linked_3485.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3484, arg_3487, arg_3488) }; var tmp142 any = tmp141; var tmp143 any; var root_3489 any = /*line :541:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3489, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3491 lang.IFn; if






























































































































































































	linked_3490 == nil { ifn_3491 = lang.IFn_Cast(root_3489) } else { ifn_3491 = nil }; var arg_3492 any = A_arbace_j2g_dyn_A_const_479; var arg_3493 any = A_arbace_j2g_dyn_A_const_480; if linked_3490 == nil { tmp143 = ifn_3491.Invoke_O_O__O(arg_3492, arg_3493) } else { tmp143 = linked_3490.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3489, arg_3492, arg_3493) }; return /*line :541:1*/ lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28, tmp29, tmp43, tmp57, tmp67, tmp76, tmp88, tmp97, tmp99, tmp101, tmp103, tmp104, tmp105, tmp113, tmp114, tmp115, tmp116, tmp125, tmp134, tmp135.Invoke_O_O_O_O__O(tmp136, tmp138, lang.Tuple_Create_O_O_O__IPersistentVector(tmp140, tmp142, tmp143), A_arbace_j2g_dyn_A_const_474), A_arbace_j2g_dyn_A_const_367)) }







































































































































































































func A_arbace_j2g_dyn_proxy_forms_A_New() *A_arbace_j2g_dyn_proxy_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_forms_A{}; t.Ctor(); return t }
//line :741:1
func (t *A_arbace_j2g_dyn_proxy_forms_A) Ctor() {}
//line :741:1
func (t *A_arbace_j2g_dyn_proxy_forms_A) Invoke_O_O__O(self, T__0_ any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_483; var tmp3 any; var root_3502 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3502, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3504 lang.IFn; if






	linked_3503 == nil { ifn_3504 = lang.IFn_Cast(root_3502) } else { ifn_3504 = nil }; var arg_3505 any; var root_3506 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3506, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3508 lang.IFn; if linked_3507 == nil { ifn_3508 = lang.IFn_Cast(root_3506) } else { ifn_3508 = nil }; var arg_3509 any = Lit_122; var arg_3510 any = Lit_123; if linked_3507 == nil { arg_3505 = ifn_3508.Invoke_O_O__O(arg_3509, arg_3510) } else { arg_3505 = linked_3507.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3506, arg_3509, arg_3510) }; if linked_3503 == nil { tmp3 = ifn_3504.Invoke_O__O(arg_3505) } else { tmp3 = linked_3503.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3502, arg_3505) }; var tmp4 any = tmp3; var tmp5 any; var root_3511 any = /*line :741:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3511, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3513 lang.IFn; if









	linked_3512 == nil { ifn_3513 = lang.IFn_Cast(root_3511) } else { ifn_3513 = nil }; var arg_3514 any = A_arbace_j2g_dyn_A_const_485; var arg_3515 any = A_arbace_j2g_dyn_A_const_486; if linked_3512 == nil { tmp5 = ifn_3513.Invoke_O_O__O(arg_3514, arg_3515) } else { tmp5 = linked_3512.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3511, arg_3514, arg_3515) }; var tmp6 any = tmp5; var tmp7 any; var root_3516 any = /*line :741:1*/A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3516, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3518 lang.IFn; if









	linked_3517 == nil { ifn_3518 = lang.IFn_Cast(root_3516) } else { ifn_3518 = nil }; var arg_3519 any = A_arbace_j2g_dyn_A_const_487; var arg_3520 any = A_arbace_j2g_dyn_A_const_488; if linked_3517 == nil { tmp7 = ifn_3518.Invoke_O_O__O(arg_3519, arg_3520) } else { tmp7 = linked_3517.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3516, arg_3519, arg_3520) }; var tmp8 any = /*line :741:1*/tmp1.Invoke_O_O_O_O_O__O(tmp2, tmp4, Lit_124, lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7), A_arbace_j2g_dyn_A_const_484); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_489; var tmp11 any; var root_3521 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3521, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3523 lang.IFn; if


















	linked_3522 == nil { ifn_3523 = lang.IFn_Cast(root_3521) } else { ifn_3523 = nil }; var arg_3524 any; var root_3525 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3525, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3527 lang.IFn; if linked_3526 == nil { ifn_3527 = lang.IFn_Cast(root_3525) } else { ifn_3527 = nil }; var arg_3528 any = Lit_125; var arg_3529 any = Lit_126; if linked_3526 == nil { arg_3524 = ifn_3527.Invoke_O_O__O(arg_3528, arg_3529) } else { arg_3524 = linked_3526.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3525, arg_3528, arg_3529) }; if linked_3522 == nil { tmp11 = ifn_3523.Invoke_O__O(arg_3524) } else { tmp11 = linked_3522.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3521, arg_3524) }; var tmp12 any = tmp11; var tmp13 any; var root_3530 any = /*line :741:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3530, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3532 lang.IFn; if



















	linked_3531 == nil { ifn_3532 = lang.IFn_Cast(root_3530) } else { ifn_3532 = nil }; var arg_3533 any; var tmp14 any; var root_3535 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3535, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3537 lang.IFn; if linked_3536 == nil { ifn_3537 = lang.IFn_Cast(root_3535) } else { ifn_3537 = nil }; var arg_3538 any = A_arbace_j2g_dyn_A_const_490; var arg_3539 any = A_arbace_j2g_dyn_A_const_491; if linked_3536 == nil { tmp14 = ifn_3537.Invoke_O_O__O(arg_3538, arg_3539) } else { tmp14 = linked_3536.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3535, arg_3538, arg_3539) }; var tmp15 any = tmp14; var tmp16 any; var root_3540 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3540, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3542 lang.IFn; if linked_3541 == nil { ifn_3542 = lang.IFn_Cast(root_3540) } else { ifn_3542 = nil }; var arg_3543 any = A_arbace_j2g_dyn_A_const_492; var arg_3544 any = A_arbace_j2g_dyn_A_const_493; if linked_3541 == nil { tmp16 = ifn_3542.Invoke_O_O__O(arg_3543, arg_3544) } else { tmp16 = linked_3541.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3540, arg_3543, arg_3544) }; var tmp17 any = tmp16; var tmp18 any; var root_3545 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3545, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3547 lang.IFn; if linked_3546 == nil { ifn_3547 = lang.IFn_Cast(root_3545) } else { ifn_3547 = nil }; var arg_3548 any = A_arbace_j2g_dyn_A_const_494; var arg_3549 any = A_arbace_j2g_dyn_A_const_495; if linked_3546 == nil { tmp18 = ifn_3547.Invoke_O_O__O(arg_3548, arg_3549) } else { tmp18 = linked_3546.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3545, arg_3548, arg_3549) }; arg_3533 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp15, tmp17, tmp18); var arg_3534 any = A_arbace_j2g_dyn_A_const_496; if linked_3531 == nil { tmp13 = ifn_3532.Invoke_O_O__O(arg_3533, arg_3534) } else { tmp13 = linked_3531.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3530, arg_3533, arg_3534) }; var tmp19 any = tmp13; var tmp20 lang.IFn = /*line :741:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyn_A_const_497; var tmp22 any = A_arbace_j2g_dyn_A_const_504; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp24 any; var root_3550 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3550, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3552 lang.IFn; if





















	linked_3551 == nil { ifn_3552 = lang.IFn_Cast(root_3550) } else { ifn_3552 = nil }; var arg_3553 any; var root_3554 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3554, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3556 lang.IFn; if linked_3555 == nil { ifn_3556 = lang.IFn_Cast(root_3554) } else { ifn_3556 = nil }; var arg_3557 any = Lit_95; var arg_3558 any = Lit_96; if linked_3555 == nil { arg_3553 = ifn_3556.Invoke_O_O__O(arg_3557, arg_3558) } else { arg_3553 = linked_3555.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3554, arg_3557, arg_3558) }; if linked_3551 == nil { tmp24 = ifn_3552.Invoke_O__O(arg_3553) } else { tmp24 = linked_3551.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3550, arg_3553) }; var tmp25 any = /*line :741:1*/tmp9.Invoke_O_O_O_O__O(tmp10, tmp12, tmp19, tmp20.Invoke_O_O_O_O_O_O_O_O__O(tmp21, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp22, tmp23.Invoke_O_O_O_O__O(tmp24, A_arbace_j2g_dyn_A_const_509, A_arbace_j2g_dyn_A_const_510, nil), A_arbace_j2g_dyn_A_const_505, A_arbace_j2g_dyn_A_const_506, A_arbace_j2g_dyn_A_const_507, A_arbace_j2g_dyn_A_const_508), A_arbace_j2g_dyn_A_const_498, A_arbace_j2g_dyn_A_const_499, A_arbace_j2g_dyn_A_const_500, A_arbace_j2g_dyn_A_const_501, A_arbace_j2g_dyn_A_const_502, A_arbace_j2g_dyn_A_const_503)); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_511; var tmp28 any; var root_3559 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3559, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3561 lang.IFn; if































	linked_3560 == nil { ifn_3561 = lang.IFn_Cast(root_3559) } else { ifn_3561 = nil }; var arg_3562 any; var root_3563 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3563, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3565 lang.IFn; if linked_3564 == nil { ifn_3565 = lang.IFn_Cast(root_3563) } else { ifn_3565 = nil }; var arg_3566 any = Lit_127; var arg_3567 any = Lit_128; if linked_3564 == nil { arg_3562 = ifn_3565.Invoke_O_O__O(arg_3566, arg_3567) } else { arg_3562 = linked_3564.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3563, arg_3566, arg_3567) }; if linked_3560 == nil { tmp28 = ifn_3561.Invoke_O__O(arg_3562) } else { tmp28 = linked_3560.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3559, arg_3562) }; var tmp29 any = tmp28; var tmp30 any; var root_3568 any = /*line :741:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3568, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3570 lang.IFn; if
































	linked_3569 == nil { ifn_3570 = lang.IFn_Cast(root_3568) } else { ifn_3570 = nil }; var arg_3571 any = lang.PersistentVector_EMPTY.Ref(); var arg_3572 any = A_arbace_j2g_dyn_A_const_512; if linked_3569 == nil { tmp30 = ifn_3570.Invoke_O_O__O(arg_3571, arg_3572) } else { tmp30 = linked_3569.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3568, arg_3571, arg_3572) }; var tmp31 any = /*line :741:1*/tmp26.Invoke_O_O_O_O__O(tmp27, tmp29, tmp30, A_arbace_j2g_dyn_A_const_513); var tmp32 any; var tmp33 any; var root_3494 any = A_arbace_j2g_dyn_A_const_33.GetRawRoot__O(); var linked_3495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3494, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_3496 lang.IFn; if



































	linked_3495 == nil { ifn_3496 = lang.IFn_Cast(root_3494) } else { ifn_3496 = nil }; var arg_3497 any; var root_3498 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3498, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3500 lang.IFn; if linked_3499 == nil { ifn_3500 = lang.IFn_Cast(root_3498) } else { ifn_3500 = nil }; var arg_3501 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); if linked_3499 == nil { arg_3497 = ifn_3500.Invoke_O__O(arg_3501) } else { arg_3497 = linked_3499.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3498, arg_3501) }; if linked_3495 == nil { tmp33 = ifn_3496.Invoke_O__O(arg_3497) } else { tmp33 = linked_3495.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_3494, arg_3497) }; if jrt.J2g_Truth(tmp33) {
		var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_dyn_A_const_514; var tmp36 any = A_arbace_j2g_dyn_A_const_515; var tmp37 any; var root_3573 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3573, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3575 lang.IFn
		if linked_3574 == nil { ifn_3575 = lang.IFn_Cast(root_3573) } else { ifn_3575 = nil }; var arg_3576 any = lang.PersistentVector_EMPTY.Ref(); var arg_3577 any = A_arbace_j2g_dyn_A_const_516; if linked_3574 == nil { tmp37 = ifn_3575.Invoke_O_O__O(arg_3576, arg_3577) } else { tmp37 = linked_3574.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3573, arg_3576, arg_3577) }
//line :778:1
		var tmp38 any = tmp37; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_dyn_A_const_517; var tmp41 any = A_arbace_j2g_dyn_A_const_518; var tmp42 any; var root_3578 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_3579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3578, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3580 lang.IFn


		if linked_3579 == nil { ifn_3580 = lang.IFn_Cast(root_3578) } else { ifn_3580 = nil }; var arg_3581 any = A_arbace_j2g_dyn_A_const_76; var arg_3582 any; var root_3584 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3584, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3586 lang.IFn; if linked_3585 == nil { ifn_3586 = lang.IFn_Cast(root_3584) } else { ifn_3586 = nil }; var arg_3587 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); if linked_3585 == nil { arg_3582 = ifn_3586.Invoke_O__O(arg_3587) } else { arg_3582 = linked_3585.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3584, arg_3587) }; var arg_3583 any; var tmp43 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp44 any; var root_3588 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_3589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3588, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_3590 lang.IFn
		if linked_3589 == nil { ifn_3590 = lang.IFn_Cast(root_3588) } else { ifn_3590 = nil }; var arg_3591 any; var root_3593 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_3594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3593, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3595 lang.IFn; if linked_3594 == nil { ifn_3595 = lang.IFn_Cast(root_3593) } else { ifn_3595 = nil }; var arg_3596 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); if linked_3594 == nil { arg_3591 = ifn_3595.Invoke_O__O(arg_3596) } else { arg_3591 = linked_3594.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3593, arg_3596) }; var arg_3592 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(), lang.RT_IntCast_J__I_NoInit(2)); if linked_3589 == nil { tmp44 = ifn_3590.Invoke_O_O__O(arg_3591, arg_3592) } else { tmp44 = linked_3589.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_3588, arg_3591, arg_3592) }; arg_3583 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp43, jrt.RefArrayOf(jrt.Object_class, nil, tmp44)).Ref()
//line :781:1
		if linked_3579 == nil { tmp42 = ifn_3580.Invoke_O_O_O__O(arg_3581, arg_3582, arg_3583) } else { tmp42 = linked_3579.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3578, arg_3581, arg_3582, arg_3583) }
//line :778:1
		tmp32 = tmp34.Invoke_O_O_O_O_O_O__O(tmp35, tmp36, Lit_129, tmp38, tmp39.Invoke_O_O_O__O(tmp40, tmp41, tmp42), jrt.Boolean_TRUE.Ref()) } else {
//line :777:1
			tmp32 = A_arbace_j2g_dyn_A_const_481 }; var tmp45 any = tmp32; var tmp46 any = A_arbace_j2g_dyn_A_const_482; var tmp47 lang.IFn = /*line :741:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp48 any = A_arbace_j2g_dyn_A_const_519; var tmp49 any = A_arbace_j2g_dyn_A_const_520; var tmp50 any; var root_3730 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3730, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3732 lang.IFn; if














































	linked_3731 == nil { ifn_3732 = lang.IFn_Cast(root_3730) } else { ifn_3732 = nil }; var arg_3733 any = A_arbace_j2g_dyn_A_const_529; var arg_3734 any = A_arbace_j2g_dyn_A_const_530; if linked_3731 == nil { tmp50 = ifn_3732.Invoke_O_O__O(arg_3733, arg_3734) } else { tmp50 = linked_3731.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3730, arg_3733, arg_3734) }; var tmp51 any = /*line :741:1*/lang.Tuple_Create_O__IPersistentVector(tmp50); var tmp52 any = A_arbace_j2g_dyn_A_const_521; var tmp53 any = A_arbace_j2g_dyn_A_const_522; var tmp54 any; var root_3597 any = A_arbace_j2g_dyn_A_const_102.GetRawRoot__O(); var linked_3598 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3597, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3599 lang.IFn; if















































	linked_3598 == nil { ifn_3599 = lang.IFn_Cast(root_3597) } else { ifn_3599 = nil }; var arg_3600 any = A_arbace_j2g_dyn_A_const_82.GetRawRoot__O(); var arg_3601 any = A_arbace_j2g_dyn_A_const_523; var arg_3602 any = A_arbace_j2g_dyn_A_const_524; var arg_3603 any; var iter__1927001039__auto____2 any; var fnbody__3725 any = A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A_New(); var tmp55 *jrt.Class; var fncls__3724 *jrt.Class = A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A_fn_class; if
	fncls__3724 == nil { var fncls__3724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, nil); A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A_fn_class = fncls__3724d; tmp55 = fncls__3724d } else { tmp55 = fncls__3724 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3725, tmp55, nil); var tmp56 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp57 any; var root_3726 any = A_arbace_j2g_dyn_A_const_527.GetRawRoot__O(); var linked_3727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3726, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3728 lang.IFn; if linked_3727 == nil { ifn_3728 = lang.IFn_Cast(root_3726) } else { ifn_3728 = nil }; var arg_3729 any = T__0_; if linked_3727 == nil { tmp57 = ifn_3728.Invoke_O__O(arg_3729) } else { tmp57 = linked_3727.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3726, arg_3729) }; arg_3603 = tmp56.Invoke_O__O(tmp57); if /*line :789:1*/ linked_3598 == nil { tmp54 = ifn_3599.Invoke_O_O_O_O__O(arg_3600, arg_3601, arg_3602, arg_3603) } else { tmp54 = linked_3598.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3597, arg_3600, arg_3601, arg_3602, arg_3603) }; var tmp58 any = /*line :741:1*/tmp47.Invoke_O_O_O_O_O_O_O_O__O(tmp48, tmp49, Lit_130, tmp51, tmp52, tmp53, tmp54, A_arbace_j2g_dyn_A_const_528); var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp60 any = A_arbace_j2g_dyn_A_const_531; var tmp61 any; var root_3735 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3735, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3737 lang.IFn; if





















































	linked_3736 == nil { ifn_3737 = lang.IFn_Cast(root_3735) } else { ifn_3737 = nil }; var arg_3738 any; var root_3739 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3739, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3741 lang.IFn; if linked_3740 == nil { ifn_3741 = lang.IFn_Cast(root_3739) } else { ifn_3741 = nil }; var arg_3742 any = Lit_132; var arg_3743 any = Lit_133; if linked_3740 == nil { arg_3738 = ifn_3741.Invoke_O_O__O(arg_3742, arg_3743) } else { arg_3738 = linked_3740.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3739, arg_3742, arg_3743) }; if linked_3736 == nil { tmp61 = ifn_3737.Invoke_O__O(arg_3738) } else { tmp61 = linked_3736.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3735, arg_3738) }; var tmp62 any = tmp61; var tmp63 any; var root_3744 any = /*line :741:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3744, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3746 lang.IFn; if






















































	linked_3745 == nil { ifn_3746 = lang.IFn_Cast(root_3744) } else { ifn_3746 = nil }; var arg_3747 any; var tmp64 any; var root_3749 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3749, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3751 lang.IFn; if linked_3750 == nil { ifn_3751 = lang.IFn_Cast(root_3749) } else { ifn_3751 = nil }; var arg_3752 any = A_arbace_j2g_dyn_A_const_532; var arg_3753 any = A_arbace_j2g_dyn_A_const_533; if linked_3750 == nil { tmp64 = ifn_3751.Invoke_O_O__O(arg_3752, arg_3753) } else { tmp64 = linked_3750.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3749, arg_3752, arg_3753) }; var tmp65 any = tmp64; var tmp66 any; var root_3754 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3754, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3756 lang.IFn; if linked_3755 == nil { ifn_3756 = lang.IFn_Cast(root_3754) } else { ifn_3756 = nil }; var arg_3757 any = A_arbace_j2g_dyn_A_const_534; var arg_3758 any = A_arbace_j2g_dyn_A_const_535; if linked_3755 == nil { tmp66 = ifn_3756.Invoke_O_O__O(arg_3757, arg_3758) } else { tmp66 = linked_3755.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3754, arg_3757, arg_3758) }; var tmp67 any = tmp66; var tmp68 any; var root_3759 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3759, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3761 lang.IFn; if linked_3760 == nil { ifn_3761 = lang.IFn_Cast(root_3759) } else { ifn_3761 = nil }; var arg_3762 any = A_arbace_j2g_dyn_A_const_536; var arg_3763 any = A_arbace_j2g_dyn_A_const_537; if linked_3760 == nil { tmp68 = ifn_3761.Invoke_O_O__O(arg_3762, arg_3763) } else { tmp68 = linked_3760.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3759, arg_3762, arg_3763) }; arg_3747 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp65, tmp67, tmp68); var arg_3748 any = A_arbace_j2g_dyn_A_const_538; if linked_3745 == nil { tmp63 = ifn_3746.Invoke_O_O__O(arg_3747, arg_3748) } else { tmp63 = linked_3745.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3744, arg_3747, arg_3748) }; var tmp69 any = tmp63; var tmp70 lang.IFn = /*line :741:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp71 any = A_arbace_j2g_dyn_A_const_540; var tmp72 any = A_arbace_j2g_dyn_A_const_541; var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp74 any = A_arbace_j2g_dyn_A_const_542; var tmp75 any = A_arbace_j2g_dyn_A_const_547; var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp77 any; var root_3764 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3764, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3766 lang.IFn; if

























































	linked_3765 == nil { ifn_3766 = lang.IFn_Cast(root_3764) } else { ifn_3766 = nil }; var arg_3767 any; var root_3768 any = A_arbace_j2g_dyn_A_const_291.GetRawRoot__O(); var linked_3769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3768, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3770 lang.IFn; if linked_3769 == nil { ifn_3770 = lang.IFn_Cast(root_3768) } else { ifn_3770 = nil }; var arg_3771 any = Lit_95; var arg_3772 any = Lit_96; if linked_3769 == nil { arg_3767 = ifn_3770.Invoke_O_O__O(arg_3771, arg_3772) } else { arg_3767 = linked_3769.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3768, arg_3771, arg_3772) }; if linked_3765 == nil { tmp77 = ifn_3766.Invoke_O__O(arg_3767) } else { tmp77 = linked_3765.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3764, arg_3767) }; return /*line :741:1*/ lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp25, tmp31, tmp45, tmp46, tmp58, tmp59.Invoke_O_O_O_O_O__O(tmp60, tmp62, tmp69, tmp70.Invoke_O_O_O__O(tmp71, tmp72, tmp73.Invoke_O_O_O_O_O_O__O(tmp74, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp75, tmp76.Invoke_O_O_O_O__O(tmp77, A_arbace_j2g_dyn_A_const_552, A_arbace_j2g_dyn_A_const_553, A_arbace_j2g_dyn_A_const_554), A_arbace_j2g_dyn_A_const_548, A_arbace_j2g_dyn_A_const_549, A_arbace_j2g_dyn_A_const_550, A_arbace_j2g_dyn_A_const_551), A_arbace_j2g_dyn_A_const_543, A_arbace_j2g_dyn_A_const_544, A_arbace_j2g_dyn_A_const_545, A_arbace_j2g_dyn_A_const_546)), A_arbace_j2g_dyn_A_const_539))) }
















































func A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A_New() *A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A{}; t.Ctor(); return t }
//line :790:1
func (t *A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A) Ctor() {}
//line :790:1
func (t *A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A) Invoke_O_O__O(self, s__711000410__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3723 any = A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A_New_O_O(s__711000410__1, self); var tmp2 *jrt.Class; var fncls__3722 *jrt.Class = A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A_fn_class; if fncls__3722 == nil { var fncls__3722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, fnbody__3723); A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A_fn_class = fncls__3722d; tmp2 = fncls__3722d } else { tmp2 = fncls__3722 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3723, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :790:1
func A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A{}; t.Ctor_O_O(p0, p1); return t }
//line :790:1
func (t *A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A) Ctor_O_O(c__s__711000410, c__iter__711000409 any) { t.F_s__711000410 = c__s__711000410; t.F_iter__711000409 = c__iter__711000409 }
//line :790:1
func (t *A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A) Invoke_O__O(self any) any { { var s__711000410__1 any; var t_ any = t.F_s__711000410; t.F_s__711000410 = nil; s__711000410__1 = t_; for { var temp__1927000414__auto____2 any; var root_3604 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3604, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3606 lang.IFn; if linked_3605 == nil { ifn_3606 = lang.IFn_Cast(root_3604) } else { ifn_3606 = nil }; var arg_3607 any = s__711000410__1; if linked_3605 == nil { temp__1927000414__auto____2 = ifn_3606.Invoke_O__O(arg_3607) } else { temp__1927000414__auto____2 = linked_3605.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3604, arg_3607) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000410__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3608 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3608, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3610 lang.IFn; if linked_3609 == nil { ifn_3610 = lang.IFn_Cast(root_3608) } else { ifn_3610 = nil }; var arg_3611 any = s__711000410__3; if linked_3609 == nil { tmp1 = ifn_3610.Invoke_O__O(arg_3611) } else { tmp1 = linked_3609.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3608, arg_3611) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3612 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3612, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3614 lang.IFn; if linked_3613 == nil { ifn_3614 = lang.IFn_Cast(root_3612) } else { ifn_3614 = nil }; var arg_3615 any = s__711000410__3; if linked_3613 == nil { c__1927001037__auto____4 = ifn_3614.Invoke_O__O(arg_3615) } else { c__1927001037__auto____4 = linked_3613.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3612, arg_3615) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000412__6 any; var root_3616 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3616, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3618 lang.IFn; if linked_3617 == nil { ifn_3618 = lang.IFn_Cast(root_3616) } else { ifn_3618 = nil }; var arg_3619 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3617 == nil { b__711000412__6 = ifn_3618.Invoke_O__O(arg_3619) } else { b__711000412__6 = linked_3617.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3616, arg_3619) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3656 any = A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A_New_O_I_O(b__711000412__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3655 *jrt.Class = A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A_fn_class; if fncls__3655 == nil { var fncls__3655d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__3656); A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A_fn_class = fncls__3655d; tmp3 = fncls__3655d } else { tmp3 = fncls__3655 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3656, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3657 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3657, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3659 lang.IFn; if linked_3658 == nil { ifn_3659 = lang.IFn_Cast(root_3657) } else { ifn_3659 = nil }; var arg_3660 any; var root_3662 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3662, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3664 lang.IFn; if linked_3663 == nil { ifn_3664 = lang.IFn_Cast(root_3662) } else { ifn_3664 = nil }; var arg_3665 any = b__711000412__6; if linked_3663 == nil { arg_3660 = ifn_3664.Invoke_O__O(arg_3665) } else { arg_3660 = linked_3663.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3662, arg_3665) }; var arg_3661 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000409); var tmp5 any; var root_3666 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3666, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3668 lang.IFn; if linked_3667 == nil { ifn_3668 = lang.IFn_Cast(root_3666) } else { ifn_3668 = nil }; var arg_3669 any = s__711000410__3; if linked_3667 == nil { tmp5 = ifn_3668.Invoke_O__O(arg_3669) } else { tmp5 = linked_3667.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3666, arg_3669) }; arg_3661 = tmp4.Invoke_O__O(tmp5); if linked_3658 == nil { return ifn_3659.Invoke_O_O__O(arg_3660, arg_3661) } else { return linked_3658.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3657, arg_3660, arg_3661) } } else { var root_3670 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3670, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3672 lang.IFn; if linked_3671 == nil { ifn_3672 = lang.IFn_Cast(root_3670) } else { ifn_3672 = nil }; var arg_3673 any; var root_3675 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3675, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3677 lang.IFn; if linked_3676 == nil { ifn_3677 = lang.IFn_Cast(root_3675) } else { ifn_3677 = nil }; var arg_3678 any = b__711000412__6; if linked_3676 == nil { arg_3673 = ifn_3677.Invoke_O__O(arg_3678) } else { arg_3673 = linked_3676.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3675, arg_3678) }; var arg_3674 any; if linked_3671 == nil { return ifn_3672.Invoke_O_O__O(arg_3673, arg_3674) } else { return linked_3671.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3670, arg_3673, arg_3674) } } } else { var p__4 any; var root_3679 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3679, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3681 lang.IFn; if linked_3680 == nil { ifn_3681 = lang.IFn_Cast(root_3679) } else { ifn_3681 = nil }; var arg_3682 any = s__711000410__3; if linked_3680 == nil { p__4 = ifn_3681.Invoke_O__O(arg_3682) } else { p__4 = linked_3680.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3679, arg_3682) }; var root_3683 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3683, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3685 lang.IFn; if linked_3684 == nil { ifn_3685 = lang.IFn_Cast(root_3683) } else { ifn_3685 = nil }; var arg_3686 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_525; var tmp8 any; var root_3688 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_3689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3688, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3690 lang.IFn
														if linked_3689 == nil { ifn_3690 = lang.IFn_Cast(root_3688) } else { ifn_3690 = nil }; var arg_3691 any = A_arbace_j2g_dyn_A_const_76; var arg_3692 any = p__4; var arg_3693 any = Lit_25; if linked_3689 == nil { tmp8 = ifn_3690.Invoke_O_O_O__O(arg_3691, arg_3692, arg_3693) } else { tmp8 = linked_3689.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3688, arg_3691, arg_3692, arg_3693) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_526; var tmp12 any; var root_3694 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3694, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3696 lang.IFn
														if linked_3695 == nil { ifn_3696 = lang.IFn_Cast(root_3694) } else { ifn_3696 = nil }; var arg_3697 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_136, nil); var tmp14 any; var root_3698 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_3699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3698, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3700 lang.IFn; if linked_3699 == nil { ifn_3700 = lang.IFn_Cast(root_3698) } else { ifn_3700 = nil }; var arg_3701 any = p__4; if linked_3699 == nil { tmp14 = ifn_3700.Invoke_O__O(arg_3701) } else { tmp14 = linked_3699.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3698, arg_3701) }; arg_3697 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3695 == nil { tmp12 = ifn_3696.Invoke_O__O(arg_3697) } else { tmp12 = linked_3695.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3694, arg_3697) }
//line :791:1
	var tmp15 any = tmp12; var tmp16 any; var root_3702 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3702, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3704 lang.IFn
	if linked_3703 == nil { ifn_3704 = lang.IFn_Cast(root_3702) } else { ifn_3704 = nil }; var arg_3705 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil); var tmp18 any; var root_3706 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_3707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3706, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3708 lang.IFn; if linked_3707 == nil { ifn_3708 = lang.IFn_Cast(root_3706) } else { ifn_3708 = nil }; var arg_3709 any = p__4; if linked_3707 == nil { tmp18 = ifn_3708.Invoke_O__O(arg_3709) } else { tmp18 = linked_3707.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3706, arg_3709) }; arg_3705 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3703 == nil { tmp16 = ifn_3704.Invoke_O__O(arg_3705) } else { tmp16 = linked_3703.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3702, arg_3705) }
//line :791:1
	var tmp19 any = tmp16; var tmp20 any; var root_3710 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3710, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3712 lang.IFn

	if linked_3711 == nil { ifn_3712 = lang.IFn_Cast(root_3710) } else { ifn_3712 = nil }; var arg_3713 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_137, nil); var tmp22 any; var root_3714 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_3715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3714, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3716 lang.IFn; if linked_3715 == nil { ifn_3716 = lang.IFn_Cast(root_3714) } else { ifn_3716 = nil }; var arg_3717 any = p__4; if linked_3715 == nil { tmp22 = ifn_3716.Invoke_O__O(arg_3717) } else { tmp22 = linked_3715.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3714, arg_3717) }; arg_3713 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref(); if linked_3711 == nil { tmp20 = ifn_3712.Invoke_O__O(arg_3713) } else { tmp20 = linked_3711.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3710, arg_3713) }
//line :791:1
	arg_3686 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp15, tmp19, tmp20))
//line :790:1
	var arg_3687 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000409); var tmp24 any; var root_3718 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_3719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3718, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3720 lang.IFn; if linked_3719 == nil { ifn_3720 = lang.IFn_Cast(root_3718) } else { ifn_3720 = nil }; var arg_3721 any = s__711000410__3; if linked_3719 == nil { tmp24 = ifn_3720.Invoke_O__O(arg_3721) } else { tmp24 = linked_3719.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3718, arg_3721) }; arg_3687 = tmp23.Invoke_O__O(tmp24); if linked_3684 == nil { return ifn_3685.Invoke_O_O__O(arg_3686, arg_3687) } else { return linked_3684.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3683, arg_3686, arg_3687) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :790:1
func A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :790:1
func (t *A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A) Ctor_O_I_O(c__b__711000412 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000412 = c__b__711000412; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :790:1
func (t *A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A) Invoke_O__O(self any) any { { var i__711000411__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000411__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000411__1)); var root_3620 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3620, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3622 lang.IFn; if linked_3621 == nil { ifn_3622 = lang.IFn_Cast(root_3620) } else { ifn_3622 = nil }; var arg_3623 any = t.F_b__711000412; var arg_3624 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_525; var tmp4 any; var root_3625 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_3626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3625, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3627 lang.IFn
																if linked_3626 == nil { ifn_3627 = lang.IFn_Cast(root_3625) } else { ifn_3627 = nil }; var arg_3628 any = A_arbace_j2g_dyn_A_const_76; var arg_3629 any = p__2; var arg_3630 any = Lit_25; if linked_3626 == nil { tmp4 = ifn_3627.Invoke_O_O_O__O(arg_3628, arg_3629, arg_3630) } else { tmp4 = linked_3626.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3625, arg_3628, arg_3629, arg_3630) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_526; var tmp8 any; var root_3631 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3631, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3633 lang.IFn
																if linked_3632 == nil { ifn_3633 = lang.IFn_Cast(root_3631) } else { ifn_3633 = nil }; var arg_3634 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_136, nil); var tmp10 any; var root_3635 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_3636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3635, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3637 lang.IFn; if linked_3636 == nil { ifn_3637 = lang.IFn_Cast(root_3635) } else { ifn_3637 = nil }; var arg_3638 any = p__2; if linked_3636 == nil { tmp10 = ifn_3637.Invoke_O__O(arg_3638) } else { tmp10 = linked_3636.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3635, arg_3638) }; arg_3634 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3632 == nil { tmp8 = ifn_3633.Invoke_O__O(arg_3634) } else { tmp8 = linked_3632.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3631, arg_3634) }
//line :791:1
	var tmp11 any = tmp8; var tmp12 any; var root_3639 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3639, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3641 lang.IFn
	if linked_3640 == nil { ifn_3641 = lang.IFn_Cast(root_3639) } else { ifn_3641 = nil }; var arg_3642 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_31, nil); var tmp14 any; var root_3643 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_3644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3643, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3645 lang.IFn; if linked_3644 == nil { ifn_3645 = lang.IFn_Cast(root_3643) } else { ifn_3645 = nil }; var arg_3646 any = p__2; if linked_3644 == nil { tmp14 = ifn_3645.Invoke_O__O(arg_3646) } else { tmp14 = linked_3644.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3643, arg_3646) }; arg_3642 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3640 == nil { tmp12 = ifn_3641.Invoke_O__O(arg_3642) } else { tmp12 = linked_3640.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3639, arg_3642) }
//line :791:1
	var tmp15 any = tmp12; var tmp16 any; var root_3647 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3647, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3649 lang.IFn

	if linked_3648 == nil { ifn_3649 = lang.IFn_Cast(root_3647) } else { ifn_3649 = nil }; var arg_3650 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_137, nil); var tmp18 any; var root_3651 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_3652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3651, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3653 lang.IFn; if linked_3652 == nil { ifn_3653 = lang.IFn_Cast(root_3651) } else { ifn_3653 = nil }; var arg_3654 any = p__2; if linked_3652 == nil { tmp18 = ifn_3653.Invoke_O__O(arg_3654) } else { tmp18 = linked_3652.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3651, arg_3654) }; arg_3650 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3648 == nil { tmp16 = ifn_3649.Invoke_O__O(arg_3650) } else { tmp16 = linked_3648.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3647, arg_3650) }
//line :791:1
	arg_3624 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp11, tmp15, tmp16))
//line :790:1
	if linked_3621 == nil { ifn_3622.Invoke_O_O__O(arg_3623, arg_3624) } else { linked_3621.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3620, arg_3623, arg_3624) }; i__711000411__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000411__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










































func A_arbace_j2g_dyn_forms_A_New() *A_arbace_j2g_dyn_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_A{}; t.Ctor(); return t }
//line :833:1
func (t *A_arbace_j2g_dyn_forms_A) Ctor() {}
//line :833:1
func (t *A_arbace_j2g_dyn_forms_A) Invoke_O_O__O(self, T__0_ any) any { var ifaces__2 any; var root_3773 any = A_arbace_j2g_dyn_A_const_555.GetRawRoot__O(); var linked_3774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3773, A_arbace_j2g_dyn_interfaces_A_fn_class); var ifn_3775 lang.IFn; if


	linked_3774 == nil { ifn_3775 = lang.IFn_Cast(root_3773) } else { ifn_3775 = nil }; var arg_3776 any = T__0_; if linked_3774 == nil { ifaces__2 = ifn_3775.Invoke_O__O(arg_3776) } else { ifaces__2 = linked_3774.(*A_arbace_j2g_dyn_interfaces_A).Invoke_O_O__O(root_3773, arg_3776) }; var ks__3 any; var root_3777 any = /*line :833:1*/A_arbace_j2g_dyn_A_const_556.GetRawRoot__O(); var linked_3778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3777, A_arbace_j2g_dyn_slot_keys_A_fn_class); var ifn_3779 lang.IFn; if



	linked_3778 == nil { ifn_3779 = lang.IFn_Cast(root_3777) } else { ifn_3779 = nil }; var arg_3780 any = ifaces__2; if linked_3778 == nil { ks__3 = ifn_3779.Invoke_O__O(arg_3780) } else { ks__3 = linked_3778.(*A_arbace_j2g_dyn_slot_keys_A).Invoke_O_O__O(root_3777, arg_3780) }; var n__4 int32 = /*line :833:1*/lang.RT_Count_O__I_NoInit(ks__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_18.GetRawRoot__O()); var tmp2 any; var root_3790 any = A_arbace_j2g_dyn_A_const_557.GetRawRoot__O(); var linked_3791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3790, A_arbace_j2g_dyn_core_forms_A_fn_class); var ifn_3792 lang.IFn; if






	linked_3791 == nil { ifn_3792 = lang.IFn_Cast(root_3790) } else { ifn_3792 = nil }; var arg_3793 any = ifaces__2; var arg_3794 any = ks__3; var arg_3795 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref(); if linked_3791 == nil { tmp2 = ifn_3792.Invoke_O_O_O__O(arg_3793, arg_3794, arg_3795) } else { tmp2 = linked_3791.(*A_arbace_j2g_dyn_core_forms_A).Invoke_O_O_O_O__O(root_3790, arg_3793, arg_3794, arg_3795) }; var tmp3 any = tmp2; var tmp4 any; var iter__1927001039__auto____5 any; var fnbody__3883 any = /*line :839:1*/A_arbace_j2g_dyn_forms_iter__711000421__711000425_A_New(); var tmp5 *jrt.Class; var fncls__3882 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000421__711000425_A_fn_class; if

	fncls__3882 == nil { var fncls__3882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); A_arbace_j2g_dyn_forms_iter__711000421__711000425_A_fn_class = fncls__3882d; tmp5 = fncls__3882d } else { tmp5 = fncls__3882 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3883, tmp5, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(ifaces__2); var tmp6 any = tmp4; var tmp7 any; var nobj__5 int32 = /*line :839:1*/lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_62.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_562.GetRawRoot__O()); var tmp9 any; var root_3890 any = A_arbace_j2g_dyn_A_const_563.GetRawRoot__O(); var linked_3891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3890, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_3892 lang.IFn; if




	linked_3891 == nil { ifn_3892 = lang.IFn_Cast(root_3890) } else { ifn_3892 = nil }; if linked_3891 == nil { tmp9 = ifn_3892.Invoke__O() } else { tmp9 = linked_3891.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_3890) }; var tmp10 any = tmp9; var tmp11 *lang.Compiler_AOTFn; var fnbody__3900 any = A_arbace_j2g_dyn_forms_fn__711000431_A_New_O_O(ks__3, ifaces__2); var tmp12 *jrt.Class; var fncls__3899 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000431_A_fn_class; if fncls__3899 == nil { var fncls__3899d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__3900); A_arbace_j2g_dyn_forms_fn__711000431_A_fn_class = fncls__3899d; tmp12 = fncls__3899d } else { tmp12 = fncls__3899 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3900, tmp12, nil); var tmp13 any = tmp11.Ref(); var tmp14 any; var root_3901 any = A_arbace_j2g_dyn_A_const_137.GetRawRoot__O(); var linked_3902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3901, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3903 lang.IFn; if linked_3902 == nil { ifn_3903 = lang.IFn_Cast(root_3901) } else { ifn_3903 = nil }; var arg_3904 any = jrt.Integer_ValueOf_I__Integer_NoInit(nobj__5).Ref(); var arg_3905 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__3)).Ref(); if linked_3902 == nil { tmp14 = ifn_3903.Invoke_O_O__O(arg_3904, arg_3905) } else { tmp14 = linked_3902.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_3901, arg_3904, arg_3905) }; tmp7 = tmp8.Invoke_O_O_O__O(tmp10, tmp13, tmp14); var tmp15 any = tmp7; var tmp16 any; var root_3906 any = /*line :839:1*/A_arbace_j2g_dyn_A_const_564.GetRawRoot__O(); var linked_3907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3906, A_arbace_j2g_dyn_native_forms_A_fn_class); var ifn_3908 lang.IFn; if






	linked_3907 == nil { ifn_3908 = lang.IFn_Cast(root_3906) } else { ifn_3908 = nil }; var arg_3909 any = jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref(); if linked_3907 == nil { tmp16 = ifn_3908.Invoke_O__O(arg_3909) } else { tmp16 = linked_3907.(*A_arbace_j2g_dyn_native_forms_A).Invoke_O_O__O(root_3906, arg_3909) }; var tmp17 any = tmp16; var tmp18 any; var root_3910 any = /*line :839:1*/A_arbace_j2g_dyn_A_const_565.GetRawRoot__O(); var linked_3911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3910, A_arbace_j2g_dyn_proxy_forms_A_fn_class); var ifn_3912 lang.IFn; if







	linked_3911 == nil { ifn_3912 = lang.IFn_Cast(root_3910) } else { ifn_3912 = nil }; var arg_3913 any = T__0_; if linked_3911 == nil { tmp18 = ifn_3912.Invoke_O__O(arg_3913) } else { tmp18 = linked_3911.(*A_arbace_j2g_dyn_proxy_forms_A).Invoke_O_O__O(root_3910, arg_3913) }; var tmp19 any = tmp18; var tmp20 lang.IFn = /*line :839:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_566.GetRawRoot__O()); var tmp21 *lang.Compiler_AOTFn; var fnbody__3926 any = A_arbace_j2g_dyn_forms_fn__711000433_A_New_O_O(ks__3, ifaces__2); var tmp22 *jrt.Class; var fncls__3925 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000433_A_fn_class; if








	fncls__3925 == nil { var fncls__3925d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__3926); A_arbace_j2g_dyn_forms_fn__711000433_A_fn_class = fncls__3925d; tmp22 = fncls__3925d } else { tmp22 = fncls__3925 }; tmp21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3926, tmp22, nil); var tmp23 any = /*line :839:1*/tmp21.Ref(); var tmp24 any; var root_3927 any = A_arbace_j2g_dyn_A_const_527.GetRawRoot__O(); var linked_3928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3927, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3929 lang.IFn; if








	linked_3928 == nil { ifn_3929 = lang.IFn_Cast(root_3927) } else { ifn_3929 = nil }; var arg_3930 any = T__0_; if linked_3928 == nil { tmp24 = ifn_3929.Invoke_O__O(arg_3930) } else { tmp24 = linked_3928.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3927, arg_3930) }; return /*line :839:1*/ tmp1.Invoke_O_O_O_O_O_O__O(tmp3, tmp6, tmp15, tmp17, tmp19, tmp20.Invoke_O_O__O(tmp23, tmp24)) }

func A_arbace_j2g_dyn_forms_iter__711000421__711000425_A_New() *A_arbace_j2g_dyn_forms_iter__711000421__711000425_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000421__711000425_A{}; t.Ctor(); return t }
//line :841:1
func (t *A_arbace_j2g_dyn_forms_iter__711000421__711000425_A) Ctor() {}
//line :841:1
func (t *A_arbace_j2g_dyn_forms_iter__711000421__711000425_A) Invoke_O_O__O(self, s__711000422__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3881 any = A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A_New_O_O(self, s__711000422__1); var tmp2 *jrt.Class; var fncls__3880 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A_fn_class; if fncls__3880 == nil { var fncls__3880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__3881); A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A_fn_class = fncls__3880d; tmp2 = fncls__3880d } else { tmp2 = fncls__3880 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3881, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :841:1
func A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A{}; t.Ctor_O_O(p0, p1); return t }
//line :841:1
func (t *A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A) Ctor_O_O(c__iter__711000421, c__s__711000422 any) { t.F_iter__711000421 = c__iter__711000421; t.F_s__711000422 = c__s__711000422 }
//line :841:1
func (t *A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A) Invoke_O__O(self any) any { { var s__711000422__1 any; var t_ any = t.F_s__711000422; t.F_s__711000422 = nil; s__711000422__1 = t_; for { var temp__1927000414__auto____2 any; var root_3796 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3796, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3798 lang.IFn; if linked_3797 == nil { ifn_3798 = lang.IFn_Cast(root_3796) } else { ifn_3798 = nil }; var arg_3799 any = s__711000422__1; if linked_3797 == nil { temp__1927000414__auto____2 = ifn_3798.Invoke_O__O(arg_3799) } else { temp__1927000414__auto____2 = linked_3797.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3796, arg_3799) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000422__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3800 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3800, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3802 lang.IFn; if linked_3801 == nil { ifn_3802 = lang.IFn_Cast(root_3800) } else { ifn_3802 = nil }; var arg_3803 any = s__711000422__3; if linked_3801 == nil { tmp1 = ifn_3802.Invoke_O__O(arg_3803) } else { tmp1 = linked_3801.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3800, arg_3803) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3804 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3804, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3806 lang.IFn; if linked_3805 == nil { ifn_3806 = lang.IFn_Cast(root_3804) } else { ifn_3806 = nil }; var arg_3807 any = s__711000422__3; if linked_3805 == nil { c__1927001037__auto____4 = ifn_3806.Invoke_O__O(arg_3807) } else { c__1927001037__auto____4 = linked_3805.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3804, arg_3807) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000424__6 any; var root_3808 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3808, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3810 lang.IFn; if linked_3809 == nil { ifn_3810 = lang.IFn_Cast(root_3808) } else { ifn_3810 = nil }; var arg_3811 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3809 == nil { b__711000424__6 = ifn_3810.Invoke_O__O(arg_3811) } else { b__711000424__6 = linked_3809.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3808, arg_3811) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3831 any = A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A_New_O_I_O(b__711000424__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3830 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A_fn_class; if fncls__3830 == nil { var fncls__3830d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__3831); A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A_fn_class = fncls__3830d; tmp3 = fncls__3830d } else { tmp3 = fncls__3830 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3831, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3832 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3832, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3834 lang.IFn; if linked_3833 == nil { ifn_3834 = lang.IFn_Cast(root_3832) } else { ifn_3834 = nil }; var arg_3835 any; var root_3837 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3837, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3839 lang.IFn; if linked_3838 == nil { ifn_3839 = lang.IFn_Cast(root_3837) } else { ifn_3839 = nil }; var arg_3840 any = b__711000424__6; if linked_3838 == nil { arg_3835 = ifn_3839.Invoke_O__O(arg_3840) } else { arg_3835 = linked_3838.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3837, arg_3840) }; var arg_3836 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000421); var tmp5 any; var root_3841 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3841, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3843 lang.IFn; if linked_3842 == nil { ifn_3843 = lang.IFn_Cast(root_3841) } else { ifn_3843 = nil }; var arg_3844 any = s__711000422__3; if linked_3842 == nil { tmp5 = ifn_3843.Invoke_O__O(arg_3844) } else { tmp5 = linked_3842.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3841, arg_3844) }; arg_3836 = tmp4.Invoke_O__O(tmp5); if linked_3833 == nil { return ifn_3834.Invoke_O_O__O(arg_3835, arg_3836) } else { return linked_3833.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3832, arg_3835, arg_3836) } } else { var root_3845 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3845, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3847 lang.IFn; if linked_3846 == nil { ifn_3847 = lang.IFn_Cast(root_3845) } else { ifn_3847 = nil }; var arg_3848 any; var root_3850 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3850, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3852 lang.IFn; if linked_3851 == nil { ifn_3852 = lang.IFn_Cast(root_3850) } else { ifn_3852 = nil }; var arg_3853 any = b__711000424__6; if linked_3851 == nil { arg_3848 = ifn_3852.Invoke_O__O(arg_3853) } else { arg_3848 = linked_3851.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3850, arg_3853) }; var arg_3849 any; if linked_3846 == nil { return ifn_3847.Invoke_O_O__O(arg_3848, arg_3849) } else { return linked_3846.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3845, arg_3848, arg_3849) } } } else { var j__4 any; var root_3854 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3854, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3856 lang.IFn; if linked_3855 == nil { ifn_3856 = lang.IFn_Cast(root_3854) } else { ifn_3856 = nil }; var arg_3857 any = s__711000422__3; if linked_3855 == nil { j__4 = ifn_3856.Invoke_O__O(arg_3857) } else { j__4 = linked_3855.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3854, arg_3857) }; var root_3858 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3858, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3860 lang.IFn; if linked_3859 == nil { ifn_3860 = lang.IFn_Cast(root_3858) } else { ifn_3860 = nil }; var arg_3861 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_558; var tmp8 any; var root_3863 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3863, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3865 lang.IFn; if linked_3864 == nil { ifn_3865 = lang.IFn_Cast(root_3863) } else { ifn_3865 = nil }; var arg_3866 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp10 any; var root_3867 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_3868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3867, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3869 lang.IFn; if linked_3868 == nil { ifn_3869 = lang.IFn_Cast(root_3867) } else { ifn_3869 = nil }; var arg_3870 any = j__4; if linked_3868 == nil { tmp10 = ifn_3869.Invoke_O__O(arg_3870) } else { tmp10 = linked_3868.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3867, arg_3870) }; arg_3866 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3864 == nil { tmp8 = ifn_3865.Invoke_O__O(arg_3866) } else { tmp8 = linked_3864.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3863, arg_3866) }; var tmp11 any = tmp8; var tmp12 any; var root_3871 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3871, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3873 lang.IFn; if linked_3872 == nil { ifn_3873 = lang.IFn_Cast(root_3871) } else { ifn_3873 = nil }; var arg_3874 any = A_arbace_j2g_dyn_A_const_559; var arg_3875 any = A_arbace_j2g_dyn_A_const_561; if linked_3872 == nil { tmp12 = ifn_3873.Invoke_O_O__O(arg_3874, arg_3875) } else { tmp12 = linked_3872.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3871, arg_3874, arg_3875) }; arg_3861 = tmp6.Invoke_O_O_O__O(tmp7, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12)); var arg_3862 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000421); var tmp14 any; var root_3876 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); var linked_3877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3876, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3878 lang.IFn; if linked_3877 == nil { ifn_3878 = lang.IFn_Cast(root_3876) } else { ifn_3878 = nil }; var arg_3879 any = s__711000422__3; if linked_3877 == nil { tmp14 = ifn_3878.Invoke_O__O(arg_3879) } else { tmp14 = linked_3877.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3876, arg_3879) }; arg_3862 = tmp13.Invoke_O__O(tmp14); if linked_3859 == nil { return ifn_3860.Invoke_O_O__O(arg_3861, arg_3862) } else { return linked_3859.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3858, arg_3861, arg_3862) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :841:1
func A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :841:1
func (t *A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A) Ctor_O_I_O(c__b__711000424 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000424 = c__b__711000424; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :841:1
func (t *A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A) Invoke_O__O(self any) any { { var i__711000423__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000423__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000423__1)); var root_3812 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3812, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3814 lang.IFn; if linked_3813 == nil { ifn_3814 = lang.IFn_Cast(root_3812) } else { ifn_3814 = nil }; var arg_3815 any = t.F_b__711000424; var arg_3816 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_82.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_558; var tmp4 any; var root_3817 any = A_arbace_j2g_dyn_A_const_94.GetRawRoot__O(); var linked_3818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3817, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3819 lang.IFn; if linked_3818 == nil { ifn_3819 = lang.IFn_Cast(root_3817) } else { ifn_3819 = nil }; var arg_3820 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_62, nil); var tmp6 any; var root_3821 any = A_arbace_j2g_dyn_A_const_51.GetRawRoot__O(); var linked_3822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3821, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3823 lang.IFn; if linked_3822 == nil { ifn_3823 = lang.IFn_Cast(root_3821) } else { ifn_3823 = nil }; var arg_3824 any = j__2; if linked_3822 == nil { tmp6 = ifn_3823.Invoke_O__O(arg_3824) } else { tmp6 = linked_3822.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3821, arg_3824) }; arg_3820 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_3818 == nil { tmp4 = ifn_3819.Invoke_O__O(arg_3820) } else { tmp4 = linked_3818.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3817, arg_3820) }; var tmp7 any = tmp4; var tmp8 any; var root_3825 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var linked_3826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3825, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3827 lang.IFn; if linked_3826 == nil { ifn_3827 = lang.IFn_Cast(root_3825) } else { ifn_3827 = nil }; var arg_3828 any = A_arbace_j2g_dyn_A_const_559; var arg_3829 any = A_arbace_j2g_dyn_A_const_560; if linked_3826 == nil { tmp8 = ifn_3827.Invoke_O_O__O(arg_3828, arg_3829) } else { tmp8 = linked_3826.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3825, arg_3828, arg_3829) }; arg_3816 = tmp2.Invoke_O_O_O__O(tmp3, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8)); if linked_3813 == nil { ifn_3814.Invoke_O_O__O(arg_3815, arg_3816) } else { linked_3813.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3812, arg_3815, arg_3816) }; i__711000423__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000423__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_forms_fn__711000431_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000431_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000431_A{}; t.Ctor_O_O(p0, p1); return t }
//line :844:1
func (t *A_arbace_j2g_dyn_forms_fn__711000431_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :844:1
func (t *A_arbace_j2g_dyn_forms_fn__711000431_A) Invoke_O_O__O(self, i__1 any) any { var root_3893 any = A_arbace_j2g_dyn_A_const_161.GetRawRoot__O(); var linked_3894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3893, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_3895 lang.IFn; if linked_3894 == nil { ifn_3895 = lang.IFn_Cast(root_3893) } else { ifn_3895 = nil }; var arg_3896 any = t.F_ifaces; var arg_3897 any = i__1; var tmp1 any = t.F_ks; var arg_3898 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(i__1)); if linked_3894 == nil { return ifn_3895.Invoke_O_O_O__O(arg_3896, arg_3897, arg_3898) } else { return linked_3894.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O__O(root_3893, arg_3896, arg_3897, arg_3898) } }



func A_arbace_j2g_dyn_forms_fn__711000433_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000433_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000433_A{}; t.Ctor_O_O(p0, p1); return t }
//line :848:1
func (t *A_arbace_j2g_dyn_forms_fn__711000433_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :848:1
func (t *A_arbace_j2g_dyn_forms_fn__711000433_A) Invoke_O_O__O(self, p1__711000420_SHARP___1 any) any { var root_3919 any = A_arbace_j2g_dyn_A_const_567.GetRawRoot__O(); var linked_3920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3919, A_arbace_j2g_dyn_sub_forms_A_fn_class); var ifn_3921 lang.IFn; if linked_3920 == nil { ifn_3921 = lang.IFn_Cast(root_3919) } else { ifn_3921 = nil }; var arg_3922 any = p1__711000420_SHARP___1; var arg_3923 any = t.F_ifaces; var arg_3924 any = t.F_ks; if linked_3920 == nil { return ifn_3921.Invoke_O_O_O__O(arg_3922, arg_3923, arg_3924) } else { return linked_3920.(*A_arbace_j2g_dyn_sub_forms_A).Invoke_O_O_O_O__O(root_3919, arg_3922, arg_3923, arg_3924) } }
























type A_arbace_j2g_dyn_A struct{ jrt.Object }

var A_arbace_j2g_dyn_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyn_A_const_0 *lang.Var

var A_arbace_j2g_dyn_A_const_1 any

var A_arbace_j2g_dyn_A_const_2 any

var A_arbace_j2g_dyn_A_const_3 any

var A_arbace_j2g_dyn_A_const_4 any

var A_arbace_j2g_dyn_A_const_5 any

var A_arbace_j2g_dyn_A_const_6 any

var A_arbace_j2g_dyn_A_const_7 any

var A_arbace_j2g_dyn_A_const_8 any

var A_arbace_j2g_dyn_A_const_9 *lang.Var

var A_arbace_j2g_dyn_A_const_10 any

var A_arbace_j2g_dyn_A_const_11 *lang.Var

var A_arbace_j2g_dyn_A_const_12 *lang.Var

var A_arbace_j2g_dyn_A_const_13 *lang.Var

var A_arbace_j2g_dyn_A_const_14 *lang.Var

var A_arbace_j2g_dyn_A_const_15 any

var A_arbace_j2g_dyn_A_const_16 *lang.Var

var A_arbace_j2g_dyn_A_const_17 *lang.Keyword

var A_arbace_j2g_dyn_A_const_18 *lang.Var

var A_arbace_j2g_dyn_A_const_19 *lang.Var

var A_arbace_j2g_dyn_A_const_20 *lang.Var

var A_arbace_j2g_dyn_A_const_21 *lang.Var

var A_arbace_j2g_dyn_A_const_22 *lang.Var

var A_arbace_j2g_dyn_A_const_23 *lang.Var

var A_arbace_j2g_dyn_A_const_24 *lang.Var

var A_arbace_j2g_dyn_A_const_25 *lang.Var

var A_arbace_j2g_dyn_A_const_26 *lang.Var

var A_arbace_j2g_dyn_A_const_27 *lang.Var

var A_arbace_j2g_dyn_A_const_28 *lang.Var

var A_arbace_j2g_dyn_A_const_29 *lang.Var

var A_arbace_j2g_dyn_A_const_30 *lang.Var

var A_arbace_j2g_dyn_A_const_31 *lang.Var

var A_arbace_j2g_dyn_A_const_32 *lang.Var

var A_arbace_j2g_dyn_A_const_33 *lang.Var

var A_arbace_j2g_dyn_A_const_34 *lang.Var

var A_arbace_j2g_dyn_A_const_35 *lang.Var

var A_arbace_j2g_dyn_A_const_36 *lang.Keyword

var A_arbace_j2g_dyn_A_const_37 *lang.Var

var A_arbace_j2g_dyn_A_const_38 *lang.Var

var A_arbace_j2g_dyn_A_const_39 *lang.Var

var A_arbace_j2g_dyn_A_const_40 *lang.Var

var A_arbace_j2g_dyn_A_const_41 *lang.Var

var A_arbace_j2g_dyn_A_const_42 *lang.Var

var A_arbace_j2g_dyn_A_const_43 *lang.Var

var A_arbace_j2g_dyn_A_const_44 *lang.Var

var A_arbace_j2g_dyn_A_const_45 *lang.Var

var A_arbace_j2g_dyn_A_const_46 *lang.Var

var A_arbace_j2g_dyn_A_const_47 *lang.Var

var A_arbace_j2g_dyn_A_const_48 *lang.Keyword

var A_arbace_j2g_dyn_A_const_49 *lang.Keyword

var A_arbace_j2g_dyn_A_const_50 *lang.Var

var A_arbace_j2g_dyn_A_const_51 *lang.Var

var A_arbace_j2g_dyn_A_const_52 *lang.Var

var A_arbace_j2g_dyn_A_const_53 *lang.Var

var A_arbace_j2g_dyn_A_const_54 *lang.Keyword

var A_arbace_j2g_dyn_A_const_55 *lang.Var

var A_arbace_j2g_dyn_A_const_56 *lang.Var

var A_arbace_j2g_dyn_A_const_57 *lang.Var

var A_arbace_j2g_dyn_A_const_58 *lang.Var

var A_arbace_j2g_dyn_A_const_59 *lang.Var

var A_arbace_j2g_dyn_A_const_60 *lang.Var

var A_arbace_j2g_dyn_A_const_61 *lang.Var

var A_arbace_j2g_dyn_A_const_62 *lang.Var

var A_arbace_j2g_dyn_A_const_63 *lang.Var

var A_arbace_j2g_dyn_A_const_64 *lang.Var

var A_arbace_j2g_dyn_A_const_65 *lang.Var

var A_arbace_j2g_dyn_A_const_66 *lang.Var

var A_arbace_j2g_dyn_A_const_67 *lang.Keyword

var A_arbace_j2g_dyn_A_const_68 *lang.Keyword

var A_arbace_j2g_dyn_A_const_69 *lang.Var

var A_arbace_j2g_dyn_A_const_70 *lang.Var

var A_arbace_j2g_dyn_A_const_71 *lang.Var

var A_arbace_j2g_dyn_A_const_72 *lang.Keyword

var A_arbace_j2g_dyn_A_const_73 *lang.Keyword

var A_arbace_j2g_dyn_A_const_74 *lang.Keyword

var A_arbace_j2g_dyn_A_const_75 *lang.Var

var A_arbace_j2g_dyn_A_const_76 *lang.Keyword

var A_arbace_j2g_dyn_A_const_77 *lang.Var

var A_arbace_j2g_dyn_A_const_78 *lang.Var

var A_arbace_j2g_dyn_A_const_79 *lang.Var

var A_arbace_j2g_dyn_A_const_80 *lang.Var

var A_arbace_j2g_dyn_A_const_81 *lang.Var

var A_arbace_j2g_dyn_A_const_82 *lang.Var

var A_arbace_j2g_dyn_A_const_83 *lang.Var

var A_arbace_j2g_dyn_A_const_84 *lang.Keyword

var A_arbace_j2g_dyn_A_const_85 any

var A_arbace_j2g_dyn_A_const_86 any

var A_arbace_j2g_dyn_A_const_87 any

var A_arbace_j2g_dyn_A_const_88 *lang.Var

var A_arbace_j2g_dyn_A_const_89 *lang.Var

var A_arbace_j2g_dyn_A_const_90 *lang.Keyword

var A_arbace_j2g_dyn_A_const_91 *lang.Var

var A_arbace_j2g_dyn_A_const_92 *lang.Var

var A_arbace_j2g_dyn_A_const_93 any

var A_arbace_j2g_dyn_A_const_94 *lang.Var

var A_arbace_j2g_dyn_A_const_95 *lang.Var

var A_arbace_j2g_dyn_A_const_96 *lang.Var

var A_arbace_j2g_dyn_A_const_97 any

var A_arbace_j2g_dyn_A_const_98 *lang.Var

var A_arbace_j2g_dyn_A_const_99 any

var A_arbace_j2g_dyn_A_const_100 any

var A_arbace_j2g_dyn_A_const_101 any

var A_arbace_j2g_dyn_A_const_102 *lang.Var

var A_arbace_j2g_dyn_A_const_103 *lang.Var

var A_arbace_j2g_dyn_A_const_104 *lang.Var

var A_arbace_j2g_dyn_A_const_105 any

var A_arbace_j2g_dyn_A_const_106 any

var A_arbace_j2g_dyn_A_const_107 any

var A_arbace_j2g_dyn_A_const_108 any

var A_arbace_j2g_dyn_A_const_109 any

var A_arbace_j2g_dyn_A_const_110 any

var A_arbace_j2g_dyn_A_const_111 *lang.Var

var A_arbace_j2g_dyn_A_const_112 any

var A_arbace_j2g_dyn_A_const_113 *lang.Var

var A_arbace_j2g_dyn_A_const_114 *lang.Var

var A_arbace_j2g_dyn_A_const_115 *lang.Keyword

var A_arbace_j2g_dyn_A_const_116 *lang.Var

var A_arbace_j2g_dyn_A_const_117 *lang.Var

var A_arbace_j2g_dyn_A_const_118 *lang.Var

var A_arbace_j2g_dyn_A_const_119 *lang.Var

var A_arbace_j2g_dyn_A_const_120 any

var A_arbace_j2g_dyn_A_const_121 any

var A_arbace_j2g_dyn_A_const_122 any

var A_arbace_j2g_dyn_A_const_123 any

var A_arbace_j2g_dyn_A_const_124 any

var A_arbace_j2g_dyn_A_const_125 any

var A_arbace_j2g_dyn_A_const_126 any

var A_arbace_j2g_dyn_A_const_127 any

var A_arbace_j2g_dyn_A_const_128 any

var A_arbace_j2g_dyn_A_const_129 any

var A_arbace_j2g_dyn_A_const_130 any

var A_arbace_j2g_dyn_A_const_131 *lang.Var

var A_arbace_j2g_dyn_A_const_132 any

var A_arbace_j2g_dyn_A_const_133 any

var A_arbace_j2g_dyn_A_const_134 any

var A_arbace_j2g_dyn_A_const_135 *lang.Var

var A_arbace_j2g_dyn_A_const_136 *lang.Var

var A_arbace_j2g_dyn_A_const_137 *lang.Var

var A_arbace_j2g_dyn_A_const_138 *lang.Var

var A_arbace_j2g_dyn_A_const_139 any

var A_arbace_j2g_dyn_A_const_140 *lang.Var

var A_arbace_j2g_dyn_A_const_141 any

var A_arbace_j2g_dyn_A_const_142 any

var A_arbace_j2g_dyn_A_const_143 any

var A_arbace_j2g_dyn_A_const_144 any

var A_arbace_j2g_dyn_A_const_145 any

var A_arbace_j2g_dyn_A_const_146 any

var A_arbace_j2g_dyn_A_const_147 any

var A_arbace_j2g_dyn_A_const_148 any

var A_arbace_j2g_dyn_A_const_149 any

var A_arbace_j2g_dyn_A_const_150 any

var A_arbace_j2g_dyn_A_const_151 any

var A_arbace_j2g_dyn_A_const_152 any

var A_arbace_j2g_dyn_A_const_153 any

var A_arbace_j2g_dyn_A_const_154 any

var A_arbace_j2g_dyn_A_const_155 any

var A_arbace_j2g_dyn_A_const_156 any

var A_arbace_j2g_dyn_A_const_157 any

var A_arbace_j2g_dyn_A_const_158 any

var A_arbace_j2g_dyn_A_const_159 *lang.Var

var A_arbace_j2g_dyn_A_const_160 any

var A_arbace_j2g_dyn_A_const_161 *lang.Var

var A_arbace_j2g_dyn_A_const_162 any

var A_arbace_j2g_dyn_A_const_163 any

var A_arbace_j2g_dyn_A_const_164 any

var A_arbace_j2g_dyn_A_const_165 *lang.Var

var A_arbace_j2g_dyn_A_const_166 *lang.Var

var A_arbace_j2g_dyn_A_const_167 *lang.Var

var A_arbace_j2g_dyn_A_const_168 *lang.Var

var A_arbace_j2g_dyn_A_const_169 *lang.Var

var A_arbace_j2g_dyn_A_const_170 *lang.Var

var A_arbace_j2g_dyn_A_const_171 any

var A_arbace_j2g_dyn_A_const_172 any

var A_arbace_j2g_dyn_A_const_173 any

var A_arbace_j2g_dyn_A_const_174 any

var A_arbace_j2g_dyn_A_const_175 any

var A_arbace_j2g_dyn_A_const_176 any

var A_arbace_j2g_dyn_A_const_177 any

var A_arbace_j2g_dyn_A_const_178 any

var A_arbace_j2g_dyn_A_const_179 any

var A_arbace_j2g_dyn_A_const_180 any

var A_arbace_j2g_dyn_A_const_181 *lang.Keyword

var A_arbace_j2g_dyn_A_const_182 *lang.Keyword

var A_arbace_j2g_dyn_A_const_183 *lang.Keyword

var A_arbace_j2g_dyn_A_const_184 any

var A_arbace_j2g_dyn_A_const_185 any

var A_arbace_j2g_dyn_A_const_186 any

var A_arbace_j2g_dyn_A_const_187 any

var A_arbace_j2g_dyn_A_const_188 any

var A_arbace_j2g_dyn_A_const_189 any

var A_arbace_j2g_dyn_A_const_190 any

var A_arbace_j2g_dyn_A_const_191 *lang.Var

var A_arbace_j2g_dyn_A_const_192 any

var A_arbace_j2g_dyn_A_const_193 any

var A_arbace_j2g_dyn_A_const_194 any

var A_arbace_j2g_dyn_A_const_195 *lang.Var

var A_arbace_j2g_dyn_A_const_196 *lang.Var

var A_arbace_j2g_dyn_A_const_197 *lang.Var

var A_arbace_j2g_dyn_A_const_198 *lang.Var

var A_arbace_j2g_dyn_A_const_199 any

var A_arbace_j2g_dyn_A_const_200 any

var A_arbace_j2g_dyn_A_const_201 any

var A_arbace_j2g_dyn_A_const_202 any

var A_arbace_j2g_dyn_A_const_203 any

var A_arbace_j2g_dyn_A_const_204 any

var A_arbace_j2g_dyn_A_const_205 any

var A_arbace_j2g_dyn_A_const_206 any

var A_arbace_j2g_dyn_A_const_207 *lang.Var

var A_arbace_j2g_dyn_A_const_208 *lang.Var

var A_arbace_j2g_dyn_A_const_209 *lang.Var

var A_arbace_j2g_dyn_A_const_210 *lang.Var

var A_arbace_j2g_dyn_A_const_211 any

var A_arbace_j2g_dyn_A_const_212 any

var A_arbace_j2g_dyn_A_const_213 *lang.Keyword

var A_arbace_j2g_dyn_A_const_214 any

var A_arbace_j2g_dyn_A_const_215 any

var A_arbace_j2g_dyn_A_const_216 *lang.Var

var A_arbace_j2g_dyn_A_const_217 *lang.Keyword

var A_arbace_j2g_dyn_A_const_218 any

var A_arbace_j2g_dyn_A_const_219 *lang.Keyword

var A_arbace_j2g_dyn_A_const_220 *lang.Var

var A_arbace_j2g_dyn_A_const_221 any

var A_arbace_j2g_dyn_A_const_222 any

var A_arbace_j2g_dyn_A_const_223 any

var A_arbace_j2g_dyn_A_const_224 any

var A_arbace_j2g_dyn_A_const_225 *lang.Var

var A_arbace_j2g_dyn_A_const_226 any

var A_arbace_j2g_dyn_A_const_227 any

var A_arbace_j2g_dyn_A_const_228 any

var A_arbace_j2g_dyn_A_const_229 any

var A_arbace_j2g_dyn_A_const_230 any

var A_arbace_j2g_dyn_A_const_231 *lang.Var

var A_arbace_j2g_dyn_A_const_232 any

var A_arbace_j2g_dyn_A_const_233 any

var A_arbace_j2g_dyn_A_const_234 any

var A_arbace_j2g_dyn_A_const_235 any

var A_arbace_j2g_dyn_A_const_236 any

var A_arbace_j2g_dyn_A_const_237 any

var A_arbace_j2g_dyn_A_const_238 *lang.Keyword

var A_arbace_j2g_dyn_A_const_239 any

var A_arbace_j2g_dyn_A_const_240 any

var A_arbace_j2g_dyn_A_const_241 any

var A_arbace_j2g_dyn_A_const_242 any

var A_arbace_j2g_dyn_A_const_243 any

var A_arbace_j2g_dyn_A_const_244 any

var A_arbace_j2g_dyn_A_const_245 any

var A_arbace_j2g_dyn_A_const_246 *lang.Var

var A_arbace_j2g_dyn_A_const_247 *lang.Var

var A_arbace_j2g_dyn_A_const_248 *lang.Var

var A_arbace_j2g_dyn_A_const_249 *lang.Var

var A_arbace_j2g_dyn_A_const_250 any

var A_arbace_j2g_dyn_A_const_251 any

var A_arbace_j2g_dyn_A_const_252 any

var A_arbace_j2g_dyn_A_const_253 any

var A_arbace_j2g_dyn_A_const_254 any

var A_arbace_j2g_dyn_A_const_255 any

var A_arbace_j2g_dyn_A_const_256 any

var A_arbace_j2g_dyn_A_const_257 any

var A_arbace_j2g_dyn_A_const_258 any

var A_arbace_j2g_dyn_A_const_259 any

var A_arbace_j2g_dyn_A_const_260 any

var A_arbace_j2g_dyn_A_const_261 any

var A_arbace_j2g_dyn_A_const_262 any

var A_arbace_j2g_dyn_A_const_263 any

var A_arbace_j2g_dyn_A_const_264 any

var A_arbace_j2g_dyn_A_const_265 any

var A_arbace_j2g_dyn_A_const_266 any

var A_arbace_j2g_dyn_A_const_267 any

var A_arbace_j2g_dyn_A_const_268 any

var A_arbace_j2g_dyn_A_const_269 any

var A_arbace_j2g_dyn_A_const_270 any

var A_arbace_j2g_dyn_A_const_271 any

var A_arbace_j2g_dyn_A_const_272 any

var A_arbace_j2g_dyn_A_const_273 any

var A_arbace_j2g_dyn_A_const_274 any

var A_arbace_j2g_dyn_A_const_275 any

var A_arbace_j2g_dyn_A_const_276 any

var A_arbace_j2g_dyn_A_const_277 any

var A_arbace_j2g_dyn_A_const_278 any

var A_arbace_j2g_dyn_A_const_279 any

var A_arbace_j2g_dyn_A_const_280 any

var A_arbace_j2g_dyn_A_const_281 any

var A_arbace_j2g_dyn_A_const_282 any

var A_arbace_j2g_dyn_A_const_283 *lang.Var

var A_arbace_j2g_dyn_A_const_284 any

var A_arbace_j2g_dyn_A_const_285 any

var A_arbace_j2g_dyn_A_const_286 *lang.Var

var A_arbace_j2g_dyn_A_const_287 *lang.Var

var A_arbace_j2g_dyn_A_const_288 *lang.Var

var A_arbace_j2g_dyn_A_const_289 any

var A_arbace_j2g_dyn_A_const_290 any

var A_arbace_j2g_dyn_A_const_291 *lang.Var

var A_arbace_j2g_dyn_A_const_292 any

var A_arbace_j2g_dyn_A_const_293 any

var A_arbace_j2g_dyn_A_const_294 any

var A_arbace_j2g_dyn_A_const_295 any

var A_arbace_j2g_dyn_A_const_296 any

var A_arbace_j2g_dyn_A_const_297 any

var A_arbace_j2g_dyn_A_const_298 any

var A_arbace_j2g_dyn_A_const_299 any

var A_arbace_j2g_dyn_A_const_300 any

var A_arbace_j2g_dyn_A_const_301 any

var A_arbace_j2g_dyn_A_const_302 any

var A_arbace_j2g_dyn_A_const_303 any

var A_arbace_j2g_dyn_A_const_304 any

var A_arbace_j2g_dyn_A_const_305 any

var A_arbace_j2g_dyn_A_const_306 any

var A_arbace_j2g_dyn_A_const_307 any

var A_arbace_j2g_dyn_A_const_308 any

var A_arbace_j2g_dyn_A_const_309 any

var A_arbace_j2g_dyn_A_const_310 any

var A_arbace_j2g_dyn_A_const_311 any

var A_arbace_j2g_dyn_A_const_312 any

var A_arbace_j2g_dyn_A_const_313 any

var A_arbace_j2g_dyn_A_const_314 any

var A_arbace_j2g_dyn_A_const_315 any

var A_arbace_j2g_dyn_A_const_316 any

var A_arbace_j2g_dyn_A_const_317 any

var A_arbace_j2g_dyn_A_const_318 any

var A_arbace_j2g_dyn_A_const_319 any

var A_arbace_j2g_dyn_A_const_320 any

var A_arbace_j2g_dyn_A_const_321 any

var A_arbace_j2g_dyn_A_const_322 any

var A_arbace_j2g_dyn_A_const_323 any

var A_arbace_j2g_dyn_A_const_324 any

var A_arbace_j2g_dyn_A_const_325 any

var A_arbace_j2g_dyn_A_const_326 any

var A_arbace_j2g_dyn_A_const_327 any

var A_arbace_j2g_dyn_A_const_328 any

var A_arbace_j2g_dyn_A_const_329 any

var A_arbace_j2g_dyn_A_const_330 any

var A_arbace_j2g_dyn_A_const_331 any

var A_arbace_j2g_dyn_A_const_332 any

var A_arbace_j2g_dyn_A_const_333 any

var A_arbace_j2g_dyn_A_const_334 any

var A_arbace_j2g_dyn_A_const_335 any

var A_arbace_j2g_dyn_A_const_336 any

var A_arbace_j2g_dyn_A_const_337 any

var A_arbace_j2g_dyn_A_const_338 *lang.Var

var A_arbace_j2g_dyn_A_const_339 any

var A_arbace_j2g_dyn_A_const_340 any

var A_arbace_j2g_dyn_A_const_341 any

var A_arbace_j2g_dyn_A_const_342 any

var A_arbace_j2g_dyn_A_const_343 any

var A_arbace_j2g_dyn_A_const_344 any

var A_arbace_j2g_dyn_A_const_345 any

var A_arbace_j2g_dyn_A_const_346 any

var A_arbace_j2g_dyn_A_const_347 any

var A_arbace_j2g_dyn_A_const_348 any

var A_arbace_j2g_dyn_A_const_349 any

var A_arbace_j2g_dyn_A_const_350 any

var A_arbace_j2g_dyn_A_const_351 any

var A_arbace_j2g_dyn_A_const_352 any

var A_arbace_j2g_dyn_A_const_353 any

var A_arbace_j2g_dyn_A_const_354 any

var A_arbace_j2g_dyn_A_const_355 any

var A_arbace_j2g_dyn_A_const_356 any

var A_arbace_j2g_dyn_A_const_357 any

var A_arbace_j2g_dyn_A_const_358 any

var A_arbace_j2g_dyn_A_const_359 *lang.Var

var A_arbace_j2g_dyn_A_const_360 *lang.Var

var A_arbace_j2g_dyn_A_const_361 *lang.Var

var A_arbace_j2g_dyn_A_const_362 any

var A_arbace_j2g_dyn_A_const_363 any

var A_arbace_j2g_dyn_A_const_364 any

var A_arbace_j2g_dyn_A_const_365 *lang.Var

var A_arbace_j2g_dyn_A_const_366 any

var A_arbace_j2g_dyn_A_const_367 any

var A_arbace_j2g_dyn_A_const_368 any

var A_arbace_j2g_dyn_A_const_369 any

var A_arbace_j2g_dyn_A_const_370 any

var A_arbace_j2g_dyn_A_const_371 any

var A_arbace_j2g_dyn_A_const_372 any

var A_arbace_j2g_dyn_A_const_373 any

var A_arbace_j2g_dyn_A_const_374 any

var A_arbace_j2g_dyn_A_const_375 any

var A_arbace_j2g_dyn_A_const_376 any

var A_arbace_j2g_dyn_A_const_377 any

var A_arbace_j2g_dyn_A_const_378 any

var A_arbace_j2g_dyn_A_const_379 *lang.Var

var A_arbace_j2g_dyn_A_const_380 any

var A_arbace_j2g_dyn_A_const_381 any

var A_arbace_j2g_dyn_A_const_382 any

var A_arbace_j2g_dyn_A_const_383 any

var A_arbace_j2g_dyn_A_const_384 any

var A_arbace_j2g_dyn_A_const_385 any

var A_arbace_j2g_dyn_A_const_386 any

var A_arbace_j2g_dyn_A_const_387 *lang.Keyword

var A_arbace_j2g_dyn_A_const_388 *lang.Keyword

var A_arbace_j2g_dyn_A_const_389 any

var A_arbace_j2g_dyn_A_const_390 *lang.Keyword

var A_arbace_j2g_dyn_A_const_391 any

var A_arbace_j2g_dyn_A_const_392 *lang.Keyword

var A_arbace_j2g_dyn_A_const_393 any

var A_arbace_j2g_dyn_A_const_394 any

var A_arbace_j2g_dyn_A_const_395 any

var A_arbace_j2g_dyn_A_const_396 any

var A_arbace_j2g_dyn_A_const_397 any

var A_arbace_j2g_dyn_A_const_398 any

var A_arbace_j2g_dyn_A_const_399 any

var A_arbace_j2g_dyn_A_const_400 any

var A_arbace_j2g_dyn_A_const_401 any

var A_arbace_j2g_dyn_A_const_402 any

var A_arbace_j2g_dyn_A_const_403 any

var A_arbace_j2g_dyn_A_const_404 any

var A_arbace_j2g_dyn_A_const_405 any

var A_arbace_j2g_dyn_A_const_406 any

var A_arbace_j2g_dyn_A_const_407 any

var A_arbace_j2g_dyn_A_const_408 any

var A_arbace_j2g_dyn_A_const_409 any

var A_arbace_j2g_dyn_A_const_410 any

var A_arbace_j2g_dyn_A_const_411 any

var A_arbace_j2g_dyn_A_const_412 any

var A_arbace_j2g_dyn_A_const_413 any

var A_arbace_j2g_dyn_A_const_414 any

var A_arbace_j2g_dyn_A_const_415 any

var A_arbace_j2g_dyn_A_const_416 any

var A_arbace_j2g_dyn_A_const_417 any

var A_arbace_j2g_dyn_A_const_418 any

var A_arbace_j2g_dyn_A_const_419 any

var A_arbace_j2g_dyn_A_const_420 any

var A_arbace_j2g_dyn_A_const_421 any

var A_arbace_j2g_dyn_A_const_422 any

var A_arbace_j2g_dyn_A_const_423 any

var A_arbace_j2g_dyn_A_const_424 any

var A_arbace_j2g_dyn_A_const_425 any

var A_arbace_j2g_dyn_A_const_426 any

var A_arbace_j2g_dyn_A_const_427 any

var A_arbace_j2g_dyn_A_const_428 any

var A_arbace_j2g_dyn_A_const_429 any

var A_arbace_j2g_dyn_A_const_430 any

var A_arbace_j2g_dyn_A_const_431 any

var A_arbace_j2g_dyn_A_const_432 any

var A_arbace_j2g_dyn_A_const_433 any

var A_arbace_j2g_dyn_A_const_434 any

var A_arbace_j2g_dyn_A_const_435 any

var A_arbace_j2g_dyn_A_const_436 any

var A_arbace_j2g_dyn_A_const_437 any

var A_arbace_j2g_dyn_A_const_438 any

var A_arbace_j2g_dyn_A_const_439 any

var A_arbace_j2g_dyn_A_const_440 any

var A_arbace_j2g_dyn_A_const_441 any

var A_arbace_j2g_dyn_A_const_442 any

var A_arbace_j2g_dyn_A_const_443 any

var A_arbace_j2g_dyn_A_const_444 any

var A_arbace_j2g_dyn_A_const_445 any

var A_arbace_j2g_dyn_A_const_446 any

var A_arbace_j2g_dyn_A_const_447 any

var A_arbace_j2g_dyn_A_const_448 any

var A_arbace_j2g_dyn_A_const_449 any

var A_arbace_j2g_dyn_A_const_450 any

var A_arbace_j2g_dyn_A_const_451 any

var A_arbace_j2g_dyn_A_const_452 any

var A_arbace_j2g_dyn_A_const_453 any

var A_arbace_j2g_dyn_A_const_454 any

var A_arbace_j2g_dyn_A_const_455 any

var A_arbace_j2g_dyn_A_const_456 any

var A_arbace_j2g_dyn_A_const_457 any

var A_arbace_j2g_dyn_A_const_458 any

var A_arbace_j2g_dyn_A_const_459 any

var A_arbace_j2g_dyn_A_const_460 any

var A_arbace_j2g_dyn_A_const_461 any

var A_arbace_j2g_dyn_A_const_462 any

var A_arbace_j2g_dyn_A_const_463 any

var A_arbace_j2g_dyn_A_const_464 any

var A_arbace_j2g_dyn_A_const_465 any

var A_arbace_j2g_dyn_A_const_466 any

var A_arbace_j2g_dyn_A_const_467 any

var A_arbace_j2g_dyn_A_const_468 any

var A_arbace_j2g_dyn_A_const_469 any

var A_arbace_j2g_dyn_A_const_470 any

var A_arbace_j2g_dyn_A_const_471 any

var A_arbace_j2g_dyn_A_const_472 any

var A_arbace_j2g_dyn_A_const_473 any

var A_arbace_j2g_dyn_A_const_474 any

var A_arbace_j2g_dyn_A_const_475 any

var A_arbace_j2g_dyn_A_const_476 any

var A_arbace_j2g_dyn_A_const_477 any

var A_arbace_j2g_dyn_A_const_478 any

var A_arbace_j2g_dyn_A_const_479 any

var A_arbace_j2g_dyn_A_const_480 any

var A_arbace_j2g_dyn_A_const_481 any

var A_arbace_j2g_dyn_A_const_482 any

var A_arbace_j2g_dyn_A_const_483 any

var A_arbace_j2g_dyn_A_const_484 any

var A_arbace_j2g_dyn_A_const_485 any

var A_arbace_j2g_dyn_A_const_486 any

var A_arbace_j2g_dyn_A_const_487 any

var A_arbace_j2g_dyn_A_const_488 any

var A_arbace_j2g_dyn_A_const_489 any

var A_arbace_j2g_dyn_A_const_490 any

var A_arbace_j2g_dyn_A_const_491 any

var A_arbace_j2g_dyn_A_const_492 any

var A_arbace_j2g_dyn_A_const_493 any

var A_arbace_j2g_dyn_A_const_494 any

var A_arbace_j2g_dyn_A_const_495 any

var A_arbace_j2g_dyn_A_const_496 any

var A_arbace_j2g_dyn_A_const_497 any

var A_arbace_j2g_dyn_A_const_498 any

var A_arbace_j2g_dyn_A_const_499 any

var A_arbace_j2g_dyn_A_const_500 any

var A_arbace_j2g_dyn_A_const_501 any

var A_arbace_j2g_dyn_A_const_502 any

var A_arbace_j2g_dyn_A_const_503 any

var A_arbace_j2g_dyn_A_const_504 any

var A_arbace_j2g_dyn_A_const_505 any

var A_arbace_j2g_dyn_A_const_506 any

var A_arbace_j2g_dyn_A_const_507 any

var A_arbace_j2g_dyn_A_const_508 any

var A_arbace_j2g_dyn_A_const_509 any

var A_arbace_j2g_dyn_A_const_510 any

var A_arbace_j2g_dyn_A_const_511 any

var A_arbace_j2g_dyn_A_const_512 any

var A_arbace_j2g_dyn_A_const_513 any

var A_arbace_j2g_dyn_A_const_514 any

var A_arbace_j2g_dyn_A_const_515 any

var A_arbace_j2g_dyn_A_const_516 any

var A_arbace_j2g_dyn_A_const_517 any

var A_arbace_j2g_dyn_A_const_518 any

var A_arbace_j2g_dyn_A_const_519 any

var A_arbace_j2g_dyn_A_const_520 any

var A_arbace_j2g_dyn_A_const_521 *lang.Keyword

var A_arbace_j2g_dyn_A_const_522 any

var A_arbace_j2g_dyn_A_const_523 any

var A_arbace_j2g_dyn_A_const_524 any

var A_arbace_j2g_dyn_A_const_525 any

var A_arbace_j2g_dyn_A_const_526 any

var A_arbace_j2g_dyn_A_const_527 *lang.Var

var A_arbace_j2g_dyn_A_const_528 any

var A_arbace_j2g_dyn_A_const_529 any

var A_arbace_j2g_dyn_A_const_530 any

var A_arbace_j2g_dyn_A_const_531 any

var A_arbace_j2g_dyn_A_const_532 any

var A_arbace_j2g_dyn_A_const_533 any

var A_arbace_j2g_dyn_A_const_534 any

var A_arbace_j2g_dyn_A_const_535 any

var A_arbace_j2g_dyn_A_const_536 any

var A_arbace_j2g_dyn_A_const_537 any

var A_arbace_j2g_dyn_A_const_538 any

var A_arbace_j2g_dyn_A_const_539 any

var A_arbace_j2g_dyn_A_const_540 any

var A_arbace_j2g_dyn_A_const_541 any

var A_arbace_j2g_dyn_A_const_542 any

var A_arbace_j2g_dyn_A_const_543 any

var A_arbace_j2g_dyn_A_const_544 any

var A_arbace_j2g_dyn_A_const_545 any

var A_arbace_j2g_dyn_A_const_546 any

var A_arbace_j2g_dyn_A_const_547 any

var A_arbace_j2g_dyn_A_const_548 any

var A_arbace_j2g_dyn_A_const_549 any

var A_arbace_j2g_dyn_A_const_550 any

var A_arbace_j2g_dyn_A_const_551 any

var A_arbace_j2g_dyn_A_const_552 any

var A_arbace_j2g_dyn_A_const_553 any

var A_arbace_j2g_dyn_A_const_554 any

var A_arbace_j2g_dyn_A_const_555 *lang.Var

var A_arbace_j2g_dyn_A_const_556 *lang.Var

var A_arbace_j2g_dyn_A_const_557 *lang.Var

var A_arbace_j2g_dyn_A_const_558 any

var A_arbace_j2g_dyn_A_const_559 any

var A_arbace_j2g_dyn_A_const_560 any

var A_arbace_j2g_dyn_A_const_561 any

var A_arbace_j2g_dyn_A_const_562 *lang.Var

var A_arbace_j2g_dyn_A_const_563 *lang.Var

var A_arbace_j2g_dyn_A_const_564 *lang.Var

var A_arbace_j2g_dyn_A_const_565 *lang.Var

var A_arbace_j2g_dyn_A_const_566 *lang.Var

var A_arbace_j2g_dyn_A_const_567 *lang.Var

var A_arbace_j2g_dyn_A_init jrt.ClassInit

func A_arbace_j2g_dyn_A_Init() { if !A_arbace_j2g_dyn_A_init.Done() { A_arbace_j2g_dyn_A_init.Run(A_arbace_j2g_dyn_A_clinit) } }

func A_arbace_j2g_dyn_A_clinit() { A_arbace_j2g_dyn_A_clinit_p0(); A_arbace_j2g_dyn_A_clinit_p1(); A_arbace_j2g_dyn_A_clinit_p2(); A_arbace_j2g_dyn_A_clinit_p3(); A_arbace_j2g_dyn_A_clinit_p4(); A_arbace_j2g_dyn_A_clinit_p5(); A_arbace_j2g_dyn_A_clinit_p6(); A_arbace_j2g_dyn_A_clinit_p7(); A_arbace_j2g_dyn_A_clinit_p8(); A_arbace_j2g_dyn_A_clinit_p9(); A_arbace_j2g_dyn_A_clinit_p10(); A_arbace_j2g_dyn_A_clinit_p11(); A_arbace_j2g_dyn_A_clinit_p12(); A_arbace_j2g_dyn_A_clinit_p13(); A_arbace_j2g_dyn_A_clinit_p14(); A_arbace_j2g_dyn_A_clinit_p15(); A_arbace_j2g_dyn_A_clinit_p16(); A_arbace_j2g_dyn_A_clinit_p17(); A_arbace_j2g_dyn_A_clinit_p18(); A_arbace_j2g_dyn_A_clinit_p19(); A_arbace_j2g_dyn_A_clinit_p20(); A_arbace_j2g_dyn_A_clinit_p21(); A_arbace_j2g_dyn_A_clinit_p22(); A_arbace_j2g_dyn_A_clinit_p23(); A_arbace_j2g_dyn_A_clinit_p24(); A_arbace_j2g_dyn_A_clinit_p25(); A_arbace_j2g_dyn_A_clinit_p26(); A_arbace_j2g_dyn_A_clinit_p27(); A_arbace_j2g_dyn_A_clinit_p28(); A_arbace_j2g_dyn_A_clinit_p29(); A_arbace_j2g_dyn_A_clinit_p30(); A_arbace_j2g_dyn_A_clinit_p31(); A_arbace_j2g_dyn_A_clinit_p32(); A_arbace_j2g_dyn_A_clinit_p33(); A_arbace_j2g_dyn_A_clinit_p34(); A_arbace_j2g_dyn_A_clinit_p35(); A_arbace_j2g_dyn_A_clinit_p36(); A_arbace_j2g_dyn_A_clinit_p37(); A_arbace_j2g_dyn_A_clinit_p38(); A_arbace_j2g_dyn_A_clinit_p39() }

func A_arbace_j2g_dyn_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 847); A_arbace_j2g_dyn_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[279]); A_arbace_j2g_dyn_A_const_1 = A_arbace_j2g_dyn_A_const_pool.A[280]; A_arbace_j2g_dyn_A_const_2 = A_arbace_j2g_dyn_A_const_pool.A[281]; A_arbace_j2g_dyn_A_const_3 = A_arbace_j2g_dyn_A_const_pool.A[282]; A_arbace_j2g_dyn_A_const_4 = A_arbace_j2g_dyn_A_const_pool.A[283]; A_arbace_j2g_dyn_A_const_5 = A_arbace_j2g_dyn_A_const_pool.A[284]; A_arbace_j2g_dyn_A_const_6 = A_arbace_j2g_dyn_A_const_pool.A[285]; A_arbace_j2g_dyn_A_const_7 = A_arbace_j2g_dyn_A_const_pool.A[286]; A_arbace_j2g_dyn_A_const_8 = A_arbace_j2g_dyn_A_const_pool.A[287]; A_arbace_j2g_dyn_A_const_9 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[288]); A_arbace_j2g_dyn_A_const_10 = A_arbace_j2g_dyn_A_const_pool.A[289]; A_arbace_j2g_dyn_A_const_11 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[290]); A_arbace_j2g_dyn_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[291]) }

func A_arbace_j2g_dyn_A_clinit_p1() { A_arbace_j2g_dyn_A_const_13 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[292]); A_arbace_j2g_dyn_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[293]); A_arbace_j2g_dyn_A_const_15 = A_arbace_j2g_dyn_A_const_pool.A[294]; A_arbace_j2g_dyn_A_const_16 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[295]); A_arbace_j2g_dyn_A_const_17 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[296]); A_arbace_j2g_dyn_A_const_18 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[297]); A_arbace_j2g_dyn_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[298]); A_arbace_j2g_dyn_A_const_20 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[299]); A_arbace_j2g_dyn_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[300]); A_arbace_j2g_dyn_A_const_22 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[301]); A_arbace_j2g_dyn_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[302]); A_arbace_j2g_dyn_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[303]) }

func A_arbace_j2g_dyn_A_clinit_p2() { A_arbace_j2g_dyn_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[304]); A_arbace_j2g_dyn_A_const_26 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[305]); A_arbace_j2g_dyn_A_const_27 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[306]); A_arbace_j2g_dyn_A_const_28 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[307]); A_arbace_j2g_dyn_A_const_29 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[308]); A_arbace_j2g_dyn_A_const_30 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[309]); A_arbace_j2g_dyn_A_const_31 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[310]); A_arbace_j2g_dyn_A_const_32 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[311]); A_arbace_j2g_dyn_A_const_33 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[312]); A_arbace_j2g_dyn_A_const_34 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[313]); A_arbace_j2g_dyn_A_const_35 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[314]); A_arbace_j2g_dyn_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[315]) }

func A_arbace_j2g_dyn_A_clinit_p3() { A_arbace_j2g_dyn_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[316]); A_arbace_j2g_dyn_A_const_38 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[317]); A_arbace_j2g_dyn_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[318]); A_arbace_j2g_dyn_A_const_40 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[319]); A_arbace_j2g_dyn_A_const_41 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[320]); A_arbace_j2g_dyn_A_const_42 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[321]); A_arbace_j2g_dyn_A_const_43 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[322]); A_arbace_j2g_dyn_A_const_44 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[323]); A_arbace_j2g_dyn_A_const_45 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[324]); A_arbace_j2g_dyn_A_const_46 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[325]); A_arbace_j2g_dyn_A_const_47 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[326]); A_arbace_j2g_dyn_A_const_48 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[327]) }

func A_arbace_j2g_dyn_A_clinit_p4() { A_arbace_j2g_dyn_A_const_49 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[328]); A_arbace_j2g_dyn_A_const_50 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[329]); A_arbace_j2g_dyn_A_const_51 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[330]); A_arbace_j2g_dyn_A_const_52 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[331]); A_arbace_j2g_dyn_A_const_53 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[332]); A_arbace_j2g_dyn_A_const_54 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[333]); A_arbace_j2g_dyn_A_const_55 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[334]); A_arbace_j2g_dyn_A_const_56 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[335]); A_arbace_j2g_dyn_A_const_57 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[336]); A_arbace_j2g_dyn_A_const_58 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[337]); A_arbace_j2g_dyn_A_const_59 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[338]); A_arbace_j2g_dyn_A_const_60 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[339]) }

func A_arbace_j2g_dyn_A_clinit_p5() { A_arbace_j2g_dyn_A_const_61 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[340]); A_arbace_j2g_dyn_A_const_62 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[341]); A_arbace_j2g_dyn_A_const_63 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[342]); A_arbace_j2g_dyn_A_const_64 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[343]); A_arbace_j2g_dyn_A_const_65 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[344]); A_arbace_j2g_dyn_A_const_66 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[345]); A_arbace_j2g_dyn_A_const_67 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[346]); A_arbace_j2g_dyn_A_const_68 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[347]); A_arbace_j2g_dyn_A_const_69 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[348]); A_arbace_j2g_dyn_A_const_70 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[349]); A_arbace_j2g_dyn_A_const_71 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[350]); A_arbace_j2g_dyn_A_const_72 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[351]) }

func A_arbace_j2g_dyn_A_clinit_p6() { A_arbace_j2g_dyn_A_const_73 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[352]); A_arbace_j2g_dyn_A_const_74 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[353]); A_arbace_j2g_dyn_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[354]); A_arbace_j2g_dyn_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[355]); A_arbace_j2g_dyn_A_const_77 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[356]); A_arbace_j2g_dyn_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[357]); A_arbace_j2g_dyn_A_const_79 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[358]); A_arbace_j2g_dyn_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[359]); A_arbace_j2g_dyn_A_const_81 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[360]); A_arbace_j2g_dyn_A_const_82 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[361]); A_arbace_j2g_dyn_A_const_83 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[362]); A_arbace_j2g_dyn_A_const_84 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[363]) }

func A_arbace_j2g_dyn_A_clinit_p7() { A_arbace_j2g_dyn_A_const_85 = A_arbace_j2g_dyn_A_const_pool.A[364]; A_arbace_j2g_dyn_A_const_86 = A_arbace_j2g_dyn_A_const_pool.A[365]; A_arbace_j2g_dyn_A_const_87 = A_arbace_j2g_dyn_A_const_pool.A[366]; A_arbace_j2g_dyn_A_const_88 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[367]); A_arbace_j2g_dyn_A_const_89 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[368]); A_arbace_j2g_dyn_A_const_90 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[369]); A_arbace_j2g_dyn_A_const_91 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[370]); A_arbace_j2g_dyn_A_const_92 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[371]); A_arbace_j2g_dyn_A_const_93 = A_arbace_j2g_dyn_A_const_pool.A[372]; A_arbace_j2g_dyn_A_const_94 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[373]); A_arbace_j2g_dyn_A_const_95 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[374]); A_arbace_j2g_dyn_A_const_96 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[375]); A_arbace_j2g_dyn_A_const_97 = A_arbace_j2g_dyn_A_const_pool.A[376] }

func A_arbace_j2g_dyn_A_clinit_p8() { A_arbace_j2g_dyn_A_const_98 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[377]); A_arbace_j2g_dyn_A_const_99 = A_arbace_j2g_dyn_A_const_pool.A[378]; A_arbace_j2g_dyn_A_const_100 = A_arbace_j2g_dyn_A_const_pool.A[379]; A_arbace_j2g_dyn_A_const_101 = A_arbace_j2g_dyn_A_const_pool.A[380]; A_arbace_j2g_dyn_A_const_102 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[381]); A_arbace_j2g_dyn_A_const_103 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[382]); A_arbace_j2g_dyn_A_const_104 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[383]); A_arbace_j2g_dyn_A_const_105 = A_arbace_j2g_dyn_A_const_pool.A[384]; A_arbace_j2g_dyn_A_const_106 = A_arbace_j2g_dyn_A_const_pool.A[385]; A_arbace_j2g_dyn_A_const_107 = A_arbace_j2g_dyn_A_const_pool.A[386]; A_arbace_j2g_dyn_A_const_108 = A_arbace_j2g_dyn_A_const_pool.A[387]; A_arbace_j2g_dyn_A_const_109 = A_arbace_j2g_dyn_A_const_pool.A[388]; A_arbace_j2g_dyn_A_const_110 = A_arbace_j2g_dyn_A_const_pool.A[389]; A_arbace_j2g_dyn_A_const_111 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[390]) }

func A_arbace_j2g_dyn_A_clinit_p9() { A_arbace_j2g_dyn_A_const_112 = A_arbace_j2g_dyn_A_const_pool.A[391]; A_arbace_j2g_dyn_A_const_113 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[392]); A_arbace_j2g_dyn_A_const_114 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[393]); A_arbace_j2g_dyn_A_const_115 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[394]); A_arbace_j2g_dyn_A_const_116 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[395]); A_arbace_j2g_dyn_A_const_117 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[396]); A_arbace_j2g_dyn_A_const_118 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[397]); A_arbace_j2g_dyn_A_const_119 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[398]); A_arbace_j2g_dyn_A_const_120 = A_arbace_j2g_dyn_A_const_pool.A[399]; A_arbace_j2g_dyn_A_const_121 = A_arbace_j2g_dyn_A_const_pool.A[400]; A_arbace_j2g_dyn_A_const_122 = A_arbace_j2g_dyn_A_const_pool.A[401]; A_arbace_j2g_dyn_A_const_123 = A_arbace_j2g_dyn_A_const_pool.A[402]; A_arbace_j2g_dyn_A_const_124 = A_arbace_j2g_dyn_A_const_pool.A[403] }

func A_arbace_j2g_dyn_A_clinit_p10() { A_arbace_j2g_dyn_A_const_125 = A_arbace_j2g_dyn_A_const_pool.A[404]; A_arbace_j2g_dyn_A_const_126 = A_arbace_j2g_dyn_A_const_pool.A[405]; A_arbace_j2g_dyn_A_const_127 = A_arbace_j2g_dyn_A_const_pool.A[406]; A_arbace_j2g_dyn_A_const_128 = A_arbace_j2g_dyn_A_const_pool.A[407]; A_arbace_j2g_dyn_A_const_129 = A_arbace_j2g_dyn_A_const_pool.A[408]; A_arbace_j2g_dyn_A_const_130 = A_arbace_j2g_dyn_A_const_pool.A[409]; A_arbace_j2g_dyn_A_const_131 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[410]); A_arbace_j2g_dyn_A_const_132 = A_arbace_j2g_dyn_A_const_pool.A[411]; A_arbace_j2g_dyn_A_const_133 = A_arbace_j2g_dyn_A_const_pool.A[412]; A_arbace_j2g_dyn_A_const_134 = A_arbace_j2g_dyn_A_const_pool.A[413]; A_arbace_j2g_dyn_A_const_135 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[414]); A_arbace_j2g_dyn_A_const_136 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[415]); A_arbace_j2g_dyn_A_const_137 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[416]); A_arbace_j2g_dyn_A_const_138 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[417]) }

func A_arbace_j2g_dyn_A_clinit_p11() { A_arbace_j2g_dyn_A_const_139 = A_arbace_j2g_dyn_A_const_pool.A[418]; A_arbace_j2g_dyn_A_const_140 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[419]); A_arbace_j2g_dyn_A_const_141 = A_arbace_j2g_dyn_A_const_pool.A[420]; A_arbace_j2g_dyn_A_const_142 = A_arbace_j2g_dyn_A_const_pool.A[421]; A_arbace_j2g_dyn_A_const_143 = A_arbace_j2g_dyn_A_const_pool.A[422]; A_arbace_j2g_dyn_A_const_144 = A_arbace_j2g_dyn_A_const_pool.A[423]; A_arbace_j2g_dyn_A_const_145 = A_arbace_j2g_dyn_A_const_pool.A[424]; A_arbace_j2g_dyn_A_const_146 = A_arbace_j2g_dyn_A_const_pool.A[425]; A_arbace_j2g_dyn_A_const_147 = A_arbace_j2g_dyn_A_const_pool.A[426]; A_arbace_j2g_dyn_A_const_148 = A_arbace_j2g_dyn_A_const_pool.A[427]; A_arbace_j2g_dyn_A_const_149 = A_arbace_j2g_dyn_A_const_pool.A[428]; A_arbace_j2g_dyn_A_const_150 = A_arbace_j2g_dyn_A_const_pool.A[429]; A_arbace_j2g_dyn_A_const_151 = A_arbace_j2g_dyn_A_const_pool.A[430]; A_arbace_j2g_dyn_A_const_152 = A_arbace_j2g_dyn_A_const_pool.A[431]; A_arbace_j2g_dyn_A_const_153 = A_arbace_j2g_dyn_A_const_pool.A[432] }

func A_arbace_j2g_dyn_A_clinit_p12() { A_arbace_j2g_dyn_A_const_154 = A_arbace_j2g_dyn_A_const_pool.A[433]; A_arbace_j2g_dyn_A_const_155 = A_arbace_j2g_dyn_A_const_pool.A[434]; A_arbace_j2g_dyn_A_const_156 = A_arbace_j2g_dyn_A_const_pool.A[435]; A_arbace_j2g_dyn_A_const_157 = A_arbace_j2g_dyn_A_const_pool.A[436]; A_arbace_j2g_dyn_A_const_158 = A_arbace_j2g_dyn_A_const_pool.A[437]; A_arbace_j2g_dyn_A_const_159 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[438]); A_arbace_j2g_dyn_A_const_160 = A_arbace_j2g_dyn_A_const_pool.A[439]; A_arbace_j2g_dyn_A_const_161 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[440]); A_arbace_j2g_dyn_A_const_162 = A_arbace_j2g_dyn_A_const_pool.A[441]; A_arbace_j2g_dyn_A_const_163 = A_arbace_j2g_dyn_A_const_pool.A[442]; A_arbace_j2g_dyn_A_const_164 = A_arbace_j2g_dyn_A_const_pool.A[443]; A_arbace_j2g_dyn_A_const_165 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[444]); A_arbace_j2g_dyn_A_const_166 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[445]); A_arbace_j2g_dyn_A_const_167 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[446]) }

func A_arbace_j2g_dyn_A_clinit_p13() { A_arbace_j2g_dyn_A_const_168 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[447]); A_arbace_j2g_dyn_A_const_169 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[448]); A_arbace_j2g_dyn_A_const_170 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[449]); A_arbace_j2g_dyn_A_const_171 = A_arbace_j2g_dyn_A_const_pool.A[450]; A_arbace_j2g_dyn_A_const_172 = A_arbace_j2g_dyn_A_const_pool.A[451]; A_arbace_j2g_dyn_A_const_173 = A_arbace_j2g_dyn_A_const_pool.A[452]; A_arbace_j2g_dyn_A_const_174 = A_arbace_j2g_dyn_A_const_pool.A[453]; A_arbace_j2g_dyn_A_const_175 = A_arbace_j2g_dyn_A_const_pool.A[454]; A_arbace_j2g_dyn_A_const_176 = A_arbace_j2g_dyn_A_const_pool.A[455]; A_arbace_j2g_dyn_A_const_177 = A_arbace_j2g_dyn_A_const_pool.A[456]; A_arbace_j2g_dyn_A_const_178 = A_arbace_j2g_dyn_A_const_pool.A[457]; A_arbace_j2g_dyn_A_const_179 = A_arbace_j2g_dyn_A_const_pool.A[458]; A_arbace_j2g_dyn_A_const_180 = A_arbace_j2g_dyn_A_const_pool.A[459]; A_arbace_j2g_dyn_A_const_181 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[460]) }

func A_arbace_j2g_dyn_A_clinit_p14() { A_arbace_j2g_dyn_A_const_182 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[461]); A_arbace_j2g_dyn_A_const_183 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[462]); A_arbace_j2g_dyn_A_const_184 = A_arbace_j2g_dyn_A_const_pool.A[463]; A_arbace_j2g_dyn_A_const_185 = A_arbace_j2g_dyn_A_const_pool.A[464]; A_arbace_j2g_dyn_A_const_186 = A_arbace_j2g_dyn_A_const_pool.A[465]; A_arbace_j2g_dyn_A_const_187 = A_arbace_j2g_dyn_A_const_pool.A[466]; A_arbace_j2g_dyn_A_const_188 = A_arbace_j2g_dyn_A_const_pool.A[467]; A_arbace_j2g_dyn_A_const_189 = A_arbace_j2g_dyn_A_const_pool.A[468]; A_arbace_j2g_dyn_A_const_190 = A_arbace_j2g_dyn_A_const_pool.A[469]; A_arbace_j2g_dyn_A_const_191 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[470]); A_arbace_j2g_dyn_A_const_192 = A_arbace_j2g_dyn_A_const_pool.A[471]; A_arbace_j2g_dyn_A_const_193 = A_arbace_j2g_dyn_A_const_pool.A[472]; A_arbace_j2g_dyn_A_const_194 = A_arbace_j2g_dyn_A_const_pool.A[473]; A_arbace_j2g_dyn_A_const_195 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[474]) }

func A_arbace_j2g_dyn_A_clinit_p15() { A_arbace_j2g_dyn_A_const_196 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[475]); A_arbace_j2g_dyn_A_const_197 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[476]); A_arbace_j2g_dyn_A_const_198 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[477]); A_arbace_j2g_dyn_A_const_199 = A_arbace_j2g_dyn_A_const_pool.A[478]; A_arbace_j2g_dyn_A_const_200 = A_arbace_j2g_dyn_A_const_pool.A[479]; A_arbace_j2g_dyn_A_const_201 = A_arbace_j2g_dyn_A_const_pool.A[480]; A_arbace_j2g_dyn_A_const_202 = A_arbace_j2g_dyn_A_const_pool.A[481]; A_arbace_j2g_dyn_A_const_203 = A_arbace_j2g_dyn_A_const_pool.A[482]; A_arbace_j2g_dyn_A_const_204 = A_arbace_j2g_dyn_A_const_pool.A[483]; A_arbace_j2g_dyn_A_const_205 = A_arbace_j2g_dyn_A_const_pool.A[484]; A_arbace_j2g_dyn_A_const_206 = A_arbace_j2g_dyn_A_const_pool.A[485]; A_arbace_j2g_dyn_A_const_207 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[486]); A_arbace_j2g_dyn_A_const_208 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[487]); A_arbace_j2g_dyn_A_const_209 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[488]) }

func A_arbace_j2g_dyn_A_clinit_p16() { A_arbace_j2g_dyn_A_const_210 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[489]); A_arbace_j2g_dyn_A_const_211 = A_arbace_j2g_dyn_A_const_pool.A[490]; A_arbace_j2g_dyn_A_const_212 = A_arbace_j2g_dyn_A_const_pool.A[491]; A_arbace_j2g_dyn_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[492]); A_arbace_j2g_dyn_A_const_214 = A_arbace_j2g_dyn_A_const_pool.A[493]; A_arbace_j2g_dyn_A_const_215 = A_arbace_j2g_dyn_A_const_pool.A[494]; A_arbace_j2g_dyn_A_const_216 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[495]); A_arbace_j2g_dyn_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[496]); A_arbace_j2g_dyn_A_const_218 = A_arbace_j2g_dyn_A_const_pool.A[497]; A_arbace_j2g_dyn_A_const_219 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[498]); A_arbace_j2g_dyn_A_const_220 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[499]); A_arbace_j2g_dyn_A_const_221 = A_arbace_j2g_dyn_A_const_pool.A[500]; A_arbace_j2g_dyn_A_const_222 = A_arbace_j2g_dyn_A_const_pool.A[501]; A_arbace_j2g_dyn_A_const_223 = A_arbace_j2g_dyn_A_const_pool.A[502] }

func A_arbace_j2g_dyn_A_clinit_p17() { A_arbace_j2g_dyn_A_const_224 = A_arbace_j2g_dyn_A_const_pool.A[503]; A_arbace_j2g_dyn_A_const_225 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[504]); A_arbace_j2g_dyn_A_const_226 = A_arbace_j2g_dyn_A_const_pool.A[505]; A_arbace_j2g_dyn_A_const_227 = A_arbace_j2g_dyn_A_const_pool.A[506]; A_arbace_j2g_dyn_A_const_228 = A_arbace_j2g_dyn_A_const_pool.A[507]; A_arbace_j2g_dyn_A_const_229 = A_arbace_j2g_dyn_A_const_pool.A[508]; A_arbace_j2g_dyn_A_const_230 = A_arbace_j2g_dyn_A_const_pool.A[509]; A_arbace_j2g_dyn_A_const_231 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[510]); A_arbace_j2g_dyn_A_const_232 = A_arbace_j2g_dyn_A_const_pool.A[511]; A_arbace_j2g_dyn_A_const_233 = A_arbace_j2g_dyn_A_const_pool.A[512]; A_arbace_j2g_dyn_A_const_234 = A_arbace_j2g_dyn_A_const_pool.A[513]; A_arbace_j2g_dyn_A_const_235 = A_arbace_j2g_dyn_A_const_pool.A[514]; A_arbace_j2g_dyn_A_const_236 = A_arbace_j2g_dyn_A_const_pool.A[515]; A_arbace_j2g_dyn_A_const_237 = A_arbace_j2g_dyn_A_const_pool.A[516]; A_arbace_j2g_dyn_A_const_238 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[517]) }

func A_arbace_j2g_dyn_A_clinit_p18() { A_arbace_j2g_dyn_A_const_239 = A_arbace_j2g_dyn_A_const_pool.A[518]; A_arbace_j2g_dyn_A_const_240 = A_arbace_j2g_dyn_A_const_pool.A[519]; A_arbace_j2g_dyn_A_const_241 = A_arbace_j2g_dyn_A_const_pool.A[520]; A_arbace_j2g_dyn_A_const_242 = A_arbace_j2g_dyn_A_const_pool.A[521]; A_arbace_j2g_dyn_A_const_243 = A_arbace_j2g_dyn_A_const_pool.A[522]; A_arbace_j2g_dyn_A_const_244 = A_arbace_j2g_dyn_A_const_pool.A[523]; A_arbace_j2g_dyn_A_const_245 = A_arbace_j2g_dyn_A_const_pool.A[524]; A_arbace_j2g_dyn_A_const_246 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[525]); A_arbace_j2g_dyn_A_const_247 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[526]); A_arbace_j2g_dyn_A_const_248 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[527]); A_arbace_j2g_dyn_A_const_249 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[528]); A_arbace_j2g_dyn_A_const_250 = A_arbace_j2g_dyn_A_const_pool.A[529]; A_arbace_j2g_dyn_A_const_251 = A_arbace_j2g_dyn_A_const_pool.A[530]; A_arbace_j2g_dyn_A_const_252 = A_arbace_j2g_dyn_A_const_pool.A[531] }

func A_arbace_j2g_dyn_A_clinit_p19() { A_arbace_j2g_dyn_A_const_253 = A_arbace_j2g_dyn_A_const_pool.A[532]; A_arbace_j2g_dyn_A_const_254 = A_arbace_j2g_dyn_A_const_pool.A[533]; A_arbace_j2g_dyn_A_const_255 = A_arbace_j2g_dyn_A_const_pool.A[534]; A_arbace_j2g_dyn_A_const_256 = A_arbace_j2g_dyn_A_const_pool.A[535]; A_arbace_j2g_dyn_A_const_257 = A_arbace_j2g_dyn_A_const_pool.A[536]; A_arbace_j2g_dyn_A_const_258 = A_arbace_j2g_dyn_A_const_pool.A[537]; A_arbace_j2g_dyn_A_const_259 = A_arbace_j2g_dyn_A_const_pool.A[538]; A_arbace_j2g_dyn_A_const_260 = A_arbace_j2g_dyn_A_const_pool.A[539]; A_arbace_j2g_dyn_A_const_261 = A_arbace_j2g_dyn_A_const_pool.A[540]; A_arbace_j2g_dyn_A_const_262 = A_arbace_j2g_dyn_A_const_pool.A[541]; A_arbace_j2g_dyn_A_const_263 = A_arbace_j2g_dyn_A_const_pool.A[542]; A_arbace_j2g_dyn_A_const_264 = A_arbace_j2g_dyn_A_const_pool.A[543]; A_arbace_j2g_dyn_A_const_265 = A_arbace_j2g_dyn_A_const_pool.A[544]; A_arbace_j2g_dyn_A_const_266 = A_arbace_j2g_dyn_A_const_pool.A[545]; A_arbace_j2g_dyn_A_const_267 = A_arbace_j2g_dyn_A_const_pool.A[546]; A_arbace_j2g_dyn_A_const_268 = A_arbace_j2g_dyn_A_const_pool.A[547] }

func A_arbace_j2g_dyn_A_clinit_p20() { A_arbace_j2g_dyn_A_const_269 = A_arbace_j2g_dyn_A_const_pool.A[548]; A_arbace_j2g_dyn_A_const_270 = A_arbace_j2g_dyn_A_const_pool.A[549]; A_arbace_j2g_dyn_A_const_271 = A_arbace_j2g_dyn_A_const_pool.A[550]; A_arbace_j2g_dyn_A_const_272 = A_arbace_j2g_dyn_A_const_pool.A[551]; A_arbace_j2g_dyn_A_const_273 = A_arbace_j2g_dyn_A_const_pool.A[552]; A_arbace_j2g_dyn_A_const_274 = A_arbace_j2g_dyn_A_const_pool.A[553]; A_arbace_j2g_dyn_A_const_275 = A_arbace_j2g_dyn_A_const_pool.A[554]; A_arbace_j2g_dyn_A_const_276 = A_arbace_j2g_dyn_A_const_pool.A[555]; A_arbace_j2g_dyn_A_const_277 = A_arbace_j2g_dyn_A_const_pool.A[556]; A_arbace_j2g_dyn_A_const_278 = A_arbace_j2g_dyn_A_const_pool.A[557]; A_arbace_j2g_dyn_A_const_279 = A_arbace_j2g_dyn_A_const_pool.A[558]; A_arbace_j2g_dyn_A_const_280 = A_arbace_j2g_dyn_A_const_pool.A[559]; A_arbace_j2g_dyn_A_const_281 = A_arbace_j2g_dyn_A_const_pool.A[560]; A_arbace_j2g_dyn_A_const_282 = A_arbace_j2g_dyn_A_const_pool.A[561]; A_arbace_j2g_dyn_A_const_283 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[562]) }

func A_arbace_j2g_dyn_A_clinit_p21() { A_arbace_j2g_dyn_A_const_284 = A_arbace_j2g_dyn_A_const_pool.A[563]; A_arbace_j2g_dyn_A_const_285 = A_arbace_j2g_dyn_A_const_pool.A[564]; A_arbace_j2g_dyn_A_const_286 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[565]); A_arbace_j2g_dyn_A_const_287 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[566]); A_arbace_j2g_dyn_A_const_288 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[567]); A_arbace_j2g_dyn_A_const_289 = A_arbace_j2g_dyn_A_const_pool.A[568]; A_arbace_j2g_dyn_A_const_290 = A_arbace_j2g_dyn_A_const_pool.A[569]; A_arbace_j2g_dyn_A_const_291 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[570]); A_arbace_j2g_dyn_A_const_292 = A_arbace_j2g_dyn_A_const_pool.A[571]; A_arbace_j2g_dyn_A_const_293 = A_arbace_j2g_dyn_A_const_pool.A[572]; A_arbace_j2g_dyn_A_const_294 = A_arbace_j2g_dyn_A_const_pool.A[573]; A_arbace_j2g_dyn_A_const_295 = A_arbace_j2g_dyn_A_const_pool.A[574]; A_arbace_j2g_dyn_A_const_296 = A_arbace_j2g_dyn_A_const_pool.A[575]; A_arbace_j2g_dyn_A_const_297 = A_arbace_j2g_dyn_A_const_pool.A[576] }

func A_arbace_j2g_dyn_A_clinit_p22() { A_arbace_j2g_dyn_A_const_298 = A_arbace_j2g_dyn_A_const_pool.A[577]; A_arbace_j2g_dyn_A_const_299 = A_arbace_j2g_dyn_A_const_pool.A[578]; A_arbace_j2g_dyn_A_const_300 = A_arbace_j2g_dyn_A_const_pool.A[579]; A_arbace_j2g_dyn_A_const_301 = A_arbace_j2g_dyn_A_const_pool.A[580]; A_arbace_j2g_dyn_A_const_302 = A_arbace_j2g_dyn_A_const_pool.A[581]; A_arbace_j2g_dyn_A_const_303 = A_arbace_j2g_dyn_A_const_pool.A[582]; A_arbace_j2g_dyn_A_const_304 = A_arbace_j2g_dyn_A_const_pool.A[583]; A_arbace_j2g_dyn_A_const_305 = A_arbace_j2g_dyn_A_const_pool.A[584]; A_arbace_j2g_dyn_A_const_306 = A_arbace_j2g_dyn_A_const_pool.A[585]; A_arbace_j2g_dyn_A_const_307 = A_arbace_j2g_dyn_A_const_pool.A[586]; A_arbace_j2g_dyn_A_const_308 = A_arbace_j2g_dyn_A_const_pool.A[587]; A_arbace_j2g_dyn_A_const_309 = A_arbace_j2g_dyn_A_const_pool.A[588]; A_arbace_j2g_dyn_A_const_310 = A_arbace_j2g_dyn_A_const_pool.A[589]; A_arbace_j2g_dyn_A_const_311 = A_arbace_j2g_dyn_A_const_pool.A[590]; A_arbace_j2g_dyn_A_const_312 = A_arbace_j2g_dyn_A_const_pool.A[591]; A_arbace_j2g_dyn_A_const_313 = A_arbace_j2g_dyn_A_const_pool.A[592] }

func A_arbace_j2g_dyn_A_clinit_p23() { A_arbace_j2g_dyn_A_const_314 = A_arbace_j2g_dyn_A_const_pool.A[593]; A_arbace_j2g_dyn_A_const_315 = A_arbace_j2g_dyn_A_const_pool.A[594]; A_arbace_j2g_dyn_A_const_316 = A_arbace_j2g_dyn_A_const_pool.A[595]; A_arbace_j2g_dyn_A_const_317 = A_arbace_j2g_dyn_A_const_pool.A[596]; A_arbace_j2g_dyn_A_const_318 = A_arbace_j2g_dyn_A_const_pool.A[597]; A_arbace_j2g_dyn_A_const_319 = A_arbace_j2g_dyn_A_const_pool.A[598]; A_arbace_j2g_dyn_A_const_320 = A_arbace_j2g_dyn_A_const_pool.A[599]; A_arbace_j2g_dyn_A_const_321 = A_arbace_j2g_dyn_A_const_pool.A[600]; A_arbace_j2g_dyn_A_const_322 = A_arbace_j2g_dyn_A_const_pool.A[601]; A_arbace_j2g_dyn_A_const_323 = A_arbace_j2g_dyn_A_const_pool.A[602]; A_arbace_j2g_dyn_A_const_324 = A_arbace_j2g_dyn_A_const_pool.A[603]; A_arbace_j2g_dyn_A_const_325 = A_arbace_j2g_dyn_A_const_pool.A[604]; A_arbace_j2g_dyn_A_const_326 = A_arbace_j2g_dyn_A_const_pool.A[605]; A_arbace_j2g_dyn_A_const_327 = A_arbace_j2g_dyn_A_const_pool.A[606]; A_arbace_j2g_dyn_A_const_328 = A_arbace_j2g_dyn_A_const_pool.A[607]; A_arbace_j2g_dyn_A_const_329 = A_arbace_j2g_dyn_A_const_pool.A[608] }

func A_arbace_j2g_dyn_A_clinit_p24() { A_arbace_j2g_dyn_A_const_330 = A_arbace_j2g_dyn_A_const_pool.A[609]; A_arbace_j2g_dyn_A_const_331 = A_arbace_j2g_dyn_A_const_pool.A[610]; A_arbace_j2g_dyn_A_const_332 = A_arbace_j2g_dyn_A_const_pool.A[611]; A_arbace_j2g_dyn_A_const_333 = A_arbace_j2g_dyn_A_const_pool.A[612]; A_arbace_j2g_dyn_A_const_334 = A_arbace_j2g_dyn_A_const_pool.A[613]; A_arbace_j2g_dyn_A_const_335 = A_arbace_j2g_dyn_A_const_pool.A[614]; A_arbace_j2g_dyn_A_const_336 = A_arbace_j2g_dyn_A_const_pool.A[615]; A_arbace_j2g_dyn_A_const_337 = A_arbace_j2g_dyn_A_const_pool.A[616]; A_arbace_j2g_dyn_A_const_338 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[617]); A_arbace_j2g_dyn_A_const_339 = A_arbace_j2g_dyn_A_const_pool.A[618]; A_arbace_j2g_dyn_A_const_340 = A_arbace_j2g_dyn_A_const_pool.A[619]; A_arbace_j2g_dyn_A_const_341 = A_arbace_j2g_dyn_A_const_pool.A[620]; A_arbace_j2g_dyn_A_const_342 = A_arbace_j2g_dyn_A_const_pool.A[621]; A_arbace_j2g_dyn_A_const_343 = A_arbace_j2g_dyn_A_const_pool.A[622]; A_arbace_j2g_dyn_A_const_344 = A_arbace_j2g_dyn_A_const_pool.A[623] }

func A_arbace_j2g_dyn_A_clinit_p25() { A_arbace_j2g_dyn_A_const_345 = A_arbace_j2g_dyn_A_const_pool.A[624]; A_arbace_j2g_dyn_A_const_346 = A_arbace_j2g_dyn_A_const_pool.A[625]; A_arbace_j2g_dyn_A_const_347 = A_arbace_j2g_dyn_A_const_pool.A[626]; A_arbace_j2g_dyn_A_const_348 = A_arbace_j2g_dyn_A_const_pool.A[627]; A_arbace_j2g_dyn_A_const_349 = A_arbace_j2g_dyn_A_const_pool.A[628]; A_arbace_j2g_dyn_A_const_350 = A_arbace_j2g_dyn_A_const_pool.A[629]; A_arbace_j2g_dyn_A_const_351 = A_arbace_j2g_dyn_A_const_pool.A[630]; A_arbace_j2g_dyn_A_const_352 = A_arbace_j2g_dyn_A_const_pool.A[631]; A_arbace_j2g_dyn_A_const_353 = A_arbace_j2g_dyn_A_const_pool.A[632]; A_arbace_j2g_dyn_A_const_354 = A_arbace_j2g_dyn_A_const_pool.A[633]; A_arbace_j2g_dyn_A_const_355 = A_arbace_j2g_dyn_A_const_pool.A[634]; A_arbace_j2g_dyn_A_const_356 = A_arbace_j2g_dyn_A_const_pool.A[635]; A_arbace_j2g_dyn_A_const_357 = A_arbace_j2g_dyn_A_const_pool.A[636]; A_arbace_j2g_dyn_A_const_358 = A_arbace_j2g_dyn_A_const_pool.A[637]; A_arbace_j2g_dyn_A_const_359 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[638]) }

func A_arbace_j2g_dyn_A_clinit_p26() { A_arbace_j2g_dyn_A_const_360 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[639]); A_arbace_j2g_dyn_A_const_361 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[640]); A_arbace_j2g_dyn_A_const_362 = A_arbace_j2g_dyn_A_const_pool.A[641]; A_arbace_j2g_dyn_A_const_363 = A_arbace_j2g_dyn_A_const_pool.A[642]; A_arbace_j2g_dyn_A_const_364 = A_arbace_j2g_dyn_A_const_pool.A[643]; A_arbace_j2g_dyn_A_const_365 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[644]); A_arbace_j2g_dyn_A_const_366 = A_arbace_j2g_dyn_A_const_pool.A[645]; A_arbace_j2g_dyn_A_const_367 = A_arbace_j2g_dyn_A_const_pool.A[646]; A_arbace_j2g_dyn_A_const_368 = A_arbace_j2g_dyn_A_const_pool.A[647]; A_arbace_j2g_dyn_A_const_369 = A_arbace_j2g_dyn_A_const_pool.A[648]; A_arbace_j2g_dyn_A_const_370 = A_arbace_j2g_dyn_A_const_pool.A[649]; A_arbace_j2g_dyn_A_const_371 = A_arbace_j2g_dyn_A_const_pool.A[650]; A_arbace_j2g_dyn_A_const_372 = A_arbace_j2g_dyn_A_const_pool.A[651]; A_arbace_j2g_dyn_A_const_373 = A_arbace_j2g_dyn_A_const_pool.A[652]; A_arbace_j2g_dyn_A_const_374 = A_arbace_j2g_dyn_A_const_pool.A[653] }

func A_arbace_j2g_dyn_A_clinit_p27() { A_arbace_j2g_dyn_A_const_375 = A_arbace_j2g_dyn_A_const_pool.A[654]; A_arbace_j2g_dyn_A_const_376 = A_arbace_j2g_dyn_A_const_pool.A[655]; A_arbace_j2g_dyn_A_const_377 = A_arbace_j2g_dyn_A_const_pool.A[656]; A_arbace_j2g_dyn_A_const_378 = A_arbace_j2g_dyn_A_const_pool.A[657]; A_arbace_j2g_dyn_A_const_379 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[658]); A_arbace_j2g_dyn_A_const_380 = A_arbace_j2g_dyn_A_const_pool.A[659]; A_arbace_j2g_dyn_A_const_381 = A_arbace_j2g_dyn_A_const_pool.A[660]; A_arbace_j2g_dyn_A_const_382 = A_arbace_j2g_dyn_A_const_pool.A[661]; A_arbace_j2g_dyn_A_const_383 = A_arbace_j2g_dyn_A_const_pool.A[662]; A_arbace_j2g_dyn_A_const_384 = A_arbace_j2g_dyn_A_const_pool.A[663]; A_arbace_j2g_dyn_A_const_385 = A_arbace_j2g_dyn_A_const_pool.A[664]; A_arbace_j2g_dyn_A_const_386 = A_arbace_j2g_dyn_A_const_pool.A[665]; A_arbace_j2g_dyn_A_const_387 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[666]); A_arbace_j2g_dyn_A_const_388 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[667]); A_arbace_j2g_dyn_A_const_389 = A_arbace_j2g_dyn_A_const_pool.A[668] }

func A_arbace_j2g_dyn_A_clinit_p28() { A_arbace_j2g_dyn_A_const_390 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[669]); A_arbace_j2g_dyn_A_const_391 = A_arbace_j2g_dyn_A_const_pool.A[670]; A_arbace_j2g_dyn_A_const_392 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[671]); A_arbace_j2g_dyn_A_const_393 = A_arbace_j2g_dyn_A_const_pool.A[672]; A_arbace_j2g_dyn_A_const_394 = A_arbace_j2g_dyn_A_const_pool.A[673]; A_arbace_j2g_dyn_A_const_395 = A_arbace_j2g_dyn_A_const_pool.A[674]; A_arbace_j2g_dyn_A_const_396 = A_arbace_j2g_dyn_A_const_pool.A[675]; A_arbace_j2g_dyn_A_const_397 = A_arbace_j2g_dyn_A_const_pool.A[676]; A_arbace_j2g_dyn_A_const_398 = A_arbace_j2g_dyn_A_const_pool.A[677]; A_arbace_j2g_dyn_A_const_399 = A_arbace_j2g_dyn_A_const_pool.A[678]; A_arbace_j2g_dyn_A_const_400 = A_arbace_j2g_dyn_A_const_pool.A[679]; A_arbace_j2g_dyn_A_const_401 = A_arbace_j2g_dyn_A_const_pool.A[680]; A_arbace_j2g_dyn_A_const_402 = A_arbace_j2g_dyn_A_const_pool.A[681]; A_arbace_j2g_dyn_A_const_403 = A_arbace_j2g_dyn_A_const_pool.A[682]; A_arbace_j2g_dyn_A_const_404 = A_arbace_j2g_dyn_A_const_pool.A[683] }

func A_arbace_j2g_dyn_A_clinit_p29() { A_arbace_j2g_dyn_A_const_405 = A_arbace_j2g_dyn_A_const_pool.A[684]; A_arbace_j2g_dyn_A_const_406 = A_arbace_j2g_dyn_A_const_pool.A[685]; A_arbace_j2g_dyn_A_const_407 = A_arbace_j2g_dyn_A_const_pool.A[686]; A_arbace_j2g_dyn_A_const_408 = A_arbace_j2g_dyn_A_const_pool.A[687]; A_arbace_j2g_dyn_A_const_409 = A_arbace_j2g_dyn_A_const_pool.A[688]; A_arbace_j2g_dyn_A_const_410 = A_arbace_j2g_dyn_A_const_pool.A[689]; A_arbace_j2g_dyn_A_const_411 = A_arbace_j2g_dyn_A_const_pool.A[690]; A_arbace_j2g_dyn_A_const_412 = A_arbace_j2g_dyn_A_const_pool.A[691]; A_arbace_j2g_dyn_A_const_413 = A_arbace_j2g_dyn_A_const_pool.A[692]; A_arbace_j2g_dyn_A_const_414 = A_arbace_j2g_dyn_A_const_pool.A[693]; A_arbace_j2g_dyn_A_const_415 = A_arbace_j2g_dyn_A_const_pool.A[694]; A_arbace_j2g_dyn_A_const_416 = A_arbace_j2g_dyn_A_const_pool.A[695]; A_arbace_j2g_dyn_A_const_417 = A_arbace_j2g_dyn_A_const_pool.A[696]; A_arbace_j2g_dyn_A_const_418 = A_arbace_j2g_dyn_A_const_pool.A[697]; A_arbace_j2g_dyn_A_const_419 = A_arbace_j2g_dyn_A_const_pool.A[698]; A_arbace_j2g_dyn_A_const_420 = A_arbace_j2g_dyn_A_const_pool.A[699] }

func A_arbace_j2g_dyn_A_clinit_p30() { A_arbace_j2g_dyn_A_const_421 = A_arbace_j2g_dyn_A_const_pool.A[700]; A_arbace_j2g_dyn_A_const_422 = A_arbace_j2g_dyn_A_const_pool.A[701]; A_arbace_j2g_dyn_A_const_423 = A_arbace_j2g_dyn_A_const_pool.A[702]; A_arbace_j2g_dyn_A_const_424 = A_arbace_j2g_dyn_A_const_pool.A[703]; A_arbace_j2g_dyn_A_const_425 = A_arbace_j2g_dyn_A_const_pool.A[704]; A_arbace_j2g_dyn_A_const_426 = A_arbace_j2g_dyn_A_const_pool.A[705]; A_arbace_j2g_dyn_A_const_427 = A_arbace_j2g_dyn_A_const_pool.A[706]; A_arbace_j2g_dyn_A_const_428 = A_arbace_j2g_dyn_A_const_pool.A[707]; A_arbace_j2g_dyn_A_const_429 = A_arbace_j2g_dyn_A_const_pool.A[708]; A_arbace_j2g_dyn_A_const_430 = A_arbace_j2g_dyn_A_const_pool.A[709]; A_arbace_j2g_dyn_A_const_431 = A_arbace_j2g_dyn_A_const_pool.A[710]; A_arbace_j2g_dyn_A_const_432 = A_arbace_j2g_dyn_A_const_pool.A[711]; A_arbace_j2g_dyn_A_const_433 = A_arbace_j2g_dyn_A_const_pool.A[712]; A_arbace_j2g_dyn_A_const_434 = A_arbace_j2g_dyn_A_const_pool.A[713]; A_arbace_j2g_dyn_A_const_435 = A_arbace_j2g_dyn_A_const_pool.A[714]; A_arbace_j2g_dyn_A_const_436 = A_arbace_j2g_dyn_A_const_pool.A[715] }

func A_arbace_j2g_dyn_A_clinit_p31() { A_arbace_j2g_dyn_A_const_437 = A_arbace_j2g_dyn_A_const_pool.A[716]; A_arbace_j2g_dyn_A_const_438 = A_arbace_j2g_dyn_A_const_pool.A[717]; A_arbace_j2g_dyn_A_const_439 = A_arbace_j2g_dyn_A_const_pool.A[718]; A_arbace_j2g_dyn_A_const_440 = A_arbace_j2g_dyn_A_const_pool.A[719]; A_arbace_j2g_dyn_A_const_441 = A_arbace_j2g_dyn_A_const_pool.A[720]; A_arbace_j2g_dyn_A_const_442 = A_arbace_j2g_dyn_A_const_pool.A[721]; A_arbace_j2g_dyn_A_const_443 = A_arbace_j2g_dyn_A_const_pool.A[722]; A_arbace_j2g_dyn_A_const_444 = A_arbace_j2g_dyn_A_const_pool.A[723]; A_arbace_j2g_dyn_A_const_445 = A_arbace_j2g_dyn_A_const_pool.A[724]; A_arbace_j2g_dyn_A_const_446 = A_arbace_j2g_dyn_A_const_pool.A[725]; A_arbace_j2g_dyn_A_const_447 = A_arbace_j2g_dyn_A_const_pool.A[726]; A_arbace_j2g_dyn_A_const_448 = A_arbace_j2g_dyn_A_const_pool.A[727]; A_arbace_j2g_dyn_A_const_449 = A_arbace_j2g_dyn_A_const_pool.A[728]; A_arbace_j2g_dyn_A_const_450 = A_arbace_j2g_dyn_A_const_pool.A[729]; A_arbace_j2g_dyn_A_const_451 = A_arbace_j2g_dyn_A_const_pool.A[730]; A_arbace_j2g_dyn_A_const_452 = A_arbace_j2g_dyn_A_const_pool.A[731] }

func A_arbace_j2g_dyn_A_clinit_p32() { A_arbace_j2g_dyn_A_const_453 = A_arbace_j2g_dyn_A_const_pool.A[732]; A_arbace_j2g_dyn_A_const_454 = A_arbace_j2g_dyn_A_const_pool.A[733]; A_arbace_j2g_dyn_A_const_455 = A_arbace_j2g_dyn_A_const_pool.A[734]; A_arbace_j2g_dyn_A_const_456 = A_arbace_j2g_dyn_A_const_pool.A[735]; A_arbace_j2g_dyn_A_const_457 = A_arbace_j2g_dyn_A_const_pool.A[736]; A_arbace_j2g_dyn_A_const_458 = A_arbace_j2g_dyn_A_const_pool.A[737]; A_arbace_j2g_dyn_A_const_459 = A_arbace_j2g_dyn_A_const_pool.A[738]; A_arbace_j2g_dyn_A_const_460 = A_arbace_j2g_dyn_A_const_pool.A[739]; A_arbace_j2g_dyn_A_const_461 = A_arbace_j2g_dyn_A_const_pool.A[740]; A_arbace_j2g_dyn_A_const_462 = A_arbace_j2g_dyn_A_const_pool.A[741]; A_arbace_j2g_dyn_A_const_463 = A_arbace_j2g_dyn_A_const_pool.A[742]; A_arbace_j2g_dyn_A_const_464 = A_arbace_j2g_dyn_A_const_pool.A[743]; A_arbace_j2g_dyn_A_const_465 = A_arbace_j2g_dyn_A_const_pool.A[744]; A_arbace_j2g_dyn_A_const_466 = A_arbace_j2g_dyn_A_const_pool.A[745]; A_arbace_j2g_dyn_A_const_467 = A_arbace_j2g_dyn_A_const_pool.A[746]; A_arbace_j2g_dyn_A_const_468 = A_arbace_j2g_dyn_A_const_pool.A[747] }

func A_arbace_j2g_dyn_A_clinit_p33() { A_arbace_j2g_dyn_A_const_469 = A_arbace_j2g_dyn_A_const_pool.A[748]; A_arbace_j2g_dyn_A_const_470 = A_arbace_j2g_dyn_A_const_pool.A[749]; A_arbace_j2g_dyn_A_const_471 = A_arbace_j2g_dyn_A_const_pool.A[750]; A_arbace_j2g_dyn_A_const_472 = A_arbace_j2g_dyn_A_const_pool.A[751]; A_arbace_j2g_dyn_A_const_473 = A_arbace_j2g_dyn_A_const_pool.A[752]; A_arbace_j2g_dyn_A_const_474 = A_arbace_j2g_dyn_A_const_pool.A[753]; A_arbace_j2g_dyn_A_const_475 = A_arbace_j2g_dyn_A_const_pool.A[754]; A_arbace_j2g_dyn_A_const_476 = A_arbace_j2g_dyn_A_const_pool.A[755]; A_arbace_j2g_dyn_A_const_477 = A_arbace_j2g_dyn_A_const_pool.A[756]; A_arbace_j2g_dyn_A_const_478 = A_arbace_j2g_dyn_A_const_pool.A[757]; A_arbace_j2g_dyn_A_const_479 = A_arbace_j2g_dyn_A_const_pool.A[758]; A_arbace_j2g_dyn_A_const_480 = A_arbace_j2g_dyn_A_const_pool.A[759]; A_arbace_j2g_dyn_A_const_481 = A_arbace_j2g_dyn_A_const_pool.A[760]; A_arbace_j2g_dyn_A_const_482 = A_arbace_j2g_dyn_A_const_pool.A[761]; A_arbace_j2g_dyn_A_const_483 = A_arbace_j2g_dyn_A_const_pool.A[762]; A_arbace_j2g_dyn_A_const_484 = A_arbace_j2g_dyn_A_const_pool.A[763] }

func A_arbace_j2g_dyn_A_clinit_p34() { A_arbace_j2g_dyn_A_const_485 = A_arbace_j2g_dyn_A_const_pool.A[764]; A_arbace_j2g_dyn_A_const_486 = A_arbace_j2g_dyn_A_const_pool.A[765]; A_arbace_j2g_dyn_A_const_487 = A_arbace_j2g_dyn_A_const_pool.A[766]; A_arbace_j2g_dyn_A_const_488 = A_arbace_j2g_dyn_A_const_pool.A[767]; A_arbace_j2g_dyn_A_const_489 = A_arbace_j2g_dyn_A_const_pool.A[768]; A_arbace_j2g_dyn_A_const_490 = A_arbace_j2g_dyn_A_const_pool.A[769]; A_arbace_j2g_dyn_A_const_491 = A_arbace_j2g_dyn_A_const_pool.A[770]; A_arbace_j2g_dyn_A_const_492 = A_arbace_j2g_dyn_A_const_pool.A[771]; A_arbace_j2g_dyn_A_const_493 = A_arbace_j2g_dyn_A_const_pool.A[772]; A_arbace_j2g_dyn_A_const_494 = A_arbace_j2g_dyn_A_const_pool.A[773]; A_arbace_j2g_dyn_A_const_495 = A_arbace_j2g_dyn_A_const_pool.A[774]; A_arbace_j2g_dyn_A_const_496 = A_arbace_j2g_dyn_A_const_pool.A[775]; A_arbace_j2g_dyn_A_const_497 = A_arbace_j2g_dyn_A_const_pool.A[776]; A_arbace_j2g_dyn_A_const_498 = A_arbace_j2g_dyn_A_const_pool.A[777]; A_arbace_j2g_dyn_A_const_499 = A_arbace_j2g_dyn_A_const_pool.A[778]; A_arbace_j2g_dyn_A_const_500 = A_arbace_j2g_dyn_A_const_pool.A[779] }

func A_arbace_j2g_dyn_A_clinit_p35() { A_arbace_j2g_dyn_A_const_501 = A_arbace_j2g_dyn_A_const_pool.A[780]; A_arbace_j2g_dyn_A_const_502 = A_arbace_j2g_dyn_A_const_pool.A[781]; A_arbace_j2g_dyn_A_const_503 = A_arbace_j2g_dyn_A_const_pool.A[782]; A_arbace_j2g_dyn_A_const_504 = A_arbace_j2g_dyn_A_const_pool.A[783]; A_arbace_j2g_dyn_A_const_505 = A_arbace_j2g_dyn_A_const_pool.A[784]; A_arbace_j2g_dyn_A_const_506 = A_arbace_j2g_dyn_A_const_pool.A[785]; A_arbace_j2g_dyn_A_const_507 = A_arbace_j2g_dyn_A_const_pool.A[786]; A_arbace_j2g_dyn_A_const_508 = A_arbace_j2g_dyn_A_const_pool.A[787]; A_arbace_j2g_dyn_A_const_509 = A_arbace_j2g_dyn_A_const_pool.A[788]; A_arbace_j2g_dyn_A_const_510 = A_arbace_j2g_dyn_A_const_pool.A[789]; A_arbace_j2g_dyn_A_const_511 = A_arbace_j2g_dyn_A_const_pool.A[790]; A_arbace_j2g_dyn_A_const_512 = A_arbace_j2g_dyn_A_const_pool.A[791]; A_arbace_j2g_dyn_A_const_513 = A_arbace_j2g_dyn_A_const_pool.A[792]; A_arbace_j2g_dyn_A_const_514 = A_arbace_j2g_dyn_A_const_pool.A[793]; A_arbace_j2g_dyn_A_const_515 = A_arbace_j2g_dyn_A_const_pool.A[794]; A_arbace_j2g_dyn_A_const_516 = A_arbace_j2g_dyn_A_const_pool.A[795] }

func A_arbace_j2g_dyn_A_clinit_p36() { A_arbace_j2g_dyn_A_const_517 = A_arbace_j2g_dyn_A_const_pool.A[796]; A_arbace_j2g_dyn_A_const_518 = A_arbace_j2g_dyn_A_const_pool.A[797]; A_arbace_j2g_dyn_A_const_519 = A_arbace_j2g_dyn_A_const_pool.A[798]; A_arbace_j2g_dyn_A_const_520 = A_arbace_j2g_dyn_A_const_pool.A[799]; A_arbace_j2g_dyn_A_const_521 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[800]); A_arbace_j2g_dyn_A_const_522 = A_arbace_j2g_dyn_A_const_pool.A[801]; A_arbace_j2g_dyn_A_const_523 = A_arbace_j2g_dyn_A_const_pool.A[802]; A_arbace_j2g_dyn_A_const_524 = A_arbace_j2g_dyn_A_const_pool.A[803]; A_arbace_j2g_dyn_A_const_525 = A_arbace_j2g_dyn_A_const_pool.A[804]; A_arbace_j2g_dyn_A_const_526 = A_arbace_j2g_dyn_A_const_pool.A[805]; A_arbace_j2g_dyn_A_const_527 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[806]); A_arbace_j2g_dyn_A_const_528 = A_arbace_j2g_dyn_A_const_pool.A[807]; A_arbace_j2g_dyn_A_const_529 = A_arbace_j2g_dyn_A_const_pool.A[808]; A_arbace_j2g_dyn_A_const_530 = A_arbace_j2g_dyn_A_const_pool.A[809]; A_arbace_j2g_dyn_A_const_531 = A_arbace_j2g_dyn_A_const_pool.A[810] }

func A_arbace_j2g_dyn_A_clinit_p37() { A_arbace_j2g_dyn_A_const_532 = A_arbace_j2g_dyn_A_const_pool.A[811]; A_arbace_j2g_dyn_A_const_533 = A_arbace_j2g_dyn_A_const_pool.A[812]; A_arbace_j2g_dyn_A_const_534 = A_arbace_j2g_dyn_A_const_pool.A[813]; A_arbace_j2g_dyn_A_const_535 = A_arbace_j2g_dyn_A_const_pool.A[814]; A_arbace_j2g_dyn_A_const_536 = A_arbace_j2g_dyn_A_const_pool.A[815]; A_arbace_j2g_dyn_A_const_537 = A_arbace_j2g_dyn_A_const_pool.A[816]; A_arbace_j2g_dyn_A_const_538 = A_arbace_j2g_dyn_A_const_pool.A[817]; A_arbace_j2g_dyn_A_const_539 = A_arbace_j2g_dyn_A_const_pool.A[818]; A_arbace_j2g_dyn_A_const_540 = A_arbace_j2g_dyn_A_const_pool.A[819]; A_arbace_j2g_dyn_A_const_541 = A_arbace_j2g_dyn_A_const_pool.A[820]; A_arbace_j2g_dyn_A_const_542 = A_arbace_j2g_dyn_A_const_pool.A[821]; A_arbace_j2g_dyn_A_const_543 = A_arbace_j2g_dyn_A_const_pool.A[822]; A_arbace_j2g_dyn_A_const_544 = A_arbace_j2g_dyn_A_const_pool.A[823]; A_arbace_j2g_dyn_A_const_545 = A_arbace_j2g_dyn_A_const_pool.A[824]; A_arbace_j2g_dyn_A_const_546 = A_arbace_j2g_dyn_A_const_pool.A[825]; A_arbace_j2g_dyn_A_const_547 = A_arbace_j2g_dyn_A_const_pool.A[826] }

func A_arbace_j2g_dyn_A_clinit_p38() { A_arbace_j2g_dyn_A_const_548 = A_arbace_j2g_dyn_A_const_pool.A[827]; A_arbace_j2g_dyn_A_const_549 = A_arbace_j2g_dyn_A_const_pool.A[828]; A_arbace_j2g_dyn_A_const_550 = A_arbace_j2g_dyn_A_const_pool.A[829]; A_arbace_j2g_dyn_A_const_551 = A_arbace_j2g_dyn_A_const_pool.A[830]; A_arbace_j2g_dyn_A_const_552 = A_arbace_j2g_dyn_A_const_pool.A[831]; A_arbace_j2g_dyn_A_const_553 = A_arbace_j2g_dyn_A_const_pool.A[832]; A_arbace_j2g_dyn_A_const_554 = A_arbace_j2g_dyn_A_const_pool.A[833]; A_arbace_j2g_dyn_A_const_555 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[834]); A_arbace_j2g_dyn_A_const_556 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[835]); A_arbace_j2g_dyn_A_const_557 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[836]); A_arbace_j2g_dyn_A_const_558 = A_arbace_j2g_dyn_A_const_pool.A[837]; A_arbace_j2g_dyn_A_const_559 = A_arbace_j2g_dyn_A_const_pool.A[838]; A_arbace_j2g_dyn_A_const_560 = A_arbace_j2g_dyn_A_const_pool.A[839]; A_arbace_j2g_dyn_A_const_561 = A_arbace_j2g_dyn_A_const_pool.A[840] }

func A_arbace_j2g_dyn_A_clinit_p39() { A_arbace_j2g_dyn_A_const_562 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[841]); A_arbace_j2g_dyn_A_const_563 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[842]); A_arbace_j2g_dyn_A_const_564 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[843]); A_arbace_j2g_dyn_A_const_565 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[844]); A_arbace_j2g_dyn_A_const_566 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[845]); A_arbace_j2g_dyn_A_const_567 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[846]) }

func A_arbace_j2g_dyn_A_New() *A_arbace_j2g_dyn_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_A) Ctor() {}

func (t *A_arbace_j2g_dyn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_A_class }

func (t *A_arbace_j2g_dyn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_A); return ok }

func A_arbace_j2g_dyn_A_Cast(x any) *A_arbace_j2g_dyn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_A_class)) }; return v }



type A_arbace_j2g_dyn_abstract_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_abstract_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_aot_fn_fields_native_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_aot_fn_fields_native_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_box_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_box_arg_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_call_impl_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_call_impl_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_class_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_ret__711000234_A struct{ j2g_header uint64; F_r any }

var A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_A struct{ j2g_header uint64; F_e any }

var A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_core_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_core_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_core_forms_fn__711000401_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_core_forms_fn__711000401_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A struct{ j2g_header uint64; F_g, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A struct{ j2g_header uint64; F_iter__711000243, F_g, F_s__711000244, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A struct{ j2g_header uint64; F_g, F_n, F_b__711000246, F_arg_conv any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_A struct{ j2g_header uint64; F_ifaces, F_lockee__1927000360__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A struct{ j2g_header uint64; F_j any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A struct{ j2g_header uint64; F_s__711000089, F_iter__711000088 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A struct{ j2g_header uint64; F_iter__711000090, F_s__711000091 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A struct{ j2g_header uint64; F_b__711000093 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_fn__711000118_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A struct{ j2g_header uint64; F_iter__711000107, F_k, F_s__711000108 any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A struct{ j2g_header uint64; F_k, F_b__711000110 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_dyn_convert_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_dyn_convert_form_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A struct{ j2g_header uint64; F_s__711000383, F_iter__711000382 any }

var A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A struct{ j2g_header uint64; F_b__711000385 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_dyn_convert_form_iter__711000382__711000386_fn__711000387_fn__711000388_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_dyn_serial_new_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_dyn_serial_new_form_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000004_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000004_A_New() *A_arbace_j2g_dyn_eval711000004_A { t := &A_arbace_j2g_dyn_eval711000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000004_A_class }

func (t *A_arbace_j2g_dyn_eval711000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); return ok }

func A_arbace_j2g_dyn_eval711000004_A_Cast(x any) *A_arbace_j2g_dyn_eval711000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000004_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000008_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000008_A_New() *A_arbace_j2g_dyn_eval711000008_A { t := &A_arbace_j2g_dyn_eval711000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000008_A_class }

func (t *A_arbace_j2g_dyn_eval711000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); return ok }

func A_arbace_j2g_dyn_eval711000008_A_Cast(x any) *A_arbace_j2g_dyn_eval711000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000008_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000008_fn__711000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000008_fn__711000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_fn_field_native_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_fn_field_native_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000431_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000431_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000433_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000433_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000421__711000425_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000421__711000425_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A struct{ j2g_header uint64; F_iter__711000421, F_s__711000422 any }

var A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A struct{ j2g_header uint64; F_b__711000424 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000421__711000425_fn__711000426_fn__711000427_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A struct{ j2g_header uint64; F_iter__711000270, F_s__711000271 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A struct{ j2g_header uint64; F_s__711000273, F_iter__711000272 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A struct{ j2g_header uint64; F_b__711000275 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A struct{ j2g_header uint64; F_s__711000285, F_iter__711000284 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A struct{ j2g_header uint64; F_b__711000287 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A struct{ j2g_header uint64; F_s__711000297, F_n, F_iter__711000296 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A struct{ j2g_header uint64; F_n, F_b__711000299 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_iface_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A struct{ j2g_header uint64; F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A struct{ j2g_header uint64; F_iter__711000158, F_s__711000159, F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A struct{ j2g_header uint64; F_b__711000161, F_r, F_pn any; F_size__1927001038__auto__ int32; F_core_QMARK_, F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000034_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000036_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A struct{ j2g_header uint64; F_iter__711000038, F_s__711000039 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A struct{ j2g_header uint64; F_s__711000041, F_n, F_iter__711000040 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A struct{ j2g_header uint64; F_n, F_b__711000043 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000178_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000196_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A struct{ j2g_header uint64; F_s__711000187, F_iter__711000186 any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A struct{ j2g_header uint64; F_b__711000189 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_impl_native_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_impl_native_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_native_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_native_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_object_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_object_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_classes_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_fn__711000201_A struct{ j2g_header uint64; F_T any }

var A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A struct{ j2g_header uint64; F_s__711000410, F_iter__711000409 any }

var A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A struct{ j2g_header uint64; F_b__711000412 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_proxy_forms_iter__711000409__711000413_fn__711000414_fn__711000415_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A struct{ j2g_header uint64; F_iter__711000205, F_s__711000206 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A struct{ j2g_header uint64; F_iter__711000207, F_n, F_s__711000208 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A struct{ j2g_header uint64; F_n, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A struct{ j2g_header uint64; F_s__711000210, F_n, F_iter__711000209, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A struct{ j2g_header uint64; F_n, F_b__711000212 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_public_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_public_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A struct{ j2g_header uint64; F_iter__711000013, F_s__711000014 any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A struct{ j2g_header uint64; F_b__711000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A struct{ j2g_header uint64; F_s__711000056, F_iter__711000055 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A struct{ j2g_header uint64; F_iter__711000057, F_s__711000058 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A struct{ j2g_header uint64; F_b__711000060 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000324_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_A struct{ j2g_header uint64; F_own, F_recv, F_clash, F_ifaces, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A struct{ j2g_header uint64; F_iter__711000307, F_s__711000308 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A struct{ j2g_header uint64; F_b__711000310 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A struct{ j2g_header uint64; F_s__711000330, F_iter__711000329 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A struct{ j2g_header uint64; F_b__711000332 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A struct{ j2g_header uint64; F_recv, F_iter__711000345, F_s__711000346, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A struct{ j2g_header uint64; F_recv, F_n, F_b__711000348 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A struct{ j2g_header uint64; F_recv, F_clash any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A struct{ j2g_header uint64; F_s__711000360, F_recv, F_clash, F_iter__711000359 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A struct{ j2g_header uint64; F_recv, F_clash, F_b__711000362 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_tag_A_fn_class *jrt.Class
