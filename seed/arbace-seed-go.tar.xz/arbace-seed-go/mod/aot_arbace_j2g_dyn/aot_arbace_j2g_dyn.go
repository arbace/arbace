//line aot_arbace_j2g_dyn.ae:1
package aot_arbace_j2g_dyn

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_New() *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyn_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyn_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyn_A_const_1, A_arbace_j2g_dyn_A_const_2, A_arbace_j2g_dyn_A_const_3, A_arbace_j2g_dyn_A_const_4, A_arbace_j2g_dyn_A_const_5, A_arbace_j2g_dyn_A_const_6, A_arbace_j2g_dyn_A_const_7, A_arbace_j2g_dyn_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyn_eval711000008_fn__711000009_A_New() *A_arbace_j2g_dyn_eval711000008_fn__711000009_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000008_fn__711000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_11.GetRawRoot__O()); var tmp2 any; var root_22 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_dyn_A_const_13; if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_22, arg_25) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(), A_arbace_j2g_dyn_A_const_15) }























func A_arbace_j2g_dyn_tag_A_New() *A_arbace_j2g_dyn_tag_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_tag_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_26 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = sym__0; var arg_30 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyn_A_const_17, type__1)); if linked_27 == nil { return ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { return linked_27.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) } }










func A_arbace_j2g_dyn_roots_A_New() *A_arbace_j2g_dyn_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_dyn_roots_A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_dyn_roots_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var fnbody__92 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New(); var tmp1 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class; if


	fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, nil); A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class = fncls__91d; tmp1 = fncls__91d } else { tmp1 = fncls__91 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()) }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New() *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Invoke_O_O__O(self, s__711000014__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(self, s__711000014__1); var tmp2 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, fnbody__90); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class = fncls__89d; tmp2 = fncls__89d } else { tmp2 = fncls__89 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Ctor_O_O(c__iter__711000013, c__s__711000014 any) { t.F_iter__711000013 = c__iter__711000013; t.F_s__711000014 = c__s__711000014 }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Invoke_O__O(self any) any { { var s__711000014__1 any; var t_ any = t.F_s__711000014; t.F_s__711000014 = nil; s__711000014__1 = t_; for { var temp__1927000414__auto____2 any; var root_31 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__711000014__1; if linked_32 == nil { temp__1927000414__auto____2 = ifn_33.Invoke_O__O(arg_34) } else { temp__1927000414__auto____2 = linked_32.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_35 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__711000014__3; if linked_36 == nil { tmp1 = ifn_37.Invoke_O__O(arg_38) } else { tmp1 = linked_36.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_35, arg_38) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_39 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = s__711000014__3; if linked_40 == nil { c__1927001037__auto____4 = ifn_41.Invoke_O__O(arg_42) } else { c__1927001037__auto____4 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_39, arg_42) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000016__6 any; var root_43 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_44 == nil { b__711000016__6 = ifn_45.Invoke_O__O(arg_46) } else { b__711000016__6 = linked_44.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_43, arg_46) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__53 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(b__711000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, fnbody__53); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__53, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_54 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any; var root_59 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = b__711000016__6; if linked_60 == nil { arg_57 = ifn_61.Invoke_O__O(arg_62) } else { arg_57 = linked_60.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_59, arg_62) }; var arg_58 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp5 any; var root_63 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = s__711000014__3; if linked_64 == nil { tmp5 = ifn_65.Invoke_O__O(arg_66) } else { tmp5 = linked_64.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_63, arg_66) }; arg_58 = tmp4.Invoke_O__O(tmp5); if linked_55 == nil { return ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { return linked_55.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_54, arg_57, arg_58) } } else { var root_67 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any; var root_72 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = b__711000016__6; if linked_73 == nil { arg_70 = ifn_74.Invoke_O__O(arg_75) } else { arg_70 = linked_73.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_72, arg_75) }; var arg_71 any; if linked_68 == nil { return ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { return linked_68.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) } } } else { var vec__711000024__4 any; var root_76 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = s__711000014__3; if linked_77 == nil { vec__711000024__4 = ifn_78.Invoke_O__O(arg_79) } else { vec__711000024__4 = linked_77.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_76, arg_79) }; var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_80 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_18, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()); var arg_84 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp7 any; var root_85 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = s__711000014__3; if linked_86 == nil { tmp7 = ifn_87.Invoke_O__O(arg_88) } else { tmp7 = linked_86.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_85, arg_88) }; arg_84 = tmp6.Invoke_O__O(tmp7); if linked_81 == nil { return ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { return linked_81.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Ctor_O_I_O(c__b__711000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000016 = c__b__711000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Invoke_O__O(self any) any { { var i__711000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_47 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = t.F_b__711000016; var arg_51 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_18, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref()); if linked_48 == nil { ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { linked_48.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; i__711000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000015__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_enabled_QMARK__A_New() *A_arbace_j2g_dyn_enabled_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_enabled_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_93 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); if linked_94 == nil { return ifn_95.Invoke_O__O(arg_96) } else { return linked_94.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_93, arg_96)
	} }
func A_arbace_j2g_dyn_public_QMARK__A_New() *A_arbace_j2g_dyn_public_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_public_QMARK__A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Ctor() {}
//line :47:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_97 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; var tmp1 int64; var na_101 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_33; var tmp3 any; var root_103 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = n__0; if linked_104 == nil { tmp3 = ifn_105.Invoke_O__O(arg_106) } else { tmp3 = linked_104.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_103, arg_106) }; na_101 = tmp2.Invoke_O__O(tmp3); var na_102 int64 = 1; if jrt.Long_InstanceOf(na_101) { var n0_107 int64 = jrt.NN(jrt.Long_Cast(na_101)).LongValue__J(); var n1_108 int64 = na_102; tmp1 = n0_107 & n1_108 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_101, na_102) }; arg_100 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_98 == nil { return ifn_99.Invoke_O__O(arg_100) } else { return linked_98.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_97, arg_100) } }

func A_arbace_j2g_dyn_interfaces_A_New() *A_arbace_j2g_dyn_interfaces_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_dyn_interfaces_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_dyn_interfaces_A) Invoke_O_O__O(self, T__0_ any) any { var base__2 any; var root_110 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_112 lang.IFn; if




	linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any; var fnbody__162 any = A_arbace_j2g_dyn_interfaces_fn__711000034_A_New(); var tmp1 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, nil); A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class = fncls__161d; tmp1 = fncls__161d } else { tmp1 = fncls__161 }; arg_113 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp1, nil); var arg_114 any; var root_163 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_165 lang.IFn; if






	linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = T__0_; var arg_167 any; var root_168 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any; var fnbody__187 any = A_arbace_j2g_dyn_interfaces_fn__711000036_A_New(); var tmp2 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, nil); A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class = fncls__186d; tmp2 = fncls__186d } else { tmp2 = fncls__186 }; arg_171 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__187, tmp2, nil); var arg_172 any; var root_188 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_190 lang.IFn; if


	linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var root_192 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var tmp3 *lang.Keyword = A_arbace_j2g_dyn_A_const_51; var arg_195 any = tmp3.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); if linked_193 == nil { arg_191 = ifn_194.Invoke_O__O(arg_195) } else { arg_191 = linked_193.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_192, arg_195) }; if linked_189 == nil { arg_172 = ifn_190.Invoke_O__O(arg_191) } else { arg_172 = linked_189.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_188, arg_191) }; if /*line :61:1*/ linked_169 == nil { arg_167 = ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { arg_167 = linked_169.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_168, arg_171, arg_172) }; if linked_164 == nil { arg_114 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { arg_114 = linked_164.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }; if /*line :54:1*/ linked_111 == nil { base__2 = ifn_112.Invoke_O_O__O(arg_113, arg_114) } else { base__2 = linked_111.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_110, arg_113, arg_114) }; var root_196 any =










	A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any; var root_200 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var root_204 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = base__2; var arg_208 any; var iter__1927001039__auto____3 any; var fnbody__333 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New(); var tmp4 *jrt.Class; var fncls__332 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class; if
	fncls__332 == nil { var fncls__332d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, nil); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class = fncls__332d; tmp4 = fncls__332d } else { tmp4 = fncls__332 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__333, tmp4, nil); arg_208 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(base__2); if /*line :65:1*/ linked_205 == nil { arg_203 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { arg_203 = linked_205.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) }; if linked_201 == nil { arg_199 = ifn_202.Invoke_O__O(arg_203) } else { arg_199 = linked_201.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_200, arg_203) }; if linked_197 == nil { return ifn_198.Invoke_O__O(arg_199) } else { return linked_197.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_196, arg_199) } }
//line :54:1
func A_arbace_j2g_dyn_interfaces_fn__711000034_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000034_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000034_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Ctor() {}
//line :54:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Invoke_O_O__O(self, p1__711000032_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_115 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = p1__711000032_SHARP___1; if linked_116 == nil { and__1927000168__auto____2 = ifn_117.Invoke_O__O(arg_118) } else { and__1927000168__auto____2 = linked_116.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_119 any = A_arbace_j2g_dyn_A_const_37.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, A_arbace_j2g_dyn_public_QMARK__A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = p1__711000032_SHARP___1; if linked_120 == nil { and__1927000168__auto____3 = ifn_121.Invoke_O__O(arg_122) } else { and__1927000168__auto____3 = linked_120.(*A_arbace_j2g_dyn_public_QMARK__A).Invoke_O_O__O(root_119, arg_122) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_123 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_125 lang.IFn

	if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var root_127 any = A_arbace_j2g_dyn_A_const_38.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any; var root_131 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = p1__711000032_SHARP___1; if linked_132 == nil { arg_130 = ifn_133.Invoke_O__O(arg_134) } else { arg_130 = linked_132.(*aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_131, arg_134) }; if linked_128 == nil { arg_126 = ifn_129.Invoke_O__O(arg_130) } else { arg_126 = linked_128.(*aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A).Invoke_O_O__O(root_127, arg_130) }; if linked_124 == nil { and__1927000168__auto____4 = ifn_125.Invoke_O__O(arg_126) } else { and__1927000168__auto____4 = linked_124.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_123, arg_126) }
//line :54:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_135 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_137 lang.IFn



		if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any; var root_139 any = A_arbace_j2g_dyn_A_const_40.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = p1__711000032_SHARP___1; var arg_143 any = Lit_116; if linked_140 == nil { arg_138 = ifn_141.Invoke_O_O__O(arg_142, arg_143) } else { arg_138 = linked_140.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_139, arg_142, arg_143) }; if linked_136 == nil { and__1927000168__auto____5 = ifn_137.Invoke_O__O(arg_138) } else { and__1927000168__auto____5 = linked_136.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_135, arg_138) }
//line :54:1
		if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp1 int64; var na_144 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_33; var tmp3 any; var root_146 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_148 lang.IFn




			if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = p1__711000032_SHARP___1; if linked_147 == nil { tmp3 = ifn_148.Invoke_O__O(arg_149) } else { tmp3 = linked_147.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_146, arg_149) }; na_144 = tmp2.Invoke_O__O(tmp3); var na_145 int64 = 8192; if jrt.Long_InstanceOf(na_144) { var n0_150 int64 = jrt.NN(jrt.Long_Cast(na_144)).LongValue__J(); var n1_151 int64 = na_145; tmp1 = n0_150 & n1_151 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_144, na_145) }; and__1927000168__auto____6 = lang.Numbers_IsZero_J__Z_NoInit(tmp1)
//line :54:1
			if and__1927000168__auto____6 {





				var root_153 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any; var root_157 any = A_arbace_j2g_dyn_A_const_41.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = p1__711000032_SHARP___1; if linked_158 == nil { arg_156 = ifn_159.Invoke_O__O(arg_160) } else { arg_156 = linked_158.(*aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A).Invoke_O_O__O(root_157, arg_160) }; if linked_154 == nil { return ifn_155.Invoke_O__O(arg_156) } else { return linked_154.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_153, arg_156) } } else {
//line :54:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_dyn_interfaces_fn__711000036_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000036_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000036_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Ctor() {}
//line :61:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Invoke_O_O__O(self, p1__711000033_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_173 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = p1__711000033_SHARP___1; if linked_174 == nil { and__1927000168__auto____2 = ifn_175.Invoke_O__O(arg_176) } else { and__1927000168__auto____2 = linked_174.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(and__1927000168__auto____2) {

	var root_177 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var tmp1 *lang.Keyword = A_arbace_j2g_dyn_A_const_45; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_180 any = tmp1.Invoke_O__O(tmp2.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O())); var arg_181 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_22); var tmp4 any; var root_182 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = p1__711000033_SHARP___1; if linked_183 == nil { tmp4 = ifn_184.Invoke_O__O(arg_185) } else { tmp4 = linked_183.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_182, arg_185) }; arg_181 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil)).Ref(); if linked_178 == nil { return ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { return linked_178.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_177, arg_180, arg_181) } } else {
//line :61:1
		return and__1927000168__auto____2 } }




func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New() *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Ctor() {}
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Invoke_O_O__O(self, s__711000039__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__331 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(self, s__711000039__1); var tmp2 *jrt.Class; var fncls__330 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class; if fncls__330 == nil { var fncls__330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, fnbody__331); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class = fncls__330d; tmp2 = fncls__330d } else { tmp2 = fncls__330 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__331, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Ctor_O_O(c__iter__711000038, c__s__711000039 any) { t.F_iter__711000038 = c__iter__711000038; t.F_s__711000039 = c__s__711000039 }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Invoke_O__O(self any) any { { var s__711000039__1 any; var t_ any = t.F_s__711000039; t.F_s__711000039 = nil; s__711000039__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_209 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = s__711000039__1; if linked_210 == nil { temp__1927000414__auto____2 = ifn_211.Invoke_O__O(arg_212) } else { temp__1927000414__auto____2 = linked_210.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_209, arg_212) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_213 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = xs__1927001018__auto____3; if linked_214 == nil { n__4 = ifn_215.Invoke_O__O(arg_216) } else { n__4 = linked_214.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_213, arg_216) }; var iterys__1927001035__auto____5 any; var fnbody__308 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(n__4); var tmp1 *jrt.Class; var fncls__307 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class; if fncls__307 == nil { var fncls__307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, fnbody__308); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class = fncls__307d; tmp1 = fncls__307d } else { tmp1 = fncls__307 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__308, tmp1, nil); var fs__1927001036__auto____6 any; var root_309 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_313 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = n__4; if linked_314 == nil { tmp3 = ifn_315.Invoke_O__O(arg_316) } else { tmp3 = linked_314.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_313, arg_316) }; arg_312 = tmp2.Invoke_O__O(tmp3); if linked_310 == nil { fs__1927001036__auto____6 = ifn_311.Invoke_O__O(arg_312) } else { fs__1927001036__auto____6 = linked_310.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_309, arg_312) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_317 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = fs__1927001036__auto____6; var arg_321 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000038); var tmp5 any; var root_322 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = s__711000039__1; if linked_323 == nil { tmp5 = ifn_324.Invoke_O__O(arg_325) } else { tmp5 = linked_323.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_322, arg_325) }; arg_321 = tmp4.Invoke_O__O(tmp5); if linked_318 == nil { return ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { return linked_318.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_317, arg_320, arg_321) } } else { var tmp6 any; var root_326 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = s__711000039__1; if linked_327 == nil { tmp6 = ifn_328.Invoke_O__O(arg_329) } else { tmp6 = linked_327.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_326, arg_329) }; s__711000039__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(p0 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Invoke_O_O__O(self, s__711000041__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__306 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(s__711000041__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__305 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class; if fncls__305 == nil { var fncls__305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, fnbody__306); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class = fncls__305d; tmp2 = fncls__305d } else { tmp2 = fncls__305 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__306, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Ctor_O_O_O(c__s__711000041, c__n, c__iter__711000040 any) { t.F_s__711000041 = c__s__711000041; t.F_n = c__n; t.F_iter__711000040 = c__iter__711000040 }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Invoke_O__O(self any) any { { var s__711000041__1 any; var t_ any = t.F_s__711000041; t.F_s__711000041 = nil; s__711000041__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_217 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = s__711000041__1; if linked_218 == nil { temp__1927000414__auto____2 = ifn_219.Invoke_O__O(arg_220) } else { temp__1927000414__auto____2 = linked_218.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_217, arg_220) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000041__3 any = temp__1927000414__auto____2; var tmp1 any; var root_221 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = s__711000041__3; if linked_222 == nil { tmp1 = ifn_223.Invoke_O__O(arg_224) } else { tmp1 = linked_222.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_221, arg_224) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_225 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = s__711000041__3; if linked_226 == nil { c__1927001037__auto____4 = ifn_227.Invoke_O__O(arg_228) } else { c__1927001037__auto____4 = linked_226.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_225, arg_228) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000043__6 any; var root_229 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_230 == nil { b__711000043__6 = ifn_231.Invoke_O__O(arg_232) } else { b__711000043__6 = linked_230.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_229, arg_232) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__252 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(t.F_n, b__711000043__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class; if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, fnbody__252); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class = fncls__251d; tmp3 = fncls__251d } else { tmp3 = fncls__251 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__252, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_253 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var root_258 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = b__711000043__6; if linked_259 == nil { arg_256 = ifn_260.Invoke_O__O(arg_261) } else { arg_256 = linked_259.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_258, arg_261) }; var arg_257 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp5 any; var root_262 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = s__711000041__3; if linked_263 == nil { tmp5 = ifn_264.Invoke_O__O(arg_265) } else { tmp5 = linked_263.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_262, arg_265) }; arg_257 = tmp4.Invoke_O__O(tmp5); if linked_254 == nil { return ifn_255.Invoke_O_O__O(arg_256, arg_257) } else { return linked_254.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_253, arg_256, arg_257) } } else { var root_266 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any; var root_271 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = b__711000043__6; if linked_272 == nil { arg_269 = ifn_273.Invoke_O__O(arg_274) } else { arg_269 = linked_272.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_271, arg_274) }; var arg_270 any; if linked_267 == nil { return ifn_268.Invoke_O_O__O(arg_269, arg_270) } else { return linked_267.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_266, arg_269, arg_270) } } } else { var s__4 any; var root_275 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = s__711000041__3; if linked_276 == nil { s__4 = ifn_277.Invoke_O__O(arg_278) } else { s__4 = linked_276.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_275, arg_278) }; var tmp6 any; var and__1927000168__auto____5 any; var root_279 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_281 lang.IFn
																			if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = s__4; var arg_283 any = t.F_n; if linked_280 == nil { and__1927000168__auto____5 = ifn_281.Invoke_O_O__O(arg_282, arg_283) } else { and__1927000168__auto____5 = linked_280.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_279, arg_282, arg_283) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_284 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = s__4; if linked_285 == nil { and__1927000168__auto____6 = ifn_286.Invoke_O__O(arg_287) } else { and__1927000168__auto____6 = linked_285.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_284, arg_287) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_288 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = s__4; if linked_289 == nil { tmp6 = ifn_290.Invoke_O__O(arg_291) } else { tmp6 = linked_289.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_288, arg_291) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :66:1
	if jrt.J2g_Truth(tmp6) { var root_292 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = s__4; var arg_296 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp8 any; var root_297 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = s__711000041__3; if linked_298 == nil { tmp8 = ifn_299.Invoke_O__O(arg_300) } else { tmp8 = linked_298.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_297, arg_300) }; arg_296 = tmp7.Invoke_O__O(tmp8); if linked_293 == nil { return ifn_294.Invoke_O_O__O(arg_295, arg_296) } else { return linked_293.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_292, arg_295, arg_296) } } else { var tmp9 any; var root_301 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = s__711000041__3; if linked_302 == nil { tmp9 = ifn_303.Invoke_O__O(arg_304) } else { tmp9 = linked_302.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_301, arg_304) }; s__711000041__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Ctor_O_O_I_O(c__n, c__b__711000043 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000043 = c__b__711000043; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Invoke_O__O(self any) any { { var i__711000042__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000042__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000042__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_233 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_235 lang.IFn
																					if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = s__2; var arg_237 any = t.F_n; if linked_234 == nil { and__1927000168__auto____3 = ifn_235.Invoke_O_O__O(arg_236, arg_237) } else { and__1927000168__auto____3 = linked_234.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_233, arg_236, arg_237) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_238 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = s__2; if linked_239 == nil { and__1927000168__auto____4 = ifn_240.Invoke_O__O(arg_241) } else { and__1927000168__auto____4 = linked_239.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_238, arg_241) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_242 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = s__2; if linked_243 == nil { tmp2 = ifn_244.Invoke_O__O(arg_245) } else { tmp2 = linked_243.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_242, arg_245) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :66:1
	if jrt.J2g_Truth(tmp2) { var root_246 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = t.F_b__711000043; var arg_250 any = s__2; if linked_247 == nil { ifn_248.Invoke_O_O__O(arg_249, arg_250) } else { linked_247.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_246, arg_249, arg_250) }; i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } else { i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_slot_keys_A_New() *A_arbace_j2g_dyn_slot_keys_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Ctor() {}
//line :70:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Invoke_O_O__O(self, ifaces__0 any) any { var ks__2 any; var root_334 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_336 lang.IFn; if


	linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any; var root_338 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any; var iter__1927001039__auto____2 any; var fnbody__448 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New(); var tmp1 *jrt.Class; var fncls__447 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class; if fncls__447 == nil { var fncls__447d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, nil); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class = fncls__447d; tmp1 = fncls__447d } else { tmp1 = fncls__447 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__448, tmp1, nil); arg_341 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(ifaces__0); if linked_339 == nil { arg_337 = ifn_340.Invoke_O__O(arg_341) } else { arg_337 = linked_339.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_338, arg_341) }; if linked_335 == nil { ks__2 = ifn_336.Invoke_O__O(arg_337) } else { ks__2 = linked_335.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_334, arg_337) }; var root_449 any =
	A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var root_453 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(); var arg_457 any = ks__2; if linked_454 == nil { arg_452 = ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { arg_452 = linked_454.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_453, arg_456, arg_457) }; if linked_450 == nil { return ifn_451.Invoke_O__O(arg_452) } else { return linked_450.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_449, arg_452) } }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Invoke_O_O__O(self, s__711000056__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__446 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(s__711000056__1, self); var tmp2 *jrt.Class; var fncls__445 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class; if fncls__445 == nil { var fncls__445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, fnbody__446); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class = fncls__445d; tmp2 = fncls__445d } else { tmp2 = fncls__445 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__446, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Ctor_O_O(c__s__711000056, c__iter__711000055 any) { t.F_s__711000056 = c__s__711000056; t.F_iter__711000055 = c__iter__711000055 }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Invoke_O__O(self any) any { { var s__711000056__1 any; var t_ any = t.F_s__711000056; t.F_s__711000056 = nil; s__711000056__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_342 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = s__711000056__1; if linked_343 == nil { temp__1927000414__auto____2 = ifn_344.Invoke_O__O(arg_345) } else { temp__1927000414__auto____2 = linked_343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_342, arg_345) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var j__4 any; var root_346 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = xs__1927001018__auto____3; if linked_347 == nil { j__4 = ifn_348.Invoke_O__O(arg_349) } else { j__4 = linked_347.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_346, arg_349) }; var iterys__1927001035__auto____5 any; var fnbody__423 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New(); var tmp1 *jrt.Class; var fncls__422 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class; if fncls__422 == nil { var fncls__422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, nil); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class = fncls__422d; tmp1 = fncls__422d } else { tmp1 = fncls__422 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__423, tmp1, nil); var fs__1927001036__auto____6 any; var root_424 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_428 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = j__4; if linked_429 == nil { tmp3 = ifn_430.Invoke_O__O(arg_431) } else { tmp3 = linked_429.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_428, arg_431) }; arg_427 = tmp2.Invoke_O__O(tmp3); if linked_425 == nil { fs__1927001036__auto____6 = ifn_426.Invoke_O__O(arg_427) } else { fs__1927001036__auto____6 = linked_425.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_424, arg_427) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_432 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = fs__1927001036__auto____6; var arg_436 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000055); var tmp5 any; var root_437 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = s__711000056__1; if linked_438 == nil { tmp5 = ifn_439.Invoke_O__O(arg_440) } else { tmp5 = linked_438.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_437, arg_440) }; arg_436 = tmp4.Invoke_O__O(tmp5); if linked_433 == nil { return ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { return linked_433.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) } } else { var tmp6 any; var root_441 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = s__711000056__1; if linked_442 == nil { tmp6 = ifn_443.Invoke_O__O(arg_444) } else { tmp6 = linked_442.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_441, arg_444) }; s__711000056__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Invoke_O_O__O(self, s__711000058__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__421 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(self, s__711000058__1); var tmp2 *jrt.Class; var fncls__420 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class; if fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, fnbody__421); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class = fncls__420d; tmp2 = fncls__420d } else { tmp2 = fncls__420 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__421, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Ctor_O_O(c__iter__711000057, c__s__711000058 any) { t.F_iter__711000057 = c__iter__711000057; t.F_s__711000058 = c__s__711000058 }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Invoke_O__O(self any) any { { var s__711000058__1 any; var t_ any = t.F_s__711000058; t.F_s__711000058 = nil; s__711000058__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_350 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = s__711000058__1; if linked_351 == nil { temp__1927000414__auto____2 = ifn_352.Invoke_O__O(arg_353) } else { temp__1927000414__auto____2 = linked_351.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_350, arg_353) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000058__3 any = temp__1927000414__auto____2; var tmp1 any; var root_354 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = s__711000058__3; if linked_355 == nil { tmp1 = ifn_356.Invoke_O__O(arg_357) } else { tmp1 = linked_355.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_354, arg_357) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_358 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = s__711000058__3; if linked_359 == nil { c__1927001037__auto____4 = ifn_360.Invoke_O__O(arg_361) } else { c__1927001037__auto____4 = linked_359.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_358, arg_361) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000060__6 any; var root_362 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_363 == nil { b__711000060__6 = ifn_364.Invoke_O__O(arg_365) } else { b__711000060__6 = linked_363.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_362, arg_365) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__376 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(b__711000060__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__375 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class; if fncls__375 == nil { var fncls__375d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, fnbody__376); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class = fncls__375d; tmp3 = fncls__375d } else { tmp3 = fncls__375 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__376, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_377 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any; var root_382 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = b__711000060__6; if linked_383 == nil { arg_380 = ifn_384.Invoke_O__O(arg_385) } else { arg_380 = linked_383.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_382, arg_385) }; var arg_381 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp5 any; var root_386 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = s__711000058__3; if linked_387 == nil { tmp5 = ifn_388.Invoke_O__O(arg_389) } else { tmp5 = linked_387.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_386, arg_389) }; arg_381 = tmp4.Invoke_O__O(tmp5); if linked_378 == nil { return ifn_379.Invoke_O_O__O(arg_380, arg_381) } else { return linked_378.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_377, arg_380, arg_381) } } else { var root_390 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any; var root_395 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = b__711000060__6; if linked_396 == nil { arg_393 = ifn_397.Invoke_O__O(arg_398) } else { arg_393 = linked_396.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_395, arg_398) }; var arg_394 any; if linked_391 == nil { return ifn_392.Invoke_O_O__O(arg_393, arg_394) } else { return linked_391.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_390, arg_393, arg_394) } } } else { var vec__711000070__4 any; var root_399 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = s__711000058__3; if linked_400 == nil { vec__711000070__4 = ifn_401.Invoke_O__O(arg_402) } else { vec__711000070__4 = linked_400.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_399, arg_402) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_403 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_405 lang.IFn; _ = ___6; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__5); if linked_404 == nil { tmp6 = ifn_405.Invoke_O__O(arg_406) } else { tmp6 = linked_404.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_403, arg_406) }; if jrt.J2g_Truth(tmp6) { var root_407 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = k__5; var arg_411 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp8 any; var root_412 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = s__711000058__3; if linked_413 == nil { tmp8 = ifn_414.Invoke_O__O(arg_415) } else { tmp8 = linked_413.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_412, arg_415) }; arg_411 = tmp7.Invoke_O__O(tmp8); if linked_408 == nil { return ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { return linked_408.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) } } else { var tmp9 any; var root_416 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = s__711000058__3; if linked_417 == nil { tmp9 = ifn_418.Invoke_O__O(arg_419) } else { tmp9 = linked_417.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_416, arg_419) }; s__711000058__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Ctor_O_I_O(c__b__711000060 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000060 = c__b__711000060; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Invoke_O__O(self any) any { { var i__711000059__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000059__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000066__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000059__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_366 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_368 lang.IFn; _ = ___4; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__3); if linked_367 == nil { tmp2 = ifn_368.Invoke_O__O(arg_369) } else { tmp2 = linked_367.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_366, arg_369) }; if jrt.J2g_Truth(tmp2) { var root_370 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = t.F_b__711000060; var arg_374 any = k__3; if linked_371 == nil { ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { linked_371.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) }; i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } else { i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_declarers_A_New() *A_arbace_j2g_dyn_declarers_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_j2g_dyn_declarers_A) Ctor() {}
//line :78:1
func (t *A_arbace_j2g_dyn_declarers_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var vec__711000078__3 any; var root_458 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_460 lang.IFn; if




	linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); if linked_459 == nil { vec__711000078__3 = ifn_460.Invoke_O__O(arg_461) } else { vec__711000078__3 = linked_459.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_458, arg_461) }; var i__4 any = /*line :78:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; if





	lang.Util_Identical_O_O__Z_NoInit(i__4, ifaces__0) { tmp1 = ix__5 } else { var lockee__1927000360__auto____6 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var tmp2 *lang.Compiler_AOTFn; var fnbody__603 any = A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(ifaces__0, lockee__1927000360__auto____6); var tmp3 *jrt.Class
		var fncls__602 /*line :84:1*/*jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class

		if fncls__602 == nil { var fncls__602d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__603); A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class = fncls__602d; tmp3 = fncls__602d } else { tmp3 = fncls__602 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__603, tmp3, nil); tmp1 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O() }; return /*line :84:1*/ lang.RT_Get_O_O__O_NoInit(tmp1, k__1) }

func A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Ctor_O_O(c__ifaces, c__lockee__1927000360__auto__ any) { t.F_ifaces = c__ifaces; t.F_lockee__1927000360__auto__ = c__lockee__1927000360__auto__ }
//line :86:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Invoke_O__O(self any) any { var locklocal__1927000361__auto____3 any; var t_ any = t.F_lockee__1927000360__auto__; t.F_lockee__1927000360__auto__ = nil; locklocal__1927000361__auto____3 = t_; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____3); var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__711000082__6 any; var root_462 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_464 lang.IFn
										if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); if linked_463 == nil { vec__711000082__6 = ifn_464.Invoke_O__O(arg_465) } else { vec__711000082__6 = linked_463.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_462, arg_465) }
//line :86:1
	var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(1), nil)

	if lang.Util_Identical_O_O__Z_NoInit(i__7, t.F_ifaces) { tmp1 = ix__8 } else { var ix__9 any; var root_466 any = A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_468 lang.IFn

		if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any; var fnbody__596 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New(); var tmp2 *jrt.Class; var fncls__595 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class; if fncls__595 == nil { var fncls__595d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class = fncls__595d; tmp2 = fncls__595d } else { tmp2 = fncls__595 }; arg_469 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__596, tmp2, nil); var arg_470 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_471 any = t.F_ifaces; if linked_467 == nil { ix__9 = ifn_468.Invoke_O_O_O__O(arg_469, arg_470, arg_471) } else { ix__9 = linked_467.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_466, arg_469, arg_470, arg_471)
		}




		var root_597 any = A_arbace_j2g_dyn_A_const_67.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var arg_601 any; var tmp3 any; var t__2 any = t.F_ifaces; t.F_ifaces = nil; tmp3 = t__2; arg_601 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, ix__9); if linked_598 == nil { ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { linked_598.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }
//line :88:1
		tmp1 = ix__9 } }; return nil }(); /*line :86:1*/lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____3); if tmp4 != nil { panic(tmp4) }; return tmp1 }



func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Invoke_O_O_O__O(self, ix__1, j__2 any) any {
	var root_472 any = A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any; var fnbody__491 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(j__2); var tmp1 *jrt.Class; var fncls__490 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class; if fncls__490 == nil { var fncls__490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__491); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class = fncls__490d; tmp1 = fncls__490d } else { tmp1 = fncls__490 }; arg_475 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__491, tmp1, nil); var arg_476 any = ix__1; var arg_477 any; var root_492 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_494 lang.IFn

	if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any; var iter__1927001039__auto____3 any; var fnbody__590 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New(); var tmp2 *jrt.Class; var fncls__589 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class; if fncls__589 == nil { var fncls__589d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class = fncls__589d; tmp2 = fncls__589d } else { tmp2 = fncls__589 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__590, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_591 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = j__2; if linked_592 == nil { tmp4 = ifn_593.Invoke_O__O(arg_594) } else { tmp4 = linked_592.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_591, arg_594) }; arg_495 = tmp3.Invoke_O__O(tmp4); if linked_493 == nil { arg_477 = ifn_494.Invoke_O__O(arg_495) } else { arg_477 = linked_493.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_492, arg_495) }
//line :91:1
	if linked_473 == nil { return ifn_474.Invoke_O_O_O__O(arg_475, arg_476, arg_477) } else { return linked_473.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_472, arg_475, arg_476, arg_477) } }
//line :91:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(p0 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A{}; t.Ctor_O(p0); return t }
//line :91:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Ctor_O(c__j any) { t.F_j = c__j }
//line :91:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Invoke_O_O_O__O(self, ix__1, kk__2 any) any { var root_478 any = A_arbace_j2g_dyn_A_const_62.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = ix__1; var arg_482 any = kk__2; var arg_483 any; var root_485 any = A_arbace_j2g_dyn_A_const_63.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(); var arg_489 any = lang.PersistentVector_EMPTY.Ref(); if linked_486 == nil { arg_483 = ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { arg_483 = linked_486.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) }; var arg_484 any = t.F_j; if linked_479 == nil { return ifn_480.Invoke_O_O_O_O__O(arg_481, arg_482, arg_483, arg_484) } else { return linked_479.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_478, arg_481, arg_482, arg_483, arg_484) } }

func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Invoke_O_O__O(self, s__711000089__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__588 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(s__711000089__1, self); var tmp2 *jrt.Class; var fncls__587 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class; if fncls__587 == nil { var fncls__587d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__588); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class = fncls__587d; tmp2 = fncls__587d } else { tmp2 = fncls__587 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__588, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Ctor_O_O(c__s__711000089, c__iter__711000088 any) { t.F_s__711000089 = c__s__711000089; t.F_iter__711000088 = c__iter__711000088 }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Invoke_O__O(self any) any { { var s__711000089__1 any; var t_ any = t.F_s__711000089; t.F_s__711000089 = nil; s__711000089__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_496 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = s__711000089__1; if linked_497 == nil { temp__1927000414__auto____2 = ifn_498.Invoke_O__O(arg_499) } else { temp__1927000414__auto____2 = linked_497.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_496, arg_499) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_500 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = xs__1927001018__auto____3; if linked_501 == nil { c__4 = ifn_502.Invoke_O__O(arg_503) } else { c__4 = linked_501.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_500, arg_503) }; var iterys__1927001035__auto____5 any; var fnbody__565 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New(); var tmp1 *jrt.Class; var fncls__564 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class; if fncls__564 == nil { var fncls__564d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class = fncls__564d; tmp1 = fncls__564d } else { tmp1 = fncls__564 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__565, tmp1, nil); var fs__1927001036__auto____6 any; var root_566 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_570 any = A_arbace_j2g_dyn_A_const_66.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = c__4; if linked_571 == nil { tmp3 = ifn_572.Invoke_O__O(arg_573) } else { tmp3 = linked_571.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_570, arg_573) }; arg_569 = tmp2.Invoke_O__O(tmp3); if linked_567 == nil { fs__1927001036__auto____6 = ifn_568.Invoke_O__O(arg_569) } else { fs__1927001036__auto____6 = linked_567.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_566, arg_569) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_574 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = fs__1927001036__auto____6; var arg_578 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000088); var tmp5 any; var root_579 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = s__711000089__1; if linked_580 == nil { tmp5 = ifn_581.Invoke_O__O(arg_582) } else { tmp5 = linked_580.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_579, arg_582) }; arg_578 = tmp4.Invoke_O__O(tmp5); if linked_575 == nil { return ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { return linked_575.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) } } else { var tmp6 any; var root_583 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = s__711000089__1; if linked_584 == nil { tmp6 = ifn_585.Invoke_O__O(arg_586) } else { tmp6 = linked_584.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_583, arg_586) }; s__711000089__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Invoke_O_O__O(self, s__711000091__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__563 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(self, s__711000091__1); var tmp2 *jrt.Class; var fncls__562 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class; if fncls__562 == nil { var fncls__562d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__563); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class = fncls__562d; tmp2 = fncls__562d } else { tmp2 = fncls__562 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__563, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Ctor_O_O(c__iter__711000090, c__s__711000091 any) { t.F_iter__711000090 = c__iter__711000090; t.F_s__711000091 = c__s__711000091 }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Invoke_O__O(self any) any { { var s__711000091__1 any; var t_ any = t.F_s__711000091; t.F_s__711000091 = nil; s__711000091__1 = t_; for { var temp__1927000414__auto____2 any; var root_504 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = s__711000091__1; if linked_505 == nil { temp__1927000414__auto____2 = ifn_506.Invoke_O__O(arg_507) } else { temp__1927000414__auto____2 = linked_505.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_504, arg_507) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000091__3 any = temp__1927000414__auto____2; var tmp1 any; var root_508 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = s__711000091__3; if linked_509 == nil { tmp1 = ifn_510.Invoke_O__O(arg_511) } else { tmp1 = linked_509.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_508, arg_511) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_512 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = s__711000091__3; if linked_513 == nil { c__1927001037__auto____4 = ifn_514.Invoke_O__O(arg_515) } else { c__1927001037__auto____4 = linked_513.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_512, arg_515) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000093__6 any; var root_516 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_517 == nil { b__711000093__6 = ifn_518.Invoke_O__O(arg_519) } else { b__711000093__6 = linked_517.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_516, arg_519) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__526 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(b__711000093__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__525 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class; if fncls__525 == nil { var fncls__525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__526); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class = fncls__525d; tmp3 = fncls__525d } else { tmp3 = fncls__525 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__526, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_527 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var root_532 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = b__711000093__6; if linked_533 == nil { arg_530 = ifn_534.Invoke_O__O(arg_535) } else { arg_530 = linked_533.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_532, arg_535) }; var arg_531 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp5 any; var root_536 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = s__711000091__3; if linked_537 == nil { tmp5 = ifn_538.Invoke_O__O(arg_539) } else { tmp5 = linked_537.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_536, arg_539) }; arg_531 = tmp4.Invoke_O__O(tmp5); if linked_528 == nil { return ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { return linked_528.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) } } else { var root_540 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any; var root_545 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = b__711000093__6; if linked_546 == nil { arg_543 = ifn_547.Invoke_O__O(arg_548) } else { arg_543 = linked_546.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_545, arg_548) }; var arg_544 any; if linked_541 == nil { return ifn_542.Invoke_O_O__O(arg_543, arg_544) } else { return linked_541.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_540, arg_543, arg_544) } } } else { var mm__4 any; var root_549 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = s__711000091__3; if linked_550 == nil { mm__4 = ifn_551.Invoke_O__O(arg_552) } else { mm__4 = linked_550.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_549, arg_552) }; var root_553 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4)); var arg_557 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp7 any; var root_558 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = s__711000091__3; if linked_559 == nil { tmp7 = ifn_560.Invoke_O__O(arg_561) } else { tmp7 = linked_559.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_558, arg_561) }; arg_557 = tmp6.Invoke_O__O(tmp7); if linked_554 == nil { return ifn_555.Invoke_O_O__O(arg_556, arg_557) } else { return linked_554.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_553, arg_556, arg_557) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Ctor_O_I_O(c__b__711000093 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000093 = c__b__711000093; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Invoke_O__O(self any) any { { var i__711000092__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000092__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000092__1)); var root_520 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = t.F_b__711000093; var arg_524 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2)); if linked_521 == nil { ifn_522.Invoke_O_O__O(arg_523, arg_524) } else { linked_521.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_520, arg_523, arg_524) }; i__711000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000092__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_dyn_defaults_for_A_New() *A_arbace_j2g_dyn_defaults_for_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var cands__3 any; var iter__1927001039__auto____3 any; var fnbody__725 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(k__1); var tmp1 *jrt.Class; var fncls__724 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class; if


	fncls__724 == nil { var fncls__724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__725); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class = fncls__724d; tmp1 = fncls__724d } else { tmp1 = fncls__724 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__725, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_737 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, A_arbace_j2g_dyn_declarers_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = ifaces__0; var arg_741 any = k__1; if linked_738 == nil { tmp3 = ifn_739.Invoke_O_O__O(arg_740, arg_741) } else { tmp3 = linked_738.(*A_arbace_j2g_dyn_declarers_A).Invoke_O_O_O__O(root_737, arg_740, arg_741) }; cands__3 = tmp2.Invoke_O__O(tmp3); var root_726 any =



	A_arbace_j2g_dyn_A_const_76.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any; var fnbody__736 any = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New(); var tmp4 *jrt.Class; var fncls__735 *jrt.Class = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class; if fncls__735 == nil { var fncls__735d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class = fncls__735d; tmp4 = fncls__735d } else { tmp4 = fncls__735 }; arg_729 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__736, tmp4, nil); var arg_730 any = cands__3; if linked_727 == nil { return ifn_728.Invoke_O_O__O(arg_729, arg_730) } else { return linked_727.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_726, arg_729, arg_730) } }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(p0 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Invoke_O_O__O(self, s__711000108__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__723 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(self, t.F_k, s__711000108__1); var tmp2 *jrt.Class; var fncls__722 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class; if fncls__722 == nil { var fncls__722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__723); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class = fncls__722d; tmp2 = fncls__722d } else { tmp2 = fncls__722 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__723, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Ctor_O_O_O(c__iter__711000107, c__k, c__s__711000108 any) { t.F_iter__711000107 = c__iter__711000107; t.F_k = c__k; t.F_s__711000108 = c__s__711000108 }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Invoke_O__O(self any) any { { var s__711000108__1 any; var t_ any = t.F_s__711000108; t.F_s__711000108 = nil; s__711000108__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_604 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = s__711000108__1; if linked_605 == nil { temp__1927000414__auto____2 = ifn_606.Invoke_O__O(arg_607) } else { temp__1927000414__auto____2 = linked_605.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_604, arg_607) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000108__3 any = temp__1927000414__auto____2; var tmp1 any; var root_608 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = s__711000108__3; if linked_609 == nil { tmp1 = ifn_610.Invoke_O__O(arg_611) } else { tmp1 = linked_609.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_608, arg_611) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_612 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = s__711000108__3; if linked_613 == nil { c__1927001037__auto____4 = ifn_614.Invoke_O__O(arg_615) } else { c__1927001037__auto____4 = linked_613.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_612, arg_615) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000110__6 any; var root_616 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_617 == nil { b__711000110__6 = ifn_618.Invoke_O__O(arg_619) } else { b__711000110__6 = linked_617.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_616, arg_619) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__654 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(t.F_k, b__711000110__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__653 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class; if fncls__653 == nil { var fncls__653d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__654); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class = fncls__653d; tmp3 = fncls__653d } else { tmp3 = fncls__653 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__654, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_655 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any; var root_660 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = b__711000110__6; if linked_661 == nil { arg_658 = ifn_662.Invoke_O__O(arg_663) } else { arg_658 = linked_661.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_660, arg_663) }; var arg_659 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp5 any; var root_664 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = s__711000108__3; if linked_665 == nil { tmp5 = ifn_666.Invoke_O__O(arg_667) } else { tmp5 = linked_665.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_664, arg_667) }; arg_659 = tmp4.Invoke_O__O(tmp5); if linked_656 == nil { return ifn_657.Invoke_O_O__O(arg_658, arg_659) } else { return linked_656.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_655, arg_658, arg_659) } } else { var root_668 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any; var root_673 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = b__711000110__6; if linked_674 == nil { arg_671 = ifn_675.Invoke_O__O(arg_676) } else { arg_671 = linked_674.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_673, arg_676) }; var arg_672 any; if linked_669 == nil { return ifn_670.Invoke_O_O__O(arg_671, arg_672) } else { return linked_669.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_668, arg_671, arg_672) } } } else { var j__4 any; var root_677 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = s__711000108__3; if linked_678 == nil { j__4 = ifn_679.Invoke_O__O(arg_680) } else { j__4 = linked_678.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_677, arg_680) }; var impl__5 any; var root_681 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_683 lang.IFn
														if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = j__4; var arg_685 any = t.F_k; if linked_682 == nil { impl__5 = ifn_683.Invoke_O_O__O(arg_684, arg_685) } else { impl__5 = linked_682.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_681, arg_684, arg_685) }
//line :103:1
	var tmp6 any
	var and__1927000168__auto____6 any = impl__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp7 any = A_arbace_j2g_dyn_A_const_69; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__5)); if and__1927000168__auto____7 { var root_686 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__5); if linked_687 == nil { tmp6 = ifn_688.Invoke_O__O(arg_689) } else { tmp6 = linked_687.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_686, arg_689) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = and__1927000168__auto____6 }
//line :103:1
	if jrt.J2g_Truth(tmp6) { var root_690 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any; var tmp8 any; var root_695 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_695, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_697 lang.IFn


		if linked_696 == nil { ifn_697 = lang.IFn_Cast(root_695) } else { ifn_697 = nil }; var arg_698 any = A_arbace_j2g_dyn_A_const_73; var arg_699 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__5); var arg_700 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp10 any; var root_701 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any; var root_706 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = t.F_k; if linked_707 == nil { arg_704 = ifn_708.Invoke_O__O(arg_709) } else { arg_704 = linked_707.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_706, arg_709) }; var arg_705 any; var root_710 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = t.F_k; if linked_711 == nil { arg_705 = ifn_712.Invoke_O__O(arg_713) } else { arg_705 = linked_711.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_710, arg_713) }; if linked_702 == nil { tmp10 = ifn_703.Invoke_O_O__O(arg_704, arg_705) } else { tmp10 = linked_702.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_701, arg_704, arg_705) }; arg_700 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_696 == nil { tmp8 = ifn_697.Invoke_O_O_O__O(arg_698, arg_699, arg_700) } else { tmp8 = linked_696.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_695, arg_698, arg_699, arg_700) }
//line :103:1
		arg_693 = lang.Tuple_Create_O_O__IPersistentVector(j__4, tmp8); var arg_694 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp12 any; var root_714 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = s__711000108__3; if linked_715 == nil { tmp12 = ifn_716.Invoke_O__O(arg_717) } else { tmp12 = linked_715.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_714, arg_717) }; arg_694 = tmp11.Invoke_O__O(tmp12); if linked_691 == nil { return ifn_692.Invoke_O_O__O(arg_693, arg_694) } else { return linked_691.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_690, arg_693, arg_694) } } else { var tmp13 any; var root_718 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = s__711000108__3; if linked_719 == nil { tmp13 = ifn_720.Invoke_O__O(arg_721) } else { tmp13 = linked_719.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_718, arg_721) }; s__711000108__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Ctor_O_O_I_O(c__k, c__b__711000110 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_b__711000110 = c__b__711000110; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Invoke_O__O(self any) any { { var i__711000109__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000109__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000109__1)); var impl__3 any; var root_620 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_622 lang.IFn
																if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = j__2; var arg_624 any = t.F_k; if linked_621 == nil { impl__3 = ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { impl__3 = linked_621.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_620, arg_623, arg_624) }
//line :103:1
	var tmp2 any
	var and__1927000168__auto____4 any = impl__3
	if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp3 any = A_arbace_j2g_dyn_A_const_69; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__3)); if and__1927000168__auto____5 { var root_625 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__3); if linked_626 == nil { tmp2 = ifn_627.Invoke_O__O(arg_628) } else { tmp2 = linked_626.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_625, arg_628) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = and__1927000168__auto____4 }
//line :103:1
	if jrt.J2g_Truth(tmp2) { var root_629 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = t.F_b__711000110; var arg_633 any; var tmp4 any; var root_634 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_636 lang.IFn


		if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = A_arbace_j2g_dyn_A_const_73; var arg_638 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__3); var arg_639 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp6 any; var root_640 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any; var root_645 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = t.F_k; if linked_646 == nil { arg_643 = ifn_647.Invoke_O__O(arg_648) } else { arg_643 = linked_646.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_645, arg_648) }; var arg_644 any; var root_649 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = t.F_k; if linked_650 == nil { arg_644 = ifn_651.Invoke_O__O(arg_652) } else { arg_644 = linked_650.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_649, arg_652) }; if linked_641 == nil { tmp6 = ifn_642.Invoke_O_O__O(arg_643, arg_644) } else { tmp6 = linked_641.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_640, arg_643, arg_644) }; arg_639 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_635 == nil { tmp4 = ifn_636.Invoke_O_O_O__O(arg_637, arg_638, arg_639) } else { tmp4 = linked_635.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_634, arg_637, arg_638, arg_639) }
//line :103:1
		arg_633 = lang.Tuple_Create_O_O__IPersistentVector(j__2, tmp4); if linked_630 == nil { ifn_631.Invoke_O_O__O(arg_632, arg_633) } else { linked_630.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_629, arg_632, arg_633) }; i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } else { i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New() *A_arbace_j2g_dyn_defaults_for_fn__711000118_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_fn__711000118_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Ctor() {}
//line :107:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Invoke_O_O__O(self, p__711000117__1 any) any { var vec__711000119__2 any = p__711000117__1; var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000119__2, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_731 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_731, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_733 lang.IFn; if linked_732 == nil { ifn_733 = lang.IFn_Cast(root_731) } else { ifn_733 = nil }; var arg_734 any = j__3; if linked_732 == nil { tmp1 = ifn_733.Invoke_O__O(arg_734) } else { tmp1 = linked_732.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_731, arg_734) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp1)))).Ref() }

func A_arbace_j2g_dyn_box_arg_A_New() *A_arbace_j2g_dyn_box_arg_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_box_arg_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_dyn_box_arg_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_dyn_box_arg_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {


	var tmp1 any; var root_742 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = d__1; if linked_743 == nil { tmp1 = ifn_744.Invoke_O__O(arg_745) } else { tmp1 = linked_743.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_742, arg_745) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_82, p__0) } else { var tmp2 any; var root_746 any = A_arbace_j2g_dyn_A_const_80.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_748 lang.IFn
		if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = d__1; if linked_747 == nil { tmp2 = ifn_748.Invoke_O__O(arg_749) } else { tmp2 = linked_747.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_746, arg_749) }
//line :112:1
		if jrt.J2g_Truth(tmp2) {
			return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_83, p__0) } else {
//line :112:1
				if A_arbace_j2g_dyn_A_const_81 != nil { return p__0 } else { return nil
				}
			}
	} }
func A_arbace_j2g_dyn_convert_result_A_New() *A_arbace_j2g_dyn_convert_result_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_dyn_convert_result_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_dyn_convert_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_12) { return r__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1)) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any; var root_805 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = A_arbace_j2g_dyn_A_const_73; var arg_809 any = Lit_18; var arg_810 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp4 any; var root_811 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1); var arg_815 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref(); if linked_812 == nil { tmp4 = ifn_813.Invoke_O_O__O(arg_814, arg_815) } else { tmp4 = linked_812.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_811, arg_814, arg_815) }; arg_810 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_806 == nil { tmp2 = ifn_807.Invoke_O_O_O__O(arg_808, arg_809, arg_810) } else { tmp2 = linked_806.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_805, arg_808, arg_809, arg_810) }; return tmp1.Invoke_O_O__O(tmp2, r__0) } else {
//line :119:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_84).Invoke_O__O(d__1)) {


				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_94; var tmp7 any; var root_816 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = A_arbace_j2g_dyn_A_const_73; var arg_820 any = d__1; if linked_817 == nil { tmp7 = ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { tmp7 = linked_817.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) }; var tmp8 any = tmp7; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_96; var tmp11 any
				if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_20) { tmp11 = A_arbace_j2g_dyn_A_const_97 } else { tmp11 = A_arbace_j2g_dyn_A_const_98 }
//line :122:1
				return tmp5.Invoke_O_O_O__O(tmp6, tmp8, tmp9.Invoke_O_O_O__O(tmp10, tmp11, r__0)) } else {
//line :119:1
					var tmp12 any; var root_750 any = A_arbace_j2g_dyn_A_const_85.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_752 lang.IFn




					if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = d__1; if linked_751 == nil { tmp12 = ifn_752.Invoke_O__O(arg_753) } else { tmp12 = linked_751.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_750, arg_753) }
//line :119:1
					if jrt.J2g_Truth(tmp12) {




						var root_754 any = A_arbace_j2g_dyn_A_const_86.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = A_arbace_j2g_dyn_A_const_73; var arg_758 any = A_arbace_j2g_dyn_A_const_87; var arg_759 any = r__0; var arg_760 any = d__1; var arg_761 any; var e__3 any; var root_762 any = A_arbace_j2g_dyn_A_const_88.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_764 lang.IFn
						if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = d__1; if linked_763 == nil { e__3 = ifn_764.Invoke_O__O(arg_765) } else { e__3 = linked_763.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_762, arg_765) }
						var tmp13 any; var root_766 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = e__3; if linked_767 == nil { tmp13 = ifn_768.Invoke_O__O(arg_769) } else { tmp13 = linked_767.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_766, arg_769) }; if jrt.J2g_Truth(tmp13) { arg_761 = nil } else {
							var tmp14 *lang.Compiler_AOTFn; var fnbody__804 any = A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(e__3); var tmp15 *jrt.Class; var fncls__803 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class; if fncls__803 == nil { var fncls__803d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__804); A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class = fncls__803d; tmp15 = fncls__803d } else { tmp15 = fncls__803 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__804, tmp15, nil); arg_761 = Up_Compiler_AOTFn_IFn(tmp14).Invoke__O() }
//line :124:1
						if linked_755 == nil { return ifn_756.Invoke_O_O_O_O_O__O(arg_757, arg_758, arg_759, arg_760, arg_761) } else { return linked_755.(*aot_arbace_j2g_model.A_arbace_j2g_model_array_test_A).Invoke_O_O_O_O_O_O__O(root_754, arg_757, arg_758, arg_759, arg_760, arg_761) } } else {
//line :119:1
							if A_arbace_j2g_dyn_A_const_81 != nil {












								var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any; var root_821 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = A_arbace_j2g_dyn_A_const_73; var arg_825 any; var root_827 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = d__1; if linked_828 == nil { arg_825 = ifn_829.Invoke_O__O(arg_830) } else { arg_825 = linked_828.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_827, arg_830) }; var arg_826 any = Lit_22; if linked_822 == nil { tmp17 = ifn_823.Invoke_O_O_O__O(arg_824, arg_825, arg_826) } else { tmp17 = linked_822.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_821, arg_824, arg_825, arg_826) }; return tmp16.Invoke_O_O__O(tmp17, r__0) } else {
//line :119:1
									return nil
								}
						}
				}
		}
	}
}

func A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(p0 any) *A_arbace_j2g_dyn_convert_result_fn__711000126_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :127:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Invoke_O__O(self any) any { { var e__1 any; var t_ any = t.F_e; t.F_e = nil; e__1 = t_; var n__2 int64 = 0; L1: for { var tmp1 any; var root_770 any = A_arbace_j2g_dyn_A_const_85.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = e__1; if linked_771 == nil { tmp1 = ifn_772.Invoke_O__O(arg_773) } else { tmp1 = linked_771.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_770, arg_773) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_799 any = A_arbace_j2g_dyn_A_const_88.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = e__1; if linked_800 == nil { tmp2 = ifn_801.Invoke_O__O(arg_802) } else { tmp2 = linked_800.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_799, arg_802) }; e__1, n__2 = tmp2, lang.Numbers_Inc_J__J_NoInit(n__2); continue L1 } else {
											var tmp3 any; var root_774 any = A_arbace_j2g_dyn_A_const_89.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any; var fnbody__780 any = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New(); var tmp4 *jrt.Class; var fncls__779 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class; if fncls__779 == nil { var fncls__779d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class = fncls__779d; tmp4 = fncls__779d } else { tmp4 = fncls__779 }; arg_777 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__780, tmp4, nil); var arg_778 any; var tmp5 any; var root_781 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = e__1; if linked_782 == nil { tmp5 = ifn_783.Invoke_O__O(arg_784) } else { tmp5 = linked_782.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_781, arg_784) }; if jrt.J2g_Truth(tmp5) {
												var root_785 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_92.GetRawRoot__O()).Invoke_O__O(e__1))).Ref(); if linked_786 == nil { arg_778 = ifn_787.Invoke_O__O(arg_788) } else { arg_778 = linked_786.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_785, arg_788) } } else {
													var root_789 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = A_arbace_j2g_dyn_A_const_73; var arg_793 any; var root_795 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = e__1; if linked_796 == nil { arg_793 = ifn_797.Invoke_O__O(arg_798) } else { arg_793 = linked_796.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_795, arg_798) }; var arg_794 any = Lit_25; if linked_790 == nil { arg_778 = ifn_791.Invoke_O_O_O__O(arg_792, arg_793, arg_794) } else { arg_778 = linked_790.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_789, arg_792, arg_793, arg_794) } }
//line :128:1
	if linked_775 == nil { tmp3 = ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { tmp3 = linked_775.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_774, arg_777, arg_778) }; return lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(n__2)) } } }; /*line :127:1*/panic("j2g: unreachable") }
func A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New() *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Ctor() {}
//line :128:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Invoke_O_O__O(self, p1__711000125_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_90, p1__711000125_SHARP___1) }





func A_arbace_j2g_dyn_call_impl_A_New() *A_arbace_j2g_dyn_call_impl_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_call_impl_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_j2g_dyn_call_impl_A) Ctor() {}
//line :134:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O_O__O(self, this__0, args__1 any) any { var n__3 int64 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(args__1))); if





	lang.Numbers_Lte_J_J__Z_NoInit(n__3, 20) {
		var root_831 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_835 any; var root_839 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp2 any; var root_843 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = Lit_11; var arg_847 any; var root_848 any = A_arbace_j2g_dyn_A_const_100.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var root_853 any = A_arbace_j2g_dyn_A_const_101.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref(); var arg_857 any = Lit_12; if linked_854 == nil { arg_851 = ifn_855.Invoke_O_O__O(arg_856, arg_857) } else { arg_851 = linked_854.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_853, arg_856, arg_857) }; var arg_852 any = Lit_12; if linked_849 == nil { arg_847 = ifn_850.Invoke_O_O__O(arg_851, arg_852) } else { arg_847 = linked_849.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_848, arg_851, arg_852) }; if linked_844 == nil { tmp2 = ifn_845.Invoke_O_O__O(arg_846, arg_847) } else { tmp2 = linked_844.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_843, arg_846, arg_847) }; arg_842 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_840 == nil { arg_835 = ifn_841.Invoke_O__O(arg_842) } else { arg_835 = linked_840.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_839, arg_842) }; var arg_836 any = A_arbace_j2g_dyn_A_const_102; var arg_837 any = this__0; var arg_838 any = args__1; if linked_832 == nil { return ifn_833.Invoke_O_O_O_O_O__O(arg_834, arg_835, arg_836, arg_837, arg_838) } else { return linked_832.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_831, arg_834, arg_835, arg_836, arg_837, arg_838) } } else {

			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyn_A_const_103; var tmp5 any = A_arbace_j2g_dyn_A_const_104; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_105; var tmp8 any; var root_858 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_862 any = A_arbace_j2g_dyn_A_const_106; var arg_863 any = A_arbace_j2g_dyn_A_const_107; var arg_864 any = this__0; var arg_865 any = args__1; if linked_859 == nil { tmp8 = ifn_860.Invoke_O_O_O_O_O__O(arg_861, arg_862, arg_863, arg_864, arg_865) } else { tmp8 = linked_859.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_858, arg_861, arg_862, arg_863, arg_864, arg_865) }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8)) } }
//line :134:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O__O(self, args__0 any) any {


	var root_866 any = A_arbace_j2g_dyn_A_const_108.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = A_arbace_j2g_dyn_A_const_109; var arg_870 any = args__0; if linked_867 == nil { return ifn_868.Invoke_O_O__O(arg_869, arg_870) } else { return linked_867.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_866, arg_869, arg_870)
	}
}







func A_arbace_j2g_dyn_abstract_text_A_New() *A_arbace_j2g_dyn_abstract_text_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Ctor() {}
//line :147:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Invoke_O_O_O__O(self, ifaces__0, p__711000134__1 any) any { var vec__711000135__3 any = p__711000134__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000135__3; var vec__711000138__7 any; var root_871 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_873 lang.IFn; if



	linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = desc__5; if linked_872 == nil { vec__711000138__7 = ifn_873.Invoke_O__O(arg_874) } else { vec__711000138__7 = linked_872.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_871, arg_874) }; var ps__8 any = /*line :147:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(1), nil); var declares_QMARK___10 any; var fnbody__887 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(name__4, desc__5); var tmp1 *jrt.Class; var fncls__886 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class; if




	fncls__886 == nil { var fncls__886d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__887); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class = fncls__886d; tmp1 = fncls__886d } else { tmp1 = fncls__886 }; declares_QMARK___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__887, tmp1, nil); var j__11 any; var or__1927000174__auto____11 any; var root_888 any = /*line :147:1*/A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_890 lang.IFn; if





	linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any; var root_892 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = declares_QMARK___10; var arg_896 any = ifaces__0; if linked_893 == nil { arg_891 = ifn_894.Invoke_O_O__O(arg_895, arg_896) } else { arg_891 = linked_893.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_892, arg_895, arg_896) }; if linked_889 == nil { or__1927000174__auto____11 = ifn_890.Invoke_O__O(arg_891) } else { or__1927000174__auto____11 = linked_889.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_888, arg_891) }; if jrt.J2g_Truth(or__1927000174__auto____11) { j__11 = or__1927000174__auto____11 } else {
		var root_897 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any; var root_901 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any; var fnbody__918 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(k__6); var tmp2 *jrt.Class; var fncls__917 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class; if fncls__917 == nil { var fncls__917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__918); A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class = fncls__917d; tmp2 = fncls__917d } else { tmp2 = fncls__917 }; arg_904 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__918, tmp2, nil); var arg_905 any = ifaces__0; if linked_902 == nil { arg_900 = ifn_903.Invoke_O_O__O(arg_904, arg_905) } else { arg_900 = linked_902.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_901, arg_904, arg_905) }; if linked_898 == nil { j__11 = ifn_899.Invoke_O__O(arg_900) } else { j__11 = linked_898.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_897, arg_900) } }; var tmp3 /*line :155:1*/*jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp4 any; var root_919 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = r__9; if linked_920 == nil { tmp4 = ifn_921.Invoke_O__O(arg_922) } else { tmp4 = linked_920.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_919, arg_922) }; var tmp5 any = tmp4; var tmp6 any; var root_923 any = A_arbace_j2g_dyn_A_const_115.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = Lit_3; var arg_927 any; var root_928 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var arg_932 any = ps__8; if linked_929 == nil { arg_927 = ifn_930.Invoke_O_O__O(arg_931, arg_932) } else { arg_927 = linked_929.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_928, arg_931, arg_932) }; if linked_924 == nil { tmp6 = ifn_925.Invoke_O_O__O(arg_926, arg_927) } else { tmp6 = linked_924.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_923, arg_926, arg_927) }; var tmp7 any = tmp6; var tmp8 *jrt.String; if
	jrt.J2g_Truth(j__11) { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil); var tmp10 any; var root_933 any = A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = j__11; var arg_937 any = Lit_5; var arg_938 any = Lit_6; if linked_934 == nil { tmp10 = ifn_935.Invoke_O_O_O__O(arg_936, arg_937, arg_938) } else { tmp10 = linked_934.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_933, arg_936, arg_937, arg_938) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)) } else { tmp8 = nil }; return /*line :155:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, name__4, nil, tmp7, nil, tmp8.Ref(), nil)).Ref() }
//line :152:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A{}; t.Ctor_O_O(p0, p1); return t }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Invoke_O_O__O(self, j__1 any) any { var root_875 any = A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any; var fnbody__881 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(t.F_name, t.F_desc); var tmp1 *jrt.Class; var fncls__880 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class; if fncls__880 == nil { var fncls__880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__881); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class = fncls__880d; tmp1 = fncls__880d } else { tmp1 = fncls__880 }; arg_878 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__881, tmp1, nil); var arg_879 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp3 any; var root_882 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_882, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_884 lang.IFn; if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = j__1; if linked_883 == nil { tmp3 = ifn_884.Invoke_O__O(arg_885) } else { tmp3 = linked_883.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_882, arg_885) }; arg_879 = tmp2.Invoke_O__O(tmp3); if linked_876 == nil { return ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { return linked_876.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) } }
//line :152:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Invoke_O_O__O(self, p1__711000132_SHARP___1 any) any { var tmp1 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(p1__711000132_SHARP___1)); if and__1927000168__auto____2 { var tmp2 any = t.F_desc; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_dyn_A_const_65.Invoke_O__O(p1__711000132_SHARP___1))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :154:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Invoke_O_O__O(self, p1__711000133_SHARP___1 any) any { var root_906 any = A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any; var fnbody__912 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(t.F_k); var tmp1 *jrt.Class; var fncls__911 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class; if fncls__911 == nil { var fncls__911d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__912); A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class = fncls__911d; tmp1 = fncls__911d } else { tmp1 = fncls__911 }; arg_909 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__912, tmp1, nil); var arg_910 any; var root_913 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = p1__711000133_SHARP___1; if linked_914 == nil { arg_910 = ifn_915.Invoke_O__O(arg_916) } else { arg_910 = linked_914.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_913, arg_916) }; if linked_907 == nil { return ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { return linked_907.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_906, arg_909, arg_910) } }
//line :154:1
func A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :154:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Invoke_O_O__O(self, p__711000146__1 any) any { var vec__711000148__2 any = p__711000146__1; var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(kk__3, t.F_k)).Ref() }



func A_arbace_j2g_dyn_iface_fallback_A_New() *A_arbace_j2g_dyn_iface_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Ctor() {}
//line :158:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O_O__O(self, ifaces__0, p__711000154__1, pn__2, r__3, core_QMARK___4 any) any { var vec__711000155__6 any = p__711000154__1; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000155__6; var root_939 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_941 lang.IFn; _ = name__7; _ = desc__8; if





	linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any; var iter__1927001039__auto____10 any; var fnbody__1055 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(r__3, pn__2, core_QMARK___4); var tmp1 *jrt.Class; var fncls__1054 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class; if
	fncls__1054 == nil { var fncls__1054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, fnbody__1055); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class = fncls__1054d; tmp1 = fncls__1054d } else { tmp1 = fncls__1054 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1055, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp3 any; var root_1056 any = A_arbace_j2g_dyn_A_const_129.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, A_arbace_j2g_dyn_defaults_for_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = ifaces__0; var arg_1060 any = k__9; if linked_1057 == nil { tmp3 = ifn_1058.Invoke_O_O__O(arg_1059, arg_1060) } else { tmp3 = linked_1057.(*A_arbace_j2g_dyn_defaults_for_A).Invoke_O_O_O__O(root_1056, arg_1059, arg_1060) }; arg_942 = tmp2.Invoke_O__O(tmp3); var arg_943 any; var tmp4 lang.IFn = /*line :164:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_130; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_131; var tmp8 any = A_arbace_j2g_dyn_A_const_132; var tmp9 any; var root_1061 any = A_arbace_j2g_dyn_A_const_133.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, A_arbace_j2g_dyn_abstract_text_A_fn_class); var ifn_1063 lang.IFn; if




	linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = ifaces__0; var arg_1065 any = k__9; if linked_1062 == nil { tmp9 = ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { tmp9 = linked_1062.(*A_arbace_j2g_dyn_abstract_text_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) }; arg_943 = /*line :164:1*/lang.Tuple_Create_O__IPersistentVector(tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9))); if linked_940 == nil { return ifn_941.Invoke_O_O__O(arg_942, arg_943) } else { return linked_940.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_939, arg_942, arg_943) } }
//line :158:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O__O(self, ifaces__0, k__1, pn__2, r__3 any) any {



	var root_1066 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = ifaces__0; var arg_1070 any = k__1; var arg_1071 any = pn__2; var arg_1072 any = r__3; var arg_1073 any = jrt.Boolean_FALSE.Ref(); if linked_1067 == nil { return ifn_1068.Invoke_O_O_O_O_O__O(arg_1069, arg_1070, arg_1071, arg_1072, arg_1073) } else { return linked_1067.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1066, arg_1069, arg_1070, arg_1071, arg_1072, arg_1073)
	}
}
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Ctor_O_O_O(c__r, c__pn, c__core_QMARK_ any) { t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Invoke_O_O__O(self, s__711000159__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1053 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(self, s__711000159__1, t.F_r, t.F_pn, t.F_core_QMARK_); var tmp2 *jrt.Class; var fncls__1052 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class; if fncls__1052 == nil { var fncls__1052d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, fnbody__1053); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class = fncls__1052d; tmp2 = fncls__1052d } else { tmp2 = fncls__1052 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1053, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :165:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Ctor_O_O_O_O_O(c__iter__711000158, c__s__711000159, c__r, c__pn, c__core_QMARK_ any) { t.F_iter__711000158 = c__iter__711000158; t.F_s__711000159 = c__s__711000159; t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Invoke_O__O(self any) any { { var s__711000159__1 any; var t_ any = t.F_s__711000159; t.F_s__711000159 = nil; s__711000159__1 = t_; for { var temp__1927000414__auto____2 any; var root_944 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = s__711000159__1; if linked_945 == nil { temp__1927000414__auto____2 = ifn_946.Invoke_O__O(arg_947) } else { temp__1927000414__auto____2 = linked_945.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_944, arg_947) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000159__3 any = temp__1927000414__auto____2; var tmp1 any; var root_948 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = s__711000159__3; if linked_949 == nil { tmp1 = ifn_950.Invoke_O__O(arg_951) } else { tmp1 = linked_949.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_948, arg_951) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_952 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = s__711000159__3; if linked_953 == nil { c__1927001037__auto____4 = ifn_954.Invoke_O__O(arg_955) } else { c__1927001037__auto____4 = linked_953.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_952, arg_955) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000161__6 any; var root_956 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_957 == nil { b__711000161__6 = ifn_958.Invoke_O__O(arg_959) } else { b__711000161__6 = linked_957.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_956, arg_959) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__991 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(b__711000161__6, t.F_r, t.F_pn, size__1927001038__auto____5, t.F_core_QMARK_, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__990 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class; if fncls__990 == nil { var fncls__990d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, fnbody__991); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class = fncls__990d; tmp3 = fncls__990d } else { tmp3 = fncls__990 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__991, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_992 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any; var root_997 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = b__711000161__6; if linked_998 == nil { arg_995 = ifn_999.Invoke_O__O(arg_1000) } else { arg_995 = linked_998.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_997, arg_1000) }; var arg_996 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp5 any; var root_1001 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = s__711000159__3; if linked_1002 == nil { tmp5 = ifn_1003.Invoke_O__O(arg_1004) } else { tmp5 = linked_1002.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1001, arg_1004) }; arg_996 = tmp4.Invoke_O__O(tmp5); if linked_993 == nil { return ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { return linked_993.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_992, arg_995, arg_996) } } else { var root_1005 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any; var root_1010 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = b__711000161__6; if linked_1011 == nil { arg_1008 = ifn_1012.Invoke_O__O(arg_1013) } else { arg_1008 = linked_1011.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1010, arg_1013) }; var arg_1009 any; if linked_1006 == nil { return ifn_1007.Invoke_O_O__O(arg_1008, arg_1009) } else { return linked_1006.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1005, arg_1008, arg_1009) } } } else { var vec__711000169__4 any; var root_1014 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = s__711000159__3; if linked_1015 == nil { vec__711000169__4 = ifn_1016.Invoke_O__O(arg_1017) } else { vec__711000169__4 = linked_1015.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1014, arg_1017) }; var j__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(1), nil); var this__7 any
														if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_119; var tmp8 any; var root_1047 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = A_arbace_j2g_dyn_A_const_73; var arg_1051 any = j__5; if linked_1048 == nil { tmp8 = ifn_1049.Invoke_O_O__O(arg_1050, arg_1051) } else { tmp8 = linked_1048.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_1047, arg_1050, arg_1051) }; this__7 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, A_arbace_j2g_dyn_A_const_128) } else { this__7 = A_arbace_j2g_dyn_A_const_118 }
//line :165:1
	var root_1018 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_121; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyn_A_const_122; var tmp13 any = A_arbace_j2g_dyn_A_const_123; var tmp14 any; var root_1023 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1025 lang.IFn

	if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = A_arbace_j2g_dyn_A_const_73; var arg_1027 any = j__5; var arg_1028 any = Lit_25; if linked_1024 == nil { tmp14 = ifn_1025.Invoke_O_O_O__O(arg_1026, arg_1027, arg_1028) } else { tmp14 = linked_1024.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1023, arg_1026, arg_1027, arg_1028) }; var tmp15 any = tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14); var tmp16 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_17, t.F_r) { var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_124; var tmp19 any; var root_1029 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1033 any = fsym__6; var arg_1034 any = this__7; var arg_1035 any = t.F_pn; if linked_1030 == nil { tmp19 = ifn_1031.Invoke_O_O_O_O__O(arg_1032, arg_1033, arg_1034, arg_1035) } else { tmp19 = linked_1030.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1029, arg_1032, arg_1033, arg_1034, arg_1035) }; tmp16 = tmp17.Invoke_O_O_O__O(tmp18, tmp19, A_arbace_j2g_dyn_A_const_127) } else { var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyn_A_const_126; var tmp22 any; var root_1036 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1040 any = fsym__6; var arg_1041 any = this__7; var arg_1042 any = t.F_pn; if linked_1037 == nil { tmp22 = ifn_1038.Invoke_O_O_O_O__O(arg_1039, arg_1040, arg_1041, arg_1042) } else { tmp22 = linked_1037.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1036, arg_1039, arg_1040, arg_1041, arg_1042) }; tmp16 = tmp20.Invoke_O_O__O(tmp21, tmp22) }
//line :167:1
	arg_1021 = tmp9.Invoke_O_O_O__O(tmp10, tmp15, tmp16)
//line :165:1
	var arg_1022 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp24 any; var root_1043 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = s__711000159__3; if linked_1044 == nil { tmp24 = ifn_1045.Invoke_O__O(arg_1046) } else { tmp24 = linked_1044.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1043, arg_1046) }; arg_1022 = tmp23.Invoke_O__O(tmp24); if linked_1019 == nil { return ifn_1020.Invoke_O_O__O(arg_1021, arg_1022) } else { return linked_1019.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1018, arg_1021, arg_1022) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :165:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Ctor_O_O_O_I_O_O(c__b__711000161, c__r, c__pn any, c__size__1927001038__auto__ int32, c__core_QMARK_, c__c__1927001037__auto__ any) { t.F_b__711000161 = c__b__711000161; t.F_r = c__r; t.F_pn = c__pn; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_core_QMARK_ = c__core_QMARK_; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :165:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Invoke_O__O(self any) any { { var i__711000160__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000160__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000165__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000160__1)); var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(1), nil); var this__5 any
																if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_119; var tmp4 any; var root_960 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = A_arbace_j2g_dyn_A_const_73; var arg_964 any = j__3; if linked_961 == nil { tmp4 = ifn_962.Invoke_O_O__O(arg_963, arg_964) } else { tmp4 = linked_961.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_960, arg_963, arg_964) }; this__5 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_j2g_dyn_A_const_120) } else { this__5 = A_arbace_j2g_dyn_A_const_118 }
//line :165:1
	var root_965 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = t.F_b__711000161; var arg_969 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_121; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_122; var tmp9 any = A_arbace_j2g_dyn_A_const_123; var tmp10 any; var root_970 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_972 lang.IFn

	if linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any = A_arbace_j2g_dyn_A_const_73; var arg_974 any = j__3; var arg_975 any = Lit_25; if linked_971 == nil { tmp10 = ifn_972.Invoke_O_O_O__O(arg_973, arg_974, arg_975) } else { tmp10 = linked_971.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_970, arg_973, arg_974, arg_975) }; var tmp11 any = tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10); var tmp12 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_17, t.F_r) { var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyn_A_const_124; var tmp15 any; var root_976 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_980 any = fsym__4; var arg_981 any = this__5; var arg_982 any = t.F_pn; if linked_977 == nil { tmp15 = ifn_978.Invoke_O_O_O_O__O(arg_979, arg_980, arg_981, arg_982) } else { tmp15 = linked_977.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_976, arg_979, arg_980, arg_981, arg_982) }; tmp12 = tmp13.Invoke_O_O_O__O(tmp14, tmp15, A_arbace_j2g_dyn_A_const_125) } else { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_126; var tmp18 any; var root_983 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_987 any = fsym__4; var arg_988 any = this__5; var arg_989 any = t.F_pn; if linked_984 == nil { tmp18 = ifn_985.Invoke_O_O_O_O__O(arg_986, arg_987, arg_988, arg_989) } else { tmp18 = linked_984.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_983, arg_986, arg_987, arg_988, arg_989) }; tmp12 = tmp16.Invoke_O_O__O(tmp17, tmp18) }
//line :167:1
	arg_969 = tmp5.Invoke_O_O_O__O(tmp6, tmp11, tmp12)
//line :165:1
	if linked_966 == nil { ifn_967.Invoke_O_O__O(arg_968, arg_969) } else { linked_966.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_965, arg_968, arg_969) }; i__711000160__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000160__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyn_method_form_A_New() *A_arbace_j2g_dyn_method_form_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_j2g_dyn_method_form_A) Ctor() {}
//line :171:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O_O__O(self, recv__0, i__1, p__711000177__2, fallback__3, this__4 any) any { var vec__711000180__6 any = p__711000177__2; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000180__6; var vec__711000183__10 any; var root_1074 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1076 lang.IFn; _ = k__9; if






	linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = desc__8; if linked_1075 == nil { vec__711000183__10 = ifn_1076.Invoke_O__O(arg_1077) } else { vec__711000183__10 = linked_1075.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1074, arg_1077) }; var ps__11 any = /*line :171:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_1078 any = A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1080 lang.IFn; if







	linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any; var iter__1927001039__auto____13 any; var fnbody__1151 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New(); var tmp1 *jrt.Class; var fncls__1150 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class; if fncls__1150 == nil { var fncls__1150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, nil); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class = fncls__1150d; tmp1 = fncls__1150d } else { tmp1 = fncls__1150 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1151, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp3 any; var root_1152 any = A_arbace_j2g_dyn_A_const_135.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__11)).Ref(); if linked_1153 == nil { tmp3 = ifn_1154.Invoke_O__O(arg_1155) } else { tmp3 = linked_1153.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1152, arg_1155) }; arg_1081 = tmp2.Invoke_O__O(tmp3); if linked_1079 == nil { pn__13 = ifn_1080.Invoke_O__O(arg_1081) } else { pn__13 = linked_1079.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1078, arg_1081) }; var base__14 any; var root_1156 any = /*line :171:1*/A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1158 lang.IFn; if








	linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = name__7; var arg_1160 any = desc__8; if linked_1157 == nil { base__14 = ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { base__14 = linked_1157.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) }; var params__15 any; var root_1161 any = /*line :171:1*/A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1163 lang.IFn; if









	linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any; var root_1165 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any; var root_1170 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = A_arbace_j2g_dyn_A_const_137; var arg_1174 any = recv__0; if linked_1171 == nil { arg_1168 = ifn_1172.Invoke_O_O__O(arg_1173, arg_1174) } else { arg_1168 = linked_1171.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1170, arg_1173, arg_1174) }; var arg_1169 any; var root_1175 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any; var fnbody__1192 any = A_arbace_j2g_dyn_method_form_fn__711000196_A_New(); var tmp4 *jrt.Class; var fncls__1191 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class; if fncls__1191 == nil { var fncls__1191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, nil); A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class = fncls__1191d; tmp4 = fncls__1191d } else { tmp4 = fncls__1191 }; arg_1178 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1192, tmp4, nil); var arg_1179 any = pn__13; var arg_1180 any = ps__11; if linked_1176 == nil { arg_1169 = ifn_1177.Invoke_O_O_O__O(arg_1178, arg_1179, arg_1180) } else { arg_1169 = linked_1176.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1175, arg_1178, arg_1179, arg_1180) }; if linked_1166 == nil { arg_1164 = ifn_1167.Invoke_O_O__O(arg_1168, arg_1169) } else { arg_1164 = linked_1166.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1165, arg_1168, arg_1169) }; if linked_1162 == nil { params__15 = ifn_1163.Invoke_O__O(arg_1164) } else { params__15 = linked_1162.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1161, arg_1164) }; var params__16 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_17, r__12) { params__16 = params__15 } else { var root_1193 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1195 lang.IFn; if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = params__15; var arg_1197 any; var tmp5 any = A_arbace_j2g_dyn_A_const_17; var tmp6 any; var root_1198 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = A_arbace_j2g_dyn_A_const_73; var arg_1202 any = r__12; if linked_1199 == nil { tmp6 = ifn_1200.Invoke_O_O__O(arg_1201, arg_1202) } else { tmp6 = linked_1199.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1198, arg_1201, arg_1202) }; arg_1197 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6)); if linked_1194 == nil { params__16 = ifn_1195.Invoke_O_O__O(arg_1196, arg_1197) } else { params__16 = linked_1194.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1193, arg_1196, arg_1197) } }; var call__17 any; var root_1203 any = /*line :171:1*/A_arbace_j2g_dyn_A_const_108.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_1205 lang.IFn; if











	linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = this__4; var arg_1207 any; var root_1208 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = A_arbace_j2g_dyn_A_const_138.GetRawRoot__O(); var arg_1212 any = pn__13; var arg_1213 any = ps__11; if linked_1209 == nil { arg_1207 = ifn_1210.Invoke_O_O_O__O(arg_1211, arg_1212, arg_1213) } else { arg_1207 = linked_1209.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1208, arg_1211, arg_1212, arg_1213) }; if linked_1204 == nil { call__17 = ifn_1205.Invoke_O_O__O(arg_1206, arg_1207) } else { call__17 = linked_1204.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_1203, arg_1206, arg_1207) }; var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_99.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var tmp9 any = A_arbace_j2g_dyn_A_const_139; var tmp10 any; var root_1223 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any = base__14; if linked_1224 == nil { tmp10 = ifn_1225.Invoke_O__O(arg_1226) } else { tmp10 = linked_1224.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1223, arg_1226) }; var tmp11 any = tmp10; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_dyn_A_const_140; var tmp14 any = A_arbace_j2g_dyn_A_const_141; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_dyn_A_const_142; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_143; var tmp19 any = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15.Invoke_O_O_O__O(tmp16, tmp17.Invoke_O_O__O(tmp18, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_144, A_arbace_j2g_dyn_A_const_145)), i__1)); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyn_A_const_146; var tmp22 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_147, A_arbace_j2g_dyn_A_const_148, nil); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_dyn_A_const_149; var tmp25 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_150, call__17); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_151; var tmp28 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_153, A_arbace_j2g_dyn_A_const_154, A_arbace_j2g_dyn_A_const_155); var tmp29 any; if




	lang.Util_Equiv_O_O__Z_NoInit(Lit_17, r__12) { tmp29 = A_arbace_j2g_dyn_A_const_152 } else { var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_dyn_A_const_156; var tmp32 any; var root_1227 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, A_arbace_j2g_dyn_convert_result_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = A_arbace_j2g_dyn_A_const_158; var arg_1231 any = r__12; if linked_1228 == nil { tmp32 = ifn_1229.Invoke_O_O__O(arg_1230, arg_1231) } else { tmp32 = linked_1228.(*A_arbace_j2g_dyn_convert_result_A).Invoke_O_O_O__O(root_1227, arg_1230, arg_1231) }; tmp29 = tmp30.Invoke_O_O__O(tmp31, tmp32) }; return /*line :184:1*/ tmp7.Invoke_O_O_O_O_O_O__O(tmp8, tmp9, tmp11, params__16, tmp12.Invoke_O_O_O__O(tmp13, tmp19, tmp20.Invoke_O_O_O__O(tmp21, tmp22, tmp23.Invoke_O_O_O__O(tmp24, tmp25, tmp26.Invoke_O_O_O__O(tmp27, tmp28, tmp29)))), lang.IFn_Cast(fallback__3).Invoke_O_O__O(pn__13, r__12)) }
//line :171:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O__O(self, recv__0, i__1, k__2, fallback__3 any) any {




	var root_1232 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = recv__0; var arg_1236 any = i__1; var arg_1237 any = k__2; var arg_1238 any = fallback__3; var arg_1239 any = A_arbace_j2g_dyn_A_const_160; if linked_1233 == nil { return ifn_1234.Invoke_O_O_O_O_O__O(arg_1235, arg_1236, arg_1237, arg_1238, arg_1239) } else { return linked_1233.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1232, arg_1235, arg_1236, arg_1237, arg_1238, arg_1239) } }
//line :171:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O__O(self, ifaces__0, i__1, k__2 any) any {



	var root_1240 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = A_arbace_j2g_dyn_A_const_161; var arg_1244 any = i__1; var arg_1245 any = k__2; var arg_1246 any; var fnbody__1257 any = A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(k__2, ifaces__0); var tmp1 *jrt.Class; var fncls__1256 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class; if fncls__1256 == nil { var fncls__1256d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, fnbody__1257); A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class = fncls__1256d; tmp1 = fncls__1256d } else { tmp1 = fncls__1256 }; arg_1246 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1257, tmp1, nil); var arg_1247 any = A_arbace_j2g_dyn_A_const_162; if linked_1241 == nil { return ifn_1242.Invoke_O_O_O_O_O__O(arg_1243, arg_1244, arg_1245, arg_1246, arg_1247) } else { return linked_1241.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1240, arg_1243, arg_1244, arg_1245, arg_1246, arg_1247) } }
//line :175:1
func A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_fn__711000178_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000178_A{}; t.Ctor_O_O(p0, p1); return t }
//line :175:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :175:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_1248 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = t.F_ifaces; var arg_1252 any = t.F_k; var arg_1253 any = pn__1; var arg_1254 any = r__2; var arg_1255 any = jrt.Boolean_TRUE.Ref(); if linked_1249 == nil { return ifn_1250.Invoke_O_O_O_O_O__O(arg_1251, arg_1252, arg_1253, arg_1254, arg_1255) } else { return linked_1249.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1248, arg_1251, arg_1252, arg_1253, arg_1254, arg_1255) } }



func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New() *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Ctor() {}
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Invoke_O_O__O(self, s__711000187__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1149 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(s__711000187__1, self); var tmp2 *jrt.Class; var fncls__1148 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class; if fncls__1148 == nil { var fncls__1148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, fnbody__1149); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class = fncls__1148d; tmp2 = fncls__1148d } else { tmp2 = fncls__1148 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1149, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :179:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A{}; t.Ctor_O_O(p0, p1); return t }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Ctor_O_O(c__s__711000187, c__iter__711000186 any) { t.F_s__711000187 = c__s__711000187; t.F_iter__711000186 = c__iter__711000186 }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Invoke_O__O(self any) any { { var s__711000187__1 any; var t_ any = t.F_s__711000187; t.F_s__711000187 = nil; s__711000187__1 = t_; for { var temp__1927000414__auto____2 any; var root_1082 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = s__711000187__1; if linked_1083 == nil { temp__1927000414__auto____2 = ifn_1084.Invoke_O__O(arg_1085) } else { temp__1927000414__auto____2 = linked_1083.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1082, arg_1085) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000187__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1086 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = s__711000187__3; if linked_1087 == nil { tmp1 = ifn_1088.Invoke_O__O(arg_1089) } else { tmp1 = linked_1087.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1086, arg_1089) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1090 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = s__711000187__3; if linked_1091 == nil { c__1927001037__auto____4 = ifn_1092.Invoke_O__O(arg_1093) } else { c__1927001037__auto____4 = linked_1091.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1090, arg_1093) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000189__6 any; var root_1094 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1095 == nil { b__711000189__6 = ifn_1096.Invoke_O__O(arg_1097) } else { b__711000189__6 = linked_1095.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1094, arg_1097) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1108 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(b__711000189__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1107 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class; if fncls__1107 == nil { var fncls__1107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, fnbody__1108); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class = fncls__1107d; tmp3 = fncls__1107d } else { tmp3 = fncls__1107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1108, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1109 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any; var root_1114 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = b__711000189__6; if linked_1115 == nil { arg_1112 = ifn_1116.Invoke_O__O(arg_1117) } else { arg_1112 = linked_1115.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1114, arg_1117) }; var arg_1113 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp5 any; var root_1118 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any = s__711000187__3; if linked_1119 == nil { tmp5 = ifn_1120.Invoke_O__O(arg_1121) } else { tmp5 = linked_1119.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1118, arg_1121) }; arg_1113 = tmp4.Invoke_O__O(tmp5); if linked_1110 == nil { return ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { return linked_1110.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) } } else { var root_1122 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1124 lang.IFn; if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any; var root_1127 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = b__711000189__6; if linked_1128 == nil { arg_1125 = ifn_1129.Invoke_O__O(arg_1130) } else { arg_1125 = linked_1128.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1127, arg_1130) }; var arg_1126 any; if linked_1123 == nil { return ifn_1124.Invoke_O_O__O(arg_1125, arg_1126) } else { return linked_1123.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1122, arg_1125, arg_1126) } } } else { var j__4 any; var root_1131 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = s__711000187__3; if linked_1132 == nil { j__4 = ifn_1133.Invoke_O__O(arg_1134) } else { j__4 = linked_1132.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1131, arg_1134) }; var root_1135 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any; var root_1140 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__4)).Ref(); if linked_1141 == nil { arg_1138 = ifn_1142.Invoke_O__O(arg_1143) } else { arg_1138 = linked_1141.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1140, arg_1143) }; var arg_1139 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp7 any; var root_1144 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = s__711000187__3; if linked_1145 == nil { tmp7 = ifn_1146.Invoke_O__O(arg_1147) } else { tmp7 = linked_1145.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1144, arg_1147) }; arg_1139 = tmp6.Invoke_O__O(tmp7); if linked_1136 == nil { return ifn_1137.Invoke_O_O__O(arg_1138, arg_1139) } else { return linked_1136.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1135, arg_1138, arg_1139) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :179:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Ctor_O_I_O(c__b__711000189 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000189 = c__b__711000189; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Invoke_O__O(self any) any { { var i__711000188__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000188__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000188__1)); var root_1098 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any = t.F_b__711000189; var arg_1102 any; var root_1103 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__2)).Ref(); if linked_1104 == nil { arg_1102 = ifn_1105.Invoke_O__O(arg_1106) } else { arg_1102 = linked_1104.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1103, arg_1106) }; if linked_1099 == nil { ifn_1100.Invoke_O_O__O(arg_1101, arg_1102) } else { linked_1099.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1098, arg_1101, arg_1102) }; i__711000188__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000188__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_method_form_fn__711000196_A_New() *A_arbace_j2g_dyn_method_form_fn__711000196_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000196_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Ctor() {}
//line :181:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Invoke_O_O_O__O(self, p1__711000175_SHARP___1, p2__711000176_SHARP___2 any) any { var root_1181 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = p1__711000175_SHARP___1; var arg_1185 any; var root_1186 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any = A_arbace_j2g_dyn_A_const_73; var arg_1190 any = p2__711000176_SHARP___2; if linked_1187 == nil { arg_1185 = ifn_1188.Invoke_O_O__O(arg_1189, arg_1190) } else { arg_1185 = linked_1187.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1186, arg_1189, arg_1190) }; if linked_1182 == nil { return ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { return linked_1182.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185) } }










func A_arbace_j2g_dyn_native_name_A_New() *A_arbace_j2g_dyn_native_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_native_name_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_dyn_native_name_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_dyn_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_14, nil, Lit_127); var tmp2 any; var root_1258 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); if linked_1259 == nil { tmp2 = ifn_1260.Invoke_O__O(arg_1261) } else { tmp2 = linked_1259.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1258, arg_1261) }; var tmp3 any = tmp2; var tmp4 any; var root_1262 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = mname__0; var arg_1266 any = desc__1; if linked_1263 == nil { tmp4 = ifn_1264.Invoke_O_O__O(arg_1265, arg_1266) } else { tmp4 = linked_1263.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1262, arg_1265, arg_1266) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref()
}





















func A_arbace_j2g_dyn_proxy_classes_A_New() *A_arbace_j2g_dyn_proxy_classes_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Ctor() {}
//line :216:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Invoke_O_O__O(self, T__0_ any) any {



	var root_1267 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any; var fnbody__1310 any = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(T__0_); var tmp1 *jrt.Class; var fncls__1309 *jrt.Class = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class; if fncls__1309 == nil { var fncls__1309d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, fnbody__1310); A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class = fncls__1309d; tmp1 = fncls__1309d } else { tmp1 = fncls__1309 }; arg_1270 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1310, tmp1, nil); var arg_1271 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); if linked_1268 == nil { return ifn_1269.Invoke_O_O__O(arg_1270, arg_1271) } else { return linked_1268.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1267, arg_1270, arg_1271) } }
//line :220:1
func A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_fn__711000201_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Ctor_O(c__T any) { t.F_T = c__T }
//line :220:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Invoke_O_O__O(self, p1__711000200_SHARP___1 any) any { var and__1927000168__auto____2 any; var or__1927000174__auto____2 any; var root_1272 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = t.F_T; var arg_1276 any = p1__711000200_SHARP___1; if linked_1273 == nil { or__1927000174__auto____2 = ifn_1274.Invoke_O_O__O(arg_1275, arg_1276) } else { or__1927000174__auto____2 = linked_1273.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1272, arg_1275, arg_1276) }; if jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { var root_1277 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = p1__711000200_SHARP___1; if linked_1278 == nil { and__1927000168__auto____2 = ifn_1279.Invoke_O__O(arg_1280) } else { and__1927000168__auto____2 = linked_1278.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1277, arg_1280) } }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1281 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = p1__711000200_SHARP___1; if linked_1282 == nil { and__1927000168__auto____3 = ifn_1283.Invoke_O__O(arg_1284) } else { and__1927000168__auto____3 = linked_1282.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_1281, arg_1284) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1285 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1287 lang.IFn
														if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any; var root_1289 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = p1__711000200_SHARP___1; if linked_1290 == nil { arg_1288 = ifn_1291.Invoke_O__O(arg_1292) } else { arg_1288 = linked_1290.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1289, arg_1292) }; if linked_1286 == nil { and__1927000168__auto____4 = ifn_1287.Invoke_O__O(arg_1288) } else { and__1927000168__auto____4 = linked_1286.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1285, arg_1288) }
//line :220:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1293 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1295 lang.IFn
		if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any; var root_1297 any = A_arbace_j2g_dyn_A_const_163.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = p1__711000200_SHARP___1; if linked_1298 == nil { arg_1296 = ifn_1299.Invoke_O__O(arg_1300) } else { arg_1296 = linked_1298.(*aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_1297, arg_1300) }; if linked_1294 == nil { and__1927000168__auto____5 = ifn_1295.Invoke_O__O(arg_1296) } else { and__1927000168__auto____5 = linked_1294.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1293, arg_1296) }
//line :220:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_1301 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any; var root_1305 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = p1__711000200_SHARP___1; if linked_1306 == nil { arg_1304 = ifn_1307.Invoke_O__O(arg_1308) } else { arg_1304 = linked_1306.(*aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_1305, arg_1308) }; if linked_1302 == nil { return ifn_1303.Invoke_O__O(arg_1304) } else { return linked_1302.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1301, arg_1304) } } else {
//line :220:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_j2g_dyn_sub_name_A_New() *A_arbace_j2g_dyn_sub_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_name_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_j2g_dyn_sub_name_A) Ctor() {}
//line :224:1
func (t *A_arbace_j2g_dyn_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_168, nil); var tmp2 any; var root_1311 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = n__0; if linked_1312 == nil { tmp2 = ifn_1313.Invoke_O__O(arg_1314) } else { tmp2 = linked_1312.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1311, arg_1314) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyn_proxy_roots_A_New() *A_arbace_j2g_dyn_proxy_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Ctor() {}
//line :226:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var fnbody__1525 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New(); var tmp1 *jrt.Class; var fncls__1524 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class; if



	fncls__1524 == nil { var fncls__1524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, nil); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class = fncls__1524d; tmp1 = fncls__1524d } else { tmp1 = fncls__1524 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1525, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_165.GetRawRoot__O()) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New() *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Ctor() {}
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Invoke_O_O__O(self, s__711000206__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1523 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(self, s__711000206__1); var tmp2 *jrt.Class; var fncls__1522 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class; if fncls__1522 == nil { var fncls__1522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, fnbody__1523); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class = fncls__1522d; tmp2 = fncls__1522d } else { tmp2 = fncls__1522 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1523, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A{}; t.Ctor_O_O(p0, p1); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Ctor_O_O(c__iter__711000205, c__s__711000206 any) { t.F_iter__711000205 = c__iter__711000205; t.F_s__711000206 = c__s__711000206 }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Invoke_O__O(self any) any { { var s__711000206__1 any; var t_ any = t.F_s__711000206; t.F_s__711000206 = nil; s__711000206__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1315 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = s__711000206__1; if linked_1316 == nil { temp__1927000414__auto____2 = ifn_1317.Invoke_O__O(arg_1318) } else { temp__1927000414__auto____2 = linked_1316.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1315, arg_1318) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1319 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = xs__1927001018__auto____3; if linked_1320 == nil { n__4 = ifn_1321.Invoke_O__O(arg_1322) } else { n__4 = linked_1320.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1319, arg_1322) }; var tmp1 any; var and__1927000168__auto____5 any; var root_1323 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1325 lang.IFn
														if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = n__4; if linked_1324 == nil { and__1927000168__auto____5 = ifn_1325.Invoke_O__O(arg_1326) } else { and__1927000168__auto____5 = linked_1324.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1323, arg_1326) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1327 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any; var root_1331 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1331, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = n__4; if linked_1332 == nil { arg_1330 = ifn_1333.Invoke_O__O(arg_1334) } else { arg_1330 = linked_1332.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1331, arg_1334) }; if linked_1328 == nil { tmp1 = ifn_1329.Invoke_O__O(arg_1330) } else { tmp1 = linked_1328.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1327, arg_1330) } } else { tmp1 = and__1927000168__auto____5 }
//line :230:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__1496 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(n__4); var tmp2 *jrt.Class; var fncls__1495 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class; if fncls__1495 == nil { var fncls__1495d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__1496); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class = fncls__1495d; tmp2 = fncls__1495d } else { tmp2 = fncls__1495 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1496, tmp2, nil); var fs__1927001036__auto____6 any; var root_1497 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1501 any = A_arbace_j2g_dyn_A_const_168.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1503 lang.IFn

		if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = n__4; if linked_1502 == nil { tmp4 = ifn_1503.Invoke_O__O(arg_1504) } else { tmp4 = linked_1502.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1501, arg_1504) }
//line :230:1
		arg_1500 = tmp3.Invoke_O__O(tmp4); if linked_1498 == nil { fs__1927001036__auto____6 = ifn_1499.Invoke_O__O(arg_1500) } else { fs__1927001036__auto____6 = linked_1498.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1497, arg_1500) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1505 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = fs__1927001036__auto____6; var arg_1509 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000205); var tmp6 any; var root_1510 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = s__711000206__1; if linked_1511 == nil { tmp6 = ifn_1512.Invoke_O__O(arg_1513) } else { tmp6 = linked_1511.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1510, arg_1513) }; arg_1509 = tmp5.Invoke_O__O(tmp6); if linked_1506 == nil { return ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { return linked_1506.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) } } else { var tmp7 any; var root_1514 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = s__711000206__1; if linked_1515 == nil { tmp7 = ifn_1516.Invoke_O__O(arg_1517) } else { tmp7 = linked_1515.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1514, arg_1517) }; s__711000206__1 = tmp7; continue L1 } } else { var tmp8 any; var root_1518 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = s__711000206__1; if linked_1519 == nil { tmp8 = ifn_1520.Invoke_O__O(arg_1521) } else { tmp8 = linked_1519.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1518, arg_1521) }; s__711000206__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Invoke_O_O__O(self, s__711000208__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1494 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(self, t.F_n, s__711000208__1); var tmp2 *jrt.Class; var fncls__1493 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class; if fncls__1493 == nil { var fncls__1493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, fnbody__1494); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class = fncls__1493d; tmp2 = fncls__1493d } else { tmp2 = fncls__1493 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1494, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Ctor_O_O_O(c__iter__711000207, c__n, c__s__711000208 any) { t.F_iter__711000207 = c__iter__711000207; t.F_n = c__n; t.F_s__711000208 = c__s__711000208 }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Invoke_O__O(self any) any { { var s__711000208__1 any; var t_ any = t.F_s__711000208; t.F_s__711000208 = nil; s__711000208__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1335 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1337 lang.IFn; if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = s__711000208__1; if linked_1336 == nil { temp__1927000414__auto____2 = ifn_1337.Invoke_O__O(arg_1338) } else { temp__1927000414__auto____2 = linked_1336.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1335, arg_1338) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_1339 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1339, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1341 lang.IFn; if linked_1340 == nil { ifn_1341 = lang.IFn_Cast(root_1339) } else { ifn_1341 = nil }; var arg_1342 any = xs__1927001018__auto____3; if linked_1340 == nil { c__4 = ifn_1341.Invoke_O__O(arg_1342) } else { c__4 = linked_1340.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1339, arg_1342) }; var tmp1 any
																			var and__1927000168__auto____5 any = c__4

	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1343 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1343, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1345 lang.IFn; if linked_1344 == nil { ifn_1345 = lang.IFn_Cast(root_1343) } else { ifn_1345 = nil }; var arg_1346 any = c__4; var arg_1347 any = Lit_100; if linked_1344 == nil { and__1927000168__auto____6 = ifn_1345.Invoke_O_O__O(arg_1346, arg_1347) } else { and__1927000168__auto____6 = linked_1344.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1343, arg_1346, arg_1347) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1348 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = c__4; if linked_1349 == nil { tmp1 = ifn_1350.Invoke_O__O(arg_1351) } else { tmp1 = linked_1349.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1348, arg_1351) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }
//line :230:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__1467 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(t.F_n, c__4); var tmp2 *jrt.Class; var fncls__1466 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class; if fncls__1466 == nil { var fncls__1466d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, fnbody__1467); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class = fncls__1466d; tmp2 = fncls__1466d } else { tmp2 = fncls__1466 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1467, tmp2, nil); var fs__1927001036__auto____6 any; var root_1468 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1468, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1470 lang.IFn; if linked_1469 == nil { ifn_1470 = lang.IFn_Cast(root_1468) } else { ifn_1470 = nil }; var arg_1471 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp5 any; var root_1472 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1472, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1474 lang.IFn



		if linked_1473 == nil { ifn_1474 = lang.IFn_Cast(root_1472) } else { ifn_1474 = nil }; var arg_1475 any = c__4; if linked_1473 == nil { tmp5 = ifn_1474.Invoke_O__O(arg_1475) } else { tmp5 = linked_1473.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1472, arg_1475) }
//line :230:1
		arg_1471 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)); if linked_1469 == nil { fs__1927001036__auto____6 = ifn_1470.Invoke_O__O(arg_1471) } else { fs__1927001036__auto____6 = linked_1469.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1468, arg_1471) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1476 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = fs__1927001036__auto____6; var arg_1480 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000207); var tmp7 any; var root_1481 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1481, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1483 lang.IFn; if linked_1482 == nil { ifn_1483 = lang.IFn_Cast(root_1481) } else { ifn_1483 = nil }; var arg_1484 any = s__711000208__1; if linked_1482 == nil { tmp7 = ifn_1483.Invoke_O__O(arg_1484) } else { tmp7 = linked_1482.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1481, arg_1484) }; arg_1480 = tmp6.Invoke_O__O(tmp7); if linked_1477 == nil { return ifn_1478.Invoke_O_O__O(arg_1479, arg_1480) } else { return linked_1477.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1476, arg_1479, arg_1480) } } else { var tmp8 any; var root_1485 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any = s__711000208__1; if linked_1486 == nil { tmp8 = ifn_1487.Invoke_O__O(arg_1488) } else { tmp8 = linked_1486.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1485, arg_1488) }; s__711000208__1 = tmp8; continue L1 } } else { var tmp9 any; var root_1489 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = s__711000208__1; if linked_1490 == nil { tmp9 = ifn_1491.Invoke_O__O(arg_1492) } else { tmp9 = linked_1490.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1489, arg_1492) }; s__711000208__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A{}; t.Ctor_O_O(p0, p1); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Ctor_O_O(c__n, c__c any) { t.F_n = c__n; t.F_c = c__c }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Invoke_O_O__O(self, s__711000210__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1465 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(s__711000210__1, t.F_n, self, t.F_c); var tmp2 *jrt.Class; var fncls__1464 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class; if fncls__1464 == nil { var fncls__1464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, fnbody__1465); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class = fncls__1464d; tmp2 = fncls__1464d } else { tmp2 = fncls__1464 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1465, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Ctor_O_O_O_O(c__s__711000210, c__n, c__iter__711000209, c__c any) { t.F_s__711000210 = c__s__711000210; t.F_n = c__n; t.F_iter__711000209 = c__iter__711000209; t.F_c = c__c }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Invoke_O__O(self any) any { { var s__711000210__1 any; var t_ any = t.F_s__711000210; t.F_s__711000210 = nil; s__711000210__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1352 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = s__711000210__1; if linked_1353 == nil { temp__1927000414__auto____2 = ifn_1354.Invoke_O__O(arg_1355) } else { temp__1927000414__auto____2 = linked_1353.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1352, arg_1355) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000210__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1356 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any = s__711000210__3; if linked_1357 == nil { tmp1 = ifn_1358.Invoke_O__O(arg_1359) } else { tmp1 = linked_1357.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1356, arg_1359) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1360 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = s__711000210__3; if linked_1361 == nil { c__1927001037__auto____4 = ifn_1362.Invoke_O__O(arg_1363) } else { c__1927001037__auto____4 = linked_1361.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1360, arg_1363) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000212__6 any; var root_1364 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1365 == nil { b__711000212__6 = ifn_1366.Invoke_O__O(arg_1367) } else { b__711000212__6 = linked_1365.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1364, arg_1367) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1395 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(t.F_n, b__711000212__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__1394 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class; if fncls__1394 == nil { var fncls__1394d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, fnbody__1395); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class = fncls__1394d; tmp3 = fncls__1394d } else { tmp3 = fncls__1394 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1395, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1396 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any; var root_1401 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = b__711000212__6; if linked_1402 == nil { arg_1399 = ifn_1403.Invoke_O__O(arg_1404) } else { arg_1399 = linked_1402.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1401, arg_1404) }; var arg_1400 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp5 any; var root_1405 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = s__711000210__3; if linked_1406 == nil { tmp5 = ifn_1407.Invoke_O__O(arg_1408) } else { tmp5 = linked_1406.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1405, arg_1408) }; arg_1400 = tmp4.Invoke_O__O(tmp5); if linked_1397 == nil { return ifn_1398.Invoke_O_O__O(arg_1399, arg_1400) } else { return linked_1397.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1396, arg_1399, arg_1400) } } else { var root_1409 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1411 lang.IFn; if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any; var root_1414 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1416 lang.IFn; if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = b__711000212__6; if linked_1415 == nil { arg_1412 = ifn_1416.Invoke_O__O(arg_1417) } else { arg_1412 = linked_1415.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1414, arg_1417) }; var arg_1413 any; if linked_1410 == nil { return ifn_1411.Invoke_O_O__O(arg_1412, arg_1413) } else { return linked_1410.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1409, arg_1412, arg_1413) } } } else { var mm__4 any; var root_1418 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = s__711000210__3; if linked_1419 == nil { mm__4 = ifn_1420.Invoke_O__O(arg_1421) } else { mm__4 = linked_1419.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1418, arg_1421) }; var tmp6 any; var root_1422 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1424 lang.IFn




	if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any; var root_1426 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = mm__4; if linked_1427 == nil { arg_1425 = ifn_1428.Invoke_O__O(arg_1429) } else { arg_1425 = linked_1427.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1426, arg_1429) }; if linked_1423 == nil { tmp6 = ifn_1424.Invoke_O__O(arg_1425) } else { tmp6 = linked_1423.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1422, arg_1425) }
//line :230:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_31, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4))





		if or__1927000174__auto____5 { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1430 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1430, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1432 lang.IFn; if linked_1431 == nil { ifn_1432 = lang.IFn_Cast(root_1430) } else { ifn_1432 = nil }; var arg_1433 any; var root_1434 any = A_arbace_j2g_dyn_A_const_167.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any = mm__4; if linked_1435 == nil { arg_1433 = ifn_1436.Invoke_O__O(arg_1437) } else { arg_1433 = linked_1435.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1434, arg_1437) }; if linked_1431 == nil { tmp7 = ifn_1432.Invoke_O__O(arg_1433) } else { tmp7 = linked_1431.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1430, arg_1433) } }
//line :230:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____5_2 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var root_1438 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1438, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = Lit_31; var arg_1442 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_1439 == nil { tmp8 = ifn_1440.Invoke_O_O__O(arg_1441, arg_1442) } else { tmp8 = linked_1439.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1438, arg_1441, arg_1442) } }
//line :230:1
			if jrt.J2g_Truth(tmp8) { var root_1443 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var tmp9 any = t.F_c; var arg_1446 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4)); var arg_1447 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp11 any; var root_1448 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = s__711000210__3; if linked_1449 == nil { tmp11 = ifn_1450.Invoke_O__O(arg_1451) } else { tmp11 = linked_1449.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1448, arg_1451) }; arg_1447 = tmp10.Invoke_O__O(tmp11); if linked_1444 == nil { return ifn_1445.Invoke_O_O__O(arg_1446, arg_1447) } else { return linked_1444.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1443, arg_1446, arg_1447) } } else { var tmp12 any; var root_1452 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = s__711000210__3; if linked_1453 == nil { tmp12 = ifn_1454.Invoke_O__O(arg_1455) } else { tmp12 = linked_1453.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1452, arg_1455) }; s__711000210__1 = tmp12; continue L1 } } else { var tmp13 any; var root_1456 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = s__711000210__3; if linked_1457 == nil { tmp13 = ifn_1458.Invoke_O__O(arg_1459) } else { tmp13 = linked_1457.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1456, arg_1459) }; s__711000210__1 = tmp13; continue L1 } } else { var tmp14 any; var root_1460 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = s__711000210__3; if linked_1461 == nil { tmp14 = ifn_1462.Invoke_O__O(arg_1463) } else { tmp14 = linked_1461.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1460, arg_1463) }; s__711000210__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Ctor_O_O_I_O_O(c__n, c__b__711000212 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__c any) { t.F_n = c__n; t.F_b__711000212 = c__b__711000212; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Invoke_O__O(self any) any { { var i__711000211__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000211__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000211__1)); var tmp2 any; var root_1368 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1370 lang.IFn




	if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any; var root_1372 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any = mm__2; if linked_1373 == nil { arg_1371 = ifn_1374.Invoke_O__O(arg_1375) } else { arg_1371 = linked_1373.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1372, arg_1375) }; if linked_1369 == nil { tmp2 = ifn_1370.Invoke_O__O(arg_1371) } else { tmp2 = linked_1369.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1368, arg_1371) }
//line :230:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_31, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2))





		if or__1927000174__auto____3 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1376 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any; var root_1380 any = A_arbace_j2g_dyn_A_const_167.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = mm__2; if linked_1381 == nil { arg_1379 = ifn_1382.Invoke_O__O(arg_1383) } else { arg_1379 = linked_1381.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1380, arg_1383) }; if linked_1377 == nil { tmp3 = ifn_1378.Invoke_O__O(arg_1379) } else { tmp3 = linked_1377.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1376, arg_1379) } }
//line :230:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____3_2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var root_1384 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = Lit_31; var arg_1388 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_1385 == nil { tmp4 = ifn_1386.Invoke_O_O__O(arg_1387, arg_1388) } else { tmp4 = linked_1385.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1384, arg_1387, arg_1388) } }
//line :230:1
			if jrt.J2g_Truth(tmp4) { var root_1389 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = t.F_b__711000212; var tmp5 any = t.F_c; var arg_1393 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2)); if linked_1390 == nil { ifn_1391.Invoke_O_O__O(arg_1392, arg_1393) } else { linked_1390.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1389, arg_1392, arg_1393) }; i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_j2g_dyn_object_fallback_A_New() *A_arbace_j2g_dyn_object_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_object_fallback_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Invoke_O_O_O_O__O(self, n__0, k__1, pn__2 any) any { var impl__4 any; var root_1526 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1528 lang.IFn; if



	linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = n__0; var arg_1530 any = k__1; if linked_1527 == nil { impl__4 = ifn_1528.Invoke_O_O__O(arg_1529, arg_1530) } else { impl__4 = linked_1527.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1526, arg_1529, arg_1530) }; var base__5 any; var root_1531 any = /*line :240:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1533 lang.IFn; if




	linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var arg_1535 any = k__1; if linked_1532 == nil { base__5 = ifn_1533.Invoke_O_O__O(arg_1534, arg_1535) } else { base__5 = linked_1532.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1531, arg_1534, arg_1535) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_169); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__4))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_170; var tmp4 any; var root_1536 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1538 lang.IFn
		if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1540 any; var root_1544 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1544, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__5)).Ref(); if linked_1545 == nil { arg_1540 = ifn_1546.Invoke_O__O(arg_1547) } else { arg_1540 = linked_1545.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1544, arg_1547) }; var arg_1541 any = A_arbace_j2g_dyn_A_const_171; var arg_1542 any = A_arbace_j2g_dyn_A_const_172; var arg_1543 any = pn__2; if linked_1537 == nil { tmp4 = ifn_1538.Invoke_O_O_O_O_O__O(arg_1539, arg_1540, arg_1541, arg_1542, arg_1543) } else { tmp4 = linked_1537.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1536, arg_1539, arg_1540, arg_1541, arg_1542, arg_1543) }
//line :246:1
		return lang.Tuple_Create_O__IPersistentVector(tmp2.Invoke_O_O__O(tmp3, tmp4)) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_173; var tmp7 any; var G__711000228__6_ any; var root_1548 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1550 lang.IFn

			if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = k__1; if linked_1549 == nil { G__711000228__6_ = ifn_1550.Invoke_O__O(arg_1551) } else { G__711000228__6_ = linked_1549.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1548, arg_1551) }; L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__711000228__6_) >> 1 & 3 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_128) { tmp7 = A_arbace_j2g_dyn_A_const_174; break L1 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_129) { tmp7 = A_arbace_j2g_dyn_A_const_175; break L1 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_130) {


				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_176; var tmp10 any = A_arbace_j2g_dyn_A_const_177; var tmp11 any; var root_1553 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = pn__2; if linked_1554 == nil { tmp11 = ifn_1555.Invoke_O__O(arg_1556) } else { tmp11 = linked_1554.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1553, arg_1556) }; tmp7 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11)
//line :248:1
				break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_131, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__711000228__6_)))))}
//line :246:1
			return lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O_O__O(tmp6, tmp7)) } }






func A_arbace_j2g_dyn_class_fallback_A_New() *A_arbace_j2g_dyn_class_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Ctor() {}
//line :253:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Invoke_O_O_O_O_O__O(self, n__0, p__711000230__1, pn__2, r__3 any) any { var vec__711000231__5 any = p__711000230__1; var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__711000231__5; var impl__9 any; var root_1557 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1559 lang.IFn; if



	linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = n__0; var arg_1561 any = k__8; if linked_1558 == nil { impl__9 = ifn_1559.Invoke_O_O__O(arg_1560, arg_1561) } else { impl__9 = linked_1558.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1557, arg_1560, arg_1561) }; var base__10 any; var root_1562 any = /*line :253:1*/A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1562, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1564 lang.IFn; if




	linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = name__6; var arg_1566 any = desc__7; if linked_1563 == nil { base__10 = ifn_1564.Invoke_O_O__O(arg_1565, arg_1566) } else { base__10 = linked_1563.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1562, arg_1565, arg_1566) }; var ret__11 any; var fnbody__1568 any = /*line :253:1*/A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(r__3); var tmp1 *jrt.Class; var fncls__1567 *jrt.Class = A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class; if





	fncls__1567 == nil { var fncls__1567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__1568); A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class = fncls__1567d; tmp1 = fncls__1567d } else { tmp1 = fncls__1567 }; ret__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1568, tmp1, nil); var G__711000236__12_ any = /*line :253:1*/A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__9); switch






	lang.Util_Hash_O__I_NoInit(G__711000236__12_) >> 4 & 3 { case 0: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_69) {

		var tmp2 lang.IFn = lang.IFn_Cast(ret__11); var tmp3 any; var root_1574 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1574, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1578 any; var root_1581 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = A_arbace_j2g_dyn_A_const_73; var arg_1585 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__9); var arg_1586 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1582 == nil { arg_1578 = ifn_1583.Invoke_O_O_O__O(arg_1584, arg_1585, arg_1586) } else { arg_1578 = linked_1582.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1581, arg_1584, arg_1585, arg_1586) }; var arg_1579 any = A_arbace_j2g_dyn_A_const_182; var arg_1580 any = pn__2; if linked_1575 == nil { tmp3 = ifn_1576.Invoke_O_O_O_O__O(arg_1577, arg_1578, arg_1579, arg_1580) } else { tmp3 = linked_1575.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1574, arg_1577, arg_1578, arg_1579, arg_1580) }; return tmp2.Invoke_O__O(tmp3) }
//line :260:1
	case 1: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_179) {
		var tmp4 lang.IFn = lang.IFn_Cast(ret__11); var tmp5 any; var root_1587 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1591 any; var root_1595 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1596 == nil { arg_1591 = ifn_1597.Invoke_O__O(arg_1598) } else { arg_1591 = linked_1596.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1595, arg_1598) }; var arg_1592 any = A_arbace_j2g_dyn_A_const_183; var arg_1593 any = A_arbace_j2g_dyn_A_const_184; var arg_1594 any = pn__2; if linked_1588 == nil { tmp5 = ifn_1589.Invoke_O_O_O_O_O__O(arg_1590, arg_1591, arg_1592, arg_1593, arg_1594) } else { tmp5 = linked_1588.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1587, arg_1590, arg_1591, arg_1592, arg_1593, arg_1594) }; return tmp4.Invoke_O__O(tmp5) }
//line :260:1
	case 2: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_180) {
		var tmp6 lang.IFn = lang.IFn_Cast(ret__11); var tmp7 any; var root_1599 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1603 any; var root_1607 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1608 == nil { arg_1603 = ifn_1609.Invoke_O__O(arg_1610) } else { arg_1603 = linked_1608.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1607, arg_1610) }; var arg_1604 any = A_arbace_j2g_dyn_A_const_183; var arg_1605 any = A_arbace_j2g_dyn_A_const_184; var arg_1606 any = pn__2; if linked_1600 == nil { tmp7 = ifn_1601.Invoke_O_O_O_O_O__O(arg_1602, arg_1603, arg_1604, arg_1605, arg_1606) } else { tmp7 = linked_1600.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1599, arg_1602, arg_1603, arg_1604, arg_1605, arg_1606) }; return tmp6.Invoke_O__O(tmp7) }
//line :260:1
	case 3: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_181) {


		var tmp8 lang.IFn = lang.IFn_Cast(ret__11); var tmp9 any; var root_1611 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1615 any; var root_1618 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1619 == nil { arg_1615 = ifn_1620.Invoke_O__O(arg_1621) } else { arg_1615 = linked_1619.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1618, arg_1621) }; var arg_1616 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any; var root_1622 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any; var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil); var tmp13 any; var root_1626 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1628 lang.IFn; if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = n__0; if linked_1627 == nil { tmp13 = ifn_1628.Invoke_O__O(arg_1629) } else { tmp13 = linked_1627.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1626, arg_1629) }; arg_1625 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13)).Ref(); if linked_1623 == nil { tmp11 = ifn_1624.Invoke_O__O(arg_1625) } else { tmp11 = linked_1623.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1622, arg_1625) }; arg_1616 = tmp10.Invoke_O_O__O(tmp11, A_arbace_j2g_dyn_A_const_185); var arg_1617 any = pn__2; if linked_1612 == nil { tmp9 = ifn_1613.Invoke_O_O_O_O__O(arg_1614, arg_1615, arg_1616, arg_1617) } else { tmp9 = linked_1612.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1611, arg_1614, arg_1615, arg_1616, arg_1617) }; return tmp8.Invoke_O__O(tmp9) }
//line :260:1
	default:}; var vec__711000237__13 any; var root_1570 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1572 lang.IFn; if



	linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = desc__7; if linked_1571 == nil { vec__711000237__13 = ifn_1572.Invoke_O__O(arg_1573) } else { vec__711000237__13 = linked_1571.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1570, arg_1573) }; var ps__14 any = /*line :260:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(0), nil); var rr__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyn_A_const_186; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_187; var tmp18 any = A_arbace_j2g_dyn_A_const_188; var tmp19 *jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns21:)' of abstract class ns1:.", []*jrt.Class{jrt.String_class}); var tmp20 any; var root_1630 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1632 lang.IFn; if




	linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = rr__15; if linked_1631 == nil { tmp20 = ifn_1632.Invoke_O__O(arg_1633) } else { tmp20 = linked_1631.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1630, arg_1633) }; var tmp21 any = tmp20; var tmp22 any; var root_1634 any = /*line :260:1*/A_arbace_j2g_dyn_A_const_115.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1636 lang.IFn; if





	linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = Lit_3; var arg_1638 any; var root_1639 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1640 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1639, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1641 lang.IFn; if linked_1640 == nil { ifn_1641 = lang.IFn_Cast(root_1639) } else { ifn_1641 = nil }; var arg_1642 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var arg_1643 any = ps__14; if linked_1640 == nil { arg_1638 = ifn_1641.Invoke_O_O__O(arg_1642, arg_1643) } else { arg_1638 = linked_1640.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1639, arg_1642, arg_1643) }; if linked_1635 == nil { tmp22 = ifn_1636.Invoke_O_O__O(arg_1637, arg_1638) } else { tmp22 = linked_1635.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1634, arg_1637, arg_1638) }; var tmp23 any = tmp22; var tmp24 any; var root_1644 any = /*line :260:1*/A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1646 lang.IFn; if






	linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = n__0; var arg_1648 any = Lit_5; var arg_1649 any = Lit_6; if linked_1645 == nil { tmp24 = ifn_1646.Invoke_O_O_O__O(arg_1647, arg_1648, arg_1649) } else { tmp24 = linked_1645.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1644, arg_1647, arg_1648, arg_1649) }; return /*line :260:1*/ lang.Tuple_Create_O__IPersistentVector(tmp14.Invoke_O_O__O(tmp15, tmp16.Invoke_O_O_O__O(tmp17, tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp21, nil, name__6, nil, tmp23, nil, tmp24, nil)).Ref()))) }
//line :259:1
func A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(p0 any) *A_arbace_j2g_dyn_class_fallback_ret__711000234_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_ret__711000234_A{}; t.Ctor_O(p0); return t }
//line :259:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :259:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Invoke_O_O__O(self, call__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(Lit_17, t.F_r) { return lang.Tuple_Create_O__IPersistentVector(call__1) } else { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_178, call__1)) } }









func A_arbace_j2g_dyn_ctor_infos_A_New() *A_arbace_j2g_dyn_ctor_infos_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_1650 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_1652 lang.IFn; if


	linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = n__0; if linked_1651 == nil { g__2 = ifn_1652.Invoke_O__O(arg_1653) } else { g__2 = linked_1651.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_1650, arg_1653) }; var arg_conv__3 any; var fnbody__1669 any = /*line :269:1*/A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New(); var tmp1 *jrt.Class; var fncls__1668 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class; if



	fncls__1668 == nil { var fncls__1668d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class = fncls__1668d; tmp1 = fncls__1668d } else { tmp1 = fncls__1668 }; arg_conv__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1669, tmp1, nil); var root_1673 any =


	A_arbace_j2g_dyn_A_const_194.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_195.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_196, A_arbace_j2g_dyn_A_const_197); if linked_1674 == nil { ifn_1675.Invoke_O__O(arg_1676) } else { linked_1674.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1673, arg_1676) }; var tmp2 any; tmp19 := /*line :269:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		{ var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyn_A_const_198; var tmp5 any; var root_1682 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_27, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_1683 == nil { tmp5 = ifn_1684.Invoke_O__O(arg_1685) } else { tmp5 = linked_1683.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1682, arg_1685) }; var tmp6 any = tmp5; var tmp7 any; var root_1686 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any; var tmp8 any; var root_1691 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = A_arbace_j2g_dyn_A_const_199; var arg_1695 any = A_arbace_j2g_dyn_A_const_200; if linked_1692 == nil { tmp8 = ifn_1693.Invoke_O_O__O(arg_1694, arg_1695) } else { tmp8 = linked_1692.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1691, arg_1694, arg_1695) }; arg_1689 = lang.Tuple_Create_O__IPersistentVector(tmp8); var arg_1690 any = A_arbace_j2g_dyn_A_const_201; if linked_1687 == nil { tmp7 = ifn_1688.Invoke_O_O__O(arg_1689, arg_1690) } else { tmp7 = linked_1687.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1686, arg_1689, arg_1690) }; var tmp9 any = tmp7; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_202; var tmp12 any; var root_1696 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1698 lang.IFn

			if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1700 any = A_arbace_j2g_dyn_A_const_203; var arg_1701 any = A_arbace_j2g_dyn_A_const_204; var arg_1702 any; var iter__1927001039__auto____6 any; var fnbody__2058 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(g__2, n__0, arg_conv__3); var tmp13 *jrt.Class; var fncls__2057 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class
			if fncls__2057 == nil { var fncls__2057d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__2058); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class = fncls__2057d; tmp13 = fncls__2057d } else { tmp13 = fncls__2057 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2058, tmp13, nil); var tmp14 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp15 any; var tmp16 any; var root_2059 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2061 lang.IFn; if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = n__0; if linked_2060 == nil { tmp16 = ifn_2061.Invoke_O__O(arg_2062) } else { tmp16 = linked_2060.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2059, arg_2062) }; if jrt.J2g_Truth(tmp16) { var root_2063 any = A_arbace_j2g_dyn_A_const_66.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = n__0; if linked_2064 == nil { tmp15 = ifn_2065.Invoke_O__O(arg_2066) } else { tmp15 = linked_2064.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_2063, arg_2066) } } else { var tmp17 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp18 any; var root_2067 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = n__0; if linked_2068 == nil { tmp18 = ifn_2069.Invoke_O__O(arg_2070) } else { tmp18 = linked_2068.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2067, arg_2070) }; tmp15 = tmp17.Invoke_O__O(tmp18) }; arg_1702 = tmp14.Invoke_O__O(tmp15)
//line :279:1
			if linked_1697 == nil { tmp12 = ifn_1698.Invoke_O_O_O_O__O(arg_1699, arg_1700, arg_1701, arg_1702) } else { tmp12 = linked_1697.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1696, arg_1699, arg_1700, arg_1701, arg_1702) }
//line :277:1
			tmp2 = tmp3.Invoke_O_O_O_O__O(tmp4, tmp6, tmp9, tmp10.Invoke_O_O__O(tmp11, tmp12)) }
//line :269:1
		return nil }(); var root_1670 any = A_arbace_j2g_dyn_A_const_193.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1672 lang.IFn; if






	linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; if linked_1671 == nil { ifn_1672.Invoke__O() } else { linked_1671.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1670) }; if /*line :269:1*/ tmp19 != nil { panic(tmp19) }; return tmp2 }



func A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New() *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Ctor() {}
//line :273:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Invoke_O_O_O__O(self, d__1, x__2 any) any { var tmp1 any; var root_1654 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = d__1; if linked_1655 == nil { tmp1 = ifn_1656.Invoke_O__O(arg_1657) } else { tmp1 = linked_1655.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1654, arg_1657) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_190; var tmp4 any; var root_1658 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = A_arbace_j2g_dyn_A_const_73; var arg_1662 any = d__1; if linked_1659 == nil { tmp4 = ifn_1660.Invoke_O_O__O(arg_1661, arg_1662) } else { tmp4 = linked_1659.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1658, arg_1661, arg_1662) }; return tmp2.Invoke_O_O_O__O(tmp3, tmp4, x__2) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_12) { return x__2 } else { if A_arbace_j2g_dyn_A_const_81 != nil {

	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_191; var tmp8 any = A_arbace_j2g_dyn_A_const_192; var tmp9 any; var root_1663 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any = A_arbace_j2g_dyn_A_const_73; var arg_1667 any = d__1; if linked_1664 == nil { tmp9 = ifn_1665.Invoke_O_O__O(arg_1666, arg_1667) } else { tmp9 = linked_1664.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1663, arg_1666, arg_1667) }; return tmp5.Invoke_O_O__O(tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9), x__2) } else {
//line :273:1
		return nil } } } }






func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Ctor_O_O_O(c__g, c__n, c__arg_conv any) { t.F_g = c__g; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Invoke_O_O__O(self, s__711000244__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2056 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(self, t.F_g, s__711000244__1, t.F_n, t.F_arg_conv); var tmp2 *jrt.Class; var fncls__2055 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class; if fncls__2055 == nil { var fncls__2055d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__2056); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class = fncls__2055d; tmp2 = fncls__2055d } else { tmp2 = fncls__2055 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2056, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :280:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Ctor_O_O_O_O_O(c__iter__711000243, c__g, c__s__711000244, c__n, c__arg_conv any) { t.F_iter__711000243 = c__iter__711000243; t.F_g = c__g; t.F_s__711000244 = c__s__711000244; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Invoke_O__O(self any) any { { var s__711000244__1 any; var t_ any = t.F_s__711000244; t.F_s__711000244 = nil; s__711000244__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1703 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = s__711000244__1; if linked_1704 == nil { temp__1927000414__auto____2 = ifn_1705.Invoke_O__O(arg_1706) } else { temp__1927000414__auto____2 = linked_1704.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1703, arg_1706) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000244__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1707 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = s__711000244__3; if linked_1708 == nil { tmp1 = ifn_1709.Invoke_O__O(arg_1710) } else { tmp1 = linked_1708.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1707, arg_1710) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1711 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = s__711000244__3; if linked_1712 == nil { c__1927001037__auto____4 = ifn_1713.Invoke_O__O(arg_1714) } else { c__1927001037__auto____4 = linked_1712.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1711, arg_1714) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000246__6 any; var root_1715 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1716 == nil { b__711000246__6 = ifn_1717.Invoke_O__O(arg_1718) } else { b__711000246__6 = linked_1716.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1715, arg_1718) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1866 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(t.F_g, t.F_n, b__711000246__6, t.F_arg_conv, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1865 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class; if fncls__1865 == nil { var fncls__1865d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__1866); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class = fncls__1865d; tmp3 = fncls__1865d } else { tmp3 = fncls__1865 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1866, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1867 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any; var root_1872 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = b__711000246__6; if linked_1873 == nil { arg_1870 = ifn_1874.Invoke_O__O(arg_1875) } else { arg_1870 = linked_1873.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1872, arg_1875) }; var arg_1871 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp5 any; var root_1876 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = s__711000244__3; if linked_1877 == nil { tmp5 = ifn_1878.Invoke_O__O(arg_1879) } else { tmp5 = linked_1877.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1876, arg_1879) }; arg_1871 = tmp4.Invoke_O__O(tmp5); if linked_1868 == nil { return ifn_1869.Invoke_O_O__O(arg_1870, arg_1871) } else { return linked_1868.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1867, arg_1870, arg_1871) } } else { var root_1880 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any; var root_1885 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = b__711000246__6; if linked_1886 == nil { arg_1883 = ifn_1887.Invoke_O__O(arg_1888) } else { arg_1883 = linked_1886.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1885, arg_1888) }; var arg_1884 any; if linked_1881 == nil { return ifn_1882.Invoke_O_O__O(arg_1883, arg_1884) } else { return linked_1881.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1880, arg_1883, arg_1884) } } } else { var mm__4 any; var root_1889 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1891 lang.IFn; if linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any = s__711000244__3; if linked_1890 == nil { mm__4 = ifn_1891.Invoke_O__O(arg_1892) } else { mm__4 = linked_1890.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1889, arg_1892) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_31, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1893 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any; var root_1897 any = A_arbace_j2g_dyn_A_const_167.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = mm__4; if linked_1898 == nil { arg_1896 = ifn_1899.Invoke_O__O(arg_1900) } else { arg_1896 = linked_1898.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1897, arg_1900) }; if linked_1894 == nil { and__1927000168__auto____6 = ifn_1895.Invoke_O__O(arg_1896) } else { and__1927000168__auto____6 = linked_1894.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1893, arg_1896) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1901 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1902 == nil { tmp6 = ifn_1903.Invoke_O__O(arg_1904) } else { tmp6 = linked_1902.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1901, arg_1904) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :280:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_1905 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1907 lang.IFn

		if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any; var root_1909 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = t.F_n; if linked_1910 == nil { arg_1908 = ifn_1911.Invoke_O__O(arg_1912) } else { arg_1908 = linked_1910.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1909, arg_1912) }; if linked_1906 == nil { or__1927000174__auto____5 = ifn_1907.Invoke_O__O(arg_1908) } else { or__1927000174__auto____5 = linked_1906.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1905, arg_1908) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_1913 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any; var root_1918 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_1919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1918, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1920 lang.IFn; if linked_1919 == nil { ifn_1920 = lang.IFn_Cast(root_1918) } else { ifn_1920 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_1921 any = tmp8.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_1922 any; var root_1923 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = t.F_n; if linked_1924 == nil { arg_1922 = ifn_1925.Invoke_O__O(arg_1926) } else { arg_1922 = linked_1924.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1923, arg_1926) }; if linked_1919 == nil { arg_1916 = ifn_1920.Invoke_O_O__O(arg_1921, arg_1922) } else { arg_1916 = linked_1919.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1918, arg_1921, arg_1922) }; var arg_1917 any; var root_1927 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1929 lang.IFn; if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1928 == nil { arg_1917 = ifn_1929.Invoke_O__O(arg_1930) } else { arg_1917 = linked_1928.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1927, arg_1930) }; if linked_1914 == nil { tmp7 = ifn_1915.Invoke_O_O__O(arg_1916, arg_1917) } else { tmp7 = linked_1914.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1913, arg_1916, arg_1917) } }
//line :280:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_1931 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1931, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1933 lang.IFn



			if linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any = t.F_n; if linked_1932 == nil { tmp9 = ifn_1933.Invoke_O__O(arg_1934) } else { tmp9 = linked_1932.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1931, arg_1934) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4) } else { var root_1935 any = A_arbace_j2g_dyn_A_const_208.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any = t.F_n; var arg_1939 any = mm__4; if linked_1936 == nil { real__5 = ifn_1937.Invoke_O_O__O(arg_1938, arg_1939) } else { real__5 = linked_1936.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1935, arg_1938, arg_1939) } }
//line :280:1
			var vec__711000259__6 any; var root_1940 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1940, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1942 lang.IFn




			if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1941 == nil { vec__711000259__6 = ifn_1942.Invoke_O__O(arg_1943) } else { vec__711000259__6 = linked_1941.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1940, arg_1943) }
//line :280:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000262__9 any; var root_1944 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1946 lang.IFn; _ = ___8





			if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = real__5; if linked_1945 == nil { vec__711000262__9 = ifn_1946.Invoke_O__O(arg_1947) } else { vec__711000262__9 = linked_1945.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1944, arg_1947) }
//line :280:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_1948 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_209; var tmp12 any = A_arbace_j2g_dyn_A_const_210; var tmp13 any = A_arbace_j2g_dyn_A_const_211; var tmp14 any; var tmp15 any; var root_1953 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1955 lang.IFn








				if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any = ps__7; if linked_1954 == nil { tmp15 = ifn_1955.Invoke_O__O(arg_1956) } else { tmp15 = linked_1954.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1953, arg_1956) }; if jrt.J2g_Truth(tmp15) { var root_1957 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1961 any = A_arbace_j2g_dyn_A_const_212; var arg_1962 any = A_arbace_j2g_dyn_A_const_238; var arg_1963 any; var root_1964 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = A_arbace_j2g_dyn_A_const_214.GetRawRoot__O(); var arg_1968 any = ps__7; if linked_1965 == nil { arg_1963 = ifn_1966.Invoke_O_O__O(arg_1967, arg_1968) } else { arg_1963 = linked_1965.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1964, arg_1967, arg_1968) }; if linked_1958 == nil { tmp14 = ifn_1959.Invoke_O_O_O_O__O(arg_1960, arg_1961, arg_1962, arg_1963) } else { tmp14 = linked_1958.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1957, arg_1960, arg_1961, arg_1962, arg_1963) } } else { tmp14 = nil }
//line :288:1
				var tmp16 any = tmp14; var tmp17 any = A_arbace_j2g_dyn_A_const_215; var tmp18 any = A_arbace_j2g_dyn_A_const_216; var tmp19 any = A_arbace_j2g_dyn_A_const_217; var tmp20 any; var root_1969 any = A_arbace_j2g_dyn_A_const_218.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1971 lang.IFn


				if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = A_arbace_j2g_dyn_A_const_219; var arg_1973 any; var root_1975 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1975, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1977 lang.IFn; if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any; var tmp21 any; var root_1980 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = A_arbace_j2g_dyn_A_const_220; var arg_1984 any = A_arbace_j2g_dyn_A_const_239; if linked_1981 == nil { tmp21 = ifn_1982.Invoke_O_O__O(arg_1983, arg_1984) } else { tmp21 = linked_1981.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1980, arg_1983, arg_1984) }; arg_1978 = lang.Tuple_Create_O__IPersistentVector(tmp21); var arg_1979 any = A_arbace_j2g_dyn_A_const_240; if linked_1976 == nil { arg_1973 = ifn_1977.Invoke_O_O__O(arg_1978, arg_1979) } else { arg_1973 = linked_1976.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1975, arg_1978, arg_1979) }; var arg_1974 any; var root_1985 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1987 lang.IFn
				if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any; var tmp22 any; var or__1927000174__auto____12 any; var root_1990 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1992 lang.IFn
				if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = t.F_n; if linked_1991 == nil { or__1927000174__auto____12 = ifn_1992.Invoke_O__O(arg_1993) } else { or__1927000174__auto____12 = linked_1991.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1990, arg_1993) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp22 = or__1927000174__auto____12 } else { var root_1994 any = A_arbace_j2g_dyn_A_const_223.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = t.F_n; if linked_1995 == nil { tmp22 = ifn_1996.Invoke_O__O(arg_1997) } else { tmp22 = linked_1995.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1994, arg_1997) } }; if jrt.J2g_Truth(tmp22) { arg_1988 = nil } else { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp24 any; var root_1998 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any = A_arbace_j2g_dyn_A_const_73; var arg_2002 any = t.F_n; var arg_2003 any = Lit_32; if linked_1999 == nil { tmp24 = ifn_2000.Invoke_O_O_O__O(arg_2001, arg_2002, arg_2003) } else { tmp24 = linked_1999.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1998, arg_2001, arg_2002, arg_2003) }; arg_1988 = lang.Tuple_Create_O__IPersistentVector(tmp23.Invoke_O__O(tmp24)) }
//line :292:1
				var arg_1989 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyn_A_const_224; var tmp27 any = A_arbace_j2g_dyn_A_const_233; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyn_A_const_234; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_dyn_A_const_235; var tmp32 any; var root_2035 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2037 lang.IFn

				if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = t.F_g; if linked_2036 == nil { tmp32 = ifn_2037.Invoke_O__O(arg_2038) } else { tmp32 = linked_2036.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2035, arg_2038) }
//line :292:1
				var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28.Invoke_O_O__O(tmp29, tmp30.Invoke_O_O_O_O__O(tmp31, tmp32, A_arbace_j2g_dyn_A_const_236, A_arbace_j2g_dyn_A_const_243))); var tmp34 any = A_arbace_j2g_dyn_A_const_241; var tmp35 any = A_arbace_j2g_dyn_A_const_242; var tmp36 any; var root_2004 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2006 lang.IFn




				if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2008 any; var root_2012 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp38 any; var root_2016 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = real__5; if linked_2017 == nil { tmp38 = ifn_2018.Invoke_O__O(arg_2019) } else { tmp38 = linked_2017.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_2016, arg_2019) }; arg_2015 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_2013 == nil { arg_2008 = ifn_2014.Invoke_O__O(arg_2015) } else { arg_2008 = linked_2013.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2012, arg_2015) }; var arg_2009 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp40 any; var root_2020 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2022 lang.IFn
				if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any; var tmp41 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil); var tmp42 any; var root_2024 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = t.F_n; if linked_2025 == nil { tmp42 = ifn_2026.Invoke_O__O(arg_2027) } else { tmp42 = linked_2025.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2024, arg_2027) }; arg_2023 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp41, jrt.RefArrayOf(jrt.Object_class, nil, tmp42)).Ref(); if linked_2021 == nil { tmp40 = ifn_2022.Invoke_O__O(arg_2023) } else { tmp40 = linked_2021.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2020, arg_2023) }; arg_2009 = tmp39.Invoke_O_O__O(tmp40, A_arbace_j2g_dyn_A_const_227)
//line :297:1
				var arg_2010 any = A_arbace_j2g_dyn_A_const_228; var arg_2011 any; var root_2028 any = A_arbace_j2g_dyn_A_const_229.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2030 lang.IFn

				if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any; var fnbody__2034 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(t.F_arg_conv); var tmp43 *jrt.Class; var fncls__2033 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class; if fncls__2033 == nil { var fncls__2033d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__2034); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class = fncls__2033d; tmp43 = fncls__2033d } else { tmp43 = fncls__2033 }; arg_2031 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2034, tmp43, nil); var arg_2032 any = ps__7; if linked_2029 == nil { arg_2011 = ifn_2030.Invoke_O_O__O(arg_2031, arg_2032) } else { arg_2011 = linked_2029.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2028, arg_2031, arg_2032) }
//line :297:1
				if linked_2005 == nil { tmp36 = ifn_2006.Invoke_O_O_O_O_O__O(arg_2007, arg_2008, arg_2009, arg_2010, arg_2011) } else { tmp36 = linked_2005.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_2004, arg_2007, arg_2008, arg_2009, arg_2010, arg_2011) }
//line :292:1
				arg_1989 = lang.Tuple_Create_O__IPersistentVector(tmp25.Invoke_O_O_O_O_O_O__O(tmp26, tmp33, tmp34, tmp35, tmp36, A_arbace_j2g_dyn_A_const_232)); if linked_1986 == nil { arg_1974 = ifn_1987.Invoke_O_O__O(arg_1988, arg_1989) } else { arg_1974 = linked_1986.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1985, arg_1988, arg_1989) }
//line :291:1
				if linked_1970 == nil { tmp20 = ifn_1971.Invoke_O_O_O__O(arg_1972, arg_1973, arg_1974) } else { tmp20 = linked_1970.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1969, arg_1972, arg_1973, arg_1974) }
//line :288:1
				arg_1951 = tmp10.Invoke_O_O_O_O_O_O_O_O__O(tmp11, tmp12, tmp13, tmp16, tmp17, tmp18, tmp19, tmp20)
//line :280:1
				var arg_1952 any; var tmp44 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp45 any; var root_2039 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2039, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2041 lang.IFn; if linked_2040 == nil { ifn_2041 = lang.IFn_Cast(root_2039) } else { ifn_2041 = nil }; var arg_2042 any = s__711000244__3; if linked_2040 == nil { tmp45 = ifn_2041.Invoke_O__O(arg_2042) } else { tmp45 = linked_2040.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2039, arg_2042) }; arg_1952 = tmp44.Invoke_O__O(tmp45); if linked_1949 == nil { return ifn_1950.Invoke_O_O__O(arg_1951, arg_1952) } else { return linked_1949.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1948, arg_1951, arg_1952) } } else { var tmp46 any; var root_2043 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = s__711000244__3; if linked_2044 == nil { tmp46 = ifn_2045.Invoke_O__O(arg_2046) } else { tmp46 = linked_2044.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2043, arg_2046) }; s__711000244__1 = tmp46; continue L1 } } else { var tmp47 any; var root_2047 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2047, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2049 lang.IFn; if linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var arg_2050 any = s__711000244__3; if linked_2048 == nil { tmp47 = ifn_2049.Invoke_O__O(arg_2050) } else { tmp47 = linked_2048.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2047, arg_2050) }; s__711000244__1 = tmp47; continue L1 } } else { var tmp48 any; var root_2051 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2051, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2053 lang.IFn; if linked_2052 == nil { ifn_2053 = lang.IFn_Cast(root_2051) } else { ifn_2053 = nil }; var arg_2054 any = s__711000244__3; if linked_2052 == nil { tmp48 = ifn_2053.Invoke_O__O(arg_2054) } else { tmp48 = linked_2052.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2051, arg_2054) }; s__711000244__1 = tmp48; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :280:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Ctor_O_O_O_O_I_O(c__g, c__n, c__b__711000246, c__arg_conv any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_g = c__g; t.F_n = c__n; t.F_b__711000246 = c__b__711000246; t.F_arg_conv = c__arg_conv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Invoke_O__O(self any) any { { var i__711000245__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000245__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000245__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_31, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1719 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any; var root_1723 any = A_arbace_j2g_dyn_A_const_167.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = mm__2; if linked_1724 == nil { arg_1722 = ifn_1725.Invoke_O__O(arg_1726) } else { arg_1722 = linked_1724.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1723, arg_1726) }; if linked_1720 == nil { and__1927000168__auto____4 = ifn_1721.Invoke_O__O(arg_1722) } else { and__1927000168__auto____4 = linked_1720.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1719, arg_1722) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1727 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1728 == nil { tmp2 = ifn_1729.Invoke_O__O(arg_1730) } else { tmp2 = linked_1728.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1727, arg_1730) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :280:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_1731 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1733 lang.IFn

		if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any; var root_1735 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = t.F_n; if linked_1736 == nil { arg_1734 = ifn_1737.Invoke_O__O(arg_1738) } else { arg_1734 = linked_1736.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1735, arg_1738) }; if linked_1732 == nil { or__1927000174__auto____3 = ifn_1733.Invoke_O__O(arg_1734) } else { or__1927000174__auto____3 = linked_1732.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1731, arg_1734) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_1739 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any; var root_1744 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_1747 any = tmp4.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_1748 any; var root_1749 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = t.F_n; if linked_1750 == nil { arg_1748 = ifn_1751.Invoke_O__O(arg_1752) } else { arg_1748 = linked_1750.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1749, arg_1752) }; if linked_1745 == nil { arg_1742 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { arg_1742 = linked_1745.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) }; var arg_1743 any; var root_1753 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1754 == nil { arg_1743 = ifn_1755.Invoke_O__O(arg_1756) } else { arg_1743 = linked_1754.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1753, arg_1756) }; if linked_1740 == nil { tmp3 = ifn_1741.Invoke_O_O__O(arg_1742, arg_1743) } else { tmp3 = linked_1740.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1739, arg_1742, arg_1743) } }
//line :280:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_1757 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1759 lang.IFn



			if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = t.F_n; if linked_1758 == nil { tmp5 = ifn_1759.Invoke_O__O(arg_1760) } else { tmp5 = linked_1758.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1757, arg_1760) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2) } else { var root_1761 any = A_arbace_j2g_dyn_A_const_208.GetRawRoot__O(); var linked_1762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1761, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1763 lang.IFn; if linked_1762 == nil { ifn_1763 = lang.IFn_Cast(root_1761) } else { ifn_1763 = nil }; var arg_1764 any = t.F_n; var arg_1765 any = mm__2; if linked_1762 == nil { real__3 = ifn_1763.Invoke_O_O__O(arg_1764, arg_1765) } else { real__3 = linked_1762.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1761, arg_1764, arg_1765) } }
//line :280:1
			var vec__711000250__4 any; var root_1766 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1768 lang.IFn




			if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1767 == nil { vec__711000250__4 = ifn_1768.Invoke_O__O(arg_1769) } else { vec__711000250__4 = linked_1767.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1766, arg_1769) }
//line :280:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000253__7 any; var root_1770 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1772 lang.IFn; _ = ___6





			if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = real__3; if linked_1771 == nil { vec__711000253__7 = ifn_1772.Invoke_O__O(arg_1773) } else { vec__711000253__7 = linked_1771.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1770, arg_1773) }
//line :280:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_1774 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = t.F_b__711000246; var arg_1778 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_209; var tmp8 any = A_arbace_j2g_dyn_A_const_210; var tmp9 any = A_arbace_j2g_dyn_A_const_211; var tmp10 any; var tmp11 any; var root_1779 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1781 lang.IFn








				if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = ps__5; if linked_1780 == nil { tmp11 = ifn_1781.Invoke_O__O(arg_1782) } else { tmp11 = linked_1780.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1779, arg_1782) }; if jrt.J2g_Truth(tmp11) { var root_1783 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1787 any = A_arbace_j2g_dyn_A_const_212; var arg_1788 any = A_arbace_j2g_dyn_A_const_213; var arg_1789 any; var root_1790 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = A_arbace_j2g_dyn_A_const_214.GetRawRoot__O(); var arg_1794 any = ps__5; if linked_1791 == nil { arg_1789 = ifn_1792.Invoke_O_O__O(arg_1793, arg_1794) } else { arg_1789 = linked_1791.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1790, arg_1793, arg_1794) }; if linked_1784 == nil { tmp10 = ifn_1785.Invoke_O_O_O_O__O(arg_1786, arg_1787, arg_1788, arg_1789) } else { tmp10 = linked_1784.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1783, arg_1786, arg_1787, arg_1788, arg_1789) } } else { tmp10 = nil }
//line :288:1
				var tmp12 any = tmp10; var tmp13 any = A_arbace_j2g_dyn_A_const_215; var tmp14 any = A_arbace_j2g_dyn_A_const_216; var tmp15 any = A_arbace_j2g_dyn_A_const_217; var tmp16 any; var root_1795 any = A_arbace_j2g_dyn_A_const_218.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1797 lang.IFn


				if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any = A_arbace_j2g_dyn_A_const_219; var arg_1799 any; var root_1801 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any; var tmp17 any; var root_1806 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_1807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1806, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1808 lang.IFn; if linked_1807 == nil { ifn_1808 = lang.IFn_Cast(root_1806) } else { ifn_1808 = nil }; var arg_1809 any = A_arbace_j2g_dyn_A_const_220; var arg_1810 any = A_arbace_j2g_dyn_A_const_221; if linked_1807 == nil { tmp17 = ifn_1808.Invoke_O_O__O(arg_1809, arg_1810) } else { tmp17 = linked_1807.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1806, arg_1809, arg_1810) }; arg_1804 = lang.Tuple_Create_O__IPersistentVector(tmp17); var arg_1805 any = A_arbace_j2g_dyn_A_const_222; if linked_1802 == nil { arg_1799 = ifn_1803.Invoke_O_O__O(arg_1804, arg_1805) } else { arg_1799 = linked_1802.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1801, arg_1804, arg_1805) }; var arg_1800 any; var root_1811 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1811, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1813 lang.IFn
				if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any; var tmp18 any; var or__1927000174__auto____10 any; var root_1816 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1816, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1818 lang.IFn
				if linked_1817 == nil { ifn_1818 = lang.IFn_Cast(root_1816) } else { ifn_1818 = nil }; var arg_1819 any = t.F_n; if linked_1817 == nil { or__1927000174__auto____10 = ifn_1818.Invoke_O__O(arg_1819) } else { or__1927000174__auto____10 = linked_1817.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1816, arg_1819) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp18 = or__1927000174__auto____10 } else { var root_1820 any = A_arbace_j2g_dyn_A_const_223.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1820, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = t.F_n; if linked_1821 == nil { tmp18 = ifn_1822.Invoke_O__O(arg_1823) } else { tmp18 = linked_1821.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1820, arg_1823) } }; if jrt.J2g_Truth(tmp18) { arg_1814 = nil } else { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp20 any; var root_1824 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1826 lang.IFn; if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any = A_arbace_j2g_dyn_A_const_73; var arg_1828 any = t.F_n; var arg_1829 any = Lit_32; if linked_1825 == nil { tmp20 = ifn_1826.Invoke_O_O_O__O(arg_1827, arg_1828, arg_1829) } else { tmp20 = linked_1825.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1824, arg_1827, arg_1828, arg_1829) }; arg_1814 = lang.Tuple_Create_O__IPersistentVector(tmp19.Invoke_O__O(tmp20)) }
//line :292:1
				var arg_1815 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyn_A_const_224; var tmp23 any = A_arbace_j2g_dyn_A_const_233; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyn_A_const_234; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_235; var tmp28 any; var root_1861 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1861, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1863 lang.IFn

				if linked_1862 == nil { ifn_1863 = lang.IFn_Cast(root_1861) } else { ifn_1863 = nil }; var arg_1864 any = t.F_g; if linked_1862 == nil { tmp28 = ifn_1863.Invoke_O__O(arg_1864) } else { tmp28 = linked_1862.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1861, arg_1864) }
//line :292:1
				var tmp29 any = lang.Tuple_Create_O_O__IPersistentVector(tmp23, tmp24.Invoke_O_O__O(tmp25, tmp26.Invoke_O_O_O_O__O(tmp27, tmp28, A_arbace_j2g_dyn_A_const_236, A_arbace_j2g_dyn_A_const_237))); var tmp30 any = A_arbace_j2g_dyn_A_const_225; var tmp31 any = A_arbace_j2g_dyn_A_const_226; var tmp32 any; var root_1830 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1832 lang.IFn




				if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1834 any; var root_1838 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1840 lang.IFn; if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp34 any; var root_1842 any = A_arbace_j2g_dyn_A_const_207.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = real__3; if linked_1843 == nil { tmp34 = ifn_1844.Invoke_O__O(arg_1845) } else { tmp34 = linked_1843.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1842, arg_1845) }; arg_1841 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, nil, tmp34)).Ref(); if linked_1839 == nil { arg_1834 = ifn_1840.Invoke_O__O(arg_1841) } else { arg_1834 = linked_1839.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1838, arg_1841) }; var arg_1835 any; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp36 any; var root_1846 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1848 lang.IFn
				if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_16, nil); var tmp38 any; var root_1850 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1852 lang.IFn; if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any = t.F_n; if linked_1851 == nil { tmp38 = ifn_1852.Invoke_O__O(arg_1853) } else { tmp38 = linked_1851.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1850, arg_1853) }; arg_1849 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_1847 == nil { tmp36 = ifn_1848.Invoke_O__O(arg_1849) } else { tmp36 = linked_1847.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1846, arg_1849) }; arg_1835 = tmp35.Invoke_O_O__O(tmp36, A_arbace_j2g_dyn_A_const_227)
//line :297:1
				var arg_1836 any = A_arbace_j2g_dyn_A_const_228; var arg_1837 any; var root_1854 any = A_arbace_j2g_dyn_A_const_229.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1856 lang.IFn

				if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any; var fnbody__1860 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(t.F_arg_conv); var tmp39 *jrt.Class; var fncls__1859 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class; if fncls__1859 == nil { var fncls__1859d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__1860); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class = fncls__1859d; tmp39 = fncls__1859d } else { tmp39 = fncls__1859 }; arg_1857 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1860, tmp39, nil); var arg_1858 any = ps__5; if linked_1855 == nil { arg_1837 = ifn_1856.Invoke_O_O__O(arg_1857, arg_1858) } else { arg_1837 = linked_1855.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1854, arg_1857, arg_1858) }
//line :297:1
				if linked_1831 == nil { tmp32 = ifn_1832.Invoke_O_O_O_O_O__O(arg_1833, arg_1834, arg_1835, arg_1836, arg_1837) } else { tmp32 = linked_1831.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1830, arg_1833, arg_1834, arg_1835, arg_1836, arg_1837) }
//line :292:1
				arg_1815 = lang.Tuple_Create_O__IPersistentVector(tmp21.Invoke_O_O_O_O_O_O__O(tmp22, tmp29, tmp30, tmp31, tmp32, A_arbace_j2g_dyn_A_const_232)); if linked_1812 == nil { arg_1800 = ifn_1813.Invoke_O_O__O(arg_1814, arg_1815) } else { arg_1800 = linked_1812.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1811, arg_1814, arg_1815) }
//line :291:1
				if linked_1796 == nil { tmp16 = ifn_1797.Invoke_O_O_O__O(arg_1798, arg_1799, arg_1800) } else { tmp16 = linked_1796.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1795, arg_1798, arg_1799, arg_1800) }
//line :288:1
				arg_1778 = tmp6.Invoke_O_O_O_O_O_O_O_O__O(tmp7, tmp8, tmp9, tmp12, tmp13, tmp14, tmp15, tmp16)
//line :280:1
				if linked_1775 == nil { ifn_1776.Invoke_O_O__O(arg_1777, arg_1778) } else { linked_1775.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1774, arg_1777, arg_1778) }; i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


















func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_230, A_arbace_j2g_dyn_A_const_231, i__1)) }
//line :299:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_230, A_arbace_j2g_dyn_A_const_231, i__1)) }


func A_arbace_j2g_dyn_go_method_names_A_New() *A_arbace_j2g_dyn_go_method_names_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Ctor() {}
//line :302:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Invoke_O_O__O(self, n__0 any) any {




	var root_2071 any = A_arbace_j2g_dyn_A_const_244.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_2075 any; var root_2076 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2078 lang.IFn
	if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any; var iter__1927001039__auto____2 any; var fnbody__2309 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New(); var tmp1 *jrt.Class; var fncls__2308 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class
	if fncls__2308 == nil { var fncls__2308d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, nil); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class = fncls__2308d; tmp1 = fncls__2308d } else { tmp1 = fncls__2308 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2309, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp3 any; var root_2310 any = A_arbace_j2g_dyn_A_const_168.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2310, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_2312 lang.IFn; if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any = n__0; if linked_2311 == nil { tmp3 = ifn_2312.Invoke_O__O(arg_2313) } else { tmp3 = linked_2311.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_2310, arg_2313) }; arg_2079 = tmp2.Invoke_O__O(tmp3)
//line :308:1
	var arg_2080 any; var iter__1927001039__auto____2_2 any; var fnbody__2405 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(n__0); var tmp4 *jrt.Class
	var fncls__2404 /*line :308:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class








	if fncls__2404 == nil { var fncls__2404d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, fnbody__2405); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class = fncls__2404d; tmp4 = fncls__2404d } else { tmp4 = fncls__2404 }; iter__1927001039__auto____2_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2405, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2_2); var tmp6 any; var root_2406 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_2407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2406, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_2408 lang.IFn; if linked_2407 == nil { ifn_2408 = lang.IFn_Cast(root_2406) } else { ifn_2408 = nil }; var arg_2409 any = n__0; if linked_2407 == nil { tmp6 = ifn_2408.Invoke_O__O(arg_2409) } else { tmp6 = linked_2407.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_2406, arg_2409) }; arg_2080 = tmp5.Invoke_O__O(tmp6)
//line :308:1
	if linked_2077 == nil { arg_2075 = ifn_2078.Invoke_O_O__O(arg_2079, arg_2080) } else { arg_2075 = linked_2077.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2076, arg_2079, arg_2080) }
//line :307:1
	if linked_2072 == nil { return ifn_2073.Invoke_O_O__O(arg_2074, arg_2075) } else { return linked_2072.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2071, arg_2074, arg_2075)
	} }
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Ctor() {}
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Invoke_O_O__O(self, s__711000271__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2307 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(self, s__711000271__1); var tmp2 *jrt.Class; var fncls__2306 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class; if fncls__2306 == nil { var fncls__2306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, fnbody__2307); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class = fncls__2306d; tmp2 = fncls__2306d } else { tmp2 = fncls__2306 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2307, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A{}; t.Ctor_O_O(p0, p1); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Ctor_O_O(c__iter__711000270, c__s__711000271 any) { t.F_iter__711000270 = c__iter__711000270; t.F_s__711000271 = c__s__711000271 }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Invoke_O__O(self any) any { { var s__711000271__1 any; var t_ any = t.F_s__711000271; t.F_s__711000271 = nil; s__711000271__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2081 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2081, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2083 lang.IFn; if linked_2082 == nil { ifn_2083 = lang.IFn_Cast(root_2081) } else { ifn_2083 = nil }; var arg_2084 any = s__711000271__1; if linked_2082 == nil { temp__1927000414__auto____2 = ifn_2083.Invoke_O__O(arg_2084) } else { temp__1927000414__auto____2 = linked_2082.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2081, arg_2084) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_2085 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2085, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2087 lang.IFn; if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = xs__1927001018__auto____3; if linked_2086 == nil { c__4 = ifn_2087.Invoke_O__O(arg_2088) } else { c__4 = linked_2086.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2085, arg_2088) }; var tmp1 any; var and__1927000168__auto____5 any = c__4
														if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2089 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2089, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2091 lang.IFn; if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any = c__4; var arg_2093 any = Lit_100; if linked_2090 == nil { tmp1 = ifn_2091.Invoke_O_O__O(arg_2092, arg_2093) } else { tmp1 = linked_2090.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2089, arg_2092, arg_2093) } } else { tmp1 = and__1927000168__auto____5 }
//line :309:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var fnbody__2155 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New(); var tmp2 *jrt.Class; var fncls__2154 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class; if fncls__2154 == nil { var fncls__2154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, nil); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class = fncls__2154d; tmp2 = fncls__2154d } else { tmp2 = fncls__2154 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2155, tmp2, nil); var fs__1927001036__auto____6 any; var root_2156 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var tmp5 any; var root_2160 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_2161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2160, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2162 lang.IFn

		if linked_2161 == nil { ifn_2162 = lang.IFn_Cast(root_2160) } else { ifn_2162 = nil }; var arg_2163 any = c__4; if linked_2161 == nil { tmp5 = ifn_2162.Invoke_O__O(arg_2163) } else { tmp5 = linked_2161.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2160, arg_2163) }; if jrt.J2g_Truth(tmp5) {
			var root_2164 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2164, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_2166 lang.IFn; if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var tmp6 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_2167 any = tmp6.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_2168 any; var root_2169 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2169, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2171 lang.IFn; if linked_2170 == nil { ifn_2171 = lang.IFn_Cast(root_2169) } else { ifn_2171 = nil }; var arg_2172 any = c__4; if linked_2170 == nil { arg_2168 = ifn_2171.Invoke_O__O(arg_2172) } else { arg_2168 = linked_2170.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2169, arg_2172) }; if linked_2165 == nil { tmp4 = ifn_2166.Invoke_O_O__O(arg_2167, arg_2168) } else { tmp4 = linked_2165.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_2164, arg_2167, arg_2168) } } else {
//line :311:1
				var iter__1927001039__auto____6 any; var fnbody__2284 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New(); var tmp7 *jrt.Class
				var fncls__2283 /*line :311:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class

				if fncls__2283 == nil { var fncls__2283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, nil); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class = fncls__2283d; tmp7 = fncls__2283d } else { tmp7 = fncls__2283 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2284, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp9 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp10 any; var root_2285 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = c__4; if linked_2286 == nil { tmp10 = ifn_2287.Invoke_O__O(arg_2288) } else { tmp10 = linked_2286.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2285, arg_2288) }; tmp4 = tmp8.Invoke_O__O(tmp9.Invoke_O__O(tmp10)) }
//line :309:1
		arg_2159 = tmp3.Invoke_O__O(tmp4); if linked_2157 == nil { fs__1927001036__auto____6 = ifn_2158.Invoke_O__O(arg_2159) } else { fs__1927001036__auto____6 = linked_2157.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2156, arg_2159) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2289 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = fs__1927001036__auto____6; var arg_2293 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__711000270); var tmp12 any; var root_2294 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2294, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2296 lang.IFn; if linked_2295 == nil { ifn_2296 = lang.IFn_Cast(root_2294) } else { ifn_2296 = nil }; var arg_2297 any = s__711000271__1; if linked_2295 == nil { tmp12 = ifn_2296.Invoke_O__O(arg_2297) } else { tmp12 = linked_2295.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2294, arg_2297) }; arg_2293 = tmp11.Invoke_O__O(tmp12); if linked_2290 == nil { return ifn_2291.Invoke_O_O__O(arg_2292, arg_2293) } else { return linked_2290.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2289, arg_2292, arg_2293) } } else { var tmp13 any; var root_2298 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2298, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2300 lang.IFn; if linked_2299 == nil { ifn_2300 = lang.IFn_Cast(root_2298) } else { ifn_2300 = nil }; var arg_2301 any = s__711000271__1; if linked_2299 == nil { tmp13 = ifn_2300.Invoke_O__O(arg_2301) } else { tmp13 = linked_2299.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2298, arg_2301) }; s__711000271__1 = tmp13; continue L1 } } else { var tmp14 any; var root_2302 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2302, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2304 lang.IFn; if linked_2303 == nil { ifn_2304 = lang.IFn_Cast(root_2302) } else { ifn_2304 = nil }; var arg_2305 any = s__711000271__1; if linked_2303 == nil { tmp14 = ifn_2304.Invoke_O__O(arg_2305) } else { tmp14 = linked_2303.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2302, arg_2305) }; s__711000271__1 = tmp14; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Ctor() {}
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Invoke_O_O__O(self, s__711000273__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2153 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(s__711000273__1, self); var tmp2 *jrt.Class; var fncls__2152 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class; if fncls__2152 == nil { var fncls__2152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, fnbody__2153); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class = fncls__2152d; tmp2 = fncls__2152d } else { tmp2 = fncls__2152 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2153, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A{}; t.Ctor_O_O(p0, p1); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Ctor_O_O(c__s__711000273, c__iter__711000272 any) { t.F_s__711000273 = c__s__711000273; t.F_iter__711000272 = c__iter__711000272 }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Invoke_O__O(self any) any { { var s__711000273__1 any; var t_ any = t.F_s__711000273; t.F_s__711000273 = nil; s__711000273__1 = t_; for { var temp__1927000414__auto____2 any; var root_2094 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = s__711000273__1; if linked_2095 == nil { temp__1927000414__auto____2 = ifn_2096.Invoke_O__O(arg_2097) } else { temp__1927000414__auto____2 = linked_2095.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2094, arg_2097) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000273__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2098 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = s__711000273__3; if linked_2099 == nil { tmp1 = ifn_2100.Invoke_O__O(arg_2101) } else { tmp1 = linked_2099.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2098, arg_2101) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2102 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = s__711000273__3; if linked_2103 == nil { c__1927001037__auto____4 = ifn_2104.Invoke_O__O(arg_2105) } else { c__1927001037__auto____4 = linked_2103.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2102, arg_2105) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000275__6 any; var root_2106 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2107 == nil { b__711000275__6 = ifn_2108.Invoke_O__O(arg_2109) } else { b__711000275__6 = linked_2107.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2106, arg_2109) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2116 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(b__711000275__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2115 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class; if fncls__2115 == nil { var fncls__2115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, fnbody__2116); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class = fncls__2115d; tmp3 = fncls__2115d } else { tmp3 = fncls__2115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2116, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2117 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2117, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any; var root_2122 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2124 lang.IFn; if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any = b__711000275__6; if linked_2123 == nil { arg_2120 = ifn_2124.Invoke_O__O(arg_2125) } else { arg_2120 = linked_2123.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2122, arg_2125) }; var arg_2121 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp5 any; var root_2126 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = s__711000273__3; if linked_2127 == nil { tmp5 = ifn_2128.Invoke_O__O(arg_2129) } else { tmp5 = linked_2127.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2126, arg_2129) }; arg_2121 = tmp4.Invoke_O__O(tmp5); if linked_2118 == nil { return ifn_2119.Invoke_O_O__O(arg_2120, arg_2121) } else { return linked_2118.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2117, arg_2120, arg_2121) } } else { var root_2130 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any; var root_2135 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2135, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2137 lang.IFn; if linked_2136 == nil { ifn_2137 = lang.IFn_Cast(root_2135) } else { ifn_2137 = nil }; var arg_2138 any = b__711000275__6; if linked_2136 == nil { arg_2133 = ifn_2137.Invoke_O__O(arg_2138) } else { arg_2133 = linked_2136.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2135, arg_2138) }; var arg_2134 any; if linked_2131 == nil { return ifn_2132.Invoke_O_O__O(arg_2133, arg_2134) } else { return linked_2131.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2130, arg_2133, arg_2134) } } } else { var nme__4 any; var root_2139 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = s__711000273__3; if linked_2140 == nil { nme__4 = ifn_2141.Invoke_O__O(arg_2142) } else { nme__4 = linked_2140.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2139, arg_2142) }; var root_2143 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = nme__4; var arg_2147 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp7 any; var root_2148 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any = s__711000273__3; if linked_2149 == nil { tmp7 = ifn_2150.Invoke_O__O(arg_2151) } else { tmp7 = linked_2149.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2148, arg_2151) }; arg_2147 = tmp6.Invoke_O__O(tmp7); if linked_2144 == nil { return ifn_2145.Invoke_O_O__O(arg_2146, arg_2147) } else { return linked_2144.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2143, arg_2146, arg_2147) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Ctor_O_I_O(c__b__711000275 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000275 = c__b__711000275; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Invoke_O__O(self any) any { { var i__711000274__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000274__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nme__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000274__1)); var root_2110 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2110, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2112 lang.IFn; if linked_2111 == nil { ifn_2112 = lang.IFn_Cast(root_2110) } else { ifn_2112 = nil }; var arg_2113 any = t.F_b__711000275; var arg_2114 any = nme__2; if linked_2111 == nil { ifn_2112.Invoke_O_O__O(arg_2113, arg_2114) } else { linked_2111.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2110, arg_2113, arg_2114) }; i__711000274__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000274__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Ctor() {}
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Invoke_O_O__O(self, s__711000285__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2282 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(s__711000285__1, self); var tmp2 *jrt.Class; var fncls__2281 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class; if fncls__2281 == nil { var fncls__2281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, fnbody__2282); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class = fncls__2281d; tmp2 = fncls__2281d } else { tmp2 = fncls__2281 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2282, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :313:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A{}; t.Ctor_O_O(p0, p1); return t }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Ctor_O_O(c__s__711000285, c__iter__711000284 any) { t.F_s__711000285 = c__s__711000285; t.F_iter__711000284 = c__iter__711000284 }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Invoke_O__O(self any) any { { var s__711000285__1 any; var t_ any = t.F_s__711000285; t.F_s__711000285 = nil; s__711000285__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2173 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any = s__711000285__1; if linked_2174 == nil { temp__1927000414__auto____2 = ifn_2175.Invoke_O__O(arg_2176) } else { temp__1927000414__auto____2 = linked_2174.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2173, arg_2176) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000285__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2177 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = s__711000285__3; if linked_2178 == nil { tmp1 = ifn_2179.Invoke_O__O(arg_2180) } else { tmp1 = linked_2178.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2177, arg_2180) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2181 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any = s__711000285__3; if linked_2182 == nil { c__1927001037__auto____4 = ifn_2183.Invoke_O__O(arg_2184) } else { c__1927001037__auto____4 = linked_2182.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2181, arg_2184) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000287__6 any; var root_2185 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2187 lang.IFn; if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2186 == nil { b__711000287__6 = ifn_2187.Invoke_O__O(arg_2188) } else { b__711000287__6 = linked_2186.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2185, arg_2188) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2218 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(b__711000287__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2217 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class; if fncls__2217 == nil { var fncls__2217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, fnbody__2218); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class = fncls__2217d; tmp3 = fncls__2217d } else { tmp3 = fncls__2217 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2218, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2219 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2221 lang.IFn; if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any; var root_2224 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = b__711000287__6; if linked_2225 == nil { arg_2222 = ifn_2226.Invoke_O__O(arg_2227) } else { arg_2222 = linked_2225.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2224, arg_2227) }; var arg_2223 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp5 any; var root_2228 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2228, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2230 lang.IFn; if linked_2229 == nil { ifn_2230 = lang.IFn_Cast(root_2228) } else { ifn_2230 = nil }; var arg_2231 any = s__711000285__3; if linked_2229 == nil { tmp5 = ifn_2230.Invoke_O__O(arg_2231) } else { tmp5 = linked_2229.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2228, arg_2231) }; arg_2223 = tmp4.Invoke_O__O(tmp5); if linked_2220 == nil { return ifn_2221.Invoke_O_O__O(arg_2222, arg_2223) } else { return linked_2220.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2219, arg_2222, arg_2223) } } else { var root_2232 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2232, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2234 lang.IFn; if linked_2233 == nil { ifn_2234 = lang.IFn_Cast(root_2232) } else { ifn_2234 = nil }; var arg_2235 any; var root_2237 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any = b__711000287__6; if linked_2238 == nil { arg_2235 = ifn_2239.Invoke_O__O(arg_2240) } else { arg_2235 = linked_2238.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2237, arg_2240) }; var arg_2236 any; if linked_2233 == nil { return ifn_2234.Invoke_O_O__O(arg_2235, arg_2236) } else { return linked_2233.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2232, arg_2235, arg_2236) } } } else { var mm__4 any; var root_2241 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2243 lang.IFn; if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any = s__711000285__3; if linked_2242 == nil { mm__4 = ifn_2243.Invoke_O__O(arg_2244) } else { mm__4 = linked_2242.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2241, arg_2244) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2245 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2247 lang.IFn
																				if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; var arg_2248 any; var root_2249 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = mm__4; if linked_2250 == nil { arg_2248 = ifn_2251.Invoke_O__O(arg_2252) } else { arg_2248 = linked_2250.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2249, arg_2252) }; if linked_2246 == nil { and__1927000168__auto____5 = ifn_2247.Invoke_O__O(arg_2248) } else { and__1927000168__auto____5 = linked_2246.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2245, arg_2248) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2253 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2253, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2255 lang.IFn; if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = Lit_31; var arg_2257 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_2254 == nil { and__1927000168__auto____6 = ifn_2255.Invoke_O_O__O(arg_2256, arg_2257) } else { and__1927000168__auto____6 = linked_2254.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2253, arg_2256, arg_2257) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2258 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = Lit_107; var arg_2262 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_2259 == nil { tmp6 = ifn_2260.Invoke_O_O__O(arg_2261, arg_2262) } else { tmp6 = linked_2259.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2258, arg_2261, arg_2262) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :313:1
	if jrt.J2g_Truth(tmp6) { var root_2263 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2263, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2265 lang.IFn; if linked_2264 == nil { ifn_2265 = lang.IFn_Cast(root_2263) } else { ifn_2265 = nil }; var arg_2266 any; var root_2268 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2268, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2270 lang.IFn

		if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); var arg_2272 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_2269 == nil { arg_2266 = ifn_2270.Invoke_O_O__O(arg_2271, arg_2272) } else { arg_2266 = linked_2269.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2268, arg_2271, arg_2272) }
//line :313:1
		var arg_2267 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp8 any; var root_2273 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2275 lang.IFn; if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any = s__711000285__3; if linked_2274 == nil { tmp8 = ifn_2275.Invoke_O__O(arg_2276) } else { tmp8 = linked_2274.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2273, arg_2276) }; arg_2267 = tmp7.Invoke_O__O(tmp8); if linked_2264 == nil { return ifn_2265.Invoke_O_O__O(arg_2266, arg_2267) } else { return linked_2264.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2263, arg_2266, arg_2267) } } else { var tmp9 any; var root_2277 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = s__711000285__3; if linked_2278 == nil { tmp9 = ifn_2279.Invoke_O__O(arg_2280) } else { tmp9 = linked_2278.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2277, arg_2280) }; s__711000285__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :313:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Ctor_O_I_O(c__b__711000287 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000287 = c__b__711000287; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Invoke_O__O(self any) any { { var i__711000286__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000286__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000286__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2189 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2189, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2191 lang.IFn
																					if linked_2190 == nil { ifn_2191 = lang.IFn_Cast(root_2189) } else { ifn_2191 = nil }; var arg_2192 any; var root_2193 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2193, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = mm__2; if linked_2194 == nil { arg_2192 = ifn_2195.Invoke_O__O(arg_2196) } else { arg_2192 = linked_2194.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2193, arg_2196) }; if linked_2190 == nil { and__1927000168__auto____3 = ifn_2191.Invoke_O__O(arg_2192) } else { and__1927000168__auto____3 = linked_2190.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2189, arg_2192) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_2197 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2197, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2199 lang.IFn; if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any = Lit_31; var arg_2201 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_2198 == nil { and__1927000168__auto____4 = ifn_2199.Invoke_O_O__O(arg_2200, arg_2201) } else { and__1927000168__auto____4 = linked_2198.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2197, arg_2200, arg_2201) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_2202 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2204 lang.IFn; if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any = Lit_107; var arg_2206 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_2203 == nil { tmp2 = ifn_2204.Invoke_O_O__O(arg_2205, arg_2206) } else { tmp2 = linked_2203.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2202, arg_2205, arg_2206) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :313:1
	if jrt.J2g_Truth(tmp2) { var root_2207 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2209 lang.IFn; if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = t.F_b__711000287; var arg_2211 any; var root_2212 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2214 lang.IFn

		if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); var arg_2216 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_2213 == nil { arg_2211 = ifn_2214.Invoke_O_O__O(arg_2215, arg_2216) } else { arg_2211 = linked_2213.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2212, arg_2215, arg_2216) }
//line :313:1
		if linked_2208 == nil { ifn_2209.Invoke_O_O__O(arg_2210, arg_2211) } else { linked_2208.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2207, arg_2210, arg_2211) }; i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } else { i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(p0 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A{}; t.Ctor_O(p0); return t }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Invoke_O_O__O(self, s__711000297__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2403 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(s__711000297__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__2402 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class; if fncls__2402 == nil { var fncls__2402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, fnbody__2403); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class = fncls__2402d; tmp2 = fncls__2402d } else { tmp2 = fncls__2402 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2403, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :317:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Ctor_O_O_O(c__s__711000297, c__n, c__iter__711000296 any) { t.F_s__711000297 = c__s__711000297; t.F_n = c__n; t.F_iter__711000296 = c__iter__711000296 }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Invoke_O__O(self any) any { { var s__711000297__1 any; var t_ any = t.F_s__711000297; t.F_s__711000297 = nil; s__711000297__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2314 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2314, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2316 lang.IFn; if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = s__711000297__1; if linked_2315 == nil { temp__1927000414__auto____2 = ifn_2316.Invoke_O__O(arg_2317) } else { temp__1927000414__auto____2 = linked_2315.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2314, arg_2317) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000297__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2318 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = s__711000297__3; if linked_2319 == nil { tmp1 = ifn_2320.Invoke_O__O(arg_2321) } else { tmp1 = linked_2319.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2318, arg_2321) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2322 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2322, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2324 lang.IFn; if linked_2323 == nil { ifn_2324 = lang.IFn_Cast(root_2322) } else { ifn_2324 = nil }; var arg_2325 any = s__711000297__3; if linked_2323 == nil { c__1927001037__auto____4 = ifn_2324.Invoke_O__O(arg_2325) } else { c__1927001037__auto____4 = linked_2323.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2322, arg_2325) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000299__6 any; var root_2326 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2328 lang.IFn; if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2327 == nil { b__711000299__6 = ifn_2328.Invoke_O__O(arg_2329) } else { b__711000299__6 = linked_2327.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2326, arg_2329) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2349 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(t.F_n, b__711000299__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2348 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class; if fncls__2348 == nil { var fncls__2348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, fnbody__2349); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class = fncls__2348d; tmp3 = fncls__2348d } else { tmp3 = fncls__2348 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2349, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2350 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2350, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2352 lang.IFn; if linked_2351 == nil { ifn_2352 = lang.IFn_Cast(root_2350) } else { ifn_2352 = nil }; var arg_2353 any; var root_2355 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2355, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2357 lang.IFn; if linked_2356 == nil { ifn_2357 = lang.IFn_Cast(root_2355) } else { ifn_2357 = nil }; var arg_2358 any = b__711000299__6; if linked_2356 == nil { arg_2353 = ifn_2357.Invoke_O__O(arg_2358) } else { arg_2353 = linked_2356.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2355, arg_2358) }; var arg_2354 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp5 any; var root_2359 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2359, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2361 lang.IFn; if linked_2360 == nil { ifn_2361 = lang.IFn_Cast(root_2359) } else { ifn_2361 = nil }; var arg_2362 any = s__711000297__3; if linked_2360 == nil { tmp5 = ifn_2361.Invoke_O__O(arg_2362) } else { tmp5 = linked_2360.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2359, arg_2362) }; arg_2354 = tmp4.Invoke_O__O(tmp5); if linked_2351 == nil { return ifn_2352.Invoke_O_O__O(arg_2353, arg_2354) } else { return linked_2351.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2350, arg_2353, arg_2354) } } else { var root_2363 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; var arg_2366 any; var root_2368 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2368, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = b__711000299__6; if linked_2369 == nil { arg_2366 = ifn_2370.Invoke_O__O(arg_2371) } else { arg_2366 = linked_2369.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2368, arg_2371) }; var arg_2367 any; if linked_2364 == nil { return ifn_2365.Invoke_O_O__O(arg_2366, arg_2367) } else { return linked_2364.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2363, arg_2366, arg_2367) } } } else { var j__4 any; var root_2372 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = s__711000297__3; if linked_2373 == nil { j__4 = ifn_2374.Invoke_O__O(arg_2375) } else { j__4 = linked_2373.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2372, arg_2375) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2376 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = j__4; var arg_2380 any = t.F_n; if linked_2377 == nil { and__1927000168__auto____5 = ifn_2378.Invoke_O_O__O(arg_2379, arg_2380) } else { and__1927000168__auto____5 = linked_2377.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2376, arg_2379, arg_2380) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2381 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2383 lang.IFn; if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; var arg_2384 any = j__4; if linked_2382 == nil { tmp6 = ifn_2383.Invoke_O__O(arg_2384) } else { tmp6 = linked_2382.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2381, arg_2384) } } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_2385 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2385, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2387 lang.IFn; if linked_2386 == nil { ifn_2387 = lang.IFn_Cast(root_2385) } else { ifn_2387 = nil }; var arg_2388 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_92, nil); var tmp8 any; var root_2390 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2390, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2392 lang.IFn
														if linked_2391 == nil { ifn_2392 = lang.IFn_Cast(root_2390) } else { ifn_2392 = nil }; var arg_2393 any = j__4; if linked_2391 == nil { tmp8 = ifn_2392.Invoke_O__O(arg_2393) } else { tmp8 = linked_2391.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2390, arg_2393) }; arg_2388 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :317:1
	var arg_2389 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp10 any; var root_2394 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2394, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2396 lang.IFn; if linked_2395 == nil { ifn_2396 = lang.IFn_Cast(root_2394) } else { ifn_2396 = nil }; var arg_2397 any = s__711000297__3; if linked_2395 == nil { tmp10 = ifn_2396.Invoke_O__O(arg_2397) } else { tmp10 = linked_2395.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2394, arg_2397) }; arg_2389 = tmp9.Invoke_O__O(tmp10); if linked_2386 == nil { return ifn_2387.Invoke_O_O__O(arg_2388, arg_2389) } else { return linked_2386.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2385, arg_2388, arg_2389) } } else { var tmp11 any; var root_2398 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2398, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2400 lang.IFn; if linked_2399 == nil { ifn_2400 = lang.IFn_Cast(root_2398) } else { ifn_2400 = nil }; var arg_2401 any = s__711000297__3; if linked_2399 == nil { tmp11 = ifn_2400.Invoke_O__O(arg_2401) } else { tmp11 = linked_2399.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2398, arg_2401) }; s__711000297__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :317:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Ctor_O_O_I_O(c__n, c__b__711000299 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000299 = c__b__711000299; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Invoke_O__O(self any) any { { var i__711000298__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000298__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000298__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2330 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any = j__2; var arg_2334 any = t.F_n; if linked_2331 == nil { and__1927000168__auto____3 = ifn_2332.Invoke_O_O__O(arg_2333, arg_2334) } else { and__1927000168__auto____3 = linked_2331.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2330, arg_2333, arg_2334) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2335 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2337 lang.IFn; if linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any = j__2; if linked_2336 == nil { tmp2 = ifn_2337.Invoke_O__O(arg_2338) } else { tmp2 = linked_2336.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2335, arg_2338) } } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_2339 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = t.F_b__711000299; var arg_2343 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_92, nil); var tmp4 any; var root_2344 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2344, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2346 lang.IFn
																if linked_2345 == nil { ifn_2346 = lang.IFn_Cast(root_2344) } else { ifn_2346 = nil }; var arg_2347 any = j__2; if linked_2345 == nil { tmp4 = ifn_2346.Invoke_O__O(arg_2347) } else { tmp4 = linked_2345.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2344, arg_2347) }; arg_2343 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :317:1
	if linked_2340 == nil { ifn_2341.Invoke_O_O__O(arg_2342, arg_2343) } else { linked_2340.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2339, arg_2342, arg_2343) }; i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } else { i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_sub_forms_A_New() *A_arbace_j2g_dyn_sub_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Ctor() {}
//line :320:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Invoke_O_O_O_O__O(self, n__0, ifaces__1, dyn_keys__2 any) any { var g__4 any; var root_2410 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_2411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2410, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_2412 lang.IFn; if






	linked_2411 == nil { ifn_2412 = lang.IFn_Cast(root_2410) } else { ifn_2412 = nil }; var arg_2413 any = n__0; if linked_2411 == nil { g__4 = ifn_2412.Invoke_O__O(arg_2413) } else { g__4 = linked_2411.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_2410, arg_2413) }; var recv__5 any; var tmp1 lang.IFn = /*line :320:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_287; var tmp3 any; var root_2963 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2963, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2965 lang.IFn; if







	linked_2964 == nil { ifn_2965 = lang.IFn_Cast(root_2963) } else { ifn_2965 = nil }; var arg_2966 any = g__4; if linked_2964 == nil { tmp3 = ifn_2965.Invoke_O__O(arg_2966) } else { tmp3 = linked_2964.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2963, arg_2966) }; recv__5 = tmp1.Invoke_O_O__O(tmp2, tmp3); var own__6 any; var root_2414 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_244.GetRawRoot__O(); var linked_2415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2414, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2416 lang.IFn; if








	linked_2415 == nil { ifn_2416 = lang.IFn_Cast(root_2414) } else { ifn_2416 = nil }; var arg_2417 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2418 any; var iter__1927001039__auto____6 any; var fnbody__2492 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New(); var tmp4 *jrt.Class; var fncls__2491 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class; if fncls__2491 == nil { var fncls__2491d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, nil); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class = fncls__2491d; tmp4 = fncls__2491d } else { tmp4 = fncls__2491 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2492, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp6 any; var root_2493 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_2494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2493, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_2495 lang.IFn; if linked_2494 == nil { ifn_2495 = lang.IFn_Cast(root_2493) } else { ifn_2495 = nil }; var arg_2496 any = n__0; if linked_2494 == nil { tmp6 = ifn_2495.Invoke_O__O(arg_2496) } else { tmp6 = linked_2494.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_2493, arg_2496) }; arg_2418 = tmp5.Invoke_O__O(tmp6); if linked_2415 == nil { own__6 = ifn_2416.Invoke_O_O__O(arg_2417, arg_2418) } else { own__6 = linked_2415.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2414, arg_2417, arg_2418) }; var dyn_set__7 any; var root_2497 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_245.GetRawRoot__O(); var linked_2498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2497, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2499 lang.IFn; if









	linked_2498 == nil { ifn_2499 = lang.IFn_Cast(root_2497) } else { ifn_2499 = nil }; var arg_2500 any = dyn_keys__2; if linked_2498 == nil { dyn_set__7 = ifn_2499.Invoke_O__O(arg_2500) } else { dyn_set__7 = linked_2498.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2497, arg_2500) }; var ks__8 any; var root_2501 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_2502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2501, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2503 lang.IFn; if










	linked_2502 == nil { ifn_2503 = lang.IFn_Cast(root_2501) } else { ifn_2503 = nil }; var arg_2504 any; var root_2505 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2506 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2505, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2507 lang.IFn; if linked_2506 == nil { ifn_2507 = lang.IFn_Cast(root_2505) } else { ifn_2507 = nil }; var arg_2508 any = dyn_keys__2; var arg_2509 any; var root_2510 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2510, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2512 lang.IFn; if linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any; var root_2514 any = A_arbace_j2g_dyn_A_const_246.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = dyn_set__7; var arg_2518 any; var root_2519 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2521 lang.IFn; if linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any = own__6; if linked_2520 == nil { arg_2518 = ifn_2521.Invoke_O__O(arg_2522) } else { arg_2518 = linked_2520.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2519, arg_2522) }; if linked_2515 == nil { arg_2513 = ifn_2516.Invoke_O_O__O(arg_2517, arg_2518) } else { arg_2513 = linked_2515.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2514, arg_2517, arg_2518) }; if linked_2511 == nil { arg_2509 = ifn_2512.Invoke_O__O(arg_2513) } else { arg_2509 = linked_2511.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2510, arg_2513) }; if linked_2506 == nil { arg_2504 = ifn_2507.Invoke_O_O__O(arg_2508, arg_2509) } else { arg_2504 = linked_2506.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2505, arg_2508, arg_2509) }; if linked_2502 == nil { ks__8 = ifn_2503.Invoke_O__O(arg_2504) } else { ks__8 = linked_2502.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2501, arg_2504) }; var clash__9 any; var root_2523 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_247.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, A_arbace_j2g_dyn_go_method_names_A_fn_class); var ifn_2525 lang.IFn; if











	linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = n__0; if linked_2524 == nil { clash__9 = ifn_2525.Invoke_O__O(arg_2526) } else { clash__9 = linked_2524.(*A_arbace_j2g_dyn_go_method_names_A).Invoke_O_O__O(root_2523, arg_2526) }; var slots__10 any; var root_2527 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2529 lang.IFn; if












	linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_95, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2528 == nil { slots__10 = ifn_2529.Invoke_O__O(arg_2530) } else { slots__10 = linked_2528.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2527, arg_2530) }; var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_42.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_248; var tmp10 *jrt.RefArray = jrt.ConstRefArray("[0,7,s12:---- DynSub_ns13:: proxies of ns2:, ns8: methods", []*jrt.Class{jrt.String_class}); var tmp11 any; var root_2539 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2541 lang.IFn; if
	linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = n__0; if linked_2540 == nil { tmp11 = ifn_2541.Invoke_O__O(arg_2542) } else { tmp11 = linked_2540.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2539, arg_2542) }; var tmp12 any = tmp11; var tmp13 any; var root_2543 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_2544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2543, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2545 lang.IFn; if
	linked_2544 == nil { ifn_2545 = lang.IFn_Cast(root_2543) } else { ifn_2545 = nil }; var arg_2546 any = n__0; var arg_2547 any = Lit_5; var arg_2548 any = Lit_6; if linked_2544 == nil { tmp13 = ifn_2545.Invoke_O_O_O__O(arg_2546, arg_2547, arg_2548) } else { tmp13 = linked_2544.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2543, arg_2546, arg_2547, arg_2548) }; var tmp14 any = /*line :334:1*/tmp8.Invoke_O_O__O(tmp9, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil, tmp13, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__8)).Ref(), nil)).Ref()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_dyn_A_const_249; var tmp17 any; var root_2549 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2549, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2551 lang.IFn; if


	linked_2550 == nil { ifn_2551 = lang.IFn_Cast(root_2549) } else { ifn_2551 = nil }; var arg_2552 any = g__4; if linked_2550 == nil { tmp17 = ifn_2551.Invoke_O__O(arg_2552) } else { tmp17 = linked_2550.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2549, arg_2552) }; var tmp18 any = tmp17; var tmp19 /*line :334:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_149, nil, Lit_150); var tmp20 any; var root_2553 any = A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_2554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2553, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2555 lang.IFn; if



	linked_2554 == nil { ifn_2555 = lang.IFn_Cast(root_2553) } else { ifn_2555 = nil }; var arg_2556 any = n__0; var arg_2557 any = Lit_5; var arg_2558 any = Lit_6; if linked_2554 == nil { tmp20 = ifn_2555.Invoke_O_O_O__O(arg_2556, arg_2557, arg_2558) } else { tmp20 = linked_2554.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2553, arg_2556, arg_2557, arg_2558) }; var tmp21 any = /*line :334:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, g__4, nil, tmp20, nil)).Ref(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyn_A_const_250; var tmp24 any; var root_2559 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2561 lang.IFn; if





	linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any = A_arbace_j2g_dyn_A_const_73; var arg_2563 any = n__0; if linked_2560 == nil { tmp24 = ifn_2561.Invoke_O_O__O(arg_2562, arg_2563) } else { tmp24 = linked_2560.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_2559, arg_2562, arg_2563) }; var tmp25 any = /*line :334:1*/tmp15.Invoke_O_O_O_O__O(tmp16, tmp18, tmp21, tmp22.Invoke_O_O_O__O(tmp23, tmp24, A_arbace_j2g_dyn_A_const_251)); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_252; var tmp28 any; var root_2564 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2564, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2566 lang.IFn; if






	linked_2565 == nil { ifn_2566 = lang.IFn_Cast(root_2564) } else { ifn_2566 = nil }; var arg_2567 any = slots__10; var arg_2568 any = A_arbace_j2g_dyn_A_const_253; if linked_2565 == nil { tmp28 = ifn_2566.Invoke_O_O__O(arg_2567, arg_2568) } else { tmp28 = linked_2565.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2564, arg_2567, arg_2568) }; var tmp29 any = tmp28; var tmp30 any; var root_2569 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2569, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2571 lang.IFn; if







	linked_2570 == nil { ifn_2571 = lang.IFn_Cast(root_2569) } else { ifn_2571 = nil }; var arg_2572 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2573 any = A_arbace_j2g_dyn_A_const_254; var arg_2574 any = A_arbace_j2g_dyn_A_const_255; var arg_2575 any; var root_2576 any = A_arbace_j2g_dyn_A_const_229.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any; var fnbody__2582 any = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New(); var tmp31 *jrt.Class; var fncls__2581 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class; if fncls__2581 == nil { var fncls__2581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, nil); A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class = fncls__2581d; tmp31 = fncls__2581d } else { tmp31 = fncls__2581 }; arg_2579 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2582, tmp31, nil); var arg_2580 any = ks__8; if linked_2577 == nil { arg_2575 = ifn_2578.Invoke_O_O__O(arg_2579, arg_2580) } else { arg_2575 = linked_2577.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2576, arg_2579, arg_2580) }; if linked_2570 == nil { tmp30 = ifn_2571.Invoke_O_O_O_O__O(arg_2572, arg_2573, arg_2574, arg_2575) } else { tmp30 = linked_2570.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2569, arg_2572, arg_2573, arg_2574, arg_2575) }; var tmp32 any = /*line :334:1*/tmp26.Invoke_O_O_O__O(tmp27, tmp29, tmp30); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp34 any = A_arbace_j2g_dyn_A_const_256; var tmp35 any; var root_2583 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2583, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2585 lang.IFn; if








	linked_2584 == nil { ifn_2585 = lang.IFn_Cast(root_2583) } else { ifn_2585 = nil }; var arg_2586 any; var root_2588 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2588, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2590 lang.IFn; if linked_2589 == nil { ifn_2590 = lang.IFn_Cast(root_2588) } else { ifn_2590 = nil }; var arg_2591 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_96, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2589 == nil { arg_2586 = ifn_2590.Invoke_O__O(arg_2591) } else { arg_2586 = linked_2589.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2588, arg_2591) }; var arg_2587 any = A_arbace_j2g_dyn_A_const_257; if linked_2584 == nil { tmp35 = ifn_2585.Invoke_O_O__O(arg_2586, arg_2587) } else { tmp35 = linked_2584.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2583, arg_2586, arg_2587) }; var tmp36 any = tmp35; var tmp37 any; var root_2592 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2592, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2594 lang.IFn; if









	linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2596 any = A_arbace_j2g_dyn_A_const_258; var arg_2597 any = A_arbace_j2g_dyn_A_const_259; var arg_2598 any; var iter__1927001039__auto____11 any; var fnbody__2660 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New(); var tmp38 *jrt.Class; var fncls__2659 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class; if fncls__2659 == nil { var fncls__2659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, nil); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class = fncls__2659d; tmp38 = fncls__2659d } else { tmp38 = fncls__2659 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2660, tmp38, nil); var tmp39 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11); var tmp40 any; var root_2661 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_2662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2661, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2663 lang.IFn; if linked_2662 == nil { ifn_2663 = lang.IFn_Cast(root_2661) } else { ifn_2663 = nil }; var arg_2664 any; var root_2665 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any = own__6; if linked_2666 == nil { arg_2664 = ifn_2667.Invoke_O__O(arg_2668) } else { arg_2664 = linked_2666.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2665, arg_2668) }; if linked_2662 == nil { tmp40 = ifn_2663.Invoke_O__O(arg_2664) } else { tmp40 = linked_2662.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2661, arg_2664) }; arg_2598 = tmp39.Invoke_O__O(tmp40); if linked_2593 == nil { tmp37 = ifn_2594.Invoke_O_O_O_O__O(arg_2595, arg_2596, arg_2597, arg_2598) } else { tmp37 = linked_2593.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2592, arg_2595, arg_2596, arg_2597, arg_2598) }; var tmp41 any = /*line :334:1*/tmp33.Invoke_O_O_O__O(tmp34, tmp36, tmp37); var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp43 any = A_arbace_j2g_dyn_A_const_260; var tmp44 any = A_arbace_j2g_dyn_A_const_261; var tmp45 any; var root_2669 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2669, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2671 lang.IFn; if










	linked_2670 == nil { ifn_2671 = lang.IFn_Cast(root_2669) } else { ifn_2671 = nil }; var arg_2672 any; var tmp46 any; var root_2674 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2674, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2676 lang.IFn; if linked_2675 == nil { ifn_2676 = lang.IFn_Cast(root_2674) } else { ifn_2676 = nil }; var arg_2677 any = A_arbace_j2g_dyn_A_const_262; var arg_2678 any = recv__5; if linked_2675 == nil { tmp46 = ifn_2676.Invoke_O_O__O(arg_2677, arg_2678) } else { tmp46 = linked_2675.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2674, arg_2677, arg_2678) }; arg_2672 = lang.Tuple_Create_O__IPersistentVector(tmp46); var arg_2673 any = A_arbace_j2g_dyn_A_const_263; if linked_2670 == nil { tmp45 = ifn_2671.Invoke_O_O__O(arg_2672, arg_2673) } else { tmp45 = linked_2670.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2669, arg_2672, arg_2673) }; var tmp47 any = /*line :334:1*/tmp42.Invoke_O_O_O_O_O__O(tmp43, tmp44, tmp45, A_arbace_j2g_dyn_A_const_264, A_arbace_j2g_dyn_A_const_265); var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp49 any = A_arbace_j2g_dyn_A_const_266; var tmp50 any = A_arbace_j2g_dyn_A_const_267; var tmp51 any; var root_2679 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2679, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2681 lang.IFn; if











	linked_2680 == nil { ifn_2681 = lang.IFn_Cast(root_2679) } else { ifn_2681 = nil }; var arg_2682 any; var tmp52 any; var root_2684 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2686 lang.IFn; if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = A_arbace_j2g_dyn_A_const_268; var arg_2688 any = recv__5; if linked_2685 == nil { tmp52 = ifn_2686.Invoke_O_O__O(arg_2687, arg_2688) } else { tmp52 = linked_2685.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2684, arg_2687, arg_2688) }; arg_2682 = lang.Tuple_Create_O__IPersistentVector(tmp52); var arg_2683 any = A_arbace_j2g_dyn_A_const_269; if linked_2680 == nil { tmp51 = ifn_2681.Invoke_O_O__O(arg_2682, arg_2683) } else { tmp51 = linked_2680.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2679, arg_2682, arg_2683) }; var tmp53 any = /*line :334:1*/tmp48.Invoke_O_O_O_O__O(tmp49, tmp50, tmp51, A_arbace_j2g_dyn_A_const_270); var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp55 any = A_arbace_j2g_dyn_A_const_271; var tmp56 any = A_arbace_j2g_dyn_A_const_272; var tmp57 any; var root_2689 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2689, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2691 lang.IFn; if












	linked_2690 == nil { ifn_2691 = lang.IFn_Cast(root_2689) } else { ifn_2691 = nil }; var arg_2692 any; var tmp58 any; var root_2694 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2694, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2696 lang.IFn; if linked_2695 == nil { ifn_2696 = lang.IFn_Cast(root_2694) } else { ifn_2696 = nil }; var arg_2697 any = A_arbace_j2g_dyn_A_const_273; var arg_2698 any = recv__5; if linked_2695 == nil { tmp58 = ifn_2696.Invoke_O_O__O(arg_2697, arg_2698) } else { tmp58 = linked_2695.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2694, arg_2697, arg_2698) }; arg_2692 = lang.Tuple_Create_O__IPersistentVector(tmp58); var arg_2693 any = A_arbace_j2g_dyn_A_const_274; if linked_2690 == nil { tmp57 = ifn_2691.Invoke_O_O__O(arg_2692, arg_2693) } else { tmp57 = linked_2690.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2689, arg_2692, arg_2693) }; var tmp59 any = /*line :334:1*/tmp54.Invoke_O_O_O_O__O(tmp55, tmp56, tmp57, A_arbace_j2g_dyn_A_const_275); var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp61 any = A_arbace_j2g_dyn_A_const_276; var tmp62 any = A_arbace_j2g_dyn_A_const_277; var tmp63 any; var root_2699 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2699, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2701 lang.IFn; if













	linked_2700 == nil { ifn_2701 = lang.IFn_Cast(root_2699) } else { ifn_2701 = nil }; var arg_2702 any; var tmp64 any; var root_2704 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2704, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2706 lang.IFn; if linked_2705 == nil { ifn_2706 = lang.IFn_Cast(root_2704) } else { ifn_2706 = nil }; var arg_2707 any = A_arbace_j2g_dyn_A_const_278; var arg_2708 any = recv__5; if linked_2705 == nil { tmp64 = ifn_2706.Invoke_O_O__O(arg_2707, arg_2708) } else { tmp64 = linked_2705.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2704, arg_2707, arg_2708) }; arg_2702 = lang.Tuple_Create_O__IPersistentVector(tmp64); var arg_2703 any = A_arbace_j2g_dyn_A_const_279; if linked_2700 == nil { tmp63 = ifn_2701.Invoke_O_O__O(arg_2702, arg_2703) } else { tmp63 = linked_2700.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2699, arg_2702, arg_2703) }; var tmp65 any = /*line :334:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp25, tmp32, tmp41, tmp47, tmp53, tmp59, tmp60.Invoke_O_O_O_O__O(tmp61, tmp62, tmp63, A_arbace_j2g_dyn_A_const_280))); var tmp66 any; var iter__1927001039__auto____11_2 any; var fnbody__2800 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(recv__5, n__0); var tmp67 *jrt.Class; var fncls__2799 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class; if














	fncls__2799 == nil { var fncls__2799d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, fnbody__2800); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class = fncls__2799d; tmp67 = fncls__2799d } else { tmp67 = fncls__2799 }; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2800, tmp67, nil); var tmp68 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11_2); var tmp69 any; var root_2801 any = A_arbace_j2g_dyn_A_const_135.GetRawRoot__O(); var linked_2802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2801, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2803 lang.IFn; if linked_2802 == nil { ifn_2803 = lang.IFn_Cast(root_2801) } else { ifn_2803 = nil }; var arg_2804 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O())).Ref(); if linked_2802 == nil { tmp69 = ifn_2803.Invoke_O__O(arg_2804) } else { tmp69 = linked_2802.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2801, arg_2804) }; tmp66 = tmp68.Invoke_O__O(tmp69); var tmp70 any = tmp66; var tmp71 any; var iter__1927001039__auto____11_3 any; var fnbody__2896 any = /*line :334:1*/A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(recv__5, clash__9); var tmp72 *jrt.Class; var fncls__2895 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class; if

















	fncls__2895 == nil { var fncls__2895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, fnbody__2896); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class = fncls__2895d; tmp72 = fncls__2895d } else { tmp72 = fncls__2895 }; iter__1927001039__auto____11_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2896, tmp72, nil); tmp71 = lang.IFn_Cast(iter__1927001039__auto____11_3).Invoke_O__O(ifaces__1); var tmp73 any = tmp71; var tmp74 any; var root_2897 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_284.GetRawRoot__O(); var linked_2898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2897, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_2899 lang.IFn; if



















	linked_2898 == nil { ifn_2899 = lang.IFn_Cast(root_2897) } else { ifn_2899 = nil }; var arg_2900 any; var fnbody__2958 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(own__6, recv__5, clash__9, ifaces__1, n__0); var tmp75 *jrt.Class; var fncls__2957 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class; if fncls__2957 == nil { var fncls__2957d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_155, false, fnbody__2958); A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class = fncls__2957d; tmp75 = fncls__2957d } else { tmp75 = fncls__2957 }; arg_2900 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2958, tmp75, nil); var arg_2901 any = ks__8; if linked_2898 == nil { tmp74 = ifn_2899.Invoke_O_O__O(arg_2900, arg_2901) } else { tmp74 = linked_2898.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_2897, arg_2900, arg_2901) }; var tmp76 any = tmp74; var tmp77 any; var root_2959 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_286.GetRawRoot__O(); var linked_2960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2959, A_arbace_j2g_dyn_ctor_infos_A_fn_class); var ifn_2961 lang.IFn; if


























	linked_2960 == nil { ifn_2961 = lang.IFn_Cast(root_2959) } else { ifn_2961 = nil }; var arg_2962 any = n__0; if linked_2960 == nil { tmp77 = ifn_2961.Invoke_O__O(arg_2962) } else { tmp77 = linked_2960.(*A_arbace_j2g_dyn_ctor_infos_A).Invoke_O_O__O(root_2959, arg_2962) }; return /*line :334:1*/ tmp7.Invoke_O_O_O_O_O__O(tmp65, tmp70, tmp73, tmp76, lang.Tuple_Create_O__IPersistentVector(tmp77)) }
//line :329:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Ctor() {}
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Invoke_O_O__O(self, s__711000308__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2490 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(self, s__711000308__1); var tmp2 *jrt.Class; var fncls__2489 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class; if fncls__2489 == nil { var fncls__2489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, fnbody__2490); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class = fncls__2489d; tmp2 = fncls__2489d } else { tmp2 = fncls__2489 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2490, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :329:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A{}; t.Ctor_O_O(p0, p1); return t }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Ctor_O_O(c__iter__711000307, c__s__711000308 any) { t.F_iter__711000307 = c__iter__711000307; t.F_s__711000308 = c__s__711000308 }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Invoke_O__O(self any) any { { var s__711000308__1 any; var t_ any = t.F_s__711000308; t.F_s__711000308 = nil; s__711000308__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2419 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = s__711000308__1; if linked_2420 == nil { temp__1927000414__auto____2 = ifn_2421.Invoke_O__O(arg_2422) } else { temp__1927000414__auto____2 = linked_2420.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2419, arg_2422) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000308__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2423 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2423, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2425 lang.IFn; if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 any = s__711000308__3; if linked_2424 == nil { tmp1 = ifn_2425.Invoke_O__O(arg_2426) } else { tmp1 = linked_2424.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2423, arg_2426) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2427 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2429 lang.IFn; if linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = s__711000308__3; if linked_2428 == nil { c__1927001037__auto____4 = ifn_2429.Invoke_O__O(arg_2430) } else { c__1927001037__auto____4 = linked_2428.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2427, arg_2430) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000310__6 any; var root_2431 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2431, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2433 lang.IFn; if linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2432 == nil { b__711000310__6 = ifn_2433.Invoke_O__O(arg_2434) } else { b__711000310__6 = linked_2432.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2431, arg_2434) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2445 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(b__711000310__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2444 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class; if fncls__2444 == nil { var fncls__2444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, fnbody__2445); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class = fncls__2444d; tmp3 = fncls__2444d } else { tmp3 = fncls__2444 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2445, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2446 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2448 lang.IFn; if linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any; var root_2451 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = b__711000310__6; if linked_2452 == nil { arg_2449 = ifn_2453.Invoke_O__O(arg_2454) } else { arg_2449 = linked_2452.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2451, arg_2454) }; var arg_2450 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp5 any; var root_2455 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2455, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2457 lang.IFn; if linked_2456 == nil { ifn_2457 = lang.IFn_Cast(root_2455) } else { ifn_2457 = nil }; var arg_2458 any = s__711000308__3; if linked_2456 == nil { tmp5 = ifn_2457.Invoke_O__O(arg_2458) } else { tmp5 = linked_2456.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2455, arg_2458) }; arg_2450 = tmp4.Invoke_O__O(tmp5); if linked_2447 == nil { return ifn_2448.Invoke_O_O__O(arg_2449, arg_2450) } else { return linked_2447.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2446, arg_2449, arg_2450) } } else { var root_2459 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2459, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2461 lang.IFn; if linked_2460 == nil { ifn_2461 = lang.IFn_Cast(root_2459) } else { ifn_2461 = nil }; var arg_2462 any; var root_2464 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2464, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2466 lang.IFn; if linked_2465 == nil { ifn_2466 = lang.IFn_Cast(root_2464) } else { ifn_2466 = nil }; var arg_2467 any = b__711000310__6; if linked_2465 == nil { arg_2462 = ifn_2466.Invoke_O__O(arg_2467) } else { arg_2462 = linked_2465.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2464, arg_2467) }; var arg_2463 any; if linked_2460 == nil { return ifn_2461.Invoke_O_O__O(arg_2462, arg_2463) } else { return linked_2460.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2459, arg_2462, arg_2463) } } } else { var vec__711000318__4 any; var root_2468 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2470 lang.IFn; if linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = s__711000308__3; if linked_2469 == nil { vec__711000318__4 = ifn_2470.Invoke_O__O(arg_2471) } else { vec__711000318__4 = linked_2469.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2468, arg_2471) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_2472 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__5); if linked_2473 == nil { tmp6 = ifn_2474.Invoke_O__O(arg_2475) } else { tmp6 = linked_2473.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2472, arg_2475) }; if jrt.J2g_Truth(tmp6) { var root_2476 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; var arg_2479 any = lang.Tuple_Create_O_O__IPersistentVector(k__5, mm__6); var arg_2480 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp8 any; var root_2481 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2481, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2483 lang.IFn; if linked_2482 == nil { ifn_2483 = lang.IFn_Cast(root_2481) } else { ifn_2483 = nil }; var arg_2484 any = s__711000308__3; if linked_2482 == nil { tmp8 = ifn_2483.Invoke_O__O(arg_2484) } else { tmp8 = linked_2482.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2481, arg_2484) }; arg_2480 = tmp7.Invoke_O__O(tmp8); if linked_2477 == nil { return ifn_2478.Invoke_O_O__O(arg_2479, arg_2480) } else { return linked_2477.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2476, arg_2479, arg_2480) } } else { var tmp9 any; var root_2485 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any = s__711000308__3; if linked_2486 == nil { tmp9 = ifn_2487.Invoke_O__O(arg_2488) } else { tmp9 = linked_2486.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2485, arg_2488) }; s__711000308__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :329:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Ctor_O_I_O(c__b__711000310 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000310 = c__b__711000310; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Invoke_O__O(self any) any { { var i__711000309__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000309__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000314__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000309__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_2435 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__3); if linked_2436 == nil { tmp2 = ifn_2437.Invoke_O__O(arg_2438) } else { tmp2 = linked_2436.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2435, arg_2438) }; if jrt.J2g_Truth(tmp2) { var root_2439 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2441 lang.IFn; if linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = t.F_b__711000310; var arg_2443 any = lang.Tuple_Create_O_O__IPersistentVector(k__3, mm__4); if linked_2440 == nil { ifn_2441.Invoke_O_O__O(arg_2442, arg_2443) } else { linked_2440.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2439, arg_2442, arg_2443) }; i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } else { i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New() *A_arbace_j2g_dyn_sub_forms_fn__711000324_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000324_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Ctor() {}
//line :342:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Invoke_O_O_O__O(self, i__1, p__711000323__2 any) any { var vec__711000325__3 any = p__711000323__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }

func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A{}; t.Ctor(); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Ctor() {}
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Invoke_O_O__O(self, s__711000330__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2658 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(s__711000330__1, self); var tmp2 *jrt.Class; var fncls__2657 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class; if fncls__2657 == nil { var fncls__2657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, fnbody__2658); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class = fncls__2657d; tmp2 = fncls__2657d } else { tmp2 = fncls__2657 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2658, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :344:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Ctor_O_O(c__s__711000330, c__iter__711000329 any) { t.F_s__711000330 = c__s__711000330; t.F_iter__711000329 = c__iter__711000329 }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Invoke_O__O(self any) any { { var s__711000330__1 any; var t_ any = t.F_s__711000330; t.F_s__711000330 = nil; s__711000330__1 = t_; for { var temp__1927000414__auto____2 any; var root_2599 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2599, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2601 lang.IFn; if linked_2600 == nil { ifn_2601 = lang.IFn_Cast(root_2599) } else { ifn_2601 = nil }; var arg_2602 any = s__711000330__1; if linked_2600 == nil { temp__1927000414__auto____2 = ifn_2601.Invoke_O__O(arg_2602) } else { temp__1927000414__auto____2 = linked_2600.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2599, arg_2602) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000330__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2603 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2603, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2605 lang.IFn; if linked_2604 == nil { ifn_2605 = lang.IFn_Cast(root_2603) } else { ifn_2605 = nil }; var arg_2606 any = s__711000330__3; if linked_2604 == nil { tmp1 = ifn_2605.Invoke_O__O(arg_2606) } else { tmp1 = linked_2604.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2603, arg_2606) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2607 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2607, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2609 lang.IFn; if linked_2608 == nil { ifn_2609 = lang.IFn_Cast(root_2607) } else { ifn_2609 = nil }; var arg_2610 any = s__711000330__3; if linked_2608 == nil { c__1927001037__auto____4 = ifn_2609.Invoke_O__O(arg_2610) } else { c__1927001037__auto____4 = linked_2608.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2607, arg_2610) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000332__6 any; var root_2611 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2611, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2613 lang.IFn; if linked_2612 == nil { ifn_2613 = lang.IFn_Cast(root_2611) } else { ifn_2613 = nil }; var arg_2614 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2612 == nil { b__711000332__6 = ifn_2613.Invoke_O__O(arg_2614) } else { b__711000332__6 = linked_2612.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2611, arg_2614) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2621 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(b__711000332__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2620 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class; if fncls__2620 == nil { var fncls__2620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, fnbody__2621); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class = fncls__2620d; tmp3 = fncls__2620d } else { tmp3 = fncls__2620 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2621, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2622 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any; var root_2627 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2627, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2629 lang.IFn; if linked_2628 == nil { ifn_2629 = lang.IFn_Cast(root_2627) } else { ifn_2629 = nil }; var arg_2630 any = b__711000332__6; if linked_2628 == nil { arg_2625 = ifn_2629.Invoke_O__O(arg_2630) } else { arg_2625 = linked_2628.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2627, arg_2630) }; var arg_2626 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp5 any; var root_2631 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2631, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2633 lang.IFn; if linked_2632 == nil { ifn_2633 = lang.IFn_Cast(root_2631) } else { ifn_2633 = nil }; var arg_2634 any = s__711000330__3; if linked_2632 == nil { tmp5 = ifn_2633.Invoke_O__O(arg_2634) } else { tmp5 = linked_2632.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2631, arg_2634) }; arg_2626 = tmp4.Invoke_O__O(tmp5); if linked_2623 == nil { return ifn_2624.Invoke_O_O__O(arg_2625, arg_2626) } else { return linked_2623.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2622, arg_2625, arg_2626) } } else { var root_2635 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2635, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2637 lang.IFn; if linked_2636 == nil { ifn_2637 = lang.IFn_Cast(root_2635) } else { ifn_2637 = nil }; var arg_2638 any; var root_2640 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2640, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2642 lang.IFn; if linked_2641 == nil { ifn_2642 = lang.IFn_Cast(root_2640) } else { ifn_2642 = nil }; var arg_2643 any = b__711000332__6; if linked_2641 == nil { arg_2638 = ifn_2642.Invoke_O__O(arg_2643) } else { arg_2638 = linked_2641.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2640, arg_2643) }; var arg_2639 any; if linked_2636 == nil { return ifn_2637.Invoke_O_O__O(arg_2638, arg_2639) } else { return linked_2636.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2635, arg_2638, arg_2639) } } } else { var vec__711000340__4 any; var root_2644 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2646 lang.IFn; if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any = s__711000330__3; if linked_2645 == nil { vec__711000340__4 = ifn_2646.Invoke_O__O(arg_2647) } else { vec__711000340__4 = linked_2645.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2644, arg_2647) }; var nme__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2648 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2648, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var arg_2651 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__5, desc__6)).Ref(), nme__5); var arg_2652 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp7 any; var root_2653 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = s__711000330__3; if linked_2654 == nil { tmp7 = ifn_2655.Invoke_O__O(arg_2656) } else { tmp7 = linked_2654.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2653, arg_2656) }; arg_2652 = tmp6.Invoke_O__O(tmp7); if linked_2649 == nil { return ifn_2650.Invoke_O_O__O(arg_2651, arg_2652) } else { return linked_2649.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2648, arg_2651, arg_2652) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :344:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Ctor_O_I_O(c__b__711000332 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000332 = c__b__711000332; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Invoke_O__O(self any) any { { var i__711000331__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000331__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000336__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000331__1)); var nme__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2615 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2615, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2617 lang.IFn; if linked_2616 == nil { ifn_2617 = lang.IFn_Cast(root_2615) } else { ifn_2617 = nil }; var arg_2618 any = t.F_b__711000332; var arg_2619 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__3, desc__4)).Ref(), nme__3); if linked_2616 == nil { ifn_2617.Invoke_O_O__O(arg_2618, arg_2619) } else { linked_2616.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2615, arg_2618, arg_2619) }; i__711000331__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000331__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A{}; t.Ctor_O_O(p0, p1); return t }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Invoke_O_O__O(self, s__711000346__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2798 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(t.F_recv, self, s__711000346__1, t.F_n); var tmp2 *jrt.Class; var fncls__2797 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class; if fncls__2797 == nil { var fncls__2797d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, fnbody__2798); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class = fncls__2797d; tmp2 = fncls__2797d } else { tmp2 = fncls__2797 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2798, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :349:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Ctor_O_O_O_O(c__recv, c__iter__711000345, c__s__711000346, c__n any) { t.F_recv = c__recv; t.F_iter__711000345 = c__iter__711000345; t.F_s__711000346 = c__s__711000346; t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Invoke_O__O(self any) any { { var s__711000346__1 any; var t_ any = t.F_s__711000346; t.F_s__711000346 = nil; s__711000346__1 = t_; for { var temp__1927000414__auto____2 any; var root_2709 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2709, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2711 lang.IFn; if linked_2710 == nil { ifn_2711 = lang.IFn_Cast(root_2709) } else { ifn_2711 = nil }; var arg_2712 any = s__711000346__1; if linked_2710 == nil { temp__1927000414__auto____2 = ifn_2711.Invoke_O__O(arg_2712) } else { temp__1927000414__auto____2 = linked_2710.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2709, arg_2712) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000346__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2713 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2715 lang.IFn; if linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any = s__711000346__3; if linked_2714 == nil { tmp1 = ifn_2715.Invoke_O__O(arg_2716) } else { tmp1 = linked_2714.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2713, arg_2716) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2717 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2717, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2719 lang.IFn; if linked_2718 == nil { ifn_2719 = lang.IFn_Cast(root_2717) } else { ifn_2719 = nil }; var arg_2720 any = s__711000346__3; if linked_2718 == nil { c__1927001037__auto____4 = ifn_2719.Invoke_O__O(arg_2720) } else { c__1927001037__auto____4 = linked_2718.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2717, arg_2720) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000348__6 any; var root_2721 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2723 lang.IFn; if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2722 == nil { b__711000348__6 = ifn_2723.Invoke_O__O(arg_2724) } else { b__711000348__6 = linked_2722.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2721, arg_2724) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2746 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(t.F_recv, t.F_n, b__711000348__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2745 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class; if fncls__2745 == nil { var fncls__2745d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_163, false, fnbody__2746); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class = fncls__2745d; tmp3 = fncls__2745d } else { tmp3 = fncls__2745 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2746, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2747 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2747, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2749 lang.IFn; if linked_2748 == nil { ifn_2749 = lang.IFn_Cast(root_2747) } else { ifn_2749 = nil }; var arg_2750 any; var root_2752 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any = b__711000348__6; if linked_2753 == nil { arg_2750 = ifn_2754.Invoke_O__O(arg_2755) } else { arg_2750 = linked_2753.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2752, arg_2755) }; var arg_2751 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp5 any; var root_2756 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2756, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2758 lang.IFn; if linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any = s__711000346__3; if linked_2757 == nil { tmp5 = ifn_2758.Invoke_O__O(arg_2759) } else { tmp5 = linked_2757.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2756, arg_2759) }; arg_2751 = tmp4.Invoke_O__O(tmp5); if linked_2748 == nil { return ifn_2749.Invoke_O_O__O(arg_2750, arg_2751) } else { return linked_2748.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2747, arg_2750, arg_2751) } } else { var root_2760 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2762 lang.IFn; if linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any; var root_2765 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2765, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2767 lang.IFn; if linked_2766 == nil { ifn_2767 = lang.IFn_Cast(root_2765) } else { ifn_2767 = nil }; var arg_2768 any = b__711000348__6; if linked_2766 == nil { arg_2763 = ifn_2767.Invoke_O__O(arg_2768) } else { arg_2763 = linked_2766.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2765, arg_2768) }; var arg_2764 any; if linked_2761 == nil { return ifn_2762.Invoke_O_O__O(arg_2763, arg_2764) } else { return linked_2761.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2760, arg_2763, arg_2764) } } } else { var i__4 any; var root_2769 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2769, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2771 lang.IFn; if linked_2770 == nil { ifn_2771 = lang.IFn_Cast(root_2769) } else { ifn_2771 = nil }; var arg_2772 any = s__711000346__3; if linked_2770 == nil { i__4 = ifn_2771.Invoke_O__O(arg_2772) } else { i__4 = linked_2770.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2769, arg_2772) }; var k__5 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__4)); var root_2773 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2773, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2775 lang.IFn; if linked_2774 == nil { ifn_2775 = lang.IFn_Cast(root_2773) } else { ifn_2775 = nil }; var arg_2776 any; var root_2778 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_2779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2778, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2780 lang.IFn

	if linked_2779 == nil { ifn_2780 = lang.IFn_Cast(root_2778) } else { ifn_2780 = nil }; var arg_2781 any = t.F_recv; var arg_2782 any = i__4; var arg_2783 any = k__5; var arg_2784 any; var fnbody__2792 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(k__5, t.F_n); var tmp6 *jrt.Class; var fncls__2791 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class; if fncls__2791 == nil { var fncls__2791d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, fnbody__2792); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class = fncls__2791d; tmp6 = fncls__2791d } else { tmp6 = fncls__2791 }; arg_2784 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2792, tmp6, nil); if linked_2779 == nil { arg_2776 = ifn_2780.Invoke_O_O_O_O__O(arg_2781, arg_2782, arg_2783, arg_2784) } else { arg_2776 = linked_2779.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2778, arg_2781, arg_2782, arg_2783, arg_2784) }
//line :349:1
	var arg_2777 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp8 any; var root_2793 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2793, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2795 lang.IFn; if linked_2794 == nil { ifn_2795 = lang.IFn_Cast(root_2793) } else { ifn_2795 = nil }; var arg_2796 any = s__711000346__3; if linked_2794 == nil { tmp8 = ifn_2795.Invoke_O__O(arg_2796) } else { tmp8 = linked_2794.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2793, arg_2796) }; arg_2777 = tmp7.Invoke_O__O(tmp8); if linked_2774 == nil { return ifn_2775.Invoke_O_O__O(arg_2776, arg_2777) } else { return linked_2774.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2773, arg_2776, arg_2777) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :349:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Ctor_O_O_O_I_O(c__recv, c__n, c__b__711000348 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_n = c__n; t.F_b__711000348 = c__b__711000348; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Invoke_O__O(self any) any { { var i__711000347__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000347__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000347__1)); var k__3 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__2)); var root_2725 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2725, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2727 lang.IFn; if linked_2726 == nil { ifn_2727 = lang.IFn_Cast(root_2725) } else { ifn_2727 = nil }; var arg_2728 any = t.F_b__711000348; var arg_2729 any; var root_2730 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_2731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2730, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2732 lang.IFn

	if linked_2731 == nil { ifn_2732 = lang.IFn_Cast(root_2730) } else { ifn_2732 = nil }; var arg_2733 any = t.F_recv; var arg_2734 any = i__2; var arg_2735 any = k__3; var arg_2736 any; var fnbody__2744 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(k__3, t.F_n); var tmp2 *jrt.Class; var fncls__2743 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class; if fncls__2743 == nil { var fncls__2743d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, fnbody__2744); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class = fncls__2743d; tmp2 = fncls__2743d } else { tmp2 = fncls__2743 }; arg_2736 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2744, tmp2, nil); if linked_2731 == nil { arg_2729 = ifn_2732.Invoke_O_O_O_O__O(arg_2733, arg_2734, arg_2735, arg_2736) } else { arg_2729 = linked_2731.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2730, arg_2733, arg_2734, arg_2735, arg_2736) }
//line :349:1
	if linked_2726 == nil { ifn_2727.Invoke_O_O__O(arg_2728, arg_2729) } else { linked_2726.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2725, arg_2728, arg_2729) }; i__711000347__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000347__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2737 any = A_arbace_j2g_dyn_A_const_281.GetRawRoot__O(); var linked_2738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2737, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2739 lang.IFn; if linked_2738 == nil { ifn_2739 = lang.IFn_Cast(root_2737) } else { ifn_2739 = nil }; var arg_2740 any = t.F_n; var arg_2741 any = t.F_k; var arg_2742 any = pn__1; if linked_2738 == nil { return ifn_2739.Invoke_O_O_O__O(arg_2740, arg_2741, arg_2742) } else { return linked_2738.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2737, arg_2740, arg_2741, arg_2742) } }
//line :351:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2785 any = A_arbace_j2g_dyn_A_const_281.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2785, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2787 lang.IFn; if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any = t.F_n; var arg_2789 any = t.F_k; var arg_2790 any = pn__1; if linked_2786 == nil { return ifn_2787.Invoke_O_O_O__O(arg_2788, arg_2789, arg_2790) } else { return linked_2786.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2785, arg_2788, arg_2789, arg_2790) } }
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Ctor_O_O(c__recv, c__clash any) { t.F_recv = c__recv; t.F_clash = c__clash }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Invoke_O_O__O(self, s__711000360__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2894 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(s__711000360__1, t.F_recv, t.F_clash, self); var tmp2 *jrt.Class; var fncls__2893 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class; if fncls__2893 == nil { var fncls__2893d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_166, false, fnbody__2894); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class = fncls__2893d; tmp2 = fncls__2893d } else { tmp2 = fncls__2893 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2894, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :352:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Ctor_O_O_O_O(c__s__711000360, c__recv, c__clash, c__iter__711000359 any) { t.F_s__711000360 = c__s__711000360; t.F_recv = c__recv; t.F_clash = c__clash; t.F_iter__711000359 = c__iter__711000359 }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Invoke_O__O(self any) any { { var s__711000360__1 any; var t_ any = t.F_s__711000360; t.F_s__711000360 = nil; s__711000360__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2805 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2805, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2807 lang.IFn; if linked_2806 == nil { ifn_2807 = lang.IFn_Cast(root_2805) } else { ifn_2807 = nil }; var arg_2808 any = s__711000360__1; if linked_2806 == nil { temp__1927000414__auto____2 = ifn_2807.Invoke_O__O(arg_2808) } else { temp__1927000414__auto____2 = linked_2806.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2805, arg_2808) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000360__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2809 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2809, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2811 lang.IFn; if linked_2810 == nil { ifn_2811 = lang.IFn_Cast(root_2809) } else { ifn_2811 = nil }; var arg_2812 any = s__711000360__3; if linked_2810 == nil { tmp1 = ifn_2811.Invoke_O__O(arg_2812) } else { tmp1 = linked_2810.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2809, arg_2812) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2813 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2813, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2815 lang.IFn; if linked_2814 == nil { ifn_2815 = lang.IFn_Cast(root_2813) } else { ifn_2815 = nil }; var arg_2816 any = s__711000360__3; if linked_2814 == nil { c__1927001037__auto____4 = ifn_2815.Invoke_O__O(arg_2816) } else { c__1927001037__auto____4 = linked_2814.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2813, arg_2816) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000362__6 any; var root_2817 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2817, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2819 lang.IFn; if linked_2818 == nil { ifn_2819 = lang.IFn_Cast(root_2817) } else { ifn_2819 = nil }; var arg_2820 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2818 == nil { b__711000362__6 = ifn_2819.Invoke_O__O(arg_2820) } else { b__711000362__6 = linked_2818.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2817, arg_2820) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2840 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(t.F_recv, t.F_clash, b__711000362__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2839 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class; if fncls__2839 == nil { var fncls__2839d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_167, false, fnbody__2840); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class = fncls__2839d; tmp3 = fncls__2839d } else { tmp3 = fncls__2839 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2840, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2841 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2841, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2843 lang.IFn; if linked_2842 == nil { ifn_2843 = lang.IFn_Cast(root_2841) } else { ifn_2843 = nil }; var arg_2844 any; var root_2846 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2846, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2848 lang.IFn; if linked_2847 == nil { ifn_2848 = lang.IFn_Cast(root_2846) } else { ifn_2848 = nil }; var arg_2849 any = b__711000362__6; if linked_2847 == nil { arg_2844 = ifn_2848.Invoke_O__O(arg_2849) } else { arg_2844 = linked_2847.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2846, arg_2849) }; var arg_2845 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp5 any; var root_2850 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2850, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2852 lang.IFn; if linked_2851 == nil { ifn_2852 = lang.IFn_Cast(root_2850) } else { ifn_2852 = nil }; var arg_2853 any = s__711000360__3; if linked_2851 == nil { tmp5 = ifn_2852.Invoke_O__O(arg_2853) } else { tmp5 = linked_2851.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2850, arg_2853) }; arg_2845 = tmp4.Invoke_O__O(tmp5); if linked_2842 == nil { return ifn_2843.Invoke_O_O__O(arg_2844, arg_2845) } else { return linked_2842.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2841, arg_2844, arg_2845) } } else { var root_2854 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2854, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2856 lang.IFn; if linked_2855 == nil { ifn_2856 = lang.IFn_Cast(root_2854) } else { ifn_2856 = nil }; var arg_2857 any; var root_2859 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2859, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2861 lang.IFn; if linked_2860 == nil { ifn_2861 = lang.IFn_Cast(root_2859) } else { ifn_2861 = nil }; var arg_2862 any = b__711000362__6; if linked_2860 == nil { arg_2857 = ifn_2861.Invoke_O__O(arg_2862) } else { arg_2857 = linked_2860.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2859, arg_2862) }; var arg_2858 any; if linked_2855 == nil { return ifn_2856.Invoke_O_O__O(arg_2857, arg_2858) } else { return linked_2855.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2854, arg_2857, arg_2858) } } } else { var j__4 any; var root_2863 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2863, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2865 lang.IFn; if linked_2864 == nil { ifn_2865 = lang.IFn_Cast(root_2863) } else { ifn_2865 = nil }; var arg_2866 any = s__711000360__3; if linked_2864 == nil { j__4 = ifn_2865.Invoke_O__O(arg_2866) } else { j__4 = linked_2864.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2863, arg_2866) }; var mk__5 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_92, nil); var tmp7 any; var root_2867 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2867, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2869 lang.IFn; if linked_2868 == nil { ifn_2869 = lang.IFn_Cast(root_2867) } else { ifn_2869 = nil }; var arg_2870 any = j__4; if linked_2868 == nil { tmp7 = ifn_2869.Invoke_O__O(arg_2870) } else { tmp7 = linked_2868.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2867, arg_2870) }; mk__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__5)) { var root_2871 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2871, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2873 lang.IFn; if linked_2872 == nil { ifn_2873 = lang.IFn_Cast(root_2871) } else { ifn_2873 = nil }; var arg_2874 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_282; var tmp10 any; var root_2876 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2878 lang.IFn
														if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any = mk__5; if linked_2877 == nil { tmp10 = ifn_2878.Invoke_O__O(arg_2879) } else { tmp10 = linked_2877.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2876, arg_2879) }; var tmp11 any = tmp10; var tmp12 any; var root_2880 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2880, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2882 lang.IFn; if linked_2881 == nil { ifn_2882 = lang.IFn_Cast(root_2880) } else { ifn_2882 = nil }; var arg_2883 any = A_arbace_j2g_dyn_A_const_283; var arg_2884 any = t.F_recv; if linked_2881 == nil { tmp12 = ifn_2882.Invoke_O_O__O(arg_2883, arg_2884) } else { tmp12 = linked_2881.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2880, arg_2883, arg_2884) }; arg_2874 = tmp8.Invoke_O_O_O__O(tmp9, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12))
//line :352:1
	var arg_2875 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp14 any; var root_2885 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any = s__711000360__3; if linked_2886 == nil { tmp14 = ifn_2887.Invoke_O__O(arg_2888) } else { tmp14 = linked_2886.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2885, arg_2888) }; arg_2875 = tmp13.Invoke_O__O(tmp14); if linked_2872 == nil { return ifn_2873.Invoke_O_O__O(arg_2874, arg_2875) } else { return linked_2872.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2871, arg_2874, arg_2875) } } else { var tmp15 any; var root_2889 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2891 lang.IFn; if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any = s__711000360__3; if linked_2890 == nil { tmp15 = ifn_2891.Invoke_O__O(arg_2892) } else { tmp15 = linked_2890.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2889, arg_2892) }; s__711000360__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Ctor_O_O_O_I_O(c__recv, c__clash, c__b__711000362 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_clash = c__clash; t.F_b__711000362 = c__b__711000362; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Invoke_O__O(self any) any { { var i__711000361__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000361__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000361__1)); var mk__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_92, nil); var tmp3 any; var root_2821 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2821, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2823 lang.IFn; if linked_2822 == nil { ifn_2823 = lang.IFn_Cast(root_2821) } else { ifn_2823 = nil }; var arg_2824 any = j__2; if linked_2822 == nil { tmp3 = ifn_2823.Invoke_O__O(arg_2824) } else { tmp3 = linked_2822.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2821, arg_2824) }; mk__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__3)) { var root_2825 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any = t.F_b__711000362; var arg_2829 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_282; var tmp6 any; var root_2830 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2830, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2832 lang.IFn
															if linked_2831 == nil { ifn_2832 = lang.IFn_Cast(root_2830) } else { ifn_2832 = nil }; var arg_2833 any = mk__3; if linked_2831 == nil { tmp6 = ifn_2832.Invoke_O__O(arg_2833) } else { tmp6 = linked_2831.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2830, arg_2833) }; var tmp7 any = tmp6; var tmp8 any; var root_2834 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2834, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2836 lang.IFn; if linked_2835 == nil { ifn_2836 = lang.IFn_Cast(root_2834) } else { ifn_2836 = nil }; var arg_2837 any = A_arbace_j2g_dyn_A_const_283; var arg_2838 any = t.F_recv; if linked_2835 == nil { tmp8 = ifn_2836.Invoke_O_O__O(arg_2837, arg_2838) } else { tmp8 = linked_2835.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2834, arg_2837, arg_2838) }; arg_2829 = tmp4.Invoke_O_O_O__O(tmp5, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8))
//line :352:1
	if linked_2826 == nil { ifn_2827.Invoke_O_O__O(arg_2828, arg_2829) } else { linked_2826.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2825, arg_2828, arg_2829) }; i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } else { i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Ctor_O_O_O_O_O(c__own, c__recv, c__clash, c__ifaces, c__n any) { t.F_own = c__own; t.F_recv = c__recv; t.F_clash = c__clash; t.F_ifaces = c__ifaces; t.F_n = c__n }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Invoke_O_O_O__O(self, i__1, p__711000369__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, p__711000369__2) } else { var vec__711000371__3 any = p__711000369__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000371__3; var tmp1 any; var and__1927000168__auto____7 bool; var na_2902 any = i__1; var na_2903 int64 = int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()))
														if jrt.Long_InstanceOf(na_2902) { var n0_2904 int64 = jrt.NN(jrt.Long_Cast(na_2902)).LongValue__J(); var n1_2905 int64 = na_2903; and__1927000168__auto____7 = n0_2904 >= n1_2905 } else { and__1927000168__auto____7 = lang.Numbers_Gte_O_J__Z_NoInit(na_2902, na_2903) }; if and__1927000168__auto____7 { var or__1927000174__auto____8 any = lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)
															if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_clash); var tmp3 any; var root_2932 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2932, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2934 lang.IFn; if linked_2933 == nil { ifn_2934 = lang.IFn_Cast(root_2932) } else { ifn_2934 = nil }; var arg_2935 any = nme__4; var arg_2936 any = desc__5; if linked_2933 == nil { tmp3 = ifn_2934.Invoke_O_O__O(arg_2935, arg_2936) } else { tmp3 = linked_2933.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2932, arg_2935, arg_2936) }; tmp1 = tmp2.Invoke_O__O(tmp3) } } else {
//line :355:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				var root_2907 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_2908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2907, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2909 lang.IFn; if linked_2908 == nil { ifn_2909 = lang.IFn_Cast(root_2907) } else { ifn_2909 = nil }; var arg_2910 any = t.F_recv; var arg_2911 any = i__1; var arg_2912 any = k__6; var arg_2913 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)) {
					var fnbody__2922 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(k__6, t.F_n); var tmp4 *jrt.Class; var fncls__2921 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class; if fncls__2921 == nil { var fncls__2921d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, fnbody__2922); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class = fncls__2921d; tmp4 = fncls__2921d } else { tmp4 = fncls__2921 }; arg_2913 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2922, tmp4, nil) } else {
						var fnbody__2931 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(k__6, t.F_ifaces); var tmp5 *jrt.Class; var fncls__2930 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class; if fncls__2930 == nil { var fncls__2930d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, fnbody__2931); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class = fncls__2930d; tmp5 = fncls__2930d } else { tmp5 = fncls__2930 }; arg_2913 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2931, tmp5, nil) }
//line :357:1
				if linked_2908 == nil { return ifn_2909.Invoke_O_O_O_O__O(arg_2910, arg_2911, arg_2912, arg_2913) } else { return linked_2908.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2907, arg_2910, arg_2911, arg_2912, arg_2913) } } else {
//line :355:1
					return nil } } }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, p__711000369__2 any) any { var vec__711000371__3 any = p__711000369__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000371__3; var tmp1 any; var and__1927000168__auto____7 bool; var na_2937 int64 = int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O())); var n0_2938 int64 = i__1_l; var n1_2939 int64 = na_2937; and__1927000168__auto____7 =
																	n0_2938 >= n1_2939; if and__1927000168__auto____7 { var or__1927000174__auto____8 any = lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)
																		if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_clash); var tmp3 any; var root_2952 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2952, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2954 lang.IFn; if linked_2953 == nil { ifn_2954 = lang.IFn_Cast(root_2952) } else { ifn_2954 = nil }; var arg_2955 any = nme__4; var arg_2956 any = desc__5; if linked_2953 == nil { tmp3 = ifn_2954.Invoke_O_O__O(arg_2955, arg_2956) } else { tmp3 = linked_2953.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2952, arg_2955, arg_2956) }; tmp1 = tmp2.Invoke_O__O(tmp3) } } else {
//line :355:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				var root_2941 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_2942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2941, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2943 lang.IFn; if linked_2942 == nil { ifn_2943 = lang.IFn_Cast(root_2941) } else { ifn_2943 = nil }; var arg_2944 any = t.F_recv; var arg_2945 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_2945 = i__1_b } else { arg_2945 = i__1_b }; var arg_2946 any = k__6; var arg_2947 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)) {
					var fnbody__2949 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(k__6, t.F_n); var tmp4 *jrt.Class; var fncls__2948 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class; if fncls__2948 == nil { var fncls__2948d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, fnbody__2949); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class = fncls__2948d; tmp4 = fncls__2948d } else { tmp4 = fncls__2948 }; arg_2947 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2949, tmp4, nil) } else {
						var fnbody__2951 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(k__6, t.F_ifaces); var tmp5 *jrt.Class; var fncls__2950 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class; if fncls__2950 == nil { var fncls__2950d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, fnbody__2951); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class = fncls__2950d; tmp5 = fncls__2950d } else { tmp5 = fncls__2950 }; arg_2947 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2951, tmp5, nil) }
//line :357:1
				if linked_2942 == nil { return ifn_2943.Invoke_O_O_O_O__O(arg_2944, arg_2945, arg_2946, arg_2947) } else { return linked_2942.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2941, arg_2944, arg_2945, arg_2946, arg_2947) } } else {
//line :355:1
					return nil } }


func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A{}; t.Ctor_O_O(p0, p1); return t }
//line :358:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :358:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2914 any = A_arbace_j2g_dyn_A_const_285.GetRawRoot__O(); var linked_2915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2914, A_arbace_j2g_dyn_class_fallback_A_fn_class); var ifn_2916 lang.IFn; if linked_2915 == nil { ifn_2916 = lang.IFn_Cast(root_2914) } else { ifn_2916 = nil }; var arg_2917 any = t.F_n; var arg_2918 any = t.F_k; var arg_2919 any = pn__1; var arg_2920 any = r__2; if linked_2915 == nil { return ifn_2916.Invoke_O_O_O_O__O(arg_2917, arg_2918, arg_2919, arg_2920) } else { return linked_2915.(*A_arbace_j2g_dyn_class_fallback_A).Invoke_O_O_O_O_O__O(root_2914, arg_2917, arg_2918, arg_2919, arg_2920) } }
func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2923 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2923, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_2925 lang.IFn; if linked_2924 == nil { ifn_2925 = lang.IFn_Cast(root_2923) } else { ifn_2925 = nil }; var arg_2926 any = t.F_ifaces; var arg_2927 any = t.F_k; var arg_2928 any = pn__1; var arg_2929 any = r__2; if linked_2924 == nil { return ifn_2925.Invoke_O_O_O_O__O(arg_2926, arg_2927, arg_2928, arg_2929) } else { return linked_2924.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O__O(root_2923, arg_2926, arg_2927, arg_2928, arg_2929) } }

















func A_arbace_j2g_dyn_fn_field_native_A_New() *A_arbace_j2g_dyn_fn_field_native_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_fn_field_native_A{}; t.Ctor(); return t }
//line :377:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Ctor() {}
//line :377:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Invoke_O__O(self any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_288; var tmp3 any; var root_2967 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2967, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2969 lang.IFn; if linked_2968 == nil { ifn_2969 = lang.IFn_Cast(root_2967) } else { ifn_2969 = nil }; var arg_2970 any; var root_2971 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_2972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2971, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_2973 lang.IFn; if linked_2972 == nil { ifn_2973 = lang.IFn_Cast(root_2971) } else { ifn_2973 = nil }; var arg_2974 any = Lit_47; var arg_2975 any = Lit_48; if linked_2972 == nil { arg_2970 = ifn_2973.Invoke_O_O__O(arg_2974, arg_2975) } else { arg_2970 = linked_2972.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_2971, arg_2974, arg_2975) }; if linked_2968 == nil { tmp3 = ifn_2969.Invoke_O__O(arg_2970) } else { tmp3 = linked_2968.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2967, arg_2970) }; var tmp4 any = tmp3; var tmp5 any; var root_2976 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2976, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2978 lang.IFn
	if linked_2977 == nil { ifn_2978 = lang.IFn_Cast(root_2976) } else { ifn_2978 = nil }; var arg_2979 any = A_arbace_j2g_dyn_A_const_291; var arg_2980 any = A_arbace_j2g_dyn_A_const_292; if linked_2977 == nil { tmp5 = ifn_2978.Invoke_O_O__O(arg_2979, arg_2980) } else { tmp5 = linked_2977.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2976, arg_2979, arg_2980) }
//line :382:1
	var tmp6 any = tmp5; var tmp7 any; var root_2981 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2981, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2983 lang.IFn
	if linked_2982 == nil { ifn_2983 = lang.IFn_Cast(root_2981) } else { ifn_2983 = nil }; var arg_2984 any = A_arbace_j2g_dyn_A_const_293; var arg_2985 any = A_arbace_j2g_dyn_A_const_294; if linked_2982 == nil { tmp7 = ifn_2983.Invoke_O_O__O(arg_2984, arg_2985) } else { tmp7 = linked_2982.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2981, arg_2984, arg_2985) }
//line :382:1
	var tmp8 any = tmp7; var tmp9 any; var root_2986 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2986, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2988 lang.IFn
	if linked_2987 == nil { ifn_2988 = lang.IFn_Cast(root_2986) } else { ifn_2988 = nil }; var arg_2989 any = A_arbace_j2g_dyn_A_const_295; var arg_2990 any = A_arbace_j2g_dyn_A_const_296; if linked_2987 == nil { tmp9 = ifn_2988.Invoke_O_O__O(arg_2989, arg_2990) } else { tmp9 = linked_2987.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2986, arg_2989, arg_2990) }
//line :382:1
	var tmp10 any = tmp9; var tmp11 any; var root_2991 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_2992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2991, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2993 lang.IFn
	if linked_2992 == nil { ifn_2993 = lang.IFn_Cast(root_2991) } else { ifn_2993 = nil }; var arg_2994 any = A_arbace_j2g_dyn_A_const_297; var arg_2995 any = A_arbace_j2g_dyn_A_const_298; if linked_2992 == nil { tmp11 = ifn_2993.Invoke_O_O__O(arg_2994, arg_2995) } else { tmp11 = linked_2992.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2991, arg_2994, arg_2995) }
//line :382:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp10, tmp11), A_arbace_j2g_dyn_A_const_290)
}








func A_arbace_j2g_dyn_aot_fn_fields_native_A_New() *A_arbace_j2g_dyn_aot_fn_fields_native_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_aot_fn_fields_native_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_j2g_dyn_aot_fn_fields_native_A) Ctor() {}
//line :392:1
func (t *A_arbace_j2g_dyn_aot_fn_fields_native_A) Invoke_O__O(self any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_299; var tmp3 any; var root_2996 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_2997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2996, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2998 lang.IFn; if linked_2997 == nil { ifn_2998 = lang.IFn_Cast(root_2996) } else { ifn_2998 = nil }; var arg_2999 any; var root_3000 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3000, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3002 lang.IFn; if linked_3001 == nil { ifn_3002 = lang.IFn_Cast(root_3000) } else { ifn_3002 = nil }; var arg_3003 any = Lit_9; var arg_3004 any = Lit_10; if linked_3001 == nil { arg_2999 = ifn_3002.Invoke_O_O__O(arg_3003, arg_3004) } else { arg_2999 = linked_3001.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3000, arg_3003, arg_3004) }; if linked_2997 == nil { tmp3 = ifn_2998.Invoke_O__O(arg_2999) } else { tmp3 = linked_2997.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2996, arg_2999) }; var tmp4 any = tmp3; var tmp5 any; var root_3005 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3005, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3007 lang.IFn
	if linked_3006 == nil { ifn_3007 = lang.IFn_Cast(root_3005) } else { ifn_3007 = nil }; var arg_3008 any = A_arbace_j2g_dyn_A_const_301; var arg_3009 any = A_arbace_j2g_dyn_A_const_302; if linked_3006 == nil { tmp5 = ifn_3007.Invoke_O_O__O(arg_3008, arg_3009) } else { tmp5 = linked_3006.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3005, arg_3008, arg_3009) }
//line :396:1
	var tmp6 any = tmp5; var tmp7 any; var root_3010 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3010, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3012 lang.IFn
	if linked_3011 == nil { ifn_3012 = lang.IFn_Cast(root_3010) } else { ifn_3012 = nil }; var arg_3013 any = A_arbace_j2g_dyn_A_const_303; var arg_3014 any = A_arbace_j2g_dyn_A_const_304; if linked_3011 == nil { tmp7 = ifn_3012.Invoke_O_O__O(arg_3013, arg_3014) } else { tmp7 = linked_3011.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3010, arg_3013, arg_3014) }
//line :396:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7), A_arbace_j2g_dyn_A_const_300)
}








func A_arbace_j2g_dyn_forms_A_New() *A_arbace_j2g_dyn_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_A{}; t.Ctor(); return t }
//line :406:1
func (t *A_arbace_j2g_dyn_forms_A) Ctor() {}
//line :406:1
func (t *A_arbace_j2g_dyn_forms_A) Invoke_O_O__O(self, T__0_ any) any { var ifaces__2 any; var root_3015 any = A_arbace_j2g_dyn_A_const_305.GetRawRoot__O(); var linked_3016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3015, A_arbace_j2g_dyn_interfaces_A_fn_class); var ifn_3017 lang.IFn; if


	linked_3016 == nil { ifn_3017 = lang.IFn_Cast(root_3015) } else { ifn_3017 = nil }; var arg_3018 any = T__0_; if linked_3016 == nil { ifaces__2 = ifn_3017.Invoke_O__O(arg_3018) } else { ifaces__2 = linked_3016.(*A_arbace_j2g_dyn_interfaces_A).Invoke_O_O__O(root_3015, arg_3018) }; var ks__3 any; var root_3019 any = /*line :406:1*/A_arbace_j2g_dyn_A_const_306.GetRawRoot__O(); var linked_3020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3019, A_arbace_j2g_dyn_slot_keys_A_fn_class); var ifn_3021 lang.IFn; if



	linked_3020 == nil { ifn_3021 = lang.IFn_Cast(root_3019) } else { ifn_3021 = nil }; var arg_3022 any = ifaces__2; if linked_3020 == nil { ks__3 = ifn_3021.Invoke_O__O(arg_3022) } else { ks__3 = linked_3020.(*A_arbace_j2g_dyn_slot_keys_A).Invoke_O_O__O(root_3019, arg_3022) }; var n__4 int32 = /*line :406:1*/lang.RT_Count_O__I_NoInit(ks__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_42.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_327; var tmp4 any = tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_49, nil, Lit_50, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ifaces__2)).Ref(), nil, jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref(), nil)).Ref()); var tmp5 any = A_arbace_j2g_dyn_A_const_307; var tmp6 any = A_arbace_j2g_dyn_A_const_308; var tmp7 any = A_arbace_j2g_dyn_A_const_309; var tmp8 any = A_arbace_j2g_dyn_A_const_310; var tmp9 any = A_arbace_j2g_dyn_A_const_311; var tmp10 any = A_arbace_j2g_dyn_A_const_312; var tmp11 any = A_arbace_j2g_dyn_A_const_313; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_dyn_A_const_328; var tmp14 any; var root_3031 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3031, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3033 lang.IFn; if



































	linked_3032 == nil { ifn_3033 = lang.IFn_Cast(root_3031) } else { ifn_3033 = nil }; var arg_3034 any = A_arbace_j2g_dyn_A_const_329; var arg_3035 any = A_arbace_j2g_dyn_A_const_330; if linked_3032 == nil { tmp14 = ifn_3033.Invoke_O_O__O(arg_3034, arg_3035) } else { tmp14 = linked_3032.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3031, arg_3034, arg_3035) }; var tmp15 any = tmp14; var tmp16 any; var root_3036 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_3037 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3036, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3038 lang.IFn; if






























	linked_3037 == nil { ifn_3038 = lang.IFn_Cast(root_3036) } else { ifn_3038 = nil }; var arg_3039 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_3040 any = A_arbace_j2g_dyn_A_const_331; var arg_3041 any = A_arbace_j2g_dyn_A_const_332; var arg_3042 any; var root_3043 any = A_arbace_j2g_dyn_A_const_229.GetRawRoot__O(); var linked_3044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3043, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_3045 lang.IFn; if linked_3044 == nil { ifn_3045 = lang.IFn_Cast(root_3043) } else { ifn_3045 = nil }; var arg_3046 any; var fnbody__3049 any = A_arbace_j2g_dyn_forms_fn__711000384_A_New(); var tmp17 *jrt.Class; var fncls__3048 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000384_A_fn_class; if fncls__3048 == nil { var fncls__3048d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, nil); A_arbace_j2g_dyn_forms_fn__711000384_A_fn_class = fncls__3048d; tmp17 = fncls__3048d } else { tmp17 = fncls__3048 }; arg_3046 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3049, tmp17, nil); var arg_3047 any = ks__3; if linked_3044 == nil { arg_3042 = ifn_3045.Invoke_O_O__O(arg_3046, arg_3047) } else { arg_3042 = linked_3044.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_3043, arg_3046, arg_3047) }; if linked_3037 == nil { tmp16 = ifn_3038.Invoke_O_O_O_O__O(arg_3039, arg_3040, arg_3041, arg_3042) } else { tmp16 = linked_3037.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3036, arg_3039, arg_3040, arg_3041, arg_3042) }; var tmp18 any = /*line :412:1*/tmp12.Invoke_O_O_O__O(tmp13, tmp15, tmp16); var tmp19 any = A_arbace_j2g_dyn_A_const_314; var tmp20 any = A_arbace_j2g_dyn_A_const_315; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyn_A_const_333; var tmp23 any = A_arbace_j2g_dyn_A_const_334; var tmp24 any; var root_3050 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3052 lang.IFn; if











































	linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any; var tmp25 any; var root_3055 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3055, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3057 lang.IFn; if linked_3056 == nil { ifn_3057 = lang.IFn_Cast(root_3055) } else { ifn_3057 = nil }; var arg_3058 any = A_arbace_j2g_dyn_A_const_335; var arg_3059 any = A_arbace_j2g_dyn_A_const_336; if linked_3056 == nil { tmp25 = ifn_3057.Invoke_O_O__O(arg_3058, arg_3059) } else { tmp25 = linked_3056.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3055, arg_3058, arg_3059) }; var tmp26 any = tmp25; var tmp27 any; var root_3060 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3060, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3062 lang.IFn; if linked_3061 == nil { ifn_3062 = lang.IFn_Cast(root_3060) } else { ifn_3062 = nil }; var arg_3063 any = A_arbace_j2g_dyn_A_const_337; var arg_3064 any = A_arbace_j2g_dyn_A_const_338; if linked_3061 == nil { tmp27 = ifn_3062.Invoke_O_O__O(arg_3063, arg_3064) } else { tmp27 = linked_3061.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3060, arg_3063, arg_3064) }; arg_3053 = lang.Tuple_Create_O_O__IPersistentVector(tmp26, tmp27); var arg_3054 any = A_arbace_j2g_dyn_A_const_339; if linked_3051 == nil { tmp24 = ifn_3052.Invoke_O_O__O(arg_3053, arg_3054) } else { tmp24 = linked_3051.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3050, arg_3053, arg_3054) }; var tmp28 any = tmp24; var tmp29 any; var root_3065 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_3066 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3065, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3067 lang.IFn; if












































	linked_3066 == nil { ifn_3067 = lang.IFn_Cast(root_3065) } else { ifn_3067 = nil }; var arg_3068 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_3069 any = A_arbace_j2g_dyn_A_const_340; var arg_3070 any = A_arbace_j2g_dyn_A_const_341; var arg_3071 any; var root_3072 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_3073 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3072, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3074 lang.IFn; if
	linked_3073 == nil { ifn_3074 = lang.IFn_Cast(root_3072) } else { ifn_3074 = nil }; var arg_3075 any; var iter__1927001039__auto____5 any; var fnbody__3160 any = A_arbace_j2g_dyn_forms_iter__711000389__711000393_A_New(); var tmp30 *jrt.Class; var fncls__3159 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000389__711000393_A_fn_class; if
	fncls__3159 == nil { var fncls__3159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_j2g_dyn_forms_iter__711000389__711000393_A_fn_class = fncls__3159d; tmp30 = fncls__3159d } else { tmp30 = fncls__3159 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3160, tmp30, nil); var tmp31 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp32 any; var root_3161 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_3162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3161, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3163 lang.IFn; if linked_3162 == nil { ifn_3163 = lang.IFn_Cast(root_3161) } else { ifn_3163 = nil }; var arg_3164 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); if linked_3162 == nil { tmp32 = ifn_3163.Invoke_O__O(arg_3164) } else { tmp32 = linked_3162.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3161, arg_3164) }; arg_3075 = tmp31.Invoke_O__O(tmp32); var arg_3076 any = A_arbace_j2g_dyn_A_const_345; if /*line :458:1*/ linked_3073 == nil { arg_3071 = ifn_3074.Invoke_O_O__O(arg_3075, arg_3076) } else { arg_3071 = linked_3073.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3072, arg_3075, arg_3076) }; if /*line :457:1*/ linked_3066 == nil { tmp29 = ifn_3067.Invoke_O_O_O_O__O(arg_3068, arg_3069, arg_3070, arg_3071) } else { tmp29 = linked_3066.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3065, arg_3068, arg_3069, arg_3070, arg_3071) }; var tmp33 any = /*line :412:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp18, tmp19, tmp20, tmp21.Invoke_O_O_O_O_O_O__O(tmp22, tmp23, Lit_53, tmp28, tmp29, A_arbace_j2g_dyn_A_const_346), A_arbace_j2g_dyn_A_const_316, A_arbace_j2g_dyn_A_const_317, A_arbace_j2g_dyn_A_const_318, A_arbace_j2g_dyn_A_const_319, A_arbace_j2g_dyn_A_const_320, A_arbace_j2g_dyn_A_const_321, A_arbace_j2g_dyn_A_const_322, A_arbace_j2g_dyn_A_const_323, A_arbace_j2g_dyn_A_const_324, A_arbace_j2g_dyn_A_const_325, A_arbace_j2g_dyn_A_const_326)); var tmp34 any; var iter__1927001039__auto____5_2 any; var fnbody__3252 any = A_arbace_j2g_dyn_forms_iter__711000405__711000409_A_New(); var tmp35 *jrt.Class; var fncls__3251 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000405__711000409_A_fn_class; if























































































	fncls__3251 == nil { var fncls__3251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, nil); A_arbace_j2g_dyn_forms_iter__711000405__711000409_A_fn_class = fncls__3251d; tmp35 = fncls__3251d } else { tmp35 = fncls__3251 }; iter__1927001039__auto____5_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3252, tmp35, nil); tmp34 = lang.IFn_Cast(iter__1927001039__auto____5_2).Invoke_O__O(ifaces__2); var tmp36 any = tmp34; var tmp37 any; var nobj__5 int32 = /*line :412:1*/lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_351.GetRawRoot__O()); var tmp39 any; var root_3259 any = A_arbace_j2g_dyn_A_const_352.GetRawRoot__O(); var linked_3260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3259, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_3261 lang.IFn; if


























































































	linked_3260 == nil { ifn_3261 = lang.IFn_Cast(root_3259) } else { ifn_3261 = nil }; if linked_3260 == nil { tmp39 = ifn_3261.Invoke__O() } else { tmp39 = linked_3260.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_3259) }; var tmp40 any = tmp39; var tmp41 *lang.Compiler_AOTFn; var fnbody__3269 any = A_arbace_j2g_dyn_forms_fn__711000415_A_New_O_O(ks__3, ifaces__2); var tmp42 *jrt.Class; var fncls__3268 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000415_A_fn_class; if fncls__3268 == nil { var fncls__3268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__3269); A_arbace_j2g_dyn_forms_fn__711000415_A_fn_class = fncls__3268d; tmp42 = fncls__3268d } else { tmp42 = fncls__3268 }; tmp41 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3269, tmp42, nil); var tmp43 any = tmp41.Ref(); var tmp44 any; var root_3270 any = A_arbace_j2g_dyn_A_const_135.GetRawRoot__O(); var linked_3271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3270, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3272 lang.IFn; if linked_3271 == nil { ifn_3272 = lang.IFn_Cast(root_3270) } else { ifn_3272 = nil }; var arg_3273 any = jrt.Integer_ValueOf_I__Integer_NoInit(nobj__5).Ref(); var arg_3274 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__3)).Ref(); if linked_3271 == nil { tmp44 = ifn_3272.Invoke_O_O__O(arg_3273, arg_3274) } else { tmp44 = linked_3271.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_3270, arg_3273, arg_3274) }; tmp37 = tmp38.Invoke_O_O_O__O(tmp40, tmp43, tmp44); var tmp45 any = tmp37; var tmp46 lang.IFn = /*line :412:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp47 any = A_arbace_j2g_dyn_A_const_363; var tmp48 any; var root_3281 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3281, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3283 lang.IFn; if




























































































	linked_3282 == nil { ifn_3283 = lang.IFn_Cast(root_3281) } else { ifn_3283 = nil }; var arg_3284 any; var root_3285 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3285, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3287 lang.IFn; if linked_3286 == nil { ifn_3287 = lang.IFn_Cast(root_3285) } else { ifn_3287 = nil }; var arg_3288 any = Lit_57; var arg_3289 any = Lit_58; if linked_3286 == nil { arg_3284 = ifn_3287.Invoke_O_O__O(arg_3288, arg_3289) } else { arg_3284 = linked_3286.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3285, arg_3288, arg_3289) }; if linked_3282 == nil { tmp48 = ifn_3283.Invoke_O__O(arg_3284) } else { tmp48 = linked_3282.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3281, arg_3284) }; var tmp49 any = tmp48; var tmp50 any; var root_3290 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3290, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3292 lang.IFn; if





























































































	linked_3291 == nil { ifn_3292 = lang.IFn_Cast(root_3290) } else { ifn_3292 = nil }; var arg_3293 any; var tmp51 any; var root_3295 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3295, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3297 lang.IFn; if linked_3296 == nil { ifn_3297 = lang.IFn_Cast(root_3295) } else { ifn_3297 = nil }; var arg_3298 any = A_arbace_j2g_dyn_A_const_364; var arg_3299 any = A_arbace_j2g_dyn_A_const_365; if linked_3296 == nil { tmp51 = ifn_3297.Invoke_O_O__O(arg_3298, arg_3299) } else { tmp51 = linked_3296.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3295, arg_3298, arg_3299) }; var tmp52 any = tmp51; var tmp53 any; var root_3300 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3300, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3302 lang.IFn; if linked_3301 == nil { ifn_3302 = lang.IFn_Cast(root_3300) } else { ifn_3302 = nil }; var arg_3303 any = A_arbace_j2g_dyn_A_const_366; var arg_3304 any = A_arbace_j2g_dyn_A_const_367; if linked_3301 == nil { tmp53 = ifn_3302.Invoke_O_O__O(arg_3303, arg_3304) } else { tmp53 = linked_3301.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3300, arg_3303, arg_3304) }; var tmp54 any = tmp53; var tmp55 any; var root_3305 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3305, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3307 lang.IFn; if linked_3306 == nil { ifn_3307 = lang.IFn_Cast(root_3305) } else { ifn_3307 = nil }; var arg_3308 any = A_arbace_j2g_dyn_A_const_368; var arg_3309 any = A_arbace_j2g_dyn_A_const_369; if linked_3306 == nil { tmp55 = ifn_3307.Invoke_O_O__O(arg_3308, arg_3309) } else { tmp55 = linked_3306.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3305, arg_3308, arg_3309) }; arg_3293 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp52, tmp54, tmp55); var arg_3294 any = A_arbace_j2g_dyn_A_const_370; if linked_3291 == nil { tmp50 = ifn_3292.Invoke_O_O__O(arg_3293, arg_3294) } else { tmp50 = linked_3291.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3290, arg_3293, arg_3294) }; var tmp56 lang.IFn = /*line :412:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp57 any = A_arbace_j2g_dyn_A_const_371; var tmp58 any = A_arbace_j2g_dyn_A_const_375; var tmp59 any = A_arbace_j2g_dyn_A_const_376; var tmp60 any = A_arbace_j2g_dyn_A_const_377; var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp62 any = A_arbace_j2g_dyn_A_const_378; var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_dyn_A_const_379; var tmp65 any = A_arbace_j2g_dyn_A_const_380; var tmp66 any = A_arbace_j2g_dyn_A_const_381; var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp68 any = A_arbace_j2g_dyn_A_const_388; var tmp69 any = A_arbace_j2g_dyn_A_const_389; var tmp70 any = tmp46.Invoke_O_O_O_O__O(tmp47, tmp49, tmp50, tmp56.Invoke_O_O_O_O_O__O(tmp57, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp58, tmp59, tmp60, tmp61.Invoke_O_O__O(tmp62, tmp63.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp64, tmp65, tmp66, tmp67.Invoke_O_O_O__O(tmp68, tmp69, jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref()), A_arbace_j2g_dyn_A_const_382, A_arbace_j2g_dyn_A_const_383, A_arbace_j2g_dyn_A_const_384, A_arbace_j2g_dyn_A_const_385, A_arbace_j2g_dyn_A_const_386, A_arbace_j2g_dyn_A_const_387))), A_arbace_j2g_dyn_A_const_372, A_arbace_j2g_dyn_A_const_373, A_arbace_j2g_dyn_A_const_374)); var tmp71 any = A_arbace_j2g_dyn_A_const_353; var tmp72 any = A_arbace_j2g_dyn_A_const_354; var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp74 any = A_arbace_j2g_dyn_A_const_390; var tmp75 any; var root_3310 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3310, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3312 lang.IFn; if



































































































































	linked_3311 == nil { ifn_3312 = lang.IFn_Cast(root_3310) } else { ifn_3312 = nil }; var arg_3313 any; var root_3314 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3314, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3316 lang.IFn; if linked_3315 == nil { ifn_3316 = lang.IFn_Cast(root_3314) } else { ifn_3316 = nil }; var arg_3317 any = Lit_59; var arg_3318 any = Lit_60; if linked_3315 == nil { arg_3313 = ifn_3316.Invoke_O_O__O(arg_3317, arg_3318) } else { arg_3313 = linked_3315.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3314, arg_3317, arg_3318) }; if linked_3311 == nil { tmp75 = ifn_3312.Invoke_O__O(arg_3313) } else { tmp75 = linked_3311.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3310, arg_3313) }; var tmp76 any = tmp75; var tmp77 any; var root_3319 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3319, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3321 lang.IFn; if




































































































































	linked_3320 == nil { ifn_3321 = lang.IFn_Cast(root_3319) } else { ifn_3321 = nil }; var arg_3322 any = A_arbace_j2g_dyn_A_const_392; var arg_3323 any = A_arbace_j2g_dyn_A_const_393; if linked_3320 == nil { tmp77 = ifn_3321.Invoke_O_O__O(arg_3322, arg_3323) } else { tmp77 = linked_3320.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3319, arg_3322, arg_3323) }; var tmp78 any = tmp77; var tmp79 any; var root_3324 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3324, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3326 lang.IFn; if




































































































































	linked_3325 == nil { ifn_3326 = lang.IFn_Cast(root_3324) } else { ifn_3326 = nil }; var arg_3327 any = A_arbace_j2g_dyn_A_const_394; var arg_3328 any = A_arbace_j2g_dyn_A_const_395; if linked_3325 == nil { tmp79 = ifn_3326.Invoke_O_O__O(arg_3327, arg_3328) } else { tmp79 = linked_3325.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3324, arg_3327, arg_3328) }; var tmp80 any = tmp79; var tmp81 any; var root_3329 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3329, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3331 lang.IFn; if




































































































































	linked_3330 == nil { ifn_3331 = lang.IFn_Cast(root_3329) } else { ifn_3331 = nil }; var arg_3332 any = A_arbace_j2g_dyn_A_const_396; var arg_3333 any = A_arbace_j2g_dyn_A_const_397; if linked_3330 == nil { tmp81 = ifn_3331.Invoke_O_O__O(arg_3332, arg_3333) } else { tmp81 = linked_3330.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3329, arg_3332, arg_3333) }; var tmp82 any = tmp81; var tmp83 any; var root_3334 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3334, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3336 lang.IFn; if




































































































































	linked_3335 == nil { ifn_3336 = lang.IFn_Cast(root_3334) } else { ifn_3336 = nil }; var arg_3337 any = A_arbace_j2g_dyn_A_const_398; var arg_3338 any = A_arbace_j2g_dyn_A_const_399; if linked_3335 == nil { tmp83 = ifn_3336.Invoke_O_O__O(arg_3337, arg_3338) } else { tmp83 = linked_3335.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3334, arg_3337, arg_3338) }; var tmp84 any = tmp83; var tmp85 any; var root_3339 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3339, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3341 lang.IFn; if




































































































































	linked_3340 == nil { ifn_3341 = lang.IFn_Cast(root_3339) } else { ifn_3341 = nil }; var arg_3342 any = A_arbace_j2g_dyn_A_const_400; var arg_3343 any = A_arbace_j2g_dyn_A_const_401; if linked_3340 == nil { tmp85 = ifn_3341.Invoke_O_O__O(arg_3342, arg_3343) } else { tmp85 = linked_3340.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3339, arg_3342, arg_3343) }; var tmp86 any = /*line :412:1*/tmp73.Invoke_O_O_O_O__O(tmp74, tmp76, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp78, tmp80, tmp82, tmp84, tmp85), A_arbace_j2g_dyn_A_const_391); var tmp87 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp88 any = A_arbace_j2g_dyn_A_const_402; var tmp89 any; var root_3344 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3344, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3346 lang.IFn; if
































































































































































	linked_3345 == nil { ifn_3346 = lang.IFn_Cast(root_3344) } else { ifn_3346 = nil }; var arg_3347 any; var root_3348 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3348, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3350 lang.IFn; if linked_3349 == nil { ifn_3350 = lang.IFn_Cast(root_3348) } else { ifn_3350 = nil }; var arg_3351 any = Lit_61; var arg_3352 any = Lit_60; if linked_3349 == nil { arg_3347 = ifn_3350.Invoke_O_O__O(arg_3351, arg_3352) } else { arg_3347 = linked_3349.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3348, arg_3351, arg_3352) }; if linked_3345 == nil { tmp89 = ifn_3346.Invoke_O__O(arg_3347) } else { tmp89 = linked_3345.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3344, arg_3347) }; var tmp90 any = tmp89; var tmp91 any; var root_3353 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3353, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3355 lang.IFn; if

































































































































































	linked_3354 == nil { ifn_3355 = lang.IFn_Cast(root_3353) } else { ifn_3355 = nil }; var arg_3356 any = A_arbace_j2g_dyn_A_const_404; var arg_3357 any = A_arbace_j2g_dyn_A_const_405; if linked_3354 == nil { tmp91 = ifn_3355.Invoke_O_O__O(arg_3356, arg_3357) } else { tmp91 = linked_3354.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3353, arg_3356, arg_3357) }; var tmp92 any = tmp91; var tmp93 any; var root_3358 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3358, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3360 lang.IFn; if

































































































































































	linked_3359 == nil { ifn_3360 = lang.IFn_Cast(root_3358) } else { ifn_3360 = nil }; var arg_3361 any = A_arbace_j2g_dyn_A_const_406; var arg_3362 any = A_arbace_j2g_dyn_A_const_407; if linked_3359 == nil { tmp93 = ifn_3360.Invoke_O_O__O(arg_3361, arg_3362) } else { tmp93 = linked_3359.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3358, arg_3361, arg_3362) }; var tmp94 any = tmp93; var tmp95 any; var root_3363 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3363, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3365 lang.IFn; if

































































































































































	linked_3364 == nil { ifn_3365 = lang.IFn_Cast(root_3363) } else { ifn_3365 = nil }; var arg_3366 any = A_arbace_j2g_dyn_A_const_408; var arg_3367 any = A_arbace_j2g_dyn_A_const_409; if linked_3364 == nil { tmp95 = ifn_3365.Invoke_O_O__O(arg_3366, arg_3367) } else { tmp95 = linked_3364.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3363, arg_3366, arg_3367) }; var tmp96 any = tmp95; var tmp97 any; var root_3368 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3368, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3370 lang.IFn; if

































































































































































	linked_3369 == nil { ifn_3370 = lang.IFn_Cast(root_3368) } else { ifn_3370 = nil }; var arg_3371 any = A_arbace_j2g_dyn_A_const_410; var arg_3372 any = A_arbace_j2g_dyn_A_const_411; if linked_3369 == nil { tmp97 = ifn_3370.Invoke_O_O__O(arg_3371, arg_3372) } else { tmp97 = linked_3369.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3368, arg_3371, arg_3372) }; var tmp98 any = tmp97; var tmp99 any; var root_3373 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3373, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3375 lang.IFn; if

































































































































































	linked_3374 == nil { ifn_3375 = lang.IFn_Cast(root_3373) } else { ifn_3375 = nil }; var arg_3376 any = A_arbace_j2g_dyn_A_const_412; var arg_3377 any = A_arbace_j2g_dyn_A_const_413; if linked_3374 == nil { tmp99 = ifn_3375.Invoke_O_O__O(arg_3376, arg_3377) } else { tmp99 = linked_3374.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3373, arg_3376, arg_3377) }; var tmp100 any = /*line :412:1*/tmp87.Invoke_O_O_O_O__O(tmp88, tmp90, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp92, tmp94, tmp96, tmp98, tmp99), A_arbace_j2g_dyn_A_const_403); var tmp101 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp102 any = A_arbace_j2g_dyn_A_const_414; var tmp103 any; var root_3378 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3378, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3380 lang.IFn; if









































































































































































	linked_3379 == nil { ifn_3380 = lang.IFn_Cast(root_3378) } else { ifn_3380 = nil }; var arg_3381 any; var root_3382 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3382, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3384 lang.IFn; if linked_3383 == nil { ifn_3384 = lang.IFn_Cast(root_3382) } else { ifn_3384 = nil }; var arg_3385 any = Lit_62; var arg_3386 any = Lit_63; if linked_3383 == nil { arg_3381 = ifn_3384.Invoke_O_O__O(arg_3385, arg_3386) } else { arg_3381 = linked_3383.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3382, arg_3385, arg_3386) }; if linked_3379 == nil { tmp103 = ifn_3380.Invoke_O__O(arg_3381) } else { tmp103 = linked_3379.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3378, arg_3381) }; var tmp104 any = tmp103; var tmp105 any; var root_3387 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3387, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3389 lang.IFn; if










































































































































































	linked_3388 == nil { ifn_3389 = lang.IFn_Cast(root_3387) } else { ifn_3389 = nil }; var arg_3390 any = A_arbace_j2g_dyn_A_const_416; var arg_3391 any = A_arbace_j2g_dyn_A_const_417; if linked_3388 == nil { tmp105 = ifn_3389.Invoke_O_O__O(arg_3390, arg_3391) } else { tmp105 = linked_3388.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3387, arg_3390, arg_3391) }; var tmp106 any = tmp105; var tmp107 any; var root_3392 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3392, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3394 lang.IFn; if










































































































































































	linked_3393 == nil { ifn_3394 = lang.IFn_Cast(root_3392) } else { ifn_3394 = nil }; var arg_3395 any = A_arbace_j2g_dyn_A_const_418; var arg_3396 any = A_arbace_j2g_dyn_A_const_419; if linked_3393 == nil { tmp107 = ifn_3394.Invoke_O_O__O(arg_3395, arg_3396) } else { tmp107 = linked_3393.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3392, arg_3395, arg_3396) }; var tmp108 any = tmp107; var tmp109 any; var root_3397 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3397, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3399 lang.IFn; if










































































































































































	linked_3398 == nil { ifn_3399 = lang.IFn_Cast(root_3397) } else { ifn_3399 = nil }; var arg_3400 any = A_arbace_j2g_dyn_A_const_420; var arg_3401 any = A_arbace_j2g_dyn_A_const_421; if linked_3398 == nil { tmp109 = ifn_3399.Invoke_O_O__O(arg_3400, arg_3401) } else { tmp109 = linked_3398.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3397, arg_3400, arg_3401) }; var tmp110 any = /*line :412:1*/tmp101.Invoke_O_O_O_O__O(tmp102, tmp104, lang.Tuple_Create_O_O_O__IPersistentVector(tmp106, tmp108, tmp109), A_arbace_j2g_dyn_A_const_415); var tmp111 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp112 any = A_arbace_j2g_dyn_A_const_422; var tmp113 any; var root_3402 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3402, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3404 lang.IFn; if
























































































































































































	linked_3403 == nil { ifn_3404 = lang.IFn_Cast(root_3402) } else { ifn_3404 = nil }; var arg_3405 any; var root_3406 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3406, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3408 lang.IFn; if linked_3407 == nil { ifn_3408 = lang.IFn_Cast(root_3406) } else { ifn_3408 = nil }; var arg_3409 any = Lit_64; var arg_3410 any = Lit_65; if linked_3407 == nil { arg_3405 = ifn_3408.Invoke_O_O__O(arg_3409, arg_3410) } else { arg_3405 = linked_3407.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3406, arg_3409, arg_3410) }; if linked_3403 == nil { tmp113 = ifn_3404.Invoke_O__O(arg_3405) } else { tmp113 = linked_3403.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3402, arg_3405) }; var tmp114 any = tmp113; var tmp115 any; var root_3411 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3411, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3413 lang.IFn; if

























































































































































































	linked_3412 == nil { ifn_3413 = lang.IFn_Cast(root_3411) } else { ifn_3413 = nil }; var arg_3414 any; var tmp116 any; var root_3416 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3416, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3418 lang.IFn; if linked_3417 == nil { ifn_3418 = lang.IFn_Cast(root_3416) } else { ifn_3418 = nil }; var arg_3419 any = A_arbace_j2g_dyn_A_const_423; var arg_3420 any = A_arbace_j2g_dyn_A_const_424; if linked_3417 == nil { tmp116 = ifn_3418.Invoke_O_O__O(arg_3419, arg_3420) } else { tmp116 = linked_3417.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3416, arg_3419, arg_3420) }; var tmp117 any = tmp116; var tmp118 any; var root_3421 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3421, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3423 lang.IFn; if linked_3422 == nil { ifn_3423 = lang.IFn_Cast(root_3421) } else { ifn_3423 = nil }; var arg_3424 any = A_arbace_j2g_dyn_A_const_425; var arg_3425 any = A_arbace_j2g_dyn_A_const_426; if linked_3422 == nil { tmp118 = ifn_3423.Invoke_O_O__O(arg_3424, arg_3425) } else { tmp118 = linked_3422.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3421, arg_3424, arg_3425) }; arg_3414 = lang.Tuple_Create_O_O__IPersistentVector(tmp117, tmp118); var arg_3415 any = A_arbace_j2g_dyn_A_const_427; if linked_3412 == nil { tmp115 = ifn_3413.Invoke_O_O__O(arg_3414, arg_3415) } else { tmp115 = linked_3412.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3411, arg_3414, arg_3415) }; var tmp119 any = /*line :412:1*/tmp111.Invoke_O_O_O_O__O(tmp112, tmp114, tmp115, A_arbace_j2g_dyn_A_const_428); var tmp120 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp121 any = A_arbace_j2g_dyn_A_const_429; var tmp122 any; var root_3426 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3426, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3428 lang.IFn; if




































































































































































































	linked_3427 == nil { ifn_3428 = lang.IFn_Cast(root_3426) } else { ifn_3428 = nil }; var arg_3429 any; var root_3430 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3430, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3432 lang.IFn; if linked_3431 == nil { ifn_3432 = lang.IFn_Cast(root_3430) } else { ifn_3432 = nil }; var arg_3433 any = Lit_66; var arg_3434 any = Lit_67; if linked_3431 == nil { arg_3429 = ifn_3432.Invoke_O_O__O(arg_3433, arg_3434) } else { arg_3429 = linked_3431.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3430, arg_3433, arg_3434) }; if linked_3427 == nil { tmp122 = ifn_3428.Invoke_O__O(arg_3429) } else { tmp122 = linked_3427.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3426, arg_3429) }; var tmp123 any = tmp122; var tmp124 any; var root_3435 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3435, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3437 lang.IFn; if





































































































































































































	linked_3436 == nil { ifn_3437 = lang.IFn_Cast(root_3435) } else { ifn_3437 = nil }; var arg_3438 any = A_arbace_j2g_dyn_A_const_431; var arg_3439 any = A_arbace_j2g_dyn_A_const_432; if linked_3436 == nil { tmp124 = ifn_3437.Invoke_O_O__O(arg_3438, arg_3439) } else { tmp124 = linked_3436.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3435, arg_3438, arg_3439) }; var tmp125 any = tmp124; var tmp126 any; var root_3440 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3440, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3442 lang.IFn; if





































































































































































































	linked_3441 == nil { ifn_3442 = lang.IFn_Cast(root_3440) } else { ifn_3442 = nil }; var arg_3443 any = A_arbace_j2g_dyn_A_const_433; var arg_3444 any = A_arbace_j2g_dyn_A_const_434; if linked_3441 == nil { tmp126 = ifn_3442.Invoke_O_O__O(arg_3443, arg_3444) } else { tmp126 = linked_3441.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3440, arg_3443, arg_3444) }; var tmp127 any = tmp126; var tmp128 any; var root_3445 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3445, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3447 lang.IFn; if





































































































































































































	linked_3446 == nil { ifn_3447 = lang.IFn_Cast(root_3445) } else { ifn_3447 = nil }; var arg_3448 any = A_arbace_j2g_dyn_A_const_435; var arg_3449 any = A_arbace_j2g_dyn_A_const_436; if linked_3446 == nil { tmp128 = ifn_3447.Invoke_O_O__O(arg_3448, arg_3449) } else { tmp128 = linked_3446.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3445, arg_3448, arg_3449) }; var tmp129 any = tmp128; var tmp130 any; var root_3450 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3450, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3452 lang.IFn; if





































































































































































































	linked_3451 == nil { ifn_3452 = lang.IFn_Cast(root_3450) } else { ifn_3452 = nil }; var arg_3453 any = A_arbace_j2g_dyn_A_const_437; var arg_3454 any = A_arbace_j2g_dyn_A_const_438; if linked_3451 == nil { tmp130 = ifn_3452.Invoke_O_O__O(arg_3453, arg_3454) } else { tmp130 = linked_3451.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3450, arg_3453, arg_3454) }; var tmp131 any = /*line :412:1*/tmp120.Invoke_O_O_O_O__O(tmp121, tmp123, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp125, tmp127, tmp129, tmp130), A_arbace_j2g_dyn_A_const_430); var tmp132 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp133 any = A_arbace_j2g_dyn_A_const_439; var tmp134 any; var root_3455 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3455, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3457 lang.IFn; if





















































































































































































































	linked_3456 == nil { ifn_3457 = lang.IFn_Cast(root_3455) } else { ifn_3457 = nil }; var arg_3458 any; var root_3459 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3459, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3461 lang.IFn; if linked_3460 == nil { ifn_3461 = lang.IFn_Cast(root_3459) } else { ifn_3461 = nil }; var arg_3462 any = Lit_68; var arg_3463 any = Lit_69; if linked_3460 == nil { arg_3458 = ifn_3461.Invoke_O_O__O(arg_3462, arg_3463) } else { arg_3458 = linked_3460.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3459, arg_3462, arg_3463) }; if linked_3456 == nil { tmp134 = ifn_3457.Invoke_O__O(arg_3458) } else { tmp134 = linked_3456.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3455, arg_3458) }; var tmp135 any = tmp134; var tmp136 any; var root_3464 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3464, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3466 lang.IFn; if






















































































































































































































	linked_3465 == nil { ifn_3466 = lang.IFn_Cast(root_3464) } else { ifn_3466 = nil }; var arg_3467 any; var tmp137 any; var root_3469 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3469, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3471 lang.IFn; if linked_3470 == nil { ifn_3471 = lang.IFn_Cast(root_3469) } else { ifn_3471 = nil }; var arg_3472 any = A_arbace_j2g_dyn_A_const_440; var arg_3473 any = A_arbace_j2g_dyn_A_const_441; if linked_3470 == nil { tmp137 = ifn_3471.Invoke_O_O__O(arg_3472, arg_3473) } else { tmp137 = linked_3470.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3469, arg_3472, arg_3473) }; var tmp138 any = tmp137; var tmp139 any; var root_3474 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3474, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3476 lang.IFn; if linked_3475 == nil { ifn_3476 = lang.IFn_Cast(root_3474) } else { ifn_3476 = nil }; var arg_3477 any = A_arbace_j2g_dyn_A_const_442; var arg_3478 any = A_arbace_j2g_dyn_A_const_443; if linked_3475 == nil { tmp139 = ifn_3476.Invoke_O_O__O(arg_3477, arg_3478) } else { tmp139 = linked_3475.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3474, arg_3477, arg_3478) }; arg_3467 = lang.Tuple_Create_O_O__IPersistentVector(tmp138, tmp139); var arg_3468 any = A_arbace_j2g_dyn_A_const_444; if linked_3465 == nil { tmp136 = ifn_3466.Invoke_O_O__O(arg_3467, arg_3468) } else { tmp136 = linked_3465.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3464, arg_3467, arg_3468) }; var tmp140 any = /*line :412:1*/tmp132.Invoke_O_O_O_O__O(tmp133, tmp135, tmp136, A_arbace_j2g_dyn_A_const_445); var tmp141 any; var root_3275 any = A_arbace_j2g_dyn_A_const_355.GetRawRoot__O(); var linked_3276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3275, A_arbace_j2g_dyn_fn_field_native_A_fn_class); var ifn_3277 lang.IFn; if



























































































































































































































	linked_3276 == nil { ifn_3277 = lang.IFn_Cast(root_3275) } else { ifn_3277 = nil }; if linked_3276 == nil { tmp141 = ifn_3277.Invoke__O() } else { tmp141 = linked_3276.(*A_arbace_j2g_dyn_fn_field_native_A).Invoke_O__O(root_3275) }; var tmp142 any = tmp141; var tmp143 any; var root_3278 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_356.GetRawRoot__O(); var linked_3279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3278, A_arbace_j2g_dyn_aot_fn_fields_native_A_fn_class); var ifn_3280 lang.IFn; if




























































































































































































































	linked_3279 == nil { ifn_3280 = lang.IFn_Cast(root_3278) } else { ifn_3280 = nil }; if linked_3279 == nil { tmp143 = ifn_3280.Invoke__O() } else { tmp143 = linked_3279.(*A_arbace_j2g_dyn_aot_fn_fields_native_A).Invoke_O__O(root_3278) }; var tmp144 any = tmp143; var tmp145 any = A_arbace_j2g_dyn_A_const_357; var tmp146 any = A_arbace_j2g_dyn_A_const_358; var tmp147 lang.IFn = /*line :412:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp148 any = A_arbace_j2g_dyn_A_const_446; var tmp149 any; var root_3479 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3479, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3481 lang.IFn; if









































































































































































































































	linked_3480 == nil { ifn_3481 = lang.IFn_Cast(root_3479) } else { ifn_3481 = nil }; var arg_3482 any; var root_3483 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3483, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3485 lang.IFn; if linked_3484 == nil { ifn_3485 = lang.IFn_Cast(root_3483) } else { ifn_3485 = nil }; var arg_3486 any = Lit_70; var arg_3487 any = Lit_71; if linked_3484 == nil { arg_3482 = ifn_3485.Invoke_O_O__O(arg_3486, arg_3487) } else { arg_3482 = linked_3484.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3483, arg_3486, arg_3487) }; if linked_3480 == nil { tmp149 = ifn_3481.Invoke_O__O(arg_3482) } else { tmp149 = linked_3480.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3479, arg_3482) }; var tmp150 any = tmp149; var tmp151 any; var root_3488 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3488, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3490 lang.IFn; if










































































































































































































































	linked_3489 == nil { ifn_3490 = lang.IFn_Cast(root_3488) } else { ifn_3490 = nil }; var arg_3491 any = A_arbace_j2g_dyn_A_const_448; var arg_3492 any = A_arbace_j2g_dyn_A_const_449; if linked_3489 == nil { tmp151 = ifn_3490.Invoke_O_O__O(arg_3491, arg_3492) } else { tmp151 = linked_3489.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3488, arg_3491, arg_3492) }; var tmp152 any = tmp151; var tmp153 any; var root_3493 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3493, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3495 lang.IFn; if










































































































































































































































	linked_3494 == nil { ifn_3495 = lang.IFn_Cast(root_3493) } else { ifn_3495 = nil }; var arg_3496 any = A_arbace_j2g_dyn_A_const_450; var arg_3497 any = A_arbace_j2g_dyn_A_const_451; if linked_3494 == nil { tmp153 = ifn_3495.Invoke_O_O__O(arg_3496, arg_3497) } else { tmp153 = linked_3494.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3493, arg_3496, arg_3497) }; var tmp154 any = /*line :412:1*/tmp147.Invoke_O_O_O_O__O(tmp148, tmp150, lang.Tuple_Create_O_O__IPersistentVector(tmp152, tmp153), A_arbace_j2g_dyn_A_const_447); var tmp155 any = A_arbace_j2g_dyn_A_const_359; var tmp156 any = A_arbace_j2g_dyn_A_const_360.GetRawRoot__O(); var tmp157 any = A_arbace_j2g_dyn_A_const_361; var tmp158 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp159 any = A_arbace_j2g_dyn_A_const_452; var tmp160 any; var root_3498 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3498, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3500 lang.IFn; if
































































































































































































































































	linked_3499 == nil { ifn_3500 = lang.IFn_Cast(root_3498) } else { ifn_3500 = nil }; var arg_3501 any; var root_3502 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3502, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3504 lang.IFn; if linked_3503 == nil { ifn_3504 = lang.IFn_Cast(root_3502) } else { ifn_3504 = nil }; var arg_3505 any = Lit_72; var arg_3506 any = Lit_73; if linked_3503 == nil { arg_3501 = ifn_3504.Invoke_O_O__O(arg_3505, arg_3506) } else { arg_3501 = linked_3503.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3502, arg_3505, arg_3506) }; if linked_3499 == nil { tmp160 = ifn_3500.Invoke_O__O(arg_3501) } else { tmp160 = linked_3499.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3498, arg_3501) }; var tmp161 any = tmp160; var tmp162 any; var root_3507 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3507, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3509 lang.IFn; if

































































































































































































































































	linked_3508 == nil { ifn_3509 = lang.IFn_Cast(root_3507) } else { ifn_3509 = nil }; var arg_3510 any; var tmp163 any; var root_3512 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3512, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3514 lang.IFn; if linked_3513 == nil { ifn_3514 = lang.IFn_Cast(root_3512) } else { ifn_3514 = nil }; var arg_3515 any = A_arbace_j2g_dyn_A_const_453; var arg_3516 any = A_arbace_j2g_dyn_A_const_454; if linked_3513 == nil { tmp163 = ifn_3514.Invoke_O_O__O(arg_3515, arg_3516) } else { tmp163 = linked_3513.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3512, arg_3515, arg_3516) }; var tmp164 any = tmp163; var tmp165 any; var root_3517 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3517, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3519 lang.IFn; if linked_3518 == nil { ifn_3519 = lang.IFn_Cast(root_3517) } else { ifn_3519 = nil }; var arg_3520 any = A_arbace_j2g_dyn_A_const_455; var arg_3521 any = A_arbace_j2g_dyn_A_const_456; if linked_3518 == nil { tmp165 = ifn_3519.Invoke_O_O__O(arg_3520, arg_3521) } else { tmp165 = linked_3518.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3517, arg_3520, arg_3521) }; arg_3510 = lang.Tuple_Create_O_O__IPersistentVector(tmp164, tmp165); var arg_3511 any = A_arbace_j2g_dyn_A_const_457; if linked_3508 == nil { tmp162 = ifn_3509.Invoke_O_O__O(arg_3510, arg_3511) } else { tmp162 = linked_3508.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3507, arg_3510, arg_3511) }; var tmp166 any = /*line :412:1*/tmp158.Invoke_O_O_O_O__O(tmp159, tmp161, tmp162, A_arbace_j2g_dyn_A_const_458); var tmp167 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp168 any = A_arbace_j2g_dyn_A_const_459; var tmp169 any; var root_3522 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3522, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3524 lang.IFn; if






































































































































































































































































	linked_3523 == nil { ifn_3524 = lang.IFn_Cast(root_3522) } else { ifn_3524 = nil }; var arg_3525 any; var root_3526 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3526, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3528 lang.IFn; if linked_3527 == nil { ifn_3528 = lang.IFn_Cast(root_3526) } else { ifn_3528 = nil }; var arg_3529 any = Lit_74; var arg_3530 any = Lit_75; if linked_3527 == nil { arg_3525 = ifn_3528.Invoke_O_O__O(arg_3529, arg_3530) } else { arg_3525 = linked_3527.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3526, arg_3529, arg_3530) }; if linked_3523 == nil { tmp169 = ifn_3524.Invoke_O__O(arg_3525) } else { tmp169 = linked_3523.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3522, arg_3525) }; var tmp170 any = tmp169; var tmp171 any; var root_3531 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3531, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3533 lang.IFn; if







































































































































































































































































	linked_3532 == nil { ifn_3533 = lang.IFn_Cast(root_3531) } else { ifn_3533 = nil }; var arg_3534 any; var tmp172 any; var root_3536 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3536, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3538 lang.IFn; if linked_3537 == nil { ifn_3538 = lang.IFn_Cast(root_3536) } else { ifn_3538 = nil }; var arg_3539 any = A_arbace_j2g_dyn_A_const_460; var arg_3540 any = A_arbace_j2g_dyn_A_const_461; if linked_3537 == nil { tmp172 = ifn_3538.Invoke_O_O__O(arg_3539, arg_3540) } else { tmp172 = linked_3537.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3536, arg_3539, arg_3540) }; var tmp173 any = tmp172; var tmp174 any; var root_3541 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3541, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3543 lang.IFn; if linked_3542 == nil { ifn_3543 = lang.IFn_Cast(root_3541) } else { ifn_3543 = nil }; var arg_3544 any = A_arbace_j2g_dyn_A_const_462; var arg_3545 any = A_arbace_j2g_dyn_A_const_463; if linked_3542 == nil { tmp174 = ifn_3543.Invoke_O_O__O(arg_3544, arg_3545) } else { tmp174 = linked_3542.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3541, arg_3544, arg_3545) }; arg_3534 = lang.Tuple_Create_O_O__IPersistentVector(tmp173, tmp174); var arg_3535 any = A_arbace_j2g_dyn_A_const_464; if linked_3532 == nil { tmp171 = ifn_3533.Invoke_O_O__O(arg_3534, arg_3535) } else { tmp171 = linked_3532.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3531, arg_3534, arg_3535) }; var tmp175 any = /*line :412:1*/tmp167.Invoke_O_O_O_O__O(tmp168, tmp170, tmp171, A_arbace_j2g_dyn_A_const_465); var tmp176 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp177 any = A_arbace_j2g_dyn_A_const_466; var tmp178 any; var root_3546 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3546, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3548 lang.IFn; if









































































































































































































































































	linked_3547 == nil { ifn_3548 = lang.IFn_Cast(root_3546) } else { ifn_3548 = nil }; var arg_3549 any; var root_3550 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3550, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3552 lang.IFn; if linked_3551 == nil { ifn_3552 = lang.IFn_Cast(root_3550) } else { ifn_3552 = nil }; var arg_3553 any = Lit_76; var arg_3554 any = Lit_77; if linked_3551 == nil { arg_3549 = ifn_3552.Invoke_O_O__O(arg_3553, arg_3554) } else { arg_3549 = linked_3551.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3550, arg_3553, arg_3554) }; if linked_3547 == nil { tmp178 = ifn_3548.Invoke_O__O(arg_3549) } else { tmp178 = linked_3547.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3546, arg_3549) }; var tmp179 any = tmp178; var tmp180 any; var root_3555 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3555, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3557 lang.IFn; if










































































































































































































































































	linked_3556 == nil { ifn_3557 = lang.IFn_Cast(root_3555) } else { ifn_3557 = nil }; var arg_3558 any = A_arbace_j2g_dyn_A_const_468; var arg_3559 any = A_arbace_j2g_dyn_A_const_469; if linked_3556 == nil { tmp180 = ifn_3557.Invoke_O_O__O(arg_3558, arg_3559) } else { tmp180 = linked_3556.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3555, arg_3558, arg_3559) }; var tmp181 any = tmp180; var tmp182 any; var root_3560 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3560, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3562 lang.IFn; if










































































































































































































































































	linked_3561 == nil { ifn_3562 = lang.IFn_Cast(root_3560) } else { ifn_3562 = nil }; var arg_3563 any = A_arbace_j2g_dyn_A_const_470; var arg_3564 any = A_arbace_j2g_dyn_A_const_471; if linked_3561 == nil { tmp182 = ifn_3562.Invoke_O_O__O(arg_3563, arg_3564) } else { tmp182 = linked_3561.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3560, arg_3563, arg_3564) }; var tmp183 any = tmp182; var tmp184 any; var root_3565 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3565, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3567 lang.IFn; if










































































































































































































































































	linked_3566 == nil { ifn_3567 = lang.IFn_Cast(root_3565) } else { ifn_3567 = nil }; var arg_3568 any = A_arbace_j2g_dyn_A_const_472; var arg_3569 any = A_arbace_j2g_dyn_A_const_473; if linked_3566 == nil { tmp184 = ifn_3567.Invoke_O_O__O(arg_3568, arg_3569) } else { tmp184 = linked_3566.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3565, arg_3568, arg_3569) }; var tmp185 any = /*line :412:1*/tmp176.Invoke_O_O_O_O__O(tmp177, tmp179, lang.Tuple_Create_O_O_O__IPersistentVector(tmp181, tmp183, tmp184), A_arbace_j2g_dyn_A_const_467); var tmp186 any = A_arbace_j2g_dyn_A_const_362; var tmp187 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp188 any = A_arbace_j2g_dyn_A_const_474; var tmp189 any; var root_3570 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3570, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3572 lang.IFn; if



















































































































































































































































































	linked_3571 == nil { ifn_3572 = lang.IFn_Cast(root_3570) } else { ifn_3572 = nil }; var arg_3573 any; var root_3574 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3574, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3576 lang.IFn; if linked_3575 == nil { ifn_3576 = lang.IFn_Cast(root_3574) } else { ifn_3576 = nil }; var arg_3577 any = Lit_78; var arg_3578 any = Lit_79; if linked_3575 == nil { arg_3573 = ifn_3576.Invoke_O_O__O(arg_3577, arg_3578) } else { arg_3573 = linked_3575.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3574, arg_3577, arg_3578) }; if linked_3571 == nil { tmp189 = ifn_3572.Invoke_O__O(arg_3573) } else { tmp189 = linked_3571.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3570, arg_3573) }; var tmp190 any = tmp189; var tmp191 any; var root_3579 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3579, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3581 lang.IFn; if






















































































































































































































































































	linked_3580 == nil { ifn_3581 = lang.IFn_Cast(root_3579) } else { ifn_3581 = nil }; var arg_3582 any = A_arbace_j2g_dyn_A_const_476; var arg_3583 any = A_arbace_j2g_dyn_A_const_477; if linked_3580 == nil { tmp191 = ifn_3581.Invoke_O_O__O(arg_3582, arg_3583) } else { tmp191 = linked_3580.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3579, arg_3582, arg_3583) }; var tmp192 any = tmp191; var tmp193 any; var root_3584 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3584, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3586 lang.IFn; if






















































































































































































































































































	linked_3585 == nil { ifn_3586 = lang.IFn_Cast(root_3584) } else { ifn_3586 = nil }; var arg_3587 any = A_arbace_j2g_dyn_A_const_478; var arg_3588 any = A_arbace_j2g_dyn_A_const_479; if linked_3585 == nil { tmp193 = ifn_3586.Invoke_O_O__O(arg_3587, arg_3588) } else { tmp193 = linked_3585.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3584, arg_3587, arg_3588) }; var tmp194 any = /*line :412:1*/tmp187.Invoke_O_O_O_O_O__O(tmp188, tmp190, Lit_80, lang.Tuple_Create_O_O__IPersistentVector(tmp192, tmp193), A_arbace_j2g_dyn_A_const_475); var tmp195 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp196 any = A_arbace_j2g_dyn_A_const_480; var tmp197 any; var root_3589 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3589, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3591 lang.IFn; if




























































































































































































































































































	linked_3590 == nil { ifn_3591 = lang.IFn_Cast(root_3589) } else { ifn_3591 = nil }; var arg_3592 any; var root_3593 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3593, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3595 lang.IFn; if linked_3594 == nil { ifn_3595 = lang.IFn_Cast(root_3593) } else { ifn_3595 = nil }; var arg_3596 any = Lit_81; var arg_3597 any = Lit_82; if linked_3594 == nil { arg_3592 = ifn_3595.Invoke_O_O__O(arg_3596, arg_3597) } else { arg_3592 = linked_3594.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3593, arg_3596, arg_3597) }; if linked_3590 == nil { tmp197 = ifn_3591.Invoke_O__O(arg_3592) } else { tmp197 = linked_3590.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3589, arg_3592) }; var tmp198 any = tmp197; var tmp199 any; var root_3598 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3598, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3600 lang.IFn; if





























































































































































































































































































	linked_3599 == nil { ifn_3600 = lang.IFn_Cast(root_3598) } else { ifn_3600 = nil }; var arg_3601 any = lang.PersistentVector_EMPTY.Ref(); var arg_3602 any = A_arbace_j2g_dyn_A_const_481; if linked_3599 == nil { tmp199 = ifn_3600.Invoke_O_O__O(arg_3601, arg_3602) } else { tmp199 = linked_3599.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3598, arg_3601, arg_3602) }; var tmp200 any = /*line :412:1*/tmp195.Invoke_O_O_O_O__O(tmp196, tmp198, tmp199, A_arbace_j2g_dyn_A_const_482); var tmp201 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp202 any = A_arbace_j2g_dyn_A_const_483; var tmp203 any = A_arbace_j2g_dyn_A_const_484; var tmp204 any; var root_3736 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3736, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3738 lang.IFn; if

































































































































































































































































































	linked_3737 == nil { ifn_3738 = lang.IFn_Cast(root_3736) } else { ifn_3738 = nil }; var arg_3739 any = A_arbace_j2g_dyn_A_const_493; var arg_3740 any = A_arbace_j2g_dyn_A_const_494; if linked_3737 == nil { tmp204 = ifn_3738.Invoke_O_O__O(arg_3739, arg_3740) } else { tmp204 = linked_3737.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3736, arg_3739, arg_3740) }; var tmp205 any = /*line :412:1*/lang.Tuple_Create_O__IPersistentVector(tmp204); var tmp206 any = A_arbace_j2g_dyn_A_const_485; var tmp207 any = A_arbace_j2g_dyn_A_const_486; var tmp208 any; var root_3603 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_3604 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3603, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3605 lang.IFn; if


































































































































































































































































































	linked_3604 == nil { ifn_3605 = lang.IFn_Cast(root_3603) } else { ifn_3605 = nil }; var arg_3606 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_3607 any = A_arbace_j2g_dyn_A_const_487; var arg_3608 any = A_arbace_j2g_dyn_A_const_488; var arg_3609 any; var iter__1927001039__auto____5_3 any; var fnbody__3731 any = A_arbace_j2g_dyn_forms_iter__711000417__711000421_A_New(); var tmp209 *jrt.Class; var fncls__3730 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000417__711000421_A_fn_class; if
	fncls__3730 == nil { var fncls__3730d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, nil); A_arbace_j2g_dyn_forms_iter__711000417__711000421_A_fn_class = fncls__3730d; tmp209 = fncls__3730d } else { tmp209 = fncls__3730 }; iter__1927001039__auto____5_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3731, tmp209, nil); var tmp210 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5_3); var tmp211 any; var root_3732 any = A_arbace_j2g_dyn_A_const_491.GetRawRoot__O(); var linked_3733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3732, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3734 lang.IFn; if linked_3733 == nil { ifn_3734 = lang.IFn_Cast(root_3732) } else { ifn_3734 = nil }; var arg_3735 any = T__0_; if linked_3733 == nil { tmp211 = ifn_3734.Invoke_O__O(arg_3735) } else { tmp211 = linked_3733.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3732, arg_3735) }; arg_3609 = tmp210.Invoke_O__O(tmp211); if /*line :703:1*/ linked_3604 == nil { tmp208 = ifn_3605.Invoke_O_O_O_O__O(arg_3606, arg_3607, arg_3608, arg_3609) } else { tmp208 = linked_3604.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3603, arg_3606, arg_3607, arg_3608, arg_3609) }; var tmp212 any = /*line :412:1*/tmp201.Invoke_O_O_O_O_O_O_O_O__O(tmp202, tmp203, Lit_83, tmp205, tmp206, tmp207, tmp208, A_arbace_j2g_dyn_A_const_492); var tmp213 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp214 any = A_arbace_j2g_dyn_A_const_495; var tmp215 any; var root_3741 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3741, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3743 lang.IFn; if








































































































































































































































































































	linked_3742 == nil { ifn_3743 = lang.IFn_Cast(root_3741) } else { ifn_3743 = nil }; var arg_3744 any; var root_3745 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3745, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3747 lang.IFn; if linked_3746 == nil { ifn_3747 = lang.IFn_Cast(root_3745) } else { ifn_3747 = nil }; var arg_3748 any = Lit_85; var arg_3749 any = Lit_86; if linked_3746 == nil { arg_3744 = ifn_3747.Invoke_O_O__O(arg_3748, arg_3749) } else { arg_3744 = linked_3746.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3745, arg_3748, arg_3749) }; if linked_3742 == nil { tmp215 = ifn_3743.Invoke_O__O(arg_3744) } else { tmp215 = linked_3742.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3741, arg_3744) }; var tmp216 any = tmp215; var tmp217 any; var root_3750 any = /*line :412:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3750, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3752 lang.IFn; if









































































































































































































































































































	linked_3751 == nil { ifn_3752 = lang.IFn_Cast(root_3750) } else { ifn_3752 = nil }; var arg_3753 any; var tmp218 any; var root_3755 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3755, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3757 lang.IFn; if linked_3756 == nil { ifn_3757 = lang.IFn_Cast(root_3755) } else { ifn_3757 = nil }; var arg_3758 any = A_arbace_j2g_dyn_A_const_496; var arg_3759 any = A_arbace_j2g_dyn_A_const_497; if linked_3756 == nil { tmp218 = ifn_3757.Invoke_O_O__O(arg_3758, arg_3759) } else { tmp218 = linked_3756.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3755, arg_3758, arg_3759) }; var tmp219 any = tmp218; var tmp220 any; var root_3760 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3760, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3762 lang.IFn; if linked_3761 == nil { ifn_3762 = lang.IFn_Cast(root_3760) } else { ifn_3762 = nil }; var arg_3763 any = A_arbace_j2g_dyn_A_const_498; var arg_3764 any = A_arbace_j2g_dyn_A_const_499; if linked_3761 == nil { tmp220 = ifn_3762.Invoke_O_O__O(arg_3763, arg_3764) } else { tmp220 = linked_3761.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3760, arg_3763, arg_3764) }; var tmp221 any = tmp220; var tmp222 any; var root_3765 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3765, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3767 lang.IFn; if linked_3766 == nil { ifn_3767 = lang.IFn_Cast(root_3765) } else { ifn_3767 = nil }; var arg_3768 any = A_arbace_j2g_dyn_A_const_500; var arg_3769 any = A_arbace_j2g_dyn_A_const_501; if linked_3766 == nil { tmp222 = ifn_3767.Invoke_O_O__O(arg_3768, arg_3769) } else { tmp222 = linked_3766.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3765, arg_3768, arg_3769) }; arg_3753 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp219, tmp221, tmp222); var arg_3754 any = A_arbace_j2g_dyn_A_const_502; if linked_3751 == nil { tmp217 = ifn_3752.Invoke_O_O__O(arg_3753, arg_3754) } else { tmp217 = linked_3751.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3750, arg_3753, arg_3754) }; var tmp223 any = tmp217; var tmp224 lang.IFn = /*line :412:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp225 any = A_arbace_j2g_dyn_A_const_504; var tmp226 any = A_arbace_j2g_dyn_A_const_505; var tmp227 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp228 any = A_arbace_j2g_dyn_A_const_506; var tmp229 any = A_arbace_j2g_dyn_A_const_511; var tmp230 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp231 any; var root_3770 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3770, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3772 lang.IFn; if












































































































































































































































































































	linked_3771 == nil { ifn_3772 = lang.IFn_Cast(root_3770) } else { ifn_3772 = nil }; var arg_3773 any; var root_3774 any = A_arbace_j2g_dyn_A_const_289.GetRawRoot__O(); var linked_3775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3774, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3776 lang.IFn; if linked_3775 == nil { ifn_3776 = lang.IFn_Cast(root_3774) } else { ifn_3776 = nil }; var arg_3777 any = Lit_57; var arg_3778 any = Lit_58; if linked_3775 == nil { arg_3773 = ifn_3776.Invoke_O_O__O(arg_3777, arg_3778) } else { arg_3773 = linked_3775.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3774, arg_3777, arg_3778) }; if linked_3771 == nil { tmp231 = ifn_3772.Invoke_O__O(arg_3773) } else { tmp231 = linked_3771.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3770, arg_3773) }; var tmp232 any = /*line :412:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp70, tmp71, tmp72, tmp86, tmp100, tmp110, tmp119, tmp131, tmp140, tmp142, tmp144, tmp145, tmp146, tmp154, tmp155, tmp156, tmp157, tmp166, tmp175, tmp185, tmp186, tmp194, tmp200, tmp212, tmp213.Invoke_O_O_O_O_O__O(tmp214, tmp216, tmp223, tmp224.Invoke_O_O_O__O(tmp225, tmp226, tmp227.Invoke_O_O_O_O_O_O__O(tmp228, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp229, tmp230.Invoke_O_O_O_O__O(tmp231, A_arbace_j2g_dyn_A_const_516, A_arbace_j2g_dyn_A_const_517, A_arbace_j2g_dyn_A_const_518), A_arbace_j2g_dyn_A_const_512, A_arbace_j2g_dyn_A_const_513, A_arbace_j2g_dyn_A_const_514, A_arbace_j2g_dyn_A_const_515), A_arbace_j2g_dyn_A_const_507, A_arbace_j2g_dyn_A_const_508, A_arbace_j2g_dyn_A_const_509, A_arbace_j2g_dyn_A_const_510)), A_arbace_j2g_dyn_A_const_503))); var tmp233 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_519.GetRawRoot__O()); var tmp234 *lang.Compiler_AOTFn; var fnbody__3791 any = A_arbace_j2g_dyn_forms_fn__711000427_A_New_O_O(ks__3, ifaces__2); var tmp235 *jrt.Class; var fncls__3790 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000427_A_fn_class; if













































































































































































































































































































































	fncls__3790 == nil { var fncls__3790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__3791); A_arbace_j2g_dyn_forms_fn__711000427_A_fn_class = fncls__3790d; tmp235 = fncls__3790d } else { tmp235 = fncls__3790 }; tmp234 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3791, tmp235, nil); var tmp236 any = /*line :412:1*/tmp234.Ref(); var tmp237 any; var root_3792 any = A_arbace_j2g_dyn_A_const_491.GetRawRoot__O(); var linked_3793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3792, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3794 lang.IFn; if













































































































































































































































































































































	linked_3793 == nil { ifn_3794 = lang.IFn_Cast(root_3792) } else { ifn_3794 = nil }; var arg_3795 any = T__0_; if linked_3793 == nil { tmp237 = ifn_3794.Invoke_O__O(arg_3795) } else { tmp237 = linked_3793.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3792, arg_3795) }; return /*line :412:1*/ tmp1.Invoke_O_O_O_O_O__O(tmp33, tmp36, tmp45, tmp232, tmp233.Invoke_O_O__O(tmp236, tmp237)) }






























func A_arbace_j2g_dyn_forms_fn__711000384_A_New() *A_arbace_j2g_dyn_forms_fn__711000384_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000384_A{}; t.Ctor(); return t }
//line :443:1
func (t *A_arbace_j2g_dyn_forms_fn__711000384_A) Ctor() {}
//line :443:1
func (t *A_arbace_j2g_dyn_forms_fn__711000384_A) Invoke_O_O_O__O(self, i__1, p__711000383__2 any) any { var vec__711000385__3 any = p__711000383__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000385__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000385__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }















func A_arbace_j2g_dyn_forms_iter__711000389__711000393_A_New() *A_arbace_j2g_dyn_forms_iter__711000389__711000393_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000389__711000393_A{}; t.Ctor(); return t }
//line :459:1
func (t *A_arbace_j2g_dyn_forms_iter__711000389__711000393_A) Ctor() {}
//line :459:1
func (t *A_arbace_j2g_dyn_forms_iter__711000389__711000393_A) Invoke_O_O__O(self, s__711000390__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3158 any = A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A_New_O_O(self, s__711000390__1); var tmp2 *jrt.Class; var fncls__3157 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A_fn_class; if fncls__3157 == nil { var fncls__3157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__3158); A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A_fn_class = fncls__3157d; tmp2 = fncls__3157d } else { tmp2 = fncls__3157 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3158, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :459:1
func A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A{}; t.Ctor_O_O(p0, p1); return t }
//line :459:1
func (t *A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A) Ctor_O_O(c__iter__711000389, c__s__711000390 any) { t.F_iter__711000389 = c__iter__711000389; t.F_s__711000390 = c__s__711000390 }
//line :459:1
func (t *A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A) Invoke_O__O(self any) any { { var s__711000390__1 any; var t_ any = t.F_s__711000390; t.F_s__711000390 = nil; s__711000390__1 = t_; for { var temp__1927000414__auto____2 any; var root_3077 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3077, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3079 lang.IFn; if linked_3078 == nil { ifn_3079 = lang.IFn_Cast(root_3077) } else { ifn_3079 = nil }; var arg_3080 any = s__711000390__1; if linked_3078 == nil { temp__1927000414__auto____2 = ifn_3079.Invoke_O__O(arg_3080) } else { temp__1927000414__auto____2 = linked_3078.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3077, arg_3080) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000390__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3081 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3083 lang.IFn; if linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = s__711000390__3; if linked_3082 == nil { tmp1 = ifn_3083.Invoke_O__O(arg_3084) } else { tmp1 = linked_3082.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3081, arg_3084) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3085 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3085, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3087 lang.IFn; if linked_3086 == nil { ifn_3087 = lang.IFn_Cast(root_3085) } else { ifn_3087 = nil }; var arg_3088 any = s__711000390__3; if linked_3086 == nil { c__1927001037__auto____4 = ifn_3087.Invoke_O__O(arg_3088) } else { c__1927001037__auto____4 = linked_3086.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3085, arg_3088) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000392__6 any; var root_3089 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3089, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3091 lang.IFn; if linked_3090 == nil { ifn_3091 = lang.IFn_Cast(root_3089) } else { ifn_3091 = nil }; var arg_3092 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3090 == nil { b__711000392__6 = ifn_3091.Invoke_O__O(arg_3092) } else { b__711000392__6 = linked_3090.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3089, arg_3092) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3110 any = A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A_New_O_I_O(b__711000392__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3109 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A_fn_class; if fncls__3109 == nil { var fncls__3109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__3110); A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A_fn_class = fncls__3109d; tmp3 = fncls__3109d } else { tmp3 = fncls__3109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3110, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3111 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3111, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3113 lang.IFn; if linked_3112 == nil { ifn_3113 = lang.IFn_Cast(root_3111) } else { ifn_3113 = nil }; var arg_3114 any; var root_3116 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3116, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3118 lang.IFn; if linked_3117 == nil { ifn_3118 = lang.IFn_Cast(root_3116) } else { ifn_3118 = nil }; var arg_3119 any = b__711000392__6; if linked_3117 == nil { arg_3114 = ifn_3118.Invoke_O__O(arg_3119) } else { arg_3114 = linked_3117.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3116, arg_3119) }; var arg_3115 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000389); var tmp5 any; var root_3120 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3120, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3122 lang.IFn; if linked_3121 == nil { ifn_3122 = lang.IFn_Cast(root_3120) } else { ifn_3122 = nil }; var arg_3123 any = s__711000390__3; if linked_3121 == nil { tmp5 = ifn_3122.Invoke_O__O(arg_3123) } else { tmp5 = linked_3121.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3120, arg_3123) }; arg_3115 = tmp4.Invoke_O__O(tmp5); if linked_3112 == nil { return ifn_3113.Invoke_O_O__O(arg_3114, arg_3115) } else { return linked_3112.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3111, arg_3114, arg_3115) } } else { var root_3124 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3124, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3126 lang.IFn; if linked_3125 == nil { ifn_3126 = lang.IFn_Cast(root_3124) } else { ifn_3126 = nil }; var arg_3127 any; var root_3129 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3129, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3131 lang.IFn; if linked_3130 == nil { ifn_3131 = lang.IFn_Cast(root_3129) } else { ifn_3131 = nil }; var arg_3132 any = b__711000392__6; if linked_3130 == nil { arg_3127 = ifn_3131.Invoke_O__O(arg_3132) } else { arg_3127 = linked_3130.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3129, arg_3132) }; var arg_3128 any; if linked_3125 == nil { return ifn_3126.Invoke_O_O__O(arg_3127, arg_3128) } else { return linked_3125.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3124, arg_3127, arg_3128) } } } else { var vec__711000400__4 any; var root_3133 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3133, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3135 lang.IFn; if linked_3134 == nil { ifn_3135 = lang.IFn_Cast(root_3133) } else { ifn_3135 = nil }; var arg_3136 any = s__711000390__3; if linked_3134 == nil { vec__711000400__4 = ifn_3135.Invoke_O__O(arg_3136) } else { vec__711000400__4 = linked_3134.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3133, arg_3136) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000400__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000400__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3137 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3137, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3139 lang.IFn; if linked_3138 == nil { ifn_3139 = lang.IFn_Cast(root_3137) } else { ifn_3139 = nil }; var arg_3140 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_342; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(d__5); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_343; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any; var root_3142 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3142, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3144 lang.IFn
													if linked_3143 == nil { ifn_3144 = lang.IFn_Cast(root_3142) } else { ifn_3144 = nil }; var arg_3145 any = A_arbace_j2g_dyn_A_const_73; var arg_3146 any = Lit_18; var arg_3147 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp14 any; var root_3148 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_3149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3148, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_3150 lang.IFn; if linked_3149 == nil { ifn_3150 = lang.IFn_Cast(root_3148) } else { ifn_3150 = nil }; var arg_3151 any = nme__6; var arg_3152 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__5)).Ref(); if linked_3149 == nil { tmp14 = ifn_3150.Invoke_O_O__O(arg_3151, arg_3152) } else { tmp14 = linked_3149.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_3148, arg_3151, arg_3152) }; arg_3147 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3143 == nil { tmp12 = ifn_3144.Invoke_O_O_O__O(arg_3145, arg_3146, arg_3147) } else { tmp12 = linked_3143.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3142, arg_3145, arg_3146, arg_3147) }; arg_3140 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(tmp12, A_arbace_j2g_dyn_A_const_344)))
//line :459:1
	var arg_3141 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__711000389); var tmp16 any; var root_3153 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3153, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3155 lang.IFn; if linked_3154 == nil { ifn_3155 = lang.IFn_Cast(root_3153) } else { ifn_3155 = nil }; var arg_3156 any = s__711000390__3; if linked_3154 == nil { tmp16 = ifn_3155.Invoke_O__O(arg_3156) } else { tmp16 = linked_3154.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3153, arg_3156) }; arg_3141 = tmp15.Invoke_O__O(tmp16); if linked_3138 == nil { return ifn_3139.Invoke_O_O__O(arg_3140, arg_3141) } else { return linked_3138.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3137, arg_3140, arg_3141) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :459:1
func A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :459:1
func (t *A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A) Ctor_O_I_O(c__b__711000392 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000392 = c__b__711000392; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :459:1
func (t *A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A) Invoke_O__O(self any) any { { var i__711000391__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000391__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000396__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000391__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000396__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000396__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3093 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3093, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3095 lang.IFn; if linked_3094 == nil { ifn_3095 = lang.IFn_Cast(root_3093) } else { ifn_3095 = nil }; var arg_3096 any = t.F_b__711000392; var arg_3097 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_342; var tmp4 any = lang.Tuple_Create_O__IPersistentVector(d__3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_343; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any; var root_3098 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3098, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3100 lang.IFn
															if linked_3099 == nil { ifn_3100 = lang.IFn_Cast(root_3098) } else { ifn_3100 = nil }; var arg_3101 any = A_arbace_j2g_dyn_A_const_73; var arg_3102 any = Lit_18; var arg_3103 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp10 any; var root_3104 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_3105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3104, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_3106 lang.IFn; if linked_3105 == nil { ifn_3106 = lang.IFn_Cast(root_3104) } else { ifn_3106 = nil }; var arg_3107 any = nme__4; var arg_3108 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_19, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3)).Ref(); if linked_3105 == nil { tmp10 = ifn_3106.Invoke_O_O__O(arg_3107, arg_3108) } else { tmp10 = linked_3105.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_3104, arg_3107, arg_3108) }; arg_3103 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3099 == nil { tmp8 = ifn_3100.Invoke_O_O_O__O(arg_3101, arg_3102, arg_3103) } else { tmp8 = linked_3099.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3098, arg_3101, arg_3102, arg_3103) }; arg_3097 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, A_arbace_j2g_dyn_A_const_344)))
//line :459:1
	if linked_3094 == nil { ifn_3095.Invoke_O_O__O(arg_3096, arg_3097) } else { linked_3094.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3093, arg_3096, arg_3097) }; i__711000391__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000391__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








































func A_arbace_j2g_dyn_forms_iter__711000405__711000409_A_New() *A_arbace_j2g_dyn_forms_iter__711000405__711000409_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000405__711000409_A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_j2g_dyn_forms_iter__711000405__711000409_A) Ctor() {}
//line :500:1
func (t *A_arbace_j2g_dyn_forms_iter__711000405__711000409_A) Invoke_O_O__O(self, s__711000406__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3250 any = A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A_New_O_O(self, s__711000406__1); var tmp2 *jrt.Class; var fncls__3249 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A_fn_class; if fncls__3249 == nil { var fncls__3249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__3250); A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A_fn_class = fncls__3249d; tmp2 = fncls__3249d } else { tmp2 = fncls__3249 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3250, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :500:1
func A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A{}; t.Ctor_O_O(p0, p1); return t }
//line :500:1
func (t *A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A) Ctor_O_O(c__iter__711000405, c__s__711000406 any) { t.F_iter__711000405 = c__iter__711000405; t.F_s__711000406 = c__s__711000406 }
//line :500:1
func (t *A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A) Invoke_O__O(self any) any { { var s__711000406__1 any; var t_ any = t.F_s__711000406; t.F_s__711000406 = nil; s__711000406__1 = t_; for { var temp__1927000414__auto____2 any; var root_3165 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3167 lang.IFn; if linked_3166 == nil { ifn_3167 = lang.IFn_Cast(root_3165) } else { ifn_3167 = nil }; var arg_3168 any = s__711000406__1; if linked_3166 == nil { temp__1927000414__auto____2 = ifn_3167.Invoke_O__O(arg_3168) } else { temp__1927000414__auto____2 = linked_3166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3165, arg_3168) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000406__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3169 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3169, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3171 lang.IFn; if linked_3170 == nil { ifn_3171 = lang.IFn_Cast(root_3169) } else { ifn_3171 = nil }; var arg_3172 any = s__711000406__3; if linked_3170 == nil { tmp1 = ifn_3171.Invoke_O__O(arg_3172) } else { tmp1 = linked_3170.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3169, arg_3172) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3173 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3173, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3175 lang.IFn; if linked_3174 == nil { ifn_3175 = lang.IFn_Cast(root_3173) } else { ifn_3175 = nil }; var arg_3176 any = s__711000406__3; if linked_3174 == nil { c__1927001037__auto____4 = ifn_3175.Invoke_O__O(arg_3176) } else { c__1927001037__auto____4 = linked_3174.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3173, arg_3176) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000408__6 any; var root_3177 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3177, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3179 lang.IFn; if linked_3178 == nil { ifn_3179 = lang.IFn_Cast(root_3177) } else { ifn_3179 = nil }; var arg_3180 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3178 == nil { b__711000408__6 = ifn_3179.Invoke_O__O(arg_3180) } else { b__711000408__6 = linked_3178.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3177, arg_3180) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3200 any = A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A_New_O_I_O(b__711000408__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3199 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A_fn_class; if fncls__3199 == nil { var fncls__3199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__3200); A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A_fn_class = fncls__3199d; tmp3 = fncls__3199d } else { tmp3 = fncls__3199 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3200, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3201 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3201, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3203 lang.IFn; if linked_3202 == nil { ifn_3203 = lang.IFn_Cast(root_3201) } else { ifn_3203 = nil }; var arg_3204 any; var root_3206 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3206, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3208 lang.IFn; if linked_3207 == nil { ifn_3208 = lang.IFn_Cast(root_3206) } else { ifn_3208 = nil }; var arg_3209 any = b__711000408__6; if linked_3207 == nil { arg_3204 = ifn_3208.Invoke_O__O(arg_3209) } else { arg_3204 = linked_3207.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3206, arg_3209) }; var arg_3205 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000405); var tmp5 any; var root_3210 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3210, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3212 lang.IFn; if linked_3211 == nil { ifn_3212 = lang.IFn_Cast(root_3210) } else { ifn_3212 = nil }; var arg_3213 any = s__711000406__3; if linked_3211 == nil { tmp5 = ifn_3212.Invoke_O__O(arg_3213) } else { tmp5 = linked_3211.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3210, arg_3213) }; arg_3205 = tmp4.Invoke_O__O(tmp5); if linked_3202 == nil { return ifn_3203.Invoke_O_O__O(arg_3204, arg_3205) } else { return linked_3202.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3201, arg_3204, arg_3205) } } else { var root_3214 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3214, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3216 lang.IFn; if linked_3215 == nil { ifn_3216 = lang.IFn_Cast(root_3214) } else { ifn_3216 = nil }; var arg_3217 any; var root_3219 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3219, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3221 lang.IFn; if linked_3220 == nil { ifn_3221 = lang.IFn_Cast(root_3219) } else { ifn_3221 = nil }; var arg_3222 any = b__711000408__6; if linked_3220 == nil { arg_3217 = ifn_3221.Invoke_O__O(arg_3222) } else { arg_3217 = linked_3220.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3219, arg_3222) }; var arg_3218 any; if linked_3215 == nil { return ifn_3216.Invoke_O_O__O(arg_3217, arg_3218) } else { return linked_3215.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3214, arg_3217, arg_3218) } } } else { var j__4 any; var root_3223 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3223, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3225 lang.IFn; if linked_3224 == nil { ifn_3225 = lang.IFn_Cast(root_3223) } else { ifn_3225 = nil }; var arg_3226 any = s__711000406__3; if linked_3224 == nil { j__4 = ifn_3225.Invoke_O__O(arg_3226) } else { j__4 = linked_3224.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3223, arg_3226) }; var root_3227 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3227, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3229 lang.IFn; if linked_3228 == nil { ifn_3229 = lang.IFn_Cast(root_3227) } else { ifn_3229 = nil }; var arg_3230 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_347; var tmp8 any; var root_3232 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3232, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3234 lang.IFn; if linked_3233 == nil { ifn_3234 = lang.IFn_Cast(root_3232) } else { ifn_3234 = nil }; var arg_3235 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_92, nil); var tmp10 any; var root_3236 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_3237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3236, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3238 lang.IFn; if linked_3237 == nil { ifn_3238 = lang.IFn_Cast(root_3236) } else { ifn_3238 = nil }; var arg_3239 any = j__4; if linked_3237 == nil { tmp10 = ifn_3238.Invoke_O__O(arg_3239) } else { tmp10 = linked_3237.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3236, arg_3239) }; arg_3235 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3233 == nil { tmp8 = ifn_3234.Invoke_O__O(arg_3235) } else { tmp8 = linked_3233.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3232, arg_3235) }; var tmp11 any = tmp8; var tmp12 any; var root_3240 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3240, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3242 lang.IFn; if linked_3241 == nil { ifn_3242 = lang.IFn_Cast(root_3240) } else { ifn_3242 = nil }; var arg_3243 any = A_arbace_j2g_dyn_A_const_348; var arg_3244 any = A_arbace_j2g_dyn_A_const_350; if linked_3241 == nil { tmp12 = ifn_3242.Invoke_O_O__O(arg_3243, arg_3244) } else { tmp12 = linked_3241.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3240, arg_3243, arg_3244) }; arg_3230 = tmp6.Invoke_O_O_O__O(tmp7, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12)); var arg_3231 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000405); var tmp14 any; var root_3245 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3245, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3247 lang.IFn; if linked_3246 == nil { ifn_3247 = lang.IFn_Cast(root_3245) } else { ifn_3247 = nil }; var arg_3248 any = s__711000406__3; if linked_3246 == nil { tmp14 = ifn_3247.Invoke_O__O(arg_3248) } else { tmp14 = linked_3246.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3245, arg_3248) }; arg_3231 = tmp13.Invoke_O__O(tmp14); if linked_3228 == nil { return ifn_3229.Invoke_O_O__O(arg_3230, arg_3231) } else { return linked_3228.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3227, arg_3230, arg_3231) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :500:1
func A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :500:1
func (t *A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A) Ctor_O_I_O(c__b__711000408 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000408 = c__b__711000408; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :500:1
func (t *A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A) Invoke_O__O(self any) any { { var i__711000407__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000407__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000407__1)); var root_3181 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3181, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3183 lang.IFn; if linked_3182 == nil { ifn_3183 = lang.IFn_Cast(root_3181) } else { ifn_3183 = nil }; var arg_3184 any = t.F_b__711000408; var arg_3185 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_347; var tmp4 any; var root_3186 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3186, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3188 lang.IFn; if linked_3187 == nil { ifn_3188 = lang.IFn_Cast(root_3186) } else { ifn_3188 = nil }; var arg_3189 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_92, nil); var tmp6 any; var root_3190 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_3191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3190, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3192 lang.IFn; if linked_3191 == nil { ifn_3192 = lang.IFn_Cast(root_3190) } else { ifn_3192 = nil }; var arg_3193 any = j__2; if linked_3191 == nil { tmp6 = ifn_3192.Invoke_O__O(arg_3193) } else { tmp6 = linked_3191.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3190, arg_3193) }; arg_3189 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_3187 == nil { tmp4 = ifn_3188.Invoke_O__O(arg_3189) } else { tmp4 = linked_3187.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3186, arg_3189) }; var tmp7 any = tmp4; var tmp8 any; var root_3194 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var linked_3195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3194, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3196 lang.IFn; if linked_3195 == nil { ifn_3196 = lang.IFn_Cast(root_3194) } else { ifn_3196 = nil }; var arg_3197 any = A_arbace_j2g_dyn_A_const_348; var arg_3198 any = A_arbace_j2g_dyn_A_const_349; if linked_3195 == nil { tmp8 = ifn_3196.Invoke_O_O__O(arg_3197, arg_3198) } else { tmp8 = linked_3195.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3194, arg_3197, arg_3198) }; arg_3185 = tmp2.Invoke_O_O_O__O(tmp3, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8)); if linked_3182 == nil { ifn_3183.Invoke_O_O__O(arg_3184, arg_3185) } else { linked_3182.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3181, arg_3184, arg_3185) }; i__711000407__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000407__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_forms_fn__711000415_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000415_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000415_A{}; t.Ctor_O_O(p0, p1); return t }
//line :503:1
func (t *A_arbace_j2g_dyn_forms_fn__711000415_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :503:1
func (t *A_arbace_j2g_dyn_forms_fn__711000415_A) Invoke_O_O__O(self, i__1 any) any { var root_3262 any = A_arbace_j2g_dyn_A_const_159.GetRawRoot__O(); var linked_3263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3262, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_3264 lang.IFn; if linked_3263 == nil { ifn_3264 = lang.IFn_Cast(root_3262) } else { ifn_3264 = nil }; var arg_3265 any = t.F_ifaces; var arg_3266 any = i__1; var tmp1 any = t.F_ks; var arg_3267 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(i__1)); if linked_3263 == nil { return ifn_3264.Invoke_O_O_O__O(arg_3265, arg_3266, arg_3267) } else { return linked_3263.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O__O(root_3262, arg_3265, arg_3266, arg_3267) } }








































































































































































































func A_arbace_j2g_dyn_forms_iter__711000417__711000421_A_New() *A_arbace_j2g_dyn_forms_iter__711000417__711000421_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000417__711000421_A{}; t.Ctor(); return t }
//line :704:1
func (t *A_arbace_j2g_dyn_forms_iter__711000417__711000421_A) Ctor() {}
//line :704:1
func (t *A_arbace_j2g_dyn_forms_iter__711000417__711000421_A) Invoke_O_O__O(self, s__711000418__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3729 any = A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A_New_O_O(self, s__711000418__1); var tmp2 *jrt.Class; var fncls__3728 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A_fn_class; if fncls__3728 == nil { var fncls__3728d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__3729); A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A_fn_class = fncls__3728d; tmp2 = fncls__3728d } else { tmp2 = fncls__3728 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3729, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :704:1
func A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A{}; t.Ctor_O_O(p0, p1); return t }
//line :704:1
func (t *A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A) Ctor_O_O(c__iter__711000417, c__s__711000418 any) { t.F_iter__711000417 = c__iter__711000417; t.F_s__711000418 = c__s__711000418 }
//line :704:1
func (t *A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A) Invoke_O__O(self any) any { { var s__711000418__1 any; var t_ any = t.F_s__711000418; t.F_s__711000418 = nil; s__711000418__1 = t_; for { var temp__1927000414__auto____2 any; var root_3610 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3610, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3612 lang.IFn; if linked_3611 == nil { ifn_3612 = lang.IFn_Cast(root_3610) } else { ifn_3612 = nil }; var arg_3613 any = s__711000418__1; if linked_3611 == nil { temp__1927000414__auto____2 = ifn_3612.Invoke_O__O(arg_3613) } else { temp__1927000414__auto____2 = linked_3611.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3610, arg_3613) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000418__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3614 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3614, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3616 lang.IFn; if linked_3615 == nil { ifn_3616 = lang.IFn_Cast(root_3614) } else { ifn_3616 = nil }; var arg_3617 any = s__711000418__3; if linked_3615 == nil { tmp1 = ifn_3616.Invoke_O__O(arg_3617) } else { tmp1 = linked_3615.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3614, arg_3617) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3618 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3618, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3620 lang.IFn; if linked_3619 == nil { ifn_3620 = lang.IFn_Cast(root_3618) } else { ifn_3620 = nil }; var arg_3621 any = s__711000418__3; if linked_3619 == nil { c__1927001037__auto____4 = ifn_3620.Invoke_O__O(arg_3621) } else { c__1927001037__auto____4 = linked_3619.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3618, arg_3621) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000420__6 any; var root_3622 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3622, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3624 lang.IFn; if linked_3623 == nil { ifn_3624 = lang.IFn_Cast(root_3622) } else { ifn_3624 = nil }; var arg_3625 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3623 == nil { b__711000420__6 = ifn_3624.Invoke_O__O(arg_3625) } else { b__711000420__6 = linked_3623.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3622, arg_3625) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__3662 any = A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A_New_O_I_O(b__711000420__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3661 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A_fn_class; if fncls__3661 == nil { var fncls__3661d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__3662); A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A_fn_class = fncls__3661d; tmp3 = fncls__3661d } else { tmp3 = fncls__3661 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3662, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_3663 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3663, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3665 lang.IFn; if linked_3664 == nil { ifn_3665 = lang.IFn_Cast(root_3663) } else { ifn_3665 = nil }; var arg_3666 any; var root_3668 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3668, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3670 lang.IFn; if linked_3669 == nil { ifn_3670 = lang.IFn_Cast(root_3668) } else { ifn_3670 = nil }; var arg_3671 any = b__711000420__6; if linked_3669 == nil { arg_3666 = ifn_3670.Invoke_O__O(arg_3671) } else { arg_3666 = linked_3669.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3668, arg_3671) }; var arg_3667 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000417); var tmp5 any; var root_3672 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3672, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3674 lang.IFn; if linked_3673 == nil { ifn_3674 = lang.IFn_Cast(root_3672) } else { ifn_3674 = nil }; var arg_3675 any = s__711000418__3; if linked_3673 == nil { tmp5 = ifn_3674.Invoke_O__O(arg_3675) } else { tmp5 = linked_3673.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3672, arg_3675) }; arg_3667 = tmp4.Invoke_O__O(tmp5); if linked_3664 == nil { return ifn_3665.Invoke_O_O__O(arg_3666, arg_3667) } else { return linked_3664.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3663, arg_3666, arg_3667) } } else { var root_3676 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3676, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3678 lang.IFn; if linked_3677 == nil { ifn_3678 = lang.IFn_Cast(root_3676) } else { ifn_3678 = nil }; var arg_3679 any; var root_3681 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3681, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3683 lang.IFn; if linked_3682 == nil { ifn_3683 = lang.IFn_Cast(root_3681) } else { ifn_3683 = nil }; var arg_3684 any = b__711000420__6; if linked_3682 == nil { arg_3679 = ifn_3683.Invoke_O__O(arg_3684) } else { arg_3679 = linked_3682.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3681, arg_3684) }; var arg_3680 any; if linked_3677 == nil { return ifn_3678.Invoke_O_O__O(arg_3679, arg_3680) } else { return linked_3677.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3676, arg_3679, arg_3680) } } } else { var p__4 any; var root_3685 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3685, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3687 lang.IFn; if linked_3686 == nil { ifn_3687 = lang.IFn_Cast(root_3685) } else { ifn_3687 = nil }; var arg_3688 any = s__711000418__3; if linked_3686 == nil { p__4 = ifn_3687.Invoke_O__O(arg_3688) } else { p__4 = linked_3686.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3685, arg_3688) }; var root_3689 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3689, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3691 lang.IFn; if linked_3690 == nil { ifn_3691 = lang.IFn_Cast(root_3689) } else { ifn_3691 = nil }; var arg_3692 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_489; var tmp8 any; var root_3694 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3694, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3696 lang.IFn
													if linked_3695 == nil { ifn_3696 = lang.IFn_Cast(root_3694) } else { ifn_3696 = nil }; var arg_3697 any = A_arbace_j2g_dyn_A_const_73; var arg_3698 any = p__4; var arg_3699 any = Lit_25; if linked_3695 == nil { tmp8 = ifn_3696.Invoke_O_O_O__O(arg_3697, arg_3698, arg_3699) } else { tmp8 = linked_3695.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3694, arg_3697, arg_3698, arg_3699) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_490; var tmp12 any; var root_3700 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3700, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3702 lang.IFn
													if linked_3701 == nil { ifn_3702 = lang.IFn_Cast(root_3700) } else { ifn_3702 = nil }; var arg_3703 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_95, nil); var tmp14 any; var root_3704 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3704, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3706 lang.IFn; if linked_3705 == nil { ifn_3706 = lang.IFn_Cast(root_3704) } else { ifn_3706 = nil }; var arg_3707 any = p__4; if linked_3705 == nil { tmp14 = ifn_3706.Invoke_O__O(arg_3707) } else { tmp14 = linked_3705.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3704, arg_3707) }; arg_3703 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3701 == nil { tmp12 = ifn_3702.Invoke_O__O(arg_3703) } else { tmp12 = linked_3701.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3700, arg_3703) }
//line :705:1
	var tmp15 any = tmp12; var tmp16 any; var root_3708 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3708, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3710 lang.IFn
	if linked_3709 == nil { ifn_3710 = lang.IFn_Cast(root_3708) } else { ifn_3710 = nil }; var arg_3711 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil); var tmp18 any; var root_3712 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3712, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3714 lang.IFn; if linked_3713 == nil { ifn_3714 = lang.IFn_Cast(root_3712) } else { ifn_3714 = nil }; var arg_3715 any = p__4; if linked_3713 == nil { tmp18 = ifn_3714.Invoke_O__O(arg_3715) } else { tmp18 = linked_3713.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3712, arg_3715) }; arg_3711 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3709 == nil { tmp16 = ifn_3710.Invoke_O__O(arg_3711) } else { tmp16 = linked_3709.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3708, arg_3711) }
//line :705:1
	var tmp19 any = tmp16; var tmp20 any; var root_3716 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3716, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3718 lang.IFn

	if linked_3717 == nil { ifn_3718 = lang.IFn_Cast(root_3716) } else { ifn_3718 = nil }; var arg_3719 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_96, nil); var tmp22 any; var root_3720 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3720, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3722 lang.IFn; if linked_3721 == nil { ifn_3722 = lang.IFn_Cast(root_3720) } else { ifn_3722 = nil }; var arg_3723 any = p__4; if linked_3721 == nil { tmp22 = ifn_3722.Invoke_O__O(arg_3723) } else { tmp22 = linked_3721.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3720, arg_3723) }; arg_3719 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref(); if linked_3717 == nil { tmp20 = ifn_3718.Invoke_O__O(arg_3719) } else { tmp20 = linked_3717.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3716, arg_3719) }
//line :705:1
	arg_3692 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp15, tmp19, tmp20))
//line :704:1
	var arg_3693 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000417); var tmp24 any; var root_3724 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3724, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3726 lang.IFn; if linked_3725 == nil { ifn_3726 = lang.IFn_Cast(root_3724) } else { ifn_3726 = nil }; var arg_3727 any = s__711000418__3; if linked_3725 == nil { tmp24 = ifn_3726.Invoke_O__O(arg_3727) } else { tmp24 = linked_3725.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3724, arg_3727) }; arg_3693 = tmp23.Invoke_O__O(tmp24); if linked_3690 == nil { return ifn_3691.Invoke_O_O__O(arg_3692, arg_3693) } else { return linked_3690.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3689, arg_3692, arg_3693) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :704:1
func A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :704:1
func (t *A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A) Ctor_O_I_O(c__b__711000420 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000420 = c__b__711000420; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :704:1
func (t *A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A) Invoke_O__O(self any) any { { var i__711000419__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000419__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000419__1)); var root_3626 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3626, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3628 lang.IFn; if linked_3627 == nil { ifn_3628 = lang.IFn_Cast(root_3626) } else { ifn_3628 = nil }; var arg_3629 any = t.F_b__711000420; var arg_3630 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_489; var tmp4 any; var root_3631 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3631, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3633 lang.IFn
															if linked_3632 == nil { ifn_3633 = lang.IFn_Cast(root_3631) } else { ifn_3633 = nil }; var arg_3634 any = A_arbace_j2g_dyn_A_const_73; var arg_3635 any = p__2; var arg_3636 any = Lit_25; if linked_3632 == nil { tmp4 = ifn_3633.Invoke_O_O_O__O(arg_3634, arg_3635, arg_3636) } else { tmp4 = linked_3632.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3631, arg_3634, arg_3635, arg_3636) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_490; var tmp8 any; var root_3637 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3637, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3639 lang.IFn
															if linked_3638 == nil { ifn_3639 = lang.IFn_Cast(root_3637) } else { ifn_3639 = nil }; var arg_3640 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_95, nil); var tmp10 any; var root_3641 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3641, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3643 lang.IFn; if linked_3642 == nil { ifn_3643 = lang.IFn_Cast(root_3641) } else { ifn_3643 = nil }; var arg_3644 any = p__2; if linked_3642 == nil { tmp10 = ifn_3643.Invoke_O__O(arg_3644) } else { tmp10 = linked_3642.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3641, arg_3644) }; arg_3640 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3638 == nil { tmp8 = ifn_3639.Invoke_O__O(arg_3640) } else { tmp8 = linked_3638.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3637, arg_3640) }
//line :705:1
	var tmp11 any = tmp8; var tmp12 any; var root_3645 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3645, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3647 lang.IFn
	if linked_3646 == nil { ifn_3647 = lang.IFn_Cast(root_3645) } else { ifn_3647 = nil }; var arg_3648 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil); var tmp14 any; var root_3649 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3649, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3651 lang.IFn; if linked_3650 == nil { ifn_3651 = lang.IFn_Cast(root_3649) } else { ifn_3651 = nil }; var arg_3652 any = p__2; if linked_3650 == nil { tmp14 = ifn_3651.Invoke_O__O(arg_3652) } else { tmp14 = linked_3650.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3649, arg_3652) }; arg_3648 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3646 == nil { tmp12 = ifn_3647.Invoke_O__O(arg_3648) } else { tmp12 = linked_3646.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3645, arg_3648) }
//line :705:1
	var tmp15 any = tmp12; var tmp16 any; var root_3653 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_3654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3653, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3655 lang.IFn

	if linked_3654 == nil { ifn_3655 = lang.IFn_Cast(root_3653) } else { ifn_3655 = nil }; var arg_3656 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_96, nil); var tmp18 any; var root_3657 any = A_arbace_j2g_dyn_A_const_189.GetRawRoot__O(); var linked_3658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3657, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3659 lang.IFn; if linked_3658 == nil { ifn_3659 = lang.IFn_Cast(root_3657) } else { ifn_3659 = nil }; var arg_3660 any = p__2; if linked_3658 == nil { tmp18 = ifn_3659.Invoke_O__O(arg_3660) } else { tmp18 = linked_3658.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3657, arg_3660) }; arg_3656 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3654 == nil { tmp16 = ifn_3655.Invoke_O__O(arg_3656) } else { tmp16 = linked_3654.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3653, arg_3656) }
//line :705:1
	arg_3630 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp11, tmp15, tmp16))
//line :704:1
	if linked_3627 == nil { ifn_3628.Invoke_O_O__O(arg_3629, arg_3630) } else { linked_3627.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3626, arg_3629, arg_3630) }; i__711000419__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000419__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































func A_arbace_j2g_dyn_forms_fn__711000427_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000427_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000427_A{}; t.Ctor_O_O(p0, p1); return t }
//line :746:1
func (t *A_arbace_j2g_dyn_forms_fn__711000427_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :746:1
func (t *A_arbace_j2g_dyn_forms_fn__711000427_A) Invoke_O_O__O(self, p1__711000382_SHARP___1 any) any { var root_3784 any = A_arbace_j2g_dyn_A_const_520.GetRawRoot__O(); var linked_3785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3784, A_arbace_j2g_dyn_sub_forms_A_fn_class); var ifn_3786 lang.IFn; if linked_3785 == nil { ifn_3786 = lang.IFn_Cast(root_3784) } else { ifn_3786 = nil }; var arg_3787 any = p1__711000382_SHARP___1; var arg_3788 any = t.F_ifaces; var arg_3789 any = t.F_ks; if linked_3785 == nil { return ifn_3786.Invoke_O_O_O__O(arg_3787, arg_3788, arg_3789) } else { return linked_3785.(*A_arbace_j2g_dyn_sub_forms_A).Invoke_O_O_O_O__O(root_3784, arg_3787, arg_3788, arg_3789) } }

































type A_arbace_j2g_dyn_A struct{ jrt.Object }

var A_arbace_j2g_dyn_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyn_A_const_0 *lang.Var

var A_arbace_j2g_dyn_A_const_1 any

var A_arbace_j2g_dyn_A_const_2 any

var A_arbace_j2g_dyn_A_const_3 any

var A_arbace_j2g_dyn_A_const_4 any

var A_arbace_j2g_dyn_A_const_5 any

var A_arbace_j2g_dyn_A_const_6 any

var A_arbace_j2g_dyn_A_const_7 any

var A_arbace_j2g_dyn_A_const_8 any

var A_arbace_j2g_dyn_A_const_9 *lang.Var

var A_arbace_j2g_dyn_A_const_10 any

var A_arbace_j2g_dyn_A_const_11 *lang.Var

var A_arbace_j2g_dyn_A_const_12 *lang.Var

var A_arbace_j2g_dyn_A_const_13 *lang.Var

var A_arbace_j2g_dyn_A_const_14 *lang.Var

var A_arbace_j2g_dyn_A_const_15 any

var A_arbace_j2g_dyn_A_const_16 *lang.Var

var A_arbace_j2g_dyn_A_const_17 *lang.Keyword

var A_arbace_j2g_dyn_A_const_18 *lang.Var

var A_arbace_j2g_dyn_A_const_19 *lang.Var

var A_arbace_j2g_dyn_A_const_20 *lang.Var

var A_arbace_j2g_dyn_A_const_21 *lang.Var

var A_arbace_j2g_dyn_A_const_22 *lang.Var

var A_arbace_j2g_dyn_A_const_23 *lang.Var

var A_arbace_j2g_dyn_A_const_24 *lang.Var

var A_arbace_j2g_dyn_A_const_25 *lang.Var

var A_arbace_j2g_dyn_A_const_26 *lang.Var

var A_arbace_j2g_dyn_A_const_27 *lang.Var

var A_arbace_j2g_dyn_A_const_28 *lang.Var

var A_arbace_j2g_dyn_A_const_29 *lang.Var

var A_arbace_j2g_dyn_A_const_30 *lang.Var

var A_arbace_j2g_dyn_A_const_31 *lang.Var

var A_arbace_j2g_dyn_A_const_32 *lang.Var

var A_arbace_j2g_dyn_A_const_33 *lang.Keyword

var A_arbace_j2g_dyn_A_const_34 *lang.Var

var A_arbace_j2g_dyn_A_const_35 *lang.Var

var A_arbace_j2g_dyn_A_const_36 *lang.Var

var A_arbace_j2g_dyn_A_const_37 *lang.Var

var A_arbace_j2g_dyn_A_const_38 *lang.Var

var A_arbace_j2g_dyn_A_const_39 *lang.Var

var A_arbace_j2g_dyn_A_const_40 *lang.Var

var A_arbace_j2g_dyn_A_const_41 *lang.Var

var A_arbace_j2g_dyn_A_const_42 *lang.Var

var A_arbace_j2g_dyn_A_const_43 *lang.Var

var A_arbace_j2g_dyn_A_const_44 *lang.Var

var A_arbace_j2g_dyn_A_const_45 *lang.Keyword

var A_arbace_j2g_dyn_A_const_46 *lang.Keyword

var A_arbace_j2g_dyn_A_const_47 *lang.Var

var A_arbace_j2g_dyn_A_const_48 *lang.Var

var A_arbace_j2g_dyn_A_const_49 *lang.Var

var A_arbace_j2g_dyn_A_const_50 *lang.Var

var A_arbace_j2g_dyn_A_const_51 *lang.Keyword

var A_arbace_j2g_dyn_A_const_52 *lang.Var

var A_arbace_j2g_dyn_A_const_53 *lang.Var

var A_arbace_j2g_dyn_A_const_54 *lang.Var

var A_arbace_j2g_dyn_A_const_55 *lang.Var

var A_arbace_j2g_dyn_A_const_56 *lang.Var

var A_arbace_j2g_dyn_A_const_57 *lang.Var

var A_arbace_j2g_dyn_A_const_58 *lang.Var

var A_arbace_j2g_dyn_A_const_59 *lang.Var

var A_arbace_j2g_dyn_A_const_60 *lang.Var

var A_arbace_j2g_dyn_A_const_61 *lang.Var

var A_arbace_j2g_dyn_A_const_62 *lang.Var

var A_arbace_j2g_dyn_A_const_63 *lang.Var

var A_arbace_j2g_dyn_A_const_64 *lang.Keyword

var A_arbace_j2g_dyn_A_const_65 *lang.Keyword

var A_arbace_j2g_dyn_A_const_66 *lang.Var

var A_arbace_j2g_dyn_A_const_67 *lang.Var

var A_arbace_j2g_dyn_A_const_68 *lang.Var

var A_arbace_j2g_dyn_A_const_69 *lang.Keyword

var A_arbace_j2g_dyn_A_const_70 *lang.Keyword

var A_arbace_j2g_dyn_A_const_71 *lang.Keyword

var A_arbace_j2g_dyn_A_const_72 *lang.Var

var A_arbace_j2g_dyn_A_const_73 *lang.Keyword

var A_arbace_j2g_dyn_A_const_74 *lang.Var

var A_arbace_j2g_dyn_A_const_75 *lang.Var

var A_arbace_j2g_dyn_A_const_76 *lang.Var

var A_arbace_j2g_dyn_A_const_77 *lang.Var

var A_arbace_j2g_dyn_A_const_78 *lang.Var

var A_arbace_j2g_dyn_A_const_79 *lang.Var

var A_arbace_j2g_dyn_A_const_80 *lang.Var

var A_arbace_j2g_dyn_A_const_81 *lang.Keyword

var A_arbace_j2g_dyn_A_const_82 any

var A_arbace_j2g_dyn_A_const_83 any

var A_arbace_j2g_dyn_A_const_84 any

var A_arbace_j2g_dyn_A_const_85 *lang.Var

var A_arbace_j2g_dyn_A_const_86 *lang.Var

var A_arbace_j2g_dyn_A_const_87 *lang.Keyword

var A_arbace_j2g_dyn_A_const_88 *lang.Var

var A_arbace_j2g_dyn_A_const_89 *lang.Var

var A_arbace_j2g_dyn_A_const_90 any

var A_arbace_j2g_dyn_A_const_91 *lang.Var

var A_arbace_j2g_dyn_A_const_92 *lang.Var

var A_arbace_j2g_dyn_A_const_93 *lang.Var

var A_arbace_j2g_dyn_A_const_94 any

var A_arbace_j2g_dyn_A_const_95 *lang.Var

var A_arbace_j2g_dyn_A_const_96 any

var A_arbace_j2g_dyn_A_const_97 any

var A_arbace_j2g_dyn_A_const_98 any

var A_arbace_j2g_dyn_A_const_99 *lang.Var

var A_arbace_j2g_dyn_A_const_100 *lang.Var

var A_arbace_j2g_dyn_A_const_101 *lang.Var

var A_arbace_j2g_dyn_A_const_102 any

var A_arbace_j2g_dyn_A_const_103 any

var A_arbace_j2g_dyn_A_const_104 any

var A_arbace_j2g_dyn_A_const_105 any

var A_arbace_j2g_dyn_A_const_106 any

var A_arbace_j2g_dyn_A_const_107 any

var A_arbace_j2g_dyn_A_const_108 *lang.Var

var A_arbace_j2g_dyn_A_const_109 any

var A_arbace_j2g_dyn_A_const_110 *lang.Var

var A_arbace_j2g_dyn_A_const_111 *lang.Var

var A_arbace_j2g_dyn_A_const_112 *lang.Keyword

var A_arbace_j2g_dyn_A_const_113 *lang.Var

var A_arbace_j2g_dyn_A_const_114 *lang.Var

var A_arbace_j2g_dyn_A_const_115 *lang.Var

var A_arbace_j2g_dyn_A_const_116 *lang.Var

var A_arbace_j2g_dyn_A_const_117 *lang.Var

var A_arbace_j2g_dyn_A_const_118 any

var A_arbace_j2g_dyn_A_const_119 any

var A_arbace_j2g_dyn_A_const_120 any

var A_arbace_j2g_dyn_A_const_121 any

var A_arbace_j2g_dyn_A_const_122 any

var A_arbace_j2g_dyn_A_const_123 any

var A_arbace_j2g_dyn_A_const_124 any

var A_arbace_j2g_dyn_A_const_125 any

var A_arbace_j2g_dyn_A_const_126 any

var A_arbace_j2g_dyn_A_const_127 any

var A_arbace_j2g_dyn_A_const_128 any

var A_arbace_j2g_dyn_A_const_129 *lang.Var

var A_arbace_j2g_dyn_A_const_130 any

var A_arbace_j2g_dyn_A_const_131 any

var A_arbace_j2g_dyn_A_const_132 any

var A_arbace_j2g_dyn_A_const_133 *lang.Var

var A_arbace_j2g_dyn_A_const_134 *lang.Var

var A_arbace_j2g_dyn_A_const_135 *lang.Var

var A_arbace_j2g_dyn_A_const_136 *lang.Var

var A_arbace_j2g_dyn_A_const_137 any

var A_arbace_j2g_dyn_A_const_138 *lang.Var

var A_arbace_j2g_dyn_A_const_139 any

var A_arbace_j2g_dyn_A_const_140 any

var A_arbace_j2g_dyn_A_const_141 any

var A_arbace_j2g_dyn_A_const_142 any

var A_arbace_j2g_dyn_A_const_143 any

var A_arbace_j2g_dyn_A_const_144 any

var A_arbace_j2g_dyn_A_const_145 any

var A_arbace_j2g_dyn_A_const_146 any

var A_arbace_j2g_dyn_A_const_147 any

var A_arbace_j2g_dyn_A_const_148 any

var A_arbace_j2g_dyn_A_const_149 any

var A_arbace_j2g_dyn_A_const_150 any

var A_arbace_j2g_dyn_A_const_151 any

var A_arbace_j2g_dyn_A_const_152 any

var A_arbace_j2g_dyn_A_const_153 any

var A_arbace_j2g_dyn_A_const_154 any

var A_arbace_j2g_dyn_A_const_155 any

var A_arbace_j2g_dyn_A_const_156 any

var A_arbace_j2g_dyn_A_const_157 *lang.Var

var A_arbace_j2g_dyn_A_const_158 any

var A_arbace_j2g_dyn_A_const_159 *lang.Var

var A_arbace_j2g_dyn_A_const_160 any

var A_arbace_j2g_dyn_A_const_161 any

var A_arbace_j2g_dyn_A_const_162 any

var A_arbace_j2g_dyn_A_const_163 *lang.Var

var A_arbace_j2g_dyn_A_const_164 *lang.Var

var A_arbace_j2g_dyn_A_const_165 *lang.Var

var A_arbace_j2g_dyn_A_const_166 *lang.Var

var A_arbace_j2g_dyn_A_const_167 *lang.Var

var A_arbace_j2g_dyn_A_const_168 *lang.Var

var A_arbace_j2g_dyn_A_const_169 any

var A_arbace_j2g_dyn_A_const_170 any

var A_arbace_j2g_dyn_A_const_171 any

var A_arbace_j2g_dyn_A_const_172 any

var A_arbace_j2g_dyn_A_const_173 any

var A_arbace_j2g_dyn_A_const_174 any

var A_arbace_j2g_dyn_A_const_175 any

var A_arbace_j2g_dyn_A_const_176 any

var A_arbace_j2g_dyn_A_const_177 any

var A_arbace_j2g_dyn_A_const_178 any

var A_arbace_j2g_dyn_A_const_179 *lang.Keyword

var A_arbace_j2g_dyn_A_const_180 *lang.Keyword

var A_arbace_j2g_dyn_A_const_181 *lang.Keyword

var A_arbace_j2g_dyn_A_const_182 any

var A_arbace_j2g_dyn_A_const_183 any

var A_arbace_j2g_dyn_A_const_184 any

var A_arbace_j2g_dyn_A_const_185 any

var A_arbace_j2g_dyn_A_const_186 any

var A_arbace_j2g_dyn_A_const_187 any

var A_arbace_j2g_dyn_A_const_188 any

var A_arbace_j2g_dyn_A_const_189 *lang.Var

var A_arbace_j2g_dyn_A_const_190 any

var A_arbace_j2g_dyn_A_const_191 any

var A_arbace_j2g_dyn_A_const_192 any

var A_arbace_j2g_dyn_A_const_193 *lang.Var

var A_arbace_j2g_dyn_A_const_194 *lang.Var

var A_arbace_j2g_dyn_A_const_195 *lang.Var

var A_arbace_j2g_dyn_A_const_196 *lang.Var

var A_arbace_j2g_dyn_A_const_197 any

var A_arbace_j2g_dyn_A_const_198 any

var A_arbace_j2g_dyn_A_const_199 any

var A_arbace_j2g_dyn_A_const_200 any

var A_arbace_j2g_dyn_A_const_201 any

var A_arbace_j2g_dyn_A_const_202 any

var A_arbace_j2g_dyn_A_const_203 any

var A_arbace_j2g_dyn_A_const_204 any

var A_arbace_j2g_dyn_A_const_205 *lang.Var

var A_arbace_j2g_dyn_A_const_206 *lang.Var

var A_arbace_j2g_dyn_A_const_207 *lang.Var

var A_arbace_j2g_dyn_A_const_208 *lang.Var

var A_arbace_j2g_dyn_A_const_209 any

var A_arbace_j2g_dyn_A_const_210 any

var A_arbace_j2g_dyn_A_const_211 *lang.Keyword

var A_arbace_j2g_dyn_A_const_212 any

var A_arbace_j2g_dyn_A_const_213 any

var A_arbace_j2g_dyn_A_const_214 *lang.Var

var A_arbace_j2g_dyn_A_const_215 *lang.Keyword

var A_arbace_j2g_dyn_A_const_216 any

var A_arbace_j2g_dyn_A_const_217 *lang.Keyword

var A_arbace_j2g_dyn_A_const_218 *lang.Var

var A_arbace_j2g_dyn_A_const_219 any

var A_arbace_j2g_dyn_A_const_220 any

var A_arbace_j2g_dyn_A_const_221 any

var A_arbace_j2g_dyn_A_const_222 any

var A_arbace_j2g_dyn_A_const_223 *lang.Var

var A_arbace_j2g_dyn_A_const_224 any

var A_arbace_j2g_dyn_A_const_225 any

var A_arbace_j2g_dyn_A_const_226 any

var A_arbace_j2g_dyn_A_const_227 any

var A_arbace_j2g_dyn_A_const_228 any

var A_arbace_j2g_dyn_A_const_229 *lang.Var

var A_arbace_j2g_dyn_A_const_230 any

var A_arbace_j2g_dyn_A_const_231 any

var A_arbace_j2g_dyn_A_const_232 any

var A_arbace_j2g_dyn_A_const_233 any

var A_arbace_j2g_dyn_A_const_234 any

var A_arbace_j2g_dyn_A_const_235 any

var A_arbace_j2g_dyn_A_const_236 *lang.Keyword

var A_arbace_j2g_dyn_A_const_237 any

var A_arbace_j2g_dyn_A_const_238 any

var A_arbace_j2g_dyn_A_const_239 any

var A_arbace_j2g_dyn_A_const_240 any

var A_arbace_j2g_dyn_A_const_241 any

var A_arbace_j2g_dyn_A_const_242 any

var A_arbace_j2g_dyn_A_const_243 any

var A_arbace_j2g_dyn_A_const_244 *lang.Var

var A_arbace_j2g_dyn_A_const_245 *lang.Var

var A_arbace_j2g_dyn_A_const_246 *lang.Var

var A_arbace_j2g_dyn_A_const_247 *lang.Var

var A_arbace_j2g_dyn_A_const_248 any

var A_arbace_j2g_dyn_A_const_249 any

var A_arbace_j2g_dyn_A_const_250 any

var A_arbace_j2g_dyn_A_const_251 any

var A_arbace_j2g_dyn_A_const_252 any

var A_arbace_j2g_dyn_A_const_253 any

var A_arbace_j2g_dyn_A_const_254 any

var A_arbace_j2g_dyn_A_const_255 any

var A_arbace_j2g_dyn_A_const_256 any

var A_arbace_j2g_dyn_A_const_257 any

var A_arbace_j2g_dyn_A_const_258 any

var A_arbace_j2g_dyn_A_const_259 any

var A_arbace_j2g_dyn_A_const_260 any

var A_arbace_j2g_dyn_A_const_261 any

var A_arbace_j2g_dyn_A_const_262 any

var A_arbace_j2g_dyn_A_const_263 any

var A_arbace_j2g_dyn_A_const_264 any

var A_arbace_j2g_dyn_A_const_265 any

var A_arbace_j2g_dyn_A_const_266 any

var A_arbace_j2g_dyn_A_const_267 any

var A_arbace_j2g_dyn_A_const_268 any

var A_arbace_j2g_dyn_A_const_269 any

var A_arbace_j2g_dyn_A_const_270 any

var A_arbace_j2g_dyn_A_const_271 any

var A_arbace_j2g_dyn_A_const_272 any

var A_arbace_j2g_dyn_A_const_273 any

var A_arbace_j2g_dyn_A_const_274 any

var A_arbace_j2g_dyn_A_const_275 any

var A_arbace_j2g_dyn_A_const_276 any

var A_arbace_j2g_dyn_A_const_277 any

var A_arbace_j2g_dyn_A_const_278 any

var A_arbace_j2g_dyn_A_const_279 any

var A_arbace_j2g_dyn_A_const_280 any

var A_arbace_j2g_dyn_A_const_281 *lang.Var

var A_arbace_j2g_dyn_A_const_282 any

var A_arbace_j2g_dyn_A_const_283 any

var A_arbace_j2g_dyn_A_const_284 *lang.Var

var A_arbace_j2g_dyn_A_const_285 *lang.Var

var A_arbace_j2g_dyn_A_const_286 *lang.Var

var A_arbace_j2g_dyn_A_const_287 any

var A_arbace_j2g_dyn_A_const_288 any

var A_arbace_j2g_dyn_A_const_289 *lang.Var

var A_arbace_j2g_dyn_A_const_290 any

var A_arbace_j2g_dyn_A_const_291 any

var A_arbace_j2g_dyn_A_const_292 any

var A_arbace_j2g_dyn_A_const_293 any

var A_arbace_j2g_dyn_A_const_294 any

var A_arbace_j2g_dyn_A_const_295 any

var A_arbace_j2g_dyn_A_const_296 any

var A_arbace_j2g_dyn_A_const_297 any

var A_arbace_j2g_dyn_A_const_298 any

var A_arbace_j2g_dyn_A_const_299 any

var A_arbace_j2g_dyn_A_const_300 any

var A_arbace_j2g_dyn_A_const_301 any

var A_arbace_j2g_dyn_A_const_302 any

var A_arbace_j2g_dyn_A_const_303 any

var A_arbace_j2g_dyn_A_const_304 any

var A_arbace_j2g_dyn_A_const_305 *lang.Var

var A_arbace_j2g_dyn_A_const_306 *lang.Var

var A_arbace_j2g_dyn_A_const_307 any

var A_arbace_j2g_dyn_A_const_308 any

var A_arbace_j2g_dyn_A_const_309 any

var A_arbace_j2g_dyn_A_const_310 any

var A_arbace_j2g_dyn_A_const_311 any

var A_arbace_j2g_dyn_A_const_312 any

var A_arbace_j2g_dyn_A_const_313 any

var A_arbace_j2g_dyn_A_const_314 any

var A_arbace_j2g_dyn_A_const_315 any

var A_arbace_j2g_dyn_A_const_316 any

var A_arbace_j2g_dyn_A_const_317 any

var A_arbace_j2g_dyn_A_const_318 any

var A_arbace_j2g_dyn_A_const_319 any

var A_arbace_j2g_dyn_A_const_320 any

var A_arbace_j2g_dyn_A_const_321 any

var A_arbace_j2g_dyn_A_const_322 any

var A_arbace_j2g_dyn_A_const_323 any

var A_arbace_j2g_dyn_A_const_324 any

var A_arbace_j2g_dyn_A_const_325 any

var A_arbace_j2g_dyn_A_const_326 any

var A_arbace_j2g_dyn_A_const_327 any

var A_arbace_j2g_dyn_A_const_328 any

var A_arbace_j2g_dyn_A_const_329 any

var A_arbace_j2g_dyn_A_const_330 any

var A_arbace_j2g_dyn_A_const_331 any

var A_arbace_j2g_dyn_A_const_332 any

var A_arbace_j2g_dyn_A_const_333 any

var A_arbace_j2g_dyn_A_const_334 any

var A_arbace_j2g_dyn_A_const_335 any

var A_arbace_j2g_dyn_A_const_336 any

var A_arbace_j2g_dyn_A_const_337 any

var A_arbace_j2g_dyn_A_const_338 any

var A_arbace_j2g_dyn_A_const_339 any

var A_arbace_j2g_dyn_A_const_340 any

var A_arbace_j2g_dyn_A_const_341 any

var A_arbace_j2g_dyn_A_const_342 any

var A_arbace_j2g_dyn_A_const_343 any

var A_arbace_j2g_dyn_A_const_344 any

var A_arbace_j2g_dyn_A_const_345 any

var A_arbace_j2g_dyn_A_const_346 any

var A_arbace_j2g_dyn_A_const_347 any

var A_arbace_j2g_dyn_A_const_348 any

var A_arbace_j2g_dyn_A_const_349 any

var A_arbace_j2g_dyn_A_const_350 any

var A_arbace_j2g_dyn_A_const_351 *lang.Var

var A_arbace_j2g_dyn_A_const_352 *lang.Var

var A_arbace_j2g_dyn_A_const_353 any

var A_arbace_j2g_dyn_A_const_354 any

var A_arbace_j2g_dyn_A_const_355 *lang.Var

var A_arbace_j2g_dyn_A_const_356 *lang.Var

var A_arbace_j2g_dyn_A_const_357 any

var A_arbace_j2g_dyn_A_const_358 any

var A_arbace_j2g_dyn_A_const_359 any

var A_arbace_j2g_dyn_A_const_360 *lang.Var

var A_arbace_j2g_dyn_A_const_361 any

var A_arbace_j2g_dyn_A_const_362 any

var A_arbace_j2g_dyn_A_const_363 any

var A_arbace_j2g_dyn_A_const_364 any

var A_arbace_j2g_dyn_A_const_365 any

var A_arbace_j2g_dyn_A_const_366 any

var A_arbace_j2g_dyn_A_const_367 any

var A_arbace_j2g_dyn_A_const_368 any

var A_arbace_j2g_dyn_A_const_369 any

var A_arbace_j2g_dyn_A_const_370 any

var A_arbace_j2g_dyn_A_const_371 any

var A_arbace_j2g_dyn_A_const_372 any

var A_arbace_j2g_dyn_A_const_373 any

var A_arbace_j2g_dyn_A_const_374 any

var A_arbace_j2g_dyn_A_const_375 any

var A_arbace_j2g_dyn_A_const_376 any

var A_arbace_j2g_dyn_A_const_377 any

var A_arbace_j2g_dyn_A_const_378 any

var A_arbace_j2g_dyn_A_const_379 any

var A_arbace_j2g_dyn_A_const_380 any

var A_arbace_j2g_dyn_A_const_381 *lang.Keyword

var A_arbace_j2g_dyn_A_const_382 *lang.Keyword

var A_arbace_j2g_dyn_A_const_383 any

var A_arbace_j2g_dyn_A_const_384 *lang.Keyword

var A_arbace_j2g_dyn_A_const_385 any

var A_arbace_j2g_dyn_A_const_386 *lang.Keyword

var A_arbace_j2g_dyn_A_const_387 any

var A_arbace_j2g_dyn_A_const_388 any

var A_arbace_j2g_dyn_A_const_389 any

var A_arbace_j2g_dyn_A_const_390 any

var A_arbace_j2g_dyn_A_const_391 any

var A_arbace_j2g_dyn_A_const_392 any

var A_arbace_j2g_dyn_A_const_393 any

var A_arbace_j2g_dyn_A_const_394 any

var A_arbace_j2g_dyn_A_const_395 any

var A_arbace_j2g_dyn_A_const_396 any

var A_arbace_j2g_dyn_A_const_397 any

var A_arbace_j2g_dyn_A_const_398 any

var A_arbace_j2g_dyn_A_const_399 any

var A_arbace_j2g_dyn_A_const_400 any

var A_arbace_j2g_dyn_A_const_401 any

var A_arbace_j2g_dyn_A_const_402 any

var A_arbace_j2g_dyn_A_const_403 any

var A_arbace_j2g_dyn_A_const_404 any

var A_arbace_j2g_dyn_A_const_405 any

var A_arbace_j2g_dyn_A_const_406 any

var A_arbace_j2g_dyn_A_const_407 any

var A_arbace_j2g_dyn_A_const_408 any

var A_arbace_j2g_dyn_A_const_409 any

var A_arbace_j2g_dyn_A_const_410 any

var A_arbace_j2g_dyn_A_const_411 any

var A_arbace_j2g_dyn_A_const_412 any

var A_arbace_j2g_dyn_A_const_413 any

var A_arbace_j2g_dyn_A_const_414 any

var A_arbace_j2g_dyn_A_const_415 any

var A_arbace_j2g_dyn_A_const_416 any

var A_arbace_j2g_dyn_A_const_417 any

var A_arbace_j2g_dyn_A_const_418 any

var A_arbace_j2g_dyn_A_const_419 any

var A_arbace_j2g_dyn_A_const_420 any

var A_arbace_j2g_dyn_A_const_421 any

var A_arbace_j2g_dyn_A_const_422 any

var A_arbace_j2g_dyn_A_const_423 any

var A_arbace_j2g_dyn_A_const_424 any

var A_arbace_j2g_dyn_A_const_425 any

var A_arbace_j2g_dyn_A_const_426 any

var A_arbace_j2g_dyn_A_const_427 any

var A_arbace_j2g_dyn_A_const_428 any

var A_arbace_j2g_dyn_A_const_429 any

var A_arbace_j2g_dyn_A_const_430 any

var A_arbace_j2g_dyn_A_const_431 any

var A_arbace_j2g_dyn_A_const_432 any

var A_arbace_j2g_dyn_A_const_433 any

var A_arbace_j2g_dyn_A_const_434 any

var A_arbace_j2g_dyn_A_const_435 any

var A_arbace_j2g_dyn_A_const_436 any

var A_arbace_j2g_dyn_A_const_437 any

var A_arbace_j2g_dyn_A_const_438 any

var A_arbace_j2g_dyn_A_const_439 any

var A_arbace_j2g_dyn_A_const_440 any

var A_arbace_j2g_dyn_A_const_441 any

var A_arbace_j2g_dyn_A_const_442 any

var A_arbace_j2g_dyn_A_const_443 any

var A_arbace_j2g_dyn_A_const_444 any

var A_arbace_j2g_dyn_A_const_445 any

var A_arbace_j2g_dyn_A_const_446 any

var A_arbace_j2g_dyn_A_const_447 any

var A_arbace_j2g_dyn_A_const_448 any

var A_arbace_j2g_dyn_A_const_449 any

var A_arbace_j2g_dyn_A_const_450 any

var A_arbace_j2g_dyn_A_const_451 any

var A_arbace_j2g_dyn_A_const_452 any

var A_arbace_j2g_dyn_A_const_453 any

var A_arbace_j2g_dyn_A_const_454 any

var A_arbace_j2g_dyn_A_const_455 any

var A_arbace_j2g_dyn_A_const_456 any

var A_arbace_j2g_dyn_A_const_457 any

var A_arbace_j2g_dyn_A_const_458 any

var A_arbace_j2g_dyn_A_const_459 any

var A_arbace_j2g_dyn_A_const_460 any

var A_arbace_j2g_dyn_A_const_461 any

var A_arbace_j2g_dyn_A_const_462 any

var A_arbace_j2g_dyn_A_const_463 any

var A_arbace_j2g_dyn_A_const_464 any

var A_arbace_j2g_dyn_A_const_465 any

var A_arbace_j2g_dyn_A_const_466 any

var A_arbace_j2g_dyn_A_const_467 any

var A_arbace_j2g_dyn_A_const_468 any

var A_arbace_j2g_dyn_A_const_469 any

var A_arbace_j2g_dyn_A_const_470 any

var A_arbace_j2g_dyn_A_const_471 any

var A_arbace_j2g_dyn_A_const_472 any

var A_arbace_j2g_dyn_A_const_473 any

var A_arbace_j2g_dyn_A_const_474 any

var A_arbace_j2g_dyn_A_const_475 any

var A_arbace_j2g_dyn_A_const_476 any

var A_arbace_j2g_dyn_A_const_477 any

var A_arbace_j2g_dyn_A_const_478 any

var A_arbace_j2g_dyn_A_const_479 any

var A_arbace_j2g_dyn_A_const_480 any

var A_arbace_j2g_dyn_A_const_481 any

var A_arbace_j2g_dyn_A_const_482 any

var A_arbace_j2g_dyn_A_const_483 any

var A_arbace_j2g_dyn_A_const_484 any

var A_arbace_j2g_dyn_A_const_485 *lang.Keyword

var A_arbace_j2g_dyn_A_const_486 any

var A_arbace_j2g_dyn_A_const_487 any

var A_arbace_j2g_dyn_A_const_488 any

var A_arbace_j2g_dyn_A_const_489 any

var A_arbace_j2g_dyn_A_const_490 any

var A_arbace_j2g_dyn_A_const_491 *lang.Var

var A_arbace_j2g_dyn_A_const_492 any

var A_arbace_j2g_dyn_A_const_493 any

var A_arbace_j2g_dyn_A_const_494 any

var A_arbace_j2g_dyn_A_const_495 any

var A_arbace_j2g_dyn_A_const_496 any

var A_arbace_j2g_dyn_A_const_497 any

var A_arbace_j2g_dyn_A_const_498 any

var A_arbace_j2g_dyn_A_const_499 any

var A_arbace_j2g_dyn_A_const_500 any

var A_arbace_j2g_dyn_A_const_501 any

var A_arbace_j2g_dyn_A_const_502 any

var A_arbace_j2g_dyn_A_const_503 any

var A_arbace_j2g_dyn_A_const_504 any

var A_arbace_j2g_dyn_A_const_505 any

var A_arbace_j2g_dyn_A_const_506 any

var A_arbace_j2g_dyn_A_const_507 any

var A_arbace_j2g_dyn_A_const_508 any

var A_arbace_j2g_dyn_A_const_509 any

var A_arbace_j2g_dyn_A_const_510 any

var A_arbace_j2g_dyn_A_const_511 any

var A_arbace_j2g_dyn_A_const_512 any

var A_arbace_j2g_dyn_A_const_513 any

var A_arbace_j2g_dyn_A_const_514 any

var A_arbace_j2g_dyn_A_const_515 any

var A_arbace_j2g_dyn_A_const_516 any

var A_arbace_j2g_dyn_A_const_517 any

var A_arbace_j2g_dyn_A_const_518 any

var A_arbace_j2g_dyn_A_const_519 *lang.Var

var A_arbace_j2g_dyn_A_const_520 *lang.Var

var A_arbace_j2g_dyn_A_init jrt.ClassInit

func A_arbace_j2g_dyn_A_Init() { if !A_arbace_j2g_dyn_A_init.Done() { A_arbace_j2g_dyn_A_init.Run(A_arbace_j2g_dyn_A_clinit) } }

func A_arbace_j2g_dyn_A_clinit() { A_arbace_j2g_dyn_A_clinit_p0(); A_arbace_j2g_dyn_A_clinit_p1(); A_arbace_j2g_dyn_A_clinit_p2(); A_arbace_j2g_dyn_A_clinit_p3(); A_arbace_j2g_dyn_A_clinit_p4(); A_arbace_j2g_dyn_A_clinit_p5(); A_arbace_j2g_dyn_A_clinit_p6(); A_arbace_j2g_dyn_A_clinit_p7(); A_arbace_j2g_dyn_A_clinit_p8(); A_arbace_j2g_dyn_A_clinit_p9(); A_arbace_j2g_dyn_A_clinit_p10(); A_arbace_j2g_dyn_A_clinit_p11(); A_arbace_j2g_dyn_A_clinit_p12(); A_arbace_j2g_dyn_A_clinit_p13(); A_arbace_j2g_dyn_A_clinit_p14(); A_arbace_j2g_dyn_A_clinit_p15(); A_arbace_j2g_dyn_A_clinit_p16(); A_arbace_j2g_dyn_A_clinit_p17(); A_arbace_j2g_dyn_A_clinit_p18(); A_arbace_j2g_dyn_A_clinit_p19(); A_arbace_j2g_dyn_A_clinit_p20(); A_arbace_j2g_dyn_A_clinit_p21(); A_arbace_j2g_dyn_A_clinit_p22(); A_arbace_j2g_dyn_A_clinit_p23(); A_arbace_j2g_dyn_A_clinit_p24(); A_arbace_j2g_dyn_A_clinit_p25(); A_arbace_j2g_dyn_A_clinit_p26(); A_arbace_j2g_dyn_A_clinit_p27(); A_arbace_j2g_dyn_A_clinit_p28(); A_arbace_j2g_dyn_A_clinit_p29(); A_arbace_j2g_dyn_A_clinit_p30(); A_arbace_j2g_dyn_A_clinit_p31(); A_arbace_j2g_dyn_A_clinit_p32(); A_arbace_j2g_dyn_A_clinit_p33(); A_arbace_j2g_dyn_A_clinit_p34(); A_arbace_j2g_dyn_A_clinit_p35(); A_arbace_j2g_dyn_A_clinit_p36() }

func A_arbace_j2g_dyn_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 790); A_arbace_j2g_dyn_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[269]); A_arbace_j2g_dyn_A_const_1 = A_arbace_j2g_dyn_A_const_pool.A[270]; A_arbace_j2g_dyn_A_const_2 = A_arbace_j2g_dyn_A_const_pool.A[271]; A_arbace_j2g_dyn_A_const_3 = A_arbace_j2g_dyn_A_const_pool.A[272]; A_arbace_j2g_dyn_A_const_4 = A_arbace_j2g_dyn_A_const_pool.A[273]; A_arbace_j2g_dyn_A_const_5 = A_arbace_j2g_dyn_A_const_pool.A[274]; A_arbace_j2g_dyn_A_const_6 = A_arbace_j2g_dyn_A_const_pool.A[275]; A_arbace_j2g_dyn_A_const_7 = A_arbace_j2g_dyn_A_const_pool.A[276]; A_arbace_j2g_dyn_A_const_8 = A_arbace_j2g_dyn_A_const_pool.A[277]; A_arbace_j2g_dyn_A_const_9 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[278]); A_arbace_j2g_dyn_A_const_10 = A_arbace_j2g_dyn_A_const_pool.A[279]; A_arbace_j2g_dyn_A_const_11 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[280]); A_arbace_j2g_dyn_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[281]) }

func A_arbace_j2g_dyn_A_clinit_p1() { A_arbace_j2g_dyn_A_const_13 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[282]); A_arbace_j2g_dyn_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[283]); A_arbace_j2g_dyn_A_const_15 = A_arbace_j2g_dyn_A_const_pool.A[284]; A_arbace_j2g_dyn_A_const_16 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[285]); A_arbace_j2g_dyn_A_const_17 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[286]); A_arbace_j2g_dyn_A_const_18 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[287]); A_arbace_j2g_dyn_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[288]); A_arbace_j2g_dyn_A_const_20 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[289]); A_arbace_j2g_dyn_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[290]); A_arbace_j2g_dyn_A_const_22 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[291]); A_arbace_j2g_dyn_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[292]); A_arbace_j2g_dyn_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[293]) }

func A_arbace_j2g_dyn_A_clinit_p2() { A_arbace_j2g_dyn_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[294]); A_arbace_j2g_dyn_A_const_26 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[295]); A_arbace_j2g_dyn_A_const_27 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[296]); A_arbace_j2g_dyn_A_const_28 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[297]); A_arbace_j2g_dyn_A_const_29 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[298]); A_arbace_j2g_dyn_A_const_30 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[299]); A_arbace_j2g_dyn_A_const_31 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[300]); A_arbace_j2g_dyn_A_const_32 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[301]); A_arbace_j2g_dyn_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[302]); A_arbace_j2g_dyn_A_const_34 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[303]); A_arbace_j2g_dyn_A_const_35 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[304]); A_arbace_j2g_dyn_A_const_36 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[305]) }

func A_arbace_j2g_dyn_A_clinit_p3() { A_arbace_j2g_dyn_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[306]); A_arbace_j2g_dyn_A_const_38 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[307]); A_arbace_j2g_dyn_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[308]); A_arbace_j2g_dyn_A_const_40 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[309]); A_arbace_j2g_dyn_A_const_41 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[310]); A_arbace_j2g_dyn_A_const_42 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[311]); A_arbace_j2g_dyn_A_const_43 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[312]); A_arbace_j2g_dyn_A_const_44 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[313]); A_arbace_j2g_dyn_A_const_45 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[314]); A_arbace_j2g_dyn_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[315]); A_arbace_j2g_dyn_A_const_47 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[316]); A_arbace_j2g_dyn_A_const_48 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[317]) }

func A_arbace_j2g_dyn_A_clinit_p4() { A_arbace_j2g_dyn_A_const_49 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[318]); A_arbace_j2g_dyn_A_const_50 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[319]); A_arbace_j2g_dyn_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[320]); A_arbace_j2g_dyn_A_const_52 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[321]); A_arbace_j2g_dyn_A_const_53 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[322]); A_arbace_j2g_dyn_A_const_54 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[323]); A_arbace_j2g_dyn_A_const_55 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[324]); A_arbace_j2g_dyn_A_const_56 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[325]); A_arbace_j2g_dyn_A_const_57 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[326]); A_arbace_j2g_dyn_A_const_58 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[327]); A_arbace_j2g_dyn_A_const_59 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[328]); A_arbace_j2g_dyn_A_const_60 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[329]) }

func A_arbace_j2g_dyn_A_clinit_p5() { A_arbace_j2g_dyn_A_const_61 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[330]); A_arbace_j2g_dyn_A_const_62 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[331]); A_arbace_j2g_dyn_A_const_63 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[332]); A_arbace_j2g_dyn_A_const_64 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[333]); A_arbace_j2g_dyn_A_const_65 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[334]); A_arbace_j2g_dyn_A_const_66 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[335]); A_arbace_j2g_dyn_A_const_67 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[336]); A_arbace_j2g_dyn_A_const_68 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[337]); A_arbace_j2g_dyn_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[338]); A_arbace_j2g_dyn_A_const_70 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[339]); A_arbace_j2g_dyn_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[340]); A_arbace_j2g_dyn_A_const_72 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[341]) }

func A_arbace_j2g_dyn_A_clinit_p6() { A_arbace_j2g_dyn_A_const_73 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[342]); A_arbace_j2g_dyn_A_const_74 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[343]); A_arbace_j2g_dyn_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[344]); A_arbace_j2g_dyn_A_const_76 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[345]); A_arbace_j2g_dyn_A_const_77 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[346]); A_arbace_j2g_dyn_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[347]); A_arbace_j2g_dyn_A_const_79 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[348]); A_arbace_j2g_dyn_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[349]); A_arbace_j2g_dyn_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[350]); A_arbace_j2g_dyn_A_const_82 = A_arbace_j2g_dyn_A_const_pool.A[351]; A_arbace_j2g_dyn_A_const_83 = A_arbace_j2g_dyn_A_const_pool.A[352]; A_arbace_j2g_dyn_A_const_84 = A_arbace_j2g_dyn_A_const_pool.A[353] }

func A_arbace_j2g_dyn_A_clinit_p7() { A_arbace_j2g_dyn_A_const_85 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[354]); A_arbace_j2g_dyn_A_const_86 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[355]); A_arbace_j2g_dyn_A_const_87 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[356]); A_arbace_j2g_dyn_A_const_88 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[357]); A_arbace_j2g_dyn_A_const_89 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[358]); A_arbace_j2g_dyn_A_const_90 = A_arbace_j2g_dyn_A_const_pool.A[359]; A_arbace_j2g_dyn_A_const_91 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[360]); A_arbace_j2g_dyn_A_const_92 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[361]); A_arbace_j2g_dyn_A_const_93 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[362]); A_arbace_j2g_dyn_A_const_94 = A_arbace_j2g_dyn_A_const_pool.A[363]; A_arbace_j2g_dyn_A_const_95 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[364]); A_arbace_j2g_dyn_A_const_96 = A_arbace_j2g_dyn_A_const_pool.A[365]; A_arbace_j2g_dyn_A_const_97 = A_arbace_j2g_dyn_A_const_pool.A[366] }

func A_arbace_j2g_dyn_A_clinit_p8() { A_arbace_j2g_dyn_A_const_98 = A_arbace_j2g_dyn_A_const_pool.A[367]; A_arbace_j2g_dyn_A_const_99 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[368]); A_arbace_j2g_dyn_A_const_100 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[369]); A_arbace_j2g_dyn_A_const_101 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[370]); A_arbace_j2g_dyn_A_const_102 = A_arbace_j2g_dyn_A_const_pool.A[371]; A_arbace_j2g_dyn_A_const_103 = A_arbace_j2g_dyn_A_const_pool.A[372]; A_arbace_j2g_dyn_A_const_104 = A_arbace_j2g_dyn_A_const_pool.A[373]; A_arbace_j2g_dyn_A_const_105 = A_arbace_j2g_dyn_A_const_pool.A[374]; A_arbace_j2g_dyn_A_const_106 = A_arbace_j2g_dyn_A_const_pool.A[375]; A_arbace_j2g_dyn_A_const_107 = A_arbace_j2g_dyn_A_const_pool.A[376]; A_arbace_j2g_dyn_A_const_108 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[377]); A_arbace_j2g_dyn_A_const_109 = A_arbace_j2g_dyn_A_const_pool.A[378]; A_arbace_j2g_dyn_A_const_110 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[379]); A_arbace_j2g_dyn_A_const_111 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[380]) }

func A_arbace_j2g_dyn_A_clinit_p9() { A_arbace_j2g_dyn_A_const_112 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[381]); A_arbace_j2g_dyn_A_const_113 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[382]); A_arbace_j2g_dyn_A_const_114 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[383]); A_arbace_j2g_dyn_A_const_115 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[384]); A_arbace_j2g_dyn_A_const_116 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[385]); A_arbace_j2g_dyn_A_const_117 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[386]); A_arbace_j2g_dyn_A_const_118 = A_arbace_j2g_dyn_A_const_pool.A[387]; A_arbace_j2g_dyn_A_const_119 = A_arbace_j2g_dyn_A_const_pool.A[388]; A_arbace_j2g_dyn_A_const_120 = A_arbace_j2g_dyn_A_const_pool.A[389]; A_arbace_j2g_dyn_A_const_121 = A_arbace_j2g_dyn_A_const_pool.A[390]; A_arbace_j2g_dyn_A_const_122 = A_arbace_j2g_dyn_A_const_pool.A[391]; A_arbace_j2g_dyn_A_const_123 = A_arbace_j2g_dyn_A_const_pool.A[392]; A_arbace_j2g_dyn_A_const_124 = A_arbace_j2g_dyn_A_const_pool.A[393]; A_arbace_j2g_dyn_A_const_125 = A_arbace_j2g_dyn_A_const_pool.A[394] }

func A_arbace_j2g_dyn_A_clinit_p10() { A_arbace_j2g_dyn_A_const_126 = A_arbace_j2g_dyn_A_const_pool.A[395]; A_arbace_j2g_dyn_A_const_127 = A_arbace_j2g_dyn_A_const_pool.A[396]; A_arbace_j2g_dyn_A_const_128 = A_arbace_j2g_dyn_A_const_pool.A[397]; A_arbace_j2g_dyn_A_const_129 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[398]); A_arbace_j2g_dyn_A_const_130 = A_arbace_j2g_dyn_A_const_pool.A[399]; A_arbace_j2g_dyn_A_const_131 = A_arbace_j2g_dyn_A_const_pool.A[400]; A_arbace_j2g_dyn_A_const_132 = A_arbace_j2g_dyn_A_const_pool.A[401]; A_arbace_j2g_dyn_A_const_133 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[402]); A_arbace_j2g_dyn_A_const_134 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[403]); A_arbace_j2g_dyn_A_const_135 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[404]); A_arbace_j2g_dyn_A_const_136 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[405]); A_arbace_j2g_dyn_A_const_137 = A_arbace_j2g_dyn_A_const_pool.A[406]; A_arbace_j2g_dyn_A_const_138 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[407]); A_arbace_j2g_dyn_A_const_139 = A_arbace_j2g_dyn_A_const_pool.A[408] }

func A_arbace_j2g_dyn_A_clinit_p11() { A_arbace_j2g_dyn_A_const_140 = A_arbace_j2g_dyn_A_const_pool.A[409]; A_arbace_j2g_dyn_A_const_141 = A_arbace_j2g_dyn_A_const_pool.A[410]; A_arbace_j2g_dyn_A_const_142 = A_arbace_j2g_dyn_A_const_pool.A[411]; A_arbace_j2g_dyn_A_const_143 = A_arbace_j2g_dyn_A_const_pool.A[412]; A_arbace_j2g_dyn_A_const_144 = A_arbace_j2g_dyn_A_const_pool.A[413]; A_arbace_j2g_dyn_A_const_145 = A_arbace_j2g_dyn_A_const_pool.A[414]; A_arbace_j2g_dyn_A_const_146 = A_arbace_j2g_dyn_A_const_pool.A[415]; A_arbace_j2g_dyn_A_const_147 = A_arbace_j2g_dyn_A_const_pool.A[416]; A_arbace_j2g_dyn_A_const_148 = A_arbace_j2g_dyn_A_const_pool.A[417]; A_arbace_j2g_dyn_A_const_149 = A_arbace_j2g_dyn_A_const_pool.A[418]; A_arbace_j2g_dyn_A_const_150 = A_arbace_j2g_dyn_A_const_pool.A[419]; A_arbace_j2g_dyn_A_const_151 = A_arbace_j2g_dyn_A_const_pool.A[420]; A_arbace_j2g_dyn_A_const_152 = A_arbace_j2g_dyn_A_const_pool.A[421]; A_arbace_j2g_dyn_A_const_153 = A_arbace_j2g_dyn_A_const_pool.A[422]; A_arbace_j2g_dyn_A_const_154 = A_arbace_j2g_dyn_A_const_pool.A[423]; A_arbace_j2g_dyn_A_const_155 = A_arbace_j2g_dyn_A_const_pool.A[424] }

func A_arbace_j2g_dyn_A_clinit_p12() { A_arbace_j2g_dyn_A_const_156 = A_arbace_j2g_dyn_A_const_pool.A[425]; A_arbace_j2g_dyn_A_const_157 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[426]); A_arbace_j2g_dyn_A_const_158 = A_arbace_j2g_dyn_A_const_pool.A[427]; A_arbace_j2g_dyn_A_const_159 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[428]); A_arbace_j2g_dyn_A_const_160 = A_arbace_j2g_dyn_A_const_pool.A[429]; A_arbace_j2g_dyn_A_const_161 = A_arbace_j2g_dyn_A_const_pool.A[430]; A_arbace_j2g_dyn_A_const_162 = A_arbace_j2g_dyn_A_const_pool.A[431]; A_arbace_j2g_dyn_A_const_163 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[432]); A_arbace_j2g_dyn_A_const_164 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[433]); A_arbace_j2g_dyn_A_const_165 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[434]); A_arbace_j2g_dyn_A_const_166 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[435]); A_arbace_j2g_dyn_A_const_167 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[436]); A_arbace_j2g_dyn_A_const_168 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[437]) }

func A_arbace_j2g_dyn_A_clinit_p13() { A_arbace_j2g_dyn_A_const_169 = A_arbace_j2g_dyn_A_const_pool.A[438]; A_arbace_j2g_dyn_A_const_170 = A_arbace_j2g_dyn_A_const_pool.A[439]; A_arbace_j2g_dyn_A_const_171 = A_arbace_j2g_dyn_A_const_pool.A[440]; A_arbace_j2g_dyn_A_const_172 = A_arbace_j2g_dyn_A_const_pool.A[441]; A_arbace_j2g_dyn_A_const_173 = A_arbace_j2g_dyn_A_const_pool.A[442]; A_arbace_j2g_dyn_A_const_174 = A_arbace_j2g_dyn_A_const_pool.A[443]; A_arbace_j2g_dyn_A_const_175 = A_arbace_j2g_dyn_A_const_pool.A[444]; A_arbace_j2g_dyn_A_const_176 = A_arbace_j2g_dyn_A_const_pool.A[445]; A_arbace_j2g_dyn_A_const_177 = A_arbace_j2g_dyn_A_const_pool.A[446]; A_arbace_j2g_dyn_A_const_178 = A_arbace_j2g_dyn_A_const_pool.A[447]; A_arbace_j2g_dyn_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[448]); A_arbace_j2g_dyn_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[449]); A_arbace_j2g_dyn_A_const_181 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[450]); A_arbace_j2g_dyn_A_const_182 = A_arbace_j2g_dyn_A_const_pool.A[451]; A_arbace_j2g_dyn_A_const_183 = A_arbace_j2g_dyn_A_const_pool.A[452] }

func A_arbace_j2g_dyn_A_clinit_p14() { A_arbace_j2g_dyn_A_const_184 = A_arbace_j2g_dyn_A_const_pool.A[453]; A_arbace_j2g_dyn_A_const_185 = A_arbace_j2g_dyn_A_const_pool.A[454]; A_arbace_j2g_dyn_A_const_186 = A_arbace_j2g_dyn_A_const_pool.A[455]; A_arbace_j2g_dyn_A_const_187 = A_arbace_j2g_dyn_A_const_pool.A[456]; A_arbace_j2g_dyn_A_const_188 = A_arbace_j2g_dyn_A_const_pool.A[457]; A_arbace_j2g_dyn_A_const_189 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[458]); A_arbace_j2g_dyn_A_const_190 = A_arbace_j2g_dyn_A_const_pool.A[459]; A_arbace_j2g_dyn_A_const_191 = A_arbace_j2g_dyn_A_const_pool.A[460]; A_arbace_j2g_dyn_A_const_192 = A_arbace_j2g_dyn_A_const_pool.A[461]; A_arbace_j2g_dyn_A_const_193 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[462]); A_arbace_j2g_dyn_A_const_194 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[463]); A_arbace_j2g_dyn_A_const_195 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[464]); A_arbace_j2g_dyn_A_const_196 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[465]); A_arbace_j2g_dyn_A_const_197 = A_arbace_j2g_dyn_A_const_pool.A[466] }

func A_arbace_j2g_dyn_A_clinit_p15() { A_arbace_j2g_dyn_A_const_198 = A_arbace_j2g_dyn_A_const_pool.A[467]; A_arbace_j2g_dyn_A_const_199 = A_arbace_j2g_dyn_A_const_pool.A[468]; A_arbace_j2g_dyn_A_const_200 = A_arbace_j2g_dyn_A_const_pool.A[469]; A_arbace_j2g_dyn_A_const_201 = A_arbace_j2g_dyn_A_const_pool.A[470]; A_arbace_j2g_dyn_A_const_202 = A_arbace_j2g_dyn_A_const_pool.A[471]; A_arbace_j2g_dyn_A_const_203 = A_arbace_j2g_dyn_A_const_pool.A[472]; A_arbace_j2g_dyn_A_const_204 = A_arbace_j2g_dyn_A_const_pool.A[473]; A_arbace_j2g_dyn_A_const_205 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[474]); A_arbace_j2g_dyn_A_const_206 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[475]); A_arbace_j2g_dyn_A_const_207 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[476]); A_arbace_j2g_dyn_A_const_208 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[477]); A_arbace_j2g_dyn_A_const_209 = A_arbace_j2g_dyn_A_const_pool.A[478]; A_arbace_j2g_dyn_A_const_210 = A_arbace_j2g_dyn_A_const_pool.A[479]; A_arbace_j2g_dyn_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[480]) }

func A_arbace_j2g_dyn_A_clinit_p16() { A_arbace_j2g_dyn_A_const_212 = A_arbace_j2g_dyn_A_const_pool.A[481]; A_arbace_j2g_dyn_A_const_213 = A_arbace_j2g_dyn_A_const_pool.A[482]; A_arbace_j2g_dyn_A_const_214 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[483]); A_arbace_j2g_dyn_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[484]); A_arbace_j2g_dyn_A_const_216 = A_arbace_j2g_dyn_A_const_pool.A[485]; A_arbace_j2g_dyn_A_const_217 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[486]); A_arbace_j2g_dyn_A_const_218 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[487]); A_arbace_j2g_dyn_A_const_219 = A_arbace_j2g_dyn_A_const_pool.A[488]; A_arbace_j2g_dyn_A_const_220 = A_arbace_j2g_dyn_A_const_pool.A[489]; A_arbace_j2g_dyn_A_const_221 = A_arbace_j2g_dyn_A_const_pool.A[490]; A_arbace_j2g_dyn_A_const_222 = A_arbace_j2g_dyn_A_const_pool.A[491]; A_arbace_j2g_dyn_A_const_223 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[492]); A_arbace_j2g_dyn_A_const_224 = A_arbace_j2g_dyn_A_const_pool.A[493]; A_arbace_j2g_dyn_A_const_225 = A_arbace_j2g_dyn_A_const_pool.A[494] }

func A_arbace_j2g_dyn_A_clinit_p17() { A_arbace_j2g_dyn_A_const_226 = A_arbace_j2g_dyn_A_const_pool.A[495]; A_arbace_j2g_dyn_A_const_227 = A_arbace_j2g_dyn_A_const_pool.A[496]; A_arbace_j2g_dyn_A_const_228 = A_arbace_j2g_dyn_A_const_pool.A[497]; A_arbace_j2g_dyn_A_const_229 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[498]); A_arbace_j2g_dyn_A_const_230 = A_arbace_j2g_dyn_A_const_pool.A[499]; A_arbace_j2g_dyn_A_const_231 = A_arbace_j2g_dyn_A_const_pool.A[500]; A_arbace_j2g_dyn_A_const_232 = A_arbace_j2g_dyn_A_const_pool.A[501]; A_arbace_j2g_dyn_A_const_233 = A_arbace_j2g_dyn_A_const_pool.A[502]; A_arbace_j2g_dyn_A_const_234 = A_arbace_j2g_dyn_A_const_pool.A[503]; A_arbace_j2g_dyn_A_const_235 = A_arbace_j2g_dyn_A_const_pool.A[504]; A_arbace_j2g_dyn_A_const_236 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[505]); A_arbace_j2g_dyn_A_const_237 = A_arbace_j2g_dyn_A_const_pool.A[506]; A_arbace_j2g_dyn_A_const_238 = A_arbace_j2g_dyn_A_const_pool.A[507]; A_arbace_j2g_dyn_A_const_239 = A_arbace_j2g_dyn_A_const_pool.A[508]; A_arbace_j2g_dyn_A_const_240 = A_arbace_j2g_dyn_A_const_pool.A[509] }

func A_arbace_j2g_dyn_A_clinit_p18() { A_arbace_j2g_dyn_A_const_241 = A_arbace_j2g_dyn_A_const_pool.A[510]; A_arbace_j2g_dyn_A_const_242 = A_arbace_j2g_dyn_A_const_pool.A[511]; A_arbace_j2g_dyn_A_const_243 = A_arbace_j2g_dyn_A_const_pool.A[512]; A_arbace_j2g_dyn_A_const_244 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[513]); A_arbace_j2g_dyn_A_const_245 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[514]); A_arbace_j2g_dyn_A_const_246 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[515]); A_arbace_j2g_dyn_A_const_247 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[516]); A_arbace_j2g_dyn_A_const_248 = A_arbace_j2g_dyn_A_const_pool.A[517]; A_arbace_j2g_dyn_A_const_249 = A_arbace_j2g_dyn_A_const_pool.A[518]; A_arbace_j2g_dyn_A_const_250 = A_arbace_j2g_dyn_A_const_pool.A[519]; A_arbace_j2g_dyn_A_const_251 = A_arbace_j2g_dyn_A_const_pool.A[520]; A_arbace_j2g_dyn_A_const_252 = A_arbace_j2g_dyn_A_const_pool.A[521]; A_arbace_j2g_dyn_A_const_253 = A_arbace_j2g_dyn_A_const_pool.A[522]; A_arbace_j2g_dyn_A_const_254 = A_arbace_j2g_dyn_A_const_pool.A[523] }

func A_arbace_j2g_dyn_A_clinit_p19() { A_arbace_j2g_dyn_A_const_255 = A_arbace_j2g_dyn_A_const_pool.A[524]; A_arbace_j2g_dyn_A_const_256 = A_arbace_j2g_dyn_A_const_pool.A[525]; A_arbace_j2g_dyn_A_const_257 = A_arbace_j2g_dyn_A_const_pool.A[526]; A_arbace_j2g_dyn_A_const_258 = A_arbace_j2g_dyn_A_const_pool.A[527]; A_arbace_j2g_dyn_A_const_259 = A_arbace_j2g_dyn_A_const_pool.A[528]; A_arbace_j2g_dyn_A_const_260 = A_arbace_j2g_dyn_A_const_pool.A[529]; A_arbace_j2g_dyn_A_const_261 = A_arbace_j2g_dyn_A_const_pool.A[530]; A_arbace_j2g_dyn_A_const_262 = A_arbace_j2g_dyn_A_const_pool.A[531]; A_arbace_j2g_dyn_A_const_263 = A_arbace_j2g_dyn_A_const_pool.A[532]; A_arbace_j2g_dyn_A_const_264 = A_arbace_j2g_dyn_A_const_pool.A[533]; A_arbace_j2g_dyn_A_const_265 = A_arbace_j2g_dyn_A_const_pool.A[534]; A_arbace_j2g_dyn_A_const_266 = A_arbace_j2g_dyn_A_const_pool.A[535]; A_arbace_j2g_dyn_A_const_267 = A_arbace_j2g_dyn_A_const_pool.A[536]; A_arbace_j2g_dyn_A_const_268 = A_arbace_j2g_dyn_A_const_pool.A[537]; A_arbace_j2g_dyn_A_const_269 = A_arbace_j2g_dyn_A_const_pool.A[538]; A_arbace_j2g_dyn_A_const_270 = A_arbace_j2g_dyn_A_const_pool.A[539] }

func A_arbace_j2g_dyn_A_clinit_p20() { A_arbace_j2g_dyn_A_const_271 = A_arbace_j2g_dyn_A_const_pool.A[540]; A_arbace_j2g_dyn_A_const_272 = A_arbace_j2g_dyn_A_const_pool.A[541]; A_arbace_j2g_dyn_A_const_273 = A_arbace_j2g_dyn_A_const_pool.A[542]; A_arbace_j2g_dyn_A_const_274 = A_arbace_j2g_dyn_A_const_pool.A[543]; A_arbace_j2g_dyn_A_const_275 = A_arbace_j2g_dyn_A_const_pool.A[544]; A_arbace_j2g_dyn_A_const_276 = A_arbace_j2g_dyn_A_const_pool.A[545]; A_arbace_j2g_dyn_A_const_277 = A_arbace_j2g_dyn_A_const_pool.A[546]; A_arbace_j2g_dyn_A_const_278 = A_arbace_j2g_dyn_A_const_pool.A[547]; A_arbace_j2g_dyn_A_const_279 = A_arbace_j2g_dyn_A_const_pool.A[548]; A_arbace_j2g_dyn_A_const_280 = A_arbace_j2g_dyn_A_const_pool.A[549]; A_arbace_j2g_dyn_A_const_281 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[550]); A_arbace_j2g_dyn_A_const_282 = A_arbace_j2g_dyn_A_const_pool.A[551]; A_arbace_j2g_dyn_A_const_283 = A_arbace_j2g_dyn_A_const_pool.A[552]; A_arbace_j2g_dyn_A_const_284 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[553]); A_arbace_j2g_dyn_A_const_285 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[554]) }

func A_arbace_j2g_dyn_A_clinit_p21() { A_arbace_j2g_dyn_A_const_286 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[555]); A_arbace_j2g_dyn_A_const_287 = A_arbace_j2g_dyn_A_const_pool.A[556]; A_arbace_j2g_dyn_A_const_288 = A_arbace_j2g_dyn_A_const_pool.A[557]; A_arbace_j2g_dyn_A_const_289 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[558]); A_arbace_j2g_dyn_A_const_290 = A_arbace_j2g_dyn_A_const_pool.A[559]; A_arbace_j2g_dyn_A_const_291 = A_arbace_j2g_dyn_A_const_pool.A[560]; A_arbace_j2g_dyn_A_const_292 = A_arbace_j2g_dyn_A_const_pool.A[561]; A_arbace_j2g_dyn_A_const_293 = A_arbace_j2g_dyn_A_const_pool.A[562]; A_arbace_j2g_dyn_A_const_294 = A_arbace_j2g_dyn_A_const_pool.A[563]; A_arbace_j2g_dyn_A_const_295 = A_arbace_j2g_dyn_A_const_pool.A[564]; A_arbace_j2g_dyn_A_const_296 = A_arbace_j2g_dyn_A_const_pool.A[565]; A_arbace_j2g_dyn_A_const_297 = A_arbace_j2g_dyn_A_const_pool.A[566]; A_arbace_j2g_dyn_A_const_298 = A_arbace_j2g_dyn_A_const_pool.A[567]; A_arbace_j2g_dyn_A_const_299 = A_arbace_j2g_dyn_A_const_pool.A[568]; A_arbace_j2g_dyn_A_const_300 = A_arbace_j2g_dyn_A_const_pool.A[569] }

func A_arbace_j2g_dyn_A_clinit_p22() { A_arbace_j2g_dyn_A_const_301 = A_arbace_j2g_dyn_A_const_pool.A[570]; A_arbace_j2g_dyn_A_const_302 = A_arbace_j2g_dyn_A_const_pool.A[571]; A_arbace_j2g_dyn_A_const_303 = A_arbace_j2g_dyn_A_const_pool.A[572]; A_arbace_j2g_dyn_A_const_304 = A_arbace_j2g_dyn_A_const_pool.A[573]; A_arbace_j2g_dyn_A_const_305 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[574]); A_arbace_j2g_dyn_A_const_306 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[575]); A_arbace_j2g_dyn_A_const_307 = A_arbace_j2g_dyn_A_const_pool.A[576]; A_arbace_j2g_dyn_A_const_308 = A_arbace_j2g_dyn_A_const_pool.A[577]; A_arbace_j2g_dyn_A_const_309 = A_arbace_j2g_dyn_A_const_pool.A[578]; A_arbace_j2g_dyn_A_const_310 = A_arbace_j2g_dyn_A_const_pool.A[579]; A_arbace_j2g_dyn_A_const_311 = A_arbace_j2g_dyn_A_const_pool.A[580]; A_arbace_j2g_dyn_A_const_312 = A_arbace_j2g_dyn_A_const_pool.A[581]; A_arbace_j2g_dyn_A_const_313 = A_arbace_j2g_dyn_A_const_pool.A[582]; A_arbace_j2g_dyn_A_const_314 = A_arbace_j2g_dyn_A_const_pool.A[583]; A_arbace_j2g_dyn_A_const_315 = A_arbace_j2g_dyn_A_const_pool.A[584] }

func A_arbace_j2g_dyn_A_clinit_p23() { A_arbace_j2g_dyn_A_const_316 = A_arbace_j2g_dyn_A_const_pool.A[585]; A_arbace_j2g_dyn_A_const_317 = A_arbace_j2g_dyn_A_const_pool.A[586]; A_arbace_j2g_dyn_A_const_318 = A_arbace_j2g_dyn_A_const_pool.A[587]; A_arbace_j2g_dyn_A_const_319 = A_arbace_j2g_dyn_A_const_pool.A[588]; A_arbace_j2g_dyn_A_const_320 = A_arbace_j2g_dyn_A_const_pool.A[589]; A_arbace_j2g_dyn_A_const_321 = A_arbace_j2g_dyn_A_const_pool.A[590]; A_arbace_j2g_dyn_A_const_322 = A_arbace_j2g_dyn_A_const_pool.A[591]; A_arbace_j2g_dyn_A_const_323 = A_arbace_j2g_dyn_A_const_pool.A[592]; A_arbace_j2g_dyn_A_const_324 = A_arbace_j2g_dyn_A_const_pool.A[593]; A_arbace_j2g_dyn_A_const_325 = A_arbace_j2g_dyn_A_const_pool.A[594]; A_arbace_j2g_dyn_A_const_326 = A_arbace_j2g_dyn_A_const_pool.A[595]; A_arbace_j2g_dyn_A_const_327 = A_arbace_j2g_dyn_A_const_pool.A[596]; A_arbace_j2g_dyn_A_const_328 = A_arbace_j2g_dyn_A_const_pool.A[597]; A_arbace_j2g_dyn_A_const_329 = A_arbace_j2g_dyn_A_const_pool.A[598]; A_arbace_j2g_dyn_A_const_330 = A_arbace_j2g_dyn_A_const_pool.A[599]; A_arbace_j2g_dyn_A_const_331 = A_arbace_j2g_dyn_A_const_pool.A[600] }

func A_arbace_j2g_dyn_A_clinit_p24() { A_arbace_j2g_dyn_A_const_332 = A_arbace_j2g_dyn_A_const_pool.A[601]; A_arbace_j2g_dyn_A_const_333 = A_arbace_j2g_dyn_A_const_pool.A[602]; A_arbace_j2g_dyn_A_const_334 = A_arbace_j2g_dyn_A_const_pool.A[603]; A_arbace_j2g_dyn_A_const_335 = A_arbace_j2g_dyn_A_const_pool.A[604]; A_arbace_j2g_dyn_A_const_336 = A_arbace_j2g_dyn_A_const_pool.A[605]; A_arbace_j2g_dyn_A_const_337 = A_arbace_j2g_dyn_A_const_pool.A[606]; A_arbace_j2g_dyn_A_const_338 = A_arbace_j2g_dyn_A_const_pool.A[607]; A_arbace_j2g_dyn_A_const_339 = A_arbace_j2g_dyn_A_const_pool.A[608]; A_arbace_j2g_dyn_A_const_340 = A_arbace_j2g_dyn_A_const_pool.A[609]; A_arbace_j2g_dyn_A_const_341 = A_arbace_j2g_dyn_A_const_pool.A[610]; A_arbace_j2g_dyn_A_const_342 = A_arbace_j2g_dyn_A_const_pool.A[611]; A_arbace_j2g_dyn_A_const_343 = A_arbace_j2g_dyn_A_const_pool.A[612]; A_arbace_j2g_dyn_A_const_344 = A_arbace_j2g_dyn_A_const_pool.A[613]; A_arbace_j2g_dyn_A_const_345 = A_arbace_j2g_dyn_A_const_pool.A[614]; A_arbace_j2g_dyn_A_const_346 = A_arbace_j2g_dyn_A_const_pool.A[615]; A_arbace_j2g_dyn_A_const_347 = A_arbace_j2g_dyn_A_const_pool.A[616] }

func A_arbace_j2g_dyn_A_clinit_p25() { A_arbace_j2g_dyn_A_const_348 = A_arbace_j2g_dyn_A_const_pool.A[617]; A_arbace_j2g_dyn_A_const_349 = A_arbace_j2g_dyn_A_const_pool.A[618]; A_arbace_j2g_dyn_A_const_350 = A_arbace_j2g_dyn_A_const_pool.A[619]; A_arbace_j2g_dyn_A_const_351 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[620]); A_arbace_j2g_dyn_A_const_352 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[621]); A_arbace_j2g_dyn_A_const_353 = A_arbace_j2g_dyn_A_const_pool.A[622]; A_arbace_j2g_dyn_A_const_354 = A_arbace_j2g_dyn_A_const_pool.A[623]; A_arbace_j2g_dyn_A_const_355 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[624]); A_arbace_j2g_dyn_A_const_356 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[625]); A_arbace_j2g_dyn_A_const_357 = A_arbace_j2g_dyn_A_const_pool.A[626]; A_arbace_j2g_dyn_A_const_358 = A_arbace_j2g_dyn_A_const_pool.A[627]; A_arbace_j2g_dyn_A_const_359 = A_arbace_j2g_dyn_A_const_pool.A[628]; A_arbace_j2g_dyn_A_const_360 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[629]); A_arbace_j2g_dyn_A_const_361 = A_arbace_j2g_dyn_A_const_pool.A[630] }

func A_arbace_j2g_dyn_A_clinit_p26() { A_arbace_j2g_dyn_A_const_362 = A_arbace_j2g_dyn_A_const_pool.A[631]; A_arbace_j2g_dyn_A_const_363 = A_arbace_j2g_dyn_A_const_pool.A[632]; A_arbace_j2g_dyn_A_const_364 = A_arbace_j2g_dyn_A_const_pool.A[633]; A_arbace_j2g_dyn_A_const_365 = A_arbace_j2g_dyn_A_const_pool.A[634]; A_arbace_j2g_dyn_A_const_366 = A_arbace_j2g_dyn_A_const_pool.A[635]; A_arbace_j2g_dyn_A_const_367 = A_arbace_j2g_dyn_A_const_pool.A[636]; A_arbace_j2g_dyn_A_const_368 = A_arbace_j2g_dyn_A_const_pool.A[637]; A_arbace_j2g_dyn_A_const_369 = A_arbace_j2g_dyn_A_const_pool.A[638]; A_arbace_j2g_dyn_A_const_370 = A_arbace_j2g_dyn_A_const_pool.A[639]; A_arbace_j2g_dyn_A_const_371 = A_arbace_j2g_dyn_A_const_pool.A[640]; A_arbace_j2g_dyn_A_const_372 = A_arbace_j2g_dyn_A_const_pool.A[641]; A_arbace_j2g_dyn_A_const_373 = A_arbace_j2g_dyn_A_const_pool.A[642]; A_arbace_j2g_dyn_A_const_374 = A_arbace_j2g_dyn_A_const_pool.A[643]; A_arbace_j2g_dyn_A_const_375 = A_arbace_j2g_dyn_A_const_pool.A[644]; A_arbace_j2g_dyn_A_const_376 = A_arbace_j2g_dyn_A_const_pool.A[645]; A_arbace_j2g_dyn_A_const_377 = A_arbace_j2g_dyn_A_const_pool.A[646] }

func A_arbace_j2g_dyn_A_clinit_p27() { A_arbace_j2g_dyn_A_const_378 = A_arbace_j2g_dyn_A_const_pool.A[647]; A_arbace_j2g_dyn_A_const_379 = A_arbace_j2g_dyn_A_const_pool.A[648]; A_arbace_j2g_dyn_A_const_380 = A_arbace_j2g_dyn_A_const_pool.A[649]; A_arbace_j2g_dyn_A_const_381 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[650]); A_arbace_j2g_dyn_A_const_382 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[651]); A_arbace_j2g_dyn_A_const_383 = A_arbace_j2g_dyn_A_const_pool.A[652]; A_arbace_j2g_dyn_A_const_384 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[653]); A_arbace_j2g_dyn_A_const_385 = A_arbace_j2g_dyn_A_const_pool.A[654]; A_arbace_j2g_dyn_A_const_386 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[655]); A_arbace_j2g_dyn_A_const_387 = A_arbace_j2g_dyn_A_const_pool.A[656]; A_arbace_j2g_dyn_A_const_388 = A_arbace_j2g_dyn_A_const_pool.A[657]; A_arbace_j2g_dyn_A_const_389 = A_arbace_j2g_dyn_A_const_pool.A[658]; A_arbace_j2g_dyn_A_const_390 = A_arbace_j2g_dyn_A_const_pool.A[659]; A_arbace_j2g_dyn_A_const_391 = A_arbace_j2g_dyn_A_const_pool.A[660] }

func A_arbace_j2g_dyn_A_clinit_p28() { A_arbace_j2g_dyn_A_const_392 = A_arbace_j2g_dyn_A_const_pool.A[661]; A_arbace_j2g_dyn_A_const_393 = A_arbace_j2g_dyn_A_const_pool.A[662]; A_arbace_j2g_dyn_A_const_394 = A_arbace_j2g_dyn_A_const_pool.A[663]; A_arbace_j2g_dyn_A_const_395 = A_arbace_j2g_dyn_A_const_pool.A[664]; A_arbace_j2g_dyn_A_const_396 = A_arbace_j2g_dyn_A_const_pool.A[665]; A_arbace_j2g_dyn_A_const_397 = A_arbace_j2g_dyn_A_const_pool.A[666]; A_arbace_j2g_dyn_A_const_398 = A_arbace_j2g_dyn_A_const_pool.A[667]; A_arbace_j2g_dyn_A_const_399 = A_arbace_j2g_dyn_A_const_pool.A[668]; A_arbace_j2g_dyn_A_const_400 = A_arbace_j2g_dyn_A_const_pool.A[669]; A_arbace_j2g_dyn_A_const_401 = A_arbace_j2g_dyn_A_const_pool.A[670]; A_arbace_j2g_dyn_A_const_402 = A_arbace_j2g_dyn_A_const_pool.A[671]; A_arbace_j2g_dyn_A_const_403 = A_arbace_j2g_dyn_A_const_pool.A[672]; A_arbace_j2g_dyn_A_const_404 = A_arbace_j2g_dyn_A_const_pool.A[673]; A_arbace_j2g_dyn_A_const_405 = A_arbace_j2g_dyn_A_const_pool.A[674]; A_arbace_j2g_dyn_A_const_406 = A_arbace_j2g_dyn_A_const_pool.A[675]; A_arbace_j2g_dyn_A_const_407 = A_arbace_j2g_dyn_A_const_pool.A[676] }

func A_arbace_j2g_dyn_A_clinit_p29() { A_arbace_j2g_dyn_A_const_408 = A_arbace_j2g_dyn_A_const_pool.A[677]; A_arbace_j2g_dyn_A_const_409 = A_arbace_j2g_dyn_A_const_pool.A[678]; A_arbace_j2g_dyn_A_const_410 = A_arbace_j2g_dyn_A_const_pool.A[679]; A_arbace_j2g_dyn_A_const_411 = A_arbace_j2g_dyn_A_const_pool.A[680]; A_arbace_j2g_dyn_A_const_412 = A_arbace_j2g_dyn_A_const_pool.A[681]; A_arbace_j2g_dyn_A_const_413 = A_arbace_j2g_dyn_A_const_pool.A[682]; A_arbace_j2g_dyn_A_const_414 = A_arbace_j2g_dyn_A_const_pool.A[683]; A_arbace_j2g_dyn_A_const_415 = A_arbace_j2g_dyn_A_const_pool.A[684]; A_arbace_j2g_dyn_A_const_416 = A_arbace_j2g_dyn_A_const_pool.A[685]; A_arbace_j2g_dyn_A_const_417 = A_arbace_j2g_dyn_A_const_pool.A[686]; A_arbace_j2g_dyn_A_const_418 = A_arbace_j2g_dyn_A_const_pool.A[687]; A_arbace_j2g_dyn_A_const_419 = A_arbace_j2g_dyn_A_const_pool.A[688]; A_arbace_j2g_dyn_A_const_420 = A_arbace_j2g_dyn_A_const_pool.A[689]; A_arbace_j2g_dyn_A_const_421 = A_arbace_j2g_dyn_A_const_pool.A[690]; A_arbace_j2g_dyn_A_const_422 = A_arbace_j2g_dyn_A_const_pool.A[691]; A_arbace_j2g_dyn_A_const_423 = A_arbace_j2g_dyn_A_const_pool.A[692] }

func A_arbace_j2g_dyn_A_clinit_p30() { A_arbace_j2g_dyn_A_const_424 = A_arbace_j2g_dyn_A_const_pool.A[693]; A_arbace_j2g_dyn_A_const_425 = A_arbace_j2g_dyn_A_const_pool.A[694]; A_arbace_j2g_dyn_A_const_426 = A_arbace_j2g_dyn_A_const_pool.A[695]; A_arbace_j2g_dyn_A_const_427 = A_arbace_j2g_dyn_A_const_pool.A[696]; A_arbace_j2g_dyn_A_const_428 = A_arbace_j2g_dyn_A_const_pool.A[697]; A_arbace_j2g_dyn_A_const_429 = A_arbace_j2g_dyn_A_const_pool.A[698]; A_arbace_j2g_dyn_A_const_430 = A_arbace_j2g_dyn_A_const_pool.A[699]; A_arbace_j2g_dyn_A_const_431 = A_arbace_j2g_dyn_A_const_pool.A[700]; A_arbace_j2g_dyn_A_const_432 = A_arbace_j2g_dyn_A_const_pool.A[701]; A_arbace_j2g_dyn_A_const_433 = A_arbace_j2g_dyn_A_const_pool.A[702]; A_arbace_j2g_dyn_A_const_434 = A_arbace_j2g_dyn_A_const_pool.A[703]; A_arbace_j2g_dyn_A_const_435 = A_arbace_j2g_dyn_A_const_pool.A[704]; A_arbace_j2g_dyn_A_const_436 = A_arbace_j2g_dyn_A_const_pool.A[705]; A_arbace_j2g_dyn_A_const_437 = A_arbace_j2g_dyn_A_const_pool.A[706]; A_arbace_j2g_dyn_A_const_438 = A_arbace_j2g_dyn_A_const_pool.A[707]; A_arbace_j2g_dyn_A_const_439 = A_arbace_j2g_dyn_A_const_pool.A[708] }

func A_arbace_j2g_dyn_A_clinit_p31() { A_arbace_j2g_dyn_A_const_440 = A_arbace_j2g_dyn_A_const_pool.A[709]; A_arbace_j2g_dyn_A_const_441 = A_arbace_j2g_dyn_A_const_pool.A[710]; A_arbace_j2g_dyn_A_const_442 = A_arbace_j2g_dyn_A_const_pool.A[711]; A_arbace_j2g_dyn_A_const_443 = A_arbace_j2g_dyn_A_const_pool.A[712]; A_arbace_j2g_dyn_A_const_444 = A_arbace_j2g_dyn_A_const_pool.A[713]; A_arbace_j2g_dyn_A_const_445 = A_arbace_j2g_dyn_A_const_pool.A[714]; A_arbace_j2g_dyn_A_const_446 = A_arbace_j2g_dyn_A_const_pool.A[715]; A_arbace_j2g_dyn_A_const_447 = A_arbace_j2g_dyn_A_const_pool.A[716]; A_arbace_j2g_dyn_A_const_448 = A_arbace_j2g_dyn_A_const_pool.A[717]; A_arbace_j2g_dyn_A_const_449 = A_arbace_j2g_dyn_A_const_pool.A[718]; A_arbace_j2g_dyn_A_const_450 = A_arbace_j2g_dyn_A_const_pool.A[719]; A_arbace_j2g_dyn_A_const_451 = A_arbace_j2g_dyn_A_const_pool.A[720]; A_arbace_j2g_dyn_A_const_452 = A_arbace_j2g_dyn_A_const_pool.A[721]; A_arbace_j2g_dyn_A_const_453 = A_arbace_j2g_dyn_A_const_pool.A[722]; A_arbace_j2g_dyn_A_const_454 = A_arbace_j2g_dyn_A_const_pool.A[723]; A_arbace_j2g_dyn_A_const_455 = A_arbace_j2g_dyn_A_const_pool.A[724] }

func A_arbace_j2g_dyn_A_clinit_p32() { A_arbace_j2g_dyn_A_const_456 = A_arbace_j2g_dyn_A_const_pool.A[725]; A_arbace_j2g_dyn_A_const_457 = A_arbace_j2g_dyn_A_const_pool.A[726]; A_arbace_j2g_dyn_A_const_458 = A_arbace_j2g_dyn_A_const_pool.A[727]; A_arbace_j2g_dyn_A_const_459 = A_arbace_j2g_dyn_A_const_pool.A[728]; A_arbace_j2g_dyn_A_const_460 = A_arbace_j2g_dyn_A_const_pool.A[729]; A_arbace_j2g_dyn_A_const_461 = A_arbace_j2g_dyn_A_const_pool.A[730]; A_arbace_j2g_dyn_A_const_462 = A_arbace_j2g_dyn_A_const_pool.A[731]; A_arbace_j2g_dyn_A_const_463 = A_arbace_j2g_dyn_A_const_pool.A[732]; A_arbace_j2g_dyn_A_const_464 = A_arbace_j2g_dyn_A_const_pool.A[733]; A_arbace_j2g_dyn_A_const_465 = A_arbace_j2g_dyn_A_const_pool.A[734]; A_arbace_j2g_dyn_A_const_466 = A_arbace_j2g_dyn_A_const_pool.A[735]; A_arbace_j2g_dyn_A_const_467 = A_arbace_j2g_dyn_A_const_pool.A[736]; A_arbace_j2g_dyn_A_const_468 = A_arbace_j2g_dyn_A_const_pool.A[737]; A_arbace_j2g_dyn_A_const_469 = A_arbace_j2g_dyn_A_const_pool.A[738]; A_arbace_j2g_dyn_A_const_470 = A_arbace_j2g_dyn_A_const_pool.A[739]; A_arbace_j2g_dyn_A_const_471 = A_arbace_j2g_dyn_A_const_pool.A[740] }

func A_arbace_j2g_dyn_A_clinit_p33() { A_arbace_j2g_dyn_A_const_472 = A_arbace_j2g_dyn_A_const_pool.A[741]; A_arbace_j2g_dyn_A_const_473 = A_arbace_j2g_dyn_A_const_pool.A[742]; A_arbace_j2g_dyn_A_const_474 = A_arbace_j2g_dyn_A_const_pool.A[743]; A_arbace_j2g_dyn_A_const_475 = A_arbace_j2g_dyn_A_const_pool.A[744]; A_arbace_j2g_dyn_A_const_476 = A_arbace_j2g_dyn_A_const_pool.A[745]; A_arbace_j2g_dyn_A_const_477 = A_arbace_j2g_dyn_A_const_pool.A[746]; A_arbace_j2g_dyn_A_const_478 = A_arbace_j2g_dyn_A_const_pool.A[747]; A_arbace_j2g_dyn_A_const_479 = A_arbace_j2g_dyn_A_const_pool.A[748]; A_arbace_j2g_dyn_A_const_480 = A_arbace_j2g_dyn_A_const_pool.A[749]; A_arbace_j2g_dyn_A_const_481 = A_arbace_j2g_dyn_A_const_pool.A[750]; A_arbace_j2g_dyn_A_const_482 = A_arbace_j2g_dyn_A_const_pool.A[751]; A_arbace_j2g_dyn_A_const_483 = A_arbace_j2g_dyn_A_const_pool.A[752]; A_arbace_j2g_dyn_A_const_484 = A_arbace_j2g_dyn_A_const_pool.A[753]; A_arbace_j2g_dyn_A_const_485 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[754]); A_arbace_j2g_dyn_A_const_486 = A_arbace_j2g_dyn_A_const_pool.A[755] }

func A_arbace_j2g_dyn_A_clinit_p34() { A_arbace_j2g_dyn_A_const_487 = A_arbace_j2g_dyn_A_const_pool.A[756]; A_arbace_j2g_dyn_A_const_488 = A_arbace_j2g_dyn_A_const_pool.A[757]; A_arbace_j2g_dyn_A_const_489 = A_arbace_j2g_dyn_A_const_pool.A[758]; A_arbace_j2g_dyn_A_const_490 = A_arbace_j2g_dyn_A_const_pool.A[759]; A_arbace_j2g_dyn_A_const_491 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[760]); A_arbace_j2g_dyn_A_const_492 = A_arbace_j2g_dyn_A_const_pool.A[761]; A_arbace_j2g_dyn_A_const_493 = A_arbace_j2g_dyn_A_const_pool.A[762]; A_arbace_j2g_dyn_A_const_494 = A_arbace_j2g_dyn_A_const_pool.A[763]; A_arbace_j2g_dyn_A_const_495 = A_arbace_j2g_dyn_A_const_pool.A[764]; A_arbace_j2g_dyn_A_const_496 = A_arbace_j2g_dyn_A_const_pool.A[765]; A_arbace_j2g_dyn_A_const_497 = A_arbace_j2g_dyn_A_const_pool.A[766]; A_arbace_j2g_dyn_A_const_498 = A_arbace_j2g_dyn_A_const_pool.A[767]; A_arbace_j2g_dyn_A_const_499 = A_arbace_j2g_dyn_A_const_pool.A[768]; A_arbace_j2g_dyn_A_const_500 = A_arbace_j2g_dyn_A_const_pool.A[769]; A_arbace_j2g_dyn_A_const_501 = A_arbace_j2g_dyn_A_const_pool.A[770] }

func A_arbace_j2g_dyn_A_clinit_p35() { A_arbace_j2g_dyn_A_const_502 = A_arbace_j2g_dyn_A_const_pool.A[771]; A_arbace_j2g_dyn_A_const_503 = A_arbace_j2g_dyn_A_const_pool.A[772]; A_arbace_j2g_dyn_A_const_504 = A_arbace_j2g_dyn_A_const_pool.A[773]; A_arbace_j2g_dyn_A_const_505 = A_arbace_j2g_dyn_A_const_pool.A[774]; A_arbace_j2g_dyn_A_const_506 = A_arbace_j2g_dyn_A_const_pool.A[775]; A_arbace_j2g_dyn_A_const_507 = A_arbace_j2g_dyn_A_const_pool.A[776]; A_arbace_j2g_dyn_A_const_508 = A_arbace_j2g_dyn_A_const_pool.A[777]; A_arbace_j2g_dyn_A_const_509 = A_arbace_j2g_dyn_A_const_pool.A[778]; A_arbace_j2g_dyn_A_const_510 = A_arbace_j2g_dyn_A_const_pool.A[779]; A_arbace_j2g_dyn_A_const_511 = A_arbace_j2g_dyn_A_const_pool.A[780]; A_arbace_j2g_dyn_A_const_512 = A_arbace_j2g_dyn_A_const_pool.A[781]; A_arbace_j2g_dyn_A_const_513 = A_arbace_j2g_dyn_A_const_pool.A[782]; A_arbace_j2g_dyn_A_const_514 = A_arbace_j2g_dyn_A_const_pool.A[783]; A_arbace_j2g_dyn_A_const_515 = A_arbace_j2g_dyn_A_const_pool.A[784]; A_arbace_j2g_dyn_A_const_516 = A_arbace_j2g_dyn_A_const_pool.A[785]; A_arbace_j2g_dyn_A_const_517 = A_arbace_j2g_dyn_A_const_pool.A[786] }

func A_arbace_j2g_dyn_A_clinit_p36() { A_arbace_j2g_dyn_A_const_518 = A_arbace_j2g_dyn_A_const_pool.A[787]; A_arbace_j2g_dyn_A_const_519 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[788]); A_arbace_j2g_dyn_A_const_520 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[789]) }

func A_arbace_j2g_dyn_A_New() *A_arbace_j2g_dyn_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_A) Ctor() {}

func (t *A_arbace_j2g_dyn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_A_class }

func (t *A_arbace_j2g_dyn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_A); return ok }

func A_arbace_j2g_dyn_A_Cast(x any) *A_arbace_j2g_dyn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_A_class)) }; return v }



type A_arbace_j2g_dyn_abstract_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_abstract_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_aot_fn_fields_native_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_aot_fn_fields_native_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_box_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_box_arg_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_call_impl_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_call_impl_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_class_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_ret__711000234_A struct{ j2g_header uint64; F_r any }

var A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_A struct{ j2g_header uint64; F_e any }

var A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A struct{ j2g_header uint64; F_g, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A struct{ j2g_header uint64; F_iter__711000243, F_g, F_s__711000244, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A struct{ j2g_header uint64; F_g, F_n, F_b__711000246, F_arg_conv any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_A struct{ j2g_header uint64; F_ifaces, F_lockee__1927000360__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A struct{ j2g_header uint64; F_j any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A struct{ j2g_header uint64; F_s__711000089, F_iter__711000088 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A struct{ j2g_header uint64; F_iter__711000090, F_s__711000091 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A struct{ j2g_header uint64; F_b__711000093 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_fn__711000118_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A struct{ j2g_header uint64; F_iter__711000107, F_k, F_s__711000108 any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A struct{ j2g_header uint64; F_k, F_b__711000110 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000004_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000004_A_New() *A_arbace_j2g_dyn_eval711000004_A { t := &A_arbace_j2g_dyn_eval711000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000004_A_class }

func (t *A_arbace_j2g_dyn_eval711000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); return ok }

func A_arbace_j2g_dyn_eval711000004_A_Cast(x any) *A_arbace_j2g_dyn_eval711000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000004_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000008_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000008_A_New() *A_arbace_j2g_dyn_eval711000008_A { t := &A_arbace_j2g_dyn_eval711000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000008_A_class }

func (t *A_arbace_j2g_dyn_eval711000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); return ok }

func A_arbace_j2g_dyn_eval711000008_A_Cast(x any) *A_arbace_j2g_dyn_eval711000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000008_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000008_fn__711000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000008_fn__711000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_fn_field_native_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_fn_field_native_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000384_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_fn__711000384_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000415_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000415_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000427_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000427_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000389__711000393_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000389__711000393_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A struct{ j2g_header uint64; F_iter__711000389, F_s__711000390 any }

var A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A struct{ j2g_header uint64; F_b__711000392 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000389__711000393_fn__711000394_fn__711000395_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000405__711000409_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000405__711000409_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A struct{ j2g_header uint64; F_iter__711000405, F_s__711000406 any }

var A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A struct{ j2g_header uint64; F_b__711000408 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000405__711000409_fn__711000410_fn__711000411_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000417__711000421_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000417__711000421_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A struct{ j2g_header uint64; F_iter__711000417, F_s__711000418 any }

var A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A struct{ j2g_header uint64; F_b__711000420 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000417__711000421_fn__711000422_fn__711000423_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A struct{ j2g_header uint64; F_iter__711000270, F_s__711000271 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A struct{ j2g_header uint64; F_s__711000273, F_iter__711000272 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A struct{ j2g_header uint64; F_b__711000275 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A struct{ j2g_header uint64; F_s__711000285, F_iter__711000284 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A struct{ j2g_header uint64; F_b__711000287 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A struct{ j2g_header uint64; F_s__711000297, F_n, F_iter__711000296 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A struct{ j2g_header uint64; F_n, F_b__711000299 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_iface_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A struct{ j2g_header uint64; F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A struct{ j2g_header uint64; F_iter__711000158, F_s__711000159, F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A struct{ j2g_header uint64; F_b__711000161, F_r, F_pn any; F_size__1927001038__auto__ int32; F_core_QMARK_, F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000034_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000036_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A struct{ j2g_header uint64; F_iter__711000038, F_s__711000039 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A struct{ j2g_header uint64; F_s__711000041, F_n, F_iter__711000040 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A struct{ j2g_header uint64; F_n, F_b__711000043 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000178_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000196_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A struct{ j2g_header uint64; F_s__711000187, F_iter__711000186 any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A struct{ j2g_header uint64; F_b__711000189 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_object_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_object_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_classes_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_fn__711000201_A struct{ j2g_header uint64; F_T any }

var A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A struct{ j2g_header uint64; F_iter__711000205, F_s__711000206 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A struct{ j2g_header uint64; F_iter__711000207, F_n, F_s__711000208 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A struct{ j2g_header uint64; F_n, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A struct{ j2g_header uint64; F_s__711000210, F_n, F_iter__711000209, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A struct{ j2g_header uint64; F_n, F_b__711000212 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_public_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_public_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A struct{ j2g_header uint64; F_iter__711000013, F_s__711000014 any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A struct{ j2g_header uint64; F_b__711000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A struct{ j2g_header uint64; F_s__711000056, F_iter__711000055 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A struct{ j2g_header uint64; F_iter__711000057, F_s__711000058 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A struct{ j2g_header uint64; F_b__711000060 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000324_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_A struct{ j2g_header uint64; F_own, F_recv, F_clash, F_ifaces, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A struct{ j2g_header uint64; F_iter__711000307, F_s__711000308 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A struct{ j2g_header uint64; F_b__711000310 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A struct{ j2g_header uint64; F_s__711000330, F_iter__711000329 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A struct{ j2g_header uint64; F_b__711000332 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A struct{ j2g_header uint64; F_recv, F_iter__711000345, F_s__711000346, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A struct{ j2g_header uint64; F_recv, F_n, F_b__711000348 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A struct{ j2g_header uint64; F_recv, F_clash any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A struct{ j2g_header uint64; F_s__711000360, F_recv, F_clash, F_iter__711000359 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A struct{ j2g_header uint64; F_recv, F_clash, F_b__711000362 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_tag_A_fn_class *jrt.Class
