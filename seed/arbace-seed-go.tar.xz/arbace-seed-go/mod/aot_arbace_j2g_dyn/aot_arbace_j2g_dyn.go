//line aot_arbace_j2g_dyn.ae:1
package aot_arbace_j2g_dyn

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_New() *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyn_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyn_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyn_A_const_1, A_arbace_j2g_dyn_A_const_2, A_arbace_j2g_dyn_A_const_3, A_arbace_j2g_dyn_A_const_4, A_arbace_j2g_dyn_A_const_5, A_arbace_j2g_dyn_A_const_6, A_arbace_j2g_dyn_A_const_7, A_arbace_j2g_dyn_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyn_eval711000008_fn__711000009_A_New() *A_arbace_j2g_dyn_eval711000008_fn__711000009_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000008_fn__711000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_11.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_j2g_dyn_A_const_13; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(), A_arbace_j2g_dyn_A_const_15) }























func A_arbace_j2g_dyn_tag_A_New() *A_arbace_j2g_dyn_tag_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_tag_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_26 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = sym__0; var arg_30 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyn_A_const_17, type__1)); if linked_27 == nil { return ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { return linked_27.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) } }










func A_arbace_j2g_dyn_roots_A_New() *A_arbace_j2g_dyn_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_dyn_roots_A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_dyn_roots_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New(); var tmp2 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class; if


	fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class = fncls__89d; tmp2 = fncls__89d } else { tmp2 = fncls__89 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()) }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New() *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Invoke_O_O__O(self, s__711000014__1 any) any { var tmp1 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(self, s__711000014__1); var tmp2 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class = fncls__88d; tmp2 = fncls__88d } else { tmp2 = fncls__88 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Ctor_O_O(c__iter__711000013, c__s__711000014 any) { t.F_iter__711000013 = c__iter__711000013; t.F_s__711000014 = c__s__711000014 }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Invoke_O__O(self any) any { { var s__711000014__1 any; var t_ any = t.F_s__711000014; t.F_s__711000014 = nil; s__711000014__1 = t_; for { var temp__1927000414__auto____2 any; var root_31 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__711000014__1; if linked_32 == nil { temp__1927000414__auto____2 = ifn_33.Invoke_O__O(arg_34) } else { temp__1927000414__auto____2 = linked_32.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_35 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__711000014__3; if linked_36 == nil { tmp1 = ifn_37.Invoke_O__O(arg_38) } else { tmp1 = linked_36.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_35, arg_38) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_39 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = s__711000014__3; if linked_40 == nil { c__1927001037__auto____4 = ifn_41.Invoke_O__O(arg_42) } else { c__1927001037__auto____4 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_39, arg_42) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000016__6 any; var root_43 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_44 == nil { b__711000016__6 = ifn_45.Invoke_O__O(arg_46) } else { b__711000016__6 = linked_44.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_43, arg_46) }; var tmp2 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(b__711000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_61 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any; var root_53 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = b__711000016__6; if linked_54 == nil { arg_64 = ifn_55.Invoke_O__O(arg_56) } else { arg_64 = linked_54.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_53, arg_56) }; var arg_65 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp5 any; var root_57 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = s__711000014__3; if linked_58 == nil { tmp5 = ifn_59.Invoke_O__O(arg_60) } else { tmp5 = linked_58.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_57, arg_60) }; arg_65 = tmp4.Invoke_O__O(tmp5); if linked_62 == nil { return ifn_63.Invoke_O_O__O(arg_64, arg_65) } else { return linked_62.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_61, arg_64, arg_65) } } else { var root_70 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var root_66 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = b__711000016__6; if linked_67 == nil { arg_73 = ifn_68.Invoke_O__O(arg_69) } else { arg_73 = linked_67.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_66, arg_69) }; var arg_74 any; if linked_71 == nil { return ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { return linked_71.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) } } } else { var vec__711000024__4 any; var root_75 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = s__711000014__3; if linked_76 == nil { vec__711000024__4 = ifn_77.Invoke_O__O(arg_78) } else { vec__711000024__4 = linked_76.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_75, arg_78) }; var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_83 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_16, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()); var arg_87 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp7 any; var root_79 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = s__711000014__3; if linked_80 == nil { tmp7 = ifn_81.Invoke_O__O(arg_82) } else { tmp7 = linked_80.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_79, arg_82) }; arg_87 = tmp6.Invoke_O__O(tmp7); if linked_84 == nil { return ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { return linked_84.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Ctor_O_I_O(c__b__711000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000016 = c__b__711000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Invoke_O__O(self any) any { { var i__711000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_47 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = t.F_b__711000016; var arg_51 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_16, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref()); if linked_48 == nil { ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { linked_48.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; i__711000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000015__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_enabled_QMARK__A_New() *A_arbace_j2g_dyn_enabled_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_enabled_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_90 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_90, arg_93)
	} }
func A_arbace_j2g_dyn_public_QMARK__A_New() *A_arbace_j2g_dyn_public_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_public_QMARK__A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Ctor() {}
//line :47:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_103 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any; var tmp1 int64; var na_94 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_33; var tmp3 any; var root_96 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = n__0; if linked_97 == nil { tmp3 = ifn_98.Invoke_O__O(arg_99) } else { tmp3 = linked_97.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_96, arg_99) }; na_94 = tmp2.Invoke_O__O(tmp3); var na_95 int64 = 1; if jrt.Long_InstanceOf(na_94) { var n0_100 int64 = jrt.NN(jrt.Long_Cast(na_94)).LongValue__J(); var n1_101 int64 = na_95; tmp1 = n0_100 & n1_101 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_94, na_95) }; arg_106 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_104 == nil { return ifn_105.Invoke_O__O(arg_106) } else { return linked_104.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_103, arg_106) } }

func A_arbace_j2g_dyn_interfaces_A_New() *A_arbace_j2g_dyn_interfaces_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_dyn_interfaces_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_dyn_interfaces_A) Invoke_O_O__O(self, T__0_ any) any { var base__2 any; var root_186 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_188 lang.IFn; if




	linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var tmp1 any = A_arbace_j2g_dyn_interfaces_fn__711000034_A_New(); var tmp2 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class = fncls__153d; tmp2 = fncls__153d } else { tmp2 = fncls__153 }; arg_189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_190 any; var root_181 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_183 lang.IFn; if






	linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = T__0_; var arg_185 any; var root_176 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any; var tmp3 any = A_arbace_j2g_dyn_interfaces_fn__711000036_A_New(); var tmp4 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class = fncls__167d; tmp4 = fncls__167d } else { tmp4 = fncls__167 }; arg_179 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_180 any; var root_172 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_174 lang.IFn; if


	linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any; var root_168 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var tmp5 *lang.Keyword = A_arbace_j2g_dyn_A_const_51; var arg_171 any = tmp5.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); if linked_169 == nil { arg_175 = ifn_170.Invoke_O__O(arg_171) } else { arg_175 = linked_169.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_168, arg_171) }; if linked_173 == nil { arg_180 = ifn_174.Invoke_O__O(arg_175) } else { arg_180 = linked_173.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_172, arg_175) }; if /*line :61:1*/ linked_177 == nil { arg_185 = ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { arg_185 = linked_177.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) }; if linked_182 == nil { arg_190 = ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { arg_190 = linked_182.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) }; if /*line :54:1*/ linked_187 == nil { base__2 = ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { base__2 = linked_187.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_186, arg_189, arg_190) }; var root_320 any =










	A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any; var root_316 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any; var root_311 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = base__2; var arg_315 any; var iter__1927001039__auto____3 any; var tmp6 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New(); var tmp7 *jrt.Class; var fncls__310 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class; if
	fncls__310 == nil { var fncls__310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class = fncls__310d; tmp7 = fncls__310d } else { tmp7 = fncls__310 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_315 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(base__2); if /*line :65:1*/ linked_312 == nil { arg_319 = ifn_313.Invoke_O_O__O(arg_314, arg_315) } else { arg_319 = linked_312.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_311, arg_314, arg_315) }; if linked_317 == nil { arg_323 = ifn_318.Invoke_O__O(arg_319) } else { arg_323 = linked_317.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_316, arg_319) }; if linked_321 == nil { return ifn_322.Invoke_O__O(arg_323) } else { return linked_321.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_320, arg_323) } }
//line :54:1
func A_arbace_j2g_dyn_interfaces_fn__711000034_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000034_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000034_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Ctor() {}
//line :54:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Invoke_O_O__O(self, p1__711000032_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_107 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = p1__711000032_SHARP___1; if linked_108 == nil { and__1927000168__auto____2 = ifn_109.Invoke_O__O(arg_110) } else { and__1927000168__auto____2 = linked_108.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_107, arg_110) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_111 any = A_arbace_j2g_dyn_A_const_37.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, A_arbace_j2g_dyn_public_QMARK__A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = p1__711000032_SHARP___1; if linked_112 == nil { and__1927000168__auto____3 = ifn_113.Invoke_O__O(arg_114) } else { and__1927000168__auto____3 = linked_112.(*A_arbace_j2g_dyn_public_QMARK__A).Invoke_O_O__O(root_111, arg_114) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_123 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_125 lang.IFn

	if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var root_119 any = A_arbace_j2g_dyn_A_const_38.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var root_115 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = p1__711000032_SHARP___1; if linked_116 == nil { arg_122 = ifn_117.Invoke_O__O(arg_118) } else { arg_122 = linked_116.(*aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_115, arg_118) }; if linked_120 == nil { arg_126 = ifn_121.Invoke_O__O(arg_122) } else { arg_126 = linked_120.(*aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A).Invoke_O_O__O(root_119, arg_122) }; if linked_124 == nil { and__1927000168__auto____4 = ifn_125.Invoke_O__O(arg_126) } else { and__1927000168__auto____4 = linked_124.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_123, arg_126) }
//line :54:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_132 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_134 lang.IFn



		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; var root_127 any = A_arbace_j2g_dyn_A_const_40.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = p1__711000032_SHARP___1; var arg_131 any = Lit_114; if linked_128 == nil { arg_135 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { arg_135 = linked_128.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_127, arg_130, arg_131) }; if linked_133 == nil { and__1927000168__auto____5 = ifn_134.Invoke_O__O(arg_135) } else { and__1927000168__auto____5 = linked_133.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_132, arg_135) }
//line :54:1
		if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp1 int64; var na_136 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_33; var tmp3 any; var root_138 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_140 lang.IFn




			if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = p1__711000032_SHARP___1; if linked_139 == nil { tmp3 = ifn_140.Invoke_O__O(arg_141) } else { tmp3 = linked_139.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_138, arg_141) }; na_136 = tmp2.Invoke_O__O(tmp3); var na_137 int64 = 8192; if jrt.Long_InstanceOf(na_136) { var n0_142 int64 = jrt.NN(jrt.Long_Cast(na_136)).LongValue__J(); var n1_143 int64 = na_137; tmp1 = n0_142 & n1_143 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_136, na_137) }; and__1927000168__auto____6 = lang.Numbers_IsZero_J__Z_NoInit(tmp1)
//line :54:1
			if and__1927000168__auto____6 {





				var root_149 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any; var root_145 any = A_arbace_j2g_dyn_A_const_41.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = p1__711000032_SHARP___1; if linked_146 == nil { arg_152 = ifn_147.Invoke_O__O(arg_148) } else { arg_152 = linked_146.(*aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A).Invoke_O_O__O(root_145, arg_148) }; if linked_150 == nil { return ifn_151.Invoke_O__O(arg_152) } else { return linked_150.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_149, arg_152) } } else {
//line :54:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_dyn_interfaces_fn__711000036_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000036_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000036_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Ctor() {}
//line :61:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Invoke_O_O__O(self, p1__711000033_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_154 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = p1__711000033_SHARP___1; if linked_155 == nil { and__1927000168__auto____2 = ifn_156.Invoke_O__O(arg_157) } else { and__1927000168__auto____2 = linked_155.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_154, arg_157) }; if jrt.J2g_Truth(and__1927000168__auto____2) {

	var root_162 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var tmp1 *lang.Keyword = A_arbace_j2g_dyn_A_const_45; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_165 any = tmp1.Invoke_O__O(tmp2.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O())); var arg_166 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20); var tmp4 any; var root_158 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = p1__711000033_SHARP___1; if linked_159 == nil { tmp4 = ifn_160.Invoke_O__O(arg_161) } else { tmp4 = linked_159.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_158, arg_161) }; arg_166 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil)).Ref(); if linked_163 == nil { return ifn_164.Invoke_O_O__O(arg_165, arg_166) } else { return linked_163.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_162, arg_165, arg_166) } } else {
//line :61:1
		return and__1927000168__auto____2 } }




func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New() *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Ctor() {}
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Invoke_O_O__O(self, s__711000039__1 any) any { var tmp1 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(self, s__711000039__1); var tmp2 *jrt.Class; var fncls__309 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class; if fncls__309 == nil { var fncls__309d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class = fncls__309d; tmp2 = fncls__309d } else { tmp2 = fncls__309 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Ctor_O_O(c__iter__711000038, c__s__711000039 any) { t.F_iter__711000038 = c__iter__711000038; t.F_s__711000039 = c__s__711000039 }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Invoke_O__O(self any) any { { var s__711000039__1 any; var t_ any = t.F_s__711000039; t.F_s__711000039 = nil; s__711000039__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_191 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = s__711000039__1; if linked_192 == nil { temp__1927000414__auto____2 = ifn_193.Invoke_O__O(arg_194) } else { temp__1927000414__auto____2 = linked_192.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_191, arg_194) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_195 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = xs__1927001018__auto____3; if linked_196 == nil { n__4 = ifn_197.Invoke_O__O(arg_198) } else { n__4 = linked_196.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_195, arg_198) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(n__4); var tmp2 *jrt.Class; var fncls__287 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class; if fncls__287 == nil { var fncls__287d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class = fncls__287d; tmp2 = fncls__287d } else { tmp2 = fncls__287 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_292 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_288 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = n__4; if linked_289 == nil { tmp4 = ifn_290.Invoke_O__O(arg_291) } else { tmp4 = linked_289.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_288, arg_291) }; arg_295 = tmp3.Invoke_O__O(tmp4); if linked_293 == nil { fs__1927001036__auto____6 = ifn_294.Invoke_O__O(arg_295) } else { fs__1927001036__auto____6 = linked_293.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_292, arg_295) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_300 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = fs__1927001036__auto____6; var arg_304 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000038); var tmp6 any; var root_296 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = s__711000039__1; if linked_297 == nil { tmp6 = ifn_298.Invoke_O__O(arg_299) } else { tmp6 = linked_297.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_296, arg_299) }; arg_304 = tmp5.Invoke_O__O(tmp6); if linked_301 == nil { return ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { return linked_301.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) } } else { var tmp7 any; var root_305 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = s__711000039__1; if linked_306 == nil { tmp7 = ifn_307.Invoke_O__O(arg_308) } else { tmp7 = linked_306.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_305, arg_308) }; s__711000039__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(p0 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Invoke_O_O__O(self, s__711000041__1 any) any { var tmp1 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(s__711000041__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__286 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class; if fncls__286 == nil { var fncls__286d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class = fncls__286d; tmp2 = fncls__286d } else { tmp2 = fncls__286 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Ctor_O_O_O(c__s__711000041, c__n, c__iter__711000040 any) { t.F_s__711000041 = c__s__711000041; t.F_n = c__n; t.F_iter__711000040 = c__iter__711000040 }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Invoke_O__O(self any) any { { var s__711000041__1 any; var t_ any = t.F_s__711000041; t.F_s__711000041 = nil; s__711000041__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_199 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__711000041__1; if linked_200 == nil { temp__1927000414__auto____2 = ifn_201.Invoke_O__O(arg_202) } else { temp__1927000414__auto____2 = linked_200.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_199, arg_202) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000041__3 any = temp__1927000414__auto____2; var tmp1 any; var root_203 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = s__711000041__3; if linked_204 == nil { tmp1 = ifn_205.Invoke_O__O(arg_206) } else { tmp1 = linked_204.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_203, arg_206) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_207 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = s__711000041__3; if linked_208 == nil { c__1927001037__auto____4 = ifn_209.Invoke_O__O(arg_210) } else { c__1927001037__auto____4 = linked_208.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_207, arg_210) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000043__6 any; var root_211 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_212 == nil { b__711000043__6 = ifn_213.Invoke_O__O(arg_214) } else { b__711000043__6 = linked_212.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_211, arg_214) }; var tmp2 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(t.F_n, b__711000043__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__233 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class; if fncls__233 == nil { var fncls__233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class = fncls__233d; tmp3 = fncls__233d } else { tmp3 = fncls__233 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_242 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any; var root_234 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = b__711000043__6; if linked_235 == nil { arg_245 = ifn_236.Invoke_O__O(arg_237) } else { arg_245 = linked_235.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_234, arg_237) }; var arg_246 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp5 any; var root_238 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = s__711000041__3; if linked_239 == nil { tmp5 = ifn_240.Invoke_O__O(arg_241) } else { tmp5 = linked_239.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_238, arg_241) }; arg_246 = tmp4.Invoke_O__O(tmp5); if linked_243 == nil { return ifn_244.Invoke_O_O__O(arg_245, arg_246) } else { return linked_243.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_242, arg_245, arg_246) } } else { var root_251 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any; var root_247 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = b__711000043__6; if linked_248 == nil { arg_254 = ifn_249.Invoke_O__O(arg_250) } else { arg_254 = linked_248.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_247, arg_250) }; var arg_255 any; if linked_252 == nil { return ifn_253.Invoke_O_O__O(arg_254, arg_255) } else { return linked_252.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_251, arg_254, arg_255) } } } else { var s__4 any; var root_256 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = s__711000041__3; if linked_257 == nil { s__4 = ifn_258.Invoke_O__O(arg_259) } else { s__4 = linked_257.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_256, arg_259) }; var tmp6 any; var and__1927000168__auto____5 any; var root_260 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_262 lang.IFn
																			if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = s__4; var arg_264 any = t.F_n; if linked_261 == nil { and__1927000168__auto____5 = ifn_262.Invoke_O_O__O(arg_263, arg_264) } else { and__1927000168__auto____5 = linked_261.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_260, arg_263, arg_264) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_265 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = s__4; if linked_266 == nil { and__1927000168__auto____6 = ifn_267.Invoke_O__O(arg_268) } else { and__1927000168__auto____6 = linked_266.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_265, arg_268) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_269 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = s__4; if linked_270 == nil { tmp6 = ifn_271.Invoke_O__O(arg_272) } else { tmp6 = linked_270.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_269, arg_272) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :66:1
	if jrt.J2g_Truth(tmp6) { var root_277 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = s__4; var arg_281 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp8 any; var root_273 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__711000041__3; if linked_274 == nil { tmp8 = ifn_275.Invoke_O__O(arg_276) } else { tmp8 = linked_274.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_273, arg_276) }; arg_281 = tmp7.Invoke_O__O(tmp8); if linked_278 == nil { return ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { return linked_278.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) } } else { var tmp9 any; var root_282 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = s__711000041__3; if linked_283 == nil { tmp9 = ifn_284.Invoke_O__O(arg_285) } else { tmp9 = linked_283.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_282, arg_285) }; s__711000041__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Ctor_O_O_I_O(c__n, c__b__711000043 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000043 = c__b__711000043; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Invoke_O__O(self any) any { { var i__711000042__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000042__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000042__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_215 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_217 lang.IFn
																					if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = s__2; var arg_219 any = t.F_n; if linked_216 == nil { and__1927000168__auto____3 = ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { and__1927000168__auto____3 = linked_216.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_215, arg_218, arg_219) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_220 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = s__2; if linked_221 == nil { and__1927000168__auto____4 = ifn_222.Invoke_O__O(arg_223) } else { and__1927000168__auto____4 = linked_221.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_220, arg_223) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_224 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = s__2; if linked_225 == nil { tmp2 = ifn_226.Invoke_O__O(arg_227) } else { tmp2 = linked_225.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_224, arg_227) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :66:1
	if jrt.J2g_Truth(tmp2) { var root_228 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = t.F_b__711000043; var arg_232 any = s__2; if linked_229 == nil { ifn_230.Invoke_O_O__O(arg_231, arg_232) } else { linked_229.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_228, arg_231, arg_232) }; i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } else { i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_slot_keys_A_New() *A_arbace_j2g_dyn_slot_keys_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Ctor() {}
//line :70:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Invoke_O_O__O(self, ifaces__0 any) any { var ks__2 any; var root_430 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_432 lang.IFn; if


	linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any; var root_426 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New(); var tmp2 *jrt.Class; var fncls__425 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class; if fncls__425 == nil { var fncls__425d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class = fncls__425d; tmp2 = fncls__425d } else { tmp2 = fncls__425 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_429 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(ifaces__0); if linked_427 == nil { arg_433 = ifn_428.Invoke_O__O(arg_429) } else { arg_433 = linked_427.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_426, arg_429) }; if linked_431 == nil { ks__2 = ifn_432.Invoke_O__O(arg_433) } else { ks__2 = linked_431.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_430, arg_433) }; var root_439 any =
	A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any; var root_434 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(); var arg_438 any = ks__2; if linked_435 == nil { arg_442 = ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { arg_442 = linked_435.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) }; if linked_440 == nil { return ifn_441.Invoke_O__O(arg_442) } else { return linked_440.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_439, arg_442) } }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Invoke_O_O__O(self, s__711000056__1 any) any { var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(s__711000056__1, self); var tmp2 *jrt.Class; var fncls__424 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class; if fncls__424 == nil { var fncls__424d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class = fncls__424d; tmp2 = fncls__424d } else { tmp2 = fncls__424 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Ctor_O_O(c__s__711000056, c__iter__711000055 any) { t.F_s__711000056 = c__s__711000056; t.F_iter__711000055 = c__iter__711000055 }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Invoke_O__O(self any) any { { var s__711000056__1 any; var t_ any = t.F_s__711000056; t.F_s__711000056 = nil; s__711000056__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_324 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = s__711000056__1; if linked_325 == nil { temp__1927000414__auto____2 = ifn_326.Invoke_O__O(arg_327) } else { temp__1927000414__auto____2 = linked_325.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_324, arg_327) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var j__4 any; var root_328 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = xs__1927001018__auto____3; if linked_329 == nil { j__4 = ifn_330.Invoke_O__O(arg_331) } else { j__4 = linked_329.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_328, arg_331) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New(); var tmp2 *jrt.Class; var fncls__402 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class; if fncls__402 == nil { var fncls__402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class = fncls__402d; tmp2 = fncls__402d } else { tmp2 = fncls__402 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_407 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_403 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = j__4; if linked_404 == nil { tmp4 = ifn_405.Invoke_O__O(arg_406) } else { tmp4 = linked_404.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_403, arg_406) }; arg_410 = tmp3.Invoke_O__O(tmp4); if linked_408 == nil { fs__1927001036__auto____6 = ifn_409.Invoke_O__O(arg_410) } else { fs__1927001036__auto____6 = linked_408.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_407, arg_410) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_415 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = fs__1927001036__auto____6; var arg_419 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000055); var tmp6 any; var root_411 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = s__711000056__1; if linked_412 == nil { tmp6 = ifn_413.Invoke_O__O(arg_414) } else { tmp6 = linked_412.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_411, arg_414) }; arg_419 = tmp5.Invoke_O__O(tmp6); if linked_416 == nil { return ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { return linked_416.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) } } else { var tmp7 any; var root_420 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = s__711000056__1; if linked_421 == nil { tmp7 = ifn_422.Invoke_O__O(arg_423) } else { tmp7 = linked_421.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_420, arg_423) }; s__711000056__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Invoke_O_O__O(self, s__711000058__1 any) any { var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(self, s__711000058__1); var tmp2 *jrt.Class; var fncls__401 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class; if fncls__401 == nil { var fncls__401d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class = fncls__401d; tmp2 = fncls__401d } else { tmp2 = fncls__401 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Ctor_O_O(c__iter__711000057, c__s__711000058 any) { t.F_iter__711000057 = c__iter__711000057; t.F_s__711000058 = c__s__711000058 }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Invoke_O__O(self any) any { { var s__711000058__1 any; var t_ any = t.F_s__711000058; t.F_s__711000058 = nil; s__711000058__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_332 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = s__711000058__1; if linked_333 == nil { temp__1927000414__auto____2 = ifn_334.Invoke_O__O(arg_335) } else { temp__1927000414__auto____2 = linked_333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_332, arg_335) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000058__3 any = temp__1927000414__auto____2; var tmp1 any; var root_336 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = s__711000058__3; if linked_337 == nil { tmp1 = ifn_338.Invoke_O__O(arg_339) } else { tmp1 = linked_337.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_336, arg_339) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_340 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = s__711000058__3; if linked_341 == nil { c__1927001037__auto____4 = ifn_342.Invoke_O__O(arg_343) } else { c__1927001037__auto____4 = linked_341.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_340, arg_343) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000060__6 any; var root_344 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_345 == nil { b__711000060__6 = ifn_346.Invoke_O__O(arg_347) } else { b__711000060__6 = linked_345.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_344, arg_347) }; var tmp2 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(b__711000060__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__357 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class; if fncls__357 == nil { var fncls__357d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class = fncls__357d; tmp3 = fncls__357d } else { tmp3 = fncls__357 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_366 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any; var root_358 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = b__711000060__6; if linked_359 == nil { arg_369 = ifn_360.Invoke_O__O(arg_361) } else { arg_369 = linked_359.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_358, arg_361) }; var arg_370 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp5 any; var root_362 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = s__711000058__3; if linked_363 == nil { tmp5 = ifn_364.Invoke_O__O(arg_365) } else { tmp5 = linked_363.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_362, arg_365) }; arg_370 = tmp4.Invoke_O__O(tmp5); if linked_367 == nil { return ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { return linked_367.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) } } else { var root_375 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any; var root_371 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = b__711000060__6; if linked_372 == nil { arg_378 = ifn_373.Invoke_O__O(arg_374) } else { arg_378 = linked_372.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_371, arg_374) }; var arg_379 any; if linked_376 == nil { return ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { return linked_376.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) } } } else { var vec__711000070__4 any; var root_380 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = s__711000058__3; if linked_381 == nil { vec__711000070__4 = ifn_382.Invoke_O__O(arg_383) } else { vec__711000070__4 = linked_381.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_380, arg_383) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_384 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_386 lang.IFn; _ = ___6; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__5); if linked_385 == nil { tmp6 = ifn_386.Invoke_O__O(arg_387) } else { tmp6 = linked_385.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_384, arg_387) }; if jrt.J2g_Truth(tmp6) { var root_392 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = k__5; var arg_396 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp8 any; var root_388 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = s__711000058__3; if linked_389 == nil { tmp8 = ifn_390.Invoke_O__O(arg_391) } else { tmp8 = linked_389.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_388, arg_391) }; arg_396 = tmp7.Invoke_O__O(tmp8); if linked_393 == nil { return ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { return linked_393.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) } } else { var tmp9 any; var root_397 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = s__711000058__3; if linked_398 == nil { tmp9 = ifn_399.Invoke_O__O(arg_400) } else { tmp9 = linked_398.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_397, arg_400) }; s__711000058__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Ctor_O_I_O(c__b__711000060 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000060 = c__b__711000060; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Invoke_O__O(self any) any { { var i__711000059__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000059__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000066__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000059__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_348 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_350 lang.IFn; _ = ___4; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__3); if linked_349 == nil { tmp2 = ifn_350.Invoke_O__O(arg_351) } else { tmp2 = linked_349.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_348, arg_351) }; if jrt.J2g_Truth(tmp2) { var root_352 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = t.F_b__711000060; var arg_356 any = k__3; if linked_353 == nil { ifn_354.Invoke_O_O__O(arg_355, arg_356) } else { linked_353.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_352, arg_355, arg_356) }; i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } else { i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_declarers_A_New() *A_arbace_j2g_dyn_declarers_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_j2g_dyn_declarers_A) Ctor() {}
//line :78:1
func (t *A_arbace_j2g_dyn_declarers_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var vec__711000078__3 any; var root_443 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_445 lang.IFn; if




	linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); if linked_444 == nil { vec__711000078__3 = ifn_445.Invoke_O__O(arg_446) } else { vec__711000078__3 = linked_444.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_443, arg_446) }; var i__4 any = /*line :78:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; if





	lang.Util_Identical_O_O__Z_NoInit(i__4, ifaces__0) { tmp1 = ix__5 } else { var lockee__1927000360__auto____6 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var tmp2 any = A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(ifaces__0, lockee__1927000360__auto____6); var tmp3 *jrt.Class
		var fncls__580 /*line :84:1*/*jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class

		if fncls__580 == nil { var fncls__580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class = fncls__580d; tmp3 = fncls__580d } else { tmp3 = fncls__580 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }; return /*line :84:1*/ lang.RT_Get_O_O__O_NoInit(tmp1, k__1) }

func A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Ctor_O_O(c__ifaces, c__lockee__1927000360__auto__ any) { t.F_ifaces = c__ifaces; t.F_lockee__1927000360__auto__ = c__lockee__1927000360__auto__ }
//line :86:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Invoke_O__O(self any) any { var locklocal__1927000361__auto____3 any; var t_ any = t.F_lockee__1927000360__auto__; t.F_lockee__1927000360__auto__ = nil; locklocal__1927000361__auto____3 = t_; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____3); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__711000082__6 any; var root_447 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_449 lang.IFn
										if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); if linked_448 == nil { vec__711000082__6 = ifn_449.Invoke_O__O(arg_450) } else { vec__711000082__6 = linked_448.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_447, arg_450) }
//line :86:1
	var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(1), nil)

	if lang.Util_Identical_O_O__Z_NoInit(i__7, t.F_ifaces) { tmp1 = ix__8 } else { var ix__9 any; var root_569 any = A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_571 lang.IFn

		if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any; var tmp2 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New(); var tmp3 *jrt.Class; var fncls__568 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class; if fncls__568 == nil { var fncls__568d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class = fncls__568d; tmp3 = fncls__568d } else { tmp3 = fncls__568 }; arg_572 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_573 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_574 any = t.F_ifaces; if linked_570 == nil { ix__9 = ifn_571.Invoke_O_O_O__O(arg_572, arg_573, arg_574) } else { ix__9 = linked_570.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_569, arg_572, arg_573, arg_574)
		}




		var root_575 any = A_arbace_j2g_dyn_A_const_67.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var arg_579 any; var tmp4 any; var t__2 any = t.F_ifaces; t.F_ifaces = nil; tmp4 = t__2; arg_579 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, ix__9); if linked_576 == nil { ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { linked_576.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_575, arg_578, arg_579) }
//line :88:1
		tmp1 = ix__9 } }; return nil }(); /*line :86:1*/lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____3); if tmp5 != nil { panic(tmp5) }; return tmp1 }



func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Invoke_O_O_O__O(self, ix__1, j__2 any) any {
	var root_562 any = A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any; var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(j__2); var tmp2 *jrt.Class; var fncls__463 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class; if fncls__463 == nil { var fncls__463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class = fncls__463d; tmp2 = fncls__463d } else { tmp2 = fncls__463 }; arg_565 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_566 any = ix__1; var arg_567 any; var root_558 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_560 lang.IFn

	if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New(); var tmp4 *jrt.Class; var fncls__553 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class; if fncls__553 == nil { var fncls__553d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class = fncls__553d; tmp4 = fncls__553d } else { tmp4 = fncls__553 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp6 any; var root_554 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = j__2; if linked_555 == nil { tmp6 = ifn_556.Invoke_O__O(arg_557) } else { tmp6 = linked_555.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_554, arg_557) }; arg_561 = tmp5.Invoke_O__O(tmp6); if linked_559 == nil { arg_567 = ifn_560.Invoke_O__O(arg_561) } else { arg_567 = linked_559.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_558, arg_561) }
//line :91:1
	if linked_563 == nil { return ifn_564.Invoke_O_O_O__O(arg_565, arg_566, arg_567) } else { return linked_563.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_562, arg_565, arg_566, arg_567) } }
//line :91:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(p0 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A{}; t.Ctor_O(p0); return t }
//line :91:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Ctor_O(c__j any) { t.F_j = c__j }
//line :91:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Invoke_O_O_O__O(self, ix__1, kk__2 any) any { var root_456 any = A_arbace_j2g_dyn_A_const_62.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = ix__1; var arg_460 any = kk__2; var arg_461 any; var root_451 any = A_arbace_j2g_dyn_A_const_63.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(); var arg_455 any = lang.PersistentVector_EMPTY.Ref(); if linked_452 == nil { arg_461 = ifn_453.Invoke_O_O__O(arg_454, arg_455) } else { arg_461 = linked_452.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_451, arg_454, arg_455) }; var arg_462 any = t.F_j; if linked_457 == nil { return ifn_458.Invoke_O_O_O_O__O(arg_459, arg_460, arg_461, arg_462) } else { return linked_457.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_456, arg_459, arg_460, arg_461, arg_462) } }

func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Invoke_O_O__O(self, s__711000089__1 any) any { var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(s__711000089__1, self); var tmp2 *jrt.Class; var fncls__552 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class; if fncls__552 == nil { var fncls__552d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class = fncls__552d; tmp2 = fncls__552d } else { tmp2 = fncls__552 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Ctor_O_O(c__s__711000089, c__iter__711000088 any) { t.F_s__711000089 = c__s__711000089; t.F_iter__711000088 = c__iter__711000088 }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Invoke_O__O(self any) any { { var s__711000089__1 any; var t_ any = t.F_s__711000089; t.F_s__711000089 = nil; s__711000089__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_464 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = s__711000089__1; if linked_465 == nil { temp__1927000414__auto____2 = ifn_466.Invoke_O__O(arg_467) } else { temp__1927000414__auto____2 = linked_465.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_464, arg_467) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_468 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = xs__1927001018__auto____3; if linked_469 == nil { c__4 = ifn_470.Invoke_O__O(arg_471) } else { c__4 = linked_469.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_468, arg_471) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New(); var tmp2 *jrt.Class; var fncls__530 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class; if fncls__530 == nil { var fncls__530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class = fncls__530d; tmp2 = fncls__530d } else { tmp2 = fncls__530 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_535 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_531 any = A_arbace_j2g_dyn_A_const_66.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = c__4; if linked_532 == nil { tmp4 = ifn_533.Invoke_O__O(arg_534) } else { tmp4 = linked_532.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_531, arg_534) }; arg_538 = tmp3.Invoke_O__O(tmp4); if linked_536 == nil { fs__1927001036__auto____6 = ifn_537.Invoke_O__O(arg_538) } else { fs__1927001036__auto____6 = linked_536.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_535, arg_538) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_543 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = fs__1927001036__auto____6; var arg_547 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000088); var tmp6 any; var root_539 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = s__711000089__1; if linked_540 == nil { tmp6 = ifn_541.Invoke_O__O(arg_542) } else { tmp6 = linked_540.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_539, arg_542) }; arg_547 = tmp5.Invoke_O__O(tmp6); if linked_544 == nil { return ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { return linked_544.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) } } else { var tmp7 any; var root_548 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = s__711000089__1; if linked_549 == nil { tmp7 = ifn_550.Invoke_O__O(arg_551) } else { tmp7 = linked_549.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_548, arg_551) }; s__711000089__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Invoke_O_O__O(self, s__711000091__1 any) any { var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(self, s__711000091__1); var tmp2 *jrt.Class; var fncls__529 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class; if fncls__529 == nil { var fncls__529d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class = fncls__529d; tmp2 = fncls__529d } else { tmp2 = fncls__529 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Ctor_O_O(c__iter__711000090, c__s__711000091 any) { t.F_iter__711000090 = c__iter__711000090; t.F_s__711000091 = c__s__711000091 }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Invoke_O__O(self any) any { { var s__711000091__1 any; var t_ any = t.F_s__711000091; t.F_s__711000091 = nil; s__711000091__1 = t_; for { var temp__1927000414__auto____2 any; var root_472 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = s__711000091__1; if linked_473 == nil { temp__1927000414__auto____2 = ifn_474.Invoke_O__O(arg_475) } else { temp__1927000414__auto____2 = linked_473.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_472, arg_475) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000091__3 any = temp__1927000414__auto____2; var tmp1 any; var root_476 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = s__711000091__3; if linked_477 == nil { tmp1 = ifn_478.Invoke_O__O(arg_479) } else { tmp1 = linked_477.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_476, arg_479) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_480 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = s__711000091__3; if linked_481 == nil { c__1927001037__auto____4 = ifn_482.Invoke_O__O(arg_483) } else { c__1927001037__auto____4 = linked_481.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_480, arg_483) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000093__6 any; var root_484 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_485 == nil { b__711000093__6 = ifn_486.Invoke_O__O(arg_487) } else { b__711000093__6 = linked_485.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_484, arg_487) }; var tmp2 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(b__711000093__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__493 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class; if fncls__493 == nil { var fncls__493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class = fncls__493d; tmp3 = fncls__493d } else { tmp3 = fncls__493 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_502 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any; var root_494 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = b__711000093__6; if linked_495 == nil { arg_505 = ifn_496.Invoke_O__O(arg_497) } else { arg_505 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_494, arg_497) }; var arg_506 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp5 any; var root_498 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = s__711000091__3; if linked_499 == nil { tmp5 = ifn_500.Invoke_O__O(arg_501) } else { tmp5 = linked_499.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_498, arg_501) }; arg_506 = tmp4.Invoke_O__O(tmp5); if linked_503 == nil { return ifn_504.Invoke_O_O__O(arg_505, arg_506) } else { return linked_503.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_502, arg_505, arg_506) } } else { var root_511 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var root_507 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = b__711000093__6; if linked_508 == nil { arg_514 = ifn_509.Invoke_O__O(arg_510) } else { arg_514 = linked_508.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_507, arg_510) }; var arg_515 any; if linked_512 == nil { return ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { return linked_512.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) } } } else { var mm__4 any; var root_516 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = s__711000091__3; if linked_517 == nil { mm__4 = ifn_518.Invoke_O__O(arg_519) } else { mm__4 = linked_517.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_516, arg_519) }; var root_524 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4)); var arg_528 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp7 any; var root_520 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = s__711000091__3; if linked_521 == nil { tmp7 = ifn_522.Invoke_O__O(arg_523) } else { tmp7 = linked_521.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_520, arg_523) }; arg_528 = tmp6.Invoke_O__O(tmp7); if linked_525 == nil { return ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { return linked_525.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Ctor_O_I_O(c__b__711000093 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000093 = c__b__711000093; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Invoke_O__O(self any) any { { var i__711000092__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000092__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000092__1)); var root_488 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = t.F_b__711000093; var arg_492 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2)); if linked_489 == nil { ifn_490.Invoke_O_O__O(arg_491, arg_492) } else { linked_489.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_488, arg_491, arg_492) }; i__711000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000092__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_dyn_defaults_for_A_New() *A_arbace_j2g_dyn_defaults_for_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var cands__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(k__1); var tmp2 *jrt.Class; var fncls__699 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class; if


	fncls__699 == nil { var fncls__699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class = fncls__699d; tmp2 = fncls__699d } else { tmp2 = fncls__699 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_710 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, A_arbace_j2g_dyn_declarers_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = ifaces__0; var arg_714 any = k__1; if linked_711 == nil { tmp4 = ifn_712.Invoke_O_O__O(arg_713, arg_714) } else { tmp4 = linked_711.(*A_arbace_j2g_dyn_declarers_A).Invoke_O_O_O__O(root_710, arg_713, arg_714) }; cands__3 = tmp3.Invoke_O__O(tmp4); var root_705 any =



	A_arbace_j2g_dyn_A_const_76.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any; var tmp5 any = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New(); var tmp6 *jrt.Class; var fncls__704 *jrt.Class = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class; if fncls__704 == nil { var fncls__704d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class = fncls__704d; tmp6 = fncls__704d } else { tmp6 = fncls__704 }; arg_708 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_709 any = cands__3; if linked_706 == nil { return ifn_707.Invoke_O_O__O(arg_708, arg_709) } else { return linked_706.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_705, arg_708, arg_709) } }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(p0 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Invoke_O_O__O(self, s__711000108__1 any) any { var tmp1 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(self, t.F_k, s__711000108__1); var tmp2 *jrt.Class; var fncls__698 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class; if fncls__698 == nil { var fncls__698d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class = fncls__698d; tmp2 = fncls__698d } else { tmp2 = fncls__698 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Ctor_O_O_O(c__iter__711000107, c__k, c__s__711000108 any) { t.F_iter__711000107 = c__iter__711000107; t.F_k = c__k; t.F_s__711000108 = c__s__711000108 }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Invoke_O__O(self any) any { { var s__711000108__1 any; var t_ any = t.F_s__711000108; t.F_s__711000108 = nil; s__711000108__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_581 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = s__711000108__1; if linked_582 == nil { temp__1927000414__auto____2 = ifn_583.Invoke_O__O(arg_584) } else { temp__1927000414__auto____2 = linked_582.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_581, arg_584) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000108__3 any = temp__1927000414__auto____2; var tmp1 any; var root_585 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = s__711000108__3; if linked_586 == nil { tmp1 = ifn_587.Invoke_O__O(arg_588) } else { tmp1 = linked_586.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_585, arg_588) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_589 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = s__711000108__3; if linked_590 == nil { c__1927001037__auto____4 = ifn_591.Invoke_O__O(arg_592) } else { c__1927001037__auto____4 = linked_590.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_589, arg_592) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000110__6 any; var root_593 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_594 == nil { b__711000110__6 = ifn_595.Invoke_O__O(arg_596) } else { b__711000110__6 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_593, arg_596) }; var tmp2 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(t.F_k, b__711000110__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__630 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class; if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class = fncls__630d; tmp3 = fncls__630d } else { tmp3 = fncls__630 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_639 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any; var root_631 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = b__711000110__6; if linked_632 == nil { arg_642 = ifn_633.Invoke_O__O(arg_634) } else { arg_642 = linked_632.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_631, arg_634) }; var arg_643 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp5 any; var root_635 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = s__711000108__3; if linked_636 == nil { tmp5 = ifn_637.Invoke_O__O(arg_638) } else { tmp5 = linked_636.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_635, arg_638) }; arg_643 = tmp4.Invoke_O__O(tmp5); if linked_640 == nil { return ifn_641.Invoke_O_O__O(arg_642, arg_643) } else { return linked_640.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_639, arg_642, arg_643) } } else { var root_648 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_644 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = b__711000110__6; if linked_645 == nil { arg_651 = ifn_646.Invoke_O__O(arg_647) } else { arg_651 = linked_645.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_644, arg_647) }; var arg_652 any; if linked_649 == nil { return ifn_650.Invoke_O_O__O(arg_651, arg_652) } else { return linked_649.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_648, arg_651, arg_652) } } } else { var j__4 any; var root_653 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = s__711000108__3; if linked_654 == nil { j__4 = ifn_655.Invoke_O__O(arg_656) } else { j__4 = linked_654.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_653, arg_656) }; var impl__5 any; var root_657 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_659 lang.IFn
														if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = j__4; var arg_661 any = t.F_k; if linked_658 == nil { impl__5 = ifn_659.Invoke_O_O__O(arg_660, arg_661) } else { impl__5 = linked_658.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_657, arg_660, arg_661) }
//line :103:1
	var tmp6 any
	var and__1927000168__auto____6 any = impl__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp7 any = A_arbace_j2g_dyn_A_const_69; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__5)); if and__1927000168__auto____7 { var root_662 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__5); if linked_663 == nil { tmp6 = ifn_664.Invoke_O__O(arg_665) } else { tmp6 = linked_663.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_662, arg_665) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = and__1927000168__auto____6 }
//line :103:1
	if jrt.J2g_Truth(tmp6) { var root_689 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any; var tmp8 any; var root_679 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_681 lang.IFn


		if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = A_arbace_j2g_dyn_A_const_73; var arg_683 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__5); var arg_684 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp10 any; var root_674 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any; var root_666 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = t.F_k; if linked_667 == nil { arg_677 = ifn_668.Invoke_O__O(arg_669) } else { arg_677 = linked_667.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_666, arg_669) }; var arg_678 any; var root_670 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = t.F_k; if linked_671 == nil { arg_678 = ifn_672.Invoke_O__O(arg_673) } else { arg_678 = linked_671.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_670, arg_673) }; if linked_675 == nil { tmp10 = ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { tmp10 = linked_675.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) }; arg_684 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_680 == nil { tmp8 = ifn_681.Invoke_O_O_O__O(arg_682, arg_683, arg_684) } else { tmp8 = linked_680.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_679, arg_682, arg_683, arg_684) }
//line :103:1
		arg_692 = lang.Tuple_Create_O_O__IPersistentVector(j__4, tmp8); var arg_693 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp12 any; var root_685 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = s__711000108__3; if linked_686 == nil { tmp12 = ifn_687.Invoke_O__O(arg_688) } else { tmp12 = linked_686.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_685, arg_688) }; arg_693 = tmp11.Invoke_O__O(tmp12); if linked_690 == nil { return ifn_691.Invoke_O_O__O(arg_692, arg_693) } else { return linked_690.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_689, arg_692, arg_693) } } else { var tmp13 any; var root_694 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = s__711000108__3; if linked_695 == nil { tmp13 = ifn_696.Invoke_O__O(arg_697) } else { tmp13 = linked_695.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_694, arg_697) }; s__711000108__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Ctor_O_O_I_O(c__k, c__b__711000110 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_b__711000110 = c__b__711000110; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Invoke_O__O(self any) any { { var i__711000109__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000109__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000109__1)); var impl__3 any; var root_597 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_599 lang.IFn
																if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = j__2; var arg_601 any = t.F_k; if linked_598 == nil { impl__3 = ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { impl__3 = linked_598.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }
//line :103:1
	var tmp2 any
	var and__1927000168__auto____4 any = impl__3
	if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp3 any = A_arbace_j2g_dyn_A_const_69; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__3)); if and__1927000168__auto____5 { var root_602 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__3); if linked_603 == nil { tmp2 = ifn_604.Invoke_O__O(arg_605) } else { tmp2 = linked_603.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_602, arg_605) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = and__1927000168__auto____4 }
//line :103:1
	if jrt.J2g_Truth(tmp2) { var root_625 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = t.F_b__711000110; var arg_629 any; var tmp4 any; var root_619 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_621 lang.IFn


		if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = A_arbace_j2g_dyn_A_const_73; var arg_623 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__3); var arg_624 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp6 any; var root_614 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any; var root_606 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = t.F_k; if linked_607 == nil { arg_617 = ifn_608.Invoke_O__O(arg_609) } else { arg_617 = linked_607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_606, arg_609) }; var arg_618 any; var root_610 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = t.F_k; if linked_611 == nil { arg_618 = ifn_612.Invoke_O__O(arg_613) } else { arg_618 = linked_611.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_610, arg_613) }; if linked_615 == nil { tmp6 = ifn_616.Invoke_O_O__O(arg_617, arg_618) } else { tmp6 = linked_615.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_614, arg_617, arg_618) }; arg_624 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_620 == nil { tmp4 = ifn_621.Invoke_O_O_O__O(arg_622, arg_623, arg_624) } else { tmp4 = linked_620.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_619, arg_622, arg_623, arg_624) }
//line :103:1
		arg_629 = lang.Tuple_Create_O_O__IPersistentVector(j__2, tmp4); if linked_626 == nil { ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { linked_626.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) }; i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } else { i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New() *A_arbace_j2g_dyn_defaults_for_fn__711000118_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_fn__711000118_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Ctor() {}
//line :107:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Invoke_O_O__O(self, p__711000117__1 any) any { var vec__711000119__2 any = p__711000117__1; var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000119__2, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_700 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = j__3; if linked_701 == nil { tmp1 = ifn_702.Invoke_O__O(arg_703) } else { tmp1 = linked_701.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_700, arg_703) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp1)))).Ref() }

func A_arbace_j2g_dyn_box_arg_A_New() *A_arbace_j2g_dyn_box_arg_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_box_arg_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_dyn_box_arg_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_dyn_box_arg_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {


	var tmp1 any; var root_715 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = d__1; if linked_716 == nil { tmp1 = ifn_717.Invoke_O__O(arg_718) } else { tmp1 = linked_716.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_715, arg_718) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_82, p__0) } else { var tmp2 any; var root_719 any = A_arbace_j2g_dyn_A_const_80.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_721 lang.IFn
		if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = d__1; if linked_720 == nil { tmp2 = ifn_721.Invoke_O__O(arg_722) } else { tmp2 = linked_720.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_719, arg_722) }
//line :112:1
		if jrt.J2g_Truth(tmp2) {
			return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_83, p__0) } else {
//line :112:1
				if A_arbace_j2g_dyn_A_const_81 != nil { return p__0 } else { return nil
				}
			}
	} }
func A_arbace_j2g_dyn_convert_result_A_New() *A_arbace_j2g_dyn_convert_result_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_dyn_convert_result_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_dyn_convert_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_10) { return r__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1)) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any; var root_732 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = A_arbace_j2g_dyn_A_const_73; var arg_736 any = Lit_16; var arg_737 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp4 any; var root_727 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1); var arg_731 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref(); if linked_728 == nil { tmp4 = ifn_729.Invoke_O_O__O(arg_730, arg_731) } else { tmp4 = linked_728.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_727, arg_730, arg_731) }; arg_737 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_733 == nil { tmp2 = ifn_734.Invoke_O_O_O__O(arg_735, arg_736, arg_737) } else { tmp2 = linked_733.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_732, arg_735, arg_736, arg_737) }; return tmp1.Invoke_O_O__O(tmp2, r__0) } else {
//line :119:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_84).Invoke_O__O(d__1)) {


				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_86; var tmp7 any; var root_738 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = A_arbace_j2g_dyn_A_const_73; var arg_742 any = d__1; if linked_739 == nil { tmp7 = ifn_740.Invoke_O_O__O(arg_741, arg_742) } else { tmp7 = linked_739.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_738, arg_741, arg_742) }; var tmp8 any = tmp7; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_88; var tmp11 any
				if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_18) { tmp11 = A_arbace_j2g_dyn_A_const_89 } else { tmp11 = A_arbace_j2g_dyn_A_const_90 }
//line :122:1
				return tmp5.Invoke_O_O_O__O(tmp6, tmp8, tmp9.Invoke_O_O_O__O(tmp10, tmp11, r__0)) } else {
//line :119:1
					var tmp12 any; var root_723 any = A_arbace_j2g_dyn_A_const_85.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_725 lang.IFn




					if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = d__1; if linked_724 == nil { tmp12 = ifn_725.Invoke_O__O(arg_726) } else { tmp12 = linked_724.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_723, arg_726) }
//line :119:1
					if jrt.J2g_Truth(tmp12) {




						var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyn_A_const_97; var tmp16 any = A_arbace_j2g_dyn_A_const_98; var tmp17 any; var root_776 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = A_arbace_j2g_dyn_A_const_73; var arg_780 any = d__1; if linked_777 == nil { tmp17 = ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { tmp17 = linked_777.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_776, arg_779, arg_780) }; var tmp18 any = tmp14.Invoke_O_O_O__O(tmp15, tmp16, tmp17); var tmp19 any = A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(d__1); var tmp20 *jrt.Class; var fncls__775 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class
						if fncls__775 == nil { var fncls__775d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class = fncls__775d; tmp20 = fncls__775d } else { tmp20 = fncls__775 }
//line :124:1
						return tmp13.Invoke_O_O_O__O(tmp18, r__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil).Invoke__O()) } else {
//line :119:1
							if A_arbace_j2g_dyn_A_const_81 != nil {










								var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp22 any; var root_785 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = A_arbace_j2g_dyn_A_const_73; var arg_789 any; var root_781 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = d__1; if linked_782 == nil { arg_789 = ifn_783.Invoke_O__O(arg_784) } else { arg_789 = linked_782.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_781, arg_784) }; var arg_790 any = Lit_20; if linked_786 == nil { tmp22 = ifn_787.Invoke_O_O_O__O(arg_788, arg_789, arg_790) } else { tmp22 = linked_786.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_785, arg_788, arg_789, arg_790) }; return tmp21.Invoke_O_O__O(tmp22, r__0) } else {
//line :119:1
									return nil
								}
						}
				}
		}
	} }
func A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(p0 any) *A_arbace_j2g_dyn_convert_result_fn__711000126_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :125:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; var n__2 int64 = 0; L1: for { var tmp1 any; var root_743 any = A_arbace_j2g_dyn_A_const_85.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = d__1; if linked_744 == nil { tmp1 = ifn_745.Invoke_O__O(arg_746) } else { tmp1 = linked_744.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_743, arg_746) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_771 any = A_arbace_j2g_dyn_A_const_96.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = d__1; if linked_772 == nil { tmp2 = ifn_773.Invoke_O__O(arg_774) } else { tmp2 = linked_772.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_771, arg_774) }; d__1, n__2 = tmp2, lang.Numbers_Inc_J__J_NoInit(n__2); continue L1 } else {
											var tmp3 any; var root_766 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any; var tmp4 any = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New(); var tmp5 *jrt.Class; var fncls__747 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class; if fncls__747 == nil { var fncls__747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class = fncls__747d; tmp5 = fncls__747d } else { tmp5 = fncls__747 }; arg_769 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_770 any; var tmp6 any; var root_748 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_748, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_750 lang.IFn; if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = d__1; if linked_749 == nil { tmp6 = ifn_750.Invoke_O__O(arg_751) } else { tmp6 = linked_749.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_748, arg_751) }; if jrt.J2g_Truth(tmp6) {
												var root_752 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_94.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); if linked_753 == nil { arg_770 = ifn_754.Invoke_O__O(arg_755) } else { arg_770 = linked_753.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_752, arg_755) } } else {
													var root_760 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = A_arbace_j2g_dyn_A_const_73; var arg_764 any; var root_756 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = d__1; if linked_757 == nil { arg_764 = ifn_758.Invoke_O__O(arg_759) } else { arg_764 = linked_757.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_756, arg_759) }; var arg_765 any = Lit_23; if linked_761 == nil { arg_770 = ifn_762.Invoke_O_O_O__O(arg_763, arg_764, arg_765) } else { arg_770 = linked_761.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_760, arg_763, arg_764, arg_765) } }
//line :126:1
	if linked_767 == nil { tmp3 = ifn_768.Invoke_O_O__O(arg_769, arg_770) } else { tmp3 = linked_767.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_766, arg_769, arg_770) }; return lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(n__2)) } } }; /*line :125:1*/panic("j2g: unreachable") }
func A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New() *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Ctor() {}
//line :126:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Invoke_O_O__O(self, p1__711000125_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_92, p1__711000125_SHARP___1) }





func A_arbace_j2g_dyn_call_impl_A_New() *A_arbace_j2g_dyn_call_impl_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_call_impl_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_dyn_call_impl_A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O_O__O(self, this__0, args__1 any) any { var n__3 int64 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(args__1))); if





	lang.Numbers_Lte_J_J__Z_NoInit(n__3, 20) {
		var root_810 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_814 any; var root_806 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp2 any; var root_801 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = Lit_9; var arg_805 any; var root_796 any = A_arbace_j2g_dyn_A_const_100.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any; var root_791 any = A_arbace_j2g_dyn_A_const_101.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref(); var arg_795 any = Lit_10; if linked_792 == nil { arg_799 = ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { arg_799 = linked_792.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_791, arg_794, arg_795) }; var arg_800 any = Lit_10; if linked_797 == nil { arg_805 = ifn_798.Invoke_O_O__O(arg_799, arg_800) } else { arg_805 = linked_797.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_796, arg_799, arg_800) }; if linked_802 == nil { tmp2 = ifn_803.Invoke_O_O__O(arg_804, arg_805) } else { tmp2 = linked_802.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_801, arg_804, arg_805) }; arg_809 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_807 == nil { arg_814 = ifn_808.Invoke_O__O(arg_809) } else { arg_814 = linked_807.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_806, arg_809) }; var arg_815 any = A_arbace_j2g_dyn_A_const_102; var arg_816 any = this__0; var arg_817 any = args__1; if linked_811 == nil { return ifn_812.Invoke_O_O_O_O_O__O(arg_813, arg_814, arg_815, arg_816, arg_817) } else { return linked_811.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_810, arg_813, arg_814, arg_815, arg_816, arg_817) } } else {

			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyn_A_const_103; var tmp5 any = A_arbace_j2g_dyn_A_const_104; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_105; var tmp8 any; var root_818 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_822 any = A_arbace_j2g_dyn_A_const_106; var arg_823 any = A_arbace_j2g_dyn_A_const_107; var arg_824 any = this__0; var arg_825 any = args__1; if linked_819 == nil { tmp8 = ifn_820.Invoke_O_O_O_O_O__O(arg_821, arg_822, arg_823, arg_824, arg_825) } else { tmp8 = linked_819.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_818, arg_821, arg_822, arg_823, arg_824, arg_825) }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8)) } }
//line :132:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O__O(self, args__0 any) any {


	var root_826 any = A_arbace_j2g_dyn_A_const_108.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = A_arbace_j2g_dyn_A_const_109; var arg_830 any = args__0; if linked_827 == nil { return ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { return linked_827.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_826, arg_829, arg_830)
	}
}







func A_arbace_j2g_dyn_abstract_text_A_New() *A_arbace_j2g_dyn_abstract_text_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Ctor() {}
//line :145:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Invoke_O_O_O__O(self, ifaces__0, p__711000134__1 any) any { var vec__711000135__3 any = p__711000134__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000135__3; var vec__711000138__7 any; var root_831 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_833 lang.IFn; if



	linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = desc__5; if linked_832 == nil { vec__711000138__7 = ifn_833.Invoke_O__O(arg_834) } else { vec__711000138__7 = linked_832.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_831, arg_834) }; var ps__8 any = /*line :145:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(1), nil); var declares_QMARK___10 any; var tmp1 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(name__4, desc__5); var tmp2 *jrt.Class; var fncls__845 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class; if




	fncls__845 == nil { var fncls__845d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class = fncls__845d; tmp2 = fncls__845d } else { tmp2 = fncls__845 }; declares_QMARK___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var j__11 any; var or__1927000174__auto____11 any; var root_851 any = /*line :145:1*/A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_853 lang.IFn; if





	linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any; var root_846 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = declares_QMARK___10; var arg_850 any = ifaces__0; if linked_847 == nil { arg_854 = ifn_848.Invoke_O_O__O(arg_849, arg_850) } else { arg_854 = linked_847.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_846, arg_849, arg_850) }; if linked_852 == nil { or__1927000174__auto____11 = ifn_853.Invoke_O__O(arg_854) } else { or__1927000174__auto____11 = linked_852.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_851, arg_854) }; if jrt.J2g_Truth(or__1927000174__auto____11) { j__11 = or__1927000174__auto____11 } else {
		var root_871 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any; var root_866 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any; var tmp3 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(k__6); var tmp4 *jrt.Class; var fncls__865 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class; if fncls__865 == nil { var fncls__865d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class = fncls__865d; tmp4 = fncls__865d } else { tmp4 = fncls__865 }; arg_869 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_870 any = ifaces__0; if linked_867 == nil { arg_874 = ifn_868.Invoke_O_O__O(arg_869, arg_870) } else { arg_874 = linked_867.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_866, arg_869, arg_870) }; if linked_872 == nil { j__11 = ifn_873.Invoke_O__O(arg_874) } else { j__11 = linked_872.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_871, arg_874) } }; var tmp5 /*line :153:1*/*jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp6 any; var root_875 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = r__9; if linked_876 == nil { tmp6 = ifn_877.Invoke_O__O(arg_878) } else { tmp6 = linked_876.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_875, arg_878) }; var tmp7 any = tmp6; var tmp8 any; var root_884 any = A_arbace_j2g_dyn_A_const_115.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = Lit_3; var arg_888 any; var root_879 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var arg_883 any = ps__8; if linked_880 == nil { arg_888 = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { arg_888 = linked_880.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) }; if linked_885 == nil { tmp8 = ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { tmp8 = linked_885.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_884, arg_887, arg_888) }; var tmp9 any = tmp8; var tmp10 *jrt.String; if
	jrt.J2g_Truth(j__11) { var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil); var tmp12 any; var root_889 any = A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = j__11; var arg_893 any = Lit_5; var arg_894 any = Lit_6; if linked_890 == nil { tmp12 = ifn_891.Invoke_O_O_O__O(arg_892, arg_893, arg_894) } else { tmp12 = linked_890.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_889, arg_892, arg_893, arg_894) }; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)) } else { tmp10 = nil }; return /*line :153:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, name__4, nil, tmp9, nil, tmp10.Ref(), nil)).Ref() }
//line :150:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :150:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Invoke_O_O__O(self, j__1 any) any { var root_840 any = A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any; var tmp1 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(t.F_name, t.F_desc); var tmp2 *jrt.Class; var fncls__835 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class; if fncls__835 == nil { var fncls__835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class = fncls__835d; tmp2 = fncls__835d } else { tmp2 = fncls__835 }; arg_843 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_844 any; var tmp3 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp4 any; var root_836 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = j__1; if linked_837 == nil { tmp4 = ifn_838.Invoke_O__O(arg_839) } else { tmp4 = linked_837.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_836, arg_839) }; arg_844 = tmp3.Invoke_O__O(tmp4); if linked_841 == nil { return ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { return linked_841.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_840, arg_843, arg_844) } }
//line :150:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :150:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Invoke_O_O__O(self, p1__711000132_SHARP___1 any) any { var tmp1 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(p1__711000132_SHARP___1)); if and__1927000168__auto____2 { var tmp2 any = t.F_desc; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_dyn_A_const_65.Invoke_O__O(p1__711000132_SHARP___1))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Invoke_O_O__O(self, p1__711000133_SHARP___1 any) any { var root_860 any = A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var tmp1 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(t.F_k); var tmp2 *jrt.Class; var fncls__855 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class; if fncls__855 == nil { var fncls__855d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class = fncls__855d; tmp2 = fncls__855d } else { tmp2 = fncls__855 }; arg_863 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_864 any; var root_856 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = p1__711000133_SHARP___1; if linked_857 == nil { arg_864 = ifn_858.Invoke_O__O(arg_859) } else { arg_864 = linked_857.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_856, arg_859) }; if linked_861 == nil { return ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { return linked_861.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) } }
//line :152:1
func A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Invoke_O_O__O(self, p__711000146__1 any) any { var vec__711000148__2 any = p__711000146__1; var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(kk__3, t.F_k)).Ref() }



func A_arbace_j2g_dyn_iface_fallback_A_New() *A_arbace_j2g_dyn_iface_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Ctor() {}
//line :156:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O_O__O(self, ifaces__0, p__711000154__1, pn__2, r__3, core_QMARK___4 any) any { var vec__711000155__6 any = p__711000154__1; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000155__6; var root_1014 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1016 lang.IFn; _ = name__7; _ = desc__8; if





	linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any; var iter__1927001039__auto____10 any; var tmp1 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(r__3, pn__2, core_QMARK___4); var tmp2 *jrt.Class; var fncls__1003 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class; if
	fncls__1003 == nil { var fncls__1003d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class = fncls__1003d; tmp2 = fncls__1003d } else { tmp2 = fncls__1003 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp4 any; var root_1004 any = A_arbace_j2g_dyn_A_const_127.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, A_arbace_j2g_dyn_defaults_for_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = ifaces__0; var arg_1008 any = k__9; if linked_1005 == nil { tmp4 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { tmp4 = linked_1005.(*A_arbace_j2g_dyn_defaults_for_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }; arg_1017 = tmp3.Invoke_O__O(tmp4); var arg_1018 any; var tmp5 lang.IFn = /*line :162:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_128; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_129; var tmp9 any = A_arbace_j2g_dyn_A_const_130; var tmp10 any; var root_1009 any = A_arbace_j2g_dyn_A_const_131.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_j2g_dyn_abstract_text_A_fn_class); var ifn_1011 lang.IFn; if




	linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = ifaces__0; var arg_1013 any = k__9; if linked_1010 == nil { tmp10 = ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { tmp10 = linked_1010.(*A_arbace_j2g_dyn_abstract_text_A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) }; arg_1018 = /*line :162:1*/lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10))); if linked_1015 == nil { return ifn_1016.Invoke_O_O__O(arg_1017, arg_1018) } else { return linked_1015.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1014, arg_1017, arg_1018) } }
//line :156:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O__O(self, ifaces__0, k__1, pn__2, r__3 any) any {



	var root_1019 any = A_arbace_j2g_dyn_A_const_132.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = ifaces__0; var arg_1023 any = k__1; var arg_1024 any = pn__2; var arg_1025 any = r__3; var arg_1026 any = jrt.Boolean_FALSE.Ref(); if linked_1020 == nil { return ifn_1021.Invoke_O_O_O_O_O__O(arg_1022, arg_1023, arg_1024, arg_1025, arg_1026) } else { return linked_1020.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1019, arg_1022, arg_1023, arg_1024, arg_1025, arg_1026)
	}
}
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Ctor_O_O_O(c__r, c__pn, c__core_QMARK_ any) { t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Invoke_O_O__O(self, s__711000159__1 any) any { var tmp1 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(self, s__711000159__1, t.F_r, t.F_pn, t.F_core_QMARK_); var tmp2 *jrt.Class; var fncls__1002 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class; if fncls__1002 == nil { var fncls__1002d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class = fncls__1002d; tmp2 = fncls__1002d } else { tmp2 = fncls__1002 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :163:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Ctor_O_O_O_O_O(c__iter__711000158, c__s__711000159, c__r, c__pn, c__core_QMARK_ any) { t.F_iter__711000158 = c__iter__711000158; t.F_s__711000159 = c__s__711000159; t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Invoke_O__O(self any) any { { var s__711000159__1 any; var t_ any = t.F_s__711000159; t.F_s__711000159 = nil; s__711000159__1 = t_; for { var temp__1927000414__auto____2 any; var root_895 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = s__711000159__1; if linked_896 == nil { temp__1927000414__auto____2 = ifn_897.Invoke_O__O(arg_898) } else { temp__1927000414__auto____2 = linked_896.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_895, arg_898) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000159__3 any = temp__1927000414__auto____2; var tmp1 any; var root_899 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = s__711000159__3; if linked_900 == nil { tmp1 = ifn_901.Invoke_O__O(arg_902) } else { tmp1 = linked_900.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_899, arg_902) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_903 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = s__711000159__3; if linked_904 == nil { c__1927001037__auto____4 = ifn_905.Invoke_O__O(arg_906) } else { c__1927001037__auto____4 = linked_904.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_903, arg_906) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000161__6 any; var root_907 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_908 == nil { b__711000161__6 = ifn_909.Invoke_O__O(arg_910) } else { b__711000161__6 = linked_908.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_907, arg_910) }; var tmp2 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(b__711000161__6, t.F_r, t.F_pn, size__1927001038__auto____5, t.F_core_QMARK_, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__941 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class; if fncls__941 == nil { var fncls__941d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class = fncls__941d; tmp3 = fncls__941d } else { tmp3 = fncls__941 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_950 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any; var root_942 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = b__711000161__6; if linked_943 == nil { arg_953 = ifn_944.Invoke_O__O(arg_945) } else { arg_953 = linked_943.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_942, arg_945) }; var arg_954 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp5 any; var root_946 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = s__711000159__3; if linked_947 == nil { tmp5 = ifn_948.Invoke_O__O(arg_949) } else { tmp5 = linked_947.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_946, arg_949) }; arg_954 = tmp4.Invoke_O__O(tmp5); if linked_951 == nil { return ifn_952.Invoke_O_O__O(arg_953, arg_954) } else { return linked_951.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_950, arg_953, arg_954) } } else { var root_959 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any; var root_955 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = b__711000161__6; if linked_956 == nil { arg_962 = ifn_957.Invoke_O__O(arg_958) } else { arg_962 = linked_956.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_955, arg_958) }; var arg_963 any; if linked_960 == nil { return ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { return linked_960.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_959, arg_962, arg_963) } } } else { var vec__711000169__4 any; var root_964 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = s__711000159__3; if linked_965 == nil { vec__711000169__4 = ifn_966.Invoke_O__O(arg_967) } else { vec__711000169__4 = linked_965.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_964, arg_967) }; var j__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(1), nil); var this__7 any
														if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_119; var tmp8 any; var root_997 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = A_arbace_j2g_dyn_A_const_73; var arg_1001 any = j__5; if linked_998 == nil { tmp8 = ifn_999.Invoke_O_O__O(arg_1000, arg_1001) } else { tmp8 = linked_998.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_997, arg_1000, arg_1001) }; this__7 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, A_arbace_j2g_dyn_A_const_120) } else { this__7 = A_arbace_j2g_dyn_A_const_118 }
//line :163:1
	var root_992 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_121; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyn_A_const_122; var tmp13 any = A_arbace_j2g_dyn_A_const_123; var tmp14 any; var root_968 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_970 lang.IFn

	if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = A_arbace_j2g_dyn_A_const_73; var arg_972 any = j__5; var arg_973 any = Lit_23; if linked_969 == nil { tmp14 = ifn_970.Invoke_O_O_O__O(arg_971, arg_972, arg_973) } else { tmp14 = linked_969.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_968, arg_971, arg_972, arg_973) }; var tmp15 any = tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14); var tmp16 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_15, t.F_r) { var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_124; var tmp19 any; var root_974 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_978 any = fsym__6; var arg_979 any = this__7; var arg_980 any = t.F_pn; if linked_975 == nil { tmp19 = ifn_976.Invoke_O_O_O_O__O(arg_977, arg_978, arg_979, arg_980) } else { tmp19 = linked_975.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_974, arg_977, arg_978, arg_979, arg_980) }; tmp16 = tmp17.Invoke_O_O_O__O(tmp18, tmp19, A_arbace_j2g_dyn_A_const_125) } else { var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyn_A_const_126; var tmp22 any; var root_981 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_985 any = fsym__6; var arg_986 any = this__7; var arg_987 any = t.F_pn; if linked_982 == nil { tmp22 = ifn_983.Invoke_O_O_O_O__O(arg_984, arg_985, arg_986, arg_987) } else { tmp22 = linked_982.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_981, arg_984, arg_985, arg_986, arg_987) }; tmp16 = tmp20.Invoke_O_O__O(tmp21, tmp22) }
//line :165:1
	arg_995 = tmp9.Invoke_O_O_O__O(tmp10, tmp15, tmp16)
//line :163:1
	var arg_996 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp24 any; var root_988 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = s__711000159__3; if linked_989 == nil { tmp24 = ifn_990.Invoke_O__O(arg_991) } else { tmp24 = linked_989.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_988, arg_991) }; arg_996 = tmp23.Invoke_O__O(tmp24); if linked_993 == nil { return ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { return linked_993.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_992, arg_995, arg_996) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :163:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Ctor_O_O_O_I_O_O(c__b__711000161, c__r, c__pn any, c__size__1927001038__auto__ int32, c__core_QMARK_, c__c__1927001037__auto__ any) { t.F_b__711000161 = c__b__711000161; t.F_r = c__r; t.F_pn = c__pn; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_core_QMARK_ = c__core_QMARK_; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Invoke_O__O(self any) any { { var i__711000160__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000160__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000165__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000160__1)); var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(1), nil); var this__5 any
																if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_119; var tmp4 any; var root_911 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = A_arbace_j2g_dyn_A_const_73; var arg_915 any = j__3; if linked_912 == nil { tmp4 = ifn_913.Invoke_O_O__O(arg_914, arg_915) } else { tmp4 = linked_912.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_911, arg_914, arg_915) }; this__5 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_j2g_dyn_A_const_120) } else { this__5 = A_arbace_j2g_dyn_A_const_118 }
//line :163:1
	var root_936 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = t.F_b__711000161; var arg_940 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_121; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_122; var tmp9 any = A_arbace_j2g_dyn_A_const_123; var tmp10 any; var root_916 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_918 lang.IFn

	if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = A_arbace_j2g_dyn_A_const_73; var arg_920 any = j__3; var arg_921 any = Lit_23; if linked_917 == nil { tmp10 = ifn_918.Invoke_O_O_O__O(arg_919, arg_920, arg_921) } else { tmp10 = linked_917.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_916, arg_919, arg_920, arg_921) }; var tmp11 any = tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10); var tmp12 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_15, t.F_r) { var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyn_A_const_124; var tmp15 any; var root_922 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_926 any = fsym__4; var arg_927 any = this__5; var arg_928 any = t.F_pn; if linked_923 == nil { tmp15 = ifn_924.Invoke_O_O_O_O__O(arg_925, arg_926, arg_927, arg_928) } else { tmp15 = linked_923.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_922, arg_925, arg_926, arg_927, arg_928) }; tmp12 = tmp13.Invoke_O_O_O__O(tmp14, tmp15, A_arbace_j2g_dyn_A_const_125) } else { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_126; var tmp18 any; var root_929 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_933 any = fsym__4; var arg_934 any = this__5; var arg_935 any = t.F_pn; if linked_930 == nil { tmp18 = ifn_931.Invoke_O_O_O_O__O(arg_932, arg_933, arg_934, arg_935) } else { tmp18 = linked_930.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_929, arg_932, arg_933, arg_934, arg_935) }; tmp12 = tmp16.Invoke_O_O__O(tmp17, tmp18) }
//line :165:1
	arg_940 = tmp5.Invoke_O_O_O__O(tmp6, tmp11, tmp12)
//line :163:1
	if linked_937 == nil { ifn_938.Invoke_O_O__O(arg_939, arg_940) } else { linked_937.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_936, arg_939, arg_940) }; i__711000160__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000160__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyn_method_form_A_New() *A_arbace_j2g_dyn_method_form_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_j2g_dyn_method_form_A) Ctor() {}
//line :169:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O_O__O(self, recv__0, i__1, p__711000177__2, fallback__3, this__4 any) any { var vec__711000180__6 any = p__711000177__2; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000180__6; var vec__711000183__10 any; var root_1027 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1029 lang.IFn; _ = k__9; if






	linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = desc__8; if linked_1028 == nil { vec__711000183__10 = ifn_1029.Invoke_O__O(arg_1030) } else { vec__711000183__10 = linked_1028.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1027, arg_1030) }; var ps__11 any = /*line :169:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_1102 any = A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1104 lang.IFn; if







	linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any; var iter__1927001039__auto____13 any; var tmp1 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New(); var tmp2 *jrt.Class; var fncls__1097 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class; if fncls__1097 == nil { var fncls__1097d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class = fncls__1097d; tmp2 = fncls__1097d } else { tmp2 = fncls__1097 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp4 any; var root_1098 any = A_arbace_j2g_dyn_A_const_133.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__11)).Ref(); if linked_1099 == nil { tmp4 = ifn_1100.Invoke_O__O(arg_1101) } else { tmp4 = linked_1099.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1098, arg_1101) }; arg_1105 = tmp3.Invoke_O__O(tmp4); if linked_1103 == nil { pn__13 = ifn_1104.Invoke_O__O(arg_1105) } else { pn__13 = linked_1103.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1102, arg_1105) }; var base__14 any; var root_1106 any = /*line :169:1*/A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1108 lang.IFn; if








	linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = name__7; var arg_1110 any = desc__8; if linked_1107 == nil { base__14 = ifn_1108.Invoke_O_O__O(arg_1109, arg_1110) } else { base__14 = linked_1107.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1106, arg_1109, arg_1110) }; var params__15 any; var root_1138 any = /*line :169:1*/A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1140 lang.IFn; if









	linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any; var root_1133 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any; var root_1111 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = A_arbace_j2g_dyn_A_const_135; var arg_1115 any = recv__0; if linked_1112 == nil { arg_1136 = ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { arg_1136 = linked_1112.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) }; var arg_1137 any; var root_1127 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any; var tmp5 any = A_arbace_j2g_dyn_method_form_fn__711000196_A_New(); var tmp6 *jrt.Class; var fncls__1126 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class; if fncls__1126 == nil { var fncls__1126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class = fncls__1126d; tmp6 = fncls__1126d } else { tmp6 = fncls__1126 }; arg_1130 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1131 any = pn__13; var arg_1132 any = ps__11; if linked_1128 == nil { arg_1137 = ifn_1129.Invoke_O_O_O__O(arg_1130, arg_1131, arg_1132) } else { arg_1137 = linked_1128.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1127, arg_1130, arg_1131, arg_1132) }; if linked_1134 == nil { arg_1141 = ifn_1135.Invoke_O_O__O(arg_1136, arg_1137) } else { arg_1141 = linked_1134.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1133, arg_1136, arg_1137) }; if linked_1139 == nil { params__15 = ifn_1140.Invoke_O__O(arg_1141) } else { params__15 = linked_1139.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1138, arg_1141) }; var params__16 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_15, r__12) { params__16 = params__15 } else { var root_1147 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = params__15; var arg_1151 any; var tmp7 any = A_arbace_j2g_dyn_A_const_17; var tmp8 any; var root_1142 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = A_arbace_j2g_dyn_A_const_73; var arg_1146 any = r__12; if linked_1143 == nil { tmp8 = ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { tmp8 = linked_1143.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) }; arg_1151 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)); if linked_1148 == nil { params__16 = ifn_1149.Invoke_O_O__O(arg_1150, arg_1151) } else { params__16 = linked_1148.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1147, arg_1150, arg_1151) } }; var call__17 any; var root_1158 any = /*line :169:1*/A_arbace_j2g_dyn_A_const_108.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_1160 lang.IFn; if











	linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = this__4; var arg_1162 any; var root_1152 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var arg_1156 any = pn__13; var arg_1157 any = ps__11; if linked_1153 == nil { arg_1162 = ifn_1154.Invoke_O_O_O__O(arg_1155, arg_1156, arg_1157) } else { arg_1162 = linked_1153.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1152, arg_1155, arg_1156, arg_1157) }; if linked_1159 == nil { call__17 = ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { call__17 = linked_1159.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) }; var tmp9 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_99.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var tmp11 any = A_arbace_j2g_dyn_A_const_137; var tmp12 any; var root_1163 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = base__14; if linked_1164 == nil { tmp12 = ifn_1165.Invoke_O__O(arg_1166) } else { tmp12 = linked_1164.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1163, arg_1166) }; var tmp13 any = tmp12; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyn_A_const_138; var tmp16 any = A_arbace_j2g_dyn_A_const_139; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_140; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_dyn_A_const_141; var tmp21 any = lang.Tuple_Create_O_O__IPersistentVector(tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_142, A_arbace_j2g_dyn_A_const_143)), i__1)); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyn_A_const_144; var tmp24 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_145, A_arbace_j2g_dyn_A_const_146, nil); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyn_A_const_147; var tmp27 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_148, call__17); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyn_A_const_149; var tmp30 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_151, A_arbace_j2g_dyn_A_const_152, A_arbace_j2g_dyn_A_const_153); var tmp31 any; if




	lang.Util_Equiv_O_O__Z_NoInit(Lit_15, r__12) { tmp31 = A_arbace_j2g_dyn_A_const_150 } else { var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_dyn_A_const_154; var tmp34 any; var root_1167 any = A_arbace_j2g_dyn_A_const_155.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, A_arbace_j2g_dyn_convert_result_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = A_arbace_j2g_dyn_A_const_156; var arg_1171 any = r__12; if linked_1168 == nil { tmp34 = ifn_1169.Invoke_O_O__O(arg_1170, arg_1171) } else { tmp34 = linked_1168.(*A_arbace_j2g_dyn_convert_result_A).Invoke_O_O_O__O(root_1167, arg_1170, arg_1171) }; tmp31 = tmp32.Invoke_O_O__O(tmp33, tmp34) }; return /*line :182:1*/ tmp9.Invoke_O_O_O_O_O_O__O(tmp10, tmp11, tmp13, params__16, tmp14.Invoke_O_O_O__O(tmp15, tmp21, tmp22.Invoke_O_O_O__O(tmp23, tmp24, tmp25.Invoke_O_O_O__O(tmp26, tmp27, tmp28.Invoke_O_O_O__O(tmp29, tmp30, tmp31)))), lang.IFn_Cast(fallback__3).Invoke_O_O__O(pn__13, r__12)) }
//line :169:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O__O(self, recv__0, i__1, k__2, fallback__3 any) any {




	var root_1181 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = recv__0; var arg_1185 any = i__1; var arg_1186 any = k__2; var arg_1187 any = fallback__3; var arg_1188 any = A_arbace_j2g_dyn_A_const_158; if linked_1182 == nil { return ifn_1183.Invoke_O_O_O_O_O__O(arg_1184, arg_1185, arg_1186, arg_1187, arg_1188) } else { return linked_1182.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1181, arg_1184, arg_1185, arg_1186, arg_1187, arg_1188) } }
//line :169:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O__O(self, ifaces__0, i__1, k__2 any) any {



	var root_1198 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = A_arbace_j2g_dyn_A_const_159; var arg_1202 any = i__1; var arg_1203 any = k__2; var arg_1204 any; var tmp1 any = A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(k__2, ifaces__0); var tmp2 *jrt.Class; var fncls__1197 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class; if fncls__1197 == nil { var fncls__1197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class = fncls__1197d; tmp2 = fncls__1197d } else { tmp2 = fncls__1197 }; arg_1204 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1205 any = A_arbace_j2g_dyn_A_const_160; if linked_1199 == nil { return ifn_1200.Invoke_O_O_O_O_O__O(arg_1201, arg_1202, arg_1203, arg_1204, arg_1205) } else { return linked_1199.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1198, arg_1201, arg_1202, arg_1203, arg_1204, arg_1205) } }
//line :173:1
func A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_fn__711000178_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000178_A{}; t.Ctor_O_O(p0, p1); return t }
//line :173:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :173:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_1189 any = A_arbace_j2g_dyn_A_const_132.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = t.F_ifaces; var arg_1193 any = t.F_k; var arg_1194 any = pn__1; var arg_1195 any = r__2; var arg_1196 any = jrt.Boolean_TRUE.Ref(); if linked_1190 == nil { return ifn_1191.Invoke_O_O_O_O_O__O(arg_1192, arg_1193, arg_1194, arg_1195, arg_1196) } else { return linked_1190.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1189, arg_1192, arg_1193, arg_1194, arg_1195, arg_1196) } }



func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New() *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Invoke_O_O__O(self, s__711000187__1 any) any { var tmp1 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(s__711000187__1, self); var tmp2 *jrt.Class; var fncls__1096 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class; if fncls__1096 == nil { var fncls__1096d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class = fncls__1096d; tmp2 = fncls__1096d } else { tmp2 = fncls__1096 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :177:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A{}; t.Ctor_O_O(p0, p1); return t }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Ctor_O_O(c__s__711000187, c__iter__711000186 any) { t.F_s__711000187 = c__s__711000187; t.F_iter__711000186 = c__iter__711000186 }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Invoke_O__O(self any) any { { var s__711000187__1 any; var t_ any = t.F_s__711000187; t.F_s__711000187 = nil; s__711000187__1 = t_; for { var temp__1927000414__auto____2 any; var root_1031 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = s__711000187__1; if linked_1032 == nil { temp__1927000414__auto____2 = ifn_1033.Invoke_O__O(arg_1034) } else { temp__1927000414__auto____2 = linked_1032.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1031, arg_1034) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000187__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1035 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = s__711000187__3; if linked_1036 == nil { tmp1 = ifn_1037.Invoke_O__O(arg_1038) } else { tmp1 = linked_1036.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1035, arg_1038) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1039 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = s__711000187__3; if linked_1040 == nil { c__1927001037__auto____4 = ifn_1041.Invoke_O__O(arg_1042) } else { c__1927001037__auto____4 = linked_1040.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1039, arg_1042) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000189__6 any; var root_1043 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1044 == nil { b__711000189__6 = ifn_1045.Invoke_O__O(arg_1046) } else { b__711000189__6 = linked_1044.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1043, arg_1046) }; var tmp2 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(b__711000189__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1056 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class; if fncls__1056 == nil { var fncls__1056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class = fncls__1056d; tmp3 = fncls__1056d } else { tmp3 = fncls__1056 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1065 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any; var root_1057 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = b__711000189__6; if linked_1058 == nil { arg_1068 = ifn_1059.Invoke_O__O(arg_1060) } else { arg_1068 = linked_1058.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1057, arg_1060) }; var arg_1069 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp5 any; var root_1061 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = s__711000187__3; if linked_1062 == nil { tmp5 = ifn_1063.Invoke_O__O(arg_1064) } else { tmp5 = linked_1062.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1061, arg_1064) }; arg_1069 = tmp4.Invoke_O__O(tmp5); if linked_1066 == nil { return ifn_1067.Invoke_O_O__O(arg_1068, arg_1069) } else { return linked_1066.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1065, arg_1068, arg_1069) } } else { var root_1074 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any; var root_1070 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = b__711000189__6; if linked_1071 == nil { arg_1077 = ifn_1072.Invoke_O__O(arg_1073) } else { arg_1077 = linked_1071.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1070, arg_1073) }; var arg_1078 any; if linked_1075 == nil { return ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { return linked_1075.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) } } } else { var j__4 any; var root_1079 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = s__711000187__3; if linked_1080 == nil { j__4 = ifn_1081.Invoke_O__O(arg_1082) } else { j__4 = linked_1080.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1079, arg_1082) }; var root_1091 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any; var root_1083 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_124, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__4)).Ref(); if linked_1084 == nil { arg_1094 = ifn_1085.Invoke_O__O(arg_1086) } else { arg_1094 = linked_1084.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1083, arg_1086) }; var arg_1095 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp7 any; var root_1087 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = s__711000187__3; if linked_1088 == nil { tmp7 = ifn_1089.Invoke_O__O(arg_1090) } else { tmp7 = linked_1088.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1087, arg_1090) }; arg_1095 = tmp6.Invoke_O__O(tmp7); if linked_1092 == nil { return ifn_1093.Invoke_O_O__O(arg_1094, arg_1095) } else { return linked_1092.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1091, arg_1094, arg_1095) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :177:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Ctor_O_I_O(c__b__711000189 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000189 = c__b__711000189; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Invoke_O__O(self any) any { { var i__711000188__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000188__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000188__1)); var root_1051 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = t.F_b__711000189; var arg_1055 any; var root_1047 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_124, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__2)).Ref(); if linked_1048 == nil { arg_1055 = ifn_1049.Invoke_O__O(arg_1050) } else { arg_1055 = linked_1048.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1047, arg_1050) }; if linked_1052 == nil { ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { linked_1052.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) }; i__711000188__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000188__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_method_form_fn__711000196_A_New() *A_arbace_j2g_dyn_method_form_fn__711000196_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000196_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Ctor() {}
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Invoke_O_O_O__O(self, p1__711000175_SHARP___1, p2__711000176_SHARP___2 any) any { var root_1121 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = p1__711000175_SHARP___1; var arg_1125 any; var root_1116 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = A_arbace_j2g_dyn_A_const_73; var arg_1120 any = p2__711000176_SHARP___2; if linked_1117 == nil { arg_1125 = ifn_1118.Invoke_O_O__O(arg_1119, arg_1120) } else { arg_1125 = linked_1117.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1116, arg_1119, arg_1120) }; if linked_1122 == nil { return ifn_1123.Invoke_O_O__O(arg_1124, arg_1125) } else { return linked_1122.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1121, arg_1124, arg_1125) } }










func A_arbace_j2g_dyn_native_name_A_New() *A_arbace_j2g_dyn_native_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_native_name_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_j2g_dyn_native_name_A) Ctor() {}
//line :190:1
func (t *A_arbace_j2g_dyn_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil, Lit_125); var tmp2 any; var root_1206 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); if linked_1207 == nil { tmp2 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp2 = linked_1207.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1206, arg_1209) }; var tmp3 any = tmp2; var tmp4 any; var root_1210 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = mname__0; var arg_1214 any = desc__1; if linked_1211 == nil { tmp4 = ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { tmp4 = linked_1211.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref()
}























func A_arbace_j2g_dyn_proxy_classes_A_New() *A_arbace_j2g_dyn_proxy_classes_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Ctor() {}
//line :216:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Invoke_O_O__O(self, T__0_ any) any {



	var root_1253 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any; var tmp1 any = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(T__0_); var tmp2 *jrt.Class; var fncls__1252 *jrt.Class = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class; if fncls__1252 == nil { var fncls__1252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class = fncls__1252d; tmp2 = fncls__1252d } else { tmp2 = fncls__1252 }; arg_1256 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1257 any = A_arbace_j2g_dyn_A_const_163.GetRawRoot__O(); if linked_1254 == nil { return ifn_1255.Invoke_O_O__O(arg_1256, arg_1257) } else { return linked_1254.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1253, arg_1256, arg_1257) } }
//line :220:1
func A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_fn__711000201_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Ctor_O(c__T any) { t.F_T = c__T }
//line :220:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Invoke_O_O__O(self, p1__711000200_SHARP___1 any) any { var and__1927000168__auto____2 any; var or__1927000174__auto____2 any; var root_1215 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = t.F_T; var arg_1219 any = p1__711000200_SHARP___1; if linked_1216 == nil { or__1927000174__auto____2 = ifn_1217.Invoke_O_O__O(arg_1218, arg_1219) } else { or__1927000174__auto____2 = linked_1216.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1215, arg_1218, arg_1219) }; if jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { var root_1220 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = p1__711000200_SHARP___1; if linked_1221 == nil { and__1927000168__auto____2 = ifn_1222.Invoke_O__O(arg_1223) } else { and__1927000168__auto____2 = linked_1221.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1220, arg_1223) } }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1224 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = p1__711000200_SHARP___1; if linked_1225 == nil { and__1927000168__auto____3 = ifn_1226.Invoke_O__O(arg_1227) } else { and__1927000168__auto____3 = linked_1225.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_1224, arg_1227) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1232 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1234 lang.IFn
														if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any; var root_1228 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = p1__711000200_SHARP___1; if linked_1229 == nil { arg_1235 = ifn_1230.Invoke_O__O(arg_1231) } else { arg_1235 = linked_1229.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1228, arg_1231) }; if linked_1233 == nil { and__1927000168__auto____4 = ifn_1234.Invoke_O__O(arg_1235) } else { and__1927000168__auto____4 = linked_1233.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1232, arg_1235) }
//line :220:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1240 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1242 lang.IFn
		if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var root_1236 any = A_arbace_j2g_dyn_A_const_161.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = p1__711000200_SHARP___1; if linked_1237 == nil { arg_1243 = ifn_1238.Invoke_O__O(arg_1239) } else { arg_1243 = linked_1237.(*aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_1236, arg_1239) }; if linked_1241 == nil { and__1927000168__auto____5 = ifn_1242.Invoke_O__O(arg_1243) } else { and__1927000168__auto____5 = linked_1241.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1240, arg_1243) }
//line :220:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_1248 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any; var root_1244 any = A_arbace_j2g_dyn_A_const_162.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_1246 lang.IFn; if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = p1__711000200_SHARP___1; if linked_1245 == nil { arg_1251 = ifn_1246.Invoke_O__O(arg_1247) } else { arg_1251 = linked_1245.(*aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_1244, arg_1247) }; if linked_1249 == nil { return ifn_1250.Invoke_O__O(arg_1251) } else { return linked_1249.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1248, arg_1251) } } else {
//line :220:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_j2g_dyn_sub_name_A_New() *A_arbace_j2g_dyn_sub_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_name_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_j2g_dyn_sub_name_A) Ctor() {}
//line :224:1
func (t *A_arbace_j2g_dyn_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_166, nil); var tmp2 any; var root_1258 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = n__0; if linked_1259 == nil { tmp2 = ifn_1260.Invoke_O__O(arg_1261) } else { tmp2 = linked_1259.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1258, arg_1261) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyn_proxy_roots_A_New() *A_arbace_j2g_dyn_proxy_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Ctor() {}
//line :226:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New(); var tmp2 *jrt.Class; var fncls__1465 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class; if



	fncls__1465 == nil { var fncls__1465d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class = fncls__1465d; tmp2 = fncls__1465d } else { tmp2 = fncls__1465 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_163.GetRawRoot__O()) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New() *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Ctor() {}
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Invoke_O_O__O(self, s__711000206__1 any) any { var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(self, s__711000206__1); var tmp2 *jrt.Class; var fncls__1464 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class; if fncls__1464 == nil { var fncls__1464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class = fncls__1464d; tmp2 = fncls__1464d } else { tmp2 = fncls__1464 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A{}; t.Ctor_O_O(p0, p1); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Ctor_O_O(c__iter__711000205, c__s__711000206 any) { t.F_iter__711000205 = c__iter__711000205; t.F_s__711000206 = c__s__711000206 }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Invoke_O__O(self any) any { { var s__711000206__1 any; var t_ any = t.F_s__711000206; t.F_s__711000206 = nil; s__711000206__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1262 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = s__711000206__1; if linked_1263 == nil { temp__1927000414__auto____2 = ifn_1264.Invoke_O__O(arg_1265) } else { temp__1927000414__auto____2 = linked_1263.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1262, arg_1265) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1266 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = xs__1927001018__auto____3; if linked_1267 == nil { n__4 = ifn_1268.Invoke_O__O(arg_1269) } else { n__4 = linked_1267.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1266, arg_1269) }; var tmp1 any; var and__1927000168__auto____5 any; var root_1270 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1272 lang.IFn
														if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = n__4; if linked_1271 == nil { and__1927000168__auto____5 = ifn_1272.Invoke_O__O(arg_1273) } else { and__1927000168__auto____5 = linked_1271.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1270, arg_1273) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1278 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any; var root_1274 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1276 lang.IFn; if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any = n__4; if linked_1275 == nil { arg_1281 = ifn_1276.Invoke_O__O(arg_1277) } else { arg_1281 = linked_1275.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1274, arg_1277) }; if linked_1279 == nil { tmp1 = ifn_1280.Invoke_O__O(arg_1281) } else { tmp1 = linked_1279.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1278, arg_1281) } } else { tmp1 = and__1927000168__auto____5 }
//line :230:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(n__4); var tmp3 *jrt.Class; var fncls__1438 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class; if fncls__1438 == nil { var fncls__1438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class = fncls__1438d; tmp3 = fncls__1438d } else { tmp3 = fncls__1438 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1443 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var root_1439 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1441 lang.IFn

		if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = n__4; if linked_1440 == nil { tmp5 = ifn_1441.Invoke_O__O(arg_1442) } else { tmp5 = linked_1440.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1439, arg_1442) }
//line :230:1
		arg_1446 = tmp4.Invoke_O__O(tmp5); if linked_1444 == nil { fs__1927001036__auto____6 = ifn_1445.Invoke_O__O(arg_1446) } else { fs__1927001036__auto____6 = linked_1444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1443, arg_1446) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1451 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = fs__1927001036__auto____6; var arg_1455 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000205); var tmp7 any; var root_1447 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = s__711000206__1; if linked_1448 == nil { tmp7 = ifn_1449.Invoke_O__O(arg_1450) } else { tmp7 = linked_1448.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1447, arg_1450) }; arg_1455 = tmp6.Invoke_O__O(tmp7); if linked_1452 == nil { return ifn_1453.Invoke_O_O__O(arg_1454, arg_1455) } else { return linked_1452.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1451, arg_1454, arg_1455) } } else { var tmp8 any; var root_1456 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = s__711000206__1; if linked_1457 == nil { tmp8 = ifn_1458.Invoke_O__O(arg_1459) } else { tmp8 = linked_1457.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1456, arg_1459) }; s__711000206__1 = tmp8; continue L1 } } else { var tmp9 any; var root_1460 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = s__711000206__1; if linked_1461 == nil { tmp9 = ifn_1462.Invoke_O__O(arg_1463) } else { tmp9 = linked_1461.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1460, arg_1463) }; s__711000206__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Invoke_O_O__O(self, s__711000208__1 any) any { var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(self, t.F_n, s__711000208__1); var tmp2 *jrt.Class; var fncls__1437 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class; if fncls__1437 == nil { var fncls__1437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class = fncls__1437d; tmp2 = fncls__1437d } else { tmp2 = fncls__1437 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Ctor_O_O_O(c__iter__711000207, c__n, c__s__711000208 any) { t.F_iter__711000207 = c__iter__711000207; t.F_n = c__n; t.F_s__711000208 = c__s__711000208 }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Invoke_O__O(self any) any { { var s__711000208__1 any; var t_ any = t.F_s__711000208; t.F_s__711000208 = nil; s__711000208__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1282 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any = s__711000208__1; if linked_1283 == nil { temp__1927000414__auto____2 = ifn_1284.Invoke_O__O(arg_1285) } else { temp__1927000414__auto____2 = linked_1283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1282, arg_1285) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_1286 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1286, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1288 lang.IFn; if linked_1287 == nil { ifn_1288 = lang.IFn_Cast(root_1286) } else { ifn_1288 = nil }; var arg_1289 any = xs__1927001018__auto____3; if linked_1287 == nil { c__4 = ifn_1288.Invoke_O__O(arg_1289) } else { c__4 = linked_1287.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1286, arg_1289) }; var tmp1 any
																			var and__1927000168__auto____5 any = c__4

	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1290 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1290, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any = c__4; var arg_1294 any = Lit_98; if linked_1291 == nil { and__1927000168__auto____6 = ifn_1292.Invoke_O_O__O(arg_1293, arg_1294) } else { and__1927000168__auto____6 = linked_1291.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1290, arg_1293, arg_1294) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1295 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = c__4; if linked_1296 == nil { tmp1 = ifn_1297.Invoke_O__O(arg_1298) } else { tmp1 = linked_1296.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1295, arg_1298) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }
//line :230:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(t.F_n, c__4); var tmp3 *jrt.Class; var fncls__1411 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class; if fncls__1411 == nil { var fncls__1411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class = fncls__1411d; tmp3 = fncls__1411d } else { tmp3 = fncls__1411 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1416 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp6 any; var root_1412 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1414 lang.IFn



		if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = c__4; if linked_1413 == nil { tmp6 = ifn_1414.Invoke_O__O(arg_1415) } else { tmp6 = linked_1413.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1412, arg_1415) }
//line :230:1
		arg_1419 = tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6)); if linked_1417 == nil { fs__1927001036__auto____6 = ifn_1418.Invoke_O__O(arg_1419) } else { fs__1927001036__auto____6 = linked_1417.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1416, arg_1419) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1424 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = fs__1927001036__auto____6; var arg_1428 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000207); var tmp8 any; var root_1420 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = s__711000208__1; if linked_1421 == nil { tmp8 = ifn_1422.Invoke_O__O(arg_1423) } else { tmp8 = linked_1421.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1420, arg_1423) }; arg_1428 = tmp7.Invoke_O__O(tmp8); if linked_1425 == nil { return ifn_1426.Invoke_O_O__O(arg_1427, arg_1428) } else { return linked_1425.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1424, arg_1427, arg_1428) } } else { var tmp9 any; var root_1429 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = s__711000208__1; if linked_1430 == nil { tmp9 = ifn_1431.Invoke_O__O(arg_1432) } else { tmp9 = linked_1430.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1429, arg_1432) }; s__711000208__1 = tmp9; continue L1 } } else { var tmp10 any; var root_1433 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = s__711000208__1; if linked_1434 == nil { tmp10 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp10 = linked_1434.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1433, arg_1436) }; s__711000208__1 = tmp10; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A{}; t.Ctor_O_O(p0, p1); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Ctor_O_O(c__n, c__c any) { t.F_n = c__n; t.F_c = c__c }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Invoke_O_O__O(self, s__711000210__1 any) any { var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(s__711000210__1, t.F_n, self, t.F_c); var tmp2 *jrt.Class; var fncls__1410 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class; if fncls__1410 == nil { var fncls__1410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class = fncls__1410d; tmp2 = fncls__1410d } else { tmp2 = fncls__1410 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Ctor_O_O_O_O(c__s__711000210, c__n, c__iter__711000209, c__c any) { t.F_s__711000210 = c__s__711000210; t.F_n = c__n; t.F_iter__711000209 = c__iter__711000209; t.F_c = c__c }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Invoke_O__O(self any) any { { var s__711000210__1 any; var t_ any = t.F_s__711000210; t.F_s__711000210 = nil; s__711000210__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1299 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = s__711000210__1; if linked_1300 == nil { temp__1927000414__auto____2 = ifn_1301.Invoke_O__O(arg_1302) } else { temp__1927000414__auto____2 = linked_1300.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1299, arg_1302) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000210__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1303 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = s__711000210__3; if linked_1304 == nil { tmp1 = ifn_1305.Invoke_O__O(arg_1306) } else { tmp1 = linked_1304.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1303, arg_1306) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1307 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = s__711000210__3; if linked_1308 == nil { c__1927001037__auto____4 = ifn_1309.Invoke_O__O(arg_1310) } else { c__1927001037__auto____4 = linked_1308.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1307, arg_1310) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000212__6 any; var root_1311 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1312 == nil { b__711000212__6 = ifn_1313.Invoke_O__O(arg_1314) } else { b__711000212__6 = linked_1312.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1311, arg_1314) }; var tmp2 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(t.F_n, b__711000212__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__1341 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class; if fncls__1341 == nil { var fncls__1341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class = fncls__1341d; tmp3 = fncls__1341d } else { tmp3 = fncls__1341 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1350 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1352 lang.IFn; if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any; var root_1342 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = b__711000212__6; if linked_1343 == nil { arg_1353 = ifn_1344.Invoke_O__O(arg_1345) } else { arg_1353 = linked_1343.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1342, arg_1345) }; var arg_1354 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp5 any; var root_1346 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = s__711000210__3; if linked_1347 == nil { tmp5 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp5 = linked_1347.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1346, arg_1349) }; arg_1354 = tmp4.Invoke_O__O(tmp5); if linked_1351 == nil { return ifn_1352.Invoke_O_O__O(arg_1353, arg_1354) } else { return linked_1351.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1350, arg_1353, arg_1354) } } else { var root_1359 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any; var root_1355 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = b__711000212__6; if linked_1356 == nil { arg_1362 = ifn_1357.Invoke_O__O(arg_1358) } else { arg_1362 = linked_1356.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1355, arg_1358) }; var arg_1363 any; if linked_1360 == nil { return ifn_1361.Invoke_O_O__O(arg_1362, arg_1363) } else { return linked_1360.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1359, arg_1362, arg_1363) } } } else { var mm__4 any; var root_1364 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = s__711000210__3; if linked_1365 == nil { mm__4 = ifn_1366.Invoke_O__O(arg_1367) } else { mm__4 = linked_1365.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1364, arg_1367) }; var tmp6 any; var root_1372 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1374 lang.IFn




	if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any; var root_1368 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = mm__4; if linked_1369 == nil { arg_1375 = ifn_1370.Invoke_O__O(arg_1371) } else { arg_1375 = linked_1369.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1368, arg_1371) }; if linked_1373 == nil { tmp6 = ifn_1374.Invoke_O__O(arg_1375) } else { tmp6 = linked_1373.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1372, arg_1375) }
//line :230:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4))





		if or__1927000174__auto____5 { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1380 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any; var root_1376 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = mm__4; if linked_1377 == nil { arg_1383 = ifn_1378.Invoke_O__O(arg_1379) } else { arg_1383 = linked_1377.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1376, arg_1379) }; if linked_1381 == nil { tmp7 = ifn_1382.Invoke_O__O(arg_1383) } else { tmp7 = linked_1381.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1380, arg_1383) } }
//line :230:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____5_2 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var root_1384 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = Lit_29; var arg_1388 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_1385 == nil { tmp8 = ifn_1386.Invoke_O_O__O(arg_1387, arg_1388) } else { tmp8 = linked_1385.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1384, arg_1387, arg_1388) } }
//line :230:1
			if jrt.J2g_Truth(tmp8) { var root_1393 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var tmp9 any = t.F_c; var arg_1396 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4)); var arg_1397 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp11 any; var root_1389 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = s__711000210__3; if linked_1390 == nil { tmp11 = ifn_1391.Invoke_O__O(arg_1392) } else { tmp11 = linked_1390.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1389, arg_1392) }; arg_1397 = tmp10.Invoke_O__O(tmp11); if linked_1394 == nil { return ifn_1395.Invoke_O_O__O(arg_1396, arg_1397) } else { return linked_1394.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1393, arg_1396, arg_1397) } } else { var tmp12 any; var root_1398 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = s__711000210__3; if linked_1399 == nil { tmp12 = ifn_1400.Invoke_O__O(arg_1401) } else { tmp12 = linked_1399.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1398, arg_1401) }; s__711000210__1 = tmp12; continue L1 } } else { var tmp13 any; var root_1402 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = s__711000210__3; if linked_1403 == nil { tmp13 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp13 = linked_1403.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1402, arg_1405) }; s__711000210__1 = tmp13; continue L1 } } else { var tmp14 any; var root_1406 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = s__711000210__3; if linked_1407 == nil { tmp14 = ifn_1408.Invoke_O__O(arg_1409) } else { tmp14 = linked_1407.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1406, arg_1409) }; s__711000210__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Ctor_O_O_I_O_O(c__n, c__b__711000212 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__c any) { t.F_n = c__n; t.F_b__711000212 = c__b__711000212; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Invoke_O__O(self any) any { { var i__711000211__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000211__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000211__1)); var tmp2 any; var root_1319 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1321 lang.IFn




	if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any; var root_1315 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = mm__2; if linked_1316 == nil { arg_1322 = ifn_1317.Invoke_O__O(arg_1318) } else { arg_1322 = linked_1316.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1315, arg_1318) }; if linked_1320 == nil { tmp2 = ifn_1321.Invoke_O__O(arg_1322) } else { tmp2 = linked_1320.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1319, arg_1322) }
//line :230:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2))





		if or__1927000174__auto____3 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1327 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any; var root_1323 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = mm__2; if linked_1324 == nil { arg_1330 = ifn_1325.Invoke_O__O(arg_1326) } else { arg_1330 = linked_1324.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1323, arg_1326) }; if linked_1328 == nil { tmp3 = ifn_1329.Invoke_O__O(arg_1330) } else { tmp3 = linked_1328.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1327, arg_1330) } }
//line :230:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____3_2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var root_1331 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = Lit_29; var arg_1335 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_1332 == nil { tmp4 = ifn_1333.Invoke_O_O__O(arg_1334, arg_1335) } else { tmp4 = linked_1332.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1331, arg_1334, arg_1335) } }
//line :230:1
			if jrt.J2g_Truth(tmp4) { var root_1336 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = t.F_b__711000212; var tmp5 any = t.F_c; var arg_1340 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2)); if linked_1337 == nil { ifn_1338.Invoke_O_O__O(arg_1339, arg_1340) } else { linked_1337.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1336, arg_1339, arg_1340) }; i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_j2g_dyn_object_fallback_A_New() *A_arbace_j2g_dyn_object_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_object_fallback_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Invoke_O_O_O_O__O(self, n__0, k__1, pn__2 any) any { var impl__4 any; var root_1466 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1468 lang.IFn; if



	linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = n__0; var arg_1470 any = k__1; if linked_1467 == nil { impl__4 = ifn_1468.Invoke_O_O__O(arg_1469, arg_1470) } else { impl__4 = linked_1467.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1466, arg_1469, arg_1470) }; var base__5 any; var root_1471 any = /*line :240:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1473 lang.IFn; if




	linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var arg_1475 any = k__1; if linked_1472 == nil { base__5 = ifn_1473.Invoke_O_O__O(arg_1474, arg_1475) } else { base__5 = linked_1472.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1471, arg_1474, arg_1475) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_167); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__4))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_168; var tmp4 any; var root_1480 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1482 lang.IFn
		if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1484 any; var root_1476 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__5)).Ref(); if linked_1477 == nil { arg_1484 = ifn_1478.Invoke_O__O(arg_1479) } else { arg_1484 = linked_1477.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1476, arg_1479) }; var arg_1485 any = A_arbace_j2g_dyn_A_const_169; var arg_1486 any = A_arbace_j2g_dyn_A_const_170; var arg_1487 any = pn__2; if linked_1481 == nil { tmp4 = ifn_1482.Invoke_O_O_O_O_O__O(arg_1483, arg_1484, arg_1485, arg_1486, arg_1487) } else { tmp4 = linked_1481.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1480, arg_1483, arg_1484, arg_1485, arg_1486, arg_1487) }
//line :246:1
		return lang.Tuple_Create_O__IPersistentVector(tmp2.Invoke_O_O__O(tmp3, tmp4)) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_171; var tmp7 any; var G__711000228__6_ any; var root_1488 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1490 lang.IFn

			if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = k__1; if linked_1489 == nil { G__711000228__6_ = ifn_1490.Invoke_O__O(arg_1491) } else { G__711000228__6_ = linked_1489.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1488, arg_1491) }; L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__711000228__6_) >> 1 & 3 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_126) { tmp7 = A_arbace_j2g_dyn_A_const_172; break L1 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_127) { tmp7 = A_arbace_j2g_dyn_A_const_173; break L1 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_128) {


				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_174; var tmp10 any = A_arbace_j2g_dyn_A_const_175; var tmp11 any; var root_1493 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = pn__2; if linked_1494 == nil { tmp11 = ifn_1495.Invoke_O__O(arg_1496) } else { tmp11 = linked_1494.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1493, arg_1496) }; tmp7 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11)
//line :248:1
				break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_129, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__711000228__6_)))))}
//line :246:1
			return lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O_O__O(tmp6, tmp7)) } }






func A_arbace_j2g_dyn_class_fallback_A_New() *A_arbace_j2g_dyn_class_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Ctor() {}
//line :253:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Invoke_O_O_O_O_O__O(self, n__0, p__711000230__1, pn__2, r__3 any) any { var vec__711000231__5 any = p__711000230__1; var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__711000231__5; var impl__9 any; var root_1497 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1499 lang.IFn; if



	linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = n__0; var arg_1501 any = k__8; if linked_1498 == nil { impl__9 = ifn_1499.Invoke_O_O__O(arg_1500, arg_1501) } else { impl__9 = linked_1498.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1497, arg_1500, arg_1501) }; var base__10 any; var root_1502 any = /*line :253:1*/A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1504 lang.IFn; if




	linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = name__6; var arg_1506 any = desc__7; if linked_1503 == nil { base__10 = ifn_1504.Invoke_O_O__O(arg_1505, arg_1506) } else { base__10 = linked_1503.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1502, arg_1505, arg_1506) }; var ret__11 any; var tmp1 any = /*line :253:1*/A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(r__3); var tmp2 *jrt.Class; var fncls__1507 *jrt.Class = A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class; if





	fncls__1507 == nil { var fncls__1507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class = fncls__1507d; tmp2 = fncls__1507d } else { tmp2 = fncls__1507 }; ret__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var G__711000236__12_ any = /*line :253:1*/A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__9); switch






	lang.Util_Hash_O__I_NoInit(G__711000236__12_) >> 4 & 3 { case 0: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_69) {

		var tmp3 lang.IFn = lang.IFn_Cast(ret__11); var tmp4 any; var root_1519 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1519, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1521 lang.IFn; if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1523 any; var root_1513 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = A_arbace_j2g_dyn_A_const_73; var arg_1517 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__9); var arg_1518 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1514 == nil { arg_1523 = ifn_1515.Invoke_O_O_O__O(arg_1516, arg_1517, arg_1518) } else { arg_1523 = linked_1514.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1513, arg_1516, arg_1517, arg_1518) }; var arg_1524 any = A_arbace_j2g_dyn_A_const_180; var arg_1525 any = pn__2; if linked_1520 == nil { tmp4 = ifn_1521.Invoke_O_O_O_O__O(arg_1522, arg_1523, arg_1524, arg_1525) } else { tmp4 = linked_1520.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1519, arg_1522, arg_1523, arg_1524, arg_1525) }; return tmp3.Invoke_O__O(tmp4) }
//line :260:1
	case 1: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_177) {
		var tmp5 lang.IFn = lang.IFn_Cast(ret__11); var tmp6 any; var root_1530 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1534 any; var root_1526 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1527 == nil { arg_1534 = ifn_1528.Invoke_O__O(arg_1529) } else { arg_1534 = linked_1527.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1526, arg_1529) }; var arg_1535 any = A_arbace_j2g_dyn_A_const_181; var arg_1536 any = A_arbace_j2g_dyn_A_const_182; var arg_1537 any = pn__2; if linked_1531 == nil { tmp6 = ifn_1532.Invoke_O_O_O_O_O__O(arg_1533, arg_1534, arg_1535, arg_1536, arg_1537) } else { tmp6 = linked_1531.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1530, arg_1533, arg_1534, arg_1535, arg_1536, arg_1537) }; return tmp5.Invoke_O__O(tmp6) }
//line :260:1
	case 2: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_178) {
		var tmp7 lang.IFn = lang.IFn_Cast(ret__11); var tmp8 any; var root_1542 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1546 any; var root_1538 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1539 == nil { arg_1546 = ifn_1540.Invoke_O__O(arg_1541) } else { arg_1546 = linked_1539.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1538, arg_1541) }; var arg_1547 any = A_arbace_j2g_dyn_A_const_181; var arg_1548 any = A_arbace_j2g_dyn_A_const_182; var arg_1549 any = pn__2; if linked_1543 == nil { tmp8 = ifn_1544.Invoke_O_O_O_O_O__O(arg_1545, arg_1546, arg_1547, arg_1548, arg_1549) } else { tmp8 = linked_1543.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1542, arg_1545, arg_1546, arg_1547, arg_1548, arg_1549) }; return tmp7.Invoke_O__O(tmp8) }
//line :260:1
	case 3: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_179) {


		var tmp9 lang.IFn = lang.IFn_Cast(ret__11); var tmp10 any; var root_1562 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1562, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1566 any; var root_1550 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1551 == nil { arg_1566 = ifn_1552.Invoke_O__O(arg_1553) } else { arg_1566 = linked_1551.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1550, arg_1553) }; var arg_1567 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any; var root_1558 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp14 any; var root_1554 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = n__0; if linked_1555 == nil { tmp14 = ifn_1556.Invoke_O__O(arg_1557) } else { tmp14 = linked_1555.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1554, arg_1557) }; arg_1561 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1559 == nil { tmp12 = ifn_1560.Invoke_O__O(arg_1561) } else { tmp12 = linked_1559.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1558, arg_1561) }; arg_1567 = tmp11.Invoke_O_O__O(tmp12, A_arbace_j2g_dyn_A_const_183); var arg_1568 any = pn__2; if linked_1563 == nil { tmp10 = ifn_1564.Invoke_O_O_O_O__O(arg_1565, arg_1566, arg_1567, arg_1568) } else { tmp10 = linked_1563.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1562, arg_1565, arg_1566, arg_1567, arg_1568) }; return tmp9.Invoke_O__O(tmp10) }
//line :260:1
	default:}; var vec__711000237__13 any; var root_1509 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1511 lang.IFn; if



	linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = desc__7; if linked_1510 == nil { vec__711000237__13 = ifn_1511.Invoke_O__O(arg_1512) } else { vec__711000237__13 = linked_1510.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1509, arg_1512) }; var ps__14 any = /*line :260:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(0), nil); var rr__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_dyn_A_const_184; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_185; var tmp19 any = A_arbace_j2g_dyn_A_const_186; var tmp20 *jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns21:)' of abstract class ns1:.", []*jrt.Class{jrt.String_class}); var tmp21 any; var root_1569 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1571 lang.IFn; if




	linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = rr__15; if linked_1570 == nil { tmp21 = ifn_1571.Invoke_O__O(arg_1572) } else { tmp21 = linked_1570.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1569, arg_1572) }; var tmp22 any = tmp21; var tmp23 any; var root_1578 any = /*line :260:1*/A_arbace_j2g_dyn_A_const_115.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1580 lang.IFn; if





	linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = Lit_3; var arg_1582 any; var root_1573 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1575 lang.IFn; if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var arg_1577 any = ps__14; if linked_1574 == nil { arg_1582 = ifn_1575.Invoke_O_O__O(arg_1576, arg_1577) } else { arg_1582 = linked_1574.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1573, arg_1576, arg_1577) }; if linked_1579 == nil { tmp23 = ifn_1580.Invoke_O_O__O(arg_1581, arg_1582) } else { tmp23 = linked_1579.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1578, arg_1581, arg_1582) }; var tmp24 any = tmp23; var tmp25 any; var root_1583 any = /*line :260:1*/A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1585 lang.IFn; if






	linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = n__0; var arg_1587 any = Lit_5; var arg_1588 any = Lit_6; if linked_1584 == nil { tmp25 = ifn_1585.Invoke_O_O_O__O(arg_1586, arg_1587, arg_1588) } else { tmp25 = linked_1584.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1583, arg_1586, arg_1587, arg_1588) }; return /*line :260:1*/ lang.Tuple_Create_O__IPersistentVector(tmp15.Invoke_O_O__O(tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp22, nil, name__6, nil, tmp24, nil, tmp25, nil)).Ref()))) }
//line :259:1
func A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(p0 any) *A_arbace_j2g_dyn_class_fallback_ret__711000234_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_ret__711000234_A{}; t.Ctor_O(p0); return t }
//line :259:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :259:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Invoke_O_O__O(self, call__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(Lit_15, t.F_r) { return lang.Tuple_Create_O__IPersistentVector(call__1) } else { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_176, call__1)) } }









func A_arbace_j2g_dyn_ctor_infos_A_New() *A_arbace_j2g_dyn_ctor_infos_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_1589 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_1591 lang.IFn; if


	linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = n__0; if linked_1590 == nil { g__2 = ifn_1591.Invoke_O__O(arg_1592) } else { g__2 = linked_1590.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_1589, arg_1592) }; var arg_conv__3 any; var tmp1 any = /*line :269:1*/A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New(); var tmp2 *jrt.Class; var fncls__1607 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class; if



	fncls__1607 == nil { var fncls__1607d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class = fncls__1607d; tmp2 = fncls__1607d } else { tmp2 = fncls__1607 }; arg_conv__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var root_1616 any =


	A_arbace_j2g_dyn_A_const_192.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_193.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_194, A_arbace_j2g_dyn_A_const_195); if linked_1617 == nil { ifn_1618.Invoke_O__O(arg_1619) } else { linked_1617.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1616, arg_1619) }; var tmp3 any; tmp21 := /*line :269:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_196; var tmp6 any; var root_1620 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_1621 == nil { tmp6 = ifn_1622.Invoke_O__O(arg_1623) } else { tmp6 = linked_1621.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1620, arg_1623) }; var tmp7 any = tmp6; var tmp8 any; var root_1629 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any; var tmp9 any; var root_1624 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = A_arbace_j2g_dyn_A_const_197; var arg_1628 any = A_arbace_j2g_dyn_A_const_198; if linked_1625 == nil { tmp9 = ifn_1626.Invoke_O_O__O(arg_1627, arg_1628) } else { tmp9 = linked_1625.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1624, arg_1627, arg_1628) }; arg_1632 = lang.Tuple_Create_O__IPersistentVector(tmp9); var arg_1633 any = A_arbace_j2g_dyn_A_const_199; if linked_1630 == nil { tmp8 = ifn_1631.Invoke_O_O__O(arg_1632, arg_1633) } else { tmp8 = linked_1630.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1629, arg_1632, arg_1633) }; var tmp10 any = tmp8; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyn_A_const_200; var tmp13 any; var root_1997 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1999 lang.IFn

			if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2001 any = A_arbace_j2g_dyn_A_const_201; var arg_2002 any = A_arbace_j2g_dyn_A_const_202; var arg_2003 any; var iter__1927001039__auto____6 any; var tmp14 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(g__2, n__0, arg_conv__3); var tmp15 *jrt.Class; var fncls__1984 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class
			if fncls__1984 == nil { var fncls__1984d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class = fncls__1984d; tmp15 = fncls__1984d } else { tmp15 = fncls__1984 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp17 any; var tmp18 any; var root_1985 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1987 lang.IFn; if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = n__0; if linked_1986 == nil { tmp18 = ifn_1987.Invoke_O__O(arg_1988) } else { tmp18 = linked_1986.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1985, arg_1988) }; if jrt.J2g_Truth(tmp18) { var root_1989 any = A_arbace_j2g_dyn_A_const_66.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = n__0; if linked_1990 == nil { tmp17 = ifn_1991.Invoke_O__O(arg_1992) } else { tmp17 = linked_1990.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_1989, arg_1992) } } else { var tmp19 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp20 any; var root_1993 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = n__0; if linked_1994 == nil { tmp20 = ifn_1995.Invoke_O__O(arg_1996) } else { tmp20 = linked_1994.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1993, arg_1996) }; tmp17 = tmp19.Invoke_O__O(tmp20) }; arg_2003 = tmp16.Invoke_O__O(tmp17)
//line :279:1
			if linked_1998 == nil { tmp13 = ifn_1999.Invoke_O_O_O_O__O(arg_2000, arg_2001, arg_2002, arg_2003) } else { tmp13 = linked_1998.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1997, arg_2000, arg_2001, arg_2002, arg_2003) }
//line :277:1
			tmp3 = tmp4.Invoke_O_O_O_O__O(tmp5, tmp7, tmp10, tmp11.Invoke_O_O__O(tmp12, tmp13)) }
//line :269:1
		return nil }(); var root_1608 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1610 lang.IFn; if






	linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; if linked_1609 == nil { ifn_1610.Invoke__O() } else { linked_1609.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1608) }; if /*line :269:1*/ tmp21 != nil { panic(tmp21) }; return tmp3 }



func A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New() *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Ctor() {}
//line :273:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Invoke_O_O_O__O(self, d__1, x__2 any) any { var tmp1 any; var root_1593 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = d__1; if linked_1594 == nil { tmp1 = ifn_1595.Invoke_O__O(arg_1596) } else { tmp1 = linked_1594.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1593, arg_1596) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_188; var tmp4 any; var root_1597 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = A_arbace_j2g_dyn_A_const_73; var arg_1601 any = d__1; if linked_1598 == nil { tmp4 = ifn_1599.Invoke_O_O__O(arg_1600, arg_1601) } else { tmp4 = linked_1598.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1597, arg_1600, arg_1601) }; return tmp2.Invoke_O_O_O__O(tmp3, tmp4, x__2) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_10) { return x__2 } else { if A_arbace_j2g_dyn_A_const_81 != nil {

	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_189; var tmp8 any = A_arbace_j2g_dyn_A_const_190; var tmp9 any; var root_1602 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = A_arbace_j2g_dyn_A_const_73; var arg_1606 any = d__1; if linked_1603 == nil { tmp9 = ifn_1604.Invoke_O_O__O(arg_1605, arg_1606) } else { tmp9 = linked_1603.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1602, arg_1605, arg_1606) }; return tmp5.Invoke_O_O__O(tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9), x__2) } else {
//line :273:1
		return nil } } } }






func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Ctor_O_O_O(c__g, c__n, c__arg_conv any) { t.F_g = c__g; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Invoke_O_O__O(self, s__711000244__1 any) any { var tmp1 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(self, t.F_g, s__711000244__1, t.F_n, t.F_arg_conv); var tmp2 *jrt.Class; var fncls__1983 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class; if fncls__1983 == nil { var fncls__1983d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class = fncls__1983d; tmp2 = fncls__1983d } else { tmp2 = fncls__1983 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :280:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Ctor_O_O_O_O_O(c__iter__711000243, c__g, c__s__711000244, c__n, c__arg_conv any) { t.F_iter__711000243 = c__iter__711000243; t.F_g = c__g; t.F_s__711000244 = c__s__711000244; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Invoke_O__O(self any) any { { var s__711000244__1 any; var t_ any = t.F_s__711000244; t.F_s__711000244 = nil; s__711000244__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1634 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1636 lang.IFn; if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = s__711000244__1; if linked_1635 == nil { temp__1927000414__auto____2 = ifn_1636.Invoke_O__O(arg_1637) } else { temp__1927000414__auto____2 = linked_1635.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1634, arg_1637) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000244__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1638 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1640 lang.IFn; if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = s__711000244__3; if linked_1639 == nil { tmp1 = ifn_1640.Invoke_O__O(arg_1641) } else { tmp1 = linked_1639.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1638, arg_1641) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1642 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = s__711000244__3; if linked_1643 == nil { c__1927001037__auto____4 = ifn_1644.Invoke_O__O(arg_1645) } else { c__1927001037__auto____4 = linked_1643.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1642, arg_1645) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000246__6 any; var root_1646 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1647 == nil { b__711000246__6 = ifn_1648.Invoke_O__O(arg_1649) } else { b__711000246__6 = linked_1647.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1646, arg_1649) }; var tmp2 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(t.F_g, t.F_n, b__711000246__6, t.F_arg_conv, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1795 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class; if fncls__1795 == nil { var fncls__1795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class = fncls__1795d; tmp3 = fncls__1795d } else { tmp3 = fncls__1795 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1804 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any; var root_1796 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = b__711000246__6; if linked_1797 == nil { arg_1807 = ifn_1798.Invoke_O__O(arg_1799) } else { arg_1807 = linked_1797.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1796, arg_1799) }; var arg_1808 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp5 any; var root_1800 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = s__711000244__3; if linked_1801 == nil { tmp5 = ifn_1802.Invoke_O__O(arg_1803) } else { tmp5 = linked_1801.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1800, arg_1803) }; arg_1808 = tmp4.Invoke_O__O(tmp5); if linked_1805 == nil { return ifn_1806.Invoke_O_O__O(arg_1807, arg_1808) } else { return linked_1805.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1804, arg_1807, arg_1808) } } else { var root_1813 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any; var root_1809 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = b__711000246__6; if linked_1810 == nil { arg_1816 = ifn_1811.Invoke_O__O(arg_1812) } else { arg_1816 = linked_1810.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1809, arg_1812) }; var arg_1817 any; if linked_1814 == nil { return ifn_1815.Invoke_O_O__O(arg_1816, arg_1817) } else { return linked_1814.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1813, arg_1816, arg_1817) } } } else { var mm__4 any; var root_1818 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = s__711000244__3; if linked_1819 == nil { mm__4 = ifn_1820.Invoke_O__O(arg_1821) } else { mm__4 = linked_1819.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1818, arg_1821) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1826 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any; var root_1822 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = mm__4; if linked_1823 == nil { arg_1829 = ifn_1824.Invoke_O__O(arg_1825) } else { arg_1829 = linked_1823.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1822, arg_1825) }; if linked_1827 == nil { and__1927000168__auto____6 = ifn_1828.Invoke_O__O(arg_1829) } else { and__1927000168__auto____6 = linked_1827.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1826, arg_1829) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1830 any = A_arbace_j2g_dyn_A_const_203.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1831 == nil { tmp6 = ifn_1832.Invoke_O__O(arg_1833) } else { tmp6 = linked_1831.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1830, arg_1833) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :280:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_1838 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1840 lang.IFn

		if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any; var root_1834 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1836 lang.IFn; if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = t.F_n; if linked_1835 == nil { arg_1841 = ifn_1836.Invoke_O__O(arg_1837) } else { arg_1841 = linked_1835.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1834, arg_1837) }; if linked_1839 == nil { or__1927000174__auto____5 = ifn_1840.Invoke_O__O(arg_1841) } else { or__1927000174__auto____5 = linked_1839.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1838, arg_1841) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_1855 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1855, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1857 lang.IFn; if linked_1856 == nil { ifn_1857 = lang.IFn_Cast(root_1855) } else { ifn_1857 = nil }; var arg_1858 any; var root_1846 any = A_arbace_j2g_dyn_A_const_204.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1848 lang.IFn; if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_1849 any = tmp8.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_1850 any; var root_1842 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = t.F_n; if linked_1843 == nil { arg_1850 = ifn_1844.Invoke_O__O(arg_1845) } else { arg_1850 = linked_1843.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1842, arg_1845) }; if linked_1847 == nil { arg_1858 = ifn_1848.Invoke_O_O__O(arg_1849, arg_1850) } else { arg_1858 = linked_1847.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1846, arg_1849, arg_1850) }; var arg_1859 any; var root_1851 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1852 == nil { arg_1859 = ifn_1853.Invoke_O__O(arg_1854) } else { arg_1859 = linked_1852.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1851, arg_1854) }; if linked_1856 == nil { tmp7 = ifn_1857.Invoke_O_O__O(arg_1858, arg_1859) } else { tmp7 = linked_1856.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1855, arg_1858, arg_1859) } }
//line :280:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_1860 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1862 lang.IFn



			if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = t.F_n; if linked_1861 == nil { tmp9 = ifn_1862.Invoke_O__O(arg_1863) } else { tmp9 = linked_1861.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1860, arg_1863) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4) } else { var root_1864 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = t.F_n; var arg_1868 any = mm__4; if linked_1865 == nil { real__5 = ifn_1866.Invoke_O_O__O(arg_1867, arg_1868) } else { real__5 = linked_1865.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1864, arg_1867, arg_1868) } }
//line :280:1
			var vec__711000259__6 any; var root_1869 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1871 lang.IFn




			if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1870 == nil { vec__711000259__6 = ifn_1871.Invoke_O__O(arg_1872) } else { vec__711000259__6 = linked_1870.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1869, arg_1872) }
//line :280:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000262__9 any; var root_1873 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1875 lang.IFn; _ = ___8





			if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = real__5; if linked_1874 == nil { vec__711000262__9 = ifn_1875.Invoke_O__O(arg_1876) } else { vec__711000262__9 = linked_1874.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1873, arg_1876) }
//line :280:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_1966 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_207; var tmp12 any = A_arbace_j2g_dyn_A_const_208; var tmp13 any = A_arbace_j2g_dyn_A_const_209; var tmp14 any; var tmp15 any; var root_1877 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1879 lang.IFn








				if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = ps__7; if linked_1878 == nil { tmp15 = ifn_1879.Invoke_O__O(arg_1880) } else { tmp15 = linked_1878.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1877, arg_1880) }; if jrt.J2g_Truth(tmp15) { var root_1886 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1886, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1888 lang.IFn; if linked_1887 == nil { ifn_1888 = lang.IFn_Cast(root_1886) } else { ifn_1888 = nil }; var arg_1889 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1890 any = A_arbace_j2g_dyn_A_const_210; var arg_1891 any = A_arbace_j2g_dyn_A_const_211; var arg_1892 any; var root_1881 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = A_arbace_j2g_dyn_A_const_212.GetRawRoot__O(); var arg_1885 any = ps__7; if linked_1882 == nil { arg_1892 = ifn_1883.Invoke_O_O__O(arg_1884, arg_1885) } else { arg_1892 = linked_1882.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1881, arg_1884, arg_1885) }; if linked_1887 == nil { tmp14 = ifn_1888.Invoke_O_O_O_O__O(arg_1889, arg_1890, arg_1891, arg_1892) } else { tmp14 = linked_1887.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1886, arg_1889, arg_1890, arg_1891, arg_1892) } } else { tmp14 = nil }
//line :288:1
				var tmp16 any = tmp14; var tmp17 any = A_arbace_j2g_dyn_A_const_213; var tmp18 any = A_arbace_j2g_dyn_A_const_214; var tmp19 any = A_arbace_j2g_dyn_A_const_215; var tmp20 any; var root_1956 any = A_arbace_j2g_dyn_A_const_216.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1956, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1958 lang.IFn


				if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = A_arbace_j2g_dyn_A_const_217; var arg_1960 any; var root_1898 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1898, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1900 lang.IFn; if linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any; var tmp21 any; var root_1893 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = A_arbace_j2g_dyn_A_const_218; var arg_1897 any = A_arbace_j2g_dyn_A_const_219; if linked_1894 == nil { tmp21 = ifn_1895.Invoke_O_O__O(arg_1896, arg_1897) } else { tmp21 = linked_1894.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1893, arg_1896, arg_1897) }; arg_1901 = lang.Tuple_Create_O__IPersistentVector(tmp21); var arg_1902 any = A_arbace_j2g_dyn_A_const_236; if linked_1899 == nil { arg_1960 = ifn_1900.Invoke_O_O__O(arg_1901, arg_1902) } else { arg_1960 = linked_1899.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1898, arg_1901, arg_1902) }; var arg_1961 any; var root_1951 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1953 lang.IFn
				if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any; var tmp22 any; var or__1927000174__auto____12 any; var root_1903 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1905 lang.IFn
				if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = t.F_n; if linked_1904 == nil { or__1927000174__auto____12 = ifn_1905.Invoke_O__O(arg_1906) } else { or__1927000174__auto____12 = linked_1904.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1903, arg_1906) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp22 = or__1927000174__auto____12 } else { var root_1907 any = A_arbace_j2g_dyn_A_const_221.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = t.F_n; if linked_1908 == nil { tmp22 = ifn_1909.Invoke_O__O(arg_1910) } else { tmp22 = linked_1908.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1907, arg_1910) } }; if jrt.J2g_Truth(tmp22) { arg_1954 = nil } else { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp24 any; var root_1911 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1913 lang.IFn; if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = A_arbace_j2g_dyn_A_const_73; var arg_1915 any = t.F_n; var arg_1916 any = Lit_30; if linked_1912 == nil { tmp24 = ifn_1913.Invoke_O_O_O__O(arg_1914, arg_1915, arg_1916) } else { tmp24 = linked_1912.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1911, arg_1914, arg_1915, arg_1916) }; arg_1954 = lang.Tuple_Create_O__IPersistentVector(tmp23.Invoke_O__O(tmp24)) }
//line :292:1
				var arg_1955 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyn_A_const_222; var tmp27 any = A_arbace_j2g_dyn_A_const_231; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyn_A_const_232; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_dyn_A_const_233; var tmp32 any; var root_1947 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1949 lang.IFn

				if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = t.F_g; if linked_1948 == nil { tmp32 = ifn_1949.Invoke_O__O(arg_1950) } else { tmp32 = linked_1948.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1947, arg_1950) }
//line :292:1
				var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28.Invoke_O_O__O(tmp29, tmp30.Invoke_O_O_O_O__O(tmp31, tmp32, A_arbace_j2g_dyn_A_const_234, A_arbace_j2g_dyn_A_const_235))); var tmp34 any = A_arbace_j2g_dyn_A_const_223; var tmp35 any = A_arbace_j2g_dyn_A_const_224; var tmp36 any; var root_1939 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1941 lang.IFn




				if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1943 any; var root_1921 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp38 any; var root_1917 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = real__5; if linked_1918 == nil { tmp38 = ifn_1919.Invoke_O__O(arg_1920) } else { tmp38 = linked_1918.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1917, arg_1920) }; arg_1924 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_1922 == nil { arg_1943 = ifn_1923.Invoke_O__O(arg_1924) } else { arg_1943 = linked_1922.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1921, arg_1924) }; var arg_1944 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp40 any; var root_1929 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1931 lang.IFn
				if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any; var tmp41 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp42 any; var root_1925 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any = t.F_n; if linked_1926 == nil { tmp42 = ifn_1927.Invoke_O__O(arg_1928) } else { tmp42 = linked_1926.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1925, arg_1928) }; arg_1932 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp41, jrt.RefArrayOf(jrt.Object_class, nil, tmp42)).Ref(); if linked_1930 == nil { tmp40 = ifn_1931.Invoke_O__O(arg_1932) } else { tmp40 = linked_1930.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1929, arg_1932) }; arg_1944 = tmp39.Invoke_O_O__O(tmp40, A_arbace_j2g_dyn_A_const_225)
//line :297:1
				var arg_1945 any = A_arbace_j2g_dyn_A_const_226; var arg_1946 any; var root_1934 any = A_arbace_j2g_dyn_A_const_227.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1934, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1936 lang.IFn

				if linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any; var tmp43 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(t.F_arg_conv); var tmp44 *jrt.Class; var fncls__1933 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class; if fncls__1933 == nil { var fncls__1933d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class = fncls__1933d; tmp44 = fncls__1933d } else { tmp44 = fncls__1933 }; arg_1937 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil); var arg_1938 any = ps__7; if linked_1935 == nil { arg_1946 = ifn_1936.Invoke_O_O__O(arg_1937, arg_1938) } else { arg_1946 = linked_1935.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1934, arg_1937, arg_1938) }
//line :297:1
				if linked_1940 == nil { tmp36 = ifn_1941.Invoke_O_O_O_O_O__O(arg_1942, arg_1943, arg_1944, arg_1945, arg_1946) } else { tmp36 = linked_1940.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1939, arg_1942, arg_1943, arg_1944, arg_1945, arg_1946) }
//line :292:1
				arg_1955 = lang.Tuple_Create_O__IPersistentVector(tmp25.Invoke_O_O_O_O_O_O__O(tmp26, tmp33, tmp34, tmp35, tmp36, A_arbace_j2g_dyn_A_const_230)); if linked_1952 == nil { arg_1961 = ifn_1953.Invoke_O_O__O(arg_1954, arg_1955) } else { arg_1961 = linked_1952.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1951, arg_1954, arg_1955) }
//line :291:1
				if linked_1957 == nil { tmp20 = ifn_1958.Invoke_O_O_O__O(arg_1959, arg_1960, arg_1961) } else { tmp20 = linked_1957.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1956, arg_1959, arg_1960, arg_1961) }
//line :288:1
				arg_1969 = tmp10.Invoke_O_O_O_O_O_O_O_O__O(tmp11, tmp12, tmp13, tmp16, tmp17, tmp18, tmp19, tmp20)
//line :280:1
				var arg_1970 any; var tmp45 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp46 any; var root_1962 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = s__711000244__3; if linked_1963 == nil { tmp46 = ifn_1964.Invoke_O__O(arg_1965) } else { tmp46 = linked_1963.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1962, arg_1965) }; arg_1970 = tmp45.Invoke_O__O(tmp46); if linked_1967 == nil { return ifn_1968.Invoke_O_O__O(arg_1969, arg_1970) } else { return linked_1967.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1966, arg_1969, arg_1970) } } else { var tmp47 any; var root_1971 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any = s__711000244__3; if linked_1972 == nil { tmp47 = ifn_1973.Invoke_O__O(arg_1974) } else { tmp47 = linked_1972.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1971, arg_1974) }; s__711000244__1 = tmp47; continue L1 } } else { var tmp48 any; var root_1975 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1975, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1977 lang.IFn; if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any = s__711000244__3; if linked_1976 == nil { tmp48 = ifn_1977.Invoke_O__O(arg_1978) } else { tmp48 = linked_1976.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1975, arg_1978) }; s__711000244__1 = tmp48; continue L1 } } else { var tmp49 any; var root_1979 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1979, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1981 lang.IFn; if linked_1980 == nil { ifn_1981 = lang.IFn_Cast(root_1979) } else { ifn_1981 = nil }; var arg_1982 any = s__711000244__3; if linked_1980 == nil { tmp49 = ifn_1981.Invoke_O__O(arg_1982) } else { tmp49 = linked_1980.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1979, arg_1982) }; s__711000244__1 = tmp49; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :280:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Ctor_O_O_O_O_I_O(c__g, c__n, c__b__711000246, c__arg_conv any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_g = c__g; t.F_n = c__n; t.F_b__711000246 = c__b__711000246; t.F_arg_conv = c__arg_conv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Invoke_O__O(self any) any { { var i__711000245__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000245__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000245__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1654 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any; var root_1650 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = mm__2; if linked_1651 == nil { arg_1657 = ifn_1652.Invoke_O__O(arg_1653) } else { arg_1657 = linked_1651.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1650, arg_1653) }; if linked_1655 == nil { and__1927000168__auto____4 = ifn_1656.Invoke_O__O(arg_1657) } else { and__1927000168__auto____4 = linked_1655.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1654, arg_1657) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1658 any = A_arbace_j2g_dyn_A_const_203.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1659 == nil { tmp2 = ifn_1660.Invoke_O__O(arg_1661) } else { tmp2 = linked_1659.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1658, arg_1661) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :280:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_1666 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1666, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1668 lang.IFn

		if linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any; var root_1662 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any = t.F_n; if linked_1663 == nil { arg_1669 = ifn_1664.Invoke_O__O(arg_1665) } else { arg_1669 = linked_1663.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1662, arg_1665) }; if linked_1667 == nil { or__1927000174__auto____3 = ifn_1668.Invoke_O__O(arg_1669) } else { or__1927000174__auto____3 = linked_1667.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1666, arg_1669) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_1683 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1683, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1685 lang.IFn; if linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any; var root_1674 any = A_arbace_j2g_dyn_A_const_204.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1676 lang.IFn; if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_1677 any = tmp4.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_1678 any; var root_1670 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1670, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1672 lang.IFn; if linked_1671 == nil { ifn_1672 = lang.IFn_Cast(root_1670) } else { ifn_1672 = nil }; var arg_1673 any = t.F_n; if linked_1671 == nil { arg_1678 = ifn_1672.Invoke_O__O(arg_1673) } else { arg_1678 = linked_1671.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1670, arg_1673) }; if linked_1675 == nil { arg_1686 = ifn_1676.Invoke_O_O__O(arg_1677, arg_1678) } else { arg_1686 = linked_1675.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1674, arg_1677, arg_1678) }; var arg_1687 any; var root_1679 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1681 lang.IFn; if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1680 == nil { arg_1687 = ifn_1681.Invoke_O__O(arg_1682) } else { arg_1687 = linked_1680.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1679, arg_1682) }; if linked_1684 == nil { tmp3 = ifn_1685.Invoke_O_O__O(arg_1686, arg_1687) } else { tmp3 = linked_1684.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1683, arg_1686, arg_1687) } }
//line :280:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_1688 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1690 lang.IFn



			if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = t.F_n; if linked_1689 == nil { tmp5 = ifn_1690.Invoke_O__O(arg_1691) } else { tmp5 = linked_1689.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1688, arg_1691) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2) } else { var root_1692 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = t.F_n; var arg_1696 any = mm__2; if linked_1693 == nil { real__3 = ifn_1694.Invoke_O_O__O(arg_1695, arg_1696) } else { real__3 = linked_1693.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1692, arg_1695, arg_1696) } }
//line :280:1
			var vec__711000250__4 any; var root_1697 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1699 lang.IFn




			if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1698 == nil { vec__711000250__4 = ifn_1699.Invoke_O__O(arg_1700) } else { vec__711000250__4 = linked_1698.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1697, arg_1700) }
//line :280:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000253__7 any; var root_1701 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1703 lang.IFn; _ = ___6





			if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = real__3; if linked_1702 == nil { vec__711000253__7 = ifn_1703.Invoke_O__O(arg_1704) } else { vec__711000253__7 = linked_1702.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1701, arg_1704) }
//line :280:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_1790 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = t.F_b__711000246; var arg_1794 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_207; var tmp8 any = A_arbace_j2g_dyn_A_const_208; var tmp9 any = A_arbace_j2g_dyn_A_const_209; var tmp10 any; var tmp11 any; var root_1705 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1707 lang.IFn








				if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = ps__5; if linked_1706 == nil { tmp11 = ifn_1707.Invoke_O__O(arg_1708) } else { tmp11 = linked_1706.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1705, arg_1708) }; if jrt.J2g_Truth(tmp11) { var root_1714 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1714, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1718 any = A_arbace_j2g_dyn_A_const_210; var arg_1719 any = A_arbace_j2g_dyn_A_const_211; var arg_1720 any; var root_1709 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = A_arbace_j2g_dyn_A_const_212.GetRawRoot__O(); var arg_1713 any = ps__5; if linked_1710 == nil { arg_1720 = ifn_1711.Invoke_O_O__O(arg_1712, arg_1713) } else { arg_1720 = linked_1710.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1709, arg_1712, arg_1713) }; if linked_1715 == nil { tmp10 = ifn_1716.Invoke_O_O_O_O__O(arg_1717, arg_1718, arg_1719, arg_1720) } else { tmp10 = linked_1715.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1714, arg_1717, arg_1718, arg_1719, arg_1720) } } else { tmp10 = nil }
//line :288:1
				var tmp12 any = tmp10; var tmp13 any = A_arbace_j2g_dyn_A_const_213; var tmp14 any = A_arbace_j2g_dyn_A_const_214; var tmp15 any = A_arbace_j2g_dyn_A_const_215; var tmp16 any; var root_1784 any = A_arbace_j2g_dyn_A_const_216.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1786 lang.IFn


				if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = A_arbace_j2g_dyn_A_const_217; var arg_1788 any; var root_1726 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any; var tmp17 any; var root_1721 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = A_arbace_j2g_dyn_A_const_218; var arg_1725 any = A_arbace_j2g_dyn_A_const_219; if linked_1722 == nil { tmp17 = ifn_1723.Invoke_O_O__O(arg_1724, arg_1725) } else { tmp17 = linked_1722.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1721, arg_1724, arg_1725) }; arg_1729 = lang.Tuple_Create_O__IPersistentVector(tmp17); var arg_1730 any = A_arbace_j2g_dyn_A_const_220; if linked_1727 == nil { arg_1788 = ifn_1728.Invoke_O_O__O(arg_1729, arg_1730) } else { arg_1788 = linked_1727.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1726, arg_1729, arg_1730) }; var arg_1789 any; var root_1779 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1781 lang.IFn
				if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any; var tmp18 any; var or__1927000174__auto____10 any; var root_1731 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1733 lang.IFn
				if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = t.F_n; if linked_1732 == nil { or__1927000174__auto____10 = ifn_1733.Invoke_O__O(arg_1734) } else { or__1927000174__auto____10 = linked_1732.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1731, arg_1734) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp18 = or__1927000174__auto____10 } else { var root_1735 any = A_arbace_j2g_dyn_A_const_221.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = t.F_n; if linked_1736 == nil { tmp18 = ifn_1737.Invoke_O__O(arg_1738) } else { tmp18 = linked_1736.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1735, arg_1738) } }; if jrt.J2g_Truth(tmp18) { arg_1782 = nil } else { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp20 any; var root_1739 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = A_arbace_j2g_dyn_A_const_73; var arg_1743 any = t.F_n; var arg_1744 any = Lit_30; if linked_1740 == nil { tmp20 = ifn_1741.Invoke_O_O_O__O(arg_1742, arg_1743, arg_1744) } else { tmp20 = linked_1740.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1739, arg_1742, arg_1743, arg_1744) }; arg_1782 = lang.Tuple_Create_O__IPersistentVector(tmp19.Invoke_O__O(tmp20)) }
//line :292:1
				var arg_1783 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyn_A_const_222; var tmp23 any = A_arbace_j2g_dyn_A_const_231; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyn_A_const_232; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_233; var tmp28 any; var root_1775 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1777 lang.IFn

				if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = t.F_g; if linked_1776 == nil { tmp28 = ifn_1777.Invoke_O__O(arg_1778) } else { tmp28 = linked_1776.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1775, arg_1778) }
//line :292:1
				var tmp29 any = lang.Tuple_Create_O_O__IPersistentVector(tmp23, tmp24.Invoke_O_O__O(tmp25, tmp26.Invoke_O_O_O_O__O(tmp27, tmp28, A_arbace_j2g_dyn_A_const_234, A_arbace_j2g_dyn_A_const_235))); var tmp30 any = A_arbace_j2g_dyn_A_const_223; var tmp31 any = A_arbace_j2g_dyn_A_const_224; var tmp32 any; var root_1767 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1768 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1767, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1769 lang.IFn




				if linked_1768 == nil { ifn_1769 = lang.IFn_Cast(root_1767) } else { ifn_1769 = nil }; var arg_1770 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1771 any; var root_1749 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp34 any; var root_1745 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1745, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1747 lang.IFn; if linked_1746 == nil { ifn_1747 = lang.IFn_Cast(root_1745) } else { ifn_1747 = nil }; var arg_1748 any = real__3; if linked_1746 == nil { tmp34 = ifn_1747.Invoke_O__O(arg_1748) } else { tmp34 = linked_1746.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1745, arg_1748) }; arg_1752 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, nil, tmp34)).Ref(); if linked_1750 == nil { arg_1771 = ifn_1751.Invoke_O__O(arg_1752) } else { arg_1771 = linked_1750.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1749, arg_1752) }; var arg_1772 any; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp36 any; var root_1757 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1759 lang.IFn
				if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp38 any; var root_1753 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = t.F_n; if linked_1754 == nil { tmp38 = ifn_1755.Invoke_O__O(arg_1756) } else { tmp38 = linked_1754.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1753, arg_1756) }; arg_1760 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_1758 == nil { tmp36 = ifn_1759.Invoke_O__O(arg_1760) } else { tmp36 = linked_1758.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1757, arg_1760) }; arg_1772 = tmp35.Invoke_O_O__O(tmp36, A_arbace_j2g_dyn_A_const_225)
//line :297:1
				var arg_1773 any = A_arbace_j2g_dyn_A_const_226; var arg_1774 any; var root_1762 any = A_arbace_j2g_dyn_A_const_227.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1764 lang.IFn

				if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any; var tmp39 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(t.F_arg_conv); var tmp40 *jrt.Class; var fncls__1761 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class; if fncls__1761 == nil { var fncls__1761d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class = fncls__1761d; tmp40 = fncls__1761d } else { tmp40 = fncls__1761 }; arg_1765 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil); var arg_1766 any = ps__5; if linked_1763 == nil { arg_1774 = ifn_1764.Invoke_O_O__O(arg_1765, arg_1766) } else { arg_1774 = linked_1763.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1762, arg_1765, arg_1766) }
//line :297:1
				if linked_1768 == nil { tmp32 = ifn_1769.Invoke_O_O_O_O_O__O(arg_1770, arg_1771, arg_1772, arg_1773, arg_1774) } else { tmp32 = linked_1768.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1767, arg_1770, arg_1771, arg_1772, arg_1773, arg_1774) }
//line :292:1
				arg_1783 = lang.Tuple_Create_O__IPersistentVector(tmp21.Invoke_O_O_O_O_O_O__O(tmp22, tmp29, tmp30, tmp31, tmp32, A_arbace_j2g_dyn_A_const_230)); if linked_1780 == nil { arg_1789 = ifn_1781.Invoke_O_O__O(arg_1782, arg_1783) } else { arg_1789 = linked_1780.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1779, arg_1782, arg_1783) }
//line :291:1
				if linked_1785 == nil { tmp16 = ifn_1786.Invoke_O_O_O__O(arg_1787, arg_1788, arg_1789) } else { tmp16 = linked_1785.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1784, arg_1787, arg_1788, arg_1789) }
//line :288:1
				arg_1794 = tmp6.Invoke_O_O_O_O_O_O_O_O__O(tmp7, tmp8, tmp9, tmp12, tmp13, tmp14, tmp15, tmp16)
//line :280:1
				if linked_1791 == nil { ifn_1792.Invoke_O_O__O(arg_1793, arg_1794) } else { linked_1791.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1790, arg_1793, arg_1794) }; i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


















func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_228, A_arbace_j2g_dyn_A_const_229, i__1)) }
//line :299:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_228, A_arbace_j2g_dyn_A_const_229, i__1)) }


func A_arbace_j2g_dyn_go_method_names_A_New() *A_arbace_j2g_dyn_go_method_names_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Ctor() {}
//line :302:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Invoke_O_O__O(self, n__0 any) any {




	var root_2327 any = A_arbace_j2g_dyn_A_const_237.GetRawRoot__O(); var linked_2328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2327, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2329 lang.IFn; if linked_2328 == nil { ifn_2329 = lang.IFn_Cast(root_2327) } else { ifn_2329 = nil }; var arg_2330 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_2331 any; var root_2322 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2323 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2322, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2324 lang.IFn
	if linked_2323 == nil { ifn_2324 = lang.IFn_Cast(root_2322) } else { ifn_2324 = nil }; var arg_2325 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New(); var tmp2 *jrt.Class; var fncls__2224 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class
	if fncls__2224 == nil { var fncls__2224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class = fncls__2224d; tmp2 = fncls__2224d } else { tmp2 = fncls__2224 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_2225 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = n__0; if linked_2226 == nil { tmp4 = ifn_2227.Invoke_O__O(arg_2228) } else { tmp4 = linked_2226.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_2225, arg_2228) }; arg_2325 = tmp3.Invoke_O__O(tmp4)
//line :308:1
	var arg_2326 any; var iter__1927001039__auto____2_2 any; var tmp5 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(n__0); var tmp6 *jrt.Class
	var fncls__2317 /*line :308:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class








	if fncls__2317 == nil { var fncls__2317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class = fncls__2317d; tmp6 = fncls__2317d } else { tmp6 = fncls__2317 }; iter__1927001039__auto____2_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2_2); var tmp8 any; var root_2318 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = n__0; if linked_2319 == nil { tmp8 = ifn_2320.Invoke_O__O(arg_2321) } else { tmp8 = linked_2319.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_2318, arg_2321) }; arg_2326 = tmp7.Invoke_O__O(tmp8)
//line :308:1
	if linked_2323 == nil { arg_2331 = ifn_2324.Invoke_O_O__O(arg_2325, arg_2326) } else { arg_2331 = linked_2323.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2322, arg_2325, arg_2326) }
//line :307:1
	if linked_2328 == nil { return ifn_2329.Invoke_O_O__O(arg_2330, arg_2331) } else { return linked_2328.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2327, arg_2330, arg_2331)
	} }
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Ctor() {}
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Invoke_O_O__O(self, s__711000271__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(self, s__711000271__1); var tmp2 *jrt.Class; var fncls__2223 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class; if fncls__2223 == nil { var fncls__2223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class = fncls__2223d; tmp2 = fncls__2223d } else { tmp2 = fncls__2223 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A{}; t.Ctor_O_O(p0, p1); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Ctor_O_O(c__iter__711000270, c__s__711000271 any) { t.F_iter__711000270 = c__iter__711000270; t.F_s__711000271 = c__s__711000271 }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Invoke_O__O(self any) any { { var s__711000271__1 any; var t_ any = t.F_s__711000271; t.F_s__711000271 = nil; s__711000271__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2004 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2006 lang.IFn; if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = s__711000271__1; if linked_2005 == nil { temp__1927000414__auto____2 = ifn_2006.Invoke_O__O(arg_2007) } else { temp__1927000414__auto____2 = linked_2005.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2004, arg_2007) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_2008 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2008, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = xs__1927001018__auto____3; if linked_2009 == nil { c__4 = ifn_2010.Invoke_O__O(arg_2011) } else { c__4 = linked_2009.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2008, arg_2011) }; var tmp1 any; var and__1927000168__auto____5 any = c__4
														if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2012 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2012, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any = c__4; var arg_2016 any = Lit_98; if linked_2013 == nil { tmp1 = ifn_2014.Invoke_O_O__O(arg_2015, arg_2016) } else { tmp1 = linked_2013.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2012, arg_2015, arg_2016) } } else { tmp1 = and__1927000168__auto____5 }
//line :309:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New(); var tmp3 *jrt.Class; var fncls__2075 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class; if fncls__2075 == nil { var fncls__2075d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class = fncls__2075d; tmp3 = fncls__2075d } else { tmp3 = fncls__2075 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_2202 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2204 lang.IFn; if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var tmp6 any; var root_2076 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2078 lang.IFn

		if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any = c__4; if linked_2077 == nil { tmp6 = ifn_2078.Invoke_O__O(arg_2079) } else { tmp6 = linked_2077.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2076, arg_2079) }; if jrt.J2g_Truth(tmp6) {
			var root_2084 any = A_arbace_j2g_dyn_A_const_204.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_2086 lang.IFn; if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var tmp7 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_2087 any = tmp7.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_2088 any; var root_2080 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2080, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2082 lang.IFn; if linked_2081 == nil { ifn_2082 = lang.IFn_Cast(root_2080) } else { ifn_2082 = nil }; var arg_2083 any = c__4; if linked_2081 == nil { arg_2088 = ifn_2082.Invoke_O__O(arg_2083) } else { arg_2088 = linked_2081.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2080, arg_2083) }; if linked_2085 == nil { tmp5 = ifn_2086.Invoke_O_O__O(arg_2087, arg_2088) } else { tmp5 = linked_2085.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_2084, arg_2087, arg_2088) } } else {
//line :311:1
				var iter__1927001039__auto____6 any; var tmp8 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New(); var tmp9 *jrt.Class
				var fncls__2197 /*line :311:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class

				if fncls__2197 == nil { var fncls__2197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class = fncls__2197d; tmp9 = fncls__2197d } else { tmp9 = fncls__2197 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp11 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp12 any; var root_2198 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2198, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2200 lang.IFn; if linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var arg_2201 any = c__4; if linked_2199 == nil { tmp12 = ifn_2200.Invoke_O__O(arg_2201) } else { tmp12 = linked_2199.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2198, arg_2201) }; tmp5 = tmp10.Invoke_O__O(tmp11.Invoke_O__O(tmp12)) }
//line :309:1
		arg_2205 = tmp4.Invoke_O__O(tmp5); if linked_2203 == nil { fs__1927001036__auto____6 = ifn_2204.Invoke_O__O(arg_2205) } else { fs__1927001036__auto____6 = linked_2203.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2202, arg_2205) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2210 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2210, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2212 lang.IFn; if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = fs__1927001036__auto____6; var arg_2214 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000270); var tmp14 any; var root_2206 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2206, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2208 lang.IFn; if linked_2207 == nil { ifn_2208 = lang.IFn_Cast(root_2206) } else { ifn_2208 = nil }; var arg_2209 any = s__711000271__1; if linked_2207 == nil { tmp14 = ifn_2208.Invoke_O__O(arg_2209) } else { tmp14 = linked_2207.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2206, arg_2209) }; arg_2214 = tmp13.Invoke_O__O(tmp14); if linked_2211 == nil { return ifn_2212.Invoke_O_O__O(arg_2213, arg_2214) } else { return linked_2211.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2210, arg_2213, arg_2214) } } else { var tmp15 any; var root_2215 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2215, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2217 lang.IFn; if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any = s__711000271__1; if linked_2216 == nil { tmp15 = ifn_2217.Invoke_O__O(arg_2218) } else { tmp15 = linked_2216.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2215, arg_2218) }; s__711000271__1 = tmp15; continue L1 } } else { var tmp16 any; var root_2219 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2221 lang.IFn; if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any = s__711000271__1; if linked_2220 == nil { tmp16 = ifn_2221.Invoke_O__O(arg_2222) } else { tmp16 = linked_2220.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2219, arg_2222) }; s__711000271__1 = tmp16; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Ctor() {}
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Invoke_O_O__O(self, s__711000273__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(s__711000273__1, self); var tmp2 *jrt.Class; var fncls__2074 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class; if fncls__2074 == nil { var fncls__2074d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class = fncls__2074d; tmp2 = fncls__2074d } else { tmp2 = fncls__2074 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A{}; t.Ctor_O_O(p0, p1); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Ctor_O_O(c__s__711000273, c__iter__711000272 any) { t.F_s__711000273 = c__s__711000273; t.F_iter__711000272 = c__iter__711000272 }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Invoke_O__O(self any) any { { var s__711000273__1 any; var t_ any = t.F_s__711000273; t.F_s__711000273 = nil; s__711000273__1 = t_; for { var temp__1927000414__auto____2 any; var root_2017 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2019 lang.IFn; if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = s__711000273__1; if linked_2018 == nil { temp__1927000414__auto____2 = ifn_2019.Invoke_O__O(arg_2020) } else { temp__1927000414__auto____2 = linked_2018.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2017, arg_2020) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000273__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2021 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = s__711000273__3; if linked_2022 == nil { tmp1 = ifn_2023.Invoke_O__O(arg_2024) } else { tmp1 = linked_2022.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2021, arg_2024) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2025 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = s__711000273__3; if linked_2026 == nil { c__1927001037__auto____4 = ifn_2027.Invoke_O__O(arg_2028) } else { c__1927001037__auto____4 = linked_2026.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2025, arg_2028) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000275__6 any; var root_2029 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2029, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2031 lang.IFn; if linked_2030 == nil { ifn_2031 = lang.IFn_Cast(root_2029) } else { ifn_2031 = nil }; var arg_2032 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2030 == nil { b__711000275__6 = ifn_2031.Invoke_O__O(arg_2032) } else { b__711000275__6 = linked_2030.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2029, arg_2032) }; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(b__711000275__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2038 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class; if fncls__2038 == nil { var fncls__2038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class = fncls__2038d; tmp3 = fncls__2038d } else { tmp3 = fncls__2038 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2047 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2047, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2049 lang.IFn; if linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var arg_2050 any; var root_2039 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2039, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2041 lang.IFn; if linked_2040 == nil { ifn_2041 = lang.IFn_Cast(root_2039) } else { ifn_2041 = nil }; var arg_2042 any = b__711000275__6; if linked_2040 == nil { arg_2050 = ifn_2041.Invoke_O__O(arg_2042) } else { arg_2050 = linked_2040.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2039, arg_2042) }; var arg_2051 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp5 any; var root_2043 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = s__711000273__3; if linked_2044 == nil { tmp5 = ifn_2045.Invoke_O__O(arg_2046) } else { tmp5 = linked_2044.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2043, arg_2046) }; arg_2051 = tmp4.Invoke_O__O(tmp5); if linked_2048 == nil { return ifn_2049.Invoke_O_O__O(arg_2050, arg_2051) } else { return linked_2048.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2047, arg_2050, arg_2051) } } else { var root_2056 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2058 lang.IFn; if linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any; var root_2052 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any = b__711000275__6; if linked_2053 == nil { arg_2059 = ifn_2054.Invoke_O__O(arg_2055) } else { arg_2059 = linked_2053.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2052, arg_2055) }; var arg_2060 any; if linked_2057 == nil { return ifn_2058.Invoke_O_O__O(arg_2059, arg_2060) } else { return linked_2057.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2056, arg_2059, arg_2060) } } } else { var nme__4 any; var root_2061 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2063 lang.IFn; if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any = s__711000273__3; if linked_2062 == nil { nme__4 = ifn_2063.Invoke_O__O(arg_2064) } else { nme__4 = linked_2062.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2061, arg_2064) }; var root_2069 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2071 lang.IFn; if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any = nme__4; var arg_2073 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp7 any; var root_2065 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = s__711000273__3; if linked_2066 == nil { tmp7 = ifn_2067.Invoke_O__O(arg_2068) } else { tmp7 = linked_2066.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2065, arg_2068) }; arg_2073 = tmp6.Invoke_O__O(tmp7); if linked_2070 == nil { return ifn_2071.Invoke_O_O__O(arg_2072, arg_2073) } else { return linked_2070.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2069, arg_2072, arg_2073) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Ctor_O_I_O(c__b__711000275 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000275 = c__b__711000275; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Invoke_O__O(self any) any { { var i__711000274__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000274__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nme__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000274__1)); var root_2033 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2033, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2035 lang.IFn; if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any = t.F_b__711000275; var arg_2037 any = nme__2; if linked_2034 == nil { ifn_2035.Invoke_O_O__O(arg_2036, arg_2037) } else { linked_2034.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2033, arg_2036, arg_2037) }; i__711000274__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000274__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Ctor() {}
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Invoke_O_O__O(self, s__711000285__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(s__711000285__1, self); var tmp2 *jrt.Class; var fncls__2196 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class; if fncls__2196 == nil { var fncls__2196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class = fncls__2196d; tmp2 = fncls__2196d } else { tmp2 = fncls__2196 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :313:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A{}; t.Ctor_O_O(p0, p1); return t }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Ctor_O_O(c__s__711000285, c__iter__711000284 any) { t.F_s__711000285 = c__s__711000285; t.F_iter__711000284 = c__iter__711000284 }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Invoke_O__O(self any) any { { var s__711000285__1 any; var t_ any = t.F_s__711000285; t.F_s__711000285 = nil; s__711000285__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2089 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2091 lang.IFn; if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any = s__711000285__1; if linked_2090 == nil { temp__1927000414__auto____2 = ifn_2091.Invoke_O__O(arg_2092) } else { temp__1927000414__auto____2 = linked_2090.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2089, arg_2092) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000285__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2093 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2093, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2095 lang.IFn; if linked_2094 == nil { ifn_2095 = lang.IFn_Cast(root_2093) } else { ifn_2095 = nil }; var arg_2096 any = s__711000285__3; if linked_2094 == nil { tmp1 = ifn_2095.Invoke_O__O(arg_2096) } else { tmp1 = linked_2094.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2093, arg_2096) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2097 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2097, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2099 lang.IFn; if linked_2098 == nil { ifn_2099 = lang.IFn_Cast(root_2097) } else { ifn_2099 = nil }; var arg_2100 any = s__711000285__3; if linked_2098 == nil { c__1927001037__auto____4 = ifn_2099.Invoke_O__O(arg_2100) } else { c__1927001037__auto____4 = linked_2098.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2097, arg_2100) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000287__6 any; var root_2101 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2102 == nil { b__711000287__6 = ifn_2103.Invoke_O__O(arg_2104) } else { b__711000287__6 = linked_2102.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2101, arg_2104) }; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(b__711000287__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2133 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class; if fncls__2133 == nil { var fncls__2133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class = fncls__2133d; tmp3 = fncls__2133d } else { tmp3 = fncls__2133 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2142 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2144 lang.IFn; if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any; var root_2134 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = b__711000287__6; if linked_2135 == nil { arg_2145 = ifn_2136.Invoke_O__O(arg_2137) } else { arg_2145 = linked_2135.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2134, arg_2137) }; var arg_2146 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp5 any; var root_2138 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2138, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2140 lang.IFn; if linked_2139 == nil { ifn_2140 = lang.IFn_Cast(root_2138) } else { ifn_2140 = nil }; var arg_2141 any = s__711000285__3; if linked_2139 == nil { tmp5 = ifn_2140.Invoke_O__O(arg_2141) } else { tmp5 = linked_2139.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2138, arg_2141) }; arg_2146 = tmp4.Invoke_O__O(tmp5); if linked_2143 == nil { return ifn_2144.Invoke_O_O__O(arg_2145, arg_2146) } else { return linked_2143.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2142, arg_2145, arg_2146) } } else { var root_2151 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2151, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2153 lang.IFn; if linked_2152 == nil { ifn_2153 = lang.IFn_Cast(root_2151) } else { ifn_2153 = nil }; var arg_2154 any; var root_2147 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any = b__711000287__6; if linked_2148 == nil { arg_2154 = ifn_2149.Invoke_O__O(arg_2150) } else { arg_2154 = linked_2148.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2147, arg_2150) }; var arg_2155 any; if linked_2152 == nil { return ifn_2153.Invoke_O_O__O(arg_2154, arg_2155) } else { return linked_2152.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2151, arg_2154, arg_2155) } } } else { var mm__4 any; var root_2156 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = s__711000285__3; if linked_2157 == nil { mm__4 = ifn_2158.Invoke_O__O(arg_2159) } else { mm__4 = linked_2157.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2156, arg_2159) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2164 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2164, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2166 lang.IFn
																				if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var arg_2167 any; var root_2160 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_2161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2160, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2162 lang.IFn; if linked_2161 == nil { ifn_2162 = lang.IFn_Cast(root_2160) } else { ifn_2162 = nil }; var arg_2163 any = mm__4; if linked_2161 == nil { arg_2167 = ifn_2162.Invoke_O__O(arg_2163) } else { arg_2167 = linked_2161.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2160, arg_2163) }; if linked_2165 == nil { and__1927000168__auto____5 = ifn_2166.Invoke_O__O(arg_2167) } else { and__1927000168__auto____5 = linked_2165.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2164, arg_2167) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2168 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2168, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2170 lang.IFn; if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any = Lit_29; var arg_2172 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_2169 == nil { and__1927000168__auto____6 = ifn_2170.Invoke_O_O__O(arg_2171, arg_2172) } else { and__1927000168__auto____6 = linked_2169.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2168, arg_2171, arg_2172) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2173 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any = Lit_105; var arg_2177 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_2174 == nil { tmp6 = ifn_2175.Invoke_O_O__O(arg_2176, arg_2177) } else { tmp6 = linked_2174.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2173, arg_2176, arg_2177) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :313:1
	if jrt.J2g_Truth(tmp6) { var root_2187 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2187, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2189 lang.IFn; if linked_2188 == nil { ifn_2189 = lang.IFn_Cast(root_2187) } else { ifn_2189 = nil }; var arg_2190 any; var root_2178 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2178, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2180 lang.IFn

		if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); var arg_2182 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_2179 == nil { arg_2190 = ifn_2180.Invoke_O_O__O(arg_2181, arg_2182) } else { arg_2190 = linked_2179.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2178, arg_2181, arg_2182) }
//line :313:1
		var arg_2191 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp8 any; var root_2183 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2183, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2185 lang.IFn; if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any = s__711000285__3; if linked_2184 == nil { tmp8 = ifn_2185.Invoke_O__O(arg_2186) } else { tmp8 = linked_2184.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2183, arg_2186) }; arg_2191 = tmp7.Invoke_O__O(tmp8); if linked_2188 == nil { return ifn_2189.Invoke_O_O__O(arg_2190, arg_2191) } else { return linked_2188.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2187, arg_2190, arg_2191) } } else { var tmp9 any; var root_2192 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2192, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2194 lang.IFn; if linked_2193 == nil { ifn_2194 = lang.IFn_Cast(root_2192) } else { ifn_2194 = nil }; var arg_2195 any = s__711000285__3; if linked_2193 == nil { tmp9 = ifn_2194.Invoke_O__O(arg_2195) } else { tmp9 = linked_2193.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2192, arg_2195) }; s__711000285__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :313:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Ctor_O_I_O(c__b__711000287 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000287 = c__b__711000287; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Invoke_O__O(self any) any { { var i__711000286__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000286__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000286__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2109 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2111 lang.IFn
																					if linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; var arg_2112 any; var root_2105 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2107 lang.IFn; if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any = mm__2; if linked_2106 == nil { arg_2112 = ifn_2107.Invoke_O__O(arg_2108) } else { arg_2112 = linked_2106.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2105, arg_2108) }; if linked_2110 == nil { and__1927000168__auto____3 = ifn_2111.Invoke_O__O(arg_2112) } else { and__1927000168__auto____3 = linked_2110.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2109, arg_2112) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_2113 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any = Lit_29; var arg_2117 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_2114 == nil { and__1927000168__auto____4 = ifn_2115.Invoke_O_O__O(arg_2116, arg_2117) } else { and__1927000168__auto____4 = linked_2114.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2113, arg_2116, arg_2117) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_2118 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2120 lang.IFn; if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any = Lit_105; var arg_2122 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_2119 == nil { tmp2 = ifn_2120.Invoke_O_O__O(arg_2121, arg_2122) } else { tmp2 = linked_2119.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2118, arg_2121, arg_2122) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :313:1
	if jrt.J2g_Truth(tmp2) { var root_2128 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = t.F_b__711000287; var arg_2132 any; var root_2123 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2125 lang.IFn

		if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); var arg_2127 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_2124 == nil { arg_2132 = ifn_2125.Invoke_O_O__O(arg_2126, arg_2127) } else { arg_2132 = linked_2124.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2123, arg_2126, arg_2127) }
//line :313:1
		if linked_2129 == nil { ifn_2130.Invoke_O_O__O(arg_2131, arg_2132) } else { linked_2129.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2128, arg_2131, arg_2132) }; i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } else { i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(p0 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A{}; t.Ctor_O(p0); return t }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Invoke_O_O__O(self, s__711000297__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(s__711000297__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__2316 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class; if fncls__2316 == nil { var fncls__2316d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class = fncls__2316d; tmp2 = fncls__2316d } else { tmp2 = fncls__2316 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :317:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Ctor_O_O_O(c__s__711000297, c__n, c__iter__711000296 any) { t.F_s__711000297 = c__s__711000297; t.F_n = c__n; t.F_iter__711000296 = c__iter__711000296 }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Invoke_O__O(self any) any { { var s__711000297__1 any; var t_ any = t.F_s__711000297; t.F_s__711000297 = nil; s__711000297__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2229 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = s__711000297__1; if linked_2230 == nil { temp__1927000414__auto____2 = ifn_2231.Invoke_O__O(arg_2232) } else { temp__1927000414__auto____2 = linked_2230.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2229, arg_2232) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000297__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2233 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any = s__711000297__3; if linked_2234 == nil { tmp1 = ifn_2235.Invoke_O__O(arg_2236) } else { tmp1 = linked_2234.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2233, arg_2236) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2237 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any = s__711000297__3; if linked_2238 == nil { c__1927001037__auto____4 = ifn_2239.Invoke_O__O(arg_2240) } else { c__1927001037__auto____4 = linked_2238.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2237, arg_2240) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000299__6 any; var root_2241 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2243 lang.IFn; if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2242 == nil { b__711000299__6 = ifn_2243.Invoke_O__O(arg_2244) } else { b__711000299__6 = linked_2242.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2241, arg_2244) }; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(t.F_n, b__711000299__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2263 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class; if fncls__2263 == nil { var fncls__2263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class = fncls__2263d; tmp3 = fncls__2263d } else { tmp3 = fncls__2263 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2272 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any; var root_2264 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2264, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2266 lang.IFn; if linked_2265 == nil { ifn_2266 = lang.IFn_Cast(root_2264) } else { ifn_2266 = nil }; var arg_2267 any = b__711000299__6; if linked_2265 == nil { arg_2275 = ifn_2266.Invoke_O__O(arg_2267) } else { arg_2275 = linked_2265.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2264, arg_2267) }; var arg_2276 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp5 any; var root_2268 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2268, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2270 lang.IFn; if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any = s__711000297__3; if linked_2269 == nil { tmp5 = ifn_2270.Invoke_O__O(arg_2271) } else { tmp5 = linked_2269.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2268, arg_2271) }; arg_2276 = tmp4.Invoke_O__O(tmp5); if linked_2273 == nil { return ifn_2274.Invoke_O_O__O(arg_2275, arg_2276) } else { return linked_2273.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2272, arg_2275, arg_2276) } } else { var root_2281 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any; var root_2277 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2279 lang.IFn; if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = b__711000299__6; if linked_2278 == nil { arg_2284 = ifn_2279.Invoke_O__O(arg_2280) } else { arg_2284 = linked_2278.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2277, arg_2280) }; var arg_2285 any; if linked_2282 == nil { return ifn_2283.Invoke_O_O__O(arg_2284, arg_2285) } else { return linked_2282.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2281, arg_2284, arg_2285) } } } else { var j__4 any; var root_2286 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2288 lang.IFn; if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any = s__711000297__3; if linked_2287 == nil { j__4 = ifn_2288.Invoke_O__O(arg_2289) } else { j__4 = linked_2287.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2286, arg_2289) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2290 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2290, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = j__4; var arg_2294 any = t.F_n; if linked_2291 == nil { and__1927000168__auto____5 = ifn_2292.Invoke_O_O__O(arg_2293, arg_2294) } else { and__1927000168__auto____5 = linked_2291.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2290, arg_2293, arg_2294) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2295 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_2296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2295, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2297 lang.IFn; if linked_2296 == nil { ifn_2297 = lang.IFn_Cast(root_2295) } else { ifn_2297 = nil }; var arg_2298 any = j__4; if linked_2296 == nil { tmp6 = ifn_2297.Invoke_O__O(arg_2298) } else { tmp6 = linked_2296.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2295, arg_2298) } } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_2307 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2307, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2309 lang.IFn; if linked_2308 == nil { ifn_2309 = lang.IFn_Cast(root_2307) } else { ifn_2309 = nil }; var arg_2310 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp8 any; var root_2299 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2301 lang.IFn
														if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any = j__4; if linked_2300 == nil { tmp8 = ifn_2301.Invoke_O__O(arg_2302) } else { tmp8 = linked_2300.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2299, arg_2302) }; arg_2310 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :317:1
	var arg_2311 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp10 any; var root_2303 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2305 lang.IFn; if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any = s__711000297__3; if linked_2304 == nil { tmp10 = ifn_2305.Invoke_O__O(arg_2306) } else { tmp10 = linked_2304.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2303, arg_2306) }; arg_2311 = tmp9.Invoke_O__O(tmp10); if linked_2308 == nil { return ifn_2309.Invoke_O_O__O(arg_2310, arg_2311) } else { return linked_2308.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2307, arg_2310, arg_2311) } } else { var tmp11 any; var root_2312 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = s__711000297__3; if linked_2313 == nil { tmp11 = ifn_2314.Invoke_O__O(arg_2315) } else { tmp11 = linked_2313.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2312, arg_2315) }; s__711000297__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :317:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Ctor_O_O_I_O(c__n, c__b__711000299 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000299 = c__b__711000299; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Invoke_O__O(self any) any { { var i__711000298__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000298__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000298__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2245 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2247 lang.IFn; if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; var arg_2248 any = j__2; var arg_2249 any = t.F_n; if linked_2246 == nil { and__1927000168__auto____3 = ifn_2247.Invoke_O_O__O(arg_2248, arg_2249) } else { and__1927000168__auto____3 = linked_2246.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2245, arg_2248, arg_2249) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2250 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_2251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2250, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2252 lang.IFn; if linked_2251 == nil { ifn_2252 = lang.IFn_Cast(root_2250) } else { ifn_2252 = nil }; var arg_2253 any = j__2; if linked_2251 == nil { tmp2 = ifn_2252.Invoke_O__O(arg_2253) } else { tmp2 = linked_2251.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2250, arg_2253) } } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_2258 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = t.F_b__711000299; var arg_2262 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp4 any; var root_2254 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2256 lang.IFn
																if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any = j__2; if linked_2255 == nil { tmp4 = ifn_2256.Invoke_O__O(arg_2257) } else { tmp4 = linked_2255.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2254, arg_2257) }; arg_2262 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :317:1
	if linked_2259 == nil { ifn_2260.Invoke_O_O__O(arg_2261, arg_2262) } else { linked_2259.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2258, arg_2261, arg_2262) }; i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } else { i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_sub_forms_A_New() *A_arbace_j2g_dyn_sub_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Ctor() {}
//line :320:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Invoke_O_O_O_O__O(self, n__0, ifaces__1, dyn_keys__2 any) any { var g__4 any; var root_2332 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2332, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_2334 lang.IFn; if






	linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; var arg_2335 any = n__0; if linked_2333 == nil { g__4 = ifn_2334.Invoke_O__O(arg_2335) } else { g__4 = linked_2333.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_2332, arg_2335) }; var recv__5 any; var tmp1 lang.IFn = /*line :320:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_280; var tmp3 any; var root_2847 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2847, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2849 lang.IFn; if







	linked_2848 == nil { ifn_2849 = lang.IFn_Cast(root_2847) } else { ifn_2849 = nil }; var arg_2850 any = g__4; if linked_2848 == nil { tmp3 = ifn_2849.Invoke_O__O(arg_2850) } else { tmp3 = linked_2848.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2847, arg_2850) }; recv__5 = tmp1.Invoke_O_O__O(tmp2, tmp3); var own__6 any; var root_2411 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_237.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2413 lang.IFn; if








	linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2415 any; var iter__1927001039__auto____6 any; var tmp4 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New(); var tmp5 *jrt.Class; var fncls__2406 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class; if fncls__2406 == nil { var fncls__2406d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class = fncls__2406d; tmp5 = fncls__2406d } else { tmp5 = fncls__2406 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp7 any; var root_2407 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_2409 lang.IFn; if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any = n__0; if linked_2408 == nil { tmp7 = ifn_2409.Invoke_O__O(arg_2410) } else { tmp7 = linked_2408.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_2407, arg_2410) }; arg_2415 = tmp6.Invoke_O__O(tmp7); if linked_2412 == nil { own__6 = ifn_2413.Invoke_O_O__O(arg_2414, arg_2415) } else { own__6 = linked_2412.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2411, arg_2414, arg_2415) }; var dyn_set__7 any; var root_2416 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_238.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2418 lang.IFn; if









	linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = dyn_keys__2; if linked_2417 == nil { dyn_set__7 = ifn_2418.Invoke_O__O(arg_2419) } else { dyn_set__7 = linked_2417.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2416, arg_2419) }; var ks__8 any; var root_2438 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_2439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2438, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2440 lang.IFn; if










	linked_2439 == nil { ifn_2440 = lang.IFn_Cast(root_2438) } else { ifn_2440 = nil }; var arg_2441 any; var root_2433 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = dyn_keys__2; var arg_2437 any; var root_2429 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2431 lang.IFn; if linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any; var root_2424 any = A_arbace_j2g_dyn_A_const_239.GetRawRoot__O(); var linked_2425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2424, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2426 lang.IFn; if linked_2425 == nil { ifn_2426 = lang.IFn_Cast(root_2424) } else { ifn_2426 = nil }; var arg_2427 any = dyn_set__7; var arg_2428 any; var root_2420 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_2421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2420, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2422 lang.IFn; if linked_2421 == nil { ifn_2422 = lang.IFn_Cast(root_2420) } else { ifn_2422 = nil }; var arg_2423 any = own__6; if linked_2421 == nil { arg_2428 = ifn_2422.Invoke_O__O(arg_2423) } else { arg_2428 = linked_2421.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2420, arg_2423) }; if linked_2425 == nil { arg_2432 = ifn_2426.Invoke_O_O__O(arg_2427, arg_2428) } else { arg_2432 = linked_2425.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2424, arg_2427, arg_2428) }; if linked_2430 == nil { arg_2437 = ifn_2431.Invoke_O__O(arg_2432) } else { arg_2437 = linked_2430.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2429, arg_2432) }; if linked_2434 == nil { arg_2441 = ifn_2435.Invoke_O_O__O(arg_2436, arg_2437) } else { arg_2441 = linked_2434.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2433, arg_2436, arg_2437) }; if linked_2439 == nil { ks__8 = ifn_2440.Invoke_O__O(arg_2441) } else { ks__8 = linked_2439.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2438, arg_2441) }; var clash__9 any; var root_2442 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_240.GetRawRoot__O(); var linked_2443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2442, A_arbace_j2g_dyn_go_method_names_A_fn_class); var ifn_2444 lang.IFn; if











	linked_2443 == nil { ifn_2444 = lang.IFn_Cast(root_2442) } else { ifn_2444 = nil }; var arg_2445 any = n__0; if linked_2443 == nil { clash__9 = ifn_2444.Invoke_O__O(arg_2445) } else { clash__9 = linked_2443.(*A_arbace_j2g_dyn_go_method_names_A).Invoke_O_O__O(root_2442, arg_2445) }; var slots__10 any; var root_2446 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2448 lang.IFn; if












	linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_93, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2447 == nil { slots__10 = ifn_2448.Invoke_O__O(arg_2449) } else { slots__10 = linked_2447.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2446, arg_2449) }; var tmp8 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_42.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_241; var tmp11 *jrt.RefArray = jrt.ConstRefArray("[0,7,s12:---- DynSub_ns13:: proxies of ns2:, ns8: methods", []*jrt.Class{jrt.String_class}); var tmp12 any; var root_2450 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2450, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2452 lang.IFn; if
	linked_2451 == nil { ifn_2452 = lang.IFn_Cast(root_2450) } else { ifn_2452 = nil }; var arg_2453 any = n__0; if linked_2451 == nil { tmp12 = ifn_2452.Invoke_O__O(arg_2453) } else { tmp12 = linked_2451.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2450, arg_2453) }; var tmp13 any = tmp12; var tmp14 any; var root_2454 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_2455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2454, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2456 lang.IFn; if
	linked_2455 == nil { ifn_2456 = lang.IFn_Cast(root_2454) } else { ifn_2456 = nil }; var arg_2457 any = n__0; var arg_2458 any = Lit_5; var arg_2459 any = Lit_6; if linked_2455 == nil { tmp14 = ifn_2456.Invoke_O_O_O__O(arg_2457, arg_2458, arg_2459) } else { tmp14 = linked_2455.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2454, arg_2457, arg_2458, arg_2459) }; var tmp15 any = /*line :334:1*/tmp9.Invoke_O_O__O(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil, tmp14, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__8)).Ref(), nil)).Ref()); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_242; var tmp18 any; var root_2460 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2460, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2462 lang.IFn; if


	linked_2461 == nil { ifn_2462 = lang.IFn_Cast(root_2460) } else { ifn_2462 = nil }; var arg_2463 any = g__4; if linked_2461 == nil { tmp18 = ifn_2462.Invoke_O__O(arg_2463) } else { tmp18 = linked_2461.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2460, arg_2463) }; var tmp19 any = tmp18; var tmp20 /*line :334:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_147, nil, Lit_148); var tmp21 any; var root_2464 any = A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_2465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2464, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2466 lang.IFn; if



	linked_2465 == nil { ifn_2466 = lang.IFn_Cast(root_2464) } else { ifn_2466 = nil }; var arg_2467 any = n__0; var arg_2468 any = Lit_5; var arg_2469 any = Lit_6; if linked_2465 == nil { tmp21 = ifn_2466.Invoke_O_O_O__O(arg_2467, arg_2468, arg_2469) } else { tmp21 = linked_2465.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2464, arg_2467, arg_2468, arg_2469) }; var tmp22 any = /*line :334:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, g__4, nil, tmp21, nil)).Ref(); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_dyn_A_const_243; var tmp25 any; var root_2470 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_2471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2470, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2472 lang.IFn; if





	linked_2471 == nil { ifn_2472 = lang.IFn_Cast(root_2470) } else { ifn_2472 = nil }; var arg_2473 any = A_arbace_j2g_dyn_A_const_73; var arg_2474 any = n__0; if linked_2471 == nil { tmp25 = ifn_2472.Invoke_O_O__O(arg_2473, arg_2474) } else { tmp25 = linked_2471.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_2470, arg_2473, arg_2474) }; var tmp26 any = /*line :334:1*/tmp16.Invoke_O_O_O_O__O(tmp17, tmp19, tmp22, tmp23.Invoke_O_O_O__O(tmp24, tmp25, A_arbace_j2g_dyn_A_const_244)); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp28 any = A_arbace_j2g_dyn_A_const_245; var tmp29 any; var root_2475 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2475, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2477 lang.IFn; if






	linked_2476 == nil { ifn_2477 = lang.IFn_Cast(root_2475) } else { ifn_2477 = nil }; var arg_2478 any = slots__10; var arg_2479 any = A_arbace_j2g_dyn_A_const_246; if linked_2476 == nil { tmp29 = ifn_2477.Invoke_O_O__O(arg_2478, arg_2479) } else { tmp29 = linked_2476.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2475, arg_2478, arg_2479) }; var tmp30 any = tmp29; var tmp31 any; var root_2486 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2487 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2486, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2488 lang.IFn; if







	linked_2487 == nil { ifn_2488 = lang.IFn_Cast(root_2486) } else { ifn_2488 = nil }; var arg_2489 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2490 any = A_arbace_j2g_dyn_A_const_247; var arg_2491 any = A_arbace_j2g_dyn_A_const_248; var arg_2492 any; var root_2481 any = A_arbace_j2g_dyn_A_const_227.GetRawRoot__O(); var linked_2482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2481, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2483 lang.IFn; if linked_2482 == nil { ifn_2483 = lang.IFn_Cast(root_2481) } else { ifn_2483 = nil }; var arg_2484 any; var tmp32 any = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New(); var tmp33 *jrt.Class; var fncls__2480 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class; if fncls__2480 == nil { var fncls__2480d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class = fncls__2480d; tmp33 = fncls__2480d } else { tmp33 = fncls__2480 }; arg_2484 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var arg_2485 any = ks__8; if linked_2482 == nil { arg_2492 = ifn_2483.Invoke_O_O__O(arg_2484, arg_2485) } else { arg_2492 = linked_2482.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2481, arg_2484, arg_2485) }; if linked_2487 == nil { tmp31 = ifn_2488.Invoke_O_O_O_O__O(arg_2489, arg_2490, arg_2491, arg_2492) } else { tmp31 = linked_2487.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2486, arg_2489, arg_2490, arg_2491, arg_2492) }; var tmp34 any = /*line :334:1*/tmp27.Invoke_O_O_O__O(tmp28, tmp30, tmp31); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp36 any = A_arbace_j2g_dyn_A_const_249; var tmp37 any; var root_2497 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2497, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2499 lang.IFn; if








	linked_2498 == nil { ifn_2499 = lang.IFn_Cast(root_2497) } else { ifn_2499 = nil }; var arg_2500 any; var root_2493 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2493, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2495 lang.IFn; if linked_2494 == nil { ifn_2495 = lang.IFn_Cast(root_2493) } else { ifn_2495 = nil }; var arg_2496 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2494 == nil { arg_2500 = ifn_2495.Invoke_O__O(arg_2496) } else { arg_2500 = linked_2494.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2493, arg_2496) }; var arg_2501 any = A_arbace_j2g_dyn_A_const_250; if linked_2498 == nil { tmp37 = ifn_2499.Invoke_O_O__O(arg_2500, arg_2501) } else { tmp37 = linked_2498.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2497, arg_2500, arg_2501) }; var tmp38 any = tmp37; var tmp39 any; var root_2569 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2569, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2571 lang.IFn; if









	linked_2570 == nil { ifn_2571 = lang.IFn_Cast(root_2569) } else { ifn_2571 = nil }; var arg_2572 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2573 any = A_arbace_j2g_dyn_A_const_251; var arg_2574 any = A_arbace_j2g_dyn_A_const_252; var arg_2575 any; var iter__1927001039__auto____11 any; var tmp40 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New(); var tmp41 *jrt.Class; var fncls__2560 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class; if fncls__2560 == nil { var fncls__2560d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class = fncls__2560d; tmp41 = fncls__2560d } else { tmp41 = fncls__2560 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); var tmp42 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11); var tmp43 any; var root_2565 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_2566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2565, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2567 lang.IFn; if linked_2566 == nil { ifn_2567 = lang.IFn_Cast(root_2565) } else { ifn_2567 = nil }; var arg_2568 any; var root_2561 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_2562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2561, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2563 lang.IFn; if linked_2562 == nil { ifn_2563 = lang.IFn_Cast(root_2561) } else { ifn_2563 = nil }; var arg_2564 any = own__6; if linked_2562 == nil { arg_2568 = ifn_2563.Invoke_O__O(arg_2564) } else { arg_2568 = linked_2562.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2561, arg_2564) }; if linked_2566 == nil { tmp43 = ifn_2567.Invoke_O__O(arg_2568) } else { tmp43 = linked_2566.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2565, arg_2568) }; arg_2575 = tmp42.Invoke_O__O(tmp43); if linked_2570 == nil { tmp39 = ifn_2571.Invoke_O_O_O_O__O(arg_2572, arg_2573, arg_2574, arg_2575) } else { tmp39 = linked_2570.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2569, arg_2572, arg_2573, arg_2574, arg_2575) }; var tmp44 any = /*line :334:1*/tmp35.Invoke_O_O_O__O(tmp36, tmp38, tmp39); var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp46 any = A_arbace_j2g_dyn_A_const_253; var tmp47 any = A_arbace_j2g_dyn_A_const_254; var tmp48 any; var root_2581 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2583 lang.IFn; if










	linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any; var tmp49 any; var root_2576 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = A_arbace_j2g_dyn_A_const_255; var arg_2580 any = recv__5; if linked_2577 == nil { tmp49 = ifn_2578.Invoke_O_O__O(arg_2579, arg_2580) } else { tmp49 = linked_2577.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2576, arg_2579, arg_2580) }; arg_2584 = lang.Tuple_Create_O__IPersistentVector(tmp49); var arg_2585 any = A_arbace_j2g_dyn_A_const_256; if linked_2582 == nil { tmp48 = ifn_2583.Invoke_O_O__O(arg_2584, arg_2585) } else { tmp48 = linked_2582.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2581, arg_2584, arg_2585) }; var tmp50 any = /*line :334:1*/tmp45.Invoke_O_O_O_O_O__O(tmp46, tmp47, tmp48, A_arbace_j2g_dyn_A_const_257, A_arbace_j2g_dyn_A_const_258); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp52 any = A_arbace_j2g_dyn_A_const_259; var tmp53 any = A_arbace_j2g_dyn_A_const_260; var tmp54 any; var root_2591 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2591, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2593 lang.IFn; if











	linked_2592 == nil { ifn_2593 = lang.IFn_Cast(root_2591) } else { ifn_2593 = nil }; var arg_2594 any; var tmp55 any; var root_2586 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2586, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2588 lang.IFn; if linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any = A_arbace_j2g_dyn_A_const_261; var arg_2590 any = recv__5; if linked_2587 == nil { tmp55 = ifn_2588.Invoke_O_O__O(arg_2589, arg_2590) } else { tmp55 = linked_2587.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2586, arg_2589, arg_2590) }; arg_2594 = lang.Tuple_Create_O__IPersistentVector(tmp55); var arg_2595 any = A_arbace_j2g_dyn_A_const_262; if linked_2592 == nil { tmp54 = ifn_2593.Invoke_O_O__O(arg_2594, arg_2595) } else { tmp54 = linked_2592.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2591, arg_2594, arg_2595) }; var tmp56 any = /*line :334:1*/tmp51.Invoke_O_O_O_O__O(tmp52, tmp53, tmp54, A_arbace_j2g_dyn_A_const_263); var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp58 any = A_arbace_j2g_dyn_A_const_264; var tmp59 any = A_arbace_j2g_dyn_A_const_265; var tmp60 any; var root_2601 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2601, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2603 lang.IFn; if












	linked_2602 == nil { ifn_2603 = lang.IFn_Cast(root_2601) } else { ifn_2603 = nil }; var arg_2604 any; var tmp61 any; var root_2596 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2596, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2598 lang.IFn; if linked_2597 == nil { ifn_2598 = lang.IFn_Cast(root_2596) } else { ifn_2598 = nil }; var arg_2599 any = A_arbace_j2g_dyn_A_const_266; var arg_2600 any = recv__5; if linked_2597 == nil { tmp61 = ifn_2598.Invoke_O_O__O(arg_2599, arg_2600) } else { tmp61 = linked_2597.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2596, arg_2599, arg_2600) }; arg_2604 = lang.Tuple_Create_O__IPersistentVector(tmp61); var arg_2605 any = A_arbace_j2g_dyn_A_const_267; if linked_2602 == nil { tmp60 = ifn_2603.Invoke_O_O__O(arg_2604, arg_2605) } else { tmp60 = linked_2602.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2601, arg_2604, arg_2605) }; var tmp62 any = /*line :334:1*/tmp57.Invoke_O_O_O_O__O(tmp58, tmp59, tmp60, A_arbace_j2g_dyn_A_const_268); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_dyn_A_const_269; var tmp65 any = A_arbace_j2g_dyn_A_const_270; var tmp66 any; var root_2611 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2611, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2613 lang.IFn; if













	linked_2612 == nil { ifn_2613 = lang.IFn_Cast(root_2611) } else { ifn_2613 = nil }; var arg_2614 any; var tmp67 any; var root_2606 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2606, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2608 lang.IFn; if linked_2607 == nil { ifn_2608 = lang.IFn_Cast(root_2606) } else { ifn_2608 = nil }; var arg_2609 any = A_arbace_j2g_dyn_A_const_271; var arg_2610 any = recv__5; if linked_2607 == nil { tmp67 = ifn_2608.Invoke_O_O__O(arg_2609, arg_2610) } else { tmp67 = linked_2607.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2606, arg_2609, arg_2610) }; arg_2614 = lang.Tuple_Create_O__IPersistentVector(tmp67); var arg_2615 any = A_arbace_j2g_dyn_A_const_272; if linked_2612 == nil { tmp66 = ifn_2613.Invoke_O_O__O(arg_2614, arg_2615) } else { tmp66 = linked_2612.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2611, arg_2614, arg_2615) }; var tmp68 any = /*line :334:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp26, tmp34, tmp44, tmp50, tmp56, tmp62, tmp63.Invoke_O_O_O_O__O(tmp64, tmp65, tmp66, A_arbace_j2g_dyn_A_const_273))); var tmp69 any; var iter__1927001039__auto____11_2 any; var tmp70 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(recv__5, n__0); var tmp71 *jrt.Class; var fncls__2702 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class; if














	fncls__2702 == nil { var fncls__2702d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class = fncls__2702d; tmp71 = fncls__2702d } else { tmp71 = fncls__2702 }; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp70, tmp71, nil); var tmp72 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11_2); var tmp73 any; var root_2703 any = A_arbace_j2g_dyn_A_const_133.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2705 lang.IFn; if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O())).Ref(); if linked_2704 == nil { tmp73 = ifn_2705.Invoke_O__O(arg_2706) } else { tmp73 = linked_2704.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2703, arg_2706) }; tmp69 = tmp72.Invoke_O__O(tmp73); var tmp74 any = tmp69; var tmp75 any; var iter__1927001039__auto____11_3 any; var tmp76 any = /*line :334:1*/A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(recv__5, clash__9); var tmp77 *jrt.Class; var fncls__2795 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class; if

















	fncls__2795 == nil { var fncls__2795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class = fncls__2795d; tmp77 = fncls__2795d } else { tmp77 = fncls__2795 }; iter__1927001039__auto____11_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp76, tmp77, nil); tmp75 = lang.IFn_Cast(iter__1927001039__auto____11_3).Invoke_O__O(ifaces__1); var tmp78 any = tmp75; var tmp79 any; var root_2830 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_277.GetRawRoot__O(); var linked_2831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2830, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_2832 lang.IFn; if



















	linked_2831 == nil { ifn_2832 = lang.IFn_Cast(root_2830) } else { ifn_2832 = nil }; var arg_2833 any; var tmp80 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(own__6, recv__5, clash__9, ifaces__1, n__0); var tmp81 *jrt.Class; var fncls__2829 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class; if fncls__2829 == nil { var fncls__2829d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class = fncls__2829d; tmp81 = fncls__2829d } else { tmp81 = fncls__2829 }; arg_2833 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp80, tmp81, nil); var arg_2834 any = ks__8; if linked_2831 == nil { tmp79 = ifn_2832.Invoke_O_O__O(arg_2833, arg_2834) } else { tmp79 = linked_2831.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_2830, arg_2833, arg_2834) }; var tmp82 any = tmp79; var tmp83 any; var root_2835 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_279.GetRawRoot__O(); var linked_2836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2835, A_arbace_j2g_dyn_ctor_infos_A_fn_class); var ifn_2837 lang.IFn; if


























	linked_2836 == nil { ifn_2837 = lang.IFn_Cast(root_2835) } else { ifn_2837 = nil }; var arg_2838 any = n__0; if linked_2836 == nil { tmp83 = ifn_2837.Invoke_O__O(arg_2838) } else { tmp83 = linked_2836.(*A_arbace_j2g_dyn_ctor_infos_A).Invoke_O_O__O(root_2835, arg_2838) }; return /*line :334:1*/ tmp8.Invoke_O_O_O_O_O__O(tmp68, tmp74, tmp78, tmp82, lang.Tuple_Create_O__IPersistentVector(tmp83)) }
//line :329:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Ctor() {}
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Invoke_O_O__O(self, s__711000308__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(self, s__711000308__1); var tmp2 *jrt.Class; var fncls__2405 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class; if fncls__2405 == nil { var fncls__2405d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class = fncls__2405d; tmp2 = fncls__2405d } else { tmp2 = fncls__2405 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :329:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A{}; t.Ctor_O_O(p0, p1); return t }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Ctor_O_O(c__iter__711000307, c__s__711000308 any) { t.F_iter__711000307 = c__iter__711000307; t.F_s__711000308 = c__s__711000308 }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Invoke_O__O(self any) any { { var s__711000308__1 any; var t_ any = t.F_s__711000308; t.F_s__711000308 = nil; s__711000308__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2336 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2336, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2338 lang.IFn; if linked_2337 == nil { ifn_2338 = lang.IFn_Cast(root_2336) } else { ifn_2338 = nil }; var arg_2339 any = s__711000308__1; if linked_2337 == nil { temp__1927000414__auto____2 = ifn_2338.Invoke_O__O(arg_2339) } else { temp__1927000414__auto____2 = linked_2337.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2336, arg_2339) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000308__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2340 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2340, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2342 lang.IFn; if linked_2341 == nil { ifn_2342 = lang.IFn_Cast(root_2340) } else { ifn_2342 = nil }; var arg_2343 any = s__711000308__3; if linked_2341 == nil { tmp1 = ifn_2342.Invoke_O__O(arg_2343) } else { tmp1 = linked_2341.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2340, arg_2343) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2344 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2344, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2346 lang.IFn; if linked_2345 == nil { ifn_2346 = lang.IFn_Cast(root_2344) } else { ifn_2346 = nil }; var arg_2347 any = s__711000308__3; if linked_2345 == nil { c__1927001037__auto____4 = ifn_2346.Invoke_O__O(arg_2347) } else { c__1927001037__auto____4 = linked_2345.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2344, arg_2347) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000310__6 any; var root_2348 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2349 == nil { b__711000310__6 = ifn_2350.Invoke_O__O(arg_2351) } else { b__711000310__6 = linked_2349.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2348, arg_2351) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(b__711000310__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2361 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class; if fncls__2361 == nil { var fncls__2361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class = fncls__2361d; tmp3 = fncls__2361d } else { tmp3 = fncls__2361 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2370 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2372 lang.IFn; if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any; var root_2362 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2362, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2364 lang.IFn; if linked_2363 == nil { ifn_2364 = lang.IFn_Cast(root_2362) } else { ifn_2364 = nil }; var arg_2365 any = b__711000310__6; if linked_2363 == nil { arg_2373 = ifn_2364.Invoke_O__O(arg_2365) } else { arg_2373 = linked_2363.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2362, arg_2365) }; var arg_2374 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp5 any; var root_2366 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2366, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2368 lang.IFn; if linked_2367 == nil { ifn_2368 = lang.IFn_Cast(root_2366) } else { ifn_2368 = nil }; var arg_2369 any = s__711000308__3; if linked_2367 == nil { tmp5 = ifn_2368.Invoke_O__O(arg_2369) } else { tmp5 = linked_2367.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2366, arg_2369) }; arg_2374 = tmp4.Invoke_O__O(tmp5); if linked_2371 == nil { return ifn_2372.Invoke_O_O__O(arg_2373, arg_2374) } else { return linked_2371.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2370, arg_2373, arg_2374) } } else { var root_2379 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2379, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2381 lang.IFn; if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any; var root_2375 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2375, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2377 lang.IFn; if linked_2376 == nil { ifn_2377 = lang.IFn_Cast(root_2375) } else { ifn_2377 = nil }; var arg_2378 any = b__711000310__6; if linked_2376 == nil { arg_2382 = ifn_2377.Invoke_O__O(arg_2378) } else { arg_2382 = linked_2376.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2375, arg_2378) }; var arg_2383 any; if linked_2380 == nil { return ifn_2381.Invoke_O_O__O(arg_2382, arg_2383) } else { return linked_2380.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2379, arg_2382, arg_2383) } } } else { var vec__711000318__4 any; var root_2384 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2386 lang.IFn; if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = s__711000308__3; if linked_2385 == nil { vec__711000318__4 = ifn_2386.Invoke_O__O(arg_2387) } else { vec__711000318__4 = linked_2385.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2384, arg_2387) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_2388 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2388, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__5); if linked_2389 == nil { tmp6 = ifn_2390.Invoke_O__O(arg_2391) } else { tmp6 = linked_2389.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2388, arg_2391) }; if jrt.J2g_Truth(tmp6) { var root_2396 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2396, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2398 lang.IFn; if linked_2397 == nil { ifn_2398 = lang.IFn_Cast(root_2396) } else { ifn_2398 = nil }; var arg_2399 any = lang.Tuple_Create_O_O__IPersistentVector(k__5, mm__6); var arg_2400 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp8 any; var root_2392 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2392, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2394 lang.IFn; if linked_2393 == nil { ifn_2394 = lang.IFn_Cast(root_2392) } else { ifn_2394 = nil }; var arg_2395 any = s__711000308__3; if linked_2393 == nil { tmp8 = ifn_2394.Invoke_O__O(arg_2395) } else { tmp8 = linked_2393.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2392, arg_2395) }; arg_2400 = tmp7.Invoke_O__O(tmp8); if linked_2397 == nil { return ifn_2398.Invoke_O_O__O(arg_2399, arg_2400) } else { return linked_2397.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2396, arg_2399, arg_2400) } } else { var tmp9 any; var root_2401 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2403 lang.IFn; if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = s__711000308__3; if linked_2402 == nil { tmp9 = ifn_2403.Invoke_O__O(arg_2404) } else { tmp9 = linked_2402.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2401, arg_2404) }; s__711000308__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :329:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Ctor_O_I_O(c__b__711000310 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000310 = c__b__711000310; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Invoke_O__O(self any) any { { var i__711000309__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000309__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000314__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000309__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_2352 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__3); if linked_2353 == nil { tmp2 = ifn_2354.Invoke_O__O(arg_2355) } else { tmp2 = linked_2353.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2352, arg_2355) }; if jrt.J2g_Truth(tmp2) { var root_2356 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = t.F_b__711000310; var arg_2360 any = lang.Tuple_Create_O_O__IPersistentVector(k__3, mm__4); if linked_2357 == nil { ifn_2358.Invoke_O_O__O(arg_2359, arg_2360) } else { linked_2357.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2356, arg_2359, arg_2360) }; i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } else { i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New() *A_arbace_j2g_dyn_sub_forms_fn__711000324_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000324_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Ctor() {}
//line :342:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Invoke_O_O_O__O(self, i__1, p__711000323__2 any) any { var vec__711000325__3 any = p__711000323__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }

func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A{}; t.Ctor(); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Ctor() {}
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Invoke_O_O__O(self, s__711000330__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(s__711000330__1, self); var tmp2 *jrt.Class; var fncls__2559 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class; if fncls__2559 == nil { var fncls__2559d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class = fncls__2559d; tmp2 = fncls__2559d } else { tmp2 = fncls__2559 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :344:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Ctor_O_O(c__s__711000330, c__iter__711000329 any) { t.F_s__711000330 = c__s__711000330; t.F_iter__711000329 = c__iter__711000329 }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Invoke_O__O(self any) any { { var s__711000330__1 any; var t_ any = t.F_s__711000330; t.F_s__711000330 = nil; s__711000330__1 = t_; for { var temp__1927000414__auto____2 any; var root_2502 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2504 lang.IFn; if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any = s__711000330__1; if linked_2503 == nil { temp__1927000414__auto____2 = ifn_2504.Invoke_O__O(arg_2505) } else { temp__1927000414__auto____2 = linked_2503.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2502, arg_2505) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000330__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2506 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2508 lang.IFn; if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any = s__711000330__3; if linked_2507 == nil { tmp1 = ifn_2508.Invoke_O__O(arg_2509) } else { tmp1 = linked_2507.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2506, arg_2509) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2510 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2510, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2512 lang.IFn; if linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any = s__711000330__3; if linked_2511 == nil { c__1927001037__auto____4 = ifn_2512.Invoke_O__O(arg_2513) } else { c__1927001037__auto____4 = linked_2511.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2510, arg_2513) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000332__6 any; var root_2514 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2515 == nil { b__711000332__6 = ifn_2516.Invoke_O__O(arg_2517) } else { b__711000332__6 = linked_2515.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2514, arg_2517) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(b__711000332__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2523 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class; if fncls__2523 == nil { var fncls__2523d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class = fncls__2523d; tmp3 = fncls__2523d } else { tmp3 = fncls__2523 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2532 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2532, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2534 lang.IFn; if linked_2533 == nil { ifn_2534 = lang.IFn_Cast(root_2532) } else { ifn_2534 = nil }; var arg_2535 any; var root_2524 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2524, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2526 lang.IFn; if linked_2525 == nil { ifn_2526 = lang.IFn_Cast(root_2524) } else { ifn_2526 = nil }; var arg_2527 any = b__711000332__6; if linked_2525 == nil { arg_2535 = ifn_2526.Invoke_O__O(arg_2527) } else { arg_2535 = linked_2525.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2524, arg_2527) }; var arg_2536 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp5 any; var root_2528 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2528, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2530 lang.IFn; if linked_2529 == nil { ifn_2530 = lang.IFn_Cast(root_2528) } else { ifn_2530 = nil }; var arg_2531 any = s__711000330__3; if linked_2529 == nil { tmp5 = ifn_2530.Invoke_O__O(arg_2531) } else { tmp5 = linked_2529.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2528, arg_2531) }; arg_2536 = tmp4.Invoke_O__O(tmp5); if linked_2533 == nil { return ifn_2534.Invoke_O_O__O(arg_2535, arg_2536) } else { return linked_2533.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2532, arg_2535, arg_2536) } } else { var root_2541 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2541, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2543 lang.IFn; if linked_2542 == nil { ifn_2543 = lang.IFn_Cast(root_2541) } else { ifn_2543 = nil }; var arg_2544 any; var root_2537 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2537, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2539 lang.IFn; if linked_2538 == nil { ifn_2539 = lang.IFn_Cast(root_2537) } else { ifn_2539 = nil }; var arg_2540 any = b__711000332__6; if linked_2538 == nil { arg_2544 = ifn_2539.Invoke_O__O(arg_2540) } else { arg_2544 = linked_2538.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2537, arg_2540) }; var arg_2545 any; if linked_2542 == nil { return ifn_2543.Invoke_O_O__O(arg_2544, arg_2545) } else { return linked_2542.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2541, arg_2544, arg_2545) } } } else { var vec__711000340__4 any; var root_2546 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2546, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2548 lang.IFn; if linked_2547 == nil { ifn_2548 = lang.IFn_Cast(root_2546) } else { ifn_2548 = nil }; var arg_2549 any = s__711000330__3; if linked_2547 == nil { vec__711000340__4 = ifn_2548.Invoke_O__O(arg_2549) } else { vec__711000340__4 = linked_2547.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2546, arg_2549) }; var nme__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2554 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2554, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2556 lang.IFn; if linked_2555 == nil { ifn_2556 = lang.IFn_Cast(root_2554) } else { ifn_2556 = nil }; var arg_2557 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__5, desc__6)).Ref(), nme__5); var arg_2558 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp7 any; var root_2550 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2550, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2552 lang.IFn; if linked_2551 == nil { ifn_2552 = lang.IFn_Cast(root_2550) } else { ifn_2552 = nil }; var arg_2553 any = s__711000330__3; if linked_2551 == nil { tmp7 = ifn_2552.Invoke_O__O(arg_2553) } else { tmp7 = linked_2551.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2550, arg_2553) }; arg_2558 = tmp6.Invoke_O__O(tmp7); if linked_2555 == nil { return ifn_2556.Invoke_O_O__O(arg_2557, arg_2558) } else { return linked_2555.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2554, arg_2557, arg_2558) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :344:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Ctor_O_I_O(c__b__711000332 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000332 = c__b__711000332; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Invoke_O__O(self any) any { { var i__711000331__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000331__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000336__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000331__1)); var nme__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2518 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2518, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2520 lang.IFn; if linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any = t.F_b__711000332; var arg_2522 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__3, desc__4)).Ref(), nme__3); if linked_2519 == nil { ifn_2520.Invoke_O_O__O(arg_2521, arg_2522) } else { linked_2519.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2518, arg_2521, arg_2522) }; i__711000331__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000331__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A{}; t.Ctor_O_O(p0, p1); return t }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Invoke_O_O__O(self, s__711000346__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(t.F_recv, self, s__711000346__1, t.F_n); var tmp2 *jrt.Class; var fncls__2701 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class; if fncls__2701 == nil { var fncls__2701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class = fncls__2701d; tmp2 = fncls__2701d } else { tmp2 = fncls__2701 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :349:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Ctor_O_O_O_O(c__recv, c__iter__711000345, c__s__711000346, c__n any) { t.F_recv = c__recv; t.F_iter__711000345 = c__iter__711000345; t.F_s__711000346 = c__s__711000346; t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Invoke_O__O(self any) any { { var s__711000346__1 any; var t_ any = t.F_s__711000346; t.F_s__711000346 = nil; s__711000346__1 = t_; for { var temp__1927000414__auto____2 any; var root_2616 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = s__711000346__1; if linked_2617 == nil { temp__1927000414__auto____2 = ifn_2618.Invoke_O__O(arg_2619) } else { temp__1927000414__auto____2 = linked_2617.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2616, arg_2619) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000346__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2620 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any = s__711000346__3; if linked_2621 == nil { tmp1 = ifn_2622.Invoke_O__O(arg_2623) } else { tmp1 = linked_2621.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2620, arg_2623) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2624 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2624, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2626 lang.IFn; if linked_2625 == nil { ifn_2626 = lang.IFn_Cast(root_2624) } else { ifn_2626 = nil }; var arg_2627 any = s__711000346__3; if linked_2625 == nil { c__1927001037__auto____4 = ifn_2626.Invoke_O__O(arg_2627) } else { c__1927001037__auto____4 = linked_2625.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2624, arg_2627) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000348__6 any; var root_2628 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2628, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2630 lang.IFn; if linked_2629 == nil { ifn_2630 = lang.IFn_Cast(root_2628) } else { ifn_2630 = nil }; var arg_2631 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2629 == nil { b__711000348__6 = ifn_2630.Invoke_O__O(arg_2631) } else { b__711000348__6 = linked_2629.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2628, arg_2631) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(t.F_recv, t.F_n, b__711000348__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2651 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class; if fncls__2651 == nil { var fncls__2651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class = fncls__2651d; tmp3 = fncls__2651d } else { tmp3 = fncls__2651 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2660 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2660, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2662 lang.IFn; if linked_2661 == nil { ifn_2662 = lang.IFn_Cast(root_2660) } else { ifn_2662 = nil }; var arg_2663 any; var root_2652 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any = b__711000348__6; if linked_2653 == nil { arg_2663 = ifn_2654.Invoke_O__O(arg_2655) } else { arg_2663 = linked_2653.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2652, arg_2655) }; var arg_2664 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp5 any; var root_2656 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2656, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2658 lang.IFn; if linked_2657 == nil { ifn_2658 = lang.IFn_Cast(root_2656) } else { ifn_2658 = nil }; var arg_2659 any = s__711000346__3; if linked_2657 == nil { tmp5 = ifn_2658.Invoke_O__O(arg_2659) } else { tmp5 = linked_2657.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2656, arg_2659) }; arg_2664 = tmp4.Invoke_O__O(tmp5); if linked_2661 == nil { return ifn_2662.Invoke_O_O__O(arg_2663, arg_2664) } else { return linked_2661.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2660, arg_2663, arg_2664) } } else { var root_2669 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2669, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2671 lang.IFn; if linked_2670 == nil { ifn_2671 = lang.IFn_Cast(root_2669) } else { ifn_2671 = nil }; var arg_2672 any; var root_2665 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any = b__711000348__6; if linked_2666 == nil { arg_2672 = ifn_2667.Invoke_O__O(arg_2668) } else { arg_2672 = linked_2666.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2665, arg_2668) }; var arg_2673 any; if linked_2670 == nil { return ifn_2671.Invoke_O_O__O(arg_2672, arg_2673) } else { return linked_2670.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2669, arg_2672, arg_2673) } } } else { var i__4 any; var root_2674 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2674, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2676 lang.IFn; if linked_2675 == nil { ifn_2676 = lang.IFn_Cast(root_2674) } else { ifn_2676 = nil }; var arg_2677 any = s__711000346__3; if linked_2675 == nil { i__4 = ifn_2676.Invoke_O__O(arg_2677) } else { i__4 = linked_2675.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2674, arg_2677) }; var k__5 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__4)); var root_2696 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2696, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2698 lang.IFn; if linked_2697 == nil { ifn_2698 = lang.IFn_Cast(root_2696) } else { ifn_2698 = nil }; var arg_2699 any; var root_2685 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_2686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2685, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2687 lang.IFn

	if linked_2686 == nil { ifn_2687 = lang.IFn_Cast(root_2685) } else { ifn_2687 = nil }; var arg_2688 any = t.F_recv; var arg_2689 any = i__4; var arg_2690 any = k__5; var arg_2691 any; var tmp6 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(k__5, t.F_n); var tmp7 *jrt.Class; var fncls__2684 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class; if fncls__2684 == nil { var fncls__2684d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class = fncls__2684d; tmp7 = fncls__2684d } else { tmp7 = fncls__2684 }; arg_2691 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2686 == nil { arg_2699 = ifn_2687.Invoke_O_O_O_O__O(arg_2688, arg_2689, arg_2690, arg_2691) } else { arg_2699 = linked_2686.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2685, arg_2688, arg_2689, arg_2690, arg_2691) }
//line :349:1
	var arg_2700 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp9 any; var root_2692 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2692, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2694 lang.IFn; if linked_2693 == nil { ifn_2694 = lang.IFn_Cast(root_2692) } else { ifn_2694 = nil }; var arg_2695 any = s__711000346__3; if linked_2693 == nil { tmp9 = ifn_2694.Invoke_O__O(arg_2695) } else { tmp9 = linked_2693.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2692, arg_2695) }; arg_2700 = tmp8.Invoke_O__O(tmp9); if linked_2697 == nil { return ifn_2698.Invoke_O_O__O(arg_2699, arg_2700) } else { return linked_2697.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2696, arg_2699, arg_2700) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :349:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Ctor_O_O_O_I_O(c__recv, c__n, c__b__711000348 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_n = c__n; t.F_b__711000348 = c__b__711000348; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Invoke_O__O(self any) any { { var i__711000347__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000347__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000347__1)); var k__3 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__2)); var root_2646 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = t.F_b__711000348; var arg_2650 any; var root_2639 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_2640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2639, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2641 lang.IFn

	if linked_2640 == nil { ifn_2641 = lang.IFn_Cast(root_2639) } else { ifn_2641 = nil }; var arg_2642 any = t.F_recv; var arg_2643 any = i__2; var arg_2644 any = k__3; var arg_2645 any; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(k__3, t.F_n); var tmp3 *jrt.Class; var fncls__2638 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class; if fncls__2638 == nil { var fncls__2638d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class = fncls__2638d; tmp3 = fncls__2638d } else { tmp3 = fncls__2638 }; arg_2645 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_2640 == nil { arg_2650 = ifn_2641.Invoke_O_O_O_O__O(arg_2642, arg_2643, arg_2644, arg_2645) } else { arg_2650 = linked_2640.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2639, arg_2642, arg_2643, arg_2644, arg_2645) }
//line :349:1
	if linked_2647 == nil { ifn_2648.Invoke_O_O__O(arg_2649, arg_2650) } else { linked_2647.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2646, arg_2649, arg_2650) }; i__711000347__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000347__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2632 any = A_arbace_j2g_dyn_A_const_274.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2632, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2634 lang.IFn; if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any = t.F_n; var arg_2636 any = t.F_k; var arg_2637 any = pn__1; if linked_2633 == nil { return ifn_2634.Invoke_O_O_O__O(arg_2635, arg_2636, arg_2637) } else { return linked_2633.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2632, arg_2635, arg_2636, arg_2637) } }
//line :351:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2678 any = A_arbace_j2g_dyn_A_const_274.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = t.F_n; var arg_2682 any = t.F_k; var arg_2683 any = pn__1; if linked_2679 == nil { return ifn_2680.Invoke_O_O_O__O(arg_2681, arg_2682, arg_2683) } else { return linked_2679.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2678, arg_2681, arg_2682, arg_2683) } }
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Ctor_O_O(c__recv, c__clash any) { t.F_recv = c__recv; t.F_clash = c__clash }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Invoke_O_O__O(self, s__711000360__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(s__711000360__1, t.F_recv, t.F_clash, self); var tmp2 *jrt.Class; var fncls__2794 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class; if fncls__2794 == nil { var fncls__2794d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class = fncls__2794d; tmp2 = fncls__2794d } else { tmp2 = fncls__2794 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :352:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Ctor_O_O_O_O(c__s__711000360, c__recv, c__clash, c__iter__711000359 any) { t.F_s__711000360 = c__s__711000360; t.F_recv = c__recv; t.F_clash = c__clash; t.F_iter__711000359 = c__iter__711000359 }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Invoke_O__O(self any) any { { var s__711000360__1 any; var t_ any = t.F_s__711000360; t.F_s__711000360 = nil; s__711000360__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2707 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = s__711000360__1; if linked_2708 == nil { temp__1927000414__auto____2 = ifn_2709.Invoke_O__O(arg_2710) } else { temp__1927000414__auto____2 = linked_2708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2707, arg_2710) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000360__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2711 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = s__711000360__3; if linked_2712 == nil { tmp1 = ifn_2713.Invoke_O__O(arg_2714) } else { tmp1 = linked_2712.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2711, arg_2714) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2715 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2715, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2717 lang.IFn; if linked_2716 == nil { ifn_2717 = lang.IFn_Cast(root_2715) } else { ifn_2717 = nil }; var arg_2718 any = s__711000360__3; if linked_2716 == nil { c__1927001037__auto____4 = ifn_2717.Invoke_O__O(arg_2718) } else { c__1927001037__auto____4 = linked_2716.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2715, arg_2718) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000362__6 any; var root_2719 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2719, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2721 lang.IFn; if linked_2720 == nil { ifn_2721 = lang.IFn_Cast(root_2719) } else { ifn_2721 = nil }; var arg_2722 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2720 == nil { b__711000362__6 = ifn_2721.Invoke_O__O(arg_2722) } else { b__711000362__6 = linked_2720.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2719, arg_2722) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(t.F_recv, t.F_clash, b__711000362__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2741 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class; if fncls__2741 == nil { var fncls__2741d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class = fncls__2741d; tmp3 = fncls__2741d } else { tmp3 = fncls__2741 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2750 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2750, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2752 lang.IFn; if linked_2751 == nil { ifn_2752 = lang.IFn_Cast(root_2750) } else { ifn_2752 = nil }; var arg_2753 any; var root_2742 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; var arg_2745 any = b__711000362__6; if linked_2743 == nil { arg_2753 = ifn_2744.Invoke_O__O(arg_2745) } else { arg_2753 = linked_2743.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2742, arg_2745) }; var arg_2754 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp5 any; var root_2746 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2746, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2748 lang.IFn; if linked_2747 == nil { ifn_2748 = lang.IFn_Cast(root_2746) } else { ifn_2748 = nil }; var arg_2749 any = s__711000360__3; if linked_2747 == nil { tmp5 = ifn_2748.Invoke_O__O(arg_2749) } else { tmp5 = linked_2747.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2746, arg_2749) }; arg_2754 = tmp4.Invoke_O__O(tmp5); if linked_2751 == nil { return ifn_2752.Invoke_O_O__O(arg_2753, arg_2754) } else { return linked_2751.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2750, arg_2753, arg_2754) } } else { var root_2759 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2759, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2761 lang.IFn; if linked_2760 == nil { ifn_2761 = lang.IFn_Cast(root_2759) } else { ifn_2761 = nil }; var arg_2762 any; var root_2755 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2755, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2757 lang.IFn; if linked_2756 == nil { ifn_2757 = lang.IFn_Cast(root_2755) } else { ifn_2757 = nil }; var arg_2758 any = b__711000362__6; if linked_2756 == nil { arg_2762 = ifn_2757.Invoke_O__O(arg_2758) } else { arg_2762 = linked_2756.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2755, arg_2758) }; var arg_2763 any; if linked_2760 == nil { return ifn_2761.Invoke_O_O__O(arg_2762, arg_2763) } else { return linked_2760.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2759, arg_2762, arg_2763) } } } else { var j__4 any; var root_2764 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; var arg_2767 any = s__711000360__3; if linked_2765 == nil { j__4 = ifn_2766.Invoke_O__O(arg_2767) } else { j__4 = linked_2765.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2764, arg_2767) }; var mk__5 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp7 any; var root_2768 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2768, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2770 lang.IFn; if linked_2769 == nil { ifn_2770 = lang.IFn_Cast(root_2768) } else { ifn_2770 = nil }; var arg_2771 any = j__4; if linked_2769 == nil { tmp7 = ifn_2770.Invoke_O__O(arg_2771) } else { tmp7 = linked_2769.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2768, arg_2771) }; mk__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__5)) { var root_2785 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2785, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2787 lang.IFn; if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_275; var tmp10 any; var root_2772 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2772, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2774 lang.IFn
														if linked_2773 == nil { ifn_2774 = lang.IFn_Cast(root_2772) } else { ifn_2774 = nil }; var arg_2775 any = mk__5; if linked_2773 == nil { tmp10 = ifn_2774.Invoke_O__O(arg_2775) } else { tmp10 = linked_2773.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2772, arg_2775) }; var tmp11 any = tmp10; var tmp12 any; var root_2776 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2776, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2778 lang.IFn; if linked_2777 == nil { ifn_2778 = lang.IFn_Cast(root_2776) } else { ifn_2778 = nil }; var arg_2779 any = A_arbace_j2g_dyn_A_const_276; var arg_2780 any = t.F_recv; if linked_2777 == nil { tmp12 = ifn_2778.Invoke_O_O__O(arg_2779, arg_2780) } else { tmp12 = linked_2777.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2776, arg_2779, arg_2780) }; arg_2788 = tmp8.Invoke_O_O_O__O(tmp9, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12))
//line :352:1
	var arg_2789 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp14 any; var root_2781 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2781, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2783 lang.IFn; if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var arg_2784 any = s__711000360__3; if linked_2782 == nil { tmp14 = ifn_2783.Invoke_O__O(arg_2784) } else { tmp14 = linked_2782.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2781, arg_2784) }; arg_2789 = tmp13.Invoke_O__O(tmp14); if linked_2786 == nil { return ifn_2787.Invoke_O_O__O(arg_2788, arg_2789) } else { return linked_2786.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2785, arg_2788, arg_2789) } } else { var tmp15 any; var root_2790 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2790, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2792 lang.IFn; if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; var arg_2793 any = s__711000360__3; if linked_2791 == nil { tmp15 = ifn_2792.Invoke_O__O(arg_2793) } else { tmp15 = linked_2791.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2790, arg_2793) }; s__711000360__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Ctor_O_O_O_I_O(c__recv, c__clash, c__b__711000362 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_clash = c__clash; t.F_b__711000362 = c__b__711000362; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Invoke_O__O(self any) any { { var i__711000361__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000361__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000361__1)); var mk__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp3 any; var root_2723 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2723, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2725 lang.IFn; if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; var arg_2726 any = j__2; if linked_2724 == nil { tmp3 = ifn_2725.Invoke_O__O(arg_2726) } else { tmp3 = linked_2724.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2723, arg_2726) }; mk__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__3)) { var root_2736 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2736, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2738 lang.IFn; if linked_2737 == nil { ifn_2738 = lang.IFn_Cast(root_2736) } else { ifn_2738 = nil }; var arg_2739 any = t.F_b__711000362; var arg_2740 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_275; var tmp6 any; var root_2727 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2727, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2729 lang.IFn
															if linked_2728 == nil { ifn_2729 = lang.IFn_Cast(root_2727) } else { ifn_2729 = nil }; var arg_2730 any = mk__3; if linked_2728 == nil { tmp6 = ifn_2729.Invoke_O__O(arg_2730) } else { tmp6 = linked_2728.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2727, arg_2730) }; var tmp7 any = tmp6; var tmp8 any; var root_2731 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2731, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2733 lang.IFn; if linked_2732 == nil { ifn_2733 = lang.IFn_Cast(root_2731) } else { ifn_2733 = nil }; var arg_2734 any = A_arbace_j2g_dyn_A_const_276; var arg_2735 any = t.F_recv; if linked_2732 == nil { tmp8 = ifn_2733.Invoke_O_O__O(arg_2734, arg_2735) } else { tmp8 = linked_2732.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2731, arg_2734, arg_2735) }; arg_2740 = tmp4.Invoke_O_O_O__O(tmp5, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8))
//line :352:1
	if linked_2737 == nil { ifn_2738.Invoke_O_O__O(arg_2739, arg_2740) } else { linked_2737.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2736, arg_2739, arg_2740) }; i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } else { i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Ctor_O_O_O_O_O(c__own, c__recv, c__clash, c__ifaces, c__n any) { t.F_own = c__own; t.F_recv = c__recv; t.F_clash = c__clash; t.F_ifaces = c__ifaces; t.F_n = c__n }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Invoke_O_O_O__O(self, i__1, p__711000369__2 any) any { var vec__711000371__3 any = p__711000369__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000371__3; var tmp1 any; var and__1927000168__auto____7 bool; var na_2796 any = i__1; var na_2797 int64 = int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O())); if
														jrt.Long_InstanceOf(na_2796) { var n0_2798 int64 = jrt.NN(jrt.Long_Cast(na_2796)).LongValue__J(); var n1_2799 int64 = na_2797; and__1927000168__auto____7 = n0_2798 >= n1_2799 } else { and__1927000168__auto____7 = lang.Numbers_Gte_O_J__Z_NoInit(na_2796, na_2797) }; if and__1927000168__auto____7 { var or__1927000174__auto____8 any = lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)
															if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_clash); var tmp3 any; var root_2824 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2824, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2826 lang.IFn; if linked_2825 == nil { ifn_2826 = lang.IFn_Cast(root_2824) } else { ifn_2826 = nil }; var arg_2827 any = nme__4; var arg_2828 any = desc__5; if linked_2825 == nil { tmp3 = ifn_2826.Invoke_O_O__O(arg_2827, arg_2828) } else { tmp3 = linked_2825.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2824, arg_2827, arg_2828) }; tmp1 = tmp2.Invoke_O__O(tmp3) } } else {
//line :355:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				var root_2817 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_2818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2817, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2819 lang.IFn; if linked_2818 == nil { ifn_2819 = lang.IFn_Cast(root_2817) } else { ifn_2819 = nil }; var arg_2820 any = t.F_recv; var arg_2821 any = i__1; var arg_2822 any = k__6; var arg_2823 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)) {
					var tmp4 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(k__6, t.F_n); var tmp5 *jrt.Class; var fncls__2808 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class; if fncls__2808 == nil { var fncls__2808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class = fncls__2808d; tmp5 = fncls__2808d } else { tmp5 = fncls__2808 }; arg_2823 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) } else {
						var tmp6 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(k__6, t.F_ifaces); var tmp7 *jrt.Class; var fncls__2816 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class; if fncls__2816 == nil { var fncls__2816d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class = fncls__2816d; tmp7 = fncls__2816d } else { tmp7 = fncls__2816 }; arg_2823 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) }
//line :357:1
				if linked_2818 == nil { return ifn_2819.Invoke_O_O_O_O__O(arg_2820, arg_2821, arg_2822, arg_2823) } else { return linked_2818.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2817, arg_2820, arg_2821, arg_2822, arg_2823) } } else {
//line :355:1
					return nil } }


func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A{}; t.Ctor_O_O(p0, p1); return t }
//line :358:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :358:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2801 any = A_arbace_j2g_dyn_A_const_278.GetRawRoot__O(); var linked_2802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2801, A_arbace_j2g_dyn_class_fallback_A_fn_class); var ifn_2803 lang.IFn; if linked_2802 == nil { ifn_2803 = lang.IFn_Cast(root_2801) } else { ifn_2803 = nil }; var arg_2804 any = t.F_n; var arg_2805 any = t.F_k; var arg_2806 any = pn__1; var arg_2807 any = r__2; if linked_2802 == nil { return ifn_2803.Invoke_O_O_O_O__O(arg_2804, arg_2805, arg_2806, arg_2807) } else { return linked_2802.(*A_arbace_j2g_dyn_class_fallback_A).Invoke_O_O_O_O_O__O(root_2801, arg_2804, arg_2805, arg_2806, arg_2807) } }
func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2809 any = A_arbace_j2g_dyn_A_const_132.GetRawRoot__O(); var linked_2810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2809, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_2811 lang.IFn; if linked_2810 == nil { ifn_2811 = lang.IFn_Cast(root_2809) } else { ifn_2811 = nil }; var arg_2812 any = t.F_ifaces; var arg_2813 any = t.F_k; var arg_2814 any = pn__1; var arg_2815 any = r__2; if linked_2810 == nil { return ifn_2811.Invoke_O_O_O_O__O(arg_2812, arg_2813, arg_2814, arg_2815) } else { return linked_2810.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O__O(root_2809, arg_2812, arg_2813, arg_2814, arg_2815) } }

















func A_arbace_j2g_dyn_fn_field_native_A_New() *A_arbace_j2g_dyn_fn_field_native_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_fn_field_native_A{}; t.Ctor(); return t }
//line :377:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Ctor() {}
//line :377:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Invoke_O__O(self any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_281; var tmp3 any; var root_2856 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2856, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2858 lang.IFn; if linked_2857 == nil { ifn_2858 = lang.IFn_Cast(root_2856) } else { ifn_2858 = nil }; var arg_2859 any; var root_2851 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any = Lit_45; var arg_2855 any = Lit_46; if linked_2852 == nil { arg_2859 = ifn_2853.Invoke_O_O__O(arg_2854, arg_2855) } else { arg_2859 = linked_2852.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_2851, arg_2854, arg_2855) }; if linked_2857 == nil { tmp3 = ifn_2858.Invoke_O__O(arg_2859) } else { tmp3 = linked_2857.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2856, arg_2859) }; var tmp4 any = tmp3; var tmp5 any; var root_2860 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2860, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2862 lang.IFn
	if linked_2861 == nil { ifn_2862 = lang.IFn_Cast(root_2860) } else { ifn_2862 = nil }; var arg_2863 any = A_arbace_j2g_dyn_A_const_284; var arg_2864 any = A_arbace_j2g_dyn_A_const_285; if linked_2861 == nil { tmp5 = ifn_2862.Invoke_O_O__O(arg_2863, arg_2864) } else { tmp5 = linked_2861.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2860, arg_2863, arg_2864) }
//line :382:1
	var tmp6 any = tmp5; var tmp7 any; var root_2865 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2865, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2867 lang.IFn
	if linked_2866 == nil { ifn_2867 = lang.IFn_Cast(root_2865) } else { ifn_2867 = nil }; var arg_2868 any = A_arbace_j2g_dyn_A_const_286; var arg_2869 any = A_arbace_j2g_dyn_A_const_287; if linked_2866 == nil { tmp7 = ifn_2867.Invoke_O_O__O(arg_2868, arg_2869) } else { tmp7 = linked_2866.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2865, arg_2868, arg_2869) }
//line :382:1
	var tmp8 any = tmp7; var tmp9 any; var root_2870 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2870, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2872 lang.IFn
	if linked_2871 == nil { ifn_2872 = lang.IFn_Cast(root_2870) } else { ifn_2872 = nil }; var arg_2873 any = A_arbace_j2g_dyn_A_const_288; var arg_2874 any = A_arbace_j2g_dyn_A_const_289; if linked_2871 == nil { tmp9 = ifn_2872.Invoke_O_O__O(arg_2873, arg_2874) } else { tmp9 = linked_2871.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2870, arg_2873, arg_2874) }
//line :382:1
	var tmp10 any = tmp9; var tmp11 any; var root_2875 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2875, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2877 lang.IFn
	if linked_2876 == nil { ifn_2877 = lang.IFn_Cast(root_2875) } else { ifn_2877 = nil }; var arg_2878 any = A_arbace_j2g_dyn_A_const_290; var arg_2879 any = A_arbace_j2g_dyn_A_const_291; if linked_2876 == nil { tmp11 = ifn_2877.Invoke_O_O__O(arg_2878, arg_2879) } else { tmp11 = linked_2876.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2875, arg_2878, arg_2879) }
//line :382:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp10, tmp11), A_arbace_j2g_dyn_A_const_283)
}








func A_arbace_j2g_dyn_forms_A_New() *A_arbace_j2g_dyn_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_j2g_dyn_forms_A) Ctor() {}
//line :392:1
func (t *A_arbace_j2g_dyn_forms_A) Invoke_O_O__O(self, T__0_ any) any { var ifaces__2 any; var root_2880 any = A_arbace_j2g_dyn_A_const_292.GetRawRoot__O(); var linked_2881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2880, A_arbace_j2g_dyn_interfaces_A_fn_class); var ifn_2882 lang.IFn; if


	linked_2881 == nil { ifn_2882 = lang.IFn_Cast(root_2880) } else { ifn_2882 = nil }; var arg_2883 any = T__0_; if linked_2881 == nil { ifaces__2 = ifn_2882.Invoke_O__O(arg_2883) } else { ifaces__2 = linked_2881.(*A_arbace_j2g_dyn_interfaces_A).Invoke_O_O__O(root_2880, arg_2883) }; var ks__3 any; var root_2884 any = /*line :392:1*/A_arbace_j2g_dyn_A_const_293.GetRawRoot__O(); var linked_2885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2884, A_arbace_j2g_dyn_slot_keys_A_fn_class); var ifn_2886 lang.IFn; if



	linked_2885 == nil { ifn_2886 = lang.IFn_Cast(root_2884) } else { ifn_2886 = nil }; var arg_2887 any = ifaces__2; if linked_2885 == nil { ks__3 = ifn_2886.Invoke_O__O(arg_2887) } else { ks__3 = linked_2885.(*A_arbace_j2g_dyn_slot_keys_A).Invoke_O_O__O(root_2884, arg_2887) }; var n__4 int32 = /*line :392:1*/lang.RT_Count_O__I_NoInit(ks__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_42.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_314; var tmp4 any = tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_47, nil, Lit_48, nil, Lit_49), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ifaces__2)).Ref(), nil, jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref(), nil)).Ref()); var tmp5 any = A_arbace_j2g_dyn_A_const_294; var tmp6 any = A_arbace_j2g_dyn_A_const_295; var tmp7 any = A_arbace_j2g_dyn_A_const_296; var tmp8 any = A_arbace_j2g_dyn_A_const_297; var tmp9 any = A_arbace_j2g_dyn_A_const_298; var tmp10 any = A_arbace_j2g_dyn_A_const_299; var tmp11 any = A_arbace_j2g_dyn_A_const_300; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_dyn_A_const_315; var tmp14 any; var root_2888 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2888, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2890 lang.IFn; if



































	linked_2889 == nil { ifn_2890 = lang.IFn_Cast(root_2888) } else { ifn_2890 = nil }; var arg_2891 any = A_arbace_j2g_dyn_A_const_316; var arg_2892 any = A_arbace_j2g_dyn_A_const_317; if linked_2889 == nil { tmp14 = ifn_2890.Invoke_O_O__O(arg_2891, arg_2892) } else { tmp14 = linked_2889.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2888, arg_2891, arg_2892) }; var tmp15 any = tmp14; var tmp16 any; var root_2899 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2900 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2899, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2901 lang.IFn; if






























	linked_2900 == nil { ifn_2901 = lang.IFn_Cast(root_2899) } else { ifn_2901 = nil }; var arg_2902 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2903 any = A_arbace_j2g_dyn_A_const_318; var arg_2904 any = A_arbace_j2g_dyn_A_const_319; var arg_2905 any; var root_2894 any = A_arbace_j2g_dyn_A_const_227.GetRawRoot__O(); var linked_2895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2894, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2896 lang.IFn; if linked_2895 == nil { ifn_2896 = lang.IFn_Cast(root_2894) } else { ifn_2896 = nil }; var arg_2897 any; var tmp17 any = A_arbace_j2g_dyn_forms_fn__711000383_A_New(); var tmp18 *jrt.Class; var fncls__2893 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000383_A_fn_class; if fncls__2893 == nil { var fncls__2893d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_dyn_forms_fn__711000383_A_fn_class = fncls__2893d; tmp18 = fncls__2893d } else { tmp18 = fncls__2893 }; arg_2897 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_2898 any = ks__3; if linked_2895 == nil { arg_2905 = ifn_2896.Invoke_O_O__O(arg_2897, arg_2898) } else { arg_2905 = linked_2895.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2894, arg_2897, arg_2898) }; if linked_2900 == nil { tmp16 = ifn_2901.Invoke_O_O_O_O__O(arg_2902, arg_2903, arg_2904, arg_2905) } else { tmp16 = linked_2900.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2899, arg_2902, arg_2903, arg_2904, arg_2905) }; var tmp19 any = /*line :398:1*/tmp12.Invoke_O_O_O__O(tmp13, tmp15, tmp16); var tmp20 any = A_arbace_j2g_dyn_A_const_301; var tmp21 any = A_arbace_j2g_dyn_A_const_302; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyn_A_const_320; var tmp24 any = A_arbace_j2g_dyn_A_const_321; var tmp25 any; var root_2916 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2916, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2918 lang.IFn; if











































	linked_2917 == nil { ifn_2918 = lang.IFn_Cast(root_2916) } else { ifn_2918 = nil }; var arg_2919 any; var tmp26 any; var root_2906 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2906, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2908 lang.IFn; if linked_2907 == nil { ifn_2908 = lang.IFn_Cast(root_2906) } else { ifn_2908 = nil }; var arg_2909 any = A_arbace_j2g_dyn_A_const_322; var arg_2910 any = A_arbace_j2g_dyn_A_const_323; if linked_2907 == nil { tmp26 = ifn_2908.Invoke_O_O__O(arg_2909, arg_2910) } else { tmp26 = linked_2907.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2906, arg_2909, arg_2910) }; var tmp27 any = tmp26; var tmp28 any; var root_2911 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2911, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2913 lang.IFn; if linked_2912 == nil { ifn_2913 = lang.IFn_Cast(root_2911) } else { ifn_2913 = nil }; var arg_2914 any = A_arbace_j2g_dyn_A_const_324; var arg_2915 any = A_arbace_j2g_dyn_A_const_325; if linked_2912 == nil { tmp28 = ifn_2913.Invoke_O_O__O(arg_2914, arg_2915) } else { tmp28 = linked_2912.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2911, arg_2914, arg_2915) }; arg_2919 = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28); var arg_2920 any = A_arbace_j2g_dyn_A_const_326; if linked_2917 == nil { tmp25 = ifn_2918.Invoke_O_O__O(arg_2919, arg_2920) } else { tmp25 = linked_2917.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2916, arg_2919, arg_2920) }; var tmp29 any = tmp25; var tmp30 any; var root_3011 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_3012 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3011, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3013 lang.IFn; if












































	linked_3012 == nil { ifn_3013 = lang.IFn_Cast(root_3011) } else { ifn_3013 = nil }; var arg_3014 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_3015 any = A_arbace_j2g_dyn_A_const_327; var arg_3016 any = A_arbace_j2g_dyn_A_const_328; var arg_3017 any; var root_3006 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_3007 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3006, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3008 lang.IFn; if
	linked_3007 == nil { ifn_3008 = lang.IFn_Cast(root_3006) } else { ifn_3008 = nil }; var arg_3009 any; var iter__1927001039__auto____5 any; var tmp31 any = A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_New(); var tmp32 *jrt.Class; var fncls__3001 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_fn_class; if
	fncls__3001 == nil { var fncls__3001d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_fn_class = fncls__3001d; tmp32 = fncls__3001d } else { tmp32 = fncls__3001 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var tmp33 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp34 any; var root_3002 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_3003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3002, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3004 lang.IFn; if linked_3003 == nil { ifn_3004 = lang.IFn_Cast(root_3002) } else { ifn_3004 = nil }; var arg_3005 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); if linked_3003 == nil { tmp34 = ifn_3004.Invoke_O__O(arg_3005) } else { tmp34 = linked_3003.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3002, arg_3005) }; arg_3009 = tmp33.Invoke_O__O(tmp34); var arg_3010 any = A_arbace_j2g_dyn_A_const_332; if /*line :444:1*/ linked_3007 == nil { arg_3017 = ifn_3008.Invoke_O_O__O(arg_3009, arg_3010) } else { arg_3017 = linked_3007.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3006, arg_3009, arg_3010) }; if /*line :443:1*/ linked_3012 == nil { tmp30 = ifn_3013.Invoke_O_O_O_O__O(arg_3014, arg_3015, arg_3016, arg_3017) } else { tmp30 = linked_3012.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3011, arg_3014, arg_3015, arg_3016, arg_3017) }; var tmp35 any = /*line :398:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp19, tmp20, tmp21, tmp22.Invoke_O_O_O_O_O_O__O(tmp23, tmp24, Lit_51, tmp29, tmp30, A_arbace_j2g_dyn_A_const_333), A_arbace_j2g_dyn_A_const_303, A_arbace_j2g_dyn_A_const_304, A_arbace_j2g_dyn_A_const_305, A_arbace_j2g_dyn_A_const_306, A_arbace_j2g_dyn_A_const_307, A_arbace_j2g_dyn_A_const_308, A_arbace_j2g_dyn_A_const_309, A_arbace_j2g_dyn_A_const_310, A_arbace_j2g_dyn_A_const_311, A_arbace_j2g_dyn_A_const_312, A_arbace_j2g_dyn_A_const_313)); var tmp36 any; var iter__1927001039__auto____5_2 any; var tmp37 any = A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_New(); var tmp38 *jrt.Class; var fncls__3102 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_fn_class; if























































































	fncls__3102 == nil { var fncls__3102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_fn_class = fncls__3102d; tmp38 = fncls__3102d } else { tmp38 = fncls__3102 }; iter__1927001039__auto____5_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil); tmp36 = lang.IFn_Cast(iter__1927001039__auto____5_2).Invoke_O__O(ifaces__2); var tmp39 any = tmp36; var tmp40 any; var nobj__5 int32 = /*line :398:1*/lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_337.GetRawRoot__O()); var tmp42 any; var root_3103 any = A_arbace_j2g_dyn_A_const_338.GetRawRoot__O(); var linked_3104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3103, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_3105 lang.IFn; if


























































































	linked_3104 == nil { ifn_3105 = lang.IFn_Cast(root_3103) } else { ifn_3105 = nil }; if linked_3104 == nil { tmp42 = ifn_3105.Invoke__O() } else { tmp42 = linked_3104.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_3103) }; var tmp43 any = tmp42; var tmp44 any = A_arbace_j2g_dyn_forms_fn__711000414_A_New_O_O(ks__3, ifaces__2); var tmp45 *jrt.Class; var fncls__3112 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000414_A_fn_class; if fncls__3112 == nil { var fncls__3112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_dyn_forms_fn__711000414_A_fn_class = fncls__3112d; tmp45 = fncls__3112d } else { tmp45 = fncls__3112 }; var tmp46 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil); var tmp47 any; var root_3113 any = A_arbace_j2g_dyn_A_const_133.GetRawRoot__O(); var linked_3114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3113, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3115 lang.IFn; if linked_3114 == nil { ifn_3115 = lang.IFn_Cast(root_3113) } else { ifn_3115 = nil }; var arg_3116 any = jrt.Integer_ValueOf_I__Integer_NoInit(nobj__5).Ref(); var arg_3117 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__3)).Ref(); if linked_3114 == nil { tmp47 = ifn_3115.Invoke_O_O__O(arg_3116, arg_3117) } else { tmp47 = linked_3114.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_3113, arg_3116, arg_3117) }; tmp40 = tmp41.Invoke_O_O_O__O(tmp43, tmp46, tmp47); var tmp48 any = tmp40; var tmp49 lang.IFn = /*line :398:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp50 any = A_arbace_j2g_dyn_A_const_348; var tmp51 any; var root_3132 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3132, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3134 lang.IFn; if




























































































	linked_3133 == nil { ifn_3134 = lang.IFn_Cast(root_3132) } else { ifn_3134 = nil }; var arg_3135 any; var root_3127 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3127, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3129 lang.IFn; if linked_3128 == nil { ifn_3129 = lang.IFn_Cast(root_3127) } else { ifn_3129 = nil }; var arg_3130 any = Lit_55; var arg_3131 any = Lit_56; if linked_3128 == nil { arg_3135 = ifn_3129.Invoke_O_O__O(arg_3130, arg_3131) } else { arg_3135 = linked_3128.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3127, arg_3130, arg_3131) }; if linked_3133 == nil { tmp51 = ifn_3134.Invoke_O__O(arg_3135) } else { tmp51 = linked_3133.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3132, arg_3135) }; var tmp52 any = tmp51; var tmp53 any; var root_3151 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3151, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3153 lang.IFn; if





























































































	linked_3152 == nil { ifn_3153 = lang.IFn_Cast(root_3151) } else { ifn_3153 = nil }; var arg_3154 any; var tmp54 any; var root_3136 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3136, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3138 lang.IFn; if linked_3137 == nil { ifn_3138 = lang.IFn_Cast(root_3136) } else { ifn_3138 = nil }; var arg_3139 any = A_arbace_j2g_dyn_A_const_349; var arg_3140 any = A_arbace_j2g_dyn_A_const_350; if linked_3137 == nil { tmp54 = ifn_3138.Invoke_O_O__O(arg_3139, arg_3140) } else { tmp54 = linked_3137.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3136, arg_3139, arg_3140) }; var tmp55 any = tmp54; var tmp56 any; var root_3141 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3141, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3143 lang.IFn; if linked_3142 == nil { ifn_3143 = lang.IFn_Cast(root_3141) } else { ifn_3143 = nil }; var arg_3144 any = A_arbace_j2g_dyn_A_const_351; var arg_3145 any = A_arbace_j2g_dyn_A_const_352; if linked_3142 == nil { tmp56 = ifn_3143.Invoke_O_O__O(arg_3144, arg_3145) } else { tmp56 = linked_3142.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3141, arg_3144, arg_3145) }; var tmp57 any = tmp56; var tmp58 any; var root_3146 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3146, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3148 lang.IFn; if linked_3147 == nil { ifn_3148 = lang.IFn_Cast(root_3146) } else { ifn_3148 = nil }; var arg_3149 any = A_arbace_j2g_dyn_A_const_353; var arg_3150 any = A_arbace_j2g_dyn_A_const_354; if linked_3147 == nil { tmp58 = ifn_3148.Invoke_O_O__O(arg_3149, arg_3150) } else { tmp58 = linked_3147.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3146, arg_3149, arg_3150) }; arg_3154 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp55, tmp57, tmp58); var arg_3155 any = A_arbace_j2g_dyn_A_const_355; if linked_3152 == nil { tmp53 = ifn_3153.Invoke_O_O__O(arg_3154, arg_3155) } else { tmp53 = linked_3152.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3151, arg_3154, arg_3155) }; var tmp59 lang.IFn = /*line :398:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp60 any = A_arbace_j2g_dyn_A_const_356; var tmp61 any = A_arbace_j2g_dyn_A_const_360; var tmp62 any = A_arbace_j2g_dyn_A_const_361; var tmp63 any = A_arbace_j2g_dyn_A_const_362; var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp65 any = A_arbace_j2g_dyn_A_const_363; var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp67 any = A_arbace_j2g_dyn_A_const_364; var tmp68 any = A_arbace_j2g_dyn_A_const_365; var tmp69 any = A_arbace_j2g_dyn_A_const_366; var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp71 any = A_arbace_j2g_dyn_A_const_373; var tmp72 any = A_arbace_j2g_dyn_A_const_374; var tmp73 any = tmp49.Invoke_O_O_O_O__O(tmp50, tmp52, tmp53, tmp59.Invoke_O_O_O_O_O__O(tmp60, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp61, tmp62, tmp63, tmp64.Invoke_O_O__O(tmp65, tmp66.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp67, tmp68, tmp69, tmp70.Invoke_O_O_O__O(tmp71, tmp72, jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref()), A_arbace_j2g_dyn_A_const_367, A_arbace_j2g_dyn_A_const_368, A_arbace_j2g_dyn_A_const_369, A_arbace_j2g_dyn_A_const_370, A_arbace_j2g_dyn_A_const_371, A_arbace_j2g_dyn_A_const_372))), A_arbace_j2g_dyn_A_const_357, A_arbace_j2g_dyn_A_const_358, A_arbace_j2g_dyn_A_const_359)); var tmp74 any = A_arbace_j2g_dyn_A_const_339; var tmp75 any = A_arbace_j2g_dyn_A_const_340; var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp77 any = A_arbace_j2g_dyn_A_const_375; var tmp78 any; var root_3161 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3161, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3163 lang.IFn; if



































































































































	linked_3162 == nil { ifn_3163 = lang.IFn_Cast(root_3161) } else { ifn_3163 = nil }; var arg_3164 any; var root_3156 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3156, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3158 lang.IFn; if linked_3157 == nil { ifn_3158 = lang.IFn_Cast(root_3156) } else { ifn_3158 = nil }; var arg_3159 any = Lit_57; var arg_3160 any = Lit_58; if linked_3157 == nil { arg_3164 = ifn_3158.Invoke_O_O__O(arg_3159, arg_3160) } else { arg_3164 = linked_3157.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3156, arg_3159, arg_3160) }; if linked_3162 == nil { tmp78 = ifn_3163.Invoke_O__O(arg_3164) } else { tmp78 = linked_3162.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3161, arg_3164) }; var tmp79 any = tmp78; var tmp80 any; var root_3165 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3165, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3167 lang.IFn; if




































































































































	linked_3166 == nil { ifn_3167 = lang.IFn_Cast(root_3165) } else { ifn_3167 = nil }; var arg_3168 any = A_arbace_j2g_dyn_A_const_377; var arg_3169 any = A_arbace_j2g_dyn_A_const_378; if linked_3166 == nil { tmp80 = ifn_3167.Invoke_O_O__O(arg_3168, arg_3169) } else { tmp80 = linked_3166.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3165, arg_3168, arg_3169) }; var tmp81 any = tmp80; var tmp82 any; var root_3170 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3170, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3172 lang.IFn; if




































































































































	linked_3171 == nil { ifn_3172 = lang.IFn_Cast(root_3170) } else { ifn_3172 = nil }; var arg_3173 any = A_arbace_j2g_dyn_A_const_379; var arg_3174 any = A_arbace_j2g_dyn_A_const_380; if linked_3171 == nil { tmp82 = ifn_3172.Invoke_O_O__O(arg_3173, arg_3174) } else { tmp82 = linked_3171.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3170, arg_3173, arg_3174) }; var tmp83 any = tmp82; var tmp84 any; var root_3175 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3175, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3177 lang.IFn; if




































































































































	linked_3176 == nil { ifn_3177 = lang.IFn_Cast(root_3175) } else { ifn_3177 = nil }; var arg_3178 any = A_arbace_j2g_dyn_A_const_381; var arg_3179 any = A_arbace_j2g_dyn_A_const_382; if linked_3176 == nil { tmp84 = ifn_3177.Invoke_O_O__O(arg_3178, arg_3179) } else { tmp84 = linked_3176.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3175, arg_3178, arg_3179) }; var tmp85 any = tmp84; var tmp86 any; var root_3180 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3180, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3182 lang.IFn; if




































































































































	linked_3181 == nil { ifn_3182 = lang.IFn_Cast(root_3180) } else { ifn_3182 = nil }; var arg_3183 any = A_arbace_j2g_dyn_A_const_383; var arg_3184 any = A_arbace_j2g_dyn_A_const_384; if linked_3181 == nil { tmp86 = ifn_3182.Invoke_O_O__O(arg_3183, arg_3184) } else { tmp86 = linked_3181.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3180, arg_3183, arg_3184) }; var tmp87 any = tmp86; var tmp88 any; var root_3185 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3185, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3187 lang.IFn; if




































































































































	linked_3186 == nil { ifn_3187 = lang.IFn_Cast(root_3185) } else { ifn_3187 = nil }; var arg_3188 any = A_arbace_j2g_dyn_A_const_385; var arg_3189 any = A_arbace_j2g_dyn_A_const_386; if linked_3186 == nil { tmp88 = ifn_3187.Invoke_O_O__O(arg_3188, arg_3189) } else { tmp88 = linked_3186.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3185, arg_3188, arg_3189) }; var tmp89 any = /*line :398:1*/tmp76.Invoke_O_O_O_O__O(tmp77, tmp79, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp81, tmp83, tmp85, tmp87, tmp88), A_arbace_j2g_dyn_A_const_376); var tmp90 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp91 any = A_arbace_j2g_dyn_A_const_387; var tmp92 any; var root_3195 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3195, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3197 lang.IFn; if
































































































































































	linked_3196 == nil { ifn_3197 = lang.IFn_Cast(root_3195) } else { ifn_3197 = nil }; var arg_3198 any; var root_3190 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3190, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3192 lang.IFn; if linked_3191 == nil { ifn_3192 = lang.IFn_Cast(root_3190) } else { ifn_3192 = nil }; var arg_3193 any = Lit_59; var arg_3194 any = Lit_58; if linked_3191 == nil { arg_3198 = ifn_3192.Invoke_O_O__O(arg_3193, arg_3194) } else { arg_3198 = linked_3191.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3190, arg_3193, arg_3194) }; if linked_3196 == nil { tmp92 = ifn_3197.Invoke_O__O(arg_3198) } else { tmp92 = linked_3196.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3195, arg_3198) }; var tmp93 any = tmp92; var tmp94 any; var root_3199 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3199, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3201 lang.IFn; if

































































































































































	linked_3200 == nil { ifn_3201 = lang.IFn_Cast(root_3199) } else { ifn_3201 = nil }; var arg_3202 any = A_arbace_j2g_dyn_A_const_389; var arg_3203 any = A_arbace_j2g_dyn_A_const_390; if linked_3200 == nil { tmp94 = ifn_3201.Invoke_O_O__O(arg_3202, arg_3203) } else { tmp94 = linked_3200.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3199, arg_3202, arg_3203) }; var tmp95 any = tmp94; var tmp96 any; var root_3204 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3204, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3206 lang.IFn; if

































































































































































	linked_3205 == nil { ifn_3206 = lang.IFn_Cast(root_3204) } else { ifn_3206 = nil }; var arg_3207 any = A_arbace_j2g_dyn_A_const_391; var arg_3208 any = A_arbace_j2g_dyn_A_const_392; if linked_3205 == nil { tmp96 = ifn_3206.Invoke_O_O__O(arg_3207, arg_3208) } else { tmp96 = linked_3205.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3204, arg_3207, arg_3208) }; var tmp97 any = tmp96; var tmp98 any; var root_3209 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3209, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3211 lang.IFn; if

































































































































































	linked_3210 == nil { ifn_3211 = lang.IFn_Cast(root_3209) } else { ifn_3211 = nil }; var arg_3212 any = A_arbace_j2g_dyn_A_const_393; var arg_3213 any = A_arbace_j2g_dyn_A_const_394; if linked_3210 == nil { tmp98 = ifn_3211.Invoke_O_O__O(arg_3212, arg_3213) } else { tmp98 = linked_3210.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3209, arg_3212, arg_3213) }; var tmp99 any = tmp98; var tmp100 any; var root_3214 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3214, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3216 lang.IFn; if

































































































































































	linked_3215 == nil { ifn_3216 = lang.IFn_Cast(root_3214) } else { ifn_3216 = nil }; var arg_3217 any = A_arbace_j2g_dyn_A_const_395; var arg_3218 any = A_arbace_j2g_dyn_A_const_396; if linked_3215 == nil { tmp100 = ifn_3216.Invoke_O_O__O(arg_3217, arg_3218) } else { tmp100 = linked_3215.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3214, arg_3217, arg_3218) }; var tmp101 any = tmp100; var tmp102 any; var root_3219 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3219, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3221 lang.IFn; if

































































































































































	linked_3220 == nil { ifn_3221 = lang.IFn_Cast(root_3219) } else { ifn_3221 = nil }; var arg_3222 any = A_arbace_j2g_dyn_A_const_397; var arg_3223 any = A_arbace_j2g_dyn_A_const_398; if linked_3220 == nil { tmp102 = ifn_3221.Invoke_O_O__O(arg_3222, arg_3223) } else { tmp102 = linked_3220.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3219, arg_3222, arg_3223) }; var tmp103 any = /*line :398:1*/tmp90.Invoke_O_O_O_O__O(tmp91, tmp93, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp95, tmp97, tmp99, tmp101, tmp102), A_arbace_j2g_dyn_A_const_388); var tmp104 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp105 any = A_arbace_j2g_dyn_A_const_399; var tmp106 any; var root_3229 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3229, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3231 lang.IFn; if









































































































































































	linked_3230 == nil { ifn_3231 = lang.IFn_Cast(root_3229) } else { ifn_3231 = nil }; var arg_3232 any; var root_3224 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3224, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3226 lang.IFn; if linked_3225 == nil { ifn_3226 = lang.IFn_Cast(root_3224) } else { ifn_3226 = nil }; var arg_3227 any = Lit_60; var arg_3228 any = Lit_61; if linked_3225 == nil { arg_3232 = ifn_3226.Invoke_O_O__O(arg_3227, arg_3228) } else { arg_3232 = linked_3225.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3224, arg_3227, arg_3228) }; if linked_3230 == nil { tmp106 = ifn_3231.Invoke_O__O(arg_3232) } else { tmp106 = linked_3230.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3229, arg_3232) }; var tmp107 any = tmp106; var tmp108 any; var root_3233 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3233, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3235 lang.IFn; if










































































































































































	linked_3234 == nil { ifn_3235 = lang.IFn_Cast(root_3233) } else { ifn_3235 = nil }; var arg_3236 any = A_arbace_j2g_dyn_A_const_401; var arg_3237 any = A_arbace_j2g_dyn_A_const_402; if linked_3234 == nil { tmp108 = ifn_3235.Invoke_O_O__O(arg_3236, arg_3237) } else { tmp108 = linked_3234.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3233, arg_3236, arg_3237) }; var tmp109 any = tmp108; var tmp110 any; var root_3238 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3238, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3240 lang.IFn; if










































































































































































	linked_3239 == nil { ifn_3240 = lang.IFn_Cast(root_3238) } else { ifn_3240 = nil }; var arg_3241 any = A_arbace_j2g_dyn_A_const_403; var arg_3242 any = A_arbace_j2g_dyn_A_const_404; if linked_3239 == nil { tmp110 = ifn_3240.Invoke_O_O__O(arg_3241, arg_3242) } else { tmp110 = linked_3239.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3238, arg_3241, arg_3242) }; var tmp111 any = tmp110; var tmp112 any; var root_3243 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3243, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3245 lang.IFn; if










































































































































































	linked_3244 == nil { ifn_3245 = lang.IFn_Cast(root_3243) } else { ifn_3245 = nil }; var arg_3246 any = A_arbace_j2g_dyn_A_const_405; var arg_3247 any = A_arbace_j2g_dyn_A_const_406; if linked_3244 == nil { tmp112 = ifn_3245.Invoke_O_O__O(arg_3246, arg_3247) } else { tmp112 = linked_3244.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3243, arg_3246, arg_3247) }; var tmp113 any = /*line :398:1*/tmp104.Invoke_O_O_O_O__O(tmp105, tmp107, lang.Tuple_Create_O_O_O__IPersistentVector(tmp109, tmp111, tmp112), A_arbace_j2g_dyn_A_const_400); var tmp114 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp115 any = A_arbace_j2g_dyn_A_const_407; var tmp116 any; var root_3253 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3253, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3255 lang.IFn; if
























































































































































































	linked_3254 == nil { ifn_3255 = lang.IFn_Cast(root_3253) } else { ifn_3255 = nil }; var arg_3256 any; var root_3248 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3248, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3250 lang.IFn; if linked_3249 == nil { ifn_3250 = lang.IFn_Cast(root_3248) } else { ifn_3250 = nil }; var arg_3251 any = Lit_62; var arg_3252 any = Lit_63; if linked_3249 == nil { arg_3256 = ifn_3250.Invoke_O_O__O(arg_3251, arg_3252) } else { arg_3256 = linked_3249.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3248, arg_3251, arg_3252) }; if linked_3254 == nil { tmp116 = ifn_3255.Invoke_O__O(arg_3256) } else { tmp116 = linked_3254.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3253, arg_3256) }; var tmp117 any = tmp116; var tmp118 any; var root_3267 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3267, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3269 lang.IFn; if

























































































































































































	linked_3268 == nil { ifn_3269 = lang.IFn_Cast(root_3267) } else { ifn_3269 = nil }; var arg_3270 any; var tmp119 any; var root_3257 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3257, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3259 lang.IFn; if linked_3258 == nil { ifn_3259 = lang.IFn_Cast(root_3257) } else { ifn_3259 = nil }; var arg_3260 any = A_arbace_j2g_dyn_A_const_408; var arg_3261 any = A_arbace_j2g_dyn_A_const_409; if linked_3258 == nil { tmp119 = ifn_3259.Invoke_O_O__O(arg_3260, arg_3261) } else { tmp119 = linked_3258.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3257, arg_3260, arg_3261) }; var tmp120 any = tmp119; var tmp121 any; var root_3262 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3262, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3264 lang.IFn; if linked_3263 == nil { ifn_3264 = lang.IFn_Cast(root_3262) } else { ifn_3264 = nil }; var arg_3265 any = A_arbace_j2g_dyn_A_const_410; var arg_3266 any = A_arbace_j2g_dyn_A_const_411; if linked_3263 == nil { tmp121 = ifn_3264.Invoke_O_O__O(arg_3265, arg_3266) } else { tmp121 = linked_3263.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3262, arg_3265, arg_3266) }; arg_3270 = lang.Tuple_Create_O_O__IPersistentVector(tmp120, tmp121); var arg_3271 any = A_arbace_j2g_dyn_A_const_412; if linked_3268 == nil { tmp118 = ifn_3269.Invoke_O_O__O(arg_3270, arg_3271) } else { tmp118 = linked_3268.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3267, arg_3270, arg_3271) }; var tmp122 any = /*line :398:1*/tmp114.Invoke_O_O_O_O__O(tmp115, tmp117, tmp118, A_arbace_j2g_dyn_A_const_413); var tmp123 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp124 any = A_arbace_j2g_dyn_A_const_414; var tmp125 any; var root_3277 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3277, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3279 lang.IFn; if




































































































































































































	linked_3278 == nil { ifn_3279 = lang.IFn_Cast(root_3277) } else { ifn_3279 = nil }; var arg_3280 any; var root_3272 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3272, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3274 lang.IFn; if linked_3273 == nil { ifn_3274 = lang.IFn_Cast(root_3272) } else { ifn_3274 = nil }; var arg_3275 any = Lit_64; var arg_3276 any = Lit_65; if linked_3273 == nil { arg_3280 = ifn_3274.Invoke_O_O__O(arg_3275, arg_3276) } else { arg_3280 = linked_3273.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3272, arg_3275, arg_3276) }; if linked_3278 == nil { tmp125 = ifn_3279.Invoke_O__O(arg_3280) } else { tmp125 = linked_3278.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3277, arg_3280) }; var tmp126 any = tmp125; var tmp127 any; var root_3281 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3281, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3283 lang.IFn; if





































































































































































































	linked_3282 == nil { ifn_3283 = lang.IFn_Cast(root_3281) } else { ifn_3283 = nil }; var arg_3284 any = A_arbace_j2g_dyn_A_const_416; var arg_3285 any = A_arbace_j2g_dyn_A_const_417; if linked_3282 == nil { tmp127 = ifn_3283.Invoke_O_O__O(arg_3284, arg_3285) } else { tmp127 = linked_3282.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3281, arg_3284, arg_3285) }; var tmp128 any = tmp127; var tmp129 any; var root_3286 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3286, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3288 lang.IFn; if





































































































































































































	linked_3287 == nil { ifn_3288 = lang.IFn_Cast(root_3286) } else { ifn_3288 = nil }; var arg_3289 any = A_arbace_j2g_dyn_A_const_418; var arg_3290 any = A_arbace_j2g_dyn_A_const_419; if linked_3287 == nil { tmp129 = ifn_3288.Invoke_O_O__O(arg_3289, arg_3290) } else { tmp129 = linked_3287.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3286, arg_3289, arg_3290) }; var tmp130 any = tmp129; var tmp131 any; var root_3291 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3291, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3293 lang.IFn; if





































































































































































































	linked_3292 == nil { ifn_3293 = lang.IFn_Cast(root_3291) } else { ifn_3293 = nil }; var arg_3294 any = A_arbace_j2g_dyn_A_const_420; var arg_3295 any = A_arbace_j2g_dyn_A_const_421; if linked_3292 == nil { tmp131 = ifn_3293.Invoke_O_O__O(arg_3294, arg_3295) } else { tmp131 = linked_3292.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3291, arg_3294, arg_3295) }; var tmp132 any = tmp131; var tmp133 any; var root_3296 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3296, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3298 lang.IFn; if





































































































































































































	linked_3297 == nil { ifn_3298 = lang.IFn_Cast(root_3296) } else { ifn_3298 = nil }; var arg_3299 any = A_arbace_j2g_dyn_A_const_422; var arg_3300 any = A_arbace_j2g_dyn_A_const_423; if linked_3297 == nil { tmp133 = ifn_3298.Invoke_O_O__O(arg_3299, arg_3300) } else { tmp133 = linked_3297.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3296, arg_3299, arg_3300) }; var tmp134 any = /*line :398:1*/tmp123.Invoke_O_O_O_O__O(tmp124, tmp126, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp128, tmp130, tmp132, tmp133), A_arbace_j2g_dyn_A_const_415); var tmp135 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp136 any = A_arbace_j2g_dyn_A_const_424; var tmp137 any; var root_3306 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3306, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3308 lang.IFn; if





















































































































































































































	linked_3307 == nil { ifn_3308 = lang.IFn_Cast(root_3306) } else { ifn_3308 = nil }; var arg_3309 any; var root_3301 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3301, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3303 lang.IFn; if linked_3302 == nil { ifn_3303 = lang.IFn_Cast(root_3301) } else { ifn_3303 = nil }; var arg_3304 any = Lit_66; var arg_3305 any = Lit_67; if linked_3302 == nil { arg_3309 = ifn_3303.Invoke_O_O__O(arg_3304, arg_3305) } else { arg_3309 = linked_3302.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3301, arg_3304, arg_3305) }; if linked_3307 == nil { tmp137 = ifn_3308.Invoke_O__O(arg_3309) } else { tmp137 = linked_3307.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3306, arg_3309) }; var tmp138 any = tmp137; var tmp139 any; var root_3320 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3320, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3322 lang.IFn; if






















































































































































































































	linked_3321 == nil { ifn_3322 = lang.IFn_Cast(root_3320) } else { ifn_3322 = nil }; var arg_3323 any; var tmp140 any; var root_3310 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3310, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3312 lang.IFn; if linked_3311 == nil { ifn_3312 = lang.IFn_Cast(root_3310) } else { ifn_3312 = nil }; var arg_3313 any = A_arbace_j2g_dyn_A_const_425; var arg_3314 any = A_arbace_j2g_dyn_A_const_426; if linked_3311 == nil { tmp140 = ifn_3312.Invoke_O_O__O(arg_3313, arg_3314) } else { tmp140 = linked_3311.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3310, arg_3313, arg_3314) }; var tmp141 any = tmp140; var tmp142 any; var root_3315 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3315, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3317 lang.IFn; if linked_3316 == nil { ifn_3317 = lang.IFn_Cast(root_3315) } else { ifn_3317 = nil }; var arg_3318 any = A_arbace_j2g_dyn_A_const_427; var arg_3319 any = A_arbace_j2g_dyn_A_const_428; if linked_3316 == nil { tmp142 = ifn_3317.Invoke_O_O__O(arg_3318, arg_3319) } else { tmp142 = linked_3316.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3315, arg_3318, arg_3319) }; arg_3323 = lang.Tuple_Create_O_O__IPersistentVector(tmp141, tmp142); var arg_3324 any = A_arbace_j2g_dyn_A_const_429; if linked_3321 == nil { tmp139 = ifn_3322.Invoke_O_O__O(arg_3323, arg_3324) } else { tmp139 = linked_3321.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3320, arg_3323, arg_3324) }; var tmp143 any = /*line :398:1*/tmp135.Invoke_O_O_O_O__O(tmp136, tmp138, tmp139, A_arbace_j2g_dyn_A_const_430); var tmp144 any; var root_3124 any = A_arbace_j2g_dyn_A_const_341.GetRawRoot__O(); var linked_3125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3124, A_arbace_j2g_dyn_fn_field_native_A_fn_class); var ifn_3126 lang.IFn; if



























































































































































































































	linked_3125 == nil { ifn_3126 = lang.IFn_Cast(root_3124) } else { ifn_3126 = nil }; if linked_3125 == nil { tmp144 = ifn_3126.Invoke__O() } else { tmp144 = linked_3125.(*A_arbace_j2g_dyn_fn_field_native_A).Invoke_O__O(root_3124) }; var tmp145 any = tmp144; var tmp146 any = A_arbace_j2g_dyn_A_const_342; var tmp147 any = A_arbace_j2g_dyn_A_const_343; var tmp148 lang.IFn = /*line :398:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp149 any = A_arbace_j2g_dyn_A_const_431; var tmp150 any; var root_3330 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3330, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3332 lang.IFn; if








































































































































































































































	linked_3331 == nil { ifn_3332 = lang.IFn_Cast(root_3330) } else { ifn_3332 = nil }; var arg_3333 any; var root_3325 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3325, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3327 lang.IFn; if linked_3326 == nil { ifn_3327 = lang.IFn_Cast(root_3325) } else { ifn_3327 = nil }; var arg_3328 any = Lit_68; var arg_3329 any = Lit_69; if linked_3326 == nil { arg_3333 = ifn_3327.Invoke_O_O__O(arg_3328, arg_3329) } else { arg_3333 = linked_3326.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3325, arg_3328, arg_3329) }; if linked_3331 == nil { tmp150 = ifn_3332.Invoke_O__O(arg_3333) } else { tmp150 = linked_3331.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3330, arg_3333) }; var tmp151 any = tmp150; var tmp152 any; var root_3334 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3334, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3336 lang.IFn; if









































































































































































































































	linked_3335 == nil { ifn_3336 = lang.IFn_Cast(root_3334) } else { ifn_3336 = nil }; var arg_3337 any = A_arbace_j2g_dyn_A_const_433; var arg_3338 any = A_arbace_j2g_dyn_A_const_434; if linked_3335 == nil { tmp152 = ifn_3336.Invoke_O_O__O(arg_3337, arg_3338) } else { tmp152 = linked_3335.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3334, arg_3337, arg_3338) }; var tmp153 any = tmp152; var tmp154 any; var root_3339 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3339, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3341 lang.IFn; if









































































































































































































































	linked_3340 == nil { ifn_3341 = lang.IFn_Cast(root_3339) } else { ifn_3341 = nil }; var arg_3342 any = A_arbace_j2g_dyn_A_const_435; var arg_3343 any = A_arbace_j2g_dyn_A_const_436; if linked_3340 == nil { tmp154 = ifn_3341.Invoke_O_O__O(arg_3342, arg_3343) } else { tmp154 = linked_3340.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3339, arg_3342, arg_3343) }; var tmp155 any = /*line :398:1*/tmp148.Invoke_O_O_O_O__O(tmp149, tmp151, lang.Tuple_Create_O_O__IPersistentVector(tmp153, tmp154), A_arbace_j2g_dyn_A_const_432); var tmp156 any = A_arbace_j2g_dyn_A_const_344; var tmp157 any = A_arbace_j2g_dyn_A_const_345.GetRawRoot__O(); var tmp158 any = A_arbace_j2g_dyn_A_const_346; var tmp159 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp160 any = A_arbace_j2g_dyn_A_const_437; var tmp161 any; var root_3349 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3349, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3351 lang.IFn; if































































































































































































































































	linked_3350 == nil { ifn_3351 = lang.IFn_Cast(root_3349) } else { ifn_3351 = nil }; var arg_3352 any; var root_3344 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3344, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3346 lang.IFn; if linked_3345 == nil { ifn_3346 = lang.IFn_Cast(root_3344) } else { ifn_3346 = nil }; var arg_3347 any = Lit_70; var arg_3348 any = Lit_71; if linked_3345 == nil { arg_3352 = ifn_3346.Invoke_O_O__O(arg_3347, arg_3348) } else { arg_3352 = linked_3345.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3344, arg_3347, arg_3348) }; if linked_3350 == nil { tmp161 = ifn_3351.Invoke_O__O(arg_3352) } else { tmp161 = linked_3350.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3349, arg_3352) }; var tmp162 any = tmp161; var tmp163 any; var root_3363 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3363, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3365 lang.IFn; if
































































































































































































































































	linked_3364 == nil { ifn_3365 = lang.IFn_Cast(root_3363) } else { ifn_3365 = nil }; var arg_3366 any; var tmp164 any; var root_3353 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3353, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3355 lang.IFn; if linked_3354 == nil { ifn_3355 = lang.IFn_Cast(root_3353) } else { ifn_3355 = nil }; var arg_3356 any = A_arbace_j2g_dyn_A_const_438; var arg_3357 any = A_arbace_j2g_dyn_A_const_439; if linked_3354 == nil { tmp164 = ifn_3355.Invoke_O_O__O(arg_3356, arg_3357) } else { tmp164 = linked_3354.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3353, arg_3356, arg_3357) }; var tmp165 any = tmp164; var tmp166 any; var root_3358 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3358, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3360 lang.IFn; if linked_3359 == nil { ifn_3360 = lang.IFn_Cast(root_3358) } else { ifn_3360 = nil }; var arg_3361 any = A_arbace_j2g_dyn_A_const_440; var arg_3362 any = A_arbace_j2g_dyn_A_const_441; if linked_3359 == nil { tmp166 = ifn_3360.Invoke_O_O__O(arg_3361, arg_3362) } else { tmp166 = linked_3359.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3358, arg_3361, arg_3362) }; arg_3366 = lang.Tuple_Create_O_O__IPersistentVector(tmp165, tmp166); var arg_3367 any = A_arbace_j2g_dyn_A_const_442; if linked_3364 == nil { tmp163 = ifn_3365.Invoke_O_O__O(arg_3366, arg_3367) } else { tmp163 = linked_3364.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3363, arg_3366, arg_3367) }; var tmp167 any = /*line :398:1*/tmp159.Invoke_O_O_O_O__O(tmp160, tmp162, tmp163, A_arbace_j2g_dyn_A_const_443); var tmp168 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp169 any = A_arbace_j2g_dyn_A_const_444; var tmp170 any; var root_3373 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3373, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3375 lang.IFn; if





































































































































































































































































	linked_3374 == nil { ifn_3375 = lang.IFn_Cast(root_3373) } else { ifn_3375 = nil }; var arg_3376 any; var root_3368 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3368, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3370 lang.IFn; if linked_3369 == nil { ifn_3370 = lang.IFn_Cast(root_3368) } else { ifn_3370 = nil }; var arg_3371 any = Lit_72; var arg_3372 any = Lit_73; if linked_3369 == nil { arg_3376 = ifn_3370.Invoke_O_O__O(arg_3371, arg_3372) } else { arg_3376 = linked_3369.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3368, arg_3371, arg_3372) }; if linked_3374 == nil { tmp170 = ifn_3375.Invoke_O__O(arg_3376) } else { tmp170 = linked_3374.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3373, arg_3376) }; var tmp171 any = tmp170; var tmp172 any; var root_3387 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3387, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3389 lang.IFn; if






































































































































































































































































	linked_3388 == nil { ifn_3389 = lang.IFn_Cast(root_3387) } else { ifn_3389 = nil }; var arg_3390 any; var tmp173 any; var root_3377 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3377, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3379 lang.IFn; if linked_3378 == nil { ifn_3379 = lang.IFn_Cast(root_3377) } else { ifn_3379 = nil }; var arg_3380 any = A_arbace_j2g_dyn_A_const_445; var arg_3381 any = A_arbace_j2g_dyn_A_const_446; if linked_3378 == nil { tmp173 = ifn_3379.Invoke_O_O__O(arg_3380, arg_3381) } else { tmp173 = linked_3378.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3377, arg_3380, arg_3381) }; var tmp174 any = tmp173; var tmp175 any; var root_3382 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3382, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3384 lang.IFn; if linked_3383 == nil { ifn_3384 = lang.IFn_Cast(root_3382) } else { ifn_3384 = nil }; var arg_3385 any = A_arbace_j2g_dyn_A_const_447; var arg_3386 any = A_arbace_j2g_dyn_A_const_448; if linked_3383 == nil { tmp175 = ifn_3384.Invoke_O_O__O(arg_3385, arg_3386) } else { tmp175 = linked_3383.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3382, arg_3385, arg_3386) }; arg_3390 = lang.Tuple_Create_O_O__IPersistentVector(tmp174, tmp175); var arg_3391 any = A_arbace_j2g_dyn_A_const_449; if linked_3388 == nil { tmp172 = ifn_3389.Invoke_O_O__O(arg_3390, arg_3391) } else { tmp172 = linked_3388.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3387, arg_3390, arg_3391) }; var tmp176 any = /*line :398:1*/tmp168.Invoke_O_O_O_O__O(tmp169, tmp171, tmp172, A_arbace_j2g_dyn_A_const_450); var tmp177 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp178 any = A_arbace_j2g_dyn_A_const_451; var tmp179 any; var root_3397 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3397, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3399 lang.IFn; if








































































































































































































































































	linked_3398 == nil { ifn_3399 = lang.IFn_Cast(root_3397) } else { ifn_3399 = nil }; var arg_3400 any; var root_3392 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3392, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3394 lang.IFn; if linked_3393 == nil { ifn_3394 = lang.IFn_Cast(root_3392) } else { ifn_3394 = nil }; var arg_3395 any = Lit_74; var arg_3396 any = Lit_75; if linked_3393 == nil { arg_3400 = ifn_3394.Invoke_O_O__O(arg_3395, arg_3396) } else { arg_3400 = linked_3393.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3392, arg_3395, arg_3396) }; if linked_3398 == nil { tmp179 = ifn_3399.Invoke_O__O(arg_3400) } else { tmp179 = linked_3398.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3397, arg_3400) }; var tmp180 any = tmp179; var tmp181 any; var root_3401 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3401, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3403 lang.IFn; if









































































































































































































































































	linked_3402 == nil { ifn_3403 = lang.IFn_Cast(root_3401) } else { ifn_3403 = nil }; var arg_3404 any = A_arbace_j2g_dyn_A_const_453; var arg_3405 any = A_arbace_j2g_dyn_A_const_454; if linked_3402 == nil { tmp181 = ifn_3403.Invoke_O_O__O(arg_3404, arg_3405) } else { tmp181 = linked_3402.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3401, arg_3404, arg_3405) }; var tmp182 any = tmp181; var tmp183 any; var root_3406 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3406, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3408 lang.IFn; if









































































































































































































































































	linked_3407 == nil { ifn_3408 = lang.IFn_Cast(root_3406) } else { ifn_3408 = nil }; var arg_3409 any = A_arbace_j2g_dyn_A_const_455; var arg_3410 any = A_arbace_j2g_dyn_A_const_456; if linked_3407 == nil { tmp183 = ifn_3408.Invoke_O_O__O(arg_3409, arg_3410) } else { tmp183 = linked_3407.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3406, arg_3409, arg_3410) }; var tmp184 any = tmp183; var tmp185 any; var root_3411 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3411, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3413 lang.IFn; if









































































































































































































































































	linked_3412 == nil { ifn_3413 = lang.IFn_Cast(root_3411) } else { ifn_3413 = nil }; var arg_3414 any = A_arbace_j2g_dyn_A_const_457; var arg_3415 any = A_arbace_j2g_dyn_A_const_458; if linked_3412 == nil { tmp185 = ifn_3413.Invoke_O_O__O(arg_3414, arg_3415) } else { tmp185 = linked_3412.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3411, arg_3414, arg_3415) }; var tmp186 any = /*line :398:1*/tmp177.Invoke_O_O_O_O__O(tmp178, tmp180, lang.Tuple_Create_O_O_O__IPersistentVector(tmp182, tmp184, tmp185), A_arbace_j2g_dyn_A_const_452); var tmp187 any = A_arbace_j2g_dyn_A_const_347; var tmp188 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp189 any = A_arbace_j2g_dyn_A_const_459; var tmp190 any; var root_3421 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3421, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3423 lang.IFn; if


















































































































































































































































































	linked_3422 == nil { ifn_3423 = lang.IFn_Cast(root_3421) } else { ifn_3423 = nil }; var arg_3424 any; var root_3416 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3416, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3418 lang.IFn; if linked_3417 == nil { ifn_3418 = lang.IFn_Cast(root_3416) } else { ifn_3418 = nil }; var arg_3419 any = Lit_76; var arg_3420 any = Lit_77; if linked_3417 == nil { arg_3424 = ifn_3418.Invoke_O_O__O(arg_3419, arg_3420) } else { arg_3424 = linked_3417.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3416, arg_3419, arg_3420) }; if linked_3422 == nil { tmp190 = ifn_3423.Invoke_O__O(arg_3424) } else { tmp190 = linked_3422.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3421, arg_3424) }; var tmp191 any = tmp190; var tmp192 any; var root_3425 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3425, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3427 lang.IFn; if





















































































































































































































































































	linked_3426 == nil { ifn_3427 = lang.IFn_Cast(root_3425) } else { ifn_3427 = nil }; var arg_3428 any = A_arbace_j2g_dyn_A_const_461; var arg_3429 any = A_arbace_j2g_dyn_A_const_462; if linked_3426 == nil { tmp192 = ifn_3427.Invoke_O_O__O(arg_3428, arg_3429) } else { tmp192 = linked_3426.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3425, arg_3428, arg_3429) }; var tmp193 any = tmp192; var tmp194 any; var root_3430 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3430, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3432 lang.IFn; if





















































































































































































































































































	linked_3431 == nil { ifn_3432 = lang.IFn_Cast(root_3430) } else { ifn_3432 = nil }; var arg_3433 any = A_arbace_j2g_dyn_A_const_463; var arg_3434 any = A_arbace_j2g_dyn_A_const_464; if linked_3431 == nil { tmp194 = ifn_3432.Invoke_O_O__O(arg_3433, arg_3434) } else { tmp194 = linked_3431.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3430, arg_3433, arg_3434) }; var tmp195 any = /*line :398:1*/tmp188.Invoke_O_O_O_O_O__O(tmp189, tmp191, Lit_78, lang.Tuple_Create_O_O__IPersistentVector(tmp193, tmp194), A_arbace_j2g_dyn_A_const_460); var tmp196 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp197 any = A_arbace_j2g_dyn_A_const_465; var tmp198 any; var root_3440 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3440, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3442 lang.IFn; if



























































































































































































































































































	linked_3441 == nil { ifn_3442 = lang.IFn_Cast(root_3440) } else { ifn_3442 = nil }; var arg_3443 any; var root_3435 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3435, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3437 lang.IFn; if linked_3436 == nil { ifn_3437 = lang.IFn_Cast(root_3435) } else { ifn_3437 = nil }; var arg_3438 any = Lit_79; var arg_3439 any = Lit_80; if linked_3436 == nil { arg_3443 = ifn_3437.Invoke_O_O__O(arg_3438, arg_3439) } else { arg_3443 = linked_3436.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3435, arg_3438, arg_3439) }; if linked_3441 == nil { tmp198 = ifn_3442.Invoke_O__O(arg_3443) } else { tmp198 = linked_3441.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3440, arg_3443) }; var tmp199 any = tmp198; var tmp200 any; var root_3444 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3444, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3446 lang.IFn; if




























































































































































































































































































	linked_3445 == nil { ifn_3446 = lang.IFn_Cast(root_3444) } else { ifn_3446 = nil }; var arg_3447 any = lang.PersistentVector_EMPTY.Ref(); var arg_3448 any = A_arbace_j2g_dyn_A_const_466; if linked_3445 == nil { tmp200 = ifn_3446.Invoke_O_O__O(arg_3447, arg_3448) } else { tmp200 = linked_3445.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3444, arg_3447, arg_3448) }; var tmp201 any = /*line :398:1*/tmp196.Invoke_O_O_O_O__O(tmp197, tmp199, tmp200, A_arbace_j2g_dyn_A_const_467); var tmp202 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp203 any = A_arbace_j2g_dyn_A_const_468; var tmp204 any = A_arbace_j2g_dyn_A_const_469; var tmp205 any; var root_3579 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3579, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3581 lang.IFn; if
































































































































































































































































































	linked_3580 == nil { ifn_3581 = lang.IFn_Cast(root_3579) } else { ifn_3581 = nil }; var arg_3582 any = A_arbace_j2g_dyn_A_const_478; var arg_3583 any = A_arbace_j2g_dyn_A_const_479; if linked_3580 == nil { tmp205 = ifn_3581.Invoke_O_O__O(arg_3582, arg_3583) } else { tmp205 = linked_3580.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3579, arg_3582, arg_3583) }; var tmp206 any = /*line :398:1*/lang.Tuple_Create_O__IPersistentVector(tmp205); var tmp207 any = A_arbace_j2g_dyn_A_const_470; var tmp208 any = A_arbace_j2g_dyn_A_const_471; var tmp209 any; var root_3572 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_3573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3572, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3574 lang.IFn; if

































































































































































































































































































	linked_3573 == nil { ifn_3574 = lang.IFn_Cast(root_3572) } else { ifn_3574 = nil }; var arg_3575 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_3576 any = A_arbace_j2g_dyn_A_const_472; var arg_3577 any = A_arbace_j2g_dyn_A_const_473; var arg_3578 any; var iter__1927001039__auto____5_3 any; var tmp210 any = A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_New(); var tmp211 *jrt.Class; var fncls__3567 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_fn_class; if
	fncls__3567 == nil { var fncls__3567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_fn_class = fncls__3567d; tmp211 = fncls__3567d } else { tmp211 = fncls__3567 }; iter__1927001039__auto____5_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp210, tmp211, nil); var tmp212 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5_3); var tmp213 any; var root_3568 any = A_arbace_j2g_dyn_A_const_476.GetRawRoot__O(); var linked_3569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3568, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3570 lang.IFn; if linked_3569 == nil { ifn_3570 = lang.IFn_Cast(root_3568) } else { ifn_3570 = nil }; var arg_3571 any = T__0_; if linked_3569 == nil { tmp213 = ifn_3570.Invoke_O__O(arg_3571) } else { tmp213 = linked_3569.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3568, arg_3571) }; arg_3578 = tmp212.Invoke_O__O(tmp213); if /*line :688:1*/ linked_3573 == nil { tmp209 = ifn_3574.Invoke_O_O_O_O__O(arg_3575, arg_3576, arg_3577, arg_3578) } else { tmp209 = linked_3573.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3572, arg_3575, arg_3576, arg_3577, arg_3578) }; var tmp214 any = /*line :398:1*/tmp202.Invoke_O_O_O_O_O_O_O_O__O(tmp203, tmp204, Lit_81, tmp206, tmp207, tmp208, tmp209, A_arbace_j2g_dyn_A_const_477); var tmp215 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp216 any = A_arbace_j2g_dyn_A_const_480; var tmp217 any; var root_3589 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3589, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3591 lang.IFn; if







































































































































































































































































































	linked_3590 == nil { ifn_3591 = lang.IFn_Cast(root_3589) } else { ifn_3591 = nil }; var arg_3592 any; var root_3584 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3584, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3586 lang.IFn; if linked_3585 == nil { ifn_3586 = lang.IFn_Cast(root_3584) } else { ifn_3586 = nil }; var arg_3587 any = Lit_83; var arg_3588 any = Lit_84; if linked_3585 == nil { arg_3592 = ifn_3586.Invoke_O_O__O(arg_3587, arg_3588) } else { arg_3592 = linked_3585.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3584, arg_3587, arg_3588) }; if linked_3590 == nil { tmp217 = ifn_3591.Invoke_O__O(arg_3592) } else { tmp217 = linked_3590.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3589, arg_3592) }; var tmp218 any = tmp217; var tmp219 any; var root_3608 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3608, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3610 lang.IFn; if








































































































































































































































































































	linked_3609 == nil { ifn_3610 = lang.IFn_Cast(root_3608) } else { ifn_3610 = nil }; var arg_3611 any; var tmp220 any; var root_3593 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3593, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3595 lang.IFn; if linked_3594 == nil { ifn_3595 = lang.IFn_Cast(root_3593) } else { ifn_3595 = nil }; var arg_3596 any = A_arbace_j2g_dyn_A_const_481; var arg_3597 any = A_arbace_j2g_dyn_A_const_482; if linked_3594 == nil { tmp220 = ifn_3595.Invoke_O_O__O(arg_3596, arg_3597) } else { tmp220 = linked_3594.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3593, arg_3596, arg_3597) }; var tmp221 any = tmp220; var tmp222 any; var root_3598 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3598, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3600 lang.IFn; if linked_3599 == nil { ifn_3600 = lang.IFn_Cast(root_3598) } else { ifn_3600 = nil }; var arg_3601 any = A_arbace_j2g_dyn_A_const_483; var arg_3602 any = A_arbace_j2g_dyn_A_const_484; if linked_3599 == nil { tmp222 = ifn_3600.Invoke_O_O__O(arg_3601, arg_3602) } else { tmp222 = linked_3599.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3598, arg_3601, arg_3602) }; var tmp223 any = tmp222; var tmp224 any; var root_3603 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3603, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3605 lang.IFn; if linked_3604 == nil { ifn_3605 = lang.IFn_Cast(root_3603) } else { ifn_3605 = nil }; var arg_3606 any = A_arbace_j2g_dyn_A_const_485; var arg_3607 any = A_arbace_j2g_dyn_A_const_486; if linked_3604 == nil { tmp224 = ifn_3605.Invoke_O_O__O(arg_3606, arg_3607) } else { tmp224 = linked_3604.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3603, arg_3606, arg_3607) }; arg_3611 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp221, tmp223, tmp224); var arg_3612 any = A_arbace_j2g_dyn_A_const_487; if linked_3609 == nil { tmp219 = ifn_3610.Invoke_O_O__O(arg_3611, arg_3612) } else { tmp219 = linked_3609.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3608, arg_3611, arg_3612) }; var tmp225 any = tmp219; var tmp226 lang.IFn = /*line :398:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp227 any = A_arbace_j2g_dyn_A_const_489; var tmp228 any = A_arbace_j2g_dyn_A_const_490; var tmp229 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp230 any = A_arbace_j2g_dyn_A_const_491; var tmp231 any = A_arbace_j2g_dyn_A_const_496; var tmp232 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp233 any; var root_3618 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3618, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3620 lang.IFn; if











































































































































































































































































































	linked_3619 == nil { ifn_3620 = lang.IFn_Cast(root_3618) } else { ifn_3620 = nil }; var arg_3621 any; var root_3613 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3613, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3615 lang.IFn; if linked_3614 == nil { ifn_3615 = lang.IFn_Cast(root_3613) } else { ifn_3615 = nil }; var arg_3616 any = Lit_55; var arg_3617 any = Lit_56; if linked_3614 == nil { arg_3621 = ifn_3615.Invoke_O_O__O(arg_3616, arg_3617) } else { arg_3621 = linked_3614.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3613, arg_3616, arg_3617) }; if linked_3619 == nil { tmp233 = ifn_3620.Invoke_O__O(arg_3621) } else { tmp233 = linked_3619.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3618, arg_3621) }; var tmp234 any = /*line :398:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp73, tmp74, tmp75, tmp89, tmp103, tmp113, tmp122, tmp134, tmp143, tmp145, tmp146, tmp147, tmp155, tmp156, tmp157, tmp158, tmp167, tmp176, tmp186, tmp187, tmp195, tmp201, tmp214, tmp215.Invoke_O_O_O_O_O__O(tmp216, tmp218, tmp225, tmp226.Invoke_O_O_O__O(tmp227, tmp228, tmp229.Invoke_O_O_O_O_O_O__O(tmp230, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp231, tmp232.Invoke_O_O_O_O__O(tmp233, A_arbace_j2g_dyn_A_const_501, A_arbace_j2g_dyn_A_const_502, A_arbace_j2g_dyn_A_const_503), A_arbace_j2g_dyn_A_const_497, A_arbace_j2g_dyn_A_const_498, A_arbace_j2g_dyn_A_const_499, A_arbace_j2g_dyn_A_const_500), A_arbace_j2g_dyn_A_const_492, A_arbace_j2g_dyn_A_const_493, A_arbace_j2g_dyn_A_const_494, A_arbace_j2g_dyn_A_const_495)), A_arbace_j2g_dyn_A_const_488))); var tmp235 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_504.GetRawRoot__O()); var tmp236 any = A_arbace_j2g_dyn_forms_fn__711000426_A_New_O_O(ks__3, ifaces__2); var tmp237 *jrt.Class; var fncls__3628 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000426_A_fn_class; if












































































































































































































































































































































	fncls__3628 == nil { var fncls__3628d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_j2g_dyn_forms_fn__711000426_A_fn_class = fncls__3628d; tmp237 = fncls__3628d } else { tmp237 = fncls__3628 }; var tmp238 any = /*line :398:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp236, tmp237, nil); var tmp239 any; var root_3629 any = A_arbace_j2g_dyn_A_const_476.GetRawRoot__O(); var linked_3630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3629, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3631 lang.IFn; if












































































































































































































































































































































	linked_3630 == nil { ifn_3631 = lang.IFn_Cast(root_3629) } else { ifn_3631 = nil }; var arg_3632 any = T__0_; if linked_3630 == nil { tmp239 = ifn_3631.Invoke_O__O(arg_3632) } else { tmp239 = linked_3630.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3629, arg_3632) }; return /*line :398:1*/ tmp1.Invoke_O_O_O_O_O__O(tmp35, tmp39, tmp48, tmp234, tmp235.Invoke_O_O__O(tmp238, tmp239)) }






























func A_arbace_j2g_dyn_forms_fn__711000383_A_New() *A_arbace_j2g_dyn_forms_fn__711000383_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000383_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_j2g_dyn_forms_fn__711000383_A) Ctor() {}
//line :429:1
func (t *A_arbace_j2g_dyn_forms_fn__711000383_A) Invoke_O_O_O__O(self, i__1, p__711000382__2 any) any { var vec__711000384__3 any = p__711000382__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000384__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000384__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }















func A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_New() *A_arbace_j2g_dyn_forms_iter__711000388__711000392_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000388__711000392_A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_A) Ctor() {}
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_A) Invoke_O_O__O(self, s__711000389__1 any) any { var tmp1 any = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_New_O_O(self, s__711000389__1); var tmp2 *jrt.Class; var fncls__3000 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_fn_class; if fncls__3000 == nil { var fncls__3000d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_fn_class = fncls__3000d; tmp2 = fncls__3000d } else { tmp2 = fncls__3000 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :445:1
func A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A{}; t.Ctor_O_O(p0, p1); return t }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A) Ctor_O_O(c__iter__711000388, c__s__711000389 any) { t.F_iter__711000388 = c__iter__711000388; t.F_s__711000389 = c__s__711000389 }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A) Invoke_O__O(self any) any { { var s__711000389__1 any; var t_ any = t.F_s__711000389; t.F_s__711000389 = nil; s__711000389__1 = t_; for { var temp__1927000414__auto____2 any; var root_2921 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2921, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2923 lang.IFn; if linked_2922 == nil { ifn_2923 = lang.IFn_Cast(root_2921) } else { ifn_2923 = nil }; var arg_2924 any = s__711000389__1; if linked_2922 == nil { temp__1927000414__auto____2 = ifn_2923.Invoke_O__O(arg_2924) } else { temp__1927000414__auto____2 = linked_2922.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2921, arg_2924) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000389__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2925 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2925, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2927 lang.IFn; if linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any = s__711000389__3; if linked_2926 == nil { tmp1 = ifn_2927.Invoke_O__O(arg_2928) } else { tmp1 = linked_2926.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2925, arg_2928) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2929 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2929, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2931 lang.IFn; if linked_2930 == nil { ifn_2931 = lang.IFn_Cast(root_2929) } else { ifn_2931 = nil }; var arg_2932 any = s__711000389__3; if linked_2930 == nil { c__1927001037__auto____4 = ifn_2931.Invoke_O__O(arg_2932) } else { c__1927001037__auto____4 = linked_2930.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2929, arg_2932) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000391__6 any; var root_2933 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2933, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2935 lang.IFn; if linked_2934 == nil { ifn_2935 = lang.IFn_Cast(root_2933) } else { ifn_2935 = nil }; var arg_2936 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2934 == nil { b__711000391__6 = ifn_2935.Invoke_O__O(arg_2936) } else { b__711000391__6 = linked_2934.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2933, arg_2936) }; var tmp2 any = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_New_O_I_O(b__711000391__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2953 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_fn_class; if fncls__2953 == nil { var fncls__2953d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_fn_class = fncls__2953d; tmp3 = fncls__2953d } else { tmp3 = fncls__2953 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2962 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2962, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2964 lang.IFn; if linked_2963 == nil { ifn_2964 = lang.IFn_Cast(root_2962) } else { ifn_2964 = nil }; var arg_2965 any; var root_2954 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2954, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2956 lang.IFn; if linked_2955 == nil { ifn_2956 = lang.IFn_Cast(root_2954) } else { ifn_2956 = nil }; var arg_2957 any = b__711000391__6; if linked_2955 == nil { arg_2965 = ifn_2956.Invoke_O__O(arg_2957) } else { arg_2965 = linked_2955.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2954, arg_2957) }; var arg_2966 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000388); var tmp5 any; var root_2958 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2958, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2960 lang.IFn; if linked_2959 == nil { ifn_2960 = lang.IFn_Cast(root_2958) } else { ifn_2960 = nil }; var arg_2961 any = s__711000389__3; if linked_2959 == nil { tmp5 = ifn_2960.Invoke_O__O(arg_2961) } else { tmp5 = linked_2959.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2958, arg_2961) }; arg_2966 = tmp4.Invoke_O__O(tmp5); if linked_2963 == nil { return ifn_2964.Invoke_O_O__O(arg_2965, arg_2966) } else { return linked_2963.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2962, arg_2965, arg_2966) } } else { var root_2971 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2971, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2973 lang.IFn; if linked_2972 == nil { ifn_2973 = lang.IFn_Cast(root_2971) } else { ifn_2973 = nil }; var arg_2974 any; var root_2967 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2967, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2969 lang.IFn; if linked_2968 == nil { ifn_2969 = lang.IFn_Cast(root_2967) } else { ifn_2969 = nil }; var arg_2970 any = b__711000391__6; if linked_2968 == nil { arg_2974 = ifn_2969.Invoke_O__O(arg_2970) } else { arg_2974 = linked_2968.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2967, arg_2970) }; var arg_2975 any; if linked_2972 == nil { return ifn_2973.Invoke_O_O__O(arg_2974, arg_2975) } else { return linked_2972.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2971, arg_2974, arg_2975) } } } else { var vec__711000399__4 any; var root_2976 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2976, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2978 lang.IFn; if linked_2977 == nil { ifn_2978 = lang.IFn_Cast(root_2976) } else { ifn_2978 = nil }; var arg_2979 any = s__711000389__3; if linked_2977 == nil { vec__711000399__4 = ifn_2978.Invoke_O__O(arg_2979) } else { vec__711000399__4 = linked_2977.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2976, arg_2979) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000399__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000399__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2995 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2995, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2997 lang.IFn; if linked_2996 == nil { ifn_2997 = lang.IFn_Cast(root_2995) } else { ifn_2997 = nil }; var arg_2998 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_329; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(d__5); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_330; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any; var root_2985 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_2986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2985, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2987 lang.IFn
													if linked_2986 == nil { ifn_2987 = lang.IFn_Cast(root_2985) } else { ifn_2987 = nil }; var arg_2988 any = A_arbace_j2g_dyn_A_const_73; var arg_2989 any = Lit_16; var arg_2990 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp14 any; var root_2980 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2980, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2982 lang.IFn; if linked_2981 == nil { ifn_2982 = lang.IFn_Cast(root_2980) } else { ifn_2982 = nil }; var arg_2983 any = nme__6; var arg_2984 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__5)).Ref(); if linked_2981 == nil { tmp14 = ifn_2982.Invoke_O_O__O(arg_2983, arg_2984) } else { tmp14 = linked_2981.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2980, arg_2983, arg_2984) }; arg_2990 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_2986 == nil { tmp12 = ifn_2987.Invoke_O_O_O__O(arg_2988, arg_2989, arg_2990) } else { tmp12 = linked_2986.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_2985, arg_2988, arg_2989, arg_2990) }; arg_2998 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(tmp12, A_arbace_j2g_dyn_A_const_331)))
//line :445:1
	var arg_2999 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__711000388); var tmp16 any; var root_2991 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2991, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2993 lang.IFn; if linked_2992 == nil { ifn_2993 = lang.IFn_Cast(root_2991) } else { ifn_2993 = nil }; var arg_2994 any = s__711000389__3; if linked_2992 == nil { tmp16 = ifn_2993.Invoke_O__O(arg_2994) } else { tmp16 = linked_2992.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2991, arg_2994) }; arg_2999 = tmp15.Invoke_O__O(tmp16); if linked_2996 == nil { return ifn_2997.Invoke_O_O__O(arg_2998, arg_2999) } else { return linked_2996.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2995, arg_2998, arg_2999) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :445:1
func A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A) Ctor_O_I_O(c__b__711000391 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000391 = c__b__711000391; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A) Invoke_O__O(self any) any { { var i__711000390__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000390__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000395__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000390__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000395__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000395__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2948 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2948, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2950 lang.IFn; if linked_2949 == nil { ifn_2950 = lang.IFn_Cast(root_2948) } else { ifn_2950 = nil }; var arg_2951 any = t.F_b__711000391; var arg_2952 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_329; var tmp4 any = lang.Tuple_Create_O__IPersistentVector(d__3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_330; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any; var root_2942 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_2943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2942, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2944 lang.IFn
															if linked_2943 == nil { ifn_2944 = lang.IFn_Cast(root_2942) } else { ifn_2944 = nil }; var arg_2945 any = A_arbace_j2g_dyn_A_const_73; var arg_2946 any = Lit_16; var arg_2947 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp10 any; var root_2937 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2937, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2939 lang.IFn; if linked_2938 == nil { ifn_2939 = lang.IFn_Cast(root_2937) } else { ifn_2939 = nil }; var arg_2940 any = nme__4; var arg_2941 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3)).Ref(); if linked_2938 == nil { tmp10 = ifn_2939.Invoke_O_O__O(arg_2940, arg_2941) } else { tmp10 = linked_2938.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2937, arg_2940, arg_2941) }; arg_2947 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_2943 == nil { tmp8 = ifn_2944.Invoke_O_O_O__O(arg_2945, arg_2946, arg_2947) } else { tmp8 = linked_2943.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_2942, arg_2945, arg_2946, arg_2947) }; arg_2952 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, A_arbace_j2g_dyn_A_const_331)))
//line :445:1
	if linked_2949 == nil { ifn_2950.Invoke_O_O__O(arg_2951, arg_2952) } else { linked_2949.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2948, arg_2951, arg_2952) }; i__711000390__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000390__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








































func A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_New() *A_arbace_j2g_dyn_forms_iter__711000404__711000408_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000404__711000408_A{}; t.Ctor(); return t }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_A) Ctor() {}
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_A) Invoke_O_O__O(self, s__711000405__1 any) any { var tmp1 any = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_New_O_O(self, s__711000405__1); var tmp2 *jrt.Class; var fncls__3101 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_fn_class; if fncls__3101 == nil { var fncls__3101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_fn_class = fncls__3101d; tmp2 = fncls__3101d } else { tmp2 = fncls__3101 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :486:1
func A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A{}; t.Ctor_O_O(p0, p1); return t }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A) Ctor_O_O(c__iter__711000404, c__s__711000405 any) { t.F_iter__711000404 = c__iter__711000404; t.F_s__711000405 = c__s__711000405 }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A) Invoke_O__O(self any) any { { var s__711000405__1 any; var t_ any = t.F_s__711000405; t.F_s__711000405 = nil; s__711000405__1 = t_; for { var temp__1927000414__auto____2 any; var root_3018 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3018, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3020 lang.IFn; if linked_3019 == nil { ifn_3020 = lang.IFn_Cast(root_3018) } else { ifn_3020 = nil }; var arg_3021 any = s__711000405__1; if linked_3019 == nil { temp__1927000414__auto____2 = ifn_3020.Invoke_O__O(arg_3021) } else { temp__1927000414__auto____2 = linked_3019.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3018, arg_3021) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000405__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3022 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3022, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3024 lang.IFn; if linked_3023 == nil { ifn_3024 = lang.IFn_Cast(root_3022) } else { ifn_3024 = nil }; var arg_3025 any = s__711000405__3; if linked_3023 == nil { tmp1 = ifn_3024.Invoke_O__O(arg_3025) } else { tmp1 = linked_3023.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3022, arg_3025) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3026 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3026, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3028 lang.IFn; if linked_3027 == nil { ifn_3028 = lang.IFn_Cast(root_3026) } else { ifn_3028 = nil }; var arg_3029 any = s__711000405__3; if linked_3027 == nil { c__1927001037__auto____4 = ifn_3028.Invoke_O__O(arg_3029) } else { c__1927001037__auto____4 = linked_3027.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3026, arg_3029) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000407__6 any; var root_3030 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3030, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3032 lang.IFn; if linked_3031 == nil { ifn_3032 = lang.IFn_Cast(root_3030) } else { ifn_3032 = nil }; var arg_3033 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3031 == nil { b__711000407__6 = ifn_3032.Invoke_O__O(arg_3033) } else { b__711000407__6 = linked_3031.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3030, arg_3033) }; var tmp2 any = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_New_O_I_O(b__711000407__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3052 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_fn_class; if fncls__3052 == nil { var fncls__3052d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_fn_class = fncls__3052d; tmp3 = fncls__3052d } else { tmp3 = fncls__3052 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3061 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3061, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3063 lang.IFn; if linked_3062 == nil { ifn_3063 = lang.IFn_Cast(root_3061) } else { ifn_3063 = nil }; var arg_3064 any; var root_3053 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3053, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3055 lang.IFn; if linked_3054 == nil { ifn_3055 = lang.IFn_Cast(root_3053) } else { ifn_3055 = nil }; var arg_3056 any = b__711000407__6; if linked_3054 == nil { arg_3064 = ifn_3055.Invoke_O__O(arg_3056) } else { arg_3064 = linked_3054.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3053, arg_3056) }; var arg_3065 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000404); var tmp5 any; var root_3057 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3057, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3059 lang.IFn; if linked_3058 == nil { ifn_3059 = lang.IFn_Cast(root_3057) } else { ifn_3059 = nil }; var arg_3060 any = s__711000405__3; if linked_3058 == nil { tmp5 = ifn_3059.Invoke_O__O(arg_3060) } else { tmp5 = linked_3058.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3057, arg_3060) }; arg_3065 = tmp4.Invoke_O__O(tmp5); if linked_3062 == nil { return ifn_3063.Invoke_O_O__O(arg_3064, arg_3065) } else { return linked_3062.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3061, arg_3064, arg_3065) } } else { var root_3070 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3070, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3072 lang.IFn; if linked_3071 == nil { ifn_3072 = lang.IFn_Cast(root_3070) } else { ifn_3072 = nil }; var arg_3073 any; var root_3066 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3066, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3068 lang.IFn; if linked_3067 == nil { ifn_3068 = lang.IFn_Cast(root_3066) } else { ifn_3068 = nil }; var arg_3069 any = b__711000407__6; if linked_3067 == nil { arg_3073 = ifn_3068.Invoke_O__O(arg_3069) } else { arg_3073 = linked_3067.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3066, arg_3069) }; var arg_3074 any; if linked_3071 == nil { return ifn_3072.Invoke_O_O__O(arg_3073, arg_3074) } else { return linked_3071.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3070, arg_3073, arg_3074) } } } else { var j__4 any; var root_3075 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3075, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3077 lang.IFn; if linked_3076 == nil { ifn_3077 = lang.IFn_Cast(root_3075) } else { ifn_3077 = nil }; var arg_3078 any = s__711000405__3; if linked_3076 == nil { j__4 = ifn_3077.Invoke_O__O(arg_3078) } else { j__4 = linked_3076.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3075, arg_3078) }; var root_3096 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3096, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3098 lang.IFn; if linked_3097 == nil { ifn_3098 = lang.IFn_Cast(root_3096) } else { ifn_3098 = nil }; var arg_3099 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_334; var tmp8 any; var root_3083 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3083, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3085 lang.IFn; if linked_3084 == nil { ifn_3085 = lang.IFn_Cast(root_3083) } else { ifn_3085 = nil }; var arg_3086 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp10 any; var root_3079 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_3080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3079, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3081 lang.IFn; if linked_3080 == nil { ifn_3081 = lang.IFn_Cast(root_3079) } else { ifn_3081 = nil }; var arg_3082 any = j__4; if linked_3080 == nil { tmp10 = ifn_3081.Invoke_O__O(arg_3082) } else { tmp10 = linked_3080.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3079, arg_3082) }; arg_3086 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3084 == nil { tmp8 = ifn_3085.Invoke_O__O(arg_3086) } else { tmp8 = linked_3084.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3083, arg_3086) }; var tmp11 any = tmp8; var tmp12 any; var root_3087 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3087, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3089 lang.IFn; if linked_3088 == nil { ifn_3089 = lang.IFn_Cast(root_3087) } else { ifn_3089 = nil }; var arg_3090 any = A_arbace_j2g_dyn_A_const_335; var arg_3091 any = A_arbace_j2g_dyn_A_const_336; if linked_3088 == nil { tmp12 = ifn_3089.Invoke_O_O__O(arg_3090, arg_3091) } else { tmp12 = linked_3088.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3087, arg_3090, arg_3091) }; arg_3099 = tmp6.Invoke_O_O_O__O(tmp7, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12)); var arg_3100 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000404); var tmp14 any; var root_3092 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3092, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3094 lang.IFn; if linked_3093 == nil { ifn_3094 = lang.IFn_Cast(root_3092) } else { ifn_3094 = nil }; var arg_3095 any = s__711000405__3; if linked_3093 == nil { tmp14 = ifn_3094.Invoke_O__O(arg_3095) } else { tmp14 = linked_3093.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3092, arg_3095) }; arg_3100 = tmp13.Invoke_O__O(tmp14); if linked_3097 == nil { return ifn_3098.Invoke_O_O__O(arg_3099, arg_3100) } else { return linked_3097.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3096, arg_3099, arg_3100) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :486:1
func A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A) Ctor_O_I_O(c__b__711000407 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000407 = c__b__711000407; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A) Invoke_O__O(self any) any { { var i__711000406__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000406__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000406__1)); var root_3047 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3047, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3049 lang.IFn; if linked_3048 == nil { ifn_3049 = lang.IFn_Cast(root_3047) } else { ifn_3049 = nil }; var arg_3050 any = t.F_b__711000407; var arg_3051 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_334; var tmp4 any; var root_3038 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3038, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3040 lang.IFn; if linked_3039 == nil { ifn_3040 = lang.IFn_Cast(root_3038) } else { ifn_3040 = nil }; var arg_3041 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp6 any; var root_3034 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_3035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3034, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3036 lang.IFn; if linked_3035 == nil { ifn_3036 = lang.IFn_Cast(root_3034) } else { ifn_3036 = nil }; var arg_3037 any = j__2; if linked_3035 == nil { tmp6 = ifn_3036.Invoke_O__O(arg_3037) } else { tmp6 = linked_3035.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3034, arg_3037) }; arg_3041 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_3039 == nil { tmp4 = ifn_3040.Invoke_O__O(arg_3041) } else { tmp4 = linked_3039.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3038, arg_3041) }; var tmp7 any = tmp4; var tmp8 any; var root_3042 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3042, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3044 lang.IFn; if linked_3043 == nil { ifn_3044 = lang.IFn_Cast(root_3042) } else { ifn_3044 = nil }; var arg_3045 any = A_arbace_j2g_dyn_A_const_335; var arg_3046 any = A_arbace_j2g_dyn_A_const_336; if linked_3043 == nil { tmp8 = ifn_3044.Invoke_O_O__O(arg_3045, arg_3046) } else { tmp8 = linked_3043.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3042, arg_3045, arg_3046) }; arg_3051 = tmp2.Invoke_O_O_O__O(tmp3, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8)); if linked_3048 == nil { ifn_3049.Invoke_O_O__O(arg_3050, arg_3051) } else { linked_3048.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3047, arg_3050, arg_3051) }; i__711000406__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000406__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_forms_fn__711000414_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000414_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000414_A{}; t.Ctor_O_O(p0, p1); return t }
//line :489:1
func (t *A_arbace_j2g_dyn_forms_fn__711000414_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :489:1
func (t *A_arbace_j2g_dyn_forms_fn__711000414_A) Invoke_O_O__O(self, i__1 any) any { var root_3106 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_3107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3106, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_3108 lang.IFn; if linked_3107 == nil { ifn_3108 = lang.IFn_Cast(root_3106) } else { ifn_3108 = nil }; var arg_3109 any = t.F_ifaces; var arg_3110 any = i__1; var tmp1 any = t.F_ks; var arg_3111 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(i__1)); if linked_3107 == nil { return ifn_3108.Invoke_O_O_O__O(arg_3109, arg_3110, arg_3111) } else { return linked_3107.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O__O(root_3106, arg_3109, arg_3110, arg_3111) } }







































































































































































































func A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_New() *A_arbace_j2g_dyn_forms_iter__711000416__711000420_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000416__711000420_A{}; t.Ctor(); return t }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_A) Ctor() {}
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_A) Invoke_O_O__O(self, s__711000417__1 any) any { var tmp1 any = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_New_O_O(self, s__711000417__1); var tmp2 *jrt.Class; var fncls__3566 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_fn_class; if fncls__3566 == nil { var fncls__3566d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_fn_class = fncls__3566d; tmp2 = fncls__3566d } else { tmp2 = fncls__3566 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :689:1
func A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A{}; t.Ctor_O_O(p0, p1); return t }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A) Ctor_O_O(c__iter__711000416, c__s__711000417 any) { t.F_iter__711000416 = c__iter__711000416; t.F_s__711000417 = c__s__711000417 }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A) Invoke_O__O(self any) any { { var s__711000417__1 any; var t_ any = t.F_s__711000417; t.F_s__711000417 = nil; s__711000417__1 = t_; for { var temp__1927000414__auto____2 any; var root_3449 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3449, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3451 lang.IFn; if linked_3450 == nil { ifn_3451 = lang.IFn_Cast(root_3449) } else { ifn_3451 = nil }; var arg_3452 any = s__711000417__1; if linked_3450 == nil { temp__1927000414__auto____2 = ifn_3451.Invoke_O__O(arg_3452) } else { temp__1927000414__auto____2 = linked_3450.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3449, arg_3452) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000417__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3453 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3453, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3455 lang.IFn; if linked_3454 == nil { ifn_3455 = lang.IFn_Cast(root_3453) } else { ifn_3455 = nil }; var arg_3456 any = s__711000417__3; if linked_3454 == nil { tmp1 = ifn_3455.Invoke_O__O(arg_3456) } else { tmp1 = linked_3454.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3453, arg_3456) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3457 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3457, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3459 lang.IFn; if linked_3458 == nil { ifn_3459 = lang.IFn_Cast(root_3457) } else { ifn_3459 = nil }; var arg_3460 any = s__711000417__3; if linked_3458 == nil { c__1927001037__auto____4 = ifn_3459.Invoke_O__O(arg_3460) } else { c__1927001037__auto____4 = linked_3458.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3457, arg_3460) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000419__6 any; var root_3461 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3461, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3463 lang.IFn; if linked_3462 == nil { ifn_3463 = lang.IFn_Cast(root_3461) } else { ifn_3463 = nil }; var arg_3464 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3462 == nil { b__711000419__6 = ifn_3463.Invoke_O__O(arg_3464) } else { b__711000419__6 = linked_3462.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3461, arg_3464) }; var tmp2 any = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_New_O_I_O(b__711000419__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3500 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_fn_class; if fncls__3500 == nil { var fncls__3500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_fn_class = fncls__3500d; tmp3 = fncls__3500d } else { tmp3 = fncls__3500 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3509 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3509, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3511 lang.IFn; if linked_3510 == nil { ifn_3511 = lang.IFn_Cast(root_3509) } else { ifn_3511 = nil }; var arg_3512 any; var root_3501 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3501, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3503 lang.IFn; if linked_3502 == nil { ifn_3503 = lang.IFn_Cast(root_3501) } else { ifn_3503 = nil }; var arg_3504 any = b__711000419__6; if linked_3502 == nil { arg_3512 = ifn_3503.Invoke_O__O(arg_3504) } else { arg_3512 = linked_3502.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3501, arg_3504) }; var arg_3513 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000416); var tmp5 any; var root_3505 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3505, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3507 lang.IFn; if linked_3506 == nil { ifn_3507 = lang.IFn_Cast(root_3505) } else { ifn_3507 = nil }; var arg_3508 any = s__711000417__3; if linked_3506 == nil { tmp5 = ifn_3507.Invoke_O__O(arg_3508) } else { tmp5 = linked_3506.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3505, arg_3508) }; arg_3513 = tmp4.Invoke_O__O(tmp5); if linked_3510 == nil { return ifn_3511.Invoke_O_O__O(arg_3512, arg_3513) } else { return linked_3510.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3509, arg_3512, arg_3513) } } else { var root_3518 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3518, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3520 lang.IFn; if linked_3519 == nil { ifn_3520 = lang.IFn_Cast(root_3518) } else { ifn_3520 = nil }; var arg_3521 any; var root_3514 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3514, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3516 lang.IFn; if linked_3515 == nil { ifn_3516 = lang.IFn_Cast(root_3514) } else { ifn_3516 = nil }; var arg_3517 any = b__711000419__6; if linked_3515 == nil { arg_3521 = ifn_3516.Invoke_O__O(arg_3517) } else { arg_3521 = linked_3515.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3514, arg_3517) }; var arg_3522 any; if linked_3519 == nil { return ifn_3520.Invoke_O_O__O(arg_3521, arg_3522) } else { return linked_3519.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3518, arg_3521, arg_3522) } } } else { var p__4 any; var root_3523 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3523, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3525 lang.IFn; if linked_3524 == nil { ifn_3525 = lang.IFn_Cast(root_3523) } else { ifn_3525 = nil }; var arg_3526 any = s__711000417__3; if linked_3524 == nil { p__4 = ifn_3525.Invoke_O__O(arg_3526) } else { p__4 = linked_3524.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3523, arg_3526) }; var root_3561 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3561, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3563 lang.IFn; if linked_3562 == nil { ifn_3563 = lang.IFn_Cast(root_3561) } else { ifn_3563 = nil }; var arg_3564 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_474; var tmp8 any; var root_3527 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3527, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3529 lang.IFn
													if linked_3528 == nil { ifn_3529 = lang.IFn_Cast(root_3527) } else { ifn_3529 = nil }; var arg_3530 any = A_arbace_j2g_dyn_A_const_73; var arg_3531 any = p__4; var arg_3532 any = Lit_23; if linked_3528 == nil { tmp8 = ifn_3529.Invoke_O_O_O__O(arg_3530, arg_3531, arg_3532) } else { tmp8 = linked_3528.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3527, arg_3530, arg_3531, arg_3532) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_475; var tmp12 any; var root_3537 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3537, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3539 lang.IFn
													if linked_3538 == nil { ifn_3539 = lang.IFn_Cast(root_3537) } else { ifn_3539 = nil }; var arg_3540 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_93, nil); var tmp14 any; var root_3533 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3533, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3535 lang.IFn; if linked_3534 == nil { ifn_3535 = lang.IFn_Cast(root_3533) } else { ifn_3535 = nil }; var arg_3536 any = p__4; if linked_3534 == nil { tmp14 = ifn_3535.Invoke_O__O(arg_3536) } else { tmp14 = linked_3534.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3533, arg_3536) }; arg_3540 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3538 == nil { tmp12 = ifn_3539.Invoke_O__O(arg_3540) } else { tmp12 = linked_3538.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3537, arg_3540) }
//line :690:1
	var tmp15 any = tmp12; var tmp16 any; var root_3545 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3545, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3547 lang.IFn
	if linked_3546 == nil { ifn_3547 = lang.IFn_Cast(root_3545) } else { ifn_3547 = nil }; var arg_3548 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp18 any; var root_3541 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3541, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3543 lang.IFn; if linked_3542 == nil { ifn_3543 = lang.IFn_Cast(root_3541) } else { ifn_3543 = nil }; var arg_3544 any = p__4; if linked_3542 == nil { tmp18 = ifn_3543.Invoke_O__O(arg_3544) } else { tmp18 = linked_3542.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3541, arg_3544) }; arg_3548 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3546 == nil { tmp16 = ifn_3547.Invoke_O__O(arg_3548) } else { tmp16 = linked_3546.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3545, arg_3548) }
//line :690:1
	var tmp19 any = tmp16; var tmp20 any; var root_3553 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3553, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3555 lang.IFn

	if linked_3554 == nil { ifn_3555 = lang.IFn_Cast(root_3553) } else { ifn_3555 = nil }; var arg_3556 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_94, nil); var tmp22 any; var root_3549 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3549, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3551 lang.IFn; if linked_3550 == nil { ifn_3551 = lang.IFn_Cast(root_3549) } else { ifn_3551 = nil }; var arg_3552 any = p__4; if linked_3550 == nil { tmp22 = ifn_3551.Invoke_O__O(arg_3552) } else { tmp22 = linked_3550.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3549, arg_3552) }; arg_3556 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref(); if linked_3554 == nil { tmp20 = ifn_3555.Invoke_O__O(arg_3556) } else { tmp20 = linked_3554.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3553, arg_3556) }
//line :690:1
	arg_3564 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp15, tmp19, tmp20))
//line :689:1
	var arg_3565 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000416); var tmp24 any; var root_3557 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3557, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3559 lang.IFn; if linked_3558 == nil { ifn_3559 = lang.IFn_Cast(root_3557) } else { ifn_3559 = nil }; var arg_3560 any = s__711000417__3; if linked_3558 == nil { tmp24 = ifn_3559.Invoke_O__O(arg_3560) } else { tmp24 = linked_3558.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3557, arg_3560) }; arg_3565 = tmp23.Invoke_O__O(tmp24); if linked_3562 == nil { return ifn_3563.Invoke_O_O__O(arg_3564, arg_3565) } else { return linked_3562.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3561, arg_3564, arg_3565) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :689:1
func A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A) Ctor_O_I_O(c__b__711000419 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000419 = c__b__711000419; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A) Invoke_O__O(self any) any { { var i__711000418__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000418__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000418__1)); var root_3495 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3495, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3497 lang.IFn; if linked_3496 == nil { ifn_3497 = lang.IFn_Cast(root_3495) } else { ifn_3497 = nil }; var arg_3498 any = t.F_b__711000419; var arg_3499 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_474; var tmp4 any; var root_3465 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3465, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3467 lang.IFn
															if linked_3466 == nil { ifn_3467 = lang.IFn_Cast(root_3465) } else { ifn_3467 = nil }; var arg_3468 any = A_arbace_j2g_dyn_A_const_73; var arg_3469 any = p__2; var arg_3470 any = Lit_23; if linked_3466 == nil { tmp4 = ifn_3467.Invoke_O_O_O__O(arg_3468, arg_3469, arg_3470) } else { tmp4 = linked_3466.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3465, arg_3468, arg_3469, arg_3470) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_475; var tmp8 any; var root_3475 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3475, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3477 lang.IFn
															if linked_3476 == nil { ifn_3477 = lang.IFn_Cast(root_3475) } else { ifn_3477 = nil }; var arg_3478 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_93, nil); var tmp10 any; var root_3471 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3471, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3473 lang.IFn; if linked_3472 == nil { ifn_3473 = lang.IFn_Cast(root_3471) } else { ifn_3473 = nil }; var arg_3474 any = p__2; if linked_3472 == nil { tmp10 = ifn_3473.Invoke_O__O(arg_3474) } else { tmp10 = linked_3472.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3471, arg_3474) }; arg_3478 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3476 == nil { tmp8 = ifn_3477.Invoke_O__O(arg_3478) } else { tmp8 = linked_3476.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3475, arg_3478) }
//line :690:1
	var tmp11 any = tmp8; var tmp12 any; var root_3483 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3483, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3485 lang.IFn
	if linked_3484 == nil { ifn_3485 = lang.IFn_Cast(root_3483) } else { ifn_3485 = nil }; var arg_3486 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp14 any; var root_3479 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3479, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3481 lang.IFn; if linked_3480 == nil { ifn_3481 = lang.IFn_Cast(root_3479) } else { ifn_3481 = nil }; var arg_3482 any = p__2; if linked_3480 == nil { tmp14 = ifn_3481.Invoke_O__O(arg_3482) } else { tmp14 = linked_3480.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3479, arg_3482) }; arg_3486 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3484 == nil { tmp12 = ifn_3485.Invoke_O__O(arg_3486) } else { tmp12 = linked_3484.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3483, arg_3486) }
//line :690:1
	var tmp15 any = tmp12; var tmp16 any; var root_3491 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3491, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3493 lang.IFn

	if linked_3492 == nil { ifn_3493 = lang.IFn_Cast(root_3491) } else { ifn_3493 = nil }; var arg_3494 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_94, nil); var tmp18 any; var root_3487 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3487, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3489 lang.IFn; if linked_3488 == nil { ifn_3489 = lang.IFn_Cast(root_3487) } else { ifn_3489 = nil }; var arg_3490 any = p__2; if linked_3488 == nil { tmp18 = ifn_3489.Invoke_O__O(arg_3490) } else { tmp18 = linked_3488.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3487, arg_3490) }; arg_3494 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3492 == nil { tmp16 = ifn_3493.Invoke_O__O(arg_3494) } else { tmp16 = linked_3492.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3491, arg_3494) }
//line :690:1
	arg_3499 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp11, tmp15, tmp16))
//line :689:1
	if linked_3496 == nil { ifn_3497.Invoke_O_O__O(arg_3498, arg_3499) } else { linked_3496.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3495, arg_3498, arg_3499) }; i__711000418__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000418__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































func A_arbace_j2g_dyn_forms_fn__711000426_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000426_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000426_A{}; t.Ctor_O_O(p0, p1); return t }
//line :731:1
func (t *A_arbace_j2g_dyn_forms_fn__711000426_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :731:1
func (t *A_arbace_j2g_dyn_forms_fn__711000426_A) Invoke_O_O__O(self, p1__711000381_SHARP___1 any) any { var root_3622 any = A_arbace_j2g_dyn_A_const_505.GetRawRoot__O(); var linked_3623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3622, A_arbace_j2g_dyn_sub_forms_A_fn_class); var ifn_3624 lang.IFn; if linked_3623 == nil { ifn_3624 = lang.IFn_Cast(root_3622) } else { ifn_3624 = nil }; var arg_3625 any = p1__711000381_SHARP___1; var arg_3626 any = t.F_ifaces; var arg_3627 any = t.F_ks; if linked_3623 == nil { return ifn_3624.Invoke_O_O_O__O(arg_3625, arg_3626, arg_3627) } else { return linked_3623.(*A_arbace_j2g_dyn_sub_forms_A).Invoke_O_O_O_O__O(root_3622, arg_3625, arg_3626, arg_3627) } }








































type A_arbace_j2g_dyn_A struct{ jrt.Object }

var A_arbace_j2g_dyn_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyn_A_const_0 *lang.Var

var A_arbace_j2g_dyn_A_const_1 any

var A_arbace_j2g_dyn_A_const_2 any

var A_arbace_j2g_dyn_A_const_3 any

var A_arbace_j2g_dyn_A_const_4 any

var A_arbace_j2g_dyn_A_const_5 any

var A_arbace_j2g_dyn_A_const_6 any

var A_arbace_j2g_dyn_A_const_7 any

var A_arbace_j2g_dyn_A_const_8 any

var A_arbace_j2g_dyn_A_const_9 *lang.Var

var A_arbace_j2g_dyn_A_const_10 any

var A_arbace_j2g_dyn_A_const_11 *lang.Var

var A_arbace_j2g_dyn_A_const_12 *lang.Var

var A_arbace_j2g_dyn_A_const_13 *lang.Var

var A_arbace_j2g_dyn_A_const_14 *lang.Var

var A_arbace_j2g_dyn_A_const_15 any

var A_arbace_j2g_dyn_A_const_16 *lang.Var

var A_arbace_j2g_dyn_A_const_17 *lang.Keyword

var A_arbace_j2g_dyn_A_const_18 *lang.Var

var A_arbace_j2g_dyn_A_const_19 *lang.Var

var A_arbace_j2g_dyn_A_const_20 *lang.Var

var A_arbace_j2g_dyn_A_const_21 *lang.Var

var A_arbace_j2g_dyn_A_const_22 *lang.Var

var A_arbace_j2g_dyn_A_const_23 *lang.Var

var A_arbace_j2g_dyn_A_const_24 *lang.Var

var A_arbace_j2g_dyn_A_const_25 *lang.Var

var A_arbace_j2g_dyn_A_const_26 *lang.Var

var A_arbace_j2g_dyn_A_const_27 *lang.Var

var A_arbace_j2g_dyn_A_const_28 *lang.Var

var A_arbace_j2g_dyn_A_const_29 *lang.Var

var A_arbace_j2g_dyn_A_const_30 *lang.Var

var A_arbace_j2g_dyn_A_const_31 *lang.Var

var A_arbace_j2g_dyn_A_const_32 *lang.Var

var A_arbace_j2g_dyn_A_const_33 *lang.Keyword

var A_arbace_j2g_dyn_A_const_34 *lang.Var

var A_arbace_j2g_dyn_A_const_35 *lang.Var

var A_arbace_j2g_dyn_A_const_36 *lang.Var

var A_arbace_j2g_dyn_A_const_37 *lang.Var

var A_arbace_j2g_dyn_A_const_38 *lang.Var

var A_arbace_j2g_dyn_A_const_39 *lang.Var

var A_arbace_j2g_dyn_A_const_40 *lang.Var

var A_arbace_j2g_dyn_A_const_41 *lang.Var

var A_arbace_j2g_dyn_A_const_42 *lang.Var

var A_arbace_j2g_dyn_A_const_43 *lang.Var

var A_arbace_j2g_dyn_A_const_44 *lang.Var

var A_arbace_j2g_dyn_A_const_45 *lang.Keyword

var A_arbace_j2g_dyn_A_const_46 *lang.Keyword

var A_arbace_j2g_dyn_A_const_47 *lang.Var

var A_arbace_j2g_dyn_A_const_48 *lang.Var

var A_arbace_j2g_dyn_A_const_49 *lang.Var

var A_arbace_j2g_dyn_A_const_50 *lang.Var

var A_arbace_j2g_dyn_A_const_51 *lang.Keyword

var A_arbace_j2g_dyn_A_const_52 *lang.Var

var A_arbace_j2g_dyn_A_const_53 *lang.Var

var A_arbace_j2g_dyn_A_const_54 *lang.Var

var A_arbace_j2g_dyn_A_const_55 *lang.Var

var A_arbace_j2g_dyn_A_const_56 *lang.Var

var A_arbace_j2g_dyn_A_const_57 *lang.Var

var A_arbace_j2g_dyn_A_const_58 *lang.Var

var A_arbace_j2g_dyn_A_const_59 *lang.Var

var A_arbace_j2g_dyn_A_const_60 *lang.Var

var A_arbace_j2g_dyn_A_const_61 *lang.Var

var A_arbace_j2g_dyn_A_const_62 *lang.Var

var A_arbace_j2g_dyn_A_const_63 *lang.Var

var A_arbace_j2g_dyn_A_const_64 *lang.Keyword

var A_arbace_j2g_dyn_A_const_65 *lang.Keyword

var A_arbace_j2g_dyn_A_const_66 *lang.Var

var A_arbace_j2g_dyn_A_const_67 *lang.Var

var A_arbace_j2g_dyn_A_const_68 *lang.Var

var A_arbace_j2g_dyn_A_const_69 *lang.Keyword

var A_arbace_j2g_dyn_A_const_70 *lang.Keyword

var A_arbace_j2g_dyn_A_const_71 *lang.Keyword

var A_arbace_j2g_dyn_A_const_72 *lang.Var

var A_arbace_j2g_dyn_A_const_73 *lang.Keyword

var A_arbace_j2g_dyn_A_const_74 *lang.Var

var A_arbace_j2g_dyn_A_const_75 *lang.Var

var A_arbace_j2g_dyn_A_const_76 *lang.Var

var A_arbace_j2g_dyn_A_const_77 *lang.Var

var A_arbace_j2g_dyn_A_const_78 *lang.Var

var A_arbace_j2g_dyn_A_const_79 *lang.Var

var A_arbace_j2g_dyn_A_const_80 *lang.Var

var A_arbace_j2g_dyn_A_const_81 *lang.Keyword

var A_arbace_j2g_dyn_A_const_82 any

var A_arbace_j2g_dyn_A_const_83 any

var A_arbace_j2g_dyn_A_const_84 any

var A_arbace_j2g_dyn_A_const_85 *lang.Var

var A_arbace_j2g_dyn_A_const_86 any

var A_arbace_j2g_dyn_A_const_87 *lang.Var

var A_arbace_j2g_dyn_A_const_88 any

var A_arbace_j2g_dyn_A_const_89 any

var A_arbace_j2g_dyn_A_const_90 any

var A_arbace_j2g_dyn_A_const_91 *lang.Var

var A_arbace_j2g_dyn_A_const_92 any

var A_arbace_j2g_dyn_A_const_93 *lang.Var

var A_arbace_j2g_dyn_A_const_94 *lang.Var

var A_arbace_j2g_dyn_A_const_95 *lang.Var

var A_arbace_j2g_dyn_A_const_96 *lang.Var

var A_arbace_j2g_dyn_A_const_97 any

var A_arbace_j2g_dyn_A_const_98 any

var A_arbace_j2g_dyn_A_const_99 *lang.Var

var A_arbace_j2g_dyn_A_const_100 *lang.Var

var A_arbace_j2g_dyn_A_const_101 *lang.Var

var A_arbace_j2g_dyn_A_const_102 any

var A_arbace_j2g_dyn_A_const_103 any

var A_arbace_j2g_dyn_A_const_104 any

var A_arbace_j2g_dyn_A_const_105 any

var A_arbace_j2g_dyn_A_const_106 any

var A_arbace_j2g_dyn_A_const_107 any

var A_arbace_j2g_dyn_A_const_108 *lang.Var

var A_arbace_j2g_dyn_A_const_109 any

var A_arbace_j2g_dyn_A_const_110 *lang.Var

var A_arbace_j2g_dyn_A_const_111 *lang.Var

var A_arbace_j2g_dyn_A_const_112 *lang.Keyword

var A_arbace_j2g_dyn_A_const_113 *lang.Var

var A_arbace_j2g_dyn_A_const_114 *lang.Var

var A_arbace_j2g_dyn_A_const_115 *lang.Var

var A_arbace_j2g_dyn_A_const_116 *lang.Var

var A_arbace_j2g_dyn_A_const_117 *lang.Var

var A_arbace_j2g_dyn_A_const_118 any

var A_arbace_j2g_dyn_A_const_119 any

var A_arbace_j2g_dyn_A_const_120 any

var A_arbace_j2g_dyn_A_const_121 any

var A_arbace_j2g_dyn_A_const_122 any

var A_arbace_j2g_dyn_A_const_123 any

var A_arbace_j2g_dyn_A_const_124 any

var A_arbace_j2g_dyn_A_const_125 any

var A_arbace_j2g_dyn_A_const_126 any

var A_arbace_j2g_dyn_A_const_127 *lang.Var

var A_arbace_j2g_dyn_A_const_128 any

var A_arbace_j2g_dyn_A_const_129 any

var A_arbace_j2g_dyn_A_const_130 any

var A_arbace_j2g_dyn_A_const_131 *lang.Var

var A_arbace_j2g_dyn_A_const_132 *lang.Var

var A_arbace_j2g_dyn_A_const_133 *lang.Var

var A_arbace_j2g_dyn_A_const_134 *lang.Var

var A_arbace_j2g_dyn_A_const_135 any

var A_arbace_j2g_dyn_A_const_136 *lang.Var

var A_arbace_j2g_dyn_A_const_137 any

var A_arbace_j2g_dyn_A_const_138 any

var A_arbace_j2g_dyn_A_const_139 any

var A_arbace_j2g_dyn_A_const_140 any

var A_arbace_j2g_dyn_A_const_141 any

var A_arbace_j2g_dyn_A_const_142 any

var A_arbace_j2g_dyn_A_const_143 any

var A_arbace_j2g_dyn_A_const_144 any

var A_arbace_j2g_dyn_A_const_145 any

var A_arbace_j2g_dyn_A_const_146 any

var A_arbace_j2g_dyn_A_const_147 any

var A_arbace_j2g_dyn_A_const_148 any

var A_arbace_j2g_dyn_A_const_149 any

var A_arbace_j2g_dyn_A_const_150 any

var A_arbace_j2g_dyn_A_const_151 any

var A_arbace_j2g_dyn_A_const_152 any

var A_arbace_j2g_dyn_A_const_153 any

var A_arbace_j2g_dyn_A_const_154 any

var A_arbace_j2g_dyn_A_const_155 *lang.Var

var A_arbace_j2g_dyn_A_const_156 any

var A_arbace_j2g_dyn_A_const_157 *lang.Var

var A_arbace_j2g_dyn_A_const_158 any

var A_arbace_j2g_dyn_A_const_159 any

var A_arbace_j2g_dyn_A_const_160 any

var A_arbace_j2g_dyn_A_const_161 *lang.Var

var A_arbace_j2g_dyn_A_const_162 *lang.Var

var A_arbace_j2g_dyn_A_const_163 *lang.Var

var A_arbace_j2g_dyn_A_const_164 *lang.Var

var A_arbace_j2g_dyn_A_const_165 *lang.Var

var A_arbace_j2g_dyn_A_const_166 *lang.Var

var A_arbace_j2g_dyn_A_const_167 any

var A_arbace_j2g_dyn_A_const_168 any

var A_arbace_j2g_dyn_A_const_169 any

var A_arbace_j2g_dyn_A_const_170 any

var A_arbace_j2g_dyn_A_const_171 any

var A_arbace_j2g_dyn_A_const_172 any

var A_arbace_j2g_dyn_A_const_173 any

var A_arbace_j2g_dyn_A_const_174 any

var A_arbace_j2g_dyn_A_const_175 any

var A_arbace_j2g_dyn_A_const_176 any

var A_arbace_j2g_dyn_A_const_177 *lang.Keyword

var A_arbace_j2g_dyn_A_const_178 *lang.Keyword

var A_arbace_j2g_dyn_A_const_179 *lang.Keyword

var A_arbace_j2g_dyn_A_const_180 any

var A_arbace_j2g_dyn_A_const_181 any

var A_arbace_j2g_dyn_A_const_182 any

var A_arbace_j2g_dyn_A_const_183 any

var A_arbace_j2g_dyn_A_const_184 any

var A_arbace_j2g_dyn_A_const_185 any

var A_arbace_j2g_dyn_A_const_186 any

var A_arbace_j2g_dyn_A_const_187 *lang.Var

var A_arbace_j2g_dyn_A_const_188 any

var A_arbace_j2g_dyn_A_const_189 any

var A_arbace_j2g_dyn_A_const_190 any

var A_arbace_j2g_dyn_A_const_191 *lang.Var

var A_arbace_j2g_dyn_A_const_192 *lang.Var

var A_arbace_j2g_dyn_A_const_193 *lang.Var

var A_arbace_j2g_dyn_A_const_194 *lang.Var

var A_arbace_j2g_dyn_A_const_195 any

var A_arbace_j2g_dyn_A_const_196 any

var A_arbace_j2g_dyn_A_const_197 any

var A_arbace_j2g_dyn_A_const_198 any

var A_arbace_j2g_dyn_A_const_199 any

var A_arbace_j2g_dyn_A_const_200 any

var A_arbace_j2g_dyn_A_const_201 any

var A_arbace_j2g_dyn_A_const_202 any

var A_arbace_j2g_dyn_A_const_203 *lang.Var

var A_arbace_j2g_dyn_A_const_204 *lang.Var

var A_arbace_j2g_dyn_A_const_205 *lang.Var

var A_arbace_j2g_dyn_A_const_206 *lang.Var

var A_arbace_j2g_dyn_A_const_207 any

var A_arbace_j2g_dyn_A_const_208 any

var A_arbace_j2g_dyn_A_const_209 *lang.Keyword

var A_arbace_j2g_dyn_A_const_210 any

var A_arbace_j2g_dyn_A_const_211 any

var A_arbace_j2g_dyn_A_const_212 *lang.Var

var A_arbace_j2g_dyn_A_const_213 *lang.Keyword

var A_arbace_j2g_dyn_A_const_214 any

var A_arbace_j2g_dyn_A_const_215 *lang.Keyword

var A_arbace_j2g_dyn_A_const_216 *lang.Var

var A_arbace_j2g_dyn_A_const_217 any

var A_arbace_j2g_dyn_A_const_218 any

var A_arbace_j2g_dyn_A_const_219 any

var A_arbace_j2g_dyn_A_const_220 any

var A_arbace_j2g_dyn_A_const_221 *lang.Var

var A_arbace_j2g_dyn_A_const_222 any

var A_arbace_j2g_dyn_A_const_223 any

var A_arbace_j2g_dyn_A_const_224 any

var A_arbace_j2g_dyn_A_const_225 any

var A_arbace_j2g_dyn_A_const_226 any

var A_arbace_j2g_dyn_A_const_227 *lang.Var

var A_arbace_j2g_dyn_A_const_228 any

var A_arbace_j2g_dyn_A_const_229 any

var A_arbace_j2g_dyn_A_const_230 any

var A_arbace_j2g_dyn_A_const_231 any

var A_arbace_j2g_dyn_A_const_232 any

var A_arbace_j2g_dyn_A_const_233 any

var A_arbace_j2g_dyn_A_const_234 *lang.Keyword

var A_arbace_j2g_dyn_A_const_235 any

var A_arbace_j2g_dyn_A_const_236 any

var A_arbace_j2g_dyn_A_const_237 *lang.Var

var A_arbace_j2g_dyn_A_const_238 *lang.Var

var A_arbace_j2g_dyn_A_const_239 *lang.Var

var A_arbace_j2g_dyn_A_const_240 *lang.Var

var A_arbace_j2g_dyn_A_const_241 any

var A_arbace_j2g_dyn_A_const_242 any

var A_arbace_j2g_dyn_A_const_243 any

var A_arbace_j2g_dyn_A_const_244 any

var A_arbace_j2g_dyn_A_const_245 any

var A_arbace_j2g_dyn_A_const_246 any

var A_arbace_j2g_dyn_A_const_247 any

var A_arbace_j2g_dyn_A_const_248 any

var A_arbace_j2g_dyn_A_const_249 any

var A_arbace_j2g_dyn_A_const_250 any

var A_arbace_j2g_dyn_A_const_251 any

var A_arbace_j2g_dyn_A_const_252 any

var A_arbace_j2g_dyn_A_const_253 any

var A_arbace_j2g_dyn_A_const_254 any

var A_arbace_j2g_dyn_A_const_255 any

var A_arbace_j2g_dyn_A_const_256 any

var A_arbace_j2g_dyn_A_const_257 any

var A_arbace_j2g_dyn_A_const_258 any

var A_arbace_j2g_dyn_A_const_259 any

var A_arbace_j2g_dyn_A_const_260 any

var A_arbace_j2g_dyn_A_const_261 any

var A_arbace_j2g_dyn_A_const_262 any

var A_arbace_j2g_dyn_A_const_263 any

var A_arbace_j2g_dyn_A_const_264 any

var A_arbace_j2g_dyn_A_const_265 any

var A_arbace_j2g_dyn_A_const_266 any

var A_arbace_j2g_dyn_A_const_267 any

var A_arbace_j2g_dyn_A_const_268 any

var A_arbace_j2g_dyn_A_const_269 any

var A_arbace_j2g_dyn_A_const_270 any

var A_arbace_j2g_dyn_A_const_271 any

var A_arbace_j2g_dyn_A_const_272 any

var A_arbace_j2g_dyn_A_const_273 any

var A_arbace_j2g_dyn_A_const_274 *lang.Var

var A_arbace_j2g_dyn_A_const_275 any

var A_arbace_j2g_dyn_A_const_276 any

var A_arbace_j2g_dyn_A_const_277 *lang.Var

var A_arbace_j2g_dyn_A_const_278 *lang.Var

var A_arbace_j2g_dyn_A_const_279 *lang.Var

var A_arbace_j2g_dyn_A_const_280 any

var A_arbace_j2g_dyn_A_const_281 any

var A_arbace_j2g_dyn_A_const_282 *lang.Var

var A_arbace_j2g_dyn_A_const_283 any

var A_arbace_j2g_dyn_A_const_284 any

var A_arbace_j2g_dyn_A_const_285 any

var A_arbace_j2g_dyn_A_const_286 any

var A_arbace_j2g_dyn_A_const_287 any

var A_arbace_j2g_dyn_A_const_288 any

var A_arbace_j2g_dyn_A_const_289 any

var A_arbace_j2g_dyn_A_const_290 any

var A_arbace_j2g_dyn_A_const_291 any

var A_arbace_j2g_dyn_A_const_292 *lang.Var

var A_arbace_j2g_dyn_A_const_293 *lang.Var

var A_arbace_j2g_dyn_A_const_294 any

var A_arbace_j2g_dyn_A_const_295 any

var A_arbace_j2g_dyn_A_const_296 any

var A_arbace_j2g_dyn_A_const_297 any

var A_arbace_j2g_dyn_A_const_298 any

var A_arbace_j2g_dyn_A_const_299 any

var A_arbace_j2g_dyn_A_const_300 any

var A_arbace_j2g_dyn_A_const_301 any

var A_arbace_j2g_dyn_A_const_302 any

var A_arbace_j2g_dyn_A_const_303 any

var A_arbace_j2g_dyn_A_const_304 any

var A_arbace_j2g_dyn_A_const_305 any

var A_arbace_j2g_dyn_A_const_306 any

var A_arbace_j2g_dyn_A_const_307 any

var A_arbace_j2g_dyn_A_const_308 any

var A_arbace_j2g_dyn_A_const_309 any

var A_arbace_j2g_dyn_A_const_310 any

var A_arbace_j2g_dyn_A_const_311 any

var A_arbace_j2g_dyn_A_const_312 any

var A_arbace_j2g_dyn_A_const_313 any

var A_arbace_j2g_dyn_A_const_314 any

var A_arbace_j2g_dyn_A_const_315 any

var A_arbace_j2g_dyn_A_const_316 any

var A_arbace_j2g_dyn_A_const_317 any

var A_arbace_j2g_dyn_A_const_318 any

var A_arbace_j2g_dyn_A_const_319 any

var A_arbace_j2g_dyn_A_const_320 any

var A_arbace_j2g_dyn_A_const_321 any

var A_arbace_j2g_dyn_A_const_322 any

var A_arbace_j2g_dyn_A_const_323 any

var A_arbace_j2g_dyn_A_const_324 any

var A_arbace_j2g_dyn_A_const_325 any

var A_arbace_j2g_dyn_A_const_326 any

var A_arbace_j2g_dyn_A_const_327 any

var A_arbace_j2g_dyn_A_const_328 any

var A_arbace_j2g_dyn_A_const_329 any

var A_arbace_j2g_dyn_A_const_330 any

var A_arbace_j2g_dyn_A_const_331 any

var A_arbace_j2g_dyn_A_const_332 any

var A_arbace_j2g_dyn_A_const_333 any

var A_arbace_j2g_dyn_A_const_334 any

var A_arbace_j2g_dyn_A_const_335 any

var A_arbace_j2g_dyn_A_const_336 any

var A_arbace_j2g_dyn_A_const_337 *lang.Var

var A_arbace_j2g_dyn_A_const_338 *lang.Var

var A_arbace_j2g_dyn_A_const_339 any

var A_arbace_j2g_dyn_A_const_340 any

var A_arbace_j2g_dyn_A_const_341 *lang.Var

var A_arbace_j2g_dyn_A_const_342 any

var A_arbace_j2g_dyn_A_const_343 any

var A_arbace_j2g_dyn_A_const_344 any

var A_arbace_j2g_dyn_A_const_345 *lang.Var

var A_arbace_j2g_dyn_A_const_346 any

var A_arbace_j2g_dyn_A_const_347 any

var A_arbace_j2g_dyn_A_const_348 any

var A_arbace_j2g_dyn_A_const_349 any

var A_arbace_j2g_dyn_A_const_350 any

var A_arbace_j2g_dyn_A_const_351 any

var A_arbace_j2g_dyn_A_const_352 any

var A_arbace_j2g_dyn_A_const_353 any

var A_arbace_j2g_dyn_A_const_354 any

var A_arbace_j2g_dyn_A_const_355 any

var A_arbace_j2g_dyn_A_const_356 any

var A_arbace_j2g_dyn_A_const_357 any

var A_arbace_j2g_dyn_A_const_358 any

var A_arbace_j2g_dyn_A_const_359 any

var A_arbace_j2g_dyn_A_const_360 any

var A_arbace_j2g_dyn_A_const_361 any

var A_arbace_j2g_dyn_A_const_362 any

var A_arbace_j2g_dyn_A_const_363 any

var A_arbace_j2g_dyn_A_const_364 any

var A_arbace_j2g_dyn_A_const_365 any

var A_arbace_j2g_dyn_A_const_366 *lang.Keyword

var A_arbace_j2g_dyn_A_const_367 *lang.Keyword

var A_arbace_j2g_dyn_A_const_368 any

var A_arbace_j2g_dyn_A_const_369 *lang.Keyword

var A_arbace_j2g_dyn_A_const_370 any

var A_arbace_j2g_dyn_A_const_371 *lang.Keyword

var A_arbace_j2g_dyn_A_const_372 any

var A_arbace_j2g_dyn_A_const_373 any

var A_arbace_j2g_dyn_A_const_374 any

var A_arbace_j2g_dyn_A_const_375 any

var A_arbace_j2g_dyn_A_const_376 any

var A_arbace_j2g_dyn_A_const_377 any

var A_arbace_j2g_dyn_A_const_378 any

var A_arbace_j2g_dyn_A_const_379 any

var A_arbace_j2g_dyn_A_const_380 any

var A_arbace_j2g_dyn_A_const_381 any

var A_arbace_j2g_dyn_A_const_382 any

var A_arbace_j2g_dyn_A_const_383 any

var A_arbace_j2g_dyn_A_const_384 any

var A_arbace_j2g_dyn_A_const_385 any

var A_arbace_j2g_dyn_A_const_386 any

var A_arbace_j2g_dyn_A_const_387 any

var A_arbace_j2g_dyn_A_const_388 any

var A_arbace_j2g_dyn_A_const_389 any

var A_arbace_j2g_dyn_A_const_390 any

var A_arbace_j2g_dyn_A_const_391 any

var A_arbace_j2g_dyn_A_const_392 any

var A_arbace_j2g_dyn_A_const_393 any

var A_arbace_j2g_dyn_A_const_394 any

var A_arbace_j2g_dyn_A_const_395 any

var A_arbace_j2g_dyn_A_const_396 any

var A_arbace_j2g_dyn_A_const_397 any

var A_arbace_j2g_dyn_A_const_398 any

var A_arbace_j2g_dyn_A_const_399 any

var A_arbace_j2g_dyn_A_const_400 any

var A_arbace_j2g_dyn_A_const_401 any

var A_arbace_j2g_dyn_A_const_402 any

var A_arbace_j2g_dyn_A_const_403 any

var A_arbace_j2g_dyn_A_const_404 any

var A_arbace_j2g_dyn_A_const_405 any

var A_arbace_j2g_dyn_A_const_406 any

var A_arbace_j2g_dyn_A_const_407 any

var A_arbace_j2g_dyn_A_const_408 any

var A_arbace_j2g_dyn_A_const_409 any

var A_arbace_j2g_dyn_A_const_410 any

var A_arbace_j2g_dyn_A_const_411 any

var A_arbace_j2g_dyn_A_const_412 any

var A_arbace_j2g_dyn_A_const_413 any

var A_arbace_j2g_dyn_A_const_414 any

var A_arbace_j2g_dyn_A_const_415 any

var A_arbace_j2g_dyn_A_const_416 any

var A_arbace_j2g_dyn_A_const_417 any

var A_arbace_j2g_dyn_A_const_418 any

var A_arbace_j2g_dyn_A_const_419 any

var A_arbace_j2g_dyn_A_const_420 any

var A_arbace_j2g_dyn_A_const_421 any

var A_arbace_j2g_dyn_A_const_422 any

var A_arbace_j2g_dyn_A_const_423 any

var A_arbace_j2g_dyn_A_const_424 any

var A_arbace_j2g_dyn_A_const_425 any

var A_arbace_j2g_dyn_A_const_426 any

var A_arbace_j2g_dyn_A_const_427 any

var A_arbace_j2g_dyn_A_const_428 any

var A_arbace_j2g_dyn_A_const_429 any

var A_arbace_j2g_dyn_A_const_430 any

var A_arbace_j2g_dyn_A_const_431 any

var A_arbace_j2g_dyn_A_const_432 any

var A_arbace_j2g_dyn_A_const_433 any

var A_arbace_j2g_dyn_A_const_434 any

var A_arbace_j2g_dyn_A_const_435 any

var A_arbace_j2g_dyn_A_const_436 any

var A_arbace_j2g_dyn_A_const_437 any

var A_arbace_j2g_dyn_A_const_438 any

var A_arbace_j2g_dyn_A_const_439 any

var A_arbace_j2g_dyn_A_const_440 any

var A_arbace_j2g_dyn_A_const_441 any

var A_arbace_j2g_dyn_A_const_442 any

var A_arbace_j2g_dyn_A_const_443 any

var A_arbace_j2g_dyn_A_const_444 any

var A_arbace_j2g_dyn_A_const_445 any

var A_arbace_j2g_dyn_A_const_446 any

var A_arbace_j2g_dyn_A_const_447 any

var A_arbace_j2g_dyn_A_const_448 any

var A_arbace_j2g_dyn_A_const_449 any

var A_arbace_j2g_dyn_A_const_450 any

var A_arbace_j2g_dyn_A_const_451 any

var A_arbace_j2g_dyn_A_const_452 any

var A_arbace_j2g_dyn_A_const_453 any

var A_arbace_j2g_dyn_A_const_454 any

var A_arbace_j2g_dyn_A_const_455 any

var A_arbace_j2g_dyn_A_const_456 any

var A_arbace_j2g_dyn_A_const_457 any

var A_arbace_j2g_dyn_A_const_458 any

var A_arbace_j2g_dyn_A_const_459 any

var A_arbace_j2g_dyn_A_const_460 any

var A_arbace_j2g_dyn_A_const_461 any

var A_arbace_j2g_dyn_A_const_462 any

var A_arbace_j2g_dyn_A_const_463 any

var A_arbace_j2g_dyn_A_const_464 any

var A_arbace_j2g_dyn_A_const_465 any

var A_arbace_j2g_dyn_A_const_466 any

var A_arbace_j2g_dyn_A_const_467 any

var A_arbace_j2g_dyn_A_const_468 any

var A_arbace_j2g_dyn_A_const_469 any

var A_arbace_j2g_dyn_A_const_470 *lang.Keyword

var A_arbace_j2g_dyn_A_const_471 any

var A_arbace_j2g_dyn_A_const_472 any

var A_arbace_j2g_dyn_A_const_473 any

var A_arbace_j2g_dyn_A_const_474 any

var A_arbace_j2g_dyn_A_const_475 any

var A_arbace_j2g_dyn_A_const_476 *lang.Var

var A_arbace_j2g_dyn_A_const_477 any

var A_arbace_j2g_dyn_A_const_478 any

var A_arbace_j2g_dyn_A_const_479 any

var A_arbace_j2g_dyn_A_const_480 any

var A_arbace_j2g_dyn_A_const_481 any

var A_arbace_j2g_dyn_A_const_482 any

var A_arbace_j2g_dyn_A_const_483 any

var A_arbace_j2g_dyn_A_const_484 any

var A_arbace_j2g_dyn_A_const_485 any

var A_arbace_j2g_dyn_A_const_486 any

var A_arbace_j2g_dyn_A_const_487 any

var A_arbace_j2g_dyn_A_const_488 any

var A_arbace_j2g_dyn_A_const_489 any

var A_arbace_j2g_dyn_A_const_490 any

var A_arbace_j2g_dyn_A_const_491 any

var A_arbace_j2g_dyn_A_const_492 any

var A_arbace_j2g_dyn_A_const_493 any

var A_arbace_j2g_dyn_A_const_494 any

var A_arbace_j2g_dyn_A_const_495 any

var A_arbace_j2g_dyn_A_const_496 any

var A_arbace_j2g_dyn_A_const_497 any

var A_arbace_j2g_dyn_A_const_498 any

var A_arbace_j2g_dyn_A_const_499 any

var A_arbace_j2g_dyn_A_const_500 any

var A_arbace_j2g_dyn_A_const_501 any

var A_arbace_j2g_dyn_A_const_502 any

var A_arbace_j2g_dyn_A_const_503 any

var A_arbace_j2g_dyn_A_const_504 *lang.Var

var A_arbace_j2g_dyn_A_const_505 *lang.Var

var A_arbace_j2g_dyn_A_init jrt.ClassInit

func A_arbace_j2g_dyn_A_Init() { if !A_arbace_j2g_dyn_A_init.Done() { A_arbace_j2g_dyn_A_init.Run(A_arbace_j2g_dyn_A_clinit) } }

func A_arbace_j2g_dyn_A_clinit() { A_arbace_j2g_dyn_A_clinit_p0(); A_arbace_j2g_dyn_A_clinit_p1(); A_arbace_j2g_dyn_A_clinit_p2(); A_arbace_j2g_dyn_A_clinit_p3(); A_arbace_j2g_dyn_A_clinit_p4(); A_arbace_j2g_dyn_A_clinit_p5(); A_arbace_j2g_dyn_A_clinit_p6(); A_arbace_j2g_dyn_A_clinit_p7(); A_arbace_j2g_dyn_A_clinit_p8(); A_arbace_j2g_dyn_A_clinit_p9(); A_arbace_j2g_dyn_A_clinit_p10(); A_arbace_j2g_dyn_A_clinit_p11(); A_arbace_j2g_dyn_A_clinit_p12(); A_arbace_j2g_dyn_A_clinit_p13(); A_arbace_j2g_dyn_A_clinit_p14(); A_arbace_j2g_dyn_A_clinit_p15(); A_arbace_j2g_dyn_A_clinit_p16(); A_arbace_j2g_dyn_A_clinit_p17(); A_arbace_j2g_dyn_A_clinit_p18(); A_arbace_j2g_dyn_A_clinit_p19(); A_arbace_j2g_dyn_A_clinit_p20(); A_arbace_j2g_dyn_A_clinit_p21(); A_arbace_j2g_dyn_A_clinit_p22(); A_arbace_j2g_dyn_A_clinit_p23(); A_arbace_j2g_dyn_A_clinit_p24(); A_arbace_j2g_dyn_A_clinit_p25(); A_arbace_j2g_dyn_A_clinit_p26(); A_arbace_j2g_dyn_A_clinit_p27(); A_arbace_j2g_dyn_A_clinit_p28(); A_arbace_j2g_dyn_A_clinit_p29(); A_arbace_j2g_dyn_A_clinit_p30(); A_arbace_j2g_dyn_A_clinit_p31(); A_arbace_j2g_dyn_A_clinit_p32(); A_arbace_j2g_dyn_A_clinit_p33(); A_arbace_j2g_dyn_A_clinit_p34(); A_arbace_j2g_dyn_A_clinit_p35() }

func A_arbace_j2g_dyn_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 770); A_arbace_j2g_dyn_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[264]); A_arbace_j2g_dyn_A_const_1 = A_arbace_j2g_dyn_A_const_pool.A[265]; A_arbace_j2g_dyn_A_const_2 = A_arbace_j2g_dyn_A_const_pool.A[266]; A_arbace_j2g_dyn_A_const_3 = A_arbace_j2g_dyn_A_const_pool.A[267]; A_arbace_j2g_dyn_A_const_4 = A_arbace_j2g_dyn_A_const_pool.A[268]; A_arbace_j2g_dyn_A_const_5 = A_arbace_j2g_dyn_A_const_pool.A[269]; A_arbace_j2g_dyn_A_const_6 = A_arbace_j2g_dyn_A_const_pool.A[270]; A_arbace_j2g_dyn_A_const_7 = A_arbace_j2g_dyn_A_const_pool.A[271]; A_arbace_j2g_dyn_A_const_8 = A_arbace_j2g_dyn_A_const_pool.A[272]; A_arbace_j2g_dyn_A_const_9 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[273]); A_arbace_j2g_dyn_A_const_10 = A_arbace_j2g_dyn_A_const_pool.A[274]; A_arbace_j2g_dyn_A_const_11 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[275]); A_arbace_j2g_dyn_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[276]) }

func A_arbace_j2g_dyn_A_clinit_p1() { A_arbace_j2g_dyn_A_const_13 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[277]); A_arbace_j2g_dyn_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[278]); A_arbace_j2g_dyn_A_const_15 = A_arbace_j2g_dyn_A_const_pool.A[279]; A_arbace_j2g_dyn_A_const_16 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[280]); A_arbace_j2g_dyn_A_const_17 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[281]); A_arbace_j2g_dyn_A_const_18 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[282]); A_arbace_j2g_dyn_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[283]); A_arbace_j2g_dyn_A_const_20 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[284]); A_arbace_j2g_dyn_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[285]); A_arbace_j2g_dyn_A_const_22 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[286]); A_arbace_j2g_dyn_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[287]); A_arbace_j2g_dyn_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[288]) }

func A_arbace_j2g_dyn_A_clinit_p2() { A_arbace_j2g_dyn_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[289]); A_arbace_j2g_dyn_A_const_26 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[290]); A_arbace_j2g_dyn_A_const_27 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[291]); A_arbace_j2g_dyn_A_const_28 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[292]); A_arbace_j2g_dyn_A_const_29 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[293]); A_arbace_j2g_dyn_A_const_30 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[294]); A_arbace_j2g_dyn_A_const_31 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[295]); A_arbace_j2g_dyn_A_const_32 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[296]); A_arbace_j2g_dyn_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[297]); A_arbace_j2g_dyn_A_const_34 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[298]); A_arbace_j2g_dyn_A_const_35 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[299]); A_arbace_j2g_dyn_A_const_36 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[300]) }

func A_arbace_j2g_dyn_A_clinit_p3() { A_arbace_j2g_dyn_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[301]); A_arbace_j2g_dyn_A_const_38 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[302]); A_arbace_j2g_dyn_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[303]); A_arbace_j2g_dyn_A_const_40 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[304]); A_arbace_j2g_dyn_A_const_41 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[305]); A_arbace_j2g_dyn_A_const_42 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[306]); A_arbace_j2g_dyn_A_const_43 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[307]); A_arbace_j2g_dyn_A_const_44 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[308]); A_arbace_j2g_dyn_A_const_45 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[309]); A_arbace_j2g_dyn_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[310]); A_arbace_j2g_dyn_A_const_47 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[311]); A_arbace_j2g_dyn_A_const_48 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[312]) }

func A_arbace_j2g_dyn_A_clinit_p4() { A_arbace_j2g_dyn_A_const_49 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[313]); A_arbace_j2g_dyn_A_const_50 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[314]); A_arbace_j2g_dyn_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[315]); A_arbace_j2g_dyn_A_const_52 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[316]); A_arbace_j2g_dyn_A_const_53 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[317]); A_arbace_j2g_dyn_A_const_54 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[318]); A_arbace_j2g_dyn_A_const_55 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[319]); A_arbace_j2g_dyn_A_const_56 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[320]); A_arbace_j2g_dyn_A_const_57 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[321]); A_arbace_j2g_dyn_A_const_58 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[322]); A_arbace_j2g_dyn_A_const_59 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[323]); A_arbace_j2g_dyn_A_const_60 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[324]) }

func A_arbace_j2g_dyn_A_clinit_p5() { A_arbace_j2g_dyn_A_const_61 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[325]); A_arbace_j2g_dyn_A_const_62 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[326]); A_arbace_j2g_dyn_A_const_63 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[327]); A_arbace_j2g_dyn_A_const_64 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[328]); A_arbace_j2g_dyn_A_const_65 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[329]); A_arbace_j2g_dyn_A_const_66 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[330]); A_arbace_j2g_dyn_A_const_67 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[331]); A_arbace_j2g_dyn_A_const_68 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[332]); A_arbace_j2g_dyn_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[333]); A_arbace_j2g_dyn_A_const_70 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[334]); A_arbace_j2g_dyn_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[335]); A_arbace_j2g_dyn_A_const_72 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[336]) }

func A_arbace_j2g_dyn_A_clinit_p6() { A_arbace_j2g_dyn_A_const_73 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[337]); A_arbace_j2g_dyn_A_const_74 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[338]); A_arbace_j2g_dyn_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[339]); A_arbace_j2g_dyn_A_const_76 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[340]); A_arbace_j2g_dyn_A_const_77 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[341]); A_arbace_j2g_dyn_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[342]); A_arbace_j2g_dyn_A_const_79 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[343]); A_arbace_j2g_dyn_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[344]); A_arbace_j2g_dyn_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[345]); A_arbace_j2g_dyn_A_const_82 = A_arbace_j2g_dyn_A_const_pool.A[346]; A_arbace_j2g_dyn_A_const_83 = A_arbace_j2g_dyn_A_const_pool.A[347]; A_arbace_j2g_dyn_A_const_84 = A_arbace_j2g_dyn_A_const_pool.A[348] }

func A_arbace_j2g_dyn_A_clinit_p7() { A_arbace_j2g_dyn_A_const_85 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[349]); A_arbace_j2g_dyn_A_const_86 = A_arbace_j2g_dyn_A_const_pool.A[350]; A_arbace_j2g_dyn_A_const_87 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[351]); A_arbace_j2g_dyn_A_const_88 = A_arbace_j2g_dyn_A_const_pool.A[352]; A_arbace_j2g_dyn_A_const_89 = A_arbace_j2g_dyn_A_const_pool.A[353]; A_arbace_j2g_dyn_A_const_90 = A_arbace_j2g_dyn_A_const_pool.A[354]; A_arbace_j2g_dyn_A_const_91 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[355]); A_arbace_j2g_dyn_A_const_92 = A_arbace_j2g_dyn_A_const_pool.A[356]; A_arbace_j2g_dyn_A_const_93 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[357]); A_arbace_j2g_dyn_A_const_94 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[358]); A_arbace_j2g_dyn_A_const_95 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[359]); A_arbace_j2g_dyn_A_const_96 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[360]); A_arbace_j2g_dyn_A_const_97 = A_arbace_j2g_dyn_A_const_pool.A[361] }

func A_arbace_j2g_dyn_A_clinit_p8() { A_arbace_j2g_dyn_A_const_98 = A_arbace_j2g_dyn_A_const_pool.A[362]; A_arbace_j2g_dyn_A_const_99 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[363]); A_arbace_j2g_dyn_A_const_100 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[364]); A_arbace_j2g_dyn_A_const_101 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[365]); A_arbace_j2g_dyn_A_const_102 = A_arbace_j2g_dyn_A_const_pool.A[366]; A_arbace_j2g_dyn_A_const_103 = A_arbace_j2g_dyn_A_const_pool.A[367]; A_arbace_j2g_dyn_A_const_104 = A_arbace_j2g_dyn_A_const_pool.A[368]; A_arbace_j2g_dyn_A_const_105 = A_arbace_j2g_dyn_A_const_pool.A[369]; A_arbace_j2g_dyn_A_const_106 = A_arbace_j2g_dyn_A_const_pool.A[370]; A_arbace_j2g_dyn_A_const_107 = A_arbace_j2g_dyn_A_const_pool.A[371]; A_arbace_j2g_dyn_A_const_108 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[372]); A_arbace_j2g_dyn_A_const_109 = A_arbace_j2g_dyn_A_const_pool.A[373]; A_arbace_j2g_dyn_A_const_110 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[374]); A_arbace_j2g_dyn_A_const_111 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[375]) }

func A_arbace_j2g_dyn_A_clinit_p9() { A_arbace_j2g_dyn_A_const_112 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[376]); A_arbace_j2g_dyn_A_const_113 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[377]); A_arbace_j2g_dyn_A_const_114 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[378]); A_arbace_j2g_dyn_A_const_115 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[379]); A_arbace_j2g_dyn_A_const_116 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[380]); A_arbace_j2g_dyn_A_const_117 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[381]); A_arbace_j2g_dyn_A_const_118 = A_arbace_j2g_dyn_A_const_pool.A[382]; A_arbace_j2g_dyn_A_const_119 = A_arbace_j2g_dyn_A_const_pool.A[383]; A_arbace_j2g_dyn_A_const_120 = A_arbace_j2g_dyn_A_const_pool.A[384]; A_arbace_j2g_dyn_A_const_121 = A_arbace_j2g_dyn_A_const_pool.A[385]; A_arbace_j2g_dyn_A_const_122 = A_arbace_j2g_dyn_A_const_pool.A[386]; A_arbace_j2g_dyn_A_const_123 = A_arbace_j2g_dyn_A_const_pool.A[387]; A_arbace_j2g_dyn_A_const_124 = A_arbace_j2g_dyn_A_const_pool.A[388]; A_arbace_j2g_dyn_A_const_125 = A_arbace_j2g_dyn_A_const_pool.A[389] }

func A_arbace_j2g_dyn_A_clinit_p10() { A_arbace_j2g_dyn_A_const_126 = A_arbace_j2g_dyn_A_const_pool.A[390]; A_arbace_j2g_dyn_A_const_127 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[391]); A_arbace_j2g_dyn_A_const_128 = A_arbace_j2g_dyn_A_const_pool.A[392]; A_arbace_j2g_dyn_A_const_129 = A_arbace_j2g_dyn_A_const_pool.A[393]; A_arbace_j2g_dyn_A_const_130 = A_arbace_j2g_dyn_A_const_pool.A[394]; A_arbace_j2g_dyn_A_const_131 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[395]); A_arbace_j2g_dyn_A_const_132 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[396]); A_arbace_j2g_dyn_A_const_133 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[397]); A_arbace_j2g_dyn_A_const_134 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[398]); A_arbace_j2g_dyn_A_const_135 = A_arbace_j2g_dyn_A_const_pool.A[399]; A_arbace_j2g_dyn_A_const_136 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[400]); A_arbace_j2g_dyn_A_const_137 = A_arbace_j2g_dyn_A_const_pool.A[401]; A_arbace_j2g_dyn_A_const_138 = A_arbace_j2g_dyn_A_const_pool.A[402]; A_arbace_j2g_dyn_A_const_139 = A_arbace_j2g_dyn_A_const_pool.A[403] }

func A_arbace_j2g_dyn_A_clinit_p11() { A_arbace_j2g_dyn_A_const_140 = A_arbace_j2g_dyn_A_const_pool.A[404]; A_arbace_j2g_dyn_A_const_141 = A_arbace_j2g_dyn_A_const_pool.A[405]; A_arbace_j2g_dyn_A_const_142 = A_arbace_j2g_dyn_A_const_pool.A[406]; A_arbace_j2g_dyn_A_const_143 = A_arbace_j2g_dyn_A_const_pool.A[407]; A_arbace_j2g_dyn_A_const_144 = A_arbace_j2g_dyn_A_const_pool.A[408]; A_arbace_j2g_dyn_A_const_145 = A_arbace_j2g_dyn_A_const_pool.A[409]; A_arbace_j2g_dyn_A_const_146 = A_arbace_j2g_dyn_A_const_pool.A[410]; A_arbace_j2g_dyn_A_const_147 = A_arbace_j2g_dyn_A_const_pool.A[411]; A_arbace_j2g_dyn_A_const_148 = A_arbace_j2g_dyn_A_const_pool.A[412]; A_arbace_j2g_dyn_A_const_149 = A_arbace_j2g_dyn_A_const_pool.A[413]; A_arbace_j2g_dyn_A_const_150 = A_arbace_j2g_dyn_A_const_pool.A[414]; A_arbace_j2g_dyn_A_const_151 = A_arbace_j2g_dyn_A_const_pool.A[415]; A_arbace_j2g_dyn_A_const_152 = A_arbace_j2g_dyn_A_const_pool.A[416]; A_arbace_j2g_dyn_A_const_153 = A_arbace_j2g_dyn_A_const_pool.A[417]; A_arbace_j2g_dyn_A_const_154 = A_arbace_j2g_dyn_A_const_pool.A[418] }

func A_arbace_j2g_dyn_A_clinit_p12() { A_arbace_j2g_dyn_A_const_155 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[419]); A_arbace_j2g_dyn_A_const_156 = A_arbace_j2g_dyn_A_const_pool.A[420]; A_arbace_j2g_dyn_A_const_157 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[421]); A_arbace_j2g_dyn_A_const_158 = A_arbace_j2g_dyn_A_const_pool.A[422]; A_arbace_j2g_dyn_A_const_159 = A_arbace_j2g_dyn_A_const_pool.A[423]; A_arbace_j2g_dyn_A_const_160 = A_arbace_j2g_dyn_A_const_pool.A[424]; A_arbace_j2g_dyn_A_const_161 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[425]); A_arbace_j2g_dyn_A_const_162 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[426]); A_arbace_j2g_dyn_A_const_163 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[427]); A_arbace_j2g_dyn_A_const_164 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[428]); A_arbace_j2g_dyn_A_const_165 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[429]); A_arbace_j2g_dyn_A_const_166 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[430]); A_arbace_j2g_dyn_A_const_167 = A_arbace_j2g_dyn_A_const_pool.A[431] }

func A_arbace_j2g_dyn_A_clinit_p13() { A_arbace_j2g_dyn_A_const_168 = A_arbace_j2g_dyn_A_const_pool.A[432]; A_arbace_j2g_dyn_A_const_169 = A_arbace_j2g_dyn_A_const_pool.A[433]; A_arbace_j2g_dyn_A_const_170 = A_arbace_j2g_dyn_A_const_pool.A[434]; A_arbace_j2g_dyn_A_const_171 = A_arbace_j2g_dyn_A_const_pool.A[435]; A_arbace_j2g_dyn_A_const_172 = A_arbace_j2g_dyn_A_const_pool.A[436]; A_arbace_j2g_dyn_A_const_173 = A_arbace_j2g_dyn_A_const_pool.A[437]; A_arbace_j2g_dyn_A_const_174 = A_arbace_j2g_dyn_A_const_pool.A[438]; A_arbace_j2g_dyn_A_const_175 = A_arbace_j2g_dyn_A_const_pool.A[439]; A_arbace_j2g_dyn_A_const_176 = A_arbace_j2g_dyn_A_const_pool.A[440]; A_arbace_j2g_dyn_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[441]); A_arbace_j2g_dyn_A_const_178 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[442]); A_arbace_j2g_dyn_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[443]); A_arbace_j2g_dyn_A_const_180 = A_arbace_j2g_dyn_A_const_pool.A[444]; A_arbace_j2g_dyn_A_const_181 = A_arbace_j2g_dyn_A_const_pool.A[445]; A_arbace_j2g_dyn_A_const_182 = A_arbace_j2g_dyn_A_const_pool.A[446] }

func A_arbace_j2g_dyn_A_clinit_p14() { A_arbace_j2g_dyn_A_const_183 = A_arbace_j2g_dyn_A_const_pool.A[447]; A_arbace_j2g_dyn_A_const_184 = A_arbace_j2g_dyn_A_const_pool.A[448]; A_arbace_j2g_dyn_A_const_185 = A_arbace_j2g_dyn_A_const_pool.A[449]; A_arbace_j2g_dyn_A_const_186 = A_arbace_j2g_dyn_A_const_pool.A[450]; A_arbace_j2g_dyn_A_const_187 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[451]); A_arbace_j2g_dyn_A_const_188 = A_arbace_j2g_dyn_A_const_pool.A[452]; A_arbace_j2g_dyn_A_const_189 = A_arbace_j2g_dyn_A_const_pool.A[453]; A_arbace_j2g_dyn_A_const_190 = A_arbace_j2g_dyn_A_const_pool.A[454]; A_arbace_j2g_dyn_A_const_191 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[455]); A_arbace_j2g_dyn_A_const_192 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[456]); A_arbace_j2g_dyn_A_const_193 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[457]); A_arbace_j2g_dyn_A_const_194 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[458]); A_arbace_j2g_dyn_A_const_195 = A_arbace_j2g_dyn_A_const_pool.A[459]; A_arbace_j2g_dyn_A_const_196 = A_arbace_j2g_dyn_A_const_pool.A[460] }

func A_arbace_j2g_dyn_A_clinit_p15() { A_arbace_j2g_dyn_A_const_197 = A_arbace_j2g_dyn_A_const_pool.A[461]; A_arbace_j2g_dyn_A_const_198 = A_arbace_j2g_dyn_A_const_pool.A[462]; A_arbace_j2g_dyn_A_const_199 = A_arbace_j2g_dyn_A_const_pool.A[463]; A_arbace_j2g_dyn_A_const_200 = A_arbace_j2g_dyn_A_const_pool.A[464]; A_arbace_j2g_dyn_A_const_201 = A_arbace_j2g_dyn_A_const_pool.A[465]; A_arbace_j2g_dyn_A_const_202 = A_arbace_j2g_dyn_A_const_pool.A[466]; A_arbace_j2g_dyn_A_const_203 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[467]); A_arbace_j2g_dyn_A_const_204 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[468]); A_arbace_j2g_dyn_A_const_205 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[469]); A_arbace_j2g_dyn_A_const_206 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[470]); A_arbace_j2g_dyn_A_const_207 = A_arbace_j2g_dyn_A_const_pool.A[471]; A_arbace_j2g_dyn_A_const_208 = A_arbace_j2g_dyn_A_const_pool.A[472]; A_arbace_j2g_dyn_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[473]); A_arbace_j2g_dyn_A_const_210 = A_arbace_j2g_dyn_A_const_pool.A[474] }

func A_arbace_j2g_dyn_A_clinit_p16() { A_arbace_j2g_dyn_A_const_211 = A_arbace_j2g_dyn_A_const_pool.A[475]; A_arbace_j2g_dyn_A_const_212 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[476]); A_arbace_j2g_dyn_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[477]); A_arbace_j2g_dyn_A_const_214 = A_arbace_j2g_dyn_A_const_pool.A[478]; A_arbace_j2g_dyn_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[479]); A_arbace_j2g_dyn_A_const_216 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[480]); A_arbace_j2g_dyn_A_const_217 = A_arbace_j2g_dyn_A_const_pool.A[481]; A_arbace_j2g_dyn_A_const_218 = A_arbace_j2g_dyn_A_const_pool.A[482]; A_arbace_j2g_dyn_A_const_219 = A_arbace_j2g_dyn_A_const_pool.A[483]; A_arbace_j2g_dyn_A_const_220 = A_arbace_j2g_dyn_A_const_pool.A[484]; A_arbace_j2g_dyn_A_const_221 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[485]); A_arbace_j2g_dyn_A_const_222 = A_arbace_j2g_dyn_A_const_pool.A[486]; A_arbace_j2g_dyn_A_const_223 = A_arbace_j2g_dyn_A_const_pool.A[487]; A_arbace_j2g_dyn_A_const_224 = A_arbace_j2g_dyn_A_const_pool.A[488] }

func A_arbace_j2g_dyn_A_clinit_p17() { A_arbace_j2g_dyn_A_const_225 = A_arbace_j2g_dyn_A_const_pool.A[489]; A_arbace_j2g_dyn_A_const_226 = A_arbace_j2g_dyn_A_const_pool.A[490]; A_arbace_j2g_dyn_A_const_227 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[491]); A_arbace_j2g_dyn_A_const_228 = A_arbace_j2g_dyn_A_const_pool.A[492]; A_arbace_j2g_dyn_A_const_229 = A_arbace_j2g_dyn_A_const_pool.A[493]; A_arbace_j2g_dyn_A_const_230 = A_arbace_j2g_dyn_A_const_pool.A[494]; A_arbace_j2g_dyn_A_const_231 = A_arbace_j2g_dyn_A_const_pool.A[495]; A_arbace_j2g_dyn_A_const_232 = A_arbace_j2g_dyn_A_const_pool.A[496]; A_arbace_j2g_dyn_A_const_233 = A_arbace_j2g_dyn_A_const_pool.A[497]; A_arbace_j2g_dyn_A_const_234 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[498]); A_arbace_j2g_dyn_A_const_235 = A_arbace_j2g_dyn_A_const_pool.A[499]; A_arbace_j2g_dyn_A_const_236 = A_arbace_j2g_dyn_A_const_pool.A[500]; A_arbace_j2g_dyn_A_const_237 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[501]); A_arbace_j2g_dyn_A_const_238 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[502]) }

func A_arbace_j2g_dyn_A_clinit_p18() { A_arbace_j2g_dyn_A_const_239 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[503]); A_arbace_j2g_dyn_A_const_240 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[504]); A_arbace_j2g_dyn_A_const_241 = A_arbace_j2g_dyn_A_const_pool.A[505]; A_arbace_j2g_dyn_A_const_242 = A_arbace_j2g_dyn_A_const_pool.A[506]; A_arbace_j2g_dyn_A_const_243 = A_arbace_j2g_dyn_A_const_pool.A[507]; A_arbace_j2g_dyn_A_const_244 = A_arbace_j2g_dyn_A_const_pool.A[508]; A_arbace_j2g_dyn_A_const_245 = A_arbace_j2g_dyn_A_const_pool.A[509]; A_arbace_j2g_dyn_A_const_246 = A_arbace_j2g_dyn_A_const_pool.A[510]; A_arbace_j2g_dyn_A_const_247 = A_arbace_j2g_dyn_A_const_pool.A[511]; A_arbace_j2g_dyn_A_const_248 = A_arbace_j2g_dyn_A_const_pool.A[512]; A_arbace_j2g_dyn_A_const_249 = A_arbace_j2g_dyn_A_const_pool.A[513]; A_arbace_j2g_dyn_A_const_250 = A_arbace_j2g_dyn_A_const_pool.A[514]; A_arbace_j2g_dyn_A_const_251 = A_arbace_j2g_dyn_A_const_pool.A[515]; A_arbace_j2g_dyn_A_const_252 = A_arbace_j2g_dyn_A_const_pool.A[516]; A_arbace_j2g_dyn_A_const_253 = A_arbace_j2g_dyn_A_const_pool.A[517] }

func A_arbace_j2g_dyn_A_clinit_p19() { A_arbace_j2g_dyn_A_const_254 = A_arbace_j2g_dyn_A_const_pool.A[518]; A_arbace_j2g_dyn_A_const_255 = A_arbace_j2g_dyn_A_const_pool.A[519]; A_arbace_j2g_dyn_A_const_256 = A_arbace_j2g_dyn_A_const_pool.A[520]; A_arbace_j2g_dyn_A_const_257 = A_arbace_j2g_dyn_A_const_pool.A[521]; A_arbace_j2g_dyn_A_const_258 = A_arbace_j2g_dyn_A_const_pool.A[522]; A_arbace_j2g_dyn_A_const_259 = A_arbace_j2g_dyn_A_const_pool.A[523]; A_arbace_j2g_dyn_A_const_260 = A_arbace_j2g_dyn_A_const_pool.A[524]; A_arbace_j2g_dyn_A_const_261 = A_arbace_j2g_dyn_A_const_pool.A[525]; A_arbace_j2g_dyn_A_const_262 = A_arbace_j2g_dyn_A_const_pool.A[526]; A_arbace_j2g_dyn_A_const_263 = A_arbace_j2g_dyn_A_const_pool.A[527]; A_arbace_j2g_dyn_A_const_264 = A_arbace_j2g_dyn_A_const_pool.A[528]; A_arbace_j2g_dyn_A_const_265 = A_arbace_j2g_dyn_A_const_pool.A[529]; A_arbace_j2g_dyn_A_const_266 = A_arbace_j2g_dyn_A_const_pool.A[530]; A_arbace_j2g_dyn_A_const_267 = A_arbace_j2g_dyn_A_const_pool.A[531]; A_arbace_j2g_dyn_A_const_268 = A_arbace_j2g_dyn_A_const_pool.A[532]; A_arbace_j2g_dyn_A_const_269 = A_arbace_j2g_dyn_A_const_pool.A[533] }

func A_arbace_j2g_dyn_A_clinit_p20() { A_arbace_j2g_dyn_A_const_270 = A_arbace_j2g_dyn_A_const_pool.A[534]; A_arbace_j2g_dyn_A_const_271 = A_arbace_j2g_dyn_A_const_pool.A[535]; A_arbace_j2g_dyn_A_const_272 = A_arbace_j2g_dyn_A_const_pool.A[536]; A_arbace_j2g_dyn_A_const_273 = A_arbace_j2g_dyn_A_const_pool.A[537]; A_arbace_j2g_dyn_A_const_274 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[538]); A_arbace_j2g_dyn_A_const_275 = A_arbace_j2g_dyn_A_const_pool.A[539]; A_arbace_j2g_dyn_A_const_276 = A_arbace_j2g_dyn_A_const_pool.A[540]; A_arbace_j2g_dyn_A_const_277 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[541]); A_arbace_j2g_dyn_A_const_278 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[542]); A_arbace_j2g_dyn_A_const_279 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[543]); A_arbace_j2g_dyn_A_const_280 = A_arbace_j2g_dyn_A_const_pool.A[544]; A_arbace_j2g_dyn_A_const_281 = A_arbace_j2g_dyn_A_const_pool.A[545]; A_arbace_j2g_dyn_A_const_282 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[546]); A_arbace_j2g_dyn_A_const_283 = A_arbace_j2g_dyn_A_const_pool.A[547] }

func A_arbace_j2g_dyn_A_clinit_p21() { A_arbace_j2g_dyn_A_const_284 = A_arbace_j2g_dyn_A_const_pool.A[548]; A_arbace_j2g_dyn_A_const_285 = A_arbace_j2g_dyn_A_const_pool.A[549]; A_arbace_j2g_dyn_A_const_286 = A_arbace_j2g_dyn_A_const_pool.A[550]; A_arbace_j2g_dyn_A_const_287 = A_arbace_j2g_dyn_A_const_pool.A[551]; A_arbace_j2g_dyn_A_const_288 = A_arbace_j2g_dyn_A_const_pool.A[552]; A_arbace_j2g_dyn_A_const_289 = A_arbace_j2g_dyn_A_const_pool.A[553]; A_arbace_j2g_dyn_A_const_290 = A_arbace_j2g_dyn_A_const_pool.A[554]; A_arbace_j2g_dyn_A_const_291 = A_arbace_j2g_dyn_A_const_pool.A[555]; A_arbace_j2g_dyn_A_const_292 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[556]); A_arbace_j2g_dyn_A_const_293 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[557]); A_arbace_j2g_dyn_A_const_294 = A_arbace_j2g_dyn_A_const_pool.A[558]; A_arbace_j2g_dyn_A_const_295 = A_arbace_j2g_dyn_A_const_pool.A[559]; A_arbace_j2g_dyn_A_const_296 = A_arbace_j2g_dyn_A_const_pool.A[560]; A_arbace_j2g_dyn_A_const_297 = A_arbace_j2g_dyn_A_const_pool.A[561]; A_arbace_j2g_dyn_A_const_298 = A_arbace_j2g_dyn_A_const_pool.A[562] }

func A_arbace_j2g_dyn_A_clinit_p22() { A_arbace_j2g_dyn_A_const_299 = A_arbace_j2g_dyn_A_const_pool.A[563]; A_arbace_j2g_dyn_A_const_300 = A_arbace_j2g_dyn_A_const_pool.A[564]; A_arbace_j2g_dyn_A_const_301 = A_arbace_j2g_dyn_A_const_pool.A[565]; A_arbace_j2g_dyn_A_const_302 = A_arbace_j2g_dyn_A_const_pool.A[566]; A_arbace_j2g_dyn_A_const_303 = A_arbace_j2g_dyn_A_const_pool.A[567]; A_arbace_j2g_dyn_A_const_304 = A_arbace_j2g_dyn_A_const_pool.A[568]; A_arbace_j2g_dyn_A_const_305 = A_arbace_j2g_dyn_A_const_pool.A[569]; A_arbace_j2g_dyn_A_const_306 = A_arbace_j2g_dyn_A_const_pool.A[570]; A_arbace_j2g_dyn_A_const_307 = A_arbace_j2g_dyn_A_const_pool.A[571]; A_arbace_j2g_dyn_A_const_308 = A_arbace_j2g_dyn_A_const_pool.A[572]; A_arbace_j2g_dyn_A_const_309 = A_arbace_j2g_dyn_A_const_pool.A[573]; A_arbace_j2g_dyn_A_const_310 = A_arbace_j2g_dyn_A_const_pool.A[574]; A_arbace_j2g_dyn_A_const_311 = A_arbace_j2g_dyn_A_const_pool.A[575]; A_arbace_j2g_dyn_A_const_312 = A_arbace_j2g_dyn_A_const_pool.A[576]; A_arbace_j2g_dyn_A_const_313 = A_arbace_j2g_dyn_A_const_pool.A[577]; A_arbace_j2g_dyn_A_const_314 = A_arbace_j2g_dyn_A_const_pool.A[578] }

func A_arbace_j2g_dyn_A_clinit_p23() { A_arbace_j2g_dyn_A_const_315 = A_arbace_j2g_dyn_A_const_pool.A[579]; A_arbace_j2g_dyn_A_const_316 = A_arbace_j2g_dyn_A_const_pool.A[580]; A_arbace_j2g_dyn_A_const_317 = A_arbace_j2g_dyn_A_const_pool.A[581]; A_arbace_j2g_dyn_A_const_318 = A_arbace_j2g_dyn_A_const_pool.A[582]; A_arbace_j2g_dyn_A_const_319 = A_arbace_j2g_dyn_A_const_pool.A[583]; A_arbace_j2g_dyn_A_const_320 = A_arbace_j2g_dyn_A_const_pool.A[584]; A_arbace_j2g_dyn_A_const_321 = A_arbace_j2g_dyn_A_const_pool.A[585]; A_arbace_j2g_dyn_A_const_322 = A_arbace_j2g_dyn_A_const_pool.A[586]; A_arbace_j2g_dyn_A_const_323 = A_arbace_j2g_dyn_A_const_pool.A[587]; A_arbace_j2g_dyn_A_const_324 = A_arbace_j2g_dyn_A_const_pool.A[588]; A_arbace_j2g_dyn_A_const_325 = A_arbace_j2g_dyn_A_const_pool.A[589]; A_arbace_j2g_dyn_A_const_326 = A_arbace_j2g_dyn_A_const_pool.A[590]; A_arbace_j2g_dyn_A_const_327 = A_arbace_j2g_dyn_A_const_pool.A[591]; A_arbace_j2g_dyn_A_const_328 = A_arbace_j2g_dyn_A_const_pool.A[592]; A_arbace_j2g_dyn_A_const_329 = A_arbace_j2g_dyn_A_const_pool.A[593]; A_arbace_j2g_dyn_A_const_330 = A_arbace_j2g_dyn_A_const_pool.A[594] }

func A_arbace_j2g_dyn_A_clinit_p24() { A_arbace_j2g_dyn_A_const_331 = A_arbace_j2g_dyn_A_const_pool.A[595]; A_arbace_j2g_dyn_A_const_332 = A_arbace_j2g_dyn_A_const_pool.A[596]; A_arbace_j2g_dyn_A_const_333 = A_arbace_j2g_dyn_A_const_pool.A[597]; A_arbace_j2g_dyn_A_const_334 = A_arbace_j2g_dyn_A_const_pool.A[598]; A_arbace_j2g_dyn_A_const_335 = A_arbace_j2g_dyn_A_const_pool.A[599]; A_arbace_j2g_dyn_A_const_336 = A_arbace_j2g_dyn_A_const_pool.A[600]; A_arbace_j2g_dyn_A_const_337 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[601]); A_arbace_j2g_dyn_A_const_338 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[602]); A_arbace_j2g_dyn_A_const_339 = A_arbace_j2g_dyn_A_const_pool.A[603]; A_arbace_j2g_dyn_A_const_340 = A_arbace_j2g_dyn_A_const_pool.A[604]; A_arbace_j2g_dyn_A_const_341 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[605]); A_arbace_j2g_dyn_A_const_342 = A_arbace_j2g_dyn_A_const_pool.A[606]; A_arbace_j2g_dyn_A_const_343 = A_arbace_j2g_dyn_A_const_pool.A[607]; A_arbace_j2g_dyn_A_const_344 = A_arbace_j2g_dyn_A_const_pool.A[608] }

func A_arbace_j2g_dyn_A_clinit_p25() { A_arbace_j2g_dyn_A_const_345 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[609]); A_arbace_j2g_dyn_A_const_346 = A_arbace_j2g_dyn_A_const_pool.A[610]; A_arbace_j2g_dyn_A_const_347 = A_arbace_j2g_dyn_A_const_pool.A[611]; A_arbace_j2g_dyn_A_const_348 = A_arbace_j2g_dyn_A_const_pool.A[612]; A_arbace_j2g_dyn_A_const_349 = A_arbace_j2g_dyn_A_const_pool.A[613]; A_arbace_j2g_dyn_A_const_350 = A_arbace_j2g_dyn_A_const_pool.A[614]; A_arbace_j2g_dyn_A_const_351 = A_arbace_j2g_dyn_A_const_pool.A[615]; A_arbace_j2g_dyn_A_const_352 = A_arbace_j2g_dyn_A_const_pool.A[616]; A_arbace_j2g_dyn_A_const_353 = A_arbace_j2g_dyn_A_const_pool.A[617]; A_arbace_j2g_dyn_A_const_354 = A_arbace_j2g_dyn_A_const_pool.A[618]; A_arbace_j2g_dyn_A_const_355 = A_arbace_j2g_dyn_A_const_pool.A[619]; A_arbace_j2g_dyn_A_const_356 = A_arbace_j2g_dyn_A_const_pool.A[620]; A_arbace_j2g_dyn_A_const_357 = A_arbace_j2g_dyn_A_const_pool.A[621]; A_arbace_j2g_dyn_A_const_358 = A_arbace_j2g_dyn_A_const_pool.A[622]; A_arbace_j2g_dyn_A_const_359 = A_arbace_j2g_dyn_A_const_pool.A[623] }

func A_arbace_j2g_dyn_A_clinit_p26() { A_arbace_j2g_dyn_A_const_360 = A_arbace_j2g_dyn_A_const_pool.A[624]; A_arbace_j2g_dyn_A_const_361 = A_arbace_j2g_dyn_A_const_pool.A[625]; A_arbace_j2g_dyn_A_const_362 = A_arbace_j2g_dyn_A_const_pool.A[626]; A_arbace_j2g_dyn_A_const_363 = A_arbace_j2g_dyn_A_const_pool.A[627]; A_arbace_j2g_dyn_A_const_364 = A_arbace_j2g_dyn_A_const_pool.A[628]; A_arbace_j2g_dyn_A_const_365 = A_arbace_j2g_dyn_A_const_pool.A[629]; A_arbace_j2g_dyn_A_const_366 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[630]); A_arbace_j2g_dyn_A_const_367 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[631]); A_arbace_j2g_dyn_A_const_368 = A_arbace_j2g_dyn_A_const_pool.A[632]; A_arbace_j2g_dyn_A_const_369 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[633]); A_arbace_j2g_dyn_A_const_370 = A_arbace_j2g_dyn_A_const_pool.A[634]; A_arbace_j2g_dyn_A_const_371 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[635]); A_arbace_j2g_dyn_A_const_372 = A_arbace_j2g_dyn_A_const_pool.A[636]; A_arbace_j2g_dyn_A_const_373 = A_arbace_j2g_dyn_A_const_pool.A[637] }

func A_arbace_j2g_dyn_A_clinit_p27() { A_arbace_j2g_dyn_A_const_374 = A_arbace_j2g_dyn_A_const_pool.A[638]; A_arbace_j2g_dyn_A_const_375 = A_arbace_j2g_dyn_A_const_pool.A[639]; A_arbace_j2g_dyn_A_const_376 = A_arbace_j2g_dyn_A_const_pool.A[640]; A_arbace_j2g_dyn_A_const_377 = A_arbace_j2g_dyn_A_const_pool.A[641]; A_arbace_j2g_dyn_A_const_378 = A_arbace_j2g_dyn_A_const_pool.A[642]; A_arbace_j2g_dyn_A_const_379 = A_arbace_j2g_dyn_A_const_pool.A[643]; A_arbace_j2g_dyn_A_const_380 = A_arbace_j2g_dyn_A_const_pool.A[644]; A_arbace_j2g_dyn_A_const_381 = A_arbace_j2g_dyn_A_const_pool.A[645]; A_arbace_j2g_dyn_A_const_382 = A_arbace_j2g_dyn_A_const_pool.A[646]; A_arbace_j2g_dyn_A_const_383 = A_arbace_j2g_dyn_A_const_pool.A[647]; A_arbace_j2g_dyn_A_const_384 = A_arbace_j2g_dyn_A_const_pool.A[648]; A_arbace_j2g_dyn_A_const_385 = A_arbace_j2g_dyn_A_const_pool.A[649]; A_arbace_j2g_dyn_A_const_386 = A_arbace_j2g_dyn_A_const_pool.A[650]; A_arbace_j2g_dyn_A_const_387 = A_arbace_j2g_dyn_A_const_pool.A[651]; A_arbace_j2g_dyn_A_const_388 = A_arbace_j2g_dyn_A_const_pool.A[652]; A_arbace_j2g_dyn_A_const_389 = A_arbace_j2g_dyn_A_const_pool.A[653] }

func A_arbace_j2g_dyn_A_clinit_p28() { A_arbace_j2g_dyn_A_const_390 = A_arbace_j2g_dyn_A_const_pool.A[654]; A_arbace_j2g_dyn_A_const_391 = A_arbace_j2g_dyn_A_const_pool.A[655]; A_arbace_j2g_dyn_A_const_392 = A_arbace_j2g_dyn_A_const_pool.A[656]; A_arbace_j2g_dyn_A_const_393 = A_arbace_j2g_dyn_A_const_pool.A[657]; A_arbace_j2g_dyn_A_const_394 = A_arbace_j2g_dyn_A_const_pool.A[658]; A_arbace_j2g_dyn_A_const_395 = A_arbace_j2g_dyn_A_const_pool.A[659]; A_arbace_j2g_dyn_A_const_396 = A_arbace_j2g_dyn_A_const_pool.A[660]; A_arbace_j2g_dyn_A_const_397 = A_arbace_j2g_dyn_A_const_pool.A[661]; A_arbace_j2g_dyn_A_const_398 = A_arbace_j2g_dyn_A_const_pool.A[662]; A_arbace_j2g_dyn_A_const_399 = A_arbace_j2g_dyn_A_const_pool.A[663]; A_arbace_j2g_dyn_A_const_400 = A_arbace_j2g_dyn_A_const_pool.A[664]; A_arbace_j2g_dyn_A_const_401 = A_arbace_j2g_dyn_A_const_pool.A[665]; A_arbace_j2g_dyn_A_const_402 = A_arbace_j2g_dyn_A_const_pool.A[666]; A_arbace_j2g_dyn_A_const_403 = A_arbace_j2g_dyn_A_const_pool.A[667]; A_arbace_j2g_dyn_A_const_404 = A_arbace_j2g_dyn_A_const_pool.A[668]; A_arbace_j2g_dyn_A_const_405 = A_arbace_j2g_dyn_A_const_pool.A[669] }

func A_arbace_j2g_dyn_A_clinit_p29() { A_arbace_j2g_dyn_A_const_406 = A_arbace_j2g_dyn_A_const_pool.A[670]; A_arbace_j2g_dyn_A_const_407 = A_arbace_j2g_dyn_A_const_pool.A[671]; A_arbace_j2g_dyn_A_const_408 = A_arbace_j2g_dyn_A_const_pool.A[672]; A_arbace_j2g_dyn_A_const_409 = A_arbace_j2g_dyn_A_const_pool.A[673]; A_arbace_j2g_dyn_A_const_410 = A_arbace_j2g_dyn_A_const_pool.A[674]; A_arbace_j2g_dyn_A_const_411 = A_arbace_j2g_dyn_A_const_pool.A[675]; A_arbace_j2g_dyn_A_const_412 = A_arbace_j2g_dyn_A_const_pool.A[676]; A_arbace_j2g_dyn_A_const_413 = A_arbace_j2g_dyn_A_const_pool.A[677]; A_arbace_j2g_dyn_A_const_414 = A_arbace_j2g_dyn_A_const_pool.A[678]; A_arbace_j2g_dyn_A_const_415 = A_arbace_j2g_dyn_A_const_pool.A[679]; A_arbace_j2g_dyn_A_const_416 = A_arbace_j2g_dyn_A_const_pool.A[680]; A_arbace_j2g_dyn_A_const_417 = A_arbace_j2g_dyn_A_const_pool.A[681]; A_arbace_j2g_dyn_A_const_418 = A_arbace_j2g_dyn_A_const_pool.A[682]; A_arbace_j2g_dyn_A_const_419 = A_arbace_j2g_dyn_A_const_pool.A[683]; A_arbace_j2g_dyn_A_const_420 = A_arbace_j2g_dyn_A_const_pool.A[684]; A_arbace_j2g_dyn_A_const_421 = A_arbace_j2g_dyn_A_const_pool.A[685] }

func A_arbace_j2g_dyn_A_clinit_p30() { A_arbace_j2g_dyn_A_const_422 = A_arbace_j2g_dyn_A_const_pool.A[686]; A_arbace_j2g_dyn_A_const_423 = A_arbace_j2g_dyn_A_const_pool.A[687]; A_arbace_j2g_dyn_A_const_424 = A_arbace_j2g_dyn_A_const_pool.A[688]; A_arbace_j2g_dyn_A_const_425 = A_arbace_j2g_dyn_A_const_pool.A[689]; A_arbace_j2g_dyn_A_const_426 = A_arbace_j2g_dyn_A_const_pool.A[690]; A_arbace_j2g_dyn_A_const_427 = A_arbace_j2g_dyn_A_const_pool.A[691]; A_arbace_j2g_dyn_A_const_428 = A_arbace_j2g_dyn_A_const_pool.A[692]; A_arbace_j2g_dyn_A_const_429 = A_arbace_j2g_dyn_A_const_pool.A[693]; A_arbace_j2g_dyn_A_const_430 = A_arbace_j2g_dyn_A_const_pool.A[694]; A_arbace_j2g_dyn_A_const_431 = A_arbace_j2g_dyn_A_const_pool.A[695]; A_arbace_j2g_dyn_A_const_432 = A_arbace_j2g_dyn_A_const_pool.A[696]; A_arbace_j2g_dyn_A_const_433 = A_arbace_j2g_dyn_A_const_pool.A[697]; A_arbace_j2g_dyn_A_const_434 = A_arbace_j2g_dyn_A_const_pool.A[698]; A_arbace_j2g_dyn_A_const_435 = A_arbace_j2g_dyn_A_const_pool.A[699]; A_arbace_j2g_dyn_A_const_436 = A_arbace_j2g_dyn_A_const_pool.A[700]; A_arbace_j2g_dyn_A_const_437 = A_arbace_j2g_dyn_A_const_pool.A[701] }

func A_arbace_j2g_dyn_A_clinit_p31() { A_arbace_j2g_dyn_A_const_438 = A_arbace_j2g_dyn_A_const_pool.A[702]; A_arbace_j2g_dyn_A_const_439 = A_arbace_j2g_dyn_A_const_pool.A[703]; A_arbace_j2g_dyn_A_const_440 = A_arbace_j2g_dyn_A_const_pool.A[704]; A_arbace_j2g_dyn_A_const_441 = A_arbace_j2g_dyn_A_const_pool.A[705]; A_arbace_j2g_dyn_A_const_442 = A_arbace_j2g_dyn_A_const_pool.A[706]; A_arbace_j2g_dyn_A_const_443 = A_arbace_j2g_dyn_A_const_pool.A[707]; A_arbace_j2g_dyn_A_const_444 = A_arbace_j2g_dyn_A_const_pool.A[708]; A_arbace_j2g_dyn_A_const_445 = A_arbace_j2g_dyn_A_const_pool.A[709]; A_arbace_j2g_dyn_A_const_446 = A_arbace_j2g_dyn_A_const_pool.A[710]; A_arbace_j2g_dyn_A_const_447 = A_arbace_j2g_dyn_A_const_pool.A[711]; A_arbace_j2g_dyn_A_const_448 = A_arbace_j2g_dyn_A_const_pool.A[712]; A_arbace_j2g_dyn_A_const_449 = A_arbace_j2g_dyn_A_const_pool.A[713]; A_arbace_j2g_dyn_A_const_450 = A_arbace_j2g_dyn_A_const_pool.A[714]; A_arbace_j2g_dyn_A_const_451 = A_arbace_j2g_dyn_A_const_pool.A[715]; A_arbace_j2g_dyn_A_const_452 = A_arbace_j2g_dyn_A_const_pool.A[716]; A_arbace_j2g_dyn_A_const_453 = A_arbace_j2g_dyn_A_const_pool.A[717] }

func A_arbace_j2g_dyn_A_clinit_p32() { A_arbace_j2g_dyn_A_const_454 = A_arbace_j2g_dyn_A_const_pool.A[718]; A_arbace_j2g_dyn_A_const_455 = A_arbace_j2g_dyn_A_const_pool.A[719]; A_arbace_j2g_dyn_A_const_456 = A_arbace_j2g_dyn_A_const_pool.A[720]; A_arbace_j2g_dyn_A_const_457 = A_arbace_j2g_dyn_A_const_pool.A[721]; A_arbace_j2g_dyn_A_const_458 = A_arbace_j2g_dyn_A_const_pool.A[722]; A_arbace_j2g_dyn_A_const_459 = A_arbace_j2g_dyn_A_const_pool.A[723]; A_arbace_j2g_dyn_A_const_460 = A_arbace_j2g_dyn_A_const_pool.A[724]; A_arbace_j2g_dyn_A_const_461 = A_arbace_j2g_dyn_A_const_pool.A[725]; A_arbace_j2g_dyn_A_const_462 = A_arbace_j2g_dyn_A_const_pool.A[726]; A_arbace_j2g_dyn_A_const_463 = A_arbace_j2g_dyn_A_const_pool.A[727]; A_arbace_j2g_dyn_A_const_464 = A_arbace_j2g_dyn_A_const_pool.A[728]; A_arbace_j2g_dyn_A_const_465 = A_arbace_j2g_dyn_A_const_pool.A[729]; A_arbace_j2g_dyn_A_const_466 = A_arbace_j2g_dyn_A_const_pool.A[730]; A_arbace_j2g_dyn_A_const_467 = A_arbace_j2g_dyn_A_const_pool.A[731]; A_arbace_j2g_dyn_A_const_468 = A_arbace_j2g_dyn_A_const_pool.A[732]; A_arbace_j2g_dyn_A_const_469 = A_arbace_j2g_dyn_A_const_pool.A[733] }

func A_arbace_j2g_dyn_A_clinit_p33() { A_arbace_j2g_dyn_A_const_470 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[734]); A_arbace_j2g_dyn_A_const_471 = A_arbace_j2g_dyn_A_const_pool.A[735]; A_arbace_j2g_dyn_A_const_472 = A_arbace_j2g_dyn_A_const_pool.A[736]; A_arbace_j2g_dyn_A_const_473 = A_arbace_j2g_dyn_A_const_pool.A[737]; A_arbace_j2g_dyn_A_const_474 = A_arbace_j2g_dyn_A_const_pool.A[738]; A_arbace_j2g_dyn_A_const_475 = A_arbace_j2g_dyn_A_const_pool.A[739]; A_arbace_j2g_dyn_A_const_476 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[740]); A_arbace_j2g_dyn_A_const_477 = A_arbace_j2g_dyn_A_const_pool.A[741]; A_arbace_j2g_dyn_A_const_478 = A_arbace_j2g_dyn_A_const_pool.A[742]; A_arbace_j2g_dyn_A_const_479 = A_arbace_j2g_dyn_A_const_pool.A[743]; A_arbace_j2g_dyn_A_const_480 = A_arbace_j2g_dyn_A_const_pool.A[744]; A_arbace_j2g_dyn_A_const_481 = A_arbace_j2g_dyn_A_const_pool.A[745]; A_arbace_j2g_dyn_A_const_482 = A_arbace_j2g_dyn_A_const_pool.A[746]; A_arbace_j2g_dyn_A_const_483 = A_arbace_j2g_dyn_A_const_pool.A[747]; A_arbace_j2g_dyn_A_const_484 = A_arbace_j2g_dyn_A_const_pool.A[748] }

func A_arbace_j2g_dyn_A_clinit_p34() { A_arbace_j2g_dyn_A_const_485 = A_arbace_j2g_dyn_A_const_pool.A[749]; A_arbace_j2g_dyn_A_const_486 = A_arbace_j2g_dyn_A_const_pool.A[750]; A_arbace_j2g_dyn_A_const_487 = A_arbace_j2g_dyn_A_const_pool.A[751]; A_arbace_j2g_dyn_A_const_488 = A_arbace_j2g_dyn_A_const_pool.A[752]; A_arbace_j2g_dyn_A_const_489 = A_arbace_j2g_dyn_A_const_pool.A[753]; A_arbace_j2g_dyn_A_const_490 = A_arbace_j2g_dyn_A_const_pool.A[754]; A_arbace_j2g_dyn_A_const_491 = A_arbace_j2g_dyn_A_const_pool.A[755]; A_arbace_j2g_dyn_A_const_492 = A_arbace_j2g_dyn_A_const_pool.A[756]; A_arbace_j2g_dyn_A_const_493 = A_arbace_j2g_dyn_A_const_pool.A[757]; A_arbace_j2g_dyn_A_const_494 = A_arbace_j2g_dyn_A_const_pool.A[758]; A_arbace_j2g_dyn_A_const_495 = A_arbace_j2g_dyn_A_const_pool.A[759]; A_arbace_j2g_dyn_A_const_496 = A_arbace_j2g_dyn_A_const_pool.A[760]; A_arbace_j2g_dyn_A_const_497 = A_arbace_j2g_dyn_A_const_pool.A[761]; A_arbace_j2g_dyn_A_const_498 = A_arbace_j2g_dyn_A_const_pool.A[762]; A_arbace_j2g_dyn_A_const_499 = A_arbace_j2g_dyn_A_const_pool.A[763]; A_arbace_j2g_dyn_A_const_500 = A_arbace_j2g_dyn_A_const_pool.A[764] }

func A_arbace_j2g_dyn_A_clinit_p35() { A_arbace_j2g_dyn_A_const_501 = A_arbace_j2g_dyn_A_const_pool.A[765]; A_arbace_j2g_dyn_A_const_502 = A_arbace_j2g_dyn_A_const_pool.A[766]; A_arbace_j2g_dyn_A_const_503 = A_arbace_j2g_dyn_A_const_pool.A[767]; A_arbace_j2g_dyn_A_const_504 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[768]); A_arbace_j2g_dyn_A_const_505 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[769]) }

func A_arbace_j2g_dyn_A_New() *A_arbace_j2g_dyn_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_A) Ctor() {}

func (t *A_arbace_j2g_dyn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_A_class }

func (t *A_arbace_j2g_dyn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_A); return ok }

func A_arbace_j2g_dyn_A_Cast(x any) *A_arbace_j2g_dyn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_A_class)) }; return v }



type A_arbace_j2g_dyn_abstract_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_abstract_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_box_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_box_arg_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_call_impl_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_call_impl_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_class_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_ret__711000234_A struct{ j2g_header uint64; F_r any }

var A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A struct{ j2g_header uint64; F_g, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A struct{ j2g_header uint64; F_iter__711000243, F_g, F_s__711000244, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A struct{ j2g_header uint64; F_g, F_n, F_b__711000246, F_arg_conv any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_A struct{ j2g_header uint64; F_ifaces, F_lockee__1927000360__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A struct{ j2g_header uint64; F_j any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A struct{ j2g_header uint64; F_s__711000089, F_iter__711000088 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A struct{ j2g_header uint64; F_iter__711000090, F_s__711000091 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A struct{ j2g_header uint64; F_b__711000093 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_fn__711000118_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A struct{ j2g_header uint64; F_iter__711000107, F_k, F_s__711000108 any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A struct{ j2g_header uint64; F_k, F_b__711000110 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000004_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000004_A_New() *A_arbace_j2g_dyn_eval711000004_A { t := &A_arbace_j2g_dyn_eval711000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000004_A_class }

func (t *A_arbace_j2g_dyn_eval711000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); return ok }

func A_arbace_j2g_dyn_eval711000004_A_Cast(x any) *A_arbace_j2g_dyn_eval711000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000004_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000008_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000008_A_New() *A_arbace_j2g_dyn_eval711000008_A { t := &A_arbace_j2g_dyn_eval711000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000008_A_class }

func (t *A_arbace_j2g_dyn_eval711000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); return ok }

func A_arbace_j2g_dyn_eval711000008_A_Cast(x any) *A_arbace_j2g_dyn_eval711000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000008_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000008_fn__711000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000008_fn__711000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_fn_field_native_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_fn_field_native_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000383_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_fn__711000383_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000414_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000414_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000426_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000426_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000388__711000392_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A struct{ j2g_header uint64; F_iter__711000388, F_s__711000389 any }

var A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A struct{ j2g_header uint64; F_b__711000391 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000404__711000408_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A struct{ j2g_header uint64; F_iter__711000404, F_s__711000405 any }

var A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A struct{ j2g_header uint64; F_b__711000407 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000416__711000420_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A struct{ j2g_header uint64; F_iter__711000416, F_s__711000417 any }

var A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A struct{ j2g_header uint64; F_b__711000419 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A struct{ j2g_header uint64; F_iter__711000270, F_s__711000271 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A struct{ j2g_header uint64; F_s__711000273, F_iter__711000272 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A struct{ j2g_header uint64; F_b__711000275 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A struct{ j2g_header uint64; F_s__711000285, F_iter__711000284 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A struct{ j2g_header uint64; F_b__711000287 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A struct{ j2g_header uint64; F_s__711000297, F_n, F_iter__711000296 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A struct{ j2g_header uint64; F_n, F_b__711000299 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_iface_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A struct{ j2g_header uint64; F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A struct{ j2g_header uint64; F_iter__711000158, F_s__711000159, F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A struct{ j2g_header uint64; F_b__711000161, F_r, F_pn any; F_size__1927001038__auto__ int32; F_core_QMARK_, F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000034_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000036_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A struct{ j2g_header uint64; F_iter__711000038, F_s__711000039 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A struct{ j2g_header uint64; F_s__711000041, F_n, F_iter__711000040 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A struct{ j2g_header uint64; F_n, F_b__711000043 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000178_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000196_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A struct{ j2g_header uint64; F_s__711000187, F_iter__711000186 any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A struct{ j2g_header uint64; F_b__711000189 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_object_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_object_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_classes_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_fn__711000201_A struct{ j2g_header uint64; F_T any }

var A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A struct{ j2g_header uint64; F_iter__711000205, F_s__711000206 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A struct{ j2g_header uint64; F_iter__711000207, F_n, F_s__711000208 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A struct{ j2g_header uint64; F_n, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A struct{ j2g_header uint64; F_s__711000210, F_n, F_iter__711000209, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A struct{ j2g_header uint64; F_n, F_b__711000212 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_public_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_public_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A struct{ j2g_header uint64; F_iter__711000013, F_s__711000014 any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A struct{ j2g_header uint64; F_b__711000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A struct{ j2g_header uint64; F_s__711000056, F_iter__711000055 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A struct{ j2g_header uint64; F_iter__711000057, F_s__711000058 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A struct{ j2g_header uint64; F_b__711000060 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000324_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_A struct{ j2g_header uint64; F_own, F_recv, F_clash, F_ifaces, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A struct{ j2g_header uint64; F_iter__711000307, F_s__711000308 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A struct{ j2g_header uint64; F_b__711000310 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A struct{ j2g_header uint64; F_s__711000330, F_iter__711000329 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A struct{ j2g_header uint64; F_b__711000332 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A struct{ j2g_header uint64; F_recv, F_iter__711000345, F_s__711000346, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A struct{ j2g_header uint64; F_recv, F_n, F_b__711000348 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A struct{ j2g_header uint64; F_recv, F_clash any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A struct{ j2g_header uint64; F_s__711000360, F_recv, F_clash, F_iter__711000359 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A struct{ j2g_header uint64; F_recv, F_clash, F_b__711000362 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_tag_A_fn_class *jrt.Class
