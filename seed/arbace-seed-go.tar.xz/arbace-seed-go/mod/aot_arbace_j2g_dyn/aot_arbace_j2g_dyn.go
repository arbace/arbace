//line aot_arbace_j2g_dyn.ae:1
package aot_arbace_j2g_dyn

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_jrt"
	"arbace/aot_arbace_j2g_model"
	"arbace/aot_arbace_j2g_names"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_New() *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_dyn_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyn_A_const_10); tmp2 = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(A_arbace_j2g_dyn_A_const_1, A_arbace_j2g_dyn_A_const_2, A_arbace_j2g_dyn_A_const_3, A_arbace_j2g_dyn_A_const_4, A_arbace_j2g_dyn_A_const_5, A_arbace_j2g_dyn_A_const_6, A_arbace_j2g_dyn_A_const_7, A_arbace_j2g_dyn_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_dyn_eval711000008_fn__711000009_A_New() *A_arbace_j2g_dyn_eval711000008_fn__711000009_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_eval711000008_fn__711000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_dyn_eval711000008_fn__711000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_11.GetRawRoot__O()); var tmp2 any; var root_22 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = A_arbace_j2g_dyn_A_const_13; if linked_23 == nil { tmp2 = ifn_24.Invoke_O__O(arg_25) } else { tmp2 = linked_23.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_22, arg_25) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(), A_arbace_j2g_dyn_A_const_15) }























func A_arbace_j2g_dyn_tag_A_New() *A_arbace_j2g_dyn_tag_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_tag_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_dyn_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { var root_26 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = sym__0; var arg_30 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_dyn_A_const_17, type__1)); if linked_27 == nil { return ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { return linked_27.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) } }










func A_arbace_j2g_dyn_roots_A_New() *A_arbace_j2g_dyn_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_j2g_dyn_roots_A) Ctor() {}
//line :36:1
func (t *A_arbace_j2g_dyn_roots_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New(); var tmp2 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class; if


	fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class = fncls__89d; tmp2 = fncls__89d } else { tmp2 = fncls__89 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()) }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_New() *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_A) Invoke_O_O__O(self, s__711000014__1 any) any { var tmp1 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(self, s__711000014__1); var tmp2 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class = fncls__88d; tmp2 = fncls__88d } else { tmp2 = fncls__88 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Ctor_O_O(c__iter__711000013, c__s__711000014 any) { t.F_iter__711000013 = c__iter__711000013; t.F_s__711000014 = c__s__711000014 }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A) Invoke_O__O(self any) any { { var s__711000014__1 any; var t_ any = t.F_s__711000014; t.F_s__711000014 = nil; s__711000014__1 = t_; for { var temp__1927000414__auto____2 any; var root_31 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = s__711000014__1; if linked_32 == nil { temp__1927000414__auto____2 = ifn_33.Invoke_O__O(arg_34) } else { temp__1927000414__auto____2 = linked_32.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000014__3 any = temp__1927000414__auto____2; var tmp1 any; var root_35 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = s__711000014__3; if linked_36 == nil { tmp1 = ifn_37.Invoke_O__O(arg_38) } else { tmp1 = linked_36.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_35, arg_38) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_39 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = s__711000014__3; if linked_40 == nil { c__1927001037__auto____4 = ifn_41.Invoke_O__O(arg_42) } else { c__1927001037__auto____4 = linked_40.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_39, arg_42) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000016__6 any; var root_43 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_44 == nil { b__711000016__6 = ifn_45.Invoke_O__O(arg_46) } else { b__711000016__6 = linked_44.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_43, arg_46) }; var tmp2 any = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(b__711000016__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_53 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any; var root_58 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = b__711000016__6; if linked_59 == nil { arg_56 = ifn_60.Invoke_O__O(arg_61) } else { arg_56 = linked_59.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_58, arg_61) }; var arg_57 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp5 any; var root_62 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = s__711000014__3; if linked_63 == nil { tmp5 = ifn_64.Invoke_O__O(arg_65) } else { tmp5 = linked_63.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_62, arg_65) }; arg_57 = tmp4.Invoke_O__O(tmp5); if linked_54 == nil { return ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { return linked_54.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) } } else { var root_66 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var root_71 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = b__711000016__6; if linked_72 == nil { arg_69 = ifn_73.Invoke_O__O(arg_74) } else { arg_69 = linked_72.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_71, arg_74) }; var arg_70 any; if linked_67 == nil { return ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { return linked_67.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) } } } else { var vec__711000024__4 any; var root_75 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = s__711000014__3; if linked_76 == nil { vec__711000024__4 = ifn_77.Invoke_O__O(arg_78) } else { vec__711000024__4 = linked_76.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_75, arg_78) }; var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000024__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_79 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_16, nme__6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__5)).Ref()); var arg_83 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000013); var tmp7 any; var root_84 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = s__711000014__3; if linked_85 == nil { tmp7 = ifn_86.Invoke_O__O(arg_87) } else { tmp7 = linked_85.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_84, arg_87) }; arg_83 = tmp6.Invoke_O__O(tmp7); if linked_80 == nil { return ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { return linked_80.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :39:1
func A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Ctor_O_I_O(c__b__711000016 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000016 = c__b__711000016; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :39:1
func (t *A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A) Invoke_O__O(self any) any { { var i__711000015__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000015__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000020__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000015__1)); var r__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000020__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_47 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = t.F_b__711000016; var arg_51 any = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_16, nme__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, r__3)).Ref()); if linked_48 == nil { ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { linked_48.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; i__711000015__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000015__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_enabled_QMARK__A_New() *A_arbace_j2g_dyn_enabled_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_enabled_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_j2g_dyn_enabled_QMARK__A) Invoke_O__O(self any) any {


	var root_90 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_90, arg_93)
	} }
func A_arbace_j2g_dyn_public_QMARK__A_New() *A_arbace_j2g_dyn_public_QMARK__A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_public_QMARK__A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Ctor() {}
//line :47:1
func (t *A_arbace_j2g_dyn_public_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var root_94 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var tmp1 int64; var na_98 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_33; var tmp3 any; var root_100 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = n__0; if linked_101 == nil { tmp3 = ifn_102.Invoke_O__O(arg_103) } else { tmp3 = linked_101.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_100, arg_103) }; na_98 = tmp2.Invoke_O__O(tmp3); var na_99 int64 = 1; if jrt.Long_InstanceOf(na_98) { var n0_104 int64 = jrt.NN(jrt.Long_Cast(na_98)).LongValue__J(); var n1_105 int64 = na_99; tmp1 = n0_104 & n1_105 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_98, na_99) }; arg_97 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_95 == nil { return ifn_96.Invoke_O__O(arg_97) } else { return linked_95.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_94, arg_97) } }

func A_arbace_j2g_dyn_interfaces_A_New() *A_arbace_j2g_dyn_interfaces_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_j2g_dyn_interfaces_A) Ctor() {}
//line :49:1
func (t *A_arbace_j2g_dyn_interfaces_A) Invoke_O_O__O(self, T__0_ any) any { var base__2 any; var root_107 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_109 lang.IFn; if




	linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any; var tmp1 any = A_arbace_j2g_dyn_interfaces_fn__711000034_A_New(); var tmp2 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class = fncls__158d; tmp2 = fncls__158d } else { tmp2 = fncls__158 }; arg_110 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_111 any; var root_159 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_161 lang.IFn; if






	linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = T__0_; var arg_163 any; var root_164 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any; var tmp3 any = A_arbace_j2g_dyn_interfaces_fn__711000036_A_New(); var tmp4 *jrt.Class; var fncls__182 *jrt.Class = A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class; if fncls__182 == nil { var fncls__182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class = fncls__182d; tmp4 = fncls__182d } else { tmp4 = fncls__182 }; arg_167 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_168 any; var root_183 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_185 lang.IFn; if


	linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any; var root_187 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var tmp5 *lang.Keyword = A_arbace_j2g_dyn_A_const_51; var arg_190 any = tmp5.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); if linked_188 == nil { arg_186 = ifn_189.Invoke_O__O(arg_190) } else { arg_186 = linked_188.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_187, arg_190) }; if linked_184 == nil { arg_168 = ifn_185.Invoke_O__O(arg_186) } else { arg_168 = linked_184.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_183, arg_186) }; if /*line :61:1*/ linked_165 == nil { arg_163 = ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { arg_163 = linked_165.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }; if linked_160 == nil { arg_111 = ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { arg_111 = linked_160.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }; if /*line :54:1*/ linked_108 == nil { base__2 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { base__2 = linked_108.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }; var root_191 any =










	A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any; var root_195 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var root_199 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = base__2; var arg_203 any; var iter__1927001039__auto____3 any; var tmp6 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New(); var tmp7 *jrt.Class; var fncls__323 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class; if
	fncls__323 == nil { var fncls__323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class = fncls__323d; tmp7 = fncls__323d } else { tmp7 = fncls__323 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_203 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(base__2); if /*line :65:1*/ linked_200 == nil { arg_198 = ifn_201.Invoke_O_O__O(arg_202, arg_203) } else { arg_198 = linked_200.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_199, arg_202, arg_203) }; if linked_196 == nil { arg_194 = ifn_197.Invoke_O__O(arg_198) } else { arg_194 = linked_196.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_195, arg_198) }; if linked_192 == nil { return ifn_193.Invoke_O__O(arg_194) } else { return linked_192.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_191, arg_194) } }
//line :54:1
func A_arbace_j2g_dyn_interfaces_fn__711000034_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000034_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000034_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Ctor() {}
//line :54:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000034_A) Invoke_O_O__O(self, p1__711000032_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_112 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = p1__711000032_SHARP___1; if linked_113 == nil { and__1927000168__auto____2 = ifn_114.Invoke_O__O(arg_115) } else { and__1927000168__auto____2 = linked_113.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_112, arg_115) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_116 any = A_arbace_j2g_dyn_A_const_37.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, A_arbace_j2g_dyn_public_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = p1__711000032_SHARP___1; if linked_117 == nil { and__1927000168__auto____3 = ifn_118.Invoke_O__O(arg_119) } else { and__1927000168__auto____3 = linked_117.(*A_arbace_j2g_dyn_public_QMARK__A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_120 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_122 lang.IFn

	if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any; var root_124 any = A_arbace_j2g_dyn_A_const_38.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var root_128 any = A_arbace_j2g_dyn_A_const_39.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = p1__711000032_SHARP___1; if linked_129 == nil { arg_127 = ifn_130.Invoke_O__O(arg_131) } else { arg_127 = linked_129.(*aot_arbace_j2g_model.A_arbace_j2g_model_pkg_A).Invoke_O_O__O(root_128, arg_131) }; if linked_125 == nil { arg_123 = ifn_126.Invoke_O__O(arg_127) } else { arg_123 = linked_125.(*aot_arbace_j2g_names.A_arbace_j2g_names_compiled_pkg_QMARK__A).Invoke_O_O__O(root_124, arg_127) }; if linked_121 == nil { and__1927000168__auto____4 = ifn_122.Invoke_O__O(arg_123) } else { and__1927000168__auto____4 = linked_121.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_120, arg_123) }
//line :54:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_132 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_134 lang.IFn



		if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; var root_136 any = A_arbace_j2g_dyn_A_const_40.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = p1__711000032_SHARP___1; var arg_140 any = Lit_114; if linked_137 == nil { arg_135 = ifn_138.Invoke_O_O__O(arg_139, arg_140) } else { arg_135 = linked_137.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_136, arg_139, arg_140) }; if linked_133 == nil { and__1927000168__auto____5 = ifn_134.Invoke_O__O(arg_135) } else { and__1927000168__auto____5 = linked_133.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_132, arg_135) }
//line :54:1
		if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp1 int64; var na_141 any; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_33; var tmp3 any; var root_143 any = A_arbace_j2g_dyn_A_const_34.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_j2g_model.A_arbace_j2g_model_info_A_fn_class); var ifn_145 lang.IFn




			if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = p1__711000032_SHARP___1; if linked_144 == nil { tmp3 = ifn_145.Invoke_O__O(arg_146) } else { tmp3 = linked_144.(*aot_arbace_j2g_model.A_arbace_j2g_model_info_A).Invoke_O_O__O(root_143, arg_146) }; na_141 = tmp2.Invoke_O__O(tmp3); var na_142 int64 = 8192; if jrt.Long_InstanceOf(na_141) { var n0_147 int64 = jrt.NN(jrt.Long_Cast(na_141)).LongValue__J(); var n1_148 int64 = na_142; tmp1 = n0_147 & n1_148 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_141, na_142) }; and__1927000168__auto____6 = lang.Numbers_IsZero_J__Z_NoInit(tmp1)
//line :54:1
			if and__1927000168__auto____6 {





				var root_150 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any; var root_154 any = A_arbace_j2g_dyn_A_const_41.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = p1__711000032_SHARP___1; if linked_155 == nil { arg_153 = ifn_156.Invoke_O__O(arg_157) } else { arg_153 = linked_155.(*aot_arbace_j2g_model.A_arbace_j2g_model_reflected_QMARK__A).Invoke_O_O__O(root_154, arg_157) }; if linked_151 == nil { return ifn_152.Invoke_O__O(arg_153) } else { return linked_151.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_150, arg_153) } } else {
//line :54:1
					return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_j2g_dyn_interfaces_fn__711000036_A_New() *A_arbace_j2g_dyn_interfaces_fn__711000036_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_fn__711000036_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Ctor() {}
//line :61:1
func (t *A_arbace_j2g_dyn_interfaces_fn__711000036_A) Invoke_O_O__O(self, p1__711000033_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_169 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = p1__711000033_SHARP___1; if linked_170 == nil { and__1927000168__auto____2 = ifn_171.Invoke_O__O(arg_172) } else { and__1927000168__auto____2 = linked_170.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_169, arg_172) }; if jrt.J2g_Truth(and__1927000168__auto____2) {

	var root_173 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var tmp1 *lang.Keyword = A_arbace_j2g_dyn_A_const_45; var tmp2 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_176 any = tmp1.Invoke_O__O(tmp2.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O())); var arg_177 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_20); var tmp4 any; var root_178 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = p1__711000033_SHARP___1; if linked_179 == nil { tmp4 = ifn_180.Invoke_O__O(arg_181) } else { tmp4 = linked_179.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_178, arg_181) }; arg_177 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil)).Ref(); if linked_174 == nil { return ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { return linked_174.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_173, arg_176, arg_177) } } else {
//line :61:1
		return and__1927000168__auto____2 } }




func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_New() *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Ctor() {}
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A) Invoke_O_O__O(self, s__711000039__1 any) any { var tmp1 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(self, s__711000039__1); var tmp2 *jrt.Class; var fncls__322 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class; if fncls__322 == nil { var fncls__322d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class = fncls__322d; tmp2 = fncls__322d } else { tmp2 = fncls__322 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Ctor_O_O(c__iter__711000038, c__s__711000039 any) { t.F_iter__711000038 = c__iter__711000038; t.F_s__711000039 = c__s__711000039 }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A) Invoke_O__O(self any) any { { var s__711000039__1 any; var t_ any = t.F_s__711000039; t.F_s__711000039 = nil; s__711000039__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_204 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = s__711000039__1; if linked_205 == nil { temp__1927000414__auto____2 = ifn_206.Invoke_O__O(arg_207) } else { temp__1927000414__auto____2 = linked_205.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_208 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = xs__1927001018__auto____3; if linked_209 == nil { n__4 = ifn_210.Invoke_O__O(arg_211) } else { n__4 = linked_209.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_208, arg_211) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(n__4); var tmp2 *jrt.Class; var fncls__300 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class; if fncls__300 == nil { var fncls__300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class = fncls__300d; tmp2 = fncls__300d } else { tmp2 = fncls__300 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_301 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_305 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = n__4; if linked_306 == nil { tmp4 = ifn_307.Invoke_O__O(arg_308) } else { tmp4 = linked_306.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_305, arg_308) }; arg_304 = tmp3.Invoke_O__O(tmp4); if linked_302 == nil { fs__1927001036__auto____6 = ifn_303.Invoke_O__O(arg_304) } else { fs__1927001036__auto____6 = linked_302.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_301, arg_304) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_309 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = fs__1927001036__auto____6; var arg_313 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000038); var tmp6 any; var root_314 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = s__711000039__1; if linked_315 == nil { tmp6 = ifn_316.Invoke_O__O(arg_317) } else { tmp6 = linked_315.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_314, arg_317) }; arg_313 = tmp5.Invoke_O__O(tmp6); if linked_310 == nil { return ifn_311.Invoke_O_O__O(arg_312, arg_313) } else { return linked_310.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_309, arg_312, arg_313) } } else { var tmp7 any; var root_318 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = s__711000039__1; if linked_319 == nil { tmp7 = ifn_320.Invoke_O__O(arg_321) } else { tmp7 = linked_319.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_318, arg_321) }; s__711000039__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_New_O(p0 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A{}; t.Ctor_O(p0); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A) Invoke_O_O__O(self, s__711000041__1 any) any { var tmp1 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(s__711000041__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__299 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class; if fncls__299 == nil { var fncls__299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class = fncls__299d; tmp2 = fncls__299d } else { tmp2 = fncls__299 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Ctor_O_O_O(c__s__711000041, c__n, c__iter__711000040 any) { t.F_s__711000041 = c__s__711000041; t.F_n = c__n; t.F_iter__711000040 = c__iter__711000040 }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A) Invoke_O__O(self any) any { { var s__711000041__1 any; var t_ any = t.F_s__711000041; t.F_s__711000041 = nil; s__711000041__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_212 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = s__711000041__1; if linked_213 == nil { temp__1927000414__auto____2 = ifn_214.Invoke_O__O(arg_215) } else { temp__1927000414__auto____2 = linked_213.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_212, arg_215) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000041__3 any = temp__1927000414__auto____2; var tmp1 any; var root_216 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = s__711000041__3; if linked_217 == nil { tmp1 = ifn_218.Invoke_O__O(arg_219) } else { tmp1 = linked_217.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_216, arg_219) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_220 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = s__711000041__3; if linked_221 == nil { c__1927001037__auto____4 = ifn_222.Invoke_O__O(arg_223) } else { c__1927001037__auto____4 = linked_221.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_220, arg_223) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000043__6 any; var root_224 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_225 == nil { b__711000043__6 = ifn_226.Invoke_O__O(arg_227) } else { b__711000043__6 = linked_225.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_224, arg_227) }; var tmp2 any = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(t.F_n, b__711000043__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__246 *jrt.Class = A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class; if fncls__246 == nil { var fncls__246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class = fncls__246d; tmp3 = fncls__246d } else { tmp3 = fncls__246 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_247 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any; var root_252 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = b__711000043__6; if linked_253 == nil { arg_250 = ifn_254.Invoke_O__O(arg_255) } else { arg_250 = linked_253.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_252, arg_255) }; var arg_251 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp5 any; var root_256 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = s__711000041__3; if linked_257 == nil { tmp5 = ifn_258.Invoke_O__O(arg_259) } else { tmp5 = linked_257.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_256, arg_259) }; arg_251 = tmp4.Invoke_O__O(tmp5); if linked_248 == nil { return ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { return linked_248.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_247, arg_250, arg_251) } } else { var root_260 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var root_265 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = b__711000043__6; if linked_266 == nil { arg_263 = ifn_267.Invoke_O__O(arg_268) } else { arg_263 = linked_266.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_265, arg_268) }; var arg_264 any; if linked_261 == nil { return ifn_262.Invoke_O_O__O(arg_263, arg_264) } else { return linked_261.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_260, arg_263, arg_264) } } } else { var s__4 any; var root_269 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = s__711000041__3; if linked_270 == nil { s__4 = ifn_271.Invoke_O__O(arg_272) } else { s__4 = linked_270.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_269, arg_272) }; var tmp6 any; var and__1927000168__auto____5 any; var root_273 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_275 lang.IFn
																			if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__4; var arg_277 any = t.F_n; if linked_274 == nil { and__1927000168__auto____5 = ifn_275.Invoke_O_O__O(arg_276, arg_277) } else { and__1927000168__auto____5 = linked_274.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_273, arg_276, arg_277) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_278 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = s__4; if linked_279 == nil { and__1927000168__auto____6 = ifn_280.Invoke_O__O(arg_281) } else { and__1927000168__auto____6 = linked_279.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_278, arg_281) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_282 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = s__4; if linked_283 == nil { tmp6 = ifn_284.Invoke_O__O(arg_285) } else { tmp6 = linked_283.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_282, arg_285) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :66:1
	if jrt.J2g_Truth(tmp6) { var root_286 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = s__4; var arg_290 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000040); var tmp8 any; var root_291 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = s__711000041__3; if linked_292 == nil { tmp8 = ifn_293.Invoke_O__O(arg_294) } else { tmp8 = linked_292.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_291, arg_294) }; arg_290 = tmp7.Invoke_O__O(tmp8); if linked_287 == nil { return ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { return linked_287.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_286, arg_289, arg_290) } } else { var tmp9 any; var root_295 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = s__711000041__3; if linked_296 == nil { tmp9 = ifn_297.Invoke_O__O(arg_298) } else { tmp9 = linked_296.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_295, arg_298) }; s__711000041__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :66:1
func A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Ctor_O_O_I_O(c__n, c__b__711000043 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000043 = c__b__711000043; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :66:1
func (t *A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A) Invoke_O__O(self any) any { { var i__711000042__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000042__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000042__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_228 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_230 lang.IFn
																					if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = s__2; var arg_232 any = t.F_n; if linked_229 == nil { and__1927000168__auto____3 = ifn_230.Invoke_O_O__O(arg_231, arg_232) } else { and__1927000168__auto____3 = linked_229.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_228, arg_231, arg_232) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_233 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = s__2; if linked_234 == nil { and__1927000168__auto____4 = ifn_235.Invoke_O__O(arg_236) } else { and__1927000168__auto____4 = linked_234.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_233, arg_236) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_237 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = s__2; if linked_238 == nil { tmp2 = ifn_239.Invoke_O__O(arg_240) } else { tmp2 = linked_238.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_237, arg_240) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :66:1
	if jrt.J2g_Truth(tmp2) { var root_241 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = t.F_b__711000043; var arg_245 any = s__2; if linked_242 == nil { ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { linked_242.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }; i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } else { i__711000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000042__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_slot_keys_A_New() *A_arbace_j2g_dyn_slot_keys_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Ctor() {}
//line :70:1
func (t *A_arbace_j2g_dyn_slot_keys_A) Invoke_O_O__O(self, ifaces__0 any) any { var ks__2 any; var root_324 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_326 lang.IFn; if


	linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_328 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New(); var tmp2 *jrt.Class; var fncls__433 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class; if fncls__433 == nil { var fncls__433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class = fncls__433d; tmp2 = fncls__433d } else { tmp2 = fncls__433 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_331 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(ifaces__0); if linked_329 == nil { arg_327 = ifn_330.Invoke_O__O(arg_331) } else { arg_327 = linked_329.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_328, arg_331) }; if linked_325 == nil { ks__2 = ifn_326.Invoke_O__O(arg_327) } else { ks__2 = linked_325.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_324, arg_327) }; var root_434 any =
	A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any; var root_438 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(); var arg_442 any = ks__2; if linked_439 == nil { arg_437 = ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { arg_437 = linked_439.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) }; if linked_435 == nil { return ifn_436.Invoke_O__O(arg_437) } else { return linked_435.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_434, arg_437) } }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A) Invoke_O_O__O(self, s__711000056__1 any) any { var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(s__711000056__1, self); var tmp2 *jrt.Class; var fncls__432 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class; if fncls__432 == nil { var fncls__432d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class = fncls__432d; tmp2 = fncls__432d } else { tmp2 = fncls__432 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Ctor_O_O(c__s__711000056, c__iter__711000055 any) { t.F_s__711000056 = c__s__711000056; t.F_iter__711000055 = c__iter__711000055 }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A) Invoke_O__O(self any) any { { var s__711000056__1 any; var t_ any = t.F_s__711000056; t.F_s__711000056 = nil; s__711000056__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_332 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = s__711000056__1; if linked_333 == nil { temp__1927000414__auto____2 = ifn_334.Invoke_O__O(arg_335) } else { temp__1927000414__auto____2 = linked_333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_332, arg_335) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var j__4 any; var root_336 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = xs__1927001018__auto____3; if linked_337 == nil { j__4 = ifn_338.Invoke_O__O(arg_339) } else { j__4 = linked_337.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_336, arg_339) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New(); var tmp2 *jrt.Class; var fncls__410 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class; if fncls__410 == nil { var fncls__410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class = fncls__410d; tmp2 = fncls__410d } else { tmp2 = fncls__410 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_411 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_415 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = j__4; if linked_416 == nil { tmp4 = ifn_417.Invoke_O__O(arg_418) } else { tmp4 = linked_416.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_415, arg_418) }; arg_414 = tmp3.Invoke_O__O(tmp4); if linked_412 == nil { fs__1927001036__auto____6 = ifn_413.Invoke_O__O(arg_414) } else { fs__1927001036__auto____6 = linked_412.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_411, arg_414) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_419 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = fs__1927001036__auto____6; var arg_423 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000055); var tmp6 any; var root_424 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = s__711000056__1; if linked_425 == nil { tmp6 = ifn_426.Invoke_O__O(arg_427) } else { tmp6 = linked_425.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_424, arg_427) }; arg_423 = tmp5.Invoke_O__O(tmp6); if linked_420 == nil { return ifn_421.Invoke_O_O__O(arg_422, arg_423) } else { return linked_420.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_419, arg_422, arg_423) } } else { var tmp7 any; var root_428 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = s__711000056__1; if linked_429 == nil { tmp7 = ifn_430.Invoke_O__O(arg_431) } else { tmp7 = linked_429.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_428, arg_431) }; s__711000056__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_New() *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Ctor() {}
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A) Invoke_O_O__O(self, s__711000058__1 any) any { var tmp1 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(self, s__711000058__1); var tmp2 *jrt.Class; var fncls__409 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class; if fncls__409 == nil { var fncls__409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class = fncls__409d; tmp2 = fncls__409d } else { tmp2 = fncls__409 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A{}; t.Ctor_O_O(p0, p1); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Ctor_O_O(c__iter__711000057, c__s__711000058 any) { t.F_iter__711000057 = c__iter__711000057; t.F_s__711000058 = c__s__711000058 }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A) Invoke_O__O(self any) any { { var s__711000058__1 any; var t_ any = t.F_s__711000058; t.F_s__711000058 = nil; s__711000058__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_340 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = s__711000058__1; if linked_341 == nil { temp__1927000414__auto____2 = ifn_342.Invoke_O__O(arg_343) } else { temp__1927000414__auto____2 = linked_341.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_340, arg_343) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000058__3 any = temp__1927000414__auto____2; var tmp1 any; var root_344 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = s__711000058__3; if linked_345 == nil { tmp1 = ifn_346.Invoke_O__O(arg_347) } else { tmp1 = linked_345.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_344, arg_347) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_348 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = s__711000058__3; if linked_349 == nil { c__1927001037__auto____4 = ifn_350.Invoke_O__O(arg_351) } else { c__1927001037__auto____4 = linked_349.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_348, arg_351) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000060__6 any; var root_352 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_353 == nil { b__711000060__6 = ifn_354.Invoke_O__O(arg_355) } else { b__711000060__6 = linked_353.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_352, arg_355) }; var tmp2 any = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(b__711000060__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__365 *jrt.Class = A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class; if fncls__365 == nil { var fncls__365d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class = fncls__365d; tmp3 = fncls__365d } else { tmp3 = fncls__365 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_366 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any; var root_371 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = b__711000060__6; if linked_372 == nil { arg_369 = ifn_373.Invoke_O__O(arg_374) } else { arg_369 = linked_372.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_371, arg_374) }; var arg_370 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp5 any; var root_375 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = s__711000058__3; if linked_376 == nil { tmp5 = ifn_377.Invoke_O__O(arg_378) } else { tmp5 = linked_376.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_375, arg_378) }; arg_370 = tmp4.Invoke_O__O(tmp5); if linked_367 == nil { return ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { return linked_367.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) } } else { var root_379 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any; var root_384 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = b__711000060__6; if linked_385 == nil { arg_382 = ifn_386.Invoke_O__O(arg_387) } else { arg_382 = linked_385.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_384, arg_387) }; var arg_383 any; if linked_380 == nil { return ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { return linked_380.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) } } } else { var vec__711000070__4 any; var root_388 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = s__711000058__3; if linked_389 == nil { vec__711000070__4 = ifn_390.Invoke_O__O(arg_391) } else { vec__711000070__4 = linked_389.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_388, arg_391) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000070__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_392 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_394 lang.IFn; _ = ___6; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__5); if linked_393 == nil { tmp6 = ifn_394.Invoke_O__O(arg_395) } else { tmp6 = linked_393.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_392, arg_395) }; if jrt.J2g_Truth(tmp6) { var root_396 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = k__5; var arg_400 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000057); var tmp8 any; var root_401 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = s__711000058__3; if linked_402 == nil { tmp8 = ifn_403.Invoke_O__O(arg_404) } else { tmp8 = linked_402.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_401, arg_404) }; arg_400 = tmp7.Invoke_O__O(tmp8); if linked_397 == nil { return ifn_398.Invoke_O_O__O(arg_399, arg_400) } else { return linked_397.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_396, arg_399, arg_400) } } else { var tmp9 any; var root_405 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = s__711000058__3; if linked_406 == nil { tmp9 = ifn_407.Invoke_O__O(arg_408) } else { tmp9 = linked_406.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_405, arg_408) }; s__711000058__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :73:1
func A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Ctor_O_I_O(c__b__711000060 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000060 = c__b__711000060; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :73:1
func (t *A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A) Invoke_O__O(self any) any { { var i__711000059__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000059__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000066__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000059__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000066__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_356 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_358 lang.IFn; _ = ___4; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__3); if linked_357 == nil { tmp2 = ifn_358.Invoke_O__O(arg_359) } else { tmp2 = linked_357.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_356, arg_359) }; if jrt.J2g_Truth(tmp2) { var root_360 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = t.F_b__711000060; var arg_364 any = k__3; if linked_361 == nil { ifn_362.Invoke_O_O__O(arg_363, arg_364) } else { linked_361.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_360, arg_363, arg_364) }; i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } else { i__711000059__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000059__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_declarers_A_New() *A_arbace_j2g_dyn_declarers_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_j2g_dyn_declarers_A) Ctor() {}
//line :78:1
func (t *A_arbace_j2g_dyn_declarers_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var vec__711000078__3 any; var root_443 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_445 lang.IFn; if




	linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); if linked_444 == nil { vec__711000078__3 = ifn_445.Invoke_O__O(arg_446) } else { vec__711000078__3 = linked_444.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_443, arg_446) }; var i__4 any = /*line :78:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000078__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; if





	lang.Util_Identical_O_O__Z_NoInit(i__4, ifaces__0) { tmp1 = ix__5 } else { var lockee__1927000360__auto____6 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var tmp2 any = A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(ifaces__0, lockee__1927000360__auto____6); var tmp3 *jrt.Class
		var fncls__580 /*line :84:1*/*jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class

		if fncls__580 == nil { var fncls__580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class = fncls__580d; tmp3 = fncls__580d } else { tmp3 = fncls__580 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O() }; return /*line :84:1*/ lang.RT_Get_O_O__O_NoInit(tmp1, k__1) }

func A_arbace_j2g_dyn_declarers_fn__711000081_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Ctor_O_O(c__ifaces, c__lockee__1927000360__auto__ any) { t.F_ifaces = c__ifaces; t.F_lockee__1927000360__auto__ = c__lockee__1927000360__auto__ }
//line :86:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_A) Invoke_O__O(self any) any { var locklocal__1927000361__auto____3 any; var t_ any = t.F_lockee__1927000360__auto__; t.F_lockee__1927000360__auto__ = nil; locklocal__1927000361__auto____3 = t_; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____3); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__711000082__6 any; var root_447 any = A_arbace_j2g_dyn_A_const_12.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_449 lang.IFn
										if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); if linked_448 == nil { vec__711000082__6 = ifn_449.Invoke_O__O(arg_450) } else { vec__711000082__6 = linked_448.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_447, arg_450) }
//line :86:1
	var i__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ix__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000082__6, lang.RT_IntCast_J__I_NoInit(1), nil)

	if lang.Util_Identical_O_O__Z_NoInit(i__7, t.F_ifaces) { tmp1 = ix__8 } else { var ix__9 any; var root_451 any = A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_453 lang.IFn

		if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any; var tmp2 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New(); var tmp3 *jrt.Class; var fncls__574 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class; if fncls__574 == nil { var fncls__574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class = fncls__574d; tmp3 = fncls__574d } else { tmp3 = fncls__574 }; arg_454 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_455 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_456 any = t.F_ifaces; if linked_452 == nil { ix__9 = ifn_453.Invoke_O_O_O__O(arg_454, arg_455, arg_456) } else { ix__9 = linked_452.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_451, arg_454, arg_455, arg_456)
		}




		var root_575 any = A_arbace_j2g_dyn_A_const_67.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = A_arbace_j2g_dyn_A_const_60.GetRawRoot__O(); var arg_579 any; var tmp4 any; var t__2 any = t.F_ifaces; t.F_ifaces = nil; tmp4 = t__2; arg_579 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, ix__9); if linked_576 == nil { ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { linked_576.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_575, arg_578, arg_579) }
//line :88:1
		tmp1 = ix__9 } }; return nil }(); /*line :86:1*/lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____3); if tmp5 != nil { panic(tmp5) }; return tmp1 }



func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Ctor() {}
//line :90:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A) Invoke_O_O_O__O(self, ix__1, j__2 any) any {
	var root_457 any = A_arbace_j2g_dyn_A_const_61.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(j__2); var tmp2 *jrt.Class; var fncls__475 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class; if fncls__475 == nil { var fncls__475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class = fncls__475d; tmp2 = fncls__475d } else { tmp2 = fncls__475 }; arg_460 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_461 any = ix__1; var arg_462 any; var root_476 any = A_arbace_j2g_dyn_A_const_52.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_478 lang.IFn

	if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New(); var tmp4 *jrt.Class; var fncls__569 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class; if fncls__569 == nil { var fncls__569d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class = fncls__569d; tmp4 = fncls__569d } else { tmp4 = fncls__569 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp6 any; var root_570 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = j__2; if linked_571 == nil { tmp6 = ifn_572.Invoke_O__O(arg_573) } else { tmp6 = linked_571.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_570, arg_573) }; arg_479 = tmp5.Invoke_O__O(tmp6); if linked_477 == nil { arg_462 = ifn_478.Invoke_O__O(arg_479) } else { arg_462 = linked_477.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_476, arg_479) }
//line :91:1
	if linked_458 == nil { return ifn_459.Invoke_O_O_O__O(arg_460, arg_461, arg_462) } else { return linked_458.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_457, arg_460, arg_461, arg_462) } }
//line :91:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_New_O(p0 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A{}; t.Ctor_O(p0); return t }
//line :91:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Ctor_O(c__j any) { t.F_j = c__j }
//line :91:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A) Invoke_O_O_O__O(self, ix__1, kk__2 any) any { var root_463 any = A_arbace_j2g_dyn_A_const_62.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = ix__1; var arg_467 any = kk__2; var arg_468 any; var root_470 any = A_arbace_j2g_dyn_A_const_63.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = A_arbace_j2g_dyn_A_const_14.GetRawRoot__O(); var arg_474 any = lang.PersistentVector_EMPTY.Ref(); if linked_471 == nil { arg_468 = ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { arg_468 = linked_471.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) }; var arg_469 any = t.F_j; if linked_464 == nil { return ifn_465.Invoke_O_O_O_O__O(arg_466, arg_467, arg_468, arg_469) } else { return linked_464.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_463, arg_466, arg_467, arg_468, arg_469) } }

func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A) Invoke_O_O__O(self, s__711000089__1 any) any { var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(s__711000089__1, self); var tmp2 *jrt.Class; var fncls__568 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class; if fncls__568 == nil { var fncls__568d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class = fncls__568d; tmp2 = fncls__568d } else { tmp2 = fncls__568 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Ctor_O_O(c__s__711000089, c__iter__711000088 any) { t.F_s__711000089 = c__s__711000089; t.F_iter__711000088 = c__iter__711000088 }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A) Invoke_O__O(self any) any { { var s__711000089__1 any; var t_ any = t.F_s__711000089; t.F_s__711000089 = nil; s__711000089__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_480 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = s__711000089__1; if linked_481 == nil { temp__1927000414__auto____2 = ifn_482.Invoke_O__O(arg_483) } else { temp__1927000414__auto____2 = linked_481.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_480, arg_483) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_484 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = xs__1927001018__auto____3; if linked_485 == nil { c__4 = ifn_486.Invoke_O__O(arg_487) } else { c__4 = linked_485.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_484, arg_487) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New(); var tmp2 *jrt.Class; var fncls__546 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class; if fncls__546 == nil { var fncls__546d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class = fncls__546d; tmp2 = fncls__546d } else { tmp2 = fncls__546 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_547 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_551 any = A_arbace_j2g_dyn_A_const_66.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = c__4; if linked_552 == nil { tmp4 = ifn_553.Invoke_O__O(arg_554) } else { tmp4 = linked_552.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_551, arg_554) }; arg_550 = tmp3.Invoke_O__O(tmp4); if linked_548 == nil { fs__1927001036__auto____6 = ifn_549.Invoke_O__O(arg_550) } else { fs__1927001036__auto____6 = linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_555 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = fs__1927001036__auto____6; var arg_559 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__711000088); var tmp6 any; var root_560 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = s__711000089__1; if linked_561 == nil { tmp6 = ifn_562.Invoke_O__O(arg_563) } else { tmp6 = linked_561.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_560, arg_563) }; arg_559 = tmp5.Invoke_O__O(tmp6); if linked_556 == nil { return ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { return linked_556.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_555, arg_558, arg_559) } } else { var tmp7 any; var root_564 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__711000089__1; if linked_565 == nil { tmp7 = ifn_566.Invoke_O__O(arg_567) } else { tmp7 = linked_565.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_564, arg_567) }; s__711000089__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_New() *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Ctor() {}
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A) Invoke_O_O__O(self, s__711000091__1 any) any { var tmp1 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(self, s__711000091__1); var tmp2 *jrt.Class; var fncls__545 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class; if fncls__545 == nil { var fncls__545d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class = fncls__545d; tmp2 = fncls__545d } else { tmp2 = fncls__545 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Ctor_O_O(c__iter__711000090, c__s__711000091 any) { t.F_iter__711000090 = c__iter__711000090; t.F_s__711000091 = c__s__711000091 }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A) Invoke_O__O(self any) any { { var s__711000091__1 any; var t_ any = t.F_s__711000091; t.F_s__711000091 = nil; s__711000091__1 = t_; for { var temp__1927000414__auto____2 any; var root_488 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = s__711000091__1; if linked_489 == nil { temp__1927000414__auto____2 = ifn_490.Invoke_O__O(arg_491) } else { temp__1927000414__auto____2 = linked_489.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_488, arg_491) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000091__3 any = temp__1927000414__auto____2; var tmp1 any; var root_492 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = s__711000091__3; if linked_493 == nil { tmp1 = ifn_494.Invoke_O__O(arg_495) } else { tmp1 = linked_493.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_492, arg_495) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_496 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = s__711000091__3; if linked_497 == nil { c__1927001037__auto____4 = ifn_498.Invoke_O__O(arg_499) } else { c__1927001037__auto____4 = linked_497.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_496, arg_499) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000093__6 any; var root_500 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_501 == nil { b__711000093__6 = ifn_502.Invoke_O__O(arg_503) } else { b__711000093__6 = linked_501.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_500, arg_503) }; var tmp2 any = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(b__711000093__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__509 *jrt.Class = A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class; if fncls__509 == nil { var fncls__509d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class = fncls__509d; tmp3 = fncls__509d } else { tmp3 = fncls__509 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_510 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any; var root_515 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = b__711000093__6; if linked_516 == nil { arg_513 = ifn_517.Invoke_O__O(arg_518) } else { arg_513 = linked_516.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_515, arg_518) }; var arg_514 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp5 any; var root_519 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = s__711000091__3; if linked_520 == nil { tmp5 = ifn_521.Invoke_O__O(arg_522) } else { tmp5 = linked_520.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_519, arg_522) }; arg_514 = tmp4.Invoke_O__O(tmp5); if linked_511 == nil { return ifn_512.Invoke_O_O__O(arg_513, arg_514) } else { return linked_511.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_510, arg_513, arg_514) } } else { var root_523 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var root_528 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = b__711000093__6; if linked_529 == nil { arg_526 = ifn_530.Invoke_O__O(arg_531) } else { arg_526 = linked_529.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_528, arg_531) }; var arg_527 any; if linked_524 == nil { return ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { return linked_524.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) } } } else { var mm__4 any; var root_532 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = s__711000091__3; if linked_533 == nil { mm__4 = ifn_534.Invoke_O__O(arg_535) } else { mm__4 = linked_533.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_532, arg_535) }; var root_536 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4)); var arg_540 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000090); var tmp7 any; var root_541 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = s__711000091__3; if linked_542 == nil { tmp7 = ifn_543.Invoke_O__O(arg_544) } else { tmp7 = linked_542.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_541, arg_544) }; arg_540 = tmp6.Invoke_O__O(tmp7); if linked_537 == nil { return ifn_538.Invoke_O_O__O(arg_539, arg_540) } else { return linked_537.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_536, arg_539, arg_540) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :93:1
func A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Ctor_O_I_O(c__b__711000093 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000093 = c__b__711000093; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :93:1
func (t *A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A) Invoke_O__O(self any) any { { var i__711000092__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000092__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000092__1)); var root_504 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = t.F_b__711000093; var arg_508 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2)); if linked_505 == nil { ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { linked_505.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) }; i__711000092__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000092__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_dyn_defaults_for_A_New() *A_arbace_j2g_dyn_defaults_for_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Ctor() {}
//line :100:1
func (t *A_arbace_j2g_dyn_defaults_for_A) Invoke_O_O_O__O(self, ifaces__0, k__1 any) any { var cands__3 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(k__1); var tmp2 *jrt.Class; var fncls__699 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class; if


	fncls__699 == nil { var fncls__699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class = fncls__699d; tmp2 = fncls__699d } else { tmp2 = fncls__699 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_710 any = A_arbace_j2g_dyn_A_const_77.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, A_arbace_j2g_dyn_declarers_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = ifaces__0; var arg_714 any = k__1; if linked_711 == nil { tmp4 = ifn_712.Invoke_O_O__O(arg_713, arg_714) } else { tmp4 = linked_711.(*A_arbace_j2g_dyn_declarers_A).Invoke_O_O_O__O(root_710, arg_713, arg_714) }; cands__3 = tmp3.Invoke_O__O(tmp4); var root_700 any =



	A_arbace_j2g_dyn_A_const_76.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any; var tmp5 any = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New(); var tmp6 *jrt.Class; var fncls__709 *jrt.Class = A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class; if fncls__709 == nil { var fncls__709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class = fncls__709d; tmp6 = fncls__709d } else { tmp6 = fncls__709 }; arg_703 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_704 any = cands__3; if linked_701 == nil { return ifn_702.Invoke_O_O__O(arg_703, arg_704) } else { return linked_701.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_700, arg_703, arg_704) } }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_New_O(p0 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A) Invoke_O_O__O(self, s__711000108__1 any) any { var tmp1 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(self, t.F_k, s__711000108__1); var tmp2 *jrt.Class; var fncls__698 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class; if fncls__698 == nil { var fncls__698d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class = fncls__698d; tmp2 = fncls__698d } else { tmp2 = fncls__698 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Ctor_O_O_O(c__iter__711000107, c__k, c__s__711000108 any) { t.F_iter__711000107 = c__iter__711000107; t.F_k = c__k; t.F_s__711000108 = c__s__711000108 }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A) Invoke_O__O(self any) any { { var s__711000108__1 any; var t_ any = t.F_s__711000108; t.F_s__711000108 = nil; s__711000108__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_581 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = s__711000108__1; if linked_582 == nil { temp__1927000414__auto____2 = ifn_583.Invoke_O__O(arg_584) } else { temp__1927000414__auto____2 = linked_582.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_581, arg_584) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000108__3 any = temp__1927000414__auto____2; var tmp1 any; var root_585 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = s__711000108__3; if linked_586 == nil { tmp1 = ifn_587.Invoke_O__O(arg_588) } else { tmp1 = linked_586.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_585, arg_588) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_589 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = s__711000108__3; if linked_590 == nil { c__1927001037__auto____4 = ifn_591.Invoke_O__O(arg_592) } else { c__1927001037__auto____4 = linked_590.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_589, arg_592) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000110__6 any; var root_593 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_594 == nil { b__711000110__6 = ifn_595.Invoke_O__O(arg_596) } else { b__711000110__6 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_593, arg_596) }; var tmp2 any = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(t.F_k, b__711000110__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__630 *jrt.Class = A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class; if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class = fncls__630d; tmp3 = fncls__630d } else { tmp3 = fncls__630 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_631 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any; var root_636 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_638 lang.IFn; if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = b__711000110__6; if linked_637 == nil { arg_634 = ifn_638.Invoke_O__O(arg_639) } else { arg_634 = linked_637.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_636, arg_639) }; var arg_635 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp5 any; var root_640 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = s__711000108__3; if linked_641 == nil { tmp5 = ifn_642.Invoke_O__O(arg_643) } else { tmp5 = linked_641.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_640, arg_643) }; arg_635 = tmp4.Invoke_O__O(tmp5); if linked_632 == nil { return ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { return linked_632.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_631, arg_634, arg_635) } } else { var root_644 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any; var root_649 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = b__711000110__6; if linked_650 == nil { arg_647 = ifn_651.Invoke_O__O(arg_652) } else { arg_647 = linked_650.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_649, arg_652) }; var arg_648 any; if linked_645 == nil { return ifn_646.Invoke_O_O__O(arg_647, arg_648) } else { return linked_645.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_644, arg_647, arg_648) } } } else { var j__4 any; var root_653 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = s__711000108__3; if linked_654 == nil { j__4 = ifn_655.Invoke_O__O(arg_656) } else { j__4 = linked_654.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_653, arg_656) }; var impl__5 any; var root_657 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_659 lang.IFn
														if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = j__4; var arg_661 any = t.F_k; if linked_658 == nil { impl__5 = ifn_659.Invoke_O_O__O(arg_660, arg_661) } else { impl__5 = linked_658.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_657, arg_660, arg_661) }
//line :103:1
	var tmp6 any
	var and__1927000168__auto____6 any = impl__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp7 any = A_arbace_j2g_dyn_A_const_69; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__5)); if and__1927000168__auto____7 { var root_662 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__5); if linked_663 == nil { tmp6 = ifn_664.Invoke_O__O(arg_665) } else { tmp6 = linked_663.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_662, arg_665) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp6 = and__1927000168__auto____6 }
//line :103:1
	if jrt.J2g_Truth(tmp6) { var root_666 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any; var tmp8 any; var root_671 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_673 lang.IFn


		if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = A_arbace_j2g_dyn_A_const_73; var arg_675 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__5); var arg_676 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp10 any; var root_677 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any; var root_682 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = t.F_k; if linked_683 == nil { arg_680 = ifn_684.Invoke_O__O(arg_685) } else { arg_680 = linked_683.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_682, arg_685) }; var arg_681 any; var root_686 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = t.F_k; if linked_687 == nil { arg_681 = ifn_688.Invoke_O__O(arg_689) } else { arg_681 = linked_687.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_686, arg_689) }; if linked_678 == nil { tmp10 = ifn_679.Invoke_O_O__O(arg_680, arg_681) } else { tmp10 = linked_678.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_677, arg_680, arg_681) }; arg_676 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_672 == nil { tmp8 = ifn_673.Invoke_O_O_O__O(arg_674, arg_675, arg_676) } else { tmp8 = linked_672.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_671, arg_674, arg_675, arg_676) }
//line :103:1
		arg_669 = lang.Tuple_Create_O_O__IPersistentVector(j__4, tmp8); var arg_670 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__711000107); var tmp12 any; var root_690 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = s__711000108__3; if linked_691 == nil { tmp12 = ifn_692.Invoke_O__O(arg_693) } else { tmp12 = linked_691.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_690, arg_693) }; arg_670 = tmp11.Invoke_O__O(tmp12); if linked_667 == nil { return ifn_668.Invoke_O_O__O(arg_669, arg_670) } else { return linked_667.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_666, arg_669, arg_670) } } else { var tmp13 any; var root_694 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = s__711000108__3; if linked_695 == nil { tmp13 = ifn_696.Invoke_O__O(arg_697) } else { tmp13 = linked_695.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_694, arg_697) }; s__711000108__1 = tmp13; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :103:1
func A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Ctor_O_O_I_O(c__k, c__b__711000110 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_b__711000110 = c__b__711000110; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :103:1
func (t *A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A) Invoke_O__O(self any) any { { var i__711000109__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000109__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000109__1)); var impl__3 any; var root_597 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_599 lang.IFn
																if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = j__2; var arg_601 any = t.F_k; if linked_598 == nil { impl__3 = ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { impl__3 = linked_598.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }
//line :103:1
	var tmp2 any
	var and__1927000168__auto____4 any = impl__3
	if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp3 any = A_arbace_j2g_dyn_A_const_69; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__3)); if and__1927000168__auto____5 { var root_602 any = A_arbace_j2g_dyn_A_const_30.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__3); if linked_603 == nil { tmp2 = ifn_604.Invoke_O__O(arg_605) } else { tmp2 = linked_603.(*aot_arbace_j2g_model.A_arbace_j2g_model_translated_QMARK__A).Invoke_O_O__O(root_602, arg_605) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp2 = and__1927000168__auto____4 }
//line :103:1
	if jrt.J2g_Truth(tmp2) { var root_606 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = t.F_b__711000110; var arg_610 any; var tmp4 any; var root_611 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_613 lang.IFn


		if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = A_arbace_j2g_dyn_A_const_73; var arg_615 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__3); var arg_616 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp6 any; var root_617 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any; var root_622 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = t.F_k; if linked_623 == nil { arg_620 = ifn_624.Invoke_O__O(arg_625) } else { arg_620 = linked_623.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_622, arg_625) }; var arg_621 any; var root_626 any = A_arbace_j2g_dyn_A_const_75.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = t.F_k; if linked_627 == nil { arg_621 = ifn_628.Invoke_O__O(arg_629) } else { arg_621 = linked_627.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_626, arg_629) }; if linked_618 == nil { tmp6 = ifn_619.Invoke_O_O__O(arg_620, arg_621) } else { tmp6 = linked_618.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_617, arg_620, arg_621) }; arg_616 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_612 == nil { tmp4 = ifn_613.Invoke_O_O_O__O(arg_614, arg_615, arg_616) } else { tmp4 = linked_612.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_611, arg_614, arg_615, arg_616) }
//line :103:1
		arg_610 = lang.Tuple_Create_O_O__IPersistentVector(j__2, tmp4); if linked_607 == nil { ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { linked_607.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) }; i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } else { i__711000109__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000109__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_defaults_for_fn__711000118_A_New() *A_arbace_j2g_dyn_defaults_for_fn__711000118_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_defaults_for_fn__711000118_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Ctor() {}
//line :107:1
func (t *A_arbace_j2g_dyn_defaults_for_fn__711000118_A) Invoke_O_O__O(self, p__711000117__1 any) any { var vec__711000119__2 any = p__711000117__1; var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000119__2, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_705 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = j__3; if linked_706 == nil { tmp1 = ifn_707.Invoke_O__O(arg_708) } else { tmp1 = linked_706.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_705, arg_708) }; return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp1)))).Ref() }

func A_arbace_j2g_dyn_box_arg_A_New() *A_arbace_j2g_dyn_box_arg_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_box_arg_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_j2g_dyn_box_arg_A) Ctor() {}
//line :109:1
func (t *A_arbace_j2g_dyn_box_arg_A) Invoke_O_O_O__O(self, p__0, d__1 any) any {


	var tmp1 any; var root_715 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = d__1; if linked_716 == nil { tmp1 = ifn_717.Invoke_O__O(arg_718) } else { tmp1 = linked_716.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_715, arg_718) }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_82, p__0) } else { var tmp2 any; var root_719 any = A_arbace_j2g_dyn_A_const_80.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A_fn_class); var ifn_721 lang.IFn
		if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = d__1; if linked_720 == nil { tmp2 = ifn_721.Invoke_O__O(arg_722) } else { tmp2 = linked_720.(*aot_arbace_j2g_model.A_arbace_j2g_model_pointer_desc_QMARK__A).Invoke_O_O__O(root_719, arg_722) }
//line :112:1
		if jrt.J2g_Truth(tmp2) {
			return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_83, p__0) } else {
//line :112:1
				if A_arbace_j2g_dyn_A_const_81 != nil { return p__0 } else { return nil
				}
			}
	} }
func A_arbace_j2g_dyn_convert_result_A_New() *A_arbace_j2g_dyn_convert_result_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_j2g_dyn_convert_result_A) Ctor() {}
//line :116:1
func (t *A_arbace_j2g_dyn_convert_result_A) Invoke_O_O_O__O(self, r__0, d__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_10) { return r__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1)) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any; var root_727 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = A_arbace_j2g_dyn_A_const_73; var arg_731 any = Lit_16; var arg_732 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp4 any; var root_733 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_29.GetRawRoot__O()).Invoke_O__O(d__1); var arg_737 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__1)).Ref(); if linked_734 == nil { tmp4 = ifn_735.Invoke_O_O__O(arg_736, arg_737) } else { tmp4 = linked_734.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_733, arg_736, arg_737) }; arg_732 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref(); if linked_728 == nil { tmp2 = ifn_729.Invoke_O_O_O__O(arg_730, arg_731, arg_732) } else { tmp2 = linked_728.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_727, arg_730, arg_731, arg_732) }; return tmp1.Invoke_O_O__O(tmp2, r__0) } else {
//line :119:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_84).Invoke_O__O(d__1)) {


				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_86; var tmp7 any; var root_738 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = A_arbace_j2g_dyn_A_const_73; var arg_742 any = d__1; if linked_739 == nil { tmp7 = ifn_740.Invoke_O_O__O(arg_741, arg_742) } else { tmp7 = linked_739.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_738, arg_741, arg_742) }; var tmp8 any = tmp7; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_88; var tmp11 any
				if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_18) { tmp11 = A_arbace_j2g_dyn_A_const_89 } else { tmp11 = A_arbace_j2g_dyn_A_const_90 }
//line :122:1
				return tmp5.Invoke_O_O_O__O(tmp6, tmp8, tmp9.Invoke_O_O_O__O(tmp10, tmp11, r__0)) } else {
//line :119:1
					var tmp12 any; var root_723 any = A_arbace_j2g_dyn_A_const_85.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_725 lang.IFn




					if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = d__1; if linked_724 == nil { tmp12 = ifn_725.Invoke_O__O(arg_726) } else { tmp12 = linked_724.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_723, arg_726) }
//line :119:1
					if jrt.J2g_Truth(tmp12) {




						var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyn_A_const_97; var tmp16 any = A_arbace_j2g_dyn_A_const_98; var tmp17 any; var root_776 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = A_arbace_j2g_dyn_A_const_73; var arg_780 any = d__1; if linked_777 == nil { tmp17 = ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { tmp17 = linked_777.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_776, arg_779, arg_780) }; var tmp18 any = tmp14.Invoke_O_O_O__O(tmp15, tmp16, tmp17); var tmp19 any = A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(d__1); var tmp20 *jrt.Class; var fncls__775 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class
						if fncls__775 == nil { var fncls__775d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class = fncls__775d; tmp20 = fncls__775d } else { tmp20 = fncls__775 }
//line :124:1
						return tmp13.Invoke_O_O_O__O(tmp18, r__0, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil).Invoke__O()) } else {
//line :119:1
							if A_arbace_j2g_dyn_A_const_81 != nil {










								var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp22 any; var root_781 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = A_arbace_j2g_dyn_A_const_73; var arg_785 any; var root_787 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = d__1; if linked_788 == nil { arg_785 = ifn_789.Invoke_O__O(arg_790) } else { arg_785 = linked_788.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_787, arg_790) }; var arg_786 any = Lit_20; if linked_782 == nil { tmp22 = ifn_783.Invoke_O_O_O__O(arg_784, arg_785, arg_786) } else { tmp22 = linked_782.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_781, arg_784, arg_785, arg_786) }; return tmp21.Invoke_O_O__O(tmp22, r__0) } else {
//line :119:1
									return nil
								}
						}
				}
		}
	} }
func A_arbace_j2g_dyn_convert_result_fn__711000126_A_New_O(p0 any) *A_arbace_j2g_dyn_convert_result_fn__711000126_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :125:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_A) Invoke_O__O(self any) any { { var d__1 any; var t_ any = t.F_d; t.F_d = nil; d__1 = t_; var n__2 int64 = 0; L1: for { var tmp1 any; var root_743 any = A_arbace_j2g_dyn_A_const_85.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = d__1; if linked_744 == nil { tmp1 = ifn_745.Invoke_O__O(arg_746) } else { tmp1 = linked_744.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_743, arg_746) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_771 any = A_arbace_j2g_dyn_A_const_96.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = d__1; if linked_772 == nil { tmp2 = ifn_773.Invoke_O__O(arg_774) } else { tmp2 = linked_772.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_771, arg_774) }; d__1, n__2 = tmp2, lang.Numbers_Inc_J__J_NoInit(n__2); continue L1 } else {
											var tmp3 any; var root_747 any = A_arbace_j2g_dyn_A_const_91.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any; var tmp4 any = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New(); var tmp5 *jrt.Class; var fncls__752 *jrt.Class = A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class; if fncls__752 == nil { var fncls__752d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class = fncls__752d; tmp5 = fncls__752d } else { tmp5 = fncls__752 }; arg_750 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_751 any; var tmp6 any; var root_753 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = d__1; if linked_754 == nil { tmp6 = ifn_755.Invoke_O__O(arg_756) } else { tmp6 = linked_754.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_753, arg_756) }; if jrt.J2g_Truth(tmp6) {
												var root_757 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_94.GetRawRoot__O()).Invoke_O__O(d__1))).Ref(); if linked_758 == nil { arg_751 = ifn_759.Invoke_O__O(arg_760) } else { arg_751 = linked_758.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_757, arg_760) } } else {
													var root_761 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = A_arbace_j2g_dyn_A_const_73; var arg_765 any; var root_767 any = A_arbace_j2g_dyn_A_const_95.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = d__1; if linked_768 == nil { arg_765 = ifn_769.Invoke_O__O(arg_770) } else { arg_765 = linked_768.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_767, arg_770) }; var arg_766 any = Lit_23; if linked_762 == nil { arg_751 = ifn_763.Invoke_O_O_O__O(arg_764, arg_765, arg_766) } else { arg_751 = linked_762.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_761, arg_764, arg_765, arg_766) } }
//line :126:1
	if linked_748 == nil { tmp3 = ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { tmp3 = linked_748.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_747, arg_750, arg_751) }; return lang.RT_Nth_O_I__O_NoInit(tmp3, lang.RT_IntCast_J__I_NoInit(n__2)) } } }; /*line :125:1*/panic("j2g: unreachable") }
func A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_New() *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Ctor() {}
//line :126:1
func (t *A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A) Invoke_O_O__O(self, p1__711000125_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_92, p1__711000125_SHARP___1) }





func A_arbace_j2g_dyn_call_impl_A_New() *A_arbace_j2g_dyn_call_impl_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_call_impl_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_j2g_dyn_call_impl_A) Ctor() {}
//line :132:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O_O__O(self, this__0, args__1 any) any { var n__3 int64 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(args__1))); if





	lang.Numbers_Lte_J_J__Z_NoInit(n__3, 20) {
		var root_791 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_795 any; var root_799 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp2 any; var root_803 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = Lit_9; var arg_807 any; var root_808 any = A_arbace_j2g_dyn_A_const_100.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any; var root_813 any = A_arbace_j2g_dyn_A_const_101.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref(); var arg_817 any = Lit_10; if linked_814 == nil { arg_811 = ifn_815.Invoke_O_O__O(arg_816, arg_817) } else { arg_811 = linked_814.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_813, arg_816, arg_817) }; var arg_812 any = Lit_10; if linked_809 == nil { arg_807 = ifn_810.Invoke_O_O__O(arg_811, arg_812) } else { arg_807 = linked_809.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_808, arg_811, arg_812) }; if linked_804 == nil { tmp2 = ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { tmp2 = linked_804.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_803, arg_806, arg_807) }; arg_802 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_800 == nil { arg_795 = ifn_801.Invoke_O__O(arg_802) } else { arg_795 = linked_800.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_799, arg_802) }; var arg_796 any = A_arbace_j2g_dyn_A_const_102; var arg_797 any = this__0; var arg_798 any = args__1; if linked_792 == nil { return ifn_793.Invoke_O_O_O_O_O__O(arg_794, arg_795, arg_796, arg_797, arg_798) } else { return linked_792.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_791, arg_794, arg_795, arg_796, arg_797, arg_798) } } else {

			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_dyn_A_const_103; var tmp5 any = A_arbace_j2g_dyn_A_const_104; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_105; var tmp8 any; var root_818 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_822 any = A_arbace_j2g_dyn_A_const_106; var arg_823 any = A_arbace_j2g_dyn_A_const_107; var arg_824 any = this__0; var arg_825 any = args__1; if linked_819 == nil { tmp8 = ifn_820.Invoke_O_O_O_O_O__O(arg_821, arg_822, arg_823, arg_824, arg_825) } else { tmp8 = linked_819.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_818, arg_821, arg_822, arg_823, arg_824, arg_825) }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8)) } }
//line :132:1
func (t *A_arbace_j2g_dyn_call_impl_A) Invoke_O_O__O(self, args__0 any) any {


	var root_826 any = A_arbace_j2g_dyn_A_const_108.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = A_arbace_j2g_dyn_A_const_109; var arg_830 any = args__0; if linked_827 == nil { return ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { return linked_827.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_826, arg_829, arg_830)
	}
}







func A_arbace_j2g_dyn_abstract_text_A_New() *A_arbace_j2g_dyn_abstract_text_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Ctor() {}
//line :145:1
func (t *A_arbace_j2g_dyn_abstract_text_A) Invoke_O_O_O__O(self, ifaces__0, p__711000134__1 any) any { var vec__711000135__3 any = p__711000134__1; var name__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000135__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000135__3; var vec__711000138__7 any; var root_831 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_833 lang.IFn; if



	linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = desc__5; if linked_832 == nil { vec__711000138__7 = ifn_833.Invoke_O__O(arg_834) } else { vec__711000138__7 = linked_832.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_831, arg_834) }; var ps__8 any = /*line :145:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(0), nil); var r__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000138__7, lang.RT_IntCast_J__I_NoInit(1), nil); var declares_QMARK___10 any; var tmp1 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(name__4, desc__5); var tmp2 *jrt.Class; var fncls__845 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class; if




	fncls__845 == nil { var fncls__845d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class = fncls__845d; tmp2 = fncls__845d } else { tmp2 = fncls__845 }; declares_QMARK___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var j__11 any; var or__1927000174__auto____11 any; var root_846 any = /*line :145:1*/A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_848 lang.IFn; if





	linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var root_850 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = declares_QMARK___10; var arg_854 any = ifaces__0; if linked_851 == nil { arg_849 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { arg_849 = linked_851.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; if linked_847 == nil { or__1927000174__auto____11 = ifn_848.Invoke_O__O(arg_849) } else { or__1927000174__auto____11 = linked_847.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_846, arg_849) }; if jrt.J2g_Truth(or__1927000174__auto____11) { j__11 = or__1927000174__auto____11 } else {
		var root_855 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any; var root_859 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any; var tmp3 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(k__6); var tmp4 *jrt.Class; var fncls__874 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class; if fncls__874 == nil { var fncls__874d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class = fncls__874d; tmp4 = fncls__874d } else { tmp4 = fncls__874 }; arg_862 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_863 any = ifaces__0; if linked_860 == nil { arg_858 = ifn_861.Invoke_O_O__O(arg_862, arg_863) } else { arg_858 = linked_860.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_859, arg_862, arg_863) }; if linked_856 == nil { j__11 = ifn_857.Invoke_O__O(arg_858) } else { j__11 = linked_856.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_855, arg_858) } }; var tmp5 /*line :153:1*/*jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns2:)'ns1:.", []*jrt.Class{jrt.String_class}); var tmp6 any; var root_875 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = r__9; if linked_876 == nil { tmp6 = ifn_877.Invoke_O__O(arg_878) } else { tmp6 = linked_876.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_875, arg_878) }; var tmp7 any = tmp6; var tmp8 any; var root_879 any = A_arbace_j2g_dyn_A_const_115.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = Lit_3; var arg_883 any; var root_884 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var arg_888 any = ps__8; if linked_885 == nil { arg_883 = ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { arg_883 = linked_885.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_884, arg_887, arg_888) }; if linked_880 == nil { tmp8 = ifn_881.Invoke_O_O__O(arg_882, arg_883) } else { tmp8 = linked_880.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_879, arg_882, arg_883) }; var tmp9 any = tmp8; var tmp10 *jrt.String; if
	jrt.J2g_Truth(j__11) { var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil); var tmp12 any; var root_889 any = A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = j__11; var arg_893 any = Lit_5; var arg_894 any = Lit_6; if linked_890 == nil { tmp12 = ifn_891.Invoke_O_O_O__O(arg_892, arg_893, arg_894) } else { tmp12 = linked_890.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_889, arg_892, arg_893, arg_894) }; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)) } else { tmp10 = nil }; return /*line :153:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, name__4, nil, tmp9, nil, tmp10.Ref(), nil)).Ref() }
//line :150:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :150:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A) Invoke_O_O__O(self, j__1 any) any { var root_835 any = A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any; var tmp1 any = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(t.F_name, t.F_desc); var tmp2 *jrt.Class; var fncls__840 *jrt.Class = A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class; if fncls__840 == nil { var fncls__840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class = fncls__840d; tmp2 = fncls__840d } else { tmp2 = fncls__840 }; arg_838 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_839 any; var tmp3 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp4 any; var root_841 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = j__1; if linked_842 == nil { tmp4 = ifn_843.Invoke_O__O(arg_844) } else { tmp4 = linked_842.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_841, arg_844) }; arg_839 = tmp3.Invoke_O__O(tmp4); if linked_836 == nil { return ifn_837.Invoke_O_O__O(arg_838, arg_839) } else { return linked_836.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_835, arg_838, arg_839) } }
//line :150:1
func A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :150:1
func (t *A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A) Invoke_O_O__O(self, p1__711000132_SHARP___1 any) any { var tmp1 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(p1__711000132_SHARP___1)); if and__1927000168__auto____2 { var tmp2 any = t.F_desc; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_dyn_A_const_65.Invoke_O__O(p1__711000132_SHARP___1))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_dyn_abstract_text_fn__711000145_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_A) Invoke_O_O__O(self, p1__711000133_SHARP___1 any) any { var root_864 any = A_arbace_j2g_dyn_A_const_111.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any; var tmp1 any = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(t.F_k); var tmp2 *jrt.Class; var fncls__869 *jrt.Class = A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class; if fncls__869 == nil { var fncls__869d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class = fncls__869d; tmp2 = fncls__869d } else { tmp2 = fncls__869 }; arg_867 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_868 any; var root_870 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = p1__711000133_SHARP___1; if linked_871 == nil { arg_868 = ifn_872.Invoke_O__O(arg_873) } else { arg_868 = linked_871.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_870, arg_873) }; if linked_865 == nil { return ifn_866.Invoke_O_O__O(arg_867, arg_868) } else { return linked_865.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_864, arg_867, arg_868) } }
//line :152:1
func A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_New_O(p0 any) *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :152:1
func (t *A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A) Invoke_O_O__O(self, p__711000146__1 any) any { var vec__711000148__2 any = p__711000146__1; var kk__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000148__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___4; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(kk__3, t.F_k)).Ref() }



func A_arbace_j2g_dyn_iface_fallback_A_New() *A_arbace_j2g_dyn_iface_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Ctor() {}
//line :156:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O_O__O(self, ifaces__0, p__711000154__1, pn__2, r__3, core_QMARK___4 any) any { var vec__711000155__6 any = p__711000154__1; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000155__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000155__6; var root_895 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_897 lang.IFn; _ = name__7; _ = desc__8; if





	linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any; var iter__1927001039__auto____10 any; var tmp1 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(r__3, pn__2, core_QMARK___4); var tmp2 *jrt.Class; var fncls__1008 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class; if
	fncls__1008 == nil { var fncls__1008d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class = fncls__1008d; tmp2 = fncls__1008d } else { tmp2 = fncls__1008 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp4 any; var root_1009 any = A_arbace_j2g_dyn_A_const_127.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_j2g_dyn_defaults_for_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = ifaces__0; var arg_1013 any = k__9; if linked_1010 == nil { tmp4 = ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { tmp4 = linked_1010.(*A_arbace_j2g_dyn_defaults_for_A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) }; arg_898 = tmp3.Invoke_O__O(tmp4); var arg_899 any; var tmp5 lang.IFn = /*line :162:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_128; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_129; var tmp9 any = A_arbace_j2g_dyn_A_const_130; var tmp10 any; var root_1014 any = A_arbace_j2g_dyn_A_const_131.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, A_arbace_j2g_dyn_abstract_text_A_fn_class); var ifn_1016 lang.IFn; if




	linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = ifaces__0; var arg_1018 any = k__9; if linked_1015 == nil { tmp10 = ifn_1016.Invoke_O_O__O(arg_1017, arg_1018) } else { tmp10 = linked_1015.(*A_arbace_j2g_dyn_abstract_text_A).Invoke_O_O_O__O(root_1014, arg_1017, arg_1018) }; arg_899 = /*line :162:1*/lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10))); if linked_896 == nil { return ifn_897.Invoke_O_O__O(arg_898, arg_899) } else { return linked_896.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_895, arg_898, arg_899) } }
//line :156:1
func (t *A_arbace_j2g_dyn_iface_fallback_A) Invoke_O_O_O_O_O__O(self, ifaces__0, k__1, pn__2, r__3 any) any {



	var root_1019 any = A_arbace_j2g_dyn_A_const_132.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = ifaces__0; var arg_1023 any = k__1; var arg_1024 any = pn__2; var arg_1025 any = r__3; var arg_1026 any = jrt.Boolean_FALSE.Ref(); if linked_1020 == nil { return ifn_1021.Invoke_O_O_O_O_O__O(arg_1022, arg_1023, arg_1024, arg_1025, arg_1026) } else { return linked_1020.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1019, arg_1022, arg_1023, arg_1024, arg_1025, arg_1026)
	}
}
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Ctor_O_O_O(c__r, c__pn, c__core_QMARK_ any) { t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A) Invoke_O_O__O(self, s__711000159__1 any) any { var tmp1 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(self, s__711000159__1, t.F_r, t.F_pn, t.F_core_QMARK_); var tmp2 *jrt.Class; var fncls__1007 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class; if fncls__1007 == nil { var fncls__1007d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class = fncls__1007d; tmp2 = fncls__1007d } else { tmp2 = fncls__1007 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :163:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Ctor_O_O_O_O_O(c__iter__711000158, c__s__711000159, c__r, c__pn, c__core_QMARK_ any) { t.F_iter__711000158 = c__iter__711000158; t.F_s__711000159 = c__s__711000159; t.F_r = c__r; t.F_pn = c__pn; t.F_core_QMARK_ = c__core_QMARK_ }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A) Invoke_O__O(self any) any { { var s__711000159__1 any; var t_ any = t.F_s__711000159; t.F_s__711000159 = nil; s__711000159__1 = t_; for { var temp__1927000414__auto____2 any; var root_900 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = s__711000159__1; if linked_901 == nil { temp__1927000414__auto____2 = ifn_902.Invoke_O__O(arg_903) } else { temp__1927000414__auto____2 = linked_901.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_900, arg_903) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000159__3 any = temp__1927000414__auto____2; var tmp1 any; var root_904 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = s__711000159__3; if linked_905 == nil { tmp1 = ifn_906.Invoke_O__O(arg_907) } else { tmp1 = linked_905.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_904, arg_907) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_908 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = s__711000159__3; if linked_909 == nil { c__1927001037__auto____4 = ifn_910.Invoke_O__O(arg_911) } else { c__1927001037__auto____4 = linked_909.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_908, arg_911) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000161__6 any; var root_912 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_913 == nil { b__711000161__6 = ifn_914.Invoke_O__O(arg_915) } else { b__711000161__6 = linked_913.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_912, arg_915) }; var tmp2 any = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(b__711000161__6, t.F_r, t.F_pn, size__1927001038__auto____5, t.F_core_QMARK_, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__946 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class; if fncls__946 == nil { var fncls__946d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class = fncls__946d; tmp3 = fncls__946d } else { tmp3 = fncls__946 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_947 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any; var root_952 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = b__711000161__6; if linked_953 == nil { arg_950 = ifn_954.Invoke_O__O(arg_955) } else { arg_950 = linked_953.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_952, arg_955) }; var arg_951 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp5 any; var root_956 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = s__711000159__3; if linked_957 == nil { tmp5 = ifn_958.Invoke_O__O(arg_959) } else { tmp5 = linked_957.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_956, arg_959) }; arg_951 = tmp4.Invoke_O__O(tmp5); if linked_948 == nil { return ifn_949.Invoke_O_O__O(arg_950, arg_951) } else { return linked_948.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_947, arg_950, arg_951) } } else { var root_960 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any; var root_965 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = b__711000161__6; if linked_966 == nil { arg_963 = ifn_967.Invoke_O__O(arg_968) } else { arg_963 = linked_966.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_965, arg_968) }; var arg_964 any; if linked_961 == nil { return ifn_962.Invoke_O_O__O(arg_963, arg_964) } else { return linked_961.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_960, arg_963, arg_964) } } } else { var vec__711000169__4 any; var root_969 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = s__711000159__3; if linked_970 == nil { vec__711000169__4 = ifn_971.Invoke_O__O(arg_972) } else { vec__711000169__4 = linked_970.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_969, arg_972) }; var j__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000169__4, lang.RT_IntCast_J__I_NoInit(1), nil); var this__7 any
														if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_119; var tmp8 any; var root_1002 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = A_arbace_j2g_dyn_A_const_73; var arg_1006 any = j__5; if linked_1003 == nil { tmp8 = ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { tmp8 = linked_1003.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) }; this__7 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, A_arbace_j2g_dyn_A_const_120) } else { this__7 = A_arbace_j2g_dyn_A_const_118 }
//line :163:1
	var root_973 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_121; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyn_A_const_122; var tmp13 any = A_arbace_j2g_dyn_A_const_123; var tmp14 any; var root_978 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_980 lang.IFn

	if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = A_arbace_j2g_dyn_A_const_73; var arg_982 any = j__5; var arg_983 any = Lit_23; if linked_979 == nil { tmp14 = ifn_980.Invoke_O_O_O__O(arg_981, arg_982, arg_983) } else { tmp14 = linked_979.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_978, arg_981, arg_982, arg_983) }; var tmp15 any = tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14); var tmp16 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_15, t.F_r) { var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_124; var tmp19 any; var root_984 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_988 any = fsym__6; var arg_989 any = this__7; var arg_990 any = t.F_pn; if linked_985 == nil { tmp19 = ifn_986.Invoke_O_O_O_O__O(arg_987, arg_988, arg_989, arg_990) } else { tmp19 = linked_985.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_984, arg_987, arg_988, arg_989, arg_990) }; tmp16 = tmp17.Invoke_O_O_O__O(tmp18, tmp19, A_arbace_j2g_dyn_A_const_125) } else { var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_dyn_A_const_126; var tmp22 any; var root_991 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_995 any = fsym__6; var arg_996 any = this__7; var arg_997 any = t.F_pn; if linked_992 == nil { tmp22 = ifn_993.Invoke_O_O_O_O__O(arg_994, arg_995, arg_996, arg_997) } else { tmp22 = linked_992.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_991, arg_994, arg_995, arg_996, arg_997) }; tmp16 = tmp20.Invoke_O_O__O(tmp21, tmp22) }
//line :165:1
	arg_976 = tmp9.Invoke_O_O_O__O(tmp10, tmp15, tmp16)
//line :163:1
	var arg_977 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000158); var tmp24 any; var root_998 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = s__711000159__3; if linked_999 == nil { tmp24 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp24 = linked_999.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_998, arg_1001) }; arg_977 = tmp23.Invoke_O__O(tmp24); if linked_974 == nil { return ifn_975.Invoke_O_O__O(arg_976, arg_977) } else { return linked_974.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_973, arg_976, arg_977) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :163:1
func A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Ctor_O_O_O_I_O_O(c__b__711000161, c__r, c__pn any, c__size__1927001038__auto__ int32, c__core_QMARK_, c__c__1927001037__auto__ any) { t.F_b__711000161 = c__b__711000161; t.F_r = c__r; t.F_pn = c__pn; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_core_QMARK_ = c__core_QMARK_; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :163:1
func (t *A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A) Invoke_O__O(self any) any { { var i__711000160__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000160__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000165__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000160__1)); var j__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fsym__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000165__2, lang.RT_IntCast_J__I_NoInit(1), nil); var this__5 any
																if jrt.J2g_Truth(t.F_core_QMARK_) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_119; var tmp4 any; var root_916 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = A_arbace_j2g_dyn_A_const_73; var arg_920 any = j__3; if linked_917 == nil { tmp4 = ifn_918.Invoke_O_O__O(arg_919, arg_920) } else { tmp4 = linked_917.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_916, arg_919, arg_920) }; this__5 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_j2g_dyn_A_const_120) } else { this__5 = A_arbace_j2g_dyn_A_const_118 }
//line :163:1
	var root_921 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = t.F_b__711000161; var arg_925 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_121; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_dyn_A_const_122; var tmp9 any = A_arbace_j2g_dyn_A_const_123; var tmp10 any; var root_926 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_928 lang.IFn

	if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = A_arbace_j2g_dyn_A_const_73; var arg_930 any = j__3; var arg_931 any = Lit_23; if linked_927 == nil { tmp10 = ifn_928.Invoke_O_O_O__O(arg_929, arg_930, arg_931) } else { tmp10 = linked_927.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_926, arg_929, arg_930, arg_931) }; var tmp11 any = tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10); var tmp12 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_15, t.F_r) { var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_dyn_A_const_124; var tmp15 any; var root_932 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_936 any = fsym__4; var arg_937 any = this__5; var arg_938 any = t.F_pn; if linked_933 == nil { tmp15 = ifn_934.Invoke_O_O_O_O__O(arg_935, arg_936, arg_937, arg_938) } else { tmp15 = linked_933.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_932, arg_935, arg_936, arg_937, arg_938) }; tmp12 = tmp13.Invoke_O_O_O__O(tmp14, tmp15, A_arbace_j2g_dyn_A_const_125) } else { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_126; var tmp18 any; var root_939 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_943 any = fsym__4; var arg_944 any = this__5; var arg_945 any = t.F_pn; if linked_940 == nil { tmp18 = ifn_941.Invoke_O_O_O_O__O(arg_942, arg_943, arg_944, arg_945) } else { tmp18 = linked_940.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_939, arg_942, arg_943, arg_944, arg_945) }; tmp12 = tmp16.Invoke_O_O__O(tmp17, tmp18) }
//line :165:1
	arg_925 = tmp5.Invoke_O_O_O__O(tmp6, tmp11, tmp12)
//line :163:1
	if linked_922 == nil { ifn_923.Invoke_O_O__O(arg_924, arg_925) } else { linked_922.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_921, arg_924, arg_925) }; i__711000160__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000160__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_dyn_method_form_A_New() *A_arbace_j2g_dyn_method_form_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_j2g_dyn_method_form_A) Ctor() {}
//line :169:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O_O__O(self, recv__0, i__1, p__711000177__2, fallback__3, this__4 any) any { var vec__711000180__6 any = p__711000177__2; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000180__6, lang.RT_IntCast_J__I_NoInit(1), nil); var k__9 any = vec__711000180__6; var vec__711000183__10 any; var root_1027 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1029 lang.IFn; _ = k__9; if






	linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = desc__8; if linked_1028 == nil { vec__711000183__10 = ifn_1029.Invoke_O__O(arg_1030) } else { vec__711000183__10 = linked_1028.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1027, arg_1030) }; var ps__11 any = /*line :169:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000183__10, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__13 any; var root_1031 any = A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1033 lang.IFn; if







	linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any; var iter__1927001039__auto____13 any; var tmp1 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New(); var tmp2 *jrt.Class; var fncls__1101 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class; if fncls__1101 == nil { var fncls__1101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class = fncls__1101d; tmp2 = fncls__1101d } else { tmp2 = fncls__1101 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13); var tmp4 any; var root_1102 any = A_arbace_j2g_dyn_A_const_133.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__11)).Ref(); if linked_1103 == nil { tmp4 = ifn_1104.Invoke_O__O(arg_1105) } else { tmp4 = linked_1103.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1102, arg_1105) }; arg_1034 = tmp3.Invoke_O__O(tmp4); if linked_1032 == nil { pn__13 = ifn_1033.Invoke_O__O(arg_1034) } else { pn__13 = linked_1032.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1031, arg_1034) }; var base__14 any; var root_1106 any = /*line :169:1*/A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1108 lang.IFn; if








	linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = name__7; var arg_1110 any = desc__8; if linked_1107 == nil { base__14 = ifn_1108.Invoke_O_O__O(arg_1109, arg_1110) } else { base__14 = linked_1107.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1106, arg_1109, arg_1110) }; var params__15 any; var root_1111 any = /*line :169:1*/A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1113 lang.IFn; if









	linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any; var root_1115 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any; var root_1120 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1122 lang.IFn; if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = A_arbace_j2g_dyn_A_const_135; var arg_1124 any = recv__0; if linked_1121 == nil { arg_1118 = ifn_1122.Invoke_O_O__O(arg_1123, arg_1124) } else { arg_1118 = linked_1121.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1120, arg_1123, arg_1124) }; var arg_1119 any; var root_1125 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any; var tmp5 any = A_arbace_j2g_dyn_method_form_fn__711000196_A_New(); var tmp6 *jrt.Class; var fncls__1141 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class; if fncls__1141 == nil { var fncls__1141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class = fncls__1141d; tmp6 = fncls__1141d } else { tmp6 = fncls__1141 }; arg_1128 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1129 any = pn__13; var arg_1130 any = ps__11; if linked_1126 == nil { arg_1119 = ifn_1127.Invoke_O_O_O__O(arg_1128, arg_1129, arg_1130) } else { arg_1119 = linked_1126.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1125, arg_1128, arg_1129, arg_1130) }; if linked_1116 == nil { arg_1114 = ifn_1117.Invoke_O_O__O(arg_1118, arg_1119) } else { arg_1114 = linked_1116.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1115, arg_1118, arg_1119) }; if linked_1112 == nil { params__15 = ifn_1113.Invoke_O__O(arg_1114) } else { params__15 = linked_1112.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1111, arg_1114) }; var params__16 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_15, r__12) { params__16 = params__15 } else { var root_1142 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = params__15; var arg_1146 any; var tmp7 any = A_arbace_j2g_dyn_A_const_17; var tmp8 any; var root_1147 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = A_arbace_j2g_dyn_A_const_73; var arg_1151 any = r__12; if linked_1148 == nil { tmp8 = ifn_1149.Invoke_O_O__O(arg_1150, arg_1151) } else { tmp8 = linked_1148.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1147, arg_1150, arg_1151) }; arg_1146 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)); if linked_1143 == nil { params__16 = ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { params__16 = linked_1143.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) } }; var call__17 any; var root_1152 any = /*line :169:1*/A_arbace_j2g_dyn_A_const_108.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, A_arbace_j2g_dyn_call_impl_A_fn_class); var ifn_1154 lang.IFn; if











	linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = this__4; var arg_1156 any; var root_1157 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = A_arbace_j2g_dyn_A_const_136.GetRawRoot__O(); var arg_1161 any = pn__13; var arg_1162 any = ps__11; if linked_1158 == nil { arg_1156 = ifn_1159.Invoke_O_O_O__O(arg_1160, arg_1161, arg_1162) } else { arg_1156 = linked_1158.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_1157, arg_1160, arg_1161, arg_1162) }; if linked_1153 == nil { call__17 = ifn_1154.Invoke_O_O__O(arg_1155, arg_1156) } else { call__17 = linked_1153.(*A_arbace_j2g_dyn_call_impl_A).Invoke_O_O_O__O(root_1152, arg_1155, arg_1156) }; var tmp9 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_99.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var tmp11 any = A_arbace_j2g_dyn_A_const_137; var tmp12 any; var root_1172 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = base__14; if linked_1173 == nil { tmp12 = ifn_1174.Invoke_O__O(arg_1175) } else { tmp12 = linked_1173.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1172, arg_1175) }; var tmp13 any = tmp12; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_dyn_A_const_138; var tmp16 any = A_arbace_j2g_dyn_A_const_139; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_140; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_dyn_A_const_141; var tmp21 any = lang.Tuple_Create_O_O__IPersistentVector(tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_142, A_arbace_j2g_dyn_A_const_143)), i__1)); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyn_A_const_144; var tmp24 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_145, A_arbace_j2g_dyn_A_const_146, nil); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyn_A_const_147; var tmp27 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_dyn_A_const_148, call__17); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyn_A_const_149; var tmp30 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_151, A_arbace_j2g_dyn_A_const_152, A_arbace_j2g_dyn_A_const_153); var tmp31 any; if




	lang.Util_Equiv_O_O__Z_NoInit(Lit_15, r__12) { tmp31 = A_arbace_j2g_dyn_A_const_150 } else { var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_dyn_A_const_154; var tmp34 any; var root_1176 any = A_arbace_j2g_dyn_A_const_155.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, A_arbace_j2g_dyn_convert_result_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = A_arbace_j2g_dyn_A_const_156; var arg_1180 any = r__12; if linked_1177 == nil { tmp34 = ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { tmp34 = linked_1177.(*A_arbace_j2g_dyn_convert_result_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) }; tmp31 = tmp32.Invoke_O_O__O(tmp33, tmp34) }; return /*line :182:1*/ tmp9.Invoke_O_O_O_O_O_O__O(tmp10, tmp11, tmp13, params__16, tmp14.Invoke_O_O_O__O(tmp15, tmp21, tmp22.Invoke_O_O_O__O(tmp23, tmp24, tmp25.Invoke_O_O_O__O(tmp26, tmp27, tmp28.Invoke_O_O_O__O(tmp29, tmp30, tmp31)))), lang.IFn_Cast(fallback__3).Invoke_O_O__O(pn__13, r__12)) }
//line :169:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O_O__O(self, recv__0, i__1, k__2, fallback__3 any) any {




	var root_1181 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = recv__0; var arg_1185 any = i__1; var arg_1186 any = k__2; var arg_1187 any = fallback__3; var arg_1188 any = A_arbace_j2g_dyn_A_const_158; if linked_1182 == nil { return ifn_1183.Invoke_O_O_O_O_O__O(arg_1184, arg_1185, arg_1186, arg_1187, arg_1188) } else { return linked_1182.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1181, arg_1184, arg_1185, arg_1186, arg_1187, arg_1188) } }
//line :169:1
func (t *A_arbace_j2g_dyn_method_form_A) Invoke_O_O_O_O__O(self, ifaces__0, i__1, k__2 any) any {



	var root_1189 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = A_arbace_j2g_dyn_A_const_159; var arg_1193 any = i__1; var arg_1194 any = k__2; var arg_1195 any; var tmp1 any = A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(k__2, ifaces__0); var tmp2 *jrt.Class; var fncls__1205 *jrt.Class = A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class; if fncls__1205 == nil { var fncls__1205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class = fncls__1205d; tmp2 = fncls__1205d } else { tmp2 = fncls__1205 }; arg_1195 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1196 any = A_arbace_j2g_dyn_A_const_160; if linked_1190 == nil { return ifn_1191.Invoke_O_O_O_O_O__O(arg_1192, arg_1193, arg_1194, arg_1195, arg_1196) } else { return linked_1190.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O_O__O(root_1189, arg_1192, arg_1193, arg_1194, arg_1195, arg_1196) } }
//line :173:1
func A_arbace_j2g_dyn_method_form_fn__711000178_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_fn__711000178_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000178_A{}; t.Ctor_O_O(p0, p1); return t }
//line :173:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :173:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000178_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_1197 any = A_arbace_j2g_dyn_A_const_132.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = t.F_ifaces; var arg_1201 any = t.F_k; var arg_1202 any = pn__1; var arg_1203 any = r__2; var arg_1204 any = jrt.Boolean_TRUE.Ref(); if linked_1198 == nil { return ifn_1199.Invoke_O_O_O_O_O__O(arg_1200, arg_1201, arg_1202, arg_1203, arg_1204) } else { return linked_1198.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O_O__O(root_1197, arg_1200, arg_1201, arg_1202, arg_1203, arg_1204) } }



func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_New() *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A) Invoke_O_O__O(self, s__711000187__1 any) any { var tmp1 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(s__711000187__1, self); var tmp2 *jrt.Class; var fncls__1100 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class; if fncls__1100 == nil { var fncls__1100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class = fncls__1100d; tmp2 = fncls__1100d } else { tmp2 = fncls__1100 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :177:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A{}; t.Ctor_O_O(p0, p1); return t }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Ctor_O_O(c__s__711000187, c__iter__711000186 any) { t.F_s__711000187 = c__s__711000187; t.F_iter__711000186 = c__iter__711000186 }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A) Invoke_O__O(self any) any { { var s__711000187__1 any; var t_ any = t.F_s__711000187; t.F_s__711000187 = nil; s__711000187__1 = t_; for { var temp__1927000414__auto____2 any; var root_1035 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = s__711000187__1; if linked_1036 == nil { temp__1927000414__auto____2 = ifn_1037.Invoke_O__O(arg_1038) } else { temp__1927000414__auto____2 = linked_1036.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1035, arg_1038) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000187__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1039 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = s__711000187__3; if linked_1040 == nil { tmp1 = ifn_1041.Invoke_O__O(arg_1042) } else { tmp1 = linked_1040.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1039, arg_1042) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1043 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1045 lang.IFn; if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = s__711000187__3; if linked_1044 == nil { c__1927001037__auto____4 = ifn_1045.Invoke_O__O(arg_1046) } else { c__1927001037__auto____4 = linked_1044.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1043, arg_1046) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000189__6 any; var root_1047 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1048 == nil { b__711000189__6 = ifn_1049.Invoke_O__O(arg_1050) } else { b__711000189__6 = linked_1048.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1047, arg_1050) }; var tmp2 any = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(b__711000189__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1060 *jrt.Class = A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class; if fncls__1060 == nil { var fncls__1060d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class = fncls__1060d; tmp3 = fncls__1060d } else { tmp3 = fncls__1060 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1061 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any; var root_1066 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = b__711000189__6; if linked_1067 == nil { arg_1064 = ifn_1068.Invoke_O__O(arg_1069) } else { arg_1064 = linked_1067.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1066, arg_1069) }; var arg_1065 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp5 any; var root_1070 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = s__711000187__3; if linked_1071 == nil { tmp5 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp5 = linked_1071.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1070, arg_1073) }; arg_1065 = tmp4.Invoke_O__O(tmp5); if linked_1062 == nil { return ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { return linked_1062.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) } } else { var root_1074 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any; var root_1079 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = b__711000189__6; if linked_1080 == nil { arg_1077 = ifn_1081.Invoke_O__O(arg_1082) } else { arg_1077 = linked_1080.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1079, arg_1082) }; var arg_1078 any; if linked_1075 == nil { return ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { return linked_1075.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) } } } else { var j__4 any; var root_1083 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1085 lang.IFn; if linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = s__711000187__3; if linked_1084 == nil { j__4 = ifn_1085.Invoke_O__O(arg_1086) } else { j__4 = linked_1084.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1083, arg_1086) }; var root_1087 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any; var root_1092 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_124, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__4)).Ref(); if linked_1093 == nil { arg_1090 = ifn_1094.Invoke_O__O(arg_1095) } else { arg_1090 = linked_1093.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1092, arg_1095) }; var arg_1091 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000186); var tmp7 any; var root_1096 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = s__711000187__3; if linked_1097 == nil { tmp7 = ifn_1098.Invoke_O__O(arg_1099) } else { tmp7 = linked_1097.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1096, arg_1099) }; arg_1091 = tmp6.Invoke_O__O(tmp7); if linked_1088 == nil { return ifn_1089.Invoke_O_O__O(arg_1090, arg_1091) } else { return linked_1088.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1087, arg_1090, arg_1091) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :177:1
func A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Ctor_O_I_O(c__b__711000189 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000189 = c__b__711000189; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :177:1
func (t *A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A) Invoke_O__O(self any) any { { var i__711000188__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000188__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000188__1)); var root_1051 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = t.F_b__711000189; var arg_1055 any; var root_1056 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_124, nil), jrt.RefArrayOf(jrt.Object_class, nil, j__2)).Ref(); if linked_1057 == nil { arg_1055 = ifn_1058.Invoke_O__O(arg_1059) } else { arg_1055 = linked_1057.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1056, arg_1059) }; if linked_1052 == nil { ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { linked_1052.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) }; i__711000188__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000188__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_method_form_fn__711000196_A_New() *A_arbace_j2g_dyn_method_form_fn__711000196_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_method_form_fn__711000196_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Ctor() {}
//line :179:1
func (t *A_arbace_j2g_dyn_method_form_fn__711000196_A) Invoke_O_O_O__O(self, p1__711000175_SHARP___1, p2__711000176_SHARP___2 any) any { var root_1131 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = p1__711000175_SHARP___1; var arg_1135 any; var root_1136 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = A_arbace_j2g_dyn_A_const_73; var arg_1140 any = p2__711000176_SHARP___2; if linked_1137 == nil { arg_1135 = ifn_1138.Invoke_O_O__O(arg_1139, arg_1140) } else { arg_1135 = linked_1137.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1136, arg_1139, arg_1140) }; if linked_1132 == nil { return ifn_1133.Invoke_O_O__O(arg_1134, arg_1135) } else { return linked_1132.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1131, arg_1134, arg_1135) } }










func A_arbace_j2g_dyn_native_name_A_New() *A_arbace_j2g_dyn_native_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_native_name_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_j2g_dyn_native_name_A) Ctor() {}
//line :190:1
func (t *A_arbace_j2g_dyn_native_name_A) Invoke_O_O_O__O(self, mname__0, desc__1 any) any {
	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil, Lit_125); var tmp2 any; var root_1206 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = A_arbace_j2g_dyn_A_const_31.GetRawRoot__O(); if linked_1207 == nil { tmp2 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp2 = linked_1207.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1206, arg_1209) }; var tmp3 any = tmp2; var tmp4 any; var root_1210 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = mname__0; var arg_1214 any = desc__1; if linked_1211 == nil { tmp4 = ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { tmp4 = linked_1211.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref()
}























func A_arbace_j2g_dyn_proxy_classes_A_New() *A_arbace_j2g_dyn_proxy_classes_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Ctor() {}
//line :216:1
func (t *A_arbace_j2g_dyn_proxy_classes_A) Invoke_O_O__O(self, T__0_ any) any {



	var root_1215 any = A_arbace_j2g_dyn_A_const_35.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any; var tmp1 any = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(T__0_); var tmp2 *jrt.Class; var fncls__1257 *jrt.Class = A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class; if fncls__1257 == nil { var fncls__1257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class = fncls__1257d; tmp2 = fncls__1257d } else { tmp2 = fncls__1257 }; arg_1218 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1219 any = A_arbace_j2g_dyn_A_const_163.GetRawRoot__O(); if linked_1216 == nil { return ifn_1217.Invoke_O_O__O(arg_1218, arg_1219) } else { return linked_1216.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1215, arg_1218, arg_1219) } }
//line :220:1
func A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_classes_fn__711000201_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Ctor_O(c__T any) { t.F_T = c__T }
//line :220:1
func (t *A_arbace_j2g_dyn_proxy_classes_fn__711000201_A) Invoke_O_O__O(self, p1__711000200_SHARP___1 any) any { var and__1927000168__auto____2 any; var or__1927000174__auto____2 any; var root_1220 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = t.F_T; var arg_1224 any = p1__711000200_SHARP___1; if linked_1221 == nil { or__1927000174__auto____2 = ifn_1222.Invoke_O_O__O(arg_1223, arg_1224) } else { or__1927000174__auto____2 = linked_1221.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1220, arg_1223, arg_1224) }; if jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { var root_1225 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = p1__711000200_SHARP___1; if linked_1226 == nil { and__1927000168__auto____2 = ifn_1227.Invoke_O__O(arg_1228) } else { and__1927000168__auto____2 = linked_1226.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1225, arg_1228) } }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_1229 any = A_arbace_j2g_dyn_A_const_54.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = p1__711000200_SHARP___1; if linked_1230 == nil { and__1927000168__auto____3 = ifn_1231.Invoke_O__O(arg_1232) } else { and__1927000168__auto____3 = linked_1230.(*aot_arbace_j2g_model.A_arbace_j2g_model_in_world_QMARK__A).Invoke_O_O__O(root_1229, arg_1232) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_1233 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1235 lang.IFn
														if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any; var root_1237 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = p1__711000200_SHARP___1; if linked_1238 == nil { arg_1236 = ifn_1239.Invoke_O__O(arg_1240) } else { arg_1236 = linked_1238.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_1237, arg_1240) }; if linked_1234 == nil { and__1927000168__auto____4 = ifn_1235.Invoke_O__O(arg_1236) } else { and__1927000168__auto____4 = linked_1234.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1233, arg_1236) }
//line :220:1
	if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_1241 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1243 lang.IFn
		if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any; var root_1245 any = A_arbace_j2g_dyn_A_const_161.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = p1__711000200_SHARP___1; if linked_1246 == nil { arg_1244 = ifn_1247.Invoke_O__O(arg_1248) } else { arg_1244 = linked_1246.(*aot_arbace_j2g_model.A_arbace_j2g_model_final_QMARK__A).Invoke_O_O__O(root_1245, arg_1248) }; if linked_1242 == nil { and__1927000168__auto____5 = ifn_1243.Invoke_O__O(arg_1244) } else { and__1927000168__auto____5 = linked_1242.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1241, arg_1244) }
//line :220:1
		if jrt.J2g_Truth(and__1927000168__auto____5) {
			var root_1249 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1251 lang.IFn; if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any; var root_1253 any = A_arbace_j2g_dyn_A_const_162.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = p1__711000200_SHARP___1; if linked_1254 == nil { arg_1252 = ifn_1255.Invoke_O__O(arg_1256) } else { arg_1252 = linked_1254.(*aot_arbace_j2g_model.A_arbace_j2g_model_leaf_QMARK__A).Invoke_O_O__O(root_1253, arg_1256) }; if linked_1250 == nil { return ifn_1251.Invoke_O__O(arg_1252) } else { return linked_1250.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1249, arg_1252) } } else {
//line :220:1
				return and__1927000168__auto____5 } } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_j2g_dyn_sub_name_A_New() *A_arbace_j2g_dyn_sub_name_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_name_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_j2g_dyn_sub_name_A) Ctor() {}
//line :224:1
func (t *A_arbace_j2g_dyn_sub_name_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_166, nil); var tmp2 any; var root_1258 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = n__0; if linked_1259 == nil { tmp2 = ifn_1260.Invoke_O__O(arg_1261) } else { tmp2 = linked_1259.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1258, arg_1261) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }

func A_arbace_j2g_dyn_proxy_roots_A_New() *A_arbace_j2g_dyn_proxy_roots_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Ctor() {}
//line :226:1
func (t *A_arbace_j2g_dyn_proxy_roots_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New(); var tmp2 *jrt.Class; var fncls__1465 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class; if



	fncls__1465 == nil { var fncls__1465d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class = fncls__1465d; tmp2 = fncls__1465d } else { tmp2 = fncls__1465 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(A_arbace_j2g_dyn_A_const_163.GetRawRoot__O()) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_New() *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Ctor() {}
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A) Invoke_O_O__O(self, s__711000206__1 any) any { var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(self, s__711000206__1); var tmp2 *jrt.Class; var fncls__1464 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class; if fncls__1464 == nil { var fncls__1464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class = fncls__1464d; tmp2 = fncls__1464d } else { tmp2 = fncls__1464 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A{}; t.Ctor_O_O(p0, p1); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Ctor_O_O(c__iter__711000205, c__s__711000206 any) { t.F_iter__711000205 = c__iter__711000205; t.F_s__711000206 = c__s__711000206 }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A) Invoke_O__O(self any) any { { var s__711000206__1 any; var t_ any = t.F_s__711000206; t.F_s__711000206 = nil; s__711000206__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1262 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = s__711000206__1; if linked_1263 == nil { temp__1927000414__auto____2 = ifn_1264.Invoke_O__O(arg_1265) } else { temp__1927000414__auto____2 = linked_1263.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1262, arg_1265) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_1266 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = xs__1927001018__auto____3; if linked_1267 == nil { n__4 = ifn_1268.Invoke_O__O(arg_1269) } else { n__4 = linked_1267.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1266, arg_1269) }; var tmp1 any; var and__1927000168__auto____5 any; var root_1270 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1272 lang.IFn
														if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = n__4; if linked_1271 == nil { and__1927000168__auto____5 = ifn_1272.Invoke_O__O(arg_1273) } else { and__1927000168__auto____5 = linked_1271.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1270, arg_1273) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1274 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1276 lang.IFn; if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any; var root_1278 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = n__4; if linked_1279 == nil { arg_1277 = ifn_1280.Invoke_O__O(arg_1281) } else { arg_1277 = linked_1279.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1278, arg_1281) }; if linked_1275 == nil { tmp1 = ifn_1276.Invoke_O__O(arg_1277) } else { tmp1 = linked_1275.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1274, arg_1277) } } else { tmp1 = and__1927000168__auto____5 }
//line :230:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(n__4); var tmp3 *jrt.Class; var fncls__1438 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class; if fncls__1438 == nil { var fncls__1438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class = fncls__1438d; tmp3 = fncls__1438d } else { tmp3 = fncls__1438 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1439 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var root_1443 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_1445 lang.IFn

		if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = n__4; if linked_1444 == nil { tmp5 = ifn_1445.Invoke_O__O(arg_1446) } else { tmp5 = linked_1444.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_1443, arg_1446) }
//line :230:1
		arg_1442 = tmp4.Invoke_O__O(tmp5); if linked_1440 == nil { fs__1927001036__auto____6 = ifn_1441.Invoke_O__O(arg_1442) } else { fs__1927001036__auto____6 = linked_1440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1439, arg_1442) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1447 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = fs__1927001036__auto____6; var arg_1451 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000205); var tmp7 any; var root_1452 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = s__711000206__1; if linked_1453 == nil { tmp7 = ifn_1454.Invoke_O__O(arg_1455) } else { tmp7 = linked_1453.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1452, arg_1455) }; arg_1451 = tmp6.Invoke_O__O(tmp7); if linked_1448 == nil { return ifn_1449.Invoke_O_O__O(arg_1450, arg_1451) } else { return linked_1448.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1447, arg_1450, arg_1451) } } else { var tmp8 any; var root_1456 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = s__711000206__1; if linked_1457 == nil { tmp8 = ifn_1458.Invoke_O__O(arg_1459) } else { tmp8 = linked_1457.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1456, arg_1459) }; s__711000206__1 = tmp8; continue L1 } } else { var tmp9 any; var root_1460 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = s__711000206__1; if linked_1461 == nil { tmp9 = ifn_1462.Invoke_O__O(arg_1463) } else { tmp9 = linked_1461.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1460, arg_1463) }; s__711000206__1 = tmp9; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_New_O(p0 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A) Invoke_O_O__O(self, s__711000208__1 any) any { var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(self, t.F_n, s__711000208__1); var tmp2 *jrt.Class; var fncls__1437 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class; if fncls__1437 == nil { var fncls__1437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class = fncls__1437d; tmp2 = fncls__1437d } else { tmp2 = fncls__1437 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Ctor_O_O_O(c__iter__711000207, c__n, c__s__711000208 any) { t.F_iter__711000207 = c__iter__711000207; t.F_n = c__n; t.F_s__711000208 = c__s__711000208 }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A) Invoke_O__O(self any) any { { var s__711000208__1 any; var t_ any = t.F_s__711000208; t.F_s__711000208 = nil; s__711000208__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1282 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any = s__711000208__1; if linked_1283 == nil { temp__1927000414__auto____2 = ifn_1284.Invoke_O__O(arg_1285) } else { temp__1927000414__auto____2 = linked_1283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1282, arg_1285) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_1286 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1286, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1288 lang.IFn; if linked_1287 == nil { ifn_1288 = lang.IFn_Cast(root_1286) } else { ifn_1288 = nil }; var arg_1289 any = xs__1927001018__auto____3; if linked_1287 == nil { c__4 = ifn_1288.Invoke_O__O(arg_1289) } else { c__4 = linked_1287.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1286, arg_1289) }; var tmp1 any
																			var and__1927000168__auto____5 any = c__4

	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1290 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1290, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any = c__4; var arg_1294 any = Lit_98; if linked_1291 == nil { and__1927000168__auto____6 = ifn_1292.Invoke_O_O__O(arg_1293, arg_1294) } else { and__1927000168__auto____6 = linked_1291.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1290, arg_1293, arg_1294) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1295 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = c__4; if linked_1296 == nil { tmp1 = ifn_1297.Invoke_O__O(arg_1298) } else { tmp1 = linked_1296.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1295, arg_1298) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }
//line :230:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(t.F_n, c__4); var tmp3 *jrt.Class; var fncls__1411 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class; if fncls__1411 == nil { var fncls__1411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class = fncls__1411d; tmp3 = fncls__1411d } else { tmp3 = fncls__1411 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_1412 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp6 any; var root_1416 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_1418 lang.IFn



		if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = c__4; if linked_1417 == nil { tmp6 = ifn_1418.Invoke_O__O(arg_1419) } else { tmp6 = linked_1417.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_1416, arg_1419) }
//line :230:1
		arg_1415 = tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6)); if linked_1413 == nil { fs__1927001036__auto____6 = ifn_1414.Invoke_O__O(arg_1415) } else { fs__1927001036__auto____6 = linked_1413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1412, arg_1415) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1420 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = fs__1927001036__auto____6; var arg_1424 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000207); var tmp8 any; var root_1425 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = s__711000208__1; if linked_1426 == nil { tmp8 = ifn_1427.Invoke_O__O(arg_1428) } else { tmp8 = linked_1426.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1425, arg_1428) }; arg_1424 = tmp7.Invoke_O__O(tmp8); if linked_1421 == nil { return ifn_1422.Invoke_O_O__O(arg_1423, arg_1424) } else { return linked_1421.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1420, arg_1423, arg_1424) } } else { var tmp9 any; var root_1429 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = s__711000208__1; if linked_1430 == nil { tmp9 = ifn_1431.Invoke_O__O(arg_1432) } else { tmp9 = linked_1430.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1429, arg_1432) }; s__711000208__1 = tmp9; continue L1 } } else { var tmp10 any; var root_1433 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = s__711000208__1; if linked_1434 == nil { tmp10 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp10 = linked_1434.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1433, arg_1436) }; s__711000208__1 = tmp10; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A{}; t.Ctor_O_O(p0, p1); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Ctor_O_O(c__n, c__c any) { t.F_n = c__n; t.F_c = c__c }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A) Invoke_O_O__O(self, s__711000210__1 any) any { var tmp1 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(s__711000210__1, t.F_n, self, t.F_c); var tmp2 *jrt.Class; var fncls__1410 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class; if fncls__1410 == nil { var fncls__1410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class = fncls__1410d; tmp2 = fncls__1410d } else { tmp2 = fncls__1410 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Ctor_O_O_O_O(c__s__711000210, c__n, c__iter__711000209, c__c any) { t.F_s__711000210 = c__s__711000210; t.F_n = c__n; t.F_iter__711000209 = c__iter__711000209; t.F_c = c__c }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A) Invoke_O__O(self any) any { { var s__711000210__1 any; var t_ any = t.F_s__711000210; t.F_s__711000210 = nil; s__711000210__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1299 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = s__711000210__1; if linked_1300 == nil { temp__1927000414__auto____2 = ifn_1301.Invoke_O__O(arg_1302) } else { temp__1927000414__auto____2 = linked_1300.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1299, arg_1302) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000210__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1303 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = s__711000210__3; if linked_1304 == nil { tmp1 = ifn_1305.Invoke_O__O(arg_1306) } else { tmp1 = linked_1304.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1303, arg_1306) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1307 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = s__711000210__3; if linked_1308 == nil { c__1927001037__auto____4 = ifn_1309.Invoke_O__O(arg_1310) } else { c__1927001037__auto____4 = linked_1308.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1307, arg_1310) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000212__6 any; var root_1311 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1312 == nil { b__711000212__6 = ifn_1313.Invoke_O__O(arg_1314) } else { b__711000212__6 = linked_1312.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1311, arg_1314) }; var tmp2 any = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(t.F_n, b__711000212__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__1341 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class; if fncls__1341 == nil { var fncls__1341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class = fncls__1341d; tmp3 = fncls__1341d } else { tmp3 = fncls__1341 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1342 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any; var root_1347 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1347, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1349 lang.IFn; if linked_1348 == nil { ifn_1349 = lang.IFn_Cast(root_1347) } else { ifn_1349 = nil }; var arg_1350 any = b__711000212__6; if linked_1348 == nil { arg_1345 = ifn_1349.Invoke_O__O(arg_1350) } else { arg_1345 = linked_1348.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1347, arg_1350) }; var arg_1346 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp5 any; var root_1351 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = s__711000210__3; if linked_1352 == nil { tmp5 = ifn_1353.Invoke_O__O(arg_1354) } else { tmp5 = linked_1352.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1351, arg_1354) }; arg_1346 = tmp4.Invoke_O__O(tmp5); if linked_1343 == nil { return ifn_1344.Invoke_O_O__O(arg_1345, arg_1346) } else { return linked_1343.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1342, arg_1345, arg_1346) } } else { var root_1355 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1357 lang.IFn; if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any; var root_1360 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = b__711000212__6; if linked_1361 == nil { arg_1358 = ifn_1362.Invoke_O__O(arg_1363) } else { arg_1358 = linked_1361.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1360, arg_1363) }; var arg_1359 any; if linked_1356 == nil { return ifn_1357.Invoke_O_O__O(arg_1358, arg_1359) } else { return linked_1356.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1355, arg_1358, arg_1359) } } } else { var mm__4 any; var root_1364 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1364, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1366 lang.IFn; if linked_1365 == nil { ifn_1366 = lang.IFn_Cast(root_1364) } else { ifn_1366 = nil }; var arg_1367 any = s__711000210__3; if linked_1365 == nil { mm__4 = ifn_1366.Invoke_O__O(arg_1367) } else { mm__4 = linked_1365.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1364, arg_1367) }; var tmp6 any; var root_1368 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1370 lang.IFn




	if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any; var root_1372 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any = mm__4; if linked_1373 == nil { arg_1371 = ifn_1374.Invoke_O__O(arg_1375) } else { arg_1371 = linked_1373.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1372, arg_1375) }; if linked_1369 == nil { tmp6 = ifn_1370.Invoke_O__O(arg_1371) } else { tmp6 = linked_1369.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1368, arg_1371) }
//line :230:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4))





		if or__1927000174__auto____5 { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1376 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any; var root_1380 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = mm__4; if linked_1381 == nil { arg_1379 = ifn_1382.Invoke_O__O(arg_1383) } else { arg_1379 = linked_1381.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1380, arg_1383) }; if linked_1377 == nil { tmp7 = ifn_1378.Invoke_O__O(arg_1379) } else { tmp7 = linked_1377.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1376, arg_1379) } }
//line :230:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____5_2 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var root_1384 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = Lit_29; var arg_1388 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_1385 == nil { tmp8 = ifn_1386.Invoke_O_O__O(arg_1387, arg_1388) } else { tmp8 = linked_1385.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1384, arg_1387, arg_1388) } }
//line :230:1
			if jrt.J2g_Truth(tmp8) { var root_1389 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var tmp9 any = t.F_c; var arg_1392 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4)); var arg_1393 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__711000209); var tmp11 any; var root_1394 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = s__711000210__3; if linked_1395 == nil { tmp11 = ifn_1396.Invoke_O__O(arg_1397) } else { tmp11 = linked_1395.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1394, arg_1397) }; arg_1393 = tmp10.Invoke_O__O(tmp11); if linked_1390 == nil { return ifn_1391.Invoke_O_O__O(arg_1392, arg_1393) } else { return linked_1390.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1389, arg_1392, arg_1393) } } else { var tmp12 any; var root_1398 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = s__711000210__3; if linked_1399 == nil { tmp12 = ifn_1400.Invoke_O__O(arg_1401) } else { tmp12 = linked_1399.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1398, arg_1401) }; s__711000210__1 = tmp12; continue L1 } } else { var tmp13 any; var root_1402 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = s__711000210__3; if linked_1403 == nil { tmp13 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp13 = linked_1403.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1402, arg_1405) }; s__711000210__1 = tmp13; continue L1 } } else { var tmp14 any; var root_1406 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1408 lang.IFn; if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any = s__711000210__3; if linked_1407 == nil { tmp14 = ifn_1408.Invoke_O__O(arg_1409) } else { tmp14 = linked_1407.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1406, arg_1409) }; s__711000210__1 = tmp14; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :230:1
func A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Ctor_O_O_I_O_O(c__n, c__b__711000212 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__c any) { t.F_n = c__n; t.F_b__711000212 = c__b__711000212; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :230:1
func (t *A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A) Invoke_O__O(self any) any { { var i__711000211__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000211__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000211__1)); var tmp2 any; var root_1315 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1317 lang.IFn




	if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any; var root_1319 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = mm__2; if linked_1320 == nil { arg_1318 = ifn_1321.Invoke_O__O(arg_1322) } else { arg_1318 = linked_1320.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_1319, arg_1322) }; if linked_1316 == nil { tmp2 = ifn_1317.Invoke_O__O(arg_1318) } else { tmp2 = linked_1316.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1315, arg_1318) }
//line :230:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2))





		if or__1927000174__auto____3 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1323 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any; var root_1327 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = mm__2; if linked_1328 == nil { arg_1326 = ifn_1329.Invoke_O__O(arg_1330) } else { arg_1326 = linked_1328.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1327, arg_1330) }; if linked_1324 == nil { tmp3 = ifn_1325.Invoke_O__O(arg_1326) } else { tmp3 = linked_1324.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1323, arg_1326) } }
//line :230:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)






			if or__1927000174__auto____3_2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var root_1331 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_1332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1331, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1333 lang.IFn; if linked_1332 == nil { ifn_1333 = lang.IFn_Cast(root_1331) } else { ifn_1333 = nil }; var arg_1334 any = Lit_29; var arg_1335 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_1332 == nil { tmp4 = ifn_1333.Invoke_O_O__O(arg_1334, arg_1335) } else { tmp4 = linked_1332.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1331, arg_1334, arg_1335) } }
//line :230:1
			if jrt.J2g_Truth(tmp4) { var root_1336 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = t.F_b__711000212; var tmp5 any = t.F_c; var arg_1340 any = lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2), A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2)); if linked_1337 == nil { ifn_1338.Invoke_O_O__O(arg_1339, arg_1340) } else { linked_1337.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1336, arg_1339, arg_1340) }; i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { i__711000211__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000211__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_j2g_dyn_object_fallback_A_New() *A_arbace_j2g_dyn_object_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_object_fallback_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Ctor() {}
//line :240:1
func (t *A_arbace_j2g_dyn_object_fallback_A) Invoke_O_O_O_O__O(self, n__0, k__1, pn__2 any) any { var impl__4 any; var root_1466 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1468 lang.IFn; if



	linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any = n__0; var arg_1470 any = k__1; if linked_1467 == nil { impl__4 = ifn_1468.Invoke_O_O__O(arg_1469, arg_1470) } else { impl__4 = linked_1467.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1466, arg_1469, arg_1470) }; var base__5 any; var root_1471 any = /*line :240:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1473 lang.IFn; if




	linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var arg_1475 any = k__1; if linked_1472 == nil { base__5 = ifn_1473.Invoke_O_O__O(arg_1474, arg_1475) } else { base__5 = linked_1472.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1471, arg_1474, arg_1475) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_167); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__4))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_168; var tmp4 any; var root_1476 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1478 lang.IFn
		if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1480 any; var root_1484 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__5)).Ref(); if linked_1485 == nil { arg_1480 = ifn_1486.Invoke_O__O(arg_1487) } else { arg_1480 = linked_1485.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1484, arg_1487) }; var arg_1481 any = A_arbace_j2g_dyn_A_const_169; var arg_1482 any = A_arbace_j2g_dyn_A_const_170; var arg_1483 any = pn__2; if linked_1477 == nil { tmp4 = ifn_1478.Invoke_O_O_O_O_O__O(arg_1479, arg_1480, arg_1481, arg_1482, arg_1483) } else { tmp4 = linked_1477.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1476, arg_1479, arg_1480, arg_1481, arg_1482, arg_1483) }
//line :246:1
		return lang.Tuple_Create_O__IPersistentVector(tmp2.Invoke_O_O__O(tmp3, tmp4)) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_171; var tmp7 any; var G__711000228__6_ any; var root_1488 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1490 lang.IFn

			if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = k__1; if linked_1489 == nil { G__711000228__6_ = ifn_1490.Invoke_O__O(arg_1491) } else { G__711000228__6_ = linked_1489.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1488, arg_1491) }; L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__711000228__6_) >> 1 & 3 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_126) { tmp7 = A_arbace_j2g_dyn_A_const_172; break L1 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_127) { tmp7 = A_arbace_j2g_dyn_A_const_173; break L1 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__711000228__6_, Lit_128) {


				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_174; var tmp10 any = A_arbace_j2g_dyn_A_const_175; var tmp11 any; var root_1493 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = pn__2; if linked_1494 == nil { tmp11 = ifn_1495.Invoke_O__O(arg_1496) } else { tmp11 = linked_1494.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1493, arg_1496) }; tmp7 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11)
//line :248:1
				break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_129, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__711000228__6_)))))}
//line :246:1
			return lang.Tuple_Create_O__IPersistentVector(tmp5.Invoke_O_O__O(tmp6, tmp7)) } }






func A_arbace_j2g_dyn_class_fallback_A_New() *A_arbace_j2g_dyn_class_fallback_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Ctor() {}
//line :253:1
func (t *A_arbace_j2g_dyn_class_fallback_A) Invoke_O_O_O_O_O__O(self, n__0, p__711000230__1, pn__2, r__3 any) any { var vec__711000231__5 any = p__711000230__1; var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000231__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__711000231__5; var impl__9 any; var root_1497 any = A_arbace_j2g_dyn_A_const_68.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A_fn_class); var ifn_1499 lang.IFn; if



	linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = n__0; var arg_1501 any = k__8; if linked_1498 == nil { impl__9 = ifn_1499.Invoke_O_O__O(arg_1500, arg_1501) } else { impl__9 = linked_1498.(*aot_arbace_j2g_model.A_arbace_j2g_model_impl_of_A).Invoke_O_O_O__O(root_1497, arg_1500, arg_1501) }; var base__10 any; var root_1502 any = /*line :253:1*/A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_1504 lang.IFn; if




	linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = name__6; var arg_1506 any = desc__7; if linked_1503 == nil { base__10 = ifn_1504.Invoke_O_O__O(arg_1505, arg_1506) } else { base__10 = linked_1503.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_1502, arg_1505, arg_1506) }; var ret__11 any; var tmp1 any = /*line :253:1*/A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(r__3); var tmp2 *jrt.Class; var fncls__1507 *jrt.Class = A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class; if





	fncls__1507 == nil { var fncls__1507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class = fncls__1507d; tmp2 = fncls__1507d } else { tmp2 = fncls__1507 }; ret__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var G__711000236__12_ any = /*line :253:1*/A_arbace_j2g_dyn_A_const_70.Invoke_O__O(impl__9); switch






	lang.Util_Hash_O__I_NoInit(G__711000236__12_) >> 4 & 3 { case 0: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_69) {

		var tmp3 lang.IFn = lang.IFn_Cast(ret__11); var tmp4 any; var root_1513 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1517 any; var root_1520 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = A_arbace_j2g_dyn_A_const_73; var arg_1524 any = A_arbace_j2g_dyn_A_const_71.Invoke_O__O(impl__9); var arg_1525 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1521 == nil { arg_1517 = ifn_1522.Invoke_O_O_O__O(arg_1523, arg_1524, arg_1525) } else { arg_1517 = linked_1521.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1520, arg_1523, arg_1524, arg_1525) }; var arg_1518 any = A_arbace_j2g_dyn_A_const_180; var arg_1519 any = pn__2; if linked_1514 == nil { tmp4 = ifn_1515.Invoke_O_O_O_O__O(arg_1516, arg_1517, arg_1518, arg_1519) } else { tmp4 = linked_1514.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1513, arg_1516, arg_1517, arg_1518, arg_1519) }; return tmp3.Invoke_O__O(tmp4) }
//line :260:1
	case 1: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_177) {
		var tmp5 lang.IFn = lang.IFn_Cast(ret__11); var tmp6 any; var root_1526 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1530 any; var root_1534 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1534, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1536 lang.IFn; if linked_1535 == nil { ifn_1536 = lang.IFn_Cast(root_1534) } else { ifn_1536 = nil }; var arg_1537 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1535 == nil { arg_1530 = ifn_1536.Invoke_O__O(arg_1537) } else { arg_1530 = linked_1535.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1534, arg_1537) }; var arg_1531 any = A_arbace_j2g_dyn_A_const_181; var arg_1532 any = A_arbace_j2g_dyn_A_const_182; var arg_1533 any = pn__2; if linked_1527 == nil { tmp6 = ifn_1528.Invoke_O_O_O_O_O__O(arg_1529, arg_1530, arg_1531, arg_1532, arg_1533) } else { tmp6 = linked_1527.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1526, arg_1529, arg_1530, arg_1531, arg_1532, arg_1533) }; return tmp5.Invoke_O__O(tmp6) }
//line :260:1
	case 2: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_178) {
		var tmp7 lang.IFn = lang.IFn_Cast(ret__11); var tmp8 any; var root_1538 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1538, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1542 any; var root_1546 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1547 == nil { arg_1542 = ifn_1548.Invoke_O__O(arg_1549) } else { arg_1542 = linked_1547.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1546, arg_1549) }; var arg_1543 any = A_arbace_j2g_dyn_A_const_181; var arg_1544 any = A_arbace_j2g_dyn_A_const_182; var arg_1545 any = pn__2; if linked_1539 == nil { tmp8 = ifn_1540.Invoke_O_O_O_O_O__O(arg_1541, arg_1542, arg_1543, arg_1544, arg_1545) } else { tmp8 = linked_1539.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1538, arg_1541, arg_1542, arg_1543, arg_1544, arg_1545) }; return tmp7.Invoke_O__O(tmp8) }
//line :260:1
	case 3: if any(G__711000236__12_) == any(A_arbace_j2g_dyn_A_const_179) {


		var tmp9 lang.IFn = lang.IFn_Cast(ret__11); var tmp10 any; var root_1550 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1554 any; var root_1557 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref(); if linked_1558 == nil { arg_1554 = ifn_1559.Invoke_O__O(arg_1560) } else { arg_1554 = linked_1558.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1557, arg_1560) }; var arg_1555 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any; var root_1561 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp14 any; var root_1565 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = n__0; if linked_1566 == nil { tmp14 = ifn_1567.Invoke_O__O(arg_1568) } else { tmp14 = linked_1566.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1565, arg_1568) }; arg_1564 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_1562 == nil { tmp12 = ifn_1563.Invoke_O__O(arg_1564) } else { tmp12 = linked_1562.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1561, arg_1564) }; arg_1555 = tmp11.Invoke_O_O__O(tmp12, A_arbace_j2g_dyn_A_const_183); var arg_1556 any = pn__2; if linked_1551 == nil { tmp10 = ifn_1552.Invoke_O_O_O_O__O(arg_1553, arg_1554, arg_1555, arg_1556) } else { tmp10 = linked_1551.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1550, arg_1553, arg_1554, arg_1555, arg_1556) }; return tmp9.Invoke_O__O(tmp10) }
//line :260:1
	default:}; var vec__711000237__13 any; var root_1509 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1511 lang.IFn; if



	linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = desc__7; if linked_1510 == nil { vec__711000237__13 = ifn_1511.Invoke_O__O(arg_1512) } else { vec__711000237__13 = linked_1510.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1509, arg_1512) }; var ps__14 any = /*line :260:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(0), nil); var rr__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000237__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_dyn_A_const_184; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_dyn_A_const_185; var tmp19 any = A_arbace_j2g_dyn_A_const_186; var tmp20 *jrt.RefArray = jrt.ConstRefArray("[0,9,s10:'abstract ns1: ns1:(ns21:)' of abstract class ns1:.", []*jrt.Class{jrt.String_class}); var tmp21 any; var root_1569 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A_fn_class); var ifn_1571 lang.IFn; if




	linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = rr__15; if linked_1570 == nil { tmp21 = ifn_1571.Invoke_O__O(arg_1572) } else { tmp21 = linked_1570.(*aot_arbace_j2g_model.A_arbace_j2g_model_java_type_name_A).Invoke_O_O__O(root_1569, arg_1572) }; var tmp22 any = tmp21; var tmp23 any; var root_1573 any = /*line :260:1*/A_arbace_j2g_dyn_A_const_115.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1575 lang.IFn; if





	linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = Lit_3; var arg_1577 any; var root_1578 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = A_arbace_j2g_dyn_A_const_114.GetRawRoot__O(); var arg_1582 any = ps__14; if linked_1579 == nil { arg_1577 = ifn_1580.Invoke_O_O__O(arg_1581, arg_1582) } else { arg_1577 = linked_1579.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1578, arg_1581, arg_1582) }; if linked_1574 == nil { tmp23 = ifn_1575.Invoke_O_O__O(arg_1576, arg_1577) } else { tmp23 = linked_1574.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1573, arg_1576, arg_1577) }; var tmp24 any = tmp23; var tmp25 any; var root_1583 any = /*line :260:1*/A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1585 lang.IFn; if






	linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = n__0; var arg_1587 any = Lit_5; var arg_1588 any = Lit_6; if linked_1584 == nil { tmp25 = ifn_1585.Invoke_O_O_O__O(arg_1586, arg_1587, arg_1588) } else { tmp25 = linked_1584.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1583, arg_1586, arg_1587, arg_1588) }; return /*line :260:1*/ lang.Tuple_Create_O__IPersistentVector(tmp15.Invoke_O_O__O(tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp19, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp22, nil, name__6, nil, tmp24, nil, tmp25, nil)).Ref()))) }
//line :259:1
func A_arbace_j2g_dyn_class_fallback_ret__711000234_A_New_O(p0 any) *A_arbace_j2g_dyn_class_fallback_ret__711000234_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_class_fallback_ret__711000234_A{}; t.Ctor_O(p0); return t }
//line :259:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :259:1
func (t *A_arbace_j2g_dyn_class_fallback_ret__711000234_A) Invoke_O_O__O(self, call__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(Lit_15, t.F_r) { return lang.Tuple_Create_O__IPersistentVector(call__1) } else { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_176, call__1)) } }









func A_arbace_j2g_dyn_ctor_infos_A_New() *A_arbace_j2g_dyn_ctor_infos_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Ctor() {}
//line :269:1
func (t *A_arbace_j2g_dyn_ctor_infos_A) Invoke_O_O__O(self, n__0 any) any { var g__2 any; var root_1589 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_1591 lang.IFn; if


	linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = n__0; if linked_1590 == nil { g__2 = ifn_1591.Invoke_O__O(arg_1592) } else { g__2 = linked_1590.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_1589, arg_1592) }; var arg_conv__3 any; var tmp1 any = /*line :269:1*/A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New(); var tmp2 *jrt.Class; var fncls__1607 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class; if



	fncls__1607 == nil { var fncls__1607d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class = fncls__1607d; tmp2 = fncls__1607d } else { tmp2 = fncls__1607 }; arg_conv__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var root_1611 any =


	A_arbace_j2g_dyn_A_const_192.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_193.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_dyn_A_const_194, A_arbace_j2g_dyn_A_const_195); if linked_1612 == nil { ifn_1613.Invoke_O__O(arg_1614) } else { linked_1612.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1611, arg_1614) }; var tmp3 any; tmp21 := /*line :269:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)







		{ var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_196; var tmp6 any; var root_1620 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__2)).Ref(); if linked_1621 == nil { tmp6 = ifn_1622.Invoke_O__O(arg_1623) } else { tmp6 = linked_1621.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1620, arg_1623) }; var tmp7 any = tmp6; var tmp8 any; var root_1624 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any; var tmp9 any; var root_1629 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = A_arbace_j2g_dyn_A_const_197; var arg_1633 any = A_arbace_j2g_dyn_A_const_198; if linked_1630 == nil { tmp9 = ifn_1631.Invoke_O_O__O(arg_1632, arg_1633) } else { tmp9 = linked_1630.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1629, arg_1632, arg_1633) }; arg_1627 = lang.Tuple_Create_O__IPersistentVector(tmp9); var arg_1628 any = A_arbace_j2g_dyn_A_const_199; if linked_1625 == nil { tmp8 = ifn_1626.Invoke_O_O__O(arg_1627, arg_1628) } else { tmp8 = linked_1625.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1624, arg_1627, arg_1628) }; var tmp10 any = tmp8; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_dyn_A_const_200; var tmp13 any; var root_1634 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1636 lang.IFn

			if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1638 any = A_arbace_j2g_dyn_A_const_201; var arg_1639 any = A_arbace_j2g_dyn_A_const_202; var arg_1640 any; var iter__1927001039__auto____6 any; var tmp14 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(g__2, n__0, arg_conv__3); var tmp15 *jrt.Class; var fncls__1991 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class
			if fncls__1991 == nil { var fncls__1991d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class = fncls__1991d; tmp15 = fncls__1991d } else { tmp15 = fncls__1991 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp17 any; var tmp18 any; var root_1992 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1992, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1994 lang.IFn; if linked_1993 == nil { ifn_1994 = lang.IFn_Cast(root_1992) } else { ifn_1994 = nil }; var arg_1995 any = n__0; if linked_1993 == nil { tmp18 = ifn_1994.Invoke_O__O(arg_1995) } else { tmp18 = linked_1993.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1992, arg_1995) }; if jrt.J2g_Truth(tmp18) { var root_1996 any = A_arbace_j2g_dyn_A_const_66.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = n__0; if linked_1997 == nil { tmp17 = ifn_1998.Invoke_O__O(arg_1999) } else { tmp17 = linked_1997.(*aot_arbace_j2g_model.A_arbace_j2g_model_methods_of_A).Invoke_O_O__O(root_1996, arg_1999) } } else { var tmp19 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp20 any; var root_2000 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = n__0; if linked_2001 == nil { tmp20 = ifn_2002.Invoke_O__O(arg_2003) } else { tmp20 = linked_2001.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2000, arg_2003) }; tmp17 = tmp19.Invoke_O__O(tmp20) }; arg_1640 = tmp16.Invoke_O__O(tmp17)
//line :279:1
			if linked_1635 == nil { tmp13 = ifn_1636.Invoke_O_O_O_O__O(arg_1637, arg_1638, arg_1639, arg_1640) } else { tmp13 = linked_1635.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1634, arg_1637, arg_1638, arg_1639, arg_1640) }
//line :277:1
			tmp3 = tmp4.Invoke_O_O_O_O__O(tmp5, tmp7, tmp10, tmp11.Invoke_O_O__O(tmp12, tmp13)) }
//line :269:1
		return nil }(); var root_1608 any = A_arbace_j2g_dyn_A_const_191.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1610 lang.IFn; if






	linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; if linked_1609 == nil { ifn_1610.Invoke__O() } else { linked_1609.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1608) }; if /*line :269:1*/ tmp21 != nil { panic(tmp21) }; return tmp3 }



func A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_New() *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Ctor() {}
//line :273:1
func (t *A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A) Invoke_O_O_O__O(self, d__1, x__2 any) any { var tmp1 any; var root_1593 any = A_arbace_j2g_dyn_A_const_78.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = d__1; if linked_1594 == nil { tmp1 = ifn_1595.Invoke_O__O(arg_1596) } else { tmp1 = linked_1594.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_1593, arg_1596) }; if jrt.J2g_Truth(tmp1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_188; var tmp4 any; var root_1597 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = A_arbace_j2g_dyn_A_const_73; var arg_1601 any = d__1; if linked_1598 == nil { tmp4 = ifn_1599.Invoke_O_O__O(arg_1600, arg_1601) } else { tmp4 = linked_1598.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1597, arg_1600, arg_1601) }; return tmp2.Invoke_O_O_O__O(tmp3, tmp4, x__2) } else { if lang.Util_Equiv_O_O__Z_NoInit(d__1, Lit_10) { return x__2 } else { if A_arbace_j2g_dyn_A_const_81 != nil {

	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_189; var tmp8 any = A_arbace_j2g_dyn_A_const_190; var tmp9 any; var root_1602 any = A_arbace_j2g_dyn_A_const_87.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = A_arbace_j2g_dyn_A_const_73; var arg_1606 any = d__1; if linked_1603 == nil { tmp9 = ifn_1604.Invoke_O_O__O(arg_1605, arg_1606) } else { tmp9 = linked_1603.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_type_A).Invoke_O_O_O__O(root_1602, arg_1605, arg_1606) }; return tmp5.Invoke_O_O__O(tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9), x__2) } else {
//line :273:1
		return nil } } } }






func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Ctor_O_O_O(c__g, c__n, c__arg_conv any) { t.F_g = c__g; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A) Invoke_O_O__O(self, s__711000244__1 any) any { var tmp1 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(self, t.F_g, s__711000244__1, t.F_n, t.F_arg_conv); var tmp2 *jrt.Class; var fncls__1990 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class; if fncls__1990 == nil { var fncls__1990d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class = fncls__1990d; tmp2 = fncls__1990d } else { tmp2 = fncls__1990 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :280:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Ctor_O_O_O_O_O(c__iter__711000243, c__g, c__s__711000244, c__n, c__arg_conv any) { t.F_iter__711000243 = c__iter__711000243; t.F_g = c__g; t.F_s__711000244 = c__s__711000244; t.F_n = c__n; t.F_arg_conv = c__arg_conv }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A) Invoke_O__O(self any) any { { var s__711000244__1 any; var t_ any = t.F_s__711000244; t.F_s__711000244 = nil; s__711000244__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1641 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = s__711000244__1; if linked_1642 == nil { temp__1927000414__auto____2 = ifn_1643.Invoke_O__O(arg_1644) } else { temp__1927000414__auto____2 = linked_1642.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1641, arg_1644) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000244__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1645 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = s__711000244__3; if linked_1646 == nil { tmp1 = ifn_1647.Invoke_O__O(arg_1648) } else { tmp1 = linked_1646.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1645, arg_1648) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1649 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = s__711000244__3; if linked_1650 == nil { c__1927001037__auto____4 = ifn_1651.Invoke_O__O(arg_1652) } else { c__1927001037__auto____4 = linked_1650.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1649, arg_1652) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000246__6 any; var root_1653 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1654 == nil { b__711000246__6 = ifn_1655.Invoke_O__O(arg_1656) } else { b__711000246__6 = linked_1654.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1653, arg_1656) }; var tmp2 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(t.F_g, t.F_n, b__711000246__6, t.F_arg_conv, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1802 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class; if fncls__1802 == nil { var fncls__1802d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class = fncls__1802d; tmp3 = fncls__1802d } else { tmp3 = fncls__1802 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1803 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any; var root_1808 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1808, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1810 lang.IFn; if linked_1809 == nil { ifn_1810 = lang.IFn_Cast(root_1808) } else { ifn_1810 = nil }; var arg_1811 any = b__711000246__6; if linked_1809 == nil { arg_1806 = ifn_1810.Invoke_O__O(arg_1811) } else { arg_1806 = linked_1809.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1808, arg_1811) }; var arg_1807 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp5 any; var root_1812 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_1813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1812, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1814 lang.IFn; if linked_1813 == nil { ifn_1814 = lang.IFn_Cast(root_1812) } else { ifn_1814 = nil }; var arg_1815 any = s__711000244__3; if linked_1813 == nil { tmp5 = ifn_1814.Invoke_O__O(arg_1815) } else { tmp5 = linked_1813.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1812, arg_1815) }; arg_1807 = tmp4.Invoke_O__O(tmp5); if linked_1804 == nil { return ifn_1805.Invoke_O_O__O(arg_1806, arg_1807) } else { return linked_1804.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1803, arg_1806, arg_1807) } } else { var root_1816 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_1817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1816, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1818 lang.IFn; if linked_1817 == nil { ifn_1818 = lang.IFn_Cast(root_1816) } else { ifn_1818 = nil }; var arg_1819 any; var root_1821 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var arg_1824 any = b__711000246__6; if linked_1822 == nil { arg_1819 = ifn_1823.Invoke_O__O(arg_1824) } else { arg_1819 = linked_1822.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1821, arg_1824) }; var arg_1820 any; if linked_1817 == nil { return ifn_1818.Invoke_O_O__O(arg_1819, arg_1820) } else { return linked_1817.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1816, arg_1819, arg_1820) } } } else { var mm__4 any; var root_1825 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1827 lang.IFn; if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = s__711000244__3; if linked_1826 == nil { mm__4 = ifn_1827.Invoke_O__O(arg_1828) } else { mm__4 = linked_1826.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1825, arg_1828) }; var tmp6 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4))
														if and__1927000168__auto____5 { var and__1927000168__auto____6 any; var root_1829 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any; var root_1833 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = mm__4; if linked_1834 == nil { arg_1832 = ifn_1835.Invoke_O__O(arg_1836) } else { arg_1832 = linked_1834.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1833, arg_1836) }; if linked_1830 == nil { and__1927000168__auto____6 = ifn_1831.Invoke_O__O(arg_1832) } else { and__1927000168__auto____6 = linked_1830.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1829, arg_1832) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1837 any = A_arbace_j2g_dyn_A_const_203.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1838 == nil { tmp6 = ifn_1839.Invoke_O__O(arg_1840) } else { tmp6 = linked_1838.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1837, arg_1840) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }
//line :280:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var or__1927000174__auto____5 any; var root_1841 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1843 lang.IFn

		if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any; var root_1845 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1845, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1847 lang.IFn; if linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = t.F_n; if linked_1846 == nil { arg_1844 = ifn_1847.Invoke_O__O(arg_1848) } else { arg_1844 = linked_1846.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1845, arg_1848) }; if linked_1842 == nil { or__1927000174__auto____5 = ifn_1843.Invoke_O__O(arg_1844) } else { or__1927000174__auto____5 = linked_1842.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1841, arg_1844) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp7 = or__1927000174__auto____5 } else {
			var root_1849 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1849, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1851 lang.IFn; if linked_1850 == nil { ifn_1851 = lang.IFn_Cast(root_1849) } else { ifn_1851 = nil }; var arg_1852 any; var root_1854 any = A_arbace_j2g_dyn_A_const_204.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1856 lang.IFn; if linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var tmp8 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_1857 any = tmp8.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_1858 any; var root_1859 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1859, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1861 lang.IFn; if linked_1860 == nil { ifn_1861 = lang.IFn_Cast(root_1859) } else { ifn_1861 = nil }; var arg_1862 any = t.F_n; if linked_1860 == nil { arg_1858 = ifn_1861.Invoke_O__O(arg_1862) } else { arg_1858 = linked_1860.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1859, arg_1862) }; if linked_1855 == nil { arg_1852 = ifn_1856.Invoke_O_O__O(arg_1857, arg_1858) } else { arg_1852 = linked_1855.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1854, arg_1857, arg_1858) }; var arg_1853 any; var root_1863 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1865 lang.IFn; if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1864 == nil { arg_1853 = ifn_1865.Invoke_O__O(arg_1866) } else { arg_1853 = linked_1864.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1863, arg_1866) }; if linked_1850 == nil { tmp7 = ifn_1851.Invoke_O_O__O(arg_1852, arg_1853) } else { tmp7 = linked_1850.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1849, arg_1852, arg_1853) } }
//line :280:1
		if jrt.J2g_Truth(tmp7) { var real__5 any; var tmp9 any; var root_1867 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1869 lang.IFn



			if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = t.F_n; if linked_1868 == nil { tmp9 = ifn_1869.Invoke_O__O(arg_1870) } else { tmp9 = linked_1868.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1867, arg_1870) }; if jrt.J2g_Truth(tmp9) { real__5 = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4) } else { var root_1871 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1871, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1873 lang.IFn; if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any = t.F_n; var arg_1875 any = mm__4; if linked_1872 == nil { real__5 = ifn_1873.Invoke_O_O__O(arg_1874, arg_1875) } else { real__5 = linked_1872.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1871, arg_1874, arg_1875) } }
//line :280:1
			var vec__711000259__6 any; var root_1876 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1878 lang.IFn




			if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_1877 == nil { vec__711000259__6 = ifn_1878.Invoke_O__O(arg_1879) } else { vec__711000259__6 = linked_1877.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1876, arg_1879) }
//line :280:1
			var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000259__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000262__9 any; var root_1880 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1882 lang.IFn; _ = ___8





			if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = real__5; if linked_1881 == nil { vec__711000262__9 = ifn_1882.Invoke_O__O(arg_1883) } else { vec__711000262__9 = linked_1881.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1880, arg_1883) }
//line :280:1
			var rps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000262__9, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___11; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__7)), int64(lang.RT_Count_O__I_NoInit(rps__10))) { var root_1884 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_207; var tmp12 any = A_arbace_j2g_dyn_A_const_208; var tmp13 any = A_arbace_j2g_dyn_A_const_209; var tmp14 any; var tmp15 any; var root_1889 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1891 lang.IFn








				if linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any = ps__7; if linked_1890 == nil { tmp15 = ifn_1891.Invoke_O__O(arg_1892) } else { tmp15 = linked_1890.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1889, arg_1892) }; if jrt.J2g_Truth(tmp15) { var root_1893 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1897 any = A_arbace_j2g_dyn_A_const_210; var arg_1898 any = A_arbace_j2g_dyn_A_const_211; var arg_1899 any; var root_1900 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1901 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1900, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1902 lang.IFn; if linked_1901 == nil { ifn_1902 = lang.IFn_Cast(root_1900) } else { ifn_1902 = nil }; var arg_1903 any = A_arbace_j2g_dyn_A_const_212.GetRawRoot__O(); var arg_1904 any = ps__7; if linked_1901 == nil { arg_1899 = ifn_1902.Invoke_O_O__O(arg_1903, arg_1904) } else { arg_1899 = linked_1901.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1900, arg_1903, arg_1904) }; if linked_1894 == nil { tmp14 = ifn_1895.Invoke_O_O_O_O__O(arg_1896, arg_1897, arg_1898, arg_1899) } else { tmp14 = linked_1894.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1893, arg_1896, arg_1897, arg_1898, arg_1899) } } else { tmp14 = nil }
//line :288:1
				var tmp16 any = tmp14; var tmp17 any = A_arbace_j2g_dyn_A_const_213; var tmp18 any = A_arbace_j2g_dyn_A_const_214; var tmp19 any = A_arbace_j2g_dyn_A_const_215; var tmp20 any; var root_1905 any = A_arbace_j2g_dyn_A_const_216.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1907 lang.IFn


				if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = A_arbace_j2g_dyn_A_const_217; var arg_1909 any; var root_1911 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1913 lang.IFn; if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any; var tmp21 any; var root_1916 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1916, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1918 lang.IFn; if linked_1917 == nil { ifn_1918 = lang.IFn_Cast(root_1916) } else { ifn_1918 = nil }; var arg_1919 any = A_arbace_j2g_dyn_A_const_218; var arg_1920 any = A_arbace_j2g_dyn_A_const_219; if linked_1917 == nil { tmp21 = ifn_1918.Invoke_O_O__O(arg_1919, arg_1920) } else { tmp21 = linked_1917.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1916, arg_1919, arg_1920) }; arg_1914 = lang.Tuple_Create_O__IPersistentVector(tmp21); var arg_1915 any = A_arbace_j2g_dyn_A_const_236; if linked_1912 == nil { arg_1909 = ifn_1913.Invoke_O_O__O(arg_1914, arg_1915) } else { arg_1909 = linked_1912.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1911, arg_1914, arg_1915) }; var arg_1910 any; var root_1921 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1923 lang.IFn
				if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any; var tmp22 any; var or__1927000174__auto____12 any; var root_1926 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1928 lang.IFn
				if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = t.F_n; if linked_1927 == nil { or__1927000174__auto____12 = ifn_1928.Invoke_O__O(arg_1929) } else { or__1927000174__auto____12 = linked_1927.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1926, arg_1929) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp22 = or__1927000174__auto____12 } else { var root_1930 any = A_arbace_j2g_dyn_A_const_221.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = t.F_n; if linked_1931 == nil { tmp22 = ifn_1932.Invoke_O__O(arg_1933) } else { tmp22 = linked_1931.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1930, arg_1933) } }; if jrt.J2g_Truth(tmp22) { arg_1924 = nil } else { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp24 any; var root_1934 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1934, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1936 lang.IFn; if linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any = A_arbace_j2g_dyn_A_const_73; var arg_1938 any = t.F_n; var arg_1939 any = Lit_30; if linked_1935 == nil { tmp24 = ifn_1936.Invoke_O_O_O__O(arg_1937, arg_1938, arg_1939) } else { tmp24 = linked_1935.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1934, arg_1937, arg_1938, arg_1939) }; arg_1924 = lang.Tuple_Create_O__IPersistentVector(tmp23.Invoke_O__O(tmp24)) }
//line :292:1
				var arg_1925 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_dyn_A_const_222; var tmp27 any = A_arbace_j2g_dyn_A_const_231; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_dyn_A_const_232; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_dyn_A_const_233; var tmp32 any; var root_1970 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1972 lang.IFn

				if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = t.F_g; if linked_1971 == nil { tmp32 = ifn_1972.Invoke_O__O(arg_1973) } else { tmp32 = linked_1971.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1970, arg_1973) }
//line :292:1
				var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28.Invoke_O_O__O(tmp29, tmp30.Invoke_O_O_O_O__O(tmp31, tmp32, A_arbace_j2g_dyn_A_const_234, A_arbace_j2g_dyn_A_const_235))); var tmp34 any = A_arbace_j2g_dyn_A_const_223; var tmp35 any = A_arbace_j2g_dyn_A_const_224; var tmp36 any; var root_1940 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1940, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1942 lang.IFn




				if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1944 any; var root_1948 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp38 any; var root_1952 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = real__5; if linked_1953 == nil { tmp38 = ifn_1954.Invoke_O__O(arg_1955) } else { tmp38 = linked_1953.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1952, arg_1955) }; arg_1951 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_1949 == nil { arg_1944 = ifn_1950.Invoke_O__O(arg_1951) } else { arg_1944 = linked_1949.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1948, arg_1951) }; var arg_1945 any; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp40 any; var root_1956 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1958 lang.IFn
				if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any; var tmp41 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp42 any; var root_1960 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = t.F_n; if linked_1961 == nil { tmp42 = ifn_1962.Invoke_O__O(arg_1963) } else { tmp42 = linked_1961.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1960, arg_1963) }; arg_1959 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp41, jrt.RefArrayOf(jrt.Object_class, nil, tmp42)).Ref(); if linked_1957 == nil { tmp40 = ifn_1958.Invoke_O__O(arg_1959) } else { tmp40 = linked_1957.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1956, arg_1959) }; arg_1945 = tmp39.Invoke_O_O__O(tmp40, A_arbace_j2g_dyn_A_const_225)
//line :297:1
				var arg_1946 any = A_arbace_j2g_dyn_A_const_226; var arg_1947 any; var root_1964 any = A_arbace_j2g_dyn_A_const_227.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1966 lang.IFn

				if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any; var tmp43 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(t.F_arg_conv); var tmp44 *jrt.Class; var fncls__1969 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class; if fncls__1969 == nil { var fncls__1969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class = fncls__1969d; tmp44 = fncls__1969d } else { tmp44 = fncls__1969 }; arg_1967 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil); var arg_1968 any = ps__7; if linked_1965 == nil { arg_1947 = ifn_1966.Invoke_O_O__O(arg_1967, arg_1968) } else { arg_1947 = linked_1965.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1964, arg_1967, arg_1968) }
//line :297:1
				if linked_1941 == nil { tmp36 = ifn_1942.Invoke_O_O_O_O_O__O(arg_1943, arg_1944, arg_1945, arg_1946, arg_1947) } else { tmp36 = linked_1941.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1940, arg_1943, arg_1944, arg_1945, arg_1946, arg_1947) }
//line :292:1
				arg_1925 = lang.Tuple_Create_O__IPersistentVector(tmp25.Invoke_O_O_O_O_O_O__O(tmp26, tmp33, tmp34, tmp35, tmp36, A_arbace_j2g_dyn_A_const_230)); if linked_1922 == nil { arg_1910 = ifn_1923.Invoke_O_O__O(arg_1924, arg_1925) } else { arg_1910 = linked_1922.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1921, arg_1924, arg_1925) }
//line :291:1
				if linked_1906 == nil { tmp20 = ifn_1907.Invoke_O_O_O__O(arg_1908, arg_1909, arg_1910) } else { tmp20 = linked_1906.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1905, arg_1908, arg_1909, arg_1910) }
//line :288:1
				arg_1887 = tmp10.Invoke_O_O_O_O_O_O_O_O__O(tmp11, tmp12, tmp13, tmp16, tmp17, tmp18, tmp19, tmp20)
//line :280:1
				var arg_1888 any; var tmp45 lang.IFn = lang.IFn_Cast(t.F_iter__711000243); var tmp46 any; var root_1974 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = s__711000244__3; if linked_1975 == nil { tmp46 = ifn_1976.Invoke_O__O(arg_1977) } else { tmp46 = linked_1975.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1974, arg_1977) }; arg_1888 = tmp45.Invoke_O__O(tmp46); if linked_1885 == nil { return ifn_1886.Invoke_O_O__O(arg_1887, arg_1888) } else { return linked_1885.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1884, arg_1887, arg_1888) } } else { var tmp47 any; var root_1978 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = s__711000244__3; if linked_1979 == nil { tmp47 = ifn_1980.Invoke_O__O(arg_1981) } else { tmp47 = linked_1979.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1978, arg_1981) }; s__711000244__1 = tmp47; continue L1 } } else { var tmp48 any; var root_1982 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = s__711000244__3; if linked_1983 == nil { tmp48 = ifn_1984.Invoke_O__O(arg_1985) } else { tmp48 = linked_1983.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1982, arg_1985) }; s__711000244__1 = tmp48; continue L1 } } else { var tmp49 any; var root_1986 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1988 lang.IFn; if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = s__711000244__3; if linked_1987 == nil { tmp49 = ifn_1988.Invoke_O__O(arg_1989) } else { tmp49 = linked_1987.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1986, arg_1989) }; s__711000244__1 = tmp49; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :280:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Ctor_O_O_O_O_I_O(c__g, c__n, c__b__711000246, c__arg_conv any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_g = c__g; t.F_n = c__n; t.F_b__711000246 = c__b__711000246; t.F_arg_conv = c__arg_conv; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :280:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A) Invoke_O__O(self any) any { { var i__711000245__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000245__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000245__1)); var tmp2 any; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_29, A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2))
																if and__1927000168__auto____3 { var and__1927000168__auto____4 any; var root_1657 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any; var root_1661 any = A_arbace_j2g_dyn_A_const_165.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A_fn_class); var ifn_1663 lang.IFn; if linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any = mm__2; if linked_1662 == nil { arg_1660 = ifn_1663.Invoke_O__O(arg_1664) } else { arg_1660 = linked_1662.(*aot_arbace_j2g_model.A_arbace_j2g_model_private_QMARK__A).Invoke_O_O__O(root_1661, arg_1664) }; if linked_1658 == nil { and__1927000168__auto____4 = ifn_1659.Invoke_O__O(arg_1660) } else { and__1927000168__auto____4 = linked_1658.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1657, arg_1660) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1665 any = A_arbace_j2g_dyn_A_const_203.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1666 == nil { tmp2 = ifn_1667.Invoke_O__O(arg_1668) } else { tmp2 = linked_1666.(*aot_arbace_j2g_model.A_arbace_j2g_model_mdesc_in_world_QMARK__A).Invoke_O_O__O(root_1665, arg_1668) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }
//line :280:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var or__1927000174__auto____3 any; var root_1669 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1671 lang.IFn

		if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any; var root_1673 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = t.F_n; if linked_1674 == nil { arg_1672 = ifn_1675.Invoke_O__O(arg_1676) } else { arg_1672 = linked_1674.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1673, arg_1676) }; if linked_1670 == nil { or__1927000174__auto____3 = ifn_1671.Invoke_O__O(arg_1672) } else { or__1927000174__auto____3 = linked_1670.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1669, arg_1672) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else {
			var root_1677 any = A_arbace_j2g_dyn_A_const_44.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any; var root_1682 any = A_arbace_j2g_dyn_A_const_204.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1682, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var tmp4 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_1685 any = tmp4.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_1686 any; var root_1687 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any = t.F_n; if linked_1688 == nil { arg_1686 = ifn_1689.Invoke_O__O(arg_1690) } else { arg_1686 = linked_1688.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1687, arg_1690) }; if linked_1683 == nil { arg_1680 = ifn_1684.Invoke_O_O__O(arg_1685, arg_1686) } else { arg_1680 = linked_1683.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_1682, arg_1685, arg_1686) }; var arg_1681 any; var root_1691 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1692 == nil { arg_1681 = ifn_1693.Invoke_O__O(arg_1694) } else { arg_1681 = linked_1692.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1691, arg_1694) }; if linked_1678 == nil { tmp3 = ifn_1679.Invoke_O_O__O(arg_1680, arg_1681) } else { tmp3 = linked_1678.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1677, arg_1680, arg_1681) } }
//line :280:1
		if jrt.J2g_Truth(tmp3) { var real__3 any; var tmp5 any; var root_1695 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1697 lang.IFn



			if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = t.F_n; if linked_1696 == nil { tmp5 = ifn_1697.Invoke_O__O(arg_1698) } else { tmp5 = linked_1696.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1695, arg_1698) }; if jrt.J2g_Truth(tmp5) { real__3 = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2) } else { var root_1699 any = A_arbace_j2g_dyn_A_const_206.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = t.F_n; var arg_1703 any = mm__2; if linked_1700 == nil { real__3 = ifn_1701.Invoke_O_O__O(arg_1702, arg_1703) } else { real__3 = linked_1700.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_ctor_real_desc_A).Invoke_O_O_O__O(root_1699, arg_1702, arg_1703) } }
//line :280:1
			var vec__711000250__4 any; var root_1704 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1706 lang.IFn




			if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_1705 == nil { vec__711000250__4 = ifn_1706.Invoke_O__O(arg_1707) } else { vec__711000250__4 = linked_1705.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1704, arg_1707) }
//line :280:1
			var ps__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000250__4, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__711000253__7 any; var root_1708 any = A_arbace_j2g_dyn_A_const_110.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_1710 lang.IFn; _ = ___6





			if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = real__3; if linked_1709 == nil { vec__711000253__7 = ifn_1710.Invoke_O__O(arg_1711) } else { vec__711000253__7 = linked_1709.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_1708, arg_1711) }
//line :280:1
			var rps__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000253__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___9; if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__5)), int64(lang.RT_Count_O__I_NoInit(rps__8))) { var root_1712 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = t.F_b__711000246; var arg_1716 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_207; var tmp8 any = A_arbace_j2g_dyn_A_const_208; var tmp9 any = A_arbace_j2g_dyn_A_const_209; var tmp10 any; var tmp11 any; var root_1717 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1719 lang.IFn








				if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = ps__5; if linked_1718 == nil { tmp11 = ifn_1719.Invoke_O__O(arg_1720) } else { tmp11 = linked_1718.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1717, arg_1720) }; if jrt.J2g_Truth(tmp11) { var root_1721 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1725 any = A_arbace_j2g_dyn_A_const_210; var arg_1726 any = A_arbace_j2g_dyn_A_const_211; var arg_1727 any; var root_1728 any = A_arbace_j2g_dyn_A_const_116.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = A_arbace_j2g_dyn_A_const_212.GetRawRoot__O(); var arg_1732 any = ps__5; if linked_1729 == nil { arg_1727 = ifn_1730.Invoke_O_O__O(arg_1731, arg_1732) } else { arg_1727 = linked_1729.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1728, arg_1731, arg_1732) }; if linked_1722 == nil { tmp10 = ifn_1723.Invoke_O_O_O_O__O(arg_1724, arg_1725, arg_1726, arg_1727) } else { tmp10 = linked_1722.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1721, arg_1724, arg_1725, arg_1726, arg_1727) } } else { tmp10 = nil }
//line :288:1
				var tmp12 any = tmp10; var tmp13 any = A_arbace_j2g_dyn_A_const_213; var tmp14 any = A_arbace_j2g_dyn_A_const_214; var tmp15 any = A_arbace_j2g_dyn_A_const_215; var tmp16 any; var root_1733 any = A_arbace_j2g_dyn_A_const_216.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1733, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1735 lang.IFn


				if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = A_arbace_j2g_dyn_A_const_217; var arg_1737 any; var root_1739 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any; var tmp17 any; var root_1744 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = A_arbace_j2g_dyn_A_const_218; var arg_1748 any = A_arbace_j2g_dyn_A_const_219; if linked_1745 == nil { tmp17 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { tmp17 = linked_1745.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) }; arg_1742 = lang.Tuple_Create_O__IPersistentVector(tmp17); var arg_1743 any = A_arbace_j2g_dyn_A_const_220; if linked_1740 == nil { arg_1737 = ifn_1741.Invoke_O_O__O(arg_1742, arg_1743) } else { arg_1737 = linked_1740.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1739, arg_1742, arg_1743) }; var arg_1738 any; var root_1749 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1751 lang.IFn
				if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any; var tmp18 any; var or__1927000174__auto____10 any; var root_1754 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_1756 lang.IFn
				if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = t.F_n; if linked_1755 == nil { or__1927000174__auto____10 = ifn_1756.Invoke_O__O(arg_1757) } else { or__1927000174__auto____10 = linked_1755.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_1754, arg_1757) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp18 = or__1927000174__auto____10 } else { var root_1758 any = A_arbace_j2g_dyn_A_const_221.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = t.F_n; if linked_1759 == nil { tmp18 = ifn_1760.Invoke_O__O(arg_1761) } else { tmp18 = linked_1759.(*aot_arbace_j2g_model.A_arbace_j2g_model_trivial_init_QMARK__A).Invoke_O_O__O(root_1758, arg_1761) } }; if jrt.J2g_Truth(tmp18) { arg_1752 = nil } else { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp20 any; var root_1762 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = A_arbace_j2g_dyn_A_const_73; var arg_1766 any = t.F_n; var arg_1767 any = Lit_30; if linked_1763 == nil { tmp20 = ifn_1764.Invoke_O_O_O__O(arg_1765, arg_1766, arg_1767) } else { tmp20 = linked_1763.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_1762, arg_1765, arg_1766, arg_1767) }; arg_1752 = lang.Tuple_Create_O__IPersistentVector(tmp19.Invoke_O__O(tmp20)) }
//line :292:1
				var arg_1753 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_dyn_A_const_222; var tmp23 any = A_arbace_j2g_dyn_A_const_231; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_dyn_A_const_232; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_dyn_A_const_233; var tmp28 any; var root_1798 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1800 lang.IFn

				if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any = t.F_g; if linked_1799 == nil { tmp28 = ifn_1800.Invoke_O__O(arg_1801) } else { tmp28 = linked_1799.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1798, arg_1801) }
//line :292:1
				var tmp29 any = lang.Tuple_Create_O_O__IPersistentVector(tmp23, tmp24.Invoke_O_O__O(tmp25, tmp26.Invoke_O_O_O_O__O(tmp27, tmp28, A_arbace_j2g_dyn_A_const_234, A_arbace_j2g_dyn_A_const_235))); var tmp30 any = A_arbace_j2g_dyn_A_const_223; var tmp31 any = A_arbace_j2g_dyn_A_const_224; var tmp32 any; var root_1768 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1770 lang.IFn




				if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_1772 any; var root_1776 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1776, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1778 lang.IFn; if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_6, nil); var tmp34 any; var root_1780 any = A_arbace_j2g_dyn_A_const_205.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1780, aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A_fn_class); var ifn_1782 lang.IFn; if linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = real__3; if linked_1781 == nil { tmp34 = ifn_1782.Invoke_O__O(arg_1783) } else { tmp34 = linked_1781.(*aot_arbace_j2g_names.A_arbace_j2g_names_ctor_base_A).Invoke_O_O__O(root_1780, arg_1783) }; arg_1779 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, nil, tmp34)).Ref(); if linked_1777 == nil { arg_1772 = ifn_1778.Invoke_O__O(arg_1779) } else { arg_1772 = linked_1777.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1776, arg_1779) }; var arg_1773 any; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp36 any; var root_1784 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1786 lang.IFn
				if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any; var tmp37 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp38 any; var root_1788 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any = t.F_n; if linked_1789 == nil { tmp38 = ifn_1790.Invoke_O__O(arg_1791) } else { tmp38 = linked_1789.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_1788, arg_1791) }; arg_1787 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp37, jrt.RefArrayOf(jrt.Object_class, nil, tmp38)).Ref(); if linked_1785 == nil { tmp36 = ifn_1786.Invoke_O__O(arg_1787) } else { tmp36 = linked_1785.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1784, arg_1787) }; arg_1773 = tmp35.Invoke_O_O__O(tmp36, A_arbace_j2g_dyn_A_const_225)
//line :297:1
				var arg_1774 any = A_arbace_j2g_dyn_A_const_226; var arg_1775 any; var root_1792 any = A_arbace_j2g_dyn_A_const_227.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1794 lang.IFn

				if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any; var tmp39 any = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(t.F_arg_conv); var tmp40 *jrt.Class; var fncls__1797 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class; if fncls__1797 == nil { var fncls__1797d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class = fncls__1797d; tmp40 = fncls__1797d } else { tmp40 = fncls__1797 }; arg_1795 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil); var arg_1796 any = ps__5; if linked_1793 == nil { arg_1775 = ifn_1794.Invoke_O_O__O(arg_1795, arg_1796) } else { arg_1775 = linked_1793.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1792, arg_1795, arg_1796) }
//line :297:1
				if linked_1769 == nil { tmp32 = ifn_1770.Invoke_O_O_O_O_O__O(arg_1771, arg_1772, arg_1773, arg_1774, arg_1775) } else { tmp32 = linked_1769.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O_O__O(root_1768, arg_1771, arg_1772, arg_1773, arg_1774, arg_1775) }
//line :292:1
				arg_1753 = lang.Tuple_Create_O__IPersistentVector(tmp21.Invoke_O_O_O_O_O_O__O(tmp22, tmp29, tmp30, tmp31, tmp32, A_arbace_j2g_dyn_A_const_230)); if linked_1750 == nil { arg_1738 = ifn_1751.Invoke_O_O__O(arg_1752, arg_1753) } else { arg_1738 = linked_1750.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1749, arg_1752, arg_1753) }
//line :291:1
				if linked_1734 == nil { tmp16 = ifn_1735.Invoke_O_O_O__O(arg_1736, arg_1737, arg_1738) } else { tmp16 = linked_1734.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1733, arg_1736, arg_1737, arg_1738) }
//line :288:1
				arg_1716 = tmp6.Invoke_O_O_O_O_O_O_O_O__O(tmp7, tmp8, tmp9, tmp12, tmp13, tmp14, tmp15, tmp16)
//line :280:1
				if linked_1713 == nil { ifn_1714.Invoke_O_O__O(arg_1715, arg_1716) } else { linked_1713.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1712, arg_1715, arg_1716) }; i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { i__711000245__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000245__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


















func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_228, A_arbace_j2g_dyn_A_const_229, i__1)) }
//line :299:1
func A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_New_O(p0 any) *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A{}; t.Ctor_O(p0); return t }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Ctor_O(c__arg_conv any) { t.F_arg_conv = c__arg_conv }
//line :299:1
func (t *A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_arg_conv); return tmp1.Invoke_O_O__O(p__2, lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_dyn_A_const_228, A_arbace_j2g_dyn_A_const_229, i__1)) }


func A_arbace_j2g_dyn_go_method_names_A_New() *A_arbace_j2g_dyn_go_method_names_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Ctor() {}
//line :302:1
func (t *A_arbace_j2g_dyn_go_method_names_A) Invoke_O_O__O(self, n__0 any) any {




	var root_2004 any = A_arbace_j2g_dyn_A_const_237.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2006 lang.IFn; if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_2008 any; var root_2009 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2011 lang.IFn
	if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New(); var tmp2 *jrt.Class; var fncls__2234 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class
	if fncls__2234 == nil { var fncls__2234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class = fncls__2234d; tmp2 = fncls__2234d } else { tmp2 = fncls__2234 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_2235 any = A_arbace_j2g_dyn_A_const_166.GetRawRoot__O(); var linked_2236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2235, aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A_fn_class); var ifn_2237 lang.IFn; if linked_2236 == nil { ifn_2237 = lang.IFn_Cast(root_2235) } else { ifn_2237 = nil }; var arg_2238 any = n__0; if linked_2236 == nil { tmp4 = ifn_2237.Invoke_O__O(arg_2238) } else { tmp4 = linked_2236.(*aot_arbace_j2g_model.A_arbace_j2g_model_superclass_chain_A).Invoke_O_O__O(root_2235, arg_2238) }; arg_2012 = tmp3.Invoke_O__O(tmp4)
//line :308:1
	var arg_2013 any; var iter__1927001039__auto____2_2 any; var tmp5 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(n__0); var tmp6 *jrt.Class
	var fncls__2327 /*line :308:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class








	if fncls__2327 == nil { var fncls__2327d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class = fncls__2327d; tmp6 = fncls__2327d } else { tmp6 = fncls__2327 }; iter__1927001039__auto____2_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2_2); var tmp8 any; var root_2328 any = A_arbace_j2g_dyn_A_const_55.GetRawRoot__O(); var linked_2329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2328, aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A_fn_class); var ifn_2330 lang.IFn; if linked_2329 == nil { ifn_2330 = lang.IFn_Cast(root_2328) } else { ifn_2330 = nil }; var arg_2331 any = n__0; if linked_2329 == nil { tmp8 = ifn_2330.Invoke_O__O(arg_2331) } else { tmp8 = linked_2329.(*aot_arbace_j2g_model.A_arbace_j2g_model_all_supertypes_A).Invoke_O_O__O(root_2328, arg_2331) }; arg_2013 = tmp7.Invoke_O__O(tmp8)
//line :308:1
	if linked_2010 == nil { arg_2008 = ifn_2011.Invoke_O_O__O(arg_2012, arg_2013) } else { arg_2008 = linked_2010.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2009, arg_2012, arg_2013) }
//line :307:1
	if linked_2005 == nil { return ifn_2006.Invoke_O_O__O(arg_2007, arg_2008) } else { return linked_2005.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2004, arg_2007, arg_2008)
	} }
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Ctor() {}
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A) Invoke_O_O__O(self, s__711000271__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(self, s__711000271__1); var tmp2 *jrt.Class; var fncls__2233 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class; if fncls__2233 == nil { var fncls__2233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class = fncls__2233d; tmp2 = fncls__2233d } else { tmp2 = fncls__2233 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A{}; t.Ctor_O_O(p0, p1); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Ctor_O_O(c__iter__711000270, c__s__711000271 any) { t.F_iter__711000270 = c__iter__711000270; t.F_s__711000271 = c__s__711000271 }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A) Invoke_O__O(self any) any { { var s__711000271__1 any; var t_ any = t.F_s__711000271; t.F_s__711000271 = nil; s__711000271__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2014 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = s__711000271__1; if linked_2015 == nil { temp__1927000414__auto____2 = ifn_2016.Invoke_O__O(arg_2017) } else { temp__1927000414__auto____2 = linked_2015.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2014, arg_2017) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_2018 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2018, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2020 lang.IFn; if linked_2019 == nil { ifn_2020 = lang.IFn_Cast(root_2018) } else { ifn_2020 = nil }; var arg_2021 any = xs__1927001018__auto____3; if linked_2019 == nil { c__4 = ifn_2020.Invoke_O__O(arg_2021) } else { c__4 = linked_2019.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2018, arg_2021) }; var tmp1 any; var and__1927000168__auto____5 any = c__4
														if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2022 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = c__4; var arg_2026 any = Lit_98; if linked_2023 == nil { tmp1 = ifn_2024.Invoke_O_O__O(arg_2025, arg_2026) } else { tmp1 = linked_2023.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2022, arg_2025, arg_2026) } } else { tmp1 = and__1927000168__auto____5 }
//line :309:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New(); var tmp3 *jrt.Class; var fncls__2085 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class; if fncls__2085 == nil { var fncls__2085d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class = fncls__2085d; tmp3 = fncls__2085d } else { tmp3 = fncls__2085 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var fs__1927001036__auto____6 any; var root_2086 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2088 lang.IFn; if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any; var tmp6 any; var root_2090 any = A_arbace_j2g_dyn_A_const_43.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A_fn_class); var ifn_2092 lang.IFn

		if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = c__4; if linked_2091 == nil { tmp6 = ifn_2092.Invoke_O__O(arg_2093) } else { tmp6 = linked_2091.(*aot_arbace_j2g_model.A_arbace_j2g_model_hand_written_QMARK__A).Invoke_O_O__O(root_2090, arg_2093) }; if jrt.J2g_Truth(tmp6) {
			var root_2094 any = A_arbace_j2g_dyn_A_const_204.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var tmp7 *lang.Keyword = A_arbace_j2g_dyn_A_const_46; var arg_2097 any = tmp7.Invoke_O__O(A_arbace_j2g_dyn_A_const_47.Get__O()); var arg_2098 any; var root_2099 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = c__4; if linked_2100 == nil { arg_2098 = ifn_2101.Invoke_O__O(arg_2102) } else { arg_2098 = linked_2100.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2099, arg_2102) }; if linked_2095 == nil { tmp5 = ifn_2096.Invoke_O_O__O(arg_2097, arg_2098) } else { tmp5 = linked_2095.(*aot_arbace_j2g_jrt.A_arbace_j2g_jrt_struct_methods_A).Invoke_O_O_O__O(root_2094, arg_2097, arg_2098) } } else {
//line :311:1
				var iter__1927001039__auto____6 any; var tmp8 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New(); var tmp9 *jrt.Class
				var fncls__2211 /*line :311:1*/*jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class

				if fncls__2211 == nil { var fncls__2211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class = fncls__2211d; tmp9 = fncls__2211d } else { tmp9 = fncls__2211 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp11 *lang.Keyword = A_arbace_j2g_dyn_A_const_112; var tmp12 any; var root_2212 any = A_arbace_j2g_dyn_A_const_113.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = c__4; if linked_2213 == nil { tmp12 = ifn_2214.Invoke_O__O(arg_2215) } else { tmp12 = linked_2213.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_2212, arg_2215) }; tmp5 = tmp10.Invoke_O__O(tmp11.Invoke_O__O(tmp12)) }
//line :309:1
		arg_2089 = tmp4.Invoke_O__O(tmp5); if linked_2087 == nil { fs__1927001036__auto____6 = ifn_2088.Invoke_O__O(arg_2089) } else { fs__1927001036__auto____6 = linked_2087.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2086, arg_2089) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2216 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = fs__1927001036__auto____6; var arg_2220 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000270); var tmp14 any; var root_2221 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = s__711000271__1; if linked_2222 == nil { tmp14 = ifn_2223.Invoke_O__O(arg_2224) } else { tmp14 = linked_2222.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2221, arg_2224) }; arg_2220 = tmp13.Invoke_O__O(tmp14); if linked_2217 == nil { return ifn_2218.Invoke_O_O__O(arg_2219, arg_2220) } else { return linked_2217.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2216, arg_2219, arg_2220) } } else { var tmp15 any; var root_2225 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = s__711000271__1; if linked_2226 == nil { tmp15 = ifn_2227.Invoke_O__O(arg_2228) } else { tmp15 = linked_2226.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2225, arg_2228) }; s__711000271__1 = tmp15; continue L1 } } else { var tmp16 any; var root_2229 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any = s__711000271__1; if linked_2230 == nil { tmp16 = ifn_2231.Invoke_O__O(arg_2232) } else { tmp16 = linked_2230.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2229, arg_2232) }; s__711000271__1 = tmp16; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Ctor() {}
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A) Invoke_O_O__O(self, s__711000273__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(s__711000273__1, self); var tmp2 *jrt.Class; var fncls__2084 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class; if fncls__2084 == nil { var fncls__2084d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class = fncls__2084d; tmp2 = fncls__2084d } else { tmp2 = fncls__2084 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A{}; t.Ctor_O_O(p0, p1); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Ctor_O_O(c__s__711000273, c__iter__711000272 any) { t.F_s__711000273 = c__s__711000273; t.F_iter__711000272 = c__iter__711000272 }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A) Invoke_O__O(self any) any { { var s__711000273__1 any; var t_ any = t.F_s__711000273; t.F_s__711000273 = nil; s__711000273__1 = t_; for { var temp__1927000414__auto____2 any; var root_2027 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = s__711000273__1; if linked_2028 == nil { temp__1927000414__auto____2 = ifn_2029.Invoke_O__O(arg_2030) } else { temp__1927000414__auto____2 = linked_2028.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2027, arg_2030) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000273__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2031 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = s__711000273__3; if linked_2032 == nil { tmp1 = ifn_2033.Invoke_O__O(arg_2034) } else { tmp1 = linked_2032.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2031, arg_2034) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2035 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = s__711000273__3; if linked_2036 == nil { c__1927001037__auto____4 = ifn_2037.Invoke_O__O(arg_2038) } else { c__1927001037__auto____4 = linked_2036.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2035, arg_2038) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000275__6 any; var root_2039 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2039, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2041 lang.IFn; if linked_2040 == nil { ifn_2041 = lang.IFn_Cast(root_2039) } else { ifn_2041 = nil }; var arg_2042 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2040 == nil { b__711000275__6 = ifn_2041.Invoke_O__O(arg_2042) } else { b__711000275__6 = linked_2040.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2039, arg_2042) }; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(b__711000275__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2048 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class; if fncls__2048 == nil { var fncls__2048d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class = fncls__2048d; tmp3 = fncls__2048d } else { tmp3 = fncls__2048 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2049 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2049, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2051 lang.IFn; if linked_2050 == nil { ifn_2051 = lang.IFn_Cast(root_2049) } else { ifn_2051 = nil }; var arg_2052 any; var root_2054 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = b__711000275__6; if linked_2055 == nil { arg_2052 = ifn_2056.Invoke_O__O(arg_2057) } else { arg_2052 = linked_2055.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2054, arg_2057) }; var arg_2053 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp5 any; var root_2058 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = s__711000273__3; if linked_2059 == nil { tmp5 = ifn_2060.Invoke_O__O(arg_2061) } else { tmp5 = linked_2059.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2058, arg_2061) }; arg_2053 = tmp4.Invoke_O__O(tmp5); if linked_2050 == nil { return ifn_2051.Invoke_O_O__O(arg_2052, arg_2053) } else { return linked_2050.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2049, arg_2052, arg_2053) } } else { var root_2062 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any; var root_2067 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = b__711000275__6; if linked_2068 == nil { arg_2065 = ifn_2069.Invoke_O__O(arg_2070) } else { arg_2065 = linked_2068.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2067, arg_2070) }; var arg_2066 any; if linked_2063 == nil { return ifn_2064.Invoke_O_O__O(arg_2065, arg_2066) } else { return linked_2063.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2062, arg_2065, arg_2066) } } } else { var nme__4 any; var root_2071 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = s__711000273__3; if linked_2072 == nil { nme__4 = ifn_2073.Invoke_O__O(arg_2074) } else { nme__4 = linked_2072.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2071, arg_2074) }; var root_2075 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2077 lang.IFn; if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = nme__4; var arg_2079 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000272); var tmp7 any; var root_2080 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2080, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2082 lang.IFn; if linked_2081 == nil { ifn_2082 = lang.IFn_Cast(root_2080) } else { ifn_2082 = nil }; var arg_2083 any = s__711000273__3; if linked_2081 == nil { tmp7 = ifn_2082.Invoke_O__O(arg_2083) } else { tmp7 = linked_2081.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2080, arg_2083) }; arg_2079 = tmp6.Invoke_O__O(tmp7); if linked_2076 == nil { return ifn_2077.Invoke_O_O__O(arg_2078, arg_2079) } else { return linked_2076.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2075, arg_2078, arg_2079) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :309:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Ctor_O_I_O(c__b__711000275 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000275 = c__b__711000275; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :309:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A) Invoke_O__O(self any) any { { var i__711000274__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000274__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nme__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000274__1)); var root_2043 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = t.F_b__711000275; var arg_2047 any = nme__2; if linked_2044 == nil { ifn_2045.Invoke_O_O__O(arg_2046, arg_2047) } else { linked_2044.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2043, arg_2046, arg_2047) }; i__711000274__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000274__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_New() *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Ctor() {}
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A) Invoke_O_O__O(self, s__711000285__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(s__711000285__1, self); var tmp2 *jrt.Class; var fncls__2210 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class; if fncls__2210 == nil { var fncls__2210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class = fncls__2210d; tmp2 = fncls__2210d } else { tmp2 = fncls__2210 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :313:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A{}; t.Ctor_O_O(p0, p1); return t }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Ctor_O_O(c__s__711000285, c__iter__711000284 any) { t.F_s__711000285 = c__s__711000285; t.F_iter__711000284 = c__iter__711000284 }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A) Invoke_O__O(self any) any { { var s__711000285__1 any; var t_ any = t.F_s__711000285; t.F_s__711000285 = nil; s__711000285__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2103 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = s__711000285__1; if linked_2104 == nil { temp__1927000414__auto____2 = ifn_2105.Invoke_O__O(arg_2106) } else { temp__1927000414__auto____2 = linked_2104.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2103, arg_2106) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000285__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2107 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2107, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2109 lang.IFn; if linked_2108 == nil { ifn_2109 = lang.IFn_Cast(root_2107) } else { ifn_2109 = nil }; var arg_2110 any = s__711000285__3; if linked_2108 == nil { tmp1 = ifn_2109.Invoke_O__O(arg_2110) } else { tmp1 = linked_2108.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2107, arg_2110) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2111 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = s__711000285__3; if linked_2112 == nil { c__1927001037__auto____4 = ifn_2113.Invoke_O__O(arg_2114) } else { c__1927001037__auto____4 = linked_2112.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2111, arg_2114) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000287__6 any; var root_2115 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2116 == nil { b__711000287__6 = ifn_2117.Invoke_O__O(arg_2118) } else { b__711000287__6 = linked_2116.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2115, arg_2118) }; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(b__711000287__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2147 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class; if fncls__2147 == nil { var fncls__2147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class = fncls__2147d; tmp3 = fncls__2147d } else { tmp3 = fncls__2147 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2148 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2148, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2150 lang.IFn; if linked_2149 == nil { ifn_2150 = lang.IFn_Cast(root_2148) } else { ifn_2150 = nil }; var arg_2151 any; var root_2153 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2153, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2155 lang.IFn; if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = b__711000287__6; if linked_2154 == nil { arg_2151 = ifn_2155.Invoke_O__O(arg_2156) } else { arg_2151 = linked_2154.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2153, arg_2156) }; var arg_2152 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp5 any; var root_2157 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = s__711000285__3; if linked_2158 == nil { tmp5 = ifn_2159.Invoke_O__O(arg_2160) } else { tmp5 = linked_2158.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2157, arg_2160) }; arg_2152 = tmp4.Invoke_O__O(tmp5); if linked_2149 == nil { return ifn_2150.Invoke_O_O__O(arg_2151, arg_2152) } else { return linked_2149.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2148, arg_2151, arg_2152) } } else { var root_2161 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2163 lang.IFn; if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any; var root_2166 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = b__711000287__6; if linked_2167 == nil { arg_2164 = ifn_2168.Invoke_O__O(arg_2169) } else { arg_2164 = linked_2167.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2166, arg_2169) }; var arg_2165 any; if linked_2162 == nil { return ifn_2163.Invoke_O_O__O(arg_2164, arg_2165) } else { return linked_2162.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2161, arg_2164, arg_2165) } } } else { var mm__4 any; var root_2170 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2172 lang.IFn; if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any = s__711000285__3; if linked_2171 == nil { mm__4 = ifn_2172.Invoke_O__O(arg_2173) } else { mm__4 = linked_2171.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2170, arg_2173) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2174 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2174, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2176 lang.IFn
																				if linked_2175 == nil { ifn_2176 = lang.IFn_Cast(root_2174) } else { ifn_2176 = nil }; var arg_2177 any; var root_2178 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2178, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2180 lang.IFn; if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any = mm__4; if linked_2179 == nil { arg_2177 = ifn_2180.Invoke_O__O(arg_2181) } else { arg_2177 = linked_2179.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2178, arg_2181) }; if linked_2175 == nil { and__1927000168__auto____5 = ifn_2176.Invoke_O__O(arg_2177) } else { and__1927000168__auto____5 = linked_2175.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2174, arg_2177) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_2182 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2184 lang.IFn; if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any = Lit_29; var arg_2186 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_2183 == nil { and__1927000168__auto____6 = ifn_2184.Invoke_O_O__O(arg_2185, arg_2186) } else { and__1927000168__auto____6 = linked_2183.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2182, arg_2185, arg_2186) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_2187 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2188 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2187, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2189 lang.IFn; if linked_2188 == nil { ifn_2189 = lang.IFn_Cast(root_2187) } else { ifn_2189 = nil }; var arg_2190 any = Lit_105; var arg_2191 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); if linked_2188 == nil { tmp6 = ifn_2189.Invoke_O_O__O(arg_2190, arg_2191) } else { tmp6 = linked_2188.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2187, arg_2190, arg_2191) } } else { tmp6 = and__1927000168__auto____6 } } else { tmp6 = and__1927000168__auto____5 }
//line :313:1
	if jrt.J2g_Truth(tmp6) { var root_2192 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2192, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2194 lang.IFn; if linked_2193 == nil { ifn_2194 = lang.IFn_Cast(root_2192) } else { ifn_2194 = nil }; var arg_2195 any; var root_2197 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2199 lang.IFn

		if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__4); var arg_2201 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__4); if linked_2198 == nil { arg_2195 = ifn_2199.Invoke_O_O__O(arg_2200, arg_2201) } else { arg_2195 = linked_2198.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2197, arg_2200, arg_2201) }
//line :313:1
		var arg_2196 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000284); var tmp8 any; var root_2202 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2204 lang.IFn; if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any = s__711000285__3; if linked_2203 == nil { tmp8 = ifn_2204.Invoke_O__O(arg_2205) } else { tmp8 = linked_2203.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2202, arg_2205) }; arg_2196 = tmp7.Invoke_O__O(tmp8); if linked_2193 == nil { return ifn_2194.Invoke_O_O__O(arg_2195, arg_2196) } else { return linked_2193.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2192, arg_2195, arg_2196) } } else { var tmp9 any; var root_2206 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2206, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2208 lang.IFn; if linked_2207 == nil { ifn_2208 = lang.IFn_Cast(root_2206) } else { ifn_2208 = nil }; var arg_2209 any = s__711000285__3; if linked_2207 == nil { tmp9 = ifn_2208.Invoke_O__O(arg_2209) } else { tmp9 = linked_2207.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2206, arg_2209) }; s__711000285__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :313:1
func A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Ctor_O_I_O(c__b__711000287 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000287 = c__b__711000287; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :313:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A) Invoke_O__O(self any) any { { var i__711000286__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000286__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000286__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2119 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2119, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2121 lang.IFn
																					if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; var arg_2122 any; var root_2123 any = A_arbace_j2g_dyn_A_const_164.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A_fn_class); var ifn_2125 lang.IFn; if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any = mm__2; if linked_2124 == nil { arg_2122 = ifn_2125.Invoke_O__O(arg_2126) } else { arg_2122 = linked_2124.(*aot_arbace_j2g_model.A_arbace_j2g_model_static_QMARK__A).Invoke_O_O__O(root_2123, arg_2126) }; if linked_2120 == nil { and__1927000168__auto____3 = ifn_2121.Invoke_O__O(arg_2122) } else { and__1927000168__auto____3 = linked_2120.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2119, arg_2122) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_2127 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2127, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2129 lang.IFn; if linked_2128 == nil { ifn_2129 = lang.IFn_Cast(root_2127) } else { ifn_2129 = nil }; var arg_2130 any = Lit_29; var arg_2131 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_2128 == nil { and__1927000168__auto____4 = ifn_2129.Invoke_O_O__O(arg_2130, arg_2131) } else { and__1927000168__auto____4 = linked_2128.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2127, arg_2130, arg_2131) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var root_2132 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2132, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = Lit_105; var arg_2136 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); if linked_2133 == nil { tmp2 = ifn_2134.Invoke_O_O__O(arg_2135, arg_2136) } else { tmp2 = linked_2133.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2132, arg_2135, arg_2136) } } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :313:1
	if jrt.J2g_Truth(tmp2) { var root_2137 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2137, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2139 lang.IFn; if linked_2138 == nil { ifn_2139 = lang.IFn_Cast(root_2137) } else { ifn_2139 = nil }; var arg_2140 any = t.F_b__711000287; var arg_2141 any; var root_2142 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2144 lang.IFn

		if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any = A_arbace_j2g_dyn_A_const_64.Invoke_O__O(mm__2); var arg_2146 any = A_arbace_j2g_dyn_A_const_65.Invoke_O__O(mm__2); if linked_2143 == nil { arg_2141 = ifn_2144.Invoke_O_O__O(arg_2145, arg_2146) } else { arg_2141 = linked_2143.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2142, arg_2145, arg_2146) }
//line :313:1
		if linked_2138 == nil { ifn_2139.Invoke_O_O__O(arg_2140, arg_2141) } else { linked_2138.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2137, arg_2140, arg_2141) }; i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } else { i__711000286__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000286__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_New_O(p0 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A{}; t.Ctor_O(p0); return t }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A) Invoke_O_O__O(self, s__711000297__1 any) any { var tmp1 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(s__711000297__1, t.F_n, self); var tmp2 *jrt.Class; var fncls__2326 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class; if fncls__2326 == nil { var fncls__2326d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class = fncls__2326d; tmp2 = fncls__2326d } else { tmp2 = fncls__2326 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :317:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Ctor_O_O_O(c__s__711000297, c__n, c__iter__711000296 any) { t.F_s__711000297 = c__s__711000297; t.F_n = c__n; t.F_iter__711000296 = c__iter__711000296 }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A) Invoke_O__O(self any) any { { var s__711000297__1 any; var t_ any = t.F_s__711000297; t.F_s__711000297 = nil; s__711000297__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2239 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = s__711000297__1; if linked_2240 == nil { temp__1927000414__auto____2 = ifn_2241.Invoke_O__O(arg_2242) } else { temp__1927000414__auto____2 = linked_2240.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2239, arg_2242) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000297__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2243 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2243, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2245 lang.IFn; if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any = s__711000297__3; if linked_2244 == nil { tmp1 = ifn_2245.Invoke_O__O(arg_2246) } else { tmp1 = linked_2244.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2243, arg_2246) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2247 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2247, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2249 lang.IFn; if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2250 any = s__711000297__3; if linked_2248 == nil { c__1927001037__auto____4 = ifn_2249.Invoke_O__O(arg_2250) } else { c__1927001037__auto____4 = linked_2248.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2247, arg_2250) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000299__6 any; var root_2251 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2251, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2253 lang.IFn; if linked_2252 == nil { ifn_2253 = lang.IFn_Cast(root_2251) } else { ifn_2253 = nil }; var arg_2254 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2252 == nil { b__711000299__6 = ifn_2253.Invoke_O__O(arg_2254) } else { b__711000299__6 = linked_2252.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2251, arg_2254) }; var tmp2 any = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(t.F_n, b__711000299__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2273 *jrt.Class = A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class; if fncls__2273 == nil { var fncls__2273d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class = fncls__2273d; tmp3 = fncls__2273d } else { tmp3 = fncls__2273 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2274 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2274, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2276 lang.IFn; if linked_2275 == nil { ifn_2276 = lang.IFn_Cast(root_2274) } else { ifn_2276 = nil }; var arg_2277 any; var root_2279 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2279, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2281 lang.IFn; if linked_2280 == nil { ifn_2281 = lang.IFn_Cast(root_2279) } else { ifn_2281 = nil }; var arg_2282 any = b__711000299__6; if linked_2280 == nil { arg_2277 = ifn_2281.Invoke_O__O(arg_2282) } else { arg_2277 = linked_2280.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2279, arg_2282) }; var arg_2278 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp5 any; var root_2283 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2283, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2285 lang.IFn; if linked_2284 == nil { ifn_2285 = lang.IFn_Cast(root_2283) } else { ifn_2285 = nil }; var arg_2286 any = s__711000297__3; if linked_2284 == nil { tmp5 = ifn_2285.Invoke_O__O(arg_2286) } else { tmp5 = linked_2284.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2283, arg_2286) }; arg_2278 = tmp4.Invoke_O__O(tmp5); if linked_2275 == nil { return ifn_2276.Invoke_O_O__O(arg_2277, arg_2278) } else { return linked_2275.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2274, arg_2277, arg_2278) } } else { var root_2287 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2287, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2289 lang.IFn; if linked_2288 == nil { ifn_2289 = lang.IFn_Cast(root_2287) } else { ifn_2289 = nil }; var arg_2290 any; var root_2292 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2292, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2294 lang.IFn; if linked_2293 == nil { ifn_2294 = lang.IFn_Cast(root_2292) } else { ifn_2294 = nil }; var arg_2295 any = b__711000299__6; if linked_2293 == nil { arg_2290 = ifn_2294.Invoke_O__O(arg_2295) } else { arg_2290 = linked_2293.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2292, arg_2295) }; var arg_2291 any; if linked_2288 == nil { return ifn_2289.Invoke_O_O__O(arg_2290, arg_2291) } else { return linked_2288.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2287, arg_2290, arg_2291) } } } else { var j__4 any; var root_2296 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2298 lang.IFn; if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = s__711000297__3; if linked_2297 == nil { j__4 = ifn_2298.Invoke_O__O(arg_2299) } else { j__4 = linked_2297.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2296, arg_2299) }; var tmp6 any; var and__1927000168__auto____5 any; var root_2300 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2301 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2300, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2302 lang.IFn; if linked_2301 == nil { ifn_2302 = lang.IFn_Cast(root_2300) } else { ifn_2302 = nil }; var arg_2303 any = j__4; var arg_2304 any = t.F_n; if linked_2301 == nil { and__1927000168__auto____5 = ifn_2302.Invoke_O_O__O(arg_2303, arg_2304) } else { and__1927000168__auto____5 = linked_2301.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2300, arg_2303, arg_2304) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_2305 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = j__4; if linked_2306 == nil { tmp6 = ifn_2307.Invoke_O__O(arg_2308) } else { tmp6 = linked_2306.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2305, arg_2308) } } else { tmp6 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp6) { var root_2309 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2309, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2311 lang.IFn; if linked_2310 == nil { ifn_2311 = lang.IFn_Cast(root_2309) } else { ifn_2311 = nil }; var arg_2312 any; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp8 any; var root_2314 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2314, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2316 lang.IFn
														if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = j__4; if linked_2315 == nil { tmp8 = ifn_2316.Invoke_O__O(arg_2317) } else { tmp8 = linked_2315.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2314, arg_2317) }; arg_2312 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8)).Ref()
//line :317:1
	var arg_2313 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__711000296); var tmp10 any; var root_2318 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = s__711000297__3; if linked_2319 == nil { tmp10 = ifn_2320.Invoke_O__O(arg_2321) } else { tmp10 = linked_2319.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2318, arg_2321) }; arg_2313 = tmp9.Invoke_O__O(tmp10); if linked_2310 == nil { return ifn_2311.Invoke_O_O__O(arg_2312, arg_2313) } else { return linked_2310.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2309, arg_2312, arg_2313) } } else { var tmp11 any; var root_2322 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2322, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2324 lang.IFn; if linked_2323 == nil { ifn_2324 = lang.IFn_Cast(root_2322) } else { ifn_2324 = nil }; var arg_2325 any = s__711000297__3; if linked_2323 == nil { tmp11 = ifn_2324.Invoke_O__O(arg_2325) } else { tmp11 = linked_2323.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2322, arg_2325) }; s__711000297__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :317:1
func A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Ctor_O_O_I_O(c__n, c__b__711000299 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__711000299 = c__b__711000299; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :317:1
func (t *A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A) Invoke_O__O(self any) any { { var i__711000298__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000298__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000298__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_2255 any = A_arbace_j2g_dyn_A_const_53.GetRawRoot__O(); var linked_2256 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2255, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2257 lang.IFn; if linked_2256 == nil { ifn_2257 = lang.IFn_Cast(root_2255) } else { ifn_2257 = nil }; var arg_2258 any = j__2; var arg_2259 any = t.F_n; if linked_2256 == nil { and__1927000168__auto____3 = ifn_2257.Invoke_O_O__O(arg_2258, arg_2259) } else { and__1927000168__auto____3 = linked_2256.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2255, arg_2258, arg_2259) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_2260 any = A_arbace_j2g_dyn_A_const_36.GetRawRoot__O(); var linked_2261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2260, aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A_fn_class); var ifn_2262 lang.IFn; if linked_2261 == nil { ifn_2262 = lang.IFn_Cast(root_2260) } else { ifn_2262 = nil }; var arg_2263 any = j__2; if linked_2261 == nil { tmp2 = ifn_2262.Invoke_O__O(arg_2263) } else { tmp2 = linked_2261.(*aot_arbace_j2g_model.A_arbace_j2g_model_interface_QMARK__A).Invoke_O_O__O(root_2260, arg_2263) } } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var root_2264 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2264, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2266 lang.IFn; if linked_2265 == nil { ifn_2266 = lang.IFn_Cast(root_2264) } else { ifn_2266 = nil }; var arg_2267 any = t.F_b__711000299; var arg_2268 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp4 any; var root_2269 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2269, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2271 lang.IFn
																if linked_2270 == nil { ifn_2271 = lang.IFn_Cast(root_2269) } else { ifn_2271 = nil }; var arg_2272 any = j__2; if linked_2270 == nil { tmp4 = ifn_2271.Invoke_O__O(arg_2272) } else { tmp4 = linked_2270.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2269, arg_2272) }; arg_2268 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)).Ref()
//line :317:1
	if linked_2265 == nil { ifn_2266.Invoke_O_O__O(arg_2267, arg_2268) } else { linked_2265.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2264, arg_2267, arg_2268) }; i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } else { i__711000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000298__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_sub_forms_A_New() *A_arbace_j2g_dyn_sub_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_A{}; t.Ctor(); return t }
//line :320:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Ctor() {}
//line :320:1
func (t *A_arbace_j2g_dyn_sub_forms_A) Invoke_O_O_O_O__O(self, n__0, ifaces__1, dyn_keys__2 any) any { var g__4 any; var root_2332 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2332, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_2334 lang.IFn; if






	linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; var arg_2335 any = n__0; if linked_2333 == nil { g__4 = ifn_2334.Invoke_O__O(arg_2335) } else { g__4 = linked_2333.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_2332, arg_2335) }; var recv__5 any; var tmp1 lang.IFn = /*line :320:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_280; var tmp3 any; var root_2865 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2865, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2867 lang.IFn; if







	linked_2866 == nil { ifn_2867 = lang.IFn_Cast(root_2865) } else { ifn_2867 = nil }; var arg_2868 any = g__4; if linked_2866 == nil { tmp3 = ifn_2867.Invoke_O__O(arg_2868) } else { tmp3 = linked_2866.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2865, arg_2868) }; recv__5 = tmp1.Invoke_O_O__O(tmp2, tmp3); var own__6 any; var root_2336 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_237.GetRawRoot__O(); var linked_2337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2336, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2338 lang.IFn; if








	linked_2337 == nil { ifn_2338 = lang.IFn_Cast(root_2336) } else { ifn_2338 = nil }; var arg_2339 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2340 any; var iter__1927001039__auto____6 any; var tmp4 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New(); var tmp5 *jrt.Class; var fncls__2411 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class; if fncls__2411 == nil { var fncls__2411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class = fncls__2411d; tmp5 = fncls__2411d } else { tmp5 = fncls__2411 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____6); var tmp7 any; var root_2412 any = A_arbace_j2g_dyn_A_const_57.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A_fn_class); var ifn_2414 lang.IFn; if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = n__0; if linked_2413 == nil { tmp7 = ifn_2414.Invoke_O__O(arg_2415) } else { tmp7 = linked_2413.(*aot_arbace_j2g_model.A_arbace_j2g_model_vmethods_A).Invoke_O_O__O(root_2412, arg_2415) }; arg_2340 = tmp6.Invoke_O__O(tmp7); if linked_2337 == nil { own__6 = ifn_2338.Invoke_O_O__O(arg_2339, arg_2340) } else { own__6 = linked_2337.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2336, arg_2339, arg_2340) }; var dyn_set__7 any; var root_2416 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_238.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2418 lang.IFn; if









	linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = dyn_keys__2; if linked_2417 == nil { dyn_set__7 = ifn_2418.Invoke_O__O(arg_2419) } else { dyn_set__7 = linked_2417.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2416, arg_2419) }; var ks__8 any; var root_2420 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_58.GetRawRoot__O(); var linked_2421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2420, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2422 lang.IFn; if










	linked_2421 == nil { ifn_2422 = lang.IFn_Cast(root_2420) } else { ifn_2422 = nil }; var arg_2423 any; var root_2424 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2424, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2426 lang.IFn; if linked_2425 == nil { ifn_2426 = lang.IFn_Cast(root_2424) } else { ifn_2426 = nil }; var arg_2427 any = dyn_keys__2; var arg_2428 any; var root_2429 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2431 lang.IFn; if linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any; var root_2433 any = A_arbace_j2g_dyn_A_const_239.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = dyn_set__7; var arg_2437 any; var root_2438 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_2439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2438, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2440 lang.IFn; if linked_2439 == nil { ifn_2440 = lang.IFn_Cast(root_2438) } else { ifn_2440 = nil }; var arg_2441 any = own__6; if linked_2439 == nil { arg_2437 = ifn_2440.Invoke_O__O(arg_2441) } else { arg_2437 = linked_2439.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2438, arg_2441) }; if linked_2434 == nil { arg_2432 = ifn_2435.Invoke_O_O__O(arg_2436, arg_2437) } else { arg_2432 = linked_2434.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2433, arg_2436, arg_2437) }; if linked_2430 == nil { arg_2428 = ifn_2431.Invoke_O__O(arg_2432) } else { arg_2428 = linked_2430.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2429, arg_2432) }; if linked_2425 == nil { arg_2423 = ifn_2426.Invoke_O_O__O(arg_2427, arg_2428) } else { arg_2423 = linked_2425.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2424, arg_2427, arg_2428) }; if linked_2421 == nil { ks__8 = ifn_2422.Invoke_O__O(arg_2423) } else { ks__8 = linked_2421.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2420, arg_2423) }; var clash__9 any; var root_2442 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_240.GetRawRoot__O(); var linked_2443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2442, A_arbace_j2g_dyn_go_method_names_A_fn_class); var ifn_2444 lang.IFn; if











	linked_2443 == nil { ifn_2444 = lang.IFn_Cast(root_2442) } else { ifn_2444 = nil }; var arg_2445 any = n__0; if linked_2443 == nil { clash__9 = ifn_2444.Invoke_O__O(arg_2445) } else { clash__9 = linked_2443.(*A_arbace_j2g_dyn_go_method_names_A).Invoke_O_O__O(root_2442, arg_2445) }; var slots__10 any; var root_2446 any = /*line :320:1*/A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2448 lang.IFn; if












	linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_93, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2447 == nil { slots__10 = ifn_2448.Invoke_O__O(arg_2449) } else { slots__10 = linked_2447.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2446, arg_2449) }; var tmp8 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_dyn_A_const_42.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_241; var tmp11 *jrt.RefArray = jrt.ConstRefArray("[0,7,s12:---- DynSub_ns13:: proxies of ns2:, ns8: methods", []*jrt.Class{jrt.String_class}); var tmp12 any; var root_2458 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2458, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2460 lang.IFn; if
	linked_2459 == nil { ifn_2460 = lang.IFn_Cast(root_2458) } else { ifn_2460 = nil }; var arg_2461 any = n__0; if linked_2459 == nil { tmp12 = ifn_2460.Invoke_O__O(arg_2461) } else { tmp12 = linked_2459.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2458, arg_2461) }; var tmp13 any = tmp12; var tmp14 any; var root_2462 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_2463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2462, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2464 lang.IFn; if
	linked_2463 == nil { ifn_2464 = lang.IFn_Cast(root_2462) } else { ifn_2464 = nil }; var arg_2465 any = n__0; var arg_2466 any = Lit_5; var arg_2467 any = Lit_6; if linked_2463 == nil { tmp14 = ifn_2464.Invoke_O_O_O__O(arg_2465, arg_2466, arg_2467) } else { tmp14 = linked_2463.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2462, arg_2465, arg_2466, arg_2467) }; var tmp15 any = /*line :334:1*/tmp9.Invoke_O_O__O(tmp10, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil, tmp14, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__8)).Ref(), nil)).Ref()); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_dyn_A_const_242; var tmp18 any; var root_2468 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2470 lang.IFn; if


	linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = g__4; if linked_2469 == nil { tmp18 = ifn_2470.Invoke_O__O(arg_2471) } else { tmp18 = linked_2469.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2468, arg_2471) }; var tmp19 any = tmp18; var tmp20 /*line :334:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_147, nil, Lit_148); var tmp21 any; var root_2472 any = A_arbace_j2g_dyn_A_const_117.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2474 lang.IFn; if



	linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any = n__0; var arg_2476 any = Lit_5; var arg_2477 any = Lit_6; if linked_2473 == nil { tmp21 = ifn_2474.Invoke_O_O_O__O(arg_2475, arg_2476, arg_2477) } else { tmp21 = linked_2473.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2472, arg_2475, arg_2476, arg_2477) }; var tmp22 any = /*line :334:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, g__4, nil, tmp21, nil)).Ref(); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_dyn_A_const_243; var tmp25 any; var root_2478 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_2479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2478, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2480 lang.IFn; if





	linked_2479 == nil { ifn_2480 = lang.IFn_Cast(root_2478) } else { ifn_2480 = nil }; var arg_2481 any = A_arbace_j2g_dyn_A_const_73; var arg_2482 any = n__0; if linked_2479 == nil { tmp25 = ifn_2480.Invoke_O_O__O(arg_2481, arg_2482) } else { tmp25 = linked_2479.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O__O(root_2478, arg_2481, arg_2482) }; var tmp26 any = /*line :334:1*/tmp16.Invoke_O_O_O_O__O(tmp17, tmp19, tmp22, tmp23.Invoke_O_O_O__O(tmp24, tmp25, A_arbace_j2g_dyn_A_const_244)); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp28 any = A_arbace_j2g_dyn_A_const_245; var tmp29 any; var root_2483 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2483, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2485 lang.IFn; if






	linked_2484 == nil { ifn_2485 = lang.IFn_Cast(root_2483) } else { ifn_2485 = nil }; var arg_2486 any = slots__10; var arg_2487 any = A_arbace_j2g_dyn_A_const_246; if linked_2484 == nil { tmp29 = ifn_2485.Invoke_O_O__O(arg_2486, arg_2487) } else { tmp29 = linked_2484.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2483, arg_2486, arg_2487) }; var tmp30 any = tmp29; var tmp31 any; var root_2488 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2489 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2488, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2490 lang.IFn; if







	linked_2489 == nil { ifn_2490 = lang.IFn_Cast(root_2488) } else { ifn_2490 = nil }; var arg_2491 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2492 any = A_arbace_j2g_dyn_A_const_247; var arg_2493 any = A_arbace_j2g_dyn_A_const_248; var arg_2494 any; var root_2495 any = A_arbace_j2g_dyn_A_const_227.GetRawRoot__O(); var linked_2496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2495, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2497 lang.IFn; if linked_2496 == nil { ifn_2497 = lang.IFn_Cast(root_2495) } else { ifn_2497 = nil }; var arg_2498 any; var tmp32 any = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New(); var tmp33 *jrt.Class; var fncls__2500 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class; if fncls__2500 == nil { var fncls__2500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class = fncls__2500d; tmp33 = fncls__2500d } else { tmp33 = fncls__2500 }; arg_2498 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); var arg_2499 any = ks__8; if linked_2496 == nil { arg_2494 = ifn_2497.Invoke_O_O__O(arg_2498, arg_2499) } else { arg_2494 = linked_2496.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2495, arg_2498, arg_2499) }; if linked_2489 == nil { tmp31 = ifn_2490.Invoke_O_O_O_O__O(arg_2491, arg_2492, arg_2493, arg_2494) } else { tmp31 = linked_2489.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2488, arg_2491, arg_2492, arg_2493, arg_2494) }; var tmp34 any = /*line :334:1*/tmp27.Invoke_O_O_O__O(tmp28, tmp30, tmp31); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp36 any = A_arbace_j2g_dyn_A_const_249; var tmp37 any; var root_2501 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2501, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2503 lang.IFn; if








	linked_2502 == nil { ifn_2503 = lang.IFn_Cast(root_2501) } else { ifn_2503 = nil }; var arg_2504 any; var root_2506 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2508 lang.IFn; if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__4)).Ref(); if linked_2507 == nil { arg_2504 = ifn_2508.Invoke_O__O(arg_2509) } else { arg_2504 = linked_2507.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2506, arg_2509) }; var arg_2505 any = A_arbace_j2g_dyn_A_const_250; if linked_2502 == nil { tmp37 = ifn_2503.Invoke_O_O__O(arg_2504, arg_2505) } else { tmp37 = linked_2502.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2501, arg_2504, arg_2505) }; var tmp38 any = tmp37; var tmp39 any; var root_2510 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2510, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2512 lang.IFn; if









	linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2514 any = A_arbace_j2g_dyn_A_const_251; var arg_2515 any = A_arbace_j2g_dyn_A_const_252; var arg_2516 any; var iter__1927001039__auto____11 any; var tmp40 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New(); var tmp41 *jrt.Class; var fncls__2575 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class; if fncls__2575 == nil { var fncls__2575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class = fncls__2575d; tmp41 = fncls__2575d } else { tmp41 = fncls__2575 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); var tmp42 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11); var tmp43 any; var root_2576 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any; var root_2580 any = A_arbace_j2g_dyn_A_const_50.GetRawRoot__O(); var linked_2581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2580, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2582 lang.IFn; if linked_2581 == nil { ifn_2582 = lang.IFn_Cast(root_2580) } else { ifn_2582 = nil }; var arg_2583 any = own__6; if linked_2581 == nil { arg_2579 = ifn_2582.Invoke_O__O(arg_2583) } else { arg_2579 = linked_2581.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2580, arg_2583) }; if linked_2577 == nil { tmp43 = ifn_2578.Invoke_O__O(arg_2579) } else { tmp43 = linked_2577.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2576, arg_2579) }; arg_2516 = tmp42.Invoke_O__O(tmp43); if linked_2511 == nil { tmp39 = ifn_2512.Invoke_O_O_O_O__O(arg_2513, arg_2514, arg_2515, arg_2516) } else { tmp39 = linked_2511.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2510, arg_2513, arg_2514, arg_2515, arg_2516) }; var tmp44 any = /*line :334:1*/tmp35.Invoke_O_O_O__O(tmp36, tmp38, tmp39); var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp46 any = A_arbace_j2g_dyn_A_const_253; var tmp47 any = A_arbace_j2g_dyn_A_const_254; var tmp48 any; var root_2584 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2586 lang.IFn; if










	linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any; var tmp49 any; var root_2589 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2589, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2591 lang.IFn; if linked_2590 == nil { ifn_2591 = lang.IFn_Cast(root_2589) } else { ifn_2591 = nil }; var arg_2592 any = A_arbace_j2g_dyn_A_const_255; var arg_2593 any = recv__5; if linked_2590 == nil { tmp49 = ifn_2591.Invoke_O_O__O(arg_2592, arg_2593) } else { tmp49 = linked_2590.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2589, arg_2592, arg_2593) }; arg_2587 = lang.Tuple_Create_O__IPersistentVector(tmp49); var arg_2588 any = A_arbace_j2g_dyn_A_const_256; if linked_2585 == nil { tmp48 = ifn_2586.Invoke_O_O__O(arg_2587, arg_2588) } else { tmp48 = linked_2585.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2584, arg_2587, arg_2588) }; var tmp50 any = /*line :334:1*/tmp45.Invoke_O_O_O_O_O__O(tmp46, tmp47, tmp48, A_arbace_j2g_dyn_A_const_257, A_arbace_j2g_dyn_A_const_258); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp52 any = A_arbace_j2g_dyn_A_const_259; var tmp53 any = A_arbace_j2g_dyn_A_const_260; var tmp54 any; var root_2594 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2594, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2596 lang.IFn; if











	linked_2595 == nil { ifn_2596 = lang.IFn_Cast(root_2594) } else { ifn_2596 = nil }; var arg_2597 any; var tmp55 any; var root_2599 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2599, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2601 lang.IFn; if linked_2600 == nil { ifn_2601 = lang.IFn_Cast(root_2599) } else { ifn_2601 = nil }; var arg_2602 any = A_arbace_j2g_dyn_A_const_261; var arg_2603 any = recv__5; if linked_2600 == nil { tmp55 = ifn_2601.Invoke_O_O__O(arg_2602, arg_2603) } else { tmp55 = linked_2600.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2599, arg_2602, arg_2603) }; arg_2597 = lang.Tuple_Create_O__IPersistentVector(tmp55); var arg_2598 any = A_arbace_j2g_dyn_A_const_262; if linked_2595 == nil { tmp54 = ifn_2596.Invoke_O_O__O(arg_2597, arg_2598) } else { tmp54 = linked_2595.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2594, arg_2597, arg_2598) }; var tmp56 any = /*line :334:1*/tmp51.Invoke_O_O_O_O__O(tmp52, tmp53, tmp54, A_arbace_j2g_dyn_A_const_263); var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp58 any = A_arbace_j2g_dyn_A_const_264; var tmp59 any = A_arbace_j2g_dyn_A_const_265; var tmp60 any; var root_2604 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2606 lang.IFn; if












	linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any; var tmp61 any; var root_2609 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2609, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2611 lang.IFn; if linked_2610 == nil { ifn_2611 = lang.IFn_Cast(root_2609) } else { ifn_2611 = nil }; var arg_2612 any = A_arbace_j2g_dyn_A_const_266; var arg_2613 any = recv__5; if linked_2610 == nil { tmp61 = ifn_2611.Invoke_O_O__O(arg_2612, arg_2613) } else { tmp61 = linked_2610.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2609, arg_2612, arg_2613) }; arg_2607 = lang.Tuple_Create_O__IPersistentVector(tmp61); var arg_2608 any = A_arbace_j2g_dyn_A_const_267; if linked_2605 == nil { tmp60 = ifn_2606.Invoke_O_O__O(arg_2607, arg_2608) } else { tmp60 = linked_2605.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2604, arg_2607, arg_2608) }; var tmp62 any = /*line :334:1*/tmp57.Invoke_O_O_O_O__O(tmp58, tmp59, tmp60, A_arbace_j2g_dyn_A_const_268); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_dyn_A_const_269; var tmp65 any = A_arbace_j2g_dyn_A_const_270; var tmp66 any; var root_2614 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2614, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2616 lang.IFn; if













	linked_2615 == nil { ifn_2616 = lang.IFn_Cast(root_2614) } else { ifn_2616 = nil }; var arg_2617 any; var tmp67 any; var root_2619 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2619, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2621 lang.IFn; if linked_2620 == nil { ifn_2621 = lang.IFn_Cast(root_2619) } else { ifn_2621 = nil }; var arg_2622 any = A_arbace_j2g_dyn_A_const_271; var arg_2623 any = recv__5; if linked_2620 == nil { tmp67 = ifn_2621.Invoke_O_O__O(arg_2622, arg_2623) } else { tmp67 = linked_2620.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2619, arg_2622, arg_2623) }; arg_2617 = lang.Tuple_Create_O__IPersistentVector(tmp67); var arg_2618 any = A_arbace_j2g_dyn_A_const_272; if linked_2615 == nil { tmp66 = ifn_2616.Invoke_O_O__O(arg_2617, arg_2618) } else { tmp66 = linked_2615.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2614, arg_2617, arg_2618) }; var tmp68 any = /*line :334:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp26, tmp34, tmp44, tmp50, tmp56, tmp62, tmp63.Invoke_O_O_O_O__O(tmp64, tmp65, tmp66, A_arbace_j2g_dyn_A_const_273))); var tmp69 any; var iter__1927001039__auto____11_2 any; var tmp70 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(recv__5, n__0); var tmp71 *jrt.Class; var fncls__2710 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class; if














	fncls__2710 == nil { var fncls__2710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class = fncls__2710d; tmp71 = fncls__2710d } else { tmp71 = fncls__2710 }; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp70, tmp71, nil); var tmp72 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____11_2); var tmp73 any; var root_2711 any = A_arbace_j2g_dyn_A_const_133.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O())).Ref(); if linked_2712 == nil { tmp73 = ifn_2713.Invoke_O__O(arg_2714) } else { tmp73 = linked_2712.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_2711, arg_2714) }; tmp69 = tmp72.Invoke_O__O(tmp73); var tmp74 any = tmp69; var tmp75 any; var iter__1927001039__auto____11_3 any; var tmp76 any = /*line :334:1*/A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(recv__5, clash__9); var tmp77 *jrt.Class; var fncls__2803 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class; if

















	fncls__2803 == nil { var fncls__2803d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class = fncls__2803d; tmp77 = fncls__2803d } else { tmp77 = fncls__2803 }; iter__1927001039__auto____11_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp76, tmp77, nil); tmp75 = lang.IFn_Cast(iter__1927001039__auto____11_3).Invoke_O__O(ifaces__1); var tmp78 any = tmp75; var tmp79 any; var root_2804 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_277.GetRawRoot__O(); var linked_2805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2804, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_2806 lang.IFn; if



















	linked_2805 == nil { ifn_2806 = lang.IFn_Cast(root_2804) } else { ifn_2806 = nil }; var arg_2807 any; var tmp80 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(own__6, recv__5, clash__9, ifaces__1, n__0); var tmp81 *jrt.Class; var fncls__2860 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class; if fncls__2860 == nil { var fncls__2860d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class = fncls__2860d; tmp81 = fncls__2860d } else { tmp81 = fncls__2860 }; arg_2807 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp80, tmp81, nil); var arg_2808 any = ks__8; if linked_2805 == nil { tmp79 = ifn_2806.Invoke_O_O__O(arg_2807, arg_2808) } else { tmp79 = linked_2805.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_2804, arg_2807, arg_2808) }; var tmp82 any = tmp79; var tmp83 any; var root_2861 any = /*line :334:1*/A_arbace_j2g_dyn_A_const_279.GetRawRoot__O(); var linked_2862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2861, A_arbace_j2g_dyn_ctor_infos_A_fn_class); var ifn_2863 lang.IFn; if


























	linked_2862 == nil { ifn_2863 = lang.IFn_Cast(root_2861) } else { ifn_2863 = nil }; var arg_2864 any = n__0; if linked_2862 == nil { tmp83 = ifn_2863.Invoke_O__O(arg_2864) } else { tmp83 = linked_2862.(*A_arbace_j2g_dyn_ctor_infos_A).Invoke_O_O__O(root_2861, arg_2864) }; return /*line :334:1*/ tmp8.Invoke_O_O_O_O_O__O(tmp68, tmp74, tmp78, tmp82, lang.Tuple_Create_O__IPersistentVector(tmp83)) }
//line :329:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Ctor() {}
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A) Invoke_O_O__O(self, s__711000308__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(self, s__711000308__1); var tmp2 *jrt.Class; var fncls__2410 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class; if fncls__2410 == nil { var fncls__2410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class = fncls__2410d; tmp2 = fncls__2410d } else { tmp2 = fncls__2410 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :329:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A{}; t.Ctor_O_O(p0, p1); return t }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Ctor_O_O(c__iter__711000307, c__s__711000308 any) { t.F_iter__711000307 = c__iter__711000307; t.F_s__711000308 = c__s__711000308 }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A) Invoke_O__O(self any) any { { var s__711000308__1 any; var t_ any = t.F_s__711000308; t.F_s__711000308 = nil; s__711000308__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2341 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2341, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2343 lang.IFn; if linked_2342 == nil { ifn_2343 = lang.IFn_Cast(root_2341) } else { ifn_2343 = nil }; var arg_2344 any = s__711000308__1; if linked_2342 == nil { temp__1927000414__auto____2 = ifn_2343.Invoke_O__O(arg_2344) } else { temp__1927000414__auto____2 = linked_2342.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2341, arg_2344) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000308__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2345 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2345, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2347 lang.IFn; if linked_2346 == nil { ifn_2347 = lang.IFn_Cast(root_2345) } else { ifn_2347 = nil }; var arg_2348 any = s__711000308__3; if linked_2346 == nil { tmp1 = ifn_2347.Invoke_O__O(arg_2348) } else { tmp1 = linked_2346.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2345, arg_2348) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2349 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2349, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2351 lang.IFn; if linked_2350 == nil { ifn_2351 = lang.IFn_Cast(root_2349) } else { ifn_2351 = nil }; var arg_2352 any = s__711000308__3; if linked_2350 == nil { c__1927001037__auto____4 = ifn_2351.Invoke_O__O(arg_2352) } else { c__1927001037__auto____4 = linked_2350.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2349, arg_2352) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000310__6 any; var root_2353 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2353, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2355 lang.IFn; if linked_2354 == nil { ifn_2355 = lang.IFn_Cast(root_2353) } else { ifn_2355 = nil }; var arg_2356 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2354 == nil { b__711000310__6 = ifn_2355.Invoke_O__O(arg_2356) } else { b__711000310__6 = linked_2354.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2353, arg_2356) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(b__711000310__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2366 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class; if fncls__2366 == nil { var fncls__2366d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class = fncls__2366d; tmp3 = fncls__2366d } else { tmp3 = fncls__2366 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2367 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2367, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2369 lang.IFn; if linked_2368 == nil { ifn_2369 = lang.IFn_Cast(root_2367) } else { ifn_2369 = nil }; var arg_2370 any; var root_2372 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2372, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2374 lang.IFn; if linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = b__711000310__6; if linked_2373 == nil { arg_2370 = ifn_2374.Invoke_O__O(arg_2375) } else { arg_2370 = linked_2373.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2372, arg_2375) }; var arg_2371 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp5 any; var root_2376 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = s__711000308__3; if linked_2377 == nil { tmp5 = ifn_2378.Invoke_O__O(arg_2379) } else { tmp5 = linked_2377.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2376, arg_2379) }; arg_2371 = tmp4.Invoke_O__O(tmp5); if linked_2368 == nil { return ifn_2369.Invoke_O_O__O(arg_2370, arg_2371) } else { return linked_2368.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2367, arg_2370, arg_2371) } } else { var root_2380 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2380, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2382 lang.IFn; if linked_2381 == nil { ifn_2382 = lang.IFn_Cast(root_2380) } else { ifn_2382 = nil }; var arg_2383 any; var root_2385 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2385, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2387 lang.IFn; if linked_2386 == nil { ifn_2387 = lang.IFn_Cast(root_2385) } else { ifn_2387 = nil }; var arg_2388 any = b__711000310__6; if linked_2386 == nil { arg_2383 = ifn_2387.Invoke_O__O(arg_2388) } else { arg_2383 = linked_2386.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2385, arg_2388) }; var arg_2384 any; if linked_2381 == nil { return ifn_2382.Invoke_O_O__O(arg_2383, arg_2384) } else { return linked_2381.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2380, arg_2383, arg_2384) } } } else { var vec__711000318__4 any; var root_2389 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2389, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2391 lang.IFn; if linked_2390 == nil { ifn_2391 = lang.IFn_Cast(root_2389) } else { ifn_2391 = nil }; var arg_2392 any = s__711000308__3; if linked_2390 == nil { vec__711000318__4 = ifn_2391.Invoke_O__O(arg_2392) } else { vec__711000318__4 = linked_2390.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2389, arg_2392) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000318__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_2393 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2393, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2395 lang.IFn; if linked_2394 == nil { ifn_2395 = lang.IFn_Cast(root_2393) } else { ifn_2395 = nil }; var arg_2396 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__5); if linked_2394 == nil { tmp6 = ifn_2395.Invoke_O__O(arg_2396) } else { tmp6 = linked_2394.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2393, arg_2396) }; if jrt.J2g_Truth(tmp6) { var root_2397 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2397, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2399 lang.IFn; if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any = lang.Tuple_Create_O_O__IPersistentVector(k__5, mm__6); var arg_2401 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__711000307); var tmp8 any; var root_2402 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2402, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2404 lang.IFn; if linked_2403 == nil { ifn_2404 = lang.IFn_Cast(root_2402) } else { ifn_2404 = nil }; var arg_2405 any = s__711000308__3; if linked_2403 == nil { tmp8 = ifn_2404.Invoke_O__O(arg_2405) } else { tmp8 = linked_2403.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2402, arg_2405) }; arg_2401 = tmp7.Invoke_O__O(tmp8); if linked_2398 == nil { return ifn_2399.Invoke_O_O__O(arg_2400, arg_2401) } else { return linked_2398.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2397, arg_2400, arg_2401) } } else { var tmp9 any; var root_2406 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2406, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2408 lang.IFn; if linked_2407 == nil { ifn_2408 = lang.IFn_Cast(root_2406) } else { ifn_2408 = nil }; var arg_2409 any = s__711000308__3; if linked_2407 == nil { tmp9 = ifn_2408.Invoke_O__O(arg_2409) } else { tmp9 = linked_2407.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2406, arg_2409) }; s__711000308__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :329:1
func A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Ctor_O_I_O(c__b__711000310 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000310 = c__b__711000310; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :329:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A) Invoke_O__O(self any) any { { var i__711000309__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000309__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000314__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000309__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000314__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_2357 any = A_arbace_j2g_dyn_A_const_32.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2357, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2359 lang.IFn; if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_56.GetRawRoot__O()).Invoke_O__O(k__3); if linked_2358 == nil { tmp2 = ifn_2359.Invoke_O__O(arg_2360) } else { tmp2 = linked_2358.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2357, arg_2360) }; if jrt.J2g_Truth(tmp2) { var root_2361 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = t.F_b__711000310; var arg_2365 any = lang.Tuple_Create_O_O__IPersistentVector(k__3, mm__4); if linked_2362 == nil { ifn_2363.Invoke_O_O__O(arg_2364, arg_2365) } else { linked_2362.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2361, arg_2364, arg_2365) }; i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } else { i__711000309__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000309__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_dyn_sub_forms_fn__711000324_A_New() *A_arbace_j2g_dyn_sub_forms_fn__711000324_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000324_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Ctor() {}
//line :342:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000324_A) Invoke_O_O_O__O(self, i__1, p__711000323__2 any) any { var vec__711000325__3 any = p__711000323__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000325__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }

func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_New() *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A{}; t.Ctor(); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Ctor() {}
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A) Invoke_O_O__O(self, s__711000330__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(s__711000330__1, self); var tmp2 *jrt.Class; var fncls__2574 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class; if fncls__2574 == nil { var fncls__2574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class = fncls__2574d; tmp2 = fncls__2574d } else { tmp2 = fncls__2574 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :344:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A{}; t.Ctor_O_O(p0, p1); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Ctor_O_O(c__s__711000330, c__iter__711000329 any) { t.F_s__711000330 = c__s__711000330; t.F_iter__711000329 = c__iter__711000329 }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A) Invoke_O__O(self any) any { { var s__711000330__1 any; var t_ any = t.F_s__711000330; t.F_s__711000330 = nil; s__711000330__1 = t_; for { var temp__1927000414__auto____2 any; var root_2517 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2517, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2519 lang.IFn; if linked_2518 == nil { ifn_2519 = lang.IFn_Cast(root_2517) } else { ifn_2519 = nil }; var arg_2520 any = s__711000330__1; if linked_2518 == nil { temp__1927000414__auto____2 = ifn_2519.Invoke_O__O(arg_2520) } else { temp__1927000414__auto____2 = linked_2518.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2517, arg_2520) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000330__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2521 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2523 lang.IFn; if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any = s__711000330__3; if linked_2522 == nil { tmp1 = ifn_2523.Invoke_O__O(arg_2524) } else { tmp1 = linked_2522.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2521, arg_2524) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2525 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2525, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2527 lang.IFn; if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any = s__711000330__3; if linked_2526 == nil { c__1927001037__auto____4 = ifn_2527.Invoke_O__O(arg_2528) } else { c__1927001037__auto____4 = linked_2526.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2525, arg_2528) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000332__6 any; var root_2529 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2529, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2531 lang.IFn; if linked_2530 == nil { ifn_2531 = lang.IFn_Cast(root_2529) } else { ifn_2531 = nil }; var arg_2532 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2530 == nil { b__711000332__6 = ifn_2531.Invoke_O__O(arg_2532) } else { b__711000332__6 = linked_2530.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2529, arg_2532) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(b__711000332__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2538 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class; if fncls__2538 == nil { var fncls__2538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class = fncls__2538d; tmp3 = fncls__2538d } else { tmp3 = fncls__2538 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2539 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2541 lang.IFn; if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any; var root_2544 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2546 lang.IFn; if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any = b__711000332__6; if linked_2545 == nil { arg_2542 = ifn_2546.Invoke_O__O(arg_2547) } else { arg_2542 = linked_2545.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2544, arg_2547) }; var arg_2543 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp5 any; var root_2548 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2548, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2550 lang.IFn; if linked_2549 == nil { ifn_2550 = lang.IFn_Cast(root_2548) } else { ifn_2550 = nil }; var arg_2551 any = s__711000330__3; if linked_2549 == nil { tmp5 = ifn_2550.Invoke_O__O(arg_2551) } else { tmp5 = linked_2549.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2548, arg_2551) }; arg_2543 = tmp4.Invoke_O__O(tmp5); if linked_2540 == nil { return ifn_2541.Invoke_O_O__O(arg_2542, arg_2543) } else { return linked_2540.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2539, arg_2542, arg_2543) } } else { var root_2552 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2552, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2554 lang.IFn; if linked_2553 == nil { ifn_2554 = lang.IFn_Cast(root_2552) } else { ifn_2554 = nil }; var arg_2555 any; var root_2557 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2557, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2559 lang.IFn; if linked_2558 == nil { ifn_2559 = lang.IFn_Cast(root_2557) } else { ifn_2559 = nil }; var arg_2560 any = b__711000332__6; if linked_2558 == nil { arg_2555 = ifn_2559.Invoke_O__O(arg_2560) } else { arg_2555 = linked_2558.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2557, arg_2560) }; var arg_2556 any; if linked_2553 == nil { return ifn_2554.Invoke_O_O__O(arg_2555, arg_2556) } else { return linked_2553.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2552, arg_2555, arg_2556) } } } else { var vec__711000340__4 any; var root_2561 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2561, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2563 lang.IFn; if linked_2562 == nil { ifn_2563 = lang.IFn_Cast(root_2561) } else { ifn_2563 = nil }; var arg_2564 any = s__711000330__3; if linked_2562 == nil { vec__711000340__4 = ifn_2563.Invoke_O__O(arg_2564) } else { vec__711000340__4 = linked_2562.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2561, arg_2564) }; var nme__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000340__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2565 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2565, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2567 lang.IFn; if linked_2566 == nil { ifn_2567 = lang.IFn_Cast(root_2565) } else { ifn_2567 = nil }; var arg_2568 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__5, desc__6)).Ref(), nme__5); var arg_2569 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__711000329); var tmp7 any; var root_2570 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2570, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2572 lang.IFn; if linked_2571 == nil { ifn_2572 = lang.IFn_Cast(root_2570) } else { ifn_2572 = nil }; var arg_2573 any = s__711000330__3; if linked_2571 == nil { tmp7 = ifn_2572.Invoke_O__O(arg_2573) } else { tmp7 = linked_2571.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2570, arg_2573) }; arg_2569 = tmp6.Invoke_O__O(tmp7); if linked_2566 == nil { return ifn_2567.Invoke_O_O__O(arg_2568, arg_2569) } else { return linked_2566.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2565, arg_2568, arg_2569) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :344:1
func A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Ctor_O_I_O(c__b__711000332 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000332 = c__b__711000332; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :344:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A) Invoke_O__O(self any) any { { var i__711000331__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000331__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000336__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000331__1)); var nme__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000336__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2533 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2533, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2535 lang.IFn; if linked_2534 == nil { ifn_2535 = lang.IFn_Cast(root_2533) } else { ifn_2535 = nil }; var arg_2536 any = t.F_b__711000332; var arg_2537 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__3, desc__4)).Ref(), nme__3); if linked_2534 == nil { ifn_2535.Invoke_O_O__O(arg_2536, arg_2537) } else { linked_2534.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2533, arg_2536, arg_2537) }; i__711000331__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000331__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A{}; t.Ctor_O_O(p0, p1); return t }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Ctor_O_O(c__recv, c__n any) { t.F_recv = c__recv; t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A) Invoke_O_O__O(self, s__711000346__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(t.F_recv, self, s__711000346__1, t.F_n); var tmp2 *jrt.Class; var fncls__2709 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class; if fncls__2709 == nil { var fncls__2709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class = fncls__2709d; tmp2 = fncls__2709d } else { tmp2 = fncls__2709 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :349:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Ctor_O_O_O_O(c__recv, c__iter__711000345, c__s__711000346, c__n any) { t.F_recv = c__recv; t.F_iter__711000345 = c__iter__711000345; t.F_s__711000346 = c__s__711000346; t.F_n = c__n }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A) Invoke_O__O(self any) any { { var s__711000346__1 any; var t_ any = t.F_s__711000346; t.F_s__711000346 = nil; s__711000346__1 = t_; for { var temp__1927000414__auto____2 any; var root_2624 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2624, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2626 lang.IFn; if linked_2625 == nil { ifn_2626 = lang.IFn_Cast(root_2624) } else { ifn_2626 = nil }; var arg_2627 any = s__711000346__1; if linked_2625 == nil { temp__1927000414__auto____2 = ifn_2626.Invoke_O__O(arg_2627) } else { temp__1927000414__auto____2 = linked_2625.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2624, arg_2627) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000346__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2628 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2628, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2630 lang.IFn; if linked_2629 == nil { ifn_2630 = lang.IFn_Cast(root_2628) } else { ifn_2630 = nil }; var arg_2631 any = s__711000346__3; if linked_2629 == nil { tmp1 = ifn_2630.Invoke_O__O(arg_2631) } else { tmp1 = linked_2629.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2628, arg_2631) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2632 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2632, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2634 lang.IFn; if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any = s__711000346__3; if linked_2633 == nil { c__1927001037__auto____4 = ifn_2634.Invoke_O__O(arg_2635) } else { c__1927001037__auto____4 = linked_2633.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2632, arg_2635) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000348__6 any; var root_2636 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2636, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2638 lang.IFn; if linked_2637 == nil { ifn_2638 = lang.IFn_Cast(root_2636) } else { ifn_2638 = nil }; var arg_2639 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2637 == nil { b__711000348__6 = ifn_2638.Invoke_O__O(arg_2639) } else { b__711000348__6 = linked_2637.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2636, arg_2639) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(t.F_recv, t.F_n, b__711000348__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2659 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class; if fncls__2659 == nil { var fncls__2659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class = fncls__2659d; tmp3 = fncls__2659d } else { tmp3 = fncls__2659 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2660 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2660, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2662 lang.IFn; if linked_2661 == nil { ifn_2662 = lang.IFn_Cast(root_2660) } else { ifn_2662 = nil }; var arg_2663 any; var root_2665 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any = b__711000348__6; if linked_2666 == nil { arg_2663 = ifn_2667.Invoke_O__O(arg_2668) } else { arg_2663 = linked_2666.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2665, arg_2668) }; var arg_2664 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp5 any; var root_2669 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2669, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2671 lang.IFn; if linked_2670 == nil { ifn_2671 = lang.IFn_Cast(root_2669) } else { ifn_2671 = nil }; var arg_2672 any = s__711000346__3; if linked_2670 == nil { tmp5 = ifn_2671.Invoke_O__O(arg_2672) } else { tmp5 = linked_2670.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2669, arg_2672) }; arg_2664 = tmp4.Invoke_O__O(tmp5); if linked_2661 == nil { return ifn_2662.Invoke_O_O__O(arg_2663, arg_2664) } else { return linked_2661.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2660, arg_2663, arg_2664) } } else { var root_2673 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2673, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2675 lang.IFn; if linked_2674 == nil { ifn_2675 = lang.IFn_Cast(root_2673) } else { ifn_2675 = nil }; var arg_2676 any; var root_2678 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = b__711000348__6; if linked_2679 == nil { arg_2676 = ifn_2680.Invoke_O__O(arg_2681) } else { arg_2676 = linked_2679.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2678, arg_2681) }; var arg_2677 any; if linked_2674 == nil { return ifn_2675.Invoke_O_O__O(arg_2676, arg_2677) } else { return linked_2674.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2673, arg_2676, arg_2677) } } } else { var i__4 any; var root_2682 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2682, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2684 lang.IFn; if linked_2683 == nil { ifn_2684 = lang.IFn_Cast(root_2682) } else { ifn_2684 = nil }; var arg_2685 any = s__711000346__3; if linked_2683 == nil { i__4 = ifn_2684.Invoke_O__O(arg_2685) } else { i__4 = linked_2683.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2682, arg_2685) }; var k__5 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__4)); var root_2686 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2686, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2688 lang.IFn; if linked_2687 == nil { ifn_2688 = lang.IFn_Cast(root_2686) } else { ifn_2688 = nil }; var arg_2689 any; var root_2691 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2693 lang.IFn

	if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any = t.F_recv; var arg_2695 any = i__4; var arg_2696 any = k__5; var arg_2697 any; var tmp6 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(k__5, t.F_n); var tmp7 *jrt.Class; var fncls__2704 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class; if fncls__2704 == nil { var fncls__2704d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class = fncls__2704d; tmp7 = fncls__2704d } else { tmp7 = fncls__2704 }; arg_2697 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); if linked_2692 == nil { arg_2689 = ifn_2693.Invoke_O_O_O_O__O(arg_2694, arg_2695, arg_2696, arg_2697) } else { arg_2689 = linked_2692.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2691, arg_2694, arg_2695, arg_2696, arg_2697) }
//line :349:1
	var arg_2690 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__711000345); var tmp9 any; var root_2705 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2705, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2707 lang.IFn; if linked_2706 == nil { ifn_2707 = lang.IFn_Cast(root_2705) } else { ifn_2707 = nil }; var arg_2708 any = s__711000346__3; if linked_2706 == nil { tmp9 = ifn_2707.Invoke_O__O(arg_2708) } else { tmp9 = linked_2706.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2705, arg_2708) }; arg_2690 = tmp8.Invoke_O__O(tmp9); if linked_2687 == nil { return ifn_2688.Invoke_O_O__O(arg_2689, arg_2690) } else { return linked_2687.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2686, arg_2689, arg_2690) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :349:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Ctor_O_O_O_I_O(c__recv, c__n, c__b__711000348 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_n = c__n; t.F_b__711000348 = c__b__711000348; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :349:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A) Invoke_O__O(self any) any { { var i__711000347__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000347__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000347__1)); var k__3 any = lang.RT_Nth_O_I__O_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O(), lang.RT_IntCast_O__I_NoInit(i__2)); var root_2640 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2640, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2642 lang.IFn; if linked_2641 == nil { ifn_2642 = lang.IFn_Cast(root_2640) } else { ifn_2642 = nil }; var arg_2643 any = t.F_b__711000348; var arg_2644 any; var root_2645 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_2646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2645, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2647 lang.IFn

	if linked_2646 == nil { ifn_2647 = lang.IFn_Cast(root_2645) } else { ifn_2647 = nil }; var arg_2648 any = t.F_recv; var arg_2649 any = i__2; var arg_2650 any = k__3; var arg_2651 any; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(k__3, t.F_n); var tmp3 *jrt.Class; var fncls__2658 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class; if fncls__2658 == nil { var fncls__2658d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class = fncls__2658d; tmp3 = fncls__2658d } else { tmp3 = fncls__2658 }; arg_2651 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_2646 == nil { arg_2644 = ifn_2647.Invoke_O_O_O_O__O(arg_2648, arg_2649, arg_2650, arg_2651) } else { arg_2644 = linked_2646.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2645, arg_2648, arg_2649, arg_2650, arg_2651) }
//line :349:1
	if linked_2641 == nil { ifn_2642.Invoke_O_O__O(arg_2643, arg_2644) } else { linked_2641.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2640, arg_2643, arg_2644) }; i__711000347__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000347__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2652 any = A_arbace_j2g_dyn_A_const_274.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any = t.F_n; var arg_2656 any = t.F_k; var arg_2657 any = pn__1; if linked_2653 == nil { return ifn_2654.Invoke_O_O_O__O(arg_2655, arg_2656, arg_2657) } else { return linked_2653.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2652, arg_2655, arg_2656, arg_2657) } }
//line :351:1
func A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A{}; t.Ctor_O_O(p0, p1); return t }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :351:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2698 any = A_arbace_j2g_dyn_A_const_274.GetRawRoot__O(); var linked_2699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2698, A_arbace_j2g_dyn_object_fallback_A_fn_class); var ifn_2700 lang.IFn; if linked_2699 == nil { ifn_2700 = lang.IFn_Cast(root_2698) } else { ifn_2700 = nil }; var arg_2701 any = t.F_n; var arg_2702 any = t.F_k; var arg_2703 any = pn__1; if linked_2699 == nil { return ifn_2700.Invoke_O_O_O__O(arg_2701, arg_2702, arg_2703) } else { return linked_2699.(*A_arbace_j2g_dyn_object_fallback_A).Invoke_O_O_O_O__O(root_2698, arg_2701, arg_2702, arg_2703) } }
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Ctor_O_O(c__recv, c__clash any) { t.F_recv = c__recv; t.F_clash = c__clash }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A) Invoke_O_O__O(self, s__711000360__1 any) any { var tmp1 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(s__711000360__1, t.F_recv, t.F_clash, self); var tmp2 *jrt.Class; var fncls__2802 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class; if fncls__2802 == nil { var fncls__2802d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class = fncls__2802d; tmp2 = fncls__2802d } else { tmp2 = fncls__2802 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :352:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Ctor_O_O_O_O(c__s__711000360, c__recv, c__clash, c__iter__711000359 any) { t.F_s__711000360 = c__s__711000360; t.F_recv = c__recv; t.F_clash = c__clash; t.F_iter__711000359 = c__iter__711000359 }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A) Invoke_O__O(self any) any { { var s__711000360__1 any; var t_ any = t.F_s__711000360; t.F_s__711000360 = nil; s__711000360__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2715 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2715, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2717 lang.IFn; if linked_2716 == nil { ifn_2717 = lang.IFn_Cast(root_2715) } else { ifn_2717 = nil }; var arg_2718 any = s__711000360__1; if linked_2716 == nil { temp__1927000414__auto____2 = ifn_2717.Invoke_O__O(arg_2718) } else { temp__1927000414__auto____2 = linked_2716.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2715, arg_2718) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000360__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2719 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2719, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2721 lang.IFn; if linked_2720 == nil { ifn_2721 = lang.IFn_Cast(root_2719) } else { ifn_2721 = nil }; var arg_2722 any = s__711000360__3; if linked_2720 == nil { tmp1 = ifn_2721.Invoke_O__O(arg_2722) } else { tmp1 = linked_2720.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2719, arg_2722) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2723 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2723, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2725 lang.IFn; if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; var arg_2726 any = s__711000360__3; if linked_2724 == nil { c__1927001037__auto____4 = ifn_2725.Invoke_O__O(arg_2726) } else { c__1927001037__auto____4 = linked_2724.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2723, arg_2726) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000362__6 any; var root_2727 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2727, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2729 lang.IFn; if linked_2728 == nil { ifn_2729 = lang.IFn_Cast(root_2727) } else { ifn_2729 = nil }; var arg_2730 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2728 == nil { b__711000362__6 = ifn_2729.Invoke_O__O(arg_2730) } else { b__711000362__6 = linked_2728.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2727, arg_2730) }; var tmp2 any = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(t.F_recv, t.F_clash, b__711000362__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2749 *jrt.Class = A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class; if fncls__2749 == nil { var fncls__2749d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class = fncls__2749d; tmp3 = fncls__2749d } else { tmp3 = fncls__2749 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2750 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2750, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2752 lang.IFn; if linked_2751 == nil { ifn_2752 = lang.IFn_Cast(root_2750) } else { ifn_2752 = nil }; var arg_2753 any; var root_2755 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2755, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2757 lang.IFn; if linked_2756 == nil { ifn_2757 = lang.IFn_Cast(root_2755) } else { ifn_2757 = nil }; var arg_2758 any = b__711000362__6; if linked_2756 == nil { arg_2753 = ifn_2757.Invoke_O__O(arg_2758) } else { arg_2753 = linked_2756.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2755, arg_2758) }; var arg_2754 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp5 any; var root_2759 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_2760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2759, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2761 lang.IFn; if linked_2760 == nil { ifn_2761 = lang.IFn_Cast(root_2759) } else { ifn_2761 = nil }; var arg_2762 any = s__711000360__3; if linked_2760 == nil { tmp5 = ifn_2761.Invoke_O__O(arg_2762) } else { tmp5 = linked_2760.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2759, arg_2762) }; arg_2754 = tmp4.Invoke_O__O(tmp5); if linked_2751 == nil { return ifn_2752.Invoke_O_O__O(arg_2753, arg_2754) } else { return linked_2751.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2750, arg_2753, arg_2754) } } else { var root_2763 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2763, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2765 lang.IFn; if linked_2764 == nil { ifn_2765 = lang.IFn_Cast(root_2763) } else { ifn_2765 = nil }; var arg_2766 any; var root_2768 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2768, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2770 lang.IFn; if linked_2769 == nil { ifn_2770 = lang.IFn_Cast(root_2768) } else { ifn_2770 = nil }; var arg_2771 any = b__711000362__6; if linked_2769 == nil { arg_2766 = ifn_2770.Invoke_O__O(arg_2771) } else { arg_2766 = linked_2769.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2768, arg_2771) }; var arg_2767 any; if linked_2764 == nil { return ifn_2765.Invoke_O_O__O(arg_2766, arg_2767) } else { return linked_2764.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2763, arg_2766, arg_2767) } } } else { var j__4 any; var root_2772 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_2773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2772, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2774 lang.IFn; if linked_2773 == nil { ifn_2774 = lang.IFn_Cast(root_2772) } else { ifn_2774 = nil }; var arg_2775 any = s__711000360__3; if linked_2773 == nil { j__4 = ifn_2774.Invoke_O__O(arg_2775) } else { j__4 = linked_2773.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2772, arg_2775) }; var mk__5 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp7 any; var root_2776 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2776, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2778 lang.IFn; if linked_2777 == nil { ifn_2778 = lang.IFn_Cast(root_2776) } else { ifn_2778 = nil }; var arg_2779 any = j__4; if linked_2777 == nil { tmp7 = ifn_2778.Invoke_O__O(arg_2779) } else { tmp7 = linked_2777.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2776, arg_2779) }; mk__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__5)) { var root_2780 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_2781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2780, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2782 lang.IFn; if linked_2781 == nil { ifn_2782 = lang.IFn_Cast(root_2780) } else { ifn_2782 = nil }; var arg_2783 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_dyn_A_const_275; var tmp10 any; var root_2785 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2785, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2787 lang.IFn
														if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any = mk__5; if linked_2786 == nil { tmp10 = ifn_2787.Invoke_O__O(arg_2788) } else { tmp10 = linked_2786.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2785, arg_2788) }; var tmp11 any = tmp10; var tmp12 any; var root_2789 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2789, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2791 lang.IFn; if linked_2790 == nil { ifn_2791 = lang.IFn_Cast(root_2789) } else { ifn_2791 = nil }; var arg_2792 any = A_arbace_j2g_dyn_A_const_276; var arg_2793 any = t.F_recv; if linked_2790 == nil { tmp12 = ifn_2791.Invoke_O_O__O(arg_2792, arg_2793) } else { tmp12 = linked_2790.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2789, arg_2792, arg_2793) }; arg_2783 = tmp8.Invoke_O_O_O__O(tmp9, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12))
//line :352:1
	var arg_2784 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000359); var tmp14 any; var root_2794 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2794, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2796 lang.IFn; if linked_2795 == nil { ifn_2796 = lang.IFn_Cast(root_2794) } else { ifn_2796 = nil }; var arg_2797 any = s__711000360__3; if linked_2795 == nil { tmp14 = ifn_2796.Invoke_O__O(arg_2797) } else { tmp14 = linked_2795.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2794, arg_2797) }; arg_2784 = tmp13.Invoke_O__O(tmp14); if linked_2781 == nil { return ifn_2782.Invoke_O_O__O(arg_2783, arg_2784) } else { return linked_2781.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2780, arg_2783, arg_2784) } } else { var tmp15 any; var root_2798 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_2799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2798, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2800 lang.IFn; if linked_2799 == nil { ifn_2800 = lang.IFn_Cast(root_2798) } else { ifn_2800 = nil }; var arg_2801 any = s__711000360__3; if linked_2799 == nil { tmp15 = ifn_2800.Invoke_O__O(arg_2801) } else { tmp15 = linked_2799.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2798, arg_2801) }; s__711000360__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :352:1
func A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Ctor_O_O_O_I_O(c__recv, c__clash, c__b__711000362 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_recv = c__recv; t.F_clash = c__clash; t.F_b__711000362 = c__b__711000362; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :352:1
func (t *A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A) Invoke_O__O(self any) any { { var i__711000361__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000361__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000361__1)); var mk__3 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp3 any; var root_2731 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_2732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2731, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_2733 lang.IFn; if linked_2732 == nil { ifn_2733 = lang.IFn_Cast(root_2731) } else { ifn_2733 = nil }; var arg_2734 any = j__2; if linked_2732 == nil { tmp3 = ifn_2733.Invoke_O__O(arg_2734) } else { tmp3 = linked_2732.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_2731, arg_2734) }; mk__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if jrt.J2g_Truth(lang.IFn_Cast(t.F_clash).Invoke_O__O(mk__3)) { var root_2735 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2735, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2737 lang.IFn; if linked_2736 == nil { ifn_2737 = lang.IFn_Cast(root_2735) } else { ifn_2737 = nil }; var arg_2738 any = t.F_b__711000362; var arg_2739 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_dyn_A_const_275; var tmp6 any; var root_2740 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2740, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2742 lang.IFn
															if linked_2741 == nil { ifn_2742 = lang.IFn_Cast(root_2740) } else { ifn_2742 = nil }; var arg_2743 any = mk__3; if linked_2741 == nil { tmp6 = ifn_2742.Invoke_O__O(arg_2743) } else { tmp6 = linked_2741.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2740, arg_2743) }; var tmp7 any = tmp6; var tmp8 any; var root_2744 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2744, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2746 lang.IFn; if linked_2745 == nil { ifn_2746 = lang.IFn_Cast(root_2744) } else { ifn_2746 = nil }; var arg_2747 any = A_arbace_j2g_dyn_A_const_276; var arg_2748 any = t.F_recv; if linked_2745 == nil { tmp8 = ifn_2746.Invoke_O_O__O(arg_2747, arg_2748) } else { tmp8 = linked_2745.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2744, arg_2747, arg_2748) }; arg_2739 = tmp4.Invoke_O_O_O__O(tmp5, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8))
//line :352:1
	if linked_2736 == nil { ifn_2737.Invoke_O_O__O(arg_2738, arg_2739) } else { linked_2736.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2735, arg_2738, arg_2739) }; i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } else { i__711000361__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000361__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_dyn_sub_forms_fn__711000370_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Ctor_O_O_O_O_O(c__own, c__recv, c__clash, c__ifaces, c__n any) { t.F_own = c__own; t.F_recv = c__recv; t.F_clash = c__clash; t.F_ifaces = c__ifaces; t.F_n = c__n }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) Invoke_O_O_O__O(self, i__1, p__711000369__2 any) any { if jrt.Long_InstanceOf(i__1) { return t.InvokeSpec_O_J_O_O__O(self, jrt.NN(jrt.Long_Cast(i__1)).LongValue__J(), i__1, p__711000369__2) } else { var vec__711000371__3 any = p__711000369__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000371__3; var tmp1 any; var and__1927000168__auto____7 bool; var na_2809 any = i__1; var na_2810 int64 = int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()))
														if jrt.Long_InstanceOf(na_2809) { var n0_2811 int64 = jrt.NN(jrt.Long_Cast(na_2809)).LongValue__J(); var n1_2812 int64 = na_2810; and__1927000168__auto____7 = n0_2811 >= n1_2812 } else { and__1927000168__auto____7 = lang.Numbers_Gte_O_J__Z_NoInit(na_2809, na_2810) }; if and__1927000168__auto____7 { var or__1927000174__auto____8 any = lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)
															if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_clash); var tmp3 any; var root_2837 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2837, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2839 lang.IFn; if linked_2838 == nil { ifn_2839 = lang.IFn_Cast(root_2837) } else { ifn_2839 = nil }; var arg_2840 any = nme__4; var arg_2841 any = desc__5; if linked_2838 == nil { tmp3 = ifn_2839.Invoke_O_O__O(arg_2840, arg_2841) } else { tmp3 = linked_2838.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2837, arg_2840, arg_2841) }; tmp1 = tmp2.Invoke_O__O(tmp3) } } else {
//line :355:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				var root_2814 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_2815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2814, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2816 lang.IFn; if linked_2815 == nil { ifn_2816 = lang.IFn_Cast(root_2814) } else { ifn_2816 = nil }; var arg_2817 any = t.F_recv; var arg_2818 any = i__1; var arg_2819 any = k__6; var arg_2820 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)) {
					var tmp4 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(k__6, t.F_n); var tmp5 *jrt.Class; var fncls__2828 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class; if fncls__2828 == nil { var fncls__2828d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class = fncls__2828d; tmp5 = fncls__2828d } else { tmp5 = fncls__2828 }; arg_2820 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) } else {
						var tmp6 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(k__6, t.F_ifaces); var tmp7 *jrt.Class; var fncls__2836 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class; if fncls__2836 == nil { var fncls__2836d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class = fncls__2836d; tmp7 = fncls__2836d } else { tmp7 = fncls__2836 }; arg_2820 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) }
//line :357:1
				if linked_2815 == nil { return ifn_2816.Invoke_O_O_O_O__O(arg_2817, arg_2818, arg_2819, arg_2820) } else { return linked_2815.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2814, arg_2817, arg_2818, arg_2819, arg_2820) } } else {
//line :355:1
					return nil } } }
//line :354:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_A) InvokeSpec_O_J_O_O__O(self any, i__1_l int64, i__1_b, p__711000369__2 any) any { var vec__711000371__3 any = p__711000369__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000371__3, lang.RT_IntCast_J__I_NoInit(1), nil); var k__6 any = vec__711000371__3; var tmp1 any; var and__1927000168__auto____7 bool; var na_2842 int64 = int64(lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O())); var n0_2843 int64 = i__1_l; var n1_2844 int64 = na_2842; and__1927000168__auto____7 =
																	n0_2843 >= n1_2844; if and__1927000168__auto____7 { var or__1927000174__auto____8 any = lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)
																		if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var tmp2 lang.IFn = lang.IFn_Cast(t.F_clash); var tmp3 any; var root_2855 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2855, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2857 lang.IFn; if linked_2856 == nil { ifn_2857 = lang.IFn_Cast(root_2855) } else { ifn_2857 = nil }; var arg_2858 any = nme__4; var arg_2859 any = desc__5; if linked_2856 == nil { tmp3 = ifn_2857.Invoke_O_O__O(arg_2858, arg_2859) } else { tmp3 = linked_2856.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2855, arg_2858, arg_2859) }; tmp1 = tmp2.Invoke_O__O(tmp3) } } else {
//line :355:1
			tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp1) {

				var root_2846 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_2847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2846, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_2848 lang.IFn; if linked_2847 == nil { ifn_2848 = lang.IFn_Cast(root_2846) } else { ifn_2848 = nil }; var arg_2849 any = t.F_recv; var arg_2850 any; if i__1_b == nil { i__1_b = jrt.Long_ValueOf_J__Long_NoInit(i__1_l).Ref(); arg_2850 = i__1_b } else { arg_2850 = i__1_b }; var arg_2851 any = k__6; var arg_2852 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_own).Invoke_O__O(k__6)) {
					var tmp4 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(k__6, t.F_n); var tmp5 *jrt.Class; var fncls__2853 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class; if fncls__2853 == nil { var fncls__2853d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class = fncls__2853d; tmp5 = fncls__2853d } else { tmp5 = fncls__2853 }; arg_2852 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) } else {
						var tmp6 any = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(k__6, t.F_ifaces); var tmp7 *jrt.Class; var fncls__2854 *jrt.Class = A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class; if fncls__2854 == nil { var fncls__2854d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class = fncls__2854d; tmp7 = fncls__2854d } else { tmp7 = fncls__2854 }; arg_2852 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) }
//line :357:1
				if linked_2847 == nil { return ifn_2848.Invoke_O_O_O_O__O(arg_2849, arg_2850, arg_2851, arg_2852) } else { return linked_2847.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O_O__O(root_2846, arg_2849, arg_2850, arg_2851, arg_2852) } } else {
//line :355:1
					return nil } }


func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A{}; t.Ctor_O_O(p0, p1); return t }
//line :358:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Ctor_O_O(c__k, c__n any) { t.F_k = c__k; t.F_n = c__n }
//line :358:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2821 any = A_arbace_j2g_dyn_A_const_278.GetRawRoot__O(); var linked_2822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2821, A_arbace_j2g_dyn_class_fallback_A_fn_class); var ifn_2823 lang.IFn; if linked_2822 == nil { ifn_2823 = lang.IFn_Cast(root_2821) } else { ifn_2823 = nil }; var arg_2824 any = t.F_n; var arg_2825 any = t.F_k; var arg_2826 any = pn__1; var arg_2827 any = r__2; if linked_2822 == nil { return ifn_2823.Invoke_O_O_O_O__O(arg_2824, arg_2825, arg_2826, arg_2827) } else { return linked_2822.(*A_arbace_j2g_dyn_class_fallback_A).Invoke_O_O_O_O_O__O(root_2821, arg_2824, arg_2825, arg_2826, arg_2827) } }
func A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A{}; t.Ctor_O_O(p0, p1); return t }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Ctor_O_O(c__k, c__ifaces any) { t.F_k = c__k; t.F_ifaces = c__ifaces }
//line :359:1
func (t *A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A) Invoke_O_O_O__O(self, pn__1, r__2 any) any { var root_2829 any = A_arbace_j2g_dyn_A_const_132.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2829, A_arbace_j2g_dyn_iface_fallback_A_fn_class); var ifn_2831 lang.IFn; if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any = t.F_ifaces; var arg_2833 any = t.F_k; var arg_2834 any = pn__1; var arg_2835 any = r__2; if linked_2830 == nil { return ifn_2831.Invoke_O_O_O_O__O(arg_2832, arg_2833, arg_2834, arg_2835) } else { return linked_2830.(*A_arbace_j2g_dyn_iface_fallback_A).Invoke_O_O_O_O_O__O(root_2829, arg_2832, arg_2833, arg_2834, arg_2835) } }

















func A_arbace_j2g_dyn_fn_field_native_A_New() *A_arbace_j2g_dyn_fn_field_native_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_fn_field_native_A{}; t.Ctor(); return t }
//line :377:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Ctor() {}
//line :377:1
func (t *A_arbace_j2g_dyn_fn_field_native_A) Invoke_O__O(self any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_dyn_A_const_281; var tmp3 any; var root_2869 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_2870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2869, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2871 lang.IFn; if linked_2870 == nil { ifn_2871 = lang.IFn_Cast(root_2869) } else { ifn_2871 = nil }; var arg_2872 any; var root_2873 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_2874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2873, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_2875 lang.IFn; if linked_2874 == nil { ifn_2875 = lang.IFn_Cast(root_2873) } else { ifn_2875 = nil }; var arg_2876 any = Lit_45; var arg_2877 any = Lit_46; if linked_2874 == nil { arg_2872 = ifn_2875.Invoke_O_O__O(arg_2876, arg_2877) } else { arg_2872 = linked_2874.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_2873, arg_2876, arg_2877) }; if linked_2870 == nil { tmp3 = ifn_2871.Invoke_O__O(arg_2872) } else { tmp3 = linked_2870.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2869, arg_2872) }; var tmp4 any = tmp3; var tmp5 any; var root_2878 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2878, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2880 lang.IFn
	if linked_2879 == nil { ifn_2880 = lang.IFn_Cast(root_2878) } else { ifn_2880 = nil }; var arg_2881 any = A_arbace_j2g_dyn_A_const_284; var arg_2882 any = A_arbace_j2g_dyn_A_const_285; if linked_2879 == nil { tmp5 = ifn_2880.Invoke_O_O__O(arg_2881, arg_2882) } else { tmp5 = linked_2879.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2878, arg_2881, arg_2882) }
//line :382:1
	var tmp6 any = tmp5; var tmp7 any; var root_2883 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2883, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2885 lang.IFn
	if linked_2884 == nil { ifn_2885 = lang.IFn_Cast(root_2883) } else { ifn_2885 = nil }; var arg_2886 any = A_arbace_j2g_dyn_A_const_286; var arg_2887 any = A_arbace_j2g_dyn_A_const_287; if linked_2884 == nil { tmp7 = ifn_2885.Invoke_O_O__O(arg_2886, arg_2887) } else { tmp7 = linked_2884.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2883, arg_2886, arg_2887) }
//line :382:1
	var tmp8 any = tmp7; var tmp9 any; var root_2888 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2888, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2890 lang.IFn
	if linked_2889 == nil { ifn_2890 = lang.IFn_Cast(root_2888) } else { ifn_2890 = nil }; var arg_2891 any = A_arbace_j2g_dyn_A_const_288; var arg_2892 any = A_arbace_j2g_dyn_A_const_289; if linked_2889 == nil { tmp9 = ifn_2890.Invoke_O_O__O(arg_2891, arg_2892) } else { tmp9 = linked_2889.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2888, arg_2891, arg_2892) }
//line :382:1
	var tmp10 any = tmp9; var tmp11 any; var root_2893 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2893, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2895 lang.IFn
	if linked_2894 == nil { ifn_2895 = lang.IFn_Cast(root_2893) } else { ifn_2895 = nil }; var arg_2896 any = A_arbace_j2g_dyn_A_const_290; var arg_2897 any = A_arbace_j2g_dyn_A_const_291; if linked_2894 == nil { tmp11 = ifn_2895.Invoke_O_O__O(arg_2896, arg_2897) } else { tmp11 = linked_2894.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2893, arg_2896, arg_2897) }
//line :382:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp10, tmp11), A_arbace_j2g_dyn_A_const_283)
}








func A_arbace_j2g_dyn_forms_A_New() *A_arbace_j2g_dyn_forms_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_j2g_dyn_forms_A) Ctor() {}
//line :392:1
func (t *A_arbace_j2g_dyn_forms_A) Invoke_O_O__O(self, T__0_ any) any { var ifaces__2 any; var root_2898 any = A_arbace_j2g_dyn_A_const_292.GetRawRoot__O(); var linked_2899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2898, A_arbace_j2g_dyn_interfaces_A_fn_class); var ifn_2900 lang.IFn; if


	linked_2899 == nil { ifn_2900 = lang.IFn_Cast(root_2898) } else { ifn_2900 = nil }; var arg_2901 any = T__0_; if linked_2899 == nil { ifaces__2 = ifn_2900.Invoke_O__O(arg_2901) } else { ifaces__2 = linked_2899.(*A_arbace_j2g_dyn_interfaces_A).Invoke_O_O__O(root_2898, arg_2901) }; var ks__3 any; var root_2902 any = /*line :392:1*/A_arbace_j2g_dyn_A_const_293.GetRawRoot__O(); var linked_2903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2902, A_arbace_j2g_dyn_slot_keys_A_fn_class); var ifn_2904 lang.IFn; if



	linked_2903 == nil { ifn_2904 = lang.IFn_Cast(root_2902) } else { ifn_2904 = nil }; var arg_2905 any = ifaces__2; if linked_2903 == nil { ks__3 = ifn_2904.Invoke_O__O(arg_2905) } else { ks__3 = linked_2903.(*A_arbace_j2g_dyn_slot_keys_A).Invoke_O_O__O(root_2902, arg_2905) }; var n__4 int32 = /*line :392:1*/lang.RT_Count_O__I_NoInit(ks__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_42.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_314; var tmp4 any = tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_47, nil, Lit_48, nil, Lit_49), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ifaces__2)).Ref(), nil, jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref(), nil)).Ref()); var tmp5 any = A_arbace_j2g_dyn_A_const_294; var tmp6 any = A_arbace_j2g_dyn_A_const_295; var tmp7 any = A_arbace_j2g_dyn_A_const_296; var tmp8 any = A_arbace_j2g_dyn_A_const_297; var tmp9 any = A_arbace_j2g_dyn_A_const_298; var tmp10 any = A_arbace_j2g_dyn_A_const_299; var tmp11 any = A_arbace_j2g_dyn_A_const_300; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_dyn_A_const_315; var tmp14 any; var root_2914 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2914, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2916 lang.IFn; if



































	linked_2915 == nil { ifn_2916 = lang.IFn_Cast(root_2914) } else { ifn_2916 = nil }; var arg_2917 any = A_arbace_j2g_dyn_A_const_316; var arg_2918 any = A_arbace_j2g_dyn_A_const_317; if linked_2915 == nil { tmp14 = ifn_2916.Invoke_O_O__O(arg_2917, arg_2918) } else { tmp14 = linked_2915.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2914, arg_2917, arg_2918) }; var tmp15 any = tmp14; var tmp16 any; var root_2919 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2919, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2921 lang.IFn; if






























	linked_2920 == nil { ifn_2921 = lang.IFn_Cast(root_2919) } else { ifn_2921 = nil }; var arg_2922 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2923 any = A_arbace_j2g_dyn_A_const_318; var arg_2924 any = A_arbace_j2g_dyn_A_const_319; var arg_2925 any; var root_2926 any = A_arbace_j2g_dyn_A_const_227.GetRawRoot__O(); var linked_2927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2926, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2928 lang.IFn; if linked_2927 == nil { ifn_2928 = lang.IFn_Cast(root_2926) } else { ifn_2928 = nil }; var arg_2929 any; var tmp17 any = A_arbace_j2g_dyn_forms_fn__711000383_A_New(); var tmp18 *jrt.Class; var fncls__2931 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000383_A_fn_class; if fncls__2931 == nil { var fncls__2931d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_j2g_dyn_forms_fn__711000383_A_fn_class = fncls__2931d; tmp18 = fncls__2931d } else { tmp18 = fncls__2931 }; arg_2929 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_2930 any = ks__3; if linked_2927 == nil { arg_2925 = ifn_2928.Invoke_O_O__O(arg_2929, arg_2930) } else { arg_2925 = linked_2927.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2926, arg_2929, arg_2930) }; if linked_2920 == nil { tmp16 = ifn_2921.Invoke_O_O_O_O__O(arg_2922, arg_2923, arg_2924, arg_2925) } else { tmp16 = linked_2920.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2919, arg_2922, arg_2923, arg_2924, arg_2925) }; var tmp19 any = /*line :398:1*/tmp12.Invoke_O_O_O__O(tmp13, tmp15, tmp16); var tmp20 any = A_arbace_j2g_dyn_A_const_301; var tmp21 any = A_arbace_j2g_dyn_A_const_302; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_dyn_A_const_320; var tmp24 any = A_arbace_j2g_dyn_A_const_321; var tmp25 any; var root_2932 any = A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_2933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2932, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2934 lang.IFn; if











































	linked_2933 == nil { ifn_2934 = lang.IFn_Cast(root_2932) } else { ifn_2934 = nil }; var arg_2935 any; var tmp26 any; var root_2937 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2937, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2939 lang.IFn; if linked_2938 == nil { ifn_2939 = lang.IFn_Cast(root_2937) } else { ifn_2939 = nil }; var arg_2940 any = A_arbace_j2g_dyn_A_const_322; var arg_2941 any = A_arbace_j2g_dyn_A_const_323; if linked_2938 == nil { tmp26 = ifn_2939.Invoke_O_O__O(arg_2940, arg_2941) } else { tmp26 = linked_2938.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2937, arg_2940, arg_2941) }; var tmp27 any = tmp26; var tmp28 any; var root_2942 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_2943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2942, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_2944 lang.IFn; if linked_2943 == nil { ifn_2944 = lang.IFn_Cast(root_2942) } else { ifn_2944 = nil }; var arg_2945 any = A_arbace_j2g_dyn_A_const_324; var arg_2946 any = A_arbace_j2g_dyn_A_const_325; if linked_2943 == nil { tmp28 = ifn_2944.Invoke_O_O__O(arg_2945, arg_2946) } else { tmp28 = linked_2943.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_2942, arg_2945, arg_2946) }; arg_2935 = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28); var arg_2936 any = A_arbace_j2g_dyn_A_const_326; if linked_2933 == nil { tmp25 = ifn_2934.Invoke_O_O__O(arg_2935, arg_2936) } else { tmp25 = linked_2933.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2932, arg_2935, arg_2936) }; var tmp29 any = tmp25; var tmp30 any; var root_2947 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_2948 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2947, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2949 lang.IFn; if












































	linked_2948 == nil { ifn_2949 = lang.IFn_Cast(root_2947) } else { ifn_2949 = nil }; var arg_2950 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_2951 any = A_arbace_j2g_dyn_A_const_327; var arg_2952 any = A_arbace_j2g_dyn_A_const_328; var arg_2953 any; var root_2954 any = A_arbace_j2g_dyn_A_const_42.GetRawRoot__O(); var linked_2955 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2954, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2956 lang.IFn; if
	linked_2955 == nil { ifn_2956 = lang.IFn_Cast(root_2954) } else { ifn_2956 = nil }; var arg_2957 any; var iter__1927001039__auto____5 any; var tmp31 any = A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_New(); var tmp32 *jrt.Class; var fncls__3039 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_fn_class; if
	fncls__3039 == nil { var fncls__3039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_fn_class = fncls__3039d; tmp32 = fncls__3039d } else { tmp32 = fncls__3039 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); var tmp33 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp34 any; var root_3040 any = A_arbace_j2g_dyn_A_const_49.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3042 lang.IFn; if linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any = A_arbace_j2g_dyn_A_const_29.GetRawRoot__O(); if linked_3041 == nil { tmp34 = ifn_3042.Invoke_O__O(arg_3043) } else { tmp34 = linked_3041.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_3040, arg_3043) }; arg_2957 = tmp33.Invoke_O__O(tmp34); var arg_2958 any = A_arbace_j2g_dyn_A_const_332; if /*line :444:1*/ linked_2955 == nil { arg_2953 = ifn_2956.Invoke_O_O__O(arg_2957, arg_2958) } else { arg_2953 = linked_2955.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2954, arg_2957, arg_2958) }; if /*line :443:1*/ linked_2948 == nil { tmp30 = ifn_2949.Invoke_O_O_O_O__O(arg_2950, arg_2951, arg_2952, arg_2953) } else { tmp30 = linked_2948.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_2947, arg_2950, arg_2951, arg_2952, arg_2953) }; var tmp35 any = /*line :398:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp19, tmp20, tmp21, tmp22.Invoke_O_O_O_O_O_O__O(tmp23, tmp24, Lit_51, tmp29, tmp30, A_arbace_j2g_dyn_A_const_333), A_arbace_j2g_dyn_A_const_303, A_arbace_j2g_dyn_A_const_304, A_arbace_j2g_dyn_A_const_305, A_arbace_j2g_dyn_A_const_306, A_arbace_j2g_dyn_A_const_307, A_arbace_j2g_dyn_A_const_308, A_arbace_j2g_dyn_A_const_309, A_arbace_j2g_dyn_A_const_310, A_arbace_j2g_dyn_A_const_311, A_arbace_j2g_dyn_A_const_312, A_arbace_j2g_dyn_A_const_313)); var tmp36 any; var iter__1927001039__auto____5_2 any; var tmp37 any = A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_New(); var tmp38 *jrt.Class; var fncls__3128 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_fn_class; if























































































	fncls__3128 == nil { var fncls__3128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_fn_class = fncls__3128d; tmp38 = fncls__3128d } else { tmp38 = fncls__3128 }; iter__1927001039__auto____5_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil); tmp36 = lang.IFn_Cast(iter__1927001039__auto____5_2).Invoke_O__O(ifaces__2); var tmp39 any = tmp36; var tmp40 any; var nobj__5 int32 = /*line :398:1*/lang.RT_Count_O__I_NoInit(A_arbace_j2g_dyn_A_const_59.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_337.GetRawRoot__O()); var tmp42 any; var root_3135 any = A_arbace_j2g_dyn_A_const_338.GetRawRoot__O(); var linked_3136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3135, aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A_fn_class); var ifn_3137 lang.IFn; if


























































































	linked_3136 == nil { ifn_3137 = lang.IFn_Cast(root_3135) } else { ifn_3137 = nil }; if linked_3136 == nil { tmp42 = ifn_3137.Invoke__O() } else { tmp42 = linked_3136.(*aot_arbace_j2g_model.A_arbace_j2g_model_jobs_A).Invoke_O__O(root_3135) }; var tmp43 any = tmp42; var tmp44 any = A_arbace_j2g_dyn_forms_fn__711000414_A_New_O_O(ks__3, ifaces__2); var tmp45 *jrt.Class; var fncls__3144 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000414_A_fn_class; if fncls__3144 == nil { var fncls__3144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_j2g_dyn_forms_fn__711000414_A_fn_class = fncls__3144d; tmp45 = fncls__3144d } else { tmp45 = fncls__3144 }; var tmp46 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil); var tmp47 any; var root_3145 any = A_arbace_j2g_dyn_A_const_133.GetRawRoot__O(); var linked_3146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3145, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_3147 lang.IFn; if linked_3146 == nil { ifn_3147 = lang.IFn_Cast(root_3145) } else { ifn_3147 = nil }; var arg_3148 any = jrt.Integer_ValueOf_I__Integer_NoInit(nobj__5).Ref(); var arg_3149 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ks__3)).Ref(); if linked_3146 == nil { tmp47 = ifn_3147.Invoke_O_O__O(arg_3148, arg_3149) } else { tmp47 = linked_3146.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_3145, arg_3148, arg_3149) }; tmp40 = tmp41.Invoke_O_O_O__O(tmp43, tmp46, tmp47); var tmp48 any = tmp40; var tmp49 lang.IFn = /*line :398:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp50 any = A_arbace_j2g_dyn_A_const_348; var tmp51 any; var root_3153 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3153, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3155 lang.IFn; if




























































































	linked_3154 == nil { ifn_3155 = lang.IFn_Cast(root_3153) } else { ifn_3155 = nil }; var arg_3156 any; var root_3157 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3157, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3159 lang.IFn; if linked_3158 == nil { ifn_3159 = lang.IFn_Cast(root_3157) } else { ifn_3159 = nil }; var arg_3160 any = Lit_55; var arg_3161 any = Lit_56; if linked_3158 == nil { arg_3156 = ifn_3159.Invoke_O_O__O(arg_3160, arg_3161) } else { arg_3156 = linked_3158.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3157, arg_3160, arg_3161) }; if linked_3154 == nil { tmp51 = ifn_3155.Invoke_O__O(arg_3156) } else { tmp51 = linked_3154.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3153, arg_3156) }; var tmp52 any = tmp51; var tmp53 any; var root_3162 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3162, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3164 lang.IFn; if





























































































	linked_3163 == nil { ifn_3164 = lang.IFn_Cast(root_3162) } else { ifn_3164 = nil }; var arg_3165 any; var tmp54 any; var root_3167 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3167, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3169 lang.IFn; if linked_3168 == nil { ifn_3169 = lang.IFn_Cast(root_3167) } else { ifn_3169 = nil }; var arg_3170 any = A_arbace_j2g_dyn_A_const_349; var arg_3171 any = A_arbace_j2g_dyn_A_const_350; if linked_3168 == nil { tmp54 = ifn_3169.Invoke_O_O__O(arg_3170, arg_3171) } else { tmp54 = linked_3168.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3167, arg_3170, arg_3171) }; var tmp55 any = tmp54; var tmp56 any; var root_3172 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3172, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3174 lang.IFn; if linked_3173 == nil { ifn_3174 = lang.IFn_Cast(root_3172) } else { ifn_3174 = nil }; var arg_3175 any = A_arbace_j2g_dyn_A_const_351; var arg_3176 any = A_arbace_j2g_dyn_A_const_352; if linked_3173 == nil { tmp56 = ifn_3174.Invoke_O_O__O(arg_3175, arg_3176) } else { tmp56 = linked_3173.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3172, arg_3175, arg_3176) }; var tmp57 any = tmp56; var tmp58 any; var root_3177 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3177, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3179 lang.IFn; if linked_3178 == nil { ifn_3179 = lang.IFn_Cast(root_3177) } else { ifn_3179 = nil }; var arg_3180 any = A_arbace_j2g_dyn_A_const_353; var arg_3181 any = A_arbace_j2g_dyn_A_const_354; if linked_3178 == nil { tmp58 = ifn_3179.Invoke_O_O__O(arg_3180, arg_3181) } else { tmp58 = linked_3178.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3177, arg_3180, arg_3181) }; arg_3165 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp55, tmp57, tmp58); var arg_3166 any = A_arbace_j2g_dyn_A_const_355; if linked_3163 == nil { tmp53 = ifn_3164.Invoke_O_O__O(arg_3165, arg_3166) } else { tmp53 = linked_3163.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3162, arg_3165, arg_3166) }; var tmp59 lang.IFn = /*line :398:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp60 any = A_arbace_j2g_dyn_A_const_356; var tmp61 any = A_arbace_j2g_dyn_A_const_360; var tmp62 any = A_arbace_j2g_dyn_A_const_361; var tmp63 any = A_arbace_j2g_dyn_A_const_362; var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp65 any = A_arbace_j2g_dyn_A_const_363; var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp67 any = A_arbace_j2g_dyn_A_const_364; var tmp68 any = A_arbace_j2g_dyn_A_const_365; var tmp69 any = A_arbace_j2g_dyn_A_const_366; var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp71 any = A_arbace_j2g_dyn_A_const_373; var tmp72 any = A_arbace_j2g_dyn_A_const_374; var tmp73 any = tmp49.Invoke_O_O_O_O__O(tmp50, tmp52, tmp53, tmp59.Invoke_O_O_O_O_O__O(tmp60, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp61, tmp62, tmp63, tmp64.Invoke_O_O__O(tmp65, tmp66.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp67, tmp68, tmp69, tmp70.Invoke_O_O_O__O(tmp71, tmp72, jrt.Integer_ValueOf_I__Integer_NoInit(n__4).Ref()), A_arbace_j2g_dyn_A_const_367, A_arbace_j2g_dyn_A_const_368, A_arbace_j2g_dyn_A_const_369, A_arbace_j2g_dyn_A_const_370, A_arbace_j2g_dyn_A_const_371, A_arbace_j2g_dyn_A_const_372))), A_arbace_j2g_dyn_A_const_357, A_arbace_j2g_dyn_A_const_358, A_arbace_j2g_dyn_A_const_359)); var tmp74 any = A_arbace_j2g_dyn_A_const_339; var tmp75 any = A_arbace_j2g_dyn_A_const_340; var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp77 any = A_arbace_j2g_dyn_A_const_375; var tmp78 any; var root_3182 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3182, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3184 lang.IFn; if



































































































































	linked_3183 == nil { ifn_3184 = lang.IFn_Cast(root_3182) } else { ifn_3184 = nil }; var arg_3185 any; var root_3186 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3186, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3188 lang.IFn; if linked_3187 == nil { ifn_3188 = lang.IFn_Cast(root_3186) } else { ifn_3188 = nil }; var arg_3189 any = Lit_57; var arg_3190 any = Lit_58; if linked_3187 == nil { arg_3185 = ifn_3188.Invoke_O_O__O(arg_3189, arg_3190) } else { arg_3185 = linked_3187.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3186, arg_3189, arg_3190) }; if linked_3183 == nil { tmp78 = ifn_3184.Invoke_O__O(arg_3185) } else { tmp78 = linked_3183.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3182, arg_3185) }; var tmp79 any = tmp78; var tmp80 any; var root_3191 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3191, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3193 lang.IFn; if




































































































































	linked_3192 == nil { ifn_3193 = lang.IFn_Cast(root_3191) } else { ifn_3193 = nil }; var arg_3194 any = A_arbace_j2g_dyn_A_const_377; var arg_3195 any = A_arbace_j2g_dyn_A_const_378; if linked_3192 == nil { tmp80 = ifn_3193.Invoke_O_O__O(arg_3194, arg_3195) } else { tmp80 = linked_3192.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3191, arg_3194, arg_3195) }; var tmp81 any = tmp80; var tmp82 any; var root_3196 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3196, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3198 lang.IFn; if




































































































































	linked_3197 == nil { ifn_3198 = lang.IFn_Cast(root_3196) } else { ifn_3198 = nil }; var arg_3199 any = A_arbace_j2g_dyn_A_const_379; var arg_3200 any = A_arbace_j2g_dyn_A_const_380; if linked_3197 == nil { tmp82 = ifn_3198.Invoke_O_O__O(arg_3199, arg_3200) } else { tmp82 = linked_3197.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3196, arg_3199, arg_3200) }; var tmp83 any = tmp82; var tmp84 any; var root_3201 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3201, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3203 lang.IFn; if




































































































































	linked_3202 == nil { ifn_3203 = lang.IFn_Cast(root_3201) } else { ifn_3203 = nil }; var arg_3204 any = A_arbace_j2g_dyn_A_const_381; var arg_3205 any = A_arbace_j2g_dyn_A_const_382; if linked_3202 == nil { tmp84 = ifn_3203.Invoke_O_O__O(arg_3204, arg_3205) } else { tmp84 = linked_3202.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3201, arg_3204, arg_3205) }; var tmp85 any = tmp84; var tmp86 any; var root_3206 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3206, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3208 lang.IFn; if




































































































































	linked_3207 == nil { ifn_3208 = lang.IFn_Cast(root_3206) } else { ifn_3208 = nil }; var arg_3209 any = A_arbace_j2g_dyn_A_const_383; var arg_3210 any = A_arbace_j2g_dyn_A_const_384; if linked_3207 == nil { tmp86 = ifn_3208.Invoke_O_O__O(arg_3209, arg_3210) } else { tmp86 = linked_3207.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3206, arg_3209, arg_3210) }; var tmp87 any = tmp86; var tmp88 any; var root_3211 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3211, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3213 lang.IFn; if




































































































































	linked_3212 == nil { ifn_3213 = lang.IFn_Cast(root_3211) } else { ifn_3213 = nil }; var arg_3214 any = A_arbace_j2g_dyn_A_const_385; var arg_3215 any = A_arbace_j2g_dyn_A_const_386; if linked_3212 == nil { tmp88 = ifn_3213.Invoke_O_O__O(arg_3214, arg_3215) } else { tmp88 = linked_3212.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3211, arg_3214, arg_3215) }; var tmp89 any = /*line :398:1*/tmp76.Invoke_O_O_O_O__O(tmp77, tmp79, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp81, tmp83, tmp85, tmp87, tmp88), A_arbace_j2g_dyn_A_const_376); var tmp90 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp91 any = A_arbace_j2g_dyn_A_const_387; var tmp92 any; var root_3216 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3216, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3218 lang.IFn; if
































































































































































	linked_3217 == nil { ifn_3218 = lang.IFn_Cast(root_3216) } else { ifn_3218 = nil }; var arg_3219 any; var root_3220 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3220, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3222 lang.IFn; if linked_3221 == nil { ifn_3222 = lang.IFn_Cast(root_3220) } else { ifn_3222 = nil }; var arg_3223 any = Lit_59; var arg_3224 any = Lit_58; if linked_3221 == nil { arg_3219 = ifn_3222.Invoke_O_O__O(arg_3223, arg_3224) } else { arg_3219 = linked_3221.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3220, arg_3223, arg_3224) }; if linked_3217 == nil { tmp92 = ifn_3218.Invoke_O__O(arg_3219) } else { tmp92 = linked_3217.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3216, arg_3219) }; var tmp93 any = tmp92; var tmp94 any; var root_3225 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3225, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3227 lang.IFn; if

































































































































































	linked_3226 == nil { ifn_3227 = lang.IFn_Cast(root_3225) } else { ifn_3227 = nil }; var arg_3228 any = A_arbace_j2g_dyn_A_const_389; var arg_3229 any = A_arbace_j2g_dyn_A_const_390; if linked_3226 == nil { tmp94 = ifn_3227.Invoke_O_O__O(arg_3228, arg_3229) } else { tmp94 = linked_3226.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3225, arg_3228, arg_3229) }; var tmp95 any = tmp94; var tmp96 any; var root_3230 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3230, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3232 lang.IFn; if

































































































































































	linked_3231 == nil { ifn_3232 = lang.IFn_Cast(root_3230) } else { ifn_3232 = nil }; var arg_3233 any = A_arbace_j2g_dyn_A_const_391; var arg_3234 any = A_arbace_j2g_dyn_A_const_392; if linked_3231 == nil { tmp96 = ifn_3232.Invoke_O_O__O(arg_3233, arg_3234) } else { tmp96 = linked_3231.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3230, arg_3233, arg_3234) }; var tmp97 any = tmp96; var tmp98 any; var root_3235 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3235, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3237 lang.IFn; if

































































































































































	linked_3236 == nil { ifn_3237 = lang.IFn_Cast(root_3235) } else { ifn_3237 = nil }; var arg_3238 any = A_arbace_j2g_dyn_A_const_393; var arg_3239 any = A_arbace_j2g_dyn_A_const_394; if linked_3236 == nil { tmp98 = ifn_3237.Invoke_O_O__O(arg_3238, arg_3239) } else { tmp98 = linked_3236.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3235, arg_3238, arg_3239) }; var tmp99 any = tmp98; var tmp100 any; var root_3240 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3240, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3242 lang.IFn; if

































































































































































	linked_3241 == nil { ifn_3242 = lang.IFn_Cast(root_3240) } else { ifn_3242 = nil }; var arg_3243 any = A_arbace_j2g_dyn_A_const_395; var arg_3244 any = A_arbace_j2g_dyn_A_const_396; if linked_3241 == nil { tmp100 = ifn_3242.Invoke_O_O__O(arg_3243, arg_3244) } else { tmp100 = linked_3241.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3240, arg_3243, arg_3244) }; var tmp101 any = tmp100; var tmp102 any; var root_3245 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3245, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3247 lang.IFn; if

































































































































































	linked_3246 == nil { ifn_3247 = lang.IFn_Cast(root_3245) } else { ifn_3247 = nil }; var arg_3248 any = A_arbace_j2g_dyn_A_const_397; var arg_3249 any = A_arbace_j2g_dyn_A_const_398; if linked_3246 == nil { tmp102 = ifn_3247.Invoke_O_O__O(arg_3248, arg_3249) } else { tmp102 = linked_3246.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3245, arg_3248, arg_3249) }; var tmp103 any = /*line :398:1*/tmp90.Invoke_O_O_O_O__O(tmp91, tmp93, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp95, tmp97, tmp99, tmp101, tmp102), A_arbace_j2g_dyn_A_const_388); var tmp104 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp105 any = A_arbace_j2g_dyn_A_const_399; var tmp106 any; var root_3250 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3250, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3252 lang.IFn; if









































































































































































	linked_3251 == nil { ifn_3252 = lang.IFn_Cast(root_3250) } else { ifn_3252 = nil }; var arg_3253 any; var root_3254 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3254, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3256 lang.IFn; if linked_3255 == nil { ifn_3256 = lang.IFn_Cast(root_3254) } else { ifn_3256 = nil }; var arg_3257 any = Lit_60; var arg_3258 any = Lit_61; if linked_3255 == nil { arg_3253 = ifn_3256.Invoke_O_O__O(arg_3257, arg_3258) } else { arg_3253 = linked_3255.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3254, arg_3257, arg_3258) }; if linked_3251 == nil { tmp106 = ifn_3252.Invoke_O__O(arg_3253) } else { tmp106 = linked_3251.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3250, arg_3253) }; var tmp107 any = tmp106; var tmp108 any; var root_3259 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3259, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3261 lang.IFn; if










































































































































































	linked_3260 == nil { ifn_3261 = lang.IFn_Cast(root_3259) } else { ifn_3261 = nil }; var arg_3262 any = A_arbace_j2g_dyn_A_const_401; var arg_3263 any = A_arbace_j2g_dyn_A_const_402; if linked_3260 == nil { tmp108 = ifn_3261.Invoke_O_O__O(arg_3262, arg_3263) } else { tmp108 = linked_3260.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3259, arg_3262, arg_3263) }; var tmp109 any = tmp108; var tmp110 any; var root_3264 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3264, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3266 lang.IFn; if










































































































































































	linked_3265 == nil { ifn_3266 = lang.IFn_Cast(root_3264) } else { ifn_3266 = nil }; var arg_3267 any = A_arbace_j2g_dyn_A_const_403; var arg_3268 any = A_arbace_j2g_dyn_A_const_404; if linked_3265 == nil { tmp110 = ifn_3266.Invoke_O_O__O(arg_3267, arg_3268) } else { tmp110 = linked_3265.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3264, arg_3267, arg_3268) }; var tmp111 any = tmp110; var tmp112 any; var root_3269 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3269, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3271 lang.IFn; if










































































































































































	linked_3270 == nil { ifn_3271 = lang.IFn_Cast(root_3269) } else { ifn_3271 = nil }; var arg_3272 any = A_arbace_j2g_dyn_A_const_405; var arg_3273 any = A_arbace_j2g_dyn_A_const_406; if linked_3270 == nil { tmp112 = ifn_3271.Invoke_O_O__O(arg_3272, arg_3273) } else { tmp112 = linked_3270.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3269, arg_3272, arg_3273) }; var tmp113 any = /*line :398:1*/tmp104.Invoke_O_O_O_O__O(tmp105, tmp107, lang.Tuple_Create_O_O_O__IPersistentVector(tmp109, tmp111, tmp112), A_arbace_j2g_dyn_A_const_400); var tmp114 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp115 any = A_arbace_j2g_dyn_A_const_407; var tmp116 any; var root_3274 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3274, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3276 lang.IFn; if
























































































































































































	linked_3275 == nil { ifn_3276 = lang.IFn_Cast(root_3274) } else { ifn_3276 = nil }; var arg_3277 any; var root_3278 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3278, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3280 lang.IFn; if linked_3279 == nil { ifn_3280 = lang.IFn_Cast(root_3278) } else { ifn_3280 = nil }; var arg_3281 any = Lit_62; var arg_3282 any = Lit_63; if linked_3279 == nil { arg_3277 = ifn_3280.Invoke_O_O__O(arg_3281, arg_3282) } else { arg_3277 = linked_3279.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3278, arg_3281, arg_3282) }; if linked_3275 == nil { tmp116 = ifn_3276.Invoke_O__O(arg_3277) } else { tmp116 = linked_3275.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3274, arg_3277) }; var tmp117 any = tmp116; var tmp118 any; var root_3283 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3283, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3285 lang.IFn; if

























































































































































































	linked_3284 == nil { ifn_3285 = lang.IFn_Cast(root_3283) } else { ifn_3285 = nil }; var arg_3286 any; var tmp119 any; var root_3288 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3288, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3290 lang.IFn; if linked_3289 == nil { ifn_3290 = lang.IFn_Cast(root_3288) } else { ifn_3290 = nil }; var arg_3291 any = A_arbace_j2g_dyn_A_const_408; var arg_3292 any = A_arbace_j2g_dyn_A_const_409; if linked_3289 == nil { tmp119 = ifn_3290.Invoke_O_O__O(arg_3291, arg_3292) } else { tmp119 = linked_3289.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3288, arg_3291, arg_3292) }; var tmp120 any = tmp119; var tmp121 any; var root_3293 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3293, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3295 lang.IFn; if linked_3294 == nil { ifn_3295 = lang.IFn_Cast(root_3293) } else { ifn_3295 = nil }; var arg_3296 any = A_arbace_j2g_dyn_A_const_410; var arg_3297 any = A_arbace_j2g_dyn_A_const_411; if linked_3294 == nil { tmp121 = ifn_3295.Invoke_O_O__O(arg_3296, arg_3297) } else { tmp121 = linked_3294.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3293, arg_3296, arg_3297) }; arg_3286 = lang.Tuple_Create_O_O__IPersistentVector(tmp120, tmp121); var arg_3287 any = A_arbace_j2g_dyn_A_const_412; if linked_3284 == nil { tmp118 = ifn_3285.Invoke_O_O__O(arg_3286, arg_3287) } else { tmp118 = linked_3284.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3283, arg_3286, arg_3287) }; var tmp122 any = /*line :398:1*/tmp114.Invoke_O_O_O_O__O(tmp115, tmp117, tmp118, A_arbace_j2g_dyn_A_const_413); var tmp123 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp124 any = A_arbace_j2g_dyn_A_const_414; var tmp125 any; var root_3298 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3298, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3300 lang.IFn; if




































































































































































































	linked_3299 == nil { ifn_3300 = lang.IFn_Cast(root_3298) } else { ifn_3300 = nil }; var arg_3301 any; var root_3302 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3302, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3304 lang.IFn; if linked_3303 == nil { ifn_3304 = lang.IFn_Cast(root_3302) } else { ifn_3304 = nil }; var arg_3305 any = Lit_64; var arg_3306 any = Lit_65; if linked_3303 == nil { arg_3301 = ifn_3304.Invoke_O_O__O(arg_3305, arg_3306) } else { arg_3301 = linked_3303.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3302, arg_3305, arg_3306) }; if linked_3299 == nil { tmp125 = ifn_3300.Invoke_O__O(arg_3301) } else { tmp125 = linked_3299.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3298, arg_3301) }; var tmp126 any = tmp125; var tmp127 any; var root_3307 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3307, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3309 lang.IFn; if





































































































































































































	linked_3308 == nil { ifn_3309 = lang.IFn_Cast(root_3307) } else { ifn_3309 = nil }; var arg_3310 any = A_arbace_j2g_dyn_A_const_416; var arg_3311 any = A_arbace_j2g_dyn_A_const_417; if linked_3308 == nil { tmp127 = ifn_3309.Invoke_O_O__O(arg_3310, arg_3311) } else { tmp127 = linked_3308.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3307, arg_3310, arg_3311) }; var tmp128 any = tmp127; var tmp129 any; var root_3312 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3312, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3314 lang.IFn; if





































































































































































































	linked_3313 == nil { ifn_3314 = lang.IFn_Cast(root_3312) } else { ifn_3314 = nil }; var arg_3315 any = A_arbace_j2g_dyn_A_const_418; var arg_3316 any = A_arbace_j2g_dyn_A_const_419; if linked_3313 == nil { tmp129 = ifn_3314.Invoke_O_O__O(arg_3315, arg_3316) } else { tmp129 = linked_3313.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3312, arg_3315, arg_3316) }; var tmp130 any = tmp129; var tmp131 any; var root_3317 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3317, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3319 lang.IFn; if





































































































































































































	linked_3318 == nil { ifn_3319 = lang.IFn_Cast(root_3317) } else { ifn_3319 = nil }; var arg_3320 any = A_arbace_j2g_dyn_A_const_420; var arg_3321 any = A_arbace_j2g_dyn_A_const_421; if linked_3318 == nil { tmp131 = ifn_3319.Invoke_O_O__O(arg_3320, arg_3321) } else { tmp131 = linked_3318.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3317, arg_3320, arg_3321) }; var tmp132 any = tmp131; var tmp133 any; var root_3322 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3322, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3324 lang.IFn; if





































































































































































































	linked_3323 == nil { ifn_3324 = lang.IFn_Cast(root_3322) } else { ifn_3324 = nil }; var arg_3325 any = A_arbace_j2g_dyn_A_const_422; var arg_3326 any = A_arbace_j2g_dyn_A_const_423; if linked_3323 == nil { tmp133 = ifn_3324.Invoke_O_O__O(arg_3325, arg_3326) } else { tmp133 = linked_3323.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3322, arg_3325, arg_3326) }; var tmp134 any = /*line :398:1*/tmp123.Invoke_O_O_O_O__O(tmp124, tmp126, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp128, tmp130, tmp132, tmp133), A_arbace_j2g_dyn_A_const_415); var tmp135 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp136 any = A_arbace_j2g_dyn_A_const_424; var tmp137 any; var root_3327 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3327, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3329 lang.IFn; if





















































































































































































































	linked_3328 == nil { ifn_3329 = lang.IFn_Cast(root_3327) } else { ifn_3329 = nil }; var arg_3330 any; var root_3331 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3331, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3333 lang.IFn; if linked_3332 == nil { ifn_3333 = lang.IFn_Cast(root_3331) } else { ifn_3333 = nil }; var arg_3334 any = Lit_66; var arg_3335 any = Lit_67; if linked_3332 == nil { arg_3330 = ifn_3333.Invoke_O_O__O(arg_3334, arg_3335) } else { arg_3330 = linked_3332.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3331, arg_3334, arg_3335) }; if linked_3328 == nil { tmp137 = ifn_3329.Invoke_O__O(arg_3330) } else { tmp137 = linked_3328.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3327, arg_3330) }; var tmp138 any = tmp137; var tmp139 any; var root_3336 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3336, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3338 lang.IFn; if






















































































































































































































	linked_3337 == nil { ifn_3338 = lang.IFn_Cast(root_3336) } else { ifn_3338 = nil }; var arg_3339 any; var tmp140 any; var root_3341 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3341, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3343 lang.IFn; if linked_3342 == nil { ifn_3343 = lang.IFn_Cast(root_3341) } else { ifn_3343 = nil }; var arg_3344 any = A_arbace_j2g_dyn_A_const_425; var arg_3345 any = A_arbace_j2g_dyn_A_const_426; if linked_3342 == nil { tmp140 = ifn_3343.Invoke_O_O__O(arg_3344, arg_3345) } else { tmp140 = linked_3342.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3341, arg_3344, arg_3345) }; var tmp141 any = tmp140; var tmp142 any; var root_3346 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3346, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3348 lang.IFn; if linked_3347 == nil { ifn_3348 = lang.IFn_Cast(root_3346) } else { ifn_3348 = nil }; var arg_3349 any = A_arbace_j2g_dyn_A_const_427; var arg_3350 any = A_arbace_j2g_dyn_A_const_428; if linked_3347 == nil { tmp142 = ifn_3348.Invoke_O_O__O(arg_3349, arg_3350) } else { tmp142 = linked_3347.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3346, arg_3349, arg_3350) }; arg_3339 = lang.Tuple_Create_O_O__IPersistentVector(tmp141, tmp142); var arg_3340 any = A_arbace_j2g_dyn_A_const_429; if linked_3337 == nil { tmp139 = ifn_3338.Invoke_O_O__O(arg_3339, arg_3340) } else { tmp139 = linked_3337.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3336, arg_3339, arg_3340) }; var tmp143 any = /*line :398:1*/tmp135.Invoke_O_O_O_O__O(tmp136, tmp138, tmp139, A_arbace_j2g_dyn_A_const_430); var tmp144 any; var root_3150 any = A_arbace_j2g_dyn_A_const_341.GetRawRoot__O(); var linked_3151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3150, A_arbace_j2g_dyn_fn_field_native_A_fn_class); var ifn_3152 lang.IFn; if



























































































































































































































	linked_3151 == nil { ifn_3152 = lang.IFn_Cast(root_3150) } else { ifn_3152 = nil }; if linked_3151 == nil { tmp144 = ifn_3152.Invoke__O() } else { tmp144 = linked_3151.(*A_arbace_j2g_dyn_fn_field_native_A).Invoke_O__O(root_3150) }; var tmp145 any = tmp144; var tmp146 any = A_arbace_j2g_dyn_A_const_342; var tmp147 any = A_arbace_j2g_dyn_A_const_343; var tmp148 lang.IFn = /*line :398:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp149 any = A_arbace_j2g_dyn_A_const_431; var tmp150 any; var root_3351 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3351, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3353 lang.IFn; if








































































































































































































































	linked_3352 == nil { ifn_3353 = lang.IFn_Cast(root_3351) } else { ifn_3353 = nil }; var arg_3354 any; var root_3355 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3355, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3357 lang.IFn; if linked_3356 == nil { ifn_3357 = lang.IFn_Cast(root_3355) } else { ifn_3357 = nil }; var arg_3358 any = Lit_68; var arg_3359 any = Lit_69; if linked_3356 == nil { arg_3354 = ifn_3357.Invoke_O_O__O(arg_3358, arg_3359) } else { arg_3354 = linked_3356.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3355, arg_3358, arg_3359) }; if linked_3352 == nil { tmp150 = ifn_3353.Invoke_O__O(arg_3354) } else { tmp150 = linked_3352.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3351, arg_3354) }; var tmp151 any = tmp150; var tmp152 any; var root_3360 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3360, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3362 lang.IFn; if









































































































































































































































	linked_3361 == nil { ifn_3362 = lang.IFn_Cast(root_3360) } else { ifn_3362 = nil }; var arg_3363 any = A_arbace_j2g_dyn_A_const_433; var arg_3364 any = A_arbace_j2g_dyn_A_const_434; if linked_3361 == nil { tmp152 = ifn_3362.Invoke_O_O__O(arg_3363, arg_3364) } else { tmp152 = linked_3361.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3360, arg_3363, arg_3364) }; var tmp153 any = tmp152; var tmp154 any; var root_3365 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3365, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3367 lang.IFn; if









































































































































































































































	linked_3366 == nil { ifn_3367 = lang.IFn_Cast(root_3365) } else { ifn_3367 = nil }; var arg_3368 any = A_arbace_j2g_dyn_A_const_435; var arg_3369 any = A_arbace_j2g_dyn_A_const_436; if linked_3366 == nil { tmp154 = ifn_3367.Invoke_O_O__O(arg_3368, arg_3369) } else { tmp154 = linked_3366.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3365, arg_3368, arg_3369) }; var tmp155 any = /*line :398:1*/tmp148.Invoke_O_O_O_O__O(tmp149, tmp151, lang.Tuple_Create_O_O__IPersistentVector(tmp153, tmp154), A_arbace_j2g_dyn_A_const_432); var tmp156 any = A_arbace_j2g_dyn_A_const_344; var tmp157 any = A_arbace_j2g_dyn_A_const_345.GetRawRoot__O(); var tmp158 any = A_arbace_j2g_dyn_A_const_346; var tmp159 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp160 any = A_arbace_j2g_dyn_A_const_437; var tmp161 any; var root_3370 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3370, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3372 lang.IFn; if































































































































































































































































	linked_3371 == nil { ifn_3372 = lang.IFn_Cast(root_3370) } else { ifn_3372 = nil }; var arg_3373 any; var root_3374 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3374, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3376 lang.IFn; if linked_3375 == nil { ifn_3376 = lang.IFn_Cast(root_3374) } else { ifn_3376 = nil }; var arg_3377 any = Lit_70; var arg_3378 any = Lit_71; if linked_3375 == nil { arg_3373 = ifn_3376.Invoke_O_O__O(arg_3377, arg_3378) } else { arg_3373 = linked_3375.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3374, arg_3377, arg_3378) }; if linked_3371 == nil { tmp161 = ifn_3372.Invoke_O__O(arg_3373) } else { tmp161 = linked_3371.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3370, arg_3373) }; var tmp162 any = tmp161; var tmp163 any; var root_3379 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3379, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3381 lang.IFn; if
































































































































































































































































	linked_3380 == nil { ifn_3381 = lang.IFn_Cast(root_3379) } else { ifn_3381 = nil }; var arg_3382 any; var tmp164 any; var root_3384 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3384, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3386 lang.IFn; if linked_3385 == nil { ifn_3386 = lang.IFn_Cast(root_3384) } else { ifn_3386 = nil }; var arg_3387 any = A_arbace_j2g_dyn_A_const_438; var arg_3388 any = A_arbace_j2g_dyn_A_const_439; if linked_3385 == nil { tmp164 = ifn_3386.Invoke_O_O__O(arg_3387, arg_3388) } else { tmp164 = linked_3385.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3384, arg_3387, arg_3388) }; var tmp165 any = tmp164; var tmp166 any; var root_3389 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3389, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3391 lang.IFn; if linked_3390 == nil { ifn_3391 = lang.IFn_Cast(root_3389) } else { ifn_3391 = nil }; var arg_3392 any = A_arbace_j2g_dyn_A_const_440; var arg_3393 any = A_arbace_j2g_dyn_A_const_441; if linked_3390 == nil { tmp166 = ifn_3391.Invoke_O_O__O(arg_3392, arg_3393) } else { tmp166 = linked_3390.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3389, arg_3392, arg_3393) }; arg_3382 = lang.Tuple_Create_O_O__IPersistentVector(tmp165, tmp166); var arg_3383 any = A_arbace_j2g_dyn_A_const_442; if linked_3380 == nil { tmp163 = ifn_3381.Invoke_O_O__O(arg_3382, arg_3383) } else { tmp163 = linked_3380.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3379, arg_3382, arg_3383) }; var tmp167 any = /*line :398:1*/tmp159.Invoke_O_O_O_O__O(tmp160, tmp162, tmp163, A_arbace_j2g_dyn_A_const_443); var tmp168 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp169 any = A_arbace_j2g_dyn_A_const_444; var tmp170 any; var root_3394 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3394, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3396 lang.IFn; if





































































































































































































































































	linked_3395 == nil { ifn_3396 = lang.IFn_Cast(root_3394) } else { ifn_3396 = nil }; var arg_3397 any; var root_3398 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3398, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3400 lang.IFn; if linked_3399 == nil { ifn_3400 = lang.IFn_Cast(root_3398) } else { ifn_3400 = nil }; var arg_3401 any = Lit_72; var arg_3402 any = Lit_73; if linked_3399 == nil { arg_3397 = ifn_3400.Invoke_O_O__O(arg_3401, arg_3402) } else { arg_3397 = linked_3399.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3398, arg_3401, arg_3402) }; if linked_3395 == nil { tmp170 = ifn_3396.Invoke_O__O(arg_3397) } else { tmp170 = linked_3395.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3394, arg_3397) }; var tmp171 any = tmp170; var tmp172 any; var root_3403 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3403, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3405 lang.IFn; if






































































































































































































































































	linked_3404 == nil { ifn_3405 = lang.IFn_Cast(root_3403) } else { ifn_3405 = nil }; var arg_3406 any; var tmp173 any; var root_3408 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3408, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3410 lang.IFn; if linked_3409 == nil { ifn_3410 = lang.IFn_Cast(root_3408) } else { ifn_3410 = nil }; var arg_3411 any = A_arbace_j2g_dyn_A_const_445; var arg_3412 any = A_arbace_j2g_dyn_A_const_446; if linked_3409 == nil { tmp173 = ifn_3410.Invoke_O_O__O(arg_3411, arg_3412) } else { tmp173 = linked_3409.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3408, arg_3411, arg_3412) }; var tmp174 any = tmp173; var tmp175 any; var root_3413 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3413, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3415 lang.IFn; if linked_3414 == nil { ifn_3415 = lang.IFn_Cast(root_3413) } else { ifn_3415 = nil }; var arg_3416 any = A_arbace_j2g_dyn_A_const_447; var arg_3417 any = A_arbace_j2g_dyn_A_const_448; if linked_3414 == nil { tmp175 = ifn_3415.Invoke_O_O__O(arg_3416, arg_3417) } else { tmp175 = linked_3414.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3413, arg_3416, arg_3417) }; arg_3406 = lang.Tuple_Create_O_O__IPersistentVector(tmp174, tmp175); var arg_3407 any = A_arbace_j2g_dyn_A_const_449; if linked_3404 == nil { tmp172 = ifn_3405.Invoke_O_O__O(arg_3406, arg_3407) } else { tmp172 = linked_3404.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3403, arg_3406, arg_3407) }; var tmp176 any = /*line :398:1*/tmp168.Invoke_O_O_O_O__O(tmp169, tmp171, tmp172, A_arbace_j2g_dyn_A_const_450); var tmp177 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp178 any = A_arbace_j2g_dyn_A_const_451; var tmp179 any; var root_3418 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3418, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3420 lang.IFn; if








































































































































































































































































	linked_3419 == nil { ifn_3420 = lang.IFn_Cast(root_3418) } else { ifn_3420 = nil }; var arg_3421 any; var root_3422 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3422, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3424 lang.IFn; if linked_3423 == nil { ifn_3424 = lang.IFn_Cast(root_3422) } else { ifn_3424 = nil }; var arg_3425 any = Lit_74; var arg_3426 any = Lit_75; if linked_3423 == nil { arg_3421 = ifn_3424.Invoke_O_O__O(arg_3425, arg_3426) } else { arg_3421 = linked_3423.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3422, arg_3425, arg_3426) }; if linked_3419 == nil { tmp179 = ifn_3420.Invoke_O__O(arg_3421) } else { tmp179 = linked_3419.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3418, arg_3421) }; var tmp180 any = tmp179; var tmp181 any; var root_3427 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3427, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3429 lang.IFn; if









































































































































































































































































	linked_3428 == nil { ifn_3429 = lang.IFn_Cast(root_3427) } else { ifn_3429 = nil }; var arg_3430 any = A_arbace_j2g_dyn_A_const_453; var arg_3431 any = A_arbace_j2g_dyn_A_const_454; if linked_3428 == nil { tmp181 = ifn_3429.Invoke_O_O__O(arg_3430, arg_3431) } else { tmp181 = linked_3428.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3427, arg_3430, arg_3431) }; var tmp182 any = tmp181; var tmp183 any; var root_3432 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3432, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3434 lang.IFn; if









































































































































































































































































	linked_3433 == nil { ifn_3434 = lang.IFn_Cast(root_3432) } else { ifn_3434 = nil }; var arg_3435 any = A_arbace_j2g_dyn_A_const_455; var arg_3436 any = A_arbace_j2g_dyn_A_const_456; if linked_3433 == nil { tmp183 = ifn_3434.Invoke_O_O__O(arg_3435, arg_3436) } else { tmp183 = linked_3433.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3432, arg_3435, arg_3436) }; var tmp184 any = tmp183; var tmp185 any; var root_3437 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3437, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3439 lang.IFn; if









































































































































































































































































	linked_3438 == nil { ifn_3439 = lang.IFn_Cast(root_3437) } else { ifn_3439 = nil }; var arg_3440 any = A_arbace_j2g_dyn_A_const_457; var arg_3441 any = A_arbace_j2g_dyn_A_const_458; if linked_3438 == nil { tmp185 = ifn_3439.Invoke_O_O__O(arg_3440, arg_3441) } else { tmp185 = linked_3438.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3437, arg_3440, arg_3441) }; var tmp186 any = /*line :398:1*/tmp177.Invoke_O_O_O_O__O(tmp178, tmp180, lang.Tuple_Create_O_O_O__IPersistentVector(tmp182, tmp184, tmp185), A_arbace_j2g_dyn_A_const_452); var tmp187 any = A_arbace_j2g_dyn_A_const_347; var tmp188 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp189 any = A_arbace_j2g_dyn_A_const_459; var tmp190 any; var root_3442 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3442, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3444 lang.IFn; if


















































































































































































































































































	linked_3443 == nil { ifn_3444 = lang.IFn_Cast(root_3442) } else { ifn_3444 = nil }; var arg_3445 any; var root_3446 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3446, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3448 lang.IFn; if linked_3447 == nil { ifn_3448 = lang.IFn_Cast(root_3446) } else { ifn_3448 = nil }; var arg_3449 any = Lit_76; var arg_3450 any = Lit_77; if linked_3447 == nil { arg_3445 = ifn_3448.Invoke_O_O__O(arg_3449, arg_3450) } else { arg_3445 = linked_3447.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3446, arg_3449, arg_3450) }; if linked_3443 == nil { tmp190 = ifn_3444.Invoke_O__O(arg_3445) } else { tmp190 = linked_3443.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3442, arg_3445) }; var tmp191 any = tmp190; var tmp192 any; var root_3451 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3451, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3453 lang.IFn; if





















































































































































































































































































	linked_3452 == nil { ifn_3453 = lang.IFn_Cast(root_3451) } else { ifn_3453 = nil }; var arg_3454 any = A_arbace_j2g_dyn_A_const_461; var arg_3455 any = A_arbace_j2g_dyn_A_const_462; if linked_3452 == nil { tmp192 = ifn_3453.Invoke_O_O__O(arg_3454, arg_3455) } else { tmp192 = linked_3452.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3451, arg_3454, arg_3455) }; var tmp193 any = tmp192; var tmp194 any; var root_3456 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3456, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3458 lang.IFn; if





















































































































































































































































































	linked_3457 == nil { ifn_3458 = lang.IFn_Cast(root_3456) } else { ifn_3458 = nil }; var arg_3459 any = A_arbace_j2g_dyn_A_const_463; var arg_3460 any = A_arbace_j2g_dyn_A_const_464; if linked_3457 == nil { tmp194 = ifn_3458.Invoke_O_O__O(arg_3459, arg_3460) } else { tmp194 = linked_3457.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3456, arg_3459, arg_3460) }; var tmp195 any = /*line :398:1*/tmp188.Invoke_O_O_O_O_O__O(tmp189, tmp191, Lit_78, lang.Tuple_Create_O_O__IPersistentVector(tmp193, tmp194), A_arbace_j2g_dyn_A_const_460); var tmp196 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp197 any = A_arbace_j2g_dyn_A_const_465; var tmp198 any; var root_3461 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3461, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3463 lang.IFn; if



























































































































































































































































































	linked_3462 == nil { ifn_3463 = lang.IFn_Cast(root_3461) } else { ifn_3463 = nil }; var arg_3464 any; var root_3465 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3465, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3467 lang.IFn; if linked_3466 == nil { ifn_3467 = lang.IFn_Cast(root_3465) } else { ifn_3467 = nil }; var arg_3468 any = Lit_79; var arg_3469 any = Lit_80; if linked_3466 == nil { arg_3464 = ifn_3467.Invoke_O_O__O(arg_3468, arg_3469) } else { arg_3464 = linked_3466.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3465, arg_3468, arg_3469) }; if linked_3462 == nil { tmp198 = ifn_3463.Invoke_O__O(arg_3464) } else { tmp198 = linked_3462.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3461, arg_3464) }; var tmp199 any = tmp198; var tmp200 any; var root_3470 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3470, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3472 lang.IFn; if




























































































































































































































































































	linked_3471 == nil { ifn_3472 = lang.IFn_Cast(root_3470) } else { ifn_3472 = nil }; var arg_3473 any = lang.PersistentVector_EMPTY.Ref(); var arg_3474 any = A_arbace_j2g_dyn_A_const_466; if linked_3471 == nil { tmp200 = ifn_3472.Invoke_O_O__O(arg_3473, arg_3474) } else { tmp200 = linked_3471.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3470, arg_3473, arg_3474) }; var tmp201 any = /*line :398:1*/tmp196.Invoke_O_O_O_O__O(tmp197, tmp199, tmp200, A_arbace_j2g_dyn_A_const_467); var tmp202 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp203 any = A_arbace_j2g_dyn_A_const_468; var tmp204 any = A_arbace_j2g_dyn_A_const_469; var tmp205 any; var root_3605 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3605, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3607 lang.IFn; if
































































































































































































































































































	linked_3606 == nil { ifn_3607 = lang.IFn_Cast(root_3605) } else { ifn_3607 = nil }; var arg_3608 any = A_arbace_j2g_dyn_A_const_478; var arg_3609 any = A_arbace_j2g_dyn_A_const_479; if linked_3606 == nil { tmp205 = ifn_3607.Invoke_O_O__O(arg_3608, arg_3609) } else { tmp205 = linked_3606.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3605, arg_3608, arg_3609) }; var tmp206 any = /*line :398:1*/lang.Tuple_Create_O__IPersistentVector(tmp205); var tmp207 any = A_arbace_j2g_dyn_A_const_470; var tmp208 any = A_arbace_j2g_dyn_A_const_471; var tmp209 any; var root_3475 any = A_arbace_j2g_dyn_A_const_99.GetRawRoot__O(); var linked_3476 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3475, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_3477 lang.IFn; if

































































































































































































































































































	linked_3476 == nil { ifn_3477 = lang.IFn_Cast(root_3475) } else { ifn_3477 = nil }; var arg_3478 any = A_arbace_j2g_dyn_A_const_79.GetRawRoot__O(); var arg_3479 any = A_arbace_j2g_dyn_A_const_472; var arg_3480 any = A_arbace_j2g_dyn_A_const_473; var arg_3481 any; var iter__1927001039__auto____5_3 any; var tmp210 any = A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_New(); var tmp211 *jrt.Class; var fncls__3600 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_fn_class; if
	fncls__3600 == nil { var fncls__3600d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_fn_class = fncls__3600d; tmp211 = fncls__3600d } else { tmp211 = fncls__3600 }; iter__1927001039__auto____5_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp210, tmp211, nil); var tmp212 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5_3); var tmp213 any; var root_3601 any = A_arbace_j2g_dyn_A_const_476.GetRawRoot__O(); var linked_3602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3601, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3603 lang.IFn; if linked_3602 == nil { ifn_3603 = lang.IFn_Cast(root_3601) } else { ifn_3603 = nil }; var arg_3604 any = T__0_; if linked_3602 == nil { tmp213 = ifn_3603.Invoke_O__O(arg_3604) } else { tmp213 = linked_3602.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3601, arg_3604) }; arg_3481 = tmp212.Invoke_O__O(tmp213); if /*line :688:1*/ linked_3476 == nil { tmp209 = ifn_3477.Invoke_O_O_O_O__O(arg_3478, arg_3479, arg_3480, arg_3481) } else { tmp209 = linked_3476.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_3475, arg_3478, arg_3479, arg_3480, arg_3481) }; var tmp214 any = /*line :398:1*/tmp202.Invoke_O_O_O_O_O_O_O_O__O(tmp203, tmp204, Lit_81, tmp206, tmp207, tmp208, tmp209, A_arbace_j2g_dyn_A_const_477); var tmp215 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp216 any = A_arbace_j2g_dyn_A_const_480; var tmp217 any; var root_3610 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3610, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3612 lang.IFn; if







































































































































































































































































































	linked_3611 == nil { ifn_3612 = lang.IFn_Cast(root_3610) } else { ifn_3612 = nil }; var arg_3613 any; var root_3614 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3614, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3616 lang.IFn; if linked_3615 == nil { ifn_3616 = lang.IFn_Cast(root_3614) } else { ifn_3616 = nil }; var arg_3617 any = Lit_83; var arg_3618 any = Lit_84; if linked_3615 == nil { arg_3613 = ifn_3616.Invoke_O_O__O(arg_3617, arg_3618) } else { arg_3613 = linked_3615.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3614, arg_3617, arg_3618) }; if linked_3611 == nil { tmp217 = ifn_3612.Invoke_O__O(arg_3613) } else { tmp217 = linked_3611.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3610, arg_3613) }; var tmp218 any = tmp217; var tmp219 any; var root_3619 any = /*line :398:1*/A_arbace_j2g_dyn_A_const_16.GetRawRoot__O(); var linked_3620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3619, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3621 lang.IFn; if








































































































































































































































































































	linked_3620 == nil { ifn_3621 = lang.IFn_Cast(root_3619) } else { ifn_3621 = nil }; var arg_3622 any; var tmp220 any; var root_3624 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3624, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3626 lang.IFn; if linked_3625 == nil { ifn_3626 = lang.IFn_Cast(root_3624) } else { ifn_3626 = nil }; var arg_3627 any = A_arbace_j2g_dyn_A_const_481; var arg_3628 any = A_arbace_j2g_dyn_A_const_482; if linked_3625 == nil { tmp220 = ifn_3626.Invoke_O_O__O(arg_3627, arg_3628) } else { tmp220 = linked_3625.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3624, arg_3627, arg_3628) }; var tmp221 any = tmp220; var tmp222 any; var root_3629 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3629, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3631 lang.IFn; if linked_3630 == nil { ifn_3631 = lang.IFn_Cast(root_3629) } else { ifn_3631 = nil }; var arg_3632 any = A_arbace_j2g_dyn_A_const_483; var arg_3633 any = A_arbace_j2g_dyn_A_const_484; if linked_3630 == nil { tmp222 = ifn_3631.Invoke_O_O__O(arg_3632, arg_3633) } else { tmp222 = linked_3630.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3629, arg_3632, arg_3633) }; var tmp223 any = tmp222; var tmp224 any; var root_3634 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3634, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3636 lang.IFn; if linked_3635 == nil { ifn_3636 = lang.IFn_Cast(root_3634) } else { ifn_3636 = nil }; var arg_3637 any = A_arbace_j2g_dyn_A_const_485; var arg_3638 any = A_arbace_j2g_dyn_A_const_486; if linked_3635 == nil { tmp224 = ifn_3636.Invoke_O_O__O(arg_3637, arg_3638) } else { tmp224 = linked_3635.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3634, arg_3637, arg_3638) }; arg_3622 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp221, tmp223, tmp224); var arg_3623 any = A_arbace_j2g_dyn_A_const_487; if linked_3620 == nil { tmp219 = ifn_3621.Invoke_O_O__O(arg_3622, arg_3623) } else { tmp219 = linked_3620.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3619, arg_3622, arg_3623) }; var tmp225 any = tmp219; var tmp226 lang.IFn = /*line :398:1*/lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp227 any = A_arbace_j2g_dyn_A_const_489; var tmp228 any = A_arbace_j2g_dyn_A_const_490; var tmp229 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp230 any = A_arbace_j2g_dyn_A_const_491; var tmp231 any = A_arbace_j2g_dyn_A_const_496; var tmp232 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp233 any; var root_3639 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3639, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3641 lang.IFn; if











































































































































































































































































































	linked_3640 == nil { ifn_3641 = lang.IFn_Cast(root_3639) } else { ifn_3641 = nil }; var arg_3642 any; var root_3643 any = A_arbace_j2g_dyn_A_const_282.GetRawRoot__O(); var linked_3644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3643, A_arbace_j2g_dyn_native_name_A_fn_class); var ifn_3645 lang.IFn; if linked_3644 == nil { ifn_3645 = lang.IFn_Cast(root_3643) } else { ifn_3645 = nil }; var arg_3646 any = Lit_55; var arg_3647 any = Lit_56; if linked_3644 == nil { arg_3642 = ifn_3645.Invoke_O_O__O(arg_3646, arg_3647) } else { arg_3642 = linked_3644.(*A_arbace_j2g_dyn_native_name_A).Invoke_O_O_O__O(root_3643, arg_3646, arg_3647) }; if linked_3640 == nil { tmp233 = ifn_3641.Invoke_O__O(arg_3642) } else { tmp233 = linked_3640.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3639, arg_3642) }; var tmp234 any = /*line :398:1*/lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp73, tmp74, tmp75, tmp89, tmp103, tmp113, tmp122, tmp134, tmp143, tmp145, tmp146, tmp147, tmp155, tmp156, tmp157, tmp158, tmp167, tmp176, tmp186, tmp187, tmp195, tmp201, tmp214, tmp215.Invoke_O_O_O_O_O__O(tmp216, tmp218, tmp225, tmp226.Invoke_O_O_O__O(tmp227, tmp228, tmp229.Invoke_O_O_O_O_O_O__O(tmp230, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(tmp231, tmp232.Invoke_O_O_O_O__O(tmp233, A_arbace_j2g_dyn_A_const_501, A_arbace_j2g_dyn_A_const_502, A_arbace_j2g_dyn_A_const_503), A_arbace_j2g_dyn_A_const_497, A_arbace_j2g_dyn_A_const_498, A_arbace_j2g_dyn_A_const_499, A_arbace_j2g_dyn_A_const_500), A_arbace_j2g_dyn_A_const_492, A_arbace_j2g_dyn_A_const_493, A_arbace_j2g_dyn_A_const_494, A_arbace_j2g_dyn_A_const_495)), A_arbace_j2g_dyn_A_const_488))); var tmp235 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_504.GetRawRoot__O()); var tmp236 any = A_arbace_j2g_dyn_forms_fn__711000426_A_New_O_O(ks__3, ifaces__2); var tmp237 *jrt.Class; var fncls__3659 *jrt.Class = A_arbace_j2g_dyn_forms_fn__711000426_A_fn_class; if












































































































































































































































































































































	fncls__3659 == nil { var fncls__3659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_j2g_dyn_forms_fn__711000426_A_fn_class = fncls__3659d; tmp237 = fncls__3659d } else { tmp237 = fncls__3659 }; var tmp238 any = /*line :398:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp236, tmp237, nil); var tmp239 any; var root_3660 any = A_arbace_j2g_dyn_A_const_476.GetRawRoot__O(); var linked_3661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3660, A_arbace_j2g_dyn_proxy_classes_A_fn_class); var ifn_3662 lang.IFn; if












































































































































































































































































































































	linked_3661 == nil { ifn_3662 = lang.IFn_Cast(root_3660) } else { ifn_3662 = nil }; var arg_3663 any = T__0_; if linked_3661 == nil { tmp239 = ifn_3662.Invoke_O__O(arg_3663) } else { tmp239 = linked_3661.(*A_arbace_j2g_dyn_proxy_classes_A).Invoke_O_O__O(root_3660, arg_3663) }; return /*line :398:1*/ tmp1.Invoke_O_O_O_O_O__O(tmp35, tmp39, tmp48, tmp234, tmp235.Invoke_O_O__O(tmp238, tmp239)) }






























func A_arbace_j2g_dyn_forms_fn__711000383_A_New() *A_arbace_j2g_dyn_forms_fn__711000383_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000383_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_j2g_dyn_forms_fn__711000383_A) Ctor() {}
//line :429:1
func (t *A_arbace_j2g_dyn_forms_fn__711000383_A) Invoke_O_O_O__O(self, i__1, p__711000382__2 any) any { var vec__711000384__3 any = p__711000382__2; var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000384__3, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000384__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, nme__4, desc__5)).Ref(), i__1) }















func A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_New() *A_arbace_j2g_dyn_forms_iter__711000388__711000392_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000388__711000392_A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_A) Ctor() {}
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_A) Invoke_O_O__O(self, s__711000389__1 any) any { var tmp1 any = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_New_O_O(self, s__711000389__1); var tmp2 *jrt.Class; var fncls__3038 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_fn_class; if fncls__3038 == nil { var fncls__3038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_fn_class = fncls__3038d; tmp2 = fncls__3038d } else { tmp2 = fncls__3038 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :445:1
func A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A{}; t.Ctor_O_O(p0, p1); return t }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A) Ctor_O_O(c__iter__711000388, c__s__711000389 any) { t.F_iter__711000388 = c__iter__711000388; t.F_s__711000389 = c__s__711000389 }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A) Invoke_O__O(self any) any { { var s__711000389__1 any; var t_ any = t.F_s__711000389; t.F_s__711000389 = nil; s__711000389__1 = t_; for { var temp__1927000414__auto____2 any; var root_2959 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_2960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2959, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2961 lang.IFn; if linked_2960 == nil { ifn_2961 = lang.IFn_Cast(root_2959) } else { ifn_2961 = nil }; var arg_2962 any = s__711000389__1; if linked_2960 == nil { temp__1927000414__auto____2 = ifn_2961.Invoke_O__O(arg_2962) } else { temp__1927000414__auto____2 = linked_2960.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2959, arg_2962) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000389__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2963 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_2964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2963, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2965 lang.IFn; if linked_2964 == nil { ifn_2965 = lang.IFn_Cast(root_2963) } else { ifn_2965 = nil }; var arg_2966 any = s__711000389__3; if linked_2964 == nil { tmp1 = ifn_2965.Invoke_O__O(arg_2966) } else { tmp1 = linked_2964.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2963, arg_2966) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2967 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_2968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2967, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2969 lang.IFn; if linked_2968 == nil { ifn_2969 = lang.IFn_Cast(root_2967) } else { ifn_2969 = nil }; var arg_2970 any = s__711000389__3; if linked_2968 == nil { c__1927001037__auto____4 = ifn_2969.Invoke_O__O(arg_2970) } else { c__1927001037__auto____4 = linked_2968.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2967, arg_2970) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000391__6 any; var root_2971 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_2972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2971, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2973 lang.IFn; if linked_2972 == nil { ifn_2973 = lang.IFn_Cast(root_2971) } else { ifn_2973 = nil }; var arg_2974 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2972 == nil { b__711000391__6 = ifn_2973.Invoke_O__O(arg_2974) } else { b__711000391__6 = linked_2972.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2971, arg_2974) }; var tmp2 any = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_New_O_I_O(b__711000391__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2991 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_fn_class; if fncls__2991 == nil { var fncls__2991d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_fn_class = fncls__2991d; tmp3 = fncls__2991d } else { tmp3 = fncls__2991 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2992 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2994 lang.IFn; if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; var arg_2995 any; var root_2997 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2999 lang.IFn; if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var arg_3000 any = b__711000391__6; if linked_2998 == nil { arg_2995 = ifn_2999.Invoke_O__O(arg_3000) } else { arg_2995 = linked_2998.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2997, arg_3000) }; var arg_2996 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000388); var tmp5 any; var root_3001 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3001, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3003 lang.IFn; if linked_3002 == nil { ifn_3003 = lang.IFn_Cast(root_3001) } else { ifn_3003 = nil }; var arg_3004 any = s__711000389__3; if linked_3002 == nil { tmp5 = ifn_3003.Invoke_O__O(arg_3004) } else { tmp5 = linked_3002.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3001, arg_3004) }; arg_2996 = tmp4.Invoke_O__O(tmp5); if linked_2993 == nil { return ifn_2994.Invoke_O_O__O(arg_2995, arg_2996) } else { return linked_2993.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2992, arg_2995, arg_2996) } } else { var root_3005 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3005, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3007 lang.IFn; if linked_3006 == nil { ifn_3007 = lang.IFn_Cast(root_3005) } else { ifn_3007 = nil }; var arg_3008 any; var root_3010 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3010, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3012 lang.IFn; if linked_3011 == nil { ifn_3012 = lang.IFn_Cast(root_3010) } else { ifn_3012 = nil }; var arg_3013 any = b__711000391__6; if linked_3011 == nil { arg_3008 = ifn_3012.Invoke_O__O(arg_3013) } else { arg_3008 = linked_3011.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3010, arg_3013) }; var arg_3009 any; if linked_3006 == nil { return ifn_3007.Invoke_O_O__O(arg_3008, arg_3009) } else { return linked_3006.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3005, arg_3008, arg_3009) } } } else { var vec__711000399__4 any; var root_3014 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3014, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3016 lang.IFn; if linked_3015 == nil { ifn_3016 = lang.IFn_Cast(root_3014) } else { ifn_3016 = nil }; var arg_3017 any = s__711000389__3; if linked_3015 == nil { vec__711000399__4 = ifn_3016.Invoke_O__O(arg_3017) } else { vec__711000399__4 = linked_3015.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3014, arg_3017) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000399__4, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000399__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_3018 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3018, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3020 lang.IFn; if linked_3019 == nil { ifn_3020 = lang.IFn_Cast(root_3018) } else { ifn_3020 = nil }; var arg_3021 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_329; var tmp8 any = lang.Tuple_Create_O__IPersistentVector(d__5); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_dyn_A_const_330; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp12 any; var root_3023 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3023, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3025 lang.IFn
													if linked_3024 == nil { ifn_3025 = lang.IFn_Cast(root_3023) } else { ifn_3025 = nil }; var arg_3026 any = A_arbace_j2g_dyn_A_const_73; var arg_3027 any = Lit_16; var arg_3028 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp14 any; var root_3029 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_3030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3029, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_3031 lang.IFn; if linked_3030 == nil { ifn_3031 = lang.IFn_Cast(root_3029) } else { ifn_3031 = nil }; var arg_3032 any = nme__6; var arg_3033 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__5)).Ref(); if linked_3030 == nil { tmp14 = ifn_3031.Invoke_O_O__O(arg_3032, arg_3033) } else { tmp14 = linked_3030.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_3029, arg_3032, arg_3033) }; arg_3028 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3024 == nil { tmp12 = ifn_3025.Invoke_O_O_O__O(arg_3026, arg_3027, arg_3028) } else { tmp12 = linked_3024.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3023, arg_3026, arg_3027, arg_3028) }; arg_3021 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(tmp12, A_arbace_j2g_dyn_A_const_331)))
//line :445:1
	var arg_3022 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__711000388); var tmp16 any; var root_3034 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3034, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3036 lang.IFn; if linked_3035 == nil { ifn_3036 = lang.IFn_Cast(root_3034) } else { ifn_3036 = nil }; var arg_3037 any = s__711000389__3; if linked_3035 == nil { tmp16 = ifn_3036.Invoke_O__O(arg_3037) } else { tmp16 = linked_3035.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3034, arg_3037) }; arg_3022 = tmp15.Invoke_O__O(tmp16); if linked_3019 == nil { return ifn_3020.Invoke_O_O__O(arg_3021, arg_3022) } else { return linked_3019.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3018, arg_3021, arg_3022) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :445:1
func A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A) Ctor_O_I_O(c__b__711000391 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000391 = c__b__711000391; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :445:1
func (t *A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A) Invoke_O__O(self any) any { { var i__711000390__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000390__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__711000395__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000390__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000395__2, lang.RT_IntCast_J__I_NoInit(0), nil); var nme__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__711000395__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2975 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_2976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2975, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2977 lang.IFn; if linked_2976 == nil { ifn_2977 = lang.IFn_Cast(root_2975) } else { ifn_2977 = nil }; var arg_2978 any = t.F_b__711000391; var arg_2979 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_329; var tmp4 any = lang.Tuple_Create_O__IPersistentVector(d__3); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_dyn_A_const_330; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp8 any; var root_2980 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_2981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2980, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_2982 lang.IFn
															if linked_2981 == nil { ifn_2982 = lang.IFn_Cast(root_2980) } else { ifn_2982 = nil }; var arg_2983 any = A_arbace_j2g_dyn_A_const_73; var arg_2984 any = Lit_16; var arg_2985 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp10 any; var root_2986 any = A_arbace_j2g_dyn_A_const_74.GetRawRoot__O(); var linked_2987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2986, aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A_fn_class); var ifn_2988 lang.IFn; if linked_2987 == nil { ifn_2988 = lang.IFn_Cast(root_2986) } else { ifn_2988 = nil }; var arg_2989 any = nme__4; var arg_2990 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_17, nil), jrt.RefArrayOf(jrt.Object_class, nil, d__3)).Ref(); if linked_2987 == nil { tmp10 = ifn_2988.Invoke_O_O__O(arg_2989, arg_2990) } else { tmp10 = linked_2987.(*aot_arbace_j2g_names.A_arbace_j2g_names_method_base_A).Invoke_O_O_O__O(root_2986, arg_2989, arg_2990) }; arg_2985 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_2981 == nil { tmp8 = ifn_2982.Invoke_O_O_O__O(arg_2983, arg_2984, arg_2985) } else { tmp8 = linked_2981.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_2980, arg_2983, arg_2984, arg_2985) }; arg_2979 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, A_arbace_j2g_dyn_A_const_331)))
//line :445:1
	if linked_2976 == nil { ifn_2977.Invoke_O_O__O(arg_2978, arg_2979) } else { linked_2976.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2975, arg_2978, arg_2979) }; i__711000390__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000390__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








































func A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_New() *A_arbace_j2g_dyn_forms_iter__711000404__711000408_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000404__711000408_A{}; t.Ctor(); return t }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_A) Ctor() {}
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_A) Invoke_O_O__O(self, s__711000405__1 any) any { var tmp1 any = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_New_O_O(self, s__711000405__1); var tmp2 *jrt.Class; var fncls__3127 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_fn_class; if fncls__3127 == nil { var fncls__3127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_fn_class = fncls__3127d; tmp2 = fncls__3127d } else { tmp2 = fncls__3127 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :486:1
func A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A{}; t.Ctor_O_O(p0, p1); return t }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A) Ctor_O_O(c__iter__711000404, c__s__711000405 any) { t.F_iter__711000404 = c__iter__711000404; t.F_s__711000405 = c__s__711000405 }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A) Invoke_O__O(self any) any { { var s__711000405__1 any; var t_ any = t.F_s__711000405; t.F_s__711000405 = nil; s__711000405__1 = t_; for { var temp__1927000414__auto____2 any; var root_3044 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3046 lang.IFn; if linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any = s__711000405__1; if linked_3045 == nil { temp__1927000414__auto____2 = ifn_3046.Invoke_O__O(arg_3047) } else { temp__1927000414__auto____2 = linked_3045.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3044, arg_3047) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000405__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3048 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3048, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3050 lang.IFn; if linked_3049 == nil { ifn_3050 = lang.IFn_Cast(root_3048) } else { ifn_3050 = nil }; var arg_3051 any = s__711000405__3; if linked_3049 == nil { tmp1 = ifn_3050.Invoke_O__O(arg_3051) } else { tmp1 = linked_3049.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3048, arg_3051) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3052 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3052, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3054 lang.IFn; if linked_3053 == nil { ifn_3054 = lang.IFn_Cast(root_3052) } else { ifn_3054 = nil }; var arg_3055 any = s__711000405__3; if linked_3053 == nil { c__1927001037__auto____4 = ifn_3054.Invoke_O__O(arg_3055) } else { c__1927001037__auto____4 = linked_3053.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3052, arg_3055) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000407__6 any; var root_3056 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3056, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3058 lang.IFn; if linked_3057 == nil { ifn_3058 = lang.IFn_Cast(root_3056) } else { ifn_3058 = nil }; var arg_3059 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3057 == nil { b__711000407__6 = ifn_3058.Invoke_O__O(arg_3059) } else { b__711000407__6 = linked_3057.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3056, arg_3059) }; var tmp2 any = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_New_O_I_O(b__711000407__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3078 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_fn_class; if fncls__3078 == nil { var fncls__3078d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_fn_class = fncls__3078d; tmp3 = fncls__3078d } else { tmp3 = fncls__3078 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3079 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3079, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3081 lang.IFn; if linked_3080 == nil { ifn_3081 = lang.IFn_Cast(root_3079) } else { ifn_3081 = nil }; var arg_3082 any; var root_3084 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3084, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3086 lang.IFn; if linked_3085 == nil { ifn_3086 = lang.IFn_Cast(root_3084) } else { ifn_3086 = nil }; var arg_3087 any = b__711000407__6; if linked_3085 == nil { arg_3082 = ifn_3086.Invoke_O__O(arg_3087) } else { arg_3082 = linked_3085.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3084, arg_3087) }; var arg_3083 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000404); var tmp5 any; var root_3088 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3088, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3090 lang.IFn; if linked_3089 == nil { ifn_3090 = lang.IFn_Cast(root_3088) } else { ifn_3090 = nil }; var arg_3091 any = s__711000405__3; if linked_3089 == nil { tmp5 = ifn_3090.Invoke_O__O(arg_3091) } else { tmp5 = linked_3089.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3088, arg_3091) }; arg_3083 = tmp4.Invoke_O__O(tmp5); if linked_3080 == nil { return ifn_3081.Invoke_O_O__O(arg_3082, arg_3083) } else { return linked_3080.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3079, arg_3082, arg_3083) } } else { var root_3092 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3092, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3094 lang.IFn; if linked_3093 == nil { ifn_3094 = lang.IFn_Cast(root_3092) } else { ifn_3094 = nil }; var arg_3095 any; var root_3097 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3097, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3099 lang.IFn; if linked_3098 == nil { ifn_3099 = lang.IFn_Cast(root_3097) } else { ifn_3099 = nil }; var arg_3100 any = b__711000407__6; if linked_3098 == nil { arg_3095 = ifn_3099.Invoke_O__O(arg_3100) } else { arg_3095 = linked_3098.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3097, arg_3100) }; var arg_3096 any; if linked_3093 == nil { return ifn_3094.Invoke_O_O__O(arg_3095, arg_3096) } else { return linked_3093.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3092, arg_3095, arg_3096) } } } else { var j__4 any; var root_3101 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3101, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3103 lang.IFn; if linked_3102 == nil { ifn_3103 = lang.IFn_Cast(root_3101) } else { ifn_3103 = nil }; var arg_3104 any = s__711000405__3; if linked_3102 == nil { j__4 = ifn_3103.Invoke_O__O(arg_3104) } else { j__4 = linked_3102.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3101, arg_3104) }; var root_3105 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3105, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3107 lang.IFn; if linked_3106 == nil { ifn_3107 = lang.IFn_Cast(root_3105) } else { ifn_3107 = nil }; var arg_3108 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_334; var tmp8 any; var root_3110 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3110, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3112 lang.IFn; if linked_3111 == nil { ifn_3112 = lang.IFn_Cast(root_3110) } else { ifn_3112 = nil }; var arg_3113 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp10 any; var root_3114 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_3115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3114, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3116 lang.IFn; if linked_3115 == nil { ifn_3116 = lang.IFn_Cast(root_3114) } else { ifn_3116 = nil }; var arg_3117 any = j__4; if linked_3115 == nil { tmp10 = ifn_3116.Invoke_O__O(arg_3117) } else { tmp10 = linked_3115.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3114, arg_3117) }; arg_3113 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3111 == nil { tmp8 = ifn_3112.Invoke_O__O(arg_3113) } else { tmp8 = linked_3111.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3110, arg_3113) }; var tmp11 any = tmp8; var tmp12 any; var root_3118 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3118, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3120 lang.IFn; if linked_3119 == nil { ifn_3120 = lang.IFn_Cast(root_3118) } else { ifn_3120 = nil }; var arg_3121 any = A_arbace_j2g_dyn_A_const_335; var arg_3122 any = A_arbace_j2g_dyn_A_const_336; if linked_3119 == nil { tmp12 = ifn_3120.Invoke_O_O__O(arg_3121, arg_3122) } else { tmp12 = linked_3119.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3118, arg_3121, arg_3122) }; arg_3108 = tmp6.Invoke_O_O_O__O(tmp7, tmp11, lang.Tuple_Create_O__IPersistentVector(tmp12)); var arg_3109 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__711000404); var tmp14 any; var root_3123 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3123, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3125 lang.IFn; if linked_3124 == nil { ifn_3125 = lang.IFn_Cast(root_3123) } else { ifn_3125 = nil }; var arg_3126 any = s__711000405__3; if linked_3124 == nil { tmp14 = ifn_3125.Invoke_O__O(arg_3126) } else { tmp14 = linked_3124.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3123, arg_3126) }; arg_3109 = tmp13.Invoke_O__O(tmp14); if linked_3106 == nil { return ifn_3107.Invoke_O_O__O(arg_3108, arg_3109) } else { return linked_3106.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3105, arg_3108, arg_3109) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :486:1
func A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A) Ctor_O_I_O(c__b__711000407 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000407 = c__b__711000407; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :486:1
func (t *A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A) Invoke_O__O(self any) any { { var i__711000406__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000406__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000406__1)); var root_3060 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3060, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3062 lang.IFn; if linked_3061 == nil { ifn_3062 = lang.IFn_Cast(root_3060) } else { ifn_3062 = nil }; var arg_3063 any = t.F_b__711000407; var arg_3064 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_334; var tmp4 any; var root_3065 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3065, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3067 lang.IFn; if linked_3066 == nil { ifn_3067 = lang.IFn_Cast(root_3065) } else { ifn_3067 = nil }; var arg_3068 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp6 any; var root_3069 any = A_arbace_j2g_dyn_A_const_48.GetRawRoot__O(); var linked_3070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3069, aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A_fn_class); var ifn_3071 lang.IFn; if linked_3070 == nil { ifn_3071 = lang.IFn_Cast(root_3069) } else { ifn_3071 = nil }; var arg_3072 any = j__2; if linked_3070 == nil { tmp6 = ifn_3071.Invoke_O__O(arg_3072) } else { tmp6 = linked_3070.(*aot_arbace_j2g_model.A_arbace_j2g_model_go_name_A).Invoke_O_O__O(root_3069, arg_3072) }; arg_3068 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6)).Ref(); if linked_3066 == nil { tmp4 = ifn_3067.Invoke_O__O(arg_3068) } else { tmp4 = linked_3066.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3065, arg_3068) }; var tmp7 any = tmp4; var tmp8 any; var root_3073 any = A_arbace_j2g_dyn_A_const_134.GetRawRoot__O(); var linked_3074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3073, A_arbace_j2g_dyn_tag_A_fn_class); var ifn_3075 lang.IFn; if linked_3074 == nil { ifn_3075 = lang.IFn_Cast(root_3073) } else { ifn_3075 = nil }; var arg_3076 any = A_arbace_j2g_dyn_A_const_335; var arg_3077 any = A_arbace_j2g_dyn_A_const_336; if linked_3074 == nil { tmp8 = ifn_3075.Invoke_O_O__O(arg_3076, arg_3077) } else { tmp8 = linked_3074.(*A_arbace_j2g_dyn_tag_A).Invoke_O_O_O__O(root_3073, arg_3076, arg_3077) }; arg_3064 = tmp2.Invoke_O_O_O__O(tmp3, tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8)); if linked_3061 == nil { ifn_3062.Invoke_O_O__O(arg_3063, arg_3064) } else { linked_3061.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3060, arg_3063, arg_3064) }; i__711000406__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000406__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_dyn_forms_fn__711000414_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000414_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000414_A{}; t.Ctor_O_O(p0, p1); return t }
//line :489:1
func (t *A_arbace_j2g_dyn_forms_fn__711000414_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :489:1
func (t *A_arbace_j2g_dyn_forms_fn__711000414_A) Invoke_O_O__O(self, i__1 any) any { var root_3138 any = A_arbace_j2g_dyn_A_const_157.GetRawRoot__O(); var linked_3139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3138, A_arbace_j2g_dyn_method_form_A_fn_class); var ifn_3140 lang.IFn; if linked_3139 == nil { ifn_3140 = lang.IFn_Cast(root_3138) } else { ifn_3140 = nil }; var arg_3141 any = t.F_ifaces; var arg_3142 any = i__1; var tmp1 any = t.F_ks; var arg_3143 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(i__1)); if linked_3139 == nil { return ifn_3140.Invoke_O_O_O__O(arg_3141, arg_3142, arg_3143) } else { return linked_3139.(*A_arbace_j2g_dyn_method_form_A).Invoke_O_O_O_O__O(root_3138, arg_3141, arg_3142, arg_3143) } }







































































































































































































func A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_New() *A_arbace_j2g_dyn_forms_iter__711000416__711000420_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000416__711000420_A{}; t.Ctor(); return t }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_A) Ctor() {}
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_A) Invoke_O_O__O(self, s__711000417__1 any) any { var tmp1 any = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_New_O_O(self, s__711000417__1); var tmp2 *jrt.Class; var fncls__3599 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_fn_class; if fncls__3599 == nil { var fncls__3599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_fn_class = fncls__3599d; tmp2 = fncls__3599d } else { tmp2 = fncls__3599 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :689:1
func A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A{}; t.Ctor_O_O(p0, p1); return t }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A) Ctor_O_O(c__iter__711000416, c__s__711000417 any) { t.F_iter__711000416 = c__iter__711000416; t.F_s__711000417 = c__s__711000417 }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A) Invoke_O__O(self any) any { { var s__711000417__1 any; var t_ any = t.F_s__711000417; t.F_s__711000417 = nil; s__711000417__1 = t_; for { var temp__1927000414__auto____2 any; var root_3482 any = A_arbace_j2g_dyn_A_const_18.GetRawRoot__O(); var linked_3483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3482, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3484 lang.IFn; if linked_3483 == nil { ifn_3484 = lang.IFn_Cast(root_3482) } else { ifn_3484 = nil }; var arg_3485 any = s__711000417__1; if linked_3483 == nil { temp__1927000414__auto____2 = ifn_3484.Invoke_O__O(arg_3485) } else { temp__1927000414__auto____2 = linked_3483.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3482, arg_3485) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__711000417__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3486 any = A_arbace_j2g_dyn_A_const_19.GetRawRoot__O(); var linked_3487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3486, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3488 lang.IFn; if linked_3487 == nil { ifn_3488 = lang.IFn_Cast(root_3486) } else { ifn_3488 = nil }; var arg_3489 any = s__711000417__3; if linked_3487 == nil { tmp1 = ifn_3488.Invoke_O__O(arg_3489) } else { tmp1 = linked_3487.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3486, arg_3489) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3490 any = A_arbace_j2g_dyn_A_const_20.GetRawRoot__O(); var linked_3491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3490, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3492 lang.IFn; if linked_3491 == nil { ifn_3492 = lang.IFn_Cast(root_3490) } else { ifn_3492 = nil }; var arg_3493 any = s__711000417__3; if linked_3491 == nil { c__1927001037__auto____4 = ifn_3492.Invoke_O__O(arg_3493) } else { c__1927001037__auto____4 = linked_3491.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3490, arg_3493) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__711000419__6 any; var root_3494 any = A_arbace_j2g_dyn_A_const_21.GetRawRoot__O(); var linked_3495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3494, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3496 lang.IFn; if linked_3495 == nil { ifn_3496 = lang.IFn_Cast(root_3494) } else { ifn_3496 = nil }; var arg_3497 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3495 == nil { b__711000419__6 = ifn_3496.Invoke_O__O(arg_3497) } else { b__711000419__6 = linked_3495.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3494, arg_3497) }; var tmp2 any = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_New_O_I_O(b__711000419__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3533 *jrt.Class = A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_fn_class; if fncls__3533 == nil { var fncls__3533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_fn_class = fncls__3533d; tmp3 = fncls__3533d } else { tmp3 = fncls__3533 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3534 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3534, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3536 lang.IFn; if linked_3535 == nil { ifn_3536 = lang.IFn_Cast(root_3534) } else { ifn_3536 = nil }; var arg_3537 any; var root_3539 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3539, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3541 lang.IFn; if linked_3540 == nil { ifn_3541 = lang.IFn_Cast(root_3539) } else { ifn_3541 = nil }; var arg_3542 any = b__711000419__6; if linked_3540 == nil { arg_3537 = ifn_3541.Invoke_O__O(arg_3542) } else { arg_3537 = linked_3540.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3539, arg_3542) }; var arg_3538 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__711000416); var tmp5 any; var root_3543 any = A_arbace_j2g_dyn_A_const_25.GetRawRoot__O(); var linked_3544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3543, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3545 lang.IFn; if linked_3544 == nil { ifn_3545 = lang.IFn_Cast(root_3543) } else { ifn_3545 = nil }; var arg_3546 any = s__711000417__3; if linked_3544 == nil { tmp5 = ifn_3545.Invoke_O__O(arg_3546) } else { tmp5 = linked_3544.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3543, arg_3546) }; arg_3538 = tmp4.Invoke_O__O(tmp5); if linked_3535 == nil { return ifn_3536.Invoke_O_O__O(arg_3537, arg_3538) } else { return linked_3535.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3534, arg_3537, arg_3538) } } else { var root_3547 any = A_arbace_j2g_dyn_A_const_23.GetRawRoot__O(); var linked_3548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3547, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3549 lang.IFn; if linked_3548 == nil { ifn_3549 = lang.IFn_Cast(root_3547) } else { ifn_3549 = nil }; var arg_3550 any; var root_3552 any = A_arbace_j2g_dyn_A_const_24.GetRawRoot__O(); var linked_3553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3552, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3554 lang.IFn; if linked_3553 == nil { ifn_3554 = lang.IFn_Cast(root_3552) } else { ifn_3554 = nil }; var arg_3555 any = b__711000419__6; if linked_3553 == nil { arg_3550 = ifn_3554.Invoke_O__O(arg_3555) } else { arg_3550 = linked_3553.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3552, arg_3555) }; var arg_3551 any; if linked_3548 == nil { return ifn_3549.Invoke_O_O__O(arg_3550, arg_3551) } else { return linked_3548.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3547, arg_3550, arg_3551) } } } else { var p__4 any; var root_3556 any = A_arbace_j2g_dyn_A_const_26.GetRawRoot__O(); var linked_3557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3556, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3558 lang.IFn; if linked_3557 == nil { ifn_3558 = lang.IFn_Cast(root_3556) } else { ifn_3558 = nil }; var arg_3559 any = s__711000417__3; if linked_3557 == nil { p__4 = ifn_3558.Invoke_O__O(arg_3559) } else { p__4 = linked_3557.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3556, arg_3559) }; var root_3560 any = A_arbace_j2g_dyn_A_const_27.GetRawRoot__O(); var linked_3561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3560, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3562 lang.IFn; if linked_3561 == nil { ifn_3562 = lang.IFn_Cast(root_3560) } else { ifn_3562 = nil }; var arg_3563 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_474; var tmp8 any; var root_3565 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3565, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3567 lang.IFn
													if linked_3566 == nil { ifn_3567 = lang.IFn_Cast(root_3565) } else { ifn_3567 = nil }; var arg_3568 any = A_arbace_j2g_dyn_A_const_73; var arg_3569 any = p__4; var arg_3570 any = Lit_23; if linked_3566 == nil { tmp8 = ifn_3567.Invoke_O_O_O__O(arg_3568, arg_3569, arg_3570) } else { tmp8 = linked_3566.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3565, arg_3568, arg_3569, arg_3570) }; var tmp9 any = lang.Tuple_Create_O__IPersistentVector(tmp8); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_dyn_A_const_475; var tmp12 any; var root_3571 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3571, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3573 lang.IFn
													if linked_3572 == nil { ifn_3573 = lang.IFn_Cast(root_3571) } else { ifn_3573 = nil }; var arg_3574 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_93, nil); var tmp14 any; var root_3575 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3575, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3577 lang.IFn; if linked_3576 == nil { ifn_3577 = lang.IFn_Cast(root_3575) } else { ifn_3577 = nil }; var arg_3578 any = p__4; if linked_3576 == nil { tmp14 = ifn_3577.Invoke_O__O(arg_3578) } else { tmp14 = linked_3576.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3575, arg_3578) }; arg_3574 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3572 == nil { tmp12 = ifn_3573.Invoke_O__O(arg_3574) } else { tmp12 = linked_3572.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3571, arg_3574) }
//line :690:1
	var tmp15 any = tmp12; var tmp16 any; var root_3579 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3579, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3581 lang.IFn
	if linked_3580 == nil { ifn_3581 = lang.IFn_Cast(root_3579) } else { ifn_3581 = nil }; var arg_3582 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp18 any; var root_3583 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3583, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3585 lang.IFn; if linked_3584 == nil { ifn_3585 = lang.IFn_Cast(root_3583) } else { ifn_3585 = nil }; var arg_3586 any = p__4; if linked_3584 == nil { tmp18 = ifn_3585.Invoke_O__O(arg_3586) } else { tmp18 = linked_3584.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3583, arg_3586) }; arg_3582 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3580 == nil { tmp16 = ifn_3581.Invoke_O__O(arg_3582) } else { tmp16 = linked_3580.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3579, arg_3582) }
//line :690:1
	var tmp19 any = tmp16; var tmp20 any; var root_3587 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3587, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3589 lang.IFn

	if linked_3588 == nil { ifn_3589 = lang.IFn_Cast(root_3587) } else { ifn_3589 = nil }; var arg_3590 any; var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_94, nil); var tmp22 any; var root_3591 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3591, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3593 lang.IFn; if linked_3592 == nil { ifn_3593 = lang.IFn_Cast(root_3591) } else { ifn_3593 = nil }; var arg_3594 any = p__4; if linked_3592 == nil { tmp22 = ifn_3593.Invoke_O__O(arg_3594) } else { tmp22 = linked_3592.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3591, arg_3594) }; arg_3590 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref(); if linked_3588 == nil { tmp20 = ifn_3589.Invoke_O__O(arg_3590) } else { tmp20 = linked_3588.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3587, arg_3590) }
//line :690:1
	arg_3563 = tmp6.Invoke_O_O_O__O(tmp7, tmp9, tmp10.Invoke_O_O_O_O__O(tmp11, tmp15, tmp19, tmp20))
//line :689:1
	var arg_3564 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__711000416); var tmp24 any; var root_3595 any = A_arbace_j2g_dyn_A_const_28.GetRawRoot__O(); var linked_3596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3595, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3597 lang.IFn; if linked_3596 == nil { ifn_3597 = lang.IFn_Cast(root_3595) } else { ifn_3597 = nil }; var arg_3598 any = s__711000417__3; if linked_3596 == nil { tmp24 = ifn_3597.Invoke_O__O(arg_3598) } else { tmp24 = linked_3596.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3595, arg_3598) }; arg_3564 = tmp23.Invoke_O__O(tmp24); if linked_3561 == nil { return ifn_3562.Invoke_O_O__O(arg_3563, arg_3564) } else { return linked_3561.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3560, arg_3563, arg_3564) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :689:1
func A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A) Ctor_O_I_O(c__b__711000419 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__711000419 = c__b__711000419; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :689:1
func (t *A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A) Invoke_O__O(self any) any { { var i__711000418__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__711000418__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__711000418__1)); var root_3498 any = A_arbace_j2g_dyn_A_const_22.GetRawRoot__O(); var linked_3499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3498, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3500 lang.IFn; if linked_3499 == nil { ifn_3500 = lang.IFn_Cast(root_3498) } else { ifn_3500 = nil }; var arg_3501 any = t.F_b__711000419; var arg_3502 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_dyn_A_const_474; var tmp4 any; var root_3503 any = A_arbace_j2g_dyn_A_const_72.GetRawRoot__O(); var linked_3504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3503, aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A_fn_class); var ifn_3505 lang.IFn
															if linked_3504 == nil { ifn_3505 = lang.IFn_Cast(root_3503) } else { ifn_3505 = nil }; var arg_3506 any = A_arbace_j2g_dyn_A_const_73; var arg_3507 any = p__2; var arg_3508 any = Lit_23; if linked_3504 == nil { tmp4 = ifn_3505.Invoke_O_O_O__O(arg_3506, arg_3507, arg_3508) } else { tmp4 = linked_3504.(*aot_arbace_j2g_model.A_arbace_j2g_model_class_sym_A).Invoke_O_O_O_O__O(root_3503, arg_3506, arg_3507, arg_3508) }; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_dyn_A_const_79.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_dyn_A_const_475; var tmp8 any; var root_3509 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3509, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3511 lang.IFn
															if linked_3510 == nil { ifn_3511 = lang.IFn_Cast(root_3509) } else { ifn_3511 = nil }; var arg_3512 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_93, nil); var tmp10 any; var root_3513 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3513, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3515 lang.IFn; if linked_3514 == nil { ifn_3515 = lang.IFn_Cast(root_3513) } else { ifn_3515 = nil }; var arg_3516 any = p__2; if linked_3514 == nil { tmp10 = ifn_3515.Invoke_O__O(arg_3516) } else { tmp10 = linked_3514.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3513, arg_3516) }; arg_3512 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(); if linked_3510 == nil { tmp8 = ifn_3511.Invoke_O__O(arg_3512) } else { tmp8 = linked_3510.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3509, arg_3512) }
//line :690:1
	var tmp11 any = tmp8; var tmp12 any; var root_3517 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3517, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3519 lang.IFn
	if linked_3518 == nil { ifn_3519 = lang.IFn_Cast(root_3517) } else { ifn_3519 = nil }; var arg_3520 any; var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_25, nil); var tmp14 any; var root_3521 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3521, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3523 lang.IFn; if linked_3522 == nil { ifn_3523 = lang.IFn_Cast(root_3521) } else { ifn_3523 = nil }; var arg_3524 any = p__2; if linked_3522 == nil { tmp14 = ifn_3523.Invoke_O__O(arg_3524) } else { tmp14 = linked_3522.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3521, arg_3524) }; arg_3520 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref(); if linked_3518 == nil { tmp12 = ifn_3519.Invoke_O__O(arg_3520) } else { tmp12 = linked_3518.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3517, arg_3520) }
//line :690:1
	var tmp15 any = tmp12; var tmp16 any; var root_3525 any = A_arbace_j2g_dyn_A_const_93.GetRawRoot__O(); var linked_3526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3525, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_3527 lang.IFn

	if linked_3526 == nil { ifn_3527 = lang.IFn_Cast(root_3525) } else { ifn_3527 = nil }; var arg_3528 any; var tmp17 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_94, nil); var tmp18 any; var root_3529 any = A_arbace_j2g_dyn_A_const_187.GetRawRoot__O(); var linked_3530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3529, A_arbace_j2g_dyn_sub_name_A_fn_class); var ifn_3531 lang.IFn; if linked_3530 == nil { ifn_3531 = lang.IFn_Cast(root_3529) } else { ifn_3531 = nil }; var arg_3532 any = p__2; if linked_3530 == nil { tmp18 = ifn_3531.Invoke_O__O(arg_3532) } else { tmp18 = linked_3530.(*A_arbace_j2g_dyn_sub_name_A).Invoke_O_O__O(root_3529, arg_3532) }; arg_3528 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp18)).Ref(); if linked_3526 == nil { tmp16 = ifn_3527.Invoke_O__O(arg_3528) } else { tmp16 = linked_3526.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_3525, arg_3528) }
//line :690:1
	arg_3502 = tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, tmp11, tmp15, tmp16))
//line :689:1
	if linked_3499 == nil { ifn_3500.Invoke_O_O__O(arg_3501, arg_3502) } else { linked_3499.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3498, arg_3501, arg_3502) }; i__711000418__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__711000418__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









































func A_arbace_j2g_dyn_forms_fn__711000426_A_New_O_O(p0, p1 any) *A_arbace_j2g_dyn_forms_fn__711000426_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_forms_fn__711000426_A{}; t.Ctor_O_O(p0, p1); return t }
//line :731:1
func (t *A_arbace_j2g_dyn_forms_fn__711000426_A) Ctor_O_O(c__ks, c__ifaces any) { t.F_ks = c__ks; t.F_ifaces = c__ifaces }
//line :731:1
func (t *A_arbace_j2g_dyn_forms_fn__711000426_A) Invoke_O_O__O(self, p1__711000381_SHARP___1 any) any { var root_3653 any = A_arbace_j2g_dyn_A_const_505.GetRawRoot__O(); var linked_3654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3653, A_arbace_j2g_dyn_sub_forms_A_fn_class); var ifn_3655 lang.IFn; if linked_3654 == nil { ifn_3655 = lang.IFn_Cast(root_3653) } else { ifn_3655 = nil }; var arg_3656 any = p1__711000381_SHARP___1; var arg_3657 any = t.F_ifaces; var arg_3658 any = t.F_ks; if linked_3654 == nil { return ifn_3655.Invoke_O_O_O__O(arg_3656, arg_3657, arg_3658) } else { return linked_3654.(*A_arbace_j2g_dyn_sub_forms_A).Invoke_O_O_O_O__O(root_3653, arg_3656, arg_3657, arg_3658) } }










































type A_arbace_j2g_dyn_A struct{ jrt.Object }

var A_arbace_j2g_dyn_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyn_A_const_0 *lang.Var

var A_arbace_j2g_dyn_A_const_1 any

var A_arbace_j2g_dyn_A_const_2 any

var A_arbace_j2g_dyn_A_const_3 any

var A_arbace_j2g_dyn_A_const_4 any

var A_arbace_j2g_dyn_A_const_5 any

var A_arbace_j2g_dyn_A_const_6 any

var A_arbace_j2g_dyn_A_const_7 any

var A_arbace_j2g_dyn_A_const_8 any

var A_arbace_j2g_dyn_A_const_9 *lang.Var

var A_arbace_j2g_dyn_A_const_10 any

var A_arbace_j2g_dyn_A_const_11 *lang.Var

var A_arbace_j2g_dyn_A_const_12 *lang.Var

var A_arbace_j2g_dyn_A_const_13 *lang.Var

var A_arbace_j2g_dyn_A_const_14 *lang.Var

var A_arbace_j2g_dyn_A_const_15 any

var A_arbace_j2g_dyn_A_const_16 *lang.Var

var A_arbace_j2g_dyn_A_const_17 *lang.Keyword

var A_arbace_j2g_dyn_A_const_18 *lang.Var

var A_arbace_j2g_dyn_A_const_19 *lang.Var

var A_arbace_j2g_dyn_A_const_20 *lang.Var

var A_arbace_j2g_dyn_A_const_21 *lang.Var

var A_arbace_j2g_dyn_A_const_22 *lang.Var

var A_arbace_j2g_dyn_A_const_23 *lang.Var

var A_arbace_j2g_dyn_A_const_24 *lang.Var

var A_arbace_j2g_dyn_A_const_25 *lang.Var

var A_arbace_j2g_dyn_A_const_26 *lang.Var

var A_arbace_j2g_dyn_A_const_27 *lang.Var

var A_arbace_j2g_dyn_A_const_28 *lang.Var

var A_arbace_j2g_dyn_A_const_29 *lang.Var

var A_arbace_j2g_dyn_A_const_30 *lang.Var

var A_arbace_j2g_dyn_A_const_31 *lang.Var

var A_arbace_j2g_dyn_A_const_32 *lang.Var

var A_arbace_j2g_dyn_A_const_33 *lang.Keyword

var A_arbace_j2g_dyn_A_const_34 *lang.Var

var A_arbace_j2g_dyn_A_const_35 *lang.Var

var A_arbace_j2g_dyn_A_const_36 *lang.Var

var A_arbace_j2g_dyn_A_const_37 *lang.Var

var A_arbace_j2g_dyn_A_const_38 *lang.Var

var A_arbace_j2g_dyn_A_const_39 *lang.Var

var A_arbace_j2g_dyn_A_const_40 *lang.Var

var A_arbace_j2g_dyn_A_const_41 *lang.Var

var A_arbace_j2g_dyn_A_const_42 *lang.Var

var A_arbace_j2g_dyn_A_const_43 *lang.Var

var A_arbace_j2g_dyn_A_const_44 *lang.Var

var A_arbace_j2g_dyn_A_const_45 *lang.Keyword

var A_arbace_j2g_dyn_A_const_46 *lang.Keyword

var A_arbace_j2g_dyn_A_const_47 *lang.Var

var A_arbace_j2g_dyn_A_const_48 *lang.Var

var A_arbace_j2g_dyn_A_const_49 *lang.Var

var A_arbace_j2g_dyn_A_const_50 *lang.Var

var A_arbace_j2g_dyn_A_const_51 *lang.Keyword

var A_arbace_j2g_dyn_A_const_52 *lang.Var

var A_arbace_j2g_dyn_A_const_53 *lang.Var

var A_arbace_j2g_dyn_A_const_54 *lang.Var

var A_arbace_j2g_dyn_A_const_55 *lang.Var

var A_arbace_j2g_dyn_A_const_56 *lang.Var

var A_arbace_j2g_dyn_A_const_57 *lang.Var

var A_arbace_j2g_dyn_A_const_58 *lang.Var

var A_arbace_j2g_dyn_A_const_59 *lang.Var

var A_arbace_j2g_dyn_A_const_60 *lang.Var

var A_arbace_j2g_dyn_A_const_61 *lang.Var

var A_arbace_j2g_dyn_A_const_62 *lang.Var

var A_arbace_j2g_dyn_A_const_63 *lang.Var

var A_arbace_j2g_dyn_A_const_64 *lang.Keyword

var A_arbace_j2g_dyn_A_const_65 *lang.Keyword

var A_arbace_j2g_dyn_A_const_66 *lang.Var

var A_arbace_j2g_dyn_A_const_67 *lang.Var

var A_arbace_j2g_dyn_A_const_68 *lang.Var

var A_arbace_j2g_dyn_A_const_69 *lang.Keyword

var A_arbace_j2g_dyn_A_const_70 *lang.Keyword

var A_arbace_j2g_dyn_A_const_71 *lang.Keyword

var A_arbace_j2g_dyn_A_const_72 *lang.Var

var A_arbace_j2g_dyn_A_const_73 *lang.Keyword

var A_arbace_j2g_dyn_A_const_74 *lang.Var

var A_arbace_j2g_dyn_A_const_75 *lang.Var

var A_arbace_j2g_dyn_A_const_76 *lang.Var

var A_arbace_j2g_dyn_A_const_77 *lang.Var

var A_arbace_j2g_dyn_A_const_78 *lang.Var

var A_arbace_j2g_dyn_A_const_79 *lang.Var

var A_arbace_j2g_dyn_A_const_80 *lang.Var

var A_arbace_j2g_dyn_A_const_81 *lang.Keyword

var A_arbace_j2g_dyn_A_const_82 any

var A_arbace_j2g_dyn_A_const_83 any

var A_arbace_j2g_dyn_A_const_84 any

var A_arbace_j2g_dyn_A_const_85 *lang.Var

var A_arbace_j2g_dyn_A_const_86 any

var A_arbace_j2g_dyn_A_const_87 *lang.Var

var A_arbace_j2g_dyn_A_const_88 any

var A_arbace_j2g_dyn_A_const_89 any

var A_arbace_j2g_dyn_A_const_90 any

var A_arbace_j2g_dyn_A_const_91 *lang.Var

var A_arbace_j2g_dyn_A_const_92 any

var A_arbace_j2g_dyn_A_const_93 *lang.Var

var A_arbace_j2g_dyn_A_const_94 *lang.Var

var A_arbace_j2g_dyn_A_const_95 *lang.Var

var A_arbace_j2g_dyn_A_const_96 *lang.Var

var A_arbace_j2g_dyn_A_const_97 any

var A_arbace_j2g_dyn_A_const_98 any

var A_arbace_j2g_dyn_A_const_99 *lang.Var

var A_arbace_j2g_dyn_A_const_100 *lang.Var

var A_arbace_j2g_dyn_A_const_101 *lang.Var

var A_arbace_j2g_dyn_A_const_102 any

var A_arbace_j2g_dyn_A_const_103 any

var A_arbace_j2g_dyn_A_const_104 any

var A_arbace_j2g_dyn_A_const_105 any

var A_arbace_j2g_dyn_A_const_106 any

var A_arbace_j2g_dyn_A_const_107 any

var A_arbace_j2g_dyn_A_const_108 *lang.Var

var A_arbace_j2g_dyn_A_const_109 any

var A_arbace_j2g_dyn_A_const_110 *lang.Var

var A_arbace_j2g_dyn_A_const_111 *lang.Var

var A_arbace_j2g_dyn_A_const_112 *lang.Keyword

var A_arbace_j2g_dyn_A_const_113 *lang.Var

var A_arbace_j2g_dyn_A_const_114 *lang.Var

var A_arbace_j2g_dyn_A_const_115 *lang.Var

var A_arbace_j2g_dyn_A_const_116 *lang.Var

var A_arbace_j2g_dyn_A_const_117 *lang.Var

var A_arbace_j2g_dyn_A_const_118 any

var A_arbace_j2g_dyn_A_const_119 any

var A_arbace_j2g_dyn_A_const_120 any

var A_arbace_j2g_dyn_A_const_121 any

var A_arbace_j2g_dyn_A_const_122 any

var A_arbace_j2g_dyn_A_const_123 any

var A_arbace_j2g_dyn_A_const_124 any

var A_arbace_j2g_dyn_A_const_125 any

var A_arbace_j2g_dyn_A_const_126 any

var A_arbace_j2g_dyn_A_const_127 *lang.Var

var A_arbace_j2g_dyn_A_const_128 any

var A_arbace_j2g_dyn_A_const_129 any

var A_arbace_j2g_dyn_A_const_130 any

var A_arbace_j2g_dyn_A_const_131 *lang.Var

var A_arbace_j2g_dyn_A_const_132 *lang.Var

var A_arbace_j2g_dyn_A_const_133 *lang.Var

var A_arbace_j2g_dyn_A_const_134 *lang.Var

var A_arbace_j2g_dyn_A_const_135 any

var A_arbace_j2g_dyn_A_const_136 *lang.Var

var A_arbace_j2g_dyn_A_const_137 any

var A_arbace_j2g_dyn_A_const_138 any

var A_arbace_j2g_dyn_A_const_139 any

var A_arbace_j2g_dyn_A_const_140 any

var A_arbace_j2g_dyn_A_const_141 any

var A_arbace_j2g_dyn_A_const_142 any

var A_arbace_j2g_dyn_A_const_143 any

var A_arbace_j2g_dyn_A_const_144 any

var A_arbace_j2g_dyn_A_const_145 any

var A_arbace_j2g_dyn_A_const_146 any

var A_arbace_j2g_dyn_A_const_147 any

var A_arbace_j2g_dyn_A_const_148 any

var A_arbace_j2g_dyn_A_const_149 any

var A_arbace_j2g_dyn_A_const_150 any

var A_arbace_j2g_dyn_A_const_151 any

var A_arbace_j2g_dyn_A_const_152 any

var A_arbace_j2g_dyn_A_const_153 any

var A_arbace_j2g_dyn_A_const_154 any

var A_arbace_j2g_dyn_A_const_155 *lang.Var

var A_arbace_j2g_dyn_A_const_156 any

var A_arbace_j2g_dyn_A_const_157 *lang.Var

var A_arbace_j2g_dyn_A_const_158 any

var A_arbace_j2g_dyn_A_const_159 any

var A_arbace_j2g_dyn_A_const_160 any

var A_arbace_j2g_dyn_A_const_161 *lang.Var

var A_arbace_j2g_dyn_A_const_162 *lang.Var

var A_arbace_j2g_dyn_A_const_163 *lang.Var

var A_arbace_j2g_dyn_A_const_164 *lang.Var

var A_arbace_j2g_dyn_A_const_165 *lang.Var

var A_arbace_j2g_dyn_A_const_166 *lang.Var

var A_arbace_j2g_dyn_A_const_167 any

var A_arbace_j2g_dyn_A_const_168 any

var A_arbace_j2g_dyn_A_const_169 any

var A_arbace_j2g_dyn_A_const_170 any

var A_arbace_j2g_dyn_A_const_171 any

var A_arbace_j2g_dyn_A_const_172 any

var A_arbace_j2g_dyn_A_const_173 any

var A_arbace_j2g_dyn_A_const_174 any

var A_arbace_j2g_dyn_A_const_175 any

var A_arbace_j2g_dyn_A_const_176 any

var A_arbace_j2g_dyn_A_const_177 *lang.Keyword

var A_arbace_j2g_dyn_A_const_178 *lang.Keyword

var A_arbace_j2g_dyn_A_const_179 *lang.Keyword

var A_arbace_j2g_dyn_A_const_180 any

var A_arbace_j2g_dyn_A_const_181 any

var A_arbace_j2g_dyn_A_const_182 any

var A_arbace_j2g_dyn_A_const_183 any

var A_arbace_j2g_dyn_A_const_184 any

var A_arbace_j2g_dyn_A_const_185 any

var A_arbace_j2g_dyn_A_const_186 any

var A_arbace_j2g_dyn_A_const_187 *lang.Var

var A_arbace_j2g_dyn_A_const_188 any

var A_arbace_j2g_dyn_A_const_189 any

var A_arbace_j2g_dyn_A_const_190 any

var A_arbace_j2g_dyn_A_const_191 *lang.Var

var A_arbace_j2g_dyn_A_const_192 *lang.Var

var A_arbace_j2g_dyn_A_const_193 *lang.Var

var A_arbace_j2g_dyn_A_const_194 *lang.Var

var A_arbace_j2g_dyn_A_const_195 any

var A_arbace_j2g_dyn_A_const_196 any

var A_arbace_j2g_dyn_A_const_197 any

var A_arbace_j2g_dyn_A_const_198 any

var A_arbace_j2g_dyn_A_const_199 any

var A_arbace_j2g_dyn_A_const_200 any

var A_arbace_j2g_dyn_A_const_201 any

var A_arbace_j2g_dyn_A_const_202 any

var A_arbace_j2g_dyn_A_const_203 *lang.Var

var A_arbace_j2g_dyn_A_const_204 *lang.Var

var A_arbace_j2g_dyn_A_const_205 *lang.Var

var A_arbace_j2g_dyn_A_const_206 *lang.Var

var A_arbace_j2g_dyn_A_const_207 any

var A_arbace_j2g_dyn_A_const_208 any

var A_arbace_j2g_dyn_A_const_209 *lang.Keyword

var A_arbace_j2g_dyn_A_const_210 any

var A_arbace_j2g_dyn_A_const_211 any

var A_arbace_j2g_dyn_A_const_212 *lang.Var

var A_arbace_j2g_dyn_A_const_213 *lang.Keyword

var A_arbace_j2g_dyn_A_const_214 any

var A_arbace_j2g_dyn_A_const_215 *lang.Keyword

var A_arbace_j2g_dyn_A_const_216 *lang.Var

var A_arbace_j2g_dyn_A_const_217 any

var A_arbace_j2g_dyn_A_const_218 any

var A_arbace_j2g_dyn_A_const_219 any

var A_arbace_j2g_dyn_A_const_220 any

var A_arbace_j2g_dyn_A_const_221 *lang.Var

var A_arbace_j2g_dyn_A_const_222 any

var A_arbace_j2g_dyn_A_const_223 any

var A_arbace_j2g_dyn_A_const_224 any

var A_arbace_j2g_dyn_A_const_225 any

var A_arbace_j2g_dyn_A_const_226 any

var A_arbace_j2g_dyn_A_const_227 *lang.Var

var A_arbace_j2g_dyn_A_const_228 any

var A_arbace_j2g_dyn_A_const_229 any

var A_arbace_j2g_dyn_A_const_230 any

var A_arbace_j2g_dyn_A_const_231 any

var A_arbace_j2g_dyn_A_const_232 any

var A_arbace_j2g_dyn_A_const_233 any

var A_arbace_j2g_dyn_A_const_234 *lang.Keyword

var A_arbace_j2g_dyn_A_const_235 any

var A_arbace_j2g_dyn_A_const_236 any

var A_arbace_j2g_dyn_A_const_237 *lang.Var

var A_arbace_j2g_dyn_A_const_238 *lang.Var

var A_arbace_j2g_dyn_A_const_239 *lang.Var

var A_arbace_j2g_dyn_A_const_240 *lang.Var

var A_arbace_j2g_dyn_A_const_241 any

var A_arbace_j2g_dyn_A_const_242 any

var A_arbace_j2g_dyn_A_const_243 any

var A_arbace_j2g_dyn_A_const_244 any

var A_arbace_j2g_dyn_A_const_245 any

var A_arbace_j2g_dyn_A_const_246 any

var A_arbace_j2g_dyn_A_const_247 any

var A_arbace_j2g_dyn_A_const_248 any

var A_arbace_j2g_dyn_A_const_249 any

var A_arbace_j2g_dyn_A_const_250 any

var A_arbace_j2g_dyn_A_const_251 any

var A_arbace_j2g_dyn_A_const_252 any

var A_arbace_j2g_dyn_A_const_253 any

var A_arbace_j2g_dyn_A_const_254 any

var A_arbace_j2g_dyn_A_const_255 any

var A_arbace_j2g_dyn_A_const_256 any

var A_arbace_j2g_dyn_A_const_257 any

var A_arbace_j2g_dyn_A_const_258 any

var A_arbace_j2g_dyn_A_const_259 any

var A_arbace_j2g_dyn_A_const_260 any

var A_arbace_j2g_dyn_A_const_261 any

var A_arbace_j2g_dyn_A_const_262 any

var A_arbace_j2g_dyn_A_const_263 any

var A_arbace_j2g_dyn_A_const_264 any

var A_arbace_j2g_dyn_A_const_265 any

var A_arbace_j2g_dyn_A_const_266 any

var A_arbace_j2g_dyn_A_const_267 any

var A_arbace_j2g_dyn_A_const_268 any

var A_arbace_j2g_dyn_A_const_269 any

var A_arbace_j2g_dyn_A_const_270 any

var A_arbace_j2g_dyn_A_const_271 any

var A_arbace_j2g_dyn_A_const_272 any

var A_arbace_j2g_dyn_A_const_273 any

var A_arbace_j2g_dyn_A_const_274 *lang.Var

var A_arbace_j2g_dyn_A_const_275 any

var A_arbace_j2g_dyn_A_const_276 any

var A_arbace_j2g_dyn_A_const_277 *lang.Var

var A_arbace_j2g_dyn_A_const_278 *lang.Var

var A_arbace_j2g_dyn_A_const_279 *lang.Var

var A_arbace_j2g_dyn_A_const_280 any

var A_arbace_j2g_dyn_A_const_281 any

var A_arbace_j2g_dyn_A_const_282 *lang.Var

var A_arbace_j2g_dyn_A_const_283 any

var A_arbace_j2g_dyn_A_const_284 any

var A_arbace_j2g_dyn_A_const_285 any

var A_arbace_j2g_dyn_A_const_286 any

var A_arbace_j2g_dyn_A_const_287 any

var A_arbace_j2g_dyn_A_const_288 any

var A_arbace_j2g_dyn_A_const_289 any

var A_arbace_j2g_dyn_A_const_290 any

var A_arbace_j2g_dyn_A_const_291 any

var A_arbace_j2g_dyn_A_const_292 *lang.Var

var A_arbace_j2g_dyn_A_const_293 *lang.Var

var A_arbace_j2g_dyn_A_const_294 any

var A_arbace_j2g_dyn_A_const_295 any

var A_arbace_j2g_dyn_A_const_296 any

var A_arbace_j2g_dyn_A_const_297 any

var A_arbace_j2g_dyn_A_const_298 any

var A_arbace_j2g_dyn_A_const_299 any

var A_arbace_j2g_dyn_A_const_300 any

var A_arbace_j2g_dyn_A_const_301 any

var A_arbace_j2g_dyn_A_const_302 any

var A_arbace_j2g_dyn_A_const_303 any

var A_arbace_j2g_dyn_A_const_304 any

var A_arbace_j2g_dyn_A_const_305 any

var A_arbace_j2g_dyn_A_const_306 any

var A_arbace_j2g_dyn_A_const_307 any

var A_arbace_j2g_dyn_A_const_308 any

var A_arbace_j2g_dyn_A_const_309 any

var A_arbace_j2g_dyn_A_const_310 any

var A_arbace_j2g_dyn_A_const_311 any

var A_arbace_j2g_dyn_A_const_312 any

var A_arbace_j2g_dyn_A_const_313 any

var A_arbace_j2g_dyn_A_const_314 any

var A_arbace_j2g_dyn_A_const_315 any

var A_arbace_j2g_dyn_A_const_316 any

var A_arbace_j2g_dyn_A_const_317 any

var A_arbace_j2g_dyn_A_const_318 any

var A_arbace_j2g_dyn_A_const_319 any

var A_arbace_j2g_dyn_A_const_320 any

var A_arbace_j2g_dyn_A_const_321 any

var A_arbace_j2g_dyn_A_const_322 any

var A_arbace_j2g_dyn_A_const_323 any

var A_arbace_j2g_dyn_A_const_324 any

var A_arbace_j2g_dyn_A_const_325 any

var A_arbace_j2g_dyn_A_const_326 any

var A_arbace_j2g_dyn_A_const_327 any

var A_arbace_j2g_dyn_A_const_328 any

var A_arbace_j2g_dyn_A_const_329 any

var A_arbace_j2g_dyn_A_const_330 any

var A_arbace_j2g_dyn_A_const_331 any

var A_arbace_j2g_dyn_A_const_332 any

var A_arbace_j2g_dyn_A_const_333 any

var A_arbace_j2g_dyn_A_const_334 any

var A_arbace_j2g_dyn_A_const_335 any

var A_arbace_j2g_dyn_A_const_336 any

var A_arbace_j2g_dyn_A_const_337 *lang.Var

var A_arbace_j2g_dyn_A_const_338 *lang.Var

var A_arbace_j2g_dyn_A_const_339 any

var A_arbace_j2g_dyn_A_const_340 any

var A_arbace_j2g_dyn_A_const_341 *lang.Var

var A_arbace_j2g_dyn_A_const_342 any

var A_arbace_j2g_dyn_A_const_343 any

var A_arbace_j2g_dyn_A_const_344 any

var A_arbace_j2g_dyn_A_const_345 *lang.Var

var A_arbace_j2g_dyn_A_const_346 any

var A_arbace_j2g_dyn_A_const_347 any

var A_arbace_j2g_dyn_A_const_348 any

var A_arbace_j2g_dyn_A_const_349 any

var A_arbace_j2g_dyn_A_const_350 any

var A_arbace_j2g_dyn_A_const_351 any

var A_arbace_j2g_dyn_A_const_352 any

var A_arbace_j2g_dyn_A_const_353 any

var A_arbace_j2g_dyn_A_const_354 any

var A_arbace_j2g_dyn_A_const_355 any

var A_arbace_j2g_dyn_A_const_356 any

var A_arbace_j2g_dyn_A_const_357 any

var A_arbace_j2g_dyn_A_const_358 any

var A_arbace_j2g_dyn_A_const_359 any

var A_arbace_j2g_dyn_A_const_360 any

var A_arbace_j2g_dyn_A_const_361 any

var A_arbace_j2g_dyn_A_const_362 any

var A_arbace_j2g_dyn_A_const_363 any

var A_arbace_j2g_dyn_A_const_364 any

var A_arbace_j2g_dyn_A_const_365 any

var A_arbace_j2g_dyn_A_const_366 *lang.Keyword

var A_arbace_j2g_dyn_A_const_367 *lang.Keyword

var A_arbace_j2g_dyn_A_const_368 any

var A_arbace_j2g_dyn_A_const_369 *lang.Keyword

var A_arbace_j2g_dyn_A_const_370 any

var A_arbace_j2g_dyn_A_const_371 *lang.Keyword

var A_arbace_j2g_dyn_A_const_372 any

var A_arbace_j2g_dyn_A_const_373 any

var A_arbace_j2g_dyn_A_const_374 any

var A_arbace_j2g_dyn_A_const_375 any

var A_arbace_j2g_dyn_A_const_376 any

var A_arbace_j2g_dyn_A_const_377 any

var A_arbace_j2g_dyn_A_const_378 any

var A_arbace_j2g_dyn_A_const_379 any

var A_arbace_j2g_dyn_A_const_380 any

var A_arbace_j2g_dyn_A_const_381 any

var A_arbace_j2g_dyn_A_const_382 any

var A_arbace_j2g_dyn_A_const_383 any

var A_arbace_j2g_dyn_A_const_384 any

var A_arbace_j2g_dyn_A_const_385 any

var A_arbace_j2g_dyn_A_const_386 any

var A_arbace_j2g_dyn_A_const_387 any

var A_arbace_j2g_dyn_A_const_388 any

var A_arbace_j2g_dyn_A_const_389 any

var A_arbace_j2g_dyn_A_const_390 any

var A_arbace_j2g_dyn_A_const_391 any

var A_arbace_j2g_dyn_A_const_392 any

var A_arbace_j2g_dyn_A_const_393 any

var A_arbace_j2g_dyn_A_const_394 any

var A_arbace_j2g_dyn_A_const_395 any

var A_arbace_j2g_dyn_A_const_396 any

var A_arbace_j2g_dyn_A_const_397 any

var A_arbace_j2g_dyn_A_const_398 any

var A_arbace_j2g_dyn_A_const_399 any

var A_arbace_j2g_dyn_A_const_400 any

var A_arbace_j2g_dyn_A_const_401 any

var A_arbace_j2g_dyn_A_const_402 any

var A_arbace_j2g_dyn_A_const_403 any

var A_arbace_j2g_dyn_A_const_404 any

var A_arbace_j2g_dyn_A_const_405 any

var A_arbace_j2g_dyn_A_const_406 any

var A_arbace_j2g_dyn_A_const_407 any

var A_arbace_j2g_dyn_A_const_408 any

var A_arbace_j2g_dyn_A_const_409 any

var A_arbace_j2g_dyn_A_const_410 any

var A_arbace_j2g_dyn_A_const_411 any

var A_arbace_j2g_dyn_A_const_412 any

var A_arbace_j2g_dyn_A_const_413 any

var A_arbace_j2g_dyn_A_const_414 any

var A_arbace_j2g_dyn_A_const_415 any

var A_arbace_j2g_dyn_A_const_416 any

var A_arbace_j2g_dyn_A_const_417 any

var A_arbace_j2g_dyn_A_const_418 any

var A_arbace_j2g_dyn_A_const_419 any

var A_arbace_j2g_dyn_A_const_420 any

var A_arbace_j2g_dyn_A_const_421 any

var A_arbace_j2g_dyn_A_const_422 any

var A_arbace_j2g_dyn_A_const_423 any

var A_arbace_j2g_dyn_A_const_424 any

var A_arbace_j2g_dyn_A_const_425 any

var A_arbace_j2g_dyn_A_const_426 any

var A_arbace_j2g_dyn_A_const_427 any

var A_arbace_j2g_dyn_A_const_428 any

var A_arbace_j2g_dyn_A_const_429 any

var A_arbace_j2g_dyn_A_const_430 any

var A_arbace_j2g_dyn_A_const_431 any

var A_arbace_j2g_dyn_A_const_432 any

var A_arbace_j2g_dyn_A_const_433 any

var A_arbace_j2g_dyn_A_const_434 any

var A_arbace_j2g_dyn_A_const_435 any

var A_arbace_j2g_dyn_A_const_436 any

var A_arbace_j2g_dyn_A_const_437 any

var A_arbace_j2g_dyn_A_const_438 any

var A_arbace_j2g_dyn_A_const_439 any

var A_arbace_j2g_dyn_A_const_440 any

var A_arbace_j2g_dyn_A_const_441 any

var A_arbace_j2g_dyn_A_const_442 any

var A_arbace_j2g_dyn_A_const_443 any

var A_arbace_j2g_dyn_A_const_444 any

var A_arbace_j2g_dyn_A_const_445 any

var A_arbace_j2g_dyn_A_const_446 any

var A_arbace_j2g_dyn_A_const_447 any

var A_arbace_j2g_dyn_A_const_448 any

var A_arbace_j2g_dyn_A_const_449 any

var A_arbace_j2g_dyn_A_const_450 any

var A_arbace_j2g_dyn_A_const_451 any

var A_arbace_j2g_dyn_A_const_452 any

var A_arbace_j2g_dyn_A_const_453 any

var A_arbace_j2g_dyn_A_const_454 any

var A_arbace_j2g_dyn_A_const_455 any

var A_arbace_j2g_dyn_A_const_456 any

var A_arbace_j2g_dyn_A_const_457 any

var A_arbace_j2g_dyn_A_const_458 any

var A_arbace_j2g_dyn_A_const_459 any

var A_arbace_j2g_dyn_A_const_460 any

var A_arbace_j2g_dyn_A_const_461 any

var A_arbace_j2g_dyn_A_const_462 any

var A_arbace_j2g_dyn_A_const_463 any

var A_arbace_j2g_dyn_A_const_464 any

var A_arbace_j2g_dyn_A_const_465 any

var A_arbace_j2g_dyn_A_const_466 any

var A_arbace_j2g_dyn_A_const_467 any

var A_arbace_j2g_dyn_A_const_468 any

var A_arbace_j2g_dyn_A_const_469 any

var A_arbace_j2g_dyn_A_const_470 *lang.Keyword

var A_arbace_j2g_dyn_A_const_471 any

var A_arbace_j2g_dyn_A_const_472 any

var A_arbace_j2g_dyn_A_const_473 any

var A_arbace_j2g_dyn_A_const_474 any

var A_arbace_j2g_dyn_A_const_475 any

var A_arbace_j2g_dyn_A_const_476 *lang.Var

var A_arbace_j2g_dyn_A_const_477 any

var A_arbace_j2g_dyn_A_const_478 any

var A_arbace_j2g_dyn_A_const_479 any

var A_arbace_j2g_dyn_A_const_480 any

var A_arbace_j2g_dyn_A_const_481 any

var A_arbace_j2g_dyn_A_const_482 any

var A_arbace_j2g_dyn_A_const_483 any

var A_arbace_j2g_dyn_A_const_484 any

var A_arbace_j2g_dyn_A_const_485 any

var A_arbace_j2g_dyn_A_const_486 any

var A_arbace_j2g_dyn_A_const_487 any

var A_arbace_j2g_dyn_A_const_488 any

var A_arbace_j2g_dyn_A_const_489 any

var A_arbace_j2g_dyn_A_const_490 any

var A_arbace_j2g_dyn_A_const_491 any

var A_arbace_j2g_dyn_A_const_492 any

var A_arbace_j2g_dyn_A_const_493 any

var A_arbace_j2g_dyn_A_const_494 any

var A_arbace_j2g_dyn_A_const_495 any

var A_arbace_j2g_dyn_A_const_496 any

var A_arbace_j2g_dyn_A_const_497 any

var A_arbace_j2g_dyn_A_const_498 any

var A_arbace_j2g_dyn_A_const_499 any

var A_arbace_j2g_dyn_A_const_500 any

var A_arbace_j2g_dyn_A_const_501 any

var A_arbace_j2g_dyn_A_const_502 any

var A_arbace_j2g_dyn_A_const_503 any

var A_arbace_j2g_dyn_A_const_504 *lang.Var

var A_arbace_j2g_dyn_A_const_505 *lang.Var

var A_arbace_j2g_dyn_A_init jrt.ClassInit

func A_arbace_j2g_dyn_A_Init() { if !A_arbace_j2g_dyn_A_init.Done() { A_arbace_j2g_dyn_A_init.Run(A_arbace_j2g_dyn_A_clinit) } }

func A_arbace_j2g_dyn_A_clinit() { A_arbace_j2g_dyn_A_clinit_p0(); A_arbace_j2g_dyn_A_clinit_p1(); A_arbace_j2g_dyn_A_clinit_p2(); A_arbace_j2g_dyn_A_clinit_p3(); A_arbace_j2g_dyn_A_clinit_p4(); A_arbace_j2g_dyn_A_clinit_p5(); A_arbace_j2g_dyn_A_clinit_p6(); A_arbace_j2g_dyn_A_clinit_p7(); A_arbace_j2g_dyn_A_clinit_p8(); A_arbace_j2g_dyn_A_clinit_p9(); A_arbace_j2g_dyn_A_clinit_p10(); A_arbace_j2g_dyn_A_clinit_p11(); A_arbace_j2g_dyn_A_clinit_p12(); A_arbace_j2g_dyn_A_clinit_p13(); A_arbace_j2g_dyn_A_clinit_p14(); A_arbace_j2g_dyn_A_clinit_p15(); A_arbace_j2g_dyn_A_clinit_p16(); A_arbace_j2g_dyn_A_clinit_p17(); A_arbace_j2g_dyn_A_clinit_p18(); A_arbace_j2g_dyn_A_clinit_p19(); A_arbace_j2g_dyn_A_clinit_p20(); A_arbace_j2g_dyn_A_clinit_p21(); A_arbace_j2g_dyn_A_clinit_p22(); A_arbace_j2g_dyn_A_clinit_p23(); A_arbace_j2g_dyn_A_clinit_p24(); A_arbace_j2g_dyn_A_clinit_p25(); A_arbace_j2g_dyn_A_clinit_p26(); A_arbace_j2g_dyn_A_clinit_p27(); A_arbace_j2g_dyn_A_clinit_p28(); A_arbace_j2g_dyn_A_clinit_p29(); A_arbace_j2g_dyn_A_clinit_p30(); A_arbace_j2g_dyn_A_clinit_p31(); A_arbace_j2g_dyn_A_clinit_p32(); A_arbace_j2g_dyn_A_clinit_p33(); A_arbace_j2g_dyn_A_clinit_p34(); A_arbace_j2g_dyn_A_clinit_p35() }

func A_arbace_j2g_dyn_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyn_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 770); A_arbace_j2g_dyn_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[264]); A_arbace_j2g_dyn_A_const_1 = A_arbace_j2g_dyn_A_const_pool.A[265]; A_arbace_j2g_dyn_A_const_2 = A_arbace_j2g_dyn_A_const_pool.A[266]; A_arbace_j2g_dyn_A_const_3 = A_arbace_j2g_dyn_A_const_pool.A[267]; A_arbace_j2g_dyn_A_const_4 = A_arbace_j2g_dyn_A_const_pool.A[268]; A_arbace_j2g_dyn_A_const_5 = A_arbace_j2g_dyn_A_const_pool.A[269]; A_arbace_j2g_dyn_A_const_6 = A_arbace_j2g_dyn_A_const_pool.A[270]; A_arbace_j2g_dyn_A_const_7 = A_arbace_j2g_dyn_A_const_pool.A[271]; A_arbace_j2g_dyn_A_const_8 = A_arbace_j2g_dyn_A_const_pool.A[272]; A_arbace_j2g_dyn_A_const_9 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[273]); A_arbace_j2g_dyn_A_const_10 = A_arbace_j2g_dyn_A_const_pool.A[274]; A_arbace_j2g_dyn_A_const_11 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[275]); A_arbace_j2g_dyn_A_const_12 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[276]) }

func A_arbace_j2g_dyn_A_clinit_p1() { A_arbace_j2g_dyn_A_const_13 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[277]); A_arbace_j2g_dyn_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[278]); A_arbace_j2g_dyn_A_const_15 = A_arbace_j2g_dyn_A_const_pool.A[279]; A_arbace_j2g_dyn_A_const_16 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[280]); A_arbace_j2g_dyn_A_const_17 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[281]); A_arbace_j2g_dyn_A_const_18 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[282]); A_arbace_j2g_dyn_A_const_19 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[283]); A_arbace_j2g_dyn_A_const_20 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[284]); A_arbace_j2g_dyn_A_const_21 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[285]); A_arbace_j2g_dyn_A_const_22 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[286]); A_arbace_j2g_dyn_A_const_23 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[287]); A_arbace_j2g_dyn_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[288]) }

func A_arbace_j2g_dyn_A_clinit_p2() { A_arbace_j2g_dyn_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[289]); A_arbace_j2g_dyn_A_const_26 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[290]); A_arbace_j2g_dyn_A_const_27 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[291]); A_arbace_j2g_dyn_A_const_28 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[292]); A_arbace_j2g_dyn_A_const_29 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[293]); A_arbace_j2g_dyn_A_const_30 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[294]); A_arbace_j2g_dyn_A_const_31 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[295]); A_arbace_j2g_dyn_A_const_32 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[296]); A_arbace_j2g_dyn_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[297]); A_arbace_j2g_dyn_A_const_34 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[298]); A_arbace_j2g_dyn_A_const_35 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[299]); A_arbace_j2g_dyn_A_const_36 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[300]) }

func A_arbace_j2g_dyn_A_clinit_p3() { A_arbace_j2g_dyn_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[301]); A_arbace_j2g_dyn_A_const_38 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[302]); A_arbace_j2g_dyn_A_const_39 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[303]); A_arbace_j2g_dyn_A_const_40 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[304]); A_arbace_j2g_dyn_A_const_41 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[305]); A_arbace_j2g_dyn_A_const_42 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[306]); A_arbace_j2g_dyn_A_const_43 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[307]); A_arbace_j2g_dyn_A_const_44 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[308]); A_arbace_j2g_dyn_A_const_45 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[309]); A_arbace_j2g_dyn_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[310]); A_arbace_j2g_dyn_A_const_47 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[311]); A_arbace_j2g_dyn_A_const_48 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[312]) }

func A_arbace_j2g_dyn_A_clinit_p4() { A_arbace_j2g_dyn_A_const_49 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[313]); A_arbace_j2g_dyn_A_const_50 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[314]); A_arbace_j2g_dyn_A_const_51 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[315]); A_arbace_j2g_dyn_A_const_52 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[316]); A_arbace_j2g_dyn_A_const_53 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[317]); A_arbace_j2g_dyn_A_const_54 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[318]); A_arbace_j2g_dyn_A_const_55 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[319]); A_arbace_j2g_dyn_A_const_56 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[320]); A_arbace_j2g_dyn_A_const_57 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[321]); A_arbace_j2g_dyn_A_const_58 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[322]); A_arbace_j2g_dyn_A_const_59 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[323]); A_arbace_j2g_dyn_A_const_60 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[324]) }

func A_arbace_j2g_dyn_A_clinit_p5() { A_arbace_j2g_dyn_A_const_61 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[325]); A_arbace_j2g_dyn_A_const_62 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[326]); A_arbace_j2g_dyn_A_const_63 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[327]); A_arbace_j2g_dyn_A_const_64 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[328]); A_arbace_j2g_dyn_A_const_65 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[329]); A_arbace_j2g_dyn_A_const_66 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[330]); A_arbace_j2g_dyn_A_const_67 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[331]); A_arbace_j2g_dyn_A_const_68 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[332]); A_arbace_j2g_dyn_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[333]); A_arbace_j2g_dyn_A_const_70 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[334]); A_arbace_j2g_dyn_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[335]); A_arbace_j2g_dyn_A_const_72 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[336]) }

func A_arbace_j2g_dyn_A_clinit_p6() { A_arbace_j2g_dyn_A_const_73 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[337]); A_arbace_j2g_dyn_A_const_74 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[338]); A_arbace_j2g_dyn_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[339]); A_arbace_j2g_dyn_A_const_76 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[340]); A_arbace_j2g_dyn_A_const_77 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[341]); A_arbace_j2g_dyn_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[342]); A_arbace_j2g_dyn_A_const_79 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[343]); A_arbace_j2g_dyn_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[344]); A_arbace_j2g_dyn_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[345]); A_arbace_j2g_dyn_A_const_82 = A_arbace_j2g_dyn_A_const_pool.A[346]; A_arbace_j2g_dyn_A_const_83 = A_arbace_j2g_dyn_A_const_pool.A[347]; A_arbace_j2g_dyn_A_const_84 = A_arbace_j2g_dyn_A_const_pool.A[348] }

func A_arbace_j2g_dyn_A_clinit_p7() { A_arbace_j2g_dyn_A_const_85 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[349]); A_arbace_j2g_dyn_A_const_86 = A_arbace_j2g_dyn_A_const_pool.A[350]; A_arbace_j2g_dyn_A_const_87 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[351]); A_arbace_j2g_dyn_A_const_88 = A_arbace_j2g_dyn_A_const_pool.A[352]; A_arbace_j2g_dyn_A_const_89 = A_arbace_j2g_dyn_A_const_pool.A[353]; A_arbace_j2g_dyn_A_const_90 = A_arbace_j2g_dyn_A_const_pool.A[354]; A_arbace_j2g_dyn_A_const_91 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[355]); A_arbace_j2g_dyn_A_const_92 = A_arbace_j2g_dyn_A_const_pool.A[356]; A_arbace_j2g_dyn_A_const_93 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[357]); A_arbace_j2g_dyn_A_const_94 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[358]); A_arbace_j2g_dyn_A_const_95 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[359]); A_arbace_j2g_dyn_A_const_96 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[360]); A_arbace_j2g_dyn_A_const_97 = A_arbace_j2g_dyn_A_const_pool.A[361] }

func A_arbace_j2g_dyn_A_clinit_p8() { A_arbace_j2g_dyn_A_const_98 = A_arbace_j2g_dyn_A_const_pool.A[362]; A_arbace_j2g_dyn_A_const_99 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[363]); A_arbace_j2g_dyn_A_const_100 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[364]); A_arbace_j2g_dyn_A_const_101 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[365]); A_arbace_j2g_dyn_A_const_102 = A_arbace_j2g_dyn_A_const_pool.A[366]; A_arbace_j2g_dyn_A_const_103 = A_arbace_j2g_dyn_A_const_pool.A[367]; A_arbace_j2g_dyn_A_const_104 = A_arbace_j2g_dyn_A_const_pool.A[368]; A_arbace_j2g_dyn_A_const_105 = A_arbace_j2g_dyn_A_const_pool.A[369]; A_arbace_j2g_dyn_A_const_106 = A_arbace_j2g_dyn_A_const_pool.A[370]; A_arbace_j2g_dyn_A_const_107 = A_arbace_j2g_dyn_A_const_pool.A[371]; A_arbace_j2g_dyn_A_const_108 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[372]); A_arbace_j2g_dyn_A_const_109 = A_arbace_j2g_dyn_A_const_pool.A[373]; A_arbace_j2g_dyn_A_const_110 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[374]); A_arbace_j2g_dyn_A_const_111 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[375]) }

func A_arbace_j2g_dyn_A_clinit_p9() { A_arbace_j2g_dyn_A_const_112 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[376]); A_arbace_j2g_dyn_A_const_113 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[377]); A_arbace_j2g_dyn_A_const_114 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[378]); A_arbace_j2g_dyn_A_const_115 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[379]); A_arbace_j2g_dyn_A_const_116 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[380]); A_arbace_j2g_dyn_A_const_117 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[381]); A_arbace_j2g_dyn_A_const_118 = A_arbace_j2g_dyn_A_const_pool.A[382]; A_arbace_j2g_dyn_A_const_119 = A_arbace_j2g_dyn_A_const_pool.A[383]; A_arbace_j2g_dyn_A_const_120 = A_arbace_j2g_dyn_A_const_pool.A[384]; A_arbace_j2g_dyn_A_const_121 = A_arbace_j2g_dyn_A_const_pool.A[385]; A_arbace_j2g_dyn_A_const_122 = A_arbace_j2g_dyn_A_const_pool.A[386]; A_arbace_j2g_dyn_A_const_123 = A_arbace_j2g_dyn_A_const_pool.A[387]; A_arbace_j2g_dyn_A_const_124 = A_arbace_j2g_dyn_A_const_pool.A[388]; A_arbace_j2g_dyn_A_const_125 = A_arbace_j2g_dyn_A_const_pool.A[389] }

func A_arbace_j2g_dyn_A_clinit_p10() { A_arbace_j2g_dyn_A_const_126 = A_arbace_j2g_dyn_A_const_pool.A[390]; A_arbace_j2g_dyn_A_const_127 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[391]); A_arbace_j2g_dyn_A_const_128 = A_arbace_j2g_dyn_A_const_pool.A[392]; A_arbace_j2g_dyn_A_const_129 = A_arbace_j2g_dyn_A_const_pool.A[393]; A_arbace_j2g_dyn_A_const_130 = A_arbace_j2g_dyn_A_const_pool.A[394]; A_arbace_j2g_dyn_A_const_131 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[395]); A_arbace_j2g_dyn_A_const_132 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[396]); A_arbace_j2g_dyn_A_const_133 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[397]); A_arbace_j2g_dyn_A_const_134 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[398]); A_arbace_j2g_dyn_A_const_135 = A_arbace_j2g_dyn_A_const_pool.A[399]; A_arbace_j2g_dyn_A_const_136 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[400]); A_arbace_j2g_dyn_A_const_137 = A_arbace_j2g_dyn_A_const_pool.A[401]; A_arbace_j2g_dyn_A_const_138 = A_arbace_j2g_dyn_A_const_pool.A[402]; A_arbace_j2g_dyn_A_const_139 = A_arbace_j2g_dyn_A_const_pool.A[403] }

func A_arbace_j2g_dyn_A_clinit_p11() { A_arbace_j2g_dyn_A_const_140 = A_arbace_j2g_dyn_A_const_pool.A[404]; A_arbace_j2g_dyn_A_const_141 = A_arbace_j2g_dyn_A_const_pool.A[405]; A_arbace_j2g_dyn_A_const_142 = A_arbace_j2g_dyn_A_const_pool.A[406]; A_arbace_j2g_dyn_A_const_143 = A_arbace_j2g_dyn_A_const_pool.A[407]; A_arbace_j2g_dyn_A_const_144 = A_arbace_j2g_dyn_A_const_pool.A[408]; A_arbace_j2g_dyn_A_const_145 = A_arbace_j2g_dyn_A_const_pool.A[409]; A_arbace_j2g_dyn_A_const_146 = A_arbace_j2g_dyn_A_const_pool.A[410]; A_arbace_j2g_dyn_A_const_147 = A_arbace_j2g_dyn_A_const_pool.A[411]; A_arbace_j2g_dyn_A_const_148 = A_arbace_j2g_dyn_A_const_pool.A[412]; A_arbace_j2g_dyn_A_const_149 = A_arbace_j2g_dyn_A_const_pool.A[413]; A_arbace_j2g_dyn_A_const_150 = A_arbace_j2g_dyn_A_const_pool.A[414]; A_arbace_j2g_dyn_A_const_151 = A_arbace_j2g_dyn_A_const_pool.A[415]; A_arbace_j2g_dyn_A_const_152 = A_arbace_j2g_dyn_A_const_pool.A[416]; A_arbace_j2g_dyn_A_const_153 = A_arbace_j2g_dyn_A_const_pool.A[417]; A_arbace_j2g_dyn_A_const_154 = A_arbace_j2g_dyn_A_const_pool.A[418] }

func A_arbace_j2g_dyn_A_clinit_p12() { A_arbace_j2g_dyn_A_const_155 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[419]); A_arbace_j2g_dyn_A_const_156 = A_arbace_j2g_dyn_A_const_pool.A[420]; A_arbace_j2g_dyn_A_const_157 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[421]); A_arbace_j2g_dyn_A_const_158 = A_arbace_j2g_dyn_A_const_pool.A[422]; A_arbace_j2g_dyn_A_const_159 = A_arbace_j2g_dyn_A_const_pool.A[423]; A_arbace_j2g_dyn_A_const_160 = A_arbace_j2g_dyn_A_const_pool.A[424]; A_arbace_j2g_dyn_A_const_161 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[425]); A_arbace_j2g_dyn_A_const_162 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[426]); A_arbace_j2g_dyn_A_const_163 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[427]); A_arbace_j2g_dyn_A_const_164 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[428]); A_arbace_j2g_dyn_A_const_165 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[429]); A_arbace_j2g_dyn_A_const_166 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[430]); A_arbace_j2g_dyn_A_const_167 = A_arbace_j2g_dyn_A_const_pool.A[431] }

func A_arbace_j2g_dyn_A_clinit_p13() { A_arbace_j2g_dyn_A_const_168 = A_arbace_j2g_dyn_A_const_pool.A[432]; A_arbace_j2g_dyn_A_const_169 = A_arbace_j2g_dyn_A_const_pool.A[433]; A_arbace_j2g_dyn_A_const_170 = A_arbace_j2g_dyn_A_const_pool.A[434]; A_arbace_j2g_dyn_A_const_171 = A_arbace_j2g_dyn_A_const_pool.A[435]; A_arbace_j2g_dyn_A_const_172 = A_arbace_j2g_dyn_A_const_pool.A[436]; A_arbace_j2g_dyn_A_const_173 = A_arbace_j2g_dyn_A_const_pool.A[437]; A_arbace_j2g_dyn_A_const_174 = A_arbace_j2g_dyn_A_const_pool.A[438]; A_arbace_j2g_dyn_A_const_175 = A_arbace_j2g_dyn_A_const_pool.A[439]; A_arbace_j2g_dyn_A_const_176 = A_arbace_j2g_dyn_A_const_pool.A[440]; A_arbace_j2g_dyn_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[441]); A_arbace_j2g_dyn_A_const_178 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[442]); A_arbace_j2g_dyn_A_const_179 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[443]); A_arbace_j2g_dyn_A_const_180 = A_arbace_j2g_dyn_A_const_pool.A[444]; A_arbace_j2g_dyn_A_const_181 = A_arbace_j2g_dyn_A_const_pool.A[445]; A_arbace_j2g_dyn_A_const_182 = A_arbace_j2g_dyn_A_const_pool.A[446] }

func A_arbace_j2g_dyn_A_clinit_p14() { A_arbace_j2g_dyn_A_const_183 = A_arbace_j2g_dyn_A_const_pool.A[447]; A_arbace_j2g_dyn_A_const_184 = A_arbace_j2g_dyn_A_const_pool.A[448]; A_arbace_j2g_dyn_A_const_185 = A_arbace_j2g_dyn_A_const_pool.A[449]; A_arbace_j2g_dyn_A_const_186 = A_arbace_j2g_dyn_A_const_pool.A[450]; A_arbace_j2g_dyn_A_const_187 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[451]); A_arbace_j2g_dyn_A_const_188 = A_arbace_j2g_dyn_A_const_pool.A[452]; A_arbace_j2g_dyn_A_const_189 = A_arbace_j2g_dyn_A_const_pool.A[453]; A_arbace_j2g_dyn_A_const_190 = A_arbace_j2g_dyn_A_const_pool.A[454]; A_arbace_j2g_dyn_A_const_191 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[455]); A_arbace_j2g_dyn_A_const_192 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[456]); A_arbace_j2g_dyn_A_const_193 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[457]); A_arbace_j2g_dyn_A_const_194 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[458]); A_arbace_j2g_dyn_A_const_195 = A_arbace_j2g_dyn_A_const_pool.A[459]; A_arbace_j2g_dyn_A_const_196 = A_arbace_j2g_dyn_A_const_pool.A[460] }

func A_arbace_j2g_dyn_A_clinit_p15() { A_arbace_j2g_dyn_A_const_197 = A_arbace_j2g_dyn_A_const_pool.A[461]; A_arbace_j2g_dyn_A_const_198 = A_arbace_j2g_dyn_A_const_pool.A[462]; A_arbace_j2g_dyn_A_const_199 = A_arbace_j2g_dyn_A_const_pool.A[463]; A_arbace_j2g_dyn_A_const_200 = A_arbace_j2g_dyn_A_const_pool.A[464]; A_arbace_j2g_dyn_A_const_201 = A_arbace_j2g_dyn_A_const_pool.A[465]; A_arbace_j2g_dyn_A_const_202 = A_arbace_j2g_dyn_A_const_pool.A[466]; A_arbace_j2g_dyn_A_const_203 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[467]); A_arbace_j2g_dyn_A_const_204 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[468]); A_arbace_j2g_dyn_A_const_205 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[469]); A_arbace_j2g_dyn_A_const_206 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[470]); A_arbace_j2g_dyn_A_const_207 = A_arbace_j2g_dyn_A_const_pool.A[471]; A_arbace_j2g_dyn_A_const_208 = A_arbace_j2g_dyn_A_const_pool.A[472]; A_arbace_j2g_dyn_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[473]); A_arbace_j2g_dyn_A_const_210 = A_arbace_j2g_dyn_A_const_pool.A[474] }

func A_arbace_j2g_dyn_A_clinit_p16() { A_arbace_j2g_dyn_A_const_211 = A_arbace_j2g_dyn_A_const_pool.A[475]; A_arbace_j2g_dyn_A_const_212 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[476]); A_arbace_j2g_dyn_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[477]); A_arbace_j2g_dyn_A_const_214 = A_arbace_j2g_dyn_A_const_pool.A[478]; A_arbace_j2g_dyn_A_const_215 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[479]); A_arbace_j2g_dyn_A_const_216 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[480]); A_arbace_j2g_dyn_A_const_217 = A_arbace_j2g_dyn_A_const_pool.A[481]; A_arbace_j2g_dyn_A_const_218 = A_arbace_j2g_dyn_A_const_pool.A[482]; A_arbace_j2g_dyn_A_const_219 = A_arbace_j2g_dyn_A_const_pool.A[483]; A_arbace_j2g_dyn_A_const_220 = A_arbace_j2g_dyn_A_const_pool.A[484]; A_arbace_j2g_dyn_A_const_221 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[485]); A_arbace_j2g_dyn_A_const_222 = A_arbace_j2g_dyn_A_const_pool.A[486]; A_arbace_j2g_dyn_A_const_223 = A_arbace_j2g_dyn_A_const_pool.A[487]; A_arbace_j2g_dyn_A_const_224 = A_arbace_j2g_dyn_A_const_pool.A[488] }

func A_arbace_j2g_dyn_A_clinit_p17() { A_arbace_j2g_dyn_A_const_225 = A_arbace_j2g_dyn_A_const_pool.A[489]; A_arbace_j2g_dyn_A_const_226 = A_arbace_j2g_dyn_A_const_pool.A[490]; A_arbace_j2g_dyn_A_const_227 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[491]); A_arbace_j2g_dyn_A_const_228 = A_arbace_j2g_dyn_A_const_pool.A[492]; A_arbace_j2g_dyn_A_const_229 = A_arbace_j2g_dyn_A_const_pool.A[493]; A_arbace_j2g_dyn_A_const_230 = A_arbace_j2g_dyn_A_const_pool.A[494]; A_arbace_j2g_dyn_A_const_231 = A_arbace_j2g_dyn_A_const_pool.A[495]; A_arbace_j2g_dyn_A_const_232 = A_arbace_j2g_dyn_A_const_pool.A[496]; A_arbace_j2g_dyn_A_const_233 = A_arbace_j2g_dyn_A_const_pool.A[497]; A_arbace_j2g_dyn_A_const_234 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[498]); A_arbace_j2g_dyn_A_const_235 = A_arbace_j2g_dyn_A_const_pool.A[499]; A_arbace_j2g_dyn_A_const_236 = A_arbace_j2g_dyn_A_const_pool.A[500]; A_arbace_j2g_dyn_A_const_237 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[501]); A_arbace_j2g_dyn_A_const_238 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[502]) }

func A_arbace_j2g_dyn_A_clinit_p18() { A_arbace_j2g_dyn_A_const_239 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[503]); A_arbace_j2g_dyn_A_const_240 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[504]); A_arbace_j2g_dyn_A_const_241 = A_arbace_j2g_dyn_A_const_pool.A[505]; A_arbace_j2g_dyn_A_const_242 = A_arbace_j2g_dyn_A_const_pool.A[506]; A_arbace_j2g_dyn_A_const_243 = A_arbace_j2g_dyn_A_const_pool.A[507]; A_arbace_j2g_dyn_A_const_244 = A_arbace_j2g_dyn_A_const_pool.A[508]; A_arbace_j2g_dyn_A_const_245 = A_arbace_j2g_dyn_A_const_pool.A[509]; A_arbace_j2g_dyn_A_const_246 = A_arbace_j2g_dyn_A_const_pool.A[510]; A_arbace_j2g_dyn_A_const_247 = A_arbace_j2g_dyn_A_const_pool.A[511]; A_arbace_j2g_dyn_A_const_248 = A_arbace_j2g_dyn_A_const_pool.A[512]; A_arbace_j2g_dyn_A_const_249 = A_arbace_j2g_dyn_A_const_pool.A[513]; A_arbace_j2g_dyn_A_const_250 = A_arbace_j2g_dyn_A_const_pool.A[514]; A_arbace_j2g_dyn_A_const_251 = A_arbace_j2g_dyn_A_const_pool.A[515]; A_arbace_j2g_dyn_A_const_252 = A_arbace_j2g_dyn_A_const_pool.A[516]; A_arbace_j2g_dyn_A_const_253 = A_arbace_j2g_dyn_A_const_pool.A[517] }

func A_arbace_j2g_dyn_A_clinit_p19() { A_arbace_j2g_dyn_A_const_254 = A_arbace_j2g_dyn_A_const_pool.A[518]; A_arbace_j2g_dyn_A_const_255 = A_arbace_j2g_dyn_A_const_pool.A[519]; A_arbace_j2g_dyn_A_const_256 = A_arbace_j2g_dyn_A_const_pool.A[520]; A_arbace_j2g_dyn_A_const_257 = A_arbace_j2g_dyn_A_const_pool.A[521]; A_arbace_j2g_dyn_A_const_258 = A_arbace_j2g_dyn_A_const_pool.A[522]; A_arbace_j2g_dyn_A_const_259 = A_arbace_j2g_dyn_A_const_pool.A[523]; A_arbace_j2g_dyn_A_const_260 = A_arbace_j2g_dyn_A_const_pool.A[524]; A_arbace_j2g_dyn_A_const_261 = A_arbace_j2g_dyn_A_const_pool.A[525]; A_arbace_j2g_dyn_A_const_262 = A_arbace_j2g_dyn_A_const_pool.A[526]; A_arbace_j2g_dyn_A_const_263 = A_arbace_j2g_dyn_A_const_pool.A[527]; A_arbace_j2g_dyn_A_const_264 = A_arbace_j2g_dyn_A_const_pool.A[528]; A_arbace_j2g_dyn_A_const_265 = A_arbace_j2g_dyn_A_const_pool.A[529]; A_arbace_j2g_dyn_A_const_266 = A_arbace_j2g_dyn_A_const_pool.A[530]; A_arbace_j2g_dyn_A_const_267 = A_arbace_j2g_dyn_A_const_pool.A[531]; A_arbace_j2g_dyn_A_const_268 = A_arbace_j2g_dyn_A_const_pool.A[532]; A_arbace_j2g_dyn_A_const_269 = A_arbace_j2g_dyn_A_const_pool.A[533] }

func A_arbace_j2g_dyn_A_clinit_p20() { A_arbace_j2g_dyn_A_const_270 = A_arbace_j2g_dyn_A_const_pool.A[534]; A_arbace_j2g_dyn_A_const_271 = A_arbace_j2g_dyn_A_const_pool.A[535]; A_arbace_j2g_dyn_A_const_272 = A_arbace_j2g_dyn_A_const_pool.A[536]; A_arbace_j2g_dyn_A_const_273 = A_arbace_j2g_dyn_A_const_pool.A[537]; A_arbace_j2g_dyn_A_const_274 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[538]); A_arbace_j2g_dyn_A_const_275 = A_arbace_j2g_dyn_A_const_pool.A[539]; A_arbace_j2g_dyn_A_const_276 = A_arbace_j2g_dyn_A_const_pool.A[540]; A_arbace_j2g_dyn_A_const_277 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[541]); A_arbace_j2g_dyn_A_const_278 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[542]); A_arbace_j2g_dyn_A_const_279 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[543]); A_arbace_j2g_dyn_A_const_280 = A_arbace_j2g_dyn_A_const_pool.A[544]; A_arbace_j2g_dyn_A_const_281 = A_arbace_j2g_dyn_A_const_pool.A[545]; A_arbace_j2g_dyn_A_const_282 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[546]); A_arbace_j2g_dyn_A_const_283 = A_arbace_j2g_dyn_A_const_pool.A[547] }

func A_arbace_j2g_dyn_A_clinit_p21() { A_arbace_j2g_dyn_A_const_284 = A_arbace_j2g_dyn_A_const_pool.A[548]; A_arbace_j2g_dyn_A_const_285 = A_arbace_j2g_dyn_A_const_pool.A[549]; A_arbace_j2g_dyn_A_const_286 = A_arbace_j2g_dyn_A_const_pool.A[550]; A_arbace_j2g_dyn_A_const_287 = A_arbace_j2g_dyn_A_const_pool.A[551]; A_arbace_j2g_dyn_A_const_288 = A_arbace_j2g_dyn_A_const_pool.A[552]; A_arbace_j2g_dyn_A_const_289 = A_arbace_j2g_dyn_A_const_pool.A[553]; A_arbace_j2g_dyn_A_const_290 = A_arbace_j2g_dyn_A_const_pool.A[554]; A_arbace_j2g_dyn_A_const_291 = A_arbace_j2g_dyn_A_const_pool.A[555]; A_arbace_j2g_dyn_A_const_292 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[556]); A_arbace_j2g_dyn_A_const_293 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[557]); A_arbace_j2g_dyn_A_const_294 = A_arbace_j2g_dyn_A_const_pool.A[558]; A_arbace_j2g_dyn_A_const_295 = A_arbace_j2g_dyn_A_const_pool.A[559]; A_arbace_j2g_dyn_A_const_296 = A_arbace_j2g_dyn_A_const_pool.A[560]; A_arbace_j2g_dyn_A_const_297 = A_arbace_j2g_dyn_A_const_pool.A[561]; A_arbace_j2g_dyn_A_const_298 = A_arbace_j2g_dyn_A_const_pool.A[562] }

func A_arbace_j2g_dyn_A_clinit_p22() { A_arbace_j2g_dyn_A_const_299 = A_arbace_j2g_dyn_A_const_pool.A[563]; A_arbace_j2g_dyn_A_const_300 = A_arbace_j2g_dyn_A_const_pool.A[564]; A_arbace_j2g_dyn_A_const_301 = A_arbace_j2g_dyn_A_const_pool.A[565]; A_arbace_j2g_dyn_A_const_302 = A_arbace_j2g_dyn_A_const_pool.A[566]; A_arbace_j2g_dyn_A_const_303 = A_arbace_j2g_dyn_A_const_pool.A[567]; A_arbace_j2g_dyn_A_const_304 = A_arbace_j2g_dyn_A_const_pool.A[568]; A_arbace_j2g_dyn_A_const_305 = A_arbace_j2g_dyn_A_const_pool.A[569]; A_arbace_j2g_dyn_A_const_306 = A_arbace_j2g_dyn_A_const_pool.A[570]; A_arbace_j2g_dyn_A_const_307 = A_arbace_j2g_dyn_A_const_pool.A[571]; A_arbace_j2g_dyn_A_const_308 = A_arbace_j2g_dyn_A_const_pool.A[572]; A_arbace_j2g_dyn_A_const_309 = A_arbace_j2g_dyn_A_const_pool.A[573]; A_arbace_j2g_dyn_A_const_310 = A_arbace_j2g_dyn_A_const_pool.A[574]; A_arbace_j2g_dyn_A_const_311 = A_arbace_j2g_dyn_A_const_pool.A[575]; A_arbace_j2g_dyn_A_const_312 = A_arbace_j2g_dyn_A_const_pool.A[576]; A_arbace_j2g_dyn_A_const_313 = A_arbace_j2g_dyn_A_const_pool.A[577]; A_arbace_j2g_dyn_A_const_314 = A_arbace_j2g_dyn_A_const_pool.A[578] }

func A_arbace_j2g_dyn_A_clinit_p23() { A_arbace_j2g_dyn_A_const_315 = A_arbace_j2g_dyn_A_const_pool.A[579]; A_arbace_j2g_dyn_A_const_316 = A_arbace_j2g_dyn_A_const_pool.A[580]; A_arbace_j2g_dyn_A_const_317 = A_arbace_j2g_dyn_A_const_pool.A[581]; A_arbace_j2g_dyn_A_const_318 = A_arbace_j2g_dyn_A_const_pool.A[582]; A_arbace_j2g_dyn_A_const_319 = A_arbace_j2g_dyn_A_const_pool.A[583]; A_arbace_j2g_dyn_A_const_320 = A_arbace_j2g_dyn_A_const_pool.A[584]; A_arbace_j2g_dyn_A_const_321 = A_arbace_j2g_dyn_A_const_pool.A[585]; A_arbace_j2g_dyn_A_const_322 = A_arbace_j2g_dyn_A_const_pool.A[586]; A_arbace_j2g_dyn_A_const_323 = A_arbace_j2g_dyn_A_const_pool.A[587]; A_arbace_j2g_dyn_A_const_324 = A_arbace_j2g_dyn_A_const_pool.A[588]; A_arbace_j2g_dyn_A_const_325 = A_arbace_j2g_dyn_A_const_pool.A[589]; A_arbace_j2g_dyn_A_const_326 = A_arbace_j2g_dyn_A_const_pool.A[590]; A_arbace_j2g_dyn_A_const_327 = A_arbace_j2g_dyn_A_const_pool.A[591]; A_arbace_j2g_dyn_A_const_328 = A_arbace_j2g_dyn_A_const_pool.A[592]; A_arbace_j2g_dyn_A_const_329 = A_arbace_j2g_dyn_A_const_pool.A[593]; A_arbace_j2g_dyn_A_const_330 = A_arbace_j2g_dyn_A_const_pool.A[594] }

func A_arbace_j2g_dyn_A_clinit_p24() { A_arbace_j2g_dyn_A_const_331 = A_arbace_j2g_dyn_A_const_pool.A[595]; A_arbace_j2g_dyn_A_const_332 = A_arbace_j2g_dyn_A_const_pool.A[596]; A_arbace_j2g_dyn_A_const_333 = A_arbace_j2g_dyn_A_const_pool.A[597]; A_arbace_j2g_dyn_A_const_334 = A_arbace_j2g_dyn_A_const_pool.A[598]; A_arbace_j2g_dyn_A_const_335 = A_arbace_j2g_dyn_A_const_pool.A[599]; A_arbace_j2g_dyn_A_const_336 = A_arbace_j2g_dyn_A_const_pool.A[600]; A_arbace_j2g_dyn_A_const_337 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[601]); A_arbace_j2g_dyn_A_const_338 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[602]); A_arbace_j2g_dyn_A_const_339 = A_arbace_j2g_dyn_A_const_pool.A[603]; A_arbace_j2g_dyn_A_const_340 = A_arbace_j2g_dyn_A_const_pool.A[604]; A_arbace_j2g_dyn_A_const_341 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[605]); A_arbace_j2g_dyn_A_const_342 = A_arbace_j2g_dyn_A_const_pool.A[606]; A_arbace_j2g_dyn_A_const_343 = A_arbace_j2g_dyn_A_const_pool.A[607]; A_arbace_j2g_dyn_A_const_344 = A_arbace_j2g_dyn_A_const_pool.A[608] }

func A_arbace_j2g_dyn_A_clinit_p25() { A_arbace_j2g_dyn_A_const_345 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[609]); A_arbace_j2g_dyn_A_const_346 = A_arbace_j2g_dyn_A_const_pool.A[610]; A_arbace_j2g_dyn_A_const_347 = A_arbace_j2g_dyn_A_const_pool.A[611]; A_arbace_j2g_dyn_A_const_348 = A_arbace_j2g_dyn_A_const_pool.A[612]; A_arbace_j2g_dyn_A_const_349 = A_arbace_j2g_dyn_A_const_pool.A[613]; A_arbace_j2g_dyn_A_const_350 = A_arbace_j2g_dyn_A_const_pool.A[614]; A_arbace_j2g_dyn_A_const_351 = A_arbace_j2g_dyn_A_const_pool.A[615]; A_arbace_j2g_dyn_A_const_352 = A_arbace_j2g_dyn_A_const_pool.A[616]; A_arbace_j2g_dyn_A_const_353 = A_arbace_j2g_dyn_A_const_pool.A[617]; A_arbace_j2g_dyn_A_const_354 = A_arbace_j2g_dyn_A_const_pool.A[618]; A_arbace_j2g_dyn_A_const_355 = A_arbace_j2g_dyn_A_const_pool.A[619]; A_arbace_j2g_dyn_A_const_356 = A_arbace_j2g_dyn_A_const_pool.A[620]; A_arbace_j2g_dyn_A_const_357 = A_arbace_j2g_dyn_A_const_pool.A[621]; A_arbace_j2g_dyn_A_const_358 = A_arbace_j2g_dyn_A_const_pool.A[622]; A_arbace_j2g_dyn_A_const_359 = A_arbace_j2g_dyn_A_const_pool.A[623] }

func A_arbace_j2g_dyn_A_clinit_p26() { A_arbace_j2g_dyn_A_const_360 = A_arbace_j2g_dyn_A_const_pool.A[624]; A_arbace_j2g_dyn_A_const_361 = A_arbace_j2g_dyn_A_const_pool.A[625]; A_arbace_j2g_dyn_A_const_362 = A_arbace_j2g_dyn_A_const_pool.A[626]; A_arbace_j2g_dyn_A_const_363 = A_arbace_j2g_dyn_A_const_pool.A[627]; A_arbace_j2g_dyn_A_const_364 = A_arbace_j2g_dyn_A_const_pool.A[628]; A_arbace_j2g_dyn_A_const_365 = A_arbace_j2g_dyn_A_const_pool.A[629]; A_arbace_j2g_dyn_A_const_366 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[630]); A_arbace_j2g_dyn_A_const_367 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[631]); A_arbace_j2g_dyn_A_const_368 = A_arbace_j2g_dyn_A_const_pool.A[632]; A_arbace_j2g_dyn_A_const_369 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[633]); A_arbace_j2g_dyn_A_const_370 = A_arbace_j2g_dyn_A_const_pool.A[634]; A_arbace_j2g_dyn_A_const_371 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[635]); A_arbace_j2g_dyn_A_const_372 = A_arbace_j2g_dyn_A_const_pool.A[636]; A_arbace_j2g_dyn_A_const_373 = A_arbace_j2g_dyn_A_const_pool.A[637] }

func A_arbace_j2g_dyn_A_clinit_p27() { A_arbace_j2g_dyn_A_const_374 = A_arbace_j2g_dyn_A_const_pool.A[638]; A_arbace_j2g_dyn_A_const_375 = A_arbace_j2g_dyn_A_const_pool.A[639]; A_arbace_j2g_dyn_A_const_376 = A_arbace_j2g_dyn_A_const_pool.A[640]; A_arbace_j2g_dyn_A_const_377 = A_arbace_j2g_dyn_A_const_pool.A[641]; A_arbace_j2g_dyn_A_const_378 = A_arbace_j2g_dyn_A_const_pool.A[642]; A_arbace_j2g_dyn_A_const_379 = A_arbace_j2g_dyn_A_const_pool.A[643]; A_arbace_j2g_dyn_A_const_380 = A_arbace_j2g_dyn_A_const_pool.A[644]; A_arbace_j2g_dyn_A_const_381 = A_arbace_j2g_dyn_A_const_pool.A[645]; A_arbace_j2g_dyn_A_const_382 = A_arbace_j2g_dyn_A_const_pool.A[646]; A_arbace_j2g_dyn_A_const_383 = A_arbace_j2g_dyn_A_const_pool.A[647]; A_arbace_j2g_dyn_A_const_384 = A_arbace_j2g_dyn_A_const_pool.A[648]; A_arbace_j2g_dyn_A_const_385 = A_arbace_j2g_dyn_A_const_pool.A[649]; A_arbace_j2g_dyn_A_const_386 = A_arbace_j2g_dyn_A_const_pool.A[650]; A_arbace_j2g_dyn_A_const_387 = A_arbace_j2g_dyn_A_const_pool.A[651]; A_arbace_j2g_dyn_A_const_388 = A_arbace_j2g_dyn_A_const_pool.A[652]; A_arbace_j2g_dyn_A_const_389 = A_arbace_j2g_dyn_A_const_pool.A[653] }

func A_arbace_j2g_dyn_A_clinit_p28() { A_arbace_j2g_dyn_A_const_390 = A_arbace_j2g_dyn_A_const_pool.A[654]; A_arbace_j2g_dyn_A_const_391 = A_arbace_j2g_dyn_A_const_pool.A[655]; A_arbace_j2g_dyn_A_const_392 = A_arbace_j2g_dyn_A_const_pool.A[656]; A_arbace_j2g_dyn_A_const_393 = A_arbace_j2g_dyn_A_const_pool.A[657]; A_arbace_j2g_dyn_A_const_394 = A_arbace_j2g_dyn_A_const_pool.A[658]; A_arbace_j2g_dyn_A_const_395 = A_arbace_j2g_dyn_A_const_pool.A[659]; A_arbace_j2g_dyn_A_const_396 = A_arbace_j2g_dyn_A_const_pool.A[660]; A_arbace_j2g_dyn_A_const_397 = A_arbace_j2g_dyn_A_const_pool.A[661]; A_arbace_j2g_dyn_A_const_398 = A_arbace_j2g_dyn_A_const_pool.A[662]; A_arbace_j2g_dyn_A_const_399 = A_arbace_j2g_dyn_A_const_pool.A[663]; A_arbace_j2g_dyn_A_const_400 = A_arbace_j2g_dyn_A_const_pool.A[664]; A_arbace_j2g_dyn_A_const_401 = A_arbace_j2g_dyn_A_const_pool.A[665]; A_arbace_j2g_dyn_A_const_402 = A_arbace_j2g_dyn_A_const_pool.A[666]; A_arbace_j2g_dyn_A_const_403 = A_arbace_j2g_dyn_A_const_pool.A[667]; A_arbace_j2g_dyn_A_const_404 = A_arbace_j2g_dyn_A_const_pool.A[668]; A_arbace_j2g_dyn_A_const_405 = A_arbace_j2g_dyn_A_const_pool.A[669] }

func A_arbace_j2g_dyn_A_clinit_p29() { A_arbace_j2g_dyn_A_const_406 = A_arbace_j2g_dyn_A_const_pool.A[670]; A_arbace_j2g_dyn_A_const_407 = A_arbace_j2g_dyn_A_const_pool.A[671]; A_arbace_j2g_dyn_A_const_408 = A_arbace_j2g_dyn_A_const_pool.A[672]; A_arbace_j2g_dyn_A_const_409 = A_arbace_j2g_dyn_A_const_pool.A[673]; A_arbace_j2g_dyn_A_const_410 = A_arbace_j2g_dyn_A_const_pool.A[674]; A_arbace_j2g_dyn_A_const_411 = A_arbace_j2g_dyn_A_const_pool.A[675]; A_arbace_j2g_dyn_A_const_412 = A_arbace_j2g_dyn_A_const_pool.A[676]; A_arbace_j2g_dyn_A_const_413 = A_arbace_j2g_dyn_A_const_pool.A[677]; A_arbace_j2g_dyn_A_const_414 = A_arbace_j2g_dyn_A_const_pool.A[678]; A_arbace_j2g_dyn_A_const_415 = A_arbace_j2g_dyn_A_const_pool.A[679]; A_arbace_j2g_dyn_A_const_416 = A_arbace_j2g_dyn_A_const_pool.A[680]; A_arbace_j2g_dyn_A_const_417 = A_arbace_j2g_dyn_A_const_pool.A[681]; A_arbace_j2g_dyn_A_const_418 = A_arbace_j2g_dyn_A_const_pool.A[682]; A_arbace_j2g_dyn_A_const_419 = A_arbace_j2g_dyn_A_const_pool.A[683]; A_arbace_j2g_dyn_A_const_420 = A_arbace_j2g_dyn_A_const_pool.A[684]; A_arbace_j2g_dyn_A_const_421 = A_arbace_j2g_dyn_A_const_pool.A[685] }

func A_arbace_j2g_dyn_A_clinit_p30() { A_arbace_j2g_dyn_A_const_422 = A_arbace_j2g_dyn_A_const_pool.A[686]; A_arbace_j2g_dyn_A_const_423 = A_arbace_j2g_dyn_A_const_pool.A[687]; A_arbace_j2g_dyn_A_const_424 = A_arbace_j2g_dyn_A_const_pool.A[688]; A_arbace_j2g_dyn_A_const_425 = A_arbace_j2g_dyn_A_const_pool.A[689]; A_arbace_j2g_dyn_A_const_426 = A_arbace_j2g_dyn_A_const_pool.A[690]; A_arbace_j2g_dyn_A_const_427 = A_arbace_j2g_dyn_A_const_pool.A[691]; A_arbace_j2g_dyn_A_const_428 = A_arbace_j2g_dyn_A_const_pool.A[692]; A_arbace_j2g_dyn_A_const_429 = A_arbace_j2g_dyn_A_const_pool.A[693]; A_arbace_j2g_dyn_A_const_430 = A_arbace_j2g_dyn_A_const_pool.A[694]; A_arbace_j2g_dyn_A_const_431 = A_arbace_j2g_dyn_A_const_pool.A[695]; A_arbace_j2g_dyn_A_const_432 = A_arbace_j2g_dyn_A_const_pool.A[696]; A_arbace_j2g_dyn_A_const_433 = A_arbace_j2g_dyn_A_const_pool.A[697]; A_arbace_j2g_dyn_A_const_434 = A_arbace_j2g_dyn_A_const_pool.A[698]; A_arbace_j2g_dyn_A_const_435 = A_arbace_j2g_dyn_A_const_pool.A[699]; A_arbace_j2g_dyn_A_const_436 = A_arbace_j2g_dyn_A_const_pool.A[700]; A_arbace_j2g_dyn_A_const_437 = A_arbace_j2g_dyn_A_const_pool.A[701] }

func A_arbace_j2g_dyn_A_clinit_p31() { A_arbace_j2g_dyn_A_const_438 = A_arbace_j2g_dyn_A_const_pool.A[702]; A_arbace_j2g_dyn_A_const_439 = A_arbace_j2g_dyn_A_const_pool.A[703]; A_arbace_j2g_dyn_A_const_440 = A_arbace_j2g_dyn_A_const_pool.A[704]; A_arbace_j2g_dyn_A_const_441 = A_arbace_j2g_dyn_A_const_pool.A[705]; A_arbace_j2g_dyn_A_const_442 = A_arbace_j2g_dyn_A_const_pool.A[706]; A_arbace_j2g_dyn_A_const_443 = A_arbace_j2g_dyn_A_const_pool.A[707]; A_arbace_j2g_dyn_A_const_444 = A_arbace_j2g_dyn_A_const_pool.A[708]; A_arbace_j2g_dyn_A_const_445 = A_arbace_j2g_dyn_A_const_pool.A[709]; A_arbace_j2g_dyn_A_const_446 = A_arbace_j2g_dyn_A_const_pool.A[710]; A_arbace_j2g_dyn_A_const_447 = A_arbace_j2g_dyn_A_const_pool.A[711]; A_arbace_j2g_dyn_A_const_448 = A_arbace_j2g_dyn_A_const_pool.A[712]; A_arbace_j2g_dyn_A_const_449 = A_arbace_j2g_dyn_A_const_pool.A[713]; A_arbace_j2g_dyn_A_const_450 = A_arbace_j2g_dyn_A_const_pool.A[714]; A_arbace_j2g_dyn_A_const_451 = A_arbace_j2g_dyn_A_const_pool.A[715]; A_arbace_j2g_dyn_A_const_452 = A_arbace_j2g_dyn_A_const_pool.A[716]; A_arbace_j2g_dyn_A_const_453 = A_arbace_j2g_dyn_A_const_pool.A[717] }

func A_arbace_j2g_dyn_A_clinit_p32() { A_arbace_j2g_dyn_A_const_454 = A_arbace_j2g_dyn_A_const_pool.A[718]; A_arbace_j2g_dyn_A_const_455 = A_arbace_j2g_dyn_A_const_pool.A[719]; A_arbace_j2g_dyn_A_const_456 = A_arbace_j2g_dyn_A_const_pool.A[720]; A_arbace_j2g_dyn_A_const_457 = A_arbace_j2g_dyn_A_const_pool.A[721]; A_arbace_j2g_dyn_A_const_458 = A_arbace_j2g_dyn_A_const_pool.A[722]; A_arbace_j2g_dyn_A_const_459 = A_arbace_j2g_dyn_A_const_pool.A[723]; A_arbace_j2g_dyn_A_const_460 = A_arbace_j2g_dyn_A_const_pool.A[724]; A_arbace_j2g_dyn_A_const_461 = A_arbace_j2g_dyn_A_const_pool.A[725]; A_arbace_j2g_dyn_A_const_462 = A_arbace_j2g_dyn_A_const_pool.A[726]; A_arbace_j2g_dyn_A_const_463 = A_arbace_j2g_dyn_A_const_pool.A[727]; A_arbace_j2g_dyn_A_const_464 = A_arbace_j2g_dyn_A_const_pool.A[728]; A_arbace_j2g_dyn_A_const_465 = A_arbace_j2g_dyn_A_const_pool.A[729]; A_arbace_j2g_dyn_A_const_466 = A_arbace_j2g_dyn_A_const_pool.A[730]; A_arbace_j2g_dyn_A_const_467 = A_arbace_j2g_dyn_A_const_pool.A[731]; A_arbace_j2g_dyn_A_const_468 = A_arbace_j2g_dyn_A_const_pool.A[732]; A_arbace_j2g_dyn_A_const_469 = A_arbace_j2g_dyn_A_const_pool.A[733] }

func A_arbace_j2g_dyn_A_clinit_p33() { A_arbace_j2g_dyn_A_const_470 = lang.Keyword_Cast(A_arbace_j2g_dyn_A_const_pool.A[734]); A_arbace_j2g_dyn_A_const_471 = A_arbace_j2g_dyn_A_const_pool.A[735]; A_arbace_j2g_dyn_A_const_472 = A_arbace_j2g_dyn_A_const_pool.A[736]; A_arbace_j2g_dyn_A_const_473 = A_arbace_j2g_dyn_A_const_pool.A[737]; A_arbace_j2g_dyn_A_const_474 = A_arbace_j2g_dyn_A_const_pool.A[738]; A_arbace_j2g_dyn_A_const_475 = A_arbace_j2g_dyn_A_const_pool.A[739]; A_arbace_j2g_dyn_A_const_476 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[740]); A_arbace_j2g_dyn_A_const_477 = A_arbace_j2g_dyn_A_const_pool.A[741]; A_arbace_j2g_dyn_A_const_478 = A_arbace_j2g_dyn_A_const_pool.A[742]; A_arbace_j2g_dyn_A_const_479 = A_arbace_j2g_dyn_A_const_pool.A[743]; A_arbace_j2g_dyn_A_const_480 = A_arbace_j2g_dyn_A_const_pool.A[744]; A_arbace_j2g_dyn_A_const_481 = A_arbace_j2g_dyn_A_const_pool.A[745]; A_arbace_j2g_dyn_A_const_482 = A_arbace_j2g_dyn_A_const_pool.A[746]; A_arbace_j2g_dyn_A_const_483 = A_arbace_j2g_dyn_A_const_pool.A[747]; A_arbace_j2g_dyn_A_const_484 = A_arbace_j2g_dyn_A_const_pool.A[748] }

func A_arbace_j2g_dyn_A_clinit_p34() { A_arbace_j2g_dyn_A_const_485 = A_arbace_j2g_dyn_A_const_pool.A[749]; A_arbace_j2g_dyn_A_const_486 = A_arbace_j2g_dyn_A_const_pool.A[750]; A_arbace_j2g_dyn_A_const_487 = A_arbace_j2g_dyn_A_const_pool.A[751]; A_arbace_j2g_dyn_A_const_488 = A_arbace_j2g_dyn_A_const_pool.A[752]; A_arbace_j2g_dyn_A_const_489 = A_arbace_j2g_dyn_A_const_pool.A[753]; A_arbace_j2g_dyn_A_const_490 = A_arbace_j2g_dyn_A_const_pool.A[754]; A_arbace_j2g_dyn_A_const_491 = A_arbace_j2g_dyn_A_const_pool.A[755]; A_arbace_j2g_dyn_A_const_492 = A_arbace_j2g_dyn_A_const_pool.A[756]; A_arbace_j2g_dyn_A_const_493 = A_arbace_j2g_dyn_A_const_pool.A[757]; A_arbace_j2g_dyn_A_const_494 = A_arbace_j2g_dyn_A_const_pool.A[758]; A_arbace_j2g_dyn_A_const_495 = A_arbace_j2g_dyn_A_const_pool.A[759]; A_arbace_j2g_dyn_A_const_496 = A_arbace_j2g_dyn_A_const_pool.A[760]; A_arbace_j2g_dyn_A_const_497 = A_arbace_j2g_dyn_A_const_pool.A[761]; A_arbace_j2g_dyn_A_const_498 = A_arbace_j2g_dyn_A_const_pool.A[762]; A_arbace_j2g_dyn_A_const_499 = A_arbace_j2g_dyn_A_const_pool.A[763]; A_arbace_j2g_dyn_A_const_500 = A_arbace_j2g_dyn_A_const_pool.A[764] }

func A_arbace_j2g_dyn_A_clinit_p35() { A_arbace_j2g_dyn_A_const_501 = A_arbace_j2g_dyn_A_const_pool.A[765]; A_arbace_j2g_dyn_A_const_502 = A_arbace_j2g_dyn_A_const_pool.A[766]; A_arbace_j2g_dyn_A_const_503 = A_arbace_j2g_dyn_A_const_pool.A[767]; A_arbace_j2g_dyn_A_const_504 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[768]); A_arbace_j2g_dyn_A_const_505 = lang.Var_Cast(A_arbace_j2g_dyn_A_const_pool.A[769]) }

func A_arbace_j2g_dyn_A_New() *A_arbace_j2g_dyn_A { A_arbace_j2g_dyn_A_Init(); t := &A_arbace_j2g_dyn_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_A) Ctor() {}

func (t *A_arbace_j2g_dyn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_A_class }

func (t *A_arbace_j2g_dyn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_A); return ok }

func A_arbace_j2g_dyn_A_Cast(x any) *A_arbace_j2g_dyn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_A_class)) }; return v }



type A_arbace_j2g_dyn_abstract_text_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_abstract_text_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A struct{ j2g_header uint64; F_name, F_desc any }

var A_arbace_j2g_dyn_abstract_text_declares_QMARK___711000141_fn__711000142_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_abstract_text_fn__711000145_fn__711000147_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_box_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_box_arg_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_call_impl_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_call_impl_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_class_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_class_fallback_ret__711000234_A struct{ j2g_header uint64; F_r any }

var A_arbace_j2g_dyn_class_fallback_ret__711000234_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_A struct{ j2g_header uint64; F_d any }

var A_arbace_j2g_dyn_convert_result_fn__711000126_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_convert_result_fn__711000126_fn__711000127_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_ctor_infos_arg_conv__711000241_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A struct{ j2g_header uint64; F_g, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A struct{ j2g_header uint64; F_iter__711000243, F_g, F_s__711000244, F_n, F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A struct{ j2g_header uint64; F_g, F_n, F_b__711000246, F_arg_conv any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000249_fn__711000256_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A struct{ j2g_header uint64; F_arg_conv any }

var A_arbace_j2g_dyn_ctor_infos_iter__711000243__711000247_fn__711000248_fn__711000265_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_A struct{ j2g_header uint64; F_ifaces, F_lockee__1927000360__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A struct{ j2g_header uint64; F_j any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_fn__711000086_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A struct{ j2g_header uint64; F_s__711000089, F_iter__711000088 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A struct{ j2g_header uint64; F_iter__711000090, F_s__711000091 any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A struct{ j2g_header uint64; F_b__711000093 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_declarers_fn__711000081_fn__711000085_iter__711000088__711000094_fn__711000095_iter__711000090__711000096_fn__711000097_fn__711000098_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_fn__711000118_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_defaults_for_fn__711000118_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A struct{ j2g_header uint64; F_k any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A struct{ j2g_header uint64; F_iter__711000107, F_k, F_s__711000108 any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A struct{ j2g_header uint64; F_k, F_b__711000110 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_defaults_for_iter__711000107__711000111_fn__711000112_fn__711000113_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_enabled_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_enabled_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000004_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000004_A_New() *A_arbace_j2g_dyn_eval711000004_A { t := &A_arbace_j2g_dyn_eval711000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000004_A_class }

func (t *A_arbace_j2g_dyn_eval711000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); return ok }

func A_arbace_j2g_dyn_eval711000004_A_Cast(x any) *A_arbace_j2g_dyn_eval711000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000004_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_eval711000008_A struct{ jrt.Object }

func A_arbace_j2g_dyn_eval711000008_A_New() *A_arbace_j2g_dyn_eval711000008_A { t := &A_arbace_j2g_dyn_eval711000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) Ctor() {}

func (t *A_arbace_j2g_dyn_eval711000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn_eval711000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn_eval711000008_A_class }

func (t *A_arbace_j2g_dyn_eval711000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn_eval711000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn_eval711000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); return ok }

func A_arbace_j2g_dyn_eval711000008_A_Cast(x any) *A_arbace_j2g_dyn_eval711000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn_eval711000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn_eval711000008_A_class)) }; return v }



type A_arbace_j2g_dyn_eval711000008_fn__711000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_eval711000008_fn__711000009_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_fn_field_native_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_fn_field_native_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000383_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_fn__711000383_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000414_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000414_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_fn__711000426_A struct{ j2g_header uint64; F_ks, F_ifaces any }

var A_arbace_j2g_dyn_forms_fn__711000426_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000388__711000392_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000388__711000392_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A struct{ j2g_header uint64; F_iter__711000388, F_s__711000389 any }

var A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A struct{ j2g_header uint64; F_b__711000391 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000388__711000392_fn__711000393_fn__711000394_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000404__711000408_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000404__711000408_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A struct{ j2g_header uint64; F_iter__711000404, F_s__711000405 any }

var A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A struct{ j2g_header uint64; F_b__711000407 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000404__711000408_fn__711000409_fn__711000410_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000416__711000420_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_forms_iter__711000416__711000420_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A struct{ j2g_header uint64; F_iter__711000416, F_s__711000417 any }

var A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A struct{ j2g_header uint64; F_b__711000419 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_forms_iter__711000416__711000420_fn__711000421_fn__711000422_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A struct{ j2g_header uint64; F_iter__711000270, F_s__711000271 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A struct{ j2g_header uint64; F_s__711000273, F_iter__711000272 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A struct{ j2g_header uint64; F_b__711000275 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000272__711000278_fn__711000279_fn__711000280_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A struct{ j2g_header uint64; F_s__711000285, F_iter__711000284 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A struct{ j2g_header uint64; F_b__711000287 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000270__711000276_fn__711000277_iter__711000284__711000288_fn__711000289_fn__711000290_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A struct{ j2g_header uint64; F_s__711000297, F_n, F_iter__711000296 any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A struct{ j2g_header uint64; F_n, F_b__711000299 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_go_method_names_iter__711000296__711000300_fn__711000301_fn__711000302_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_iface_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A struct{ j2g_header uint64; F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A struct{ j2g_header uint64; F_iter__711000158, F_s__711000159, F_r, F_pn, F_core_QMARK_ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A struct{ j2g_header uint64; F_b__711000161, F_r, F_pn any; F_size__1927001038__auto__ int32; F_core_QMARK_, F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_iface_fallback_iter__711000158__711000162_fn__711000163_fn__711000164_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000034_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000034_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_fn__711000036_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_fn__711000036_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A struct{ j2g_header uint64; F_iter__711000038, F_s__711000039 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A struct{ j2g_header uint64; F_s__711000041, F_n, F_iter__711000040 any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A struct{ j2g_header uint64; F_n, F_b__711000043 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_interfaces_iter__711000038__711000044_fn__711000045_iter__711000040__711000046_fn__711000047_fn__711000048_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000178_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_method_form_fn__711000178_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_fn__711000196_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_fn__711000196_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A struct{ j2g_header uint64; F_s__711000187, F_iter__711000186 any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A struct{ j2g_header uint64; F_b__711000189 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_method_form_iter__711000186__711000190_fn__711000191_fn__711000192_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_native_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_native_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_object_fallback_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_object_fallback_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_classes_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_classes_fn__711000201_A struct{ j2g_header uint64; F_T any }

var A_arbace_j2g_dyn_proxy_classes_fn__711000201_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A struct{ j2g_header uint64; F_iter__711000205, F_s__711000206 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A struct{ j2g_header uint64; F_iter__711000207, F_n, F_s__711000208 any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A struct{ j2g_header uint64; F_n, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A struct{ j2g_header uint64; F_s__711000210, F_n, F_iter__711000209, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A struct{ j2g_header uint64; F_n, F_b__711000212 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_c any }

var A_arbace_j2g_dyn_proxy_roots_iter__711000205__711000213_fn__711000214_iter__711000207__711000215_fn__711000216_iter__711000209__711000217_fn__711000218_fn__711000219_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_public_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_public_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A struct{ j2g_header uint64; F_iter__711000013, F_s__711000014 any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A struct{ j2g_header uint64; F_b__711000016 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_roots_iter__711000013__711000017_fn__711000018_fn__711000019_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A struct{ j2g_header uint64; F_s__711000056, F_iter__711000055 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A struct{ j2g_header uint64; F_iter__711000057, F_s__711000058 any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A struct{ j2g_header uint64; F_b__711000060 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_slot_keys_iter__711000055__711000061_fn__711000062_iter__711000057__711000063_fn__711000064_fn__711000065_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000324_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_fn__711000324_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_A struct{ j2g_header uint64; F_own, F_recv, F_clash, F_ifaces, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000374_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A struct{ j2g_header uint64; F_k, F_ifaces any }

var A_arbace_j2g_dyn_sub_forms_fn__711000370_fn__711000376_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A struct{ j2g_header uint64; F_iter__711000307, F_s__711000308 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A struct{ j2g_header uint64; F_b__711000310 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000307__711000311_fn__711000312_fn__711000313_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A struct{ j2g_header uint64; F_s__711000330, F_iter__711000329 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A struct{ j2g_header uint64; F_b__711000332 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000329__711000333_fn__711000334_fn__711000335_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A struct{ j2g_header uint64; F_recv, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A struct{ j2g_header uint64; F_recv, F_iter__711000345, F_s__711000346, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A struct{ j2g_header uint64; F_recv, F_n, F_b__711000348 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000351_fn__711000352_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A struct{ j2g_header uint64; F_k, F_n any }

var A_arbace_j2g_dyn_sub_forms_iter__711000345__711000349_fn__711000350_fn__711000355_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A struct{ j2g_header uint64; F_recv, F_clash any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A struct{ j2g_header uint64; F_s__711000360, F_recv, F_clash, F_iter__711000359 any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A struct{ j2g_header uint64; F_recv, F_clash, F_b__711000362 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_dyn_sub_forms_iter__711000359__711000363_fn__711000364_fn__711000365_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_sub_name_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_sub_name_A_fn_class *jrt.Class



type A_arbace_j2g_dyn_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_dyn_tag_A_fn_class *jrt.Class
