//line aot_arbace_j2g_dyn__init.ae:1
package aot_arbace_j2g_dyn

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_dyn__init_A_Unit0__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_dyn__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_dyn__init_A_const_1) }
//line :1:1
func A_arbace_j2g_dyn__init_A_Unit1__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_dyn__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_dyn__init_A_Unit2__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, nil); A_arbace_j2g_dyn_eval711000004_loading__1927001464__auto____711000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_dyn__init_A_Unit3__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_dyn__init_A_const_1)).Equals_O__Z(A_arbace_j2g_dyn__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_dyn_eval711000008_fn__711000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_dyn_eval711000008_fn__711000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, nil); A_arbace_j2g_dyn_eval711000008_fn__711000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_j2g_dyn__init_A_Load__O() any { A_arbace_j2g_dyn__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_dyn__init_A_Unit0__O(); A_arbace_j2g_dyn__init_A_Unit1__O(); A_arbace_j2g_dyn__init_A_Unit2__O(); A_arbace_j2g_dyn__init_A_Unit3__O(); A_arbace_j2g_dyn__init_A_Unit4__O(); A_arbace_j2g_dyn__init_A_Unit5__O(); A_arbace_j2g_dyn__init_A_Unit6__O(); A_arbace_j2g_dyn__init_A_Unit7__O(); A_arbace_j2g_dyn__init_A_Unit8__O(); A_arbace_j2g_dyn__init_A_Unit9__O(); A_arbace_j2g_dyn__init_A_Unit10__O(); A_arbace_j2g_dyn__init_A_Unit11__O(); A_arbace_j2g_dyn__init_A_Unit12__O(); A_arbace_j2g_dyn__init_A_Unit13__O(); A_arbace_j2g_dyn__init_A_Unit14__O(); A_arbace_j2g_dyn__init_A_Unit15__O(); A_arbace_j2g_dyn__init_A_Unit16__O(); A_arbace_j2g_dyn__init_A_Unit17__O(); A_arbace_j2g_dyn__init_A_Unit18__O(); A_arbace_j2g_dyn__init_A_Unit19__O(); A_arbace_j2g_dyn__init_A_Unit20__O(); A_arbace_j2g_dyn__init_A_Unit21__O(); A_arbace_j2g_dyn__init_A_Unit22__O(); A_arbace_j2g_dyn__init_A_Unit23__O(); A_arbace_j2g_dyn__init_A_Unit24__O(); A_arbace_j2g_dyn__init_A_Unit25__O(); A_arbace_j2g_dyn__init_A_Unit26__O(); A_arbace_j2g_dyn__init_A_Unit27__O(); A_arbace_j2g_dyn__init_A_Unit28__O(); A_arbace_j2g_dyn__init_A_Unit29__O(); A_arbace_j2g_dyn__init_A_Unit30__O(); A_arbace_j2g_dyn__init_A_Unit31__O(); A_arbace_j2g_dyn__init_A_Unit32__O(); A_arbace_j2g_dyn__init_A_Unit33__O(); A_arbace_j2g_dyn__init_A_Unit34__O(); A_arbace_j2g_dyn__init_A_Unit35__O(); A_arbace_j2g_dyn__init_A_Unit36__O(); A_arbace_j2g_dyn__init_A_Unit37__O(); A_arbace_j2g_dyn__init_A_Unit38__O(); return nil }

















func A_arbace_j2g_dyn__init_A_Unit4__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); A_arbace_j2g_dyn__init_A_const_4.BindRoot_O__V(Lit_172); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_5)); return A_arbace_j2g_dyn__init_A_const_4 }

func A_arbace_j2g_dyn__init_A_Unit5__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_dyn_tag_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_dyn_tag_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_173, false, nil); A_arbace_j2g_dyn_tag_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_7)); return A_arbace_j2g_dyn__init_A_const_6 }

func A_arbace_j2g_dyn__init_A_Unit6__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); A_arbace_j2g_dyn__init_A_const_8.BindRoot_O__V(A_arbace_j2g_dyn__init_A_const_9); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_10)); return A_arbace_j2g_dyn__init_A_const_8 }



func A_arbace_j2g_dyn__init_A_Unit7__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); A_arbace_j2g_dyn__init_A_const_11.BindRoot_O__V(A_arbace_j2g_dyn__init_A_const_12); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_13)); return A_arbace_j2g_dyn__init_A_const_11 }




func A_arbace_j2g_dyn__init_A_Unit8__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_dyn_roots_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_dyn_roots_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_174, false, nil); A_arbace_j2g_dyn_roots_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_15)); return A_arbace_j2g_dyn__init_A_const_14 }





func A_arbace_j2g_dyn__init_A_Unit9__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_dyn_enabled_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_dyn_enabled_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, nil); A_arbace_j2g_dyn_enabled_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_17)); return A_arbace_j2g_dyn__init_A_const_16 }




func A_arbace_j2g_dyn__init_A_Unit10__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_dyn_public_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_dyn_public_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_176, false, nil); A_arbace_j2g_dyn_public_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_19)); return A_arbace_j2g_dyn__init_A_const_18 }

func A_arbace_j2g_dyn__init_A_Unit11__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_dyn_interfaces_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_dyn_interfaces_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_177, false, nil); A_arbace_j2g_dyn_interfaces_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_21)); return A_arbace_j2g_dyn__init_A_const_20 }




















func A_arbace_j2g_dyn__init_A_Unit12__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_dyn_slot_keys_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_dyn_slot_keys_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_178, false, nil); A_arbace_j2g_dyn_slot_keys_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_23)); return A_arbace_j2g_dyn__init_A_const_22 }





func A_arbace_j2g_dyn__init_A_Unit13__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(76, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_24; var tmp2 any; var root_17 any = A_arbace_j2g_dyn__init_A_const_25.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_17, arg_20) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_dyn__init_A_const_24; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_26)); return A_arbace_j2g_dyn__init_A_const_24 }

func A_arbace_j2g_dyn__init_A_Unit14__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_dyn_declarers_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_dyn_declarers_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_179, false, nil); A_arbace_j2g_dyn_declarers_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_28)); return A_arbace_j2g_dyn__init_A_const_27 }





















func A_arbace_j2g_dyn__init_A_Unit15__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(100, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_dyn_defaults_for_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_dyn_defaults_for_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_180, false, nil); A_arbace_j2g_dyn_defaults_for_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_30)); return A_arbace_j2g_dyn__init_A_const_29 }








func A_arbace_j2g_dyn__init_A_Unit16__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_dyn_box_arg_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_dyn_box_arg_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_181, false, nil); A_arbace_j2g_dyn_box_arg_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_32)); return A_arbace_j2g_dyn__init_A_const_31 }






func A_arbace_j2g_dyn__init_A_Unit17__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_j2g_dyn_convert_result_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_dyn_convert_result_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_182, false, nil); A_arbace_j2g_dyn_convert_result_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_34)); return A_arbace_j2g_dyn__init_A_const_33 }

















func A_arbace_j2g_dyn__init_A_Unit18__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_dyn_call_impl_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_dyn_call_impl_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_183, false, nil); A_arbace_j2g_dyn_call_impl_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_36)); return A_arbace_j2g_dyn__init_A_const_35 }










func A_arbace_j2g_dyn__init_A_Unit19__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_37; tmp1.BindRoot_O__V(A_arbace_j2g_dyn__init_A_const_38.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_j2g_dyn__init_A_const_37; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_39)); return A_arbace_j2g_dyn__init_A_const_37 }

func A_arbace_j2g_dyn__init_A_Unit20__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_dyn_abstract_text_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_dyn_abstract_text_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_184, false, nil); A_arbace_j2g_dyn_abstract_text_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_41)); return A_arbace_j2g_dyn__init_A_const_40 }










func A_arbace_j2g_dyn__init_A_Unit21__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_dyn_iface_fallback_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_dyn_iface_fallback_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_185, false, nil); A_arbace_j2g_dyn_iface_fallback_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_43)); return A_arbace_j2g_dyn__init_A_const_42 }












func A_arbace_j2g_dyn__init_A_Unit22__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_j2g_dyn_method_form_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_dyn_method_form_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_186, false, nil); A_arbace_j2g_dyn_method_form_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_45)); return A_arbace_j2g_dyn__init_A_const_44 }




















func A_arbace_j2g_dyn__init_A_Unit23__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_j2g_dyn_native_name_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_dyn_native_name_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_187, false, nil); A_arbace_j2g_dyn_native_name_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_47)); return A_arbace_j2g_dyn__init_A_const_46 }





func A_arbace_j2g_dyn__init_A_Unit24__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_48; tmp1.BindRoot_O__V(A_arbace_j2g_dyn__init_A_const_49.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_j2g_dyn__init_A_const_48; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_50)); return A_arbace_j2g_dyn__init_A_const_48 }







func A_arbace_j2g_dyn__init_A_Unit25__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(206, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_51; tmp1.BindRoot_O__V(A_arbace_j2g_dyn__init_A_const_52.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_j2g_dyn__init_A_const_51; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_53)); return A_arbace_j2g_dyn__init_A_const_51 }





func A_arbace_j2g_dyn__init_A_Unit26__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_54; var tmp2 any; var root_39 any = A_arbace_j2g_dyn__init_A_const_55.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_41 lang.IFn; if

	linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var root_43 any = A_arbace_j2g_dyn__init_A_const_56.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any; var root_47 any = A_arbace_j2g_dyn__init_A_const_57.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_j2g_dyn__init_A_const_48.GetRawRoot__O(); var arg_51 any = A_arbace_j2g_dyn__init_A_const_51.GetRawRoot__O(); if linked_48 == nil { arg_46 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { arg_46 = linked_48.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; if linked_44 == nil { arg_42 = ifn_45.Invoke_O__O(arg_46) } else { arg_42 = linked_44.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_43, arg_46) }; if linked_40 == nil { tmp2 = ifn_41.Invoke_O__O(arg_42) } else { tmp2 = linked_40.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_39, arg_42) }; /*line :212:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_dyn__init_A_const_54; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_58)); return A_arbace_j2g_dyn__init_A_const_54 }



func A_arbace_j2g_dyn__init_A_Unit27__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__53 any = A_arbace_j2g_dyn_proxy_classes_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_dyn_proxy_classes_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_188, false, nil); A_arbace_j2g_dyn_proxy_classes_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__53, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_60)); return A_arbace_j2g_dyn__init_A_const_59 }







func A_arbace_j2g_dyn__init_A_Unit28__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__55 any = A_arbace_j2g_dyn_sub_name_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_j2g_dyn_sub_name_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_189, false, nil); A_arbace_j2g_dyn_sub_name_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__55, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_62)); return A_arbace_j2g_dyn__init_A_const_61 }

func A_arbace_j2g_dyn__init_A_Unit29__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(226, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__57 any = A_arbace_j2g_dyn_proxy_roots_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_dyn_proxy_roots_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_190, false, nil); A_arbace_j2g_dyn_proxy_roots_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__57, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_64)); return A_arbace_j2g_dyn__init_A_const_63 }













func A_arbace_j2g_dyn__init_A_Unit30__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(240, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__59 any = A_arbace_j2g_dyn_object_fallback_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_j2g_dyn_object_fallback_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_191, false, nil); A_arbace_j2g_dyn_object_fallback_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__59, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_66)); return A_arbace_j2g_dyn__init_A_const_65 }












func A_arbace_j2g_dyn__init_A_Unit31__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__61 any = A_arbace_j2g_dyn_class_fallback_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_j2g_dyn_class_fallback_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_192, false, nil); A_arbace_j2g_dyn_class_fallback_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__61, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_68)); return A_arbace_j2g_dyn__init_A_const_67 }















func A_arbace_j2g_dyn__init_A_Unit32__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(269, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__63 any = A_arbace_j2g_dyn_ctor_infos_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_j2g_dyn_ctor_infos_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_193, false, nil); A_arbace_j2g_dyn_ctor_infos_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__63, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_70)); return A_arbace_j2g_dyn__init_A_const_69 }
































func A_arbace_j2g_dyn__init_A_Unit33__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(302, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__65 any = A_arbace_j2g_dyn_go_method_names_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_j2g_dyn_go_method_names_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_194, false, nil); A_arbace_j2g_dyn_go_method_names_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__65, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_72)); return A_arbace_j2g_dyn__init_A_const_71 }

















func A_arbace_j2g_dyn__init_A_Unit34__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(320, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__67 any = A_arbace_j2g_dyn_sub_forms_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_j2g_dyn_sub_forms_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_195, false, nil); A_arbace_j2g_dyn_sub_forms_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__67, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_74)); return A_arbace_j2g_dyn__init_A_const_73 }










































func A_arbace_j2g_dyn__init_A_Unit35__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(363, 1); A_arbace_j2g_dyn__init_A_const_75.BindRoot_O__V(A_arbace_j2g_dyn__init_A_const_76); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_75; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_77)); return A_arbace_j2g_dyn__init_A_const_75 }













func A_arbace_j2g_dyn__init_A_Unit36__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(377, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__69 any = A_arbace_j2g_dyn_fn_field_native_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_dyn_fn_field_native_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_196, false, nil); A_arbace_j2g_dyn_fn_field_native_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_79)); return A_arbace_j2g_dyn__init_A_const_78 }














func A_arbace_j2g_dyn__init_A_Unit37__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(392, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__71 any = A_arbace_j2g_dyn_aot_fn_fields_native_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_j2g_dyn_aot_fn_fields_native_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_197, false, nil); A_arbace_j2g_dyn_aot_fn_fields_native_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__71, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_81)); return A_arbace_j2g_dyn__init_A_const_80 }













func A_arbace_j2g_dyn__init_A_Unit38__O() any { A_arbace_j2g_dyn__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(406, 1); var tmp1 *lang.Var = A_arbace_j2g_dyn__init_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__73 any = A_arbace_j2g_dyn_forms_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_j2g_dyn_forms_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_198, false, nil); A_arbace_j2g_dyn_forms_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__73, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_dyn__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_dyn__init_A_const_83)); return A_arbace_j2g_dyn__init_A_const_82 }



type A_arbace_j2g_dyn__init_A struct{ jrt.Object }

var A_arbace_j2g_dyn__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_dyn__init_A_const_0 *lang.Var

var A_arbace_j2g_dyn__init_A_const_1 any

var A_arbace_j2g_dyn__init_A_const_2 any

var A_arbace_j2g_dyn__init_A_const_3 any

var A_arbace_j2g_dyn__init_A_const_4 *lang.Var

var A_arbace_j2g_dyn__init_A_const_5 any

var A_arbace_j2g_dyn__init_A_const_6 *lang.Var

var A_arbace_j2g_dyn__init_A_const_7 any

var A_arbace_j2g_dyn__init_A_const_8 *lang.Var

var A_arbace_j2g_dyn__init_A_const_9 any

var A_arbace_j2g_dyn__init_A_const_10 any

var A_arbace_j2g_dyn__init_A_const_11 *lang.Var

var A_arbace_j2g_dyn__init_A_const_12 any

var A_arbace_j2g_dyn__init_A_const_13 any

var A_arbace_j2g_dyn__init_A_const_14 *lang.Var

var A_arbace_j2g_dyn__init_A_const_15 any

var A_arbace_j2g_dyn__init_A_const_16 *lang.Var

var A_arbace_j2g_dyn__init_A_const_17 any

var A_arbace_j2g_dyn__init_A_const_18 *lang.Var

var A_arbace_j2g_dyn__init_A_const_19 any

var A_arbace_j2g_dyn__init_A_const_20 *lang.Var

var A_arbace_j2g_dyn__init_A_const_21 any

var A_arbace_j2g_dyn__init_A_const_22 *lang.Var

var A_arbace_j2g_dyn__init_A_const_23 any

var A_arbace_j2g_dyn__init_A_const_24 *lang.Var

var A_arbace_j2g_dyn__init_A_const_25 *lang.Var

var A_arbace_j2g_dyn__init_A_const_26 any

var A_arbace_j2g_dyn__init_A_const_27 *lang.Var

var A_arbace_j2g_dyn__init_A_const_28 any

var A_arbace_j2g_dyn__init_A_const_29 *lang.Var

var A_arbace_j2g_dyn__init_A_const_30 any

var A_arbace_j2g_dyn__init_A_const_31 *lang.Var

var A_arbace_j2g_dyn__init_A_const_32 any

var A_arbace_j2g_dyn__init_A_const_33 *lang.Var

var A_arbace_j2g_dyn__init_A_const_34 any

var A_arbace_j2g_dyn__init_A_const_35 *lang.Var

var A_arbace_j2g_dyn__init_A_const_36 any

var A_arbace_j2g_dyn__init_A_const_37 *lang.Var

var A_arbace_j2g_dyn__init_A_const_38 *lang.Var

var A_arbace_j2g_dyn__init_A_const_39 any

var A_arbace_j2g_dyn__init_A_const_40 *lang.Var

var A_arbace_j2g_dyn__init_A_const_41 any

var A_arbace_j2g_dyn__init_A_const_42 *lang.Var

var A_arbace_j2g_dyn__init_A_const_43 any

var A_arbace_j2g_dyn__init_A_const_44 *lang.Var

var A_arbace_j2g_dyn__init_A_const_45 any

var A_arbace_j2g_dyn__init_A_const_46 *lang.Var

var A_arbace_j2g_dyn__init_A_const_47 any

var A_arbace_j2g_dyn__init_A_const_48 *lang.Var

var A_arbace_j2g_dyn__init_A_const_49 *lang.Var

var A_arbace_j2g_dyn__init_A_const_50 any

var A_arbace_j2g_dyn__init_A_const_51 *lang.Var

var A_arbace_j2g_dyn__init_A_const_52 *lang.Var

var A_arbace_j2g_dyn__init_A_const_53 any

var A_arbace_j2g_dyn__init_A_const_54 *lang.Var

var A_arbace_j2g_dyn__init_A_const_55 *lang.Var

var A_arbace_j2g_dyn__init_A_const_56 *lang.Var

var A_arbace_j2g_dyn__init_A_const_57 *lang.Var

var A_arbace_j2g_dyn__init_A_const_58 any

var A_arbace_j2g_dyn__init_A_const_59 *lang.Var

var A_arbace_j2g_dyn__init_A_const_60 any

var A_arbace_j2g_dyn__init_A_const_61 *lang.Var

var A_arbace_j2g_dyn__init_A_const_62 any

var A_arbace_j2g_dyn__init_A_const_63 *lang.Var

var A_arbace_j2g_dyn__init_A_const_64 any

var A_arbace_j2g_dyn__init_A_const_65 *lang.Var

var A_arbace_j2g_dyn__init_A_const_66 any

var A_arbace_j2g_dyn__init_A_const_67 *lang.Var

var A_arbace_j2g_dyn__init_A_const_68 any

var A_arbace_j2g_dyn__init_A_const_69 *lang.Var

var A_arbace_j2g_dyn__init_A_const_70 any

var A_arbace_j2g_dyn__init_A_const_71 *lang.Var

var A_arbace_j2g_dyn__init_A_const_72 any

var A_arbace_j2g_dyn__init_A_const_73 *lang.Var

var A_arbace_j2g_dyn__init_A_const_74 any

var A_arbace_j2g_dyn__init_A_const_75 *lang.Var

var A_arbace_j2g_dyn__init_A_const_76 any

var A_arbace_j2g_dyn__init_A_const_77 any

var A_arbace_j2g_dyn__init_A_const_78 *lang.Var

var A_arbace_j2g_dyn__init_A_const_79 any

var A_arbace_j2g_dyn__init_A_const_80 *lang.Var

var A_arbace_j2g_dyn__init_A_const_81 any

var A_arbace_j2g_dyn__init_A_const_82 *lang.Var

var A_arbace_j2g_dyn__init_A_const_83 any

var A_arbace_j2g_dyn__init_A_init jrt.ClassInit

func A_arbace_j2g_dyn__init_A_Init() { if !A_arbace_j2g_dyn__init_A_init.Done() { A_arbace_j2g_dyn__init_A_init.Run(A_arbace_j2g_dyn__init_A_clinit) } }

func A_arbace_j2g_dyn__init_A_clinit() { A_arbace_j2g_dyn__init_A_clinit_p0(); A_arbace_j2g_dyn__init_A_clinit_p1(); A_arbace_j2g_dyn__init_A_clinit_p2(); A_arbace_j2g_dyn__init_A_clinit_p3(); A_arbace_j2g_dyn__init_A_clinit_p4(); A_arbace_j2g_dyn__init_A_clinit_p5(); A_arbace_j2g_dyn__init_A_clinit_p6() }

func A_arbace_j2g_dyn__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_dyn__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_169, 129); A_arbace_j2g_dyn__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[45]); A_arbace_j2g_dyn__init_A_const_1 = A_arbace_j2g_dyn__init_A_const_pool.A[46]; A_arbace_j2g_dyn__init_A_const_2 = A_arbace_j2g_dyn__init_A_const_pool.A[47]; A_arbace_j2g_dyn__init_A_const_3 = A_arbace_j2g_dyn__init_A_const_pool.A[48]; A_arbace_j2g_dyn__init_A_const_4 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[49]); A_arbace_j2g_dyn__init_A_const_5 = A_arbace_j2g_dyn__init_A_const_pool.A[50]; A_arbace_j2g_dyn__init_A_const_6 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[51]); A_arbace_j2g_dyn__init_A_const_7 = A_arbace_j2g_dyn__init_A_const_pool.A[52]; A_arbace_j2g_dyn__init_A_const_8 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[53]); A_arbace_j2g_dyn__init_A_const_9 = A_arbace_j2g_dyn__init_A_const_pool.A[54]; A_arbace_j2g_dyn__init_A_const_10 = A_arbace_j2g_dyn__init_A_const_pool.A[55]; A_arbace_j2g_dyn__init_A_const_11 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[56]); A_arbace_j2g_dyn__init_A_const_12 = A_arbace_j2g_dyn__init_A_const_pool.A[57] }

func A_arbace_j2g_dyn__init_A_clinit_p1() { A_arbace_j2g_dyn__init_A_const_13 = A_arbace_j2g_dyn__init_A_const_pool.A[58]; A_arbace_j2g_dyn__init_A_const_14 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[59]); A_arbace_j2g_dyn__init_A_const_15 = A_arbace_j2g_dyn__init_A_const_pool.A[60]; A_arbace_j2g_dyn__init_A_const_16 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[61]); A_arbace_j2g_dyn__init_A_const_17 = A_arbace_j2g_dyn__init_A_const_pool.A[62]; A_arbace_j2g_dyn__init_A_const_18 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[63]); A_arbace_j2g_dyn__init_A_const_19 = A_arbace_j2g_dyn__init_A_const_pool.A[64]; A_arbace_j2g_dyn__init_A_const_20 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[65]); A_arbace_j2g_dyn__init_A_const_21 = A_arbace_j2g_dyn__init_A_const_pool.A[66]; A_arbace_j2g_dyn__init_A_const_22 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[67]); A_arbace_j2g_dyn__init_A_const_23 = A_arbace_j2g_dyn__init_A_const_pool.A[68]; A_arbace_j2g_dyn__init_A_const_24 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[69]); A_arbace_j2g_dyn__init_A_const_25 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[70]) }

func A_arbace_j2g_dyn__init_A_clinit_p2() { A_arbace_j2g_dyn__init_A_const_26 = A_arbace_j2g_dyn__init_A_const_pool.A[71]; A_arbace_j2g_dyn__init_A_const_27 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[72]); A_arbace_j2g_dyn__init_A_const_28 = A_arbace_j2g_dyn__init_A_const_pool.A[73]; A_arbace_j2g_dyn__init_A_const_29 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[74]); A_arbace_j2g_dyn__init_A_const_30 = A_arbace_j2g_dyn__init_A_const_pool.A[75]; A_arbace_j2g_dyn__init_A_const_31 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[76]); A_arbace_j2g_dyn__init_A_const_32 = A_arbace_j2g_dyn__init_A_const_pool.A[77]; A_arbace_j2g_dyn__init_A_const_33 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[78]); A_arbace_j2g_dyn__init_A_const_34 = A_arbace_j2g_dyn__init_A_const_pool.A[79]; A_arbace_j2g_dyn__init_A_const_35 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[80]); A_arbace_j2g_dyn__init_A_const_36 = A_arbace_j2g_dyn__init_A_const_pool.A[81]; A_arbace_j2g_dyn__init_A_const_37 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[82]); A_arbace_j2g_dyn__init_A_const_38 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[83]) }

func A_arbace_j2g_dyn__init_A_clinit_p3() { A_arbace_j2g_dyn__init_A_const_39 = A_arbace_j2g_dyn__init_A_const_pool.A[84]; A_arbace_j2g_dyn__init_A_const_40 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[85]); A_arbace_j2g_dyn__init_A_const_41 = A_arbace_j2g_dyn__init_A_const_pool.A[86]; A_arbace_j2g_dyn__init_A_const_42 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[87]); A_arbace_j2g_dyn__init_A_const_43 = A_arbace_j2g_dyn__init_A_const_pool.A[88]; A_arbace_j2g_dyn__init_A_const_44 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[89]); A_arbace_j2g_dyn__init_A_const_45 = A_arbace_j2g_dyn__init_A_const_pool.A[90]; A_arbace_j2g_dyn__init_A_const_46 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[91]); A_arbace_j2g_dyn__init_A_const_47 = A_arbace_j2g_dyn__init_A_const_pool.A[92]; A_arbace_j2g_dyn__init_A_const_48 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[93]); A_arbace_j2g_dyn__init_A_const_49 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[94]); A_arbace_j2g_dyn__init_A_const_50 = A_arbace_j2g_dyn__init_A_const_pool.A[95]; A_arbace_j2g_dyn__init_A_const_51 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[96]) }

func A_arbace_j2g_dyn__init_A_clinit_p4() { A_arbace_j2g_dyn__init_A_const_52 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[97]); A_arbace_j2g_dyn__init_A_const_53 = A_arbace_j2g_dyn__init_A_const_pool.A[98]; A_arbace_j2g_dyn__init_A_const_54 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[99]); A_arbace_j2g_dyn__init_A_const_55 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[100]); A_arbace_j2g_dyn__init_A_const_56 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[101]); A_arbace_j2g_dyn__init_A_const_57 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[102]); A_arbace_j2g_dyn__init_A_const_58 = A_arbace_j2g_dyn__init_A_const_pool.A[103]; A_arbace_j2g_dyn__init_A_const_59 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[104]); A_arbace_j2g_dyn__init_A_const_60 = A_arbace_j2g_dyn__init_A_const_pool.A[105]; A_arbace_j2g_dyn__init_A_const_61 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[106]); A_arbace_j2g_dyn__init_A_const_62 = A_arbace_j2g_dyn__init_A_const_pool.A[107]; A_arbace_j2g_dyn__init_A_const_63 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[108]); A_arbace_j2g_dyn__init_A_const_64 = A_arbace_j2g_dyn__init_A_const_pool.A[109] }

func A_arbace_j2g_dyn__init_A_clinit_p5() { A_arbace_j2g_dyn__init_A_const_65 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[110]); A_arbace_j2g_dyn__init_A_const_66 = A_arbace_j2g_dyn__init_A_const_pool.A[111]; A_arbace_j2g_dyn__init_A_const_67 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[112]); A_arbace_j2g_dyn__init_A_const_68 = A_arbace_j2g_dyn__init_A_const_pool.A[113]; A_arbace_j2g_dyn__init_A_const_69 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[114]); A_arbace_j2g_dyn__init_A_const_70 = A_arbace_j2g_dyn__init_A_const_pool.A[115]; A_arbace_j2g_dyn__init_A_const_71 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[116]); A_arbace_j2g_dyn__init_A_const_72 = A_arbace_j2g_dyn__init_A_const_pool.A[117]; A_arbace_j2g_dyn__init_A_const_73 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[118]); A_arbace_j2g_dyn__init_A_const_74 = A_arbace_j2g_dyn__init_A_const_pool.A[119]; A_arbace_j2g_dyn__init_A_const_75 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[120]); A_arbace_j2g_dyn__init_A_const_76 = A_arbace_j2g_dyn__init_A_const_pool.A[121]; A_arbace_j2g_dyn__init_A_const_77 = A_arbace_j2g_dyn__init_A_const_pool.A[122] }

func A_arbace_j2g_dyn__init_A_clinit_p6() { A_arbace_j2g_dyn__init_A_const_78 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[123]); A_arbace_j2g_dyn__init_A_const_79 = A_arbace_j2g_dyn__init_A_const_pool.A[124]; A_arbace_j2g_dyn__init_A_const_80 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[125]); A_arbace_j2g_dyn__init_A_const_81 = A_arbace_j2g_dyn__init_A_const_pool.A[126]; A_arbace_j2g_dyn__init_A_const_82 = lang.Var_Cast(A_arbace_j2g_dyn__init_A_const_pool.A[127]); A_arbace_j2g_dyn__init_A_const_83 = A_arbace_j2g_dyn__init_A_const_pool.A[128] }

func A_arbace_j2g_dyn__init_A_New() *A_arbace_j2g_dyn__init_A { A_arbace_j2g_dyn__init_A_Init(); t := &A_arbace_j2g_dyn__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_dyn__init_A) Ctor() {}

func (t *A_arbace_j2g_dyn__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_dyn__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_dyn__init_A_class }

func (t *A_arbace_j2g_dyn__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_dyn__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_dyn__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_dyn__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_dyn__init_A); return ok }

func A_arbace_j2g_dyn__init_A_Cast(x any) *A_arbace_j2g_dyn__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_dyn__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_dyn__init_A_class)) }; return v }
