//line aot_arbace_repr_clojure_rename__init.ae:1
package aot_arbace_repr_clojure_rename

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rename__init_A_Unit0__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_clojure_rename__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rename__init_A_const_1) }
//line :1:1
func A_arbace_repr_clojure_rename__init_A_Unit1__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_clojure_rename__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_2)) }
//line :1:1
func A_arbace_repr_clojure_rename__init_A_Unit2__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_clojure_rename__init_A_Unit3__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_clojure_rename__init_A_const_1)).Equals_O__Z(A_arbace_repr_clojure_rename__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_clojure_rename__init_A_Load__O() any { A_arbace_repr_clojure_rename__init_A_Init(); jrt.StartCheck(); A_arbace_repr_clojure_rename__init_A_Unit0__O(); A_arbace_repr_clojure_rename__init_A_Unit1__O(); A_arbace_repr_clojure_rename__init_A_Unit2__O(); A_arbace_repr_clojure_rename__init_A_Unit3__O(); A_arbace_repr_clojure_rename__init_A_Unit4__O(); A_arbace_repr_clojure_rename__init_A_Unit5__O(); A_arbace_repr_clojure_rename__init_A_Unit6__O(); A_arbace_repr_clojure_rename__init_A_Unit7__O(); A_arbace_repr_clojure_rename__init_A_Unit8__O(); A_arbace_repr_clojure_rename__init_A_Unit9__O(); A_arbace_repr_clojure_rename__init_A_Unit10__O(); A_arbace_repr_clojure_rename__init_A_Unit11__O(); A_arbace_repr_clojure_rename__init_A_Unit12__O(); A_arbace_repr_clojure_rename__init_A_Unit13__O(); A_arbace_repr_clojure_rename__init_A_Unit14__O(); A_arbace_repr_clojure_rename__init_A_Unit15__O(); A_arbace_repr_clojure_rename__init_A_Unit16__O(); return nil }























func A_arbace_repr_clojure_rename__init_A_Unit4__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); A_arbace_repr_clojure_rename__init_A_const_4.BindRoot_O__V(A_arbace_repr_clojure_rename__init_A_const_5); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_6)); return A_arbace_repr_clojure_rename__init_A_const_4 }














func A_arbace_repr_clojure_rename__init_A_Unit5__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); A_arbace_repr_clojure_rename__init_A_const_7.BindRoot_O__V(A_arbace_repr_clojure_rename__init_A_const_8); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_9)); return A_arbace_repr_clojure_rename__init_A_const_7 }



func A_arbace_repr_clojure_rename__init_A_Unit6__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_10; var tmp2 any = A_arbace_repr_clojure_rename_alt_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_clojure_rename_alt_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_repr_clojure_rename_alt_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_11)); return A_arbace_repr_clojure_rename__init_A_const_10 }







func A_arbace_repr_clojure_rename__init_A_Unit7__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_repr_clojure_rename__init_A_const_12.BindRoot_O__V(Lit_20); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_13)); return A_arbace_repr_clojure_rename__init_A_const_12 }


func A_arbace_repr_clojure_rename__init_A_Unit8__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); A_arbace_repr_clojure_rename__init_A_const_14.BindRoot_O__V(Lit_21); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_15)); return A_arbace_repr_clojure_rename__init_A_const_14 }
func A_arbace_repr_clojure_rename__init_A_Unit9__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_16; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_repr_clojure_rename__init_A_const_17.GetRawRoot__O()).Invoke_O_O_O__O(Lit_5, A_arbace_repr_clojure_rename__init_A_const_14.GetRawRoot__O(), Lit_22)); var tmp2 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_16; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_18)); return A_arbace_repr_clojure_rename__init_A_const_16 }

func A_arbace_repr_clojure_rename__init_A_Unit10__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_19; var tmp2 any = A_arbace_repr_clojure_rename_patterns_of_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_repr_clojure_rename_patterns_of_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_repr_clojure_rename_patterns_of_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_20)); return A_arbace_repr_clojure_rename__init_A_const_19 }















func A_arbace_repr_clojure_rename__init_A_Unit11__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_21; var tmp2 any; var root_11 any = A_arbace_repr_clojure_rename__init_A_const_19.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, A_arbace_repr_clojure_rename_patterns_of_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = Lit_15; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*A_arbace_repr_clojure_rename_patterns_of_A).Invoke_O_O__O(root_11, arg_14) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_21; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_22)); return A_arbace_repr_clojure_rename__init_A_const_21 }

func A_arbace_repr_clojure_rename__init_A_Unit12__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_23; var tmp2 any; var root_15 any = A_arbace_repr_clojure_rename__init_A_const_19.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, A_arbace_repr_clojure_rename_patterns_of_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = Lit_12; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*A_arbace_repr_clojure_rename_patterns_of_A).Invoke_O_O__O(root_15, arg_18) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_23; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_24)); return A_arbace_repr_clojure_rename__init_A_const_23 }

func A_arbace_repr_clojure_rename__init_A_Unit13__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_25; var tmp2 any; var root_19 any = A_arbace_repr_clojure_rename__init_A_const_26.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_21 lang.IFn; if


	linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename__init_A_const_17.GetRawRoot__O()); var tmp4 any; var root_29 any = A_arbace_repr_clojure_rename__init_A_const_10.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_repr_clojure_rename__init_A_const_4.GetRawRoot__O(); var arg_33 any = Lit_9; if linked_30 == nil { tmp4 = ifn_31.Invoke_O_O__O(arg_32, arg_33) } else { tmp4 = linked_30.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_29, arg_32, arg_33) }; arg_22 = tmp3.Invoke_O_O_O__O(Lit_24, tmp4, Lit_25); if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_19, arg_22) }; /*line :82:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_25; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_27)); return A_arbace_repr_clojure_rename__init_A_const_25 }




func A_arbace_repr_clojure_rename__init_A_Unit14__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_28; var tmp2 any; var root_34 any = A_arbace_repr_clojure_rename__init_A_const_26.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_36 lang.IFn; if
								linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename__init_A_const_17.GetRawRoot__O()); var tmp4 any; var root_44 any = A_arbace_repr_clojure_rename__init_A_const_10.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_repr_clojure_rename__init_A_const_4.GetRawRoot__O(); var arg_48 any = Lit_9; if linked_45 == nil { tmp4 = ifn_46.Invoke_O_O__O(arg_47, arg_48) } else { tmp4 = linked_45.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_44, arg_47, arg_48) }; arg_37 = tmp3.Invoke_O_O_O__O(Lit_24, tmp4, Lit_26); if linked_35 == nil { tmp2 = ifn_36.Invoke_O__O(arg_37) } else { tmp2 = linked_35.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_34, arg_37) }; /*line :87:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_28; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_29)); return A_arbace_repr_clojure_rename__init_A_const_28 }


func A_arbace_repr_clojure_rename__init_A_Unit15__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_30; var tmp2 any = A_arbace_repr_clojure_rename_rename_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_repr_clojure_rename_rename_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_repr_clojure_rename_rename_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_31)); return A_arbace_repr_clojure_rename__init_A_const_30 }




func A_arbace_repr_clojure_rename__init_A_Unit16__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_32; var tmp2 any = A_arbace_repr_clojure_rename_unrename_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_repr_clojure_rename_unrename_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_repr_clojure_rename_unrename_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_33)); return A_arbace_repr_clojure_rename__init_A_const_32 }



type A_arbace_repr_clojure_rename__init_A struct{ jrt.Object }

var A_arbace_repr_clojure_rename__init_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rename__init_A_const_0 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_1 any

var A_arbace_repr_clojure_rename__init_A_const_2 any

var A_arbace_repr_clojure_rename__init_A_const_3 any

var A_arbace_repr_clojure_rename__init_A_const_4 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_5 any

var A_arbace_repr_clojure_rename__init_A_const_6 any

var A_arbace_repr_clojure_rename__init_A_const_7 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_8 any

var A_arbace_repr_clojure_rename__init_A_const_9 any

var A_arbace_repr_clojure_rename__init_A_const_10 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_11 any

var A_arbace_repr_clojure_rename__init_A_const_12 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_13 any

var A_arbace_repr_clojure_rename__init_A_const_14 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_15 any

var A_arbace_repr_clojure_rename__init_A_const_16 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_17 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_18 any

var A_arbace_repr_clojure_rename__init_A_const_19 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_20 any

var A_arbace_repr_clojure_rename__init_A_const_21 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_22 any

var A_arbace_repr_clojure_rename__init_A_const_23 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_24 any

var A_arbace_repr_clojure_rename__init_A_const_25 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_26 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_27 any

var A_arbace_repr_clojure_rename__init_A_const_28 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_29 any

var A_arbace_repr_clojure_rename__init_A_const_30 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_31 any

var A_arbace_repr_clojure_rename__init_A_const_32 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_33 any

var A_arbace_repr_clojure_rename__init_A_init jrt.ClassInit

func A_arbace_repr_clojure_rename__init_A_Init() { if !A_arbace_repr_clojure_rename__init_A_init.Done() { A_arbace_repr_clojure_rename__init_A_init.Run(A_arbace_repr_clojure_rename__init_A_clinit) } }

func A_arbace_repr_clojure_rename__init_A_clinit() { A_arbace_repr_clojure_rename__init_A_clinit_p0(); A_arbace_repr_clojure_rename__init_A_clinit_p1(); A_arbace_repr_clojure_rename__init_A_clinit_p2() }

func A_arbace_repr_clojure_rename__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rename__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_16, 45); A_arbace_repr_clojure_rename__init_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[11]); A_arbace_repr_clojure_rename__init_A_const_1 = A_arbace_repr_clojure_rename__init_A_const_pool.A[12]; A_arbace_repr_clojure_rename__init_A_const_2 = A_arbace_repr_clojure_rename__init_A_const_pool.A[13]; A_arbace_repr_clojure_rename__init_A_const_3 = A_arbace_repr_clojure_rename__init_A_const_pool.A[14]; A_arbace_repr_clojure_rename__init_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[15]); A_arbace_repr_clojure_rename__init_A_const_5 = A_arbace_repr_clojure_rename__init_A_const_pool.A[16]; A_arbace_repr_clojure_rename__init_A_const_6 = A_arbace_repr_clojure_rename__init_A_const_pool.A[17]; A_arbace_repr_clojure_rename__init_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[18]); A_arbace_repr_clojure_rename__init_A_const_8 = A_arbace_repr_clojure_rename__init_A_const_pool.A[19]; A_arbace_repr_clojure_rename__init_A_const_9 = A_arbace_repr_clojure_rename__init_A_const_pool.A[20]; A_arbace_repr_clojure_rename__init_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[21]); A_arbace_repr_clojure_rename__init_A_const_11 = A_arbace_repr_clojure_rename__init_A_const_pool.A[22]; A_arbace_repr_clojure_rename__init_A_const_12 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[23]) }

func A_arbace_repr_clojure_rename__init_A_clinit_p1() { A_arbace_repr_clojure_rename__init_A_const_13 = A_arbace_repr_clojure_rename__init_A_const_pool.A[24]; A_arbace_repr_clojure_rename__init_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[25]); A_arbace_repr_clojure_rename__init_A_const_15 = A_arbace_repr_clojure_rename__init_A_const_pool.A[26]; A_arbace_repr_clojure_rename__init_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[27]); A_arbace_repr_clojure_rename__init_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[28]); A_arbace_repr_clojure_rename__init_A_const_18 = A_arbace_repr_clojure_rename__init_A_const_pool.A[29]; A_arbace_repr_clojure_rename__init_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[30]); A_arbace_repr_clojure_rename__init_A_const_20 = A_arbace_repr_clojure_rename__init_A_const_pool.A[31]; A_arbace_repr_clojure_rename__init_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[32]); A_arbace_repr_clojure_rename__init_A_const_22 = A_arbace_repr_clojure_rename__init_A_const_pool.A[33]; A_arbace_repr_clojure_rename__init_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[34]); A_arbace_repr_clojure_rename__init_A_const_24 = A_arbace_repr_clojure_rename__init_A_const_pool.A[35]; A_arbace_repr_clojure_rename__init_A_const_25 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[36]) }

func A_arbace_repr_clojure_rename__init_A_clinit_p2() { A_arbace_repr_clojure_rename__init_A_const_26 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[37]); A_arbace_repr_clojure_rename__init_A_const_27 = A_arbace_repr_clojure_rename__init_A_const_pool.A[38]; A_arbace_repr_clojure_rename__init_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[39]); A_arbace_repr_clojure_rename__init_A_const_29 = A_arbace_repr_clojure_rename__init_A_const_pool.A[40]; A_arbace_repr_clojure_rename__init_A_const_30 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[41]); A_arbace_repr_clojure_rename__init_A_const_31 = A_arbace_repr_clojure_rename__init_A_const_pool.A[42]; A_arbace_repr_clojure_rename__init_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[43]); A_arbace_repr_clojure_rename__init_A_const_33 = A_arbace_repr_clojure_rename__init_A_const_pool.A[44] }

func A_arbace_repr_clojure_rename__init_A_New() *A_arbace_repr_clojure_rename__init_A { A_arbace_repr_clojure_rename__init_A_Init(); t := &A_arbace_repr_clojure_rename__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename__init_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename__init_A_class }

func (t *A_arbace_repr_clojure_rename__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename__init_A); return ok }

func A_arbace_repr_clojure_rename__init_A_Cast(x any) *A_arbace_repr_clojure_rename__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename__init_A_class)) }; return v }
