//line aot_arbace_repr_clojure_rename__init.ae:1
package aot_arbace_repr_clojure_rename

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rename__init_A_Unit0__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_clojure_rename__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rename__init_A_const_1) }
//line :1:1
func A_arbace_repr_clojure_rename__init_A_Unit1__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_clojure_rename__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_2)) }
//line :1:1
func A_arbace_repr_clojure_rename__init_A_Unit2__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_repr_clojure_rename__init_A_Unit3__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_clojure_rename__init_A_const_1)).Equals_O__Z(A_arbace_repr_clojure_rename__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_repr_clojure_rename__init_A_Load__O() any { A_arbace_repr_clojure_rename__init_A_Init(); jrt.StartCheck(); A_arbace_repr_clojure_rename__init_A_Unit0__O(); A_arbace_repr_clojure_rename__init_A_Unit1__O(); A_arbace_repr_clojure_rename__init_A_Unit2__O(); A_arbace_repr_clojure_rename__init_A_Unit3__O(); A_arbace_repr_clojure_rename__init_A_Unit4__O(); A_arbace_repr_clojure_rename__init_A_Unit5__O(); A_arbace_repr_clojure_rename__init_A_Unit6__O(); A_arbace_repr_clojure_rename__init_A_Unit7__O(); A_arbace_repr_clojure_rename__init_A_Unit8__O(); A_arbace_repr_clojure_rename__init_A_Unit9__O(); A_arbace_repr_clojure_rename__init_A_Unit10__O(); A_arbace_repr_clojure_rename__init_A_Unit11__O(); A_arbace_repr_clojure_rename__init_A_Unit12__O(); A_arbace_repr_clojure_rename__init_A_Unit13__O(); A_arbace_repr_clojure_rename__init_A_Unit14__O(); A_arbace_repr_clojure_rename__init_A_Unit15__O(); A_arbace_repr_clojure_rename__init_A_Unit16__O(); return nil }























func A_arbace_repr_clojure_rename__init_A_Unit4__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); A_arbace_repr_clojure_rename__init_A_const_4.BindRoot_O__V(A_arbace_repr_clojure_rename__init_A_const_5); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_6)); return A_arbace_repr_clojure_rename__init_A_const_4 }














func A_arbace_repr_clojure_rename__init_A_Unit5__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); A_arbace_repr_clojure_rename__init_A_const_7.BindRoot_O__V(A_arbace_repr_clojure_rename__init_A_const_8); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_9)); return A_arbace_repr_clojure_rename__init_A_const_7 }



func A_arbace_repr_clojure_rename__init_A_Unit6__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_repr_clojure_rename_alt_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_clojure_rename_alt_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_repr_clojure_rename_alt_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_11)); return A_arbace_repr_clojure_rename__init_A_const_10 }







func A_arbace_repr_clojure_rename__init_A_Unit7__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); A_arbace_repr_clojure_rename__init_A_const_12.BindRoot_O__V(Lit_20); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_13)); return A_arbace_repr_clojure_rename__init_A_const_12 }


func A_arbace_repr_clojure_rename__init_A_Unit8__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); A_arbace_repr_clojure_rename__init_A_const_14.BindRoot_O__V(Lit_21); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_15)); return A_arbace_repr_clojure_rename__init_A_const_14 }
func A_arbace_repr_clojure_rename__init_A_Unit9__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_16; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_repr_clojure_rename__init_A_const_17.GetRawRoot__O()).Invoke_O_O_O__O(Lit_5, A_arbace_repr_clojure_rename__init_A_const_14.GetRawRoot__O(), Lit_22)); var tmp2 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_16; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_18)); return A_arbace_repr_clojure_rename__init_A_const_16 }

func A_arbace_repr_clojure_rename__init_A_Unit10__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_repr_clojure_rename_patterns_of_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_clojure_rename_patterns_of_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_repr_clojure_rename_patterns_of_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_20)); return A_arbace_repr_clojure_rename__init_A_const_19 }















func A_arbace_repr_clojure_rename__init_A_Unit11__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(78, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_21; var tmp2 any; var root_15 any = A_arbace_repr_clojure_rename__init_A_const_19.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, A_arbace_repr_clojure_rename_patterns_of_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = Lit_15; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*A_arbace_repr_clojure_rename_patterns_of_A).Invoke_O_O__O(root_15, arg_18) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_21; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_22)); return A_arbace_repr_clojure_rename__init_A_const_21 }

func A_arbace_repr_clojure_rename__init_A_Unit12__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_23; var tmp2 any; var root_19 any = A_arbace_repr_clojure_rename__init_A_const_19.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, A_arbace_repr_clojure_rename_patterns_of_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = Lit_12; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*A_arbace_repr_clojure_rename_patterns_of_A).Invoke_O_O__O(root_19, arg_22) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_23; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_24)); return A_arbace_repr_clojure_rename__init_A_const_23 }

func A_arbace_repr_clojure_rename__init_A_Unit13__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_25; var tmp2 any; var root_23 any = A_arbace_repr_clojure_rename__init_A_const_26.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_25 lang.IFn; if


	linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename__init_A_const_17.GetRawRoot__O()); var tmp4 any; var root_33 any = A_arbace_repr_clojure_rename__init_A_const_10.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = A_arbace_repr_clojure_rename__init_A_const_4.GetRawRoot__O(); var arg_37 any = Lit_9; if linked_34 == nil { tmp4 = ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { tmp4 = linked_34.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) }; arg_26 = tmp3.Invoke_O_O_O__O(Lit_24, tmp4, Lit_25); if linked_24 == nil { tmp2 = ifn_25.Invoke_O__O(arg_26) } else { tmp2 = linked_24.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_23, arg_26) }; /*line :82:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_25; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_27)); return A_arbace_repr_clojure_rename__init_A_const_25 }




func A_arbace_repr_clojure_rename__init_A_Unit14__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_28; var tmp2 any; var root_38 any = A_arbace_repr_clojure_rename__init_A_const_26.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_40 lang.IFn; if
								linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename__init_A_const_17.GetRawRoot__O()); var tmp4 any; var root_48 any = A_arbace_repr_clojure_rename__init_A_const_10.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = A_arbace_repr_clojure_rename__init_A_const_4.GetRawRoot__O(); var arg_52 any = Lit_9; if linked_49 == nil { tmp4 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { tmp4 = linked_49.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }; arg_41 = tmp3.Invoke_O_O_O__O(Lit_24, tmp4, Lit_26); if linked_39 == nil { tmp2 = ifn_40.Invoke_O__O(arg_41) } else { tmp2 = linked_39.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_38, arg_41) }; /*line :87:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_28; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_29)); return A_arbace_repr_clojure_rename__init_A_const_28 }


func A_arbace_repr_clojure_rename__init_A_Unit15__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_repr_clojure_rename_rename_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_repr_clojure_rename_rename_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_repr_clojure_rename_rename_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_31)); return A_arbace_repr_clojure_rename__init_A_const_30 }




func A_arbace_repr_clojure_rename__init_A_Unit16__O() any { A_arbace_repr_clojure_rename__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_repr_clojure_rename_unrename_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_repr_clojure_rename_unrename_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_repr_clojure_rename_unrename_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure_rename__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure_rename__init_A_const_33)); return A_arbace_repr_clojure_rename__init_A_const_32 }



type A_arbace_repr_clojure_rename__init_A struct{ jrt.Object }

var A_arbace_repr_clojure_rename__init_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rename__init_A_const_0 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_1 any

var A_arbace_repr_clojure_rename__init_A_const_2 any

var A_arbace_repr_clojure_rename__init_A_const_3 any

var A_arbace_repr_clojure_rename__init_A_const_4 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_5 any

var A_arbace_repr_clojure_rename__init_A_const_6 any

var A_arbace_repr_clojure_rename__init_A_const_7 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_8 any

var A_arbace_repr_clojure_rename__init_A_const_9 any

var A_arbace_repr_clojure_rename__init_A_const_10 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_11 any

var A_arbace_repr_clojure_rename__init_A_const_12 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_13 any

var A_arbace_repr_clojure_rename__init_A_const_14 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_15 any

var A_arbace_repr_clojure_rename__init_A_const_16 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_17 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_18 any

var A_arbace_repr_clojure_rename__init_A_const_19 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_20 any

var A_arbace_repr_clojure_rename__init_A_const_21 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_22 any

var A_arbace_repr_clojure_rename__init_A_const_23 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_24 any

var A_arbace_repr_clojure_rename__init_A_const_25 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_26 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_27 any

var A_arbace_repr_clojure_rename__init_A_const_28 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_29 any

var A_arbace_repr_clojure_rename__init_A_const_30 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_31 any

var A_arbace_repr_clojure_rename__init_A_const_32 *lang.Var

var A_arbace_repr_clojure_rename__init_A_const_33 any

var A_arbace_repr_clojure_rename__init_A_init jrt.ClassInit

func A_arbace_repr_clojure_rename__init_A_Init() { if !A_arbace_repr_clojure_rename__init_A_init.Done() { A_arbace_repr_clojure_rename__init_A_init.Run(A_arbace_repr_clojure_rename__init_A_clinit) } }

func A_arbace_repr_clojure_rename__init_A_clinit() { A_arbace_repr_clojure_rename__init_A_clinit_p0(); A_arbace_repr_clojure_rename__init_A_clinit_p1(); A_arbace_repr_clojure_rename__init_A_clinit_p2() }

func A_arbace_repr_clojure_rename__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rename__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_16, 45); A_arbace_repr_clojure_rename__init_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[11]); A_arbace_repr_clojure_rename__init_A_const_1 = A_arbace_repr_clojure_rename__init_A_const_pool.A[12]; A_arbace_repr_clojure_rename__init_A_const_2 = A_arbace_repr_clojure_rename__init_A_const_pool.A[13]; A_arbace_repr_clojure_rename__init_A_const_3 = A_arbace_repr_clojure_rename__init_A_const_pool.A[14]; A_arbace_repr_clojure_rename__init_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[15]); A_arbace_repr_clojure_rename__init_A_const_5 = A_arbace_repr_clojure_rename__init_A_const_pool.A[16]; A_arbace_repr_clojure_rename__init_A_const_6 = A_arbace_repr_clojure_rename__init_A_const_pool.A[17]; A_arbace_repr_clojure_rename__init_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[18]); A_arbace_repr_clojure_rename__init_A_const_8 = A_arbace_repr_clojure_rename__init_A_const_pool.A[19]; A_arbace_repr_clojure_rename__init_A_const_9 = A_arbace_repr_clojure_rename__init_A_const_pool.A[20]; A_arbace_repr_clojure_rename__init_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[21]); A_arbace_repr_clojure_rename__init_A_const_11 = A_arbace_repr_clojure_rename__init_A_const_pool.A[22]; A_arbace_repr_clojure_rename__init_A_const_12 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[23]) }

func A_arbace_repr_clojure_rename__init_A_clinit_p1() { A_arbace_repr_clojure_rename__init_A_const_13 = A_arbace_repr_clojure_rename__init_A_const_pool.A[24]; A_arbace_repr_clojure_rename__init_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[25]); A_arbace_repr_clojure_rename__init_A_const_15 = A_arbace_repr_clojure_rename__init_A_const_pool.A[26]; A_arbace_repr_clojure_rename__init_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[27]); A_arbace_repr_clojure_rename__init_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[28]); A_arbace_repr_clojure_rename__init_A_const_18 = A_arbace_repr_clojure_rename__init_A_const_pool.A[29]; A_arbace_repr_clojure_rename__init_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[30]); A_arbace_repr_clojure_rename__init_A_const_20 = A_arbace_repr_clojure_rename__init_A_const_pool.A[31]; A_arbace_repr_clojure_rename__init_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[32]); A_arbace_repr_clojure_rename__init_A_const_22 = A_arbace_repr_clojure_rename__init_A_const_pool.A[33]; A_arbace_repr_clojure_rename__init_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[34]); A_arbace_repr_clojure_rename__init_A_const_24 = A_arbace_repr_clojure_rename__init_A_const_pool.A[35]; A_arbace_repr_clojure_rename__init_A_const_25 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[36]) }

func A_arbace_repr_clojure_rename__init_A_clinit_p2() { A_arbace_repr_clojure_rename__init_A_const_26 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[37]); A_arbace_repr_clojure_rename__init_A_const_27 = A_arbace_repr_clojure_rename__init_A_const_pool.A[38]; A_arbace_repr_clojure_rename__init_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[39]); A_arbace_repr_clojure_rename__init_A_const_29 = A_arbace_repr_clojure_rename__init_A_const_pool.A[40]; A_arbace_repr_clojure_rename__init_A_const_30 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[41]); A_arbace_repr_clojure_rename__init_A_const_31 = A_arbace_repr_clojure_rename__init_A_const_pool.A[42]; A_arbace_repr_clojure_rename__init_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_rename__init_A_const_pool.A[43]); A_arbace_repr_clojure_rename__init_A_const_33 = A_arbace_repr_clojure_rename__init_A_const_pool.A[44] }

func A_arbace_repr_clojure_rename__init_A_New() *A_arbace_repr_clojure_rename__init_A { A_arbace_repr_clojure_rename__init_A_Init(); t := &A_arbace_repr_clojure_rename__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename__init_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename__init_A_class }

func (t *A_arbace_repr_clojure_rename__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename__init_A); return ok }

func A_arbace_repr_clojure_rename__init_A_Cast(x any) *A_arbace_repr_clojure_rename__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename__init_A_class)) }; return v }
