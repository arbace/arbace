//line aot_arbace_repr_clojure_rename.ae:1
package aot_arbace_repr_clojure_rename

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_New() *A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rename_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rename_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_New() *A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rename_A_const_8), A_arbace_repr_clojure_rename_A_const_6.GetRawRoot__O(), A_arbace_repr_clojure_rename_A_const_7) }














































func A_arbace_repr_clojure_rename_alt_A_New() *A_arbace_repr_clojure_rename_alt_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_alt_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_repr_clojure_rename_alt_A) Ctor() {}
//line :48:1
func (t *A_arbace_repr_clojure_rename_alt_A) Invoke_O_O_O__O(self, names__0, sep__1 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_9.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_10.GetRawRoot__O()); var tmp3 any = A_arbace_repr_clojure_rename_alt_fn__557000013_A_New_O(sep__1); var tmp4 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_clojure_rename_alt_fn__557000013_A_fn_class
//line :53:1
	if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_clojure_rename_alt_fn__557000013_A_fn_class = fncls__2d; tmp4 = fncls__2d } else { tmp4 = fncls__2 }
	return tmp1.Invoke_O_O__O(Lit_1, tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_13.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_clojure_rename_A_const_15.GetRawRoot__O(), A_arbace_repr_clojure_rename_A_const_16.GetRawRoot__O()), names__0))) }
//line :53:1
func A_arbace_repr_clojure_rename_alt_fn__557000013_A_New_O(p0 any) *A_arbace_repr_clojure_rename_alt_fn__557000013_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_alt_fn__557000013_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_A) Ctor_O(c__sep any) { t.F_sep = c__sep }
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_9.GetRawRoot__O()); var tmp2 any = t.F_sep; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_10.GetRawRoot__O()); var tmp4 any = A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_New(); var tmp5 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_11.GetRawRoot__O()).Invoke_O_O__O(n__1, A_arbace_repr_clojure_rename_A_const_12))) }
//line :53:1
func A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_New() *A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A) Ctor() {}
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A) Invoke_O_O__O(self, p1__557000012_SHARP___1 any) any { return jrt.Pattern_Quote_String__String_NoInit(jrt.String_Cast(p1__557000012_SHARP___1)).Ref() }


























func A_arbace_repr_clojure_rename_rename_A_New() *A_arbace_repr_clojure_rename_rename_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_rename_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_repr_clojure_rename_rename_A) Ctor() {}
//line :80:1
func (t *A_arbace_repr_clojure_rename_rename_A) Invoke_O_O__O(self, s__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_18.GetRawRoot__O()); var tmp3 any = A_arbace_repr_clojure_rename_rename_fn__557000018_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_clojure_rename_rename_fn__557000018_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_repr_clojure_rename_rename_fn__557000018_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; return tmp1.Invoke_O_O_O__O(tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), s__0, A_arbace_repr_clojure_rename_A_const_20.GetRawRoot__O()), A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(), Lit_5) }
//line :83:1
func A_arbace_repr_clojure_rename_rename_fn__557000018_A_New() *A_arbace_repr_clojure_rename_rename_fn__557000018_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_rename_fn__557000018_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_clojure_rename_rename_fn__557000018_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_clojure_rename_rename_fn__557000018_A) Invoke_O_O_O__O(self, s__1, p__2 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O()).Invoke_O_O_O__O(s__1, p__2, Lit_6) }










type A_arbace_repr_clojure_rename_A struct{ jrt.Object }

var A_arbace_repr_clojure_rename_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rename_A_const_0 *lang.Var

var A_arbace_repr_clojure_rename_A_const_1 *lang.Var

var A_arbace_repr_clojure_rename_A_const_2 any

var A_arbace_repr_clojure_rename_A_const_3 any

var A_arbace_repr_clojure_rename_A_const_4 *lang.Var

var A_arbace_repr_clojure_rename_A_const_5 *lang.Var

var A_arbace_repr_clojure_rename_A_const_6 *lang.Var

var A_arbace_repr_clojure_rename_A_const_7 any

var A_arbace_repr_clojure_rename_A_const_8 *lang.Var

var A_arbace_repr_clojure_rename_A_const_9 *lang.Var

var A_arbace_repr_clojure_rename_A_const_10 *lang.Var

var A_arbace_repr_clojure_rename_A_const_11 *lang.Var

var A_arbace_repr_clojure_rename_A_const_12 any

var A_arbace_repr_clojure_rename_A_const_13 *lang.Var

var A_arbace_repr_clojure_rename_A_const_14 *lang.Var

var A_arbace_repr_clojure_rename_A_const_15 *lang.Var

var A_arbace_repr_clojure_rename_A_const_16 *lang.Var

var A_arbace_repr_clojure_rename_A_const_17 *lang.Var

var A_arbace_repr_clojure_rename_A_const_18 *lang.Var

var A_arbace_repr_clojure_rename_A_const_19 *lang.Var

var A_arbace_repr_clojure_rename_A_const_20 *lang.Var

var A_arbace_repr_clojure_rename_A_init jrt.ClassInit

func A_arbace_repr_clojure_rename_A_Init() { if !A_arbace_repr_clojure_rename_A_init.Done() { A_arbace_repr_clojure_rename_A_init.Run(A_arbace_repr_clojure_rename_A_clinit) } }

func A_arbace_repr_clojure_rename_A_clinit() { jrt.StartCheck(); A_arbace_repr_clojure_rename_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 26); A_arbace_repr_clojure_rename_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[5]); A_arbace_repr_clojure_rename_A_const_1 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[6]); A_arbace_repr_clojure_rename_A_const_2 = A_arbace_repr_clojure_rename_A_const_pool.A[7]; A_arbace_repr_clojure_rename_A_const_3 = A_arbace_repr_clojure_rename_A_const_pool.A[8]; A_arbace_repr_clojure_rename_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[9]); A_arbace_repr_clojure_rename_A_const_5 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[10]); A_arbace_repr_clojure_rename_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[11]); A_arbace_repr_clojure_rename_A_const_7 = A_arbace_repr_clojure_rename_A_const_pool.A[12]; A_arbace_repr_clojure_rename_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[13]); A_arbace_repr_clojure_rename_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[14]); A_arbace_repr_clojure_rename_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[15]); A_arbace_repr_clojure_rename_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[16]); A_arbace_repr_clojure_rename_A_const_12 = A_arbace_repr_clojure_rename_A_const_pool.A[17]; A_arbace_repr_clojure_rename_A_const_13 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[18]); A_arbace_repr_clojure_rename_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[19]); A_arbace_repr_clojure_rename_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[20]); A_arbace_repr_clojure_rename_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[21]); A_arbace_repr_clojure_rename_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[22]); A_arbace_repr_clojure_rename_A_const_18 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[23]); A_arbace_repr_clojure_rename_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[24]); A_arbace_repr_clojure_rename_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[25]) }

func A_arbace_repr_clojure_rename_A_New() *A_arbace_repr_clojure_rename_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename_A_class }

func (t *A_arbace_repr_clojure_rename_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename_A); return ok }

func A_arbace_repr_clojure_rename_A_Cast(x any) *A_arbace_repr_clojure_rename_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename_A_class)) }; return v }



type A_arbace_repr_clojure_rename_alt_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_alt_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_alt_fn__557000013_A struct{ j2g_header uint64; F_sep any }

var A_arbace_repr_clojure_rename_alt_fn__557000013_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_eval557000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_rename_eval557000004_A_New() *A_arbace_repr_clojure_rename_eval557000004_A { t := &A_arbace_repr_clojure_rename_eval557000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename_eval557000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename_eval557000004_A_class }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename_eval557000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename_eval557000004_A); return ok }

func A_arbace_repr_clojure_rename_eval557000004_A_Cast(x any) *A_arbace_repr_clojure_rename_eval557000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename_eval557000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename_eval557000004_A_class)) }; return v }



type A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_eval557000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_rename_eval557000008_A_New() *A_arbace_repr_clojure_rename_eval557000008_A { t := &A_arbace_repr_clojure_rename_eval557000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename_eval557000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename_eval557000008_A_class }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename_eval557000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename_eval557000008_A); return ok }

func A_arbace_repr_clojure_rename_eval557000008_A_Cast(x any) *A_arbace_repr_clojure_rename_eval557000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename_eval557000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename_eval557000008_A_class)) }; return v }



type A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_rename_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_rename_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_rename_fn__557000018_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_rename_fn__557000018_A_fn_class *jrt.Class
