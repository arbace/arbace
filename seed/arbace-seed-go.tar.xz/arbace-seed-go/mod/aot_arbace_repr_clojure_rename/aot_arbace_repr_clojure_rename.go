//line aot_arbace_repr_clojure_rename.ae:1
package aot_arbace_repr_clojure_rename

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_New() *A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rename_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rename_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_New() *A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_repr_clojure_rename_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_repr_clojure_rename_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_rename_A_const_7.GetRawRoot__O(), A_arbace_repr_clojure_rename_A_const_8) }














































func A_arbace_repr_clojure_rename_alt_A_New() *A_arbace_repr_clojure_rename_alt_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_alt_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_repr_clojure_rename_alt_A) Ctor() {}
//line :48:1
func (t *A_arbace_repr_clojure_rename_alt_A) Invoke_O_O_O__O(self, names__0, sep__1 any) any {





	var root_19 any = A_arbace_repr_clojure_rename_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = Lit_1; var arg_23 any; var root_24 any = A_arbace_repr_clojure_rename_A_const_10.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_26 lang.IFn
//line :53:1
	if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var fnbody__47 any = A_arbace_repr_clojure_rename_alt_fn__557000013_A_New_O(sep__1); var tmp1 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_repr_clojure_rename_alt_fn__557000013_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__47); A_arbace_repr_clojure_rename_alt_fn__557000013_A_fn_class = fncls__46d; tmp1 = fncls__46d } else { tmp1 = fncls__46 }; arg_27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__47, tmp1, nil); var arg_28 any; var root_48 any = A_arbace_repr_clojure_rename_A_const_13.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_50 lang.IFn
//line :52:1
	if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any; var root_53 any = A_arbace_repr_clojure_rename_A_const_14.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_repr_clojure_rename_A_const_15.GetRawRoot__O(); var arg_57 any = A_arbace_repr_clojure_rename_A_const_16.GetRawRoot__O(); if linked_54 == nil { arg_51 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { arg_51 = linked_54.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) }; var arg_52 any = names__0; if linked_49 == nil { arg_28 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { arg_28 = linked_49.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }
	if linked_25 == nil { arg_23 = ifn_26.Invoke_O_O__O(arg_27, arg_28) } else { arg_23 = linked_25.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_24, arg_27, arg_28) }
	if linked_20 == nil { return ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { return linked_20.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) } }
//line :53:1
func A_arbace_repr_clojure_rename_alt_fn__557000013_A_New_O(p0 any) *A_arbace_repr_clojure_rename_alt_fn__557000013_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_alt_fn__557000013_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_A) Ctor_O(c__sep any) { t.F_sep = c__sep }
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_A) Invoke_O_O__O(self, n__1 any) any { var root_29 any = A_arbace_repr_clojure_rename_A_const_9.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = t.F_sep; var arg_33 any; var root_34 any = A_arbace_repr_clojure_rename_A_const_10.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var fnbody__40 any = A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_New(); var tmp1 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_fn_class = fncls__39d; tmp1 = fncls__39d } else { tmp1 = fncls__39 }; arg_37 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp1, nil); var arg_38 any; var root_41 any = A_arbace_repr_clojure_rename_A_const_11.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = n__1; var arg_45 any = A_arbace_repr_clojure_rename_A_const_12; if linked_42 == nil { arg_38 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { arg_38 = linked_42.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if linked_35 == nil { arg_33 = ifn_36.Invoke_O_O__O(arg_37, arg_38) } else { arg_33 = linked_35.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_34, arg_37, arg_38) }; if linked_30 == nil { return ifn_31.Invoke_O_O__O(arg_32, arg_33) } else { return linked_30.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_29, arg_32, arg_33) } }
//line :53:1
func A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_New() *A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A) Ctor() {}
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A) Invoke_O_O__O(self, p1__557000012_SHARP___1 any) any { return jrt.Pattern_Quote_String__String_NoInit(jrt.String_Cast(p1__557000012_SHARP___1)).Ref() }








func A_arbace_repr_clojure_rename_patterns_of_A_New() *A_arbace_repr_clojure_rename_patterns_of_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_patterns_of_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_repr_clojure_rename_patterns_of_A) Ctor() {}
//line :62:1
func (t *A_arbace_repr_clojure_rename_patterns_of_A) Invoke_O_O__O(self, w__0 any) any { var tmp1 any; var root_58 any = A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_60 lang.IFn; if




	linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_4, nil, Lit_5, nil, Lit_6); var tmp3 any = A_arbace_repr_clojure_rename_A_const_18.GetRawRoot__O(); var tmp4 any = A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(); var tmp5 any; var root_62 any = A_arbace_repr_clojure_rename_A_const_20.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = A_arbace_repr_clojure_rename_A_const_21.GetRawRoot__O(); var arg_66 any = A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(); if linked_63 == nil { tmp5 = ifn_64.Invoke_O_O__O(arg_65, arg_66) } else { tmp5 = linked_63.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_62, arg_65, arg_66) }; arg_61 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, w__0, nil, tmp4, nil, tmp5, nil)).Ref(); if linked_59 == nil { tmp1 = ifn_60.Invoke_O__O(arg_61) } else { tmp1 = linked_59.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_58, arg_61) }; var tmp6 any = tmp1; var tmp7 any; var root_67 any = /*line :62:1*/A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_69 lang.IFn; if






	linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,9,s17:(?<=(?:^|[^\\w])L)ns3:(?=ns16:(?:lang|asm|javans4:api)ns1:)", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, w__0, nil, A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(), nil, A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(), nil, A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(), nil)).Ref(); if linked_68 == nil { tmp7 = ifn_69.Invoke_O__O(arg_70) } else { tmp7 = linked_68.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_67, arg_70) }; var tmp8 any = tmp7; var tmp9 any; var root_71 any = /*line :62:1*/A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_73 lang.IFn; if










	linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any; var tmp10 *jrt.RefArray = jrt.ConstRefArray("[0,9,nns3:(?=ns3:(?:ns20:)(?!(?!__)[\\w*+!?-]|ns7:[a-z]))", []*jrt.Class{jrt.String_class}); var tmp11 any = A_arbace_repr_clojure_rename_A_const_18.GetRawRoot__O(); var tmp12 any = A_arbace_repr_clojure_rename_A_const_22.GetRawRoot__O(); var tmp13 any; var root_75 any = A_arbace_repr_clojure_rename_A_const_20.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = A_arbace_repr_clojure_rename_A_const_23.GetRawRoot__O(); var arg_79 any = A_arbace_repr_clojure_rename_A_const_22.GetRawRoot__O(); if linked_76 == nil { tmp13 = ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { tmp13 = linked_76.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_75, arg_78, arg_79) }; arg_74 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11, w__0, nil, tmp12, nil, tmp13, nil, A_arbace_repr_clojure_rename_A_const_22.GetRawRoot__O(), nil)).Ref(); if linked_72 == nil { tmp9 = ifn_73.Invoke_O__O(arg_74) } else { tmp9 = linked_72.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_71, arg_74) }; var tmp14 any = tmp9; var tmp15 any; var root_80 any = /*line :62:1*/A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_82 lang.IFn; if













	linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_7, nil, Lit_8); var tmp17 any = A_arbace_repr_clojure_rename_A_const_18.GetRawRoot__O(); var tmp18 any; var root_84 any = A_arbace_repr_clojure_rename_A_const_20.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = A_arbace_repr_clojure_rename_A_const_23.GetRawRoot__O(); var arg_88 any = Lit_9; if linked_85 == nil { tmp18 = ifn_86.Invoke_O_O__O(arg_87, arg_88) } else { tmp18 = linked_85.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_84, arg_87, arg_88) }; arg_83 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp17, w__0, nil, tmp18, nil)).Ref(); if linked_81 == nil { tmp15 = ifn_82.Invoke_O__O(arg_83) } else { tmp15 = linked_81.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_80, arg_83) }; return /*line :62:1*/ lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp14, tmp15) }



























func A_arbace_repr_clojure_rename_rename_A_New() *A_arbace_repr_clojure_rename_rename_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_rename_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_repr_clojure_rename_rename_A) Ctor() {}
//line :90:1
func (t *A_arbace_repr_clojure_rename_rename_A) Invoke_O_O__O(self, s__0 any) any {


	var root_89 any = A_arbace_repr_clojure_rename_A_const_24.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any; var root_95 any = A_arbace_repr_clojure_rename_A_const_25.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var fnbody__108 any = A_arbace_repr_clojure_rename_rename_fn__557000019_A_New(); var tmp1 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_repr_clojure_rename_rename_fn__557000019_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_repr_clojure_rename_rename_fn__557000019_A_fn_class = fncls__107d; tmp1 = fncls__107d } else { tmp1 = fncls__107 }; arg_98 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp1, nil); var arg_99 any = s__0; var arg_100 any = A_arbace_repr_clojure_rename_A_const_26.GetRawRoot__O(); if linked_96 == nil { arg_92 = ifn_97.Invoke_O_O_O__O(arg_98, arg_99, arg_100) } else { arg_92 = linked_96.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_95, arg_98, arg_99, arg_100) }; var arg_93 any = A_arbace_repr_clojure_rename_A_const_27.GetRawRoot__O(); var arg_94 any = Lit_11; if linked_90 == nil { return ifn_91.Invoke_O_O_O__O(arg_92, arg_93, arg_94) } else { return linked_90.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_89, arg_92, arg_93, arg_94) } }
//line :93:1
func A_arbace_repr_clojure_rename_rename_fn__557000019_A_New() *A_arbace_repr_clojure_rename_rename_fn__557000019_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_rename_fn__557000019_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_repr_clojure_rename_rename_fn__557000019_A) Ctor() {}
//line :93:1
func (t *A_arbace_repr_clojure_rename_rename_fn__557000019_A) Invoke_O_O_O__O(self, s__1, p__2 any) any { var root_101 any = A_arbace_repr_clojure_rename_A_const_24.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = s__1; var arg_105 any = p__2; var arg_106 any = Lit_12; if linked_102 == nil { return ifn_103.Invoke_O_O_O__O(arg_104, arg_105, arg_106) } else { return linked_102.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_101, arg_104, arg_105, arg_106) } }

func A_arbace_repr_clojure_rename_unrename_A_New() *A_arbace_repr_clojure_rename_unrename_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_unrename_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_repr_clojure_rename_unrename_A) Ctor() {}
//line :95:1
func (t *A_arbace_repr_clojure_rename_unrename_A) Invoke_O_O__O(self, s__0 any) any {





	var root_109 any = A_arbace_repr_clojure_rename_A_const_25.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any; var fnbody__122 any = A_arbace_repr_clojure_rename_unrename_fn__557000022_A_New(); var tmp1 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_repr_clojure_rename_unrename_fn__557000022_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); A_arbace_repr_clojure_rename_unrename_fn__557000022_A_fn_class = fncls__121d; tmp1 = fncls__121d } else { tmp1 = fncls__121 }; arg_112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp1, nil); var arg_113 any; var root_123 any = A_arbace_repr_clojure_rename_A_const_24.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_125 lang.IFn
	if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = s__0; var arg_127 any = A_arbace_repr_clojure_rename_A_const_28.GetRawRoot__O(); var arg_128 any = Lit_14; if linked_124 == nil { arg_113 = ifn_125.Invoke_O_O_O__O(arg_126, arg_127, arg_128) } else { arg_113 = linked_124.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_123, arg_126, arg_127, arg_128) }
//line :101:1
	var arg_114 any = A_arbace_repr_clojure_rename_A_const_29.GetRawRoot__O(); if linked_110 == nil { return ifn_111.Invoke_O_O_O__O(arg_112, arg_113, arg_114) } else { return linked_110.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_109, arg_112, arg_113, arg_114) } }
//line :101:1
func A_arbace_repr_clojure_rename_unrename_fn__557000022_A_New() *A_arbace_repr_clojure_rename_unrename_fn__557000022_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_unrename_fn__557000022_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_repr_clojure_rename_unrename_fn__557000022_A) Ctor() {}
//line :101:1
func (t *A_arbace_repr_clojure_rename_unrename_fn__557000022_A) Invoke_O_O_O__O(self, s__1, p__2 any) any { var root_115 any = A_arbace_repr_clojure_rename_A_const_24.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = s__1; var arg_119 any = p__2; var arg_120 any = Lit_15; if linked_116 == nil { return ifn_117.Invoke_O_O_O__O(arg_118, arg_119, arg_120) } else { return linked_116.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_115, arg_118, arg_119, arg_120) } }














type A_arbace_repr_clojure_rename_A struct{ jrt.Object }

var A_arbace_repr_clojure_rename_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rename_A_const_0 *lang.Var

var A_arbace_repr_clojure_rename_A_const_1 any

var A_arbace_repr_clojure_rename_A_const_2 *lang.Var

var A_arbace_repr_clojure_rename_A_const_3 any

var A_arbace_repr_clojure_rename_A_const_4 *lang.Var

var A_arbace_repr_clojure_rename_A_const_5 *lang.Var

var A_arbace_repr_clojure_rename_A_const_6 *lang.Var

var A_arbace_repr_clojure_rename_A_const_7 *lang.Var

var A_arbace_repr_clojure_rename_A_const_8 any

var A_arbace_repr_clojure_rename_A_const_9 *lang.Var

var A_arbace_repr_clojure_rename_A_const_10 *lang.Var

var A_arbace_repr_clojure_rename_A_const_11 *lang.Var

var A_arbace_repr_clojure_rename_A_const_12 any

var A_arbace_repr_clojure_rename_A_const_13 *lang.Var

var A_arbace_repr_clojure_rename_A_const_14 *lang.Var

var A_arbace_repr_clojure_rename_A_const_15 *lang.Var

var A_arbace_repr_clojure_rename_A_const_16 *lang.Var

var A_arbace_repr_clojure_rename_A_const_17 *lang.Var

var A_arbace_repr_clojure_rename_A_const_18 *lang.Var

var A_arbace_repr_clojure_rename_A_const_19 *lang.Var

var A_arbace_repr_clojure_rename_A_const_20 *lang.Var

var A_arbace_repr_clojure_rename_A_const_21 *lang.Var

var A_arbace_repr_clojure_rename_A_const_22 *lang.Var

var A_arbace_repr_clojure_rename_A_const_23 *lang.Var

var A_arbace_repr_clojure_rename_A_const_24 *lang.Var

var A_arbace_repr_clojure_rename_A_const_25 *lang.Var

var A_arbace_repr_clojure_rename_A_const_26 *lang.Var

var A_arbace_repr_clojure_rename_A_const_27 *lang.Var

var A_arbace_repr_clojure_rename_A_const_28 *lang.Var

var A_arbace_repr_clojure_rename_A_const_29 *lang.Var

var A_arbace_repr_clojure_rename_A_init jrt.ClassInit

func A_arbace_repr_clojure_rename_A_Init() { if !A_arbace_repr_clojure_rename_A_init.Done() { A_arbace_repr_clojure_rename_A_init.Run(A_arbace_repr_clojure_rename_A_clinit) } }

func A_arbace_repr_clojure_rename_A_clinit() { A_arbace_repr_clojure_rename_A_clinit_p0(); A_arbace_repr_clojure_rename_A_clinit_p1(); A_arbace_repr_clojure_rename_A_clinit_p2() }

func A_arbace_repr_clojure_rename_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rename_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 35); A_arbace_repr_clojure_rename_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[5]); A_arbace_repr_clojure_rename_A_const_1 = A_arbace_repr_clojure_rename_A_const_pool.A[6]; A_arbace_repr_clojure_rename_A_const_2 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[7]); A_arbace_repr_clojure_rename_A_const_3 = A_arbace_repr_clojure_rename_A_const_pool.A[8]; A_arbace_repr_clojure_rename_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[9]); A_arbace_repr_clojure_rename_A_const_5 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[10]); A_arbace_repr_clojure_rename_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[11]); A_arbace_repr_clojure_rename_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[12]); A_arbace_repr_clojure_rename_A_const_8 = A_arbace_repr_clojure_rename_A_const_pool.A[13]; A_arbace_repr_clojure_rename_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[14]); A_arbace_repr_clojure_rename_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[15]); A_arbace_repr_clojure_rename_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[16]) }

func A_arbace_repr_clojure_rename_A_clinit_p1() { A_arbace_repr_clojure_rename_A_const_12 = A_arbace_repr_clojure_rename_A_const_pool.A[17]; A_arbace_repr_clojure_rename_A_const_13 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[18]); A_arbace_repr_clojure_rename_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[19]); A_arbace_repr_clojure_rename_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[20]); A_arbace_repr_clojure_rename_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[21]); A_arbace_repr_clojure_rename_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[22]); A_arbace_repr_clojure_rename_A_const_18 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[23]); A_arbace_repr_clojure_rename_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[24]); A_arbace_repr_clojure_rename_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[25]); A_arbace_repr_clojure_rename_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[26]); A_arbace_repr_clojure_rename_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[27]); A_arbace_repr_clojure_rename_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[28]) }

func A_arbace_repr_clojure_rename_A_clinit_p2() { A_arbace_repr_clojure_rename_A_const_24 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[29]); A_arbace_repr_clojure_rename_A_const_25 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[30]); A_arbace_repr_clojure_rename_A_const_26 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[31]); A_arbace_repr_clojure_rename_A_const_27 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[32]); A_arbace_repr_clojure_rename_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[33]); A_arbace_repr_clojure_rename_A_const_29 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[34]) }

func A_arbace_repr_clojure_rename_A_New() *A_arbace_repr_clojure_rename_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename_A_class }

func (t *A_arbace_repr_clojure_rename_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename_A); return ok }

func A_arbace_repr_clojure_rename_A_Cast(x any) *A_arbace_repr_clojure_rename_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename_A_class)) }; return v }



type A_arbace_repr_clojure_rename_alt_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_alt_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_alt_fn__557000013_A struct{ j2g_header uint64; F_sep any }

var A_arbace_repr_clojure_rename_alt_fn__557000013_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_eval557000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_rename_eval557000004_A_New() *A_arbace_repr_clojure_rename_eval557000004_A { t := &A_arbace_repr_clojure_rename_eval557000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename_eval557000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename_eval557000004_A_class }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename_eval557000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename_eval557000004_A); return ok }

func A_arbace_repr_clojure_rename_eval557000004_A_Cast(x any) *A_arbace_repr_clojure_rename_eval557000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename_eval557000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename_eval557000004_A_class)) }; return v }



type A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_eval557000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_rename_eval557000008_A_New() *A_arbace_repr_clojure_rename_eval557000008_A { t := &A_arbace_repr_clojure_rename_eval557000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename_eval557000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename_eval557000008_A_class }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename_eval557000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename_eval557000008_A); return ok }

func A_arbace_repr_clojure_rename_eval557000008_A_Cast(x any) *A_arbace_repr_clojure_rename_eval557000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename_eval557000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename_eval557000008_A_class)) }; return v }



type A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_patterns_of_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_patterns_of_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_rename_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_rename_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_rename_fn__557000019_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_rename_fn__557000019_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_unrename_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_unrename_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_unrename_fn__557000022_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_unrename_fn__557000022_A_fn_class *jrt.Class
