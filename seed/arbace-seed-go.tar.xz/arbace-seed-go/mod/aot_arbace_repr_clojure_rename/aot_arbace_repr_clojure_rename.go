//line aot_arbace_repr_clojure_rename.ae:1
package aot_arbace_repr_clojure_rename

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_New() *A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rename_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_rename_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_New() *A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_rename_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_repr_clojure_rename_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_repr_clojure_rename_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_rename_A_const_7.GetRawRoot__O(), A_arbace_repr_clojure_rename_A_const_8) }














































func A_arbace_repr_clojure_rename_alt_A_New() *A_arbace_repr_clojure_rename_alt_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_alt_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_repr_clojure_rename_alt_A) Ctor() {}
//line :48:1
func (t *A_arbace_repr_clojure_rename_alt_A) Invoke_O_O_O__O(self, names__0, sep__1 any) any {





	var root_19 any = A_arbace_repr_clojure_rename_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = Lit_1; var arg_23 any; var root_24 any = A_arbace_repr_clojure_rename_A_const_10.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_26 lang.IFn
//line :53:1
	if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var tmp1 any = A_arbace_repr_clojure_rename_alt_fn__557000013_A_New_O(sep__1); var tmp2 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_clojure_rename_alt_fn__557000013_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_clojure_rename_alt_fn__557000013_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; arg_27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_28 any; var root_46 any = A_arbace_repr_clojure_rename_A_const_13.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_48 lang.IFn
//line :52:1
	if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var root_51 any = A_arbace_repr_clojure_rename_A_const_14.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = A_arbace_repr_clojure_rename_A_const_15.GetRawRoot__O(); var arg_55 any = A_arbace_repr_clojure_rename_A_const_16.GetRawRoot__O(); if linked_52 == nil { arg_49 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { arg_49 = linked_52.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; var arg_50 any = names__0; if linked_47 == nil { arg_28 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { arg_28 = linked_47.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }
	if linked_25 == nil { arg_23 = ifn_26.Invoke_O_O__O(arg_27, arg_28) } else { arg_23 = linked_25.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_24, arg_27, arg_28) }
	if linked_20 == nil { return ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { return linked_20.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) } }
//line :53:1
func A_arbace_repr_clojure_rename_alt_fn__557000013_A_New_O(p0 any) *A_arbace_repr_clojure_rename_alt_fn__557000013_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_alt_fn__557000013_A{}; t.Ctor_O(p0); return t }
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_A) Ctor_O(c__sep any) { t.F_sep = c__sep }
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_A) Invoke_O_O__O(self, n__1 any) any { var root_29 any = A_arbace_repr_clojure_rename_A_const_9.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = t.F_sep; var arg_33 any; var root_34 any = A_arbace_repr_clojure_rename_A_const_10.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var tmp1 any = A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_New(); var tmp2 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_fn_class = fncls__39d; tmp2 = fncls__39d } else { tmp2 = fncls__39 }; arg_37 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_38 any; var root_40 any = A_arbace_repr_clojure_rename_A_const_11.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = n__1; var arg_44 any = A_arbace_repr_clojure_rename_A_const_12; if linked_41 == nil { arg_38 = ifn_42.Invoke_O_O__O(arg_43, arg_44) } else { arg_38 = linked_41.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_40, arg_43, arg_44) }; if linked_35 == nil { arg_33 = ifn_36.Invoke_O_O__O(arg_37, arg_38) } else { arg_33 = linked_35.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_34, arg_37, arg_38) }; if linked_30 == nil { return ifn_31.Invoke_O_O__O(arg_32, arg_33) } else { return linked_30.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_29, arg_32, arg_33) } }
//line :53:1
func A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_New() *A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A) Ctor() {}
//line :53:1
func (t *A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A) Invoke_O_O__O(self, p1__557000012_SHARP___1 any) any { return jrt.Pattern_Quote_String__String_NoInit(jrt.String_Cast(p1__557000012_SHARP___1)).Ref() }








func A_arbace_repr_clojure_rename_patterns_of_A_New() *A_arbace_repr_clojure_rename_patterns_of_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_patterns_of_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_repr_clojure_rename_patterns_of_A) Ctor() {}
//line :62:1
func (t *A_arbace_repr_clojure_rename_patterns_of_A) Invoke_O_O__O(self, w__0 any) any { var tmp1 any; var root_56 any = A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_58 lang.IFn; if




	linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_4, nil, Lit_5, nil, Lit_6); var tmp3 any = A_arbace_repr_clojure_rename_A_const_18.GetRawRoot__O(); var tmp4 any = A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(); var tmp5 any; var root_60 any = A_arbace_repr_clojure_rename_A_const_20.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = A_arbace_repr_clojure_rename_A_const_21.GetRawRoot__O(); var arg_64 any = A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(); if linked_61 == nil { tmp5 = ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { tmp5 = linked_61.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }; arg_59 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, w__0, nil, tmp4, nil, tmp5, nil)).Ref(); if linked_57 == nil { tmp1 = ifn_58.Invoke_O__O(arg_59) } else { tmp1 = linked_57.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_56, arg_59) }; var tmp6 any = tmp1; var tmp7 any; var root_65 any = /*line :62:1*/A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_67 lang.IFn; if






	linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,9,s17:(?<=(?:^|[^\\w])L)ns3:(?=ns16:(?:lang|asm|javans4:api)ns1:)", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, w__0, nil, A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(), nil, A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(), nil, A_arbace_repr_clojure_rename_A_const_19.GetRawRoot__O(), nil)).Ref(); if linked_66 == nil { tmp7 = ifn_67.Invoke_O__O(arg_68) } else { tmp7 = linked_66.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_65, arg_68) }; var tmp8 any = tmp7; var tmp9 any; var root_69 any = /*line :62:1*/A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_71 lang.IFn; if










	linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var tmp10 *jrt.RefArray = jrt.ConstRefArray("[0,9,nns3:(?=ns3:(?:ns20:)(?!(?!__)[\\w*+!?-]|ns7:[a-z]))", []*jrt.Class{jrt.String_class}); var tmp11 any = A_arbace_repr_clojure_rename_A_const_18.GetRawRoot__O(); var tmp12 any = A_arbace_repr_clojure_rename_A_const_22.GetRawRoot__O(); var tmp13 any; var root_73 any = A_arbace_repr_clojure_rename_A_const_20.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = A_arbace_repr_clojure_rename_A_const_23.GetRawRoot__O(); var arg_77 any = A_arbace_repr_clojure_rename_A_const_22.GetRawRoot__O(); if linked_74 == nil { tmp13 = ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { tmp13 = linked_74.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_73, arg_76, arg_77) }; arg_72 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11, w__0, nil, tmp12, nil, tmp13, nil, A_arbace_repr_clojure_rename_A_const_22.GetRawRoot__O(), nil)).Ref(); if linked_70 == nil { tmp9 = ifn_71.Invoke_O__O(arg_72) } else { tmp9 = linked_70.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_69, arg_72) }; var tmp14 any = tmp9; var tmp15 any; var root_78 any = /*line :62:1*/A_arbace_repr_clojure_rename_A_const_17.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_re_pattern_A_fn_class); var ifn_80 lang.IFn; if













	linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any; var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_7, nil, Lit_8); var tmp17 any = A_arbace_repr_clojure_rename_A_const_18.GetRawRoot__O(); var tmp18 any; var root_82 any = A_arbace_repr_clojure_rename_A_const_20.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, A_arbace_repr_clojure_rename_alt_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = A_arbace_repr_clojure_rename_A_const_23.GetRawRoot__O(); var arg_86 any = Lit_9; if linked_83 == nil { tmp18 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { tmp18 = linked_83.(*A_arbace_repr_clojure_rename_alt_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; arg_81 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp17, w__0, nil, tmp18, nil)).Ref(); if linked_79 == nil { tmp15 = ifn_80.Invoke_O__O(arg_81) } else { tmp15 = linked_79.(*aot_arbace_core.A_arbace_core_re_pattern_A).Invoke_O_O__O(root_78, arg_81) }; return /*line :62:1*/ lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp14, tmp15) }



























func A_arbace_repr_clojure_rename_rename_A_New() *A_arbace_repr_clojure_rename_rename_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_rename_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_repr_clojure_rename_rename_A) Ctor() {}
//line :90:1
func (t *A_arbace_repr_clojure_rename_rename_A) Invoke_O_O__O(self, s__0 any) any {


	var root_87 any = A_arbace_repr_clojure_rename_A_const_24.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any; var root_93 any = A_arbace_repr_clojure_rename_A_const_25.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any; var tmp1 any = A_arbace_repr_clojure_rename_rename_fn__557000019_A_New(); var tmp2 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_repr_clojure_rename_rename_fn__557000019_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_repr_clojure_rename_rename_fn__557000019_A_fn_class = fncls__105d; tmp2 = fncls__105d } else { tmp2 = fncls__105 }; arg_96 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_97 any = s__0; var arg_98 any = A_arbace_repr_clojure_rename_A_const_26.GetRawRoot__O(); if linked_94 == nil { arg_90 = ifn_95.Invoke_O_O_O__O(arg_96, arg_97, arg_98) } else { arg_90 = linked_94.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_93, arg_96, arg_97, arg_98) }; var arg_91 any = A_arbace_repr_clojure_rename_A_const_27.GetRawRoot__O(); var arg_92 any = Lit_11; if linked_88 == nil { return ifn_89.Invoke_O_O_O__O(arg_90, arg_91, arg_92) } else { return linked_88.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_87, arg_90, arg_91, arg_92) } }
//line :93:1
func A_arbace_repr_clojure_rename_rename_fn__557000019_A_New() *A_arbace_repr_clojure_rename_rename_fn__557000019_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_rename_fn__557000019_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_repr_clojure_rename_rename_fn__557000019_A) Ctor() {}
//line :93:1
func (t *A_arbace_repr_clojure_rename_rename_fn__557000019_A) Invoke_O_O_O__O(self, s__1, p__2 any) any { var root_99 any = A_arbace_repr_clojure_rename_A_const_24.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = s__1; var arg_103 any = p__2; var arg_104 any = Lit_12; if linked_100 == nil { return ifn_101.Invoke_O_O_O__O(arg_102, arg_103, arg_104) } else { return linked_100.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_99, arg_102, arg_103, arg_104) } }

func A_arbace_repr_clojure_rename_unrename_A_New() *A_arbace_repr_clojure_rename_unrename_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_unrename_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_repr_clojure_rename_unrename_A) Ctor() {}
//line :95:1
func (t *A_arbace_repr_clojure_rename_unrename_A) Invoke_O_O__O(self, s__0 any) any {





	var root_106 any = A_arbace_repr_clojure_rename_A_const_25.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var tmp1 any = A_arbace_repr_clojure_rename_unrename_fn__557000022_A_New(); var tmp2 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_repr_clojure_rename_unrename_fn__557000022_A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_repr_clojure_rename_unrename_fn__557000022_A_fn_class = fncls__118d; tmp2 = fncls__118d } else { tmp2 = fncls__118 }; arg_109 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_110 any; var root_119 any = A_arbace_repr_clojure_rename_A_const_24.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_121 lang.IFn
	if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = s__0; var arg_123 any = A_arbace_repr_clojure_rename_A_const_28.GetRawRoot__O(); var arg_124 any = Lit_14; if linked_120 == nil { arg_110 = ifn_121.Invoke_O_O_O__O(arg_122, arg_123, arg_124) } else { arg_110 = linked_120.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_119, arg_122, arg_123, arg_124) }
//line :101:1
	var arg_111 any = A_arbace_repr_clojure_rename_A_const_29.GetRawRoot__O(); if linked_107 == nil { return ifn_108.Invoke_O_O_O__O(arg_109, arg_110, arg_111) } else { return linked_107.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_106, arg_109, arg_110, arg_111) } }
//line :101:1
func A_arbace_repr_clojure_rename_unrename_fn__557000022_A_New() *A_arbace_repr_clojure_rename_unrename_fn__557000022_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_unrename_fn__557000022_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_repr_clojure_rename_unrename_fn__557000022_A) Ctor() {}
//line :101:1
func (t *A_arbace_repr_clojure_rename_unrename_fn__557000022_A) Invoke_O_O_O__O(self, s__1, p__2 any) any { var root_112 any = A_arbace_repr_clojure_rename_A_const_24.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = s__1; var arg_116 any = p__2; var arg_117 any = Lit_15; if linked_113 == nil { return ifn_114.Invoke_O_O_O__O(arg_115, arg_116, arg_117) } else { return linked_113.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_112, arg_115, arg_116, arg_117) } }














type A_arbace_repr_clojure_rename_A struct{ jrt.Object }

var A_arbace_repr_clojure_rename_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_rename_A_const_0 *lang.Var

var A_arbace_repr_clojure_rename_A_const_1 any

var A_arbace_repr_clojure_rename_A_const_2 *lang.Var

var A_arbace_repr_clojure_rename_A_const_3 any

var A_arbace_repr_clojure_rename_A_const_4 *lang.Var

var A_arbace_repr_clojure_rename_A_const_5 *lang.Var

var A_arbace_repr_clojure_rename_A_const_6 *lang.Var

var A_arbace_repr_clojure_rename_A_const_7 *lang.Var

var A_arbace_repr_clojure_rename_A_const_8 any

var A_arbace_repr_clojure_rename_A_const_9 *lang.Var

var A_arbace_repr_clojure_rename_A_const_10 *lang.Var

var A_arbace_repr_clojure_rename_A_const_11 *lang.Var

var A_arbace_repr_clojure_rename_A_const_12 any

var A_arbace_repr_clojure_rename_A_const_13 *lang.Var

var A_arbace_repr_clojure_rename_A_const_14 *lang.Var

var A_arbace_repr_clojure_rename_A_const_15 *lang.Var

var A_arbace_repr_clojure_rename_A_const_16 *lang.Var

var A_arbace_repr_clojure_rename_A_const_17 *lang.Var

var A_arbace_repr_clojure_rename_A_const_18 *lang.Var

var A_arbace_repr_clojure_rename_A_const_19 *lang.Var

var A_arbace_repr_clojure_rename_A_const_20 *lang.Var

var A_arbace_repr_clojure_rename_A_const_21 *lang.Var

var A_arbace_repr_clojure_rename_A_const_22 *lang.Var

var A_arbace_repr_clojure_rename_A_const_23 *lang.Var

var A_arbace_repr_clojure_rename_A_const_24 *lang.Var

var A_arbace_repr_clojure_rename_A_const_25 *lang.Var

var A_arbace_repr_clojure_rename_A_const_26 *lang.Var

var A_arbace_repr_clojure_rename_A_const_27 *lang.Var

var A_arbace_repr_clojure_rename_A_const_28 *lang.Var

var A_arbace_repr_clojure_rename_A_const_29 *lang.Var

var A_arbace_repr_clojure_rename_A_init jrt.ClassInit

func A_arbace_repr_clojure_rename_A_Init() { if !A_arbace_repr_clojure_rename_A_init.Done() { A_arbace_repr_clojure_rename_A_init.Run(A_arbace_repr_clojure_rename_A_clinit) } }

func A_arbace_repr_clojure_rename_A_clinit() { A_arbace_repr_clojure_rename_A_clinit_p0(); A_arbace_repr_clojure_rename_A_clinit_p1(); A_arbace_repr_clojure_rename_A_clinit_p2() }

func A_arbace_repr_clojure_rename_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_rename_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 35); A_arbace_repr_clojure_rename_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[5]); A_arbace_repr_clojure_rename_A_const_1 = A_arbace_repr_clojure_rename_A_const_pool.A[6]; A_arbace_repr_clojure_rename_A_const_2 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[7]); A_arbace_repr_clojure_rename_A_const_3 = A_arbace_repr_clojure_rename_A_const_pool.A[8]; A_arbace_repr_clojure_rename_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[9]); A_arbace_repr_clojure_rename_A_const_5 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[10]); A_arbace_repr_clojure_rename_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[11]); A_arbace_repr_clojure_rename_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[12]); A_arbace_repr_clojure_rename_A_const_8 = A_arbace_repr_clojure_rename_A_const_pool.A[13]; A_arbace_repr_clojure_rename_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[14]); A_arbace_repr_clojure_rename_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[15]); A_arbace_repr_clojure_rename_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[16]) }

func A_arbace_repr_clojure_rename_A_clinit_p1() { A_arbace_repr_clojure_rename_A_const_12 = A_arbace_repr_clojure_rename_A_const_pool.A[17]; A_arbace_repr_clojure_rename_A_const_13 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[18]); A_arbace_repr_clojure_rename_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[19]); A_arbace_repr_clojure_rename_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[20]); A_arbace_repr_clojure_rename_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[21]); A_arbace_repr_clojure_rename_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[22]); A_arbace_repr_clojure_rename_A_const_18 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[23]); A_arbace_repr_clojure_rename_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[24]); A_arbace_repr_clojure_rename_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[25]); A_arbace_repr_clojure_rename_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[26]); A_arbace_repr_clojure_rename_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[27]); A_arbace_repr_clojure_rename_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[28]) }

func A_arbace_repr_clojure_rename_A_clinit_p2() { A_arbace_repr_clojure_rename_A_const_24 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[29]); A_arbace_repr_clojure_rename_A_const_25 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[30]); A_arbace_repr_clojure_rename_A_const_26 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[31]); A_arbace_repr_clojure_rename_A_const_27 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[32]); A_arbace_repr_clojure_rename_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[33]); A_arbace_repr_clojure_rename_A_const_29 = lang.Var_Cast(A_arbace_repr_clojure_rename_A_const_pool.A[34]) }

func A_arbace_repr_clojure_rename_A_New() *A_arbace_repr_clojure_rename_A { A_arbace_repr_clojure_rename_A_Init(); t := &A_arbace_repr_clojure_rename_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename_A_class }

func (t *A_arbace_repr_clojure_rename_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename_A); return ok }

func A_arbace_repr_clojure_rename_A_Cast(x any) *A_arbace_repr_clojure_rename_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename_A_class)) }; return v }



type A_arbace_repr_clojure_rename_alt_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_alt_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_alt_fn__557000013_A struct{ j2g_header uint64; F_sep any }

var A_arbace_repr_clojure_rename_alt_fn__557000013_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_alt_fn__557000013_fn__557000014_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_eval557000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_rename_eval557000004_A_New() *A_arbace_repr_clojure_rename_eval557000004_A { t := &A_arbace_repr_clojure_rename_eval557000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename_eval557000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename_eval557000004_A_class }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename_eval557000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename_eval557000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename_eval557000004_A); return ok }

func A_arbace_repr_clojure_rename_eval557000004_A_Cast(x any) *A_arbace_repr_clojure_rename_eval557000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename_eval557000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename_eval557000004_A_class)) }; return v }



type A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_eval557000004_loading__1927001464__auto____557000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_eval557000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_rename_eval557000008_A_New() *A_arbace_repr_clojure_rename_eval557000008_A { t := &A_arbace_repr_clojure_rename_eval557000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_rename_eval557000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_rename_eval557000008_A_class }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_rename_eval557000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_rename_eval557000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_rename_eval557000008_A); return ok }

func A_arbace_repr_clojure_rename_eval557000008_A_Cast(x any) *A_arbace_repr_clojure_rename_eval557000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_rename_eval557000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_rename_eval557000008_A_class)) }; return v }



type A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_eval557000008_fn__557000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_patterns_of_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_patterns_of_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_rename_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_rename_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_rename_fn__557000019_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_rename_fn__557000019_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_unrename_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_unrename_A_fn_class *jrt.Class



type A_arbace_repr_clojure_rename_unrename_fn__557000022_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_rename_unrename_fn__557000022_A_fn_class *jrt.Class
