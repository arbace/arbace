//line j2g_strings.ae:1
package aot_arbace_repr_clojure_rename

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,strkn3,docv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn26,arbace.repr.clojure.renamem2,R4,s1954,The clojure -> arbace renaming of agenda step 4 (doc/VENDOR-NOTES.md, \"What is renamed\"),\n  as a textual rewrite of source text: repr/clojure's rule :rename (arbace.repr.clojure.rules,\n  doc/REPR-CLOJURE.md; c2a's until 2026-10-17), which bin/clojure-tests applies to Clojure's\n  test suite and its test libraries. As arbace.j2c.rename it derived arbace/ from the frozen clojure/ once (bin/vendor-arbace and\n  bin/vendor-spec, on the branch arbace-for-java-26).\n\n  Renamed: names that belong to the vendored Clojure, written dotted or as paths:\n  - the Java packages clojure.lang, clojure.asm (with commons, signature), clojure.java.api,\n    whatever follows them (class names, members, descriptors \"Lclojure/lang/Var;\", array\n    names \"[Lclojure.lang.Var;\");\n  - the vendored namespaces (exactly: clojure.core, clojure.core.protocols, ..., see\n    `namespaces`), as symbols, qualified symbols and keywords, strings and resource paths\n    (clojure/core, clojure/pprint/cl_format, clojure/core__init);\n  - the keyword namespace clojure.error;\n  - the system properties Clojure reads: clojure.compile.*, clojure.compiler.*,\n    clojure.server.*, clojure.read.eval, clojure.main.report, clojure.basis;\n  - clojure.jar in usage texts;\n  - spec, vendored later (doc/VENDOR-NOTES.md, \"Spec\"): clojure.spec with whatever follows\n    (clojure.spec.alpha, .gen.alpha, .test.alpha, :clojure.spec.alpha/problems, the\n    clojure.spec.* system properties, clojure/spec/alpha) and clojure.core.specs.alpha.\n  Left alone: other libraries' names (clojure.test.check, clojure.tools.namespace, clojure.tools.deps, clojure.data.generators,\n  clojure.java.classpath, ...; and the suite's own clojure.test-clojure.*), identifiers that\n  merely contain the word (clojure-version, *clojure-version*, refer-clojure, CLOJURE_NS,\n  __clojureFnMap, thread names clojure-agent-*; some were renamed by hand after vendoring, see\n  doc/VENDOR-NOTES.md), prose and URLs (clojure.org).v11,arbace.core13,*loaded-libs*v13,arbace.string4,joinv11,arbace.core3,mapv13,arbace.string5,splitp2,\\.v11,arbace.core7,sort-byv11,arbace.core4,compv11,arbace.core1,-v11,arbace.core5,countv13,arbace.string7,replacev11,arbace.core6,reducev26,arbace.repr.clojure.rename11,source-filev26,arbace.repr.clojure.rename8,patterns")

var Lit_1 *jrt.String = jrt.Intern("|")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.clojure.rename$alt$fn__557000013")

var Lit_3 *jrt.String = jrt.Intern("arbace.repr.clojure.rename$alt$fn__557000013$fn__557000014")

var Lit_4 *jrt.String = jrt.Intern("arbace.repr.clojure.rename$rename$fn__557000018")

var Lit_5 *jrt.String = jrt.Intern("$1.ae")

var Lit_6 *jrt.String = jrt.Intern("arbace")

var Lit_7 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn5,namesyn3,sepyn1,sv11,arbace.core5,in-nsMyn26,arbace.repr.clojure.renamem2,R0,s1954,The clojure -> arbace renaming of agenda step 4 (doc/VENDOR-NOTES.md, \"What is renamed\"),\n  as a textual rewrite of source text: repr/clojure's rule :rename (arbace.repr.clojure.rules,\n  doc/REPR-CLOJURE.md; c2a's until 2026-10-17), which bin/clojure-tests applies to Clojure's\n  test suite and its test libraries. As arbace.j2c.rename it derived arbace/ from the frozen clojure/ once (bin/vendor-arbace and\n  bin/vendor-spec, on the branch arbace-for-java-26).\n\n  Renamed: names that belong to the vendored Clojure, written dotted or as paths:\n  - the Java packages clojure.lang, clojure.asm (with commons, signature), clojure.java.api,\n    whatever follows them (class names, members, descriptors \"Lclojure/lang/Var;\", array\n    names \"[Lclojure.lang.Var;\");\n  - the vendored namespaces (exactly: clojure.core, clojure.core.protocols, ..., see\n    `namespaces`), as symbols, qualified symbols and keywords, strings and resource paths\n    (clojure/core, clojure/pprint/cl_format, clojure/core__init);\n  - the keyword namespace clojure.error;\n  - the system properties Clojure reads: clojure.compile.*, clojure.compiler.*,\n    clojure.server.*, clojure.read.eval, clojure.main.report, clojure.basis;\n  - clojure.jar in usage texts;\n  - spec, vendored later (doc/VENDOR-NOTES.md, \"Spec\"): clojure.spec with whatever follows\n    (clojure.spec.alpha, .gen.alpha, .test.alpha, :clojure.spec.alpha/problems, the\n    clojure.spec.* system properties, clojure/spec/alpha) and clojure.core.specs.alpha.\n  Left alone: other libraries' names (clojure.test.check, clojure.tools.namespace, clojure.tools.deps, clojure.data.generators,\n  clojure.java.classpath, ...; and the suite's own clojure.test-clojure.*), identifiers that\n  merely contain the word (clojure-version, *clojure-version*, refer-clojure, CLOJURE_NS,\n  __clojureFnMap, thread names clojure-agent-*; some were renamed by hand after vendoring, see\n  doc/VENDOR-NOTES.md), prose and URLs (clojure.org).m2,R0,s1954,The clojure -> arbace renaming of agenda step 4 (doc/VENDOR-NOTES.md, \"What is renamed\"),\n  as a textual rewrite of source text: repr/clojure's rule :rename (arbace.repr.clojure.rules,\n  doc/REPR-CLOJURE.md; c2a's until 2026-10-17), which bin/clojure-tests applies to Clojure's\n  test suite and its test libraries. As arbace.j2c.rename it derived arbace/ from the frozen clojure/ once (bin/vendor-arbace and\n  bin/vendor-spec, on the branch arbace-for-java-26).\n\n  Renamed: names that belong to the vendored Clojure, written dotted or as paths:\n  - the Java packages clojure.lang, clojure.asm (with commons, signature), clojure.java.api,\n    whatever follows them (class names, members, descriptors \"Lclojure/lang/Var;\", array\n    names \"[Lclojure.lang.Var;\");\n  - the vendored namespaces (exactly: clojure.core, clojure.core.protocols, ..., see\n    `namespaces`), as symbols, qualified symbols and keywords, strings and resource paths\n    (clojure/core, clojure/pprint/cl_format, clojure/core__init);\n  - the keyword namespace clojure.error;\n  - the system properties Clojure reads: clojure.compile.*, clojure.compiler.*,\n    clojure.server.*, clojure.read.eval, clojure.main.report, clojure.basis;\n  - clojure.jar in usage texts;\n  - spec, vendored later (doc/VENDOR-NOTES.md, \"Spec\"): clojure.spec with whatever follows\n    (clojure.spec.alpha, .gen.alpha, .test.alpha, :clojure.spec.alpha/problems, the\n    clojure.spec.* system properties, clojure/spec/alpha) and clojure.core.specs.alpha.\n  Left alone: other libraries' names (clojure.test.check, clojure.tools.namespace, clojure.tools.deps, clojure.data.generators,\n  clojure.java.classpath, ...; and the suite's own clojure.test-clojure.*), identifiers that\n  merely contain the word (clojure-version, *clojure-version*, refer-clojure, CLOJURE_NS,\n  __clojureFnMap, thread names clojure-agent-*; some were renamed by hand after vendoring, see\n  doc/VENDOR-NOTES.md), prose and URLs (clojure.org).R1,v26,arbace.repr.clojure.rename10,namespacesV54,s4,cores14,core.protocolss13,core.reducerss11,core.servers12,core_deftypes10,core_prints10,core_proxys8,genclasss4,gvecs4,datas6,datafys3,edns9,inspectors7,instants10,java.basiss15,java.basis.impls11,java.browses14,java.browse-uis14,java.browse_uis7,java.ios12,java.javadocs12,java.processs10,java.shells4,mains4,maths6,pprints16,pprint.cl_formats20,pprint.column_writers15,pprint.dispatchs18,pprint.pprint_bases20,pprint.pretty_writers18,pprint.print_tables16,pprint.utilitiess7,reflects12,reflect.javas4,repls9,repl.depss3,sets10,stacktraces6,strings8,templates4,tests10,test.junits8,test.taps18,tools.deps.interops4,uuids4,walks3,xmls3,zips16,core.specs.alphas9,read.evals11,main.reports5,basiss3,jarm8,R2,i29,R3,i1,R4,s29,arbace/repr/clojure/rename.aeR0,s122,The namespaces of the vendored Clojure (clojure/**/*.clj), plus the files loaded into them,\n  without the clojure. prefix.v26,arbace.repr.clojure.rename8,prefixesV8,s4,langs3,asms8,java.apis7,compiles8,compilers6,servers5,errors4,specm8,R2,i44,R3,i1,R4,s29,arbace/repr/clojure/rename.aeR0,s44,Renamed together with whatever follows them.v26,arbace.repr.clojure.rename3,altm12,R5,TR6,L1,V2,R7,R8,R0,s82,A regex alternation of the names (longest first), their dots matched by regex sep.R2,i48,R3,i1,R4,s29,arbace/repr/clojure/rename.aev26,arbace.repr.clojure.rename6,beforem8,R5,TR2,i56,R3,i1,R4,s29,arbace/repr/clojure/rename.aev26,arbace.repr.clojure.rename3,dotm8,R5,TR2,i59,R3,i1,R4,s29,arbace/repr/clojure/rename.aev26,arbace.repr.clojure.rename3,anyv11,arbace.core3,strm8,R5,TR2,i60,R3,i1,R4,s29,arbace/repr/clojure/rename.aev26,arbace.repr.clojure.rename8,patternsm6,R2,i62,R3,i1,R4,s29,arbace/repr/clojure/rename.aev11,arbace.core10,re-patternv26,arbace.repr.clojure.rename11,source-filem8,R2,i75,R3,i1,R4,s29,arbace/repr/clojure/rename.aeR0,s179,A vendored namespace's source file as a path, once renamed: arbace/core.clj, whose Arbace\n  name is arbace/core.ae (Arbace's sources are .ae, doc/VENDOR-NOTES.md, hand change 19).v26,arbace.repr.clojure.rename6,renamem10,R6,L1,V1,R9,R0,s47,Renames the vendored Clojure's names in text s.R2,i80,R3,i1,R4,s29,arbace/repr/clojure/rename.ae")

var Lit_8 *jrt.String = jrt.Intern("arbace.repr.clojure.rename$eval557000004$loading__1927001464__auto____557000005")

var Lit_9 *jrt.String = jrt.Intern("arbace.repr.clojure.rename$eval557000008$fn__557000009")

var Lit_10 *jrt.String = jrt.Intern("arbace.repr.clojure.rename$alt")

var Lit_11 *jrt.String = jrt.Intern("(?:(?<=-D)|(?<![\\w.$-]))")

var Lit_12 *jrt.String = jrt.Intern("\\\\?\\.")

var Lit_13 *jrt.String = jrt.Intern("(?:")

var Lit_14 *jrt.String = jrt.Intern("|/)")

var Lit_15 *jrt.String = jrt.Intern("clojure(?=")

var Lit_16 *jrt.String = jrt.Intern(")(?![\\w-]))")

var Lit_17 *jrt.String = jrt.Intern("(?<=(?:^|[^\\w])L)clojure(?=")

var Lit_18 *jrt.String = jrt.Intern("(?:lang|asm|java")

var Lit_19 *jrt.String = jrt.Intern("api)")

var Lit_20 *jrt.String = jrt.Intern(")")

var Lit_21 *jrt.String = jrt.Intern(")(?!(?!__)[\\w*+!?-]|")

var Lit_22 *jrt.String = jrt.Intern("[a-z]))")

var Lit_23 *jrt.String = jrt.Intern("clojure(?=/(?:")

var Lit_24 *jrt.String = jrt.Intern("/")

var Lit_25 *jrt.String = jrt.Intern(")(?!(?!__)[\\w-]|/\\w))")

var Lit_26 *jrt.String = jrt.Intern("(?<![\\w.$-])(arbace/(?:")

var Lit_27 *jrt.String = jrt.Intern("))\\.clj(?![\\w])")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.clojure.rename$rename")
