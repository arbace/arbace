//line a2g_strings.ae:1
package aot_arbace_a2g_jrt

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.set")

var Lit_7 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_8 *jrt.String = jrt.Intern("io")

var Lit_9 *jrt.String = jrt.Intern("arbace.g2a.print")

var Lit_10 *jrt.String = jrt.Intern("gp")

var Lit_11 *jrt.String = jrt.Intern("commute")

var Lit_12 *jrt.String = jrt.Intern("deref")

var Lit_13 *jrt.String = jrt.Intern("conj")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_15 *jrt.String = jrt.Intern("doc")

var Lit_16 *jrt.String = jrt.Intern("What a2g knows of jrt's hand-written Go forms (go/arbace/jrt, doc/go/JRT-NOTES.md): the Go\n  types, methods, functions and variables they declare, the Java classes they define (by their\n  Define registrations) and which of those are stand-ins (A2G-SPEC §4.3, amendment J9), read\n  from the forms themselves so that a2g's output and jrt meet at the names jrt really has.")

var Lit_17 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_18 *jrt.String = jrt.Intern("seq?")

var Lit_19 *jrt.String = jrt.Intern("symbol?")

var Lit_20 *jrt.String = jrt.Intern("name")

var Lit_21 *jrt.String = jrt.Intern("first")

var Lit_22 *jrt.String = jrt.Intern("arbace.go")

var Lit_23 *jrt.String = jrt.Intern("go")

var Lit_24 *jrt.String = jrt.Intern("namespace")

var Lit_25 *jrt.String = jrt.Intern("tag")

var Lit_26 *jrt.String = jrt.Intern("tag-of")

var Lit_27 *jrt.String = jrt.Intern("*")

var Lit_28 *jrt.String = jrt.Intern("else")

var Lit_29 *jrt.String = jrt.Intern("second")

var Lit_30 *jrt.String = jrt.Intern("string?")

var Lit_31 *jrt.String = jrt.Intern("rest")

var Lit_32 *jrt.String = jrt.Intern("atom")

var Lit_33 *jrt.String = jrt.Intern("head")

var Lit_34 *jrt.String = jrt.Intern("ClassInfo")

var Lit_35 *jrt.String = jrt.Intern("apply")

var Lit_36 *jrt.String = jrt.Intern("reset!")

var Lit_37 *jrt.String = jrt.Intern("run!")

var Lit_38 *jrt.String = jrt.Intern("hash-map")

var Lit_39 *jrt.String = jrt.Intern("drop")

var Lit_40 *jrt.String = jrt.Intern("Name")

var Lit_41 *jrt.String = jrt.Intern("info")

var Lit_42 *jrt.String = jrt.Intern("read-forms")

var Lit_43 *jrt.String = jrt.Intern("volatile!")

var Lit_44 *jrt.String = jrt.Intern("types")

var Lit_45 *jrt.String = jrt.Intern("methods")

var Lit_46 *jrt.String = jrt.Intern("funcs")

var Lit_47 *jrt.String = jrt.Intern("vars")

var Lit_48 *jrt.String = jrt.Intern("classes")

var Lit_49 *jrt.String = jrt.Intern("consts")

var Lit_50 *jrt.String = jrt.Intern("seq")

var Lit_51 *jrt.String = jrt.Intern("go-head")

var Lit_52 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_53 *jrt.String = jrt.Intern("chunk-first")

var Lit_54 *jrt.String = jrt.Intern("next")

var Lit_55 *jrt.String = jrt.Intern("strip-doc")

var Lit_56 *jrt.String = jrt.Intern("type-params")

var Lit_57 *jrt.String = jrt.Intern("recv-type")

var Lit_58 *jrt.String = jrt.Intern("update-in")

var Lit_59 *jrt.String = jrt.Intern("vector?")

var Lit_60 *jrt.String = jrt.Intern("assoc-in")

var Lit_61 *jrt.String = jrt.Intern("update")

var Lit_62 *jrt.String = jrt.Intern("fnil")

var Lit_63 *jrt.String = jrt.Intern("kind")

var Lit_64 *jrt.String = jrt.Intern("struct")

var Lit_65 *jrt.String = jrt.Intern("interface")

var Lit_66 *jrt.String = jrt.Intern("other")

var Lit_67 *jrt.String = jrt.Intern("form")

var Lit_68 *jrt.String = jrt.Intern("chunk-rest")

var Lit_69 *jrt.String = jrt.Intern("values")

var Lit_70 *jrt.String = jrt.Intern("define-name")

var Lit_71 *jrt.String = jrt.Intern("to-array")

var Lit_72 *jrt.String = jrt.Intern("set")

var Lit_73 *jrt.String = jrt.Intern("embeds")

var Lit_74 *jrt.String = jrt.Intern("vec")

var Lit_75 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_76 *jrt.String = jrt.Intern("remove")

var Lit_77 *jrt.String = jrt.Intern("chunk-append")

var Lit_78 *jrt.String = jrt.Intern("chunk-cons")

var Lit_79 *jrt.String = jrt.Intern("cons")

var Lit_80 *jrt.String = jrt.Intern("chunk")

var Lit_81 *jrt.String = jrt.Intern("re-find")

var Lit_82 *jrt.String = jrt.Intern("_(tamago|darwin|windows|freebsd|netbsd|openbsd|dragonfly|solaris|illumos|aix|plan9|js|wasip1|ios|android)\\.ae$")

var Lit_83 *jrt.String = jrt.Intern("sort-by")

var Lit_84 *jrt.String = jrt.Intern("into")

var Lit_85 *jrt.String = jrt.Intern("files")

var Lit_86 *jrt.String = jrt.Intern("interfaces")

var Lit_87 *jrt.String = jrt.Intern("filter")

var Lit_88 *jrt.String = jrt.Intern("ends-with?")

var Lit_89 *jrt.String = jrt.Intern("not")

var Lit_90 *jrt.String = jrt.Intern("other-system?")

var Lit_91 *jrt.String = jrt.Intern("file")

var Lit_92 *jrt.String = jrt.Intern("sorted-map")

var Lit_93 *jrt.String = jrt.Intern("scan-file")

var Lit_94 *jrt.String = jrt.Intern("merge")

var Lit_95 *jrt.String = jrt.Intern("map")

var Lit_96 *jrt.String = jrt.Intern("vals")

var Lit_97 *jrt.String = jrt.Intern("merge-with")

var Lit_98 *jrt.String = jrt.Intern("union")

var Lit_99 *jrt.String = jrt.Intern("var")

var Lit_100 *jrt.String = jrt.Intern("replace")

var Lit_101 *jrt.String = jrt.Intern("standin")

var Lit_102 *jrt.String = jrt.Intern("starts-with?")

var Lit_103 *jrt.String = jrt.Intern("_class$")

var Lit_104 *jrt.String = jrt.Intern("concat")

var Lit_105 *jrt.String = jrt.Intern("interface-elems")

var Lit_106 *jrt.String = jrt.Intern("struct-embed")

var Lit_107 *jrt.String = jrt.Intern("mapcat")

var Lit_108 *jrt.String = jrt.Intern("iface-methods")

var Lit_109 *jrt.String = jrt.Intern("arbace.a2g.jrt$define_name")

var Lit_110 *jrt.String = jrt.Intern("arbace.a2g.jrt$define_name$walk__1261000019")

var Lit_111 *jrt.String = jrt.Intern("lit")

var Lit_112 *jrt.String = jrt.Intern("arbace.a2g.jrt$eval1261000004$loading__1927001464__auto____1261000005")

var Lit_113 *jrt.String = jrt.Intern("arbace.a2g.jrt$eval1261000008$fn__1261000009")

var Lit_114 *jrt.String = jrt.Intern("arbace.a2g.jrt$go_head")

var Lit_115 *jrt.String = jrt.Intern("arbace.a2g.jrt$head")

var Lit_116 *jrt.String = jrt.Intern("arbace.a2g.jrt$iface_methods")

var Lit_117 *jrt.String = jrt.Intern("arbace.a2g.jrt$iface_methods$fn__1261000268")

var Lit_118 *jrt.String = jrt.Intern("arbace.a2g.jrt$interface_elems")

var Lit_119 *jrt.String = jrt.Intern("arbace.a2g.jrt$interface_elems$iter__1261000161__1261000165")

var Lit_120 *jrt.String = jrt.Intern("arbace.a2g.jrt$interface_elems$iter__1261000161__1261000165$fn__1261000166")

var Lit_121 *jrt.String = jrt.Intern("arbace.a2g.jrt$interface_elems$iter__1261000161__1261000165$fn__1261000166$fn__1261000167")

var Lit_122 *jrt.String = jrt.Intern("arbace.a2g.jrt$interface_elems$iter__1261000171__1261000175")

var Lit_123 *jrt.String = jrt.Intern("arbace.a2g.jrt$interface_elems$iter__1261000171__1261000175$fn__1261000176")

var Lit_124 *jrt.String = jrt.Intern("arbace.a2g.jrt$interface_elems$iter__1261000171__1261000175$fn__1261000176$fn__1261000177")

var Lit_125 *jrt.String = jrt.Intern("arbace.a2g.jrt$other_system_QMARK_")

var Lit_126 *jrt.String = jrt.Intern("arbace.a2g.jrt$recv_type")

var Lit_127 *jrt.String = jrt.Intern("arbace.a2g.jrt$recv_type$nm__1261000015")

var Lit_128 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan")

var Lit_129 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$fn__1261000186")

var Lit_130 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$fn__1261000188")

var Lit_131 *jrt.String = jrt.Intern(".ae")

var Lit_132 *jrt.String = jrt.Intern("_test.ae")

var Lit_133 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000190__1261000194")

var Lit_134 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000190__1261000194$fn__1261000195")

var Lit_135 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000190__1261000194$fn__1261000195$fn__1261000196")

var Lit_136 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000200__1261000206")

var Lit_137 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207")

var Lit_138 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207$iter__1261000202__1261000211")

var Lit_139 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207$iter__1261000202__1261000211$fn__1261000212")

var Lit_140 *jrt.String = jrt.Intern("")

var Lit_141 *jrt.String = jrt.Intern("standin_")

var Lit_142 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207$iter__1261000202__1261000211$fn__1261000212$fn__1261000213")

var Lit_143 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000225__1261000229")

var Lit_144 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000225__1261000229$fn__1261000230")

var Lit_145 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000225__1261000229$fn__1261000230$fn__1261000231")

var Lit_146 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000245__1261000249")

var Lit_147 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000245__1261000249$fn__1261000250")

var Lit_148 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan$iter__1261000245__1261000249$fn__1261000250$fn__1261000251")

var Lit_149 *jrt.String = jrt.Intern("arbace.a2g.jrt$scan_file")

var Lit_150 *jrt.String = jrt.Intern("method")

var Lit_151 *jrt.String = jrt.Intern("type")

var Lit_152 *jrt.String = jrt.Intern("const")

var Lit_153 *jrt.String = jrt.Intern("func")

var Lit_154 *jrt.String = jrt.Intern("arbace.a2g.jrt$strip_doc")

var Lit_155 *jrt.String = jrt.Intern("arbace.a2g.jrt$struct_embed")

var Lit_156 *jrt.String = jrt.Intern("arbace.a2g.jrt$struct_methods")

var Lit_157 *jrt.String = jrt.Intern("arbace.a2g.jrt$tag_of")

var Lit_158 *jrt.String = jrt.Intern("in-ns")

var Lit_159 *jrt.String = jrt.Intern("private")

var Lit_160 *jrt.String = jrt.Intern("arglists")

var Lit_161 *jrt.String = jrt.Intern("f")

var Lit_162 *jrt.String = jrt.Intern("line")

var Lit_163 *jrt.String = jrt.Intern("column")

var Lit_164 *jrt.String = jrt.Intern("arbace/a2g/jrt.ae")

var Lit_165 *jrt.String = jrt.Intern("x")

var Lit_166 *jrt.String = jrt.Intern("r")

var Lit_167 *jrt.String = jrt.Intern("The receiver type name of a go/method's receiver parameter.")

var Lit_168 *jrt.String = jrt.Intern("xs")

var Lit_169 *jrt.String = jrt.Intern("init")

var Lit_170 *jrt.String = jrt.Intern("The Java name a (Define (addr (lit ClassInfo :Name \"...\" ...))) registers, or nil.")

var Lit_171 *jrt.String = jrt.Intern("Declarations of one jrt forms file: {:types {name {:kind :struct|:interface|:other :form f}}\n  :methods {type #{names}} :funcs #{} :vars #{} :classes {java-name var-name}}.")

var Lit_172 *jrt.String = jrt.Intern("tf")

var Lit_173 *jrt.String = jrt.Intern("Method names and embedded interface names of an interface type form.")

var Lit_174 *jrt.String = jrt.Intern("The embedded type name of a struct's first field, when it embeds one.")

var Lit_175 *jrt.String = jrt.Intern("n")

var Lit_176 *jrt.String = jrt.Intern("String")

var Lit_177 *jrt.String = jrt.Intern("Whether a forms file is named for a system other than Linux (Go's file name constraint,\n  NAME_GOOS.ae), so that a Linux build never has it.")

var Lit_178 *jrt.String = jrt.Intern("scan")

var Lit_179 *jrt.String = jrt.Intern("dir")

var Lit_180 *jrt.String = jrt.Intern("Scans jrt's hand-written forms directory (go/arbace/jrt, test files excluded, and the files\n  of other systems than Linux, which a2g translates for: those named for one by Go's file name\n  rule, such as the box's hostbox_tamago.ae, doc/go/BOX-NOTES.md). Returns\n  {:files {file-name scan} :types :methods :funcs :vars :classes {java-name {:var :go :file\n  :standin}} :interfaces {name {:methods :embeds}} :embeds {struct first-embedded}}.")

var Lit_181 *jrt.String = jrt.Intern("struct-methods")

var Lit_182 *jrt.String = jrt.Intern("go-type")

var Lit_183 *jrt.String = jrt.Intern("The method names a struct type has, its embedded ancestors' included (Go's promotion).")

var Lit_184 *jrt.String = jrt.Intern("The method names of an interface type, embedded interfaces included.")
