//line aot_arbace_a2g_jrt.ae:1
package aot_arbace_a2g_jrt

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_New() *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A { A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_Init(); t := &A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_jrt_A_Init(); tmp11 = A_arbace_a2g_jrt_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_a2g_jrt_A_Init(); tmp15 = A_arbace_a2g_jrt_A_const_6; tmp3 = tmp8.Invoke_O_O_O_O__O(tmp10, tmp12, tmp14, tmp15) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp16 != nil { panic(tmp16) }; return tmp3 }
//line :1:1
func A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_New() *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A { A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_Init(); t := &A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_11; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_9; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_10; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }









func A_arbace_a2g_jrt_head_A_New() *A_arbace_a2g_jrt_head_A { A_arbace_a2g_jrt_head_A_Init(); t := &A_arbace_a2g_jrt_head_A{}; t.Ctor(); return t }
//line :11:1
func (t *A_arbace_a2g_jrt_head_A) Ctor() {}
//line :11:1
func (t *A_arbace_a2g_jrt_head_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_13; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_15; tmp1 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(f__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { var tmp6 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_14; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp8 = A_arbace_a2g_jrt_A_const_15; return tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(f__0)) } else { return nil } }

func A_arbace_a2g_jrt_go_head_A_New() *A_arbace_a2g_jrt_go_head_A { A_arbace_a2g_jrt_go_head_A_Init(); t := &A_arbace_a2g_jrt_go_head_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_a2g_jrt_go_head_A) Ctor() {}
//line :13:1
func (t *A_arbace_a2g_jrt_go_head_A) Invoke_O_O__O(self, f__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(f__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_13; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_15; and__1927000168__auto____3 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(f__0)); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp6 any; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_16; var tmp7 lang.IFn = lang.IFn_Cast(tmp6); var tmp8 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp8 = A_arbace_a2g_jrt_A_const_17; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp10 = A_arbace_a2g_jrt_A_const_15; tmp1 = tmp7.Invoke_O__O(tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(f__0))) } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp11 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp11 = A_arbace_a2g_jrt_A_const_14; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_15; return tmp12.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :14:1
			return nil
		}
}
func A_arbace_a2g_jrt_tag_of_A_New() *A_arbace_a2g_jrt_tag_of_A { A_arbace_a2g_jrt_tag_of_A_Init(); t := &A_arbace_a2g_jrt_tag_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_a2g_jrt_tag_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_a2g_jrt_tag_of_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_18; var tmp2 *lang.Keyword = tmp1; return jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(x__0)) }

func A_arbace_a2g_jrt_recv_type_A_New() *A_arbace_a2g_jrt_recv_type_A { A_arbace_a2g_jrt_recv_type_A_Init(); t := &A_arbace_a2g_jrt_recv_type_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_a2g_jrt_recv_type_A) Ctor() {}
//line :19:1
func (t *A_arbace_a2g_jrt_recv_type_A) Invoke_O_O__O(self, r__0 any) any { var t__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(r__0)) { var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_19; t__2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(r__0) } else { t__2 = r__0 }; var body_nm__3 /*line :19:1*/*A_arbace_a2g_jrt_recv_type_nm__1261000015_A = A_arbace_a2g_jrt_recv_type_nm__1261000015_A_New(); var nm__3 any; var tmp3 *jrt.Class; A_arbace_a2g_jrt_recv_type_nm__1261000015_A_Init(); tmp3 = A_arbace_a2g_jrt_recv_type_nm__1261000015_A_fn_class; nm__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_nm__3.Ref(), tmp3, nil); return /*line :27:1*/ lang.IFn_Cast(nm__3).Invoke_O__O(t__2) }
//line :23:1
func A_arbace_a2g_jrt_recv_type_nm__1261000015_A_New() *A_arbace_a2g_jrt_recv_type_nm__1261000015_A { A_arbace_a2g_jrt_recv_type_nm__1261000015_A_Init(); t := &A_arbace_a2g_jrt_recv_type_nm__1261000015_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_a2g_jrt_recv_type_nm__1261000015_A) Ctor() {}
//line :23:1
func (t *A_arbace_a2g_jrt_recv_type_nm__1261000015_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__1)) { var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_14; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1) } else { var tmp3 any; var and__1927000168__auto____2 any; var tmp4 *lang.Var
											A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp5 any; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_20; var tmp6 any = tmp5; var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_15; tmp3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(x__1))).Ref() } else { tmp3 = and__1927000168__auto____2 }
//line :23:1
	if jrt.A2g_Truth(tmp3) {
		var tmp8 lang.IFn = lang.IFn_Cast(self); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_22; return tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :23:1
			var tmp10 any; var and__1927000168__auto____2_2 any; var tmp11 *lang.Var

			A_arbace_a2g_jrt_A_Init(); tmp11 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____2_2 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(and__1927000168__auto____2_2) { var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_13; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp14 = A_arbace_a2g_jrt_A_const_15; tmp10 = tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(x__1)) } else { tmp10 = and__1927000168__auto____2_2 }
//line :23:1
			if jrt.A2g_Truth(tmp10) {

				var tmp15 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp15 = A_arbace_a2g_jrt_A_const_14; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp17 = A_arbace_a2g_jrt_A_const_15; return tmp16.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :23:1
					var tmp18 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp18 = A_arbace_a2g_jrt_A_const_21; if tmp18 != nil { return nil } else { return nil } } } } }





func A_arbace_a2g_jrt_strip_doc_A_New() *A_arbace_a2g_jrt_strip_doc_A { A_arbace_a2g_jrt_strip_doc_A_Init(); t := &A_arbace_a2g_jrt_strip_doc_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_a2g_jrt_strip_doc_A) Ctor() {}
//line :29:1
func (t *A_arbace_a2g_jrt_strip_doc_A) Invoke_O_O__O(self, xs__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_23; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_15; if jrt.A2g_Truth(tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(xs__0))) { var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_24; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(xs__0) } else { return xs__0 } }

func A_arbace_a2g_jrt_define_name_A_New() *A_arbace_a2g_jrt_define_name_A { A_arbace_a2g_jrt_define_name_A_Init(); t := &A_arbace_a2g_jrt_define_name_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_a2g_jrt_define_name_A) Ctor() {}
//line :31:1
func (t *A_arbace_a2g_jrt_define_name_A) Invoke_O_O__O(self, init__0 any) any { var found__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_25; found__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(nil); var body_walk__3 /*line :31:1*/*A_arbace_a2g_jrt_define_name_walk__1261000019_A = A_arbace_a2g_jrt_define_name_walk__1261000019_A_New_O(found__2); var walk__3 any; var tmp2 *jrt.Class; A_arbace_a2g_jrt_define_name_walk__1261000019_A_Init(); tmp2 = A_arbace_a2g_jrt_define_name_walk__1261000019_A_fn_class; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_walk__3.Ref(), tmp2, nil);










	lang.IFn_Cast(walk__3).Invoke_O__O(init__0); var tmp3 /*line :34:1*/*lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_8; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(found__2) }
func A_arbace_a2g_jrt_define_name_walk__1261000019_A_New_O(p0 any) *A_arbace_a2g_jrt_define_name_walk__1261000019_A { A_arbace_a2g_jrt_define_name_walk__1261000019_A_Init(); t := &A_arbace_a2g_jrt_define_name_walk__1261000019_A{}; t.Ctor_O(p0); return t }
//line :35:1
func (t *A_arbace_a2g_jrt_define_name_walk__1261000019_A) Ctor_O(c__found any) { t.F_found = c__found }
//line :35:1
func (t *A_arbace_a2g_jrt_define_name_walk__1261000019_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var
	A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 bool; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_26; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z(Lit_111, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__1)); if and__1927000168__auto____3 { var tmp4 any; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_27; var tmp5 any = tmp4; var tmp6 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_22; tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(x__1))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { tmp1 = and__1927000168__auto____2 }
//line :36:1
	if jrt.A2g_Truth(tmp1) { var kvs__2 any; var tmp7 *lang.Var

		A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_28; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_31; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp11 = A_arbace_a2g_jrt_A_const_32; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_33; kvs__2 = tmp8.Invoke_O_O__O(tmp10, tmp12.Invoke_O_O__O(tmp13, x__1))
		var tmp14 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp14 = A_arbace_a2g_jrt_A_const_23; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp16 = A_arbace_a2g_jrt_A_const_34; if jrt.A2g_Truth(tmp15.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(kvs__2))) { var tmp17 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp17 = A_arbace_a2g_jrt_A_const_29; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = t.F_found; var tmp20 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp20 = A_arbace_a2g_jrt_A_const_35; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp22 = A_arbace_a2g_jrt_A_const_34; var tmp23 any = jrt.NN(tmp22).Invoke_O__O(kvs__2); var tmp24 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp24 = A_arbace_a2g_jrt_A_const_36; return tmp18.Invoke_O_O__O(tmp19, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, tmp23, tmp24.Ref(), kvs__2))) } else { return nil } } else {
//line :36:1
			var tmp25 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp25 = A_arbace_a2g_jrt_A_const_12; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(x__1)) {



				var tmp26 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp26 = A_arbace_a2g_jrt_A_const_30; return lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O_O__O(self, x__1) } else {
//line :36:1
					var tmp27 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp27 = A_arbace_a2g_jrt_A_const_21; if tmp27 != nil { return nil } else { return nil
					}
				}
		}
}




func A_arbace_a2g_jrt_scan_file_A_New() *A_arbace_a2g_jrt_scan_file_A { A_arbace_a2g_jrt_scan_file_A_Init(); t := &A_arbace_a2g_jrt_scan_file_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_a2g_jrt_scan_file_A) Ctor() {}
//line :45:1
func (t *A_arbace_a2g_jrt_scan_file_A) Invoke_O_O__O(self, f__0 any) any { var forms__2 any; var tmp1 *lang.Var;



	A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_37; forms__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__0); var acc__3 any; var tmp2 /*line :45:1*/*lang.Var;




	A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_38; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_39; var tmp5 any = tmp4.Ref(); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp8 = A_arbace_a2g_jrt_A_const_40; var tmp9 any = tmp8.Ref(); var tmp10 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp10 = lang.PersistentArrayMap_EMPTY; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_41; var tmp13 any = tmp12.Ref(); var tmp14 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp14 = lang.PersistentHashSet_EMPTY; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp16 = A_arbace_a2g_jrt_A_const_42; var tmp17 any = tmp16.Ref(); var tmp18 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp18 = lang.PersistentHashSet_EMPTY; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp20 = A_arbace_a2g_jrt_A_const_43; var tmp21 any = tmp20.Ref(); var tmp22 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp22 = lang.PersistentArrayMap_EMPTY; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp24 = A_arbace_a2g_jrt_A_const_44; var tmp25 any = tmp24.Ref(); var tmp26 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp26 = lang.PersistentHashSet_EMPTY; acc__3 = tmp3.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp7, tmp9, tmp11, tmp13, tmp15, tmp17, tmp19, tmp21, tmp23, tmp25, tmp26.Ref()))); var seq_1261000022__4 any; var tmp27 /*line :45:1*/*lang.Var;





	A_arbace_a2g_jrt_A_Init(); tmp27 = A_arbace_a2g_jrt_A_const_45; seq_1261000022__4 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(forms__2); var chunk_1261000023__5 any; var count_1261000024__6 int64 = 0; var i_1261000025__7 int64 = 0; L1:
//line :45:1
	for {





		if lang.Numbers_Lt_J_J__Z(i_1261000025__7, count_1261000024__6) { var fm__8 any = lang.Indexed_Cast(chunk_1261000023__5).Nth_I__O(lang.RT_IntCast_J__I(i_1261000025__7)); var h__9 any; var tmp28 *lang.Var
			A_arbace_a2g_jrt_A_Init(); tmp28 = A_arbace_a2g_jrt_A_const_46; h__9 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(fm__8)
//line :51:1
			if jrt.A2g_Truth(h__9) { var G__1261000026__10_ any = h__9


			L2: switch { default: switch lang.Util_Hash_O__I(G__1261000026__10_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z(G__1261000026__10_, Lit_150) { var vec__1261000027__11 any = fm__8; var seq__1261000028__12 any; var tmp29 *lang.Var


















				A_arbace_a2g_jrt_A_Init(); tmp29 = A_arbace_a2g_jrt_A_const_45; seq__1261000028__12 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(vec__1261000027__11)
//line :54:1
				var first__1261000029__13 any; var tmp30 *lang.Var


















				A_arbace_a2g_jrt_A_Init(); tmp30 = A_arbace_a2g_jrt_A_const_15; first__1261000029__13 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(seq__1261000028__12)
//line :54:1
				var seq__1261000028__14 any; var tmp31 *lang.Var


















				A_arbace_a2g_jrt_A_Init(); tmp31 = A_arbace_a2g_jrt_A_const_49; seq__1261000028__14 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(seq__1261000028__12)
//line :54:1
				var ___15 any = first__1261000029__13; var first__1261000029__16 any; var tmp32 *lang.Var; _ = ___15


















				A_arbace_a2g_jrt_A_Init(); tmp32 = A_arbace_a2g_jrt_A_const_15; first__1261000029__16 = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(seq__1261000028__14)
//line :54:1
				var seq__1261000028__17 any; var tmp33 *lang.Var


















				A_arbace_a2g_jrt_A_Init(); tmp33 = A_arbace_a2g_jrt_A_const_49; seq__1261000028__17 = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(seq__1261000028__14)
//line :54:1
				var nm__18 any = first__1261000029__16; var more__19 any = seq__1261000028__17; var more__20 any; var tmp34 *lang.Var



















				A_arbace_a2g_jrt_A_Init(); tmp34 = A_arbace_a2g_jrt_A_const_50; more__20 = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(more__19)
//line :54:1
				var more__21 any; var tmp35 *lang.Keyword




















				A_arbace_a2g_jrt_A_Init(); tmp35 = A_arbace_a2g_jrt_A_const_51; var tmp36 any = tmp35.Ref(); var tmp37 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp37 = A_arbace_a2g_jrt_A_const_15; if lang.Util_Equiv_O_O__Z(tmp36, lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(more__20)) { var tmp38 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp38 = A_arbace_a2g_jrt_A_const_32; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any; A_arbace_a2g_jrt_A_Init(); tmp40 = A_arbace_a2g_jrt_A_const_33; more__21 = tmp39.Invoke_O_O__O(tmp40, more__20) } else { more__21 = more__20 }
//line :54:1
				var params__22 any; var tmp41 *lang.Var





















				A_arbace_a2g_jrt_A_Init(); tmp41 = A_arbace_a2g_jrt_A_const_15; params__22 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(more__21)
//line :54:1
				var rt__23 any; var tmp42 *lang.Var






















				A_arbace_a2g_jrt_A_Init(); tmp42 = A_arbace_a2g_jrt_A_const_52; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp44 = A_arbace_a2g_jrt_A_const_15; rt__23 = tmp43.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(params__22))
				if jrt.A2g_Truth(rt__23) { var tmp45 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp46 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp46 = A_arbace_a2g_jrt_A_const_53; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp49 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp49 = A_arbace_a2g_jrt_A_const_40; var tmp50 any = lang.Tuple_Create_O_O__IPersistentVector(tmp49.Ref(), rt__23); var tmp51 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp51 = A_arbace_a2g_jrt_A_const_57; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp53 = A_arbace_a2g_jrt_A_const_9; var tmp54 any = jrt.NN(tmp53).GetRawRoot__O(); var tmp55 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp55 = lang.PersistentHashSet_EMPTY; var tmp56 any = tmp52.Invoke_O_O__O(tmp54, tmp55.Ref()); var tmp57 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp57 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp45).Reset_O__O(tmp47.Invoke_O_O_O_O__O(tmp48, tmp50, tmp56, lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(nm__18))) }
//line :54:1
				break L2 }; case 2: if lang.Util_Equiv_O_O__Z(G__1261000026__10_, Lit_151) { var vec__1261000030__11 any = fm__8; var seq__1261000031__12 any; var tmp58 *lang.Var
					A_arbace_a2g_jrt_A_Init(); tmp58 = A_arbace_a2g_jrt_A_const_45; seq__1261000031__12 = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()).Invoke_O__O(vec__1261000030__11)
//line :54:1
					var first__1261000032__13 any; var tmp59 *lang.Var
					A_arbace_a2g_jrt_A_Init(); tmp59 = A_arbace_a2g_jrt_A_const_15; first__1261000032__13 = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(seq__1261000031__12)
//line :54:1
					var seq__1261000031__14 any; var tmp60 *lang.Var
					A_arbace_a2g_jrt_A_Init(); tmp60 = A_arbace_a2g_jrt_A_const_49; seq__1261000031__14 = lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(seq__1261000031__12)
//line :54:1
					var ___15_2 any = first__1261000032__13; var more__16 any = seq__1261000031__14; var more__17 any; var tmp61 *lang.Var; _ = ___15_2

					A_arbace_a2g_jrt_A_Init(); tmp61 = A_arbace_a2g_jrt_A_const_50; more__17 = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(more__16)
					var tmp62 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp62 = A_arbace_a2g_jrt_A_const_54; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp64 = A_arbace_a2g_jrt_A_const_15; if jrt.A2g_Truth(tmp63.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(more__17))) { var seq_1261000033__18 any; var tmp65 *lang.Var
						A_arbace_a2g_jrt_A_Init(); tmp65 = A_arbace_a2g_jrt_A_const_45; seq_1261000033__18 = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(more__17)
//line :57:1
						var chunk_1261000034__19 any; var count_1261000035__20 int64 = 0; var i_1261000036__21 int64 = 0; L3: for {
							if lang.Numbers_Lt_J_J__Z(i_1261000036__21, count_1261000035__20) { var vec__1261000037__22 any = lang.Indexed_Cast(chunk_1261000034__19).Nth_I__O(lang.RT_IntCast_J__I(i_1261000036__21)); var nm__23 any = lang.RT_Nth_O_I_O__O(vec__1261000037__22, lang.RT_IntCast_J__I(0), nil); var tf__24 any = lang.RT_Nth_O_I_O__O(vec__1261000037__22, lang.RT_IntCast_J__I(1), nil); var tmp66 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp67 *lang.Var
								A_arbace_a2g_jrt_A_Init(); tmp67 = A_arbace_a2g_jrt_A_const_55; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp70 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp70 = A_arbace_a2g_jrt_A_const_39; var tmp71 any = tmp70.Ref(); var tmp72 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp72 = A_arbace_a2g_jrt_A_const_14; var tmp73 any = lang.Tuple_Create_O_O__IPersistentVector(tmp71, lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O__O(nm__23)); var tmp74 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp74 = A_arbace_a2g_jrt_A_const_58; var tmp75 any = tmp74.Ref(); var tmp76 *lang.Keyword; var tmp77 any; var and__1927000168__auto____25 any; var tmp78 *lang.Var
								A_arbace_a2g_jrt_A_Init(); tmp78 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____25 = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()).Invoke_O__O(tf__24); if jrt.A2g_Truth(and__1927000168__auto____25) { var tmp79 any; A_arbace_a2g_jrt_A_Init(); tmp79 = A_arbace_a2g_jrt_A_const_59; var tmp80 any = tmp79; var tmp81 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp81 = A_arbace_a2g_jrt_A_const_15; tmp77 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp80, lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke_O__O(tf__24))).Ref() } else { tmp77 = and__1927000168__auto____25 }; if jrt.A2g_Truth(tmp77) { A_arbace_a2g_jrt_A_Init(); tmp76 = A_arbace_a2g_jrt_A_const_60 } else { var tmp82 any; var and__1927000168__auto____25_2 any; var tmp83 *lang.Var
									A_arbace_a2g_jrt_A_Init(); tmp83 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____25_2 = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()).Invoke_O__O(tf__24); if jrt.A2g_Truth(and__1927000168__auto____25_2) { var tmp84 any; A_arbace_a2g_jrt_A_Init(); tmp84 = A_arbace_a2g_jrt_A_const_61; var tmp85 any = tmp84; var tmp86 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp86 = A_arbace_a2g_jrt_A_const_15; tmp82 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp85, lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()).Invoke_O__O(tf__24))).Ref() } else { tmp82 = and__1927000168__auto____25_2 }
//line :60:1
									if jrt.A2g_Truth(tmp82) { A_arbace_a2g_jrt_A_Init(); tmp76 = A_arbace_a2g_jrt_A_const_62 } else { var tmp87 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp87 = A_arbace_a2g_jrt_A_const_21; if tmp87 != nil { A_arbace_a2g_jrt_A_Init(); tmp76 = A_arbace_a2g_jrt_A_const_63 } else { tmp76 = nil } } }
//line :59:1
								var tmp88 any = tmp76.Ref(); var tmp89 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp89 = A_arbace_a2g_jrt_A_const_64; jrt.NN(tmp66).Reset_O__O(tmp68.Invoke_O_O_O__O(tmp69, tmp73, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp75, tmp88, tmp89.Ref(), tf__24))))
//line :58:1
								seq_1261000033__18, chunk_1261000034__19, count_1261000035__20, i_1261000036__21 = seq_1261000033__18, chunk_1261000034__19, count_1261000035__20, lang.Numbers_Unchecked_inc_J__J(i_1261000036__21); continue L3 } else { var temp__1927000414__auto____22 any; var tmp90 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp90 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____22 = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()).Invoke_O__O(seq_1261000033__18); if jrt.A2g_Truth(temp__1927000414__auto____22) { var seq_1261000033__23 any = temp__1927000414__auto____22; var tmp91 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp91 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()).Invoke_O__O(seq_1261000033__23)) { var c__1927000678__auto____24 any; var tmp92 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp92 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____24 = lang.IFn_Cast(jrt.NN(tmp92).GetRawRoot__O()).Invoke_O__O(seq_1261000033__23); var tmp93 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp93 = A_arbace_a2g_jrt_A_const_65; seq_1261000033__18, chunk_1261000034__19, count_1261000035__20, i_1261000036__21 = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()).Invoke_O__O(seq_1261000033__23), c__1927000678__auto____24, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__1261000040__24 any; var tmp94 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp94 = A_arbace_a2g_jrt_A_const_15; vec__1261000040__24 = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()).Invoke_O__O(seq_1261000033__23); var nm__25 any = lang.RT_Nth_O_I_O__O(vec__1261000040__24, lang.RT_IntCast_J__I(0), nil); var tf__26 any = lang.RT_Nth_O_I_O__O(vec__1261000040__24, lang.RT_IntCast_J__I(1), nil); var tmp95 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp96 *lang.Var
									A_arbace_a2g_jrt_A_Init(); tmp96 = A_arbace_a2g_jrt_A_const_55; var tmp97 lang.IFn = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()); var tmp98 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp99 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp99 = A_arbace_a2g_jrt_A_const_39; var tmp100 any = tmp99.Ref(); var tmp101 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp101 = A_arbace_a2g_jrt_A_const_14; var tmp102 any = lang.Tuple_Create_O_O__IPersistentVector(tmp100, lang.IFn_Cast(jrt.NN(tmp101).GetRawRoot__O()).Invoke_O__O(nm__25)); var tmp103 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp103 = A_arbace_a2g_jrt_A_const_58; var tmp104 any = tmp103.Ref(); var tmp105 *lang.Keyword; var tmp106 any; var and__1927000168__auto____27 any; var tmp107 *lang.Var
									A_arbace_a2g_jrt_A_Init(); tmp107 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____27 = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()).Invoke_O__O(tf__26); if jrt.A2g_Truth(and__1927000168__auto____27) { var tmp108 any; A_arbace_a2g_jrt_A_Init(); tmp108 = A_arbace_a2g_jrt_A_const_59; var tmp109 any = tmp108; var tmp110 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp110 = A_arbace_a2g_jrt_A_const_15; tmp106 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp109, lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()).Invoke_O__O(tf__26))).Ref() } else { tmp106 = and__1927000168__auto____27 }; if jrt.A2g_Truth(tmp106) { A_arbace_a2g_jrt_A_Init(); tmp105 = A_arbace_a2g_jrt_A_const_60 } else { var tmp111 any; var and__1927000168__auto____27_2 any; var tmp112 *lang.Var
										A_arbace_a2g_jrt_A_Init(); tmp112 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____27_2 = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()).Invoke_O__O(tf__26); if jrt.A2g_Truth(and__1927000168__auto____27_2) { var tmp113 any; A_arbace_a2g_jrt_A_Init(); tmp113 = A_arbace_a2g_jrt_A_const_61; var tmp114 any = tmp113; var tmp115 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp115 = A_arbace_a2g_jrt_A_const_15; tmp111 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp114, lang.IFn_Cast(jrt.NN(tmp115).GetRawRoot__O()).Invoke_O__O(tf__26))).Ref() } else { tmp111 = and__1927000168__auto____27_2 }
//line :60:1
										if jrt.A2g_Truth(tmp111) { A_arbace_a2g_jrt_A_Init(); tmp105 = A_arbace_a2g_jrt_A_const_62 } else { var tmp116 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp116 = A_arbace_a2g_jrt_A_const_21; if tmp116 != nil { A_arbace_a2g_jrt_A_Init(); tmp105 = A_arbace_a2g_jrt_A_const_63 } else { tmp105 = nil } } }
//line :59:1
									var tmp117 any = tmp105.Ref(); var tmp118 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp118 = A_arbace_a2g_jrt_A_const_64; jrt.NN(tmp95).Reset_O__O(tmp97.Invoke_O_O_O__O(tmp98, tmp102, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp104, tmp117, tmp118.Ref(), tf__26))))
//line :58:1
									var tmp119 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp119 = A_arbace_a2g_jrt_A_const_49; seq_1261000033__18, chunk_1261000034__19, count_1261000035__20, i_1261000036__21 = lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()).Invoke_O__O(seq_1261000033__23), nil, 0, 0; continue L3 } } }
//line :57:1
							break L3 } } else { var nm__18_2 any; var tmp120 *lang.Var






								A_arbace_a2g_jrt_A_Init(); tmp120 = A_arbace_a2g_jrt_A_const_15; nm__18_2 = lang.IFn_Cast(jrt.NN(tmp120).GetRawRoot__O()).Invoke_O__O(more__17)
//line :57:1
								var more__19_2 any; var tmp121 *lang.Var







								A_arbace_a2g_jrt_A_Init(); tmp121 = A_arbace_a2g_jrt_A_const_50; var tmp122 lang.IFn = lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()); var tmp123 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp123 = A_arbace_a2g_jrt_A_const_24; more__19_2 = tmp122.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp123).GetRawRoot__O()).Invoke_O__O(more__17))
//line :57:1
								var more__20_2 any; var tmp124 *lang.Keyword








								A_arbace_a2g_jrt_A_Init(); tmp124 = A_arbace_a2g_jrt_A_const_51; var tmp125 any = tmp124.Ref(); var tmp126 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp126 = A_arbace_a2g_jrt_A_const_15; if lang.Util_Equiv_O_O__Z(tmp125, lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()).Invoke_O__O(more__19_2)) { var tmp127 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp127 = A_arbace_a2g_jrt_A_const_32; var tmp128 lang.IFn = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()); var tmp129 any; A_arbace_a2g_jrt_A_Init(); tmp129 = A_arbace_a2g_jrt_A_const_33; more__20_2 = tmp128.Invoke_O_O__O(tmp129, more__19_2) } else { more__20_2 = more__19_2 }
//line :57:1
								var tf__21 any; var tmp130 *lang.Var









								A_arbace_a2g_jrt_A_Init(); tmp130 = A_arbace_a2g_jrt_A_const_15; tf__21 = lang.IFn_Cast(jrt.NN(tmp130).GetRawRoot__O()).Invoke_O__O(more__20_2)
								var tmp131 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp132 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp132 = A_arbace_a2g_jrt_A_const_55; var tmp133 lang.IFn = lang.IFn_Cast(jrt.NN(tmp132).GetRawRoot__O()); var tmp134 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp135 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp135 = A_arbace_a2g_jrt_A_const_39; var tmp136 any = tmp135.Ref(); var tmp137 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp137 = A_arbace_a2g_jrt_A_const_14; var tmp138 any = lang.Tuple_Create_O_O__IPersistentVector(tmp136, lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()).Invoke_O__O(nm__18_2)); var tmp139 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp139 = A_arbace_a2g_jrt_A_const_58; var tmp140 any = tmp139.Ref(); var tmp141 *lang.Keyword; var tmp142 any; var and__1927000168__auto____22 any; var tmp143 *lang.Var
								A_arbace_a2g_jrt_A_Init(); tmp143 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____22 = lang.IFn_Cast(jrt.NN(tmp143).GetRawRoot__O()).Invoke_O__O(tf__21); if jrt.A2g_Truth(and__1927000168__auto____22) { var tmp144 any; A_arbace_a2g_jrt_A_Init(); tmp144 = A_arbace_a2g_jrt_A_const_66; var tmp145 any = tmp144; var tmp146 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp146 = A_arbace_a2g_jrt_A_const_15; tmp142 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp145, lang.IFn_Cast(jrt.NN(tmp146).GetRawRoot__O()).Invoke_O__O(tf__21))).Ref() } else { tmp142 = and__1927000168__auto____22 }; if jrt.A2g_Truth(tmp142) { A_arbace_a2g_jrt_A_Init(); tmp141 = A_arbace_a2g_jrt_A_const_60 } else { var tmp147 any; var and__1927000168__auto____22_2 any; var tmp148 *lang.Var
									A_arbace_a2g_jrt_A_Init(); tmp148 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____22_2 = lang.IFn_Cast(jrt.NN(tmp148).GetRawRoot__O()).Invoke_O__O(tf__21); if jrt.A2g_Truth(and__1927000168__auto____22_2) { var tmp149 any; A_arbace_a2g_jrt_A_Init(); tmp149 = A_arbace_a2g_jrt_A_const_67; var tmp150 any = tmp149; var tmp151 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp151 = A_arbace_a2g_jrt_A_const_15; tmp147 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp150, lang.IFn_Cast(jrt.NN(tmp151).GetRawRoot__O()).Invoke_O__O(tf__21))).Ref() } else { tmp147 = and__1927000168__auto____22_2 }
//line :69:1
									if jrt.A2g_Truth(tmp147) { A_arbace_a2g_jrt_A_Init(); tmp141 = A_arbace_a2g_jrt_A_const_62 } else { var tmp152 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp152 = A_arbace_a2g_jrt_A_const_21; if tmp152 != nil { A_arbace_a2g_jrt_A_Init(); tmp141 = A_arbace_a2g_jrt_A_const_63 } else { tmp141 = nil } } }
//line :68:1
								var tmp153 any = tmp141.Ref(); var tmp154 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp154 = A_arbace_a2g_jrt_A_const_64; jrt.NN(tmp131).Reset_O__O(tmp133.Invoke_O_O_O__O(tmp134, tmp138, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp140, tmp153, tmp154.Ref(), tf__21)))) }
//line :54:1
					break L2 }; case 3: if lang.Util_Equiv_O_O__Z(G__1261000026__10_, Lit_152) { var vec__1261000043__11 any = fm__8; var seq__1261000044__12 any; var tmp155 *lang.Var








































						A_arbace_a2g_jrt_A_Init(); tmp155 = A_arbace_a2g_jrt_A_const_45; seq__1261000044__12 = lang.IFn_Cast(jrt.NN(tmp155).GetRawRoot__O()).Invoke_O__O(vec__1261000043__11)
//line :54:1
						var first__1261000045__13 any; var tmp156 *lang.Var








































						A_arbace_a2g_jrt_A_Init(); tmp156 = A_arbace_a2g_jrt_A_const_15; first__1261000045__13 = lang.IFn_Cast(jrt.NN(tmp156).GetRawRoot__O()).Invoke_O__O(seq__1261000044__12)
//line :54:1
						var seq__1261000044__14 any; var tmp157 *lang.Var








































						A_arbace_a2g_jrt_A_Init(); tmp157 = A_arbace_a2g_jrt_A_const_49; seq__1261000044__14 = lang.IFn_Cast(jrt.NN(tmp157).GetRawRoot__O()).Invoke_O__O(seq__1261000044__12)
//line :54:1
						var ___15_3 any = first__1261000045__13; var more__16_2 any = seq__1261000044__14; var more__17_2 any; var tmp158 *lang.Var; _ = ___15_3









































						A_arbace_a2g_jrt_A_Init(); tmp158 = A_arbace_a2g_jrt_A_const_50; more__17_2 = lang.IFn_Cast(jrt.NN(tmp158).GetRawRoot__O()).Invoke_O__O(more__16_2)
						var tmp159 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp159 = A_arbace_a2g_jrt_A_const_54; var tmp160 lang.IFn = lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()); var tmp161 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp161 = A_arbace_a2g_jrt_A_const_15; if jrt.A2g_Truth(tmp160.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()).Invoke_O__O(more__17_2))) { var seq_1261000046__18 any; var tmp162 *lang.Var
							A_arbace_a2g_jrt_A_Init(); tmp162 = A_arbace_a2g_jrt_A_const_45; seq_1261000046__18 = lang.IFn_Cast(jrt.NN(tmp162).GetRawRoot__O()).Invoke_O__O(more__17_2)
//line :97:1
							var chunk_1261000047__19 any; var count_1261000048__20 int64 = 0; var i_1261000049__21 int64 = 0; L4: for {
								if lang.Numbers_Lt_J_J__Z(i_1261000049__21, count_1261000048__20) { var vec__1261000050__22 any = lang.Indexed_Cast(chunk_1261000047__19).Nth_I__O(lang.RT_IntCast_J__I(i_1261000049__21)); var tg__23 any = lang.RT_Nth_O_I_O__O(vec__1261000050__22, lang.RT_IntCast_J__I(0), nil); var tmp163 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp163 = A_arbace_a2g_jrt_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()).Invoke_O__O(tg__23)) { var tmp164 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp165 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp165 = A_arbace_a2g_jrt_A_const_56; var tmp166 lang.IFn = lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()); var tmp167 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp168 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp168 = A_arbace_a2g_jrt_A_const_44; var tmp169 any = tmp168.Ref(); var tmp170 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp170 = A_arbace_a2g_jrt_A_const_9; var tmp171 any = jrt.NN(tmp170).GetRawRoot__O(); var tmp172 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp172 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp164).Reset_O__O(tmp166.Invoke_O_O_O_O__O(tmp167, tmp169, tmp171, lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()).Invoke_O__O(tg__23))) }; seq_1261000046__18, chunk_1261000047__19, count_1261000048__20, i_1261000049__21 = seq_1261000046__18, chunk_1261000047__19, count_1261000048__20, lang.Numbers_Unchecked_inc_J__J(i_1261000049__21); continue L4 } else { var temp__1927000414__auto____22_2 any; var tmp173 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp173 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____22_2 = lang.IFn_Cast(jrt.NN(tmp173).GetRawRoot__O()).Invoke_O__O(seq_1261000046__18); if jrt.A2g_Truth(temp__1927000414__auto____22_2) { var seq_1261000046__23 any = temp__1927000414__auto____22_2; var tmp174 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp174 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp174).GetRawRoot__O()).Invoke_O__O(seq_1261000046__23)) { var c__1927000678__auto____24_2 any; var tmp175 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp175 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____24_2 = lang.IFn_Cast(jrt.NN(tmp175).GetRawRoot__O()).Invoke_O__O(seq_1261000046__23); var tmp176 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp176 = A_arbace_a2g_jrt_A_const_65; seq_1261000046__18, chunk_1261000047__19, count_1261000048__20, i_1261000049__21 = lang.IFn_Cast(jrt.NN(tmp176).GetRawRoot__O()).Invoke_O__O(seq_1261000046__23), c__1927000678__auto____24_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____24_2))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var vec__1261000053__24 any; var tmp177 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp177 = A_arbace_a2g_jrt_A_const_15; vec__1261000053__24 = lang.IFn_Cast(jrt.NN(tmp177).GetRawRoot__O()).Invoke_O__O(seq_1261000046__23); var tg__25 any = lang.RT_Nth_O_I_O__O(vec__1261000053__24, lang.RT_IntCast_J__I(0), nil); var tmp178 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp178 = A_arbace_a2g_jrt_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp178).GetRawRoot__O()).Invoke_O__O(tg__25)) { var tmp179 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp180 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp180 = A_arbace_a2g_jrt_A_const_56; var tmp181 lang.IFn = lang.IFn_Cast(jrt.NN(tmp180).GetRawRoot__O()); var tmp182 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp183 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp183 = A_arbace_a2g_jrt_A_const_44; var tmp184 any = tmp183.Ref(); var tmp185 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp185 = A_arbace_a2g_jrt_A_const_9; var tmp186 any = jrt.NN(tmp185).GetRawRoot__O(); var tmp187 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp187 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp179).Reset_O__O(tmp181.Invoke_O_O_O_O__O(tmp182, tmp184, tmp186, lang.IFn_Cast(jrt.NN(tmp187).GetRawRoot__O()).Invoke_O__O(tg__25))) }; var tmp188 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp188 = A_arbace_a2g_jrt_A_const_49; seq_1261000046__18, chunk_1261000047__19, count_1261000048__20, i_1261000049__21 = lang.IFn_Cast(jrt.NN(tmp188).GetRawRoot__O()).Invoke_O__O(seq_1261000046__23), nil, 0, 0; continue L4 } } }
//line :97:1
								break L4 } } else {

									var tmp189 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp189 = A_arbace_a2g_jrt_A_const_13; var tmp190 lang.IFn = lang.IFn_Cast(jrt.NN(tmp189).GetRawRoot__O()); var tmp191 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp191 = A_arbace_a2g_jrt_A_const_15; if jrt.A2g_Truth(tmp190.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp191).GetRawRoot__O()).Invoke_O__O(more__17_2))) { var tmp192 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp193 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp193 = A_arbace_a2g_jrt_A_const_56; var tmp194 lang.IFn = lang.IFn_Cast(jrt.NN(tmp193).GetRawRoot__O()); var tmp195 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp196 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp196 = A_arbace_a2g_jrt_A_const_44; var tmp197 any = tmp196.Ref(); var tmp198 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp198 = A_arbace_a2g_jrt_A_const_9; var tmp199 any = jrt.NN(tmp198).GetRawRoot__O(); var tmp200 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp200 = A_arbace_a2g_jrt_A_const_14; var tmp201 lang.IFn = lang.IFn_Cast(jrt.NN(tmp200).GetRawRoot__O()); var tmp202 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp202 = A_arbace_a2g_jrt_A_const_15; jrt.NN(tmp192).Reset_O__O(tmp194.Invoke_O_O_O_O__O(tmp195, tmp197, tmp199, tmp201.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp202).GetRawRoot__O()).Invoke_O__O(more__17_2)))) } }
//line :54:1
						break L2 }; case 4: if lang.Util_Equiv_O_O__Z(G__1261000026__10_, Lit_153) { var vec__1261000056__11 any = fm__8; var ___12 any = lang.RT_Nth_O_I_O__O(vec__1261000056__11, lang.RT_IntCast_J__I(0), nil); var nm__13 any = lang.RT_Nth_O_I_O__O(vec__1261000056__11, lang.RT_IntCast_J__I(1), nil); var tmp203 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp204 *lang.Var; _ = ___12
























							A_arbace_a2g_jrt_A_Init(); tmp204 = A_arbace_a2g_jrt_A_const_56; var tmp205 lang.IFn = lang.IFn_Cast(jrt.NN(tmp204).GetRawRoot__O()); var tmp206 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp207 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp207 = A_arbace_a2g_jrt_A_const_41; var tmp208 any = tmp207.Ref(); var tmp209 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp209 = A_arbace_a2g_jrt_A_const_9; var tmp210 any = jrt.NN(tmp209).GetRawRoot__O(); var tmp211 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp211 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp203).Reset_O__O(tmp205.Invoke_O_O_O_O__O(tmp206, tmp208, tmp210, lang.IFn_Cast(jrt.NN(tmp211).GetRawRoot__O()).Invoke_O__O(nm__13)))
//line :54:1
							break L2 }; case 7: if lang.Util_Equiv_O_O__Z(G__1261000026__10_, Lit_99) { var vec__1261000059__11 any = fm__8; var seq__1261000060__12 any; var tmp212 *lang.Var

























								A_arbace_a2g_jrt_A_Init(); tmp212 = A_arbace_a2g_jrt_A_const_45; seq__1261000060__12 = lang.IFn_Cast(jrt.NN(tmp212).GetRawRoot__O()).Invoke_O__O(vec__1261000059__11)
//line :54:1
								var first__1261000061__13 any; var tmp213 *lang.Var

























								A_arbace_a2g_jrt_A_Init(); tmp213 = A_arbace_a2g_jrt_A_const_15; first__1261000061__13 = lang.IFn_Cast(jrt.NN(tmp213).GetRawRoot__O()).Invoke_O__O(seq__1261000060__12)
//line :54:1
								var seq__1261000060__14 any; var tmp214 *lang.Var

























								A_arbace_a2g_jrt_A_Init(); tmp214 = A_arbace_a2g_jrt_A_const_49; seq__1261000060__14 = lang.IFn_Cast(jrt.NN(tmp214).GetRawRoot__O()).Invoke_O__O(seq__1261000060__12)
//line :54:1
								var ___15_4 any = first__1261000061__13; var more__16_3 any = seq__1261000060__14; var more__17_3 any; var tmp215 *lang.Var; _ = ___15_4


























								A_arbace_a2g_jrt_A_Init(); tmp215 = A_arbace_a2g_jrt_A_const_50; more__17_3 = lang.IFn_Cast(jrt.NN(tmp215).GetRawRoot__O()).Invoke_O__O(more__16_3)
								var tmp216 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp216 = A_arbace_a2g_jrt_A_const_54; var tmp217 lang.IFn = lang.IFn_Cast(jrt.NN(tmp216).GetRawRoot__O()); var tmp218 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp218 = A_arbace_a2g_jrt_A_const_15; if jrt.A2g_Truth(tmp217.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp218).GetRawRoot__O()).Invoke_O__O(more__17_3))) { var seq_1261000062__18 any; var tmp219 *lang.Var
									A_arbace_a2g_jrt_A_Init(); tmp219 = A_arbace_a2g_jrt_A_const_45; seq_1261000062__18 = lang.IFn_Cast(jrt.NN(tmp219).GetRawRoot__O()).Invoke_O__O(more__17_3)
//line :82:1
									var chunk_1261000063__19 any; var count_1261000064__20 int64 = 0; var i_1261000065__21 int64 = 0; L5: for {
										if lang.Numbers_Lt_J_J__Z(i_1261000065__21, count_1261000064__20) { var vec__1261000066__22 any = lang.Indexed_Cast(chunk_1261000063__19).Nth_I__O(lang.RT_IntCast_J__I(i_1261000065__21)); var tg__23_2 any = lang.RT_Nth_O_I_O__O(vec__1261000066__22, lang.RT_IntCast_J__I(0), nil); var init__24 any = lang.RT_Nth_O_I_O__O(vec__1261000066__22, lang.RT_IntCast_J__I(1), nil); var tmp220 any; var and__1927000168__auto____25_3 any; var tmp221 *lang.Var
											A_arbace_a2g_jrt_A_Init(); tmp221 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____25_3 = lang.IFn_Cast(jrt.NN(tmp221).GetRawRoot__O()).Invoke_O__O(tg__23_2); if jrt.A2g_Truth(and__1927000168__auto____25_3) { var tmp222 any; A_arbace_a2g_jrt_A_Init(); tmp222 = A_arbace_a2g_jrt_A_const_71; var tmp223 any = tmp222; var tmp224 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp224 = A_arbace_a2g_jrt_A_const_15; tmp220 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp223, lang.IFn_Cast(jrt.NN(tmp224).GetRawRoot__O()).Invoke_O__O(tg__23_2))).Ref() } else { tmp220 = and__1927000168__auto____25_3 }; if jrt.A2g_Truth(tmp220) { var seq_1261000069__25 any; var tmp225 *lang.Var
												A_arbace_a2g_jrt_A_Init(); tmp225 = A_arbace_a2g_jrt_A_const_45; var tmp226 lang.IFn = lang.IFn_Cast(jrt.NN(tmp225).GetRawRoot__O()); var tmp227 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp227 = A_arbace_a2g_jrt_A_const_24; seq_1261000069__25 = tmp226.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp227).GetRawRoot__O()).Invoke_O__O(tg__23_2))
//line :84:1
												var chunk_1261000070__26 any; var count_1261000071__27 int64 = 0; var i_1261000072__28 int64 = 0; L6: for {
													if lang.Numbers_Lt_J_J__Z(i_1261000072__28, count_1261000071__27) { var s__29 any = lang.Indexed_Cast(chunk_1261000070__26).Nth_I__O(lang.RT_IntCast_J__I(i_1261000072__28)); var tmp228 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp229 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp229 = A_arbace_a2g_jrt_A_const_56; var tmp230 lang.IFn = lang.IFn_Cast(jrt.NN(tmp229).GetRawRoot__O()); var tmp231 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp232 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp232 = A_arbace_a2g_jrt_A_const_42; var tmp233 any = tmp232.Ref(); var tmp234 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp234 = A_arbace_a2g_jrt_A_const_9; var tmp235 any = jrt.NN(tmp234).GetRawRoot__O(); var tmp236 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp236 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp228).Reset_O__O(tmp230.Invoke_O_O_O_O__O(tmp231, tmp233, tmp235, lang.IFn_Cast(jrt.NN(tmp236).GetRawRoot__O()).Invoke_O__O(s__29))); seq_1261000069__25, chunk_1261000070__26, count_1261000071__27, i_1261000072__28 = seq_1261000069__25, chunk_1261000070__26, count_1261000071__27, lang.Numbers_Unchecked_inc_J__J(i_1261000072__28); continue L6 } else { var temp__1927000414__auto____29 any; var tmp237 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp237 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____29 = lang.IFn_Cast(jrt.NN(tmp237).GetRawRoot__O()).Invoke_O__O(seq_1261000069__25); if jrt.A2g_Truth(temp__1927000414__auto____29) { var seq_1261000069__30 any = temp__1927000414__auto____29; var tmp238 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp238 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp238).GetRawRoot__O()).Invoke_O__O(seq_1261000069__30)) { var c__1927000678__auto____31 any; var tmp239 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp239 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____31 = lang.IFn_Cast(jrt.NN(tmp239).GetRawRoot__O()).Invoke_O__O(seq_1261000069__30); var tmp240 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp240 = A_arbace_a2g_jrt_A_const_65; seq_1261000069__25, chunk_1261000070__26, count_1261000071__27, i_1261000072__28 = lang.IFn_Cast(jrt.NN(tmp240).GetRawRoot__O()).Invoke_O__O(seq_1261000069__30), c__1927000678__auto____31, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____31))), int64(lang.RT_IntCast_J__I(0)); continue L6 } else { var s__31 any; var tmp241 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp241 = A_arbace_a2g_jrt_A_const_15; s__31 = lang.IFn_Cast(jrt.NN(tmp241).GetRawRoot__O()).Invoke_O__O(seq_1261000069__30); var tmp242 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp243 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp243 = A_arbace_a2g_jrt_A_const_56; var tmp244 lang.IFn = lang.IFn_Cast(jrt.NN(tmp243).GetRawRoot__O()); var tmp245 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp246 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp246 = A_arbace_a2g_jrt_A_const_42; var tmp247 any = tmp246.Ref(); var tmp248 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp248 = A_arbace_a2g_jrt_A_const_9; var tmp249 any = jrt.NN(tmp248).GetRawRoot__O(); var tmp250 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp250 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp242).Reset_O__O(tmp244.Invoke_O_O_O_O__O(tmp245, tmp247, tmp249, lang.IFn_Cast(jrt.NN(tmp250).GetRawRoot__O()).Invoke_O__O(s__31))); var tmp251 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp251 = A_arbace_a2g_jrt_A_const_49; seq_1261000069__25, chunk_1261000070__26, count_1261000071__27, i_1261000072__28 = lang.IFn_Cast(jrt.NN(tmp251).GetRawRoot__O()).Invoke_O__O(seq_1261000069__30), nil, 0, 0; continue L6 } } }
//line :84:1
													break L6 } } else {

														var tmp252 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp253 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp253 = A_arbace_a2g_jrt_A_const_56; var tmp254 lang.IFn = lang.IFn_Cast(jrt.NN(tmp253).GetRawRoot__O()); var tmp255 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp256 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp256 = A_arbace_a2g_jrt_A_const_42; var tmp257 any = tmp256.Ref(); var tmp258 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp258 = A_arbace_a2g_jrt_A_const_9; var tmp259 any = jrt.NN(tmp258).GetRawRoot__O(); var tmp260 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp260 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp252).Reset_O__O(tmp254.Invoke_O_O_O_O__O(tmp255, tmp257, tmp259, lang.IFn_Cast(jrt.NN(tmp260).GetRawRoot__O()).Invoke_O__O(tg__23_2)))
//line :84:1
														var temp__1927000414__auto____25 any; var tmp261 *lang.Var


														A_arbace_a2g_jrt_A_Init(); tmp261 = A_arbace_a2g_jrt_A_const_69; temp__1927000414__auto____25 = lang.IFn_Cast(jrt.NN(tmp261).GetRawRoot__O()).Invoke_O__O(init__24); if jrt.A2g_Truth(temp__1927000414__auto____25) { var map__1261000073__26 any = temp__1927000414__auto____25; var map__1261000073__27 any; if lang.ISeq_InstanceOf(map__1261000073__26) { var tmp262 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp262 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp262).GetRawRoot__O()).Invoke_O__O(map__1261000073__26)) { var tmp263 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp263 = A_arbace_a2g_jrt_A_const_70; map__1261000073__27 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp263).GetRawRoot__O()).Invoke_O__O(map__1261000073__26), jrt.Object_class.ArrayClass())).Ref() } else { var tmp264 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp264 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp264).GetRawRoot__O()).Invoke_O__O(map__1261000073__26)) { var tmp265 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp265 = A_arbace_a2g_jrt_A_const_15; map__1261000073__27 = lang.IFn_Cast(jrt.NN(tmp265).GetRawRoot__O()).Invoke_O__O(map__1261000073__26) } else { lang.PersistentArrayMap_Init(); map__1261000073__27 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000073__27 = map__1261000073__26 }; var n__28 any; var tmp266 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp266 = A_arbace_a2g_jrt_A_const_35; n__28 = lang.RT_Get_O_O__O(map__1261000073__27, tmp266.Ref())
															var tmp267 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp268 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp268 = A_arbace_a2g_jrt_A_const_55; var tmp269 lang.IFn = lang.IFn_Cast(jrt.NN(tmp268).GetRawRoot__O()); var tmp270 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp271 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp271 = A_arbace_a2g_jrt_A_const_43; var tmp272 any = lang.Tuple_Create_O_O__IPersistentVector(tmp271.Ref(), n__28); var tmp273 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp273 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp267).Reset_O__O(tmp269.Invoke_O_O_O__O(tmp270, tmp272, lang.IFn_Cast(jrt.NN(tmp273).GetRawRoot__O()).Invoke_O__O(tg__23_2))) } }
//line :83:1
											seq_1261000062__18, chunk_1261000063__19, count_1261000064__20, i_1261000065__21 = seq_1261000062__18, chunk_1261000063__19, count_1261000064__20, lang.Numbers_Unchecked_inc_J__J(i_1261000065__21); continue L5 } else { var temp__1927000414__auto____22_3 any; var tmp274 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp274 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____22_3 = lang.IFn_Cast(jrt.NN(tmp274).GetRawRoot__O()).Invoke_O__O(seq_1261000062__18); if jrt.A2g_Truth(temp__1927000414__auto____22_3) { var seq_1261000062__23 any = temp__1927000414__auto____22_3; var tmp275 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp275 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp275).GetRawRoot__O()).Invoke_O__O(seq_1261000062__23)) { var c__1927000678__auto____24_3 any; var tmp276 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp276 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____24_3 = lang.IFn_Cast(jrt.NN(tmp276).GetRawRoot__O()).Invoke_O__O(seq_1261000062__23); var tmp277 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp277 = A_arbace_a2g_jrt_A_const_65; seq_1261000062__18, chunk_1261000063__19, count_1261000064__20, i_1261000065__21 = lang.IFn_Cast(jrt.NN(tmp277).GetRawRoot__O()).Invoke_O__O(seq_1261000062__23), c__1927000678__auto____24_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____24_3))), int64(lang.RT_IntCast_J__I(0)); continue L5 } else { var vec__1261000075__24 any; var tmp278 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp278 = A_arbace_a2g_jrt_A_const_15; vec__1261000075__24 = lang.IFn_Cast(jrt.NN(tmp278).GetRawRoot__O()).Invoke_O__O(seq_1261000062__23); var tg__25_2 any = lang.RT_Nth_O_I_O__O(vec__1261000075__24, lang.RT_IntCast_J__I(0), nil); var init__26 any = lang.RT_Nth_O_I_O__O(vec__1261000075__24, lang.RT_IntCast_J__I(1), nil); var tmp279 any; var and__1927000168__auto____27_3 any; var tmp280 *lang.Var
												A_arbace_a2g_jrt_A_Init(); tmp280 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____27_3 = lang.IFn_Cast(jrt.NN(tmp280).GetRawRoot__O()).Invoke_O__O(tg__25_2); if jrt.A2g_Truth(and__1927000168__auto____27_3) { var tmp281 any; A_arbace_a2g_jrt_A_Init(); tmp281 = A_arbace_a2g_jrt_A_const_71; var tmp282 any = tmp281; var tmp283 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp283 = A_arbace_a2g_jrt_A_const_15; tmp279 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp282, lang.IFn_Cast(jrt.NN(tmp283).GetRawRoot__O()).Invoke_O__O(tg__25_2))).Ref() } else { tmp279 = and__1927000168__auto____27_3 }; if jrt.A2g_Truth(tmp279) { var seq_1261000078__27 any; var tmp284 *lang.Var
													A_arbace_a2g_jrt_A_Init(); tmp284 = A_arbace_a2g_jrt_A_const_45; var tmp285 lang.IFn = lang.IFn_Cast(jrt.NN(tmp284).GetRawRoot__O()); var tmp286 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp286 = A_arbace_a2g_jrt_A_const_24; seq_1261000078__27 = tmp285.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp286).GetRawRoot__O()).Invoke_O__O(tg__25_2))
//line :84:1
													var chunk_1261000079__28 any; var count_1261000080__29 int64 = 0; var i_1261000081__30 int64 = 0; L7: for {
														if lang.Numbers_Lt_J_J__Z(i_1261000081__30, count_1261000080__29) { var s__31_2 any = lang.Indexed_Cast(chunk_1261000079__28).Nth_I__O(lang.RT_IntCast_J__I(i_1261000081__30)); var tmp287 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp288 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp288 = A_arbace_a2g_jrt_A_const_56; var tmp289 lang.IFn = lang.IFn_Cast(jrt.NN(tmp288).GetRawRoot__O()); var tmp290 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp291 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp291 = A_arbace_a2g_jrt_A_const_42; var tmp292 any = tmp291.Ref(); var tmp293 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp293 = A_arbace_a2g_jrt_A_const_9; var tmp294 any = jrt.NN(tmp293).GetRawRoot__O(); var tmp295 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp295 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp287).Reset_O__O(tmp289.Invoke_O_O_O_O__O(tmp290, tmp292, tmp294, lang.IFn_Cast(jrt.NN(tmp295).GetRawRoot__O()).Invoke_O__O(s__31_2))); seq_1261000078__27, chunk_1261000079__28, count_1261000080__29, i_1261000081__30 = seq_1261000078__27, chunk_1261000079__28, count_1261000080__29, lang.Numbers_Unchecked_inc_J__J(i_1261000081__30); continue L7 } else { var temp__1927000414__auto____31 any; var tmp296 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp296 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____31 = lang.IFn_Cast(jrt.NN(tmp296).GetRawRoot__O()).Invoke_O__O(seq_1261000078__27); if jrt.A2g_Truth(temp__1927000414__auto____31) { var seq_1261000078__32 any = temp__1927000414__auto____31; var tmp297 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp297 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp297).GetRawRoot__O()).Invoke_O__O(seq_1261000078__32)) { var c__1927000678__auto____33 any; var tmp298 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp298 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____33 = lang.IFn_Cast(jrt.NN(tmp298).GetRawRoot__O()).Invoke_O__O(seq_1261000078__32); var tmp299 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp299 = A_arbace_a2g_jrt_A_const_65; seq_1261000078__27, chunk_1261000079__28, count_1261000080__29, i_1261000081__30 = lang.IFn_Cast(jrt.NN(tmp299).GetRawRoot__O()).Invoke_O__O(seq_1261000078__32), c__1927000678__auto____33, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____33))), int64(lang.RT_IntCast_J__I(0)); continue L7 } else { var s__33 any; var tmp300 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp300 = A_arbace_a2g_jrt_A_const_15; s__33 = lang.IFn_Cast(jrt.NN(tmp300).GetRawRoot__O()).Invoke_O__O(seq_1261000078__32); var tmp301 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp302 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp302 = A_arbace_a2g_jrt_A_const_56; var tmp303 lang.IFn = lang.IFn_Cast(jrt.NN(tmp302).GetRawRoot__O()); var tmp304 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp305 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp305 = A_arbace_a2g_jrt_A_const_42; var tmp306 any = tmp305.Ref(); var tmp307 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp307 = A_arbace_a2g_jrt_A_const_9; var tmp308 any = jrt.NN(tmp307).GetRawRoot__O(); var tmp309 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp309 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp301).Reset_O__O(tmp303.Invoke_O_O_O_O__O(tmp304, tmp306, tmp308, lang.IFn_Cast(jrt.NN(tmp309).GetRawRoot__O()).Invoke_O__O(s__33))); var tmp310 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp310 = A_arbace_a2g_jrt_A_const_49; seq_1261000078__27, chunk_1261000079__28, count_1261000080__29, i_1261000081__30 = lang.IFn_Cast(jrt.NN(tmp310).GetRawRoot__O()).Invoke_O__O(seq_1261000078__32), nil, 0, 0; continue L7 } } }
//line :84:1
														break L7 } } else {

															var tmp311 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp312 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp312 = A_arbace_a2g_jrt_A_const_56; var tmp313 lang.IFn = lang.IFn_Cast(jrt.NN(tmp312).GetRawRoot__O()); var tmp314 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp315 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp315 = A_arbace_a2g_jrt_A_const_42; var tmp316 any = tmp315.Ref(); var tmp317 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp317 = A_arbace_a2g_jrt_A_const_9; var tmp318 any = jrt.NN(tmp317).GetRawRoot__O(); var tmp319 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp319 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp311).Reset_O__O(tmp313.Invoke_O_O_O_O__O(tmp314, tmp316, tmp318, lang.IFn_Cast(jrt.NN(tmp319).GetRawRoot__O()).Invoke_O__O(tg__25_2)))
//line :84:1
															var temp__1927000414__auto____27 any; var tmp320 *lang.Var


															A_arbace_a2g_jrt_A_Init(); tmp320 = A_arbace_a2g_jrt_A_const_69; temp__1927000414__auto____27 = lang.IFn_Cast(jrt.NN(tmp320).GetRawRoot__O()).Invoke_O__O(init__26); if jrt.A2g_Truth(temp__1927000414__auto____27) { var map__1261000082__28 any = temp__1927000414__auto____27; var map__1261000082__29 any; if lang.ISeq_InstanceOf(map__1261000082__28) { var tmp321 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp321 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp321).GetRawRoot__O()).Invoke_O__O(map__1261000082__28)) { var tmp322 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp322 = A_arbace_a2g_jrt_A_const_70; map__1261000082__29 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp322).GetRawRoot__O()).Invoke_O__O(map__1261000082__28), jrt.Object_class.ArrayClass())).Ref() } else { var tmp323 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp323 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp323).GetRawRoot__O()).Invoke_O__O(map__1261000082__28)) { var tmp324 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp324 = A_arbace_a2g_jrt_A_const_15; map__1261000082__29 = lang.IFn_Cast(jrt.NN(tmp324).GetRawRoot__O()).Invoke_O__O(map__1261000082__28) } else { lang.PersistentArrayMap_Init(); map__1261000082__29 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000082__29 = map__1261000082__28 }; var n__30 any; var tmp325 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp325 = A_arbace_a2g_jrt_A_const_35; n__30 = lang.RT_Get_O_O__O(map__1261000082__29, tmp325.Ref())
																var tmp326 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp327 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp327 = A_arbace_a2g_jrt_A_const_55; var tmp328 lang.IFn = lang.IFn_Cast(jrt.NN(tmp327).GetRawRoot__O()); var tmp329 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp330 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp330 = A_arbace_a2g_jrt_A_const_43; var tmp331 any = lang.Tuple_Create_O_O__IPersistentVector(tmp330.Ref(), n__30); var tmp332 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp332 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp326).Reset_O__O(tmp328.Invoke_O_O_O__O(tmp329, tmp331, lang.IFn_Cast(jrt.NN(tmp332).GetRawRoot__O()).Invoke_O__O(tg__25_2))) } }
//line :83:1
												var tmp333 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp333 = A_arbace_a2g_jrt_A_const_49; seq_1261000062__18, chunk_1261000063__19, count_1261000064__20, i_1261000065__21 = lang.IFn_Cast(jrt.NN(tmp333).GetRawRoot__O()).Invoke_O__O(seq_1261000062__23), nil, 0, 0; continue L5 } } }
//line :82:1
										break L5 } } else { var vec__1261000084__18 any = more__17_3; var tg__19 any = lang.RT_Nth_O_I_O__O(vec__1261000084__18, lang.RT_IntCast_J__I(0), nil); var init__20 any = lang.RT_Nth_O_I_O__O(vec__1261000084__18, lang.RT_IntCast_J__I(1), nil); var tmp334 any; var and__1927000168__auto____21 any; var tmp335 *lang.Var







											A_arbace_a2g_jrt_A_Init(); tmp335 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____21 = lang.IFn_Cast(jrt.NN(tmp335).GetRawRoot__O()).Invoke_O__O(tg__19); if jrt.A2g_Truth(and__1927000168__auto____21) { var tmp336 any; A_arbace_a2g_jrt_A_Init(); tmp336 = A_arbace_a2g_jrt_A_const_68; var tmp337 any = tmp336; var tmp338 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp338 = A_arbace_a2g_jrt_A_const_15; tmp334 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp337, lang.IFn_Cast(jrt.NN(tmp338).GetRawRoot__O()).Invoke_O__O(tg__19))).Ref() } else { tmp334 = and__1927000168__auto____21 }; if jrt.A2g_Truth(tmp334) { var seq_1261000087__21 any; var tmp339 *lang.Var
												A_arbace_a2g_jrt_A_Init(); tmp339 = A_arbace_a2g_jrt_A_const_45; var tmp340 lang.IFn = lang.IFn_Cast(jrt.NN(tmp339).GetRawRoot__O()); var tmp341 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp341 = A_arbace_a2g_jrt_A_const_24; seq_1261000087__21 = tmp340.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp341).GetRawRoot__O()).Invoke_O__O(tg__19))
//line :90:1
												var chunk_1261000088__22 any; var count_1261000089__23 int64 = 0; var i_1261000090__24 int64 = 0; L8: for {
													if lang.Numbers_Lt_J_J__Z(i_1261000090__24, count_1261000089__23) { var s__25 any = lang.Indexed_Cast(chunk_1261000088__22).Nth_I__O(lang.RT_IntCast_J__I(i_1261000090__24)); var tmp342 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp343 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp343 = A_arbace_a2g_jrt_A_const_56; var tmp344 lang.IFn = lang.IFn_Cast(jrt.NN(tmp343).GetRawRoot__O()); var tmp345 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp346 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp346 = A_arbace_a2g_jrt_A_const_42; var tmp347 any = tmp346.Ref(); var tmp348 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp348 = A_arbace_a2g_jrt_A_const_9; var tmp349 any = jrt.NN(tmp348).GetRawRoot__O(); var tmp350 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp350 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp342).Reset_O__O(tmp344.Invoke_O_O_O_O__O(tmp345, tmp347, tmp349, lang.IFn_Cast(jrt.NN(tmp350).GetRawRoot__O()).Invoke_O__O(s__25))); seq_1261000087__21, chunk_1261000088__22, count_1261000089__23, i_1261000090__24 = seq_1261000087__21, chunk_1261000088__22, count_1261000089__23, lang.Numbers_Unchecked_inc_J__J(i_1261000090__24); continue L8 } else { var temp__1927000414__auto____25_2 any; var tmp351 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp351 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____25_2 = lang.IFn_Cast(jrt.NN(tmp351).GetRawRoot__O()).Invoke_O__O(seq_1261000087__21); if jrt.A2g_Truth(temp__1927000414__auto____25_2) { var seq_1261000087__26 any = temp__1927000414__auto____25_2; var tmp352 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp352 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp352).GetRawRoot__O()).Invoke_O__O(seq_1261000087__26)) { var c__1927000678__auto____27 any; var tmp353 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp353 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____27 = lang.IFn_Cast(jrt.NN(tmp353).GetRawRoot__O()).Invoke_O__O(seq_1261000087__26); var tmp354 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp354 = A_arbace_a2g_jrt_A_const_65; seq_1261000087__21, chunk_1261000088__22, count_1261000089__23, i_1261000090__24 = lang.IFn_Cast(jrt.NN(tmp354).GetRawRoot__O()).Invoke_O__O(seq_1261000087__26), c__1927000678__auto____27, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I(0)); continue L8 } else { var s__27 any; var tmp355 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp355 = A_arbace_a2g_jrt_A_const_15; s__27 = lang.IFn_Cast(jrt.NN(tmp355).GetRawRoot__O()).Invoke_O__O(seq_1261000087__26); var tmp356 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp357 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp357 = A_arbace_a2g_jrt_A_const_56; var tmp358 lang.IFn = lang.IFn_Cast(jrt.NN(tmp357).GetRawRoot__O()); var tmp359 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp360 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp360 = A_arbace_a2g_jrt_A_const_42; var tmp361 any = tmp360.Ref(); var tmp362 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp362 = A_arbace_a2g_jrt_A_const_9; var tmp363 any = jrt.NN(tmp362).GetRawRoot__O(); var tmp364 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp364 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp356).Reset_O__O(tmp358.Invoke_O_O_O_O__O(tmp359, tmp361, tmp363, lang.IFn_Cast(jrt.NN(tmp364).GetRawRoot__O()).Invoke_O__O(s__27))); var tmp365 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp365 = A_arbace_a2g_jrt_A_const_49; seq_1261000087__21, chunk_1261000088__22, count_1261000089__23, i_1261000090__24 = lang.IFn_Cast(jrt.NN(tmp365).GetRawRoot__O()).Invoke_O__O(seq_1261000087__26), nil, 0, 0; continue L8 } } }
//line :90:1
													break L8 } } else {

														var tmp366 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp367 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp367 = A_arbace_a2g_jrt_A_const_56; var tmp368 lang.IFn = lang.IFn_Cast(jrt.NN(tmp367).GetRawRoot__O()); var tmp369 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp370 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp370 = A_arbace_a2g_jrt_A_const_42; var tmp371 any = tmp370.Ref(); var tmp372 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp372 = A_arbace_a2g_jrt_A_const_9; var tmp373 any = jrt.NN(tmp372).GetRawRoot__O(); var tmp374 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp374 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp366).Reset_O__O(tmp368.Invoke_O_O_O_O__O(tmp369, tmp371, tmp373, lang.IFn_Cast(jrt.NN(tmp374).GetRawRoot__O()).Invoke_O__O(tg__19)))
//line :90:1
														var temp__1927000414__auto____21 any; var tmp375 *lang.Var


														A_arbace_a2g_jrt_A_Init(); tmp375 = A_arbace_a2g_jrt_A_const_69; temp__1927000414__auto____21 = lang.IFn_Cast(jrt.NN(tmp375).GetRawRoot__O()).Invoke_O__O(init__20); if jrt.A2g_Truth(temp__1927000414__auto____21) { var map__1261000091__22 any = temp__1927000414__auto____21; var map__1261000091__23 any; if lang.ISeq_InstanceOf(map__1261000091__22) { var tmp376 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp376 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp376).GetRawRoot__O()).Invoke_O__O(map__1261000091__22)) { var tmp377 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp377 = A_arbace_a2g_jrt_A_const_70; map__1261000091__23 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp377).GetRawRoot__O()).Invoke_O__O(map__1261000091__22), jrt.Object_class.ArrayClass())).Ref() } else { var tmp378 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp378 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp378).GetRawRoot__O()).Invoke_O__O(map__1261000091__22)) { var tmp379 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp379 = A_arbace_a2g_jrt_A_const_15; map__1261000091__23 = lang.IFn_Cast(jrt.NN(tmp379).GetRawRoot__O()).Invoke_O__O(map__1261000091__22) } else { lang.PersistentArrayMap_Init(); map__1261000091__23 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000091__23 = map__1261000091__22 }; var n__24 any; var tmp380 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp380 = A_arbace_a2g_jrt_A_const_35; n__24 = lang.RT_Get_O_O__O(map__1261000091__23, tmp380.Ref())
															var tmp381 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp382 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp382 = A_arbace_a2g_jrt_A_const_55; var tmp383 lang.IFn = lang.IFn_Cast(jrt.NN(tmp382).GetRawRoot__O()); var tmp384 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp385 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp385 = A_arbace_a2g_jrt_A_const_43; var tmp386 any = lang.Tuple_Create_O_O__IPersistentVector(tmp385.Ref(), n__24); var tmp387 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp387 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp381).Reset_O__O(tmp383.Invoke_O_O_O__O(tmp384, tmp386, lang.IFn_Cast(jrt.NN(tmp387).GetRawRoot__O()).Invoke_O__O(tg__19))) } } }
//line :54:1
								break L2 }; default:}}
//line :51:1
				seq_1261000022__4, chunk_1261000023__5, count_1261000024__6, i_1261000025__7 = seq_1261000022__4, chunk_1261000023__5, count_1261000024__6, lang.Numbers_Unchecked_inc_J__J(i_1261000025__7); continue L1 } else { seq_1261000022__4, chunk_1261000023__5, count_1261000024__6, i_1261000025__7 = seq_1261000022__4, chunk_1261000023__5, count_1261000024__6, lang.Numbers_Unchecked_inc_J__J(i_1261000025__7); continue L1 } } else { var temp__1927000414__auto____8 any; var tmp388 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp388 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp388).GetRawRoot__O()).Invoke_O__O(seq_1261000022__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_1261000022__9 any = temp__1927000414__auto____8; var tmp389 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp389 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp389).GetRawRoot__O()).Invoke_O__O(seq_1261000022__9)) { var c__1927000678__auto____10 any; var tmp390 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp390 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp390).GetRawRoot__O()).Invoke_O__O(seq_1261000022__9); var tmp391 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp391 = A_arbace_a2g_jrt_A_const_65; seq_1261000022__4, chunk_1261000023__5, count_1261000024__6, i_1261000025__7 = lang.IFn_Cast(jrt.NN(tmp391).GetRawRoot__O()).Invoke_O__O(seq_1261000022__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var fm__10 any; var tmp392 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp392 = A_arbace_a2g_jrt_A_const_15; fm__10 = lang.IFn_Cast(jrt.NN(tmp392).GetRawRoot__O()).Invoke_O__O(seq_1261000022__9); var h__11 any; var tmp393 *lang.Var
					A_arbace_a2g_jrt_A_Init(); tmp393 = A_arbace_a2g_jrt_A_const_46; h__11 = lang.IFn_Cast(jrt.NN(tmp393).GetRawRoot__O()).Invoke_O__O(fm__10)
//line :51:1
					if jrt.A2g_Truth(h__11) { var G__1261000093__12_ any = h__11


					L9: switch { default: switch lang.Util_Hash_O__I(G__1261000093__12_) >> 0 & 7 { case 1: if lang.Util_Equiv_O_O__Z(G__1261000093__12_, Lit_150) { var vec__1261000094__13 any = fm__10; var seq__1261000095__14 any; var tmp394 *lang.Var


















						A_arbace_a2g_jrt_A_Init(); tmp394 = A_arbace_a2g_jrt_A_const_45; seq__1261000095__14 = lang.IFn_Cast(jrt.NN(tmp394).GetRawRoot__O()).Invoke_O__O(vec__1261000094__13)
//line :54:1
						var first__1261000096__15 any; var tmp395 *lang.Var


















						A_arbace_a2g_jrt_A_Init(); tmp395 = A_arbace_a2g_jrt_A_const_15; first__1261000096__15 = lang.IFn_Cast(jrt.NN(tmp395).GetRawRoot__O()).Invoke_O__O(seq__1261000095__14)
//line :54:1
						var seq__1261000095__16 any; var tmp396 *lang.Var


















						A_arbace_a2g_jrt_A_Init(); tmp396 = A_arbace_a2g_jrt_A_const_49; seq__1261000095__16 = lang.IFn_Cast(jrt.NN(tmp396).GetRawRoot__O()).Invoke_O__O(seq__1261000095__14)
//line :54:1
						var ___17 any = first__1261000096__15; var first__1261000096__18 any; var tmp397 *lang.Var; _ = ___17


















						A_arbace_a2g_jrt_A_Init(); tmp397 = A_arbace_a2g_jrt_A_const_15; first__1261000096__18 = lang.IFn_Cast(jrt.NN(tmp397).GetRawRoot__O()).Invoke_O__O(seq__1261000095__16)
//line :54:1
						var seq__1261000095__19 any; var tmp398 *lang.Var


















						A_arbace_a2g_jrt_A_Init(); tmp398 = A_arbace_a2g_jrt_A_const_49; seq__1261000095__19 = lang.IFn_Cast(jrt.NN(tmp398).GetRawRoot__O()).Invoke_O__O(seq__1261000095__16)
//line :54:1
						var nm__20 any = first__1261000096__18; var more__21_2 any = seq__1261000095__19; var more__22 any; var tmp399 *lang.Var



















						A_arbace_a2g_jrt_A_Init(); tmp399 = A_arbace_a2g_jrt_A_const_50; more__22 = lang.IFn_Cast(jrt.NN(tmp399).GetRawRoot__O()).Invoke_O__O(more__21_2)
//line :54:1
						var more__23 any; var tmp400 *lang.Keyword




















						A_arbace_a2g_jrt_A_Init(); tmp400 = A_arbace_a2g_jrt_A_const_51; var tmp401 any = tmp400.Ref(); var tmp402 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp402 = A_arbace_a2g_jrt_A_const_15; if lang.Util_Equiv_O_O__Z(tmp401, lang.IFn_Cast(jrt.NN(tmp402).GetRawRoot__O()).Invoke_O__O(more__22)) { var tmp403 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp403 = A_arbace_a2g_jrt_A_const_32; var tmp404 lang.IFn = lang.IFn_Cast(jrt.NN(tmp403).GetRawRoot__O()); var tmp405 any; A_arbace_a2g_jrt_A_Init(); tmp405 = A_arbace_a2g_jrt_A_const_33; more__23 = tmp404.Invoke_O_O__O(tmp405, more__22) } else { more__23 = more__22 }
//line :54:1
						var params__24 any; var tmp406 *lang.Var





















						A_arbace_a2g_jrt_A_Init(); tmp406 = A_arbace_a2g_jrt_A_const_15; params__24 = lang.IFn_Cast(jrt.NN(tmp406).GetRawRoot__O()).Invoke_O__O(more__23)
//line :54:1
						var rt__25 any; var tmp407 *lang.Var






















						A_arbace_a2g_jrt_A_Init(); tmp407 = A_arbace_a2g_jrt_A_const_52; var tmp408 lang.IFn = lang.IFn_Cast(jrt.NN(tmp407).GetRawRoot__O()); var tmp409 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp409 = A_arbace_a2g_jrt_A_const_15; rt__25 = tmp408.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp409).GetRawRoot__O()).Invoke_O__O(params__24))
						if jrt.A2g_Truth(rt__25) { var tmp410 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp411 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp411 = A_arbace_a2g_jrt_A_const_53; var tmp412 lang.IFn = lang.IFn_Cast(jrt.NN(tmp411).GetRawRoot__O()); var tmp413 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp414 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp414 = A_arbace_a2g_jrt_A_const_40; var tmp415 any = lang.Tuple_Create_O_O__IPersistentVector(tmp414.Ref(), rt__25); var tmp416 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp416 = A_arbace_a2g_jrt_A_const_57; var tmp417 lang.IFn = lang.IFn_Cast(jrt.NN(tmp416).GetRawRoot__O()); var tmp418 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp418 = A_arbace_a2g_jrt_A_const_9; var tmp419 any = jrt.NN(tmp418).GetRawRoot__O(); var tmp420 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp420 = lang.PersistentHashSet_EMPTY; var tmp421 any = tmp417.Invoke_O_O__O(tmp419, tmp420.Ref()); var tmp422 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp422 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp410).Reset_O__O(tmp412.Invoke_O_O_O_O__O(tmp413, tmp415, tmp421, lang.IFn_Cast(jrt.NN(tmp422).GetRawRoot__O()).Invoke_O__O(nm__20))) }
//line :54:1
						break L9 }; case 2: if lang.Util_Equiv_O_O__Z(G__1261000093__12_, Lit_151) { var vec__1261000097__13 any = fm__10; var seq__1261000098__14 any; var tmp423 *lang.Var
							A_arbace_a2g_jrt_A_Init(); tmp423 = A_arbace_a2g_jrt_A_const_45; seq__1261000098__14 = lang.IFn_Cast(jrt.NN(tmp423).GetRawRoot__O()).Invoke_O__O(vec__1261000097__13)
//line :54:1
							var first__1261000099__15 any; var tmp424 *lang.Var
							A_arbace_a2g_jrt_A_Init(); tmp424 = A_arbace_a2g_jrt_A_const_15; first__1261000099__15 = lang.IFn_Cast(jrt.NN(tmp424).GetRawRoot__O()).Invoke_O__O(seq__1261000098__14)
//line :54:1
							var seq__1261000098__16 any; var tmp425 *lang.Var
							A_arbace_a2g_jrt_A_Init(); tmp425 = A_arbace_a2g_jrt_A_const_49; seq__1261000098__16 = lang.IFn_Cast(jrt.NN(tmp425).GetRawRoot__O()).Invoke_O__O(seq__1261000098__14)
//line :54:1
							var ___17_2 any = first__1261000099__15; var more__18 any = seq__1261000098__16; var more__19_3 any; var tmp426 *lang.Var; _ = ___17_2

							A_arbace_a2g_jrt_A_Init(); tmp426 = A_arbace_a2g_jrt_A_const_50; more__19_3 = lang.IFn_Cast(jrt.NN(tmp426).GetRawRoot__O()).Invoke_O__O(more__18)
							var tmp427 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp427 = A_arbace_a2g_jrt_A_const_54; var tmp428 lang.IFn = lang.IFn_Cast(jrt.NN(tmp427).GetRawRoot__O()); var tmp429 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp429 = A_arbace_a2g_jrt_A_const_15; if jrt.A2g_Truth(tmp428.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp429).GetRawRoot__O()).Invoke_O__O(more__19_3))) { var seq_1261000100__20 any; var tmp430 *lang.Var
								A_arbace_a2g_jrt_A_Init(); tmp430 = A_arbace_a2g_jrt_A_const_45; seq_1261000100__20 = lang.IFn_Cast(jrt.NN(tmp430).GetRawRoot__O()).Invoke_O__O(more__19_3)
//line :57:1
								var chunk_1261000101__21 any; var count_1261000102__22 int64 = 0; var i_1261000103__23 int64 = 0; L10: for {
									if lang.Numbers_Lt_J_J__Z(i_1261000103__23, count_1261000102__22) { var vec__1261000104__24 any = lang.Indexed_Cast(chunk_1261000101__21).Nth_I__O(lang.RT_IntCast_J__I(i_1261000103__23)); var nm__25_2 any = lang.RT_Nth_O_I_O__O(vec__1261000104__24, lang.RT_IntCast_J__I(0), nil); var tf__26_2 any = lang.RT_Nth_O_I_O__O(vec__1261000104__24, lang.RT_IntCast_J__I(1), nil); var tmp431 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp432 *lang.Var
										A_arbace_a2g_jrt_A_Init(); tmp432 = A_arbace_a2g_jrt_A_const_55; var tmp433 lang.IFn = lang.IFn_Cast(jrt.NN(tmp432).GetRawRoot__O()); var tmp434 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp435 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp435 = A_arbace_a2g_jrt_A_const_39; var tmp436 any = tmp435.Ref(); var tmp437 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp437 = A_arbace_a2g_jrt_A_const_14; var tmp438 any = lang.Tuple_Create_O_O__IPersistentVector(tmp436, lang.IFn_Cast(jrt.NN(tmp437).GetRawRoot__O()).Invoke_O__O(nm__25_2)); var tmp439 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp439 = A_arbace_a2g_jrt_A_const_58; var tmp440 any = tmp439.Ref(); var tmp441 *lang.Keyword; var tmp442 any; var and__1927000168__auto____27_4 any; var tmp443 *lang.Var
										A_arbace_a2g_jrt_A_Init(); tmp443 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____27_4 = lang.IFn_Cast(jrt.NN(tmp443).GetRawRoot__O()).Invoke_O__O(tf__26_2); if jrt.A2g_Truth(and__1927000168__auto____27_4) { var tmp444 any; A_arbace_a2g_jrt_A_Init(); tmp444 = A_arbace_a2g_jrt_A_const_59; var tmp445 any = tmp444; var tmp446 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp446 = A_arbace_a2g_jrt_A_const_15; tmp442 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp445, lang.IFn_Cast(jrt.NN(tmp446).GetRawRoot__O()).Invoke_O__O(tf__26_2))).Ref() } else { tmp442 = and__1927000168__auto____27_4 }; if jrt.A2g_Truth(tmp442) { A_arbace_a2g_jrt_A_Init(); tmp441 = A_arbace_a2g_jrt_A_const_60 } else { var tmp447 any; var and__1927000168__auto____27_5 any; var tmp448 *lang.Var
											A_arbace_a2g_jrt_A_Init(); tmp448 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____27_5 = lang.IFn_Cast(jrt.NN(tmp448).GetRawRoot__O()).Invoke_O__O(tf__26_2); if jrt.A2g_Truth(and__1927000168__auto____27_5) { var tmp449 any; A_arbace_a2g_jrt_A_Init(); tmp449 = A_arbace_a2g_jrt_A_const_61; var tmp450 any = tmp449; var tmp451 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp451 = A_arbace_a2g_jrt_A_const_15; tmp447 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp450, lang.IFn_Cast(jrt.NN(tmp451).GetRawRoot__O()).Invoke_O__O(tf__26_2))).Ref() } else { tmp447 = and__1927000168__auto____27_5 }
//line :60:1
											if jrt.A2g_Truth(tmp447) { A_arbace_a2g_jrt_A_Init(); tmp441 = A_arbace_a2g_jrt_A_const_62 } else { var tmp452 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp452 = A_arbace_a2g_jrt_A_const_21; if tmp452 != nil { A_arbace_a2g_jrt_A_Init(); tmp441 = A_arbace_a2g_jrt_A_const_63 } else { tmp441 = nil } } }
//line :59:1
										var tmp453 any = tmp441.Ref(); var tmp454 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp454 = A_arbace_a2g_jrt_A_const_64; jrt.NN(tmp431).Reset_O__O(tmp433.Invoke_O_O_O__O(tmp434, tmp438, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp440, tmp453, tmp454.Ref(), tf__26_2))))
//line :58:1
										seq_1261000100__20, chunk_1261000101__21, count_1261000102__22, i_1261000103__23 = seq_1261000100__20, chunk_1261000101__21, count_1261000102__22, lang.Numbers_Unchecked_inc_J__J(i_1261000103__23); continue L10 } else { var temp__1927000414__auto____24 any; var tmp455 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp455 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____24 = lang.IFn_Cast(jrt.NN(tmp455).GetRawRoot__O()).Invoke_O__O(seq_1261000100__20); if jrt.A2g_Truth(temp__1927000414__auto____24) { var seq_1261000100__25 any = temp__1927000414__auto____24; var tmp456 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp456 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp456).GetRawRoot__O()).Invoke_O__O(seq_1261000100__25)) { var c__1927000678__auto____26 any; var tmp457 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp457 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____26 = lang.IFn_Cast(jrt.NN(tmp457).GetRawRoot__O()).Invoke_O__O(seq_1261000100__25); var tmp458 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp458 = A_arbace_a2g_jrt_A_const_65; seq_1261000100__20, chunk_1261000101__21, count_1261000102__22, i_1261000103__23 = lang.IFn_Cast(jrt.NN(tmp458).GetRawRoot__O()).Invoke_O__O(seq_1261000100__25), c__1927000678__auto____26, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I(0)); continue L10 } else { var vec__1261000107__26 any; var tmp459 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp459 = A_arbace_a2g_jrt_A_const_15; vec__1261000107__26 = lang.IFn_Cast(jrt.NN(tmp459).GetRawRoot__O()).Invoke_O__O(seq_1261000100__25); var nm__27 any = lang.RT_Nth_O_I_O__O(vec__1261000107__26, lang.RT_IntCast_J__I(0), nil); var tf__28 any = lang.RT_Nth_O_I_O__O(vec__1261000107__26, lang.RT_IntCast_J__I(1), nil); var tmp460 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp461 *lang.Var
											A_arbace_a2g_jrt_A_Init(); tmp461 = A_arbace_a2g_jrt_A_const_55; var tmp462 lang.IFn = lang.IFn_Cast(jrt.NN(tmp461).GetRawRoot__O()); var tmp463 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp464 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp464 = A_arbace_a2g_jrt_A_const_39; var tmp465 any = tmp464.Ref(); var tmp466 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp466 = A_arbace_a2g_jrt_A_const_14; var tmp467 any = lang.Tuple_Create_O_O__IPersistentVector(tmp465, lang.IFn_Cast(jrt.NN(tmp466).GetRawRoot__O()).Invoke_O__O(nm__27)); var tmp468 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp468 = A_arbace_a2g_jrt_A_const_58; var tmp469 any = tmp468.Ref(); var tmp470 *lang.Keyword; var tmp471 any; var and__1927000168__auto____29 any; var tmp472 *lang.Var
											A_arbace_a2g_jrt_A_Init(); tmp472 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____29 = lang.IFn_Cast(jrt.NN(tmp472).GetRawRoot__O()).Invoke_O__O(tf__28); if jrt.A2g_Truth(and__1927000168__auto____29) { var tmp473 any; A_arbace_a2g_jrt_A_Init(); tmp473 = A_arbace_a2g_jrt_A_const_59; var tmp474 any = tmp473; var tmp475 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp475 = A_arbace_a2g_jrt_A_const_15; tmp471 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp474, lang.IFn_Cast(jrt.NN(tmp475).GetRawRoot__O()).Invoke_O__O(tf__28))).Ref() } else { tmp471 = and__1927000168__auto____29 }; if jrt.A2g_Truth(tmp471) { A_arbace_a2g_jrt_A_Init(); tmp470 = A_arbace_a2g_jrt_A_const_60 } else { var tmp476 any; var and__1927000168__auto____29_2 any; var tmp477 *lang.Var
												A_arbace_a2g_jrt_A_Init(); tmp477 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____29_2 = lang.IFn_Cast(jrt.NN(tmp477).GetRawRoot__O()).Invoke_O__O(tf__28); if jrt.A2g_Truth(and__1927000168__auto____29_2) { var tmp478 any; A_arbace_a2g_jrt_A_Init(); tmp478 = A_arbace_a2g_jrt_A_const_61; var tmp479 any = tmp478; var tmp480 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp480 = A_arbace_a2g_jrt_A_const_15; tmp476 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp479, lang.IFn_Cast(jrt.NN(tmp480).GetRawRoot__O()).Invoke_O__O(tf__28))).Ref() } else { tmp476 = and__1927000168__auto____29_2 }
//line :60:1
												if jrt.A2g_Truth(tmp476) { A_arbace_a2g_jrt_A_Init(); tmp470 = A_arbace_a2g_jrt_A_const_62 } else { var tmp481 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp481 = A_arbace_a2g_jrt_A_const_21; if tmp481 != nil { A_arbace_a2g_jrt_A_Init(); tmp470 = A_arbace_a2g_jrt_A_const_63 } else { tmp470 = nil } } }
//line :59:1
											var tmp482 any = tmp470.Ref(); var tmp483 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp483 = A_arbace_a2g_jrt_A_const_64; jrt.NN(tmp460).Reset_O__O(tmp462.Invoke_O_O_O__O(tmp463, tmp467, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp469, tmp482, tmp483.Ref(), tf__28))))
//line :58:1
											var tmp484 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp484 = A_arbace_a2g_jrt_A_const_49; seq_1261000100__20, chunk_1261000101__21, count_1261000102__22, i_1261000103__23 = lang.IFn_Cast(jrt.NN(tmp484).GetRawRoot__O()).Invoke_O__O(seq_1261000100__25), nil, 0, 0; continue L10 } } }
//line :57:1
									break L10 } } else { var nm__20_2 any; var tmp485 *lang.Var






										A_arbace_a2g_jrt_A_Init(); tmp485 = A_arbace_a2g_jrt_A_const_15; nm__20_2 = lang.IFn_Cast(jrt.NN(tmp485).GetRawRoot__O()).Invoke_O__O(more__19_3)
//line :57:1
										var more__21_3 any; var tmp486 *lang.Var







										A_arbace_a2g_jrt_A_Init(); tmp486 = A_arbace_a2g_jrt_A_const_50; var tmp487 lang.IFn = lang.IFn_Cast(jrt.NN(tmp486).GetRawRoot__O()); var tmp488 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp488 = A_arbace_a2g_jrt_A_const_24; more__21_3 = tmp487.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp488).GetRawRoot__O()).Invoke_O__O(more__19_3))
//line :57:1
										var more__22_2 any; var tmp489 *lang.Keyword








										A_arbace_a2g_jrt_A_Init(); tmp489 = A_arbace_a2g_jrt_A_const_51; var tmp490 any = tmp489.Ref(); var tmp491 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp491 = A_arbace_a2g_jrt_A_const_15; if lang.Util_Equiv_O_O__Z(tmp490, lang.IFn_Cast(jrt.NN(tmp491).GetRawRoot__O()).Invoke_O__O(more__21_3)) { var tmp492 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp492 = A_arbace_a2g_jrt_A_const_32; var tmp493 lang.IFn = lang.IFn_Cast(jrt.NN(tmp492).GetRawRoot__O()); var tmp494 any; A_arbace_a2g_jrt_A_Init(); tmp494 = A_arbace_a2g_jrt_A_const_33; more__22_2 = tmp493.Invoke_O_O__O(tmp494, more__21_3) } else { more__22_2 = more__21_3 }
//line :57:1
										var tf__23 any; var tmp495 *lang.Var









										A_arbace_a2g_jrt_A_Init(); tmp495 = A_arbace_a2g_jrt_A_const_15; tf__23 = lang.IFn_Cast(jrt.NN(tmp495).GetRawRoot__O()).Invoke_O__O(more__22_2)
										var tmp496 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp497 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp497 = A_arbace_a2g_jrt_A_const_55; var tmp498 lang.IFn = lang.IFn_Cast(jrt.NN(tmp497).GetRawRoot__O()); var tmp499 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp500 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp500 = A_arbace_a2g_jrt_A_const_39; var tmp501 any = tmp500.Ref(); var tmp502 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp502 = A_arbace_a2g_jrt_A_const_14; var tmp503 any = lang.Tuple_Create_O_O__IPersistentVector(tmp501, lang.IFn_Cast(jrt.NN(tmp502).GetRawRoot__O()).Invoke_O__O(nm__20_2)); var tmp504 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp504 = A_arbace_a2g_jrt_A_const_58; var tmp505 any = tmp504.Ref(); var tmp506 *lang.Keyword; var tmp507 any; var and__1927000168__auto____24 any; var tmp508 *lang.Var
										A_arbace_a2g_jrt_A_Init(); tmp508 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____24 = lang.IFn_Cast(jrt.NN(tmp508).GetRawRoot__O()).Invoke_O__O(tf__23); if jrt.A2g_Truth(and__1927000168__auto____24) { var tmp509 any; A_arbace_a2g_jrt_A_Init(); tmp509 = A_arbace_a2g_jrt_A_const_66; var tmp510 any = tmp509; var tmp511 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp511 = A_arbace_a2g_jrt_A_const_15; tmp507 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp510, lang.IFn_Cast(jrt.NN(tmp511).GetRawRoot__O()).Invoke_O__O(tf__23))).Ref() } else { tmp507 = and__1927000168__auto____24 }; if jrt.A2g_Truth(tmp507) { A_arbace_a2g_jrt_A_Init(); tmp506 = A_arbace_a2g_jrt_A_const_60 } else { var tmp512 any; var and__1927000168__auto____24_2 any; var tmp513 *lang.Var
											A_arbace_a2g_jrt_A_Init(); tmp513 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____24_2 = lang.IFn_Cast(jrt.NN(tmp513).GetRawRoot__O()).Invoke_O__O(tf__23); if jrt.A2g_Truth(and__1927000168__auto____24_2) { var tmp514 any; A_arbace_a2g_jrt_A_Init(); tmp514 = A_arbace_a2g_jrt_A_const_67; var tmp515 any = tmp514; var tmp516 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp516 = A_arbace_a2g_jrt_A_const_15; tmp512 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp515, lang.IFn_Cast(jrt.NN(tmp516).GetRawRoot__O()).Invoke_O__O(tf__23))).Ref() } else { tmp512 = and__1927000168__auto____24_2 }
//line :69:1
											if jrt.A2g_Truth(tmp512) { A_arbace_a2g_jrt_A_Init(); tmp506 = A_arbace_a2g_jrt_A_const_62 } else { var tmp517 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp517 = A_arbace_a2g_jrt_A_const_21; if tmp517 != nil { A_arbace_a2g_jrt_A_Init(); tmp506 = A_arbace_a2g_jrt_A_const_63 } else { tmp506 = nil } } }
//line :68:1
										var tmp518 any = tmp506.Ref(); var tmp519 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp519 = A_arbace_a2g_jrt_A_const_64; jrt.NN(tmp496).Reset_O__O(tmp498.Invoke_O_O_O__O(tmp499, tmp503, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp505, tmp518, tmp519.Ref(), tf__23)))) }
//line :54:1
							break L9 }; case 3: if lang.Util_Equiv_O_O__Z(G__1261000093__12_, Lit_152) { var vec__1261000110__13 any = fm__10; var seq__1261000111__14 any; var tmp520 *lang.Var








































								A_arbace_a2g_jrt_A_Init(); tmp520 = A_arbace_a2g_jrt_A_const_45; seq__1261000111__14 = lang.IFn_Cast(jrt.NN(tmp520).GetRawRoot__O()).Invoke_O__O(vec__1261000110__13)
//line :54:1
								var first__1261000112__15 any; var tmp521 *lang.Var








































								A_arbace_a2g_jrt_A_Init(); tmp521 = A_arbace_a2g_jrt_A_const_15; first__1261000112__15 = lang.IFn_Cast(jrt.NN(tmp521).GetRawRoot__O()).Invoke_O__O(seq__1261000111__14)
//line :54:1
								var seq__1261000111__16 any; var tmp522 *lang.Var








































								A_arbace_a2g_jrt_A_Init(); tmp522 = A_arbace_a2g_jrt_A_const_49; seq__1261000111__16 = lang.IFn_Cast(jrt.NN(tmp522).GetRawRoot__O()).Invoke_O__O(seq__1261000111__14)
//line :54:1
								var ___17_3 any = first__1261000112__15; var more__18_2 any = seq__1261000111__16; var more__19_4 any; var tmp523 *lang.Var; _ = ___17_3









































								A_arbace_a2g_jrt_A_Init(); tmp523 = A_arbace_a2g_jrt_A_const_50; more__19_4 = lang.IFn_Cast(jrt.NN(tmp523).GetRawRoot__O()).Invoke_O__O(more__18_2)
								var tmp524 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp524 = A_arbace_a2g_jrt_A_const_54; var tmp525 lang.IFn = lang.IFn_Cast(jrt.NN(tmp524).GetRawRoot__O()); var tmp526 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp526 = A_arbace_a2g_jrt_A_const_15; if jrt.A2g_Truth(tmp525.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp526).GetRawRoot__O()).Invoke_O__O(more__19_4))) { var seq_1261000113__20 any; var tmp527 *lang.Var
									A_arbace_a2g_jrt_A_Init(); tmp527 = A_arbace_a2g_jrt_A_const_45; seq_1261000113__20 = lang.IFn_Cast(jrt.NN(tmp527).GetRawRoot__O()).Invoke_O__O(more__19_4)
//line :97:1
									var chunk_1261000114__21 any; var count_1261000115__22 int64 = 0; var i_1261000116__23 int64 = 0; L11: for {
										if lang.Numbers_Lt_J_J__Z(i_1261000116__23, count_1261000115__22) { var vec__1261000117__24 any = lang.Indexed_Cast(chunk_1261000114__21).Nth_I__O(lang.RT_IntCast_J__I(i_1261000116__23)); var tg__25_3 any = lang.RT_Nth_O_I_O__O(vec__1261000117__24, lang.RT_IntCast_J__I(0), nil); var tmp528 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp528 = A_arbace_a2g_jrt_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp528).GetRawRoot__O()).Invoke_O__O(tg__25_3)) { var tmp529 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp530 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp530 = A_arbace_a2g_jrt_A_const_56; var tmp531 lang.IFn = lang.IFn_Cast(jrt.NN(tmp530).GetRawRoot__O()); var tmp532 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp533 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp533 = A_arbace_a2g_jrt_A_const_44; var tmp534 any = tmp533.Ref(); var tmp535 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp535 = A_arbace_a2g_jrt_A_const_9; var tmp536 any = jrt.NN(tmp535).GetRawRoot__O(); var tmp537 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp537 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp529).Reset_O__O(tmp531.Invoke_O_O_O_O__O(tmp532, tmp534, tmp536, lang.IFn_Cast(jrt.NN(tmp537).GetRawRoot__O()).Invoke_O__O(tg__25_3))) }; seq_1261000113__20, chunk_1261000114__21, count_1261000115__22, i_1261000116__23 = seq_1261000113__20, chunk_1261000114__21, count_1261000115__22, lang.Numbers_Unchecked_inc_J__J(i_1261000116__23); continue L11 } else { var temp__1927000414__auto____24_2 any; var tmp538 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp538 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____24_2 = lang.IFn_Cast(jrt.NN(tmp538).GetRawRoot__O()).Invoke_O__O(seq_1261000113__20); if jrt.A2g_Truth(temp__1927000414__auto____24_2) { var seq_1261000113__25 any = temp__1927000414__auto____24_2; var tmp539 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp539 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp539).GetRawRoot__O()).Invoke_O__O(seq_1261000113__25)) { var c__1927000678__auto____26_2 any; var tmp540 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp540 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____26_2 = lang.IFn_Cast(jrt.NN(tmp540).GetRawRoot__O()).Invoke_O__O(seq_1261000113__25); var tmp541 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp541 = A_arbace_a2g_jrt_A_const_65; seq_1261000113__20, chunk_1261000114__21, count_1261000115__22, i_1261000116__23 = lang.IFn_Cast(jrt.NN(tmp541).GetRawRoot__O()).Invoke_O__O(seq_1261000113__25), c__1927000678__auto____26_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____26_2))), int64(lang.RT_IntCast_J__I(0)); continue L11 } else { var vec__1261000120__26 any; var tmp542 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp542 = A_arbace_a2g_jrt_A_const_15; vec__1261000120__26 = lang.IFn_Cast(jrt.NN(tmp542).GetRawRoot__O()).Invoke_O__O(seq_1261000113__25); var tg__27 any = lang.RT_Nth_O_I_O__O(vec__1261000120__26, lang.RT_IntCast_J__I(0), nil); var tmp543 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp543 = A_arbace_a2g_jrt_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp543).GetRawRoot__O()).Invoke_O__O(tg__27)) { var tmp544 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp545 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp545 = A_arbace_a2g_jrt_A_const_56; var tmp546 lang.IFn = lang.IFn_Cast(jrt.NN(tmp545).GetRawRoot__O()); var tmp547 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp548 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp548 = A_arbace_a2g_jrt_A_const_44; var tmp549 any = tmp548.Ref(); var tmp550 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp550 = A_arbace_a2g_jrt_A_const_9; var tmp551 any = jrt.NN(tmp550).GetRawRoot__O(); var tmp552 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp552 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp544).Reset_O__O(tmp546.Invoke_O_O_O_O__O(tmp547, tmp549, tmp551, lang.IFn_Cast(jrt.NN(tmp552).GetRawRoot__O()).Invoke_O__O(tg__27))) }; var tmp553 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp553 = A_arbace_a2g_jrt_A_const_49; seq_1261000113__20, chunk_1261000114__21, count_1261000115__22, i_1261000116__23 = lang.IFn_Cast(jrt.NN(tmp553).GetRawRoot__O()).Invoke_O__O(seq_1261000113__25), nil, 0, 0; continue L11 } } }
//line :97:1
										break L11 } } else {

											var tmp554 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp554 = A_arbace_a2g_jrt_A_const_13; var tmp555 lang.IFn = lang.IFn_Cast(jrt.NN(tmp554).GetRawRoot__O()); var tmp556 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp556 = A_arbace_a2g_jrt_A_const_15; if jrt.A2g_Truth(tmp555.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp556).GetRawRoot__O()).Invoke_O__O(more__19_4))) { var tmp557 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp558 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp558 = A_arbace_a2g_jrt_A_const_56; var tmp559 lang.IFn = lang.IFn_Cast(jrt.NN(tmp558).GetRawRoot__O()); var tmp560 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp561 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp561 = A_arbace_a2g_jrt_A_const_44; var tmp562 any = tmp561.Ref(); var tmp563 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp563 = A_arbace_a2g_jrt_A_const_9; var tmp564 any = jrt.NN(tmp563).GetRawRoot__O(); var tmp565 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp565 = A_arbace_a2g_jrt_A_const_14; var tmp566 lang.IFn = lang.IFn_Cast(jrt.NN(tmp565).GetRawRoot__O()); var tmp567 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp567 = A_arbace_a2g_jrt_A_const_15; jrt.NN(tmp557).Reset_O__O(tmp559.Invoke_O_O_O_O__O(tmp560, tmp562, tmp564, tmp566.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp567).GetRawRoot__O()).Invoke_O__O(more__19_4)))) } }
//line :54:1
								break L9 }; case 4: if lang.Util_Equiv_O_O__Z(G__1261000093__12_, Lit_153) { var vec__1261000123__13 any = fm__10; var ___14 any = lang.RT_Nth_O_I_O__O(vec__1261000123__13, lang.RT_IntCast_J__I(0), nil); var nm__15 any = lang.RT_Nth_O_I_O__O(vec__1261000123__13, lang.RT_IntCast_J__I(1), nil); var tmp568 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp569 *lang.Var; _ = ___14
























									A_arbace_a2g_jrt_A_Init(); tmp569 = A_arbace_a2g_jrt_A_const_56; var tmp570 lang.IFn = lang.IFn_Cast(jrt.NN(tmp569).GetRawRoot__O()); var tmp571 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp572 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp572 = A_arbace_a2g_jrt_A_const_41; var tmp573 any = tmp572.Ref(); var tmp574 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp574 = A_arbace_a2g_jrt_A_const_9; var tmp575 any = jrt.NN(tmp574).GetRawRoot__O(); var tmp576 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp576 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp568).Reset_O__O(tmp570.Invoke_O_O_O_O__O(tmp571, tmp573, tmp575, lang.IFn_Cast(jrt.NN(tmp576).GetRawRoot__O()).Invoke_O__O(nm__15)))
//line :54:1
									break L9 }; case 7: if lang.Util_Equiv_O_O__Z(G__1261000093__12_, Lit_99) { var vec__1261000126__13 any = fm__10; var seq__1261000127__14 any; var tmp577 *lang.Var

























										A_arbace_a2g_jrt_A_Init(); tmp577 = A_arbace_a2g_jrt_A_const_45; seq__1261000127__14 = lang.IFn_Cast(jrt.NN(tmp577).GetRawRoot__O()).Invoke_O__O(vec__1261000126__13)
//line :54:1
										var first__1261000128__15 any; var tmp578 *lang.Var

























										A_arbace_a2g_jrt_A_Init(); tmp578 = A_arbace_a2g_jrt_A_const_15; first__1261000128__15 = lang.IFn_Cast(jrt.NN(tmp578).GetRawRoot__O()).Invoke_O__O(seq__1261000127__14)
//line :54:1
										var seq__1261000127__16 any; var tmp579 *lang.Var

























										A_arbace_a2g_jrt_A_Init(); tmp579 = A_arbace_a2g_jrt_A_const_49; seq__1261000127__16 = lang.IFn_Cast(jrt.NN(tmp579).GetRawRoot__O()).Invoke_O__O(seq__1261000127__14)
//line :54:1
										var ___17_4 any = first__1261000128__15; var more__18_3 any = seq__1261000127__16; var more__19_5 any; var tmp580 *lang.Var; _ = ___17_4


























										A_arbace_a2g_jrt_A_Init(); tmp580 = A_arbace_a2g_jrt_A_const_50; more__19_5 = lang.IFn_Cast(jrt.NN(tmp580).GetRawRoot__O()).Invoke_O__O(more__18_3)
										var tmp581 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp581 = A_arbace_a2g_jrt_A_const_54; var tmp582 lang.IFn = lang.IFn_Cast(jrt.NN(tmp581).GetRawRoot__O()); var tmp583 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp583 = A_arbace_a2g_jrt_A_const_15; if jrt.A2g_Truth(tmp582.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp583).GetRawRoot__O()).Invoke_O__O(more__19_5))) { var seq_1261000129__20 any; var tmp584 *lang.Var
											A_arbace_a2g_jrt_A_Init(); tmp584 = A_arbace_a2g_jrt_A_const_45; seq_1261000129__20 = lang.IFn_Cast(jrt.NN(tmp584).GetRawRoot__O()).Invoke_O__O(more__19_5)
//line :82:1
											var chunk_1261000130__21 any; var count_1261000131__22 int64 = 0; var i_1261000132__23 int64 = 0; L12: for {
												if lang.Numbers_Lt_J_J__Z(i_1261000132__23, count_1261000131__22) { var vec__1261000133__24 any = lang.Indexed_Cast(chunk_1261000130__21).Nth_I__O(lang.RT_IntCast_J__I(i_1261000132__23)); var tg__25_4 any = lang.RT_Nth_O_I_O__O(vec__1261000133__24, lang.RT_IntCast_J__I(0), nil); var init__26_2 any = lang.RT_Nth_O_I_O__O(vec__1261000133__24, lang.RT_IntCast_J__I(1), nil); var tmp585 any; var and__1927000168__auto____27_6 any; var tmp586 *lang.Var
													A_arbace_a2g_jrt_A_Init(); tmp586 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____27_6 = lang.IFn_Cast(jrt.NN(tmp586).GetRawRoot__O()).Invoke_O__O(tg__25_4); if jrt.A2g_Truth(and__1927000168__auto____27_6) { var tmp587 any; A_arbace_a2g_jrt_A_Init(); tmp587 = A_arbace_a2g_jrt_A_const_71; var tmp588 any = tmp587; var tmp589 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp589 = A_arbace_a2g_jrt_A_const_15; tmp585 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp588, lang.IFn_Cast(jrt.NN(tmp589).GetRawRoot__O()).Invoke_O__O(tg__25_4))).Ref() } else { tmp585 = and__1927000168__auto____27_6 }; if jrt.A2g_Truth(tmp585) { var seq_1261000136__27 any; var tmp590 *lang.Var
														A_arbace_a2g_jrt_A_Init(); tmp590 = A_arbace_a2g_jrt_A_const_45; var tmp591 lang.IFn = lang.IFn_Cast(jrt.NN(tmp590).GetRawRoot__O()); var tmp592 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp592 = A_arbace_a2g_jrt_A_const_24; seq_1261000136__27 = tmp591.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp592).GetRawRoot__O()).Invoke_O__O(tg__25_4))
//line :84:1
														var chunk_1261000137__28 any; var count_1261000138__29 int64 = 0; var i_1261000139__30 int64 = 0; L13: for {
															if lang.Numbers_Lt_J_J__Z(i_1261000139__30, count_1261000138__29) { var s__31_3 any = lang.Indexed_Cast(chunk_1261000137__28).Nth_I__O(lang.RT_IntCast_J__I(i_1261000139__30)); var tmp593 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp594 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp594 = A_arbace_a2g_jrt_A_const_56; var tmp595 lang.IFn = lang.IFn_Cast(jrt.NN(tmp594).GetRawRoot__O()); var tmp596 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp597 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp597 = A_arbace_a2g_jrt_A_const_42; var tmp598 any = tmp597.Ref(); var tmp599 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp599 = A_arbace_a2g_jrt_A_const_9; var tmp600 any = jrt.NN(tmp599).GetRawRoot__O(); var tmp601 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp601 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp593).Reset_O__O(tmp595.Invoke_O_O_O_O__O(tmp596, tmp598, tmp600, lang.IFn_Cast(jrt.NN(tmp601).GetRawRoot__O()).Invoke_O__O(s__31_3))); seq_1261000136__27, chunk_1261000137__28, count_1261000138__29, i_1261000139__30 = seq_1261000136__27, chunk_1261000137__28, count_1261000138__29, lang.Numbers_Unchecked_inc_J__J(i_1261000139__30); continue L13 } else { var temp__1927000414__auto____31_2 any; var tmp602 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp602 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____31_2 = lang.IFn_Cast(jrt.NN(tmp602).GetRawRoot__O()).Invoke_O__O(seq_1261000136__27); if jrt.A2g_Truth(temp__1927000414__auto____31_2) { var seq_1261000136__32 any = temp__1927000414__auto____31_2; var tmp603 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp603 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp603).GetRawRoot__O()).Invoke_O__O(seq_1261000136__32)) { var c__1927000678__auto____33_2 any; var tmp604 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp604 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____33_2 = lang.IFn_Cast(jrt.NN(tmp604).GetRawRoot__O()).Invoke_O__O(seq_1261000136__32); var tmp605 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp605 = A_arbace_a2g_jrt_A_const_65; seq_1261000136__27, chunk_1261000137__28, count_1261000138__29, i_1261000139__30 = lang.IFn_Cast(jrt.NN(tmp605).GetRawRoot__O()).Invoke_O__O(seq_1261000136__32), c__1927000678__auto____33_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____33_2))), int64(lang.RT_IntCast_J__I(0)); continue L13 } else { var s__33_2 any; var tmp606 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp606 = A_arbace_a2g_jrt_A_const_15; s__33_2 = lang.IFn_Cast(jrt.NN(tmp606).GetRawRoot__O()).Invoke_O__O(seq_1261000136__32); var tmp607 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp608 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp608 = A_arbace_a2g_jrt_A_const_56; var tmp609 lang.IFn = lang.IFn_Cast(jrt.NN(tmp608).GetRawRoot__O()); var tmp610 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp611 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp611 = A_arbace_a2g_jrt_A_const_42; var tmp612 any = tmp611.Ref(); var tmp613 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp613 = A_arbace_a2g_jrt_A_const_9; var tmp614 any = jrt.NN(tmp613).GetRawRoot__O(); var tmp615 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp615 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp607).Reset_O__O(tmp609.Invoke_O_O_O_O__O(tmp610, tmp612, tmp614, lang.IFn_Cast(jrt.NN(tmp615).GetRawRoot__O()).Invoke_O__O(s__33_2))); var tmp616 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp616 = A_arbace_a2g_jrt_A_const_49; seq_1261000136__27, chunk_1261000137__28, count_1261000138__29, i_1261000139__30 = lang.IFn_Cast(jrt.NN(tmp616).GetRawRoot__O()).Invoke_O__O(seq_1261000136__32), nil, 0, 0; continue L13 } } }
//line :84:1
															break L13 } } else {

																var tmp617 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp618 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp618 = A_arbace_a2g_jrt_A_const_56; var tmp619 lang.IFn = lang.IFn_Cast(jrt.NN(tmp618).GetRawRoot__O()); var tmp620 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp621 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp621 = A_arbace_a2g_jrt_A_const_42; var tmp622 any = tmp621.Ref(); var tmp623 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp623 = A_arbace_a2g_jrt_A_const_9; var tmp624 any = jrt.NN(tmp623).GetRawRoot__O(); var tmp625 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp625 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp617).Reset_O__O(tmp619.Invoke_O_O_O_O__O(tmp620, tmp622, tmp624, lang.IFn_Cast(jrt.NN(tmp625).GetRawRoot__O()).Invoke_O__O(tg__25_4)))
//line :84:1
																var temp__1927000414__auto____27_2 any; var tmp626 *lang.Var


																A_arbace_a2g_jrt_A_Init(); tmp626 = A_arbace_a2g_jrt_A_const_69; temp__1927000414__auto____27_2 = lang.IFn_Cast(jrt.NN(tmp626).GetRawRoot__O()).Invoke_O__O(init__26_2); if jrt.A2g_Truth(temp__1927000414__auto____27_2) { var map__1261000140__28 any = temp__1927000414__auto____27_2; var map__1261000140__29 any; if lang.ISeq_InstanceOf(map__1261000140__28) { var tmp627 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp627 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp627).GetRawRoot__O()).Invoke_O__O(map__1261000140__28)) { var tmp628 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp628 = A_arbace_a2g_jrt_A_const_70; map__1261000140__29 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp628).GetRawRoot__O()).Invoke_O__O(map__1261000140__28), jrt.Object_class.ArrayClass())).Ref() } else { var tmp629 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp629 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp629).GetRawRoot__O()).Invoke_O__O(map__1261000140__28)) { var tmp630 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp630 = A_arbace_a2g_jrt_A_const_15; map__1261000140__29 = lang.IFn_Cast(jrt.NN(tmp630).GetRawRoot__O()).Invoke_O__O(map__1261000140__28) } else { lang.PersistentArrayMap_Init(); map__1261000140__29 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000140__29 = map__1261000140__28 }; var n__30_2 any; var tmp631 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp631 = A_arbace_a2g_jrt_A_const_35; n__30_2 = lang.RT_Get_O_O__O(map__1261000140__29, tmp631.Ref())
																	var tmp632 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp633 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp633 = A_arbace_a2g_jrt_A_const_55; var tmp634 lang.IFn = lang.IFn_Cast(jrt.NN(tmp633).GetRawRoot__O()); var tmp635 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp636 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp636 = A_arbace_a2g_jrt_A_const_43; var tmp637 any = lang.Tuple_Create_O_O__IPersistentVector(tmp636.Ref(), n__30_2); var tmp638 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp638 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp632).Reset_O__O(tmp634.Invoke_O_O_O__O(tmp635, tmp637, lang.IFn_Cast(jrt.NN(tmp638).GetRawRoot__O()).Invoke_O__O(tg__25_4))) } }
//line :83:1
													seq_1261000129__20, chunk_1261000130__21, count_1261000131__22, i_1261000132__23 = seq_1261000129__20, chunk_1261000130__21, count_1261000131__22, lang.Numbers_Unchecked_inc_J__J(i_1261000132__23); continue L12 } else { var temp__1927000414__auto____24_3 any; var tmp639 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp639 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____24_3 = lang.IFn_Cast(jrt.NN(tmp639).GetRawRoot__O()).Invoke_O__O(seq_1261000129__20); if jrt.A2g_Truth(temp__1927000414__auto____24_3) { var seq_1261000129__25 any = temp__1927000414__auto____24_3; var tmp640 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp640 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp640).GetRawRoot__O()).Invoke_O__O(seq_1261000129__25)) { var c__1927000678__auto____26_3 any; var tmp641 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp641 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____26_3 = lang.IFn_Cast(jrt.NN(tmp641).GetRawRoot__O()).Invoke_O__O(seq_1261000129__25); var tmp642 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp642 = A_arbace_a2g_jrt_A_const_65; seq_1261000129__20, chunk_1261000130__21, count_1261000131__22, i_1261000132__23 = lang.IFn_Cast(jrt.NN(tmp642).GetRawRoot__O()).Invoke_O__O(seq_1261000129__25), c__1927000678__auto____26_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____26_3))), int64(lang.RT_IntCast_J__I(0)); continue L12 } else { var vec__1261000142__26 any; var tmp643 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp643 = A_arbace_a2g_jrt_A_const_15; vec__1261000142__26 = lang.IFn_Cast(jrt.NN(tmp643).GetRawRoot__O()).Invoke_O__O(seq_1261000129__25); var tg__27_2 any = lang.RT_Nth_O_I_O__O(vec__1261000142__26, lang.RT_IntCast_J__I(0), nil); var init__28 any = lang.RT_Nth_O_I_O__O(vec__1261000142__26, lang.RT_IntCast_J__I(1), nil); var tmp644 any; var and__1927000168__auto____29_3 any; var tmp645 *lang.Var
														A_arbace_a2g_jrt_A_Init(); tmp645 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____29_3 = lang.IFn_Cast(jrt.NN(tmp645).GetRawRoot__O()).Invoke_O__O(tg__27_2); if jrt.A2g_Truth(and__1927000168__auto____29_3) { var tmp646 any; A_arbace_a2g_jrt_A_Init(); tmp646 = A_arbace_a2g_jrt_A_const_71; var tmp647 any = tmp646; var tmp648 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp648 = A_arbace_a2g_jrt_A_const_15; tmp644 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp647, lang.IFn_Cast(jrt.NN(tmp648).GetRawRoot__O()).Invoke_O__O(tg__27_2))).Ref() } else { tmp644 = and__1927000168__auto____29_3 }; if jrt.A2g_Truth(tmp644) { var seq_1261000145__29 any; var tmp649 *lang.Var
															A_arbace_a2g_jrt_A_Init(); tmp649 = A_arbace_a2g_jrt_A_const_45; var tmp650 lang.IFn = lang.IFn_Cast(jrt.NN(tmp649).GetRawRoot__O()); var tmp651 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp651 = A_arbace_a2g_jrt_A_const_24; seq_1261000145__29 = tmp650.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp651).GetRawRoot__O()).Invoke_O__O(tg__27_2))
//line :84:1
															var chunk_1261000146__30 any; var count_1261000147__31 int64 = 0; var i_1261000148__32 int64 = 0; L14: for {
																if lang.Numbers_Lt_J_J__Z(i_1261000148__32, count_1261000147__31) { var s__33_3 any = lang.Indexed_Cast(chunk_1261000146__30).Nth_I__O(lang.RT_IntCast_J__I(i_1261000148__32)); var tmp652 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp653 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp653 = A_arbace_a2g_jrt_A_const_56; var tmp654 lang.IFn = lang.IFn_Cast(jrt.NN(tmp653).GetRawRoot__O()); var tmp655 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp656 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp656 = A_arbace_a2g_jrt_A_const_42; var tmp657 any = tmp656.Ref(); var tmp658 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp658 = A_arbace_a2g_jrt_A_const_9; var tmp659 any = jrt.NN(tmp658).GetRawRoot__O(); var tmp660 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp660 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp652).Reset_O__O(tmp654.Invoke_O_O_O_O__O(tmp655, tmp657, tmp659, lang.IFn_Cast(jrt.NN(tmp660).GetRawRoot__O()).Invoke_O__O(s__33_3))); seq_1261000145__29, chunk_1261000146__30, count_1261000147__31, i_1261000148__32 = seq_1261000145__29, chunk_1261000146__30, count_1261000147__31, lang.Numbers_Unchecked_inc_J__J(i_1261000148__32); continue L14 } else { var temp__1927000414__auto____33 any; var tmp661 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp661 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____33 = lang.IFn_Cast(jrt.NN(tmp661).GetRawRoot__O()).Invoke_O__O(seq_1261000145__29); if jrt.A2g_Truth(temp__1927000414__auto____33) { var seq_1261000145__34 any = temp__1927000414__auto____33; var tmp662 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp662 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp662).GetRawRoot__O()).Invoke_O__O(seq_1261000145__34)) { var c__1927000678__auto____35 any; var tmp663 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp663 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____35 = lang.IFn_Cast(jrt.NN(tmp663).GetRawRoot__O()).Invoke_O__O(seq_1261000145__34); var tmp664 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp664 = A_arbace_a2g_jrt_A_const_65; seq_1261000145__29, chunk_1261000146__30, count_1261000147__31, i_1261000148__32 = lang.IFn_Cast(jrt.NN(tmp664).GetRawRoot__O()).Invoke_O__O(seq_1261000145__34), c__1927000678__auto____35, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____35))), int64(lang.RT_IntCast_J__I(0)); continue L14 } else { var s__35 any; var tmp665 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp665 = A_arbace_a2g_jrt_A_const_15; s__35 = lang.IFn_Cast(jrt.NN(tmp665).GetRawRoot__O()).Invoke_O__O(seq_1261000145__34); var tmp666 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp667 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp667 = A_arbace_a2g_jrt_A_const_56; var tmp668 lang.IFn = lang.IFn_Cast(jrt.NN(tmp667).GetRawRoot__O()); var tmp669 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp670 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp670 = A_arbace_a2g_jrt_A_const_42; var tmp671 any = tmp670.Ref(); var tmp672 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp672 = A_arbace_a2g_jrt_A_const_9; var tmp673 any = jrt.NN(tmp672).GetRawRoot__O(); var tmp674 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp674 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp666).Reset_O__O(tmp668.Invoke_O_O_O_O__O(tmp669, tmp671, tmp673, lang.IFn_Cast(jrt.NN(tmp674).GetRawRoot__O()).Invoke_O__O(s__35))); var tmp675 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp675 = A_arbace_a2g_jrt_A_const_49; seq_1261000145__29, chunk_1261000146__30, count_1261000147__31, i_1261000148__32 = lang.IFn_Cast(jrt.NN(tmp675).GetRawRoot__O()).Invoke_O__O(seq_1261000145__34), nil, 0, 0; continue L14 } } }
//line :84:1
																break L14 } } else {

																	var tmp676 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp677 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp677 = A_arbace_a2g_jrt_A_const_56; var tmp678 lang.IFn = lang.IFn_Cast(jrt.NN(tmp677).GetRawRoot__O()); var tmp679 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp680 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp680 = A_arbace_a2g_jrt_A_const_42; var tmp681 any = tmp680.Ref(); var tmp682 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp682 = A_arbace_a2g_jrt_A_const_9; var tmp683 any = jrt.NN(tmp682).GetRawRoot__O(); var tmp684 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp684 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp676).Reset_O__O(tmp678.Invoke_O_O_O_O__O(tmp679, tmp681, tmp683, lang.IFn_Cast(jrt.NN(tmp684).GetRawRoot__O()).Invoke_O__O(tg__27_2)))
//line :84:1
																	var temp__1927000414__auto____29_2 any; var tmp685 *lang.Var


																	A_arbace_a2g_jrt_A_Init(); tmp685 = A_arbace_a2g_jrt_A_const_69; temp__1927000414__auto____29_2 = lang.IFn_Cast(jrt.NN(tmp685).GetRawRoot__O()).Invoke_O__O(init__28); if jrt.A2g_Truth(temp__1927000414__auto____29_2) { var map__1261000149__30 any = temp__1927000414__auto____29_2; var map__1261000149__31 any; if lang.ISeq_InstanceOf(map__1261000149__30) { var tmp686 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp686 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp686).GetRawRoot__O()).Invoke_O__O(map__1261000149__30)) { var tmp687 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp687 = A_arbace_a2g_jrt_A_const_70; map__1261000149__31 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp687).GetRawRoot__O()).Invoke_O__O(map__1261000149__30), jrt.Object_class.ArrayClass())).Ref() } else { var tmp688 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp688 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp688).GetRawRoot__O()).Invoke_O__O(map__1261000149__30)) { var tmp689 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp689 = A_arbace_a2g_jrt_A_const_15; map__1261000149__31 = lang.IFn_Cast(jrt.NN(tmp689).GetRawRoot__O()).Invoke_O__O(map__1261000149__30) } else { lang.PersistentArrayMap_Init(); map__1261000149__31 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000149__31 = map__1261000149__30 }; var n__32 any; var tmp690 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp690 = A_arbace_a2g_jrt_A_const_35; n__32 = lang.RT_Get_O_O__O(map__1261000149__31, tmp690.Ref())
																		var tmp691 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp692 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp692 = A_arbace_a2g_jrt_A_const_55; var tmp693 lang.IFn = lang.IFn_Cast(jrt.NN(tmp692).GetRawRoot__O()); var tmp694 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp695 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp695 = A_arbace_a2g_jrt_A_const_43; var tmp696 any = lang.Tuple_Create_O_O__IPersistentVector(tmp695.Ref(), n__32); var tmp697 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp697 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp691).Reset_O__O(tmp693.Invoke_O_O_O__O(tmp694, tmp696, lang.IFn_Cast(jrt.NN(tmp697).GetRawRoot__O()).Invoke_O__O(tg__27_2))) } }
//line :83:1
														var tmp698 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp698 = A_arbace_a2g_jrt_A_const_49; seq_1261000129__20, chunk_1261000130__21, count_1261000131__22, i_1261000132__23 = lang.IFn_Cast(jrt.NN(tmp698).GetRawRoot__O()).Invoke_O__O(seq_1261000129__25), nil, 0, 0; continue L12 } } }
//line :82:1
												break L12 } } else { var vec__1261000151__20 any = more__19_5; var tg__21 any = lang.RT_Nth_O_I_O__O(vec__1261000151__20, lang.RT_IntCast_J__I(0), nil); var init__22 any = lang.RT_Nth_O_I_O__O(vec__1261000151__20, lang.RT_IntCast_J__I(1), nil); var tmp699 any; var and__1927000168__auto____23 any; var tmp700 *lang.Var







													A_arbace_a2g_jrt_A_Init(); tmp700 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____23 = lang.IFn_Cast(jrt.NN(tmp700).GetRawRoot__O()).Invoke_O__O(tg__21); if jrt.A2g_Truth(and__1927000168__auto____23) { var tmp701 any; A_arbace_a2g_jrt_A_Init(); tmp701 = A_arbace_a2g_jrt_A_const_68; var tmp702 any = tmp701; var tmp703 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp703 = A_arbace_a2g_jrt_A_const_15; tmp699 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp702, lang.IFn_Cast(jrt.NN(tmp703).GetRawRoot__O()).Invoke_O__O(tg__21))).Ref() } else { tmp699 = and__1927000168__auto____23 }; if jrt.A2g_Truth(tmp699) { var seq_1261000154__23 any; var tmp704 *lang.Var
														A_arbace_a2g_jrt_A_Init(); tmp704 = A_arbace_a2g_jrt_A_const_45; var tmp705 lang.IFn = lang.IFn_Cast(jrt.NN(tmp704).GetRawRoot__O()); var tmp706 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp706 = A_arbace_a2g_jrt_A_const_24; seq_1261000154__23 = tmp705.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp706).GetRawRoot__O()).Invoke_O__O(tg__21))
//line :90:1
														var chunk_1261000155__24 any; var count_1261000156__25 int64 = 0; var i_1261000157__26 int64 = 0; L15: for {
															if lang.Numbers_Lt_J_J__Z(i_1261000157__26, count_1261000156__25) { var s__27_2 any = lang.Indexed_Cast(chunk_1261000155__24).Nth_I__O(lang.RT_IntCast_J__I(i_1261000157__26)); var tmp707 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp708 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp708 = A_arbace_a2g_jrt_A_const_56; var tmp709 lang.IFn = lang.IFn_Cast(jrt.NN(tmp708).GetRawRoot__O()); var tmp710 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp711 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp711 = A_arbace_a2g_jrt_A_const_42; var tmp712 any = tmp711.Ref(); var tmp713 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp713 = A_arbace_a2g_jrt_A_const_9; var tmp714 any = jrt.NN(tmp713).GetRawRoot__O(); var tmp715 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp715 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp707).Reset_O__O(tmp709.Invoke_O_O_O_O__O(tmp710, tmp712, tmp714, lang.IFn_Cast(jrt.NN(tmp715).GetRawRoot__O()).Invoke_O__O(s__27_2))); seq_1261000154__23, chunk_1261000155__24, count_1261000156__25, i_1261000157__26 = seq_1261000154__23, chunk_1261000155__24, count_1261000156__25, lang.Numbers_Unchecked_inc_J__J(i_1261000157__26); continue L15 } else { var temp__1927000414__auto____27_3 any; var tmp716 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp716 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____27_3 = lang.IFn_Cast(jrt.NN(tmp716).GetRawRoot__O()).Invoke_O__O(seq_1261000154__23); if jrt.A2g_Truth(temp__1927000414__auto____27_3) { var seq_1261000154__28 any = temp__1927000414__auto____27_3; var tmp717 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp717 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp717).GetRawRoot__O()).Invoke_O__O(seq_1261000154__28)) { var c__1927000678__auto____29 any; var tmp718 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp718 = A_arbace_a2g_jrt_A_const_48; c__1927000678__auto____29 = lang.IFn_Cast(jrt.NN(tmp718).GetRawRoot__O()).Invoke_O__O(seq_1261000154__28); var tmp719 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp719 = A_arbace_a2g_jrt_A_const_65; seq_1261000154__23, chunk_1261000155__24, count_1261000156__25, i_1261000157__26 = lang.IFn_Cast(jrt.NN(tmp719).GetRawRoot__O()).Invoke_O__O(seq_1261000154__28), c__1927000678__auto____29, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____29))), int64(lang.RT_IntCast_J__I(0)); continue L15 } else { var s__29_2 any; var tmp720 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp720 = A_arbace_a2g_jrt_A_const_15; s__29_2 = lang.IFn_Cast(jrt.NN(tmp720).GetRawRoot__O()).Invoke_O__O(seq_1261000154__28); var tmp721 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp722 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp722 = A_arbace_a2g_jrt_A_const_56; var tmp723 lang.IFn = lang.IFn_Cast(jrt.NN(tmp722).GetRawRoot__O()); var tmp724 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp725 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp725 = A_arbace_a2g_jrt_A_const_42; var tmp726 any = tmp725.Ref(); var tmp727 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp727 = A_arbace_a2g_jrt_A_const_9; var tmp728 any = jrt.NN(tmp727).GetRawRoot__O(); var tmp729 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp729 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp721).Reset_O__O(tmp723.Invoke_O_O_O_O__O(tmp724, tmp726, tmp728, lang.IFn_Cast(jrt.NN(tmp729).GetRawRoot__O()).Invoke_O__O(s__29_2))); var tmp730 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp730 = A_arbace_a2g_jrt_A_const_49; seq_1261000154__23, chunk_1261000155__24, count_1261000156__25, i_1261000157__26 = lang.IFn_Cast(jrt.NN(tmp730).GetRawRoot__O()).Invoke_O__O(seq_1261000154__28), nil, 0, 0; continue L15 } } }
//line :90:1
															break L15 } } else {

																var tmp731 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp732 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp732 = A_arbace_a2g_jrt_A_const_56; var tmp733 lang.IFn = lang.IFn_Cast(jrt.NN(tmp732).GetRawRoot__O()); var tmp734 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp735 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp735 = A_arbace_a2g_jrt_A_const_42; var tmp736 any = tmp735.Ref(); var tmp737 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp737 = A_arbace_a2g_jrt_A_const_9; var tmp738 any = jrt.NN(tmp737).GetRawRoot__O(); var tmp739 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp739 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp731).Reset_O__O(tmp733.Invoke_O_O_O_O__O(tmp734, tmp736, tmp738, lang.IFn_Cast(jrt.NN(tmp739).GetRawRoot__O()).Invoke_O__O(tg__21)))
//line :90:1
																var temp__1927000414__auto____23 any; var tmp740 *lang.Var


																A_arbace_a2g_jrt_A_Init(); tmp740 = A_arbace_a2g_jrt_A_const_69; temp__1927000414__auto____23 = lang.IFn_Cast(jrt.NN(tmp740).GetRawRoot__O()).Invoke_O__O(init__22); if jrt.A2g_Truth(temp__1927000414__auto____23) { var map__1261000158__24 any = temp__1927000414__auto____23; var map__1261000158__25 any; if lang.ISeq_InstanceOf(map__1261000158__24) { var tmp741 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp741 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp741).GetRawRoot__O()).Invoke_O__O(map__1261000158__24)) { var tmp742 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp742 = A_arbace_a2g_jrt_A_const_70; map__1261000158__25 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp742).GetRawRoot__O()).Invoke_O__O(map__1261000158__24), jrt.Object_class.ArrayClass())).Ref() } else { var tmp743 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp743 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp743).GetRawRoot__O()).Invoke_O__O(map__1261000158__24)) { var tmp744 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp744 = A_arbace_a2g_jrt_A_const_15; map__1261000158__25 = lang.IFn_Cast(jrt.NN(tmp744).GetRawRoot__O()).Invoke_O__O(map__1261000158__24) } else { lang.PersistentArrayMap_Init(); map__1261000158__25 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000158__25 = map__1261000158__24 }; var n__26 any; var tmp745 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp745 = A_arbace_a2g_jrt_A_const_35; n__26 = lang.RT_Get_O_O__O(map__1261000158__25, tmp745.Ref())
																	var tmp746 *lang.Volatile = lang.Volatile_Cast(acc__3); var tmp747 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp747 = A_arbace_a2g_jrt_A_const_55; var tmp748 lang.IFn = lang.IFn_Cast(jrt.NN(tmp747).GetRawRoot__O()); var tmp749 any = jrt.NN(lang.Volatile_Cast(acc__3)).Deref__O(); var tmp750 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp750 = A_arbace_a2g_jrt_A_const_43; var tmp751 any = lang.Tuple_Create_O_O__IPersistentVector(tmp750.Ref(), n__26); var tmp752 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp752 = A_arbace_a2g_jrt_A_const_14; jrt.NN(tmp746).Reset_O__O(tmp748.Invoke_O_O_O__O(tmp749, tmp751, lang.IFn_Cast(jrt.NN(tmp752).GetRawRoot__O()).Invoke_O__O(tg__21))) } } }
//line :54:1
										break L9 }; default:}}
//line :51:1
						var tmp753 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp753 = A_arbace_a2g_jrt_A_const_49; seq_1261000022__4, chunk_1261000023__5, count_1261000024__6, i_1261000025__7 = lang.IFn_Cast(jrt.NN(tmp753).GetRawRoot__O()).Invoke_O__O(seq_1261000022__9), nil, 0, 0; continue L1 } else { var tmp754 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp754 = A_arbace_a2g_jrt_A_const_49; seq_1261000022__4, chunk_1261000023__5, count_1261000024__6, i_1261000025__7 = lang.IFn_Cast(jrt.NN(tmp754).GetRawRoot__O()).Invoke_O__O(seq_1261000022__9), nil, 0, 0; continue L1 } } } }
//line :45:1
		break L1 }; var tmp755 /*line :49:1*/*lang.Var; A_arbace_a2g_jrt_A_Init(); tmp755 = A_arbace_a2g_jrt_A_const_8; return lang.IFn_Cast(jrt.NN(tmp755).GetRawRoot__O()).Invoke_O__O(acc__3) }





















































func A_arbace_a2g_jrt_interface_elems_A_New() *A_arbace_a2g_jrt_interface_elems_A { A_arbace_a2g_jrt_interface_elems_A_Init(); t := &A_arbace_a2g_jrt_interface_elems_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_a2g_jrt_interface_elems_A) Ctor() {}
//line :103:1
func (t *A_arbace_a2g_jrt_interface_elems_A) Invoke_O_O__O(self, tf__0 any) any { var elems__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_24; elems__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(tf__0); var tmp2 /*line :103:1*/*lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_40; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_72; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var iter__1927001039__auto____3 any; var tmp7 any = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_New(); var tmp8 *jrt.Class;



	A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_Init(); tmp8 = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(elems__2); var tmp9 any = /*line :103:1*/tmp5.Invoke_O__O(tmp6); var tmp10 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp10 = A_arbace_a2g_jrt_A_const_73; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_74; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any; var iter__1927001039__auto____3_2 any; var tmp15 any = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_New(); var tmp16 *jrt.Class;





	A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_Init(); tmp16 = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_fn_class; iter__1927001039__auto____3_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); tmp14 = lang.IFn_Cast(iter__1927001039__auto____3_2).Invoke_O__O(elems__2); return /*line :103:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp9, tmp11, tmp13.Invoke_O__O(tmp14))) }



func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_New() *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A { A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_Init(); t := &A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A) Ctor() {}
//line :107:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A) Invoke_O_O__O(self, s__1261000162__1 any) any { var tmp1 any = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_New_O_O(s__1261000162__1, self); var tmp2 *jrt.Class; A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_Init(); tmp2 = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :107:1
func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_New_O_O(p0, p1 any) *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A { A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_Init(); t := &A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A{}; t.Ctor_O_O(p0, p1); return t }
//line :107:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A) Ctor_O_O(c__s__1261000162, c__iter__1261000161 any) { t.F_s__1261000162 = c__s__1261000162; t.F_iter__1261000161 = c__iter__1261000161 }
//line :107:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A) Invoke_O__O(self any) any { { var s__1261000162__1 any; var t_ any = t.F_s__1261000162; t.F_s__1261000162 = nil; s__1261000162__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1261000162__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1261000162__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1261000162__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_48; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1261000162__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1261000164__6 any; var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_75; b__1261000164__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_New_O_I_O(b__1261000164__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_Init(); tmp6 = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_78; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_80; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1261000164__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1261000161); var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_65; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1261000162__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_78; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp15 = A_arbace_a2g_jrt_A_const_80; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1261000164__6), nil) } } else { var e__4 any; var tmp16 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp16 = A_arbace_a2g_jrt_A_const_15; e__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1261000162__3); var tmp17 any; var and__1927000168__auto____5 any; var tmp18 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp18 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(e__4); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp19 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp19 = A_arbace_a2g_jrt_A_const_13; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp21 = A_arbace_a2g_jrt_A_const_15; and__1927000168__auto____6 = tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(e__4)); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp22 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp22 = A_arbace_a2g_jrt_A_const_54; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp24 = A_arbace_a2g_jrt_A_const_22; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp26 = A_arbace_a2g_jrt_A_const_76; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp28 = A_arbace_a2g_jrt_A_const_23; tmp17 = tmp23.Invoke_O__O(tmp25.Invoke_O__O(tmp27.Invoke_O_O__O(jrt.NN(tmp28).GetRawRoot__O(), e__4))) } else { tmp17 = and__1927000168__auto____6 } } else { tmp17 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp17) { var tmp29 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp29 = A_arbace_a2g_jrt_A_const_79; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp31 = A_arbace_a2g_jrt_A_const_14; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp33 = A_arbace_a2g_jrt_A_const_15; var tmp34 any = tmp32.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(e__4)); var tmp35 lang.IFn = lang.IFn_Cast(t.F_iter__1261000161); var tmp36 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp36 = A_arbace_a2g_jrt_A_const_24; return tmp30.Invoke_O_O__O(tmp34, tmp35.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(s__1261000162__3))) } else { var tmp37 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp37 = A_arbace_a2g_jrt_A_const_24; s__1261000162__1 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(s__1261000162__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :107:1
func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A { A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_Init(); t := &A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :107:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A) Ctor_O_I_O(c__b__1261000164 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1261000164 = c__b__1261000164; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :107:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A) Invoke_O__O(self any) any { { var i__1261000163__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1261000163__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1261000163__1)); var tmp2 any; var and__1927000168__auto____3 any; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_12; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(e__2); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_13; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_15; and__1927000168__auto____4 = tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(e__2)); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_54; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_22; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp11 = A_arbace_a2g_jrt_A_const_76; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_23; tmp2 = tmp8.Invoke_O__O(tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(jrt.NN(tmp13).GetRawRoot__O(), e__2))) } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp2) { var tmp14 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp14 = A_arbace_a2g_jrt_A_const_77; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any = t.F_b__1261000164; var tmp17 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp17 = A_arbace_a2g_jrt_A_const_14; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp19 = A_arbace_a2g_jrt_A_const_15; tmp15.Invoke_O_O__O(tmp16, tmp18.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(e__2))); i__1261000163__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000163__1); continue L1 } else { i__1261000163__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000163__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_New() *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A { A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_Init(); t := &A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A) Ctor() {}
//line :109:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A) Invoke_O_O__O(self, s__1261000172__1 any) any { var tmp1 any = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_New_O_O(s__1261000172__1, self); var tmp2 *jrt.Class; A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_Init(); tmp2 = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :109:1
func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_New_O_O(p0, p1 any) *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A { A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_Init(); t := &A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :109:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A) Ctor_O_O(c__s__1261000172, c__iter__1261000171 any) { t.F_s__1261000172 = c__s__1261000172; t.F_iter__1261000171 = c__iter__1261000171 }
//line :109:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A) Invoke_O__O(self any) any { { var s__1261000172__1 any; var t_ any = t.F_s__1261000172; t.F_s__1261000172 = nil; s__1261000172__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1261000172__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1261000172__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1261000172__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_48; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1261000172__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1261000174__6 any; var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_75; b__1261000174__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_New_O_I_O(b__1261000174__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_Init(); tmp6 = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_78; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_80; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1261000174__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1261000171); var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_65; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1261000172__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_78; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp15 = A_arbace_a2g_jrt_A_const_80; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1261000174__6), nil) } } else { var e__4 any; var tmp16 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp16 = A_arbace_a2g_jrt_A_const_15; e__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1261000172__3); var tmp17 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp17 = A_arbace_a2g_jrt_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(e__4)) { var tmp18 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp18 = A_arbace_a2g_jrt_A_const_79; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp20 = A_arbace_a2g_jrt_A_const_14; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(e__4); var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__1261000171); var tmp23 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp23 = A_arbace_a2g_jrt_A_const_24; return tmp19.Invoke_O_O__O(tmp21, tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__1261000172__3))) } else { var tmp24 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp24 = A_arbace_a2g_jrt_A_const_24; s__1261000172__1 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(s__1261000172__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :109:1
func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A { A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_Init(); t := &A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :109:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A) Ctor_O_I_O(c__b__1261000174 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1261000174 = c__b__1261000174; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :109:1
func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A) Invoke_O__O(self any) any { { var i__1261000173__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1261000173__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1261000173__1)); var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(e__2)) { var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_77; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_b__1261000174; var tmp6 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_14; tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(e__2)); i__1261000173__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000173__1); continue L1 } else { i__1261000173__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000173__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_jrt_struct_embed_A_New() *A_arbace_a2g_jrt_struct_embed_A { A_arbace_a2g_jrt_struct_embed_A_Init(); t := &A_arbace_a2g_jrt_struct_embed_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_a2g_jrt_struct_embed_A) Ctor() {}
//line :111:1
func (t *A_arbace_a2g_jrt_struct_embed_A) Invoke_O_O__O(self, tf__0 any) any { var f__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_22; f__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(tf__0); var tmp2 any; var and__1927000168__auto____3 any = f__2; if
	jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_13; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(f__2); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_19; tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(f__2), nil)).Ref() } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp2) { var tmp5 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_14; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(f__2) } else { return nil } }

func A_arbace_a2g_jrt_other_system_QMARK__A_New() *A_arbace_a2g_jrt_other_system_QMARK__A { A_arbace_a2g_jrt_other_system_QMARK__A_Init(); t := &A_arbace_a2g_jrt_other_system_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_a2g_jrt_other_system_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_a2g_jrt_other_system_QMARK__A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_81; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_82; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp2.Invoke_O_O__O(tmp3, n__0))).Ref()
}
func A_arbace_a2g_jrt_scan_A_New() *A_arbace_a2g_jrt_scan_A { A_arbace_a2g_jrt_scan_A_Init(); t := &A_arbace_a2g_jrt_scan_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_a2g_jrt_scan_A) Ctor() {}
//line :123:1
func (t *A_arbace_a2g_jrt_scan_A) Invoke_O_O__O(self, dir__0 any) any { var files__2 any; var tmp1 *lang.Var;










	A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_83; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_jrt_scan_fn__1261000186_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_jrt_scan_fn__1261000186_A_Init(); tmp4 = A_arbace_a2g_jrt_scan_fn__1261000186_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_87; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_a2g_jrt_scan_fn__1261000188_A_New(); var tmp9 *jrt.Class; A_arbace_a2g_jrt_scan_fn__1261000188_A_Init(); tmp9 = A_arbace_a2g_jrt_scan_fn__1261000188_A_fn_class; var tmp10 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp11 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp11 = A_arbace_a2g_jrt_A_const_91; files__2 = tmp2.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(tmp10, jrt.NN(jrt.File_Cast(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(dir__0))).ListFiles__File1().Ref())); var scans__3 any; var tmp12 /*line :123:1*/*lang.Var;











	A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_84; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp14 = A_arbace_a2g_jrt_A_const_92; var tmp15 any = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke__O(); var tmp16 any; var iter__1927001039__auto____3 any; var tmp17 any = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_New(); var tmp18 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_Init(); tmp18 = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(files__2); scans__3 = tmp13.Invoke_O_O__O(tmp15, tmp16); var types__4 any; var tmp19 /*line :123:1*/*lang.Var;












	A_arbace_a2g_jrt_A_Init(); tmp19 = A_arbace_a2g_jrt_A_const_28; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp21 = A_arbace_a2g_jrt_A_const_94; var tmp22 any = jrt.NN(tmp21).GetRawRoot__O(); var tmp23 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp23 = A_arbace_a2g_jrt_A_const_95; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp25 = A_arbace_a2g_jrt_A_const_39; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp27 = A_arbace_a2g_jrt_A_const_96; types__4 = tmp20.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O__O(tmp26, lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(scans__3))); var methods__5 any; var tmp28 /*line :123:1*/*lang.Var;













	A_arbace_a2g_jrt_A_Init(); tmp28 = A_arbace_a2g_jrt_A_const_28; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp30 = A_arbace_a2g_jrt_A_const_97; var tmp31 any = jrt.NN(tmp30).GetRawRoot__O(); var tmp32 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp32 = A_arbace_a2g_jrt_A_const_84; var tmp33 any = jrt.NN(tmp32).GetRawRoot__O(); var tmp34 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp34 = A_arbace_a2g_jrt_A_const_95; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp36 = A_arbace_a2g_jrt_A_const_40; var tmp37 any = tmp36.Ref(); var tmp38 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp38 = A_arbace_a2g_jrt_A_const_96; methods__5 = tmp29.Invoke_O_O_O__O(tmp31, tmp33, tmp35.Invoke_O_O__O(tmp37, lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(scans__3))); var tmp39 /*line :123:1*/*lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp39 = A_arbace_a2g_jrt_A_const_85; var tmp40 any = tmp39.Ref(); var tmp41 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp41 = A_arbace_a2g_jrt_A_const_39; var tmp42 any = tmp41.Ref(); var tmp43 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp43 = A_arbace_a2g_jrt_A_const_40; var tmp44 any = tmp43.Ref(); var tmp45 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp45 = A_arbace_a2g_jrt_A_const_41; var tmp46 any = tmp45.Ref(); var tmp47 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp47 = A_arbace_a2g_jrt_A_const_28; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp49 = A_arbace_a2g_jrt_A_const_98; var tmp50 any = jrt.NN(tmp49).GetRawRoot__O(); var tmp51 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp51 = A_arbace_a2g_jrt_A_const_95; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp53 = A_arbace_a2g_jrt_A_const_41; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp55 = A_arbace_a2g_jrt_A_const_96; var tmp56 any = tmp48.Invoke_O_O__O(tmp50, tmp52.Invoke_O_O__O(tmp54, lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(scans__3))); var tmp57 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp57 = A_arbace_a2g_jrt_A_const_42; var tmp58 any = tmp57.Ref(); var tmp59 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp59 = A_arbace_a2g_jrt_A_const_28; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp61 = A_arbace_a2g_jrt_A_const_98; var tmp62 any = jrt.NN(tmp61).GetRawRoot__O(); var tmp63 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp63 = A_arbace_a2g_jrt_A_const_95; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp65 = A_arbace_a2g_jrt_A_const_42; var tmp66 any = tmp65.Ref(); var tmp67 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp67 = A_arbace_a2g_jrt_A_const_96; var tmp68 any = tmp60.Invoke_O_O__O(tmp62, tmp64.Invoke_O_O__O(tmp66, lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(scans__3))); var tmp69 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp69 = A_arbace_a2g_jrt_A_const_44; var tmp70 any = tmp69.Ref(); var tmp71 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp71 = A_arbace_a2g_jrt_A_const_28; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp73 = A_arbace_a2g_jrt_A_const_98; var tmp74 any = jrt.NN(tmp73).GetRawRoot__O(); var tmp75 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp75 = A_arbace_a2g_jrt_A_const_95; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp77 = A_arbace_a2g_jrt_A_const_44; var tmp78 any = tmp77.Ref(); var tmp79 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp79 = A_arbace_a2g_jrt_A_const_96; var tmp80 any = tmp72.Invoke_O_O__O(tmp74, tmp76.Invoke_O_O__O(tmp78, lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O__O(scans__3))); var tmp81 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp81 = A_arbace_a2g_jrt_A_const_43; var tmp82 any = tmp81.Ref(); var tmp83 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp83 = A_arbace_a2g_jrt_A_const_84; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp85 = lang.PersistentArrayMap_EMPTY; var tmp86 any = tmp85.Ref(); var tmp87 any; var iter__1927001039__auto____6 any; var tmp88 any = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_New(); var tmp89 *jrt.Class;




















	A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_Init(); tmp89 = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_fn_class; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp88, tmp89, nil); tmp87 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(scans__3); var tmp90 any = /*line :123:1*/tmp84.Invoke_O_O__O(tmp86, tmp87); var tmp91 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp91 = A_arbace_a2g_jrt_A_const_86; var tmp92 any = tmp91.Ref(); var tmp93 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp93 = A_arbace_a2g_jrt_A_const_84; var tmp94 lang.IFn = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()); var tmp95 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp95 = lang.PersistentArrayMap_EMPTY; var tmp96 any = tmp95.Ref(); var tmp97 any; var iter__1927001039__auto____6_2 any; var tmp98 any = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_New(); var tmp99 *jrt.Class;
























	A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_Init(); tmp99 = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_fn_class; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp98, tmp99, nil); tmp97 = lang.IFn_Cast(iter__1927001039__auto____6_2).Invoke_O__O(types__4); var tmp100 any = /*line :123:1*/tmp94.Invoke_O_O__O(tmp96, tmp97); var tmp101 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp101 = A_arbace_a2g_jrt_A_const_73; var tmp102 any = tmp101.Ref(); var tmp103 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp103 = A_arbace_a2g_jrt_A_const_84; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp105 = lang.PersistentArrayMap_EMPTY; var tmp106 any = tmp105.Ref(); var tmp107 any; var iter__1927001039__auto____6_3 any; var tmp108 any = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_New(); var tmp109 *jrt.Class;


























	A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_Init(); tmp109 = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_fn_class; iter__1927001039__auto____6_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp108, tmp109, nil); tmp107 = lang.IFn_Cast(iter__1927001039__auto____6_3).Invoke_O__O(types__4); return /*line :123:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, scans__3, tmp42, types__4, tmp44, methods__5, tmp46, tmp56, tmp58, tmp68, tmp70, tmp80, tmp82, tmp90, tmp92, tmp100, tmp102, tmp104.Invoke_O_O__O(tmp106, tmp107))) }







func A_arbace_a2g_jrt_scan_fn__1261000188_A_New() *A_arbace_a2g_jrt_scan_fn__1261000188_A { A_arbace_a2g_jrt_scan_fn__1261000188_A_Init(); t := &A_arbace_a2g_jrt_scan_fn__1261000188_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_a2g_jrt_scan_fn__1261000188_A) Ctor() {}
//line :131:1
func (t *A_arbace_a2g_jrt_scan_fn__1261000188_A) Invoke_O_O__O(self, p1__1261000184_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_88; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__1261000184_SHARP___1)).GetName__String().Ref(), Lit_131); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var
													A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_89; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_88; and__1927000168__auto____3 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__1261000184_SHARP___1)).GetName__String().Ref(), Lit_132))
//line :131:1
	if jrt.A2g_Truth(and__1927000168__auto____3) {

		var tmp5 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_89; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_90; return tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1261000184_SHARP___1)).GetName__String().Ref())) } else {
//line :131:1
			return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_a2g_jrt_scan_fn__1261000186_A_New() *A_arbace_a2g_jrt_scan_fn__1261000186_A { A_arbace_a2g_jrt_scan_fn__1261000186_A_Init(); t := &A_arbace_a2g_jrt_scan_fn__1261000186_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_a2g_jrt_scan_fn__1261000186_A) Ctor() {}
//line :134:1
func (t *A_arbace_a2g_jrt_scan_fn__1261000186_A) Invoke_O_O__O(self, p1__1261000185_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1261000185_SHARP___1)).GetName__String().Ref() }
func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_New() *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A { A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A) Ctor() {}
//line :135:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A) Invoke_O_O__O(self, s__1261000191__1 any) any { var tmp1 any = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_New_O_O(s__1261000191__1, self); var tmp2 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_Init(); tmp2 = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :135:1
func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_New_O_O(p0, p1 any) *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A { A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A{}; t.Ctor_O_O(p0, p1); return t }
//line :135:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A) Ctor_O_O(c__s__1261000191, c__iter__1261000190 any) { t.F_s__1261000191 = c__s__1261000191; t.F_iter__1261000190 = c__iter__1261000190 }
//line :135:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A) Invoke_O__O(self any) any { { var s__1261000191__1 any; var t_ any = t.F_s__1261000191; t.F_s__1261000191 = nil; s__1261000191__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1261000191__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1261000191__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1261000191__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_48; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1261000191__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1261000193__6 any; var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_75; b__1261000193__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_New_O_I_O(b__1261000193__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_Init(); tmp6 = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_78; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_80; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1261000193__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1261000190); var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_65; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1261000191__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_78; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp15 = A_arbace_a2g_jrt_A_const_80; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1261000193__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp16 = A_arbace_a2g_jrt_A_const_15; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1261000191__3); var tmp17 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp17 = A_arbace_a2g_jrt_A_const_79; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = jrt.NN(jrt.File_Cast(f__4)).GetName__String().Ref(); var tmp20 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp20 = A_arbace_a2g_jrt_A_const_93; var tmp21 any = lang.Tuple_Create_O_O__IPersistentVector(tmp19, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(f__4)); var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__1261000190); var tmp23 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp23 = A_arbace_a2g_jrt_A_const_24; return tmp18.Invoke_O_O__O(tmp21, tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__1261000191__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :135:1
func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A { A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :135:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A) Ctor_O_I_O(c__b__1261000193 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1261000193 = c__b__1261000193; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :135:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A) Invoke_O__O(self any) any { { var i__1261000192__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1261000192__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1261000192__1)); var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_77; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1261000193; var tmp5 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp6 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_93; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(f__2))); i__1261000192__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000192__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_New() *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A) Ctor() {}
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A) Invoke_O_O__O(self, s__1261000201__1 any) any { var tmp1 any = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_New_O_O(s__1261000201__1, self); var tmp2 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_Init(); tmp2 = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :144:1
func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_New_O_O(p0, p1 any) *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A{}; t.Ctor_O_O(p0, p1); return t }
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A) Ctor_O_O(c__s__1261000201, c__iter__1261000200 any) { t.F_s__1261000201 = c__s__1261000201; t.F_iter__1261000200 = c__iter__1261000200 }
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A) Invoke_O__O(self any) any { { var s__1261000201__1 any; var t_ any = t.F_s__1261000201; t.F_s__1261000201 = nil; s__1261000201__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1261000201__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1261000208__4 any; var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_15; vec__1261000208__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var fname__5 any = lang.RT_Nth_O_I_O__O(vec__1261000208__4, lang.RT_IntCast_J__I(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O(vec__1261000208__4, lang.RT_IntCast_J__I(1), nil); var iterys__1927001035__auto____7 any; var tmp3 any = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_New_O(fname__5); var tmp4 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_Init(); tmp4 = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_fn_class; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var fs__1927001036__auto____8 any; var tmp5 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_45; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp8 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp8 = A_arbace_a2g_jrt_A_const_43; fs__1927001036__auto____8 = tmp6.Invoke_O__O(tmp7.Invoke_O__O(jrt.NN(tmp8).Invoke_O__O(s__6))); if jrt.A2g_Truth(fs__1927001036__auto____8) { var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_106; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1261000200); var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_24; return tmp10.Invoke_O_O__O(fs__1927001036__auto____8, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1261000201__1))) } else { var tmp13 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_24; s__1261000201__1 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(s__1261000201__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :144:1
func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_New_O(p0 any) *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A{}; t.Ctor_O(p0); return t }
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A) Invoke_O_O__O(self, s__1261000203__1 any) any { var tmp1 any = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_New_O_O_O(t.F_fname, s__1261000203__1, self); var tmp2 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_Init(); tmp2 = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :144:1
func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A) Ctor_O_O_O(c__fname, c__s__1261000203, c__iter__1261000202 any) { t.F_fname = c__fname; t.F_s__1261000203 = c__s__1261000203; t.F_iter__1261000202 = c__iter__1261000202 }
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A) Invoke_O__O(self any) any { { var s__1261000203__1 any; var t_ any = t.F_s__1261000203; t.F_s__1261000203 = nil; s__1261000203__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1261000203__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1261000203__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1261000203__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_48; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1261000203__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1261000205__6 any; var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_75; b__1261000205__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_New_O_I_O_O(t.F_fname, size__1927001038__auto____5, c__1927001037__auto____4, b__1261000205__6); var tmp6 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_Init(); tmp6 = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_78; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_80; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1261000205__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1261000202); var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_65; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1261000203__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_78; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp15 = A_arbace_a2g_jrt_A_const_80; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1261000205__6), nil) } } else { var vec__1261000218__4 any; var tmp16 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp16 = A_arbace_a2g_jrt_A_const_15; vec__1261000218__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1261000203__3); var jn__5 any = lang.RT_Nth_O_I_O__O(vec__1261000218__4, lang.RT_IntCast_J__I(0), nil); var vn__6 any = lang.RT_Nth_O_I_O__O(vec__1261000218__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp17 = A_arbace_a2g_jrt_A_const_79; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp19 = A_arbace_a2g_jrt_A_const_99; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp21 = A_arbace_a2g_jrt_A_const_100; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp23 = A_arbace_a2g_jrt_A_const_101; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_a2g_jrt_A_Init(); tmp25 = A_arbace_a2g_jrt_A_const_105; var tmp26 any = tmp24.Invoke_O_O_O__O(vn__6, tmp25, Lit_140); var tmp27 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp27 = A_arbace_a2g_jrt_A_const_102; var tmp28 any = tmp27.Ref(); var tmp29 any = t.F_fname; var tmp30 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp30 = A_arbace_a2g_jrt_A_const_103; var tmp31 any = tmp30.Ref(); var tmp32 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp32 = A_arbace_a2g_jrt_A_const_104; var tmp33 any = lang.Tuple_Create_O_O__IPersistentVector(jn__5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, vn__6, tmp22, tmp26, tmp28, tmp29, tmp31, lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O_O__O(t.F_fname, Lit_141)))); var tmp34 lang.IFn = lang.IFn_Cast(t.F_iter__1261000202); var tmp35 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp35 = A_arbace_a2g_jrt_A_const_24; return tmp18.Invoke_O_O__O(tmp33, tmp34.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(s__1261000203__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :144:1
func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A) Ctor_O_I_O_O(c__fname any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1261000205 any) { t.F_fname = c__fname; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1261000205 = c__b__1261000205 }
//line :144:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A) Invoke_O__O(self any) any { { var i__1261000204__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1261000204__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1261000214__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1261000204__1)); var jn__3 any = lang.RT_Nth_O_I_O__O(vec__1261000214__2, lang.RT_IntCast_J__I(0), nil); var vn__4 any = lang.RT_Nth_O_I_O__O(vec__1261000214__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_77; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1261000205; var tmp5 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_99; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_100; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_101; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_a2g_jrt_A_Init(); tmp11 = A_arbace_a2g_jrt_A_const_105; var tmp12 any = tmp10.Invoke_O_O_O__O(vn__4, tmp11, Lit_140); var tmp13 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_102; var tmp14 any = tmp13.Ref(); var tmp15 any = t.F_fname; var tmp16 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp16 = A_arbace_a2g_jrt_A_const_103; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp18 = A_arbace_a2g_jrt_A_const_104; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(jn__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, vn__4, tmp8, tmp12, tmp14, tmp15, tmp17, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(t.F_fname, Lit_141))))); i__1261000204__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000204__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_New() *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A { A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A) Ctor() {}
//line :148:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A) Invoke_O_O__O(self, s__1261000226__1 any) any { var tmp1 any = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_New_O_O(s__1261000226__1, self); var tmp2 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_Init(); tmp2 = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :148:1
func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_New_O_O(p0, p1 any) *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A { A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A{}; t.Ctor_O_O(p0, p1); return t }
//line :148:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A) Ctor_O_O(c__s__1261000226, c__iter__1261000225 any) { t.F_s__1261000226 = c__s__1261000226; t.F_iter__1261000225 = c__iter__1261000225 }
//line :148:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A) Invoke_O__O(self any) any { { var s__1261000226__1 any; var t_ any = t.F_s__1261000226; t.F_s__1261000226 = nil; s__1261000226__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1261000226__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1261000226__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1261000226__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_48; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1261000226__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1261000228__6 any; var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_75; b__1261000228__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_New_O_I_O(b__1261000228__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_Init(); tmp6 = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_78; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_80; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1261000228__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1261000225); var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_65; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1261000226__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_78; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp15 = A_arbace_a2g_jrt_A_const_80; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1261000228__6), nil) } } else { var vec__1261000238__4 any; var tmp16 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp16 = A_arbace_a2g_jrt_A_const_15; vec__1261000238__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1261000226__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1261000238__4, lang.RT_IntCast_J__I(0), nil); var map__1261000241__6 any = lang.RT_Nth_O_I_O__O(vec__1261000238__4, lang.RT_IntCast_J__I(1), nil); var map__1261000241__7 any; if lang.ISeq_InstanceOf(map__1261000241__6) { var tmp17 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp17 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(map__1261000241__6)) { var tmp18 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp18 = A_arbace_a2g_jrt_A_const_70; map__1261000241__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(map__1261000241__6), jrt.Object_class.ArrayClass())).Ref() } else { var tmp19 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp19 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(map__1261000241__6)) { var tmp20 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp20 = A_arbace_a2g_jrt_A_const_15; map__1261000241__7 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(map__1261000241__6) } else { lang.PersistentArrayMap_Init(); map__1261000241__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000241__7 = map__1261000241__6 }; var kind__8 any; var tmp21 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp21 = A_arbace_a2g_jrt_A_const_58; kind__8 = lang.RT_Get_O_O__O(map__1261000241__7, tmp21.Ref()); var form__9 any; var tmp22 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp22 = A_arbace_a2g_jrt_A_const_64; form__9 = lang.RT_Get_O_O__O(map__1261000241__7, tmp22.Ref()); var tmp23 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp23 = A_arbace_a2g_jrt_A_const_62; if lang.Util_Equiv_O_O__Z(kind__8, tmp23.Ref()) { var tmp24 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp24 = A_arbace_a2g_jrt_A_const_79; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp26 = A_arbace_a2g_jrt_A_const_107; var tmp27 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(form__9)); var tmp28 lang.IFn = lang.IFn_Cast(t.F_iter__1261000225); var tmp29 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp29 = A_arbace_a2g_jrt_A_const_24; return tmp25.Invoke_O_O__O(tmp27, tmp28.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(s__1261000226__3))) } else { var tmp30 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp30 = A_arbace_a2g_jrt_A_const_24; s__1261000226__1 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(s__1261000226__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :148:1
func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A { A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :148:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A) Ctor_O_I_O(c__b__1261000228 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1261000228 = c__b__1261000228; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :148:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A) Invoke_O__O(self any) any { { var i__1261000227__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1261000227__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1261000232__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1261000227__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__1261000232__2, lang.RT_IntCast_J__I(0), nil); var map__1261000235__4 any = lang.RT_Nth_O_I_O__O(vec__1261000232__2, lang.RT_IntCast_J__I(1), nil); var map__1261000235__5 any; if lang.ISeq_InstanceOf(map__1261000235__4) { var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1261000235__4)) { var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_70; map__1261000235__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1261000235__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1261000235__4)) { var tmp5 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_15; map__1261000235__5 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1261000235__4) } else { lang.PersistentArrayMap_Init(); map__1261000235__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000235__5 = map__1261000235__4 }; var kind__6 any; var tmp6 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_58; kind__6 = lang.RT_Get_O_O__O(map__1261000235__5, tmp6.Ref()); var form__7 any; var tmp7 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_64; form__7 = lang.RT_Get_O_O__O(map__1261000235__5, tmp7.Ref()); var tmp8 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp8 = A_arbace_a2g_jrt_A_const_62; if lang.Util_Equiv_O_O__Z(kind__6, tmp8.Ref()) { var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_77; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = t.F_b__1261000228; var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_107; tmp10.Invoke_O_O__O(tmp11, lang.Tuple_Create_O_O__IPersistentVector(n__3, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(form__7))); i__1261000227__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000227__1); continue L1 } else { i__1261000227__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000227__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_New() *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A { A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A) Ctor() {}
//line :150:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A) Invoke_O_O__O(self, s__1261000246__1 any) any { var tmp1 any = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_New_O_O(s__1261000246__1, self); var tmp2 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_Init(); tmp2 = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :150:1
func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_New_O_O(p0, p1 any) *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A { A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A{}; t.Ctor_O_O(p0, p1); return t }
//line :150:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A) Ctor_O_O(c__s__1261000246, c__iter__1261000245 any) { t.F_s__1261000246 = c__s__1261000246; t.F_iter__1261000245 = c__iter__1261000245 }
//line :150:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A) Invoke_O__O(self any) any { { var s__1261000246__1 any; var t_ any = t.F_s__1261000246; t.F_s__1261000246 = nil; s__1261000246__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_45; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1261000246__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1261000246__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_47; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1261000246__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_48; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1261000246__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1261000248__6 any; var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_75; b__1261000248__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1261000248__6); var tmp6 *jrt.Class; A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_Init(); tmp6 = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_78; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_80; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1261000248__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1261000245); var tmp12 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp12 = A_arbace_a2g_jrt_A_const_65; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1261000246__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_78; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp15 = A_arbace_a2g_jrt_A_const_80; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1261000248__6), nil) } } else { var vec__1261000258__4 any; var tmp16 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp16 = A_arbace_a2g_jrt_A_const_15; vec__1261000258__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1261000246__3); var n__5 any = lang.RT_Nth_O_I_O__O(vec__1261000258__4, lang.RT_IntCast_J__I(0), nil); var map__1261000261__6 any = lang.RT_Nth_O_I_O__O(vec__1261000258__4, lang.RT_IntCast_J__I(1), nil); var map__1261000261__7 any; if lang.ISeq_InstanceOf(map__1261000261__6) { var tmp17 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp17 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(map__1261000261__6)) { var tmp18 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp18 = A_arbace_a2g_jrt_A_const_70; map__1261000261__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(map__1261000261__6), jrt.Object_class.ArrayClass())).Ref() } else { var tmp19 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp19 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(map__1261000261__6)) { var tmp20 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp20 = A_arbace_a2g_jrt_A_const_15; map__1261000261__7 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(map__1261000261__6) } else { lang.PersistentArrayMap_Init(); map__1261000261__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000261__7 = map__1261000261__6 }; var kind__8 any; var tmp21 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp21 = A_arbace_a2g_jrt_A_const_58; kind__8 = lang.RT_Get_O_O__O(map__1261000261__7, tmp21.Ref()); var form__9 any; var tmp22 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp22 = A_arbace_a2g_jrt_A_const_64; form__9 = lang.RT_Get_O_O__O(map__1261000261__7, tmp22.Ref()); var tmp23 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp23 = A_arbace_a2g_jrt_A_const_60; if lang.Util_Equiv_O_O__Z(kind__8, tmp23.Ref()) { var e__10 any; var tmp24 *lang.Var
													A_arbace_a2g_jrt_A_Init(); tmp24 = A_arbace_a2g_jrt_A_const_108; e__10 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(form__9)
//line :150:1
	if jrt.A2g_Truth(e__10) { var tmp25 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp25 = A_arbace_a2g_jrt_A_const_79; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any = lang.Tuple_Create_O_O__IPersistentVector(n__5, e__10); var tmp28 lang.IFn = lang.IFn_Cast(t.F_iter__1261000245); var tmp29 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp29 = A_arbace_a2g_jrt_A_const_24; return tmp26.Invoke_O_O__O(tmp27, tmp28.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(s__1261000246__3))) } else { var tmp30 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp30 = A_arbace_a2g_jrt_A_const_24; s__1261000246__1 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(s__1261000246__3); continue L1 } } else { var tmp31 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp31 = A_arbace_a2g_jrt_A_const_24; s__1261000246__1 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(s__1261000246__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :150:1
func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A { A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_Init(); t := &A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :150:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1261000248 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1261000248 = c__b__1261000248 }
//line :150:1
func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A) Invoke_O__O(self any) any { { var i__1261000247__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1261000247__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1261000252__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1261000247__1)); var n__3 any = lang.RT_Nth_O_I_O__O(vec__1261000252__2, lang.RT_IntCast_J__I(0), nil); var map__1261000255__4 any = lang.RT_Nth_O_I_O__O(vec__1261000252__2, lang.RT_IntCast_J__I(1), nil); var map__1261000255__5 any; if lang.ISeq_InstanceOf(map__1261000255__4) { var tmp2 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1261000255__4)) { var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_70; map__1261000255__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1261000255__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1261000255__4)) { var tmp5 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_15; map__1261000255__5 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__1261000255__4) } else { lang.PersistentArrayMap_Init(); map__1261000255__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1261000255__5 = map__1261000255__4 }; var kind__6 any; var tmp6 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_58; kind__6 = lang.RT_Get_O_O__O(map__1261000255__5, tmp6.Ref()); var form__7 any; var tmp7 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp7 = A_arbace_a2g_jrt_A_const_64; form__7 = lang.RT_Get_O_O__O(map__1261000255__5, tmp7.Ref()); var tmp8 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp8 = A_arbace_a2g_jrt_A_const_60; if lang.Util_Equiv_O_O__Z(kind__6, tmp8.Ref()) { var e__8 any; var tmp9 *lang.Var
															A_arbace_a2g_jrt_A_Init(); tmp9 = A_arbace_a2g_jrt_A_const_108; e__8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(form__7)
//line :150:1
	if jrt.A2g_Truth(e__8) { var tmp10 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp10 = A_arbace_a2g_jrt_A_const_77; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = t.F_b__1261000248; tmp11.Invoke_O_O__O(tmp12, lang.Tuple_Create_O_O__IPersistentVector(n__3, e__8)); i__1261000247__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000247__1); continue L1 } else { i__1261000247__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000247__1); continue L1 } } else { i__1261000247__1 = lang.Numbers_Unchecked_inc_J__J(i__1261000247__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_a2g_jrt_struct_methods_A_New() *A_arbace_a2g_jrt_struct_methods_A { A_arbace_a2g_jrt_struct_methods_A_Init(); t := &A_arbace_a2g_jrt_struct_methods_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_a2g_jrt_struct_methods_A) Ctor() {}
//line :154:1
func (t *A_arbace_a2g_jrt_struct_methods_A) Invoke_O_O_O__O(self, scan__0, go_type__1 any) any { { var t__3 any = go_type__1; var acc__4 any; lang.PersistentHashSet_Init(); acc__4 = lang.PersistentHashSet_EMPTY.Ref(); L1: for {



	if lang.Util_Identical_O_O__Z(t__3, nil) { return acc__4 } else {

		var tmp1 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_73; var tmp2 any = lang.RT_Get_O_O__O(jrt.NN(tmp1).Invoke_O__O(scan__0), t__3); var tmp3 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp3 = A_arbace_a2g_jrt_A_const_84; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp5 = A_arbace_a2g_jrt_A_const_40; t__3, acc__4 = tmp2, tmp4.Invoke_O_O__O(acc__4, lang.RT_Get_O_O__O(jrt.NN(tmp5).Invoke_O__O(scan__0), t__3)); continue L1 } } }; /*line :154:1*/panic("a2g: unreachable") }







func A_arbace_a2g_jrt_iface_methods_A_New() *A_arbace_a2g_jrt_iface_methods_A { A_arbace_a2g_jrt_iface_methods_A_Init(); t := &A_arbace_a2g_jrt_iface_methods_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_a2g_jrt_iface_methods_A) Ctor() {}
//line :162:1
func (t *A_arbace_a2g_jrt_iface_methods_A) Invoke_O_O_O__O(self, scan__0, go_type__1 any) any { var i__3 any; var tmp1 *lang.Keyword;


	A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_86; i__3 = lang.RT_Get_O_O__O(jrt.NN(tmp1).Invoke_O__O(scan__0), go_type__1); var tmp2 /*line :166:1*/*lang.Var; A_arbace_a2g_jrt_A_Init(); tmp2 = A_arbace_a2g_jrt_A_const_84; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp4 = A_arbace_a2g_jrt_A_const_72; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp6 = A_arbace_a2g_jrt_A_const_40; var tmp7 any = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(i__3)); var tmp8 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp8 = A_arbace_a2g_jrt_A_const_109; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_New_O(scan__0); var tmp11 *jrt.Class; A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_Init(); tmp11 = A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_fn_class; var tmp12 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var tmp13 *lang.Keyword; A_arbace_a2g_jrt_A_Init(); tmp13 = A_arbace_a2g_jrt_A_const_73; return tmp3.Invoke_O_O__O(tmp7, tmp9.Invoke_O_O__O(tmp12, jrt.NN(tmp13).Invoke_O__O(i__3))) }
//line :166:1
func A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_New_O(p0 any) *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A { A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_Init(); t := &A_arbace_a2g_jrt_iface_methods_fn__1261000268_A{}; t.Ctor_O(p0); return t }
//line :166:1
func (t *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A) Ctor_O(c__scan any) { t.F_scan = c__scan }
//line :166:1
func (t *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A) Invoke_O_O__O(self, p1__1261000267_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_jrt_A_Init(); tmp1 = A_arbace_a2g_jrt_A_const_110; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_scan, p1__1261000267_SHARP___1) }
















































































































type A_arbace_a2g_jrt_A struct{ jrt.Object }

var A_arbace_a2g_jrt_A_const_0 *lang.Var

var A_arbace_a2g_jrt_A_const_1 *lang.Var

var A_arbace_a2g_jrt_A_const_2 any

var A_arbace_a2g_jrt_A_const_3 any

var A_arbace_a2g_jrt_A_const_4 any

var A_arbace_a2g_jrt_A_const_5 any

var A_arbace_a2g_jrt_A_const_6 any

var A_arbace_a2g_jrt_A_const_7 *lang.Var

var A_arbace_a2g_jrt_A_const_8 *lang.Var

var A_arbace_a2g_jrt_A_const_9 *lang.Var

var A_arbace_a2g_jrt_A_const_10 any

var A_arbace_a2g_jrt_A_const_11 *lang.Var

var A_arbace_a2g_jrt_A_const_12 *lang.Var

var A_arbace_a2g_jrt_A_const_13 *lang.Var

var A_arbace_a2g_jrt_A_const_14 *lang.Var

var A_arbace_a2g_jrt_A_const_15 *lang.Var

var A_arbace_a2g_jrt_A_const_16 any

var A_arbace_a2g_jrt_A_const_17 *lang.Var

var A_arbace_a2g_jrt_A_const_18 *lang.Keyword

var A_arbace_a2g_jrt_A_const_19 *lang.Var

var A_arbace_a2g_jrt_A_const_20 any

var A_arbace_a2g_jrt_A_const_21 *lang.Keyword

var A_arbace_a2g_jrt_A_const_22 *lang.Var

var A_arbace_a2g_jrt_A_const_23 *lang.Var

var A_arbace_a2g_jrt_A_const_24 *lang.Var

var A_arbace_a2g_jrt_A_const_25 *lang.Var

var A_arbace_a2g_jrt_A_const_26 *lang.Var

var A_arbace_a2g_jrt_A_const_27 any

var A_arbace_a2g_jrt_A_const_28 *lang.Var

var A_arbace_a2g_jrt_A_const_29 *lang.Var

var A_arbace_a2g_jrt_A_const_30 *lang.Var

var A_arbace_a2g_jrt_A_const_31 *lang.Var

var A_arbace_a2g_jrt_A_const_32 *lang.Var

var A_arbace_a2g_jrt_A_const_33 any

var A_arbace_a2g_jrt_A_const_34 *lang.Keyword

var A_arbace_a2g_jrt_A_const_35 *lang.Keyword

var A_arbace_a2g_jrt_A_const_36 *lang.Keyword

var A_arbace_a2g_jrt_A_const_37 *lang.Var

var A_arbace_a2g_jrt_A_const_38 *lang.Var

var A_arbace_a2g_jrt_A_const_39 *lang.Keyword

var A_arbace_a2g_jrt_A_const_40 *lang.Keyword

var A_arbace_a2g_jrt_A_const_41 *lang.Keyword

var A_arbace_a2g_jrt_A_const_42 *lang.Keyword

var A_arbace_a2g_jrt_A_const_43 *lang.Keyword

var A_arbace_a2g_jrt_A_const_44 *lang.Keyword

var A_arbace_a2g_jrt_A_const_45 *lang.Var

var A_arbace_a2g_jrt_A_const_46 *lang.Var

var A_arbace_a2g_jrt_A_const_47 *lang.Var

var A_arbace_a2g_jrt_A_const_48 *lang.Var

var A_arbace_a2g_jrt_A_const_49 *lang.Var

var A_arbace_a2g_jrt_A_const_50 *lang.Var

var A_arbace_a2g_jrt_A_const_51 *lang.Keyword

var A_arbace_a2g_jrt_A_const_52 *lang.Var

var A_arbace_a2g_jrt_A_const_53 *lang.Var

var A_arbace_a2g_jrt_A_const_54 *lang.Var

var A_arbace_a2g_jrt_A_const_55 *lang.Var

var A_arbace_a2g_jrt_A_const_56 *lang.Var

var A_arbace_a2g_jrt_A_const_57 *lang.Var

var A_arbace_a2g_jrt_A_const_58 *lang.Keyword

var A_arbace_a2g_jrt_A_const_59 any

var A_arbace_a2g_jrt_A_const_60 *lang.Keyword

var A_arbace_a2g_jrt_A_const_61 any

var A_arbace_a2g_jrt_A_const_62 *lang.Keyword

var A_arbace_a2g_jrt_A_const_63 *lang.Keyword

var A_arbace_a2g_jrt_A_const_64 *lang.Keyword

var A_arbace_a2g_jrt_A_const_65 *lang.Var

var A_arbace_a2g_jrt_A_const_66 any

var A_arbace_a2g_jrt_A_const_67 any

var A_arbace_a2g_jrt_A_const_68 any

var A_arbace_a2g_jrt_A_const_69 *lang.Var

var A_arbace_a2g_jrt_A_const_70 *lang.Var

var A_arbace_a2g_jrt_A_const_71 any

var A_arbace_a2g_jrt_A_const_72 *lang.Var

var A_arbace_a2g_jrt_A_const_73 *lang.Keyword

var A_arbace_a2g_jrt_A_const_74 *lang.Var

var A_arbace_a2g_jrt_A_const_75 *lang.Var

var A_arbace_a2g_jrt_A_const_76 *lang.Var

var A_arbace_a2g_jrt_A_const_77 *lang.Var

var A_arbace_a2g_jrt_A_const_78 *lang.Var

var A_arbace_a2g_jrt_A_const_79 *lang.Var

var A_arbace_a2g_jrt_A_const_80 *lang.Var

var A_arbace_a2g_jrt_A_const_81 *lang.Var

var A_arbace_a2g_jrt_A_const_82 any

var A_arbace_a2g_jrt_A_const_83 *lang.Var

var A_arbace_a2g_jrt_A_const_84 *lang.Var

var A_arbace_a2g_jrt_A_const_85 *lang.Keyword

var A_arbace_a2g_jrt_A_const_86 *lang.Keyword

var A_arbace_a2g_jrt_A_const_87 *lang.Var

var A_arbace_a2g_jrt_A_const_88 *lang.Var

var A_arbace_a2g_jrt_A_const_89 *lang.Var

var A_arbace_a2g_jrt_A_const_90 *lang.Var

var A_arbace_a2g_jrt_A_const_91 *lang.Var

var A_arbace_a2g_jrt_A_const_92 *lang.Var

var A_arbace_a2g_jrt_A_const_93 *lang.Var

var A_arbace_a2g_jrt_A_const_94 *lang.Var

var A_arbace_a2g_jrt_A_const_95 *lang.Var

var A_arbace_a2g_jrt_A_const_96 *lang.Var

var A_arbace_a2g_jrt_A_const_97 *lang.Var

var A_arbace_a2g_jrt_A_const_98 *lang.Var

var A_arbace_a2g_jrt_A_const_99 *lang.Keyword

var A_arbace_a2g_jrt_A_const_100 *lang.Keyword

var A_arbace_a2g_jrt_A_const_101 *lang.Var

var A_arbace_a2g_jrt_A_const_102 *lang.Keyword

var A_arbace_a2g_jrt_A_const_103 *lang.Keyword

var A_arbace_a2g_jrt_A_const_104 *lang.Var

var A_arbace_a2g_jrt_A_const_105 any

var A_arbace_a2g_jrt_A_const_106 *lang.Var

var A_arbace_a2g_jrt_A_const_107 *lang.Var

var A_arbace_a2g_jrt_A_const_108 *lang.Var

var A_arbace_a2g_jrt_A_const_109 *lang.Var

var A_arbace_a2g_jrt_A_const_110 *lang.Var

var A_arbace_a2g_jrt_A_init jrt.ClassInit

func A_arbace_a2g_jrt_A_Init() { if !A_arbace_a2g_jrt_A_init.Done() { A_arbace_a2g_jrt_A_init.Run(A_arbace_a2g_jrt_A_clinit) } }

func A_arbace_a2g_jrt_A_clinit() { A_arbace_a2g_jrt_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_jrt_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_jrt_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_jrt_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_jrt_A_const_4 = lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref()); A_arbace_a2g_jrt_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref()); A_arbace_a2g_jrt_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref()); A_arbace_a2g_jrt_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_a2g_jrt_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_a2g_jrt_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_a2g_jrt_A_const_10 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_14)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16))); A_arbace_a2g_jrt_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_a2g_jrt_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_a2g_jrt_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_a2g_jrt_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_a2g_jrt_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_a2g_jrt_A_const_16 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_22, Lit_23)).Ref(); A_arbace_a2g_jrt_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_a2g_jrt_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_a2g_jrt_A_const_19 = lang.RT_Var_String_String__Var(Lit_14, Lit_26); A_arbace_a2g_jrt_A_const_20 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref(); A_arbace_a2g_jrt_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_a2g_jrt_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_a2g_jrt_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_a2g_jrt_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_a2g_jrt_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_a2g_jrt_A_const_26 = lang.RT_Var_String_String__Var(Lit_14, Lit_33); A_arbace_a2g_jrt_A_const_27 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(); A_arbace_a2g_jrt_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_a2g_jrt_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_a2g_jrt_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_a2g_jrt_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_a2g_jrt_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_a2g_jrt_A_const_33 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_a2g_jrt_A_const_34 = lang.RT_Keyword_String_String__Keyword(nil, Lit_40); A_arbace_a2g_jrt_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_20); A_arbace_a2g_jrt_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); A_arbace_a2g_jrt_A_const_37 = lang.RT_Var_String_String__Var(Lit_9, Lit_42); A_arbace_a2g_jrt_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_a2g_jrt_A_const_39 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_a2g_jrt_A_const_40 = lang.RT_Keyword_String_String__Keyword(nil, Lit_45); A_arbace_a2g_jrt_A_const_41 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_a2g_jrt_A_const_42 = lang.RT_Keyword_String_String__Keyword(nil, Lit_47); A_arbace_a2g_jrt_A_const_43 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_a2g_jrt_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_a2g_jrt_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_a2g_jrt_A_const_46 = lang.RT_Var_String_String__Var(Lit_14, Lit_51); A_arbace_a2g_jrt_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_a2g_jrt_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_a2g_jrt_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_a2g_jrt_A_const_50 = lang.RT_Var_String_String__Var(Lit_14, Lit_55); A_arbace_a2g_jrt_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_a2g_jrt_A_const_52 = lang.RT_Var_String_String__Var(Lit_14, Lit_57); A_arbace_a2g_jrt_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_a2g_jrt_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_a2g_jrt_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_a2g_jrt_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_a2g_jrt_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_a2g_jrt_A_const_58 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_a2g_jrt_A_const_59 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_64).Ref(); A_arbace_a2g_jrt_A_const_60 = lang.RT_Keyword_String_String__Keyword(nil, Lit_64); A_arbace_a2g_jrt_A_const_61 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(); A_arbace_a2g_jrt_A_const_62 = lang.RT_Keyword_String_String__Keyword(nil, Lit_65); A_arbace_a2g_jrt_A_const_63 = lang.RT_Keyword_String_String__Keyword(nil, Lit_66); A_arbace_a2g_jrt_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_67); A_arbace_a2g_jrt_A_const_65 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_a2g_jrt_A_const_66 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_64).Ref(); A_arbace_a2g_jrt_A_const_67 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_65).Ref(); A_arbace_a2g_jrt_A_const_68 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_a2g_jrt_A_const_69 = lang.RT_Var_String_String__Var(Lit_14, Lit_70); A_arbace_a2g_jrt_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_a2g_jrt_A_const_71 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_a2g_jrt_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_a2g_jrt_A_const_73 = lang.RT_Keyword_String_String__Keyword(nil, Lit_73); A_arbace_a2g_jrt_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_a2g_jrt_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_a2g_jrt_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_a2g_jrt_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_a2g_jrt_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_a2g_jrt_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_a2g_jrt_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_a2g_jrt_A_const_81 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_a2g_jrt_A_const_82 = jrt.Pattern_Compile_String__Pattern(Lit_82).Ref(); A_arbace_a2g_jrt_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_83); A_arbace_a2g_jrt_A_const_84 = lang.RT_Var_String_String__Var(Lit_0, Lit_84); A_arbace_a2g_jrt_A_const_85 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_a2g_jrt_A_const_86 = lang.RT_Keyword_String_String__Keyword(nil, Lit_86); A_arbace_a2g_jrt_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_a2g_jrt_A_const_88 = lang.RT_Var_String_String__Var(Lit_3, Lit_88); A_arbace_a2g_jrt_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_a2g_jrt_A_const_90 = lang.RT_Var_String_String__Var(Lit_14, Lit_90); A_arbace_a2g_jrt_A_const_91 = lang.RT_Var_String_String__Var(Lit_7, Lit_91); A_arbace_a2g_jrt_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_92); A_arbace_a2g_jrt_A_const_93 = lang.RT_Var_String_String__Var(Lit_14, Lit_93); A_arbace_a2g_jrt_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_94); A_arbace_a2g_jrt_A_const_95 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_a2g_jrt_A_const_96 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_a2g_jrt_A_const_97 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_a2g_jrt_A_const_98 = lang.RT_Var_String_String__Var(Lit_6, Lit_98); A_arbace_a2g_jrt_A_const_99 = lang.RT_Keyword_String_String__Keyword(nil, Lit_99); A_arbace_a2g_jrt_A_const_100 = lang.RT_Keyword_String_String__Keyword(nil, Lit_23); A_arbace_a2g_jrt_A_const_101 = lang.RT_Var_String_String__Var(Lit_3, Lit_100); A_arbace_a2g_jrt_A_const_102 = lang.RT_Keyword_String_String__Keyword(nil, Lit_91); A_arbace_a2g_jrt_A_const_103 = lang.RT_Keyword_String_String__Keyword(nil, Lit_101); A_arbace_a2g_jrt_A_const_104 = lang.RT_Var_String_String__Var(Lit_3, Lit_102); A_arbace_a2g_jrt_A_const_105 = jrt.Pattern_Compile_String__Pattern(Lit_103).Ref(); A_arbace_a2g_jrt_A_const_106 = lang.RT_Var_String_String__Var(Lit_0, Lit_104); A_arbace_a2g_jrt_A_const_107 = lang.RT_Var_String_String__Var(Lit_14, Lit_105); A_arbace_a2g_jrt_A_const_108 = lang.RT_Var_String_String__Var(Lit_14, Lit_106); A_arbace_a2g_jrt_A_const_109 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); A_arbace_a2g_jrt_A_const_110 = lang.RT_Var_String_String__Var(Lit_14, Lit_108) }

func A_arbace_a2g_jrt_A_New() *A_arbace_a2g_jrt_A { A_arbace_a2g_jrt_A_Init(); t := &A_arbace_a2g_jrt_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_jrt_A) Ctor() {}

func (t *A_arbace_a2g_jrt_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_A_class }

func (t *A_arbace_a2g_jrt_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_A); return ok }

func A_arbace_a2g_jrt_A_Cast(x any) *A_arbace_a2g_jrt_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_A_class)) }; return v }



type A_arbace_a2g_jrt_define_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_define_name_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_define_name_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_define_name_A_init jrt.ClassInit

func A_arbace_a2g_jrt_define_name_A_Init() { if !A_arbace_a2g_jrt_define_name_A_init.Done() { A_arbace_a2g_jrt_define_name_A_init.Run(A_arbace_a2g_jrt_define_name_A_clinit) } }

func A_arbace_a2g_jrt_define_name_A_clinit() { A_arbace_a2g_jrt_define_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_define_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_define_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_define_name_A_class }

func (t *A_arbace_a2g_jrt_define_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_define_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_define_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_define_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_define_name_A); return ok }

func A_arbace_a2g_jrt_define_name_A_Cast(x any) *A_arbace_a2g_jrt_define_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_define_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_define_name_A_class)) }; return v }



type A_arbace_a2g_jrt_define_name_walk__1261000019_A struct{ jrt.Object; F_found any }

func (t *A_arbace_a2g_jrt_define_name_walk__1261000019_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_define_name_walk__1261000019_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_define_name_walk__1261000019_A_init jrt.ClassInit

func A_arbace_a2g_jrt_define_name_walk__1261000019_A_Init() { if !A_arbace_a2g_jrt_define_name_walk__1261000019_A_init.Done() { A_arbace_a2g_jrt_define_name_walk__1261000019_A_init.Run(A_arbace_a2g_jrt_define_name_walk__1261000019_A_clinit) } }

func A_arbace_a2g_jrt_define_name_walk__1261000019_A_clinit() { A_arbace_a2g_jrt_define_name_walk__1261000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_define_name_walk__1261000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_define_name_walk__1261000019_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_define_name_walk__1261000019_A_class }

func (t *A_arbace_a2g_jrt_define_name_walk__1261000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_define_name_walk__1261000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_define_name_walk__1261000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_define_name_walk__1261000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_define_name_walk__1261000019_A); return ok }

func A_arbace_a2g_jrt_define_name_walk__1261000019_A_Cast(x any) *A_arbace_a2g_jrt_define_name_walk__1261000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_define_name_walk__1261000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_define_name_walk__1261000019_A_class)) }; return v }



type A_arbace_a2g_jrt_eval1261000004_A struct{ jrt.Object }

func A_arbace_a2g_jrt_eval1261000004_A_New() *A_arbace_a2g_jrt_eval1261000004_A { t := &A_arbace_a2g_jrt_eval1261000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_jrt_eval1261000004_A) Ctor() {}

func (t *A_arbace_a2g_jrt_eval1261000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_eval1261000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_eval1261000004_A_class }

func (t *A_arbace_a2g_jrt_eval1261000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_eval1261000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_eval1261000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_eval1261000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_eval1261000004_A); return ok }

func A_arbace_a2g_jrt_eval1261000004_A_Cast(x any) *A_arbace_a2g_jrt_eval1261000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_eval1261000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_eval1261000004_A_class)) }; return v }



type A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_init jrt.ClassInit

func A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_Init() { if !A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_init.Done() { A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_init.Run(A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_clinit) } }

func A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_clinit() { A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_class }

func (t *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A); return ok }

func A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_Cast(x any) *A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_class)) }; return v }



type A_arbace_a2g_jrt_eval1261000008_A struct{ jrt.Object }

func A_arbace_a2g_jrt_eval1261000008_A_New() *A_arbace_a2g_jrt_eval1261000008_A { t := &A_arbace_a2g_jrt_eval1261000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_jrt_eval1261000008_A) Ctor() {}

func (t *A_arbace_a2g_jrt_eval1261000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_eval1261000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_eval1261000008_A_class }

func (t *A_arbace_a2g_jrt_eval1261000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_eval1261000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_eval1261000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_eval1261000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_eval1261000008_A); return ok }

func A_arbace_a2g_jrt_eval1261000008_A_Cast(x any) *A_arbace_a2g_jrt_eval1261000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_eval1261000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_eval1261000008_A_class)) }; return v }



type A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_init jrt.ClassInit

func A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_Init() { if !A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_init.Done() { A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_init.Run(A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_clinit) } }

func A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_clinit() { A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_class }

func (t *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A); return ok }

func A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_Cast(x any) *A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_class)) }; return v }



type A_arbace_a2g_jrt_go_head_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_go_head_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_go_head_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_go_head_A_init jrt.ClassInit

func A_arbace_a2g_jrt_go_head_A_Init() { if !A_arbace_a2g_jrt_go_head_A_init.Done() { A_arbace_a2g_jrt_go_head_A_init.Run(A_arbace_a2g_jrt_go_head_A_clinit) } }

func A_arbace_a2g_jrt_go_head_A_clinit() { A_arbace_a2g_jrt_go_head_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_go_head_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_go_head_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_go_head_A_class }

func (t *A_arbace_a2g_jrt_go_head_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_go_head_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_go_head_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_go_head_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_go_head_A); return ok }

func A_arbace_a2g_jrt_go_head_A_Cast(x any) *A_arbace_a2g_jrt_go_head_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_go_head_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_go_head_A_class)) }; return v }



type A_arbace_a2g_jrt_head_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_head_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_head_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_head_A_init jrt.ClassInit

func A_arbace_a2g_jrt_head_A_Init() { if !A_arbace_a2g_jrt_head_A_init.Done() { A_arbace_a2g_jrt_head_A_init.Run(A_arbace_a2g_jrt_head_A_clinit) } }

func A_arbace_a2g_jrt_head_A_clinit() { A_arbace_a2g_jrt_head_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_head_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_head_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_head_A_class }

func (t *A_arbace_a2g_jrt_head_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_head_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_head_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_head_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_head_A); return ok }

func A_arbace_a2g_jrt_head_A_Cast(x any) *A_arbace_a2g_jrt_head_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_head_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_head_A_class)) }; return v }



type A_arbace_a2g_jrt_iface_methods_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_iface_methods_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_jrt_iface_methods_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_iface_methods_A_init jrt.ClassInit

func A_arbace_a2g_jrt_iface_methods_A_Init() { if !A_arbace_a2g_jrt_iface_methods_A_init.Done() { A_arbace_a2g_jrt_iface_methods_A_init.Run(A_arbace_a2g_jrt_iface_methods_A_clinit) } }

func A_arbace_a2g_jrt_iface_methods_A_clinit() { A_arbace_a2g_jrt_iface_methods_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_iface_methods_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_iface_methods_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_iface_methods_A_class }

func (t *A_arbace_a2g_jrt_iface_methods_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_iface_methods_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_iface_methods_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_iface_methods_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_iface_methods_A); return ok }

func A_arbace_a2g_jrt_iface_methods_A_Cast(x any) *A_arbace_a2g_jrt_iface_methods_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_iface_methods_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_iface_methods_A_class)) }; return v }



type A_arbace_a2g_jrt_iface_methods_fn__1261000268_A struct{ jrt.Object; F_scan any }

func (t *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_init jrt.ClassInit

func A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_Init() { if !A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_init.Done() { A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_init.Run(A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_clinit) } }

func A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_clinit() { A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_class }

func (t *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_iface_methods_fn__1261000268_A); return ok }

func A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_Cast(x any) *A_arbace_a2g_jrt_iface_methods_fn__1261000268_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_iface_methods_fn__1261000268_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_class)) }; return v }



type A_arbace_a2g_jrt_interface_elems_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_interface_elems_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_interface_elems_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_A_init jrt.ClassInit

func A_arbace_a2g_jrt_interface_elems_A_Init() { if !A_arbace_a2g_jrt_interface_elems_A_init.Done() { A_arbace_a2g_jrt_interface_elems_A_init.Run(A_arbace_a2g_jrt_interface_elems_A_clinit) } }

func A_arbace_a2g_jrt_interface_elems_A_clinit() { A_arbace_a2g_jrt_interface_elems_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_118, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_interface_elems_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_interface_elems_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_interface_elems_A_class }

func (t *A_arbace_a2g_jrt_interface_elems_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_interface_elems_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_interface_elems_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_interface_elems_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_interface_elems_A); return ok }

func A_arbace_a2g_jrt_interface_elems_A_Cast(x any) *A_arbace_a2g_jrt_interface_elems_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_interface_elems_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_interface_elems_A_class)) }; return v }



type A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_init jrt.ClassInit

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_Init() { if !A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_init.Done() { A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_init.Run(A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_clinit) } }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_clinit() { A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_class }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A); return ok }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_Cast(x any) *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_class)) }; return v }



type A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A struct{ jrt.Object; F_s__1261000162, F_iter__1261000161 any }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_init jrt.ClassInit

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_Init() { if !A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_init.Done() { A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_init.Run(A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_clinit) } }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_clinit() { A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_class }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A); return ok }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_Cast(x any) *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_class)) }; return v }



type A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A struct{ jrt.Object; F_b__1261000164 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_init jrt.ClassInit

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_Init() { if !A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_init.Done() { A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_init.Run(A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_clinit) } }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_clinit() { A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_class }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A); return ok }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_Cast(x any) *A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_class)) }; return v }



type A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_init jrt.ClassInit

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_Init() { if !A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_init.Done() { A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_init.Run(A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_clinit) } }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_clinit() { A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_class }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A); return ok }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_Cast(x any) *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_class)) }; return v }



type A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A struct{ jrt.Object; F_s__1261000172, F_iter__1261000171 any }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_init jrt.ClassInit

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_Init() { if !A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_init.Done() { A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_init.Run(A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_clinit) } }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_clinit() { A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_class }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A); return ok }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_Cast(x any) *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_class)) }; return v }



type A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A struct{ jrt.Object; F_b__1261000174 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_init jrt.ClassInit

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_Init() { if !A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_init.Done() { A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_init.Run(A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_clinit) } }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_clinit() { A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_class }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A); return ok }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_Cast(x any) *A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_class)) }; return v }



type A_arbace_a2g_jrt_other_system_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_other_system_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_other_system_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_jrt_other_system_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_jrt_other_system_QMARK__A_Init() { if !A_arbace_a2g_jrt_other_system_QMARK__A_init.Done() { A_arbace_a2g_jrt_other_system_QMARK__A_init.Run(A_arbace_a2g_jrt_other_system_QMARK__A_clinit) } }

func A_arbace_a2g_jrt_other_system_QMARK__A_clinit() { A_arbace_a2g_jrt_other_system_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_other_system_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_other_system_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_other_system_QMARK__A_class }

func (t *A_arbace_a2g_jrt_other_system_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_other_system_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_other_system_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_other_system_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_other_system_QMARK__A); return ok }

func A_arbace_a2g_jrt_other_system_QMARK__A_Cast(x any) *A_arbace_a2g_jrt_other_system_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_other_system_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_other_system_QMARK__A_class)) }; return v }



type A_arbace_a2g_jrt_recv_type_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_recv_type_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_recv_type_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_recv_type_A_init jrt.ClassInit

func A_arbace_a2g_jrt_recv_type_A_Init() { if !A_arbace_a2g_jrt_recv_type_A_init.Done() { A_arbace_a2g_jrt_recv_type_A_init.Run(A_arbace_a2g_jrt_recv_type_A_clinit) } }

func A_arbace_a2g_jrt_recv_type_A_clinit() { A_arbace_a2g_jrt_recv_type_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_recv_type_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_recv_type_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_recv_type_A_class }

func (t *A_arbace_a2g_jrt_recv_type_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_recv_type_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_recv_type_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_recv_type_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_recv_type_A); return ok }

func A_arbace_a2g_jrt_recv_type_A_Cast(x any) *A_arbace_a2g_jrt_recv_type_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_recv_type_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_recv_type_A_class)) }; return v }



type A_arbace_a2g_jrt_recv_type_nm__1261000015_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_recv_type_nm__1261000015_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_recv_type_nm__1261000015_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_recv_type_nm__1261000015_A_init jrt.ClassInit

func A_arbace_a2g_jrt_recv_type_nm__1261000015_A_Init() { if !A_arbace_a2g_jrt_recv_type_nm__1261000015_A_init.Done() { A_arbace_a2g_jrt_recv_type_nm__1261000015_A_init.Run(A_arbace_a2g_jrt_recv_type_nm__1261000015_A_clinit) } }

func A_arbace_a2g_jrt_recv_type_nm__1261000015_A_clinit() { A_arbace_a2g_jrt_recv_type_nm__1261000015_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_recv_type_nm__1261000015_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_recv_type_nm__1261000015_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_recv_type_nm__1261000015_A_class }

func (t *A_arbace_a2g_jrt_recv_type_nm__1261000015_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_recv_type_nm__1261000015_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_recv_type_nm__1261000015_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_recv_type_nm__1261000015_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_recv_type_nm__1261000015_A); return ok }

func A_arbace_a2g_jrt_recv_type_nm__1261000015_A_Cast(x any) *A_arbace_a2g_jrt_recv_type_nm__1261000015_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_recv_type_nm__1261000015_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_recv_type_nm__1261000015_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_scan_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_scan_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_A_Init() { if !A_arbace_a2g_jrt_scan_A_init.Done() { A_arbace_a2g_jrt_scan_A_init.Run(A_arbace_a2g_jrt_scan_A_clinit) } }

func A_arbace_a2g_jrt_scan_A_clinit() { A_arbace_a2g_jrt_scan_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_A_class }

func (t *A_arbace_a2g_jrt_scan_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_A); return ok }

func A_arbace_a2g_jrt_scan_A_Cast(x any) *A_arbace_a2g_jrt_scan_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_fn__1261000186_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_scan_fn__1261000186_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_scan_fn__1261000186_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_fn__1261000186_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_fn__1261000186_A_Init() { if !A_arbace_a2g_jrt_scan_fn__1261000186_A_init.Done() { A_arbace_a2g_jrt_scan_fn__1261000186_A_init.Run(A_arbace_a2g_jrt_scan_fn__1261000186_A_clinit) } }

func A_arbace_a2g_jrt_scan_fn__1261000186_A_clinit() { A_arbace_a2g_jrt_scan_fn__1261000186_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_fn__1261000186_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_fn__1261000186_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_fn__1261000186_A_class }

func (t *A_arbace_a2g_jrt_scan_fn__1261000186_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_fn__1261000186_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_fn__1261000186_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_fn__1261000186_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_fn__1261000186_A); return ok }

func A_arbace_a2g_jrt_scan_fn__1261000186_A_Cast(x any) *A_arbace_a2g_jrt_scan_fn__1261000186_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_fn__1261000186_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_fn__1261000186_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_fn__1261000188_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_scan_fn__1261000188_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_scan_fn__1261000188_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_fn__1261000188_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_fn__1261000188_A_Init() { if !A_arbace_a2g_jrt_scan_fn__1261000188_A_init.Done() { A_arbace_a2g_jrt_scan_fn__1261000188_A_init.Run(A_arbace_a2g_jrt_scan_fn__1261000188_A_clinit) } }

func A_arbace_a2g_jrt_scan_fn__1261000188_A_clinit() { A_arbace_a2g_jrt_scan_fn__1261000188_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_fn__1261000188_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_fn__1261000188_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_fn__1261000188_A_class }

func (t *A_arbace_a2g_jrt_scan_fn__1261000188_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_fn__1261000188_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_fn__1261000188_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_fn__1261000188_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_fn__1261000188_A); return ok }

func A_arbace_a2g_jrt_scan_fn__1261000188_A_Cast(x any) *A_arbace_a2g_jrt_scan_fn__1261000188_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_fn__1261000188_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_fn__1261000188_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A struct{ jrt.Object; F_s__1261000191, F_iter__1261000190 any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A struct{ jrt.Object; F_b__1261000193 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A struct{ jrt.Object; F_s__1261000201, F_iter__1261000200 any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A struct{ jrt.Object; F_fname any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A struct{ jrt.Object; F_fname, F_s__1261000203, F_iter__1261000202 any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A struct{ jrt.Object; F_fname any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1261000205 any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A struct{ jrt.Object; F_s__1261000226, F_iter__1261000225 any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A struct{ jrt.Object; F_b__1261000228 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_146, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A struct{ jrt.Object; F_s__1261000246, F_iter__1261000245 any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A struct{ jrt.Object; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1261000248 any }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_Init() { if !A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_init.Done() { A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_init.Run(A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_clinit) } }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_clinit() { A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_class }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A); return ok }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_Cast(x any) *A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_class)) }; return v }



type A_arbace_a2g_jrt_scan_file_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_scan_file_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_scan_file_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_scan_file_A_init jrt.ClassInit

func A_arbace_a2g_jrt_scan_file_A_Init() { if !A_arbace_a2g_jrt_scan_file_A_init.Done() { A_arbace_a2g_jrt_scan_file_A_init.Run(A_arbace_a2g_jrt_scan_file_A_clinit) } }

func A_arbace_a2g_jrt_scan_file_A_clinit() { A_arbace_a2g_jrt_scan_file_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_scan_file_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_scan_file_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_scan_file_A_class }

func (t *A_arbace_a2g_jrt_scan_file_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_scan_file_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_scan_file_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_scan_file_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_scan_file_A); return ok }

func A_arbace_a2g_jrt_scan_file_A_Cast(x any) *A_arbace_a2g_jrt_scan_file_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_scan_file_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_scan_file_A_class)) }; return v }



type A_arbace_a2g_jrt_strip_doc_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_strip_doc_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_strip_doc_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_strip_doc_A_init jrt.ClassInit

func A_arbace_a2g_jrt_strip_doc_A_Init() { if !A_arbace_a2g_jrt_strip_doc_A_init.Done() { A_arbace_a2g_jrt_strip_doc_A_init.Run(A_arbace_a2g_jrt_strip_doc_A_clinit) } }

func A_arbace_a2g_jrt_strip_doc_A_clinit() { A_arbace_a2g_jrt_strip_doc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_154, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_strip_doc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_strip_doc_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_strip_doc_A_class }

func (t *A_arbace_a2g_jrt_strip_doc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_strip_doc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_strip_doc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_strip_doc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_strip_doc_A); return ok }

func A_arbace_a2g_jrt_strip_doc_A_Cast(x any) *A_arbace_a2g_jrt_strip_doc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_strip_doc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_strip_doc_A_class)) }; return v }



type A_arbace_a2g_jrt_struct_embed_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_struct_embed_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_struct_embed_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_struct_embed_A_init jrt.ClassInit

func A_arbace_a2g_jrt_struct_embed_A_Init() { if !A_arbace_a2g_jrt_struct_embed_A_init.Done() { A_arbace_a2g_jrt_struct_embed_A_init.Run(A_arbace_a2g_jrt_struct_embed_A_clinit) } }

func A_arbace_a2g_jrt_struct_embed_A_clinit() { A_arbace_a2g_jrt_struct_embed_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_struct_embed_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_struct_embed_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_struct_embed_A_class }

func (t *A_arbace_a2g_jrt_struct_embed_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_struct_embed_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_struct_embed_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_struct_embed_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_struct_embed_A); return ok }

func A_arbace_a2g_jrt_struct_embed_A_Cast(x any) *A_arbace_a2g_jrt_struct_embed_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_struct_embed_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_struct_embed_A_class)) }; return v }



type A_arbace_a2g_jrt_struct_methods_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_struct_methods_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_jrt_struct_methods_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_struct_methods_A_init jrt.ClassInit

func A_arbace_a2g_jrt_struct_methods_A_Init() { if !A_arbace_a2g_jrt_struct_methods_A_init.Done() { A_arbace_a2g_jrt_struct_methods_A_init.Run(A_arbace_a2g_jrt_struct_methods_A_clinit) } }

func A_arbace_a2g_jrt_struct_methods_A_clinit() { A_arbace_a2g_jrt_struct_methods_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_156, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_struct_methods_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_struct_methods_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_struct_methods_A_class }

func (t *A_arbace_a2g_jrt_struct_methods_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_struct_methods_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_struct_methods_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_struct_methods_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_struct_methods_A); return ok }

func A_arbace_a2g_jrt_struct_methods_A_Cast(x any) *A_arbace_a2g_jrt_struct_methods_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_struct_methods_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_struct_methods_A_class)) }; return v }



type A_arbace_a2g_jrt_tag_of_A struct{ jrt.Object }

func (t *A_arbace_a2g_jrt_tag_of_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_jrt_tag_of_A_fn_class *jrt.Class

var A_arbace_a2g_jrt_tag_of_A_init jrt.ClassInit

func A_arbace_a2g_jrt_tag_of_A_Init() { if !A_arbace_a2g_jrt_tag_of_A_init.Done() { A_arbace_a2g_jrt_tag_of_A_init.Run(A_arbace_a2g_jrt_tag_of_A_clinit) } }

func A_arbace_a2g_jrt_tag_of_A_clinit() { A_arbace_a2g_jrt_tag_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_jrt_tag_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_jrt_tag_of_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_jrt_tag_of_A_class }

func (t *A_arbace_a2g_jrt_tag_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_jrt_tag_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_jrt_tag_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_jrt_tag_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_jrt_tag_of_A); return ok }

func A_arbace_a2g_jrt_tag_of_A_Cast(x any) *A_arbace_a2g_jrt_tag_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_jrt_tag_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_jrt_tag_of_A_class)) }; return v }
