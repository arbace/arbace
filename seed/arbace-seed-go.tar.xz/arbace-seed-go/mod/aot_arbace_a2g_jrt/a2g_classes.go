//line a2g_classes.ae:1
package aot_arbace_a2g_jrt

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_a2g_jrt_define_name_A_class, Name: "arbace.a2g.jrt$define_name", Modifiers: 25, Simple: "define_name", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_define_name_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_define_name_walk__1261000019_A_class, Name: "arbace.a2g.jrt$define_name$walk__1261000019", Modifiers: 25, Simple: "walk__1261000019", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_define_name_walk__1261000019_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_define_name_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_class, Name: "arbace.a2g.jrt$eval1261000004$loading__1927001464__auto____1261000005", Modifiers: 25, Simple: "loading__1927001464__auto____1261000005", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_eval1261000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_class, Name: "arbace.a2g.jrt$eval1261000008$fn__1261000009", Modifiers: 25, Simple: "fn__1261000009", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_eval1261000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_go_head_A_class, Name: "arbace.a2g.jrt$go_head", Modifiers: 25, Simple: "go_head", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_go_head_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_head_A_class, Name: "arbace.a2g.jrt$head", Modifiers: 25, Simple: "head", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_head_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_iface_methods_A_class, Name: "arbace.a2g.jrt$iface_methods", Modifiers: 25, Simple: "iface_methods", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_iface_methods_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_class, Name: "arbace.a2g.jrt$iface_methods$fn__1261000268", Modifiers: 25, Simple: "fn__1261000268", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_iface_methods_fn__1261000268_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_iface_methods_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_interface_elems_A_class, Name: "arbace.a2g.jrt$interface_elems", Modifiers: 25, Simple: "interface_elems", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_class, Name: "arbace.a2g.jrt$interface_elems$iter__1261000161__1261000165", Modifiers: 25, Simple: "iter__1261000161__1261000165", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_interface_elems_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_class, Name: "arbace.a2g.jrt$interface_elems$iter__1261000161__1261000165$fn__1261000166", Modifiers: 25, Simple: "fn__1261000166", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_class, Name: "arbace.a2g.jrt$interface_elems$iter__1261000161__1261000165$fn__1261000166$fn__1261000167", Modifiers: 25, Simple: "fn__1261000167", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_class, Name: "arbace.a2g.jrt$interface_elems$iter__1261000171__1261000175", Modifiers: 25, Simple: "iter__1261000171__1261000175", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_interface_elems_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_class, Name: "arbace.a2g.jrt$interface_elems$iter__1261000171__1261000175$fn__1261000176", Modifiers: 25, Simple: "fn__1261000176", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_class, Name: "arbace.a2g.jrt$interface_elems$iter__1261000171__1261000175$fn__1261000176$fn__1261000177", Modifiers: 25, Simple: "fn__1261000177", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_other_system_QMARK__A_class, Name: "arbace.a2g.jrt$other_system_QMARK_", Modifiers: 25, Simple: "other_system_QMARK_", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_other_system_QMARK__A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_recv_type_A_class, Name: "arbace.a2g.jrt$recv_type", Modifiers: 25, Simple: "recv_type", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_recv_type_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_recv_type_nm__1261000015_A_class, Name: "arbace.a2g.jrt$recv_type$nm__1261000015", Modifiers: 25, Simple: "nm__1261000015", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_recv_type_nm__1261000015_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_recv_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_A_class, Name: "arbace.a2g.jrt$scan", Modifiers: 25, Simple: "scan", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_fn__1261000186_A_class, Name: "arbace.a2g.jrt$scan$fn__1261000186", Modifiers: 25, Simple: "fn__1261000186", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_fn__1261000186_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_fn__1261000188_A_class, Name: "arbace.a2g.jrt$scan$fn__1261000188", Modifiers: 25, Simple: "fn__1261000188", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_fn__1261000188_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000190__1261000194", Modifiers: 25, Simple: "iter__1261000190__1261000194", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000190__1261000194$fn__1261000195", Modifiers: 25, Simple: "fn__1261000195", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000190__1261000194$fn__1261000195$fn__1261000196", Modifiers: 25, Simple: "fn__1261000196", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206", Modifiers: 25, Simple: "iter__1261000200__1261000206", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207", Modifiers: 25, Simple: "fn__1261000207", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207$iter__1261000202__1261000211", Modifiers: 25, Simple: "iter__1261000202__1261000211", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207$iter__1261000202__1261000211$fn__1261000212", Modifiers: 25, Simple: "fn__1261000212", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207$iter__1261000202__1261000211$fn__1261000212$fn__1261000213", Modifiers: 25, Simple: "fn__1261000213", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000225__1261000229", Modifiers: 25, Simple: "iter__1261000225__1261000229", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000225__1261000229$fn__1261000230", Modifiers: 25, Simple: "fn__1261000230", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000225__1261000229$fn__1261000230$fn__1261000231", Modifiers: 25, Simple: "fn__1261000231", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000245__1261000249", Modifiers: 25, Simple: "iter__1261000245__1261000249", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000245__1261000249$fn__1261000250", Modifiers: 25, Simple: "fn__1261000250", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_class, Name: "arbace.a2g.jrt$scan$iter__1261000245__1261000249$fn__1261000250$fn__1261000251", Modifiers: 25, Simple: "fn__1261000251", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_scan_file_A_class, Name: "arbace.a2g.jrt$scan_file", Modifiers: 25, Simple: "scan_file", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_file_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_strip_doc_A_class, Name: "arbace.a2g.jrt$strip_doc", Modifiers: 25, Simple: "strip_doc", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_strip_doc_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_struct_embed_A_class, Name: "arbace.a2g.jrt$struct_embed", Modifiers: 25, Simple: "struct_embed", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_struct_embed_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_struct_methods_A_class, Name: "arbace.a2g.jrt$struct_methods", Modifiers: 25, Simple: "struct_methods", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_struct_methods_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_a2g_jrt_tag_of_A_class, Name: "arbace.a2g.jrt$tag_of", Modifiers: 25, Simple: "tag_of", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_tag_of_A", Source: "jrt.ae", Declaring: &A_arbace_a2g_jrt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_a2g_jrt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_A_New()}; return nil }

var A_arbace_a2g_jrt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_jrt_A_new}

var A_arbace_a2g_jrt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_A"})

func init() { i := A_arbace_a2g_jrt_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_A_InstanceOf; i.Init = A_arbace_a2g_jrt_A_Init; i.Table = A_arbace_a2g_jrt_A_members }

var A_arbace_a2g_jrt_define_name_A_class *jrt.Class

var A_arbace_a2g_jrt_define_name_walk__1261000019_A_class *jrt.Class

func A_arbace_a2g_jrt_eval1261000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_eval1261000004_A_New()}; return nil }

var A_arbace_a2g_jrt_eval1261000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_jrt_eval1261000004_A_new}

var A_arbace_a2g_jrt_eval1261000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$eval1261000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_jrt_A_class, Simple: "eval1261000004", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_eval1261000004_A"})

func init() { i := A_arbace_a2g_jrt_eval1261000004_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_eval1261000004_A_InstanceOf; i.Table = A_arbace_a2g_jrt_eval1261000004_A_members }

var A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_class *jrt.Class

func A_arbace_a2g_jrt_eval1261000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_eval1261000008_A_New()}; return nil }

var A_arbace_a2g_jrt_eval1261000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_jrt_eval1261000008_A_new}

var A_arbace_a2g_jrt_eval1261000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$eval1261000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_jrt_A_class, Simple: "eval1261000008", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_eval1261000008_A"})

func init() { i := A_arbace_a2g_jrt_eval1261000008_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_eval1261000008_A_InstanceOf; i.Table = A_arbace_a2g_jrt_eval1261000008_A_members }

var A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_class *jrt.Class

var A_arbace_a2g_jrt_go_head_A_class *jrt.Class

var A_arbace_a2g_jrt_head_A_class *jrt.Class

var A_arbace_a2g_jrt_iface_methods_A_class *jrt.Class

var A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_A_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_class *jrt.Class

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_class *jrt.Class

var A_arbace_a2g_jrt_other_system_QMARK__A_class *jrt.Class

var A_arbace_a2g_jrt_recv_type_A_class *jrt.Class

var A_arbace_a2g_jrt_recv_type_nm__1261000015_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_fn__1261000186_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_fn__1261000188_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_class *jrt.Class

var A_arbace_a2g_jrt_scan_file_A_class *jrt.Class

var A_arbace_a2g_jrt_strip_doc_A_class *jrt.Class

var A_arbace_a2g_jrt_struct_embed_A_class *jrt.Class

var A_arbace_a2g_jrt_struct_methods_A_class *jrt.Class

var A_arbace_a2g_jrt_tag_of_A_class *jrt.Class

func A_arbace_a2g_jrt__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_jrt__init_A_Load__O()}; return nil }

func A_arbace_a2g_jrt__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt__init_A_New()}; return nil }

var A_arbace_a2g_jrt__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_jrt__init_A_invoke, New: A_arbace_a2g_jrt__init_A_new}

var A_arbace_a2g_jrt__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt__init_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt__init_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt__init_A_InstanceOf; i.Init = A_arbace_a2g_jrt__init_A_Init; i.Table = A_arbace_a2g_jrt__init_A_members }
