//line a2g_classes.ae:1
package aot_arbace_a2g_jrt

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_jrt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_A_New()}; return nil }

var A_arbace_a2g_jrt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_jrt_A_new}

var A_arbace_a2g_jrt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_A"})

func init() { i := A_arbace_a2g_jrt_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_A_InstanceOf; i.Init = A_arbace_a2g_jrt_A_Init; i.Table = A_arbace_a2g_jrt_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_A_class, reflect.TypeFor[A_arbace_a2g_jrt_A]()) }

func A_arbace_a2g_jrt_define_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_define_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_define_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_define_name_A_New()}; return nil }

func A_arbace_a2g_jrt_define_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_define_name_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_define_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_define_name_A_invoke, New: A_arbace_a2g_jrt_define_name_A_new, Get: A_arbace_a2g_jrt_define_name_A_get}

var A_arbace_a2g_jrt_define_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$define_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "define_name", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_define_name_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_define_name_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_define_name_A_InstanceOf; i.Init = A_arbace_a2g_jrt_define_name_A_Init; i.Table = A_arbace_a2g_jrt_define_name_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_define_name_A_class, reflect.TypeFor[A_arbace_a2g_jrt_define_name_A]()) }

func A_arbace_a2g_jrt_define_name_walk__1261000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_define_name_walk__1261000019_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_define_name_walk__1261000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_define_name_walk__1261000019_A_New_O(args[0])}; return nil }

func A_arbace_a2g_jrt_define_name_walk__1261000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_define_name_walk__1261000019_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_define_name_walk__1261000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_define_name_walk__1261000019_A_invoke, New: A_arbace_a2g_jrt_define_name_walk__1261000019_A_new, Get: A_arbace_a2g_jrt_define_name_walk__1261000019_A_get}

var A_arbace_a2g_jrt_define_name_walk__1261000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$define_name$walk__1261000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_define_name_A_class, Simple: "walk__1261000019", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_define_name_walk__1261000019_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_define_name_walk__1261000019_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_define_name_walk__1261000019_A_InstanceOf; i.Init = A_arbace_a2g_jrt_define_name_walk__1261000019_A_Init; i.Table = A_arbace_a2g_jrt_define_name_walk__1261000019_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_define_name_walk__1261000019_A_class, reflect.TypeFor[A_arbace_a2g_jrt_define_name_walk__1261000019_A]()) }

func A_arbace_a2g_jrt_eval1261000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_eval1261000004_A_New()}; return nil }

var A_arbace_a2g_jrt_eval1261000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_jrt_eval1261000004_A_new}

var A_arbace_a2g_jrt_eval1261000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$eval1261000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_jrt_A_class, Simple: "eval1261000004", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_eval1261000004_A"})

func init() { i := A_arbace_a2g_jrt_eval1261000004_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_eval1261000004_A_InstanceOf; i.Table = A_arbace_a2g_jrt_eval1261000004_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_eval1261000004_A_class, reflect.TypeFor[A_arbace_a2g_jrt_eval1261000004_A]()) }

func A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_New()}; return nil }

func A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_invoke, New: A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_new, Get: A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_get}

var A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$eval1261000004$loading__1927001464__auto____1261000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_eval1261000004_A_class, Simple: "loading__1927001464__auto____1261000005", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_InstanceOf; i.Init = A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_Init; i.Table = A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A_class, reflect.TypeFor[A_arbace_a2g_jrt_eval1261000004_loading__1927001464__auto____1261000005_A]()) }

func A_arbace_a2g_jrt_eval1261000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_eval1261000008_A_New()}; return nil }

var A_arbace_a2g_jrt_eval1261000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_jrt_eval1261000008_A_new}

var A_arbace_a2g_jrt_eval1261000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$eval1261000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_jrt_A_class, Simple: "eval1261000008", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_eval1261000008_A"})

func init() { i := A_arbace_a2g_jrt_eval1261000008_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_eval1261000008_A_InstanceOf; i.Table = A_arbace_a2g_jrt_eval1261000008_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_eval1261000008_A_class, reflect.TypeFor[A_arbace_a2g_jrt_eval1261000008_A]()) }

func A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_New()}; return nil }

func A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_invoke, New: A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_new, Get: A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_get}

var A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$eval1261000008$fn__1261000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_eval1261000008_A_class, Simple: "fn__1261000009", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_InstanceOf; i.Init = A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_Init; i.Table = A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A_class, reflect.TypeFor[A_arbace_a2g_jrt_eval1261000008_fn__1261000009_A]()) }

func A_arbace_a2g_jrt_go_head_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_go_head_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_go_head_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_go_head_A_New()}; return nil }

func A_arbace_a2g_jrt_go_head_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_go_head_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_go_head_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_go_head_A_invoke, New: A_arbace_a2g_jrt_go_head_A_new, Get: A_arbace_a2g_jrt_go_head_A_get}

var A_arbace_a2g_jrt_go_head_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$go_head", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "go_head", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_go_head_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_go_head_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_go_head_A_InstanceOf; i.Init = A_arbace_a2g_jrt_go_head_A_Init; i.Table = A_arbace_a2g_jrt_go_head_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_go_head_A_class, reflect.TypeFor[A_arbace_a2g_jrt_go_head_A]()) }

func A_arbace_a2g_jrt_head_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_head_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_head_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_head_A_New()}; return nil }

func A_arbace_a2g_jrt_head_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_head_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_head_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_head_A_invoke, New: A_arbace_a2g_jrt_head_A_new, Get: A_arbace_a2g_jrt_head_A_get}

var A_arbace_a2g_jrt_head_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$head", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "head", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_head_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_head_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_head_A_InstanceOf; i.Init = A_arbace_a2g_jrt_head_A_Init; i.Table = A_arbace_a2g_jrt_head_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_head_A_class, reflect.TypeFor[A_arbace_a2g_jrt_head_A]()) }

func A_arbace_a2g_jrt_iface_methods_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_iface_methods_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_jrt_iface_methods_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_iface_methods_A_New()}; return nil }

func A_arbace_a2g_jrt_iface_methods_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_iface_methods_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_iface_methods_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_iface_methods_A_invoke, New: A_arbace_a2g_jrt_iface_methods_A_new, Get: A_arbace_a2g_jrt_iface_methods_A_get}

var A_arbace_a2g_jrt_iface_methods_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$iface_methods", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "iface_methods", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_iface_methods_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_iface_methods_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_iface_methods_A_InstanceOf; i.Init = A_arbace_a2g_jrt_iface_methods_A_Init; i.Table = A_arbace_a2g_jrt_iface_methods_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_iface_methods_A_class, reflect.TypeFor[A_arbace_a2g_jrt_iface_methods_A]()) }

func A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_iface_methods_fn__1261000268_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_New_O(args[0])}; return nil }

func A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_invoke, New: A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_new, Get: A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_get}

var A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$iface_methods$fn__1261000268", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_iface_methods_A_class, Simple: "fn__1261000268", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_iface_methods_fn__1261000268_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_InstanceOf; i.Init = A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_Init; i.Table = A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_iface_methods_fn__1261000268_A_class, reflect.TypeFor[A_arbace_a2g_jrt_iface_methods_fn__1261000268_A]()) }

func A_arbace_a2g_jrt_interface_elems_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_interface_elems_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_interface_elems_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_interface_elems_A_New()}; return nil }

func A_arbace_a2g_jrt_interface_elems_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_interface_elems_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_interface_elems_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_interface_elems_A_invoke, New: A_arbace_a2g_jrt_interface_elems_A_new, Get: A_arbace_a2g_jrt_interface_elems_A_get}

var A_arbace_a2g_jrt_interface_elems_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$interface_elems", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "interface_elems", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_interface_elems_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_interface_elems_A_InstanceOf; i.Init = A_arbace_a2g_jrt_interface_elems_A_Init; i.Table = A_arbace_a2g_jrt_interface_elems_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_interface_elems_A_class, reflect.TypeFor[A_arbace_a2g_jrt_interface_elems_A]()) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_New()}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_invoke, New: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_new, Get: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_get}

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$interface_elems$iter__1261000161__1261000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_interface_elems_A_class, Simple: "iter__1261000161__1261000165", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_InstanceOf; i.Init = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_Init; i.Table = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_class, reflect.TypeFor[A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A]()) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_invoke, New: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_new, Get: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_get}

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$interface_elems$iter__1261000161__1261000165$fn__1261000166", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_A_class, Simple: "fn__1261000166", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_InstanceOf; i.Init = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_Init; i.Table = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_class, reflect.TypeFor[A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A]()) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_invoke, New: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_new, Get: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_get}

var A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$interface_elems$iter__1261000161__1261000165$fn__1261000166$fn__1261000167", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_A_class, Simple: "fn__1261000167", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_InstanceOf; i.Init = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_Init; i.Table = A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A_class, reflect.TypeFor[A_arbace_a2g_jrt_interface_elems_iter__1261000161__1261000165_fn__1261000166_fn__1261000167_A]()) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_New()}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_invoke, New: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_new, Get: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_get}

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$interface_elems$iter__1261000171__1261000175", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_interface_elems_A_class, Simple: "iter__1261000171__1261000175", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_InstanceOf; i.Init = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_Init; i.Table = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_class, reflect.TypeFor[A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A]()) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_invoke, New: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_new, Get: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_get}

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$interface_elems$iter__1261000171__1261000175$fn__1261000176", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_A_class, Simple: "fn__1261000176", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_InstanceOf; i.Init = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_Init; i.Table = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_class, reflect.TypeFor[A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A]()) }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_invoke, New: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_new, Get: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_get}

var A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$interface_elems$iter__1261000171__1261000175$fn__1261000176$fn__1261000177", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_A_class, Simple: "fn__1261000177", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_InstanceOf; i.Init = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_Init; i.Table = A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A_class, reflect.TypeFor[A_arbace_a2g_jrt_interface_elems_iter__1261000171__1261000175_fn__1261000176_fn__1261000177_A]()) }

func A_arbace_a2g_jrt_other_system_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_other_system_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_other_system_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_other_system_QMARK__A_New()}; return nil }

func A_arbace_a2g_jrt_other_system_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_other_system_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_jrt_other_system_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_other_system_QMARK__A_invoke, New: A_arbace_a2g_jrt_other_system_QMARK__A_new, Get: A_arbace_a2g_jrt_other_system_QMARK__A_get}

var A_arbace_a2g_jrt_other_system_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$other_system_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "other_system_QMARK_", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_other_system_QMARK__A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_other_system_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_other_system_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_jrt_other_system_QMARK__A_Init; i.Table = A_arbace_a2g_jrt_other_system_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_other_system_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_jrt_other_system_QMARK__A]()) }

func A_arbace_a2g_jrt_recv_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_recv_type_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_recv_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_recv_type_A_New()}; return nil }

func A_arbace_a2g_jrt_recv_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_recv_type_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_recv_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_recv_type_A_invoke, New: A_arbace_a2g_jrt_recv_type_A_new, Get: A_arbace_a2g_jrt_recv_type_A_get}

var A_arbace_a2g_jrt_recv_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$recv_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "recv_type", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_recv_type_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_recv_type_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_recv_type_A_InstanceOf; i.Init = A_arbace_a2g_jrt_recv_type_A_Init; i.Table = A_arbace_a2g_jrt_recv_type_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_recv_type_A_class, reflect.TypeFor[A_arbace_a2g_jrt_recv_type_A]()) }

func A_arbace_a2g_jrt_recv_type_nm__1261000015_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_recv_type_nm__1261000015_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_recv_type_nm__1261000015_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_recv_type_nm__1261000015_A_New()}; return nil }

func A_arbace_a2g_jrt_recv_type_nm__1261000015_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_recv_type_nm__1261000015_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_recv_type_nm__1261000015_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_recv_type_nm__1261000015_A_invoke, New: A_arbace_a2g_jrt_recv_type_nm__1261000015_A_new, Get: A_arbace_a2g_jrt_recv_type_nm__1261000015_A_get}

var A_arbace_a2g_jrt_recv_type_nm__1261000015_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$recv_type$nm__1261000015", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_recv_type_A_class, Simple: "nm__1261000015", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_recv_type_nm__1261000015_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_recv_type_nm__1261000015_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_recv_type_nm__1261000015_A_InstanceOf; i.Init = A_arbace_a2g_jrt_recv_type_nm__1261000015_A_Init; i.Table = A_arbace_a2g_jrt_recv_type_nm__1261000015_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_recv_type_nm__1261000015_A_class, reflect.TypeFor[A_arbace_a2g_jrt_recv_type_nm__1261000015_A]()) }

func A_arbace_a2g_jrt_scan_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_A_New()}; return nil }

func A_arbace_a2g_jrt_scan_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_A_invoke, New: A_arbace_a2g_jrt_scan_A_new, Get: A_arbace_a2g_jrt_scan_A_get}

var A_arbace_a2g_jrt_scan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "scan", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_A_Init; i.Table = A_arbace_a2g_jrt_scan_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_A]()) }

func A_arbace_a2g_jrt_scan_fn__1261000186_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_fn__1261000186_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_fn__1261000186_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_fn__1261000186_A_New()}; return nil }

func A_arbace_a2g_jrt_scan_fn__1261000186_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_fn__1261000186_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_fn__1261000186_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_fn__1261000186_A_invoke, New: A_arbace_a2g_jrt_scan_fn__1261000186_A_new, Get: A_arbace_a2g_jrt_scan_fn__1261000186_A_get}

var A_arbace_a2g_jrt_scan_fn__1261000186_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$fn__1261000186", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_scan_A_class, Simple: "fn__1261000186", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_fn__1261000186_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_fn__1261000186_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_fn__1261000186_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_fn__1261000186_A_Init; i.Table = A_arbace_a2g_jrt_scan_fn__1261000186_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_fn__1261000186_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_fn__1261000186_A]()) }

func A_arbace_a2g_jrt_scan_fn__1261000188_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_fn__1261000188_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_fn__1261000188_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_fn__1261000188_A_New()}; return nil }

func A_arbace_a2g_jrt_scan_fn__1261000188_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_fn__1261000188_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_fn__1261000188_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_fn__1261000188_A_invoke, New: A_arbace_a2g_jrt_scan_fn__1261000188_A_new, Get: A_arbace_a2g_jrt_scan_fn__1261000188_A_get}

var A_arbace_a2g_jrt_scan_fn__1261000188_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$fn__1261000188", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_scan_A_class, Simple: "fn__1261000188", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_fn__1261000188_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_fn__1261000188_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_fn__1261000188_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_fn__1261000188_A_Init; i.Table = A_arbace_a2g_jrt_scan_fn__1261000188_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_fn__1261000188_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_fn__1261000188_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_New()}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000190__1261000194", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_scan_A_class, Simple: "iter__1261000190__1261000194", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000190__1261000194$fn__1261000195", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_A_class, Simple: "fn__1261000195", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000190__1261000194$fn__1261000195$fn__1261000196", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_A_class, Simple: "fn__1261000196", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000190__1261000194_fn__1261000195_fn__1261000196_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_New()}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_scan_A_class, Simple: "iter__1261000200__1261000206", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_A_class, Simple: "fn__1261000207", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_New_O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207$iter__1261000202__1261000211", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_A_class, Simple: "iter__1261000202__1261000211", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207$iter__1261000202__1261000211$fn__1261000212", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_A_class, Simple: "fn__1261000212", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000200__1261000206$fn__1261000207$iter__1261000202__1261000211$fn__1261000212$fn__1261000213", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_A_class, Simple: "fn__1261000213", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000200__1261000206_fn__1261000207_iter__1261000202__1261000211_fn__1261000212_fn__1261000213_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_New()}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000225__1261000229", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_scan_A_class, Simple: "iter__1261000225__1261000229", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000225__1261000229$fn__1261000230", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_A_class, Simple: "fn__1261000230", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000225__1261000229$fn__1261000230$fn__1261000231", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_A_class, Simple: "fn__1261000231", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000225__1261000229_fn__1261000230_fn__1261000231_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_New()}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000245__1261000249", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_scan_A_class, Simple: "iter__1261000245__1261000249", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000245__1261000249$fn__1261000250", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_A_class, Simple: "fn__1261000250", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A]()) }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_invoke, New: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_new, Get: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_get}

var A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan$iter__1261000245__1261000249$fn__1261000250$fn__1261000251", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_A_class, Simple: "fn__1261000251", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_Init; i.Table = A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_iter__1261000245__1261000249_fn__1261000250_fn__1261000251_A]()) }

func A_arbace_a2g_jrt_scan_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_scan_file_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_scan_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_scan_file_A_New()}; return nil }

func A_arbace_a2g_jrt_scan_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_scan_file_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_scan_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_scan_file_A_invoke, New: A_arbace_a2g_jrt_scan_file_A_new, Get: A_arbace_a2g_jrt_scan_file_A_get}

var A_arbace_a2g_jrt_scan_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$scan_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "scan_file", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_scan_file_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_scan_file_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_scan_file_A_InstanceOf; i.Init = A_arbace_a2g_jrt_scan_file_A_Init; i.Table = A_arbace_a2g_jrt_scan_file_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_scan_file_A_class, reflect.TypeFor[A_arbace_a2g_jrt_scan_file_A]()) }

func A_arbace_a2g_jrt_strip_doc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_strip_doc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_strip_doc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_strip_doc_A_New()}; return nil }

func A_arbace_a2g_jrt_strip_doc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_strip_doc_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_strip_doc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_strip_doc_A_invoke, New: A_arbace_a2g_jrt_strip_doc_A_new, Get: A_arbace_a2g_jrt_strip_doc_A_get}

var A_arbace_a2g_jrt_strip_doc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$strip_doc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "strip_doc", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_strip_doc_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_strip_doc_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_strip_doc_A_InstanceOf; i.Init = A_arbace_a2g_jrt_strip_doc_A_Init; i.Table = A_arbace_a2g_jrt_strip_doc_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_strip_doc_A_class, reflect.TypeFor[A_arbace_a2g_jrt_strip_doc_A]()) }

func A_arbace_a2g_jrt_struct_embed_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_struct_embed_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_struct_embed_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_struct_embed_A_New()}; return nil }

func A_arbace_a2g_jrt_struct_embed_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_struct_embed_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_struct_embed_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_struct_embed_A_invoke, New: A_arbace_a2g_jrt_struct_embed_A_new, Get: A_arbace_a2g_jrt_struct_embed_A_get}

var A_arbace_a2g_jrt_struct_embed_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$struct_embed", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "struct_embed", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_struct_embed_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_struct_embed_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_struct_embed_A_InstanceOf; i.Init = A_arbace_a2g_jrt_struct_embed_A_Init; i.Table = A_arbace_a2g_jrt_struct_embed_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_struct_embed_A_class, reflect.TypeFor[A_arbace_a2g_jrt_struct_embed_A]()) }

func A_arbace_a2g_jrt_struct_methods_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_struct_methods_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_jrt_struct_methods_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_struct_methods_A_New()}; return nil }

func A_arbace_a2g_jrt_struct_methods_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_struct_methods_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_struct_methods_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_struct_methods_A_invoke, New: A_arbace_a2g_jrt_struct_methods_A_new, Get: A_arbace_a2g_jrt_struct_methods_A_get}

var A_arbace_a2g_jrt_struct_methods_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$struct_methods", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "struct_methods", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_struct_methods_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_struct_methods_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_struct_methods_A_InstanceOf; i.Init = A_arbace_a2g_jrt_struct_methods_A_Init; i.Table = A_arbace_a2g_jrt_struct_methods_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_struct_methods_A_class, reflect.TypeFor[A_arbace_a2g_jrt_struct_methods_A]()) }

func A_arbace_a2g_jrt_tag_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_jrt_tag_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_jrt_tag_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt_tag_of_A_New()}; return nil }

func A_arbace_a2g_jrt_tag_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_jrt_tag_of_A_fn_class)}; return nil }

var A_arbace_a2g_jrt_tag_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_jrt_tag_of_A_invoke, New: A_arbace_a2g_jrt_tag_of_A_new, Get: A_arbace_a2g_jrt_tag_of_A_get}

var A_arbace_a2g_jrt_tag_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt$tag_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_jrt_A_class, Simple: "tag_of", Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt_tag_of_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt_tag_of_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt_tag_of_A_InstanceOf; i.Init = A_arbace_a2g_jrt_tag_of_A_Init; i.Table = A_arbace_a2g_jrt_tag_of_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt_tag_of_A_class, reflect.TypeFor[A_arbace_a2g_jrt_tag_of_A]()) }

func A_arbace_a2g_jrt__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_jrt__init_A_Load__O(); case 1: return A_arbace_a2g_jrt__init_A_Unit0__O(); case 2: return A_arbace_a2g_jrt__init_A_Unit1__O(); case 3: return A_arbace_a2g_jrt__init_A_Unit10__O(); case 4: return A_arbace_a2g_jrt__init_A_Unit11__O(); case 5: return A_arbace_a2g_jrt__init_A_Unit12__O(); case 6: return A_arbace_a2g_jrt__init_A_Unit13__O(); case 7: return A_arbace_a2g_jrt__init_A_Unit14__O(); case 8: return A_arbace_a2g_jrt__init_A_Unit15__O(); case 9: return A_arbace_a2g_jrt__init_A_Unit16__O(); case 10: return A_arbace_a2g_jrt__init_A_Unit2__O(); case 11: return A_arbace_a2g_jrt__init_A_Unit3__O(); case 12: return A_arbace_a2g_jrt__init_A_Unit4__O(); case 13: return A_arbace_a2g_jrt__init_A_Unit5__O(); case 14: return A_arbace_a2g_jrt__init_A_Unit6__O(); case 15: return A_arbace_a2g_jrt__init_A_Unit7__O(); case 16: return A_arbace_a2g_jrt__init_A_Unit8__O(); case 17: return A_arbace_a2g_jrt__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_jrt__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_jrt__init_A_New()}; return nil }

var A_arbace_a2g_jrt__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_jrt__init_A_invoke, New: A_arbace_a2g_jrt__init_A_new}

var A_arbace_a2g_jrt__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.jrt__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_jrt.A_arbace_a2g_jrt__init_A", Source: "jrt.ae"})

func init() { i := A_arbace_a2g_jrt__init_A_class.Info(); i.IsInstance = A_arbace_a2g_jrt__init_A_InstanceOf; i.Init = A_arbace_a2g_jrt__init_A_Init; i.Table = A_arbace_a2g_jrt__init_A_members; jrt.RegisterGoType(A_arbace_a2g_jrt__init_A_class, reflect.TypeFor[A_arbace_a2g_jrt__init_A]()) }
