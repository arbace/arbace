//line j2g_strings.ae:1
package aot_arbace_j2g_code

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn17,arbace.j2g.accessyn3,accyn13,arbace.j2g.vhyn2,vhyn11,arbace.corekn3,dockn4,desckn5,flagskn5,classkn6,clinitkn4,ctorkn4,synckn11,locked-thiskn4,namekn11,method-nameks15,arbace.j2g.code4,failkn3,pkgkn3,tagkn7,counterkn5,takenkn3,tmpkn4,usedkn5,nameskn2,idkn3,symks3,j2g4,linekn3,letyn4,zeroyn1,_yn4,set!yn3,letkn4,typekn4,nullkn4,elseyn4,convyn3,anyyn4,.Refkn3,upskn4,noneyn4,instkn1,xkn1,tkn2,opkn2,orkn3,andkn10,method-refkn5,boundkn4,kindkn10,set-statickn10,get-statickn5,fieldkn8,declarerkn5,ownerkn6,statickn6,simplekn6,lambdakn4,recvkn6,targetkn4,exprkn3,valkn5,arraykn5,indexkn4,basekn4,argskn5,elemskn4,dimskn4,nodekn5,partskn7,effectskn7,alengthkn7,convertkn9,get-fieldkn5,arithkn4,agetkn9,this-pathkn4,fromkn3,remkn3,divkn1,okn3,newkn10,var-invokekn6,invokekn8,java-strkn9,var-derefkn9,class-litkn5,constkn5,localkn7,mutablekn1,bkn4,pureyn2,fnyn6,returnyn5,int32kn7,missingkn2,nnkn4,litskn10,lit-prefixyn4,boolkn5,statekn15,analysis-failedkn5,funcskn3,jrtkn7,handleskn2,vhkn3,getkn3,caskn4,swapkn3,addkn3,setkn3,xorkn7,cmpxchgks15,arbace.j2g.code5,vh-okkn4,viewkn4,modekn4,varskn6,constskn4,castkn9,instance?kn6,bigintkn6,methodkn11,array-clonekn9,new-arraykn9,set-fieldkn10,array-initkn2,fikn10,fi-adapterkn4,thiskn4,pathkn11,outer-paramkn5,outerkn8,capturedkn6,fieldsyn5,.Loadyn4,int8yn6,uint16ys4,math15,Float64frombitsys4,math15,Float32frombitsyn5,int16yn6,.Storeys4,math11,Float64bitsys4,math11,Float32bitskn3,ptryn11,.ArrayClasskn4,cutskn3,varks15,arbace.j2g.code2,gokn12,null-checkedyn9,.Deref__Oyn3,andyn2,orkn7,comparekn3,cmpkn4,nil?yn2,==kn10,identical?kn3,notyn3,notkn16,outer-param-pathkn5,bool=yn3,lenyn3,.-Aks3,c2j2,nnkn4,metakn6,memberyn4,agetyn2,!=kn6,familykn4,ushrkn3,shrkn3,shlyn7,bit-andyn1,*kn5,exactkn3,mulkn3,subkn3,decyn1,/kn3,incyn1,%yn7,float32ys4,math3,Modyn7,float64yn5,int64yn2,>>yn6,uint64yn6,uint32yn1,-yn7,bit-notyn6,bit-oryn1,+yn7,bit-xorkn3,negkn6,andnotyn11,bit-and-notyn2,<<kn2,toyn6,assertkn8,instanceyn16,.IsInstance_O__Zkn5,superkn4,boolkn3,i32kn6,narrowkn3,i64kn3,f32kn3,f64kn3,volyn4,addryn14,.CompareAndSetyn15,.CompareAndSwapyn5,.Swapkn5,orderyn5,.Copykn7,cast-tokn7,specialkn11,outer-superkn15,outer-instance?kn11,super-outerkn10,enum-constkn4,anonkn7,ordinalkn7,nestingkn8,captureskn4,holekn3,strkn3,arryn3,lityn5,slicekn7,literalkn9,tag-constkn7,targetskn9,try-framekn5,codeskn2,rvkn7,rv-zerokn4,codekn5,fn-idkn9,method-fnkn6,returnks15,arbace.j2g.code4,voidkn4,linekn5,breakkn1,kkn4,stmtkn6,assertkn3,trykn2,ifkn9,ctor-callkn12,ctor-call-fnkn4,asetyn4,asetkn5,labelkn11,if-instancekn8,for-eachkn6,switchkn4,loopkn7,monitorkn4,bodykn5,recurkn8,bindingskn4,cvalkn9,set-localkn2,dokn3,retyn4,whenkn10,statementskn5,throwyn5,panickn10,method-retkn6,assignkn4,jumpkn4,testkn3,msgkn8,msg-desckn3,ctxyn5,breakkn5,typesyn8,continuekn4,thenyn2,ifyn2,dokn10,label-usedyn6,valuesyn5,whileyn5,labelyn6,switchyn7,defaultkn6,hiddenkn3,lenkn1,ikn4,collkn4,elemyn3,foryn1,<yn4,inc!kn2,itkn8,iteratoryn11,.HasNext__Zkn7,patternkn5,compskn6,recordkn15,record-accessorkn7,derivedkn7,methodskn7,virtualkn7,resultsyn3,excyn5,deferkn8,accessorkn9,constantskn14,enum-constantskn5,caseskn7,defaultkn6,labelskn3,selkn5,guardkn4,enumyn12,.Equals_O__Zkn3,intyn4,casekn6,stringkn8,sel-typeyn12,.HashCode__Iyn4,condyn11,.-F_ordinalyn10,.Self_Enumkn7,classeskn7,catcheskn6,catch?kn5,formskn3,rv?kn4,ctl?yn3,ctlyn2,rvkn7,finallykn14,normal-finallykn4,lockkn3,samkn2,pskn1,rkn12,serializablekn7,markerskn7,lambdaskn8,boundarykn9,uses-thiskn6,paramsyn4,capskn6,columnyn5,.-Seryn4,funckn9,inst-desckn2,Fnkn12,invoker-desckn7,invokeryn1,fyn1,xyn4,isfnkn10,null-checkkn7,unboundv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,v11,arbace.core5,referR17,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.j2g.codem2,R18,s410,j2g's translation of code (J2G-SPEC §7): the analyzer's typed nodes to Go statements and\n  expressions, in four contexts (statement, return, assign, expression, §7.2), with\n  temporaries for Java's order of evaluation, Java's arithmetic (§7.4), null checks and the\n  typed-nil rule (§5.6), try/catch/finally and control codes (§7.9), monitors (§8.1), loops,\n  labels and switches (§7.7, §7.8), lambdas (§7.11).v15,arbace.j2g.code7,*races*v16,arbace.j2g.model7,static?v16,arbace.j2g.model11,iface-desc?R19,v11,arbace.core3,notv16,arbace.j2g.model4,has?R20,l16,l64,R21,v15,arbace.j2g.code3,*f*R22,R23,R24,R25,v11,arbace.core5,swap!R26,R27,v11,arbace.core7,ex-infov11,arbace.core5,mergem2,R28,TR29,v16,arbace.j2g.model7,jrt-symv15,arbace.j2g.code3,pkgv16,arbace.j2g.model9,class-symv16,arbace.j2g.model7,go-typev11,arbace.core9,with-metaR30,R31,v11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core3,incl0,R32,v16,arbace.j2g.names10,local-namev11,arbace.core9,contains?v11,arbace.core6,symbolv15,arbace.j2g.code9,fresh-rawv15,arbace.j2g.code12,new-counter!R33,R34,v11,arbace.core3,strR35,R36,v15,arbace.j2g.code5,freshR37,v11,arbace.core5,assocv15,arbace.j2g.code6,*line*v11,arbace.core4,seq?R38,v11,arbace.core9,vary-metav15,arbace.j2g.code7,*block*v15,arbace.j2g.code9,with-lineR39,v15,arbace.j2g.code3,tagv11,arbace.core5,some?v11,arbace.core4,listR40,v11,arbace.core7,reversev11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,nextv11,arbace.core7,vector?v11,arbace.core4,restv11,arbace.core3,vecv11,arbace.core6,mapcatv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core7,symbol?v11,arbace.core4,not=R41,v11,arbace.core12,chunk-appendR42,R41,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core6,concatv11,arbace.core5,applyR43,v11,arbace.core4,somev15,arbace.j2g.code10,fold-itemsv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core4,atomv22,arbace.classes.analyze10,value-typeR44,R45,S5,s1,Js1,Ss1,Cs1,Bs1,IS2,s1,Fs1,Dd0,R46,v11,arbace.core7,number?v11,arbace.core8,boolean?v11,arbace.core7,string?v15,arbace.j2g.code12,object-like?v13,arbace.string12,starts-with?v16,arbace.j2g.model11,code-class?v20,arbace.classes.types14,desc->internalR47,R48,R49,R50,v15,arbace.j2g.code10,*pkgstate*v16,arbace.j2g.names9,desc-codev20,arbace.classes.types5,prim?v15,arbace.j2g.code7,zero-ofR51,v15,arbace.j2g.code12,prim-convertv15,arbace.j2g.code6,coercev15,arbace.j2g.code7,box-valv20,arbace.classes.types6,box-ofv20,arbace.classes.types8,unbox-ofv16,arbace.j2g.names11,method-basev20,arbace.classes.types15,prim-desc->namev16,arbace.j2g.model13,pointer-desc?v15,arbace.j2g.code4,jsymv15,arbace.j2g.code4,failv15,arbace.j2g.code6,up-symv15,arbace.j2g.code6,gotypeR48,R48,R52,R52,v11,arbace.core8,to-arrayR53,R54,v15,arbace.j2g.code10,simple-opsR55,S2,R56,R57,R58,R59,R60,v15,arbace.j2g.code15,guarded-static?v16,arbace.j2g.names15,compiled-class?S2,R61,R62,R63,R64,R65,v16,arbace.j2g.model11,translated?v16,arbace.j2g.model13,trivial-init?v18,arbace.classes.env9,subclass?v16,arbace.j2g.model10,interface?v15,arbace.j2g.code16,compiled-caller?v16,arbace.j2g.model12,start-class?R66,v16,arbace.j2g.model8,nest-topv15,arbace.j2g.code11,*node-memo*v15,arbace.j2g.code9,memo-nodeR67,v15,arbace.j2g.code7,simple*v17,arbace.j2g.access8,unaccessv15,arbace.j2g.code12,expressible?v15,arbace.j2g.code14,missing-reasonv11,arbace.core6,every?v15,arbace.j2g.code7,simple?R68,v11,arbace.core6,removev11,arbace.core4,nil?R69,v11,arbace.core4,map?R70,v11,arbace.core6,filterR71,R72,R73,R74,R75,R76,R77,R78,v11,arbace.core4,keepR79,R80,R81,v15,arbace.j2g.code8,effects*v11,arbace.core9,volatile!v15,arbace.j2g.code10,effect-opsS5,R82,R83,R84,R85,R86,S2,R82,R86,R84,R87,R83,v20,arbace.classes.types4,ref?R88,R85,S2,R89,R90,S2,s1,Js1,Iv11,arbace.core7,vreset!R91,S6,R58,R68,R92,R93,R94,R95,S5,R96,R82,R84,R62,R86,S2,R89,R90,S2,s1,Js1,IR97,R98,R99,R100,R101,v15,arbace.j2g.code3,tmpR102,v15,arbace.j2g.code5,decl!v15,arbace.j2g.code8,use-sym!R47,v11,arbace.core4,lastR103,R104,v15,arbace.j2g.code9,const-numv15,arbace.j2g.code9,non-constR105,v15,arbace.j2g.code9,any-afterv11,arbace.core4,mapvv15,arbace.j2g.code8,effects?v15,arbace.j2g.code7,stable?v15,arbace.j2g.code12,reads-state?v11,arbace.core5,rangev15,arbace.j2g.code4,exprR106,v15,arbace.j2g.code12,missing-exprR107,v15,arbace.j2g.code11,hoist-valueR108,R109,v15,arbace.j2g.code1,vS4,s1,Js1,Ss1,Bs1,Iv11,arbace.core5,char?S2,s1,Fs1,Dv15,arbace.j2g.code9,float-litv15,arbace.j2g.code10,string-litv11,arbace.core8,keyword?v16,arbace.j2g.model12,erased-desc?R47,R52,R110,v16,arbace.j2g.model9,in-world?v22,arbace.classes.analyze4,declR111,R112,v13,arbace.string7,replacep3,\\s+v15,arbace.j2g.code13,class-missingv16,arbace.j2g.model12,desc-classesv16,arbace.j2g.model19,method-desc-classesR113,R114,v16,arbace.j2g.model3,*w*v16,arbace.j2g.model7,go-namev16,arbace.j2g.model11,j2g-static?R94,v11,arbace.core6,empty?v20,arbace.classes.types11,class-desc?v16,arbace.j2g.names6,pkg-ofv13,arbace.j2g.vh9,op-handleR115,R116,R117,S2,s1,Js1,IR57,S3,s1,Js1,Zs1,IS2,s1,Js1,IR118,S2,s1,Js1,IR119,S2,s1,Js1,IR120,S4,s1,Js1,Fs1,Is1,DR56,S3,s1,Js1,Zs1,IS2,s1,Js1,IR121,S2,s1,Js1,IR122,S3,s1,Js1,Zs1,IS2,s1,Js1,IR123,S2,s1,Js1,Iv13,arbace.j2g.vh6,fence?R124,v15,arbace.j2g.code12,lookup-call?v13,arbace.j2g.vh9,varhandlev15,arbace.j2g.code5,vh-opS2,R73,R125,v20,arbace.classes.types9,elem-typeR125,S2,s3,sets3,getv15,arbace.j2g.code13,vh-supported?R126,v15,arbace.j2g.code12,desc-missingv16,arbace.j2g.model13,hand-written?v16,arbace.j2g.names17,static-field-nameR127,R128,R129,R130,R131,R61,R132,v15,arbace.j2g.code10,vh-missingR133,v15,arbace.j2g.code13,mdesc-missingv16,arbace.j2g.model22,throwable-print-helperv15,arbace.j2g.code17,hw-static-exists?v16,arbace.j2g.model17,hw-method-exists?v16,arbace.j2g.model14,all-supertypesv16,arbace.j2g.model16,member-in-world?R134,R135,R136,R137,R92,v16,arbace.j2g.names8,new-nameR138,R62,R139,v20,arbace.classes.types14,internal->descv16,arbace.j2g.names10,field-namev22,arbace.classes.analyze10,this0-namev16,arbace.j2g.model5,leaf?R140,v15,arbace.j2g.code8,this-valR141,v15,arbace.j2g.code11,outer-fieldR142,R143,v15,arbace.j2g.code11,binding-symv16,arbace.j2g.model9,fields-ofv11,arbace.core10,take-whilev16,arbace.j2g.model16,superclass-chainR144,v15,arbace.j2g.code13,volatile-flagv15,arbace.j2g.code9,vh-field?R145,R47,R146,R47,R147,R148,R149,R47,R150,R151,R47,R105,R152,R153,v15,arbace.j2g.code9,struct-ofR154,v11,arbace.core4,intov15,arbace.j2g.code8,operandsv16,arbace.j2g.names15,reserved-memberv16,arbace.j2g.names10,munge-namev15,arbace.j2g.code4,csymv20,arbace.classes.types6,array?R155,v15,arbace.j2g.code9,class-valR156,v15,arbace.j2g.code2,vtv15,arbace.j2g.code5,stmt!v15,arbace.j2g.code7,assign!R157,R158,v15,arbace.j2g.code5,hoistv15,arbace.j2g.code7,expr-opv15,arbace.j2g.code5,emit!v15,arbace.j2g.code8,cast-valv15,arbace.j2g.code15,target-operandsV1,nv15,arbace.j2g.code11,field-placev15,arbace.j2g.code15,volatile-field?v15,arbace.j2g.code13,volatile-readR159,R52,v15,arbace.j2g.code10,lambda-valv15,arbace.j2g.code11,convert-valR96,R160,v15,arbace.j2g.code12,static-placeR93,v11,arbace.core6,repeatv20,arbace.classes.types10,lang-classv20,arbace.classes.types11,method-descR160,v11,arbace.core3,mapR161,R162,v15,arbace.j2g.code9,cond-exprv15,arbace.j2g.code10,invoke-valR163,V2,nnv11,arbace.core4,nameR164,R165,R166,v15,arbace.j2g.code9,local-valv15,arbace.j2g.code12,instance-valR167,V2,nnR166,R166,R166,R166,R47,R48,R47,R48,v15,arbace.j2g.code9,arith-valR168,R169,v15,arbace.j2g.code7,new-valv15,arbace.j2g.code9,array-valR170,R171,V2,s1,Zs1,ZR166,R82,R47,R105,R172,R173,R174,R175,R176,v15,arbace.j2g.code14,method-ref-valv15,arbace.j2g.code13,this-path-valR86,V2,ns1,IR52,v15,arbace.j2g.code14,fi-adapter-valR177,v15,arbace.j2g.code7,index-xR173,R95,v15,arbace.j2g.code12,java-str-valv15,arbace.j2g.code11,const-valueS2,R98,R99,S2,R98,R99,R178,v11,arbace.core6,float?v11,arbace.core6,bigintr21,18446744073709551616NR179,S3,R180,R181,R182,v15,arbace.j2g.code7,go-lit?R183,R47,R184,R185,R186,R90,R89,S2,s1,Fs1,DR180,R187,R188,R189,v15,arbace.j2g.code9,divisor-xR190,R191,R47,R192,R193,R47,R194,R47,R194,R193,R191,R47,R195,R196,R47,R197,v15,arbace.j2g.code12,unsigned-litR47,R105,R196,R47,R198,l32,R199,S2,s1,Fs1,DR199,l1,R184,R189,R200,R201,R183,R181,R202,R196,R47,R203,R204,R202,R205,R199,R182,R206,R207,R47,S4,s1,Ss1,Cs1,Bs1,IS2,s1,Fs1,Dv15,arbace.j2g.code13,fold-int-convS2,s1,Fs1,DV2,s1,Ds1,BV2,s1,Ds1,CV2,s1,Ds1,IV2,s1,Ds1,JS4,s1,Ss1,Cs1,Bs1,IV2,s1,Ds1,SV2,s1,Fs1,BV2,s1,Fs1,CV2,s1,Fs1,IV2,s1,Fs1,JV2,s1,Fs1,SV2,s1,Js1,BV2,s1,Js1,CR47,v16,arbace.j2g.model7,prim-goV2,s1,Js1,SR47,R208,v18,arbace.classes.env11,assignable?v16,arbace.j2g.model10,array-testR209,R52,R210,R211,V2,s4,waits4,(J)VR47,R105,v20,arbace.classes.types17,parse-method-descR212,R213,R214,S3,s1,Ss1,Cs1,BR215,R216,R217,R218,R219,R47,R105,R47,R146,R47,R147,R47,R150,R153,R152,R149,R148,R220,R221,R222,R222,R222,R223,R223,R223,v15,arbace.j2g.code14,volatile-writev15,arbace.j2g.code6,vh-argv11,arbace.core6,secondv11,arbace.core4,dropl2,V2,s2,[Bs1,IR224,v15,arbace.j2g.code9,vh-resultv15,arbace.j2g.code13,vh-field-formR47,v15,arbace.j2g.code6,vh-valR225,R226,v15,arbace.j2g.code8,args-forR227,R228,v14,arbace.j2g.jrt14,struct-methodsv16,arbace.j2g.names9,impl-namev16,arbace.j2g.model8,private?S2,R87,R99,V1,nv15,arbace.j2g.code14,object-helpersS5,V2,s9,notifyAlls3,()VV2,s4,waits5,(JI)VV2,s4,waits4,(J)VV2,s6,notifys3,()VV2,s4,waits3,()VR166,R166,v15,arbace.j2g.code12,super-structv15,arbace.j2g.code18,object-helper-argsv16,arbace.j2g.model4,infoR229,R230,v11,arbace.core8,split-atR231,S2,R232,R99,R233,R234,R235,v22,arbace.classes.analyze14,ctor-real-descv16,arbace.j2g.model3,pkgv16,arbace.j2g.names8,pkg-namev15,arbace.j2g.code9,ctor-argsV1,R45,v15,arbace.j2g.code10,utf8-safe?v15,arbace.j2g.code10,const-treeR236,R237,R238,v11,arbace.core6,reducev11,arbace.core1,+v15,arbace.j2g.code13,const-stringsv11,arbace.core12,keep-indexedv15,arbace.j2g.code12,const-encodev15,arbace.j2g.code15,const-array-minR239,R240,R184,v16,arbace.j2g.model13,prim-array-gov15,arbace.j2g.code11,const-arrayv11,arbace.core4,subsv11,arbace.core6,zipmapv11,arbace.core11,map-indexedl-1,R241,R242,R47,R105,R243,R244,R245,R104,R246,R247,R248,R249,v15,arbace.j2g.code8,outside?R250,v15,arbace.j2g.code10,code-jump!R251,R252,R104,R104,v15,arbace.j2g.code7,expr-asv15,arbace.j2g.code15,class-init-callR42,v15,arbace.j2g.code11,note-store!v16,arbace.j2g.model14,desc-in-world?S2,R61,R135,S2,R61,R135,R42,v15,arbace.j2g.code6,stmt!*R253,v15,arbace.j2g.code14,dropped-store?R254,v15,arbace.j2g.code13,translate-ctxm2,R255,R256,R257,m2,R255,R256,R258,m2,R255,R256,R259,m2,R255,R256,v15,arbace.j2g.code8,go-call?R42,R41,R260,R261,R262,R263,R173,R151,R264,m2,R255,R256,R265,m2,R255,R256,R266,m2,R255,R256,v15,arbace.j2g.code10,set-field!R267,m2,R255,R256,v15,arbace.j2g.code11,set-static!R268,m2,R255,R256,R269,m2,R255,R256,R270,R271,m2,R255,R256,R272,R273,R274,R42,R275,R276,R277,m2,R255,R256,v11,arbace.core4,run!R278,R279,R280,R281,v15,arbace.j2g.code14,method-return!m2,R255,R256,v15,arbace.j2g.code8,go-headsR255,R282,R42,R256,v15,arbace.j2g.code14,translate-ctx*v15,arbace.j2g.code8,ctx-descv15,arbace.j2g.code13,assign-value!m2,R255,R283,R284,R285,R286,R277,R161,R169,R169,R280,v15,arbace.j2g.code21,translate-if-instancev15,arbace.j2g.code16,translate-and-orR283,v15,arbace.j2g.code11,target-infoR287,m6,R55,R98,R44,R45,R72,nR288,R289,R290,v15,arbace.j2g.code17,translate-monitorv15,arbace.j2g.code13,translate-tryv15,arbace.j2g.code10,with-blockR291,R277,R292,R293,R293,v15,arbace.j2g.code18,translate-for-eachm2,R255,R283,v15,arbace.j2g.code16,translate-switchv15,arbace.j2g.code15,translate-labelv15,arbace.j2g.code14,translate-loopm2,R255,R256,R294,R42,R42,R295,R295,m2,R255,R256,R292,R293,R293,R42,m4,R55,R51,R44,R51,R263,R173,R151,R277,S2,R45,R51,R277,R277,R169,v11,arbace.core7,keywordv15,arbace.j2g.code9,new-labelv11,arbace.core4,compR288,R296,R297,R296,v11,arbace.core8,assoc-inR297,R298,R299,R42,R300,R301,R302,R303,m2,R255,R256,R304,R297,R305,R306,R307,R308,R309,m2,R255,R256,R297,R296,R310,v11,arbace.core3,popv11,arbace.core4,peekR105,R47,R105,R172,R173,R105,v15,arbace.j2g.code16,pattern-bindingsR311,R312,R313,R314,R315,R316,v15,arbace.j2g.code16,derived-accessorR42,R317,R42,R277,R178,R280,R103,R318,R319,R320,R220,R319,R42,R104,R321,v15,arbace.j2g.code14,match-pattern!v15,arbace.j2g.code14,accessor-call!R42,R41,R42,R292,R293,R42,R41,R110,R42,v15,arbace.j2g.code14,assert-classesR209,v15,arbace.j2g.code15,record-pattern?v15,arbace.j2g.code16,declare-pattern!R292,R293,R293,R42,R41,v15,arbace.j2g.code18,if-instance-assertR292,R293,R293,R322,v18,arbace.classes.env9,reflectedR323,R324,R325,R326,v11,arbace.core6,vectorR42,R327,S4,R280,R104,R290,R288,R288,v11,arbace.core6,reset!R328,R277,R329,v15,arbace.j2g.code9,box-primsR166,R330,R330,R47,R277,R166,R277,R166,R280,R277,R162,R277,R178,R297,R298,R299,R331,R298,R332,R299,R333,v11,arbace.core8,group-byv15,arbace.j2g.code9,java-hashR298,R332,R299,R334,R298,R332,v15,arbace.j2g.code12,enum-ordinalR299,R105,R298,R335,R332,R336,R330,R42,v11,arbace.core7,sort-byv11,arbace.core3,keyR337,R337,R338,R339,R340,R341,v11,arbace.core6,gensymR342,R343,R344,R332,R293,m2,R255,R283,R290,R298,R345,R105,R346,R110,R319,R104,R104,R103,R103,R103,R320,R220,R319,R104,R347,R348,V2,m2,R255,R256,nv15,arbace.j2g.code12,live-catchesv15,arbace.j2g.code11,try-literalm2,R341,Tv15,arbace.j2g.code12,literal-formv15,arbace.j2g.code15,dispatch-codes!R295,R277,R166,R162,R293,v11,arbace.core8,take-nthR277,R336,R280,R178,R277,R178,R280,m2,R341,TR295,R277,R178,R280,V2,m2,R255,R256,nR349,R320,R295,v22,arbace.classes.analyze8,find-samR350,R351,R352,v11,arbace.core4,sortv11,arbace.core8,distinctR353,V1,s20,java/io/SerializableR354,R355,v15,arbace.j2g.code11,adapter-symR52,v15,arbace.j2g.code14,serial-lambdasR356,R357,l7,l6,R358,l8,v18,arbace.classes.env10,interface?l9,l5,v15,arbace.j2g.code14,lambda-markersv15,arbace.j2g.code11,serial-implv15,arbace.j2g.code22,serial-lambdas-methodsv15,arbace.j2g.code19,convert-ref-or-primR103,R359,R184,m2,R30,R48,R43,R177,ML2,R173,R359,m4,R253,i2380,R360,i79,R42,R41,R43,R42,R361,R359,R104,R362,V1,R48,R184,R42,R47,R105,R363,R220,R239,R364,v15,arbace.j2g.code7,sam-sigR104,R103,v15,arbace.j2g.code12,serial-site?v15,arbace.j2g.code13,receiver-capsv15,arbace.j2g.code17,serial-lambda-valR220,R239,R365,R366,R367,v11,arbace.core5,list*R103,R104,R103,R368,R48,R43,R295,R367,R369,R209,R368,R277,R161,R369,R169,R368,R104,R220,R239,R368,R370,R52,R371,v16,arbace.j2g.model11,find-methodR103,R104,R220,R239,")

var Lit_1 *jrt.String = jrt.Intern(".-")

var Lit_2 *jrt.String = jrt.Intern("MatchException_New_String_Throwable")

var Lit_3 *jrt.String = jrt.Intern("Throwable_I")

var Lit_4 *jrt.String = jrt.Intern("Catch")

var Lit_5 *jrt.String = jrt.Intern("Thrown")

var Lit_6 *jrt.String = jrt.Intern("StrOfObj")

var Lit_7 *jrt.String = jrt.Intern("_Fn")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.code$adapter_sym$fn__969000819")

var Lit_9 *jrt.String = jrt.Intern("_")

var Lit_10 *jrt.String = jrt.Intern("J")

var Lit_11 *jrt.String = jrt.Intern("arbace.j2g.code$arith_val$cnt__969000253")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.code$arith_val$fmul__969000255")

var Lit_13 *jrt.String = jrt.Intern("Math_MultiplyExact_J_J__J")

var Lit_14 *jrt.String = jrt.Intern("Math_AddExact_J_J__J")

var Lit_15 *jrt.String = jrt.Intern("Math_IncrementExact_J__J")

var Lit_16 *jrt.String = jrt.Intern("Math_SubtractExact_J_J__J")

var Lit_17 *jrt.String = jrt.Intern("Math_DecrementExact_J__J")

var Lit_18 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_19 *jrt.String = jrt.Intern("F")

var Lit_20 *jrt.String = jrt.Intern("I")

var Lit_21 *jrt.String = jrt.Intern("NewMultiArray")

var Lit_22 *jrt.String = jrt.Intern("New")

var Lit_23 *jrt.String = jrt.Intern("NewRefArray")

var Lit_24 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_25 *jrt.String = jrt.Intern("ArrayOf")

var Lit_26 *jrt.String = jrt.Intern("RefArrayOf")

var Lit_27 *jrt.String = jrt.Intern("p")

var Lit_28 *jrt.String = jrt.Intern("valueOf")

var Lit_29 *jrt.String = jrt.Intern("(")

var Lit_30 *jrt.String = jrt.Intern(")L")

var Lit_31 *jrt.String = jrt.Intern(";")

var Lit_32 *jrt.String = jrt.Intern("_Cast")

var Lit_33 *jrt.String = jrt.Intern("As")

var Lit_34 *jrt.String = jrt.Intern("_Init")

var Lit_35 *jrt.String = jrt.Intern("class ")

var Lit_36 *jrt.String = jrt.Intern(" was refused by j2g: ")

var Lit_37 *jrt.String = jrt.Intern("/")

var Lit_38 *jrt.String = jrt.Intern(".")

var Lit_39 *jrt.String = jrt.Intern(" ")

var Lit_40 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_41 *jrt.String = jrt.Intern("Prim_")

var Lit_42 *jrt.String = jrt.Intern("V")

var Lit_43 *jrt.String = jrt.Intern("Prim_void")

var Lit_44 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_45 *jrt.String = jrt.Intern("Object_class")

var Lit_46 *jrt.String = jrt.Intern("_class")

var Lit_47 *jrt.String = jrt.Intern("L")

var Lit_48 *jrt.String = jrt.Intern("Value")

var Lit_49 *jrt.String = jrt.Intern("()")

var Lit_50 *jrt.String = jrt.Intern("NN")

var Lit_51 *jrt.String = jrt.Intern("unexpected primitive coercion ")

var Lit_52 *jrt.String = jrt.Intern(" -> ")

var Lit_53 *jrt.String = jrt.Intern(" in method ")

var Lit_54 *jrt.String = jrt.Intern("pointer coercion ")

var Lit_55 *jrt.String = jrt.Intern("Z")

var Lit_56 *jrt.String = jrt.Intern("Ljava/lang/Boolean;")

var Lit_57 *jrt.String = jrt.Intern("J2g_Truth")

var Lit_58 *jrt.String = jrt.Intern("ConstRefArray")

var Lit_59 *jrt.String = jrt.Intern("Class")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.code$const_encode$fn__969000399")

var Lit_61 *jrt.String = jrt.Intern("[")

var Lit_62 *jrt.String = jrt.Intern(",")

var Lit_63 *jrt.String = jrt.Intern("h")

var Lit_64 *jrt.String = jrt.Intern("s")

var Lit_65 *jrt.String = jrt.Intern(":")

var Lit_66 *jrt.String = jrt.Intern("UTF-8")

var Lit_67 *jrt.String = jrt.Intern("n")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.code$const_tree$fn__969000388")

var Lit_69 *jrt.String = jrt.Intern("C")

var Lit_70 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_71 *jrt.String = jrt.Intern("Clojure constant")

var Lit_72 *jrt.String = jrt.Intern("J2g_UnboxWiden")

var Lit_73 *jrt.String = jrt.Intern("unboxing ")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.code$ctor_args$iter__969000373__969000377")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.code$ctor_args$iter__969000373__969000377$fn__969000378")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.code$ctor_args$iter__969000373__969000377$fn__969000378$fn__969000379")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.code$declare_pattern_BANG_$fn__969000550")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.code$derived_accessor$fn__969000532")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.code$dispatch_codes_BANG_$clause__969000754")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.code$dispatch_codes_BANG_$clause__969000754$fn__969000755")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.code$effects_QMARK_$fn__969000095")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.code$effects_STAR_$w__969000098")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal$fn__969000564")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal$fn__969000566")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal$fn__969000568")

var Lit_86 *jrt.String = jrt.Intern("j2g: no constant ")

var Lit_87 *jrt.String = jrt.Intern(" in enum ")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal$fn__969000568$fn__969000569")

var Lit_89 *jrt.String = jrt.Intern("java/util/Objects")

var Lit_90 *jrt.String = jrt.Intern("J2g_RequireNonNullP")

var Lit_91 *jrt.String = jrt.Intern("J2g_RequireNonNull")

var Lit_92 *jrt.String = jrt.Intern("J2g_NotNull")

var Lit_93 *jrt.String = jrt.Intern("IFn")

var Lit_94 *jrt.String = jrt.Intern("invoke")

var Lit_95 *jrt.String = jrt.Intern("unreachable")

var Lit_96 *jrt.String = jrt.Intern("Ljava/lang/Class;")

var Lit_97 *jrt.String = jrt.Intern("no expression translation for ")

var Lit_98 *jrt.String = jrt.Intern("j2g: ")

var Lit_99 *jrt.String = jrt.Intern("FnInvokers")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$iter__969000939__969000943")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$fn__969000949")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$fn__969000952")

var Lit_103 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_104 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$iter__969000939__969000943$fn__969000944")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$iter__969000939__969000943$fn__969000944$fn__969000945")

var Lit_106 *jrt.String = jrt.Intern("NaN32")

var Lit_107 *jrt.String = jrt.Intern("NaN64")

var Lit_108 *jrt.String = jrt.Intern("PosInf")

var Lit_109 *jrt.String = jrt.Intern("NegInf")

var Lit_110 *jrt.String = jrt.Intern("32")

var Lit_111 *jrt.String = jrt.Intern("64")

var Lit_112 *jrt.String = jrt.Intern("NegZero32")

var Lit_113 *jrt.String = jrt.Intern("NegZero64")

var Lit_114 *jrt.String = jrt.Intern("B")

var Lit_115 *jrt.String = jrt.Intern("S")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$fn__969000039")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$fn__969000042")

var Lit_118 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053")

var Lit_119 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$fn__969000066")

var Lit_120 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053$fn__969000054")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053$fn__969000054$iter__969000049__969000058")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053$fn__969000054$iter__969000049__969000058$fn__969000059")

var Lit_123 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053$fn__969000054$iter__969000049__969000058$fn__969000059$fn__969000060")

var Lit_124 *jrt.String = jrt.Intern("arbace.j2g.code$instance_val$fn__969000268")

var Lit_125 *jrt.String = jrt.Intern("J2g_Discard")

var Lit_126 *jrt.String = jrt.Intern("arbace.j2g.code$invoke_val$rv__969000338")

var Lit_127 *jrt.String = jrt.Intern("VhFence")

var Lit_128 *jrt.String = jrt.Intern("static Object method")

var Lit_129 *jrt.String = jrt.Intern("_NoInit")

var Lit_130 *jrt.String = jrt.Intern(".Self_")

var Lit_131 *jrt.String = jrt.Intern("hashCode")

var Lit_132 *jrt.String = jrt.Intern("IdentityHash")

var Lit_133 *jrt.String = jrt.Intern("toString")

var Lit_134 *jrt.String = jrt.Intern("Object_toString")

var Lit_135 *jrt.String = jrt.Intern("equals")

var Lit_136 *jrt.String = jrt.Intern("an outer class's super call of Object.")

var Lit_137 *jrt.String = jrt.Intern(".Impl_")

var Lit_138 *jrt.String = jrt.Intern("getClass")

var Lit_139 *jrt.String = jrt.Intern("GetClass")

var Lit_140 *jrt.String = jrt.Intern("clone")

var Lit_141 *jrt.String = jrt.Intern("J2g_ObjectClone")

var Lit_142 *jrt.String = jrt.Intern("super call of Object.")

var Lit_143 *jrt.String = jrt.Intern("Object method ")

var Lit_144 *jrt.String = jrt.Intern(" on an Object")

var Lit_145 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val$fn__969000409")

var Lit_146 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val$iter__969000411__969000415")

var Lit_147 *jrt.String = jrt.Intern("Concat")

var Lit_148 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val$iter__969000411__969000415$fn__969000416")

var Lit_149 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val$iter__969000411__969000415$fn__969000416$fn__969000417")

var Lit_150 *jrt.String = jrt.Intern("StrOfInt")

var Lit_151 *jrt.String = jrt.Intern("StrOfChar")

var Lit_152 *jrt.String = jrt.Intern("D")

var Lit_153 *jrt.String = jrt.Intern("StrOfDouble")

var Lit_154 *jrt.String = jrt.Intern("StrOfFloat")

var Lit_155 *jrt.String = jrt.Intern("StrOfLong")

var Lit_156 *jrt.String = jrt.Intern("StrOfBool")

var Lit_157 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_markers$fn__969000815")

var Lit_158 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$iter__969000893__969000897")

var Lit_159 *jrt.String = jrt.Intern("lambda")

var Lit_160 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$fn__969000903")

var Lit_161 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$iter__969000923__969000927")

var Lit_162 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$fn__969000903$fn__969000904")

var Lit_163 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$fn__969000903$fn__969000917")

var Lit_164 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$iter__969000893__969000897$fn__969000898")

var Lit_165 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$iter__969000893__969000897$fn__969000898$fn__969000899")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$iter__969000923__969000927$fn__969000928")

var Lit_167 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$iter__969000923__969000927$fn__969000928$fn__969000929")

var Lit_168 *jrt.String = jrt.Intern("arbace.j2g.code$literal_form$fix__969000764")

var Lit_169 *jrt.String = jrt.Intern("arbace.j2g.code$live_catches$fn__969000740")

var Lit_170 *jrt.String = jrt.Intern("arbace.j2g.code$live_catches$fn__969000740$fn__969000741")

var Lit_171 *jrt.String = jrt.Intern("java/lang/Throwable")

var Lit_172 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_173 *jrt.String = jrt.Intern("lookup")

var Lit_174 *jrt.String = jrt.Intern("jdk/internal/jrt/Invokers")

var Lit_175 *jrt.String = jrt.Intern("arbace.j2g.code$match_pattern_BANG_$inner__969000536")

var Lit_176 *jrt.String = jrt.Intern("arbace.j2g.code$match_pattern_BANG_$inner__969000536$comps__969000538")

var Lit_177 *jrt.String = jrt.Intern("arbace.j2g.code$match_pattern_BANG_$inner__969000536$comps__969000538$fn__969000541")

var Lit_178 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$iter__969000960__969000964")

var Lit_179 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$callf__969000970")

var Lit_180 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$fn__969000979")

var Lit_181 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$callf__969000970$fn__969000972")

var Lit_182 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$callf__969000970$fn__969000974")

var Lit_183 *jrt.String = jrt.Intern("")

var Lit_184 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$iter__969000960__969000964$fn__969000965")

var Lit_185 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$iter__969000960__969000964$fn__969000965$fn__969000966")

var Lit_186 *jrt.String = jrt.Intern("J2g_Missing")

var Lit_187 *jrt.String = jrt.Intern("jrt lacks ")

var Lit_188 *jrt.String = jrt.Intern("a BigInt constant")

var Lit_189 *jrt.String = jrt.Intern("arbace.j2g.code$missing_reason$fn__969000174")

var Lit_190 *jrt.String = jrt.Intern("method ")

var Lit_191 *jrt.String = jrt.Intern("jrt lacks constructor ")

var Lit_192 *jrt.String = jrt.Intern("Object_New")

var Lit_193 *jrt.String = jrt.Intern("?")

var Lit_194 *jrt.String = jrt.Intern("arbace.j2g.code$operands$fn__969000122")

var Lit_195 *jrt.String = jrt.Intern("arbace.j2g.code$operands$fn__969000124")

var Lit_196 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000126__969000130")

var Lit_197 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000136__969000140")

var Lit_198 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000146__969000150")

var Lit_199 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000126__969000130$fn__969000131")

var Lit_200 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000126__969000130$fn__969000131$fn__969000132")

var Lit_201 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000136__969000140$fn__969000141")

var Lit_202 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000136__969000140$fn__969000141$fn__969000142")

var Lit_203 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000146__969000150$fn__969000151")

var Lit_204 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000146__969000150$fn__969000151$fn__969000152")

var Lit_205 *jrt.String = jrt.Intern("arbace.j2g.code$pattern_bindings$fn__969000524")

var Lit_206 *jrt.String = jrt.Intern("D2I")

var Lit_207 *jrt.String = jrt.Intern("D2L")

var Lit_208 *jrt.String = jrt.Intern("F2I")

var Lit_209 *jrt.String = jrt.Intern("F2L")

var Lit_210 *jrt.String = jrt.Intern("arbace.j2g.code$reads_state_QMARK_$w__969000105")

var Lit_211 *jrt.String = jrt.Intern("serialSite")

var Lit_212 *jrt.String = jrt.Intern("serialFactory")

var Lit_213 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$mcall__969000838")

var Lit_214 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$str_lit__969000840")

var Lit_215 *jrt.String = jrt.Intern("serialObj")

var Lit_216 *jrt.String = jrt.Intern("RefArray")

var Lit_217 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$fn__969000843")

var Lit_218 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$fn__969000849")

var Lit_219 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$iter__969000854__969000858")

var Lit_220 *jrt.String = jrt.Intern("instance")

var Lit_221 *jrt.String = jrt.Intern("Ljdk/internal/jrt/SerialLambdas$Site;")

var Lit_222 *jrt.String = jrt.Intern("jdk/internal/jrt/SerialLambdas$Factory")

var Lit_223 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$iter__969000870__969000874")

var Lit_224 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$iter__969000854__969000858$fn__969000859")

var Lit_225 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$iter__969000854__969000858$fn__969000859$fn__969000860")

var Lit_226 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$iter__969000870__969000874$fn__969000875")

var Lit_227 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val$iter__969000870__969000874$fn__969000875$fn__969000876")

var Lit_228 *jrt.String = jrt.Intern("Str")

var Lit_229 *jrt.String = jrt.Intern("arbace.j2g.code$simple_QMARK_$fn__969000087")

var Lit_230 *jrt.String = jrt.Intern("arbace.j2g.code$simple_STAR_$fn__969000092")

var Lit_231 *jrt.String = jrt.Intern("Ljava/lang/Throwable;")

var Lit_232 *jrt.String = jrt.Intern("Lit_")

var Lit_233 *jrt.String = jrt.Intern("arbace.j2g.code$struct_of$fn__969000197")

var Lit_234 *jrt.String = jrt.Intern("arbace.j2g.code$struct_of$fn__969000201")

var Lit_235 *jrt.String = jrt.Intern("arbace.j2g.code$struct_of$fn__969000197$fn__969000198")

var Lit_236 *jrt.String = jrt.Intern("no this here")

var Lit_237 *jrt.String = jrt.Intern("tmp")

var Lit_238 *jrt.String = jrt.Intern("arbace.j2g.code$translate_and_or$go__969000476")

var Lit_239 *jrt.String = jrt.Intern("arbace.j2g.code$translate_and_or$go__969000476$fn__969000480")

var Lit_240 *jrt.String = jrt.Intern("AssertionError_New_")

var Lit_241 *jrt.String = jrt.Intern("AssertionError_New")

var Lit_242 *jrt.String = jrt.Intern("J2g_AssertionsDisabled")

var Lit_243 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_$fn__969000458")

var Lit_244 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_$fn__969000460")

var Lit_245 *jrt.String = jrt.Intern("break target not in scope")

var Lit_246 *jrt.String = jrt.Intern("recur target not in scope")

var Lit_247 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_$fn__969000464")

var Lit_248 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_$fn__969000466")

var Lit_249 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000511")

var Lit_250 *jrt.String = jrt.Intern("Ljava/util/Iterator;")

var Lit_251 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000515")

var Lit_252 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000519")

var Lit_253 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000511$fn__969000512")

var Lit_254 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000515$fn__969000516")

var Lit_255 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance$fn__969000554")

var Lit_256 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance$fn__969000556")

var Lit_257 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance$fn__969000558")

var Lit_258 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance$fn__969000560")

var Lit_259 *jrt.String = jrt.Intern("arbace.j2g.code$translate_label$fn__969000506")

var Lit_260 *jrt.String = jrt.Intern("arbace.j2g.code$translate_label$fn__969000506$fn__969000507")

var Lit_261 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$iter__969000485__969000489")

var Lit_262 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$fn__969000501")

var Lit_263 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$fn__969000501$fn__969000502")

var Lit_264 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$iter__969000485__969000489$fn__969000490")

var Lit_265 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$iter__969000485__969000489$fn__969000490$fn__969000491")

var Lit_266 *jrt.String = jrt.Intern("MonitorEnter")

var Lit_267 *jrt.String = jrt.Intern("arbace.j2g.code$translate_monitor$fn__969000805")

var Lit_268 *jrt.String = jrt.Intern("arbace.j2g.code$translate_monitor$fn__969000805$fn__969000806")

var Lit_269 *jrt.String = jrt.Intern("MonitorExit")

var Lit_270 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000578")

var Lit_271 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$arm__969000583")

var Lit_272 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000587")

var Lit_273 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000592")

var Lit_274 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$done__969000597")

var Lit_275 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$arm_done__969000599")

var Lit_276 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$guarded__969000601")

var Lit_277 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$label_test__969000603")

var Lit_278 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000605")

var Lit_279 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000627__969000631")

var Lit_280 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000641__969000647")

var Lit_281 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000660")

var Lit_282 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000663")

var Lit_283 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000668__969000672")

var Lit_284 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000696__969000700")

var Lit_285 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000724__969000728")

var Lit_286 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$arm__969000583$fn__969000584")

var Lit_287 *jrt.String = jrt.Intern("NPE")

var Lit_288 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000605$fn__969000610")

var Lit_289 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000605$fn__969000612")

var Lit_290 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000605$fn__969000614")

var Lit_291 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000605$fn__969000616")

var Lit_292 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000605$fn__969000618")

var Lit_293 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000605$fn__969000620")

var Lit_294 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000605$fn__969000622")

var Lit_295 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000605$fn__969000624")

var Lit_296 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000627__969000631$fn__969000632")

var Lit_297 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000627__969000631$fn__969000632$fn__969000633")

var Lit_298 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000627__969000631$fn__969000632$fn__969000637")

var Lit_299 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000627__969000631$fn__969000632$fn__969000633$fn__969000634")

var Lit_300 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000641__969000647$fn__969000648")

var Lit_301 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000641__969000647$fn__969000648$iter__969000643__969000652")

var Lit_302 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000641__969000647$fn__969000648$iter__969000643__969000652$fn__969000653")

var Lit_303 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000641__969000647$fn__969000648$iter__969000643__969000652$fn__969000653$fn__969000654")

var Lit_304 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000668__969000672$fn__969000673")

var Lit_305 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000668__969000672$fn__969000673$fn__969000674")

var Lit_306 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000668__969000672$fn__969000673$fn__969000689")

var Lit_307 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000668__969000672$fn__969000673$fn__969000674$fn__969000679")

var Lit_308 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000696__969000700$fn__969000701")

var Lit_309 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000696__969000700$fn__969000701$fn__969000702")

var Lit_310 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000696__969000700$fn__969000701$fn__969000717")

var Lit_311 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000696__969000700$fn__969000701$fn__969000702$fn__969000707")

var Lit_312 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000724__969000728$fn__969000729")

var Lit_313 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000724__969000728$fn__969000729$fn__969000730")

var Lit_314 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000724__969000728$fn__969000729$fn__969000734")

var Lit_315 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000724__969000728$fn__969000729$fn__969000730$fn__969000731")

var Lit_316 *jrt.String = jrt.Intern("Box")

var Lit_317 *jrt.String = jrt.Intern("a constant pattern label")

var Lit_318 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774")

var Lit_319 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$fn__969000798")

var Lit_320 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774$fn__969000775")

var Lit_321 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774$fn__969000777")

var Lit_322 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774$fn__969000779")

var Lit_323 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774$fn__969000795")

var Lit_324 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774$fn__969000779$fn__969000780")

var Lit_325 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774$fn__969000779$iter__969000782__969000786")

var Lit_326 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774$fn__969000779$fn__969000792")

var Lit_327 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774$fn__969000779$iter__969000782__969000786$fn__969000787")

var Lit_328 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000774$fn__969000779$iter__969000782__969000786$fn__969000787$fn__969000788")

var Lit_329 *jrt.String = jrt.Intern("fn")

var Lit_330 *jrt.String = jrt.Intern("arbace.j2g.code$try_literal$fn__969000749")

var Lit_331 *jrt.String = jrt.Intern("arbace.j2g.code$try_literal$fn__969000751")

var Lit_332 *jrt.String = jrt.Intern("Up_")

var Lit_333 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form$narrow__969000282")

var Lit_334 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form$widen__969000284")

var Lit_335 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form$bits__969000287")

var Lit_336 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form$unbits__969000290")

var Lit_337 *jrt.String = jrt.Intern("Xor")

var Lit_338 *jrt.String = jrt.Intern("And")

var Lit_339 *jrt.String = jrt.Intern("Or")

var Lit_340 *jrt.String = jrt.Intern("VhGetAnd")

var Lit_341 *jrt.String = jrt.Intern("Bool")

var Lit_342 *jrt.String = jrt.Intern("VhGetAndXorInt32")

var Lit_343 *jrt.String = jrt.Intern("VhGetAndXorInt64")

var Lit_344 *jrt.String = jrt.Intern("VhGetAndAddFloat32")

var Lit_345 *jrt.String = jrt.Intern("VhGetAndAddInt32")

var Lit_346 *jrt.String = jrt.Intern("VhGetAndAddInt64")

var Lit_347 *jrt.String = jrt.Intern("VhGetAndAddFloat64")

var Lit_348 *jrt.String = jrt.Intern("VhCmpXchgBool")

var Lit_349 *jrt.String = jrt.Intern("VhCmpXchgPtr")

var Lit_350 *jrt.String = jrt.Intern("VhCmpXchgVol")

var Lit_351 *jrt.String = jrt.Intern("VhCmpXchgUint32")

var Lit_352 *jrt.String = jrt.Intern("VhCmpXchgInt32")

var Lit_353 *jrt.String = jrt.Intern("VhCmpXchgInt64")

var Lit_354 *jrt.String = jrt.Intern("VhCmpXchgUint64")

var Lit_355 *jrt.String = jrt.Intern("VarHandle.")

var Lit_356 *jrt.String = jrt.Intern(" on ")

var Lit_357 *jrt.String = jrt.Intern(" (J2G-SPEC §8.5)")

var Lit_358 *jrt.String = jrt.Intern(" on a handle that is not a constant of its class (J2G-SPEC §8.5)")

var Lit_359 *jrt.String = jrt.Intern("[B")

var Lit_360 *jrt.String = jrt.Intern("arbace.j2g.code$vh_val$fn__969000315")

var Lit_361 *jrt.String = jrt.Intern("VhView")

var Lit_362 *jrt.String = jrt.Intern("Set")

var Lit_363 *jrt.String = jrt.Intern("Get")

var Lit_364 *jrt.String = jrt.Intern("Int")

var Lit_365 *jrt.String = jrt.Intern("Long")

var Lit_366 *jrt.String = jrt.Intern("arbace.j2g.code$vh_val$fn__969000322")

var Lit_367 *jrt.String = jrt.Intern("arbace.j2g.code$vh_val$fn__969000328")

var Lit_368 *jrt.String = jrt.Intern("IntArray")

var Lit_369 *jrt.String = jrt.Intern("LongArray")

var Lit_370 *jrt.String = jrt.Intern("GetAndAnd")

var Lit_371 *jrt.String = jrt.Intern("Cas")

var Lit_372 *jrt.String = jrt.Intern("Swap")

var Lit_373 *jrt.String = jrt.Intern("GetAndAdd")

var Lit_374 *jrt.String = jrt.Intern("GetAndOr")

var Lit_375 *jrt.String = jrt.Intern("GetAndXor")

var Lit_376 *jrt.String = jrt.Intern("CmpXchg")

var Lit_377 *jrt.String = jrt.Intern("Vh")

var Lit_378 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn1,fyn1,oyn3,msgyn1,&yn4,datayn5,identyn1,nyn6,suffixyn1,dkn7,privateyn3,symyn4,typeyn1,kyn1,syn1,byn4,formyn2,gtyn4,inityn5,itemsyn4,usedyn4,nodeyn1,xyn1,vyn2,tokn8,declaredyn4,fromyn2,nnyn1,tkn2,asyn4,morekn9,var-derefkn7,alengthkn7,convertkn10,array-initkn10,method-refkn6,lambdakn3,newks15,arbace.j2g.code2,gokn9,get-fieldkn5,arithkn4,castkn5,bool=kn4,nil?kn9,instance?kn3,notkn10,identical?kn9,class-litkn12,null-checkedkn10,fi-adapterkn5,constkn9,this-pathkn16,outer-param-pathkn9,new-arraykn10,get-statickn7,comparekn10,var-invokekn6,invokekn4,agetkn5,localkn8,java-strkn4,noneyn7,computekn10,set-statickn6,assertkn9,set-fieldkn9,ctor-callkn4,asetkn7,monitorkn5,throwkn3,trykn9,set-localyn3,valyn5,flagsyn2,tyyn5,nodesyn5,wantskn3,tagyn6,Stringyn3,whyyn3,clsyn4,baseyn1,myn2,sdyn4,declyn5,fnameyn3,ptryn5,placeyn2,tvv11,arbace.core5,in-nsMyn15,arbace.j2g.codem2,R0,s410,j2g's translation of code (J2G-SPEC §7): the analyzer's typed nodes to Go statements and\n  expressions, in four contexts (statement, return, assign, expression, §7.2), with\n  temporaries for Java's order of evaluation, Java's arithmetic (§7.4), null checks and the\n  typed-nil rule (§5.6), try/catch/finally and control codes (§7.9), monitors (§8.1), loops,\n  labels and switches (§7.7, §7.8), lambdas (§7.11).m2,R0,s410,j2g's translation of code (J2G-SPEC §7): the analyzer's typed nodes to Go statements and\n  expressions, in four contexts (statement, return, assign, expression, §7.2), with\n  temporaries for Java's order of evaluation, Java's arithmetic (§7.4), null checks and the\n  typed-nil rule (§5.6), try/catch/finally and control codes (§7.9), monitors (§8.1), loops,\n  labels and switches (§7.7, §7.8), lambdas (§7.11).R1,v15,arbace.j2g.code3,*f*m10,R2,TR3,i19,R4,i1,R5,s18,arbace/j2g/code.aeR0,s176,The Go function being written: {:pkg :class :static :t :this :method-ret :fn-id :targets\n  :try-frame :captured :ctor-params, and atoms :names :taken :used :counter :pkgstate}.v15,arbace.j2g.code7,*block*m10,R2,TR3,i24,R4,i1,R5,s18,arbace/j2g/code.aeR0,s51,The statement list being written: an atom of items.v15,arbace.j2g.code10,*pkgstate*m10,R2,TR3,i26,R4,i1,R5,s18,arbace/j2g/code.aeR0,s318,Per package: {:lits (atom {string sym}) :ups (atom #{[from to]}) :lambdas (atom #{fi})\n  :cuts (atom #{class})}; for one class translated on its own (arbace.j2g.main's parallel\n  translation): :lits local with a :lit-prefix, :ups :lambdas :cuts atoms of vectors (what\n  was conj'ed, in order, for the merge to replay).v15,arbace.j2g.code7,*races*m10,R2,TR3,i33,R4,i1,R5,s18,arbace/j2g/code.aeR0,s122,An atom collecting the candidate two-word races (J2G-SPEC §8.3, Q10), or nil:\n  #{[class field-name desc static? writer]}.v15,arbace.j2g.code11,note-store!m10,R6,L1,V2,R7,R8,R0,s274,Records a store into field f (declared in o) when it is a two-word race candidate: a\n  non-final, non-volatile field of interface Go type written outside its class's constructors\n  (static initializer for a static field), not in a synchronized method nor in locking on this.R3,i38,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,failm8,R6,L1,V3,R9,R10,V1,R11,R3,i53,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code3,pkgm8,R6,L1,V0,R3,i55,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,jsymm8,R6,L1,V1,R12,R3,i57,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,csymm8,R6,L2,V1,R13,V2,R13,R14,R3,i58,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,gotypem8,R6,L1,V1,R15,R3,i59,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code3,tagm10,R16,TR6,L1,V2,R17,R18,R3,i61,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,new-counter!m8,R6,L1,V1,R19,R3,i63,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,freshm10,R6,L1,V1,R20,R0,s33,A fresh Go local name based on s.R3,i66,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,fresh-rawm10,R6,L1,V1,R20,R0,s81,A fresh Go local name for j2g's own variables (not munged: no Java local has it).R3,i77,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code3,tmpm8,R6,L1,V0,R3,i87,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,use-sym!m8,R6,L1,V1,R20,R3,i89,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,binding-symm10,R6,L1,V1,R21,R0,s59,The Go name of an analyzer binding in the current function.R3,i91,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,*line*m10,R2,TR3,i102,R4,i1,R5,s18,arbace/j2g/code.aeR0,s227,The Java forms line of the node being translated (the analyzer's :line), or nil: the\n  statements written meanwhile carry it as :j2g/line metadata, which arbace.j2g.out turns into\n  the forms' positions (J2G-SPEC §4.3, §7.9.6).v15,arbace.j2g.code9,with-linem10,R6,L1,V1,R22,R0,s72,form with the current line as :j2g/line, unless it has one (lists only).R3,i108,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,emit!m8,R6,L1,V1,R22,R3,i115,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,decl!m10,R6,L1,V3,R17,R23,R24,R0,s82,Declares Go local sym of Go type gt with initial value init (nil: the zero value).R3,i117,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,fold-itemsm10,R16,TR6,L1,V2,R25,R26,R3,i124,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,with-blockm10,R6,L1,V1,R7,R0,s70,Runs f with a fresh statement list; returns the list of Go statements.R3,i144,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,block-formsm8,R6,L1,V1,R25,R3,i151,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code2,vtm8,R6,L1,V1,R27,R3,i156,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,object-like?m8,R6,L1,V1,R15,R3,i158,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,zero-ofm10,R6,L1,V1,R15,R0,s52,The Go zero value of descriptor d, as an expression.R3,i160,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,literal?m8,R6,L1,V1,R28,R3,i168,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,fold-int-convm12,R16,TR6,L1,V2,R29,R30,R0,s83,A Go integer literal converted to Java type to (wrapping as Java's conversions do).R3,i170,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,stmt!*m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code14,translate-ctx*m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,exprm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,expr-opm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,expr-asm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,stmt!m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,assign!m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,ret!m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,cond-exprm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,translate-ctxm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code14,missing-reasonm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,missing-exprm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,go-call?m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,prim-convertm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,box-valm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,up-symm10,R6,L1,V3,R28,R32,R30,R0,s132,The nil-preserving conversion of pointer type `from` (desc) to interface `to` (desc):\n  .Ref for any, else a generated Up_ function.R3,i181,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,coercem10,R6,L1,V4,R28,R32,R30,R33,R0,s257,Converts Go expression x of Java static type from (a descriptor, :null) to Java type `to`\n  as an assignment conversion that the analyzer left implicit (reference widening): pointer\n  to interface conversions are nil-preserving unless nn (x known not null).R3,i193,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code1,vm10,R16,TR6,L1,V4,R28,R34,R10,m2,R35,R36,R3,i232,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code15,guarded-static?m8,R31,TR3,i237,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,simple-opsS31,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,m8,R16,TR3,i239,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,expressible?m10,R6,L1,V1,R27,R0,s83,Is node's own operation one Go expression (its operands may still need statements)?R3,i245,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code16,compiled-caller?m12,R16,TR6,L1,V0,R0,s80,Is the function being written in a class of a compiled namespace (arbace.c2j's)?R3,i253,R4,i1,R5,s18,arbace/j2g/code.aem12,R16,TR6,L1,V1,R27,R0,s90,A static access that runs C_Init() first (from code outside the class and its subclasses).R3,i258,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,*node-memo*m10,R2,TR3,i277,R4,i1,R5,s18,arbace/j2g/code.aeR0,s449,nil, or {:simple :effects} two java.util.IdentityHashMaps in which simple? and effects?\n  keep their answer for a node (by identity) while one class is translated (arbace.j2g.main's\n  apart): each walks the node's operands, and the operands of an expression ask again of\n  theirs, level after level. An answer is kept with what it depends on besides the node and\n  the world: the class and staticness of the function being written (guarded-static?).v15,arbace.j2g.code9,memo-nodem12,R16,TR6,L1,V3,R19,R27,R68,R0,s66,(compute) for node, kept in *node-memo*'s map k when there is one.R3,i285,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,simple*m8,R31,TR3,i300,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,simple?m10,R6,L1,V1,R27,R0,s37,Can node be one Go expression (§7.2)?R3,i302,R4,i1,R5,s18,arbace/j2g/code.aem10,R16,TR6,L1,V1,R27,R3,i307,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,effect-opsS20,R37,R40,R69,R41,R42,R43,R47,R54,R70,R71,R72,R73,R74,R59,R62,R63,R75,R76,R66,R77,m8,R16,TR3,i319,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,effects*m8,R31,TR3,i323,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,effects?m10,R6,L1,V1,R27,R0,s49,Can evaluating node change state or throw (§7.2)?R3,i325,R4,i1,R5,s18,arbace/j2g/code.aem10,R16,TR6,L1,V1,R27,R3,i330,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,reads-state?m10,R6,L1,V1,R27,R0,s265,Is node's value at risk from a later operand's call (§7.2): it reads a field, a static or\n  an array element, or can throw (an integer division), outside the arguments of a call of\n  its own (Go orders calls among themselves, and a call's arguments come before it)?R3,i349,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,stable?m10,R6,L1,V1,R27,R0,s90,Is node's value unaffected by any later evaluation (a constant, an immutable local, this)?R3,i367,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,hoist-valuem12,R16,TR6,L1,V1,R78,R0,s47,Puts a translated value into a fresh temporary.R3,i378,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,any-afterm12,R16,TR6,L1,V1,R79,R0,s173,For a vector of flags: whether one after position i is true, for each i (one pass from the\n  right, so that an array initializer of n elements costs n tests, not n squared).R3,i387,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,const-numm12,R16,TR6,L1,V1,R28,R0,s90,The number a Go form is when it is a numeric constant (a literal, or a literal converted).R3,i396,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,non-constm12,R16,TR6,L1,V2,R28,R80,R0,s187,x, of Go type ty, through a function literal's call, which is not a constant: where gc refuses\n  a constant that Java takes at run time (doc/classes/JAVA-CONFORMANCE-SURVEY.md §5.4, JC2).R3,i402,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,index-xm12,R16,TR6,L1,V1,R28,R0,s179,An array index as Go takes it: a constant negative index (a[-1], which Java throws at run time\n  as ArrayIndexOutOfBoundsException, and gc refuses at compile time) not a constant.R3,i408,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,divisor-xm12,R16,TR6,L1,V2,R28,R80,R0,s216,A divisor as Go takes it: a constant zero (x / 0, which Java throws at run time as\n  ArithmeticException for integers, or makes an infinity or NaN for floating point, and gc\n  refuses at compile time) not a constant.R3,i415,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,operandsm10,R6,L1,V2,R81,R82,R0,s260,Translates nodes left to right as operands of one Go expression (or call), each converted\n  to its type in `wants` (a desc or nil). An operand is moved to a temporary when a later\n  operand writes statements or has side effects that could change what it reads.R3,i423,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,java-hashm10,R16,TR6,L1,V1,Myn1,sm2,R83,R84,R3,i456,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,string-litm10,R6,L1,V1,R20,R0,s275,The pooled literal (§7.5) of Java string s: a package variable Lit_n. In a class translated\n  on its own (arbace.j2g.main's parallel translation), :lit-prefix names the class's literals\n  apart, in its own first-use order; the merge renames them Lit_n in the package's order.R3,i458,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,float-litm8,R6,L1,V2,R34,R28,R3,i469,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,const-valuem8,R6,L1,V1,R27,R3,i478,R4,i1,R5,s18,arbace/j2g/code.aem8,R6,L1,V2,R85,R15,R3,i493,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,class-missingm10,R16,TR6,L1,V1,R13,R3,i500,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,desc-missingm10,R16,TR6,L1,V1,R15,R3,i508,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,mdesc-missingm10,R16,TR6,L1,V1,R15,R3,i509,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code17,hw-static-exists?m10,R16,TR6,L1,V2,R86,R87,R3,i511,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,lookup-call?m10,R6,L1,V1,R27,R0,s567,MethodHandles.lookup(): the lookup VarHandle constants are found with (J2G-SPEC §8.5); in Go\n  a nil of no use, the handles being compiled statically. Since F15 (doc/classes/JAVA-DEFERRED-TRIAGE.md,\n  \"As built: F15 (java.lang.invoke)\") the analyzer writes it as jdk.internal.jrt.Invokers.lookup(C.class)\n  when the world has java.lang.invoke: in a JDK class of the world (pkg-of :jrt, where the VarHandle idiom\n  lives) still the nil, so the JDK's static initializers stay as they were; in a program's own class and\n  in Arbace's a real lookup of the caller's class.R3,i515,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,vh-opm10,R6,L1,V1,R27,R0,s83,The constant VarHandle and access mode of a VarHandle call (J2G-SPEC §8.5), or nil.R3,i532,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,vh-supported?m12,R16,TR6,L1,V3,R19,R88,R15,R0,s80,Can j2g translate access mode m of a handle of kind k on values of descriptor d?R3,i537,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,vh-missingm12,R16,TR6,L1,V1,R27,R0,s119,For a VarHandle call or MethodHandles.lookup(): ::vh-ok when j2g translates it, else why\n  not; nil for any other node.R3,i546,R4,i1,R5,s18,arbace/j2g/code.aem10,R6,L1,V1,R27,R0,s104,Why node cannot be translated in this world (a class or member it needs does not exist in\n  Go), or nil.R3,i565,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,this-valm10,R6,L1,V0,R0,s81,The whole object of the current instance code: t in a leaf class, this otherwise.R3,i621,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,outer-fieldm8,R6,L1,V2,R28,R86,R3,i626,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,this-path-valm8,R6,L1,V1,R27,R3,i634,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,local-valm8,R6,L1,V1,R27,R3,i649,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,struct-ofm10,R6,L1,V6,R28,R89,R90,R91,R10,V1,R92,R0,s314,An expression of the struct of declaring class `decl` reached from value x of static type\n  desc sd (§5.2): x itself for a pointer, Self_D for a class interface; through the embedded\n  struct when a nearer class hides a field of the same name. ptr: x is the struct pointer of\n  sd's class itself (t, the receiver).R3,i655,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,volatile-flagl64,m8,R16,TR3,i670,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,vh-field?m10,R6,L1,V1,R7,R0,s111,Does a constant VarHandle of the world name field f (J2G-SPEC §8.5)? It then has the\n  volatile representation.R3,i672,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code15,volatile-field?m8,R6,L1,V1,R7,R3,i678,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,volatile-readm8,R6,L1,V2,R93,R15,R3,i680,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code14,volatile-writem8,R6,L1,V3,R93,R15,R28,R3,i687,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,field-placem10,R6,L1,V2,R94,R7,R0,s67,The Go place of instance field f (declared in class o) on value tv.R3,i693,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code15,target-operandsm10,R6,L1,V2,R81,R82,R0,s81,operands, with this (the current object, no outer hops) as the receiver struct t.R3,i700,R4,i1,R5,s18,arbace/j2g/code.ae")

var Lit_379 *jrt.String = jrt.Intern("arbace.j2g.code$eval969000004$loading__1927001464__auto____969000005")

var Lit_380 *jrt.String = jrt.Intern("arbace.j2g.code$eval969000008$fn__969000009")

var Lit_381 *jrt.String = jrt.Intern("arbace.j2g.code$note_store_BANG_")

var Lit_382 *jrt.String = jrt.Intern("arbace.j2g.code$fail")

var Lit_383 *jrt.String = jrt.Intern("arbace.j2g.code$pkg")

var Lit_384 *jrt.String = jrt.Intern("arbace.j2g.code$jsym")

var Lit_385 *jrt.String = jrt.Intern("arbace.j2g.code$csym")

var Lit_386 *jrt.String = jrt.Intern("arbace.j2g.code$gotype")

var Lit_387 *jrt.String = jrt.Intern("arbace.j2g.code$tag")

var Lit_388 *jrt.String = jrt.Intern("arbace.j2g.code$new_counter_BANG_")

var Lit_389 *jrt.String = jrt.Intern("arbace.j2g.code$fresh")

var Lit_390 *jrt.String = jrt.Intern("arbace.j2g.code$fresh_raw")

var Lit_391 *jrt.String = jrt.Intern("arbace.j2g.code$tmp")

var Lit_392 *jrt.String = jrt.Intern("arbace.j2g.code$use_sym_BANG_")

var Lit_393 *jrt.String = jrt.Intern("arbace.j2g.code$binding_sym")

var Lit_394 *jrt.String = jrt.Intern("arbace.j2g.code$with_line")

var Lit_395 *jrt.String = jrt.Intern("arbace.j2g.code$emit_BANG_")

var Lit_396 *jrt.String = jrt.Intern("arbace.j2g.code$decl_BANG_")

var Lit_397 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items")

var Lit_398 *jrt.String = jrt.Intern("arbace.j2g.code$with_block")

var Lit_399 *jrt.String = jrt.Intern("arbace.j2g.code$block_forms")

var Lit_400 *jrt.String = jrt.Intern("arbace.j2g.code$vt")

var Lit_401 *jrt.String = jrt.Intern("arbace.j2g.code$object_like_QMARK_")

var Lit_402 *jrt.String = jrt.Intern("arbace.j2g.code$zero_of")

var Lit_403 *jrt.String = jrt.Intern("arbace.j2g.code$literal_QMARK_")

var Lit_404 *jrt.String = jrt.Intern("arbace.j2g.code$fold_int_conv")

var Lit_405 *jrt.String = jrt.Intern("arbace.j2g.code$up_sym")

var Lit_406 *jrt.String = jrt.Intern("arbace.j2g.code$coerce")

var Lit_407 *jrt.String = jrt.Intern("arbace.j2g.code$v")

var Lit_408 *jrt.String = jrt.Intern("arbace.j2g.code$expressible_QMARK_")

var Lit_409 *jrt.String = jrt.Intern("arbace.j2g.code$compiled_caller_QMARK_")

var Lit_410 *jrt.String = jrt.Intern("arbace.j2g.code$guarded_static_QMARK_")

var Lit_411 *jrt.String = jrt.Intern("arbace.j2g.code$memo_node")

var Lit_412 *jrt.String = jrt.Intern("arbace.j2g.code$simple_QMARK_")

var Lit_413 *jrt.String = jrt.Intern("arbace.j2g.code$simple_STAR_")

var Lit_414 *jrt.String = jrt.Intern("arbace.j2g.code$effects_QMARK_")

var Lit_415 *jrt.String = jrt.Intern("arbace.j2g.code$effects_STAR_")

var Lit_416 *jrt.String = jrt.Intern("arbace.j2g.code$reads_state_QMARK_")

var Lit_417 *jrt.String = jrt.Intern("arbace.j2g.code$stable_QMARK_")

var Lit_418 *jrt.String = jrt.Intern("arbace.j2g.code$hoist_value")

var Lit_419 *jrt.String = jrt.Intern("arbace.j2g.code$any_after")

var Lit_420 *jrt.String = jrt.Intern("arbace.j2g.code$const_num")

var Lit_421 *jrt.String = jrt.Intern("arbace.j2g.code$non_const")

var Lit_422 *jrt.String = jrt.Intern("arbace.j2g.code$index_x")

var Lit_423 *jrt.String = jrt.Intern("arbace.j2g.code$divisor_x")

var Lit_424 *jrt.String = jrt.Intern("arbace.j2g.code$operands")

var Lit_425 *jrt.String = jrt.Intern("arbace.j2g.code$java_hash")

var Lit_426 *jrt.String = jrt.Intern("arbace.j2g.code$string_lit")

var Lit_427 *jrt.String = jrt.Intern("arbace.j2g.code$float_lit")

var Lit_428 *jrt.String = jrt.Intern("arbace.j2g.code$const_value")

var Lit_429 *jrt.String = jrt.Intern("arbace.j2g.code$missing_expr")

var Lit_430 *jrt.String = jrt.Intern("arbace.j2g.code$class_missing")

var Lit_431 *jrt.String = jrt.Intern("arbace.j2g.code$desc_missing")

var Lit_432 *jrt.String = jrt.Intern("arbace.j2g.code$mdesc_missing")

var Lit_433 *jrt.String = jrt.Intern("arbace.j2g.code$hw_static_exists_QMARK_")

var Lit_434 *jrt.String = jrt.Intern("arbace.j2g.code$lookup_call_QMARK_")

var Lit_435 *jrt.String = jrt.Intern("arbace.j2g.code$vh_op")

var Lit_436 *jrt.String = jrt.Intern("arbace.j2g.code$vh_supported_QMARK_")

var Lit_437 *jrt.String = jrt.Intern("arbace.j2g.code$vh_missing")

var Lit_438 *jrt.String = jrt.Intern("arbace.j2g.code$missing_reason")

var Lit_439 *jrt.String = jrt.Intern("arbace.j2g.code$this_val")

var Lit_440 *jrt.String = jrt.Intern("arbace.j2g.code$outer_field")

var Lit_441 *jrt.String = jrt.Intern("arbace.j2g.code$this_path_val")

var Lit_442 *jrt.String = jrt.Intern("arbace.j2g.code$local_val")

var Lit_443 *jrt.String = jrt.Intern("arbace.j2g.code$struct_of")

var Lit_444 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_QMARK_")

var Lit_445 *jrt.String = jrt.Intern("arbace.j2g.code$volatile_field_QMARK_")

var Lit_446 *jrt.String = jrt.Intern("arbace.j2g.code$volatile_read")

var Lit_447 *jrt.String = jrt.Intern("arbace.j2g.code$volatile_write")

var Lit_448 *jrt.String = jrt.Intern("arbace.j2g.code$field_place")

var Lit_449 *jrt.String = jrt.Intern("arbace.j2g.code$target_operands")

var Lit_450 *jrt.String = jrt.Intern("kn8,arglistsyn1,fkn4,linekn6,columnkn4,fileyn1,oyn1,dkn3,dockn8,declaredyn4,nodeyn2,tokn7,privateyn1,xyn1,vyn4,bitsyn1,pyn4,fromyn4,nameyn4,descyn2,xsyn6,m-descyn9,arg-nodesyn1,ryn1,myn5,placeyn1,hyn2,cnkn3,tagyn6,Stringyn5,holesyn4,treeyn7,classesyn13,StringBuilderyn6,targetyn4,jumpyn9,target-fnyn8,val-formyn4,agetyn1,<yn7,bit-xoryn4,zeroyn2,<=yn1,*yn4,makeyn11,bit-and-notyn2,fnyn4,instyn1,>yn1,%yn3,newyn1,-yn2,oryn7,bit-andyn3,lityn3,notyn2,>>yn3,capyn6,assertyn8,subsliceyn1,/yn6,bit-oryn2,>=yn4,addryn4,convyn1,+yn7,bit-notyn2,!=yn2,==yn3,lenyn3,andyn2,<<yn3,ctxkn4,keysyn5,owneryn2,rdyn8,accessoryn1,cyn2,vtyn1,kyn2,xnyn1,eyn7,body-fnyn6,catch?yn7,monitoryn3,ctlyn2,rvyn5,codesyn5,formsyn3,rv?yn4,ctl?yn11,lit-rv-descyn2,fiyn7,markersv15,arbace.j2g.code12,static-placem8,R0,L1,V1,R1,R2,i709,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code15,class-init-callm8,R0,L1,V1,R5,R2,i713,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code9,class-valm10,R0,L1,V1,R6,R7,s33,The Class object of descriptor d.R2,i720,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code10,invoke-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code7,new-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code9,arith-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code11,convert-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code8,cast-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code12,instance-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code12,java-str-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code10,lambda-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,method-ref-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code9,array-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code16,const-or-missingm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,fi-adapter-valm8,R8,TR2,i741,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code5,hoistm10,R0,L1,V1,R9,R7,s88,Translates a node that is not one Go expression into a fresh temporary (assign context).R2,i744,R3,i1,R4,s18,arbace/j2g/code.aem10,R0,L1,V1,R9,R7,s74,Translates node in expression context: {:x go-form :t java-desc :nn bool}.R2,i756,R3,i1,R4,s18,arbace/j2g/code.aem10,R0,L1,V1,R9,R7,s89,The Go expression of an expressible node's own operation (operands translated as needed).R2,i771,R3,i1,R4,s18,arbace/j2g/code.aem10,R0,L1,V2,R9,R10,R7,s271,node's Go expression converted to Java type `to`. A node whose type is null (a block whose\n  value is nil: javac's Resolve.onDemandImportScopeRecovery's lambda) is a statement, then nil\n  of type `to`: its temporary would be Object's, any, which no other interface takes.R2,i858,R3,i1,R4,s18,arbace/j2g/code.aem10,R0,L1,V1,R9,R7,s81,A Go boolean expression of node as a condition (Clojure's truth on non-booleans).R2,i875,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code7,go-lit?m10,R11,TR0,L1,V1,R12,R2,i892,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code12,unsigned-litm12,R11,TR0,L1,V2,R13,R14,R7,s145,A Go literal of the unsigned value of Java integer v of the given width (Go rejects the\n  conversion of a negative constant to an unsigned type).R2,i894,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V1,R9,R2,i903,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V2,R12,R15,R2,i957,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V3,R12,R16,R10,R2,i961,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V1,R9,R2,i978,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V1,R9,R2,i998,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V1,R9,R2,i1026,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,object-helpersm18,V2,s9,notifyAlls3,()Vs9,NotifyAllV2,s8,getClasss19,()Ljava/lang/Class;s8,GetClassV2,s8,toStrings20,()Ljava/lang/String;s8,ToStringV2,s6,equalss21,(Ljava/lang/Object;)Zs6,EqualsV2,s4,waits5,(JI)Vs11,WaitTimeoutV2,s4,waits4,(J)Vs11,WaitTimeoutV2,s6,notifys3,()Vs6,NotifyV2,s8,hashCodes3,()Is8,HashCodeV2,s4,waits3,()Vs4,Waitm8,R11,TR2,i1046,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code18,object-helper-argsm12,R11,TR0,L1,V3,R17,R18,R19,R7,s171,The helper's arguments after the receiver: jrt's WaitTimeout is wait(long, int), so\n  wait(long)'s nanoseconds, 0, are added (javac's BaseFileManager; TimeUnit.timedWait).R2,i1052,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code8,args-form10,R11,TR0,L1,V2,R20,R21,R2,i1058,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code12,super-structm10,R0,L1,V0,R7,s63,The embedded struct of the current class's superclass: (.-B t).R2,i1062,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code6,vh-argm12,R11,TR0,L1,V2,R9,R6,R7,s137,An argument node of a VarHandle call converted to descriptor d as the handle does: a\n  checked cast unless its static type is assignable.R2,i1068,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code9,vh-resultm12,R11,TR0,L1,V3,R12,R6,R22,R7,s132,A VarHandle call's result form x of descriptor d as the call's return type r (the JVM's\n  checkcast of a polymorphic call's result).R2,i1077,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code13,vh-field-formm12,R11,TR0,L1,V4,R23,R24,R6,R19,R7,s143,The Go form of access mode m on the atomic field place (the volatile representation of a\n  field of descriptor d, §8.2) with argument forms xs.R2,i1088,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code6,vh-valm10,R0,L1,V2,R9,R25,R7,s158,A VarHandle access-mode call on a constant handle (J2G-SPEC §8.5): the atomic operation on\n  the field it names, or on the array element (jrt's Vh functions).R2,i1134,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code9,box-primsm10,s19,Ljava/lang/Integer;s5,int32s21,Ljava/lang/Character;s6,uint16s17,Ljava/lang/Short;s5,int16s16,Ljava/lang/Byte;s4,int8s16,Ljava/lang/Long;s5,int64m10,R11,TR2,i1174,R3,i1,R4,s18,arbace/j2g/code.aeR7,s77,A box class's descriptor -> its primitive's Go type (a constant label's Box).m8,R0,L1,V1,R9,R2,i1179,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code9,ctor-argsm10,R0,L1,V2,R9,R26,R7,s219,The Go arguments of constructor ctor of class cn for a :new or :ctor-call node: the outer\n  instance, the superclass's outer instance, the enum constant's name and ordinal, the\n  declared arguments, the captured locals.R2,i1311,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V1,R9,R2,i1331,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code15,const-array-minl4,m10,R11,TR2,i1346,R3,i1,R4,s18,arbace/j2g/code.aeR7,s78,The least number of string leaves for which an initializer is written as data.v15,arbace.j2g.code10,utf8-safe?m12,R11,TR0,L1,V1,Myn1,sm2,R27,R28,R7,s69,Can the Java string travel as Go UTF-8 text (no unpaired surrogates)?R2,i1350,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code10,const-treem12,R11,TR0,L1,V2,R9,R29,R7,s150,node as a constant array tree ([:arr elem-desc trees], [:str s], [:null], [:hole i]), holes\n  collecting the immutable locals, or nil when it is none.R2,i1365,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code13,const-stringsm10,R11,TR0,L1,V1,R30,R2,i1382,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code12,const-encodem12,R11,TR0,L1,V3,R30,R31,Myn2,sbm2,R27,R32,R7,s89,The encoding of a tree (jrt's constarray.ae), classes an atom of the element descriptors.R2,i1388,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code11,const-arraym12,R11,TR0,L1,V1,R9,R7,s110,The ConstRefArray call of a reference array initializer that is a constant tree with enough\n  strings, or nil.R2,i1402,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V1,R9,R2,i1417,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V1,R9,R2,i1441,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code11,target-infom10,R11,TR0,L1,V1,R33,R2,i1467,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code10,code-jump!m12,R11,TR0,L1,V1,R34,R7,s242,A jump (return, break, recur) leaving the Go function literal of a try or locking body: it\n  is recorded in the innermost frame with a control code and performed after the literal\n  returns (§7.9.3). jump is {:kind :return|:break|:recur ...}.R2,i1469,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code8,outside?m10,R11,TR0,L1,V1,R35,R2,i1480,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,method-return!m12,R11,TR0,L1,V1,R36,R7,s88,A return from the method (::void for a void method's), a control code inside a try body.R2,i1482,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code11,set-static!m10,R11,TR0,L1,V1,R9,R2,i1489,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,dropped-store?m12,R11,TR0,L1,V1,R9,R7,s402,A store into a field that the closed world drops (its type is outside it) that can go:\n  a static initializer's store into a field of its class (serialization's\n  serialPersistentFields: nothing can read the field), or the store of the constant null\n  into a field of this object or a static field (PrintWriter's psOut, a PrintStream: the\n  field can hold nothing else, no instance of its type exists).R2,i1501,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code10,set-field!m10,R11,TR0,L1,V1,R9,R2,i1521,R3,i1,R4,s18,arbace/j2g/code.aem10,R0,L1,V1,R9,R7,s37,Translates node in statement context.R2,i1528,R3,i1,R4,s18,arbace/j2g/code.aem10,R11,TR0,L1,V1,R9,R2,i1534,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code8,go-headsS34,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,m8,R11,TR2,i1588,R3,i1,R4,s18,arbace/j2g/code.aem10,R0,L1,V1,R12,R7,s53,Is Go form x a call (which may stand as a statement)?R2,i1592,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code13,assign-value!m10,R11,TR0,L1,V2,R12,R71,R2,i1602,R3,i1,R4,s18,arbace/j2g/code.aem10,R0,L1,V2,R9,R71,R7,s54,Translates node storing its value into ctx's variable.R2,i1608,R3,i1,R4,s18,arbace/j2g/code.aem10,R0,L1,V1,R9,R7,s68,Translates node as the value of the current method (return context).R2,i1613,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code8,ctx-descm10,R11,TR0,L1,V1,R71,R2,i1618,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code13,translate-trym8,R8,TR2,i1620,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code17,translate-monitorm8,R8,TR2,i1620,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,translate-loopm8,R8,TR2,i1620,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code15,translate-labelm8,R8,TR2,i1620,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code16,translate-switchm8,R8,TR2,i1620,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code18,translate-for-eachm8,R8,TR2,i1620,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code21,translate-if-instancem8,R8,TR2,i1620,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code16,translate-and-orm8,R8,TR2,i1620,R3,i1,R4,s18,arbace/j2g/code.aem10,R0,L1,V2,R9,R71,R7,s88,Translates node in context ctx: {:k :stmt}, {:k :assign :var sym :desc d}, {:k :return}.R2,i1623,R3,i1,R4,s18,arbace/j2g/code.aem10,R11,TR0,L1,V2,R9,R71,R2,i1629,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V2,R9,R71,R2,i1746,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code9,new-labelm8,R0,L1,V0,R2,i1771,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V2,R9,R71,R2,i1773,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V2,R9,R71,R2,i1798,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V2,R9,R71,R2,i1807,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code16,pattern-bindingsm10,R11,TR0,L1,V1,R15,R2,i1845,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code15,record-pattern?m10,R11,TR0,L1,V1,R15,R2,i1848,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code16,derived-accessorm12,R11,TR0,L1,V1,m2,R72,V3,R73,R17,R18,R7,s153,The record component field an accessor reads when the record does not declare the accessor\n  itself (the analyzer derived it: it cannot throw), else nil.R2,i1850,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,accessor-call!m12,R11,TR0,L1,V4,R22,R74,R75,R76,R7,s280,Assigns record r's component (accessor `accessor`) to Go variable c. A derived accessor is\n  the field read (records are final, r is not null); a declared one is called, and an\n  exception it throws is wrapped in MatchException(t.toString(), t), as javac wraps it\n  (JLS 14.30.2).R2,i1858,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,match-pattern!m12,R11,TR0,L1,V4,R15,R12,R77,R78,R7,s288,Emits the statements matching Go value x (a stable expression of Java type vt) against\n  pattern p: the type tests, the record components read through their accessors, the\n  bindings assigned (declared before by declare-pattern!); calls k to emit what follows a\n  match, inside the tests.R2,i1882,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code16,declare-pattern!m12,R11,TR0,L1,V3,R15,R12,R77,R7,s117,Declares the bindings of pattern p and a flag; returns the flag, set when the value\n  matches (after match-pattern!).R2,i1918,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,assert-classesS2,s26,arbace/lang/Compiler$AOTFns30,arbace/lang/Compiler$AOTRestFnm10,R11,TR2,i1933,R3,i1,R4,s18,arbace/j2g/code.aeR7,s366,The classes whose if-instance binds by Go's assertion (if-instance-assert): the compiled fns'\n  (Futamura F6: Compiler$AOTFn/linkedFast, the guard of a call of an unboxed entry or a worker,\n  inlined by gc). Every translated class that is no interface could be (doc/FUTAMURA-SURVEY.md,\n  F6.1); only these are, so that the rest of the program's code does not change.v15,arbace.j2g.code18,if-instance-assertm12,R11,TR0,L1,V2,R6,R79,R7,s354,The binding of if-instance's pattern of class d on value xn (a Go value) once its test held,\n  for a class of assert-classes: Go's assertion to the type its C_InstanceOf asserts (the value\n  is not nil and of that type, so C_Cast could neither answer nil nor throw, and gc can inline\n  the assertion where it does not inline C_Cast), else nil (cast-val).R2,i1940,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V2,R9,R71,R2,i1951,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code12,enum-ordinalm10,R11,TR0,L1,V2,R80,R76,R2,i1974,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V2,R9,R71,R2,i1982,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code12,live-catchesm12,R11,TR0,L1,V1,R9,R7,s92,The catch clauses of a try node that can catch something: those naming a class of the world.R2,i2110,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code11,try-literalm12,R11,TR0,L1,V2,R81,m2,R72,V2,R82,R83,R7,s207,Runs body-fn as the body of a Go function literal called in place, with control codes for\n  the jumps out of it. Returns {:call form :codes [...] :has-exc bool :rv? bool} and the\n  literal's statement forms.R2,i2115,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code15,dispatch-codes!m12,R11,TR0,L1,V3,R84,R85,R86,R7,s96,After a try literal: performs the pending jump of each control code in the enclosing\n  function.R2,i2132,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code12,literal-formm12,R11,TR0,L1,V3,m2,R72,V4,R87,R86,R88,R89,R82,R90,R7,s87,The Go function literal and its call: results ctl, rv (when used), exc (when catching).R2,i2153,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V2,R9,R71,R2,i2176,R3,i1,R4,s18,arbace/j2g/code.aem8,R0,L1,V2,R9,R71,R2,i2249,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code7,sam-sigm8,R0,L1,V1,R91,R2,i2274,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,lambda-markersm10,R0,L1,V1,R9,R7,s332,The marker interfaces of a lambda or method reference whose target is an intersection\n  (\"(& Comparator Serializable)\": LambdaMetafactory's altMetafactory makes its class implement\n  them; amendment JB5): Serializable when serializable, and the other markers, those in the\n  world that the interface does not already extend, sorted.R2,i2279,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code11,adapter-symm10,R0,L2,V1,R91,V2,R91,R92,R7,s176,The adapter type F_Fn of functional interface fi, recorded for generation in fi's package;\n  with marker interfaces, the adapter F_Fn_M1_..._Mn that also implements them (JB5).R2,i2290,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code19,convert-ref-or-primm12,R11,TR0,L1,V3,R12,R16,R10,R7,s130,Converts Go value x of Java type from to Java type to, as LambdaMetafactory adapts:\n  casts, unboxing, boxing, primitive widening.R2,i2298,R3,i1,R4,s18,arbace/j2g/code.aev15,arbace.j2g.code14,serial-lambdasm8,R2,i2324,R3,i1,R4,s18,arbace/j2g/code.aeR7,s61,jrt's own Java the serializable lambdas' sites register with.")

var Lit_451 *jrt.String = jrt.Intern("arbace.j2g.code$static_place")

var Lit_452 *jrt.String = jrt.Intern("arbace.j2g.code$class_init_call")

var Lit_453 *jrt.String = jrt.Intern("arbace.j2g.code$class_val")

var Lit_454 *jrt.String = jrt.Intern("arbace.j2g.code$hoist")

var Lit_455 *jrt.String = jrt.Intern("arbace.j2g.code$expr")

var Lit_456 *jrt.String = jrt.Intern("arbace.j2g.code$expr_op")

var Lit_457 *jrt.String = jrt.Intern("arbace.j2g.code$expr_as")

var Lit_458 *jrt.String = jrt.Intern("arbace.j2g.code$cond_expr")

var Lit_459 *jrt.String = jrt.Intern("arbace.j2g.code$go_lit_QMARK_")

var Lit_460 *jrt.String = jrt.Intern("arbace.j2g.code$unsigned_lit")

var Lit_461 *jrt.String = jrt.Intern("arbace.j2g.code$arith_val")

var Lit_462 *jrt.String = jrt.Intern("arbace.j2g.code$box_val")

var Lit_463 *jrt.String = jrt.Intern("arbace.j2g.code$prim_convert")

var Lit_464 *jrt.String = jrt.Intern("arbace.j2g.code$convert_val")

var Lit_465 *jrt.String = jrt.Intern("arbace.j2g.code$cast_val")

var Lit_466 *jrt.String = jrt.Intern("arbace.j2g.code$instance_val")

var Lit_467 *jrt.String = jrt.Intern("arbace.j2g.code$object_helper_args")

var Lit_468 *jrt.String = jrt.Intern("arbace.j2g.code$args_for")

var Lit_469 *jrt.String = jrt.Intern("arbace.j2g.code$super_struct")

var Lit_470 *jrt.String = jrt.Intern("arbace.j2g.code$vh_arg")

var Lit_471 *jrt.String = jrt.Intern("arbace.j2g.code$vh_result")

var Lit_472 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form")

var Lit_473 *jrt.String = jrt.Intern("arbace.j2g.code$vh_val")

var Lit_474 *jrt.String = jrt.Intern("arbace.j2g.code$invoke_val")

var Lit_475 *jrt.String = jrt.Intern("arbace.j2g.code$ctor_args")

var Lit_476 *jrt.String = jrt.Intern("arbace.j2g.code$new_val")

var Lit_477 *jrt.String = jrt.Intern("arbace.j2g.code$utf8_safe_QMARK_")

var Lit_478 *jrt.String = jrt.Intern("arbace.j2g.code$const_tree")

var Lit_479 *jrt.String = jrt.Intern("arbace.j2g.code$const_strings")

var Lit_480 *jrt.String = jrt.Intern("arbace.j2g.code$const_encode")

var Lit_481 *jrt.String = jrt.Intern("arbace.j2g.code$const_array")

var Lit_482 *jrt.String = jrt.Intern("arbace.j2g.code$array_val")

var Lit_483 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val")

var Lit_484 *jrt.String = jrt.Intern("arbace.j2g.code$target_info")

var Lit_485 *jrt.String = jrt.Intern("arbace.j2g.code$code_jump_BANG_")

var Lit_486 *jrt.String = jrt.Intern("arbace.j2g.code$outside_QMARK_")

var Lit_487 *jrt.String = jrt.Intern("arbace.j2g.code$method_return_BANG_")

var Lit_488 *jrt.String = jrt.Intern("arbace.j2g.code$set_static_BANG_")

var Lit_489 *jrt.String = jrt.Intern("arbace.j2g.code$dropped_store_QMARK_")

var Lit_490 *jrt.String = jrt.Intern("arbace.j2g.code$set_field_BANG_")

var Lit_491 *jrt.String = jrt.Intern("arbace.j2g.code$stmt_BANG_")

var Lit_492 *jrt.String = jrt.Intern("arbace.j2g.code$stmt_BANG__STAR_")

var Lit_493 *jrt.String = jrt.Intern("arbace.j2g.code$go_call_QMARK_")

var Lit_494 *jrt.String = jrt.Intern("arbace.j2g.code$assign_value_BANG_")

var Lit_495 *jrt.String = jrt.Intern("arbace.j2g.code$assign_BANG_")

var Lit_496 *jrt.String = jrt.Intern("arbace.j2g.code$ret_BANG_")

var Lit_497 *jrt.String = jrt.Intern("arbace.j2g.code$ctx_desc")

var Lit_498 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx")

var Lit_499 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_")

var Lit_500 *jrt.String = jrt.Intern("arbace.j2g.code$translate_and_or")

var Lit_501 *jrt.String = jrt.Intern("arbace.j2g.code$new_label")

var Lit_502 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop")

var Lit_503 *jrt.String = jrt.Intern("arbace.j2g.code$translate_label")

var Lit_504 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each")

var Lit_505 *jrt.String = jrt.Intern("arbace.j2g.code$pattern_bindings")

var Lit_506 *jrt.String = jrt.Intern("arbace.j2g.code$record_pattern_QMARK_")

var Lit_507 *jrt.String = jrt.Intern("arbace.j2g.code$derived_accessor")

var Lit_508 *jrt.String = jrt.Intern("arbace.j2g.code$accessor_call_BANG_")

var Lit_509 *jrt.String = jrt.Intern("arbace.j2g.code$match_pattern_BANG_")

var Lit_510 *jrt.String = jrt.Intern("arbace.j2g.code$declare_pattern_BANG_")

var Lit_511 *jrt.String = jrt.Intern("arbace.j2g.code$if_instance_assert")

var Lit_512 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance")

var Lit_513 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal")

var Lit_514 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch")

var Lit_515 *jrt.String = jrt.Intern("arbace.j2g.code$live_catches")

var Lit_516 *jrt.String = jrt.Intern("arbace.j2g.code$try_literal")

var Lit_517 *jrt.String = jrt.Intern("arbace.j2g.code$dispatch_codes_BANG_")

var Lit_518 *jrt.String = jrt.Intern("arbace.j2g.code$literal_form")

var Lit_519 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try")

var Lit_520 *jrt.String = jrt.Intern("arbace.j2g.code$translate_monitor")

var Lit_521 *jrt.String = jrt.Intern("arbace.j2g.code$sam_sig")

var Lit_522 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_markers")

var Lit_523 *jrt.String = jrt.Intern("arbace.j2g.code$adapter_sym")

var Lit_524 *jrt.String = jrt.Intern("arbace.j2g.code$convert_ref_or_prim")

var Lit_525 *jrt.String = jrt.Intern("jdk/internal/jrt/SerialLambdas")

var Lit_526 *jrt.String = jrt.Intern("kn4,linekn6,columnkn4,filekn3,dockn8,arglistsyn4,nodekn7,privateyn9,adapter-xyn4,capsyn5,extrav15,arbace.j2g.code22,serial-lambdas-methodsm8,R0,i2326,R1,i1,R2,s18,arbace/j2g/code.aeR3,s88,SerialLambdas' methods a site calls ([name desc]); reachability roots (arbace.j2g.main).V2,s8,instances76,(Ljdk/internal/jrt/SerialLambdas$Site;[Ljava/lang/Object;)Ljava/lang/Object;V2,s7,replaces38,(Ljava/lang/Object;)Ljava/lang/Object;v11,arbace.core3,strv15,arbace.j2g.code12,serial-site?m10,R4,L1,V1,R5,R3,s88,Is node (a lambda or method reference) serializable in a world with jrt's SerialLambdas?R0,i2334,R1,i1,R2,s18,arbace/j2g/code.aev15,arbace.j2g.code11,serial-implm12,R6,TR4,L1,V1,R5,R3,s354,The SerializedLambda's implementation of node: [kind class name signature], as javac and\n  LambdaMetafactory give them (a lambda's own method lambda$..., static or, capturing this, an\n  instance method; a method reference's method and its MethodHandleInfo REF_ kind); the\n  signature of a lambda's method its captured values' types, then its parameters'.R0,i2339,R1,i1,R2,s18,arbace/j2g/code.aev15,arbace.j2g.code17,serial-lambda-valm10,R4,L1,V4,R5,R7,R8,R9,R3,s562,A serializable lambda's or method reference's value (JCS169): the adapter value made by a\n  factory of its captured values, which the site registers with SerialLambdas as javac's\n  $deserializeLambda$ would find it, and whose objects hold their serial state (the adapter's Ser:\n  SerialLambdas.instance), so that the adapter's writeReplace answers a SerializedLambda. caps are\n  [go-name java-type] of the Go locals the adapter's code closes over (the receiver first): the\n  factory's code is the site's, those names shadowed by the factory's captured arguments.R0,i2356,R1,i1,R2,s18,arbace/j2g/code.aev15,arbace.j2g.code13,receiver-capsm12,R6,TR4,L1,V0,R3,s182,The enclosing object as serial-lambda-val's caps and extra bindings: [[this-sym its type]] and,\n  for a class whose struct is not its object (not a leaf), the struct t bound from it.R0,i2401,R1,i1,R2,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R0,i2410,R1,i1,R2,s18,arbace/j2g/code.aem10,R4,L1,V1,R5,R3,s313,Clojure's adapter of an argument to a functional interface parameter (Compiler's\n  FISupport.maybeEmitFIAdapter; :fi-adapter): an IFn that is not already an instance of the\n  interface becomes its adapter F_Fn (§7.11) calling FnInvokers' invoker, as the JVM's\n  LambdaMetafactory site does; anything else is cast.R0,i2439,R1,i1,R2,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R0,i2465,R1,i1,R2,s18,arbace/j2g/code.ae")

var Lit_527 *jrt.String = jrt.Intern("register")

var Lit_528 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;")

var Lit_529 *jrt.String = jrt.Intern("Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljdk/internal/jrt/SerialLambdas$Factory;)")

var Lit_530 *jrt.String = jrt.Intern("arbace.j2g.code$serial_site_QMARK_")

var Lit_531 *jrt.String = jrt.Intern("arbace.j2g.code$serial_impl")

var Lit_532 *jrt.String = jrt.Intern("arbace.j2g.code$serial_lambda_val")

var Lit_533 *jrt.String = jrt.Intern("arbace.j2g.code$receiver_caps")

var Lit_534 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val")

var Lit_535 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val")

var Lit_536 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val")
