//line j2g_strings.ae:1
package aot_arbace_j2g_code

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn17,arbace.j2g.accessyn3,accyn13,arbace.j2g.vhyn2,vhkn3,dockn4,desckn5,flagskn5,classkn6,clinitkn4,ctorkn4,synckn11,locked-thiskn4,namekn11,method-nameks15,arbace.j2g.code4,failkn3,pkgkn3,tagkn7,counterkn5,takenkn3,tmpkn4,usedkn2,idkn5,nameskn3,symks3,j2g4,linekn3,letyn4,zeroyn1,_yn4,set!yn3,letkn4,typekn4,nullkn4,elseyn4,convyn3,anyyn4,.Refkn3,upskn4,noneyn4,instkn1,xkn1,tkn2,opkn2,orkn3,andkn10,method-refkn5,boundkn4,kindkn10,set-statickn10,get-statickn5,fieldkn8,declarerkn5,ownerkn6,statickn6,simplekn6,lambdakn4,recvkn6,targetkn4,argskn5,elemskn4,dimskn4,exprkn3,valkn5,arraykn5,indexkn4,basekn4,nodekn5,partskn7,effectskn7,alengthkn7,convertkn9,get-fieldkn5,arithkn4,agetkn3,remkn3,divkn9,this-pathkn4,fromkn1,okn3,newkn10,var-invokekn6,invokekn8,java-strkn9,var-derefkn9,class-litkn5,constkn5,localkn7,mutablekn1,bkn4,purekn7,missingkn2,nnkn4,litskn10,lit-prefixyn4,boolkn5,funcskn3,jrtkn7,handleskn2,vhkn3,getkn3,caskn4,swapkn3,addkn3,setkn3,xorkn7,cmpxchgks15,arbace.j2g.code5,vh-okkn4,viewkn4,modekn4,castkn9,instance?kn4,varskn6,constskn6,bigintkn6,methodkn11,array-clonekn7,specialkn11,outer-superkn9,new-arraykn9,set-fieldkn10,array-initkn2,fikn10,fi-adapterkn4,thiskn4,pathkn11,outer-paramkn5,outerkn8,capturedkn6,fieldsyn5,.Loadyn4,int8yn6,uint16ys4,math15,Float64frombitsys4,math15,Float32frombitsyn5,int16yn6,.Storeyn5,int32ys4,math11,Float64bitsys4,math11,Float32bitskn3,ptryn11,.ArrayClasskn4,cutskn3,varks15,arbace.j2g.code2,gokn12,null-checkedyn9,.Deref__Oyn3,andyn2,orkn7,comparekn4,nil?kn3,cmpyn2,==kn10,identical?kn3,notyn3,notkn16,outer-param-pathkn5,bool=yn3,lenyn3,.-Aks3,c2j2,nnkn4,metakn6,memberyn4,agetyn2,!=kn6,familykn4,ushrkn3,shrkn3,shlyn7,bit-andyn1,*kn5,exactkn3,mulkn3,subkn3,decyn1,/kn3,incyn1,%yn7,float32ys4,math3,Modyn7,float64yn5,int64yn2,>>yn6,uint64yn6,uint32yn1,-yn7,bit-notyn6,bit-oryn1,+yn7,bit-xorkn3,negkn6,andnotyn11,bit-and-notyn2,<<kn2,toyn16,.IsInstance_O__Zkn5,superkn4,boolkn3,i32kn6,narrowkn3,i64kn3,f32kn3,f64kn3,volyn4,addryn14,.CompareAndSetyn15,.CompareAndSwapyn5,.Swapkn5,orderkn7,cast-toyn5,.Copykn10,enum-constkn4,anonkn15,outer-instance?kn11,super-outerkn7,ordinalkn7,nestingkn8,captureskn5,statekn4,holekn3,strkn3,arryn3,lityn5,slicekn7,literalkn9,tag-constkn7,targetskn9,try-framekn5,codeskn4,codeyn6,returnkn2,rvkn7,rv-zerokn5,fn-idkn9,method-fnkn6,returnks15,arbace.j2g.code4,voidkn4,linekn5,breakkn6,assertkn3,trykn2,ifkn1,kkn4,stmtkn9,ctor-callkn12,ctor-call-fnkn4,asetyn4,asetkn5,labelkn11,if-instancekn8,for-eachkn6,switchkn4,loopkn7,monitorkn5,recurkn8,bindingskn4,cvalkn4,bodykn9,set-localkn2,dokn10,statementskn3,retkn5,throwyn4,whenyn5,panickn10,method-retkn6,assignkn3,msgkn4,jumpkn3,ctxkn4,testkn8,msg-desckn4,thenyn2,ifyn2,dokn10,label-usedyn5,breakkn5,typesyn6,valuesyn8,continueyn5,labelyn5,whileyn6,switchyn7,defaultkn6,hiddenkn4,elemkn3,lenkn1,ikn4,collyn3,foryn1,<yn4,inc!kn2,itkn8,iteratoryn11,.HasNext__Zkn7,patternkn5,compskn6,recordkn15,record-accessorkn7,derivedkn7,methodskn7,virtualyn2,fnkn7,resultsyn3,excyn5,deferkn8,accessorkn9,constantskn14,enum-constantskn5,caseskn7,defaultkn5,guardkn4,enumyn12,.Equals_O__Zkn3,intkn6,stringkn6,labelskn3,selyn4,caseyn4,condyn12,.HashCode__Ikn8,sel-typeyn11,.-F_ordinalyn10,.Self_Enumkn7,classeskn7,catcheskn6,catch?kn5,formskn3,rv?kn4,ctl?yn3,ctlyn2,rvkn7,finallykn14,normal-finallykn4,lockkn3,samkn2,pskn1,rkn12,serializablekn7,markerskn7,lambdaskn6,paramskn9,inst-desckn2,Fnkn12,invoker-descyn1,fkn7,invokeryn1,xyn4,isfnyn6,assertkn7,unboundkn10,null-checkv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.j2g.codem2,R18,s410,j2g's translation of code (J2G-SPEC §7): the analyzer's typed nodes to Go statements and\n  expressions, in four contexts (statement, return, assign, expression, §7.2), with\n  temporaries for Java's order of evaluation, Java's arithmetic (§7.4), null checks and the\n  typed-nil rule (§5.6), try/catch/finally and control codes (§7.9), monitors (§8.1), loops,\n  labels and switches (§7.7, §7.8), lambdas (§7.11).v11,arbace.core13,*loaded-libs*v15,arbace.j2g.code7,*races*v16,arbace.j2g.model7,static?v16,arbace.j2g.model11,iface-desc?v11,arbace.core3,notv11,arbace.core5,swap!R19,v16,arbace.j2g.model4,has?R20,l16,l64,R21,v15,arbace.j2g.code3,*f*R22,R23,R24,R25,R26,R27,v11,arbace.core7,ex-infov11,arbace.core5,mergem2,R28,TR29,v16,arbace.j2g.model7,jrt-symv15,arbace.j2g.code3,pkgv16,arbace.j2g.model9,class-symv16,arbace.j2g.model7,go-typev11,arbace.core9,with-metaR30,R31,v11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core3,incl0,R32,v16,arbace.j2g.names10,local-namev11,arbace.core9,contains?v11,arbace.core6,symbolv15,arbace.j2g.code9,fresh-rawv15,arbace.j2g.code12,new-counter!R33,R34,v11,arbace.core3,strR35,v15,arbace.j2g.code5,freshR36,R37,v11,arbace.core5,assocv15,arbace.j2g.code6,*line*v11,arbace.core4,seq?v11,arbace.core9,vary-metaR38,v15,arbace.j2g.code7,*block*v15,arbace.j2g.code9,with-lineR39,v15,arbace.j2g.code3,tagv11,arbace.core5,some?v11,arbace.core4,listR40,v11,arbace.core7,reversev11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,nextv11,arbace.core7,vector?v11,arbace.core4,restv11,arbace.core3,vecv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core7,symbol?v11,arbace.core4,not=R41,v11,arbace.core12,chunk-appendR42,R41,v11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core6,concatv11,arbace.core6,mapcatv11,arbace.core5,applyv11,arbace.core4,someR43,v15,arbace.j2g.code10,fold-itemsv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core4,atomv22,arbace.classes.analyze10,value-typeR44,R45,S5,s1,Js1,Ss1,Cs1,Bs1,IS2,s1,Fs1,Dd0,R46,v11,arbace.core7,number?v11,arbace.core8,boolean?v11,arbace.core7,string?v15,arbace.j2g.code12,object-like?v13,arbace.string12,starts-with?v16,arbace.j2g.model11,code-class?v20,arbace.classes.types14,desc->internalR47,R48,R49,R50,v15,arbace.j2g.code10,*pkgstate*v16,arbace.j2g.names9,desc-codev20,arbace.classes.types5,prim?v15,arbace.j2g.code7,zero-ofR51,v15,arbace.j2g.code12,prim-convertv15,arbace.j2g.code6,coercev20,arbace.classes.types8,unbox-ofv15,arbace.j2g.code4,failv16,arbace.j2g.model13,pointer-desc?v15,arbace.j2g.code6,up-symv15,arbace.j2g.code6,gotypev15,arbace.j2g.code7,box-valv20,arbace.classes.types6,box-ofv16,arbace.j2g.names11,method-basev20,arbace.classes.types15,prim-desc->namev15,arbace.j2g.code4,jsymR52,v11,arbace.core8,to-arrayR53,R54,v15,arbace.j2g.code10,simple-opsR55,S2,R56,R57,R58,R59,R60,v15,arbace.j2g.code15,guarded-static?v16,arbace.j2g.names15,compiled-class?S2,R61,R62,R63,R64,R65,v16,arbace.j2g.model11,translated?v16,arbace.j2g.model13,trivial-init?v18,arbace.classes.env9,subclass?v15,arbace.j2g.code16,compiled-caller?v16,arbace.j2g.model12,start-class?v16,arbace.j2g.model8,nest-topR66,v15,arbace.j2g.code11,*node-memo*v15,arbace.j2g.code9,memo-nodeR67,v15,arbace.j2g.code7,simple*v17,arbace.j2g.access8,unaccessv15,arbace.j2g.code12,expressible?v11,arbace.core6,every?v15,arbace.j2g.code14,missing-reasonv15,arbace.j2g.code7,simple?R68,v11,arbace.core6,removev11,arbace.core4,nil?R69,v11,arbace.core4,map?R70,v11,arbace.core6,filterR71,R72,R73,v11,arbace.core4,keepR74,R75,R76,R77,R78,R79,R80,R81,v15,arbace.j2g.code8,effects*v11,arbace.core9,volatile!v15,arbace.j2g.code10,effect-opsS5,R82,R83,R84,R85,R86,S2,R82,R86,R84,R83,v20,arbace.classes.types4,ref?R85,S2,R87,R88,S2,s1,Js1,Iv11,arbace.core7,vreset!R89,R90,R91,S6,R58,R68,R92,R93,R94,R95,S5,R96,R82,R84,R62,R86,S2,R87,R88,S2,s1,Js1,IR97,R98,R99,R100,R101,v15,arbace.j2g.code3,tmpv15,arbace.j2g.code5,decl!v15,arbace.j2g.code8,use-sym!R102,v15,arbace.j2g.code9,any-afterv11,arbace.core4,mapvv15,arbace.j2g.code8,effects?v15,arbace.j2g.code12,reads-state?v15,arbace.j2g.code7,stable?v11,arbace.core5,rangev15,arbace.j2g.code4,exprR103,v15,arbace.j2g.code11,hoist-valuev15,arbace.j2g.code12,missing-exprR104,R105,R106,v15,arbace.j2g.code1,vS4,s1,Js1,Ss1,Bs1,IS2,s1,Fs1,Dv11,arbace.core5,char?v15,arbace.j2g.code9,float-litv15,arbace.j2g.code10,string-litv11,arbace.core8,keyword?v16,arbace.j2g.model12,erased-desc?R47,R52,R107,v16,arbace.j2g.model9,in-world?v13,arbace.string7,replacev15,arbace.j2g.code13,class-missingv16,arbace.j2g.model12,desc-classesv16,arbace.j2g.model19,method-desc-classesv16,arbace.j2g.model11,j2g-static?R108,R109,v16,arbace.j2g.model3,*w*v16,arbace.j2g.model7,go-nameR94,v11,arbace.core6,empty?v13,arbace.j2g.vh9,op-handleR110,R111,R112,S2,s1,Js1,IR57,S3,s1,Js1,Zs1,IS2,s1,Js1,IR113,S2,s1,Js1,IR114,S2,s1,Js1,IR115,S4,s1,Js1,Fs1,Is1,DR56,S3,s1,Js1,Zs1,IS2,s1,Js1,IR116,S2,s1,Js1,IR117,S3,s1,Js1,Zs1,IS2,s1,Js1,IR118,S2,s1,Js1,Iv13,arbace.j2g.vh6,fence?R119,v15,arbace.j2g.code12,lookup-call?v13,arbace.j2g.vh9,varhandlev15,arbace.j2g.code5,vh-opS2,R76,R120,v20,arbace.classes.types9,elem-typeR120,S2,s3,sets3,getv15,arbace.j2g.code13,vh-supported?R121,v15,arbace.j2g.code12,desc-missingv16,arbace.j2g.model13,hand-written?v16,arbace.j2g.names17,static-field-nameR122,R123,R124,R125,R126,R61,R127,v15,arbace.j2g.code10,vh-missingR128,v15,arbace.j2g.code13,mdesc-missingR129,R130,v15,arbace.j2g.code17,hw-static-exists?v16,arbace.j2g.model17,hw-method-exists?R131,v16,arbace.j2g.model14,all-supertypesv16,arbace.j2g.model16,member-in-world?R132,R133,R92,v16,arbace.j2g.names8,new-nameR134,R135,R62,R136,v20,arbace.classes.types14,internal->descv16,arbace.j2g.model5,leaf?v16,arbace.j2g.names10,field-namev22,arbace.classes.analyze10,this0-nameR137,v15,arbace.j2g.code8,this-valR138,v15,arbace.j2g.code11,outer-fieldR139,v22,arbace.classes.analyze4,declR140,v15,arbace.j2g.code11,binding-symv16,arbace.j2g.model9,fields-ofv11,arbace.core10,take-whilev16,arbace.j2g.model16,superclass-chainR141,v15,arbace.j2g.code9,vh-field?v15,arbace.j2g.code13,volatile-flagR142,R47,R143,R47,R144,R145,R146,R47,R147,R148,R47,R149,R150,R151,v15,arbace.j2g.code9,struct-ofR152,v11,arbace.core4,intov15,arbace.j2g.code8,operandsv16,arbace.j2g.names10,munge-namev15,arbace.j2g.code4,csymv20,arbace.classes.types6,array?R153,v15,arbace.j2g.code9,class-valR154,v15,arbace.j2g.code2,vtv15,arbace.j2g.code5,stmt!v15,arbace.j2g.code7,assign!R155,R156,v15,arbace.j2g.code5,hoistv15,arbace.j2g.code7,expr-opv15,arbace.j2g.code5,emit!v15,arbace.j2g.code8,cast-valv15,arbace.j2g.code15,target-operandsv15,arbace.j2g.code11,field-placeR157,v15,arbace.j2g.code10,lambda-valV1,nv15,arbace.j2g.code15,volatile-field?v15,arbace.j2g.code13,volatile-readR52,v15,arbace.j2g.code11,convert-valR96,R93,v20,arbace.classes.types10,lang-classR158,v15,arbace.j2g.code12,static-placev11,arbace.core6,repeatv20,arbace.classes.types11,method-descv11,arbace.core3,mapR158,v15,arbace.j2g.code10,invoke-valR159,R160,v15,arbace.j2g.code9,cond-exprR161,R162,V2,nnv11,arbace.core4,nameR163,v15,arbace.j2g.code9,local-valR164,v15,arbace.j2g.code12,instance-valR165,v15,arbace.j2g.code9,arith-valV2,nnR164,R164,R164,R164,R47,R48,R47,R48,R166,v15,arbace.j2g.code7,new-valR167,v15,arbace.j2g.code9,array-valR168,R169,R82,V2,s1,Zs1,ZR164,R47,R149,R170,R171,v15,arbace.j2g.code14,method-ref-valR172,R173,R174,v15,arbace.j2g.code13,this-path-valR86,v15,arbace.j2g.code14,fi-adapter-valV2,ns1,IR175,R171,R52,R95,v15,arbace.j2g.code12,java-str-valv15,arbace.j2g.code11,const-valueS2,R98,R99,R176,v11,arbace.core6,float?v11,arbace.core6,bigintr21,18446744073709551616NR177,S3,R178,R179,R180,v15,arbace.j2g.code7,go-lit?R181,R47,R182,R183,R184,R88,R87,S2,s1,Fs1,DR178,R185,R186,R187,R188,R189,R47,R190,R191,R47,R192,R47,R192,R191,R189,R47,R193,R194,R47,R195,v15,arbace.j2g.code12,unsigned-litR47,R149,R194,R47,R196,l32,R197,S2,s1,Fs1,DR197,l1,R182,R187,R198,R199,R181,R179,R200,R194,R201,R202,R200,R203,R197,R180,R204,R205,S4,s1,Ss1,Cs1,Bs1,IS2,s1,Fs1,Dv15,arbace.j2g.code13,fold-int-convS2,s1,Fs1,DV2,s1,Ds1,BV2,s1,Ds1,CV2,s1,Ds1,IV2,s1,Ds1,JS4,s1,Ss1,Cs1,Bs1,IV2,s1,Ds1,SV2,s1,Fs1,BV2,s1,Fs1,CV2,s1,Fs1,IV2,s1,Fs1,JV2,s1,Fs1,SV2,s1,Js1,BV2,s1,Js1,CR47,v16,arbace.j2g.model7,prim-goV2,s1,Js1,SR47,R206,v18,arbace.classes.env11,assignable?R52,R52,R207,R207,v20,arbace.classes.types17,parse-method-descR208,R209,R210,S3,s1,Ss1,Cs1,BR211,R212,R213,R214,R215,R47,R149,R47,R143,R47,R144,R47,R147,R151,R150,R146,R145,R216,R217,R218,R218,R218,R219,R219,R219,v15,arbace.j2g.code14,volatile-writev15,arbace.j2g.code9,vh-resultv15,arbace.j2g.code6,vh-argv11,arbace.core6,secondv11,arbace.core4,dropl2,V2,s2,[Bs1,IR220,v15,arbace.j2g.code13,vh-field-formv15,arbace.j2g.code6,vh-valv15,arbace.j2g.code8,args-forv16,arbace.j2g.model10,interface?v14,arbace.j2g.jrt14,struct-methodsv16,arbace.j2g.model8,private?S2,R89,R99,v15,arbace.j2g.code14,object-helpersS4,V2,s9,notifyAlls3,()VV2,s4,waits4,(J)VV2,s6,notifys3,()VV2,s4,waits3,()VR47,R48,R221,R222,R164,v16,arbace.j2g.names9,impl-namev15,arbace.j2g.code12,super-structV1,nv16,arbace.j2g.model4,infov11,arbace.core8,split-atR223,S2,R224,R99,R225,R226,R227,R228,R229,R230,v22,arbace.classes.analyze14,ctor-real-descv15,arbace.j2g.code9,ctor-argsv16,arbace.j2g.model3,pkgv16,arbace.j2g.names8,pkg-nameV1,R45,v15,arbace.j2g.code10,utf8-safe?R231,R232,v15,arbace.j2g.code10,const-treeR233,v11,arbace.core6,reducev11,arbace.core1,+v15,arbace.j2g.code13,const-stringsv11,arbace.core12,keep-indexedv15,arbace.j2g.code12,const-encodev15,arbace.j2g.code15,const-array-minR234,R235,R182,v15,arbace.j2g.code11,const-arrayv16,arbace.j2g.model13,prim-array-gov11,arbace.core4,subsv11,arbace.core6,zipmapR236,R237,R47,R149,v11,arbace.core11,map-indexedl-1,R238,R239,R240,R241,R242,R243,R244,R245,v15,arbace.j2g.code8,outside?v15,arbace.j2g.code10,code-jump!R246,R247,R248,R242,R242,v15,arbace.j2g.code7,expr-asv15,arbace.j2g.code15,class-init-callv15,arbace.j2g.code11,note-store!R42,S2,R61,R132,S2,R61,R132,v16,arbace.j2g.model14,desc-in-world?R42,v15,arbace.j2g.code6,stmt!*R249,R250,v15,arbace.j2g.code13,translate-ctxR251,R252,R253,v15,arbace.j2g.code14,dropped-store?m2,R254,R255,m2,R254,R255,m2,R254,R255,R256,R257,m2,R254,R255,R258,R259,R171,R148,R260,R261,m2,R254,R255,R262,m2,R254,R255,v15,arbace.j2g.code10,set-field!m2,R254,R255,R263,v15,arbace.j2g.code11,set-static!m2,R254,R255,R264,R265,m2,R254,R255,m2,R254,R255,R266,R267,R268,R269,m2,R254,R255,R270,R271,R42,v11,arbace.core4,run!R272,R273,R274,R275,m2,R254,R255,R276,R277,v15,arbace.j2g.code14,method-return!m2,R254,R255,v15,arbace.j2g.code8,go-call?R42,R41,v15,arbace.j2g.code8,go-headsR254,R278,R255,R42,v15,arbace.j2g.code14,translate-ctx*v15,arbace.j2g.code8,ctx-descv15,arbace.j2g.code13,assign-value!R279,v15,arbace.j2g.code21,translate-if-instancev15,arbace.j2g.code16,translate-and-orR280,v15,arbace.j2g.code11,target-infoR281,m2,R254,R280,R282,R283,R275,R159,R167,R167,R276,v15,arbace.j2g.code17,translate-monitorv15,arbace.j2g.code13,translate-tryv15,arbace.j2g.code10,with-blockv15,arbace.j2g.code18,translate-for-eachR284,R275,R285,R286,R286,v15,arbace.j2g.code16,translate-switchm2,R254,R280,v15,arbace.j2g.code15,translate-labelv15,arbace.j2g.code14,translate-loopm6,R55,R98,R44,R45,R75,nm2,R254,R255,R287,R288,R289,R42,R42,R290,R290,R291,m2,R254,R255,R285,R286,R286,R42,m4,R55,R51,R44,R51,R259,R171,R148,S2,R45,R51,R275,R275,R275,R167,v11,arbace.core7,keywordv15,arbace.j2g.code9,new-labelR288,v11,arbace.core4,compv11,arbace.core8,assoc-inR292,R293,R293,R292,R294,R295,R296,R297,m2,R254,R255,m2,R254,R255,R298,R299,R300,R149,R47,R149,R170,R171,R149,R292,R301,R302,R303,R304,R305,R292,R293,R306,v11,arbace.core3,popv11,arbace.core4,peekR42,v15,arbace.j2g.code16,pattern-bindingsR307,R308,R309,R310,R311,R312,v15,arbace.j2g.code16,derived-accessorR42,R313,R42,R314,R315,R316,R317,R216,R316,R42,R242,R275,R176,R276,R318,v15,arbace.j2g.code14,match-pattern!v15,arbace.j2g.code14,accessor-call!R42,R285,R286,R107,R42,v15,arbace.j2g.code15,record-pattern?v15,arbace.j2g.code16,declare-pattern!R285,R286,R286,R285,R286,R286,R319,v18,arbace.classes.env9,reflectedR320,R321,R322,v11,arbace.core4,lastS4,R276,R242,R291,R288,v11,arbace.core6,reset!R288,R323,R275,R324,R164,R325,R326,R327,v11,arbace.core8,group-byR328,v11,arbace.core6,vectorR42,R329,R275,R164,R275,R164,R276,R275,R176,R160,R275,R292,R294,R295,R294,R330,R295,v15,arbace.j2g.code9,java-hashR149,R294,R330,R331,R325,R42,R332,v11,arbace.core7,sort-byv11,arbace.core3,keyR294,R330,R295,R333,R334,R334,R335,R294,R330,v15,arbace.j2g.code12,enum-ordinalR295,R336,R337,R338,v11,arbace.core6,gensymR339,R340,R341,R330,R286,m2,R254,R280,R291,R294,R242,R314,R242,R342,R149,R343,R107,R316,R314,R314,R317,R216,R316,R242,R344,R345,V2,m2,R254,R255,nv15,arbace.j2g.code11,try-literalv15,arbace.j2g.code12,literal-formv15,arbace.j2g.code15,dispatch-codes!m2,R338,TR290,R275,R164,v15,arbace.j2g.code12,live-catchesR160,R286,v11,arbace.core8,take-nthR275,R176,R331,R276,R275,R176,R276,m2,R338,TR290,R275,R176,R276,V2,m2,R254,R255,nR317,R346,R290,v22,arbace.classes.analyze8,find-samR347,R348,R349,v11,arbace.core4,sortv11,arbace.core8,distinctR350,V1,s20,java/io/SerializableR351,R352,v15,arbace.j2g.code11,adapter-symv15,arbace.j2g.code7,sam-sigR353,v15,arbace.j2g.code19,convert-ref-or-primR242,R314,R354,R216,R234,R355,v15,arbace.j2g.code14,lambda-markersv11,arbace.core5,list*R356,R357,R358,R314,R242,R314,R359,R48,R43,R290,R357,R360,R361,R359,R275,R159,R360,R167,R359,R242,R216,R234,R359,R362,v16,arbace.j2g.model11,find-methodR363,R52,R314,R242,R216,R234,")

var Lit_1 *jrt.String = jrt.Intern(".-")

var Lit_2 *jrt.String = jrt.Intern("MatchException_New_String_Throwable")

var Lit_3 *jrt.String = jrt.Intern("Throwable_I")

var Lit_4 *jrt.String = jrt.Intern("Catch")

var Lit_5 *jrt.String = jrt.Intern("Thrown")

var Lit_6 *jrt.String = jrt.Intern("StrOfObj")

var Lit_7 *jrt.String = jrt.Intern("_Fn")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.code$adapter_sym$fn__969000802")

var Lit_9 *jrt.String = jrt.Intern("_")

var Lit_10 *jrt.String = jrt.Intern("J")

var Lit_11 *jrt.String = jrt.Intern("arbace.j2g.code$arith_val$cnt__969000248")

var Lit_12 *jrt.String = jrt.Intern("arbace.j2g.code$arith_val$fmul__969000250")

var Lit_13 *jrt.String = jrt.Intern("Math_MultiplyExact_J_J__J")

var Lit_14 *jrt.String = jrt.Intern("Math_AddExact_J_J__J")

var Lit_15 *jrt.String = jrt.Intern("Math_IncrementExact_J__J")

var Lit_16 *jrt.String = jrt.Intern("Math_SubtractExact_J_J__J")

var Lit_17 *jrt.String = jrt.Intern("Math_DecrementExact_J__J")

var Lit_18 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_19 *jrt.String = jrt.Intern("F")

var Lit_20 *jrt.String = jrt.Intern("I")

var Lit_21 *jrt.String = jrt.Intern("NewMultiArray")

var Lit_22 *jrt.String = jrt.Intern("New")

var Lit_23 *jrt.String = jrt.Intern("NewRefArray")

var Lit_24 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_25 *jrt.String = jrt.Intern("ArrayOf")

var Lit_26 *jrt.String = jrt.Intern("RefArrayOf")

var Lit_27 *jrt.String = jrt.Intern("p")

var Lit_28 *jrt.String = jrt.Intern("valueOf")

var Lit_29 *jrt.String = jrt.Intern("(")

var Lit_30 *jrt.String = jrt.Intern(")L")

var Lit_31 *jrt.String = jrt.Intern(";")

var Lit_32 *jrt.String = jrt.Intern("J2g_CastArray")

var Lit_33 *jrt.String = jrt.Intern("_Cast")

var Lit_34 *jrt.String = jrt.Intern("As")

var Lit_35 *jrt.String = jrt.Intern("_Init")

var Lit_36 *jrt.String = jrt.Intern("class ")

var Lit_37 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_38 *jrt.String = jrt.Intern("/")

var Lit_39 *jrt.String = jrt.Intern(".")

var Lit_40 *jrt.String = jrt.Intern("Prim_")

var Lit_41 *jrt.String = jrt.Intern("V")

var Lit_42 *jrt.String = jrt.Intern("Prim_void")

var Lit_43 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_44 *jrt.String = jrt.Intern("Object_class")

var Lit_45 *jrt.String = jrt.Intern("_class")

var Lit_46 *jrt.String = jrt.Intern("L")

var Lit_47 *jrt.String = jrt.Intern("Value")

var Lit_48 *jrt.String = jrt.Intern("()")

var Lit_49 *jrt.String = jrt.Intern("NN")

var Lit_50 *jrt.String = jrt.Intern("unexpected primitive coercion ")

var Lit_51 *jrt.String = jrt.Intern(" -> ")

var Lit_52 *jrt.String = jrt.Intern(" in method ")

var Lit_53 *jrt.String = jrt.Intern("pointer coercion ")

var Lit_54 *jrt.String = jrt.Intern("Z")

var Lit_55 *jrt.String = jrt.Intern("Ljava/lang/Boolean;")

var Lit_56 *jrt.String = jrt.Intern("J2g_Truth")

var Lit_57 *jrt.String = jrt.Intern("ConstRefArray")

var Lit_58 *jrt.String = jrt.Intern("Class")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.code$const_encode$fn__969000383")

var Lit_60 *jrt.String = jrt.Intern("[")

var Lit_61 *jrt.String = jrt.Intern(",")

var Lit_62 *jrt.String = jrt.Intern("h")

var Lit_63 *jrt.String = jrt.Intern("s")

var Lit_64 *jrt.String = jrt.Intern(":")

var Lit_65 *jrt.String = jrt.Intern("UTF-8")

var Lit_66 *jrt.String = jrt.Intern("n")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.code$const_tree$fn__969000372")

var Lit_68 *jrt.String = jrt.Intern("C")

var Lit_69 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_70 *jrt.String = jrt.Intern("Clojure constant")

var Lit_71 *jrt.String = jrt.Intern("unboxing ")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.code$ctor_args$iter__969000357__969000361")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.code$ctor_args$iter__969000357__969000361$fn__969000362")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.code$ctor_args$iter__969000357__969000361$fn__969000362$fn__969000363")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.code$declare_pattern_BANG_$fn__969000534")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.code$derived_accessor$fn__969000516")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.code$dispatch_codes_BANG_$clause__969000737")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.code$dispatch_codes_BANG_$clause__969000737$fn__969000738")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.code$effects_QMARK_$fn__969000095")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.code$effects_STAR_$w__969000098")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal$fn__969000547")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal$fn__969000549")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal$fn__969000551")

var Lit_84 *jrt.String = jrt.Intern("j2g: no constant ")

var Lit_85 *jrt.String = jrt.Intern(" in enum ")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal$fn__969000551$fn__969000552")

var Lit_87 *jrt.String = jrt.Intern("J2g_NotNull")

var Lit_88 *jrt.String = jrt.Intern("IFn")

var Lit_89 *jrt.String = jrt.Intern("invoke")

var Lit_90 *jrt.String = jrt.Intern("unreachable")

var Lit_91 *jrt.String = jrt.Intern("Ljava/lang/Class;")

var Lit_92 *jrt.String = jrt.Intern("no expression translation for ")

var Lit_93 *jrt.String = jrt.Intern("j2g: ")

var Lit_94 *jrt.String = jrt.Intern("FnInvokers")

var Lit_95 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$iter__969000844__969000848")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$fn__969000854")

var Lit_97 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$fn__969000857")

var Lit_98 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$iter__969000844__969000848$fn__969000849")

var Lit_100 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val$iter__969000844__969000848$fn__969000849$fn__969000850")

var Lit_101 *jrt.String = jrt.Intern("NaN32")

var Lit_102 *jrt.String = jrt.Intern("NaN64")

var Lit_103 *jrt.String = jrt.Intern("PosInf")

var Lit_104 *jrt.String = jrt.Intern("NegInf")

var Lit_105 *jrt.String = jrt.Intern("32")

var Lit_106 *jrt.String = jrt.Intern("64")

var Lit_107 *jrt.String = jrt.Intern("NegZero32")

var Lit_108 *jrt.String = jrt.Intern("NegZero64")

var Lit_109 *jrt.String = jrt.Intern("B")

var Lit_110 *jrt.String = jrt.Intern("S")

var Lit_111 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$fn__969000039")

var Lit_112 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$fn__969000042")

var Lit_113 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053")

var Lit_114 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$fn__969000066")

var Lit_115 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053$fn__969000054")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053$fn__969000054$iter__969000049__969000058")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053$fn__969000054$iter__969000049__969000058$fn__969000059")

var Lit_118 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items$iter__969000047__969000053$fn__969000054$iter__969000049__969000058$fn__969000059$fn__969000060")

var Lit_119 *jrt.String = jrt.Intern("arbace.j2g.code$instance_val$fn__969000263")

var Lit_120 *jrt.String = jrt.Intern("J2g_Discard")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.code$invoke_val$rv__969000332")

var Lit_122 *jrt.String = jrt.Intern("VhFence")

var Lit_123 *jrt.String = jrt.Intern("static Object method")

var Lit_124 *jrt.String = jrt.Intern("_NoInit")

var Lit_125 *jrt.String = jrt.Intern("getClass")

var Lit_126 *jrt.String = jrt.Intern("GetClass")

var Lit_127 *jrt.String = jrt.Intern("hashCode")

var Lit_128 *jrt.String = jrt.Intern("IdentityHash")

var Lit_129 *jrt.String = jrt.Intern("toString")

var Lit_130 *jrt.String = jrt.Intern("Object_toString")

var Lit_131 *jrt.String = jrt.Intern("clone")

var Lit_132 *jrt.String = jrt.Intern("J2g_ObjectClone")

var Lit_133 *jrt.String = jrt.Intern("equals")

var Lit_134 *jrt.String = jrt.Intern("super call of Object.")

var Lit_135 *jrt.String = jrt.Intern(".Impl_")

var Lit_136 *jrt.String = jrt.Intern(".Self_")

var Lit_137 *jrt.String = jrt.Intern("Object method ")

var Lit_138 *jrt.String = jrt.Intern(" on an Object")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val$fn__969000393")

var Lit_140 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val$iter__969000395__969000399")

var Lit_141 *jrt.String = jrt.Intern("Concat")

var Lit_142 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val$iter__969000395__969000399$fn__969000400")

var Lit_143 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val$iter__969000395__969000399$fn__969000400$fn__969000401")

var Lit_144 *jrt.String = jrt.Intern("StrOfInt")

var Lit_145 *jrt.String = jrt.Intern("StrOfChar")

var Lit_146 *jrt.String = jrt.Intern("D")

var Lit_147 *jrt.String = jrt.Intern("StrOfDouble")

var Lit_148 *jrt.String = jrt.Intern("StrOfFloat")

var Lit_149 *jrt.String = jrt.Intern("StrOfLong")

var Lit_150 *jrt.String = jrt.Intern("StrOfBool")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_markers$fn__969000798")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$iter__969000811__969000815")

var Lit_153 *jrt.String = jrt.Intern("lambda")

var Lit_154 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$fn__969000821")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$fn__969000821$fn__969000822")

var Lit_156 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$fn__969000821$fn__969000835")

var Lit_157 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$iter__969000811__969000815$fn__969000816")

var Lit_158 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val$iter__969000811__969000815$fn__969000816$fn__969000817")

var Lit_159 *jrt.String = jrt.Intern("arbace.j2g.code$literal_form$fix__969000747")

var Lit_160 *jrt.String = jrt.Intern("arbace.j2g.code$live_catches$fn__969000723")

var Lit_161 *jrt.String = jrt.Intern("arbace.j2g.code$live_catches$fn__969000723$fn__969000724")

var Lit_162 *jrt.String = jrt.Intern("java/lang/Throwable")

var Lit_163 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_164 *jrt.String = jrt.Intern("lookup")

var Lit_165 *jrt.String = jrt.Intern("arbace.j2g.code$match_pattern_BANG_$inner__969000520")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.code$match_pattern_BANG_$inner__969000520$comps__969000522")

var Lit_167 *jrt.String = jrt.Intern("arbace.j2g.code$match_pattern_BANG_$inner__969000520$comps__969000522$fn__969000525")

var Lit_168 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$iter__969000865__969000869")

var Lit_169 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$callf__969000875")

var Lit_170 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$fn__969000884")

var Lit_171 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$callf__969000875$fn__969000877")

var Lit_172 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$callf__969000875$fn__969000879")

var Lit_173 *jrt.String = jrt.Intern("")

var Lit_174 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$iter__969000865__969000869$fn__969000870")

var Lit_175 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val$iter__969000865__969000869$fn__969000870$fn__969000871")

var Lit_176 *jrt.String = jrt.Intern("J2g_Missing")

var Lit_177 *jrt.String = jrt.Intern("jrt lacks ")

var Lit_178 *jrt.String = jrt.Intern("a BigInt constant")

var Lit_179 *jrt.String = jrt.Intern("an outer class's super call")

var Lit_180 *jrt.String = jrt.Intern("arbace.j2g.code$missing_reason$fn__969000169")

var Lit_181 *jrt.String = jrt.Intern("method ")

var Lit_182 *jrt.String = jrt.Intern("jrt lacks constructor ")

var Lit_183 *jrt.String = jrt.Intern("Object_New")

var Lit_184 *jrt.String = jrt.Intern("?")

var Lit_185 *jrt.String = jrt.Intern("arbace.j2g.code$operands$fn__969000118")

var Lit_186 *jrt.String = jrt.Intern("arbace.j2g.code$operands$fn__969000120")

var Lit_187 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000122__969000126")

var Lit_188 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000132__969000136")

var Lit_189 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000142__969000146")

var Lit_190 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000122__969000126$fn__969000127")

var Lit_191 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000122__969000126$fn__969000127$fn__969000128")

var Lit_192 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000132__969000136$fn__969000137")

var Lit_193 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000132__969000136$fn__969000137$fn__969000138")

var Lit_194 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000142__969000146$fn__969000147")

var Lit_195 *jrt.String = jrt.Intern("arbace.j2g.code$operands$iter__969000142__969000146$fn__969000147$fn__969000148")

var Lit_196 *jrt.String = jrt.Intern("arbace.j2g.code$pattern_bindings$fn__969000508")

var Lit_197 *jrt.String = jrt.Intern("D2I")

var Lit_198 *jrt.String = jrt.Intern("D2L")

var Lit_199 *jrt.String = jrt.Intern("F2I")

var Lit_200 *jrt.String = jrt.Intern("F2L")

var Lit_201 *jrt.String = jrt.Intern("arbace.j2g.code$reads_state_QMARK_$w__969000105")

var Lit_202 *jrt.String = jrt.Intern("arbace.j2g.code$simple_QMARK_$fn__969000087")

var Lit_203 *jrt.String = jrt.Intern("arbace.j2g.code$simple_STAR_$fn__969000092")

var Lit_204 *jrt.String = jrt.Intern("Ljava/lang/Throwable;")

var Lit_205 *jrt.String = jrt.Intern("Lit_")

var Lit_206 *jrt.String = jrt.Intern("arbace.j2g.code$struct_of$fn__969000192")

var Lit_207 *jrt.String = jrt.Intern("arbace.j2g.code$struct_of$fn__969000196")

var Lit_208 *jrt.String = jrt.Intern("arbace.j2g.code$struct_of$fn__969000192$fn__969000193")

var Lit_209 *jrt.String = jrt.Intern("no this here")

var Lit_210 *jrt.String = jrt.Intern("tmp")

var Lit_211 *jrt.String = jrt.Intern("arbace.j2g.code$translate_and_or$go__969000460")

var Lit_212 *jrt.String = jrt.Intern("arbace.j2g.code$translate_and_or$go__969000460$fn__969000464")

var Lit_213 *jrt.String = jrt.Intern("AssertionError_New_")

var Lit_214 *jrt.String = jrt.Intern("AssertionError_New")

var Lit_215 *jrt.String = jrt.Intern("J2g_AssertionsDisabled")

var Lit_216 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_$fn__969000442")

var Lit_217 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_$fn__969000444")

var Lit_218 *jrt.String = jrt.Intern("break target not in scope")

var Lit_219 *jrt.String = jrt.Intern("recur target not in scope")

var Lit_220 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_$fn__969000448")

var Lit_221 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_$fn__969000450")

var Lit_222 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000495")

var Lit_223 *jrt.String = jrt.Intern("Ljava/util/Iterator;")

var Lit_224 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000499")

var Lit_225 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000503")

var Lit_226 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000495$fn__969000496")

var Lit_227 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each$fn__969000499$fn__969000500")

var Lit_228 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance$fn__969000537")

var Lit_229 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance$fn__969000539")

var Lit_230 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance$fn__969000541")

var Lit_231 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance$fn__969000543")

var Lit_232 *jrt.String = jrt.Intern("arbace.j2g.code$translate_label$fn__969000490")

var Lit_233 *jrt.String = jrt.Intern("arbace.j2g.code$translate_label$fn__969000490$fn__969000491")

var Lit_234 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$iter__969000469__969000473")

var Lit_235 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$fn__969000485")

var Lit_236 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$fn__969000485$fn__969000486")

var Lit_237 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$iter__969000469__969000473$fn__969000474")

var Lit_238 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop$iter__969000469__969000473$fn__969000474$fn__969000475")

var Lit_239 *jrt.String = jrt.Intern("MonitorEnter")

var Lit_240 *jrt.String = jrt.Intern("arbace.j2g.code$translate_monitor$fn__969000788")

var Lit_241 *jrt.String = jrt.Intern("arbace.j2g.code$translate_monitor$fn__969000788$fn__969000789")

var Lit_242 *jrt.String = jrt.Intern("MonitorExit")

var Lit_243 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000561")

var Lit_244 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$arm__969000566")

var Lit_245 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000570")

var Lit_246 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000575")

var Lit_247 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$done__969000580")

var Lit_248 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$arm_done__969000582")

var Lit_249 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$guarded__969000584")

var Lit_250 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$label_test__969000586")

var Lit_251 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000588")

var Lit_252 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000610__969000614")

var Lit_253 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000624__969000630")

var Lit_254 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000643")

var Lit_255 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000646")

var Lit_256 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000651__969000655")

var Lit_257 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000679__969000683")

var Lit_258 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000707__969000711")

var Lit_259 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$arm__969000566$fn__969000567")

var Lit_260 *jrt.String = jrt.Intern("NPE")

var Lit_261 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000588$fn__969000593")

var Lit_262 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000588$fn__969000595")

var Lit_263 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000588$fn__969000597")

var Lit_264 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000588$fn__969000599")

var Lit_265 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000588$fn__969000601")

var Lit_266 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000588$fn__969000603")

var Lit_267 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000588$fn__969000605")

var Lit_268 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$fn__969000588$fn__969000607")

var Lit_269 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000610__969000614$fn__969000615")

var Lit_270 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000610__969000614$fn__969000615$fn__969000616")

var Lit_271 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000610__969000614$fn__969000615$fn__969000620")

var Lit_272 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000610__969000614$fn__969000615$fn__969000616$fn__969000617")

var Lit_273 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000624__969000630$fn__969000631")

var Lit_274 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000624__969000630$fn__969000631$iter__969000626__969000635")

var Lit_275 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000624__969000630$fn__969000631$iter__969000626__969000635$fn__969000636")

var Lit_276 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000624__969000630$fn__969000631$iter__969000626__969000635$fn__969000636$fn__969000637")

var Lit_277 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000651__969000655$fn__969000656")

var Lit_278 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000651__969000655$fn__969000656$fn__969000657")

var Lit_279 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000651__969000655$fn__969000656$fn__969000672")

var Lit_280 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000651__969000655$fn__969000656$fn__969000657$fn__969000662")

var Lit_281 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000679__969000683$fn__969000684")

var Lit_282 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000679__969000683$fn__969000684$fn__969000685")

var Lit_283 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000679__969000683$fn__969000684$fn__969000700")

var Lit_284 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000679__969000683$fn__969000684$fn__969000685$fn__969000690")

var Lit_285 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000707__969000711$fn__969000712")

var Lit_286 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000707__969000711$fn__969000712$fn__969000713")

var Lit_287 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000707__969000711$fn__969000712$fn__969000717")

var Lit_288 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch$iter__969000707__969000711$fn__969000712$fn__969000713$fn__969000714")

var Lit_289 *jrt.String = jrt.Intern("a constant pattern label")

var Lit_290 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757")

var Lit_291 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$fn__969000781")

var Lit_292 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757$fn__969000758")

var Lit_293 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757$fn__969000760")

var Lit_294 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757$fn__969000762")

var Lit_295 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757$fn__969000778")

var Lit_296 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757$fn__969000762$fn__969000763")

var Lit_297 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757$fn__969000762$iter__969000765__969000769")

var Lit_298 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757$fn__969000762$fn__969000775")

var Lit_299 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757$fn__969000762$iter__969000765__969000769$fn__969000770")

var Lit_300 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try$inner__969000757$fn__969000762$iter__969000765__969000769$fn__969000770$fn__969000771")

var Lit_301 *jrt.String = jrt.Intern("fn")

var Lit_302 *jrt.String = jrt.Intern("arbace.j2g.code$try_literal$fn__969000732")

var Lit_303 *jrt.String = jrt.Intern("arbace.j2g.code$try_literal$fn__969000734")

var Lit_304 *jrt.String = jrt.Intern("Up_")

var Lit_305 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form$narrow__969000276")

var Lit_306 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form$widen__969000278")

var Lit_307 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form$bits__969000281")

var Lit_308 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form$unbits__969000284")

var Lit_309 *jrt.String = jrt.Intern("Xor")

var Lit_310 *jrt.String = jrt.Intern("And")

var Lit_311 *jrt.String = jrt.Intern("Or")

var Lit_312 *jrt.String = jrt.Intern("VhGetAnd")

var Lit_313 *jrt.String = jrt.Intern("Bool")

var Lit_314 *jrt.String = jrt.Intern("VhGetAndXorInt32")

var Lit_315 *jrt.String = jrt.Intern("VhGetAndXorInt64")

var Lit_316 *jrt.String = jrt.Intern("VhGetAndAddFloat32")

var Lit_317 *jrt.String = jrt.Intern("VhGetAndAddInt32")

var Lit_318 *jrt.String = jrt.Intern("VhGetAndAddInt64")

var Lit_319 *jrt.String = jrt.Intern("VhGetAndAddFloat64")

var Lit_320 *jrt.String = jrt.Intern("VhCmpXchgBool")

var Lit_321 *jrt.String = jrt.Intern("VhCmpXchgPtr")

var Lit_322 *jrt.String = jrt.Intern("VhCmpXchgVol")

var Lit_323 *jrt.String = jrt.Intern("VhCmpXchgUint32")

var Lit_324 *jrt.String = jrt.Intern("VhCmpXchgInt32")

var Lit_325 *jrt.String = jrt.Intern("VhCmpXchgInt64")

var Lit_326 *jrt.String = jrt.Intern("VhCmpXchgUint64")

var Lit_327 *jrt.String = jrt.Intern("VarHandle.")

var Lit_328 *jrt.String = jrt.Intern(" on ")

var Lit_329 *jrt.String = jrt.Intern(" (J2G-SPEC §8.5)")

var Lit_330 *jrt.String = jrt.Intern(" on a handle that is not a constant of its class (J2G-SPEC §8.5)")

var Lit_331 *jrt.String = jrt.Intern("[B")

var Lit_332 *jrt.String = jrt.Intern("arbace.j2g.code$vh_val$fn__969000309")

var Lit_333 *jrt.String = jrt.Intern("VhView")

var Lit_334 *jrt.String = jrt.Intern("Set")

var Lit_335 *jrt.String = jrt.Intern("Get")

var Lit_336 *jrt.String = jrt.Intern("Int")

var Lit_337 *jrt.String = jrt.Intern("Long")

var Lit_338 *jrt.String = jrt.Intern("arbace.j2g.code$vh_val$fn__969000316")

var Lit_339 *jrt.String = jrt.Intern("arbace.j2g.code$vh_val$fn__969000322")

var Lit_340 *jrt.String = jrt.Intern("IntArray")

var Lit_341 *jrt.String = jrt.Intern("LongArray")

var Lit_342 *jrt.String = jrt.Intern("RefArray")

var Lit_343 *jrt.String = jrt.Intern("GetAndAnd")

var Lit_344 *jrt.String = jrt.Intern("Cas")

var Lit_345 *jrt.String = jrt.Intern("Swap")

var Lit_346 *jrt.String = jrt.Intern("GetAndAdd")

var Lit_347 *jrt.String = jrt.Intern("GetAndOr")

var Lit_348 *jrt.String = jrt.Intern("GetAndXor")

var Lit_349 *jrt.String = jrt.Intern("CmpXchg")

var Lit_350 *jrt.String = jrt.Intern("Vh")

var Lit_351 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn1,fyn1,oyn3,msgyn1,&yn4,datayn5,identyn1,nyn6,suffixyn1,dkn7,privateyn3,symyn4,typeyn1,kyn1,syn1,byn4,formyn2,gtyn4,inityn5,itemsyn4,usedyn4,nodeyn1,xyn1,vyn2,tokn8,declaredyn4,fromyn2,nnyn1,tkn2,asyn4,morekn9,var-derefkn7,alengthkn7,convertkn10,array-initkn10,method-refkn6,lambdakn3,newks15,arbace.j2g.code2,gokn9,get-fieldkn5,arithkn4,castkn5,bool=kn4,nil?kn9,instance?kn3,notkn10,identical?kn9,class-litkn12,null-checkedkn10,fi-adapterkn5,constkn9,this-pathkn16,outer-param-pathkn9,new-arraykn10,get-statickn7,comparekn10,var-invokekn6,invokekn4,agetkn5,localkn8,java-strkn4,noneyn7,computekn10,set-statickn6,assertkn9,set-fieldkn9,ctor-callkn4,asetkn7,monitorkn5,throwkn3,trykn9,set-localyn3,valyn5,flagsyn5,nodesyn5,wantskn3,tagyn6,Stringyn3,whyyn3,clsyn4,baseyn1,myn2,sdyn4,declyn5,fnameyn3,ptryn5,placeyn2,tvv11,arbace.core5,in-nsMyn15,arbace.j2g.codem2,R0,s410,j2g's translation of code (J2G-SPEC §7): the analyzer's typed nodes to Go statements and\n  expressions, in four contexts (statement, return, assign, expression, §7.2), with\n  temporaries for Java's order of evaluation, Java's arithmetic (§7.4), null checks and the\n  typed-nil rule (§5.6), try/catch/finally and control codes (§7.9), monitors (§8.1), loops,\n  labels and switches (§7.7, §7.8), lambdas (§7.11).m2,R0,s410,j2g's translation of code (J2G-SPEC §7): the analyzer's typed nodes to Go statements and\n  expressions, in four contexts (statement, return, assign, expression, §7.2), with\n  temporaries for Java's order of evaluation, Java's arithmetic (§7.4), null checks and the\n  typed-nil rule (§5.6), try/catch/finally and control codes (§7.9), monitors (§8.1), loops,\n  labels and switches (§7.7, §7.8), lambdas (§7.11).R1,v15,arbace.j2g.code3,*f*m10,R2,TR3,i19,R4,i1,R5,s18,arbace/j2g/code.aeR0,s176,The Go function being written: {:pkg :class :static :t :this :method-ret :fn-id :targets\n  :try-frame :captured :ctor-params, and atoms :names :taken :used :counter :pkgstate}.v15,arbace.j2g.code7,*block*m10,R2,TR3,i24,R4,i1,R5,s18,arbace/j2g/code.aeR0,s51,The statement list being written: an atom of items.v15,arbace.j2g.code10,*pkgstate*m10,R2,TR3,i26,R4,i1,R5,s18,arbace/j2g/code.aeR0,s318,Per package: {:lits (atom {string sym}) :ups (atom #{[from to]}) :lambdas (atom #{fi})\n  :cuts (atom #{class})}; for one class translated on its own (arbace.j2g.main's parallel\n  translation): :lits local with a :lit-prefix, :ups :lambdas :cuts atoms of vectors (what\n  was conj'ed, in order, for the merge to replay).v15,arbace.j2g.code7,*races*m10,R2,TR3,i33,R4,i1,R5,s18,arbace/j2g/code.aeR0,s122,An atom collecting the candidate two-word races (J2G-SPEC §8.3, Q10), or nil:\n  #{[class field-name desc static? writer]}.v15,arbace.j2g.code11,note-store!m10,R6,L1,V2,R7,R8,R0,s274,Records a store into field f (declared in o) when it is a two-word race candidate: a\n  non-final, non-volatile field of interface Go type written outside its class's constructors\n  (static initializer for a static field), not in a synchronized method nor in locking on this.R3,i38,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,failm8,R6,L1,V3,R9,R10,V1,R11,R3,i53,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code3,pkgm8,R6,L1,V0,R3,i55,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,jsymm8,R6,L1,V1,R12,R3,i57,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,csymm8,R6,L2,V1,R13,V2,R13,R14,R3,i58,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,gotypem8,R6,L1,V1,R15,R3,i59,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code3,tagm10,R16,TR6,L1,V2,R17,R18,R3,i61,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,new-counter!m8,R6,L1,V1,R19,R3,i63,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,freshm10,R6,L1,V1,R20,R0,s33,A fresh Go local name based on s.R3,i66,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,fresh-rawm10,R6,L1,V1,R20,R0,s81,A fresh Go local name for j2g's own variables (not munged: no Java local has it).R3,i77,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code3,tmpm8,R6,L1,V0,R3,i87,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,use-sym!m8,R6,L1,V1,R20,R3,i89,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,binding-symm10,R6,L1,V1,R21,R0,s59,The Go name of an analyzer binding in the current function.R3,i91,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,*line*m10,R2,TR3,i102,R4,i1,R5,s18,arbace/j2g/code.aeR0,s227,The Java forms line of the node being translated (the analyzer's :line), or nil: the\n  statements written meanwhile carry it as :j2g/line metadata, which arbace.j2g.out turns into\n  the forms' positions (J2G-SPEC §4.3, §7.9.6).v15,arbace.j2g.code9,with-linem10,R6,L1,V1,R22,R0,s72,form with the current line as :j2g/line, unless it has one (lists only).R3,i108,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,emit!m8,R6,L1,V1,R22,R3,i115,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,decl!m10,R6,L1,V3,R17,R23,R24,R0,s82,Declares Go local sym of Go type gt with initial value init (nil: the zero value).R3,i117,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,fold-itemsm10,R16,TR6,L1,V2,R25,R26,R3,i124,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,with-blockm10,R6,L1,V1,R7,R0,s70,Runs f with a fresh statement list; returns the list of Go statements.R3,i144,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,block-formsm8,R6,L1,V1,R25,R3,i151,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code2,vtm8,R6,L1,V1,R27,R3,i156,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,object-like?m8,R6,L1,V1,R15,R3,i158,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,zero-ofm10,R6,L1,V1,R15,R0,s52,The Go zero value of descriptor d, as an expression.R3,i160,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,literal?m8,R6,L1,V1,R28,R3,i168,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,fold-int-convm12,R16,TR6,L1,V2,R29,R30,R0,s83,A Go integer literal converted to Java type to (wrapping as Java's conversions do).R3,i170,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,stmt!*m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code14,translate-ctx*m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,exprm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,expr-opm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,expr-asm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,stmt!m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,assign!m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code4,ret!m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,cond-exprm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,translate-ctxm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code14,missing-reasonm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,missing-exprm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,go-call?m8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,prim-convertm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,box-valm8,R31,TR3,i178,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,up-symm10,R6,L1,V3,R28,R32,R30,R0,s132,The nil-preserving conversion of pointer type `from` (desc) to interface `to` (desc):\n  .Ref for any, else a generated Up_ function.R3,i181,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code6,coercem10,R6,L1,V4,R28,R32,R30,R33,R0,s257,Converts Go expression x of Java static type from (a descriptor, :null) to Java type `to`\n  as an assignment conversion that the analyzer left implicit (reference widening): pointer\n  to interface conversions are nil-preserving unless nn (x known not null).R3,i193,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code1,vm10,R16,TR6,L1,V4,R28,R34,R10,m2,R35,R36,R3,i227,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code15,guarded-static?m8,R31,TR3,i232,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,simple-opsS31,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,m8,R16,TR3,i234,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,expressible?m10,R6,L1,V1,R27,R0,s83,Is node's own operation one Go expression (its operands may still need statements)?R3,i240,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code16,compiled-caller?m12,R16,TR6,L1,V0,R0,s80,Is the function being written in a class of a compiled namespace (arbace.c2j's)?R3,i248,R4,i1,R5,s18,arbace/j2g/code.aem12,R16,TR6,L1,V1,R27,R0,s90,A static access that runs C_Init() first (from code outside the class and its subclasses).R3,i253,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,*node-memo*m10,R2,TR3,i269,R4,i1,R5,s18,arbace/j2g/code.aeR0,s449,nil, or {:simple :effects} two java.util.IdentityHashMaps in which simple? and effects?\n  keep their answer for a node (by identity) while one class is translated (arbace.j2g.main's\n  apart): each walks the node's operands, and the operands of an expression ask again of\n  theirs, level after level. An answer is kept with what it depends on besides the node and\n  the world: the class and staticness of the function being written (guarded-static?).v15,arbace.j2g.code9,memo-nodem12,R16,TR6,L1,V3,R19,R27,R68,R0,s66,(compute) for node, kept in *node-memo*'s map k when there is one.R3,i277,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,simple*m8,R31,TR3,i292,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,simple?m10,R6,L1,V1,R27,R0,s37,Can node be one Go expression (§7.2)?R3,i294,R4,i1,R5,s18,arbace/j2g/code.aem10,R16,TR6,L1,V1,R27,R3,i299,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,effect-opsS20,R37,R40,R69,R41,R42,R43,R47,R54,R70,R71,R72,R73,R74,R59,R62,R63,R75,R76,R66,R77,m8,R16,TR3,i311,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,effects*m8,R31,TR3,i315,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,effects?m10,R6,L1,V1,R27,R0,s49,Can evaluating node change state or throw (§7.2)?R3,i317,R4,i1,R5,s18,arbace/j2g/code.aem10,R16,TR6,L1,V1,R27,R3,i322,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,reads-state?m10,R6,L1,V1,R27,R0,s265,Is node's value at risk from a later operand's call (§7.2): it reads a field, a static or\n  an array element, or can throw (an integer division), outside the arguments of a call of\n  its own (Go orders calls among themselves, and a call's arguments come before it)?R3,i341,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code7,stable?m10,R6,L1,V1,R27,R0,s90,Is node's value unaffected by any later evaluation (a constant, an immutable local, this)?R3,i359,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,hoist-valuem12,R16,TR6,L1,V1,R78,R0,s47,Puts a translated value into a fresh temporary.R3,i370,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,any-afterm12,R16,TR6,L1,V1,R79,R0,s173,For a vector of flags: whether one after position i is true, for each i (one pass from the\n  right, so that an array initializer of n elements costs n tests, not n squared).R3,i379,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,operandsm10,R6,L1,V2,R80,R81,R0,s260,Translates nodes left to right as operands of one Go expression (or call), each converted\n  to its type in `wants` (a desc or nil). An operand is moved to a temporary when a later\n  operand writes statements or has side effects that could change what it reads.R3,i388,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,java-hashm10,R16,TR6,L1,V1,Myn1,sm2,R82,R83,R3,i421,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,string-litm10,R6,L1,V1,R20,R0,s275,The pooled literal (§7.5) of Java string s: a package variable Lit_n. In a class translated\n  on its own (arbace.j2g.main's parallel translation), :lit-prefix names the class's literals\n  apart, in its own first-use order; the merge renames them Lit_n in the package's order.R3,i423,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,float-litm8,R6,L1,V2,R34,R28,R3,i434,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,const-valuem8,R6,L1,V1,R27,R3,i443,R4,i1,R5,s18,arbace/j2g/code.aem8,R6,L1,V2,R84,R15,R3,i458,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,class-missingm10,R16,TR6,L1,V1,R13,R3,i465,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,desc-missingm10,R16,TR6,L1,V1,R15,R3,i468,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,mdesc-missingm10,R16,TR6,L1,V1,R15,R3,i469,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code17,hw-static-exists?m10,R16,TR6,L1,V2,R85,R86,R3,i471,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,lookup-call?m12,R16,TR6,L1,V1,R27,R0,s150,MethodHandles.lookup(): the lookup VarHandle constants are found with (J2G-SPEC §8.5); in Go\n  a nil of no use, the handles being compiled statically.R3,i475,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code5,vh-opm10,R6,L1,V1,R27,R0,s83,The constant VarHandle and access mode of a VarHandle call (J2G-SPEC §8.5), or nil.R3,i482,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,vh-supported?m12,R16,TR6,L1,V3,R19,R87,R15,R0,s80,Can j2g translate access mode m of a handle of kind k on values of descriptor d?R3,i487,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,vh-missingm12,R16,TR6,L1,V1,R27,R0,s119,For a VarHandle call or MethodHandles.lookup(): ::vh-ok when j2g translates it, else why\n  not; nil for any other node.R3,i496,R4,i1,R5,s18,arbace/j2g/code.aem10,R6,L1,V1,R27,R0,s104,Why node cannot be translated in this world (a class or member it needs does not exist in\n  Go), or nil.R3,i515,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code8,this-valm10,R6,L1,V0,R0,s81,The whole object of the current instance code: t in a leaf class, this otherwise.R3,i568,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,outer-fieldm10,R16,TR6,L1,V2,R28,R85,R3,i573,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,this-path-valm8,R6,L1,V1,R27,R3,i580,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,local-valm8,R6,L1,V1,R27,R3,i595,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,struct-ofm10,R6,L1,V6,R28,R88,R89,R90,R10,V1,R91,R0,s314,An expression of the struct of declaring class `decl` reached from value x of static type\n  desc sd (§5.2): x itself for a pointer, Self_D for a class interface; through the embedded\n  struct when a nearer class hides a field of the same name. ptr: x is the struct pointer of\n  sd's class itself (t, the receiver).R3,i601,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,volatile-flagl64,m8,R16,TR3,i616,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,vh-field?m10,R6,L1,V1,R7,R0,s111,Does a constant VarHandle of the world name field f (J2G-SPEC §8.5)? It then has the\n  volatile representation.R3,i618,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code15,volatile-field?m8,R6,L1,V1,R7,R3,i624,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code13,volatile-readm8,R6,L1,V2,R92,R15,R3,i626,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code14,volatile-writem8,R6,L1,V3,R92,R15,R28,R3,i633,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code11,field-placem10,R6,L1,V2,R93,R7,R0,s67,The Go place of instance field f (declared in class o) on value tv.R3,i639,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code15,target-operandsm10,R6,L1,V2,R80,R81,R0,s81,operands, with this (the current object, no outer hops) as the receiver struct t.R3,i646,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code12,static-placem8,R6,L1,V1,R7,R3,i655,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code15,class-init-callm8,R6,L1,V1,R8,R3,i659,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code9,class-valm10,R6,L1,V1,R15,R0,s33,The Class object of descriptor d.R3,i666,R4,i1,R5,s18,arbace/j2g/code.aev15,arbace.j2g.code10,invoke-valm8,R31,TR3,i687,R4,i1,R5,s18,arbace/j2g/code.ae")

var Lit_352 *jrt.String = jrt.Intern("arbace.j2g.code$eval969000004$loading__1927001464__auto____969000005")

var Lit_353 *jrt.String = jrt.Intern("arbace.j2g.code$eval969000008$fn__969000009")

var Lit_354 *jrt.String = jrt.Intern("arbace.j2g.code$note_store_BANG_")

var Lit_355 *jrt.String = jrt.Intern("arbace.j2g.code$fail")

var Lit_356 *jrt.String = jrt.Intern("arbace.j2g.code$pkg")

var Lit_357 *jrt.String = jrt.Intern("arbace.j2g.code$jsym")

var Lit_358 *jrt.String = jrt.Intern("arbace.j2g.code$csym")

var Lit_359 *jrt.String = jrt.Intern("arbace.j2g.code$gotype")

var Lit_360 *jrt.String = jrt.Intern("arbace.j2g.code$tag")

var Lit_361 *jrt.String = jrt.Intern("arbace.j2g.code$new_counter_BANG_")

var Lit_362 *jrt.String = jrt.Intern("arbace.j2g.code$fresh")

var Lit_363 *jrt.String = jrt.Intern("arbace.j2g.code$fresh_raw")

var Lit_364 *jrt.String = jrt.Intern("arbace.j2g.code$tmp")

var Lit_365 *jrt.String = jrt.Intern("arbace.j2g.code$use_sym_BANG_")

var Lit_366 *jrt.String = jrt.Intern("arbace.j2g.code$binding_sym")

var Lit_367 *jrt.String = jrt.Intern("arbace.j2g.code$with_line")

var Lit_368 *jrt.String = jrt.Intern("arbace.j2g.code$emit_BANG_")

var Lit_369 *jrt.String = jrt.Intern("arbace.j2g.code$decl_BANG_")

var Lit_370 *jrt.String = jrt.Intern("arbace.j2g.code$fold_items")

var Lit_371 *jrt.String = jrt.Intern("arbace.j2g.code$with_block")

var Lit_372 *jrt.String = jrt.Intern("arbace.j2g.code$block_forms")

var Lit_373 *jrt.String = jrt.Intern("arbace.j2g.code$vt")

var Lit_374 *jrt.String = jrt.Intern("arbace.j2g.code$object_like_QMARK_")

var Lit_375 *jrt.String = jrt.Intern("arbace.j2g.code$zero_of")

var Lit_376 *jrt.String = jrt.Intern("arbace.j2g.code$literal_QMARK_")

var Lit_377 *jrt.String = jrt.Intern("arbace.j2g.code$fold_int_conv")

var Lit_378 *jrt.String = jrt.Intern("arbace.j2g.code$up_sym")

var Lit_379 *jrt.String = jrt.Intern("arbace.j2g.code$coerce")

var Lit_380 *jrt.String = jrt.Intern("arbace.j2g.code$v")

var Lit_381 *jrt.String = jrt.Intern("arbace.j2g.code$expressible_QMARK_")

var Lit_382 *jrt.String = jrt.Intern("arbace.j2g.code$compiled_caller_QMARK_")

var Lit_383 *jrt.String = jrt.Intern("arbace.j2g.code$guarded_static_QMARK_")

var Lit_384 *jrt.String = jrt.Intern("arbace.j2g.code$memo_node")

var Lit_385 *jrt.String = jrt.Intern("arbace.j2g.code$simple_QMARK_")

var Lit_386 *jrt.String = jrt.Intern("arbace.j2g.code$simple_STAR_")

var Lit_387 *jrt.String = jrt.Intern("arbace.j2g.code$effects_QMARK_")

var Lit_388 *jrt.String = jrt.Intern("arbace.j2g.code$effects_STAR_")

var Lit_389 *jrt.String = jrt.Intern("arbace.j2g.code$reads_state_QMARK_")

var Lit_390 *jrt.String = jrt.Intern("arbace.j2g.code$stable_QMARK_")

var Lit_391 *jrt.String = jrt.Intern("arbace.j2g.code$hoist_value")

var Lit_392 *jrt.String = jrt.Intern("arbace.j2g.code$any_after")

var Lit_393 *jrt.String = jrt.Intern("arbace.j2g.code$operands")

var Lit_394 *jrt.String = jrt.Intern("arbace.j2g.code$java_hash")

var Lit_395 *jrt.String = jrt.Intern("arbace.j2g.code$string_lit")

var Lit_396 *jrt.String = jrt.Intern("arbace.j2g.code$float_lit")

var Lit_397 *jrt.String = jrt.Intern("arbace.j2g.code$const_value")

var Lit_398 *jrt.String = jrt.Intern("arbace.j2g.code$missing_expr")

var Lit_399 *jrt.String = jrt.Intern("arbace.j2g.code$class_missing")

var Lit_400 *jrt.String = jrt.Intern("arbace.j2g.code$desc_missing")

var Lit_401 *jrt.String = jrt.Intern("arbace.j2g.code$mdesc_missing")

var Lit_402 *jrt.String = jrt.Intern("arbace.j2g.code$hw_static_exists_QMARK_")

var Lit_403 *jrt.String = jrt.Intern("arbace.j2g.code$lookup_call_QMARK_")

var Lit_404 *jrt.String = jrt.Intern("arbace.j2g.code$vh_op")

var Lit_405 *jrt.String = jrt.Intern("arbace.j2g.code$vh_supported_QMARK_")

var Lit_406 *jrt.String = jrt.Intern("arbace.j2g.code$vh_missing")

var Lit_407 *jrt.String = jrt.Intern("arbace.j2g.code$missing_reason")

var Lit_408 *jrt.String = jrt.Intern("arbace.j2g.code$this_val")

var Lit_409 *jrt.String = jrt.Intern("arbace.j2g.code$outer_field")

var Lit_410 *jrt.String = jrt.Intern("arbace.j2g.code$this_path_val")

var Lit_411 *jrt.String = jrt.Intern("arbace.j2g.code$local_val")

var Lit_412 *jrt.String = jrt.Intern("arbace.j2g.code$struct_of")

var Lit_413 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_QMARK_")

var Lit_414 *jrt.String = jrt.Intern("arbace.j2g.code$volatile_field_QMARK_")

var Lit_415 *jrt.String = jrt.Intern("arbace.j2g.code$volatile_read")

var Lit_416 *jrt.String = jrt.Intern("arbace.j2g.code$volatile_write")

var Lit_417 *jrt.String = jrt.Intern("arbace.j2g.code$field_place")

var Lit_418 *jrt.String = jrt.Intern("arbace.j2g.code$target_operands")

var Lit_419 *jrt.String = jrt.Intern("arbace.j2g.code$static_place")

var Lit_420 *jrt.String = jrt.Intern("arbace.j2g.code$class_init_call")

var Lit_421 *jrt.String = jrt.Intern("arbace.j2g.code$class_val")

var Lit_422 *jrt.String = jrt.Intern("kn8,declaredkn4,linekn6,columnkn4,filekn8,arglistsyn4,nodekn3,docyn2,tokn7,privateyn1,xyn1,vyn4,bitsyn1,pyn4,fromyn6,m-descyn9,arg-nodesyn1,dyn1,ryn1,myn5,placeyn2,xsyn1,hyn2,cnkn3,tagyn6,Stringyn5,holesyn4,treeyn7,classesyn13,StringBuilderyn6,targetyn4,jumpyn9,target-fnyn8,val-formyn4,agetyn1,<yn7,bit-xoryn4,zeroyn2,<=yn1,*yn4,makeyn11,bit-and-notyn2,fnyn4,instyn1,>yn1,%yn3,newyn1,-yn2,oryn7,bit-andyn3,lityn3,notyn2,>>yn3,capyn6,assertyn8,subsliceyn1,/yn6,bit-oryn2,>=yn4,addryn4,convyn1,+yn7,bit-notyn2,!=yn2,==yn3,lenyn3,andyn2,<<yn3,ctxkn4,keysyn5,owneryn4,nameyn4,descyn2,rdyn8,accessoryn1,cyn2,vtyn1,kyn1,eyn7,body-fnyn6,catch?yn7,monitoryn3,ctlyn2,rvyn5,codesyn5,formsyn3,rv?yn4,ctl?yn11,lit-rv-descyn2,fiyn7,markersv15,arbace.j2g.code7,new-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code9,arith-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code11,convert-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code8,cast-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code12,instance-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code12,java-str-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code10,lambda-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code14,method-ref-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code9,array-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code16,const-or-missingm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code14,fi-adapter-valm8,R0,TR1,i687,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code5,hoistm10,R4,L1,V1,R5,R6,s88,Translates a node that is not one Go expression into a fresh temporary (assign context).R1,i690,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V1,R5,R6,s74,Translates node in expression context: {:x go-form :t java-desc :nn bool}.R1,i702,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V1,R5,R6,s89,The Go expression of an expressible node's own operation (operands translated as needed).R1,i717,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V2,R5,R7,R6,s49,node's Go expression converted to Java type `to`.R1,i800,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V1,R5,R6,s81,A Go boolean expression of node as a condition (Clojure's truth on non-booleans).R1,i806,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code7,go-lit?m10,R8,TR4,L1,V1,R9,R1,i823,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code12,unsigned-litm12,R8,TR4,L1,V2,R10,R11,R6,s145,A Go literal of the unsigned value of Java integer v of the given width (Go rejects the\n  conversion of a negative constant to an unsigned type).R1,i825,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i834,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V2,R9,R12,R1,i886,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V3,R9,R13,R7,R1,i890,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i907,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i927,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i945,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code14,object-helpersm16,V2,s6,equalss21,(Ljava/lang/Object;)Zs6,EqualsV2,s8,hashCodes3,()Is8,HashCodeV2,s8,toStrings20,()Ljava/lang/String;s8,ToStringV2,s8,getClasss19,()Ljava/lang/Class;s8,GetClassV2,s6,notifys3,()Vs6,NotifyV2,s9,notifyAlls3,()Vs9,NotifyAllV2,s4,waits3,()Vs4,WaitV2,s4,waits4,(J)Vs11,WaitTimeoutm8,R8,TR1,i965,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code8,args-form10,R8,TR4,L1,V2,R14,R15,R1,i971,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code12,super-structm10,R4,L1,V0,R6,s63,The embedded struct of the current class's superclass: (.-B t).R1,i975,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code6,vh-argm12,R8,TR4,L1,V2,R5,R16,R6,s137,An argument node of a VarHandle call converted to descriptor d as the handle does: a\n  checked cast unless its static type is assignable.R1,i981,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code9,vh-resultm12,R8,TR4,L1,V3,R9,R16,R17,R6,s132,A VarHandle call's result form x of descriptor d as the call's return type r (the JVM's\n  checkcast of a polymorphic call's result).R1,i990,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code13,vh-field-formm12,R8,TR4,L1,V4,R18,R19,R16,R20,R6,s143,The Go form of access mode m on the atomic field place (the volatile representation of a\n  field of descriptor d, §8.2) with argument forms xs.R1,i1001,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code6,vh-valm10,R4,L1,V2,R5,R21,R6,s158,A VarHandle access-mode call on a constant handle (J2G-SPEC §8.5): the atomic operation on\n  the field it names, or on the array element (jrt's Vh functions).R1,i1047,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i1087,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code9,ctor-argsm10,R4,L1,V2,R5,R22,R6,s219,The Go arguments of constructor ctor of class cn for a :new or :ctor-call node: the outer\n  instance, the superclass's outer instance, the enum constant's name and ordinal, the\n  declared arguments, the captured locals.R1,i1177,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i1197,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code15,const-array-minl4,m10,R8,TR1,i1212,R2,i1,R3,s18,arbace/j2g/code.aeR6,s78,The least number of string leaves for which an initializer is written as data.v15,arbace.j2g.code10,utf8-safe?m12,R8,TR4,L1,V1,Myn1,sm2,R23,R24,R6,s69,Can the Java string travel as Go UTF-8 text (no unpaired surrogates)?R1,i1216,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code10,const-treem12,R8,TR4,L1,V2,R5,R25,R6,s150,node as a constant array tree ([:arr elem-desc trees], [:str s], [:null], [:hole i]), holes\n  collecting the immutable locals, or nil when it is none.R1,i1231,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code13,const-stringsm10,R8,TR4,L1,V1,R26,R1,i1248,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code12,const-encodem12,R8,TR4,L1,V3,R26,R27,Myn2,sbm2,R23,R28,R6,s89,The encoding of a tree (jrt's constarray.ae), classes an atom of the element descriptors.R1,i1254,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code11,const-arraym12,R8,TR4,L1,V1,R5,R6,s110,The ConstRefArray call of a reference array initializer that is a constant tree with enough\n  strings, or nil.R1,i1268,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i1283,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i1307,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code11,target-infom10,R8,TR4,L1,V1,R29,R1,i1333,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code10,code-jump!m12,R8,TR4,L1,V1,R30,R6,s242,A jump (return, break, recur) leaving the Go function literal of a try or locking body: it\n  is recorded in the innermost frame with a control code and performed after the literal\n  returns (§7.9.3). jump is {:kind :return|:break|:recur ...}.R1,i1335,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code8,outside?m10,R8,TR4,L1,V1,R31,R1,i1346,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code14,method-return!m12,R8,TR4,L1,V1,R32,R6,s88,A return from the method (::void for a void method's), a control code inside a try body.R1,i1348,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code11,set-static!m10,R8,TR4,L1,V1,R5,R1,i1355,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code14,dropped-store?m12,R8,TR4,L1,V1,R5,R6,s402,A store into a field that the closed world drops (its type is outside it) that can go:\n  a static initializer's store into a field of its class (serialization's\n  serialPersistentFields: nothing can read the field), or the store of the constant null\n  into a field of this object or a static field (PrintWriter's psOut, a PrintStream: the\n  field can hold nothing else, no instance of its type exists).R1,i1367,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code10,set-field!m10,R8,TR4,L1,V1,R5,R1,i1387,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V1,R5,R6,s37,Translates node in statement context.R1,i1394,R2,i1,R3,s18,arbace/j2g/code.aem10,R8,TR4,L1,V1,R5,R1,i1400,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code8,go-headsS34,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,m8,R8,TR1,i1454,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V1,R9,R6,s53,Is Go form x a call (which may stand as a statement)?R1,i1458,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code13,assign-value!m10,R8,TR4,L1,V2,R9,R67,R1,i1468,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V2,R5,R67,R6,s54,Translates node storing its value into ctx's variable.R1,i1474,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V1,R5,R6,s68,Translates node as the value of the current method (return context).R1,i1479,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code8,ctx-descm10,R8,TR4,L1,V1,R67,R1,i1484,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code13,translate-trym8,R0,TR1,i1486,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code17,translate-monitorm8,R0,TR1,i1486,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code14,translate-loopm8,R0,TR1,i1486,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code15,translate-labelm8,R0,TR1,i1486,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code16,translate-switchm8,R0,TR1,i1486,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code18,translate-for-eachm8,R0,TR1,i1486,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code21,translate-if-instancem8,R0,TR1,i1486,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code16,translate-and-orm8,R0,TR1,i1486,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V2,R5,R67,R6,s88,Translates node in context ctx: {:k :stmt}, {:k :assign :var sym :desc d}, {:k :return}.R1,i1489,R2,i1,R3,s18,arbace/j2g/code.aem10,R8,TR4,L1,V2,R5,R67,R1,i1495,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V2,R5,R67,R1,i1612,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code9,new-labelm8,R4,L1,V0,R1,i1637,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V2,R5,R67,R1,i1639,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V2,R5,R67,R1,i1662,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V2,R5,R67,R1,i1671,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code16,pattern-bindingsm10,R8,TR4,L1,V1,R12,R1,i1709,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code15,record-pattern?m10,R8,TR4,L1,V1,R12,R1,i1712,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code16,derived-accessorm12,R8,TR4,L1,V1,m2,R68,V3,R69,R70,R71,R6,s153,The record component field an accessor reads when the record does not declare the accessor\n  itself (the analyzer derived it: it cannot throw), else nil.R1,i1714,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code14,accessor-call!m12,R8,TR4,L1,V4,R17,R72,R73,R74,R6,s280,Assigns record r's component (accessor `accessor`) to Go variable c. A derived accessor is\n  the field read (records are final, r is not null); a declared one is called, and an\n  exception it throws is wrapped in MatchException(t.toString(), t), as javac wraps it\n  (JLS 14.30.2).R1,i1722,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code14,match-pattern!m12,R8,TR4,L1,V4,R12,R9,R75,R76,R6,s288,Emits the statements matching Go value x (a stable expression of Java type vt) against\n  pattern p: the type tests, the record components read through their accessors, the\n  bindings assigned (declared before by declare-pattern!); calls k to emit what follows a\n  match, inside the tests.R1,i1746,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code16,declare-pattern!m12,R8,TR4,L1,V3,R12,R9,R75,R6,s117,Declares the bindings of pattern p and a flag; returns the flag, set when the value\n  matches (after match-pattern!).R1,i1778,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V2,R5,R67,R1,i1790,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code12,enum-ordinalm10,R8,TR4,L1,V2,R77,R74,R1,i1809,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V2,R5,R67,R1,i1817,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code12,live-catchesm12,R8,TR4,L1,V1,R5,R6,s92,The catch clauses of a try node that can catch something: those naming a class of the world.R1,i1939,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code11,try-literalm12,R8,TR4,L1,V2,R78,m2,R68,V2,R79,R80,R6,s207,Runs body-fn as the body of a Go function literal called in place, with control codes for\n  the jumps out of it. Returns {:call form :codes [...] :has-exc bool :rv? bool} and the\n  literal's statement forms.R1,i1944,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code15,dispatch-codes!m12,R8,TR4,L1,V3,R81,R82,R83,R6,s96,After a try literal: performs the pending jump of each control code in the enclosing\n  function.R1,i1961,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code12,literal-formm12,R8,TR4,L1,V3,m2,R68,V4,R84,R83,R85,R86,R79,R87,R6,s87,The Go function literal and its call: results ctl, rv (when used), exc (when catching).R1,i1982,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V2,R5,R67,R1,i2005,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V2,R5,R67,R1,i2078,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code7,sam-sigm8,R4,L1,V1,R88,R1,i2103,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code14,lambda-markersm10,R4,L1,V1,R5,R6,s332,The marker interfaces of a lambda or method reference whose target is an intersection\n  (\"(& Comparator Serializable)\": LambdaMetafactory's altMetafactory makes its class implement\n  them; amendment JB5): Serializable when serializable, and the other markers, those in the\n  world that the interface does not already extend, sorted.R1,i2108,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code11,adapter-symm10,R4,L2,V1,R88,V2,R88,R89,R6,s176,The adapter type F_Fn of functional interface fi, recorded for generation in fi's package;\n  with marker interfaces, the adapter F_Fn_M1_..._Mn that also implements them (JB5).R1,i2119,R2,i1,R3,s18,arbace/j2g/code.aev15,arbace.j2g.code19,convert-ref-or-primm12,R8,TR4,L1,V3,R9,R13,R7,R6,s130,Converts Go value x of Java type from to Java type to, as LambdaMetafactory adapts:\n  casts, unboxing, boxing, primitive widening.R1,i2127,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i2141,R2,i1,R3,s18,arbace/j2g/code.aem10,R4,L1,V1,R5,R6,s313,Clojure's adapter of an argument to a functional interface parameter (Compiler's\n  FISupport.maybeEmitFIAdapter; :fi-adapter): an IFn that is not already an instance of the\n  interface becomes its adapter F_Fn (§7.11) calling FnInvokers' invoker, as the JVM's\n  LambdaMetafactory site does; anything else is cast.R1,i2164,R2,i1,R3,s18,arbace/j2g/code.aem8,R4,L1,V1,R5,R1,i2190,R2,i1,R3,s18,arbace/j2g/code.ae")

var Lit_423 *jrt.String = jrt.Intern("arbace.j2g.code$hoist")

var Lit_424 *jrt.String = jrt.Intern("arbace.j2g.code$expr")

var Lit_425 *jrt.String = jrt.Intern("arbace.j2g.code$expr_op")

var Lit_426 *jrt.String = jrt.Intern("arbace.j2g.code$expr_as")

var Lit_427 *jrt.String = jrt.Intern("arbace.j2g.code$cond_expr")

var Lit_428 *jrt.String = jrt.Intern("arbace.j2g.code$go_lit_QMARK_")

var Lit_429 *jrt.String = jrt.Intern("arbace.j2g.code$unsigned_lit")

var Lit_430 *jrt.String = jrt.Intern("arbace.j2g.code$arith_val")

var Lit_431 *jrt.String = jrt.Intern("arbace.j2g.code$box_val")

var Lit_432 *jrt.String = jrt.Intern("arbace.j2g.code$prim_convert")

var Lit_433 *jrt.String = jrt.Intern("arbace.j2g.code$convert_val")

var Lit_434 *jrt.String = jrt.Intern("arbace.j2g.code$cast_val")

var Lit_435 *jrt.String = jrt.Intern("arbace.j2g.code$instance_val")

var Lit_436 *jrt.String = jrt.Intern("arbace.j2g.code$args_for")

var Lit_437 *jrt.String = jrt.Intern("arbace.j2g.code$super_struct")

var Lit_438 *jrt.String = jrt.Intern("arbace.j2g.code$vh_arg")

var Lit_439 *jrt.String = jrt.Intern("arbace.j2g.code$vh_result")

var Lit_440 *jrt.String = jrt.Intern("arbace.j2g.code$vh_field_form")

var Lit_441 *jrt.String = jrt.Intern("arbace.j2g.code$vh_val")

var Lit_442 *jrt.String = jrt.Intern("arbace.j2g.code$invoke_val")

var Lit_443 *jrt.String = jrt.Intern("arbace.j2g.code$ctor_args")

var Lit_444 *jrt.String = jrt.Intern("arbace.j2g.code$new_val")

var Lit_445 *jrt.String = jrt.Intern("arbace.j2g.code$utf8_safe_QMARK_")

var Lit_446 *jrt.String = jrt.Intern("arbace.j2g.code$const_tree")

var Lit_447 *jrt.String = jrt.Intern("arbace.j2g.code$const_strings")

var Lit_448 *jrt.String = jrt.Intern("arbace.j2g.code$const_encode")

var Lit_449 *jrt.String = jrt.Intern("arbace.j2g.code$const_array")

var Lit_450 *jrt.String = jrt.Intern("arbace.j2g.code$array_val")

var Lit_451 *jrt.String = jrt.Intern("arbace.j2g.code$java_str_val")

var Lit_452 *jrt.String = jrt.Intern("arbace.j2g.code$target_info")

var Lit_453 *jrt.String = jrt.Intern("arbace.j2g.code$code_jump_BANG_")

var Lit_454 *jrt.String = jrt.Intern("arbace.j2g.code$outside_QMARK_")

var Lit_455 *jrt.String = jrt.Intern("arbace.j2g.code$method_return_BANG_")

var Lit_456 *jrt.String = jrt.Intern("arbace.j2g.code$set_static_BANG_")

var Lit_457 *jrt.String = jrt.Intern("arbace.j2g.code$dropped_store_QMARK_")

var Lit_458 *jrt.String = jrt.Intern("arbace.j2g.code$set_field_BANG_")

var Lit_459 *jrt.String = jrt.Intern("arbace.j2g.code$stmt_BANG_")

var Lit_460 *jrt.String = jrt.Intern("arbace.j2g.code$stmt_BANG__STAR_")

var Lit_461 *jrt.String = jrt.Intern("arbace.j2g.code$go_call_QMARK_")

var Lit_462 *jrt.String = jrt.Intern("arbace.j2g.code$assign_value_BANG_")

var Lit_463 *jrt.String = jrt.Intern("arbace.j2g.code$assign_BANG_")

var Lit_464 *jrt.String = jrt.Intern("arbace.j2g.code$ret_BANG_")

var Lit_465 *jrt.String = jrt.Intern("arbace.j2g.code$ctx_desc")

var Lit_466 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx")

var Lit_467 *jrt.String = jrt.Intern("arbace.j2g.code$translate_ctx_STAR_")

var Lit_468 *jrt.String = jrt.Intern("arbace.j2g.code$translate_and_or")

var Lit_469 *jrt.String = jrt.Intern("arbace.j2g.code$new_label")

var Lit_470 *jrt.String = jrt.Intern("arbace.j2g.code$translate_loop")

var Lit_471 *jrt.String = jrt.Intern("arbace.j2g.code$translate_label")

var Lit_472 *jrt.String = jrt.Intern("arbace.j2g.code$translate_for_each")

var Lit_473 *jrt.String = jrt.Intern("arbace.j2g.code$pattern_bindings")

var Lit_474 *jrt.String = jrt.Intern("arbace.j2g.code$record_pattern_QMARK_")

var Lit_475 *jrt.String = jrt.Intern("arbace.j2g.code$derived_accessor")

var Lit_476 *jrt.String = jrt.Intern("arbace.j2g.code$accessor_call_BANG_")

var Lit_477 *jrt.String = jrt.Intern("arbace.j2g.code$match_pattern_BANG_")

var Lit_478 *jrt.String = jrt.Intern("arbace.j2g.code$declare_pattern_BANG_")

var Lit_479 *jrt.String = jrt.Intern("arbace.j2g.code$translate_if_instance")

var Lit_480 *jrt.String = jrt.Intern("arbace.j2g.code$enum_ordinal")

var Lit_481 *jrt.String = jrt.Intern("arbace.j2g.code$translate_switch")

var Lit_482 *jrt.String = jrt.Intern("arbace.j2g.code$live_catches")

var Lit_483 *jrt.String = jrt.Intern("arbace.j2g.code$try_literal")

var Lit_484 *jrt.String = jrt.Intern("arbace.j2g.code$dispatch_codes_BANG_")

var Lit_485 *jrt.String = jrt.Intern("arbace.j2g.code$literal_form")

var Lit_486 *jrt.String = jrt.Intern("arbace.j2g.code$translate_try")

var Lit_487 *jrt.String = jrt.Intern("arbace.j2g.code$translate_monitor")

var Lit_488 *jrt.String = jrt.Intern("arbace.j2g.code$sam_sig")

var Lit_489 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_markers")

var Lit_490 *jrt.String = jrt.Intern("arbace.j2g.code$adapter_sym")

var Lit_491 *jrt.String = jrt.Intern("arbace.j2g.code$convert_ref_or_prim")

var Lit_492 *jrt.String = jrt.Intern("arbace.j2g.code$lambda_val")

var Lit_493 *jrt.String = jrt.Intern("arbace.j2g.code$fi_adapter_val")

var Lit_494 *jrt.String = jrt.Intern("arbace.j2g.code$method_ref_val")
