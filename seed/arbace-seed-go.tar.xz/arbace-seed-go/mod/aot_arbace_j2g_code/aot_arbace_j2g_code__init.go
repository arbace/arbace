//line aot_arbace_j2g_code__init.ae:1
package aot_arbace_j2g_code

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_code__init_part0_A_Unit0__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_code__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_code__init_part0_A_const_1) }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Unit1__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_code__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_2)) }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Unit2__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_code_eval969000004_loading__1927001464__auto____969000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_code_eval969000004_loading__1927001464__auto____969000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_356, false, nil); A_arbace_j2g_code_eval969000004_loading__1927001464__auto____969000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Unit3__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_code__init_part0_A_const_1)).Equals_O__Z(A_arbace_j2g_code__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_code_eval969000008_fn__969000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_code_eval969000008_fn__969000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_357, false, nil); A_arbace_j2g_code_eval969000008_fn__969000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Init__O() any { A_arbace_j2g_code__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Load__O() any { A_arbace_j2g_code__init_part0_A_Init(); A_arbace_j2g_code__init_part0_A_Unit0__O(); A_arbace_j2g_code__init_part0_A_Unit1__O(); A_arbace_j2g_code__init_part0_A_Unit2__O(); A_arbace_j2g_code__init_part0_A_Unit3__O(); A_arbace_j2g_code__init_part0_A_Unit4__O(); A_arbace_j2g_code__init_part0_A_Unit5__O(); A_arbace_j2g_code__init_part0_A_Unit6__O(); A_arbace_j2g_code__init_part0_A_Unit7__O(); A_arbace_j2g_code__init_part0_A_Unit8__O(); A_arbace_j2g_code__init_part0_A_Unit9__O(); A_arbace_j2g_code__init_part0_A_Unit10__O(); A_arbace_j2g_code__init_part0_A_Unit11__O(); A_arbace_j2g_code__init_part0_A_Unit12__O(); A_arbace_j2g_code__init_part0_A_Unit13__O(); A_arbace_j2g_code__init_part0_A_Unit14__O(); A_arbace_j2g_code__init_part0_A_Unit15__O(); A_arbace_j2g_code__init_part0_A_Unit16__O(); A_arbace_j2g_code__init_part0_A_Unit17__O(); A_arbace_j2g_code__init_part0_A_Unit18__O(); A_arbace_j2g_code__init_part0_A_Unit19__O(); A_arbace_j2g_code__init_part0_A_Unit20__O(); A_arbace_j2g_code__init_part0_A_Unit21__O(); A_arbace_j2g_code__init_part0_A_Unit22__O(); A_arbace_j2g_code__init_part0_A_Unit23__O(); A_arbace_j2g_code__init_part0_A_Unit24__O(); A_arbace_j2g_code__init_part0_A_Unit25__O(); A_arbace_j2g_code__init_part0_A_Unit26__O(); A_arbace_j2g_code__init_part0_A_Unit27__O(); A_arbace_j2g_code__init_part0_A_Unit28__O(); A_arbace_j2g_code__init_part0_A_Unit29__O(); A_arbace_j2g_code__init_part0_A_Unit30__O(); A_arbace_j2g_code__init_part0_A_Unit31__O(); A_arbace_j2g_code__init_part0_A_Unit32__O(); A_arbace_j2g_code__init_part0_A_Unit33__O(); A_arbace_j2g_code__init_part0_A_Unit34__O(); A_arbace_j2g_code__init_part0_A_Unit35__O(); A_arbace_j2g_code__init_part0_A_Unit36__O(); A_arbace_j2g_code__init_part0_A_Unit37__O(); A_arbace_j2g_code__init_part0_A_Unit38__O(); A_arbace_j2g_code__init_part0_A_Unit39__O(); A_arbace_j2g_code__init_part0_A_Unit40__O(); A_arbace_j2g_code__init_part0_A_Unit41__O(); A_arbace_j2g_code__init_part0_A_Unit42__O(); A_arbace_j2g_code__init_part0_A_Unit43__O(); A_arbace_j2g_code__init_part0_A_Unit44__O(); A_arbace_j2g_code__init_part0_A_Unit45__O(); A_arbace_j2g_code__init_part0_A_Unit46__O(); A_arbace_j2g_code__init_part0_A_Unit47__O(); A_arbace_j2g_code__init_part0_A_Unit48__O(); A_arbace_j2g_code__init_part0_A_Unit49__O(); A_arbace_j2g_code__init_part0_A_Unit50__O(); A_arbace_j2g_code__init_part0_A_Unit51__O(); A_arbace_j2g_code__init_part0_A_Unit52__O(); A_arbace_j2g_code__init_part0_A_Unit53__O(); A_arbace_j2g_code__init_part0_A_Unit54__O(); A_arbace_j2g_code__init_part0_A_Unit55__O(); A_arbace_j2g_code__init_part0_A_Unit56__O(); A_arbace_j2g_code__init_part0_A_Unit57__O(); A_arbace_j2g_code__init_part0_A_Unit58__O(); A_arbace_j2g_code__init_part0_A_Unit59__O(); A_arbace_j2g_code__init_part0_A_Unit60__O(); A_arbace_j2g_code__init_part0_A_Unit61__O(); A_arbace_j2g_code__init_part0_A_Unit62__O(); A_arbace_j2g_code__init_part0_A_Unit63__O(); A_arbace_j2g_code__init_part0_A_Unit64__O(); A_arbace_j2g_code__init_part0_A_Unit65__O(); A_arbace_j2g_code__init_part0_A_Unit66__O(); A_arbace_j2g_code__init_part0_A_Unit67__O(); A_arbace_j2g_code__init_part0_A_Unit68__O(); A_arbace_j2g_code__init_part0_A_Unit69__O(); A_arbace_j2g_code__init_part0_A_Unit70__O(); A_arbace_j2g_code__init_part0_A_Unit71__O(); A_arbace_j2g_code__init_part0_A_Unit72__O(); A_arbace_j2g_code__init_part0_A_Unit73__O(); A_arbace_j2g_code__init_part0_A_Unit74__O(); A_arbace_j2g_code__init_part0_A_Unit75__O(); A_arbace_j2g_code__init_part0_A_Unit76__O(); A_arbace_j2g_code__init_part0_A_Unit77__O(); A_arbace_j2g_code__init_part0_A_Unit78__O(); A_arbace_j2g_code__init_part0_A_Unit79__O(); A_arbace_j2g_code__init_part0_A_Unit80__O(); A_arbace_j2g_code__init_part0_A_Unit81__O(); A_arbace_j2g_code__init_part0_A_Unit82__O(); A_arbace_j2g_code__init_part0_A_Unit83__O(); A_arbace_j2g_code__init_part0_A_Unit84__O(); A_arbace_j2g_code__init_part0_A_Unit85__O(); A_arbace_j2g_code__init_part0_A_Unit86__O(); A_arbace_j2g_code__init_part0_A_Unit87__O(); A_arbace_j2g_code__init_part0_A_Unit88__O(); A_arbace_j2g_code__init_part0_A_Unit89__O(); A_arbace_j2g_code__init_part0_A_Unit90__O(); A_arbace_j2g_code__init_part0_A_Unit91__O(); A_arbace_j2g_code__init_part0_A_Unit92__O(); A_arbace_j2g_code__init_part0_A_Unit93__O(); A_arbace_j2g_code__init_part0_A_Unit94__O(); A_arbace_j2g_code__init_part0_A_Unit95__O(); A_arbace_j2g_code__init_part0_A_Unit96__O(); A_arbace_j2g_code__init_part0_A_Unit97__O(); A_arbace_j2g_code__init_part0_A_Unit98__O(); A_arbace_j2g_code__init_part0_A_Unit99__O(); return nil }



func A_arbace_j2g_code__init_A_Load__O() any { jrt.StartCheck(); A_arbace_j2g_code__init_part0_A_Init__O(); A_arbace_j2g_code__init_part1_A_Init__O(); A_arbace_j2g_code__init_part2_A_Init__O(); A_arbace_j2g_code__init_part0_A_Load__O(); A_arbace_j2g_code__init_part1_A_Load__O(); A_arbace_j2g_code__init_part2_A_Load__O(); return nil }













func A_arbace_j2g_code__init_part0_A_Unit4__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); A_arbace_j2g_code__init_part0_A_const_4.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_5)); return A_arbace_j2g_code__init_part0_A_const_4.SetDynamic_Z__Var(true).Ref() }




func A_arbace_j2g_code__init_part0_A_Unit5__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); A_arbace_j2g_code__init_part0_A_const_6.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_7)); return A_arbace_j2g_code__init_part0_A_const_6.SetDynamic_Z__Var(true).Ref() }

func A_arbace_j2g_code__init_part0_A_Unit6__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); A_arbace_j2g_code__init_part0_A_const_8.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_9)); return A_arbace_j2g_code__init_part0_A_const_8.SetDynamic_Z__Var(true).Ref() }






func A_arbace_j2g_code__init_part0_A_Unit7__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); A_arbace_j2g_code__init_part0_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_11)); return A_arbace_j2g_code__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }




func A_arbace_j2g_code__init_part0_A_Unit8__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_code_note_store_BANG__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_code_note_store_BANG__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_358, false, nil); A_arbace_j2g_code_note_store_BANG__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_13)); return A_arbace_j2g_code__init_part0_A_const_12 }














func A_arbace_j2g_code__init_part0_A_Unit9__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_14; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__8 any = A_arbace_j2g_code_fail_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_code_fail_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_359, true, nil); A_arbace_j2g_code_fail_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__8, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_15)); return A_arbace_j2g_code__init_part0_A_const_14 }

func A_arbace_j2g_code__init_part0_A_Unit10__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_code_pkg_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_code_pkg_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_360, false, nil); A_arbace_j2g_code_pkg_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_17)); return A_arbace_j2g_code__init_part0_A_const_16 }

func A_arbace_j2g_code__init_part0_A_Unit11__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(57, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_code_jsym_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_code_jsym_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_361, false, nil); A_arbace_j2g_code_jsym_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_19)); return A_arbace_j2g_code__init_part0_A_const_18 }
func A_arbace_j2g_code__init_part0_A_Unit12__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_code_csym_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_code_csym_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_362, false, nil); A_arbace_j2g_code_csym_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_21)); return A_arbace_j2g_code__init_part0_A_const_20 }
func A_arbace_j2g_code__init_part0_A_Unit13__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_code_gotype_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_code_gotype_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_363, false, nil); A_arbace_j2g_code_gotype_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_23)); return A_arbace_j2g_code__init_part0_A_const_22 }

func A_arbace_j2g_code__init_part0_A_Unit14__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_code_tag_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_code_tag_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_364, false, nil); A_arbace_j2g_code_tag_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_25)); return A_arbace_j2g_code__init_part0_A_const_24 }

func A_arbace_j2g_code__init_part0_A_Unit15__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_code_new_counter_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_code_new_counter_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_365, false, nil); A_arbace_j2g_code_new_counter_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_27)); return A_arbace_j2g_code__init_part0_A_const_26 }


func A_arbace_j2g_code__init_part0_A_Unit16__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_code_fresh_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_code_fresh_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_366, false, nil); A_arbace_j2g_code_fresh_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_29)); return A_arbace_j2g_code__init_part0_A_const_28 }










func A_arbace_j2g_code__init_part0_A_Unit17__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_code_fresh_raw_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_code_fresh_raw_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_367, false, nil); A_arbace_j2g_code_fresh_raw_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_31)); return A_arbace_j2g_code__init_part0_A_const_30 }









func A_arbace_j2g_code__init_part0_A_Unit18__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_code_tmp_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_code_tmp_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_368, false, nil); A_arbace_j2g_code_tmp_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_33)); return A_arbace_j2g_code__init_part0_A_const_32 }

func A_arbace_j2g_code__init_part0_A_Unit19__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_j2g_code_use_sym_BANG__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_code_use_sym_BANG__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_369, false, nil); A_arbace_j2g_code_use_sym_BANG__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_35)); return A_arbace_j2g_code__init_part0_A_const_34 }

func A_arbace_j2g_code__init_part0_A_Unit20__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_code_binding_sym_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_code_binding_sym_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_370, false, nil); A_arbace_j2g_code_binding_sym_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_37)); return A_arbace_j2g_code__init_part0_A_const_36 }










func A_arbace_j2g_code__init_part0_A_Unit21__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); A_arbace_j2g_code__init_part0_A_const_38.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_39)); return A_arbace_j2g_code__init_part0_A_const_38.SetDynamic_Z__Var(true).Ref() }





func A_arbace_j2g_code__init_part0_A_Unit22__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(108, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_code_with_line_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_code_with_line_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_371, false, nil); A_arbace_j2g_code_with_line_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_41)); return A_arbace_j2g_code__init_part0_A_const_40 }






func A_arbace_j2g_code__init_part0_A_Unit23__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_code_emit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_code_emit_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_372, false, nil); A_arbace_j2g_code_emit_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_43)); return A_arbace_j2g_code__init_part0_A_const_42 }

func A_arbace_j2g_code__init_part0_A_Unit24__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_j2g_code_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_code_decl_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_373, false, nil); A_arbace_j2g_code_decl_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_45)); return A_arbace_j2g_code__init_part0_A_const_44 }






func A_arbace_j2g_code__init_part0_A_Unit25__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_j2g_code_fold_items_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_code_fold_items_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_374, false, nil); A_arbace_j2g_code_fold_items_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_47)); return A_arbace_j2g_code__init_part0_A_const_46 }



















func A_arbace_j2g_code__init_part0_A_Unit26__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_j2g_code_with_block_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_code_with_block_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_375, false, nil); A_arbace_j2g_code_with_block_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_49)); return A_arbace_j2g_code__init_part0_A_const_48 }






func A_arbace_j2g_code__init_part0_A_Unit27__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_j2g_code_block_forms_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_code_block_forms_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_376, false, nil); A_arbace_j2g_code_block_forms_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_51)); return A_arbace_j2g_code__init_part0_A_const_50 }




func A_arbace_j2g_code__init_part0_A_Unit28__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_j2g_code_vt_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_code_vt_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_377, false, nil); A_arbace_j2g_code_vt_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_53)); return A_arbace_j2g_code__init_part0_A_const_52 }

func A_arbace_j2g_code__init_part0_A_Unit29__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_j2g_code_object_like_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_code_object_like_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_378, false, nil); A_arbace_j2g_code_object_like_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_55)); return A_arbace_j2g_code__init_part0_A_const_54 }

func A_arbace_j2g_code__init_part0_A_Unit30__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_j2g_code_zero_of_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_code_zero_of_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_379, false, nil); A_arbace_j2g_code_zero_of_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_57)); return A_arbace_j2g_code__init_part0_A_const_56 }







func A_arbace_j2g_code__init_part0_A_Unit31__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_j2g_code_literal_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_code_literal_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_380, false, nil); A_arbace_j2g_code_literal_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_59)); return A_arbace_j2g_code__init_part0_A_const_58 }

func A_arbace_j2g_code__init_part0_A_Unit32__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(170, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_j2g_code_fold_int_conv_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_code_fold_int_conv_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_381, false, nil); A_arbace_j2g_code_fold_int_conv_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_61)); return A_arbace_j2g_code__init_part0_A_const_60 }







func A_arbace_j2g_code__init_part0_A_Unit33__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_62; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_63)); return A_arbace_j2g_code__init_part0_A_const_62 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit34__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_65)); return A_arbace_j2g_code__init_part0_A_const_64 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit35__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_67)); return A_arbace_j2g_code__init_part0_A_const_66 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit36__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_69)); return A_arbace_j2g_code__init_part0_A_const_68 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit37__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_70; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_71)); return A_arbace_j2g_code__init_part0_A_const_70 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit38__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_73)); return A_arbace_j2g_code__init_part0_A_const_72 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit39__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_75)); return A_arbace_j2g_code__init_part0_A_const_74 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit40__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_77)); return A_arbace_j2g_code__init_part0_A_const_76 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit41__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_79)); return A_arbace_j2g_code__init_part0_A_const_78 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit42__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_81)); return A_arbace_j2g_code__init_part0_A_const_80 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit43__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_82; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_83)); return A_arbace_j2g_code__init_part0_A_const_82 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit44__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_85)); return A_arbace_j2g_code__init_part0_A_const_84 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit45__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_87)); return A_arbace_j2g_code__init_part0_A_const_86 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit46__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_89)); return A_arbace_j2g_code__init_part0_A_const_88 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit47__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_91)); return A_arbace_j2g_code__init_part0_A_const_90 }


func A_arbace_j2g_code__init_part0_A_Unit48__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_j2g_code_up_sym_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_code_up_sym_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_382, false, nil); A_arbace_j2g_code_up_sym_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_93)); return A_arbace_j2g_code__init_part0_A_const_92 }











func A_arbace_j2g_code__init_part0_A_Unit49__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(193, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_j2g_code_coerce_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_code_coerce_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_383, false, nil); A_arbace_j2g_code_coerce_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_95)); return A_arbace_j2g_code__init_part0_A_const_94 }






































func A_arbace_j2g_code__init_part0_A_Unit50__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_96; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__58 any = A_arbace_j2g_code_v_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_code_v_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_384, true, nil); A_arbace_j2g_code_v_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__58, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_97)); return A_arbace_j2g_code__init_part0_A_const_96 }




func A_arbace_j2g_code__init_part0_A_Unit51__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(237, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_98; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_99)); return A_arbace_j2g_code__init_part0_A_const_98 }

func A_arbace_j2g_code__init_part0_A_Unit52__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(239, 1); A_arbace_j2g_code__init_part0_A_const_100.BindRoot_O__V(A_arbace_j2g_code__init_part0_A_const_101); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_102)); return A_arbace_j2g_code__init_part0_A_const_100 }





func A_arbace_j2g_code__init_part0_A_Unit53__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(245, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_j2g_code_expressible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_code_expressible_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_385, false, nil); A_arbace_j2g_code_expressible_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_104)); return A_arbace_j2g_code__init_part0_A_const_103 }







func A_arbace_j2g_code__init_part0_A_Unit54__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_j2g_code_compiled_caller_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_j2g_code_compiled_caller_QMARK__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_386, false, nil); A_arbace_j2g_code_compiled_caller_QMARK__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_106)); return A_arbace_j2g_code__init_part0_A_const_105 }




func A_arbace_j2g_code__init_part0_A_Unit55__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_j2g_code_guarded_static_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_code_guarded_static_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_387, false, nil); A_arbace_j2g_code_guarded_static_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_107)); return A_arbace_j2g_code__init_part0_A_const_98 }


















func A_arbace_j2g_code__init_part0_A_Unit56__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(277, 1); A_arbace_j2g_code__init_part0_A_const_108.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_109)); return A_arbace_j2g_code__init_part0_A_const_108.SetDynamic_Z__Var(true).Ref() }







func A_arbace_j2g_code__init_part0_A_Unit57__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(285, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_j2g_code_memo_node_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_code_memo_node_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_388, false, nil); A_arbace_j2g_code_memo_node_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_111)); return A_arbace_j2g_code__init_part0_A_const_110 }














func A_arbace_j2g_code__init_part0_A_Unit58__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_112; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_113)); return A_arbace_j2g_code__init_part0_A_const_112 }

func A_arbace_j2g_code__init_part0_A_Unit59__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(302, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_j2g_code_simple_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_j2g_code_simple_QMARK__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_389, false, nil); A_arbace_j2g_code_simple_QMARK__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_115)); return A_arbace_j2g_code__init_part0_A_const_114 }




func A_arbace_j2g_code__init_part0_A_Unit60__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(307, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_j2g_code_simple_STAR__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_code_simple_STAR__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_390, false, nil); A_arbace_j2g_code_simple_STAR__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_116)); return A_arbace_j2g_code__init_part0_A_const_112 }











func A_arbace_j2g_code__init_part0_A_Unit61__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(319, 1); A_arbace_j2g_code__init_part0_A_const_117.BindRoot_O__V(A_arbace_j2g_code__init_part0_A_const_118); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_117; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_119)); return A_arbace_j2g_code__init_part0_A_const_117 }



func A_arbace_j2g_code__init_part0_A_Unit62__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(323, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_120; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_121)); return A_arbace_j2g_code__init_part0_A_const_120 }

func A_arbace_j2g_code__init_part0_A_Unit63__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(325, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_j2g_code_effects_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_code_effects_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_391, false, nil); A_arbace_j2g_code_effects_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_123)); return A_arbace_j2g_code__init_part0_A_const_122 }




func A_arbace_j2g_code__init_part0_A_Unit64__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_j2g_code_effects_STAR__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_code_effects_STAR__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_392, false, nil); A_arbace_j2g_code_effects_STAR__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_124)); return A_arbace_j2g_code__init_part0_A_const_120 }


















func A_arbace_j2g_code__init_part0_A_Unit65__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_j2g_code_reads_state_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_j2g_code_reads_state_QMARK__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_393, false, nil); A_arbace_j2g_code_reads_state_QMARK__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_126)); return A_arbace_j2g_code__init_part0_A_const_125 }

















func A_arbace_j2g_code__init_part0_A_Unit66__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_j2g_code_stable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_j2g_code_stable_QMARK__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_394, false, nil); A_arbace_j2g_code_stable_QMARK__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_128)); return A_arbace_j2g_code__init_part0_A_const_127 }










func A_arbace_j2g_code__init_part0_A_Unit67__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_j2g_code_hoist_value_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_code_hoist_value_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_395, false, nil); A_arbace_j2g_code_hoist_value_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_130)); return A_arbace_j2g_code__init_part0_A_const_129 }








func A_arbace_j2g_code__init_part0_A_Unit68__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(387, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_j2g_code_any_after_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_j2g_code_any_after_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_396, false, nil); A_arbace_j2g_code_any_after_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_132)); return A_arbace_j2g_code__init_part0_A_const_131 }








func A_arbace_j2g_code__init_part0_A_Unit69__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(396, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_j2g_code_const_num_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_j2g_code_const_num_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_397, false, nil); A_arbace_j2g_code_const_num_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_134)); return A_arbace_j2g_code__init_part0_A_const_133 }





func A_arbace_j2g_code__init_part0_A_Unit70__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(402, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_j2g_code_non_const_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_code_non_const_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_398, false, nil); A_arbace_j2g_code_non_const_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_136)); return A_arbace_j2g_code__init_part0_A_const_135 }





func A_arbace_j2g_code__init_part0_A_Unit71__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(408, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_j2g_code_index_x_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_j2g_code_index_x_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_399, false, nil); A_arbace_j2g_code_index_x_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_138)); return A_arbace_j2g_code__init_part0_A_const_137 }






func A_arbace_j2g_code__init_part0_A_Unit72__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_j2g_code_divisor_x_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_code_divisor_x_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_400, false, nil); A_arbace_j2g_code_divisor_x_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_140)); return A_arbace_j2g_code__init_part0_A_const_139 }







func A_arbace_j2g_code__init_part0_A_Unit73__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(423, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_141; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_j2g_code_operands_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_j2g_code_operands_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_401, false, nil); A_arbace_j2g_code_operands_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_142)); return A_arbace_j2g_code__init_part0_A_const_141 }
































func A_arbace_j2g_code__init_part0_A_Unit74__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(456, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_j2g_code_java_hash_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_j2g_code_java_hash_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_402, false, nil); A_arbace_j2g_code_java_hash_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_144)); return A_arbace_j2g_code__init_part0_A_const_143 }

func A_arbace_j2g_code__init_part0_A_Unit75__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(458, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_j2g_code_string_lit_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_j2g_code_string_lit_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_403, false, nil); A_arbace_j2g_code_string_lit_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_146)); return A_arbace_j2g_code__init_part0_A_const_145 }










func A_arbace_j2g_code__init_part0_A_Unit76__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(469, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_j2g_code_float_lit_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_j2g_code_float_lit_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_404, false, nil); A_arbace_j2g_code_float_lit_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_148)); return A_arbace_j2g_code__init_part0_A_const_147 }








func A_arbace_j2g_code__init_part0_A_Unit77__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(478, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_j2g_code_const_value_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_j2g_code_const_value_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_405, false, nil); A_arbace_j2g_code_const_value_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_150)); return A_arbace_j2g_code__init_part0_A_const_149 }














func A_arbace_j2g_code__init_part0_A_Unit78__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(493, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_j2g_code_missing_expr_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_j2g_code_missing_expr_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_406, false, nil); A_arbace_j2g_code_missing_expr_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_151)); return A_arbace_j2g_code__init_part0_A_const_84 }






func A_arbace_j2g_code__init_part0_A_Unit79__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(500, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_j2g_code_class_missing_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_j2g_code_class_missing_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_407, false, nil); A_arbace_j2g_code_class_missing_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_153)); return A_arbace_j2g_code__init_part0_A_const_152 }


func A_arbace_j2g_code__init_part0_A_Unit80__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(503, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_j2g_code_desc_missing_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_j2g_code_desc_missing_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_408, false, nil); A_arbace_j2g_code_desc_missing_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_155)); return A_arbace_j2g_code__init_part0_A_const_154 }
func A_arbace_j2g_code__init_part0_A_Unit81__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(504, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_j2g_code_mdesc_missing_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_j2g_code_mdesc_missing_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_409, false, nil); A_arbace_j2g_code_mdesc_missing_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_157)); return A_arbace_j2g_code__init_part0_A_const_156 }

func A_arbace_j2g_code__init_part0_A_Unit82__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(506, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_j2g_code_hw_static_exists_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_j2g_code_hw_static_exists_QMARK__A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_410, false, nil); A_arbace_j2g_code_hw_static_exists_QMARK__A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_159)); return A_arbace_j2g_code__init_part0_A_const_158 }



func A_arbace_j2g_code__init_part0_A_Unit83__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(510, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_160; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_j2g_code_lookup_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_j2g_code_lookup_call_QMARK__A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_411, false, nil); A_arbace_j2g_code_lookup_call_QMARK__A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_161)); return A_arbace_j2g_code__init_part0_A_const_160 }






func A_arbace_j2g_code__init_part0_A_Unit84__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(517, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_j2g_code_vh_op_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_j2g_code_vh_op_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_412, false, nil); A_arbace_j2g_code_vh_op_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_163)); return A_arbace_j2g_code__init_part0_A_const_162 }




func A_arbace_j2g_code__init_part0_A_Unit85__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(522, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_164; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_j2g_code_vh_supported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_j2g_code_vh_supported_QMARK__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_413, false, nil); A_arbace_j2g_code_vh_supported_QMARK__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_165)); return A_arbace_j2g_code__init_part0_A_const_164 }








func A_arbace_j2g_code__init_part0_A_Unit86__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_j2g_code_vh_missing_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_j2g_code_vh_missing_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_414, false, nil); A_arbace_j2g_code_vh_missing_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_167)); return A_arbace_j2g_code__init_part0_A_const_166 }


















func A_arbace_j2g_code__init_part0_A_Unit87__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(550, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_j2g_code_missing_reason_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_j2g_code_missing_reason_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_415, false, nil); A_arbace_j2g_code_missing_reason_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_168)); return A_arbace_j2g_code__init_part0_A_const_82 }























































func A_arbace_j2g_code__init_part0_A_Unit88__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(606, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_j2g_code_this_val_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_j2g_code_this_val_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_416, false, nil); A_arbace_j2g_code_this_val_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_170)); return A_arbace_j2g_code__init_part0_A_const_169 }




func A_arbace_j2g_code__init_part0_A_Unit89__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(611, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_j2g_code_outer_field_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_j2g_code_outer_field_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_417, false, nil); A_arbace_j2g_code_outer_field_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_172)); return A_arbace_j2g_code__init_part0_A_const_171 }







func A_arbace_j2g_code__init_part0_A_Unit90__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(619, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_173; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_j2g_code_this_path_val_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_j2g_code_this_path_val_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_418, false, nil); A_arbace_j2g_code_this_path_val_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_174)); return A_arbace_j2g_code__init_part0_A_const_173 }














func A_arbace_j2g_code__init_part0_A_Unit91__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(634, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_j2g_code_local_val_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_j2g_code_local_val_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_419, false, nil); A_arbace_j2g_code_local_val_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_176)); return A_arbace_j2g_code__init_part0_A_const_175 }





func A_arbace_j2g_code__init_part0_A_Unit92__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(640, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_177; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__130 any = A_arbace_j2g_code_struct_of_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_j2g_code_struct_of_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_420, true, nil); A_arbace_j2g_code_struct_of_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__130, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_178)); return A_arbace_j2g_code__init_part0_A_const_177 }














func A_arbace_j2g_code__init_part0_A_Unit93__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(655, 1); A_arbace_j2g_code__init_part0_A_const_179.BindRoot_O__V(A_arbace_j2g_code__init_part0_A_const_180); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_179; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_181)); return A_arbace_j2g_code__init_part0_A_const_179 }

func A_arbace_j2g_code__init_part0_A_Unit94__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(657, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_j2g_code_vh_field_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_j2g_code_vh_field_QMARK__A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_421, false, nil); A_arbace_j2g_code_vh_field_QMARK__A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_183)); return A_arbace_j2g_code__init_part0_A_const_182 }





func A_arbace_j2g_code__init_part0_A_Unit95__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(663, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_184; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_j2g_code_volatile_field_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_j2g_code_volatile_field_QMARK__A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_422, false, nil); A_arbace_j2g_code_volatile_field_QMARK__A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_185)); return A_arbace_j2g_code__init_part0_A_const_184 }

func A_arbace_j2g_code__init_part0_A_Unit96__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(665, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_186; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_j2g_code_volatile_read_A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_j2g_code_volatile_read_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_423, false, nil); A_arbace_j2g_code_volatile_read_A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_186; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_187)); return A_arbace_j2g_code__init_part0_A_const_186 }






func A_arbace_j2g_code__init_part0_A_Unit97__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(672, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_188; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_j2g_code_volatile_write_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_j2g_code_volatile_write_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_424, false, nil); A_arbace_j2g_code_volatile_write_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_188; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_189)); return A_arbace_j2g_code__init_part0_A_const_188 }





func A_arbace_j2g_code__init_part0_A_Unit98__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(678, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_190; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_j2g_code_field_place_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_j2g_code_field_place_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_425, false, nil); A_arbace_j2g_code_field_place_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_190; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_191)); return A_arbace_j2g_code__init_part0_A_const_190 }






func A_arbace_j2g_code__init_part0_A_Unit99__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(685, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_192; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_j2g_code_target_operands_A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_j2g_code_target_operands_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_426, false, nil); A_arbace_j2g_code_target_operands_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_192; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_193)); return A_arbace_j2g_code__init_part0_A_const_192 }








func A_arbace_j2g_code__init_part1_A_Unit100__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(694, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_code_static_place_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_code_static_place_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_428, false, nil); A_arbace_j2g_code_static_place_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_1)); return A_arbace_j2g_code__init_part1_A_const_0 }
//line :694:1
func A_arbace_j2g_code__init_part1_A_Init__O() any { A_arbace_j2g_code__init_part1_A_Init(); return nil }
//line :694:1
func A_arbace_j2g_code__init_part1_A_Load__O() any { A_arbace_j2g_code__init_part1_A_Init(); A_arbace_j2g_code__init_part1_A_Unit100__O(); A_arbace_j2g_code__init_part1_A_Unit101__O(); A_arbace_j2g_code__init_part1_A_Unit102__O(); A_arbace_j2g_code__init_part1_A_Unit103__O(); A_arbace_j2g_code__init_part1_A_Unit104__O(); A_arbace_j2g_code__init_part1_A_Unit105__O(); A_arbace_j2g_code__init_part1_A_Unit106__O(); A_arbace_j2g_code__init_part1_A_Unit107__O(); A_arbace_j2g_code__init_part1_A_Unit108__O(); A_arbace_j2g_code__init_part1_A_Unit109__O(); A_arbace_j2g_code__init_part1_A_Unit110__O(); A_arbace_j2g_code__init_part1_A_Unit111__O(); A_arbace_j2g_code__init_part1_A_Unit112__O(); A_arbace_j2g_code__init_part1_A_Unit113__O(); A_arbace_j2g_code__init_part1_A_Unit114__O(); A_arbace_j2g_code__init_part1_A_Unit115__O(); A_arbace_j2g_code__init_part1_A_Unit116__O(); A_arbace_j2g_code__init_part1_A_Unit117__O(); A_arbace_j2g_code__init_part1_A_Unit118__O(); A_arbace_j2g_code__init_part1_A_Unit119__O(); A_arbace_j2g_code__init_part1_A_Unit120__O(); A_arbace_j2g_code__init_part1_A_Unit121__O(); A_arbace_j2g_code__init_part1_A_Unit122__O(); A_arbace_j2g_code__init_part1_A_Unit123__O(); A_arbace_j2g_code__init_part1_A_Unit124__O(); A_arbace_j2g_code__init_part1_A_Unit125__O(); A_arbace_j2g_code__init_part1_A_Unit126__O(); A_arbace_j2g_code__init_part1_A_Unit127__O(); A_arbace_j2g_code__init_part1_A_Unit128__O(); A_arbace_j2g_code__init_part1_A_Unit129__O(); A_arbace_j2g_code__init_part1_A_Unit130__O(); A_arbace_j2g_code__init_part1_A_Unit131__O(); A_arbace_j2g_code__init_part1_A_Unit132__O(); A_arbace_j2g_code__init_part1_A_Unit133__O(); A_arbace_j2g_code__init_part1_A_Unit134__O(); A_arbace_j2g_code__init_part1_A_Unit135__O(); A_arbace_j2g_code__init_part1_A_Unit136__O(); A_arbace_j2g_code__init_part1_A_Unit137__O(); A_arbace_j2g_code__init_part1_A_Unit138__O(); A_arbace_j2g_code__init_part1_A_Unit139__O(); A_arbace_j2g_code__init_part1_A_Unit140__O(); A_arbace_j2g_code__init_part1_A_Unit141__O(); A_arbace_j2g_code__init_part1_A_Unit142__O(); A_arbace_j2g_code__init_part1_A_Unit143__O(); A_arbace_j2g_code__init_part1_A_Unit144__O(); A_arbace_j2g_code__init_part1_A_Unit145__O(); A_arbace_j2g_code__init_part1_A_Unit146__O(); A_arbace_j2g_code__init_part1_A_Unit147__O(); A_arbace_j2g_code__init_part1_A_Unit148__O(); A_arbace_j2g_code__init_part1_A_Unit149__O(); A_arbace_j2g_code__init_part1_A_Unit150__O(); A_arbace_j2g_code__init_part1_A_Unit151__O(); A_arbace_j2g_code__init_part1_A_Unit152__O(); A_arbace_j2g_code__init_part1_A_Unit153__O(); A_arbace_j2g_code__init_part1_A_Unit154__O(); A_arbace_j2g_code__init_part1_A_Unit155__O(); A_arbace_j2g_code__init_part1_A_Unit156__O(); A_arbace_j2g_code__init_part1_A_Unit157__O(); A_arbace_j2g_code__init_part1_A_Unit158__O(); A_arbace_j2g_code__init_part1_A_Unit159__O(); A_arbace_j2g_code__init_part1_A_Unit160__O(); A_arbace_j2g_code__init_part1_A_Unit161__O(); A_arbace_j2g_code__init_part1_A_Unit162__O(); A_arbace_j2g_code__init_part1_A_Unit163__O(); A_arbace_j2g_code__init_part1_A_Unit164__O(); A_arbace_j2g_code__init_part1_A_Unit165__O(); A_arbace_j2g_code__init_part1_A_Unit166__O(); A_arbace_j2g_code__init_part1_A_Unit167__O(); A_arbace_j2g_code__init_part1_A_Unit168__O(); A_arbace_j2g_code__init_part1_A_Unit169__O(); A_arbace_j2g_code__init_part1_A_Unit170__O(); A_arbace_j2g_code__init_part1_A_Unit171__O(); A_arbace_j2g_code__init_part1_A_Unit172__O(); A_arbace_j2g_code__init_part1_A_Unit173__O(); A_arbace_j2g_code__init_part1_A_Unit174__O(); A_arbace_j2g_code__init_part1_A_Unit175__O(); A_arbace_j2g_code__init_part1_A_Unit176__O(); A_arbace_j2g_code__init_part1_A_Unit177__O(); A_arbace_j2g_code__init_part1_A_Unit178__O(); A_arbace_j2g_code__init_part1_A_Unit179__O(); A_arbace_j2g_code__init_part1_A_Unit180__O(); A_arbace_j2g_code__init_part1_A_Unit181__O(); A_arbace_j2g_code__init_part1_A_Unit182__O(); A_arbace_j2g_code__init_part1_A_Unit183__O(); A_arbace_j2g_code__init_part1_A_Unit184__O(); A_arbace_j2g_code__init_part1_A_Unit185__O(); A_arbace_j2g_code__init_part1_A_Unit186__O(); A_arbace_j2g_code__init_part1_A_Unit187__O(); A_arbace_j2g_code__init_part1_A_Unit188__O(); A_arbace_j2g_code__init_part1_A_Unit189__O(); A_arbace_j2g_code__init_part1_A_Unit190__O(); A_arbace_j2g_code__init_part1_A_Unit191__O(); A_arbace_j2g_code__init_part1_A_Unit192__O(); A_arbace_j2g_code__init_part1_A_Unit193__O(); A_arbace_j2g_code__init_part1_A_Unit194__O(); A_arbace_j2g_code__init_part1_A_Unit195__O(); A_arbace_j2g_code__init_part1_A_Unit196__O(); A_arbace_j2g_code__init_part1_A_Unit197__O(); A_arbace_j2g_code__init_part1_A_Unit198__O(); A_arbace_j2g_code__init_part1_A_Unit199__O(); return nil }



func A_arbace_j2g_code__init_part1_A_Unit101__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(698, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_code_class_init_call_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_code_class_init_call_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_429, false, nil); A_arbace_j2g_code_class_init_call_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_3)); return A_arbace_j2g_code__init_part1_A_const_2 }






func A_arbace_j2g_code__init_part1_A_Unit102__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(705, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_code_class_val_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_code_class_val_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_430, false, nil); A_arbace_j2g_code_class_val_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_5)); return A_arbace_j2g_code__init_part1_A_const_4 }




















func A_arbace_j2g_code__init_part1_A_Unit103__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_7)); return A_arbace_j2g_code__init_part1_A_const_6 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit104__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_9)); return A_arbace_j2g_code__init_part1_A_const_8 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit105__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_11)); return A_arbace_j2g_code__init_part1_A_const_10 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit106__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_13)); return A_arbace_j2g_code__init_part1_A_const_12 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit107__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_15)); return A_arbace_j2g_code__init_part1_A_const_14 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit108__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_17)); return A_arbace_j2g_code__init_part1_A_const_16 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit109__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_19)); return A_arbace_j2g_code__init_part1_A_const_18 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit110__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_21)); return A_arbace_j2g_code__init_part1_A_const_20 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit111__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_23)); return A_arbace_j2g_code__init_part1_A_const_22 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit112__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_25)); return A_arbace_j2g_code__init_part1_A_const_24 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit113__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_27)); return A_arbace_j2g_code__init_part1_A_const_26 }
//line :726:1
func A_arbace_j2g_code__init_part1_A_Unit114__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_29)); return A_arbace_j2g_code__init_part1_A_const_28 }


func A_arbace_j2g_code__init_part1_A_Unit115__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(729, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_code_hoist_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_code_hoist_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_431, false, nil); A_arbace_j2g_code_hoist_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_31)); return A_arbace_j2g_code__init_part1_A_const_30 }











func A_arbace_j2g_code__init_part1_A_Unit116__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(741, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_code_expr_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_code_expr_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_432, false, nil); A_arbace_j2g_code_expr_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_33)); return A_arbace_j2g_code__init_part1_A_const_32 }














func A_arbace_j2g_code__init_part1_A_Unit117__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(756, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_code_expr_op_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_code_expr_op_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_433, false, nil); A_arbace_j2g_code_expr_op_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_35)); return A_arbace_j2g_code__init_part1_A_const_34 }






















































































func A_arbace_j2g_code__init_part1_A_Unit118__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(843, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_code_expr_as_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_code_expr_as_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_434, false, nil); A_arbace_j2g_code_expr_as_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_37)); return A_arbace_j2g_code__init_part1_A_const_36 }
















func A_arbace_j2g_code__init_part1_A_Unit119__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(860, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_code_cond_expr_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_code_cond_expr_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_435, false, nil); A_arbace_j2g_code_cond_expr_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_39)); return A_arbace_j2g_code__init_part1_A_const_38 }
















func A_arbace_j2g_code__init_part1_A_Unit120__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(877, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_code_go_lit_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_code_go_lit_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_436, false, nil); A_arbace_j2g_code_go_lit_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_41)); return A_arbace_j2g_code__init_part1_A_const_40 }

func A_arbace_j2g_code__init_part1_A_Unit121__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(879, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_code_unsigned_lit_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_code_unsigned_lit_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_437, false, nil); A_arbace_j2g_code_unsigned_lit_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_43)); return A_arbace_j2g_code__init_part1_A_const_42 }








func A_arbace_j2g_code__init_part1_A_Unit122__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(888, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_code_arith_val_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_code_arith_val_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_438, false, nil); A_arbace_j2g_code_arith_val_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_44)); return A_arbace_j2g_code__init_part1_A_const_10 }



















































func A_arbace_j2g_code__init_part1_A_Unit123__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(940, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_code_box_val_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_code_box_val_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_439, false, nil); A_arbace_j2g_code_box_val_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_46)); return A_arbace_j2g_code__init_part1_A_const_45 }



func A_arbace_j2g_code__init_part1_A_Unit124__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(944, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_code_prim_convert_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_code_prim_convert_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_440, false, nil); A_arbace_j2g_code_prim_convert_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_48)); return A_arbace_j2g_code__init_part1_A_const_47 }
















func A_arbace_j2g_code__init_part1_A_Unit125__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(961, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_j2g_code_convert_val_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_code_convert_val_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_441, false, nil); A_arbace_j2g_code_convert_val_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_49)); return A_arbace_j2g_code__init_part1_A_const_12 }



















func A_arbace_j2g_code__init_part1_A_Unit126__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(981, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_code_cast_val_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_code_cast_val_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_442, false, nil); A_arbace_j2g_code_cast_val_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_50)); return A_arbace_j2g_code__init_part1_A_const_14 }



























func A_arbace_j2g_code__init_part1_A_Unit127__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1009, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_code_instance_val_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_code_instance_val_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_443, false, nil); A_arbace_j2g_code_instance_val_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_51)); return A_arbace_j2g_code__init_part1_A_const_16 }



















func A_arbace_j2g_code__init_part1_A_Unit128__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1029, 1); A_arbace_j2g_code__init_part1_A_const_52.BindRoot_O__V(A_arbace_j2g_code__init_part1_A_const_53); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_52; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_54)); return A_arbace_j2g_code__init_part1_A_const_52 }





func A_arbace_j2g_code__init_part1_A_Unit129__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1035, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_code_object_helper_args_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_code_object_helper_args_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_444, false, nil); A_arbace_j2g_code_object_helper_args_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_56)); return A_arbace_j2g_code__init_part1_A_const_55 }





func A_arbace_j2g_code__init_part1_A_Unit130__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1041, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_j2g_code_args_for_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_code_args_for_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_445, false, nil); A_arbace_j2g_code_args_for_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_58)); return A_arbace_j2g_code__init_part1_A_const_57 }



func A_arbace_j2g_code__init_part1_A_Unit131__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1045, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_j2g_code_super_struct_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_code_super_struct_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_446, false, nil); A_arbace_j2g_code_super_struct_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_60)); return A_arbace_j2g_code__init_part1_A_const_59 }





func A_arbace_j2g_code__init_part1_A_Unit132__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1051, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_j2g_code_vh_arg_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_code_vh_arg_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_447, false, nil); A_arbace_j2g_code_vh_arg_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_62)); return A_arbace_j2g_code__init_part1_A_const_61 }








func A_arbace_j2g_code__init_part1_A_Unit133__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1060, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_j2g_code_vh_result_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_code_vh_result_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_448, false, nil); A_arbace_j2g_code_vh_result_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_64)); return A_arbace_j2g_code__init_part1_A_const_63 }










func A_arbace_j2g_code__init_part1_A_Unit134__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1071, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_j2g_code_vh_field_form_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_code_vh_field_form_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_449, false, nil); A_arbace_j2g_code_vh_field_form_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_66)); return A_arbace_j2g_code__init_part1_A_const_65 }













































func A_arbace_j2g_code__init_part1_A_Unit135__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1117, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_j2g_code_vh_val_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_code_vh_val_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_450, false, nil); A_arbace_j2g_code_vh_val_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_68)); return A_arbace_j2g_code__init_part1_A_const_67 }







































func A_arbace_j2g_code__init_part1_A_Unit136__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1157, 1); A_arbace_j2g_code__init_part1_A_const_69.BindRoot_O__V(A_arbace_j2g_code__init_part1_A_const_70); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_69; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_71)); return A_arbace_j2g_code__init_part1_A_const_69 }




func A_arbace_j2g_code__init_part1_A_Unit137__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1162, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_j2g_code_invoke_val_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_code_invoke_val_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_451, false, nil); A_arbace_j2g_code_invoke_val_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_72)); return A_arbace_j2g_code__init_part1_A_const_6 }
































































































































func A_arbace_j2g_code__init_part1_A_Unit138__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1291, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_j2g_code_ctor_args_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_code_ctor_args_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_452, false, nil); A_arbace_j2g_code_ctor_args_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_74)); return A_arbace_j2g_code__init_part1_A_const_73 }



















func A_arbace_j2g_code__init_part1_A_Unit139__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1311, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_j2g_code_new_val_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_code_new_val_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_453, false, nil); A_arbace_j2g_code_new_val_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_75)); return A_arbace_j2g_code__init_part1_A_const_8 }














func A_arbace_j2g_code__init_part1_A_Unit140__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1326, 1); A_arbace_j2g_code__init_part1_A_const_76.BindRoot_O__V(A_arbace_j2g_code__init_part1_A_const_77); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_78)); return A_arbace_j2g_code__init_part1_A_const_76 }



func A_arbace_j2g_code__init_part1_A_Unit141__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1330, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_j2g_code_utf8_safe_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_code_utf8_safe_QMARK__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_454, false, nil); A_arbace_j2g_code_utf8_safe_QMARK__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_80)); return A_arbace_j2g_code__init_part1_A_const_79 }














func A_arbace_j2g_code__init_part1_A_Unit142__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1345, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_j2g_code_const_tree_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_code_const_tree_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_455, false, nil); A_arbace_j2g_code_const_tree_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_82)); return A_arbace_j2g_code__init_part1_A_const_81 }
















func A_arbace_j2g_code__init_part1_A_Unit143__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1362, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_j2g_code_const_strings_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_code_const_strings_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_456, false, nil); A_arbace_j2g_code_const_strings_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_84)); return A_arbace_j2g_code__init_part1_A_const_83 }





func A_arbace_j2g_code__init_part1_A_Unit144__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1368, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_j2g_code_const_encode_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_code_const_encode_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_457, false, nil); A_arbace_j2g_code_const_encode_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_86)); return A_arbace_j2g_code__init_part1_A_const_85 }













func A_arbace_j2g_code__init_part1_A_Unit145__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1382, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_j2g_code_const_array_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_j2g_code_const_array_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_458, false, nil); A_arbace_j2g_code_const_array_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_88)); return A_arbace_j2g_code__init_part1_A_const_87 }














func A_arbace_j2g_code__init_part1_A_Unit146__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1397, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_j2g_code_array_val_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_code_array_val_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_459, false, nil); A_arbace_j2g_code_array_val_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_89)); return A_arbace_j2g_code__init_part1_A_const_24 }























func A_arbace_j2g_code__init_part1_A_Unit147__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1421, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_j2g_code_java_str_val_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_code_java_str_val_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_460, false, nil); A_arbace_j2g_code_java_str_val_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_90)); return A_arbace_j2g_code__init_part1_A_const_18 }

























func A_arbace_j2g_code__init_part1_A_Unit148__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1447, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_j2g_code_target_info_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_j2g_code_target_info_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_461, false, nil); A_arbace_j2g_code_target_info_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_92)); return A_arbace_j2g_code__init_part1_A_const_91 }

func A_arbace_j2g_code__init_part1_A_Unit149__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1449, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_j2g_code_code_jump_BANG__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_code_code_jump_BANG__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_462, false, nil); A_arbace_j2g_code_code_jump_BANG__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_94)); return A_arbace_j2g_code__init_part1_A_const_93 }










func A_arbace_j2g_code__init_part1_A_Unit150__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1460, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_j2g_code_outside_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_code_outside_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_463, false, nil); A_arbace_j2g_code_outside_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_96)); return A_arbace_j2g_code__init_part1_A_const_95 }

func A_arbace_j2g_code__init_part1_A_Unit151__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1462, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_j2g_code_method_return_BANG__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_code_method_return_BANG__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_464, false, nil); A_arbace_j2g_code_method_return_BANG__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_98)); return A_arbace_j2g_code__init_part1_A_const_97 }






func A_arbace_j2g_code__init_part1_A_Unit152__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1469, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_j2g_code_set_static_BANG__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_j2g_code_set_static_BANG__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_465, false, nil); A_arbace_j2g_code_set_static_BANG__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_100)); return A_arbace_j2g_code__init_part1_A_const_99 }











func A_arbace_j2g_code__init_part1_A_Unit153__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1481, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_j2g_code_dropped_store_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_j2g_code_dropped_store_QMARK__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_466, false, nil); A_arbace_j2g_code_dropped_store_QMARK__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_102)); return A_arbace_j2g_code__init_part1_A_const_101 }



















func A_arbace_j2g_code__init_part1_A_Unit154__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1501, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_j2g_code_set_field_BANG__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_code_set_field_BANG__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_467, false, nil); A_arbace_j2g_code_set_field_BANG__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_104)); return A_arbace_j2g_code__init_part1_A_const_103 }






func A_arbace_j2g_code__init_part1_A_Unit155__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1508, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_j2g_code_stmt_BANG__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_j2g_code_stmt_BANG__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_468, false, nil); A_arbace_j2g_code_stmt_BANG__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_106)); return A_arbace_j2g_code__init_part1_A_const_105 }





func A_arbace_j2g_code__init_part1_A_Unit156__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1514, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_j2g_code_stmt_BANG__STAR__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_j2g_code_stmt_BANG__STAR__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_469, false, nil); A_arbace_j2g_code_stmt_BANG__STAR__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_108)); return A_arbace_j2g_code__init_part1_A_const_107 }





















































func A_arbace_j2g_code__init_part1_A_Unit157__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1568, 1); A_arbace_j2g_code__init_part1_A_const_109.BindRoot_O__V(A_arbace_j2g_code__init_part1_A_const_110); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_109; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_111)); return A_arbace_j2g_code__init_part1_A_const_109 }



func A_arbace_j2g_code__init_part1_A_Unit158__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1572, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_j2g_code_go_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_code_go_call_QMARK__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_470, false, nil); A_arbace_j2g_code_go_call_QMARK__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_113)); return A_arbace_j2g_code__init_part1_A_const_112 }









func A_arbace_j2g_code__init_part1_A_Unit159__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1582, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_j2g_code_assign_value_BANG__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_j2g_code_assign_value_BANG__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_471, false, nil); A_arbace_j2g_code_assign_value_BANG__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_115)); return A_arbace_j2g_code__init_part1_A_const_114 }





func A_arbace_j2g_code__init_part1_A_Unit160__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1588, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_j2g_code_assign_BANG__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_code_assign_BANG__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_472, false, nil); A_arbace_j2g_code_assign_BANG__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_117)); return A_arbace_j2g_code__init_part1_A_const_116 }




func A_arbace_j2g_code__init_part1_A_Unit161__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1593, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_j2g_code_ret_BANG__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_j2g_code_ret_BANG__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_473, false, nil); A_arbace_j2g_code_ret_BANG__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_119)); return A_arbace_j2g_code__init_part1_A_const_118 }




func A_arbace_j2g_code__init_part1_A_Unit162__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1598, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_j2g_code_ctx_desc_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_j2g_code_ctx_desc_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_474, false, nil); A_arbace_j2g_code_ctx_desc_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_121)); return A_arbace_j2g_code__init_part1_A_const_120 }

func A_arbace_j2g_code__init_part1_A_Unit163__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1600, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_122; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_123)); return A_arbace_j2g_code__init_part1_A_const_122 }
//line :1600:1
func A_arbace_j2g_code__init_part1_A_Unit164__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1600, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_124; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_125)); return A_arbace_j2g_code__init_part1_A_const_124 }
//line :1600:1
func A_arbace_j2g_code__init_part1_A_Unit165__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1600, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_126; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_127)); return A_arbace_j2g_code__init_part1_A_const_126 }
//line :1600:1
func A_arbace_j2g_code__init_part1_A_Unit166__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1600, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_128; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_129)); return A_arbace_j2g_code__init_part1_A_const_128 }
//line :1600:1
func A_arbace_j2g_code__init_part1_A_Unit167__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1600, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_130; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_131)); return A_arbace_j2g_code__init_part1_A_const_130 }
//line :1600:1
func A_arbace_j2g_code__init_part1_A_Unit168__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1600, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_132; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_133)); return A_arbace_j2g_code__init_part1_A_const_132 }
//line :1600:1
func A_arbace_j2g_code__init_part1_A_Unit169__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1600, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_134; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_135)); return A_arbace_j2g_code__init_part1_A_const_134 }
//line :1600:1
func A_arbace_j2g_code__init_part1_A_Unit170__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1600, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_136; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_137)); return A_arbace_j2g_code__init_part1_A_const_136 }


func A_arbace_j2g_code__init_part1_A_Unit171__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1603, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_j2g_code_translate_ctx_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_j2g_code_translate_ctx_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_475, false, nil); A_arbace_j2g_code_translate_ctx_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_139)); return A_arbace_j2g_code__init_part1_A_const_138 }





func A_arbace_j2g_code__init_part1_A_Unit172__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1609, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_j2g_code_translate_ctx_STAR__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_j2g_code_translate_ctx_STAR__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_476, false, nil); A_arbace_j2g_code_translate_ctx_STAR__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_141)); return A_arbace_j2g_code__init_part1_A_const_140 }




















































































































func A_arbace_j2g_code__init_part1_A_Unit173__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1726, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_136; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_j2g_code_translate_and_or_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_j2g_code_translate_and_or_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_477, false, nil); A_arbace_j2g_code_translate_and_or_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_142)); return A_arbace_j2g_code__init_part1_A_const_136 }
























func A_arbace_j2g_code__init_part1_A_Unit174__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1751, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_j2g_code_new_label_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_j2g_code_new_label_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_478, false, nil); A_arbace_j2g_code_new_label_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_144)); return A_arbace_j2g_code__init_part1_A_const_143 }

func A_arbace_j2g_code__init_part1_A_Unit175__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1753, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_j2g_code_translate_loop_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_j2g_code_translate_loop_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_479, false, nil); A_arbace_j2g_code_translate_loop_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_145)); return A_arbace_j2g_code__init_part1_A_const_126 }
























func A_arbace_j2g_code__init_part1_A_Unit176__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1778, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_j2g_code_translate_label_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_j2g_code_translate_label_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_480, false, nil); A_arbace_j2g_code_translate_label_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_146)); return A_arbace_j2g_code__init_part1_A_const_128 }








func A_arbace_j2g_code__init_part1_A_Unit177__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1787, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_132; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_j2g_code_translate_for_each_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_j2g_code_translate_for_each_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_481, false, nil); A_arbace_j2g_code_translate_for_each_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_147)); return A_arbace_j2g_code__init_part1_A_const_132 }





































func A_arbace_j2g_code__init_part1_A_Unit178__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1825, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_j2g_code_pattern_bindings_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_j2g_code_pattern_bindings_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_482, false, nil); A_arbace_j2g_code_pattern_bindings_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_149)); return A_arbace_j2g_code__init_part1_A_const_148 }


func A_arbace_j2g_code__init_part1_A_Unit179__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1828, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_150; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_j2g_code_record_pattern_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_j2g_code_record_pattern_QMARK__A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_483, false, nil); A_arbace_j2g_code_record_pattern_QMARK__A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_151)); return A_arbace_j2g_code__init_part1_A_const_150 }

func A_arbace_j2g_code__init_part1_A_Unit180__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1830, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_j2g_code_derived_accessor_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_j2g_code_derived_accessor_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_484, false, nil); A_arbace_j2g_code_derived_accessor_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_153)); return A_arbace_j2g_code__init_part1_A_const_152 }







func A_arbace_j2g_code__init_part1_A_Unit181__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1838, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_j2g_code_accessor_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_j2g_code_accessor_call_BANG__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_485, false, nil); A_arbace_j2g_code_accessor_call_BANG__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_155)); return A_arbace_j2g_code__init_part1_A_const_154 }























func A_arbace_j2g_code__init_part1_A_Unit182__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1862, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_j2g_code_match_pattern_BANG__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_j2g_code_match_pattern_BANG__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_486, false, nil); A_arbace_j2g_code_match_pattern_BANG__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_157)); return A_arbace_j2g_code__init_part1_A_const_156 }



































func A_arbace_j2g_code__init_part1_A_Unit183__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1898, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_j2g_code_declare_pattern_BANG__A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_j2g_code_declare_pattern_BANG__A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_487, false, nil); A_arbace_j2g_code_declare_pattern_BANG__A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_159)); return A_arbace_j2g_code__init_part1_A_const_158 }














func A_arbace_j2g_code__init_part1_A_Unit184__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1913, 1); A_arbace_j2g_code__init_part1_A_const_160.BindRoot_O__V(A_arbace_j2g_code__init_part1_A_const_161); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_160; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_162)); return A_arbace_j2g_code__init_part1_A_const_160 }






func A_arbace_j2g_code__init_part1_A_Unit185__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1920, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_j2g_code_if_instance_assert_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_j2g_code_if_instance_assert_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_488, false, nil); A_arbace_j2g_code_if_instance_assert_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_164)); return A_arbace_j2g_code__init_part1_A_const_163 }










func A_arbace_j2g_code__init_part1_A_Unit186__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1931, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_j2g_code_translate_if_instance_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_j2g_code_translate_if_instance_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_489, false, nil); A_arbace_j2g_code_translate_if_instance_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_165)); return A_arbace_j2g_code__init_part1_A_const_134 }






















func A_arbace_j2g_code__init_part1_A_Unit187__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1954, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_j2g_code_enum_ordinal_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_j2g_code_enum_ordinal_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_490, false, nil); A_arbace_j2g_code_enum_ordinal_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_167)); return A_arbace_j2g_code__init_part1_A_const_166 }







func A_arbace_j2g_code__init_part1_A_Unit188__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1962, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_j2g_code_translate_switch_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_j2g_code_translate_switch_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_491, false, nil); A_arbace_j2g_code_translate_switch_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_168)); return A_arbace_j2g_code__init_part1_A_const_130 }































































































































func A_arbace_j2g_code__init_part1_A_Unit189__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2090, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_j2g_code_live_catches_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_j2g_code_live_catches_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_492, false, nil); A_arbace_j2g_code_live_catches_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_170)); return A_arbace_j2g_code__init_part1_A_const_169 }




func A_arbace_j2g_code__init_part1_A_Unit190__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2095, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_171; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_j2g_code_try_literal_A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_j2g_code_try_literal_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_493, false, nil); A_arbace_j2g_code_try_literal_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_172)); return A_arbace_j2g_code__init_part1_A_const_171 }
















func A_arbace_j2g_code__init_part1_A_Unit191__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2112, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_173; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_j2g_code_dispatch_codes_BANG__A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_j2g_code_dispatch_codes_BANG__A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_494, false, nil); A_arbace_j2g_code_dispatch_codes_BANG__A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_174)); return A_arbace_j2g_code__init_part1_A_const_173 }




















func A_arbace_j2g_code__init_part1_A_Unit192__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2133, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_j2g_code_literal_form_A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_j2g_code_literal_form_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_495, false, nil); A_arbace_j2g_code_literal_form_A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_176)); return A_arbace_j2g_code__init_part1_A_const_175 }






















func A_arbace_j2g_code__init_part1_A_Unit193__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2156, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_j2g_code_translate_try_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_j2g_code_translate_try_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_496, false, nil); A_arbace_j2g_code_translate_try_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_177)); return A_arbace_j2g_code__init_part1_A_const_122 }








































































func A_arbace_j2g_code__init_part1_A_Unit194__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2229, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_124; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_j2g_code_translate_monitor_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_j2g_code_translate_monitor_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_497, false, nil); A_arbace_j2g_code_translate_monitor_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_178)); return A_arbace_j2g_code__init_part1_A_const_124 }
























func A_arbace_j2g_code__init_part1_A_Unit195__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2254, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_179; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_j2g_code_sam_sig_A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_j2g_code_sam_sig_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_498, false, nil); A_arbace_j2g_code_sam_sig_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_180)); return A_arbace_j2g_code__init_part1_A_const_179 }




func A_arbace_j2g_code__init_part1_A_Unit196__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2259, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_181; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_j2g_code_lambda_markers_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_j2g_code_lambda_markers_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_499, false, nil); A_arbace_j2g_code_lambda_markers_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_182)); return A_arbace_j2g_code__init_part1_A_const_181 }










func A_arbace_j2g_code__init_part1_A_Unit197__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2270, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_183; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_j2g_code_adapter_sym_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_j2g_code_adapter_sym_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_500, false, nil); A_arbace_j2g_code_adapter_sym_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_184)); return A_arbace_j2g_code__init_part1_A_const_183 }







func A_arbace_j2g_code__init_part1_A_Unit198__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2278, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_185; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_j2g_code_convert_ref_or_prim_A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_j2g_code_convert_ref_or_prim_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_501, false, nil); A_arbace_j2g_code_convert_ref_or_prim_A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_186)); return A_arbace_j2g_code__init_part1_A_const_185 }





















func A_arbace_j2g_code__init_part1_A_Unit199__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2300, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_j2g_code_lambda_val_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_j2g_code_lambda_val_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_502, false, nil); A_arbace_j2g_code_lambda_val_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_187)); return A_arbace_j2g_code__init_part1_A_const_20 }






















func A_arbace_j2g_code__init_part2_A_Unit200__O() any { A_arbace_j2g_code__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2323, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part2_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_code_fi_adapter_val_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_code_fi_adapter_val_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_504, false, nil); A_arbace_j2g_code_fi_adapter_val_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part2_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part2_A_const_1)); return A_arbace_j2g_code__init_part2_A_const_0 }
//line :2323:1
func A_arbace_j2g_code__init_part2_A_Init__O() any { A_arbace_j2g_code__init_part2_A_Init(); return nil }
//line :2323:1
func A_arbace_j2g_code__init_part2_A_Load__O() any { A_arbace_j2g_code__init_part2_A_Init(); A_arbace_j2g_code__init_part2_A_Unit200__O(); A_arbace_j2g_code__init_part2_A_Unit201__O(); return nil }

























func A_arbace_j2g_code__init_part2_A_Unit201__O() any { A_arbace_j2g_code__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2349, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part2_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_code_method_ref_val_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_code_method_ref_val_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_505, false, nil); A_arbace_j2g_code_method_ref_val_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_code__init_part2_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part2_A_const_3)); return A_arbace_j2g_code__init_part2_A_const_2 }



type A_arbace_j2g_code__init_A struct{ jrt.Object }

func A_arbace_j2g_code__init_A_New() *A_arbace_j2g_code__init_A { t := &A_arbace_j2g_code__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_code__init_A) Ctor() {}

func (t *A_arbace_j2g_code__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_code__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_code__init_A_class }

func (t *A_arbace_j2g_code__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_code__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_code__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_code__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_code__init_A); return ok }

func A_arbace_j2g_code__init_A_Cast(x any) *A_arbace_j2g_code__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_code__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_code__init_A_class)) }; return v }



type A_arbace_j2g_code__init_part0_A struct{ jrt.Object }

var A_arbace_j2g_code__init_part0_A_const_pool *jrt.RefArray

var A_arbace_j2g_code__init_part0_A_const_0 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_1 any

var A_arbace_j2g_code__init_part0_A_const_2 any

var A_arbace_j2g_code__init_part0_A_const_3 any

var A_arbace_j2g_code__init_part0_A_const_4 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_5 any

var A_arbace_j2g_code__init_part0_A_const_6 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_7 any

var A_arbace_j2g_code__init_part0_A_const_8 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_9 any

var A_arbace_j2g_code__init_part0_A_const_10 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_11 any

var A_arbace_j2g_code__init_part0_A_const_12 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_13 any

var A_arbace_j2g_code__init_part0_A_const_14 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_15 any

var A_arbace_j2g_code__init_part0_A_const_16 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_17 any

var A_arbace_j2g_code__init_part0_A_const_18 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_19 any

var A_arbace_j2g_code__init_part0_A_const_20 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_21 any

var A_arbace_j2g_code__init_part0_A_const_22 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_23 any

var A_arbace_j2g_code__init_part0_A_const_24 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_25 any

var A_arbace_j2g_code__init_part0_A_const_26 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_27 any

var A_arbace_j2g_code__init_part0_A_const_28 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_29 any

var A_arbace_j2g_code__init_part0_A_const_30 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_31 any

var A_arbace_j2g_code__init_part0_A_const_32 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_33 any

var A_arbace_j2g_code__init_part0_A_const_34 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_35 any

var A_arbace_j2g_code__init_part0_A_const_36 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_37 any

var A_arbace_j2g_code__init_part0_A_const_38 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_39 any

var A_arbace_j2g_code__init_part0_A_const_40 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_41 any

var A_arbace_j2g_code__init_part0_A_const_42 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_43 any

var A_arbace_j2g_code__init_part0_A_const_44 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_45 any

var A_arbace_j2g_code__init_part0_A_const_46 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_47 any

var A_arbace_j2g_code__init_part0_A_const_48 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_49 any

var A_arbace_j2g_code__init_part0_A_const_50 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_51 any

var A_arbace_j2g_code__init_part0_A_const_52 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_53 any

var A_arbace_j2g_code__init_part0_A_const_54 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_55 any

var A_arbace_j2g_code__init_part0_A_const_56 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_57 any

var A_arbace_j2g_code__init_part0_A_const_58 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_59 any

var A_arbace_j2g_code__init_part0_A_const_60 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_61 any

var A_arbace_j2g_code__init_part0_A_const_62 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_63 any

var A_arbace_j2g_code__init_part0_A_const_64 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_65 any

var A_arbace_j2g_code__init_part0_A_const_66 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_67 any

var A_arbace_j2g_code__init_part0_A_const_68 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_69 any

var A_arbace_j2g_code__init_part0_A_const_70 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_71 any

var A_arbace_j2g_code__init_part0_A_const_72 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_73 any

var A_arbace_j2g_code__init_part0_A_const_74 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_75 any

var A_arbace_j2g_code__init_part0_A_const_76 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_77 any

var A_arbace_j2g_code__init_part0_A_const_78 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_79 any

var A_arbace_j2g_code__init_part0_A_const_80 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_81 any

var A_arbace_j2g_code__init_part0_A_const_82 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_83 any

var A_arbace_j2g_code__init_part0_A_const_84 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_85 any

var A_arbace_j2g_code__init_part0_A_const_86 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_87 any

var A_arbace_j2g_code__init_part0_A_const_88 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_89 any

var A_arbace_j2g_code__init_part0_A_const_90 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_91 any

var A_arbace_j2g_code__init_part0_A_const_92 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_93 any

var A_arbace_j2g_code__init_part0_A_const_94 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_95 any

var A_arbace_j2g_code__init_part0_A_const_96 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_97 any

var A_arbace_j2g_code__init_part0_A_const_98 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_99 any

var A_arbace_j2g_code__init_part0_A_const_100 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_101 any

var A_arbace_j2g_code__init_part0_A_const_102 any

var A_arbace_j2g_code__init_part0_A_const_103 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_104 any

var A_arbace_j2g_code__init_part0_A_const_105 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_106 any

var A_arbace_j2g_code__init_part0_A_const_107 any

var A_arbace_j2g_code__init_part0_A_const_108 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_109 any

var A_arbace_j2g_code__init_part0_A_const_110 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_111 any

var A_arbace_j2g_code__init_part0_A_const_112 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_113 any

var A_arbace_j2g_code__init_part0_A_const_114 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_115 any

var A_arbace_j2g_code__init_part0_A_const_116 any

var A_arbace_j2g_code__init_part0_A_const_117 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_118 any

var A_arbace_j2g_code__init_part0_A_const_119 any

var A_arbace_j2g_code__init_part0_A_const_120 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_121 any

var A_arbace_j2g_code__init_part0_A_const_122 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_123 any

var A_arbace_j2g_code__init_part0_A_const_124 any

var A_arbace_j2g_code__init_part0_A_const_125 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_126 any

var A_arbace_j2g_code__init_part0_A_const_127 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_128 any

var A_arbace_j2g_code__init_part0_A_const_129 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_130 any

var A_arbace_j2g_code__init_part0_A_const_131 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_132 any

var A_arbace_j2g_code__init_part0_A_const_133 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_134 any

var A_arbace_j2g_code__init_part0_A_const_135 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_136 any

var A_arbace_j2g_code__init_part0_A_const_137 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_138 any

var A_arbace_j2g_code__init_part0_A_const_139 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_140 any

var A_arbace_j2g_code__init_part0_A_const_141 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_142 any

var A_arbace_j2g_code__init_part0_A_const_143 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_144 any

var A_arbace_j2g_code__init_part0_A_const_145 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_146 any

var A_arbace_j2g_code__init_part0_A_const_147 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_148 any

var A_arbace_j2g_code__init_part0_A_const_149 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_150 any

var A_arbace_j2g_code__init_part0_A_const_151 any

var A_arbace_j2g_code__init_part0_A_const_152 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_153 any

var A_arbace_j2g_code__init_part0_A_const_154 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_155 any

var A_arbace_j2g_code__init_part0_A_const_156 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_157 any

var A_arbace_j2g_code__init_part0_A_const_158 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_159 any

var A_arbace_j2g_code__init_part0_A_const_160 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_161 any

var A_arbace_j2g_code__init_part0_A_const_162 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_163 any

var A_arbace_j2g_code__init_part0_A_const_164 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_165 any

var A_arbace_j2g_code__init_part0_A_const_166 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_167 any

var A_arbace_j2g_code__init_part0_A_const_168 any

var A_arbace_j2g_code__init_part0_A_const_169 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_170 any

var A_arbace_j2g_code__init_part0_A_const_171 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_172 any

var A_arbace_j2g_code__init_part0_A_const_173 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_174 any

var A_arbace_j2g_code__init_part0_A_const_175 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_176 any

var A_arbace_j2g_code__init_part0_A_const_177 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_178 any

var A_arbace_j2g_code__init_part0_A_const_179 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_180 any

var A_arbace_j2g_code__init_part0_A_const_181 any

var A_arbace_j2g_code__init_part0_A_const_182 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_183 any

var A_arbace_j2g_code__init_part0_A_const_184 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_185 any

var A_arbace_j2g_code__init_part0_A_const_186 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_187 any

var A_arbace_j2g_code__init_part0_A_const_188 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_189 any

var A_arbace_j2g_code__init_part0_A_const_190 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_191 any

var A_arbace_j2g_code__init_part0_A_const_192 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_193 any

var A_arbace_j2g_code__init_part0_A_init jrt.ClassInit

func A_arbace_j2g_code__init_part0_A_Init() { if !A_arbace_j2g_code__init_part0_A_init.Done() { A_arbace_j2g_code__init_part0_A_init.Run(A_arbace_j2g_code__init_part0_A_clinit) } }

func A_arbace_j2g_code__init_part0_A_clinit() { A_arbace_j2g_code__init_part0_A_clinit_p0(); A_arbace_j2g_code__init_part0_A_clinit_p1(); A_arbace_j2g_code__init_part0_A_clinit_p2(); A_arbace_j2g_code__init_part0_A_clinit_p3(); A_arbace_j2g_code__init_part0_A_clinit_p4(); A_arbace_j2g_code__init_part0_A_clinit_p5(); A_arbace_j2g_code__init_part0_A_clinit_p6(); A_arbace_j2g_code__init_part0_A_clinit_p7(); A_arbace_j2g_code__init_part0_A_clinit_p8(); A_arbace_j2g_code__init_part0_A_clinit_p9(); A_arbace_j2g_code__init_part0_A_clinit_p10(); A_arbace_j2g_code__init_part0_A_clinit_p11(); A_arbace_j2g_code__init_part0_A_clinit_p12(); A_arbace_j2g_code__init_part0_A_clinit_p13(); A_arbace_j2g_code__init_part0_A_clinit_p14() }

func A_arbace_j2g_code__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_code__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_355, 289); A_arbace_j2g_code__init_part0_A_const_0 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[95]); A_arbace_j2g_code__init_part0_A_const_1 = A_arbace_j2g_code__init_part0_A_const_pool.A[96]; A_arbace_j2g_code__init_part0_A_const_2 = A_arbace_j2g_code__init_part0_A_const_pool.A[97]; A_arbace_j2g_code__init_part0_A_const_3 = A_arbace_j2g_code__init_part0_A_const_pool.A[98]; A_arbace_j2g_code__init_part0_A_const_4 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[99]); A_arbace_j2g_code__init_part0_A_const_5 = A_arbace_j2g_code__init_part0_A_const_pool.A[100]; A_arbace_j2g_code__init_part0_A_const_6 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[101]); A_arbace_j2g_code__init_part0_A_const_7 = A_arbace_j2g_code__init_part0_A_const_pool.A[102]; A_arbace_j2g_code__init_part0_A_const_8 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[103]); A_arbace_j2g_code__init_part0_A_const_9 = A_arbace_j2g_code__init_part0_A_const_pool.A[104]; A_arbace_j2g_code__init_part0_A_const_10 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[105]); A_arbace_j2g_code__init_part0_A_const_11 = A_arbace_j2g_code__init_part0_A_const_pool.A[106]; A_arbace_j2g_code__init_part0_A_const_12 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[107]) }

func A_arbace_j2g_code__init_part0_A_clinit_p1() { A_arbace_j2g_code__init_part0_A_const_13 = A_arbace_j2g_code__init_part0_A_const_pool.A[108]; A_arbace_j2g_code__init_part0_A_const_14 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[109]); A_arbace_j2g_code__init_part0_A_const_15 = A_arbace_j2g_code__init_part0_A_const_pool.A[110]; A_arbace_j2g_code__init_part0_A_const_16 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[111]); A_arbace_j2g_code__init_part0_A_const_17 = A_arbace_j2g_code__init_part0_A_const_pool.A[112]; A_arbace_j2g_code__init_part0_A_const_18 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[113]); A_arbace_j2g_code__init_part0_A_const_19 = A_arbace_j2g_code__init_part0_A_const_pool.A[114]; A_arbace_j2g_code__init_part0_A_const_20 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[115]); A_arbace_j2g_code__init_part0_A_const_21 = A_arbace_j2g_code__init_part0_A_const_pool.A[116]; A_arbace_j2g_code__init_part0_A_const_22 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[117]); A_arbace_j2g_code__init_part0_A_const_23 = A_arbace_j2g_code__init_part0_A_const_pool.A[118]; A_arbace_j2g_code__init_part0_A_const_24 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[119]); A_arbace_j2g_code__init_part0_A_const_25 = A_arbace_j2g_code__init_part0_A_const_pool.A[120] }

func A_arbace_j2g_code__init_part0_A_clinit_p2() { A_arbace_j2g_code__init_part0_A_const_26 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[121]); A_arbace_j2g_code__init_part0_A_const_27 = A_arbace_j2g_code__init_part0_A_const_pool.A[122]; A_arbace_j2g_code__init_part0_A_const_28 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[123]); A_arbace_j2g_code__init_part0_A_const_29 = A_arbace_j2g_code__init_part0_A_const_pool.A[124]; A_arbace_j2g_code__init_part0_A_const_30 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[125]); A_arbace_j2g_code__init_part0_A_const_31 = A_arbace_j2g_code__init_part0_A_const_pool.A[126]; A_arbace_j2g_code__init_part0_A_const_32 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[127]); A_arbace_j2g_code__init_part0_A_const_33 = A_arbace_j2g_code__init_part0_A_const_pool.A[128]; A_arbace_j2g_code__init_part0_A_const_34 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[129]); A_arbace_j2g_code__init_part0_A_const_35 = A_arbace_j2g_code__init_part0_A_const_pool.A[130]; A_arbace_j2g_code__init_part0_A_const_36 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[131]); A_arbace_j2g_code__init_part0_A_const_37 = A_arbace_j2g_code__init_part0_A_const_pool.A[132]; A_arbace_j2g_code__init_part0_A_const_38 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[133]) }

func A_arbace_j2g_code__init_part0_A_clinit_p3() { A_arbace_j2g_code__init_part0_A_const_39 = A_arbace_j2g_code__init_part0_A_const_pool.A[134]; A_arbace_j2g_code__init_part0_A_const_40 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[135]); A_arbace_j2g_code__init_part0_A_const_41 = A_arbace_j2g_code__init_part0_A_const_pool.A[136]; A_arbace_j2g_code__init_part0_A_const_42 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[137]); A_arbace_j2g_code__init_part0_A_const_43 = A_arbace_j2g_code__init_part0_A_const_pool.A[138]; A_arbace_j2g_code__init_part0_A_const_44 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[139]); A_arbace_j2g_code__init_part0_A_const_45 = A_arbace_j2g_code__init_part0_A_const_pool.A[140]; A_arbace_j2g_code__init_part0_A_const_46 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[141]); A_arbace_j2g_code__init_part0_A_const_47 = A_arbace_j2g_code__init_part0_A_const_pool.A[142]; A_arbace_j2g_code__init_part0_A_const_48 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[143]); A_arbace_j2g_code__init_part0_A_const_49 = A_arbace_j2g_code__init_part0_A_const_pool.A[144]; A_arbace_j2g_code__init_part0_A_const_50 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[145]); A_arbace_j2g_code__init_part0_A_const_51 = A_arbace_j2g_code__init_part0_A_const_pool.A[146] }

func A_arbace_j2g_code__init_part0_A_clinit_p4() { A_arbace_j2g_code__init_part0_A_const_52 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[147]); A_arbace_j2g_code__init_part0_A_const_53 = A_arbace_j2g_code__init_part0_A_const_pool.A[148]; A_arbace_j2g_code__init_part0_A_const_54 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[149]); A_arbace_j2g_code__init_part0_A_const_55 = A_arbace_j2g_code__init_part0_A_const_pool.A[150]; A_arbace_j2g_code__init_part0_A_const_56 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[151]); A_arbace_j2g_code__init_part0_A_const_57 = A_arbace_j2g_code__init_part0_A_const_pool.A[152]; A_arbace_j2g_code__init_part0_A_const_58 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[153]); A_arbace_j2g_code__init_part0_A_const_59 = A_arbace_j2g_code__init_part0_A_const_pool.A[154]; A_arbace_j2g_code__init_part0_A_const_60 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[155]); A_arbace_j2g_code__init_part0_A_const_61 = A_arbace_j2g_code__init_part0_A_const_pool.A[156]; A_arbace_j2g_code__init_part0_A_const_62 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[157]); A_arbace_j2g_code__init_part0_A_const_63 = A_arbace_j2g_code__init_part0_A_const_pool.A[158]; A_arbace_j2g_code__init_part0_A_const_64 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[159]) }

func A_arbace_j2g_code__init_part0_A_clinit_p5() { A_arbace_j2g_code__init_part0_A_const_65 = A_arbace_j2g_code__init_part0_A_const_pool.A[160]; A_arbace_j2g_code__init_part0_A_const_66 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[161]); A_arbace_j2g_code__init_part0_A_const_67 = A_arbace_j2g_code__init_part0_A_const_pool.A[162]; A_arbace_j2g_code__init_part0_A_const_68 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[163]); A_arbace_j2g_code__init_part0_A_const_69 = A_arbace_j2g_code__init_part0_A_const_pool.A[164]; A_arbace_j2g_code__init_part0_A_const_70 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[165]); A_arbace_j2g_code__init_part0_A_const_71 = A_arbace_j2g_code__init_part0_A_const_pool.A[166]; A_arbace_j2g_code__init_part0_A_const_72 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[167]); A_arbace_j2g_code__init_part0_A_const_73 = A_arbace_j2g_code__init_part0_A_const_pool.A[168]; A_arbace_j2g_code__init_part0_A_const_74 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[169]); A_arbace_j2g_code__init_part0_A_const_75 = A_arbace_j2g_code__init_part0_A_const_pool.A[170]; A_arbace_j2g_code__init_part0_A_const_76 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[171]); A_arbace_j2g_code__init_part0_A_const_77 = A_arbace_j2g_code__init_part0_A_const_pool.A[172] }

func A_arbace_j2g_code__init_part0_A_clinit_p6() { A_arbace_j2g_code__init_part0_A_const_78 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[173]); A_arbace_j2g_code__init_part0_A_const_79 = A_arbace_j2g_code__init_part0_A_const_pool.A[174]; A_arbace_j2g_code__init_part0_A_const_80 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[175]); A_arbace_j2g_code__init_part0_A_const_81 = A_arbace_j2g_code__init_part0_A_const_pool.A[176]; A_arbace_j2g_code__init_part0_A_const_82 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[177]); A_arbace_j2g_code__init_part0_A_const_83 = A_arbace_j2g_code__init_part0_A_const_pool.A[178]; A_arbace_j2g_code__init_part0_A_const_84 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[179]); A_arbace_j2g_code__init_part0_A_const_85 = A_arbace_j2g_code__init_part0_A_const_pool.A[180]; A_arbace_j2g_code__init_part0_A_const_86 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[181]); A_arbace_j2g_code__init_part0_A_const_87 = A_arbace_j2g_code__init_part0_A_const_pool.A[182]; A_arbace_j2g_code__init_part0_A_const_88 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[183]); A_arbace_j2g_code__init_part0_A_const_89 = A_arbace_j2g_code__init_part0_A_const_pool.A[184]; A_arbace_j2g_code__init_part0_A_const_90 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[185]) }

func A_arbace_j2g_code__init_part0_A_clinit_p7() { A_arbace_j2g_code__init_part0_A_const_91 = A_arbace_j2g_code__init_part0_A_const_pool.A[186]; A_arbace_j2g_code__init_part0_A_const_92 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[187]); A_arbace_j2g_code__init_part0_A_const_93 = A_arbace_j2g_code__init_part0_A_const_pool.A[188]; A_arbace_j2g_code__init_part0_A_const_94 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[189]); A_arbace_j2g_code__init_part0_A_const_95 = A_arbace_j2g_code__init_part0_A_const_pool.A[190]; A_arbace_j2g_code__init_part0_A_const_96 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[191]); A_arbace_j2g_code__init_part0_A_const_97 = A_arbace_j2g_code__init_part0_A_const_pool.A[192]; A_arbace_j2g_code__init_part0_A_const_98 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[193]); A_arbace_j2g_code__init_part0_A_const_99 = A_arbace_j2g_code__init_part0_A_const_pool.A[194]; A_arbace_j2g_code__init_part0_A_const_100 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[195]); A_arbace_j2g_code__init_part0_A_const_101 = A_arbace_j2g_code__init_part0_A_const_pool.A[196]; A_arbace_j2g_code__init_part0_A_const_102 = A_arbace_j2g_code__init_part0_A_const_pool.A[197]; A_arbace_j2g_code__init_part0_A_const_103 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[198]); A_arbace_j2g_code__init_part0_A_const_104 = A_arbace_j2g_code__init_part0_A_const_pool.A[199] }

func A_arbace_j2g_code__init_part0_A_clinit_p8() { A_arbace_j2g_code__init_part0_A_const_105 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[200]); A_arbace_j2g_code__init_part0_A_const_106 = A_arbace_j2g_code__init_part0_A_const_pool.A[201]; A_arbace_j2g_code__init_part0_A_const_107 = A_arbace_j2g_code__init_part0_A_const_pool.A[202]; A_arbace_j2g_code__init_part0_A_const_108 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[203]); A_arbace_j2g_code__init_part0_A_const_109 = A_arbace_j2g_code__init_part0_A_const_pool.A[204]; A_arbace_j2g_code__init_part0_A_const_110 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[205]); A_arbace_j2g_code__init_part0_A_const_111 = A_arbace_j2g_code__init_part0_A_const_pool.A[206]; A_arbace_j2g_code__init_part0_A_const_112 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[207]); A_arbace_j2g_code__init_part0_A_const_113 = A_arbace_j2g_code__init_part0_A_const_pool.A[208]; A_arbace_j2g_code__init_part0_A_const_114 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[209]); A_arbace_j2g_code__init_part0_A_const_115 = A_arbace_j2g_code__init_part0_A_const_pool.A[210]; A_arbace_j2g_code__init_part0_A_const_116 = A_arbace_j2g_code__init_part0_A_const_pool.A[211]; A_arbace_j2g_code__init_part0_A_const_117 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[212]); A_arbace_j2g_code__init_part0_A_const_118 = A_arbace_j2g_code__init_part0_A_const_pool.A[213] }

func A_arbace_j2g_code__init_part0_A_clinit_p9() { A_arbace_j2g_code__init_part0_A_const_119 = A_arbace_j2g_code__init_part0_A_const_pool.A[214]; A_arbace_j2g_code__init_part0_A_const_120 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[215]); A_arbace_j2g_code__init_part0_A_const_121 = A_arbace_j2g_code__init_part0_A_const_pool.A[216]; A_arbace_j2g_code__init_part0_A_const_122 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[217]); A_arbace_j2g_code__init_part0_A_const_123 = A_arbace_j2g_code__init_part0_A_const_pool.A[218]; A_arbace_j2g_code__init_part0_A_const_124 = A_arbace_j2g_code__init_part0_A_const_pool.A[219]; A_arbace_j2g_code__init_part0_A_const_125 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[220]); A_arbace_j2g_code__init_part0_A_const_126 = A_arbace_j2g_code__init_part0_A_const_pool.A[221]; A_arbace_j2g_code__init_part0_A_const_127 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[222]); A_arbace_j2g_code__init_part0_A_const_128 = A_arbace_j2g_code__init_part0_A_const_pool.A[223]; A_arbace_j2g_code__init_part0_A_const_129 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[224]); A_arbace_j2g_code__init_part0_A_const_130 = A_arbace_j2g_code__init_part0_A_const_pool.A[225]; A_arbace_j2g_code__init_part0_A_const_131 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[226]); A_arbace_j2g_code__init_part0_A_const_132 = A_arbace_j2g_code__init_part0_A_const_pool.A[227] }

func A_arbace_j2g_code__init_part0_A_clinit_p10() { A_arbace_j2g_code__init_part0_A_const_133 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[228]); A_arbace_j2g_code__init_part0_A_const_134 = A_arbace_j2g_code__init_part0_A_const_pool.A[229]; A_arbace_j2g_code__init_part0_A_const_135 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[230]); A_arbace_j2g_code__init_part0_A_const_136 = A_arbace_j2g_code__init_part0_A_const_pool.A[231]; A_arbace_j2g_code__init_part0_A_const_137 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[232]); A_arbace_j2g_code__init_part0_A_const_138 = A_arbace_j2g_code__init_part0_A_const_pool.A[233]; A_arbace_j2g_code__init_part0_A_const_139 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[234]); A_arbace_j2g_code__init_part0_A_const_140 = A_arbace_j2g_code__init_part0_A_const_pool.A[235]; A_arbace_j2g_code__init_part0_A_const_141 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[236]); A_arbace_j2g_code__init_part0_A_const_142 = A_arbace_j2g_code__init_part0_A_const_pool.A[237]; A_arbace_j2g_code__init_part0_A_const_143 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[238]); A_arbace_j2g_code__init_part0_A_const_144 = A_arbace_j2g_code__init_part0_A_const_pool.A[239]; A_arbace_j2g_code__init_part0_A_const_145 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[240]) }

func A_arbace_j2g_code__init_part0_A_clinit_p11() { A_arbace_j2g_code__init_part0_A_const_146 = A_arbace_j2g_code__init_part0_A_const_pool.A[241]; A_arbace_j2g_code__init_part0_A_const_147 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[242]); A_arbace_j2g_code__init_part0_A_const_148 = A_arbace_j2g_code__init_part0_A_const_pool.A[243]; A_arbace_j2g_code__init_part0_A_const_149 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[244]); A_arbace_j2g_code__init_part0_A_const_150 = A_arbace_j2g_code__init_part0_A_const_pool.A[245]; A_arbace_j2g_code__init_part0_A_const_151 = A_arbace_j2g_code__init_part0_A_const_pool.A[246]; A_arbace_j2g_code__init_part0_A_const_152 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[247]); A_arbace_j2g_code__init_part0_A_const_153 = A_arbace_j2g_code__init_part0_A_const_pool.A[248]; A_arbace_j2g_code__init_part0_A_const_154 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[249]); A_arbace_j2g_code__init_part0_A_const_155 = A_arbace_j2g_code__init_part0_A_const_pool.A[250]; A_arbace_j2g_code__init_part0_A_const_156 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[251]); A_arbace_j2g_code__init_part0_A_const_157 = A_arbace_j2g_code__init_part0_A_const_pool.A[252]; A_arbace_j2g_code__init_part0_A_const_158 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[253]); A_arbace_j2g_code__init_part0_A_const_159 = A_arbace_j2g_code__init_part0_A_const_pool.A[254] }

func A_arbace_j2g_code__init_part0_A_clinit_p12() { A_arbace_j2g_code__init_part0_A_const_160 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[255]); A_arbace_j2g_code__init_part0_A_const_161 = A_arbace_j2g_code__init_part0_A_const_pool.A[256]; A_arbace_j2g_code__init_part0_A_const_162 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[257]); A_arbace_j2g_code__init_part0_A_const_163 = A_arbace_j2g_code__init_part0_A_const_pool.A[258]; A_arbace_j2g_code__init_part0_A_const_164 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[259]); A_arbace_j2g_code__init_part0_A_const_165 = A_arbace_j2g_code__init_part0_A_const_pool.A[260]; A_arbace_j2g_code__init_part0_A_const_166 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[261]); A_arbace_j2g_code__init_part0_A_const_167 = A_arbace_j2g_code__init_part0_A_const_pool.A[262]; A_arbace_j2g_code__init_part0_A_const_168 = A_arbace_j2g_code__init_part0_A_const_pool.A[263]; A_arbace_j2g_code__init_part0_A_const_169 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[264]); A_arbace_j2g_code__init_part0_A_const_170 = A_arbace_j2g_code__init_part0_A_const_pool.A[265]; A_arbace_j2g_code__init_part0_A_const_171 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[266]); A_arbace_j2g_code__init_part0_A_const_172 = A_arbace_j2g_code__init_part0_A_const_pool.A[267] }

func A_arbace_j2g_code__init_part0_A_clinit_p13() { A_arbace_j2g_code__init_part0_A_const_173 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[268]); A_arbace_j2g_code__init_part0_A_const_174 = A_arbace_j2g_code__init_part0_A_const_pool.A[269]; A_arbace_j2g_code__init_part0_A_const_175 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[270]); A_arbace_j2g_code__init_part0_A_const_176 = A_arbace_j2g_code__init_part0_A_const_pool.A[271]; A_arbace_j2g_code__init_part0_A_const_177 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[272]); A_arbace_j2g_code__init_part0_A_const_178 = A_arbace_j2g_code__init_part0_A_const_pool.A[273]; A_arbace_j2g_code__init_part0_A_const_179 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[274]); A_arbace_j2g_code__init_part0_A_const_180 = A_arbace_j2g_code__init_part0_A_const_pool.A[275]; A_arbace_j2g_code__init_part0_A_const_181 = A_arbace_j2g_code__init_part0_A_const_pool.A[276]; A_arbace_j2g_code__init_part0_A_const_182 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[277]); A_arbace_j2g_code__init_part0_A_const_183 = A_arbace_j2g_code__init_part0_A_const_pool.A[278]; A_arbace_j2g_code__init_part0_A_const_184 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[279]); A_arbace_j2g_code__init_part0_A_const_185 = A_arbace_j2g_code__init_part0_A_const_pool.A[280] }

func A_arbace_j2g_code__init_part0_A_clinit_p14() { A_arbace_j2g_code__init_part0_A_const_186 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[281]); A_arbace_j2g_code__init_part0_A_const_187 = A_arbace_j2g_code__init_part0_A_const_pool.A[282]; A_arbace_j2g_code__init_part0_A_const_188 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[283]); A_arbace_j2g_code__init_part0_A_const_189 = A_arbace_j2g_code__init_part0_A_const_pool.A[284]; A_arbace_j2g_code__init_part0_A_const_190 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[285]); A_arbace_j2g_code__init_part0_A_const_191 = A_arbace_j2g_code__init_part0_A_const_pool.A[286]; A_arbace_j2g_code__init_part0_A_const_192 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[287]); A_arbace_j2g_code__init_part0_A_const_193 = A_arbace_j2g_code__init_part0_A_const_pool.A[288] }

func A_arbace_j2g_code__init_part0_A_New() *A_arbace_j2g_code__init_part0_A { A_arbace_j2g_code__init_part0_A_Init(); t := &A_arbace_j2g_code__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_code__init_part0_A) Ctor() {}

func (t *A_arbace_j2g_code__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_code__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_code__init_part0_A_class }

func (t *A_arbace_j2g_code__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_code__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_code__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_code__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_code__init_part0_A); return ok }

func A_arbace_j2g_code__init_part0_A_Cast(x any) *A_arbace_j2g_code__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_code__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_code__init_part0_A_class)) }; return v }



type A_arbace_j2g_code__init_part1_A struct{ jrt.Object }

var A_arbace_j2g_code__init_part1_A_const_pool *jrt.RefArray

var A_arbace_j2g_code__init_part1_A_const_0 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_1 any

var A_arbace_j2g_code__init_part1_A_const_2 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_3 any

var A_arbace_j2g_code__init_part1_A_const_4 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_5 any

var A_arbace_j2g_code__init_part1_A_const_6 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_7 any

var A_arbace_j2g_code__init_part1_A_const_8 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_9 any

var A_arbace_j2g_code__init_part1_A_const_10 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_11 any

var A_arbace_j2g_code__init_part1_A_const_12 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_13 any

var A_arbace_j2g_code__init_part1_A_const_14 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_15 any

var A_arbace_j2g_code__init_part1_A_const_16 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_17 any

var A_arbace_j2g_code__init_part1_A_const_18 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_19 any

var A_arbace_j2g_code__init_part1_A_const_20 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_21 any

var A_arbace_j2g_code__init_part1_A_const_22 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_23 any

var A_arbace_j2g_code__init_part1_A_const_24 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_25 any

var A_arbace_j2g_code__init_part1_A_const_26 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_27 any

var A_arbace_j2g_code__init_part1_A_const_28 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_29 any

var A_arbace_j2g_code__init_part1_A_const_30 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_31 any

var A_arbace_j2g_code__init_part1_A_const_32 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_33 any

var A_arbace_j2g_code__init_part1_A_const_34 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_35 any

var A_arbace_j2g_code__init_part1_A_const_36 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_37 any

var A_arbace_j2g_code__init_part1_A_const_38 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_39 any

var A_arbace_j2g_code__init_part1_A_const_40 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_41 any

var A_arbace_j2g_code__init_part1_A_const_42 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_43 any

var A_arbace_j2g_code__init_part1_A_const_44 any

var A_arbace_j2g_code__init_part1_A_const_45 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_46 any

var A_arbace_j2g_code__init_part1_A_const_47 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_48 any

var A_arbace_j2g_code__init_part1_A_const_49 any

var A_arbace_j2g_code__init_part1_A_const_50 any

var A_arbace_j2g_code__init_part1_A_const_51 any

var A_arbace_j2g_code__init_part1_A_const_52 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_53 any

var A_arbace_j2g_code__init_part1_A_const_54 any

var A_arbace_j2g_code__init_part1_A_const_55 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_56 any

var A_arbace_j2g_code__init_part1_A_const_57 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_58 any

var A_arbace_j2g_code__init_part1_A_const_59 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_60 any

var A_arbace_j2g_code__init_part1_A_const_61 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_62 any

var A_arbace_j2g_code__init_part1_A_const_63 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_64 any

var A_arbace_j2g_code__init_part1_A_const_65 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_66 any

var A_arbace_j2g_code__init_part1_A_const_67 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_68 any

var A_arbace_j2g_code__init_part1_A_const_69 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_70 any

var A_arbace_j2g_code__init_part1_A_const_71 any

var A_arbace_j2g_code__init_part1_A_const_72 any

var A_arbace_j2g_code__init_part1_A_const_73 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_74 any

var A_arbace_j2g_code__init_part1_A_const_75 any

var A_arbace_j2g_code__init_part1_A_const_76 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_77 any

var A_arbace_j2g_code__init_part1_A_const_78 any

var A_arbace_j2g_code__init_part1_A_const_79 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_80 any

var A_arbace_j2g_code__init_part1_A_const_81 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_82 any

var A_arbace_j2g_code__init_part1_A_const_83 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_84 any

var A_arbace_j2g_code__init_part1_A_const_85 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_86 any

var A_arbace_j2g_code__init_part1_A_const_87 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_88 any

var A_arbace_j2g_code__init_part1_A_const_89 any

var A_arbace_j2g_code__init_part1_A_const_90 any

var A_arbace_j2g_code__init_part1_A_const_91 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_92 any

var A_arbace_j2g_code__init_part1_A_const_93 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_94 any

var A_arbace_j2g_code__init_part1_A_const_95 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_96 any

var A_arbace_j2g_code__init_part1_A_const_97 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_98 any

var A_arbace_j2g_code__init_part1_A_const_99 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_100 any

var A_arbace_j2g_code__init_part1_A_const_101 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_102 any

var A_arbace_j2g_code__init_part1_A_const_103 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_104 any

var A_arbace_j2g_code__init_part1_A_const_105 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_106 any

var A_arbace_j2g_code__init_part1_A_const_107 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_108 any

var A_arbace_j2g_code__init_part1_A_const_109 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_110 any

var A_arbace_j2g_code__init_part1_A_const_111 any

var A_arbace_j2g_code__init_part1_A_const_112 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_113 any

var A_arbace_j2g_code__init_part1_A_const_114 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_115 any

var A_arbace_j2g_code__init_part1_A_const_116 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_117 any

var A_arbace_j2g_code__init_part1_A_const_118 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_119 any

var A_arbace_j2g_code__init_part1_A_const_120 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_121 any

var A_arbace_j2g_code__init_part1_A_const_122 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_123 any

var A_arbace_j2g_code__init_part1_A_const_124 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_125 any

var A_arbace_j2g_code__init_part1_A_const_126 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_127 any

var A_arbace_j2g_code__init_part1_A_const_128 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_129 any

var A_arbace_j2g_code__init_part1_A_const_130 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_131 any

var A_arbace_j2g_code__init_part1_A_const_132 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_133 any

var A_arbace_j2g_code__init_part1_A_const_134 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_135 any

var A_arbace_j2g_code__init_part1_A_const_136 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_137 any

var A_arbace_j2g_code__init_part1_A_const_138 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_139 any

var A_arbace_j2g_code__init_part1_A_const_140 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_141 any

var A_arbace_j2g_code__init_part1_A_const_142 any

var A_arbace_j2g_code__init_part1_A_const_143 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_144 any

var A_arbace_j2g_code__init_part1_A_const_145 any

var A_arbace_j2g_code__init_part1_A_const_146 any

var A_arbace_j2g_code__init_part1_A_const_147 any

var A_arbace_j2g_code__init_part1_A_const_148 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_149 any

var A_arbace_j2g_code__init_part1_A_const_150 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_151 any

var A_arbace_j2g_code__init_part1_A_const_152 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_153 any

var A_arbace_j2g_code__init_part1_A_const_154 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_155 any

var A_arbace_j2g_code__init_part1_A_const_156 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_157 any

var A_arbace_j2g_code__init_part1_A_const_158 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_159 any

var A_arbace_j2g_code__init_part1_A_const_160 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_161 any

var A_arbace_j2g_code__init_part1_A_const_162 any

var A_arbace_j2g_code__init_part1_A_const_163 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_164 any

var A_arbace_j2g_code__init_part1_A_const_165 any

var A_arbace_j2g_code__init_part1_A_const_166 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_167 any

var A_arbace_j2g_code__init_part1_A_const_168 any

var A_arbace_j2g_code__init_part1_A_const_169 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_170 any

var A_arbace_j2g_code__init_part1_A_const_171 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_172 any

var A_arbace_j2g_code__init_part1_A_const_173 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_174 any

var A_arbace_j2g_code__init_part1_A_const_175 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_176 any

var A_arbace_j2g_code__init_part1_A_const_177 any

var A_arbace_j2g_code__init_part1_A_const_178 any

var A_arbace_j2g_code__init_part1_A_const_179 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_180 any

var A_arbace_j2g_code__init_part1_A_const_181 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_182 any

var A_arbace_j2g_code__init_part1_A_const_183 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_184 any

var A_arbace_j2g_code__init_part1_A_const_185 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_186 any

var A_arbace_j2g_code__init_part1_A_const_187 any

var A_arbace_j2g_code__init_part1_A_init jrt.ClassInit

func A_arbace_j2g_code__init_part1_A_Init() { if !A_arbace_j2g_code__init_part1_A_init.Done() { A_arbace_j2g_code__init_part1_A_init.Run(A_arbace_j2g_code__init_part1_A_clinit) } }

func A_arbace_j2g_code__init_part1_A_clinit() { A_arbace_j2g_code__init_part1_A_clinit_p0(); A_arbace_j2g_code__init_part1_A_clinit_p1(); A_arbace_j2g_code__init_part1_A_clinit_p2(); A_arbace_j2g_code__init_part1_A_clinit_p3() }

func A_arbace_j2g_code__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_code__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_427, 268); A_arbace_j2g_code__init_part1_A_const_0 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[93]); A_arbace_j2g_code__init_part1_A_const_1 = A_arbace_j2g_code__init_part1_A_const_pool.A[94]; A_arbace_j2g_code__init_part1_A_const_2 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[95]); A_arbace_j2g_code__init_part1_A_const_3 = A_arbace_j2g_code__init_part1_A_const_pool.A[96]; A_arbace_j2g_code__init_part1_A_const_4 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[97]); A_arbace_j2g_code__init_part1_A_const_5 = A_arbace_j2g_code__init_part1_A_const_pool.A[98]; A_arbace_j2g_code__init_part1_A_const_6 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[99]); A_arbace_j2g_code__init_part1_A_const_7 = A_arbace_j2g_code__init_part1_A_const_pool.A[100]; A_arbace_j2g_code__init_part1_A_const_8 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[101]); A_arbace_j2g_code__init_part1_A_const_9 = A_arbace_j2g_code__init_part1_A_const_pool.A[102]; A_arbace_j2g_code__init_part1_A_const_10 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[103]); A_arbace_j2g_code__init_part1_A_const_11 = A_arbace_j2g_code__init_part1_A_const_pool.A[104] }

func A_arbace_j2g_code__init_part1_A_clinit_p1() { A_arbace_j2g_code__init_part1_A_const_12 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[105]); A_arbace_j2g_code__init_part1_A_const_13 = A_arbace_j2g_code__init_part1_A_const_pool.A[106]; A_arbace_j2g_code__init_part1_A_const_14 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[107]); A_arbace_j2g_code__init_part1_A_const_15 = A_arbace_j2g_code__init_part1_A_const_pool.A[108]; A_arbace_j2g_code__init_part1_A_const_16 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[109]); A_arbace_j2g_code__init_part1_A_const_17 = A_arbace_j2g_code__init_part1_A_const_pool.A[110]; A_arbace_j2g_code__init_part1_A_const_18 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[111]); A_arbace_j2g_code__init_part1_A_const_19 = A_arbace_j2g_code__init_part1_A_const_pool.A[112]; A_arbace_j2g_code__init_part1_A_const_20 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[113]); A_arbace_j2g_code__init_part1_A_const_21 = A_arbace_j2g_code__init_part1_A_const_pool.A[114]; A_arbace_j2g_code__init_part1_A_const_22 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[115]); A_arbace_j2g_code__init_part1_A_const_23 = A_arbace_j2g_code__init_part1_A_const_pool.A[116]; A_arbace_j2g_code__init_part1_A_const_24 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[117]) }

func A_arbace_j2g_code__init_part1_A_clinit_p2() { A_arbace_j2g_code__init_part1_A_const_25 = A_arbace_j2g_code__init_part1_A_const_pool.A[118]; A_arbace_j2g_code__init_part1_A_const_26 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[119]); A_arbace_j2g_code__init_part1_A_const_27 = A_arbace_j2g_code__init_part1_A_const_pool.A[120]; A_arbace_j2g_code__init_part1_A_const_28 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[121]); A_arbace_j2g_code__init_part1_A_const_29 = A_arbace_j2g_code__init_part1_A_const_pool.A[122]; A_arbace_j2g_code__init_part1_A_const_30 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[123]); A_arbace_j2g_code__init_part1_A_const_31 = A_arbace_j2g_code__init_part1_A_const_pool.A[124] }

func A_arbace_j2g_code__init_part1_A_clinit_p3() { var tmp1 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp1 = A_arbace_j2g_code__init_part0_A_const_66; A_arbace_j2g_code__init_part1_A_const_32 = tmp1; A_arbace_j2g_code__init_part1_A_const_33 = A_arbace_j2g_code__init_part1_A_const_pool.A[125]; var tmp2 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp2 = A_arbace_j2g_code__init_part0_A_const_68; A_arbace_j2g_code__init_part1_A_const_34 = tmp2; A_arbace_j2g_code__init_part1_A_const_35 = A_arbace_j2g_code__init_part1_A_const_pool.A[126]; var tmp3 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp3 = A_arbace_j2g_code__init_part0_A_const_70; A_arbace_j2g_code__init_part1_A_const_36 = tmp3; A_arbace_j2g_code__init_part1_A_const_37 = A_arbace_j2g_code__init_part1_A_const_pool.A[127]; var tmp4 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp4 = A_arbace_j2g_code__init_part0_A_const_78; A_arbace_j2g_code__init_part1_A_const_38 = tmp4; A_arbace_j2g_code__init_part1_A_const_39 = A_arbace_j2g_code__init_part1_A_const_pool.A[128]; A_arbace_j2g_code__init_part1_A_const_40 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[129]); A_arbace_j2g_code__init_part1_A_const_41 = A_arbace_j2g_code__init_part1_A_const_pool.A[130]; A_arbace_j2g_code__init_part1_A_const_42 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[131]); A_arbace_j2g_code__init_part1_A_const_43 = A_arbace_j2g_code__init_part1_A_const_pool.A[132]; A_arbace_j2g_code__init_part1_A_const_44 = A_arbace_j2g_code__init_part1_A_const_pool.A[133]; var tmp5 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp5 = A_arbace_j2g_code__init_part0_A_const_90; A_arbace_j2g_code__init_part1_A_const_45 = tmp5; A_arbace_j2g_code__init_part1_A_const_46 = A_arbace_j2g_code__init_part1_A_const_pool.A[134]; var tmp6 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp6 = A_arbace_j2g_code__init_part0_A_const_88; A_arbace_j2g_code__init_part1_A_const_47 = tmp6; A_arbace_j2g_code__init_part1_A_const_48 = A_arbace_j2g_code__init_part1_A_const_pool.A[135]; A_arbace_j2g_code__init_part1_A_const_49 = A_arbace_j2g_code__init_part1_A_const_pool.A[136]; A_arbace_j2g_code__init_part1_A_const_50 = A_arbace_j2g_code__init_part1_A_const_pool.A[137]; A_arbace_j2g_code__init_part1_A_const_51 = A_arbace_j2g_code__init_part1_A_const_pool.A[138]; A_arbace_j2g_code__init_part1_A_const_52 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[139]); A_arbace_j2g_code__init_part1_A_const_53 = A_arbace_j2g_code__init_part1_A_const_pool.A[140]; A_arbace_j2g_code__init_part1_A_const_54 = A_arbace_j2g_code__init_part1_A_const_pool.A[141]; A_arbace_j2g_code__init_part1_A_const_55 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[142]); A_arbace_j2g_code__init_part1_A_const_56 = A_arbace_j2g_code__init_part1_A_const_pool.A[143]; A_arbace_j2g_code__init_part1_A_const_57 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[144]); A_arbace_j2g_code__init_part1_A_const_58 = A_arbace_j2g_code__init_part1_A_const_pool.A[145]; A_arbace_j2g_code__init_part1_A_const_59 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[146]); A_arbace_j2g_code__init_part1_A_const_60 = A_arbace_j2g_code__init_part1_A_const_pool.A[147]; A_arbace_j2g_code__init_part1_A_const_61 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[148]); A_arbace_j2g_code__init_part1_A_const_62 = A_arbace_j2g_code__init_part1_A_const_pool.A[149]; A_arbace_j2g_code__init_part1_A_const_63 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[150]); A_arbace_j2g_code__init_part1_A_const_64 = A_arbace_j2g_code__init_part1_A_const_pool.A[151]; A_arbace_j2g_code__init_part1_A_const_65 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[152]); A_arbace_j2g_code__init_part1_A_const_66 = A_arbace_j2g_code__init_part1_A_const_pool.A[153]; A_arbace_j2g_code__init_part1_A_const_67 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[154]); A_arbace_j2g_code__init_part1_A_const_68 = A_arbace_j2g_code__init_part1_A_const_pool.A[155]; A_arbace_j2g_code__init_part1_A_const_69 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[156]); A_arbace_j2g_code__init_part1_A_const_70 = A_arbace_j2g_code__init_part1_A_const_pool.A[157]; A_arbace_j2g_code__init_part1_A_const_71 = A_arbace_j2g_code__init_part1_A_const_pool.A[158]; A_arbace_j2g_code__init_part1_A_const_72 = A_arbace_j2g_code__init_part1_A_const_pool.A[159]; A_arbace_j2g_code__init_part1_A_const_73 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[160]); A_arbace_j2g_code__init_part1_A_const_74 = A_arbace_j2g_code__init_part1_A_const_pool.A[161]; A_arbace_j2g_code__init_part1_A_const_75 = A_arbace_j2g_code__init_part1_A_const_pool.A[162]; A_arbace_j2g_code__init_part1_A_const_76 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[163]); A_arbace_j2g_code__init_part1_A_const_77 = A_arbace_j2g_code__init_part1_A_const_pool.A[164]; A_arbace_j2g_code__init_part1_A_const_78 = A_arbace_j2g_code__init_part1_A_const_pool.A[165]; A_arbace_j2g_code__init_part1_A_const_79 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[166]); A_arbace_j2g_code__init_part1_A_const_80 = A_arbace_j2g_code__init_part1_A_const_pool.A[167]; A_arbace_j2g_code__init_part1_A_const_81 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[168]); A_arbace_j2g_code__init_part1_A_const_82 = A_arbace_j2g_code__init_part1_A_const_pool.A[169]; A_arbace_j2g_code__init_part1_A_const_83 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[170]); A_arbace_j2g_code__init_part1_A_const_84 = A_arbace_j2g_code__init_part1_A_const_pool.A[171]; A_arbace_j2g_code__init_part1_A_const_85 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[172]); A_arbace_j2g_code__init_part1_A_const_86 = A_arbace_j2g_code__init_part1_A_const_pool.A[173]; A_arbace_j2g_code__init_part1_A_const_87 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[174]); A_arbace_j2g_code__init_part1_A_const_88 = A_arbace_j2g_code__init_part1_A_const_pool.A[175]; A_arbace_j2g_code__init_part1_A_const_89 = A_arbace_j2g_code__init_part1_A_const_pool.A[176]; A_arbace_j2g_code__init_part1_A_const_90 = A_arbace_j2g_code__init_part1_A_const_pool.A[177]; A_arbace_j2g_code__init_part1_A_const_91 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[178]); A_arbace_j2g_code__init_part1_A_const_92 = A_arbace_j2g_code__init_part1_A_const_pool.A[179]; A_arbace_j2g_code__init_part1_A_const_93 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[180]); A_arbace_j2g_code__init_part1_A_const_94 = A_arbace_j2g_code__init_part1_A_const_pool.A[181]; A_arbace_j2g_code__init_part1_A_const_95 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[182]); A_arbace_j2g_code__init_part1_A_const_96 = A_arbace_j2g_code__init_part1_A_const_pool.A[183]; A_arbace_j2g_code__init_part1_A_const_97 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[184]); A_arbace_j2g_code__init_part1_A_const_98 = A_arbace_j2g_code__init_part1_A_const_pool.A[185]; A_arbace_j2g_code__init_part1_A_const_99 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[186]); A_arbace_j2g_code__init_part1_A_const_100 = A_arbace_j2g_code__init_part1_A_const_pool.A[187]; A_arbace_j2g_code__init_part1_A_const_101 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[188]); A_arbace_j2g_code__init_part1_A_const_102 = A_arbace_j2g_code__init_part1_A_const_pool.A[189]; A_arbace_j2g_code__init_part1_A_const_103 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[190]); A_arbace_j2g_code__init_part1_A_const_104 = A_arbace_j2g_code__init_part1_A_const_pool.A[191]; var tmp7 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp7 = A_arbace_j2g_code__init_part0_A_const_72; A_arbace_j2g_code__init_part1_A_const_105 = tmp7; A_arbace_j2g_code__init_part1_A_const_106 = A_arbace_j2g_code__init_part1_A_const_pool.A[192]; var tmp8 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp8 = A_arbace_j2g_code__init_part0_A_const_62; A_arbace_j2g_code__init_part1_A_const_107 = tmp8; A_arbace_j2g_code__init_part1_A_const_108 = A_arbace_j2g_code__init_part1_A_const_pool.A[193]; A_arbace_j2g_code__init_part1_A_const_109 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[194]); A_arbace_j2g_code__init_part1_A_const_110 = A_arbace_j2g_code__init_part1_A_const_pool.A[195]; A_arbace_j2g_code__init_part1_A_const_111 = A_arbace_j2g_code__init_part1_A_const_pool.A[196]; var tmp9 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp9 = A_arbace_j2g_code__init_part0_A_const_86; A_arbace_j2g_code__init_part1_A_const_112 = tmp9; A_arbace_j2g_code__init_part1_A_const_113 = A_arbace_j2g_code__init_part1_A_const_pool.A[197]; A_arbace_j2g_code__init_part1_A_const_114 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[198]); A_arbace_j2g_code__init_part1_A_const_115 = A_arbace_j2g_code__init_part1_A_const_pool.A[199]; var tmp10 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp10 = A_arbace_j2g_code__init_part0_A_const_74; A_arbace_j2g_code__init_part1_A_const_116 = tmp10; A_arbace_j2g_code__init_part1_A_const_117 = A_arbace_j2g_code__init_part1_A_const_pool.A[200]; var tmp11 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp11 = A_arbace_j2g_code__init_part0_A_const_76; A_arbace_j2g_code__init_part1_A_const_118 = tmp11; A_arbace_j2g_code__init_part1_A_const_119 = A_arbace_j2g_code__init_part1_A_const_pool.A[201]; A_arbace_j2g_code__init_part1_A_const_120 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[202]); A_arbace_j2g_code__init_part1_A_const_121 = A_arbace_j2g_code__init_part1_A_const_pool.A[203]; A_arbace_j2g_code__init_part1_A_const_122 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[204]); A_arbace_j2g_code__init_part1_A_const_123 = A_arbace_j2g_code__init_part1_A_const_pool.A[205]; A_arbace_j2g_code__init_part1_A_const_124 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[206]); A_arbace_j2g_code__init_part1_A_const_125 = A_arbace_j2g_code__init_part1_A_const_pool.A[207]; A_arbace_j2g_code__init_part1_A_const_126 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[208]); A_arbace_j2g_code__init_part1_A_const_127 = A_arbace_j2g_code__init_part1_A_const_pool.A[209]; A_arbace_j2g_code__init_part1_A_const_128 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[210]); A_arbace_j2g_code__init_part1_A_const_129 = A_arbace_j2g_code__init_part1_A_const_pool.A[211]; A_arbace_j2g_code__init_part1_A_const_130 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[212]); A_arbace_j2g_code__init_part1_A_const_131 = A_arbace_j2g_code__init_part1_A_const_pool.A[213]; A_arbace_j2g_code__init_part1_A_const_132 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[214]); A_arbace_j2g_code__init_part1_A_const_133 = A_arbace_j2g_code__init_part1_A_const_pool.A[215]; A_arbace_j2g_code__init_part1_A_const_134 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[216]); A_arbace_j2g_code__init_part1_A_const_135 = A_arbace_j2g_code__init_part1_A_const_pool.A[217]; A_arbace_j2g_code__init_part1_A_const_136 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[218]); A_arbace_j2g_code__init_part1_A_const_137 = A_arbace_j2g_code__init_part1_A_const_pool.A[219]; var tmp12 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp12 = A_arbace_j2g_code__init_part0_A_const_80; A_arbace_j2g_code__init_part1_A_const_138 = tmp12; A_arbace_j2g_code__init_part1_A_const_139 = A_arbace_j2g_code__init_part1_A_const_pool.A[220]; var tmp13 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp13 = A_arbace_j2g_code__init_part0_A_const_64; A_arbace_j2g_code__init_part1_A_const_140 = tmp13; A_arbace_j2g_code__init_part1_A_const_141 = A_arbace_j2g_code__init_part1_A_const_pool.A[221]; A_arbace_j2g_code__init_part1_A_const_142 = A_arbace_j2g_code__init_part1_A_const_pool.A[222]; A_arbace_j2g_code__init_part1_A_const_143 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[223]); A_arbace_j2g_code__init_part1_A_const_144 = A_arbace_j2g_code__init_part1_A_const_pool.A[224]; A_arbace_j2g_code__init_part1_A_const_145 = A_arbace_j2g_code__init_part1_A_const_pool.A[225]; A_arbace_j2g_code__init_part1_A_const_146 = A_arbace_j2g_code__init_part1_A_const_pool.A[226]; A_arbace_j2g_code__init_part1_A_const_147 = A_arbace_j2g_code__init_part1_A_const_pool.A[227]; A_arbace_j2g_code__init_part1_A_const_148 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[228]); A_arbace_j2g_code__init_part1_A_const_149 = A_arbace_j2g_code__init_part1_A_const_pool.A[229]; A_arbace_j2g_code__init_part1_A_const_150 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[230]); A_arbace_j2g_code__init_part1_A_const_151 = A_arbace_j2g_code__init_part1_A_const_pool.A[231]; A_arbace_j2g_code__init_part1_A_const_152 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[232]); A_arbace_j2g_code__init_part1_A_const_153 = A_arbace_j2g_code__init_part1_A_const_pool.A[233]; A_arbace_j2g_code__init_part1_A_const_154 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[234]); A_arbace_j2g_code__init_part1_A_const_155 = A_arbace_j2g_code__init_part1_A_const_pool.A[235]; A_arbace_j2g_code__init_part1_A_const_156 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[236]); A_arbace_j2g_code__init_part1_A_const_157 = A_arbace_j2g_code__init_part1_A_const_pool.A[237]; A_arbace_j2g_code__init_part1_A_const_158 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[238]); A_arbace_j2g_code__init_part1_A_const_159 = A_arbace_j2g_code__init_part1_A_const_pool.A[239]; A_arbace_j2g_code__init_part1_A_const_160 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[240]); A_arbace_j2g_code__init_part1_A_const_161 = A_arbace_j2g_code__init_part1_A_const_pool.A[241]; A_arbace_j2g_code__init_part1_A_const_162 = A_arbace_j2g_code__init_part1_A_const_pool.A[242]; A_arbace_j2g_code__init_part1_A_const_163 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[243]); A_arbace_j2g_code__init_part1_A_const_164 = A_arbace_j2g_code__init_part1_A_const_pool.A[244]; A_arbace_j2g_code__init_part1_A_const_165 = A_arbace_j2g_code__init_part1_A_const_pool.A[245]; A_arbace_j2g_code__init_part1_A_const_166 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[246]); A_arbace_j2g_code__init_part1_A_const_167 = A_arbace_j2g_code__init_part1_A_const_pool.A[247]; A_arbace_j2g_code__init_part1_A_const_168 = A_arbace_j2g_code__init_part1_A_const_pool.A[248]; A_arbace_j2g_code__init_part1_A_const_169 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[249]); A_arbace_j2g_code__init_part1_A_const_170 = A_arbace_j2g_code__init_part1_A_const_pool.A[250]; A_arbace_j2g_code__init_part1_A_const_171 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[251]); A_arbace_j2g_code__init_part1_A_const_172 = A_arbace_j2g_code__init_part1_A_const_pool.A[252]; A_arbace_j2g_code__init_part1_A_const_173 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[253]); A_arbace_j2g_code__init_part1_A_const_174 = A_arbace_j2g_code__init_part1_A_const_pool.A[254]; A_arbace_j2g_code__init_part1_A_const_175 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[255]); A_arbace_j2g_code__init_part1_A_const_176 = A_arbace_j2g_code__init_part1_A_const_pool.A[256]; A_arbace_j2g_code__init_part1_A_const_177 = A_arbace_j2g_code__init_part1_A_const_pool.A[257]; A_arbace_j2g_code__init_part1_A_const_178 = A_arbace_j2g_code__init_part1_A_const_pool.A[258]; A_arbace_j2g_code__init_part1_A_const_179 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[259]); A_arbace_j2g_code__init_part1_A_const_180 = A_arbace_j2g_code__init_part1_A_const_pool.A[260]; A_arbace_j2g_code__init_part1_A_const_181 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[261]); A_arbace_j2g_code__init_part1_A_const_182 = A_arbace_j2g_code__init_part1_A_const_pool.A[262]; A_arbace_j2g_code__init_part1_A_const_183 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[263]); A_arbace_j2g_code__init_part1_A_const_184 = A_arbace_j2g_code__init_part1_A_const_pool.A[264]; A_arbace_j2g_code__init_part1_A_const_185 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[265]); A_arbace_j2g_code__init_part1_A_const_186 = A_arbace_j2g_code__init_part1_A_const_pool.A[266]; A_arbace_j2g_code__init_part1_A_const_187 = A_arbace_j2g_code__init_part1_A_const_pool.A[267] }

func A_arbace_j2g_code__init_part1_A_New() *A_arbace_j2g_code__init_part1_A { A_arbace_j2g_code__init_part1_A_Init(); t := &A_arbace_j2g_code__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_code__init_part1_A) Ctor() {}

func (t *A_arbace_j2g_code__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_code__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_code__init_part1_A_class }

func (t *A_arbace_j2g_code__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_code__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_code__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_code__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_code__init_part1_A); return ok }

func A_arbace_j2g_code__init_part1_A_Cast(x any) *A_arbace_j2g_code__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_code__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_code__init_part1_A_class)) }; return v }



type A_arbace_j2g_code__init_part2_A struct{ jrt.Object }

var A_arbace_j2g_code__init_part2_A_const_pool *jrt.RefArray

var A_arbace_j2g_code__init_part2_A_const_0 *lang.Var

var A_arbace_j2g_code__init_part2_A_const_1 any

var A_arbace_j2g_code__init_part2_A_const_2 *lang.Var

var A_arbace_j2g_code__init_part2_A_const_3 any

var A_arbace_j2g_code__init_part2_A_init jrt.ClassInit

func A_arbace_j2g_code__init_part2_A_Init() { if !A_arbace_j2g_code__init_part2_A_init.Done() { A_arbace_j2g_code__init_part2_A_init.Run(A_arbace_j2g_code__init_part2_A_clinit) } }

func A_arbace_j2g_code__init_part2_A_clinit() { jrt.StartCheck(); A_arbace_j2g_code__init_part2_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_503, 8); var tmp1 *lang.Var; A_arbace_j2g_code__init_part1_A_Init(); tmp1 = A_arbace_j2g_code__init_part1_A_const_28; A_arbace_j2g_code__init_part2_A_const_0 = tmp1; A_arbace_j2g_code__init_part2_A_const_1 = A_arbace_j2g_code__init_part2_A_const_pool.A[6]; var tmp2 *lang.Var; A_arbace_j2g_code__init_part1_A_Init(); tmp2 = A_arbace_j2g_code__init_part1_A_const_22; A_arbace_j2g_code__init_part2_A_const_2 = tmp2; A_arbace_j2g_code__init_part2_A_const_3 = A_arbace_j2g_code__init_part2_A_const_pool.A[7] }

func A_arbace_j2g_code__init_part2_A_New() *A_arbace_j2g_code__init_part2_A { A_arbace_j2g_code__init_part2_A_Init(); t := &A_arbace_j2g_code__init_part2_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_code__init_part2_A) Ctor() {}

func (t *A_arbace_j2g_code__init_part2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_code__init_part2_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_code__init_part2_A_class }

func (t *A_arbace_j2g_code__init_part2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_code__init_part2_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_code__init_part2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_code__init_part2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_code__init_part2_A); return ok }

func A_arbace_j2g_code__init_part2_A_Cast(x any) *A_arbace_j2g_code__init_part2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_code__init_part2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_code__init_part2_A_class)) }; return v }
