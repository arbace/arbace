//line aot_arbace_j2g_code__init.ae:1
package aot_arbace_j2g_code

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_code__init_part0_A_Unit0__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_code__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_code__init_part0_A_const_1) }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Unit1__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_code__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_2)) }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Unit2__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_j2g_code_eval969000004_loading__1927001464__auto____969000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_code_eval969000004_loading__1927001464__auto____969000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_352, false); A_arbace_j2g_code_eval969000004_loading__1927001464__auto____969000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Unit3__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_code__init_part0_A_const_1)).Equals_O__Z(A_arbace_j2g_code__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_j2g_code_eval969000008_fn__969000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_j2g_code_eval969000008_fn__969000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_353, false); A_arbace_j2g_code_eval969000008_fn__969000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Init__O() any { A_arbace_j2g_code__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_j2g_code__init_part0_A_Load__O() any { A_arbace_j2g_code__init_part0_A_Init(); A_arbace_j2g_code__init_part0_A_Unit0__O(); A_arbace_j2g_code__init_part0_A_Unit1__O(); A_arbace_j2g_code__init_part0_A_Unit2__O(); A_arbace_j2g_code__init_part0_A_Unit3__O(); A_arbace_j2g_code__init_part0_A_Unit4__O(); A_arbace_j2g_code__init_part0_A_Unit5__O(); A_arbace_j2g_code__init_part0_A_Unit6__O(); A_arbace_j2g_code__init_part0_A_Unit7__O(); A_arbace_j2g_code__init_part0_A_Unit8__O(); A_arbace_j2g_code__init_part0_A_Unit9__O(); A_arbace_j2g_code__init_part0_A_Unit10__O(); A_arbace_j2g_code__init_part0_A_Unit11__O(); A_arbace_j2g_code__init_part0_A_Unit12__O(); A_arbace_j2g_code__init_part0_A_Unit13__O(); A_arbace_j2g_code__init_part0_A_Unit14__O(); A_arbace_j2g_code__init_part0_A_Unit15__O(); A_arbace_j2g_code__init_part0_A_Unit16__O(); A_arbace_j2g_code__init_part0_A_Unit17__O(); A_arbace_j2g_code__init_part0_A_Unit18__O(); A_arbace_j2g_code__init_part0_A_Unit19__O(); A_arbace_j2g_code__init_part0_A_Unit20__O(); A_arbace_j2g_code__init_part0_A_Unit21__O(); A_arbace_j2g_code__init_part0_A_Unit22__O(); A_arbace_j2g_code__init_part0_A_Unit23__O(); A_arbace_j2g_code__init_part0_A_Unit24__O(); A_arbace_j2g_code__init_part0_A_Unit25__O(); A_arbace_j2g_code__init_part0_A_Unit26__O(); A_arbace_j2g_code__init_part0_A_Unit27__O(); A_arbace_j2g_code__init_part0_A_Unit28__O(); A_arbace_j2g_code__init_part0_A_Unit29__O(); A_arbace_j2g_code__init_part0_A_Unit30__O(); A_arbace_j2g_code__init_part0_A_Unit31__O(); A_arbace_j2g_code__init_part0_A_Unit32__O(); A_arbace_j2g_code__init_part0_A_Unit33__O(); A_arbace_j2g_code__init_part0_A_Unit34__O(); A_arbace_j2g_code__init_part0_A_Unit35__O(); A_arbace_j2g_code__init_part0_A_Unit36__O(); A_arbace_j2g_code__init_part0_A_Unit37__O(); A_arbace_j2g_code__init_part0_A_Unit38__O(); A_arbace_j2g_code__init_part0_A_Unit39__O(); A_arbace_j2g_code__init_part0_A_Unit40__O(); A_arbace_j2g_code__init_part0_A_Unit41__O(); A_arbace_j2g_code__init_part0_A_Unit42__O(); A_arbace_j2g_code__init_part0_A_Unit43__O(); A_arbace_j2g_code__init_part0_A_Unit44__O(); A_arbace_j2g_code__init_part0_A_Unit45__O(); A_arbace_j2g_code__init_part0_A_Unit46__O(); A_arbace_j2g_code__init_part0_A_Unit47__O(); A_arbace_j2g_code__init_part0_A_Unit48__O(); A_arbace_j2g_code__init_part0_A_Unit49__O(); A_arbace_j2g_code__init_part0_A_Unit50__O(); A_arbace_j2g_code__init_part0_A_Unit51__O(); A_arbace_j2g_code__init_part0_A_Unit52__O(); A_arbace_j2g_code__init_part0_A_Unit53__O(); A_arbace_j2g_code__init_part0_A_Unit54__O(); A_arbace_j2g_code__init_part0_A_Unit55__O(); A_arbace_j2g_code__init_part0_A_Unit56__O(); A_arbace_j2g_code__init_part0_A_Unit57__O(); A_arbace_j2g_code__init_part0_A_Unit58__O(); A_arbace_j2g_code__init_part0_A_Unit59__O(); A_arbace_j2g_code__init_part0_A_Unit60__O(); A_arbace_j2g_code__init_part0_A_Unit61__O(); A_arbace_j2g_code__init_part0_A_Unit62__O(); A_arbace_j2g_code__init_part0_A_Unit63__O(); A_arbace_j2g_code__init_part0_A_Unit64__O(); A_arbace_j2g_code__init_part0_A_Unit65__O(); A_arbace_j2g_code__init_part0_A_Unit66__O(); A_arbace_j2g_code__init_part0_A_Unit67__O(); A_arbace_j2g_code__init_part0_A_Unit68__O(); A_arbace_j2g_code__init_part0_A_Unit69__O(); A_arbace_j2g_code__init_part0_A_Unit70__O(); A_arbace_j2g_code__init_part0_A_Unit71__O(); A_arbace_j2g_code__init_part0_A_Unit72__O(); A_arbace_j2g_code__init_part0_A_Unit73__O(); A_arbace_j2g_code__init_part0_A_Unit74__O(); A_arbace_j2g_code__init_part0_A_Unit75__O(); A_arbace_j2g_code__init_part0_A_Unit76__O(); A_arbace_j2g_code__init_part0_A_Unit77__O(); A_arbace_j2g_code__init_part0_A_Unit78__O(); A_arbace_j2g_code__init_part0_A_Unit79__O(); A_arbace_j2g_code__init_part0_A_Unit80__O(); A_arbace_j2g_code__init_part0_A_Unit81__O(); A_arbace_j2g_code__init_part0_A_Unit82__O(); A_arbace_j2g_code__init_part0_A_Unit83__O(); A_arbace_j2g_code__init_part0_A_Unit84__O(); A_arbace_j2g_code__init_part0_A_Unit85__O(); A_arbace_j2g_code__init_part0_A_Unit86__O(); A_arbace_j2g_code__init_part0_A_Unit87__O(); A_arbace_j2g_code__init_part0_A_Unit88__O(); A_arbace_j2g_code__init_part0_A_Unit89__O(); A_arbace_j2g_code__init_part0_A_Unit90__O(); A_arbace_j2g_code__init_part0_A_Unit91__O(); A_arbace_j2g_code__init_part0_A_Unit92__O(); A_arbace_j2g_code__init_part0_A_Unit93__O(); A_arbace_j2g_code__init_part0_A_Unit94__O(); A_arbace_j2g_code__init_part0_A_Unit95__O(); A_arbace_j2g_code__init_part0_A_Unit96__O(); A_arbace_j2g_code__init_part0_A_Unit97__O(); A_arbace_j2g_code__init_part0_A_Unit98__O(); A_arbace_j2g_code__init_part0_A_Unit99__O(); return nil }



func A_arbace_j2g_code__init_A_Load__O() any { jrt.StartCheck(); A_arbace_j2g_code__init_part0_A_Init__O(); A_arbace_j2g_code__init_part1_A_Init__O(); A_arbace_j2g_code__init_part0_A_Load__O(); A_arbace_j2g_code__init_part1_A_Load__O(); return nil }













func A_arbace_j2g_code__init_part0_A_Unit4__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); A_arbace_j2g_code__init_part0_A_const_4.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_5)); return A_arbace_j2g_code__init_part0_A_const_4.SetDynamic_Z__Var(true).Ref() }




func A_arbace_j2g_code__init_part0_A_Unit5__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); A_arbace_j2g_code__init_part0_A_const_6.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_7)); return A_arbace_j2g_code__init_part0_A_const_6.SetDynamic_Z__Var(true).Ref() }

func A_arbace_j2g_code__init_part0_A_Unit6__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); A_arbace_j2g_code__init_part0_A_const_8.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_9)); return A_arbace_j2g_code__init_part0_A_const_8.SetDynamic_Z__Var(true).Ref() }






func A_arbace_j2g_code__init_part0_A_Unit7__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); A_arbace_j2g_code__init_part0_A_const_10.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_11)); return A_arbace_j2g_code__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }




func A_arbace_j2g_code__init_part0_A_Unit8__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_12; var tmp2 any = A_arbace_j2g_code_note_store_BANG__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_code_note_store_BANG__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_354, false); A_arbace_j2g_code_note_store_BANG__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_13)); return A_arbace_j2g_code__init_part0_A_const_12 }














func A_arbace_j2g_code__init_part0_A_Unit9__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_14; var tmp2 any = A_arbace_j2g_code_fail_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_code_fail_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_355, true); A_arbace_j2g_code_fail_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_15)); return A_arbace_j2g_code__init_part0_A_const_14 }

func A_arbace_j2g_code__init_part0_A_Unit10__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_16; var tmp2 any = A_arbace_j2g_code_pkg_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_code_pkg_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_356, false); A_arbace_j2g_code_pkg_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_17)); return A_arbace_j2g_code__init_part0_A_const_16 }

func A_arbace_j2g_code__init_part0_A_Unit11__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(57, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_18; var tmp2 any = A_arbace_j2g_code_jsym_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_code_jsym_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_357, false); A_arbace_j2g_code_jsym_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_19)); return A_arbace_j2g_code__init_part0_A_const_18 }
func A_arbace_j2g_code__init_part0_A_Unit12__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_20; var tmp2 any = A_arbace_j2g_code_csym_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_code_csym_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_358, false); A_arbace_j2g_code_csym_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_21)); return A_arbace_j2g_code__init_part0_A_const_20 }
func A_arbace_j2g_code__init_part0_A_Unit13__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_22; var tmp2 any = A_arbace_j2g_code_gotype_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_code_gotype_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_359, false); A_arbace_j2g_code_gotype_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_23)); return A_arbace_j2g_code__init_part0_A_const_22 }

func A_arbace_j2g_code__init_part0_A_Unit14__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_24; var tmp2 any = A_arbace_j2g_code_tag_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_code_tag_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_360, false); A_arbace_j2g_code_tag_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_25)); return A_arbace_j2g_code__init_part0_A_const_24 }

func A_arbace_j2g_code__init_part0_A_Unit15__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_26; var tmp2 any = A_arbace_j2g_code_new_counter_BANG__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_code_new_counter_BANG__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_361, false); A_arbace_j2g_code_new_counter_BANG__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_27)); return A_arbace_j2g_code__init_part0_A_const_26 }


func A_arbace_j2g_code__init_part0_A_Unit16__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_28; var tmp2 any = A_arbace_j2g_code_fresh_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_code_fresh_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_362, false); A_arbace_j2g_code_fresh_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_29)); return A_arbace_j2g_code__init_part0_A_const_28 }










func A_arbace_j2g_code__init_part0_A_Unit17__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_30; var tmp2 any = A_arbace_j2g_code_fresh_raw_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_code_fresh_raw_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_363, false); A_arbace_j2g_code_fresh_raw_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_31)); return A_arbace_j2g_code__init_part0_A_const_30 }









func A_arbace_j2g_code__init_part0_A_Unit18__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_32; var tmp2 any = A_arbace_j2g_code_tmp_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_code_tmp_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_364, false); A_arbace_j2g_code_tmp_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_33)); return A_arbace_j2g_code__init_part0_A_const_32 }

func A_arbace_j2g_code__init_part0_A_Unit19__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_34; var tmp2 any = A_arbace_j2g_code_use_sym_BANG__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_j2g_code_use_sym_BANG__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_365, false); A_arbace_j2g_code_use_sym_BANG__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_35)); return A_arbace_j2g_code__init_part0_A_const_34 }

func A_arbace_j2g_code__init_part0_A_Unit20__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_36; var tmp2 any = A_arbace_j2g_code_binding_sym_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_code_binding_sym_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_366, false); A_arbace_j2g_code_binding_sym_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_37)); return A_arbace_j2g_code__init_part0_A_const_36 }










func A_arbace_j2g_code__init_part0_A_Unit21__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); A_arbace_j2g_code__init_part0_A_const_38.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_39)); return A_arbace_j2g_code__init_part0_A_const_38.SetDynamic_Z__Var(true).Ref() }





func A_arbace_j2g_code__init_part0_A_Unit22__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(108, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_40; var tmp2 any = A_arbace_j2g_code_with_line_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_j2g_code_with_line_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_367, false); A_arbace_j2g_code_with_line_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_41)); return A_arbace_j2g_code__init_part0_A_const_40 }






func A_arbace_j2g_code__init_part0_A_Unit23__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_42; var tmp2 any = A_arbace_j2g_code_emit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_code_emit_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_368, false); A_arbace_j2g_code_emit_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_43)); return A_arbace_j2g_code__init_part0_A_const_42 }

func A_arbace_j2g_code__init_part0_A_Unit24__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_44; var tmp2 any = A_arbace_j2g_code_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_code_decl_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_369, false); A_arbace_j2g_code_decl_BANG__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_45)); return A_arbace_j2g_code__init_part0_A_const_44 }






func A_arbace_j2g_code__init_part0_A_Unit25__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_46; var tmp2 any = A_arbace_j2g_code_fold_items_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_code_fold_items_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_370, false); A_arbace_j2g_code_fold_items_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_47)); return A_arbace_j2g_code__init_part0_A_const_46 }



















func A_arbace_j2g_code__init_part0_A_Unit26__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_48; var tmp2 any = A_arbace_j2g_code_with_block_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_code_with_block_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_371, false); A_arbace_j2g_code_with_block_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_49)); return A_arbace_j2g_code__init_part0_A_const_48 }






func A_arbace_j2g_code__init_part0_A_Unit27__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_50; var tmp2 any = A_arbace_j2g_code_block_forms_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_code_block_forms_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_372, false); A_arbace_j2g_code_block_forms_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_51)); return A_arbace_j2g_code__init_part0_A_const_50 }




func A_arbace_j2g_code__init_part0_A_Unit28__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_52; var tmp2 any = A_arbace_j2g_code_vt_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_j2g_code_vt_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_373, false); A_arbace_j2g_code_vt_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_53)); return A_arbace_j2g_code__init_part0_A_const_52 }

func A_arbace_j2g_code__init_part0_A_Unit29__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_54; var tmp2 any = A_arbace_j2g_code_object_like_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_code_object_like_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_374, false); A_arbace_j2g_code_object_like_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_55)); return A_arbace_j2g_code__init_part0_A_const_54 }

func A_arbace_j2g_code__init_part0_A_Unit30__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_56; var tmp2 any = A_arbace_j2g_code_zero_of_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_j2g_code_zero_of_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_375, false); A_arbace_j2g_code_zero_of_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_57)); return A_arbace_j2g_code__init_part0_A_const_56 }







func A_arbace_j2g_code__init_part0_A_Unit31__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_58; var tmp2 any = A_arbace_j2g_code_literal_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_code_literal_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_376, false); A_arbace_j2g_code_literal_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_59)); return A_arbace_j2g_code__init_part0_A_const_58 }

func A_arbace_j2g_code__init_part0_A_Unit32__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(170, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_60; var tmp2 any = A_arbace_j2g_code_fold_int_conv_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_code_fold_int_conv_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_377, false); A_arbace_j2g_code_fold_int_conv_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_61)); return A_arbace_j2g_code__init_part0_A_const_60 }







func A_arbace_j2g_code__init_part0_A_Unit33__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_62; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_63)); return A_arbace_j2g_code__init_part0_A_const_62 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit34__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_65)); return A_arbace_j2g_code__init_part0_A_const_64 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit35__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_67)); return A_arbace_j2g_code__init_part0_A_const_66 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit36__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_69)); return A_arbace_j2g_code__init_part0_A_const_68 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit37__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_70; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_71)); return A_arbace_j2g_code__init_part0_A_const_70 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit38__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_73)); return A_arbace_j2g_code__init_part0_A_const_72 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit39__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_75)); return A_arbace_j2g_code__init_part0_A_const_74 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit40__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_77)); return A_arbace_j2g_code__init_part0_A_const_76 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit41__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_78; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_79)); return A_arbace_j2g_code__init_part0_A_const_78 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit42__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_81)); return A_arbace_j2g_code__init_part0_A_const_80 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit43__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_82; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_83)); return A_arbace_j2g_code__init_part0_A_const_82 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit44__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_84; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_85)); return A_arbace_j2g_code__init_part0_A_const_84 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit45__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_87)); return A_arbace_j2g_code__init_part0_A_const_86 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit46__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_89)); return A_arbace_j2g_code__init_part0_A_const_88 }
//line :178:1
func A_arbace_j2g_code__init_part0_A_Unit47__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_91)); return A_arbace_j2g_code__init_part0_A_const_90 }


func A_arbace_j2g_code__init_part0_A_Unit48__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_92; var tmp2 any = A_arbace_j2g_code_up_sym_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_code_up_sym_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_378, false); A_arbace_j2g_code_up_sym_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_93)); return A_arbace_j2g_code__init_part0_A_const_92 }











func A_arbace_j2g_code__init_part0_A_Unit49__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(193, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_94; var tmp2 any = A_arbace_j2g_code_coerce_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_j2g_code_coerce_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_379, false); A_arbace_j2g_code_coerce_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_95)); return A_arbace_j2g_code__init_part0_A_const_94 }

































func A_arbace_j2g_code__init_part0_A_Unit50__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(227, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_96; var tmp2 any = A_arbace_j2g_code_v_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_code_v_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_380, true); A_arbace_j2g_code_v_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_97)); return A_arbace_j2g_code__init_part0_A_const_96 }




func A_arbace_j2g_code__init_part0_A_Unit51__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_98; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_99)); return A_arbace_j2g_code__init_part0_A_const_98 }

func A_arbace_j2g_code__init_part0_A_Unit52__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); A_arbace_j2g_code__init_part0_A_const_100.BindRoot_O__V(A_arbace_j2g_code__init_part0_A_const_101); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_102)); return A_arbace_j2g_code__init_part0_A_const_100 }





func A_arbace_j2g_code__init_part0_A_Unit53__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(240, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_103; var tmp2 any = A_arbace_j2g_code_expressible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_j2g_code_expressible_QMARK__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_381, false); A_arbace_j2g_code_expressible_QMARK__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_104)); return A_arbace_j2g_code__init_part0_A_const_103 }







func A_arbace_j2g_code__init_part0_A_Unit54__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_105; var tmp2 any = A_arbace_j2g_code_compiled_caller_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_code_compiled_caller_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_382, false); A_arbace_j2g_code_compiled_caller_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_106)); return A_arbace_j2g_code__init_part0_A_const_105 }




func A_arbace_j2g_code__init_part0_A_Unit55__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_98; var tmp2 any = A_arbace_j2g_code_guarded_static_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_j2g_code_guarded_static_QMARK__A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_383, false); A_arbace_j2g_code_guarded_static_QMARK__A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_107)); return A_arbace_j2g_code__init_part0_A_const_98 }















func A_arbace_j2g_code__init_part0_A_Unit56__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(269, 1); A_arbace_j2g_code__init_part0_A_const_108.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_109)); return A_arbace_j2g_code__init_part0_A_const_108.SetDynamic_Z__Var(true).Ref() }







func A_arbace_j2g_code__init_part0_A_Unit57__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(277, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_110; var tmp2 any = A_arbace_j2g_code_memo_node_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_code_memo_node_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_384, false); A_arbace_j2g_code_memo_node_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_111)); return A_arbace_j2g_code__init_part0_A_const_110 }














func A_arbace_j2g_code__init_part0_A_Unit58__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_112; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_113)); return A_arbace_j2g_code__init_part0_A_const_112 }

func A_arbace_j2g_code__init_part0_A_Unit59__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(294, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_114; var tmp2 any = A_arbace_j2g_code_simple_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_j2g_code_simple_QMARK__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_385, false); A_arbace_j2g_code_simple_QMARK__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_115)); return A_arbace_j2g_code__init_part0_A_const_114 }




func A_arbace_j2g_code__init_part0_A_Unit60__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(299, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_112; var tmp2 any = A_arbace_j2g_code_simple_STAR__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_code_simple_STAR__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_386, false); A_arbace_j2g_code_simple_STAR__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_116)); return A_arbace_j2g_code__init_part0_A_const_112 }











func A_arbace_j2g_code__init_part0_A_Unit61__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(311, 1); A_arbace_j2g_code__init_part0_A_const_117.BindRoot_O__V(A_arbace_j2g_code__init_part0_A_const_118); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_117; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_119)); return A_arbace_j2g_code__init_part0_A_const_117 }



func A_arbace_j2g_code__init_part0_A_Unit62__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(315, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_120; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_121)); return A_arbace_j2g_code__init_part0_A_const_120 }

func A_arbace_j2g_code__init_part0_A_Unit63__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(317, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_122; var tmp2 any = A_arbace_j2g_code_effects_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_j2g_code_effects_QMARK__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_387, false); A_arbace_j2g_code_effects_QMARK__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_123)); return A_arbace_j2g_code__init_part0_A_const_122 }




func A_arbace_j2g_code__init_part0_A_Unit64__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(322, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_120; var tmp2 any = A_arbace_j2g_code_effects_STAR__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_code_effects_STAR__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_388, false); A_arbace_j2g_code_effects_STAR__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_124)); return A_arbace_j2g_code__init_part0_A_const_120 }


















func A_arbace_j2g_code__init_part0_A_Unit65__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(341, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_125; var tmp2 any = A_arbace_j2g_code_reads_state_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_j2g_code_reads_state_QMARK__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_389, false); A_arbace_j2g_code_reads_state_QMARK__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_126)); return A_arbace_j2g_code__init_part0_A_const_125 }

















func A_arbace_j2g_code__init_part0_A_Unit66__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(359, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_127; var tmp2 any = A_arbace_j2g_code_stable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_code_stable_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_390, false); A_arbace_j2g_code_stable_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_128)); return A_arbace_j2g_code__init_part0_A_const_127 }










func A_arbace_j2g_code__init_part0_A_Unit67__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_129; var tmp2 any = A_arbace_j2g_code_hoist_value_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_j2g_code_hoist_value_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_391, false); A_arbace_j2g_code_hoist_value_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_130)); return A_arbace_j2g_code__init_part0_A_const_129 }








func A_arbace_j2g_code__init_part0_A_Unit68__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_131; var tmp2 any = A_arbace_j2g_code_any_after_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_code_any_after_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_392, false); A_arbace_j2g_code_any_after_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_132)); return A_arbace_j2g_code__init_part0_A_const_131 }








func A_arbace_j2g_code__init_part0_A_Unit69__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(388, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_133; var tmp2 any = A_arbace_j2g_code_operands_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_j2g_code_operands_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_393, false); A_arbace_j2g_code_operands_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_134)); return A_arbace_j2g_code__init_part0_A_const_133 }
































func A_arbace_j2g_code__init_part0_A_Unit70__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(421, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_135; var tmp2 any = A_arbace_j2g_code_java_hash_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_code_java_hash_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_394, false); A_arbace_j2g_code_java_hash_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_136)); return A_arbace_j2g_code__init_part0_A_const_135 }

func A_arbace_j2g_code__init_part0_A_Unit71__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(423, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_137; var tmp2 any = A_arbace_j2g_code_string_lit_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_j2g_code_string_lit_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_395, false); A_arbace_j2g_code_string_lit_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_138)); return A_arbace_j2g_code__init_part0_A_const_137 }










func A_arbace_j2g_code__init_part0_A_Unit72__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_139; var tmp2 any = A_arbace_j2g_code_float_lit_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_code_float_lit_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_396, false); A_arbace_j2g_code_float_lit_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_140)); return A_arbace_j2g_code__init_part0_A_const_139 }








func A_arbace_j2g_code__init_part0_A_Unit73__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(443, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_141; var tmp2 any = A_arbace_j2g_code_const_value_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_j2g_code_const_value_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_397, false); A_arbace_j2g_code_const_value_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_142)); return A_arbace_j2g_code__init_part0_A_const_141 }














func A_arbace_j2g_code__init_part0_A_Unit74__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(458, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_84; var tmp2 any = A_arbace_j2g_code_missing_expr_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_code_missing_expr_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_398, false); A_arbace_j2g_code_missing_expr_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_143)); return A_arbace_j2g_code__init_part0_A_const_84 }






func A_arbace_j2g_code__init_part0_A_Unit75__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_144; var tmp2 any = A_arbace_j2g_code_class_missing_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_j2g_code_class_missing_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_399, false); A_arbace_j2g_code_class_missing_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_145)); return A_arbace_j2g_code__init_part0_A_const_144 }


func A_arbace_j2g_code__init_part0_A_Unit76__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(468, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_146; var tmp2 any = A_arbace_j2g_code_desc_missing_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_code_desc_missing_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_400, false); A_arbace_j2g_code_desc_missing_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_147)); return A_arbace_j2g_code__init_part0_A_const_146 }
func A_arbace_j2g_code__init_part0_A_Unit77__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(469, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_148; var tmp2 any = A_arbace_j2g_code_mdesc_missing_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_j2g_code_mdesc_missing_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_401, false); A_arbace_j2g_code_mdesc_missing_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_149)); return A_arbace_j2g_code__init_part0_A_const_148 }

func A_arbace_j2g_code__init_part0_A_Unit78__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_150; var tmp2 any = A_arbace_j2g_code_hw_static_exists_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_code_hw_static_exists_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_402, false); A_arbace_j2g_code_hw_static_exists_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_151)); return A_arbace_j2g_code__init_part0_A_const_150 }



func A_arbace_j2g_code__init_part0_A_Unit79__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(475, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_152; var tmp2 any = A_arbace_j2g_code_lookup_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_code_lookup_call_QMARK__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_403, false); A_arbace_j2g_code_lookup_call_QMARK__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_153)); return A_arbace_j2g_code__init_part0_A_const_152 }






func A_arbace_j2g_code__init_part0_A_Unit80__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(482, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_154; var tmp2 any = A_arbace_j2g_code_vh_op_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_code_vh_op_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_404, false); A_arbace_j2g_code_vh_op_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_155)); return A_arbace_j2g_code__init_part0_A_const_154 }




func A_arbace_j2g_code__init_part0_A_Unit81__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(487, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_156; var tmp2 any = A_arbace_j2g_code_vh_supported_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_j2g_code_vh_supported_QMARK__A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_405, false); A_arbace_j2g_code_vh_supported_QMARK__A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_157)); return A_arbace_j2g_code__init_part0_A_const_156 }








func A_arbace_j2g_code__init_part0_A_Unit82__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(496, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_158; var tmp2 any = A_arbace_j2g_code_vh_missing_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_code_vh_missing_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_406, false); A_arbace_j2g_code_vh_missing_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_159)); return A_arbace_j2g_code__init_part0_A_const_158 }


















func A_arbace_j2g_code__init_part0_A_Unit83__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(515, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_82; var tmp2 any = A_arbace_j2g_code_missing_reason_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_code_missing_reason_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_407, false); A_arbace_j2g_code_missing_reason_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_160)); return A_arbace_j2g_code__init_part0_A_const_82 }




















































func A_arbace_j2g_code__init_part0_A_Unit84__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(568, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_161; var tmp2 any = A_arbace_j2g_code_this_val_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_code_this_val_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_408, false); A_arbace_j2g_code_this_val_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_162)); return A_arbace_j2g_code__init_part0_A_const_161 }




func A_arbace_j2g_code__init_part0_A_Unit85__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(573, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_163; var tmp2 any = A_arbace_j2g_code_outer_field_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_j2g_code_outer_field_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_409, false); A_arbace_j2g_code_outer_field_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_164)); return A_arbace_j2g_code__init_part0_A_const_163 }






func A_arbace_j2g_code__init_part0_A_Unit86__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(580, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_165; var tmp2 any = A_arbace_j2g_code_this_path_val_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_code_this_path_val_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_410, false); A_arbace_j2g_code_this_path_val_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_166)); return A_arbace_j2g_code__init_part0_A_const_165 }














func A_arbace_j2g_code__init_part0_A_Unit87__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(595, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_167; var tmp2 any = A_arbace_j2g_code_local_val_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_j2g_code_local_val_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_411, false); A_arbace_j2g_code_local_val_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_168)); return A_arbace_j2g_code__init_part0_A_const_167 }





func A_arbace_j2g_code__init_part0_A_Unit88__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(601, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_169; var tmp2 any = A_arbace_j2g_code_struct_of_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_j2g_code_struct_of_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_412, true); A_arbace_j2g_code_struct_of_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_170)); return A_arbace_j2g_code__init_part0_A_const_169 }














func A_arbace_j2g_code__init_part0_A_Unit89__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(616, 1); A_arbace_j2g_code__init_part0_A_const_171.BindRoot_O__V(A_arbace_j2g_code__init_part0_A_const_172); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_171; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_173)); return A_arbace_j2g_code__init_part0_A_const_171 }

func A_arbace_j2g_code__init_part0_A_Unit90__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(618, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_174; var tmp2 any = A_arbace_j2g_code_vh_field_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_j2g_code_vh_field_QMARK__A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_413, false); A_arbace_j2g_code_vh_field_QMARK__A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_175)); return A_arbace_j2g_code__init_part0_A_const_174 }





func A_arbace_j2g_code__init_part0_A_Unit91__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(624, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_176; var tmp2 any = A_arbace_j2g_code_volatile_field_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_code_volatile_field_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_414, false); A_arbace_j2g_code_volatile_field_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_177)); return A_arbace_j2g_code__init_part0_A_const_176 }

func A_arbace_j2g_code__init_part0_A_Unit92__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(626, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_178; var tmp2 any = A_arbace_j2g_code_volatile_read_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_j2g_code_volatile_read_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_415, false); A_arbace_j2g_code_volatile_read_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_179)); return A_arbace_j2g_code__init_part0_A_const_178 }






func A_arbace_j2g_code__init_part0_A_Unit93__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(633, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_180; var tmp2 any = A_arbace_j2g_code_volatile_write_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_code_volatile_write_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_416, false); A_arbace_j2g_code_volatile_write_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_181)); return A_arbace_j2g_code__init_part0_A_const_180 }





func A_arbace_j2g_code__init_part0_A_Unit94__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(639, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_182; var tmp2 any = A_arbace_j2g_code_field_place_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_j2g_code_field_place_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_417, false); A_arbace_j2g_code_field_place_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_183)); return A_arbace_j2g_code__init_part0_A_const_182 }






func A_arbace_j2g_code__init_part0_A_Unit95__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(646, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_184; var tmp2 any = A_arbace_j2g_code_target_operands_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_j2g_code_target_operands_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_418, false); A_arbace_j2g_code_target_operands_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_185)); return A_arbace_j2g_code__init_part0_A_const_184 }








func A_arbace_j2g_code__init_part0_A_Unit96__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(655, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_186; var tmp2 any = A_arbace_j2g_code_static_place_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_code_static_place_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_419, false); A_arbace_j2g_code_static_place_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_186; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_187)); return A_arbace_j2g_code__init_part0_A_const_186 }



func A_arbace_j2g_code__init_part0_A_Unit97__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(659, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_188; var tmp2 any = A_arbace_j2g_code_class_init_call_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_code_class_init_call_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_420, false); A_arbace_j2g_code_class_init_call_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_188; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_189)); return A_arbace_j2g_code__init_part0_A_const_188 }






func A_arbace_j2g_code__init_part0_A_Unit98__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(666, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_190; var tmp2 any = A_arbace_j2g_code_class_val_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_j2g_code_class_val_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_421, false); A_arbace_j2g_code_class_val_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part0_A_const_190; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_191)); return A_arbace_j2g_code__init_part0_A_const_190 }




















func A_arbace_j2g_code__init_part0_A_Unit99__O() any { A_arbace_j2g_code__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part0_A_const_192; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part0_A_const_193)); return A_arbace_j2g_code__init_part0_A_const_192 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit100__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_0; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_1)); return A_arbace_j2g_code__init_part1_A_const_0 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit101__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_3)); return A_arbace_j2g_code__init_part1_A_const_2 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit102__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_5)); return A_arbace_j2g_code__init_part1_A_const_4 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit103__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_7)); return A_arbace_j2g_code__init_part1_A_const_6 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit104__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_9)); return A_arbace_j2g_code__init_part1_A_const_8 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit105__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_11)); return A_arbace_j2g_code__init_part1_A_const_10 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit106__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_13)); return A_arbace_j2g_code__init_part1_A_const_12 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit107__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_15)); return A_arbace_j2g_code__init_part1_A_const_14 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit108__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_17)); return A_arbace_j2g_code__init_part1_A_const_16 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit109__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_19)); return A_arbace_j2g_code__init_part1_A_const_18 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Unit110__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(687, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_21)); return A_arbace_j2g_code__init_part1_A_const_20 }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Init__O() any { A_arbace_j2g_code__init_part1_A_Init(); return nil }
//line :687:1
func A_arbace_j2g_code__init_part1_A_Load__O() any { A_arbace_j2g_code__init_part1_A_Init(); A_arbace_j2g_code__init_part1_A_Unit100__O(); A_arbace_j2g_code__init_part1_A_Unit101__O(); A_arbace_j2g_code__init_part1_A_Unit102__O(); A_arbace_j2g_code__init_part1_A_Unit103__O(); A_arbace_j2g_code__init_part1_A_Unit104__O(); A_arbace_j2g_code__init_part1_A_Unit105__O(); A_arbace_j2g_code__init_part1_A_Unit106__O(); A_arbace_j2g_code__init_part1_A_Unit107__O(); A_arbace_j2g_code__init_part1_A_Unit108__O(); A_arbace_j2g_code__init_part1_A_Unit109__O(); A_arbace_j2g_code__init_part1_A_Unit110__O(); A_arbace_j2g_code__init_part1_A_Unit111__O(); A_arbace_j2g_code__init_part1_A_Unit112__O(); A_arbace_j2g_code__init_part1_A_Unit113__O(); A_arbace_j2g_code__init_part1_A_Unit114__O(); A_arbace_j2g_code__init_part1_A_Unit115__O(); A_arbace_j2g_code__init_part1_A_Unit116__O(); A_arbace_j2g_code__init_part1_A_Unit117__O(); A_arbace_j2g_code__init_part1_A_Unit118__O(); A_arbace_j2g_code__init_part1_A_Unit119__O(); A_arbace_j2g_code__init_part1_A_Unit120__O(); A_arbace_j2g_code__init_part1_A_Unit121__O(); A_arbace_j2g_code__init_part1_A_Unit122__O(); A_arbace_j2g_code__init_part1_A_Unit123__O(); A_arbace_j2g_code__init_part1_A_Unit124__O(); A_arbace_j2g_code__init_part1_A_Unit125__O(); A_arbace_j2g_code__init_part1_A_Unit126__O(); A_arbace_j2g_code__init_part1_A_Unit127__O(); A_arbace_j2g_code__init_part1_A_Unit128__O(); A_arbace_j2g_code__init_part1_A_Unit129__O(); A_arbace_j2g_code__init_part1_A_Unit130__O(); A_arbace_j2g_code__init_part1_A_Unit131__O(); A_arbace_j2g_code__init_part1_A_Unit132__O(); A_arbace_j2g_code__init_part1_A_Unit133__O(); A_arbace_j2g_code__init_part1_A_Unit134__O(); A_arbace_j2g_code__init_part1_A_Unit135__O(); A_arbace_j2g_code__init_part1_A_Unit136__O(); A_arbace_j2g_code__init_part1_A_Unit137__O(); A_arbace_j2g_code__init_part1_A_Unit138__O(); A_arbace_j2g_code__init_part1_A_Unit139__O(); A_arbace_j2g_code__init_part1_A_Unit140__O(); A_arbace_j2g_code__init_part1_A_Unit141__O(); A_arbace_j2g_code__init_part1_A_Unit142__O(); A_arbace_j2g_code__init_part1_A_Unit143__O(); A_arbace_j2g_code__init_part1_A_Unit144__O(); A_arbace_j2g_code__init_part1_A_Unit145__O(); A_arbace_j2g_code__init_part1_A_Unit146__O(); A_arbace_j2g_code__init_part1_A_Unit147__O(); A_arbace_j2g_code__init_part1_A_Unit148__O(); A_arbace_j2g_code__init_part1_A_Unit149__O(); A_arbace_j2g_code__init_part1_A_Unit150__O(); A_arbace_j2g_code__init_part1_A_Unit151__O(); A_arbace_j2g_code__init_part1_A_Unit152__O(); A_arbace_j2g_code__init_part1_A_Unit153__O(); A_arbace_j2g_code__init_part1_A_Unit154__O(); A_arbace_j2g_code__init_part1_A_Unit155__O(); A_arbace_j2g_code__init_part1_A_Unit156__O(); A_arbace_j2g_code__init_part1_A_Unit157__O(); A_arbace_j2g_code__init_part1_A_Unit158__O(); A_arbace_j2g_code__init_part1_A_Unit159__O(); A_arbace_j2g_code__init_part1_A_Unit160__O(); A_arbace_j2g_code__init_part1_A_Unit161__O(); A_arbace_j2g_code__init_part1_A_Unit162__O(); A_arbace_j2g_code__init_part1_A_Unit163__O(); A_arbace_j2g_code__init_part1_A_Unit164__O(); A_arbace_j2g_code__init_part1_A_Unit165__O(); A_arbace_j2g_code__init_part1_A_Unit166__O(); A_arbace_j2g_code__init_part1_A_Unit167__O(); A_arbace_j2g_code__init_part1_A_Unit168__O(); A_arbace_j2g_code__init_part1_A_Unit169__O(); A_arbace_j2g_code__init_part1_A_Unit170__O(); A_arbace_j2g_code__init_part1_A_Unit171__O(); A_arbace_j2g_code__init_part1_A_Unit172__O(); A_arbace_j2g_code__init_part1_A_Unit173__O(); A_arbace_j2g_code__init_part1_A_Unit174__O(); A_arbace_j2g_code__init_part1_A_Unit175__O(); A_arbace_j2g_code__init_part1_A_Unit176__O(); A_arbace_j2g_code__init_part1_A_Unit177__O(); A_arbace_j2g_code__init_part1_A_Unit178__O(); A_arbace_j2g_code__init_part1_A_Unit179__O(); A_arbace_j2g_code__init_part1_A_Unit180__O(); A_arbace_j2g_code__init_part1_A_Unit181__O(); A_arbace_j2g_code__init_part1_A_Unit182__O(); A_arbace_j2g_code__init_part1_A_Unit183__O(); A_arbace_j2g_code__init_part1_A_Unit184__O(); A_arbace_j2g_code__init_part1_A_Unit185__O(); A_arbace_j2g_code__init_part1_A_Unit186__O(); A_arbace_j2g_code__init_part1_A_Unit187__O(); A_arbace_j2g_code__init_part1_A_Unit188__O(); A_arbace_j2g_code__init_part1_A_Unit189__O(); A_arbace_j2g_code__init_part1_A_Unit190__O(); A_arbace_j2g_code__init_part1_A_Unit191__O(); A_arbace_j2g_code__init_part1_A_Unit192__O(); A_arbace_j2g_code__init_part1_A_Unit193__O(); return nil }


func A_arbace_j2g_code__init_part1_A_Unit111__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(690, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_22; var tmp2 any = A_arbace_j2g_code_hoist_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_code_hoist_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_423, false); A_arbace_j2g_code_hoist_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_23)); return A_arbace_j2g_code__init_part1_A_const_22 }











func A_arbace_j2g_code__init_part1_A_Unit112__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(702, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_24; var tmp2 any = A_arbace_j2g_code_expr_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_j2g_code_expr_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_424, false); A_arbace_j2g_code_expr_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_25)); return A_arbace_j2g_code__init_part1_A_const_24 }














func A_arbace_j2g_code__init_part1_A_Unit113__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(717, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_26; var tmp2 any = A_arbace_j2g_code_expr_op_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_code_expr_op_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_425, false); A_arbace_j2g_code_expr_op_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_27)); return A_arbace_j2g_code__init_part1_A_const_26 }


















































































func A_arbace_j2g_code__init_part1_A_Unit114__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(800, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_28; var tmp2 any = A_arbace_j2g_code_expr_as_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_code_expr_as_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_426, false); A_arbace_j2g_code_expr_as_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_29)); return A_arbace_j2g_code__init_part1_A_const_28 }





func A_arbace_j2g_code__init_part1_A_Unit115__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(806, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_30; var tmp2 any = A_arbace_j2g_code_cond_expr_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_code_cond_expr_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_427, false); A_arbace_j2g_code_cond_expr_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_31)); return A_arbace_j2g_code__init_part1_A_const_30 }
















func A_arbace_j2g_code__init_part1_A_Unit116__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(823, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_32; var tmp2 any = A_arbace_j2g_code_go_lit_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_code_go_lit_QMARK__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_428, false); A_arbace_j2g_code_go_lit_QMARK__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_33)); return A_arbace_j2g_code__init_part1_A_const_32 }

func A_arbace_j2g_code__init_part1_A_Unit117__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(825, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_34; var tmp2 any = A_arbace_j2g_code_unsigned_lit_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_code_unsigned_lit_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_429, false); A_arbace_j2g_code_unsigned_lit_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_35)); return A_arbace_j2g_code__init_part1_A_const_34 }








func A_arbace_j2g_code__init_part1_A_Unit118__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(834, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_2; var tmp2 any = A_arbace_j2g_code_arith_val_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_code_arith_val_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_430, false); A_arbace_j2g_code_arith_val_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_36)); return A_arbace_j2g_code__init_part1_A_const_2 }



















































func A_arbace_j2g_code__init_part1_A_Unit119__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(886, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_37; var tmp2 any = A_arbace_j2g_code_box_val_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_code_box_val_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_431, false); A_arbace_j2g_code_box_val_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_38)); return A_arbace_j2g_code__init_part1_A_const_37 }



func A_arbace_j2g_code__init_part1_A_Unit120__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(890, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_39; var tmp2 any = A_arbace_j2g_code_prim_convert_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_j2g_code_prim_convert_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_432, false); A_arbace_j2g_code_prim_convert_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_40)); return A_arbace_j2g_code__init_part1_A_const_39 }
















func A_arbace_j2g_code__init_part1_A_Unit121__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(907, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_4; var tmp2 any = A_arbace_j2g_code_convert_val_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_code_convert_val_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_433, false); A_arbace_j2g_code_convert_val_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_41)); return A_arbace_j2g_code__init_part1_A_const_4 }



















func A_arbace_j2g_code__init_part1_A_Unit122__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(927, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_6; var tmp2 any = A_arbace_j2g_code_cast_val_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_code_cast_val_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_434, false); A_arbace_j2g_code_cast_val_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_42)); return A_arbace_j2g_code__init_part1_A_const_6 }

















func A_arbace_j2g_code__init_part1_A_Unit123__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(945, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_8; var tmp2 any = A_arbace_j2g_code_instance_val_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_code_instance_val_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_435, false); A_arbace_j2g_code_instance_val_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_43)); return A_arbace_j2g_code__init_part1_A_const_8 }



















func A_arbace_j2g_code__init_part1_A_Unit124__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(965, 1); A_arbace_j2g_code__init_part1_A_const_44.BindRoot_O__V(A_arbace_j2g_code__init_part1_A_const_45); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_44; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_46)); return A_arbace_j2g_code__init_part1_A_const_44 }





func A_arbace_j2g_code__init_part1_A_Unit125__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(971, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_47; var tmp2 any = A_arbace_j2g_code_args_for_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_j2g_code_args_for_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_436, false); A_arbace_j2g_code_args_for_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_48)); return A_arbace_j2g_code__init_part1_A_const_47 }



func A_arbace_j2g_code__init_part1_A_Unit126__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(975, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_49; var tmp2 any = A_arbace_j2g_code_super_struct_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_code_super_struct_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_437, false); A_arbace_j2g_code_super_struct_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_50)); return A_arbace_j2g_code__init_part1_A_const_49 }





func A_arbace_j2g_code__init_part1_A_Unit127__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(981, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_51; var tmp2 any = A_arbace_j2g_code_vh_arg_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_j2g_code_vh_arg_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_438, false); A_arbace_j2g_code_vh_arg_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_52)); return A_arbace_j2g_code__init_part1_A_const_51 }








func A_arbace_j2g_code__init_part1_A_Unit128__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(990, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_53; var tmp2 any = A_arbace_j2g_code_vh_result_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_code_vh_result_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_439, false); A_arbace_j2g_code_vh_result_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_54)); return A_arbace_j2g_code__init_part1_A_const_53 }










func A_arbace_j2g_code__init_part1_A_Unit129__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1001, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_55; var tmp2 any = A_arbace_j2g_code_vh_field_form_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_code_vh_field_form_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_440, false); A_arbace_j2g_code_vh_field_form_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_56)); return A_arbace_j2g_code__init_part1_A_const_55 }













































func A_arbace_j2g_code__init_part1_A_Unit130__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1047, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_57; var tmp2 any = A_arbace_j2g_code_vh_val_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_code_vh_val_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_441, false); A_arbace_j2g_code_vh_val_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_58)); return A_arbace_j2g_code__init_part1_A_const_57 }







































func A_arbace_j2g_code__init_part1_A_Unit131__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1087, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_59; var tmp2 any = A_arbace_j2g_code_invoke_val_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_code_invoke_val_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_442, false); A_arbace_j2g_code_invoke_val_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_60)); return A_arbace_j2g_code__init_part1_A_const_59 }

























































































func A_arbace_j2g_code__init_part1_A_Unit132__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1177, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_61; var tmp2 any = A_arbace_j2g_code_ctor_args_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_code_ctor_args_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_443, false); A_arbace_j2g_code_ctor_args_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_62)); return A_arbace_j2g_code__init_part1_A_const_61 }



















func A_arbace_j2g_code__init_part1_A_Unit133__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1197, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_0; var tmp2 any = A_arbace_j2g_code_new_val_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_j2g_code_new_val_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_444, false); A_arbace_j2g_code_new_val_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_63)); return A_arbace_j2g_code__init_part1_A_const_0 }














func A_arbace_j2g_code__init_part1_A_Unit134__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1212, 1); A_arbace_j2g_code__init_part1_A_const_64.BindRoot_O__V(A_arbace_j2g_code__init_part1_A_const_65); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_66)); return A_arbace_j2g_code__init_part1_A_const_64 }



func A_arbace_j2g_code__init_part1_A_Unit135__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1216, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_67; var tmp2 any = A_arbace_j2g_code_utf8_safe_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_code_utf8_safe_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_445, false); A_arbace_j2g_code_utf8_safe_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_68)); return A_arbace_j2g_code__init_part1_A_const_67 }














func A_arbace_j2g_code__init_part1_A_Unit136__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1231, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_69; var tmp2 any = A_arbace_j2g_code_const_tree_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_j2g_code_const_tree_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_446, false); A_arbace_j2g_code_const_tree_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_70)); return A_arbace_j2g_code__init_part1_A_const_69 }
















func A_arbace_j2g_code__init_part1_A_Unit137__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1248, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_71; var tmp2 any = A_arbace_j2g_code_const_strings_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_code_const_strings_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_447, false); A_arbace_j2g_code_const_strings_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_72)); return A_arbace_j2g_code__init_part1_A_const_71 }





func A_arbace_j2g_code__init_part1_A_Unit138__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1254, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_73; var tmp2 any = A_arbace_j2g_code_const_encode_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_code_const_encode_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_448, false); A_arbace_j2g_code_const_encode_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_74)); return A_arbace_j2g_code__init_part1_A_const_73 }













func A_arbace_j2g_code__init_part1_A_Unit139__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1268, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_75; var tmp2 any = A_arbace_j2g_code_const_array_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_code_const_array_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_449, false); A_arbace_j2g_code_const_array_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_76)); return A_arbace_j2g_code__init_part1_A_const_75 }














func A_arbace_j2g_code__init_part1_A_Unit140__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1283, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_16; var tmp2 any = A_arbace_j2g_code_array_val_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_j2g_code_array_val_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_450, false); A_arbace_j2g_code_array_val_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_77)); return A_arbace_j2g_code__init_part1_A_const_16 }























func A_arbace_j2g_code__init_part1_A_Unit141__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1307, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_10; var tmp2 any = A_arbace_j2g_code_java_str_val_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_code_java_str_val_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_451, false); A_arbace_j2g_code_java_str_val_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_78)); return A_arbace_j2g_code__init_part1_A_const_10 }

























func A_arbace_j2g_code__init_part1_A_Unit142__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1333, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_79; var tmp2 any = A_arbace_j2g_code_target_info_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_j2g_code_target_info_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_452, false); A_arbace_j2g_code_target_info_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_80)); return A_arbace_j2g_code__init_part1_A_const_79 }

func A_arbace_j2g_code__init_part1_A_Unit143__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1335, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_81; var tmp2 any = A_arbace_j2g_code_code_jump_BANG__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_code_code_jump_BANG__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_453, false); A_arbace_j2g_code_code_jump_BANG__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_82)); return A_arbace_j2g_code__init_part1_A_const_81 }










func A_arbace_j2g_code__init_part1_A_Unit144__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1346, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_83; var tmp2 any = A_arbace_j2g_code_outside_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_j2g_code_outside_QMARK__A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_454, false); A_arbace_j2g_code_outside_QMARK__A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_84)); return A_arbace_j2g_code__init_part1_A_const_83 }

func A_arbace_j2g_code__init_part1_A_Unit145__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1348, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_85; var tmp2 any = A_arbace_j2g_code_method_return_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_code_method_return_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_455, false); A_arbace_j2g_code_method_return_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_86)); return A_arbace_j2g_code__init_part1_A_const_85 }






func A_arbace_j2g_code__init_part1_A_Unit146__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1355, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_87; var tmp2 any = A_arbace_j2g_code_set_static_BANG__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_j2g_code_set_static_BANG__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_456, false); A_arbace_j2g_code_set_static_BANG__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_88)); return A_arbace_j2g_code__init_part1_A_const_87 }











func A_arbace_j2g_code__init_part1_A_Unit147__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1367, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_89; var tmp2 any = A_arbace_j2g_code_dropped_store_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_code_dropped_store_QMARK__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_457, false); A_arbace_j2g_code_dropped_store_QMARK__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_90)); return A_arbace_j2g_code__init_part1_A_const_89 }



















func A_arbace_j2g_code__init_part1_A_Unit148__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1387, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_91; var tmp2 any = A_arbace_j2g_code_set_field_BANG__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_j2g_code_set_field_BANG__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_458, false); A_arbace_j2g_code_set_field_BANG__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_92)); return A_arbace_j2g_code__init_part1_A_const_91 }






func A_arbace_j2g_code__init_part1_A_Unit149__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1394, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_93; var tmp2 any = A_arbace_j2g_code_stmt_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_code_stmt_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_459, false); A_arbace_j2g_code_stmt_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_94)); return A_arbace_j2g_code__init_part1_A_const_93 }





func A_arbace_j2g_code__init_part1_A_Unit150__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1400, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_95; var tmp2 any = A_arbace_j2g_code_stmt_BANG__STAR__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_j2g_code_stmt_BANG__STAR__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_460, false); A_arbace_j2g_code_stmt_BANG__STAR__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_96)); return A_arbace_j2g_code__init_part1_A_const_95 }





















































func A_arbace_j2g_code__init_part1_A_Unit151__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1454, 1); A_arbace_j2g_code__init_part1_A_const_97.BindRoot_O__V(A_arbace_j2g_code__init_part1_A_const_98); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_97; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_99)); return A_arbace_j2g_code__init_part1_A_const_97 }



func A_arbace_j2g_code__init_part1_A_Unit152__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1458, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_100; var tmp2 any = A_arbace_j2g_code_go_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_code_go_call_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_461, false); A_arbace_j2g_code_go_call_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_101)); return A_arbace_j2g_code__init_part1_A_const_100 }









func A_arbace_j2g_code__init_part1_A_Unit153__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1468, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_102; var tmp2 any = A_arbace_j2g_code_assign_value_BANG__A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_j2g_code_assign_value_BANG__A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_462, false); A_arbace_j2g_code_assign_value_BANG__A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_103)); return A_arbace_j2g_code__init_part1_A_const_102 }





func A_arbace_j2g_code__init_part1_A_Unit154__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1474, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_104; var tmp2 any = A_arbace_j2g_code_assign_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_code_assign_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_463, false); A_arbace_j2g_code_assign_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_105)); return A_arbace_j2g_code__init_part1_A_const_104 }




func A_arbace_j2g_code__init_part1_A_Unit155__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1479, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_106; var tmp2 any = A_arbace_j2g_code_ret_BANG__A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_j2g_code_ret_BANG__A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_464, false); A_arbace_j2g_code_ret_BANG__A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_107)); return A_arbace_j2g_code__init_part1_A_const_106 }




func A_arbace_j2g_code__init_part1_A_Unit156__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1484, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_108; var tmp2 any = A_arbace_j2g_code_ctx_desc_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_code_ctx_desc_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_465, false); A_arbace_j2g_code_ctx_desc_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_109)); return A_arbace_j2g_code__init_part1_A_const_108 }

func A_arbace_j2g_code__init_part1_A_Unit157__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1486, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_110; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_111)); return A_arbace_j2g_code__init_part1_A_const_110 }
//line :1486:1
func A_arbace_j2g_code__init_part1_A_Unit158__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1486, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_112; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_113)); return A_arbace_j2g_code__init_part1_A_const_112 }
//line :1486:1
func A_arbace_j2g_code__init_part1_A_Unit159__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1486, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_114; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_115)); return A_arbace_j2g_code__init_part1_A_const_114 }
//line :1486:1
func A_arbace_j2g_code__init_part1_A_Unit160__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1486, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_116; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_117)); return A_arbace_j2g_code__init_part1_A_const_116 }
//line :1486:1
func A_arbace_j2g_code__init_part1_A_Unit161__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1486, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_118; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_119)); return A_arbace_j2g_code__init_part1_A_const_118 }
//line :1486:1
func A_arbace_j2g_code__init_part1_A_Unit162__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1486, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_120; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_121)); return A_arbace_j2g_code__init_part1_A_const_120 }
//line :1486:1
func A_arbace_j2g_code__init_part1_A_Unit163__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1486, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_122; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_123)); return A_arbace_j2g_code__init_part1_A_const_122 }
//line :1486:1
func A_arbace_j2g_code__init_part1_A_Unit164__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1486, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_124; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_125)); return A_arbace_j2g_code__init_part1_A_const_124 }


func A_arbace_j2g_code__init_part1_A_Unit165__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1489, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_126; var tmp2 any = A_arbace_j2g_code_translate_ctx_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_j2g_code_translate_ctx_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_466, false); A_arbace_j2g_code_translate_ctx_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_127)); return A_arbace_j2g_code__init_part1_A_const_126 }





func A_arbace_j2g_code__init_part1_A_Unit166__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1495, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_128; var tmp2 any = A_arbace_j2g_code_translate_ctx_STAR__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_code_translate_ctx_STAR__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_467, false); A_arbace_j2g_code_translate_ctx_STAR__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_129)); return A_arbace_j2g_code__init_part1_A_const_128 }




















































































































func A_arbace_j2g_code__init_part1_A_Unit167__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1612, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_124; var tmp2 any = A_arbace_j2g_code_translate_and_or_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_j2g_code_translate_and_or_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_468, false); A_arbace_j2g_code_translate_and_or_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_130)); return A_arbace_j2g_code__init_part1_A_const_124 }
























func A_arbace_j2g_code__init_part1_A_Unit168__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1637, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_131; var tmp2 any = A_arbace_j2g_code_new_label_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_code_new_label_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_469, false); A_arbace_j2g_code_new_label_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_132)); return A_arbace_j2g_code__init_part1_A_const_131 }

func A_arbace_j2g_code__init_part1_A_Unit169__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1639, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_114; var tmp2 any = A_arbace_j2g_code_translate_loop_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_j2g_code_translate_loop_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_470, false); A_arbace_j2g_code_translate_loop_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_133)); return A_arbace_j2g_code__init_part1_A_const_114 }






















func A_arbace_j2g_code__init_part1_A_Unit170__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1662, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_116; var tmp2 any = A_arbace_j2g_code_translate_label_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_code_translate_label_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_471, false); A_arbace_j2g_code_translate_label_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_134)); return A_arbace_j2g_code__init_part1_A_const_116 }








func A_arbace_j2g_code__init_part1_A_Unit171__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1671, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_120; var tmp2 any = A_arbace_j2g_code_translate_for_each_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_j2g_code_translate_for_each_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_472, false); A_arbace_j2g_code_translate_for_each_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_135)); return A_arbace_j2g_code__init_part1_A_const_120 }





































func A_arbace_j2g_code__init_part1_A_Unit172__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1709, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_136; var tmp2 any = A_arbace_j2g_code_pattern_bindings_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_code_pattern_bindings_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_473, false); A_arbace_j2g_code_pattern_bindings_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_137)); return A_arbace_j2g_code__init_part1_A_const_136 }


func A_arbace_j2g_code__init_part1_A_Unit173__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1712, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_138; var tmp2 any = A_arbace_j2g_code_record_pattern_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_j2g_code_record_pattern_QMARK__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_474, false); A_arbace_j2g_code_record_pattern_QMARK__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_139)); return A_arbace_j2g_code__init_part1_A_const_138 }

func A_arbace_j2g_code__init_part1_A_Unit174__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1714, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_140; var tmp2 any = A_arbace_j2g_code_derived_accessor_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_code_derived_accessor_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_475, false); A_arbace_j2g_code_derived_accessor_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_141)); return A_arbace_j2g_code__init_part1_A_const_140 }







func A_arbace_j2g_code__init_part1_A_Unit175__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1722, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_142; var tmp2 any = A_arbace_j2g_code_accessor_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_j2g_code_accessor_call_BANG__A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_476, false); A_arbace_j2g_code_accessor_call_BANG__A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_143)); return A_arbace_j2g_code__init_part1_A_const_142 }























func A_arbace_j2g_code__init_part1_A_Unit176__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1746, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_144; var tmp2 any = A_arbace_j2g_code_match_pattern_BANG__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_code_match_pattern_BANG__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_477, false); A_arbace_j2g_code_match_pattern_BANG__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_145)); return A_arbace_j2g_code__init_part1_A_const_144 }































func A_arbace_j2g_code__init_part1_A_Unit177__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1778, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_146; var tmp2 any = A_arbace_j2g_code_declare_pattern_BANG__A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_code_declare_pattern_BANG__A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_478, false); A_arbace_j2g_code_declare_pattern_BANG__A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_147)); return A_arbace_j2g_code__init_part1_A_const_146 }











func A_arbace_j2g_code__init_part1_A_Unit178__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1790, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_122; var tmp2 any = A_arbace_j2g_code_translate_if_instance_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_code_translate_if_instance_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_479, false); A_arbace_j2g_code_translate_if_instance_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_148)); return A_arbace_j2g_code__init_part1_A_const_122 }


















func A_arbace_j2g_code__init_part1_A_Unit179__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1809, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_149; var tmp2 any = A_arbace_j2g_code_enum_ordinal_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_j2g_code_enum_ordinal_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_480, false); A_arbace_j2g_code_enum_ordinal_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_150)); return A_arbace_j2g_code__init_part1_A_const_149 }







func A_arbace_j2g_code__init_part1_A_Unit180__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1817, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_118; var tmp2 any = A_arbace_j2g_code_translate_switch_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_code_translate_switch_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_481, false); A_arbace_j2g_code_translate_switch_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_151)); return A_arbace_j2g_code__init_part1_A_const_118 }

























































































































func A_arbace_j2g_code__init_part1_A_Unit181__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1939, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_152; var tmp2 any = A_arbace_j2g_code_live_catches_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_j2g_code_live_catches_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_482, false); A_arbace_j2g_code_live_catches_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_153)); return A_arbace_j2g_code__init_part1_A_const_152 }




func A_arbace_j2g_code__init_part1_A_Unit182__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1944, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_154; var tmp2 any = A_arbace_j2g_code_try_literal_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_j2g_code_try_literal_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_483, false); A_arbace_j2g_code_try_literal_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_155)); return A_arbace_j2g_code__init_part1_A_const_154 }
















func A_arbace_j2g_code__init_part1_A_Unit183__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1961, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_156; var tmp2 any = A_arbace_j2g_code_dispatch_codes_BANG__A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_j2g_code_dispatch_codes_BANG__A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_484, false); A_arbace_j2g_code_dispatch_codes_BANG__A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_157)); return A_arbace_j2g_code__init_part1_A_const_156 }




















func A_arbace_j2g_code__init_part1_A_Unit184__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1982, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_158; var tmp2 any = A_arbace_j2g_code_literal_form_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_code_literal_form_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_485, false); A_arbace_j2g_code_literal_form_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_159)); return A_arbace_j2g_code__init_part1_A_const_158 }






















func A_arbace_j2g_code__init_part1_A_Unit185__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2005, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_110; var tmp2 any = A_arbace_j2g_code_translate_try_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_j2g_code_translate_try_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_486, false); A_arbace_j2g_code_translate_try_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_160)); return A_arbace_j2g_code__init_part1_A_const_110 }








































































func A_arbace_j2g_code__init_part1_A_Unit186__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2078, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_112; var tmp2 any = A_arbace_j2g_code_translate_monitor_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_code_translate_monitor_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_487, false); A_arbace_j2g_code_translate_monitor_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_161)); return A_arbace_j2g_code__init_part1_A_const_112 }
























func A_arbace_j2g_code__init_part1_A_Unit187__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2103, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_162; var tmp2 any = A_arbace_j2g_code_sam_sig_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_j2g_code_sam_sig_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_488, false); A_arbace_j2g_code_sam_sig_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_163)); return A_arbace_j2g_code__init_part1_A_const_162 }




func A_arbace_j2g_code__init_part1_A_Unit188__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2108, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_164; var tmp2 any = A_arbace_j2g_code_lambda_markers_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_j2g_code_lambda_markers_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_489, false); A_arbace_j2g_code_lambda_markers_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_165)); return A_arbace_j2g_code__init_part1_A_const_164 }










func A_arbace_j2g_code__init_part1_A_Unit189__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2119, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_166; var tmp2 any = A_arbace_j2g_code_adapter_sym_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_code_adapter_sym_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_490, false); A_arbace_j2g_code_adapter_sym_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_167)); return A_arbace_j2g_code__init_part1_A_const_166 }







func A_arbace_j2g_code__init_part1_A_Unit190__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2127, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_168; var tmp2 any = A_arbace_j2g_code_convert_ref_or_prim_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_code_convert_ref_or_prim_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_491, false); A_arbace_j2g_code_convert_ref_or_prim_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_169)); return A_arbace_j2g_code__init_part1_A_const_168 }













func A_arbace_j2g_code__init_part1_A_Unit191__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2141, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_12; var tmp2 any = A_arbace_j2g_code_lambda_val_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_j2g_code_lambda_val_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_492, false); A_arbace_j2g_code_lambda_val_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_170)); return A_arbace_j2g_code__init_part1_A_const_12 }






















func A_arbace_j2g_code__init_part1_A_Unit192__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2164, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_20; var tmp2 any = A_arbace_j2g_code_fi_adapter_val_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_code_fi_adapter_val_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_493, false); A_arbace_j2g_code_fi_adapter_val_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_171)); return A_arbace_j2g_code__init_part1_A_const_20 }

























func A_arbace_j2g_code__init_part1_A_Unit193__O() any { A_arbace_j2g_code__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2190, 1); var tmp1 *lang.Var = A_arbace_j2g_code__init_part1_A_const_14; var tmp2 any = A_arbace_j2g_code_method_ref_val_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_j2g_code_method_ref_val_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_494, false); A_arbace_j2g_code_method_ref_val_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_j2g_code__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_code__init_part1_A_const_172)); return A_arbace_j2g_code__init_part1_A_const_14 }



type A_arbace_j2g_code__init_A struct{ jrt.Object }

func A_arbace_j2g_code__init_A_New() *A_arbace_j2g_code__init_A { t := &A_arbace_j2g_code__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_code__init_A) Ctor() {}

func (t *A_arbace_j2g_code__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_code__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_code__init_A_class }

func (t *A_arbace_j2g_code__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_code__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_code__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_code__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_code__init_A); return ok }

func A_arbace_j2g_code__init_A_Cast(x any) *A_arbace_j2g_code__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_code__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_code__init_A_class)) }; return v }



type A_arbace_j2g_code__init_part0_A struct{ jrt.Object }

var A_arbace_j2g_code__init_part0_A_const_pool *jrt.RefArray

var A_arbace_j2g_code__init_part0_A_const_0 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_1 any

var A_arbace_j2g_code__init_part0_A_const_2 any

var A_arbace_j2g_code__init_part0_A_const_3 any

var A_arbace_j2g_code__init_part0_A_const_4 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_5 any

var A_arbace_j2g_code__init_part0_A_const_6 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_7 any

var A_arbace_j2g_code__init_part0_A_const_8 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_9 any

var A_arbace_j2g_code__init_part0_A_const_10 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_11 any

var A_arbace_j2g_code__init_part0_A_const_12 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_13 any

var A_arbace_j2g_code__init_part0_A_const_14 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_15 any

var A_arbace_j2g_code__init_part0_A_const_16 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_17 any

var A_arbace_j2g_code__init_part0_A_const_18 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_19 any

var A_arbace_j2g_code__init_part0_A_const_20 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_21 any

var A_arbace_j2g_code__init_part0_A_const_22 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_23 any

var A_arbace_j2g_code__init_part0_A_const_24 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_25 any

var A_arbace_j2g_code__init_part0_A_const_26 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_27 any

var A_arbace_j2g_code__init_part0_A_const_28 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_29 any

var A_arbace_j2g_code__init_part0_A_const_30 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_31 any

var A_arbace_j2g_code__init_part0_A_const_32 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_33 any

var A_arbace_j2g_code__init_part0_A_const_34 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_35 any

var A_arbace_j2g_code__init_part0_A_const_36 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_37 any

var A_arbace_j2g_code__init_part0_A_const_38 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_39 any

var A_arbace_j2g_code__init_part0_A_const_40 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_41 any

var A_arbace_j2g_code__init_part0_A_const_42 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_43 any

var A_arbace_j2g_code__init_part0_A_const_44 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_45 any

var A_arbace_j2g_code__init_part0_A_const_46 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_47 any

var A_arbace_j2g_code__init_part0_A_const_48 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_49 any

var A_arbace_j2g_code__init_part0_A_const_50 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_51 any

var A_arbace_j2g_code__init_part0_A_const_52 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_53 any

var A_arbace_j2g_code__init_part0_A_const_54 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_55 any

var A_arbace_j2g_code__init_part0_A_const_56 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_57 any

var A_arbace_j2g_code__init_part0_A_const_58 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_59 any

var A_arbace_j2g_code__init_part0_A_const_60 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_61 any

var A_arbace_j2g_code__init_part0_A_const_62 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_63 any

var A_arbace_j2g_code__init_part0_A_const_64 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_65 any

var A_arbace_j2g_code__init_part0_A_const_66 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_67 any

var A_arbace_j2g_code__init_part0_A_const_68 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_69 any

var A_arbace_j2g_code__init_part0_A_const_70 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_71 any

var A_arbace_j2g_code__init_part0_A_const_72 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_73 any

var A_arbace_j2g_code__init_part0_A_const_74 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_75 any

var A_arbace_j2g_code__init_part0_A_const_76 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_77 any

var A_arbace_j2g_code__init_part0_A_const_78 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_79 any

var A_arbace_j2g_code__init_part0_A_const_80 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_81 any

var A_arbace_j2g_code__init_part0_A_const_82 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_83 any

var A_arbace_j2g_code__init_part0_A_const_84 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_85 any

var A_arbace_j2g_code__init_part0_A_const_86 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_87 any

var A_arbace_j2g_code__init_part0_A_const_88 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_89 any

var A_arbace_j2g_code__init_part0_A_const_90 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_91 any

var A_arbace_j2g_code__init_part0_A_const_92 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_93 any

var A_arbace_j2g_code__init_part0_A_const_94 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_95 any

var A_arbace_j2g_code__init_part0_A_const_96 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_97 any

var A_arbace_j2g_code__init_part0_A_const_98 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_99 any

var A_arbace_j2g_code__init_part0_A_const_100 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_101 any

var A_arbace_j2g_code__init_part0_A_const_102 any

var A_arbace_j2g_code__init_part0_A_const_103 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_104 any

var A_arbace_j2g_code__init_part0_A_const_105 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_106 any

var A_arbace_j2g_code__init_part0_A_const_107 any

var A_arbace_j2g_code__init_part0_A_const_108 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_109 any

var A_arbace_j2g_code__init_part0_A_const_110 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_111 any

var A_arbace_j2g_code__init_part0_A_const_112 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_113 any

var A_arbace_j2g_code__init_part0_A_const_114 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_115 any

var A_arbace_j2g_code__init_part0_A_const_116 any

var A_arbace_j2g_code__init_part0_A_const_117 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_118 any

var A_arbace_j2g_code__init_part0_A_const_119 any

var A_arbace_j2g_code__init_part0_A_const_120 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_121 any

var A_arbace_j2g_code__init_part0_A_const_122 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_123 any

var A_arbace_j2g_code__init_part0_A_const_124 any

var A_arbace_j2g_code__init_part0_A_const_125 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_126 any

var A_arbace_j2g_code__init_part0_A_const_127 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_128 any

var A_arbace_j2g_code__init_part0_A_const_129 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_130 any

var A_arbace_j2g_code__init_part0_A_const_131 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_132 any

var A_arbace_j2g_code__init_part0_A_const_133 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_134 any

var A_arbace_j2g_code__init_part0_A_const_135 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_136 any

var A_arbace_j2g_code__init_part0_A_const_137 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_138 any

var A_arbace_j2g_code__init_part0_A_const_139 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_140 any

var A_arbace_j2g_code__init_part0_A_const_141 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_142 any

var A_arbace_j2g_code__init_part0_A_const_143 any

var A_arbace_j2g_code__init_part0_A_const_144 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_145 any

var A_arbace_j2g_code__init_part0_A_const_146 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_147 any

var A_arbace_j2g_code__init_part0_A_const_148 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_149 any

var A_arbace_j2g_code__init_part0_A_const_150 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_151 any

var A_arbace_j2g_code__init_part0_A_const_152 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_153 any

var A_arbace_j2g_code__init_part0_A_const_154 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_155 any

var A_arbace_j2g_code__init_part0_A_const_156 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_157 any

var A_arbace_j2g_code__init_part0_A_const_158 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_159 any

var A_arbace_j2g_code__init_part0_A_const_160 any

var A_arbace_j2g_code__init_part0_A_const_161 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_162 any

var A_arbace_j2g_code__init_part0_A_const_163 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_164 any

var A_arbace_j2g_code__init_part0_A_const_165 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_166 any

var A_arbace_j2g_code__init_part0_A_const_167 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_168 any

var A_arbace_j2g_code__init_part0_A_const_169 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_170 any

var A_arbace_j2g_code__init_part0_A_const_171 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_172 any

var A_arbace_j2g_code__init_part0_A_const_173 any

var A_arbace_j2g_code__init_part0_A_const_174 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_175 any

var A_arbace_j2g_code__init_part0_A_const_176 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_177 any

var A_arbace_j2g_code__init_part0_A_const_178 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_179 any

var A_arbace_j2g_code__init_part0_A_const_180 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_181 any

var A_arbace_j2g_code__init_part0_A_const_182 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_183 any

var A_arbace_j2g_code__init_part0_A_const_184 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_185 any

var A_arbace_j2g_code__init_part0_A_const_186 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_187 any

var A_arbace_j2g_code__init_part0_A_const_188 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_189 any

var A_arbace_j2g_code__init_part0_A_const_190 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_191 any

var A_arbace_j2g_code__init_part0_A_const_192 *lang.Var

var A_arbace_j2g_code__init_part0_A_const_193 any

var A_arbace_j2g_code__init_part0_A_init jrt.ClassInit

func A_arbace_j2g_code__init_part0_A_Init() { if !A_arbace_j2g_code__init_part0_A_init.Done() { A_arbace_j2g_code__init_part0_A_init.Run(A_arbace_j2g_code__init_part0_A_clinit) } }

func A_arbace_j2g_code__init_part0_A_clinit() { A_arbace_j2g_code__init_part0_A_clinit_p0(); A_arbace_j2g_code__init_part0_A_clinit_p1(); A_arbace_j2g_code__init_part0_A_clinit_p2(); A_arbace_j2g_code__init_part0_A_clinit_p3(); A_arbace_j2g_code__init_part0_A_clinit_p4(); A_arbace_j2g_code__init_part0_A_clinit_p5(); A_arbace_j2g_code__init_part0_A_clinit_p6(); A_arbace_j2g_code__init_part0_A_clinit_p7(); A_arbace_j2g_code__init_part0_A_clinit_p8(); A_arbace_j2g_code__init_part0_A_clinit_p9(); A_arbace_j2g_code__init_part0_A_clinit_p10(); A_arbace_j2g_code__init_part0_A_clinit_p11(); A_arbace_j2g_code__init_part0_A_clinit_p12(); A_arbace_j2g_code__init_part0_A_clinit_p13(); A_arbace_j2g_code__init_part0_A_clinit_p14() }

func A_arbace_j2g_code__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_code__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_351, 288); A_arbace_j2g_code__init_part0_A_const_0 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[94]); A_arbace_j2g_code__init_part0_A_const_1 = A_arbace_j2g_code__init_part0_A_const_pool.A[95]; A_arbace_j2g_code__init_part0_A_const_2 = A_arbace_j2g_code__init_part0_A_const_pool.A[96]; A_arbace_j2g_code__init_part0_A_const_3 = A_arbace_j2g_code__init_part0_A_const_pool.A[97]; A_arbace_j2g_code__init_part0_A_const_4 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[98]); A_arbace_j2g_code__init_part0_A_const_5 = A_arbace_j2g_code__init_part0_A_const_pool.A[99]; A_arbace_j2g_code__init_part0_A_const_6 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[100]); A_arbace_j2g_code__init_part0_A_const_7 = A_arbace_j2g_code__init_part0_A_const_pool.A[101]; A_arbace_j2g_code__init_part0_A_const_8 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[102]); A_arbace_j2g_code__init_part0_A_const_9 = A_arbace_j2g_code__init_part0_A_const_pool.A[103]; A_arbace_j2g_code__init_part0_A_const_10 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[104]); A_arbace_j2g_code__init_part0_A_const_11 = A_arbace_j2g_code__init_part0_A_const_pool.A[105]; A_arbace_j2g_code__init_part0_A_const_12 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[106]) }

func A_arbace_j2g_code__init_part0_A_clinit_p1() { A_arbace_j2g_code__init_part0_A_const_13 = A_arbace_j2g_code__init_part0_A_const_pool.A[107]; A_arbace_j2g_code__init_part0_A_const_14 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[108]); A_arbace_j2g_code__init_part0_A_const_15 = A_arbace_j2g_code__init_part0_A_const_pool.A[109]; A_arbace_j2g_code__init_part0_A_const_16 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[110]); A_arbace_j2g_code__init_part0_A_const_17 = A_arbace_j2g_code__init_part0_A_const_pool.A[111]; A_arbace_j2g_code__init_part0_A_const_18 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[112]); A_arbace_j2g_code__init_part0_A_const_19 = A_arbace_j2g_code__init_part0_A_const_pool.A[113]; A_arbace_j2g_code__init_part0_A_const_20 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[114]); A_arbace_j2g_code__init_part0_A_const_21 = A_arbace_j2g_code__init_part0_A_const_pool.A[115]; A_arbace_j2g_code__init_part0_A_const_22 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[116]); A_arbace_j2g_code__init_part0_A_const_23 = A_arbace_j2g_code__init_part0_A_const_pool.A[117]; A_arbace_j2g_code__init_part0_A_const_24 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[118]); A_arbace_j2g_code__init_part0_A_const_25 = A_arbace_j2g_code__init_part0_A_const_pool.A[119] }

func A_arbace_j2g_code__init_part0_A_clinit_p2() { A_arbace_j2g_code__init_part0_A_const_26 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[120]); A_arbace_j2g_code__init_part0_A_const_27 = A_arbace_j2g_code__init_part0_A_const_pool.A[121]; A_arbace_j2g_code__init_part0_A_const_28 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[122]); A_arbace_j2g_code__init_part0_A_const_29 = A_arbace_j2g_code__init_part0_A_const_pool.A[123]; A_arbace_j2g_code__init_part0_A_const_30 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[124]); A_arbace_j2g_code__init_part0_A_const_31 = A_arbace_j2g_code__init_part0_A_const_pool.A[125]; A_arbace_j2g_code__init_part0_A_const_32 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[126]); A_arbace_j2g_code__init_part0_A_const_33 = A_arbace_j2g_code__init_part0_A_const_pool.A[127]; A_arbace_j2g_code__init_part0_A_const_34 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[128]); A_arbace_j2g_code__init_part0_A_const_35 = A_arbace_j2g_code__init_part0_A_const_pool.A[129]; A_arbace_j2g_code__init_part0_A_const_36 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[130]); A_arbace_j2g_code__init_part0_A_const_37 = A_arbace_j2g_code__init_part0_A_const_pool.A[131]; A_arbace_j2g_code__init_part0_A_const_38 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[132]) }

func A_arbace_j2g_code__init_part0_A_clinit_p3() { A_arbace_j2g_code__init_part0_A_const_39 = A_arbace_j2g_code__init_part0_A_const_pool.A[133]; A_arbace_j2g_code__init_part0_A_const_40 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[134]); A_arbace_j2g_code__init_part0_A_const_41 = A_arbace_j2g_code__init_part0_A_const_pool.A[135]; A_arbace_j2g_code__init_part0_A_const_42 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[136]); A_arbace_j2g_code__init_part0_A_const_43 = A_arbace_j2g_code__init_part0_A_const_pool.A[137]; A_arbace_j2g_code__init_part0_A_const_44 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[138]); A_arbace_j2g_code__init_part0_A_const_45 = A_arbace_j2g_code__init_part0_A_const_pool.A[139]; A_arbace_j2g_code__init_part0_A_const_46 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[140]); A_arbace_j2g_code__init_part0_A_const_47 = A_arbace_j2g_code__init_part0_A_const_pool.A[141]; A_arbace_j2g_code__init_part0_A_const_48 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[142]); A_arbace_j2g_code__init_part0_A_const_49 = A_arbace_j2g_code__init_part0_A_const_pool.A[143]; A_arbace_j2g_code__init_part0_A_const_50 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[144]); A_arbace_j2g_code__init_part0_A_const_51 = A_arbace_j2g_code__init_part0_A_const_pool.A[145] }

func A_arbace_j2g_code__init_part0_A_clinit_p4() { A_arbace_j2g_code__init_part0_A_const_52 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[146]); A_arbace_j2g_code__init_part0_A_const_53 = A_arbace_j2g_code__init_part0_A_const_pool.A[147]; A_arbace_j2g_code__init_part0_A_const_54 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[148]); A_arbace_j2g_code__init_part0_A_const_55 = A_arbace_j2g_code__init_part0_A_const_pool.A[149]; A_arbace_j2g_code__init_part0_A_const_56 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[150]); A_arbace_j2g_code__init_part0_A_const_57 = A_arbace_j2g_code__init_part0_A_const_pool.A[151]; A_arbace_j2g_code__init_part0_A_const_58 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[152]); A_arbace_j2g_code__init_part0_A_const_59 = A_arbace_j2g_code__init_part0_A_const_pool.A[153]; A_arbace_j2g_code__init_part0_A_const_60 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[154]); A_arbace_j2g_code__init_part0_A_const_61 = A_arbace_j2g_code__init_part0_A_const_pool.A[155]; A_arbace_j2g_code__init_part0_A_const_62 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[156]); A_arbace_j2g_code__init_part0_A_const_63 = A_arbace_j2g_code__init_part0_A_const_pool.A[157]; A_arbace_j2g_code__init_part0_A_const_64 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[158]) }

func A_arbace_j2g_code__init_part0_A_clinit_p5() { A_arbace_j2g_code__init_part0_A_const_65 = A_arbace_j2g_code__init_part0_A_const_pool.A[159]; A_arbace_j2g_code__init_part0_A_const_66 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[160]); A_arbace_j2g_code__init_part0_A_const_67 = A_arbace_j2g_code__init_part0_A_const_pool.A[161]; A_arbace_j2g_code__init_part0_A_const_68 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[162]); A_arbace_j2g_code__init_part0_A_const_69 = A_arbace_j2g_code__init_part0_A_const_pool.A[163]; A_arbace_j2g_code__init_part0_A_const_70 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[164]); A_arbace_j2g_code__init_part0_A_const_71 = A_arbace_j2g_code__init_part0_A_const_pool.A[165]; A_arbace_j2g_code__init_part0_A_const_72 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[166]); A_arbace_j2g_code__init_part0_A_const_73 = A_arbace_j2g_code__init_part0_A_const_pool.A[167]; A_arbace_j2g_code__init_part0_A_const_74 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[168]); A_arbace_j2g_code__init_part0_A_const_75 = A_arbace_j2g_code__init_part0_A_const_pool.A[169]; A_arbace_j2g_code__init_part0_A_const_76 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[170]); A_arbace_j2g_code__init_part0_A_const_77 = A_arbace_j2g_code__init_part0_A_const_pool.A[171] }

func A_arbace_j2g_code__init_part0_A_clinit_p6() { A_arbace_j2g_code__init_part0_A_const_78 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[172]); A_arbace_j2g_code__init_part0_A_const_79 = A_arbace_j2g_code__init_part0_A_const_pool.A[173]; A_arbace_j2g_code__init_part0_A_const_80 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[174]); A_arbace_j2g_code__init_part0_A_const_81 = A_arbace_j2g_code__init_part0_A_const_pool.A[175]; A_arbace_j2g_code__init_part0_A_const_82 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[176]); A_arbace_j2g_code__init_part0_A_const_83 = A_arbace_j2g_code__init_part0_A_const_pool.A[177]; A_arbace_j2g_code__init_part0_A_const_84 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[178]); A_arbace_j2g_code__init_part0_A_const_85 = A_arbace_j2g_code__init_part0_A_const_pool.A[179]; A_arbace_j2g_code__init_part0_A_const_86 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[180]); A_arbace_j2g_code__init_part0_A_const_87 = A_arbace_j2g_code__init_part0_A_const_pool.A[181]; A_arbace_j2g_code__init_part0_A_const_88 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[182]); A_arbace_j2g_code__init_part0_A_const_89 = A_arbace_j2g_code__init_part0_A_const_pool.A[183]; A_arbace_j2g_code__init_part0_A_const_90 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[184]) }

func A_arbace_j2g_code__init_part0_A_clinit_p7() { A_arbace_j2g_code__init_part0_A_const_91 = A_arbace_j2g_code__init_part0_A_const_pool.A[185]; A_arbace_j2g_code__init_part0_A_const_92 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[186]); A_arbace_j2g_code__init_part0_A_const_93 = A_arbace_j2g_code__init_part0_A_const_pool.A[187]; A_arbace_j2g_code__init_part0_A_const_94 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[188]); A_arbace_j2g_code__init_part0_A_const_95 = A_arbace_j2g_code__init_part0_A_const_pool.A[189]; A_arbace_j2g_code__init_part0_A_const_96 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[190]); A_arbace_j2g_code__init_part0_A_const_97 = A_arbace_j2g_code__init_part0_A_const_pool.A[191]; A_arbace_j2g_code__init_part0_A_const_98 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[192]); A_arbace_j2g_code__init_part0_A_const_99 = A_arbace_j2g_code__init_part0_A_const_pool.A[193]; A_arbace_j2g_code__init_part0_A_const_100 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[194]); A_arbace_j2g_code__init_part0_A_const_101 = A_arbace_j2g_code__init_part0_A_const_pool.A[195]; A_arbace_j2g_code__init_part0_A_const_102 = A_arbace_j2g_code__init_part0_A_const_pool.A[196]; A_arbace_j2g_code__init_part0_A_const_103 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[197]); A_arbace_j2g_code__init_part0_A_const_104 = A_arbace_j2g_code__init_part0_A_const_pool.A[198] }

func A_arbace_j2g_code__init_part0_A_clinit_p8() { A_arbace_j2g_code__init_part0_A_const_105 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[199]); A_arbace_j2g_code__init_part0_A_const_106 = A_arbace_j2g_code__init_part0_A_const_pool.A[200]; A_arbace_j2g_code__init_part0_A_const_107 = A_arbace_j2g_code__init_part0_A_const_pool.A[201]; A_arbace_j2g_code__init_part0_A_const_108 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[202]); A_arbace_j2g_code__init_part0_A_const_109 = A_arbace_j2g_code__init_part0_A_const_pool.A[203]; A_arbace_j2g_code__init_part0_A_const_110 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[204]); A_arbace_j2g_code__init_part0_A_const_111 = A_arbace_j2g_code__init_part0_A_const_pool.A[205]; A_arbace_j2g_code__init_part0_A_const_112 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[206]); A_arbace_j2g_code__init_part0_A_const_113 = A_arbace_j2g_code__init_part0_A_const_pool.A[207]; A_arbace_j2g_code__init_part0_A_const_114 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[208]); A_arbace_j2g_code__init_part0_A_const_115 = A_arbace_j2g_code__init_part0_A_const_pool.A[209]; A_arbace_j2g_code__init_part0_A_const_116 = A_arbace_j2g_code__init_part0_A_const_pool.A[210]; A_arbace_j2g_code__init_part0_A_const_117 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[211]); A_arbace_j2g_code__init_part0_A_const_118 = A_arbace_j2g_code__init_part0_A_const_pool.A[212] }

func A_arbace_j2g_code__init_part0_A_clinit_p9() { A_arbace_j2g_code__init_part0_A_const_119 = A_arbace_j2g_code__init_part0_A_const_pool.A[213]; A_arbace_j2g_code__init_part0_A_const_120 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[214]); A_arbace_j2g_code__init_part0_A_const_121 = A_arbace_j2g_code__init_part0_A_const_pool.A[215]; A_arbace_j2g_code__init_part0_A_const_122 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[216]); A_arbace_j2g_code__init_part0_A_const_123 = A_arbace_j2g_code__init_part0_A_const_pool.A[217]; A_arbace_j2g_code__init_part0_A_const_124 = A_arbace_j2g_code__init_part0_A_const_pool.A[218]; A_arbace_j2g_code__init_part0_A_const_125 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[219]); A_arbace_j2g_code__init_part0_A_const_126 = A_arbace_j2g_code__init_part0_A_const_pool.A[220]; A_arbace_j2g_code__init_part0_A_const_127 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[221]); A_arbace_j2g_code__init_part0_A_const_128 = A_arbace_j2g_code__init_part0_A_const_pool.A[222]; A_arbace_j2g_code__init_part0_A_const_129 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[223]); A_arbace_j2g_code__init_part0_A_const_130 = A_arbace_j2g_code__init_part0_A_const_pool.A[224]; A_arbace_j2g_code__init_part0_A_const_131 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[225]); A_arbace_j2g_code__init_part0_A_const_132 = A_arbace_j2g_code__init_part0_A_const_pool.A[226] }

func A_arbace_j2g_code__init_part0_A_clinit_p10() { A_arbace_j2g_code__init_part0_A_const_133 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[227]); A_arbace_j2g_code__init_part0_A_const_134 = A_arbace_j2g_code__init_part0_A_const_pool.A[228]; A_arbace_j2g_code__init_part0_A_const_135 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[229]); A_arbace_j2g_code__init_part0_A_const_136 = A_arbace_j2g_code__init_part0_A_const_pool.A[230]; A_arbace_j2g_code__init_part0_A_const_137 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[231]); A_arbace_j2g_code__init_part0_A_const_138 = A_arbace_j2g_code__init_part0_A_const_pool.A[232]; A_arbace_j2g_code__init_part0_A_const_139 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[233]); A_arbace_j2g_code__init_part0_A_const_140 = A_arbace_j2g_code__init_part0_A_const_pool.A[234]; A_arbace_j2g_code__init_part0_A_const_141 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[235]); A_arbace_j2g_code__init_part0_A_const_142 = A_arbace_j2g_code__init_part0_A_const_pool.A[236]; A_arbace_j2g_code__init_part0_A_const_143 = A_arbace_j2g_code__init_part0_A_const_pool.A[237]; A_arbace_j2g_code__init_part0_A_const_144 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[238]); A_arbace_j2g_code__init_part0_A_const_145 = A_arbace_j2g_code__init_part0_A_const_pool.A[239] }

func A_arbace_j2g_code__init_part0_A_clinit_p11() { A_arbace_j2g_code__init_part0_A_const_146 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[240]); A_arbace_j2g_code__init_part0_A_const_147 = A_arbace_j2g_code__init_part0_A_const_pool.A[241]; A_arbace_j2g_code__init_part0_A_const_148 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[242]); A_arbace_j2g_code__init_part0_A_const_149 = A_arbace_j2g_code__init_part0_A_const_pool.A[243]; A_arbace_j2g_code__init_part0_A_const_150 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[244]); A_arbace_j2g_code__init_part0_A_const_151 = A_arbace_j2g_code__init_part0_A_const_pool.A[245]; A_arbace_j2g_code__init_part0_A_const_152 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[246]); A_arbace_j2g_code__init_part0_A_const_153 = A_arbace_j2g_code__init_part0_A_const_pool.A[247]; A_arbace_j2g_code__init_part0_A_const_154 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[248]); A_arbace_j2g_code__init_part0_A_const_155 = A_arbace_j2g_code__init_part0_A_const_pool.A[249]; A_arbace_j2g_code__init_part0_A_const_156 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[250]); A_arbace_j2g_code__init_part0_A_const_157 = A_arbace_j2g_code__init_part0_A_const_pool.A[251]; A_arbace_j2g_code__init_part0_A_const_158 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[252]) }

func A_arbace_j2g_code__init_part0_A_clinit_p12() { A_arbace_j2g_code__init_part0_A_const_159 = A_arbace_j2g_code__init_part0_A_const_pool.A[253]; A_arbace_j2g_code__init_part0_A_const_160 = A_arbace_j2g_code__init_part0_A_const_pool.A[254]; A_arbace_j2g_code__init_part0_A_const_161 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[255]); A_arbace_j2g_code__init_part0_A_const_162 = A_arbace_j2g_code__init_part0_A_const_pool.A[256]; A_arbace_j2g_code__init_part0_A_const_163 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[257]); A_arbace_j2g_code__init_part0_A_const_164 = A_arbace_j2g_code__init_part0_A_const_pool.A[258]; A_arbace_j2g_code__init_part0_A_const_165 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[259]); A_arbace_j2g_code__init_part0_A_const_166 = A_arbace_j2g_code__init_part0_A_const_pool.A[260]; A_arbace_j2g_code__init_part0_A_const_167 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[261]); A_arbace_j2g_code__init_part0_A_const_168 = A_arbace_j2g_code__init_part0_A_const_pool.A[262]; A_arbace_j2g_code__init_part0_A_const_169 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[263]); A_arbace_j2g_code__init_part0_A_const_170 = A_arbace_j2g_code__init_part0_A_const_pool.A[264]; A_arbace_j2g_code__init_part0_A_const_171 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[265]); A_arbace_j2g_code__init_part0_A_const_172 = A_arbace_j2g_code__init_part0_A_const_pool.A[266] }

func A_arbace_j2g_code__init_part0_A_clinit_p13() { A_arbace_j2g_code__init_part0_A_const_173 = A_arbace_j2g_code__init_part0_A_const_pool.A[267]; A_arbace_j2g_code__init_part0_A_const_174 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[268]); A_arbace_j2g_code__init_part0_A_const_175 = A_arbace_j2g_code__init_part0_A_const_pool.A[269]; A_arbace_j2g_code__init_part0_A_const_176 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[270]); A_arbace_j2g_code__init_part0_A_const_177 = A_arbace_j2g_code__init_part0_A_const_pool.A[271]; A_arbace_j2g_code__init_part0_A_const_178 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[272]); A_arbace_j2g_code__init_part0_A_const_179 = A_arbace_j2g_code__init_part0_A_const_pool.A[273]; A_arbace_j2g_code__init_part0_A_const_180 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[274]); A_arbace_j2g_code__init_part0_A_const_181 = A_arbace_j2g_code__init_part0_A_const_pool.A[275]; A_arbace_j2g_code__init_part0_A_const_182 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[276]); A_arbace_j2g_code__init_part0_A_const_183 = A_arbace_j2g_code__init_part0_A_const_pool.A[277]; A_arbace_j2g_code__init_part0_A_const_184 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[278]); A_arbace_j2g_code__init_part0_A_const_185 = A_arbace_j2g_code__init_part0_A_const_pool.A[279] }

func A_arbace_j2g_code__init_part0_A_clinit_p14() { A_arbace_j2g_code__init_part0_A_const_186 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[280]); A_arbace_j2g_code__init_part0_A_const_187 = A_arbace_j2g_code__init_part0_A_const_pool.A[281]; A_arbace_j2g_code__init_part0_A_const_188 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[282]); A_arbace_j2g_code__init_part0_A_const_189 = A_arbace_j2g_code__init_part0_A_const_pool.A[283]; A_arbace_j2g_code__init_part0_A_const_190 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[284]); A_arbace_j2g_code__init_part0_A_const_191 = A_arbace_j2g_code__init_part0_A_const_pool.A[285]; A_arbace_j2g_code__init_part0_A_const_192 = lang.Var_Cast(A_arbace_j2g_code__init_part0_A_const_pool.A[286]); A_arbace_j2g_code__init_part0_A_const_193 = A_arbace_j2g_code__init_part0_A_const_pool.A[287] }

func A_arbace_j2g_code__init_part0_A_New() *A_arbace_j2g_code__init_part0_A { A_arbace_j2g_code__init_part0_A_Init(); t := &A_arbace_j2g_code__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_code__init_part0_A) Ctor() {}

func (t *A_arbace_j2g_code__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_code__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_code__init_part0_A_class }

func (t *A_arbace_j2g_code__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_code__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_code__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_code__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_code__init_part0_A); return ok }

func A_arbace_j2g_code__init_part0_A_Cast(x any) *A_arbace_j2g_code__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_code__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_code__init_part0_A_class)) }; return v }



type A_arbace_j2g_code__init_part1_A struct{ jrt.Object }

var A_arbace_j2g_code__init_part1_A_const_pool *jrt.RefArray

var A_arbace_j2g_code__init_part1_A_const_0 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_1 any

var A_arbace_j2g_code__init_part1_A_const_2 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_3 any

var A_arbace_j2g_code__init_part1_A_const_4 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_5 any

var A_arbace_j2g_code__init_part1_A_const_6 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_7 any

var A_arbace_j2g_code__init_part1_A_const_8 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_9 any

var A_arbace_j2g_code__init_part1_A_const_10 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_11 any

var A_arbace_j2g_code__init_part1_A_const_12 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_13 any

var A_arbace_j2g_code__init_part1_A_const_14 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_15 any

var A_arbace_j2g_code__init_part1_A_const_16 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_17 any

var A_arbace_j2g_code__init_part1_A_const_18 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_19 any

var A_arbace_j2g_code__init_part1_A_const_20 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_21 any

var A_arbace_j2g_code__init_part1_A_const_22 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_23 any

var A_arbace_j2g_code__init_part1_A_const_24 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_25 any

var A_arbace_j2g_code__init_part1_A_const_26 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_27 any

var A_arbace_j2g_code__init_part1_A_const_28 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_29 any

var A_arbace_j2g_code__init_part1_A_const_30 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_31 any

var A_arbace_j2g_code__init_part1_A_const_32 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_33 any

var A_arbace_j2g_code__init_part1_A_const_34 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_35 any

var A_arbace_j2g_code__init_part1_A_const_36 any

var A_arbace_j2g_code__init_part1_A_const_37 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_38 any

var A_arbace_j2g_code__init_part1_A_const_39 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_40 any

var A_arbace_j2g_code__init_part1_A_const_41 any

var A_arbace_j2g_code__init_part1_A_const_42 any

var A_arbace_j2g_code__init_part1_A_const_43 any

var A_arbace_j2g_code__init_part1_A_const_44 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_45 any

var A_arbace_j2g_code__init_part1_A_const_46 any

var A_arbace_j2g_code__init_part1_A_const_47 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_48 any

var A_arbace_j2g_code__init_part1_A_const_49 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_50 any

var A_arbace_j2g_code__init_part1_A_const_51 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_52 any

var A_arbace_j2g_code__init_part1_A_const_53 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_54 any

var A_arbace_j2g_code__init_part1_A_const_55 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_56 any

var A_arbace_j2g_code__init_part1_A_const_57 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_58 any

var A_arbace_j2g_code__init_part1_A_const_59 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_60 any

var A_arbace_j2g_code__init_part1_A_const_61 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_62 any

var A_arbace_j2g_code__init_part1_A_const_63 any

var A_arbace_j2g_code__init_part1_A_const_64 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_65 any

var A_arbace_j2g_code__init_part1_A_const_66 any

var A_arbace_j2g_code__init_part1_A_const_67 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_68 any

var A_arbace_j2g_code__init_part1_A_const_69 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_70 any

var A_arbace_j2g_code__init_part1_A_const_71 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_72 any

var A_arbace_j2g_code__init_part1_A_const_73 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_74 any

var A_arbace_j2g_code__init_part1_A_const_75 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_76 any

var A_arbace_j2g_code__init_part1_A_const_77 any

var A_arbace_j2g_code__init_part1_A_const_78 any

var A_arbace_j2g_code__init_part1_A_const_79 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_80 any

var A_arbace_j2g_code__init_part1_A_const_81 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_82 any

var A_arbace_j2g_code__init_part1_A_const_83 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_84 any

var A_arbace_j2g_code__init_part1_A_const_85 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_86 any

var A_arbace_j2g_code__init_part1_A_const_87 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_88 any

var A_arbace_j2g_code__init_part1_A_const_89 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_90 any

var A_arbace_j2g_code__init_part1_A_const_91 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_92 any

var A_arbace_j2g_code__init_part1_A_const_93 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_94 any

var A_arbace_j2g_code__init_part1_A_const_95 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_96 any

var A_arbace_j2g_code__init_part1_A_const_97 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_98 any

var A_arbace_j2g_code__init_part1_A_const_99 any

var A_arbace_j2g_code__init_part1_A_const_100 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_101 any

var A_arbace_j2g_code__init_part1_A_const_102 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_103 any

var A_arbace_j2g_code__init_part1_A_const_104 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_105 any

var A_arbace_j2g_code__init_part1_A_const_106 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_107 any

var A_arbace_j2g_code__init_part1_A_const_108 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_109 any

var A_arbace_j2g_code__init_part1_A_const_110 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_111 any

var A_arbace_j2g_code__init_part1_A_const_112 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_113 any

var A_arbace_j2g_code__init_part1_A_const_114 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_115 any

var A_arbace_j2g_code__init_part1_A_const_116 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_117 any

var A_arbace_j2g_code__init_part1_A_const_118 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_119 any

var A_arbace_j2g_code__init_part1_A_const_120 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_121 any

var A_arbace_j2g_code__init_part1_A_const_122 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_123 any

var A_arbace_j2g_code__init_part1_A_const_124 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_125 any

var A_arbace_j2g_code__init_part1_A_const_126 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_127 any

var A_arbace_j2g_code__init_part1_A_const_128 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_129 any

var A_arbace_j2g_code__init_part1_A_const_130 any

var A_arbace_j2g_code__init_part1_A_const_131 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_132 any

var A_arbace_j2g_code__init_part1_A_const_133 any

var A_arbace_j2g_code__init_part1_A_const_134 any

var A_arbace_j2g_code__init_part1_A_const_135 any

var A_arbace_j2g_code__init_part1_A_const_136 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_137 any

var A_arbace_j2g_code__init_part1_A_const_138 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_139 any

var A_arbace_j2g_code__init_part1_A_const_140 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_141 any

var A_arbace_j2g_code__init_part1_A_const_142 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_143 any

var A_arbace_j2g_code__init_part1_A_const_144 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_145 any

var A_arbace_j2g_code__init_part1_A_const_146 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_147 any

var A_arbace_j2g_code__init_part1_A_const_148 any

var A_arbace_j2g_code__init_part1_A_const_149 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_150 any

var A_arbace_j2g_code__init_part1_A_const_151 any

var A_arbace_j2g_code__init_part1_A_const_152 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_153 any

var A_arbace_j2g_code__init_part1_A_const_154 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_155 any

var A_arbace_j2g_code__init_part1_A_const_156 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_157 any

var A_arbace_j2g_code__init_part1_A_const_158 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_159 any

var A_arbace_j2g_code__init_part1_A_const_160 any

var A_arbace_j2g_code__init_part1_A_const_161 any

var A_arbace_j2g_code__init_part1_A_const_162 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_163 any

var A_arbace_j2g_code__init_part1_A_const_164 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_165 any

var A_arbace_j2g_code__init_part1_A_const_166 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_167 any

var A_arbace_j2g_code__init_part1_A_const_168 *lang.Var

var A_arbace_j2g_code__init_part1_A_const_169 any

var A_arbace_j2g_code__init_part1_A_const_170 any

var A_arbace_j2g_code__init_part1_A_const_171 any

var A_arbace_j2g_code__init_part1_A_const_172 any

var A_arbace_j2g_code__init_part1_A_init jrt.ClassInit

func A_arbace_j2g_code__init_part1_A_Init() { if !A_arbace_j2g_code__init_part1_A_init.Done() { A_arbace_j2g_code__init_part1_A_init.Run(A_arbace_j2g_code__init_part1_A_clinit) } }

func A_arbace_j2g_code__init_part1_A_clinit() { A_arbace_j2g_code__init_part1_A_clinit_p0(); A_arbace_j2g_code__init_part1_A_clinit_p1(); A_arbace_j2g_code__init_part1_A_clinit_p2() }

func A_arbace_j2g_code__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_code__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_422, 249); A_arbace_j2g_code__init_part1_A_const_0 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[90]); A_arbace_j2g_code__init_part1_A_const_1 = A_arbace_j2g_code__init_part1_A_const_pool.A[91]; A_arbace_j2g_code__init_part1_A_const_2 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[92]); A_arbace_j2g_code__init_part1_A_const_3 = A_arbace_j2g_code__init_part1_A_const_pool.A[93]; A_arbace_j2g_code__init_part1_A_const_4 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[94]); A_arbace_j2g_code__init_part1_A_const_5 = A_arbace_j2g_code__init_part1_A_const_pool.A[95]; A_arbace_j2g_code__init_part1_A_const_6 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[96]); A_arbace_j2g_code__init_part1_A_const_7 = A_arbace_j2g_code__init_part1_A_const_pool.A[97]; A_arbace_j2g_code__init_part1_A_const_8 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[98]); A_arbace_j2g_code__init_part1_A_const_9 = A_arbace_j2g_code__init_part1_A_const_pool.A[99]; A_arbace_j2g_code__init_part1_A_const_10 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[100]); A_arbace_j2g_code__init_part1_A_const_11 = A_arbace_j2g_code__init_part1_A_const_pool.A[101] }

func A_arbace_j2g_code__init_part1_A_clinit_p1() { A_arbace_j2g_code__init_part1_A_const_12 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[102]); A_arbace_j2g_code__init_part1_A_const_13 = A_arbace_j2g_code__init_part1_A_const_pool.A[103]; A_arbace_j2g_code__init_part1_A_const_14 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[104]); A_arbace_j2g_code__init_part1_A_const_15 = A_arbace_j2g_code__init_part1_A_const_pool.A[105]; A_arbace_j2g_code__init_part1_A_const_16 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[106]); A_arbace_j2g_code__init_part1_A_const_17 = A_arbace_j2g_code__init_part1_A_const_pool.A[107]; A_arbace_j2g_code__init_part1_A_const_18 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[108]); A_arbace_j2g_code__init_part1_A_const_19 = A_arbace_j2g_code__init_part1_A_const_pool.A[109]; A_arbace_j2g_code__init_part1_A_const_20 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[110]); A_arbace_j2g_code__init_part1_A_const_21 = A_arbace_j2g_code__init_part1_A_const_pool.A[111]; A_arbace_j2g_code__init_part1_A_const_22 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[112]); A_arbace_j2g_code__init_part1_A_const_23 = A_arbace_j2g_code__init_part1_A_const_pool.A[113] }

func A_arbace_j2g_code__init_part1_A_clinit_p2() { var tmp1 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp1 = A_arbace_j2g_code__init_part0_A_const_66; A_arbace_j2g_code__init_part1_A_const_24 = tmp1; A_arbace_j2g_code__init_part1_A_const_25 = A_arbace_j2g_code__init_part1_A_const_pool.A[114]; var tmp2 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp2 = A_arbace_j2g_code__init_part0_A_const_68; A_arbace_j2g_code__init_part1_A_const_26 = tmp2; A_arbace_j2g_code__init_part1_A_const_27 = A_arbace_j2g_code__init_part1_A_const_pool.A[115]; var tmp3 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp3 = A_arbace_j2g_code__init_part0_A_const_70; A_arbace_j2g_code__init_part1_A_const_28 = tmp3; A_arbace_j2g_code__init_part1_A_const_29 = A_arbace_j2g_code__init_part1_A_const_pool.A[116]; var tmp4 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp4 = A_arbace_j2g_code__init_part0_A_const_78; A_arbace_j2g_code__init_part1_A_const_30 = tmp4; A_arbace_j2g_code__init_part1_A_const_31 = A_arbace_j2g_code__init_part1_A_const_pool.A[117]; A_arbace_j2g_code__init_part1_A_const_32 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[118]); A_arbace_j2g_code__init_part1_A_const_33 = A_arbace_j2g_code__init_part1_A_const_pool.A[119]; A_arbace_j2g_code__init_part1_A_const_34 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[120]); A_arbace_j2g_code__init_part1_A_const_35 = A_arbace_j2g_code__init_part1_A_const_pool.A[121]; A_arbace_j2g_code__init_part1_A_const_36 = A_arbace_j2g_code__init_part1_A_const_pool.A[122]; var tmp5 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp5 = A_arbace_j2g_code__init_part0_A_const_90; A_arbace_j2g_code__init_part1_A_const_37 = tmp5; A_arbace_j2g_code__init_part1_A_const_38 = A_arbace_j2g_code__init_part1_A_const_pool.A[123]; var tmp6 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp6 = A_arbace_j2g_code__init_part0_A_const_88; A_arbace_j2g_code__init_part1_A_const_39 = tmp6; A_arbace_j2g_code__init_part1_A_const_40 = A_arbace_j2g_code__init_part1_A_const_pool.A[124]; A_arbace_j2g_code__init_part1_A_const_41 = A_arbace_j2g_code__init_part1_A_const_pool.A[125]; A_arbace_j2g_code__init_part1_A_const_42 = A_arbace_j2g_code__init_part1_A_const_pool.A[126]; A_arbace_j2g_code__init_part1_A_const_43 = A_arbace_j2g_code__init_part1_A_const_pool.A[127]; A_arbace_j2g_code__init_part1_A_const_44 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[128]); A_arbace_j2g_code__init_part1_A_const_45 = A_arbace_j2g_code__init_part1_A_const_pool.A[129]; A_arbace_j2g_code__init_part1_A_const_46 = A_arbace_j2g_code__init_part1_A_const_pool.A[130]; A_arbace_j2g_code__init_part1_A_const_47 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[131]); A_arbace_j2g_code__init_part1_A_const_48 = A_arbace_j2g_code__init_part1_A_const_pool.A[132]; A_arbace_j2g_code__init_part1_A_const_49 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[133]); A_arbace_j2g_code__init_part1_A_const_50 = A_arbace_j2g_code__init_part1_A_const_pool.A[134]; A_arbace_j2g_code__init_part1_A_const_51 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[135]); A_arbace_j2g_code__init_part1_A_const_52 = A_arbace_j2g_code__init_part1_A_const_pool.A[136]; A_arbace_j2g_code__init_part1_A_const_53 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[137]); A_arbace_j2g_code__init_part1_A_const_54 = A_arbace_j2g_code__init_part1_A_const_pool.A[138]; A_arbace_j2g_code__init_part1_A_const_55 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[139]); A_arbace_j2g_code__init_part1_A_const_56 = A_arbace_j2g_code__init_part1_A_const_pool.A[140]; A_arbace_j2g_code__init_part1_A_const_57 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[141]); A_arbace_j2g_code__init_part1_A_const_58 = A_arbace_j2g_code__init_part1_A_const_pool.A[142]; var tmp7 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp7 = A_arbace_j2g_code__init_part0_A_const_192; A_arbace_j2g_code__init_part1_A_const_59 = tmp7; A_arbace_j2g_code__init_part1_A_const_60 = A_arbace_j2g_code__init_part1_A_const_pool.A[143]; A_arbace_j2g_code__init_part1_A_const_61 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[144]); A_arbace_j2g_code__init_part1_A_const_62 = A_arbace_j2g_code__init_part1_A_const_pool.A[145]; A_arbace_j2g_code__init_part1_A_const_63 = A_arbace_j2g_code__init_part1_A_const_pool.A[146]; A_arbace_j2g_code__init_part1_A_const_64 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[147]); A_arbace_j2g_code__init_part1_A_const_65 = A_arbace_j2g_code__init_part1_A_const_pool.A[148]; A_arbace_j2g_code__init_part1_A_const_66 = A_arbace_j2g_code__init_part1_A_const_pool.A[149]; A_arbace_j2g_code__init_part1_A_const_67 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[150]); A_arbace_j2g_code__init_part1_A_const_68 = A_arbace_j2g_code__init_part1_A_const_pool.A[151]; A_arbace_j2g_code__init_part1_A_const_69 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[152]); A_arbace_j2g_code__init_part1_A_const_70 = A_arbace_j2g_code__init_part1_A_const_pool.A[153]; A_arbace_j2g_code__init_part1_A_const_71 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[154]); A_arbace_j2g_code__init_part1_A_const_72 = A_arbace_j2g_code__init_part1_A_const_pool.A[155]; A_arbace_j2g_code__init_part1_A_const_73 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[156]); A_arbace_j2g_code__init_part1_A_const_74 = A_arbace_j2g_code__init_part1_A_const_pool.A[157]; A_arbace_j2g_code__init_part1_A_const_75 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[158]); A_arbace_j2g_code__init_part1_A_const_76 = A_arbace_j2g_code__init_part1_A_const_pool.A[159]; A_arbace_j2g_code__init_part1_A_const_77 = A_arbace_j2g_code__init_part1_A_const_pool.A[160]; A_arbace_j2g_code__init_part1_A_const_78 = A_arbace_j2g_code__init_part1_A_const_pool.A[161]; A_arbace_j2g_code__init_part1_A_const_79 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[162]); A_arbace_j2g_code__init_part1_A_const_80 = A_arbace_j2g_code__init_part1_A_const_pool.A[163]; A_arbace_j2g_code__init_part1_A_const_81 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[164]); A_arbace_j2g_code__init_part1_A_const_82 = A_arbace_j2g_code__init_part1_A_const_pool.A[165]; A_arbace_j2g_code__init_part1_A_const_83 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[166]); A_arbace_j2g_code__init_part1_A_const_84 = A_arbace_j2g_code__init_part1_A_const_pool.A[167]; A_arbace_j2g_code__init_part1_A_const_85 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[168]); A_arbace_j2g_code__init_part1_A_const_86 = A_arbace_j2g_code__init_part1_A_const_pool.A[169]; A_arbace_j2g_code__init_part1_A_const_87 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[170]); A_arbace_j2g_code__init_part1_A_const_88 = A_arbace_j2g_code__init_part1_A_const_pool.A[171]; A_arbace_j2g_code__init_part1_A_const_89 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[172]); A_arbace_j2g_code__init_part1_A_const_90 = A_arbace_j2g_code__init_part1_A_const_pool.A[173]; A_arbace_j2g_code__init_part1_A_const_91 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[174]); A_arbace_j2g_code__init_part1_A_const_92 = A_arbace_j2g_code__init_part1_A_const_pool.A[175]; var tmp8 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp8 = A_arbace_j2g_code__init_part0_A_const_72; A_arbace_j2g_code__init_part1_A_const_93 = tmp8; A_arbace_j2g_code__init_part1_A_const_94 = A_arbace_j2g_code__init_part1_A_const_pool.A[176]; var tmp9 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp9 = A_arbace_j2g_code__init_part0_A_const_62; A_arbace_j2g_code__init_part1_A_const_95 = tmp9; A_arbace_j2g_code__init_part1_A_const_96 = A_arbace_j2g_code__init_part1_A_const_pool.A[177]; A_arbace_j2g_code__init_part1_A_const_97 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[178]); A_arbace_j2g_code__init_part1_A_const_98 = A_arbace_j2g_code__init_part1_A_const_pool.A[179]; A_arbace_j2g_code__init_part1_A_const_99 = A_arbace_j2g_code__init_part1_A_const_pool.A[180]; var tmp10 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp10 = A_arbace_j2g_code__init_part0_A_const_86; A_arbace_j2g_code__init_part1_A_const_100 = tmp10; A_arbace_j2g_code__init_part1_A_const_101 = A_arbace_j2g_code__init_part1_A_const_pool.A[181]; A_arbace_j2g_code__init_part1_A_const_102 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[182]); A_arbace_j2g_code__init_part1_A_const_103 = A_arbace_j2g_code__init_part1_A_const_pool.A[183]; var tmp11 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp11 = A_arbace_j2g_code__init_part0_A_const_74; A_arbace_j2g_code__init_part1_A_const_104 = tmp11; A_arbace_j2g_code__init_part1_A_const_105 = A_arbace_j2g_code__init_part1_A_const_pool.A[184]; var tmp12 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp12 = A_arbace_j2g_code__init_part0_A_const_76; A_arbace_j2g_code__init_part1_A_const_106 = tmp12; A_arbace_j2g_code__init_part1_A_const_107 = A_arbace_j2g_code__init_part1_A_const_pool.A[185]; A_arbace_j2g_code__init_part1_A_const_108 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[186]); A_arbace_j2g_code__init_part1_A_const_109 = A_arbace_j2g_code__init_part1_A_const_pool.A[187]; A_arbace_j2g_code__init_part1_A_const_110 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[188]); A_arbace_j2g_code__init_part1_A_const_111 = A_arbace_j2g_code__init_part1_A_const_pool.A[189]; A_arbace_j2g_code__init_part1_A_const_112 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[190]); A_arbace_j2g_code__init_part1_A_const_113 = A_arbace_j2g_code__init_part1_A_const_pool.A[191]; A_arbace_j2g_code__init_part1_A_const_114 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[192]); A_arbace_j2g_code__init_part1_A_const_115 = A_arbace_j2g_code__init_part1_A_const_pool.A[193]; A_arbace_j2g_code__init_part1_A_const_116 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[194]); A_arbace_j2g_code__init_part1_A_const_117 = A_arbace_j2g_code__init_part1_A_const_pool.A[195]; A_arbace_j2g_code__init_part1_A_const_118 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[196]); A_arbace_j2g_code__init_part1_A_const_119 = A_arbace_j2g_code__init_part1_A_const_pool.A[197]; A_arbace_j2g_code__init_part1_A_const_120 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[198]); A_arbace_j2g_code__init_part1_A_const_121 = A_arbace_j2g_code__init_part1_A_const_pool.A[199]; A_arbace_j2g_code__init_part1_A_const_122 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[200]); A_arbace_j2g_code__init_part1_A_const_123 = A_arbace_j2g_code__init_part1_A_const_pool.A[201]; A_arbace_j2g_code__init_part1_A_const_124 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[202]); A_arbace_j2g_code__init_part1_A_const_125 = A_arbace_j2g_code__init_part1_A_const_pool.A[203]; var tmp13 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp13 = A_arbace_j2g_code__init_part0_A_const_80; A_arbace_j2g_code__init_part1_A_const_126 = tmp13; A_arbace_j2g_code__init_part1_A_const_127 = A_arbace_j2g_code__init_part1_A_const_pool.A[204]; var tmp14 *lang.Var; A_arbace_j2g_code__init_part0_A_Init(); tmp14 = A_arbace_j2g_code__init_part0_A_const_64; A_arbace_j2g_code__init_part1_A_const_128 = tmp14; A_arbace_j2g_code__init_part1_A_const_129 = A_arbace_j2g_code__init_part1_A_const_pool.A[205]; A_arbace_j2g_code__init_part1_A_const_130 = A_arbace_j2g_code__init_part1_A_const_pool.A[206]; A_arbace_j2g_code__init_part1_A_const_131 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[207]); A_arbace_j2g_code__init_part1_A_const_132 = A_arbace_j2g_code__init_part1_A_const_pool.A[208]; A_arbace_j2g_code__init_part1_A_const_133 = A_arbace_j2g_code__init_part1_A_const_pool.A[209]; A_arbace_j2g_code__init_part1_A_const_134 = A_arbace_j2g_code__init_part1_A_const_pool.A[210]; A_arbace_j2g_code__init_part1_A_const_135 = A_arbace_j2g_code__init_part1_A_const_pool.A[211]; A_arbace_j2g_code__init_part1_A_const_136 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[212]); A_arbace_j2g_code__init_part1_A_const_137 = A_arbace_j2g_code__init_part1_A_const_pool.A[213]; A_arbace_j2g_code__init_part1_A_const_138 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[214]); A_arbace_j2g_code__init_part1_A_const_139 = A_arbace_j2g_code__init_part1_A_const_pool.A[215]; A_arbace_j2g_code__init_part1_A_const_140 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[216]); A_arbace_j2g_code__init_part1_A_const_141 = A_arbace_j2g_code__init_part1_A_const_pool.A[217]; A_arbace_j2g_code__init_part1_A_const_142 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[218]); A_arbace_j2g_code__init_part1_A_const_143 = A_arbace_j2g_code__init_part1_A_const_pool.A[219]; A_arbace_j2g_code__init_part1_A_const_144 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[220]); A_arbace_j2g_code__init_part1_A_const_145 = A_arbace_j2g_code__init_part1_A_const_pool.A[221]; A_arbace_j2g_code__init_part1_A_const_146 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[222]); A_arbace_j2g_code__init_part1_A_const_147 = A_arbace_j2g_code__init_part1_A_const_pool.A[223]; A_arbace_j2g_code__init_part1_A_const_148 = A_arbace_j2g_code__init_part1_A_const_pool.A[224]; A_arbace_j2g_code__init_part1_A_const_149 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[225]); A_arbace_j2g_code__init_part1_A_const_150 = A_arbace_j2g_code__init_part1_A_const_pool.A[226]; A_arbace_j2g_code__init_part1_A_const_151 = A_arbace_j2g_code__init_part1_A_const_pool.A[227]; A_arbace_j2g_code__init_part1_A_const_152 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[228]); A_arbace_j2g_code__init_part1_A_const_153 = A_arbace_j2g_code__init_part1_A_const_pool.A[229]; A_arbace_j2g_code__init_part1_A_const_154 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[230]); A_arbace_j2g_code__init_part1_A_const_155 = A_arbace_j2g_code__init_part1_A_const_pool.A[231]; A_arbace_j2g_code__init_part1_A_const_156 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[232]); A_arbace_j2g_code__init_part1_A_const_157 = A_arbace_j2g_code__init_part1_A_const_pool.A[233]; A_arbace_j2g_code__init_part1_A_const_158 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[234]); A_arbace_j2g_code__init_part1_A_const_159 = A_arbace_j2g_code__init_part1_A_const_pool.A[235]; A_arbace_j2g_code__init_part1_A_const_160 = A_arbace_j2g_code__init_part1_A_const_pool.A[236]; A_arbace_j2g_code__init_part1_A_const_161 = A_arbace_j2g_code__init_part1_A_const_pool.A[237]; A_arbace_j2g_code__init_part1_A_const_162 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[238]); A_arbace_j2g_code__init_part1_A_const_163 = A_arbace_j2g_code__init_part1_A_const_pool.A[239]; A_arbace_j2g_code__init_part1_A_const_164 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[240]); A_arbace_j2g_code__init_part1_A_const_165 = A_arbace_j2g_code__init_part1_A_const_pool.A[241]; A_arbace_j2g_code__init_part1_A_const_166 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[242]); A_arbace_j2g_code__init_part1_A_const_167 = A_arbace_j2g_code__init_part1_A_const_pool.A[243]; A_arbace_j2g_code__init_part1_A_const_168 = lang.Var_Cast(A_arbace_j2g_code__init_part1_A_const_pool.A[244]); A_arbace_j2g_code__init_part1_A_const_169 = A_arbace_j2g_code__init_part1_A_const_pool.A[245]; A_arbace_j2g_code__init_part1_A_const_170 = A_arbace_j2g_code__init_part1_A_const_pool.A[246]; A_arbace_j2g_code__init_part1_A_const_171 = A_arbace_j2g_code__init_part1_A_const_pool.A[247]; A_arbace_j2g_code__init_part1_A_const_172 = A_arbace_j2g_code__init_part1_A_const_pool.A[248] }

func A_arbace_j2g_code__init_part1_A_New() *A_arbace_j2g_code__init_part1_A { A_arbace_j2g_code__init_part1_A_Init(); t := &A_arbace_j2g_code__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_code__init_part1_A) Ctor() {}

func (t *A_arbace_j2g_code__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_code__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_code__init_part1_A_class }

func (t *A_arbace_j2g_code__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_code__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_code__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_code__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_code__init_part1_A); return ok }

func A_arbace_j2g_code__init_part1_A_Cast(x any) *A_arbace_j2g_code__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_code__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_code__init_part1_A_class)) }; return v }
