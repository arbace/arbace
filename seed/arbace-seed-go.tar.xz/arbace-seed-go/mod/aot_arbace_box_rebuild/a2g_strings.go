//line a2g_strings.ae:1
package aot_arbace_box_rebuild

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.box")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("box")

var Lit_6 *jrt.String = jrt.Intern("arbace.box.build")

var Lit_7 *jrt.String = jrt.Intern("build")

var Lit_8 *jrt.String = jrt.Intern("arbace.box.plan")

var Lit_9 *jrt.String = jrt.Intern("plan")

var Lit_10 *jrt.String = jrt.Intern("arbace.box.elf")

var Lit_11 *jrt.String = jrt.Intern("elf")

var Lit_12 *jrt.String = jrt.Intern("arbace.edn")

var Lit_13 *jrt.String = jrt.Intern("edn")

var Lit_14 *jrt.String = jrt.Intern("arbace.string")

var Lit_15 *jrt.String = jrt.Intern("str")

var Lit_16 *jrt.String = jrt.Intern("commute")

var Lit_17 *jrt.String = jrt.Intern("deref")

var Lit_18 *jrt.String = jrt.Intern("conj")

var Lit_19 *jrt.String = jrt.Intern("arbace.box.rebuild")

var Lit_20 *jrt.String = jrt.Intern("doc")

var Lit_21 *jrt.String = jrt.Intern("S3's chain in the box: Arbace's guest image from its sources, as bin/arbace-go --build --box\n  makes it on the host.\n\n    (rebuild src opts)   the image built from source tree src (a hash or a ref; the checkout as\n                         git archive gives it, VERSION filled): its hash; ref :ref (opts) pointed\n                         at it\n\n  The steps, each an action (arbace.box.build: a spawn, its result in the action cache):\n    compile     the namespaces compiled to class forms (standalone S6, SA152) by the tools'\n                image, whose runtime is these sources' (bin/arbace-go's host_compile): the\n                namespaces listed, then prepared from the sources at /s and compiled\n                (arbace.aot.main), the tree aot; skipped with :aot false (opts)\n    a2g         a2g --program in Arbace's guest (:host, the image that runs the tools), the\n                sources arbace/, go/, jdk/, overlay/ at /s and the compiled namespaces at /i:\n                the program as Go forms (prog)\n    print       g2a's printing (arbace.box.print), in two guests: tamago/'s standard library and goos module\n                with jrt's runtime overlay and the file system's patch (overlay/go); the\n                program with box/ and x509roots/ (bin/arbace-go --build --box's printing)\n    plan        GOROOT/src, the module arbace and TamaGo's goos module as trees, planned in\n                Arbace (arbace.box.plan)\n    build       every package compiled (jrt and lang in 12 GiB guests: SA101 (b)), the image\n                linked with Arbace's version (-X main.arbaceVersion, from the tree's VERSION)\n    prepare     the image run once (ARBACE_PREPARE): the image of prepared namespaces\n    image       the main package compiled again with it, linked again, its symbol table cut\n                to the monitor's symbols (arbace.box.elf, tools/elfsyms's)\n\n  opts: :arch (amd64, arm64; by default the guest's own), :host (the image that runs a2g and\n  g2a, a hash or a ref; by default the ref arbace.<arch>), :config (the toolchain's facts, a\n  hash or a ref; by default tool.config.<arch>: {:tool-tags [...] :release-tags [...] :include\n  TREE}, bin/box-tools put), :ref, :jobs (the compiles at once, by default 4), :a2g-cpus (by\n  default 8), :run (arbace.box.build's, the actions' executor: by default a spawn), :log,\n  :aot (false: the namespaces evaluated, ARBACE_AOT=0's build),\n  :given ({:aot TREE :a2g TREE :printed-goroot TREE :printed-program TREE}: those steps' results taken\n  as given, another run's, those steps not run: they are the same for every architecture;\n  doc/go/BOX-NOTES.md, S8, BX117).\n  (steps src opts) answers every intermediate result as a map instead.\n\n  natively, (host-run cfg) is an executor for :run that runs an action as a host process,\n  chrooted (tools/chrootrun) into a directory holding its trees at their mount points: the\n  images in (:images cfg), {HASH {:exe PATH :env [...]}}, run so (Go's compile, asm and link of\n  the host's toolchain; Arbace's native executable for the tools' image), any other spawned:\n  the same steps with the host's tools, the reference the image built in the box equals.")

var Lit_22 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_23 *jrt.String = jrt.Intern("ex-info")

var Lit_24 *jrt.String = jrt.Intern("assoc")

var Lit_25 *jrt.String = jrt.Intern("error")

var Lit_26 *jrt.String = jrt.Intern("string?")

var Lit_27 *jrt.String = jrt.Intern("re-matches")

var Lit_28 *jrt.String = jrt.Intern("ref")

var Lit_29 *jrt.String = jrt.Intern("fail")

var Lit_30 *jrt.String = jrt.Intern("else")

var Lit_31 *jrt.String = jrt.Intern("[0-9a-f]{64}")

var Lit_32 *jrt.String = jrt.Intern("pr-str")

var Lit_33 *jrt.String = jrt.Intern("tree-get")

var Lit_34 *jrt.String = jrt.Intern("dir")

var Lit_35 *jrt.String = jrt.Intern("dir-at")

var Lit_36 *jrt.String = jrt.Intern("tree")

var Lit_37 *jrt.String = jrt.Intern("path")

var Lit_38 *jrt.String = jrt.Intern("put-tree")

var Lit_39 *jrt.String = jrt.Intern("select-keys")

var Lit_40 *jrt.String = jrt.Intern("reduce")

var Lit_41 *jrt.String = jrt.Intern("lay-over")

var Lit_42 *jrt.String = jrt.Intern("remove")

var Lit_43 *jrt.String = jrt.Intern("seq")

var Lit_44 *jrt.String = jrt.Intern("first")

var Lit_45 *jrt.String = jrt.Intern("next")

var Lit_46 *jrt.String = jrt.Intern("empty?")

var Lit_47 *jrt.String = jrt.Intern("split")

var Lit_48 *jrt.String = jrt.Intern("/")

var Lit_49 *jrt.String = jrt.Intern("put-at")

var Lit_50 *jrt.String = jrt.Intern("join")

var Lit_51 *jrt.String = jrt.Intern("exec")

var Lit_52 *jrt.String = jrt.Intern("file")

var Lit_53 *jrt.String = jrt.Intern("get")

var Lit_54 *jrt.String = jrt.Intern("file-text")

var Lit_55 *jrt.String = jrt.Intern("includes?")

var Lit_56 *jrt.String = jrt.Intern("second")

var Lit_57 *jrt.String = jrt.Intern("blank?")

var Lit_58 *jrt.String = jrt.Intern("subs")

var Lit_59 *jrt.String = jrt.Intern("re-find")

var Lit_60 *jrt.String = jrt.Intern("(?m)^commit (.*)$")

var Lit_61 *jrt.String = jrt.Intern("(?m)^describe (.*)$")

var Lit_62 *jrt.String = jrt.Intern("out")

var Lit_63 *jrt.String = jrt.Intern("result")

var Lit_64 *jrt.String = jrt.Intern("replace")

var Lit_65 *jrt.String = jrt.Intern("prepare-script")

var Lit_66 *jrt.String = jrt.Intern("hash-of")

var Lit_67 *jrt.String = jrt.Intern("arch")

var Lit_68 *jrt.String = jrt.Intern("read-string")

var Lit_69 *jrt.String = jrt.Intern("merge")

var Lit_70 *jrt.String = jrt.Intern("log")

var Lit_71 *jrt.String = jrt.Intern("action")

var Lit_72 *jrt.String = jrt.Intern("format")

var Lit_73 *jrt.String = jrt.Intern("a2g-cpus")

var Lit_74 *jrt.String = jrt.Intern("given")

var Lit_75 *jrt.String = jrt.Intern("false?")

var Lit_76 *jrt.String = jrt.Intern("aot")

var Lit_77 *jrt.String = jrt.Intern("dir-at!")

var Lit_78 *jrt.String = jrt.Intern("a2g")

var Lit_79 *jrt.String = jrt.Intern("future-call")

var Lit_80 *jrt.String = jrt.Intern("put")

var Lit_81 *jrt.String = jrt.Intern("version")

var Lit_82 *jrt.String = jrt.Intern("archives")

var Lit_83 *jrt.String = jrt.Intern("link")

var Lit_84 *jrt.String = jrt.Intern("starts-with?")

var Lit_85 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_86 *jrt.String = jrt.Intern("chunk-first")

var Lit_87 *jrt.String = jrt.Intern("split-lines")

var Lit_88 *jrt.String = jrt.Intern("console")

var Lit_89 *jrt.String = jrt.Intern("chunk-rest")

var Lit_90 *jrt.String = jrt.Intern("update")

var Lit_91 *jrt.String = jrt.Intern("src")

var Lit_92 *jrt.String = jrt.Intern("prog")

var Lit_93 *jrt.String = jrt.Intern("printed-goroot")

var Lit_94 *jrt.String = jrt.Intern("printed-program")

var Lit_95 *jrt.String = jrt.Intern("goroot")

var Lit_96 *jrt.String = jrt.Intern("goos")

var Lit_97 *jrt.String = jrt.Intern("mod")

var Lit_98 *jrt.String = jrt.Intern("image1")

var Lit_99 *jrt.String = jrt.Intern("image-bin")

var Lit_100 *jrt.String = jrt.Intern("linked")

var Lit_101 *jrt.String = jrt.Intern("image")

var Lit_102 *jrt.String = jrt.Intern("arch-of")

var Lit_103 *jrt.String = jrt.Intern("host")

var Lit_104 *jrt.String = jrt.Intern("config")

var Lit_105 *jrt.String = jrt.Intern("jobs")

var Lit_106 *jrt.String = jrt.Intern("resources")

var Lit_107 *jrt.String = jrt.Intern("default-resources")

var Lit_108 *jrt.String = jrt.Intern("run")

var Lit_109 *jrt.String = jrt.Intern("cache")

var Lit_110 *jrt.String = jrt.Intern("tools")

var Lit_111 *jrt.String = jrt.Intern("println")

var Lit_112 *jrt.String = jrt.Intern("args")

var Lit_113 *jrt.String = jrt.Intern("arbace")

var Lit_114 *jrt.String = jrt.Intern("/c/nss.ae")

var Lit_115 *jrt.String = jrt.Intern("env")

var Lit_116 *jrt.String = jrt.Intern("ARBACE_PATH=/s")

var Lit_117 *jrt.String = jrt.Intern("trees")

var Lit_118 *jrt.String = jrt.Intern("cwd")

var Lit_119 *jrt.String = jrt.Intern("ram")

var Lit_120 *jrt.String = jrt.Intern("GiB")

var Lit_121 *jrt.String = jrt.Intern("cpus")

var Lit_122 *jrt.String = jrt.Intern("select-tree")

var Lit_123 *jrt.String = jrt.Intern("put-file")

var Lit_124 *jrt.String = jrt.Intern("namespaces-script")

var Lit_125 *jrt.String = jrt.Intern("/c/compile.ae")

var Lit_126 *jrt.String = jrt.Intern("go")

var Lit_127 *jrt.String = jrt.Intern("compile-script")

var Lit_128 *jrt.String = jrt.Intern("-m")

var Lit_129 *jrt.String = jrt.Intern("arbace.a2g.main")

var Lit_130 *jrt.String = jrt.Intern("--program")

var Lit_131 *jrt.String = jrt.Intern("into")

var Lit_132 *jrt.String = jrt.Intern("--input")

var Lit_133 *jrt.String = jrt.Intern("/i")

var Lit_134 *jrt.String = jrt.Intern("--out")

var Lit_135 *jrt.String = jrt.Intern("/o/a2g")

var Lit_136 *jrt.String = jrt.Intern("jdk")

var Lit_137 *jrt.String = jrt.Intern("overlay")

var Lit_138 *jrt.String = jrt.Intern("arbace.box.print")

var Lit_139 *jrt.String = jrt.Intern("print-goroot")

var Lit_140 *jrt.String = jrt.Intern("print-program")

var Lit_141 *jrt.String = jrt.Intern("x509roots")

var Lit_142 *jrt.String = jrt.Intern("concat")

var Lit_143 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_144 *jrt.String = jrt.Intern("chunk-append")

var Lit_145 *jrt.String = jrt.Intern("chunk-cons")

var Lit_146 *jrt.String = jrt.Intern("cons")

var Lit_147 *jrt.String = jrt.Intern("chunk")

var Lit_148 *jrt.String = jrt.Intern("rest")

var Lit_149 *jrt.String = jrt.Intern("goexperiment")

var Lit_150 *jrt.String = jrt.Intern("modules")

var Lit_151 *jrt.String = jrt.Intern("goospkg")

var Lit_152 *jrt.String = jrt.Intern("main")

var Lit_153 *jrt.String = jrt.Intern("goarch")

var Lit_154 *jrt.String = jrt.Intern("goamd64")

var Lit_155 *jrt.String = jrt.Intern("goarm64")

var Lit_156 *jrt.String = jrt.Intern("tool-tags")

var Lit_157 *jrt.String = jrt.Intern("release-tags")

var Lit_158 *jrt.String = jrt.Intern("tags")

var Lit_159 *jrt.String = jrt.Intern("include")

var Lit_160 *jrt.String = jrt.Intern("packages")

var Lit_161 *jrt.String = jrt.Intern("ldflags")

var Lit_162 *jrt.String = jrt.Intern("/c/prepare.ae")

var Lit_163 *jrt.String = jrt.Intern("ARBACE_PREPARE=/o/image.bin")

var Lit_164 *jrt.String = jrt.Intern("GOGC=400")

var Lit_165 *jrt.String = jrt.Intern("mapv")

var Lit_166 *jrt.String = jrt.Intern("only")

var Lit_167 *jrt.String = jrt.Intern("cut-symbols")

var Lit_168 *jrt.String = jrt.Intern("get-bytes")

var Lit_169 *jrt.String = jrt.Intern("guest-symbols")

var Lit_170 *jrt.String = jrt.Intern("ref!")

var Lit_171 *jrt.String = jrt.Intern("size")

var Lit_172 *jrt.String = jrt.Intern("steps")

var Lit_173 *jrt.String = jrt.Intern("rebuild")

var Lit_174 *jrt.String = jrt.Intern("to-array")

var Lit_175 *jrt.String = jrt.Intern("exit")

var Lit_176 *jrt.String = jrt.Intern("delete-tree")

var Lit_177 *jrt.String = jrt.Intern("images")

var Lit_178 *jrt.String = jrt.Intern("chrootrun")

var Lit_179 *jrt.String = jrt.Intern("work")

var Lit_180 *jrt.String = jrt.Intern("prepare-exe")

var Lit_181 *jrt.String = jrt.Intern("atom")

var Lit_182 *jrt.String = jrt.Intern("some")

var Lit_183 *jrt.String = jrt.Intern("exe")

var Lit_184 *jrt.String = jrt.Intern("swap!")

var Lit_185 *jrt.String = jrt.Intern("get-tree")

var Lit_186 *jrt.String = jrt.Intern("make-array")

var Lit_187 *jrt.String = jrt.Intern("vec")

var Lit_188 *jrt.String = jrt.Intern("put-dir")

var Lit_189 *jrt.String = jrt.Intern("inc")

var Lit_190 *jrt.String = jrt.Intern("java.nio.file.CopyOption")

var Lit_191 *jrt.String = jrt.Intern("result-text")

var Lit_192 *jrt.String = jrt.Intern("hash")

var Lit_193 *jrt.String = jrt.Intern("arbace.box.rebuild$arch_of")

var Lit_194 *jrt.String = jrt.Intern("os.arch")

var Lit_195 *jrt.String = jrt.Intern("arm64")

var Lit_196 *jrt.String = jrt.Intern("aarch64")

var Lit_197 *jrt.String = jrt.Intern("amd64")

var Lit_198 *jrt.String = jrt.Intern("arbace.box.rebuild$compile_script")

var Lit_199 *jrt.String = jrt.Intern("arbace.box.rebuild$delete_tree")

var Lit_200 *jrt.String = jrt.Intern("arbace.box.rebuild$dir_at")

var Lit_201 *jrt.String = jrt.Intern("arbace.box.rebuild$dir_at_BANG_")

var Lit_202 *jrt.String = jrt.Intern(": no directory ")

var Lit_203 *jrt.String = jrt.Intern("arbace.box.rebuild$eval1433000004$loading__1927001464__auto____1433000005")

var Lit_204 *jrt.String = jrt.Intern("java.io.File")

var Lit_205 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_206 *jrt.String = jrt.Intern("arbace.box.rebuild$eval1433000008$fn__1433000009")

var Lit_207 *jrt.String = jrt.Intern("arbace.box.rebuild$fail")

var Lit_208 *jrt.String = jrt.Intern("arbace.box.rebuild: ")

var Lit_209 *jrt.String = jrt.Intern("arbace.box.rebuild$file_text")

var Lit_210 *jrt.String = jrt.Intern("arbace.box.rebuild$hash_of")

var Lit_211 *jrt.String = jrt.Intern("no ref ")

var Lit_212 *jrt.String = jrt.Intern(" (")

var Lit_213 *jrt.String = jrt.Intern(")")

var Lit_214 *jrt.String = jrt.Intern("not a hash or a ref: ")

var Lit_215 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run")

var Lit_216 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114")

var Lit_217 *jrt.String = jrt.Intern(".x/prog")

var Lit_218 *jrt.String = jrt.Intern("/.x/prog")

var Lit_219 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114$fn__1433000115")

var Lit_220 *jrt.String = jrt.Intern("ARBACE_PREPARE=")

var Lit_221 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114$fn__1433000123")

var Lit_222 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114$fn__1433000135")

var Lit_223 *jrt.String = jrt.Intern("/tmp")

var Lit_224 *jrt.String = jrt.Intern("/.x")

var Lit_225 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114$fn__1433000141")

var Lit_226 *jrt.String = jrt.Intern("=")

var Lit_227 *jrt.String = jrt.Intern("arbace.box.rebuild$lay_over")

var Lit_228 *jrt.String = jrt.Intern("arbace.box.rebuild$lay_over$fn__1433000021")

var Lit_229 *jrt.String = jrt.Intern("arbace.box.rebuild$namespaces_script")

var Lit_230 *jrt.String = jrt.Intern("arbace.box.rebuild$out")

var Lit_231 *jrt.String = jrt.Intern(": no output tree")

var Lit_232 *jrt.String = jrt.Intern("arbace.box.rebuild$prepare_script")

var Lit_233 *jrt.String = jrt.Intern("(doseq [n (quote [")

var Lit_234 *jrt.String = jrt.Intern("])]\n")

var Lit_235 *jrt.String = jrt.Intern("  (try (require n) (catch Throwable e (println \"image: not prepared:\" n (.getMessage e)))))\n")

var Lit_236 *jrt.String = jrt.Intern("\n")

var Lit_237 *jrt.String = jrt.Intern(" ")

var Lit_238 *jrt.String = jrt.Intern("arbace.box.rebuild$put_at")

var Lit_239 *jrt.String = jrt.Intern("arbace.box.rebuild$rebuild")

var Lit_240 *jrt.String = jrt.Intern("arbace.box.rebuild$result_text")

var Lit_241 *jrt.String = jrt.Intern("{:exit ")

var Lit_242 *jrt.String = jrt.Intern("\n :console \"")

var Lit_243 *jrt.String = jrt.Intern("\"}\n")

var Lit_244 *jrt.String = jrt.Intern("\n :out \"")

var Lit_245 *jrt.String = jrt.Intern("\"")

var Lit_246 *jrt.String = jrt.Intern("arbace.box.rebuild$select_tree")

var Lit_247 *jrt.String = jrt.Intern("arbace.box.rebuild$steps")

var Lit_248 *jrt.String = jrt.Intern("the sources")

var Lit_249 *jrt.String = jrt.Intern("arbace.")

var Lit_250 *jrt.String = jrt.Intern("the tools' image")

var Lit_251 *jrt.String = jrt.Intern("tool.config.")

var Lit_252 *jrt.String = jrt.Intern("the toolchain's facts")

var Lit_253 *jrt.String = jrt.Intern("list the namespaces")

var Lit_254 *jrt.String = jrt.Intern("/s")

var Lit_255 *jrt.String = jrt.Intern("/c")

var Lit_256 *jrt.String = jrt.Intern("nss.ae")

var Lit_257 *jrt.String = jrt.Intern("/o")

var Lit_258 *jrt.String = jrt.Intern("nss.txt")

var Lit_259 *jrt.String = jrt.Intern("list the namespaces: no nss.txt")

var Lit_260 *jrt.String = jrt.Intern("compile the namespaces")

var Lit_261 *jrt.String = jrt.Intern("compile.ae")

var Lit_262 *jrt.String = jrt.Intern("/o/aot")

var Lit_263 *jrt.String = jrt.Intern("")

var Lit_264 *jrt.String = jrt.Intern("aot:")

var Lit_265 *jrt.String = jrt.Intern("rebuild: ")

var Lit_266 *jrt.String = jrt.Intern("rebuild: the namespaces compiled ")

var Lit_267 *jrt.String = jrt.Intern("a2g --program")

var Lit_268 *jrt.String = jrt.Intern("GOMEMLIMIT=12GiB")

var Lit_269 *jrt.String = jrt.Intern("A2G_JOBS=")

var Lit_270 *jrt.String = jrt.Intern("a2g/prog")

var Lit_271 *jrt.String = jrt.Intern("rebuild: a2g's program ")

var Lit_272 *jrt.String = jrt.Intern("tamago")

var Lit_273 *jrt.String = jrt.Intern("std")

var Lit_274 *jrt.String = jrt.Intern("goroot/src")

var Lit_275 *jrt.String = jrt.Intern("tamago/")

var Lit_276 *jrt.String = jrt.Intern("runtime")

var Lit_277 *jrt.String = jrt.Intern("syscall/fs_tamago.go")

var Lit_278 *jrt.String = jrt.Intern("go.mod")

var Lit_279 *jrt.String = jrt.Intern("goos/go.mod")

var Lit_280 *jrt.String = jrt.Intern("config.edn")

var Lit_281 *jrt.String = jrt.Intern("{}")

var Lit_282 *jrt.String = jrt.Intern("the program sets GOEXPERIMENT ")

var Lit_283 *jrt.String = jrt.Intern(": not built by the driver")

var Lit_284 *jrt.String = jrt.Intern("github.com/usbarmory/tamago")

var Lit_285 *jrt.String = jrt.Intern("arbace/cmd/arbace")

var Lit_286 *jrt.String = jrt.Intern("v1")

var Lit_287 *jrt.String = jrt.Intern("v8.0")

var Lit_288 *jrt.String = jrt.Intern("-T")

var Lit_289 *jrt.String = jrt.Intern("0x201000")

var Lit_290 *jrt.String = jrt.Intern("-R")

var Lit_291 *jrt.String = jrt.Intern("0x1000")

var Lit_292 *jrt.String = jrt.Intern("-w")

var Lit_293 *jrt.String = jrt.Intern("-X")

var Lit_294 *jrt.String = jrt.Intern("main.arbaceVersion=")

var Lit_295 *jrt.String = jrt.Intern("rebuild: the first image ")

var Lit_296 *jrt.String = jrt.Intern("namespaces.txt")

var Lit_297 *jrt.String = jrt.Intern("a2g's program has no namespaces.txt")

var Lit_298 *jrt.String = jrt.Intern("prepare the namespaces")

var Lit_299 *jrt.String = jrt.Intern("prepare.ae")

var Lit_300 *jrt.String = jrt.Intern("prepare")

var Lit_301 *jrt.String = jrt.Intern("image.bin")

var Lit_302 *jrt.String = jrt.Intern("prepare wrote no image")

var Lit_303 *jrt.String = jrt.Intern("rebuild: the image ")

var Lit_304 *jrt.String = jrt.Intern(" bytes) in ")

var Lit_305 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000063")

var Lit_306 *jrt.String = jrt.Intern("print tamago/ and overlay/go")

var Lit_307 *jrt.String = jrt.Intern("/f")

var Lit_308 *jrt.String = jrt.Intern("/g")

var Lit_309 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000065")

var Lit_310 *jrt.String = jrt.Intern("print the program")

var Lit_311 *jrt.String = jrt.Intern("/p")

var Lit_312 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000068")

var Lit_313 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000093")

var Lit_314 *jrt.String = jrt.Intern("image:")

var Lit_315 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000095")

var Lit_316 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000095$fn__1433000096")

var Lit_317 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$forms__1433000061")

var Lit_318 *jrt.String = jrt.Intern("arch/amd64/go")

var Lit_319 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$iter__1433000073__1433000077")

var Lit_320 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$iter__1433000073__1433000077$fn__1433000078")

var Lit_321 *jrt.String = jrt.Intern("runtime/")

var Lit_322 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$iter__1433000073__1433000077$fn__1433000078$fn__1433000079")

var Lit_323 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$run__1433000051")

var Lit_324 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$secs__1433000053")

var Lit_325 *jrt.String = jrt.Intern("%.1f s")

var Lit_326 *jrt.String = jrt.Intern("arbace.box.rebuild$version")

var Lit_327 *jrt.String = jrt.Intern("VERSION")

var Lit_328 *jrt.String = jrt.Intern("$Format:")

var Lit_329 *jrt.String = jrt.Intern("{:describe \"unknown\" :commit nil :dirty nil}")

var Lit_330 *jrt.String = jrt.Intern("{:describe \"")

var Lit_331 *jrt.String = jrt.Intern("\" :commit \"")

var Lit_332 *jrt.String = jrt.Intern("\" :dirty false}")

var Lit_333 *jrt.String = jrt.Intern("in-ns")

var Lit_334 *jrt.String = jrt.Intern("private")

var Lit_335 *jrt.String = jrt.Intern("line")

var Lit_336 *jrt.String = jrt.Intern("column")

var Lit_337 *jrt.String = jrt.Intern("arbace/box/rebuild.ae")

var Lit_338 *jrt.String = jrt.Intern("arglists")

var Lit_339 *jrt.String = jrt.Intern("msg")

var Lit_340 *jrt.String = jrt.Intern("data")

var Lit_341 *jrt.String = jrt.Intern("x")

var Lit_342 *jrt.String = jrt.Intern("what")

var Lit_343 *jrt.String = jrt.Intern("x, a hash or a ref's name, as a hash.")

var Lit_344 *jrt.String = jrt.Intern("t")

var Lit_345 *jrt.String = jrt.Intern("p")

var Lit_346 *jrt.String = jrt.Intern("tag")

var Lit_347 *jrt.String = jrt.Intern("String")

var Lit_348 *jrt.String = jrt.Intern("The tree at path p of tree t, nil when there is none.")

var Lit_349 *jrt.String = jrt.Intern("names")

var Lit_350 *jrt.String = jrt.Intern("Tree t with only the named entries.")

var Lit_351 *jrt.String = jrt.Intern("a")

var Lit_352 *jrt.String = jrt.Intern("b")

var Lit_353 *jrt.String = jrt.Intern("Tree b laid over tree a: b's entries replace a's, but for directories in both, laid over\n  each other.")

var Lit_354 *jrt.String = jrt.Intern("e")

var Lit_355 *jrt.String = jrt.Intern("Tree t (nil: an empty one) with entry e at path p (\"a/b.go\"), the directories made.")

var Lit_356 *jrt.String = jrt.Intern("The version map's text of source tree src (its VERSION, as git archive fills it):\n  {:describe \"...\" :commit \"...\" :dirty false}, or the unknown one.")

var Lit_357 *jrt.String = jrt.Intern("whim_vectors")

var Lit_358 *jrt.String = jrt.Intern("whim_apentry")

var Lit_359 *jrt.String = jrt.Intern("runtime/goos.RamStart")

var Lit_360 *jrt.String = jrt.Intern("The symbols the monitor reads (bin/arbace-go's box_symbols).")

var Lit_361 *jrt.String = jrt.Intern("res")

var Lit_362 *jrt.String = jrt.Intern("nss")

var Lit_363 *jrt.String = jrt.Intern("bin/arbace-go's prepare script for the namespaces of namespaces.txt's text.")

var Lit_364 *jrt.String = jrt.Intern("bin/arbace-go's list of the embedded namespaces (a2g's namespaces.txt), written to /o/nss.txt.")

var Lit_365 *jrt.String = jrt.Intern("bin/arbace-go's host_compile script: the namespaces of nss's text prepared, then compiled\n  into out.")

var Lit_366 *jrt.String = jrt.Intern("opts")

var Lit_367 *jrt.String = jrt.Intern("The rebuild of source tree src (see the namespace's doc): a map of every step's result\n  (trees, the plan, the images), :image the final one's hash.")

var Lit_368 *jrt.String = jrt.Intern("The image rebuilt from source tree src (see the namespace's doc): its hash.")

var Lit_369 *jrt.String = jrt.Intern("keys")

var Lit_370 *jrt.String = jrt.Intern("f")

var Lit_371 *jrt.String = jrt.Intern("File")

var Lit_372 *jrt.String = jrt.Intern("host-run")

var Lit_373 *jrt.String = jrt.Intern("An executor for arbace.box.build's :run (see the namespace's doc): cfg {:images {HASH\n  {:exe PATH :env [NAME=VALUE ...]}} :chrootrun PATH :work DIR :prepare-exe PATH}: a request\n  for an image of :images runs its :exe, one setting ARBACE_PREPARE runs :prepare-exe (the\n  native executable of the program: the image is the same on every architecture), any other\n  is spawned.")

var Lit_374 *jrt.String = jrt.Intern("arbace/jrt")

var Lit_375 *jrt.String = jrt.Intern("arbace/lang")

var Lit_376 *jrt.String = jrt.Intern("arbace/aot_arbace_core")

var Lit_377 *jrt.String = jrt.Intern("arbace/aot_*")
