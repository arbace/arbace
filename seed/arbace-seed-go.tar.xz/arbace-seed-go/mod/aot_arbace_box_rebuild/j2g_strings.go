//line j2g_strings.ae:1
package aot_arbace_box_rebuild

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn10,arbace.boxkn2,asyn3,boxyn16,arbace.box.buildyn5,buildyn15,arbace.box.planyn4,planyn14,arbace.box.elfyn3,elfyn10,arbace.ednyn3,ednyn13,arbace.stringyn3,strkn3,docks18,arbace.box.rebuild5,errorkn4,elsekn3,refkn3,dirkn4,treekn4,pathkn4,execkn4,filekn3,outkn6,resultkn4,archkn3,logkn8,j2g-cpuskn5,givenkn3,aotkn3,j2gkn7,consolekn3,srckn4,progkn14,printed-gorootkn15,printed-programkn6,gorootkn4,gooskn3,modkn4,plankn7,versionkn6,image1kn9,image-binkn6,linkedkn5,imagekn4,hostkn6,configkn4,jobskn9,resourceskn3,runkn5,cachekn5,toolskn4,argskn3,envkn5,treeskn3,cwdkn3,ramkn4,cpuskn12,goexperimentkn7,moduleskn7,goospkgkn4,mainkn6,goarchkn7,goamd64kn7,goarm64kn9,tool-tagskn12,release-tagskn4,tagskn7,includekn8,packageskn7,ldflagskn4,onlykn8,archiveskn4,exitkn6,imageskn9,chrootrunkn4,workkn11,prepare-exekn3,exekn4,hashv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn18,arbace.box.rebuildm2,R14,s3169,S3's chain in the box: Arbace's guest image from its sources, as bin/arbace-go --build --box\n  makes it on the host.\n\n    (rebuild src opts)   the image built from source tree src (a hash or a ref; the checkout as\n                         git archive gives it, VERSION filled): its hash; ref :ref (opts) pointed\n                         at it\n\n  The steps, each an action (arbace.box.build: a spawn, its result in the action cache):\n    compile     the namespaces compiled to Java forms (standalone S6, SA152) by the tools'\n                image, whose runtime is these sources' (bin/arbace-go's host_compile): the\n                namespaces listed, then prepared from the sources at /s and compiled\n                (arbace.c2j.main), the tree aot; skipped with :aot false (opts)\n    j2g         j2g --program in Arbace's guest (:host, the image that runs the tools), the\n                sources arbace/, go/, jdk/, overlay/ at /s and the compiled namespaces at /i:\n                the program as Go forms (prog)\n    print       repr/go's printing (arbace.box.print), in two guests: tamago/'s standard library and goos module\n                with jrt's runtime overlay and the file system's patch (overlay/go); the\n                program with box/ and x509roots/ (bin/arbace-go --build --box's printing)\n    plan        GOROOT/src, the module arbace and TamaGo's goos module as trees, planned in\n                Arbace (arbace.box.plan)\n    build       every package compiled (jrt and lang in 12 GiB guests: SA101 (b)), the image\n                linked with Arbace's version (-X main.arbaceVersion, from the tree's VERSION)\n    prepare     the image run once (ARBACE_PREPARE): the image of prepared namespaces\n    image       the main package compiled again with it, linked again, its symbol table cut\n                to the monitor's symbols (arbace.box.elf, tools/elfsyms's)\n\n  opts: :arch (amd64, arm64; by default the guest's own), :host (the image that runs j2g and\n  repr/go, a hash or a ref; by default the ref arbace.<arch>), :config (the toolchain's facts, a\n  hash or a ref; by default tool.config.<arch>: {:tool-tags [...] :release-tags [...] :include\n  TREE}, bin/box-tools put), :ref, :jobs (the compiles at once, by default 4), :j2g-cpus (by\n  default 8), :run (arbace.box.build's, the actions' executor: by default a spawn), :log,\n  :aot (false: the namespaces evaluated, ARBACE_AOT=0's build),\n  :given ({:aot TREE :j2g TREE :printed-goroot TREE :printed-program TREE}: those steps' results taken\n  as given, another run's, those steps not run: they are the same for every architecture;\n  doc/go/BOX-NOTES.md, S8, BX117).\n  (steps src opts) answers every intermediate result as a map instead.\n\n  natively, (host-run cfg) is an executor for :run that runs an action as a host process,\n  chrooted (tools/chrootrun) into a directory holding its trees at their mount points: the\n  images in (:images cfg), {HASH {:exe PATH :env [...]}}, run so (Go's compile, asm and link of\n  the host's toolchain; Arbace's native executable for the tools' image), any other spawned:\n  the same steps with the host's tools, the reference the image built in the box equals.v11,arbace.core13,*loaded-libs*v11,arbace.core7,ex-infov11,arbace.core5,assocR15,v11,arbace.core7,string?v11,arbace.core10,re-matchesv10,arbace.box3,refv18,arbace.box.rebuild4,failR16,p12,[0-9a-f]{64}R17,v11,arbace.core6,pr-strv10,arbace.box8,tree-getR18,v18,arbace.box.rebuild6,dir-atR19,R20,v10,arbace.box8,put-treev11,arbace.core11,select-keysv10,arbace.box4,treev11,arbace.core6,reducev18,arbace.box.rebuild8,lay-overv11,arbace.core6,removev11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,nextv11,arbace.core6,empty?v13,arbace.string5,splitp1,/v18,arbace.box.rebuild6,put-atv13,arbace.string4,joinS2,R21,R22,v10,arbace.box3,getv18,arbace.box.rebuild9,file-textv13,arbace.string9,includes?v11,arbace.core6,secondv13,arbace.string6,blank?v11,arbace.core4,subsv11,arbace.core7,re-findp17,(?m)^commit (.*)$p19,(?m)^describe (.*)$v11,arbace.core3,strl0,R23,R24,v13,arbace.string7,replacev18,arbace.box.rebuild14,prepare-scriptv18,arbace.box.rebuild7,hash-ofR25,v10,arbace.edn11,read-stringv11,arbace.core5,mergeR26,v16,arbace.box.build6,actionv11,arbace.core6,formatR27,R28,v11,arbace.core6,false?R29,v18,arbace.box.rebuild7,dir-at!R30,v18,arbace.box.rebuild3,outv11,arbace.core11,future-callv15,arbace.box.plan4,planv10,arbace.box3,putv18,arbace.box.rebuild7,versionv16,arbace.box.build8,archivesv16,arbace.box.build4,linkv13,arbace.string12,starts-with?v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv13,arbace.string11,split-linesR31,v11,arbace.core10,chunk-restv11,arbace.core6,updateR32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,v18,arbace.box.rebuild7,arch-ofR45,R46,R47,l4,R48,v18,arbace.box.rebuild17,default-resourcesV6,R47,R49,R26,R50,R51,R48,v11,arbace.core7,printlnl8,R52,V2,s6,arbaces9,/c/nss.aeR53,V1,s14,ARBACE_PATH=/sR54,R55,R56,v18,arbace.box.rebuild3,GiBR57,l2,v18,arbace.box.rebuild11,select-treeV1,s6,arbacev10,arbace.box8,put-filev18,arbace.box.rebuild17,namespaces-scriptV2,s6,arbaces13,/c/compile.aeV8,s16,ARBACE_COMPILE=1s15,ARBACE_NO_AOT=1s17,ARBACE_NO_IMAGE=1s19,ARBACE_PATH_FIRST=1s14,ARBACE_PATH=/ss18,ARBACE_AOT_ROOT=/ss31,ARBACE_PREPARE=/o/compile.images8,GOGC=400V2,s6,arbaces2,gov18,arbace.box.rebuild14,compile-scriptV4,s6,arbaces2,-ms15,arbace.j2g.mains9,--programv11,arbace.core4,intoV2,s7,--inputs2,/iV2,s5,--outs6,/o/j2gV4,s6,arbaces2,gos3,jdks7,overlayV4,s6,arbaces2,-ms16,arbace.box.prints12,print-gorootV1,s14,ARBACE_PATH=/sV2,s6,arbaces7,overlayV4,s6,arbaces2,-ms16,arbace.box.prints13,print-programV1,s14,ARBACE_PATH=/sV3,s6,arbaces3,boxs9,x509rootsv11,arbace.core6,concatv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restR58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,V2,s6,arbaces13,/c/prepare.aeV2,s27,ARBACE_PREPARE=/o/image.bins8,GOGC=400v11,arbace.core4,mapvR71,R72,v14,arbace.box.elf11,cut-symbolsv10,arbace.box9,get-bytesv18,arbace.box.rebuild13,guest-symbolsv10,arbace.box4,ref!v10,arbace.box4,sizev18,arbace.box.rebuild5,stepsv18,arbace.box.rebuild7,rebuildv11,arbace.core8,to-arrayR73,v18,arbace.box.rebuild11,delete-treeR74,R75,R76,R77,v11,arbace.core4,atomv11,arbace.core4,someR78,v11,arbace.core5,swap!v10,arbace.box8,get-treev11,arbace.core10,make-arrayv11,arbace.core3,vecv10,arbace.box7,put-dirv10,arbace.box3,runv11,arbace.core3,incC24,java.nio.file.CopyOptionv18,arbace.box.rebuild11,result-textR79,")

var Lit_1 *jrt.String = jrt.Intern("os.arch")

var Lit_2 *jrt.String = jrt.Intern("arm64")

var Lit_3 *jrt.String = jrt.Intern("aarch64")

var Lit_4 *jrt.String = jrt.Intern("amd64")

var Lit_5 *jrt.String = jrt.Intern(": no directory ")

var Lit_6 *jrt.String = jrt.Intern("java.io.File")

var Lit_7 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_8 *jrt.String = jrt.Intern("arbace.box.rebuild: ")

var Lit_9 *jrt.String = jrt.Intern("no ref ")

var Lit_10 *jrt.String = jrt.Intern(" (")

var Lit_11 *jrt.String = jrt.Intern(")")

var Lit_12 *jrt.String = jrt.Intern("not a hash or a ref: ")

var Lit_13 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114")

var Lit_14 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114$fn__1433000115")

var Lit_15 *jrt.String = jrt.Intern("/")

var Lit_16 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114$fn__1433000123")

var Lit_17 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114$fn__1433000135")

var Lit_18 *jrt.String = jrt.Intern(".x/prog")

var Lit_19 *jrt.String = jrt.Intern("/.x/prog")

var Lit_20 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run$fn__1433000114$fn__1433000141")

var Lit_21 *jrt.String = jrt.Intern("ARBACE_PREPARE=")

var Lit_22 *jrt.String = jrt.Intern("/tmp")

var Lit_23 *jrt.String = jrt.Intern("/.x")

var Lit_24 *jrt.String = jrt.Intern("=")

var Lit_25 *jrt.String = jrt.Intern("arbace.box.rebuild$lay_over$fn__1433000021")

var Lit_26 *jrt.String = jrt.Intern(": no output tree")

var Lit_27 *jrt.String = jrt.Intern("(doseq [n (quote [")

var Lit_28 *jrt.String = jrt.Intern("])]\n")

var Lit_29 *jrt.String = jrt.Intern("  (try (require n) (catch Throwable e (println \"image: not prepared:\" n (.getMessage e)))))\n")

var Lit_30 *jrt.String = jrt.Intern("\n")

var Lit_31 *jrt.String = jrt.Intern(" ")

var Lit_32 *jrt.String = jrt.Intern("{:exit ")

var Lit_33 *jrt.String = jrt.Intern("\n :console \"")

var Lit_34 *jrt.String = jrt.Intern("\"}\n")

var Lit_35 *jrt.String = jrt.Intern("\n :out \"")

var Lit_36 *jrt.String = jrt.Intern("\"")

var Lit_37 *jrt.String = jrt.Intern("the sources")

var Lit_38 *jrt.String = jrt.Intern("arbace.")

var Lit_39 *jrt.String = jrt.Intern("the tools' image")

var Lit_40 *jrt.String = jrt.Intern("tool.config.")

var Lit_41 *jrt.String = jrt.Intern("the toolchain's facts")

var Lit_42 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$run__1433000051")

var Lit_43 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$secs__1433000053")

var Lit_44 *jrt.String = jrt.Intern("list the namespaces")

var Lit_45 *jrt.String = jrt.Intern("/s")

var Lit_46 *jrt.String = jrt.Intern("/c")

var Lit_47 *jrt.String = jrt.Intern("nss.ae")

var Lit_48 *jrt.String = jrt.Intern("/o")

var Lit_49 *jrt.String = jrt.Intern("nss.txt")

var Lit_50 *jrt.String = jrt.Intern("list the namespaces: no nss.txt")

var Lit_51 *jrt.String = jrt.Intern("compile the namespaces")

var Lit_52 *jrt.String = jrt.Intern("compile.ae")

var Lit_53 *jrt.String = jrt.Intern("/o/aot")

var Lit_54 *jrt.String = jrt.Intern("")

var Lit_55 *jrt.String = jrt.Intern("aot:")

var Lit_56 *jrt.String = jrt.Intern("rebuild: ")

var Lit_57 *jrt.String = jrt.Intern("aot")

var Lit_58 *jrt.String = jrt.Intern("rebuild: the namespaces compiled ")

var Lit_59 *jrt.String = jrt.Intern("j2g --program")

var Lit_60 *jrt.String = jrt.Intern("ARBACE_PATH=/s")

var Lit_61 *jrt.String = jrt.Intern("GOGC=400")

var Lit_62 *jrt.String = jrt.Intern("GOMEMLIMIT=12GiB")

var Lit_63 *jrt.String = jrt.Intern("J2G_JOBS=")

var Lit_64 *jrt.String = jrt.Intern("/i")

var Lit_65 *jrt.String = jrt.Intern("j2g")

var Lit_66 *jrt.String = jrt.Intern("j2g/prog")

var Lit_67 *jrt.String = jrt.Intern("rebuild: j2g's program ")

var Lit_68 *jrt.String = jrt.Intern("tamago")

var Lit_69 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$forms__1433000061")

var Lit_70 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000063")

var Lit_71 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000065")

var Lit_72 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000068")

var Lit_73 *jrt.String = jrt.Intern("std")

var Lit_74 *jrt.String = jrt.Intern("print-goroot")

var Lit_75 *jrt.String = jrt.Intern("goroot/src")

var Lit_76 *jrt.String = jrt.Intern("tamago/")

var Lit_77 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$iter__1433000073__1433000077")

var Lit_78 *jrt.String = jrt.Intern("runtime")

var Lit_79 *jrt.String = jrt.Intern("syscall/fs_tamago.go")

var Lit_80 *jrt.String = jrt.Intern("goos")

var Lit_81 *jrt.String = jrt.Intern("go.mod")

var Lit_82 *jrt.String = jrt.Intern("goos/go.mod")

var Lit_83 *jrt.String = jrt.Intern("mod")

var Lit_84 *jrt.String = jrt.Intern("print-program")

var Lit_85 *jrt.String = jrt.Intern("config.edn")

var Lit_86 *jrt.String = jrt.Intern("{}")

var Lit_87 *jrt.String = jrt.Intern("the program sets GOEXPERIMENT ")

var Lit_88 *jrt.String = jrt.Intern(": not built by the driver")

var Lit_89 *jrt.String = jrt.Intern("arbace")

var Lit_90 *jrt.String = jrt.Intern("github.com/usbarmory/tamago")

var Lit_91 *jrt.String = jrt.Intern("arbace/cmd/arbace")

var Lit_92 *jrt.String = jrt.Intern("v1")

var Lit_93 *jrt.String = jrt.Intern("v8.0")

var Lit_94 *jrt.String = jrt.Intern("-T")

var Lit_95 *jrt.String = jrt.Intern("0x201000")

var Lit_96 *jrt.String = jrt.Intern("-R")

var Lit_97 *jrt.String = jrt.Intern("0x1000")

var Lit_98 *jrt.String = jrt.Intern("-w")

var Lit_99 *jrt.String = jrt.Intern("-X")

var Lit_100 *jrt.String = jrt.Intern("main.arbaceVersion=")

var Lit_101 *jrt.String = jrt.Intern("rebuild: the first image ")

var Lit_102 *jrt.String = jrt.Intern("namespaces.txt")

var Lit_103 *jrt.String = jrt.Intern("j2g's program has no namespaces.txt")

var Lit_104 *jrt.String = jrt.Intern("prepare the namespaces")

var Lit_105 *jrt.String = jrt.Intern("prepare.ae")

var Lit_106 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000093")

var Lit_107 *jrt.String = jrt.Intern("prepare")

var Lit_108 *jrt.String = jrt.Intern("image.bin")

var Lit_109 *jrt.String = jrt.Intern("prepare wrote no image")

var Lit_110 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000095")

var Lit_111 *jrt.String = jrt.Intern("rebuild: the image ")

var Lit_112 *jrt.String = jrt.Intern(" bytes) in ")

var Lit_113 *jrt.String = jrt.Intern("print tamago/ and overlay/go")

var Lit_114 *jrt.String = jrt.Intern("/f")

var Lit_115 *jrt.String = jrt.Intern("goroot")

var Lit_116 *jrt.String = jrt.Intern("/g")

var Lit_117 *jrt.String = jrt.Intern("print the program")

var Lit_118 *jrt.String = jrt.Intern("/p")

var Lit_119 *jrt.String = jrt.Intern("image:")

var Lit_120 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$fn__1433000095$fn__1433000096")

var Lit_121 *jrt.String = jrt.Intern("go")

var Lit_122 *jrt.String = jrt.Intern("arch/amd64/go")

var Lit_123 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$iter__1433000073__1433000077$fn__1433000078")

var Lit_124 *jrt.String = jrt.Intern("arbace.box.rebuild$steps$iter__1433000073__1433000077$fn__1433000078$fn__1433000079")

var Lit_125 *jrt.String = jrt.Intern("runtime/")

var Lit_126 *jrt.String = jrt.Intern("%.1f s")

var Lit_127 *jrt.String = jrt.Intern("VERSION")

var Lit_128 *jrt.String = jrt.Intern("$Format:")

var Lit_129 *jrt.String = jrt.Intern("{:describe \"unknown\" :commit nil :dirty nil}")

var Lit_130 *jrt.String = jrt.Intern("{:describe \"")

var Lit_131 *jrt.String = jrt.Intern("\" :commit \"")

var Lit_132 *jrt.String = jrt.Intern("\" :dirty false}")

var Lit_133 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn3,msgyn4,datayn1,xyn4,whatyn1,tkn3,tagyn6,Stringyn1,pyn5,namesyn1,ayn1,byn1,eyn3,srckn3,ramkn4,cpuskn4,linkyn3,resyn3,nssyn3,outyn4,optskn4,keysyn4,exityn7,consoleyn4,Fileyn6,imagesyn9,chrootrunyn4,workyn11,prepare-exev11,arbace.core5,in-nsMyn18,arbace.box.rebuildm2,R0,s3169,S3's chain in the box: Arbace's guest image from its sources, as bin/arbace-go --build --box\n  makes it on the host.\n\n    (rebuild src opts)   the image built from source tree src (a hash or a ref; the checkout as\n                         git archive gives it, VERSION filled): its hash; ref :ref (opts) pointed\n                         at it\n\n  The steps, each an action (arbace.box.build: a spawn, its result in the action cache):\n    compile     the namespaces compiled to Java forms (standalone S6, SA152) by the tools'\n                image, whose runtime is these sources' (bin/arbace-go's host_compile): the\n                namespaces listed, then prepared from the sources at /s and compiled\n                (arbace.c2j.main), the tree aot; skipped with :aot false (opts)\n    j2g         j2g --program in Arbace's guest (:host, the image that runs the tools), the\n                sources arbace/, go/, jdk/, overlay/ at /s and the compiled namespaces at /i:\n                the program as Go forms (prog)\n    print       repr/go's printing (arbace.box.print), in two guests: tamago/'s standard library and goos module\n                with jrt's runtime overlay and the file system's patch (overlay/go); the\n                program with box/ and x509roots/ (bin/arbace-go --build --box's printing)\n    plan        GOROOT/src, the module arbace and TamaGo's goos module as trees, planned in\n                Arbace (arbace.box.plan)\n    build       every package compiled (jrt and lang in 12 GiB guests: SA101 (b)), the image\n                linked with Arbace's version (-X main.arbaceVersion, from the tree's VERSION)\n    prepare     the image run once (ARBACE_PREPARE): the image of prepared namespaces\n    image       the main package compiled again with it, linked again, its symbol table cut\n                to the monitor's symbols (arbace.box.elf, tools/elfsyms's)\n\n  opts: :arch (amd64, arm64; by default the guest's own), :host (the image that runs j2g and\n  repr/go, a hash or a ref; by default the ref arbace.<arch>), :config (the toolchain's facts, a\n  hash or a ref; by default tool.config.<arch>: {:tool-tags [...] :release-tags [...] :include\n  TREE}, bin/box-tools put), :ref, :jobs (the compiles at once, by default 4), :j2g-cpus (by\n  default 8), :run (arbace.box.build's, the actions' executor: by default a spawn), :log,\n  :aot (false: the namespaces evaluated, ARBACE_AOT=0's build),\n  :given ({:aot TREE :j2g TREE :printed-goroot TREE :printed-program TREE}: those steps' results taken\n  as given, another run's, those steps not run: they are the same for every architecture;\n  doc/go/BOX-NOTES.md, S8, BX117).\n  (steps src opts) answers every intermediate result as a map instead.\n\n  natively, (host-run cfg) is an executor for :run that runs an action as a host process,\n  chrooted (tools/chrootrun) into a directory holding its trees at their mount points: the\n  images in (:images cfg), {HASH {:exe PATH :env [...]}}, run so (Go's compile, asm and link of\n  the host's toolchain; Arbace's native executable for the tools' image), any other spawned:\n  the same steps with the host's tools, the reference the image built in the box equals.m2,R0,s3169,S3's chain in the box: Arbace's guest image from its sources, as bin/arbace-go --build --box\n  makes it on the host.\n\n    (rebuild src opts)   the image built from source tree src (a hash or a ref; the checkout as\n                         git archive gives it, VERSION filled): its hash; ref :ref (opts) pointed\n                         at it\n\n  The steps, each an action (arbace.box.build: a spawn, its result in the action cache):\n    compile     the namespaces compiled to Java forms (standalone S6, SA152) by the tools'\n                image, whose runtime is these sources' (bin/arbace-go's host_compile): the\n                namespaces listed, then prepared from the sources at /s and compiled\n                (arbace.c2j.main), the tree aot; skipped with :aot false (opts)\n    j2g         j2g --program in Arbace's guest (:host, the image that runs the tools), the\n                sources arbace/, go/, jdk/, overlay/ at /s and the compiled namespaces at /i:\n                the program as Go forms (prog)\n    print       repr/go's printing (arbace.box.print), in two guests: tamago/'s standard library and goos module\n                with jrt's runtime overlay and the file system's patch (overlay/go); the\n                program with box/ and x509roots/ (bin/arbace-go --build --box's printing)\n    plan        GOROOT/src, the module arbace and TamaGo's goos module as trees, planned in\n                Arbace (arbace.box.plan)\n    build       every package compiled (jrt and lang in 12 GiB guests: SA101 (b)), the image\n                linked with Arbace's version (-X main.arbaceVersion, from the tree's VERSION)\n    prepare     the image run once (ARBACE_PREPARE): the image of prepared namespaces\n    image       the main package compiled again with it, linked again, its symbol table cut\n                to the monitor's symbols (arbace.box.elf, tools/elfsyms's)\n\n  opts: :arch (amd64, arm64; by default the guest's own), :host (the image that runs j2g and\n  repr/go, a hash or a ref; by default the ref arbace.<arch>), :config (the toolchain's facts, a\n  hash or a ref; by default tool.config.<arch>: {:tool-tags [...] :release-tags [...] :include\n  TREE}, bin/box-tools put), :ref, :jobs (the compiles at once, by default 4), :j2g-cpus (by\n  default 8), :run (arbace.box.build's, the actions' executor: by default a spawn), :log,\n  :aot (false: the namespaces evaluated, ARBACE_AOT=0's build),\n  :given ({:aot TREE :j2g TREE :printed-goroot TREE :printed-program TREE}: those steps' results taken\n  as given, another run's, those steps not run: they are the same for every architecture;\n  doc/go/BOX-NOTES.md, S8, BX117).\n  (steps src opts) answers every intermediate result as a map instead.\n\n  natively, (host-run cfg) is an executor for :run that runs an action as a host process,\n  chrooted (tools/chrootrun) into a directory holding its trees at their mount points: the\n  images in (:images cfg), {HASH {:exe PATH :env [...]}}, run so (Go's compile, asm and link of\n  the host's toolchain; Arbace's native executable for the tools' image), any other spawned:\n  the same steps with the host's tools, the reference the image built in the box equals.R1,v18,arbace.box.rebuild3,GiBm8,R2,TR3,i57,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild4,failm10,R2,TR6,L1,V2,R7,R8,R3,i59,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild7,hash-ofm12,R2,TR6,L1,V2,R9,R10,R0,s37,x, a hash or a ref's name, as a hash.R3,i65,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild6,dir-atm12,R2,TR6,L1,V2,R11,Myn1,pm2,R12,R13,R0,s53,The tree at path p of tree t, nil when there is none.R3,i72,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild7,dir-at!m10,R2,TR6,L1,V3,R11,R14,R10,R3,i78,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild11,select-treem12,R2,TR6,L1,V2,R11,R15,R0,s35,Tree t with only the named entries.R3,i82,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild8,lay-overm12,R2,TR6,L1,V2,R16,R17,R0,s102,Tree b laid over tree a: b's entries replace a's, but for directories in both, laid over\n  each other.R3,i87,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild6,put-atm10,R6,L1,V3,R11,Myn1,pm2,R12,R13,R18,R0,s83,Tree t (nil: an empty one) with entry e at path p (\"a/b.go\"), the directories made.R3,i98,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild9,file-textm10,R2,TR6,L1,V2,R11,R14,R3,i108,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild7,versionm10,R6,L1,V1,R19,R0,s149,The version map's text of source tree src (its VERSION, as git archive fills it):\n  {:describe \"...\" :commit \"...\" :dirty false}, or the unknown one.R3,i115,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild13,guest-symbolsV3,s12,whim_vectorss12,whim_apentrys21,runtime/goos.RamStartm8,R3,i130,R4,i1,R5,s21,arbace/box/rebuild.aeR0,s60,The symbols the monitor reads (bin/arbace-go's box_symbols).v18,arbace.box.rebuild17,default-resourcesR20,R21,l4,l2,R22,m8,R2,TR3,i134,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild7,arch-ofm10,R2,TR6,L1,V0,R3,i147,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild3,outm10,R2,TR6,L1,V2,R23,R10,R3,i150,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild14,prepare-scriptm12,R2,TR6,L1,V1,R24,R0,s75,bin/arbace-go's prepare script for the namespaces of namespaces.txt's text.R3,i153,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild17,namespaces-scriptm12,R2,TR6,L1,V0,R0,s94,bin/arbace-go's list of the embedded namespaces (j2g's namespaces.txt), written to /o/nss.txt.R3,i159,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild14,compile-scriptm12,R2,TR6,L1,V2,R24,R25,R0,s101,bin/arbace-go's host_compile script: the namespaces of nss's text prepared, then compiled\n  into out.R3,i167,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild5,stepsm10,R6,L1,V2,R19,R26,R0,s148,The rebuild of source tree src (see the namespace's doc): a map of every step's result\n  (trees, the plan, the images), :image the final one's hash.R3,i177,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild7,rebuildm10,R6,L2,V1,R19,V2,R19,R26,R0,s75,The image rebuilt from source tree src (see the namespace's doc): its hash.R3,i305,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild11,result-textm10,R2,TR6,L1,V1,m2,R27,V3,R28,R25,R29,R3,i313,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild11,delete-treem10,R2,TR6,L1,V1,Myn1,fm2,R12,R30,R3,i316,R4,i1,R5,s21,arbace/box/rebuild.aev18,arbace.box.rebuild8,host-runm10,R6,L1,V1,m2,R27,V4,R31,R32,R33,R34,R0,s375,An executor for arbace.box.build's :run (see the namespace's doc): cfg {:images {HASH\n  {:exe PATH :env [NAME=VALUE ...]}} :chrootrun PATH :work DIR :prepare-exe PATH}: a request\n  for an image of :images runs its :exe, one setting ARBACE_PREPARE runs :prepare-exe (the\n  native executable of the program: the image is the same on every architecture), any other\n  is spawned.R3,i322,R4,i1,R5,s21,arbace/box/rebuild.ae")

var Lit_134 *jrt.String = jrt.Intern("arbace.box.rebuild$eval1433000004$loading__1927001464__auto____1433000005")

var Lit_135 *jrt.String = jrt.Intern("arbace.box.rebuild$eval1433000008$fn__1433000009")

var Lit_136 *jrt.String = jrt.Intern("arbace.box.rebuild$fail")

var Lit_137 *jrt.String = jrt.Intern("arbace.box.rebuild$hash_of")

var Lit_138 *jrt.String = jrt.Intern("arbace.box.rebuild$dir_at")

var Lit_139 *jrt.String = jrt.Intern("arbace.box.rebuild$dir_at_BANG_")

var Lit_140 *jrt.String = jrt.Intern("arbace.box.rebuild$select_tree")

var Lit_141 *jrt.String = jrt.Intern("arbace.box.rebuild$lay_over")

var Lit_142 *jrt.String = jrt.Intern("arbace.box.rebuild$put_at")

var Lit_143 *jrt.String = jrt.Intern("arbace.box.rebuild$file_text")

var Lit_144 *jrt.String = jrt.Intern("arbace.box.rebuild$version")

var Lit_145 *jrt.String = jrt.Intern("arbace/jrt")

var Lit_146 *jrt.String = jrt.Intern("arbace/lang")

var Lit_147 *jrt.String = jrt.Intern("arbace/aot_arbace_core")

var Lit_148 *jrt.String = jrt.Intern("arbace/aot_*")

var Lit_149 *jrt.String = jrt.Intern("arbace.box.rebuild$arch_of")

var Lit_150 *jrt.String = jrt.Intern("arbace.box.rebuild$out")

var Lit_151 *jrt.String = jrt.Intern("arbace.box.rebuild$prepare_script")

var Lit_152 *jrt.String = jrt.Intern("arbace.box.rebuild$namespaces_script")

var Lit_153 *jrt.String = jrt.Intern("arbace.box.rebuild$compile_script")

var Lit_154 *jrt.String = jrt.Intern("arbace.box.rebuild$steps")

var Lit_155 *jrt.String = jrt.Intern("arbace.box.rebuild$rebuild")

var Lit_156 *jrt.String = jrt.Intern("arbace.box.rebuild$result_text")

var Lit_157 *jrt.String = jrt.Intern("arbace.box.rebuild$delete_tree")

var Lit_158 *jrt.String = jrt.Intern("arbace.box.rebuild$host_run")
