//line a2g_classes.ae:1
package aot_arbace_box_rebuild

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_box_rebuild_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_A_New()}; return nil }

var A_arbace_box_rebuild_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_rebuild_A_new}

var A_arbace_box_rebuild_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_A"})

func init() { i := A_arbace_box_rebuild_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_A_InstanceOf; i.Init = A_arbace_box_rebuild_A_Init; i.Table = A_arbace_box_rebuild_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_A_class, reflect.TypeFor[A_arbace_box_rebuild_A]()) }

func A_arbace_box_rebuild_arch_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_arch_of_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_arch_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_arch_of_A_New()}; return nil }

func A_arbace_box_rebuild_arch_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_arch_of_A_fn_class)}; return nil }

var A_arbace_box_rebuild_arch_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_arch_of_A_invoke, New: A_arbace_box_rebuild_arch_of_A_new, Get: A_arbace_box_rebuild_arch_of_A_get}

var A_arbace_box_rebuild_arch_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$arch_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "arch_of", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_arch_of_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_arch_of_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_arch_of_A_InstanceOf; i.Init = A_arbace_box_rebuild_arch_of_A_Init; i.Table = A_arbace_box_rebuild_arch_of_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_arch_of_A_class, reflect.TypeFor[A_arbace_box_rebuild_arch_of_A]()) }

func A_arbace_box_rebuild_compile_script_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_compile_script_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_compile_script_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_compile_script_A_New()}; return nil }

func A_arbace_box_rebuild_compile_script_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_compile_script_A_fn_class)}; return nil }

var A_arbace_box_rebuild_compile_script_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_compile_script_A_invoke, New: A_arbace_box_rebuild_compile_script_A_new, Get: A_arbace_box_rebuild_compile_script_A_get}

var A_arbace_box_rebuild_compile_script_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$compile_script", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "compile_script", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_compile_script_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_compile_script_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_compile_script_A_InstanceOf; i.Init = A_arbace_box_rebuild_compile_script_A_Init; i.Table = A_arbace_box_rebuild_compile_script_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_compile_script_A_class, reflect.TypeFor[A_arbace_box_rebuild_compile_script_A]()) }

func A_arbace_box_rebuild_delete_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_delete_tree_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_delete_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_delete_tree_A_New()}; return nil }

func A_arbace_box_rebuild_delete_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_delete_tree_A_fn_class)}; return nil }

var A_arbace_box_rebuild_delete_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_delete_tree_A_invoke, New: A_arbace_box_rebuild_delete_tree_A_new, Get: A_arbace_box_rebuild_delete_tree_A_get}

var A_arbace_box_rebuild_delete_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$delete_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "delete_tree", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_delete_tree_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_delete_tree_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_delete_tree_A_InstanceOf; i.Init = A_arbace_box_rebuild_delete_tree_A_Init; i.Table = A_arbace_box_rebuild_delete_tree_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_delete_tree_A_class, reflect.TypeFor[A_arbace_box_rebuild_delete_tree_A]()) }

func A_arbace_box_rebuild_dir_at_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_dir_at_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_dir_at_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_dir_at_A_New()}; return nil }

func A_arbace_box_rebuild_dir_at_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_dir_at_A_fn_class)}; return nil }

var A_arbace_box_rebuild_dir_at_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_dir_at_A_invoke, New: A_arbace_box_rebuild_dir_at_A_new, Get: A_arbace_box_rebuild_dir_at_A_get}

var A_arbace_box_rebuild_dir_at_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$dir_at", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "dir_at", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_dir_at_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_dir_at_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_dir_at_A_InstanceOf; i.Init = A_arbace_box_rebuild_dir_at_A_Init; i.Table = A_arbace_box_rebuild_dir_at_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_dir_at_A_class, reflect.TypeFor[A_arbace_box_rebuild_dir_at_A]()) }

func A_arbace_box_rebuild_dir_at_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_dir_at_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_rebuild_dir_at_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_dir_at_BANG__A_New()}; return nil }

func A_arbace_box_rebuild_dir_at_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_dir_at_BANG__A_fn_class)}; return nil }

var A_arbace_box_rebuild_dir_at_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_dir_at_BANG__A_invoke, New: A_arbace_box_rebuild_dir_at_BANG__A_new, Get: A_arbace_box_rebuild_dir_at_BANG__A_get}

var A_arbace_box_rebuild_dir_at_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$dir_at_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "dir_at_BANG_", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_dir_at_BANG__A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_dir_at_BANG__A_class.Info(); i.IsInstance = A_arbace_box_rebuild_dir_at_BANG__A_InstanceOf; i.Init = A_arbace_box_rebuild_dir_at_BANG__A_Init; i.Table = A_arbace_box_rebuild_dir_at_BANG__A_members; jrt.RegisterGoType(A_arbace_box_rebuild_dir_at_BANG__A_class, reflect.TypeFor[A_arbace_box_rebuild_dir_at_BANG__A]()) }

func A_arbace_box_rebuild_eval1433000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_eval1433000004_A_New()}; return nil }

var A_arbace_box_rebuild_eval1433000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_rebuild_eval1433000004_A_new}

var A_arbace_box_rebuild_eval1433000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$eval1433000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_rebuild_A_class, Simple: "eval1433000004", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_eval1433000004_A"})

func init() { i := A_arbace_box_rebuild_eval1433000004_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_eval1433000004_A_InstanceOf; i.Table = A_arbace_box_rebuild_eval1433000004_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_eval1433000004_A_class, reflect.TypeFor[A_arbace_box_rebuild_eval1433000004_A]()) }

func A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_New()}; return nil }

func A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_fn_class)}; return nil }

var A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_invoke, New: A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_new, Get: A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_get}

var A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$eval1433000004$loading__1927001464__auto____1433000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_eval1433000004_A_class, Simple: "loading__1927001464__auto____1433000005", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_InstanceOf; i.Init = A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_Init; i.Table = A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_class, reflect.TypeFor[A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A]()) }

func A_arbace_box_rebuild_eval1433000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_eval1433000008_A_New()}; return nil }

var A_arbace_box_rebuild_eval1433000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_rebuild_eval1433000008_A_new}

var A_arbace_box_rebuild_eval1433000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$eval1433000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_rebuild_A_class, Simple: "eval1433000008", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_eval1433000008_A"})

func init() { i := A_arbace_box_rebuild_eval1433000008_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_eval1433000008_A_InstanceOf; i.Table = A_arbace_box_rebuild_eval1433000008_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_eval1433000008_A_class, reflect.TypeFor[A_arbace_box_rebuild_eval1433000008_A]()) }

func A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_eval1433000008_fn__1433000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_New()}; return nil }

func A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_fn_class)}; return nil }

var A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_invoke, New: A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_new, Get: A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_get}

var A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$eval1433000008$fn__1433000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_eval1433000008_A_class, Simple: "fn__1433000009", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_eval1433000008_fn__1433000009_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_InstanceOf; i.Init = A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_Init; i.Table = A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_class, reflect.TypeFor[A_arbace_box_rebuild_eval1433000008_fn__1433000009_A]()) }

func A_arbace_box_rebuild_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_fail_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_fail_A_New()}; return nil }

func A_arbace_box_rebuild_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_fail_A_fn_class)}; return nil }

var A_arbace_box_rebuild_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_fail_A_invoke, New: A_arbace_box_rebuild_fail_A_new, Get: A_arbace_box_rebuild_fail_A_get}

var A_arbace_box_rebuild_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "fail", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_fail_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_fail_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_fail_A_InstanceOf; i.Init = A_arbace_box_rebuild_fail_A_Init; i.Table = A_arbace_box_rebuild_fail_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_fail_A_class, reflect.TypeFor[A_arbace_box_rebuild_fail_A]()) }

func A_arbace_box_rebuild_file_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_file_text_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_file_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_file_text_A_New()}; return nil }

func A_arbace_box_rebuild_file_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_file_text_A_fn_class)}; return nil }

var A_arbace_box_rebuild_file_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_file_text_A_invoke, New: A_arbace_box_rebuild_file_text_A_new, Get: A_arbace_box_rebuild_file_text_A_get}

var A_arbace_box_rebuild_file_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$file_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "file_text", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_file_text_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_file_text_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_file_text_A_InstanceOf; i.Init = A_arbace_box_rebuild_file_text_A_Init; i.Table = A_arbace_box_rebuild_file_text_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_file_text_A_class, reflect.TypeFor[A_arbace_box_rebuild_file_text_A]()) }

func A_arbace_box_rebuild_hash_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_hash_of_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_hash_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_hash_of_A_New()}; return nil }

func A_arbace_box_rebuild_hash_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_hash_of_A_fn_class)}; return nil }

var A_arbace_box_rebuild_hash_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_hash_of_A_invoke, New: A_arbace_box_rebuild_hash_of_A_new, Get: A_arbace_box_rebuild_hash_of_A_get}

var A_arbace_box_rebuild_hash_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$hash_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "hash_of", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_hash_of_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_hash_of_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_hash_of_A_InstanceOf; i.Init = A_arbace_box_rebuild_hash_of_A_Init; i.Table = A_arbace_box_rebuild_hash_of_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_hash_of_A_class, reflect.TypeFor[A_arbace_box_rebuild_hash_of_A]()) }

func A_arbace_box_rebuild_host_run_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_host_run_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_host_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_host_run_A_New()}; return nil }

func A_arbace_box_rebuild_host_run_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_host_run_A_fn_class)}; return nil }

var A_arbace_box_rebuild_host_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_host_run_A_invoke, New: A_arbace_box_rebuild_host_run_A_new, Get: A_arbace_box_rebuild_host_run_A_get}

var A_arbace_box_rebuild_host_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$host_run", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "host_run", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_host_run_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_host_run_A_InstanceOf; i.Init = A_arbace_box_rebuild_host_run_A_Init; i.Table = A_arbace_box_rebuild_host_run_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_host_run_A_class, reflect.TypeFor[A_arbace_box_rebuild_host_run_A]()) }

func A_arbace_box_rebuild_host_run_fn__1433000114_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_host_run_fn__1433000114_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_host_run_fn__1433000114_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_host_run_fn__1433000114_A_fn_class)}; return nil }

var A_arbace_box_rebuild_host_run_fn__1433000114_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_host_run_fn__1433000114_A_invoke, New: A_arbace_box_rebuild_host_run_fn__1433000114_A_new, Get: A_arbace_box_rebuild_host_run_fn__1433000114_A_get}

var A_arbace_box_rebuild_host_run_fn__1433000114_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$host_run$fn__1433000114", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_host_run_A_class, Simple: "fn__1433000114", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_host_run_fn__1433000114_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_host_run_fn__1433000114_A_InstanceOf; i.Init = A_arbace_box_rebuild_host_run_fn__1433000114_A_Init; i.Table = A_arbace_box_rebuild_host_run_fn__1433000114_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_host_run_fn__1433000114_A_class, reflect.TypeFor[A_arbace_box_rebuild_host_run_fn__1433000114_A]()) }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_New()}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_fn_class)}; return nil }

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_invoke, New: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_new, Get: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_get}

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$host_run$fn__1433000114$fn__1433000115", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_host_run_fn__1433000114_A_class, Simple: "fn__1433000115", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_InstanceOf; i.Init = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_Init; i.Table = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_class, reflect.TypeFor[A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A]()) }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_fn_class)}; return nil }

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_invoke, New: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_new, Get: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_get}

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$host_run$fn__1433000114$fn__1433000123", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_host_run_fn__1433000114_A_class, Simple: "fn__1433000123", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_InstanceOf; i.Init = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_Init; i.Table = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_class, reflect.TypeFor[A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A]()) }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_fn_class)}; return nil }

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_invoke, New: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_new, Get: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_get}

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$host_run$fn__1433000114$fn__1433000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_host_run_fn__1433000114_A_class, Simple: "fn__1433000135", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_InstanceOf; i.Init = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_Init; i.Table = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_class, reflect.TypeFor[A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A]()) }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_fn_class)}; return nil }

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_invoke, New: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_new, Get: A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_get}

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$host_run$fn__1433000114$fn__1433000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_host_run_fn__1433000114_A_class, Simple: "fn__1433000141", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_InstanceOf; i.Init = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_Init; i.Table = A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_class, reflect.TypeFor[A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A]()) }

func A_arbace_box_rebuild_lay_over_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_lay_over_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_lay_over_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_lay_over_A_New()}; return nil }

func A_arbace_box_rebuild_lay_over_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_lay_over_A_fn_class)}; return nil }

var A_arbace_box_rebuild_lay_over_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_lay_over_A_invoke, New: A_arbace_box_rebuild_lay_over_A_new, Get: A_arbace_box_rebuild_lay_over_A_get}

var A_arbace_box_rebuild_lay_over_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$lay_over", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "lay_over", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_lay_over_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_lay_over_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_lay_over_A_InstanceOf; i.Init = A_arbace_box_rebuild_lay_over_A_Init; i.Table = A_arbace_box_rebuild_lay_over_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_lay_over_A_class, reflect.TypeFor[A_arbace_box_rebuild_lay_over_A]()) }

func A_arbace_box_rebuild_lay_over_fn__1433000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_lay_over_fn__1433000021_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_lay_over_fn__1433000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_lay_over_fn__1433000021_A_New()}; return nil }

func A_arbace_box_rebuild_lay_over_fn__1433000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_lay_over_fn__1433000021_A_fn_class)}; return nil }

var A_arbace_box_rebuild_lay_over_fn__1433000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_lay_over_fn__1433000021_A_invoke, New: A_arbace_box_rebuild_lay_over_fn__1433000021_A_new, Get: A_arbace_box_rebuild_lay_over_fn__1433000021_A_get}

var A_arbace_box_rebuild_lay_over_fn__1433000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$lay_over$fn__1433000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_lay_over_A_class, Simple: "fn__1433000021", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_lay_over_fn__1433000021_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_lay_over_fn__1433000021_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_lay_over_fn__1433000021_A_InstanceOf; i.Init = A_arbace_box_rebuild_lay_over_fn__1433000021_A_Init; i.Table = A_arbace_box_rebuild_lay_over_fn__1433000021_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_lay_over_fn__1433000021_A_class, reflect.TypeFor[A_arbace_box_rebuild_lay_over_fn__1433000021_A]()) }

func A_arbace_box_rebuild_namespaces_script_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_namespaces_script_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_namespaces_script_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_namespaces_script_A_New()}; return nil }

func A_arbace_box_rebuild_namespaces_script_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_namespaces_script_A_fn_class)}; return nil }

var A_arbace_box_rebuild_namespaces_script_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_namespaces_script_A_invoke, New: A_arbace_box_rebuild_namespaces_script_A_new, Get: A_arbace_box_rebuild_namespaces_script_A_get}

var A_arbace_box_rebuild_namespaces_script_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$namespaces_script", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "namespaces_script", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_namespaces_script_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_namespaces_script_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_namespaces_script_A_InstanceOf; i.Init = A_arbace_box_rebuild_namespaces_script_A_Init; i.Table = A_arbace_box_rebuild_namespaces_script_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_namespaces_script_A_class, reflect.TypeFor[A_arbace_box_rebuild_namespaces_script_A]()) }

func A_arbace_box_rebuild_out_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_out_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_out_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_out_A_New()}; return nil }

func A_arbace_box_rebuild_out_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_out_A_fn_class)}; return nil }

var A_arbace_box_rebuild_out_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_out_A_invoke, New: A_arbace_box_rebuild_out_A_new, Get: A_arbace_box_rebuild_out_A_get}

var A_arbace_box_rebuild_out_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$out", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "out", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_out_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_out_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_out_A_InstanceOf; i.Init = A_arbace_box_rebuild_out_A_Init; i.Table = A_arbace_box_rebuild_out_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_out_A_class, reflect.TypeFor[A_arbace_box_rebuild_out_A]()) }

func A_arbace_box_rebuild_prepare_script_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_prepare_script_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_prepare_script_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_prepare_script_A_New()}; return nil }

func A_arbace_box_rebuild_prepare_script_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_prepare_script_A_fn_class)}; return nil }

var A_arbace_box_rebuild_prepare_script_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_prepare_script_A_invoke, New: A_arbace_box_rebuild_prepare_script_A_new, Get: A_arbace_box_rebuild_prepare_script_A_get}

var A_arbace_box_rebuild_prepare_script_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$prepare_script", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "prepare_script", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_prepare_script_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_prepare_script_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_prepare_script_A_InstanceOf; i.Init = A_arbace_box_rebuild_prepare_script_A_Init; i.Table = A_arbace_box_rebuild_prepare_script_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_prepare_script_A_class, reflect.TypeFor[A_arbace_box_rebuild_prepare_script_A]()) }

func A_arbace_box_rebuild_put_at_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_put_at_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_rebuild_put_at_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_put_at_A_New()}; return nil }

func A_arbace_box_rebuild_put_at_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_put_at_A_fn_class)}; return nil }

var A_arbace_box_rebuild_put_at_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_put_at_A_invoke, New: A_arbace_box_rebuild_put_at_A_new, Get: A_arbace_box_rebuild_put_at_A_get}

var A_arbace_box_rebuild_put_at_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$put_at", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "put_at", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_put_at_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_put_at_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_put_at_A_InstanceOf; i.Init = A_arbace_box_rebuild_put_at_A_Init; i.Table = A_arbace_box_rebuild_put_at_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_put_at_A_class, reflect.TypeFor[A_arbace_box_rebuild_put_at_A]()) }

func A_arbace_box_rebuild_rebuild_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_rebuild_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_box_rebuild_rebuild_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_rebuild_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_rebuild_A_New()}; return nil }

func A_arbace_box_rebuild_rebuild_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_rebuild_A_fn_class)}; return nil }

var A_arbace_box_rebuild_rebuild_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_rebuild_A_invoke, New: A_arbace_box_rebuild_rebuild_A_new, Get: A_arbace_box_rebuild_rebuild_A_get}

var A_arbace_box_rebuild_rebuild_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$rebuild", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "rebuild", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_rebuild_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_rebuild_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_rebuild_A_InstanceOf; i.Init = A_arbace_box_rebuild_rebuild_A_Init; i.Table = A_arbace_box_rebuild_rebuild_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_rebuild_A_class, reflect.TypeFor[A_arbace_box_rebuild_rebuild_A]()) }

func A_arbace_box_rebuild_result_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_result_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_result_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_result_text_A_New()}; return nil }

func A_arbace_box_rebuild_result_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_result_text_A_fn_class)}; return nil }

var A_arbace_box_rebuild_result_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_result_text_A_invoke, New: A_arbace_box_rebuild_result_text_A_new, Get: A_arbace_box_rebuild_result_text_A_get}

var A_arbace_box_rebuild_result_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$result_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "result_text", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_result_text_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_result_text_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_result_text_A_InstanceOf; i.Init = A_arbace_box_rebuild_result_text_A_Init; i.Table = A_arbace_box_rebuild_result_text_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_result_text_A_class, reflect.TypeFor[A_arbace_box_rebuild_result_text_A]()) }

func A_arbace_box_rebuild_select_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_select_tree_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_select_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_select_tree_A_New()}; return nil }

func A_arbace_box_rebuild_select_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_select_tree_A_fn_class)}; return nil }

var A_arbace_box_rebuild_select_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_select_tree_A_invoke, New: A_arbace_box_rebuild_select_tree_A_new, Get: A_arbace_box_rebuild_select_tree_A_get}

var A_arbace_box_rebuild_select_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$select_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "select_tree", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_select_tree_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_select_tree_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_select_tree_A_InstanceOf; i.Init = A_arbace_box_rebuild_select_tree_A_Init; i.Table = A_arbace_box_rebuild_select_tree_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_select_tree_A_class, reflect.TypeFor[A_arbace_box_rebuild_select_tree_A]()) }

func A_arbace_box_rebuild_steps_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_steps_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_A_New()}; return nil }

func A_arbace_box_rebuild_steps_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_A_invoke, New: A_arbace_box_rebuild_steps_A_new, Get: A_arbace_box_rebuild_steps_A_get}

var A_arbace_box_rebuild_steps_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "steps", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_A_Init; i.Table = A_arbace_box_rebuild_steps_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_A]()) }

func A_arbace_box_rebuild_steps_fn__1433000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_fn__1433000063_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_fn__1433000063_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_fn__1433000063_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_fn__1433000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_fn__1433000063_A_invoke, New: A_arbace_box_rebuild_steps_fn__1433000063_A_new, Get: A_arbace_box_rebuild_steps_fn__1433000063_A_get}

var A_arbace_box_rebuild_steps_fn__1433000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$fn__1433000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_steps_A_class, Simple: "fn__1433000063", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000063_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_fn__1433000063_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_fn__1433000063_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_fn__1433000063_A_Init; i.Table = A_arbace_box_rebuild_steps_fn__1433000063_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_fn__1433000063_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_fn__1433000063_A]()) }

func A_arbace_box_rebuild_steps_fn__1433000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_fn__1433000065_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_fn__1433000065_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_fn__1433000065_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_fn__1433000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_fn__1433000065_A_invoke, New: A_arbace_box_rebuild_steps_fn__1433000065_A_new, Get: A_arbace_box_rebuild_steps_fn__1433000065_A_get}

var A_arbace_box_rebuild_steps_fn__1433000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$fn__1433000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_steps_A_class, Simple: "fn__1433000065", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000065_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_fn__1433000065_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_fn__1433000065_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_fn__1433000065_A_Init; i.Table = A_arbace_box_rebuild_steps_fn__1433000065_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_fn__1433000065_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_fn__1433000065_A]()) }

func A_arbace_box_rebuild_steps_fn__1433000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_fn__1433000068_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_fn__1433000068_A_New()}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_fn__1433000068_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_fn__1433000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_fn__1433000068_A_invoke, New: A_arbace_box_rebuild_steps_fn__1433000068_A_new, Get: A_arbace_box_rebuild_steps_fn__1433000068_A_get}

var A_arbace_box_rebuild_steps_fn__1433000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$fn__1433000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_steps_A_class, Simple: "fn__1433000068", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000068_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_fn__1433000068_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_fn__1433000068_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_fn__1433000068_A_Init; i.Table = A_arbace_box_rebuild_steps_fn__1433000068_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_fn__1433000068_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_fn__1433000068_A]()) }

func A_arbace_box_rebuild_steps_fn__1433000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_fn__1433000093_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_fn__1433000093_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_fn__1433000093_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_fn__1433000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_fn__1433000093_A_invoke, New: A_arbace_box_rebuild_steps_fn__1433000093_A_new, Get: A_arbace_box_rebuild_steps_fn__1433000093_A_get}

var A_arbace_box_rebuild_steps_fn__1433000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$fn__1433000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_steps_A_class, Simple: "fn__1433000093", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000093_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_fn__1433000093_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_fn__1433000093_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_fn__1433000093_A_Init; i.Table = A_arbace_box_rebuild_steps_fn__1433000093_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_fn__1433000093_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_fn__1433000093_A]()) }

func A_arbace_box_rebuild_steps_fn__1433000095_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_fn__1433000095_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000095_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_fn__1433000095_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000095_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_fn__1433000095_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_fn__1433000095_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_fn__1433000095_A_invoke, New: A_arbace_box_rebuild_steps_fn__1433000095_A_new, Get: A_arbace_box_rebuild_steps_fn__1433000095_A_get}

var A_arbace_box_rebuild_steps_fn__1433000095_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$fn__1433000095", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_steps_A_class, Simple: "fn__1433000095", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000095_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_fn__1433000095_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_fn__1433000095_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_fn__1433000095_A_Init; i.Table = A_arbace_box_rebuild_steps_fn__1433000095_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_fn__1433000095_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_fn__1433000095_A]()) }

func A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_invoke, New: A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_new, Get: A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_get}

var A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$fn__1433000095$fn__1433000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_steps_fn__1433000095_A_class, Simple: "fn__1433000096", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_Init; i.Table = A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A]()) }

func A_arbace_box_rebuild_steps_forms__1433000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_forms__1433000061_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_steps_forms__1433000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_forms__1433000061_A_New()}; return nil }

func A_arbace_box_rebuild_steps_forms__1433000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_forms__1433000061_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_forms__1433000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_forms__1433000061_A_invoke, New: A_arbace_box_rebuild_steps_forms__1433000061_A_new, Get: A_arbace_box_rebuild_steps_forms__1433000061_A_get}

var A_arbace_box_rebuild_steps_forms__1433000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$forms__1433000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_steps_A_class, Simple: "forms__1433000061", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_forms__1433000061_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_forms__1433000061_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_forms__1433000061_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_forms__1433000061_A_Init; i.Table = A_arbace_box_rebuild_steps_forms__1433000061_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_forms__1433000061_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_forms__1433000061_A]()) }

func A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_New()}; return nil }

func A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_invoke, New: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_new, Get: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_get}

var A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$iter__1433000073__1433000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_steps_A_class, Simple: "iter__1433000073__1433000077", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_Init; i.Table = A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A]()) }

func A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_invoke, New: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_new, Get: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_get}

var A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$iter__1433000073__1433000077$fn__1433000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_class, Simple: "fn__1433000078", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_Init; i.Table = A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A]()) }

func A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_invoke, New: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_new, Get: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_get}

var A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$iter__1433000073__1433000077$fn__1433000078$fn__1433000079", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_class, Simple: "fn__1433000079", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_Init; i.Table = A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A]()) }

func A_arbace_box_rebuild_steps_run__1433000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_run__1433000051_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_rebuild_steps_run__1433000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_run__1433000051_A_New_O(args[0])}; return nil }

func A_arbace_box_rebuild_steps_run__1433000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_run__1433000051_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_run__1433000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_run__1433000051_A_invoke, New: A_arbace_box_rebuild_steps_run__1433000051_A_new, Get: A_arbace_box_rebuild_steps_run__1433000051_A_get}

var A_arbace_box_rebuild_steps_run__1433000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$run__1433000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_rebuild_steps_A_class, Simple: "run__1433000051", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_run__1433000051_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_run__1433000051_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_run__1433000051_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_run__1433000051_A_Init; i.Table = A_arbace_box_rebuild_steps_run__1433000051_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_run__1433000051_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_run__1433000051_A]()) }

func A_arbace_box_rebuild_steps_secs__1433000053_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_steps_secs__1433000053_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_rebuild_steps_secs__1433000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_steps_secs__1433000053_A_New_J(args[0].(int64))}; return nil }

func A_arbace_box_rebuild_steps_secs__1433000053_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_steps_secs__1433000053_A_fn_class)}; return nil }

var A_arbace_box_rebuild_steps_secs__1433000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_steps_secs__1433000053_A_invoke, New: A_arbace_box_rebuild_steps_secs__1433000053_A_new, Get: A_arbace_box_rebuild_steps_secs__1433000053_A_get}

var A_arbace_box_rebuild_steps_secs__1433000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$steps$secs__1433000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_rebuild_steps_A_class, Simple: "secs__1433000053", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_secs__1433000053_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_steps_secs__1433000053_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_steps_secs__1433000053_A_InstanceOf; i.Init = A_arbace_box_rebuild_steps_secs__1433000053_A_Init; i.Table = A_arbace_box_rebuild_steps_secs__1433000053_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_steps_secs__1433000053_A_class, reflect.TypeFor[A_arbace_box_rebuild_steps_secs__1433000053_A]()) }

func A_arbace_box_rebuild_version_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_rebuild_version_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_rebuild_version_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_version_A_New()}; return nil }

func A_arbace_box_rebuild_version_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_rebuild_version_A_fn_class)}; return nil }

var A_arbace_box_rebuild_version_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_rebuild_version_A_invoke, New: A_arbace_box_rebuild_version_A_new, Get: A_arbace_box_rebuild_version_A_get}

var A_arbace_box_rebuild_version_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$version", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_rebuild_A_class, Simple: "version", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_version_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild_version_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_version_A_InstanceOf; i.Init = A_arbace_box_rebuild_version_A_Init; i.Table = A_arbace_box_rebuild_version_A_members; jrt.RegisterGoType(A_arbace_box_rebuild_version_A_class, reflect.TypeFor[A_arbace_box_rebuild_version_A]()) }

func A_arbace_box_rebuild__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_rebuild__init_A_Load__O(); case 1: return A_arbace_box_rebuild__init_A_Unit0__O(); case 2: return A_arbace_box_rebuild__init_A_Unit1__O(); case 3: return A_arbace_box_rebuild__init_A_Unit10__O(); case 4: return A_arbace_box_rebuild__init_A_Unit11__O(); case 5: return A_arbace_box_rebuild__init_A_Unit12__O(); case 6: return A_arbace_box_rebuild__init_A_Unit13__O(); case 7: return A_arbace_box_rebuild__init_A_Unit14__O(); case 8: return A_arbace_box_rebuild__init_A_Unit15__O(); case 9: return A_arbace_box_rebuild__init_A_Unit16__O(); case 10: return A_arbace_box_rebuild__init_A_Unit17__O(); case 11: return A_arbace_box_rebuild__init_A_Unit18__O(); case 12: return A_arbace_box_rebuild__init_A_Unit19__O(); case 13: return A_arbace_box_rebuild__init_A_Unit2__O(); case 14: return A_arbace_box_rebuild__init_A_Unit20__O(); case 15: return A_arbace_box_rebuild__init_A_Unit21__O(); case 16: return A_arbace_box_rebuild__init_A_Unit22__O(); case 17: return A_arbace_box_rebuild__init_A_Unit23__O(); case 18: return A_arbace_box_rebuild__init_A_Unit24__O(); case 19: return A_arbace_box_rebuild__init_A_Unit25__O(); case 20: return A_arbace_box_rebuild__init_A_Unit3__O(); case 21: return A_arbace_box_rebuild__init_A_Unit4__O(); case 22: return A_arbace_box_rebuild__init_A_Unit5__O(); case 23: return A_arbace_box_rebuild__init_A_Unit6__O(); case 24: return A_arbace_box_rebuild__init_A_Unit7__O(); case 25: return A_arbace_box_rebuild__init_A_Unit8__O(); case 26: return A_arbace_box_rebuild__init_A_Unit9__O()}; return nil }

func A_arbace_box_rebuild__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild__init_A_New()}; return nil }

var A_arbace_box_rebuild__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_rebuild__init_A_invoke, New: A_arbace_box_rebuild__init_A_new}

var A_arbace_box_rebuild__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild__init_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild__init_A_class.Info(); i.IsInstance = A_arbace_box_rebuild__init_A_InstanceOf; i.Init = A_arbace_box_rebuild__init_A_Init; i.Table = A_arbace_box_rebuild__init_A_members; jrt.RegisterGoType(A_arbace_box_rebuild__init_A_class, reflect.TypeFor[A_arbace_box_rebuild__init_A]()) }
