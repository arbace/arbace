//line j2g_classes.ae:1
package aot_arbace_box_rebuild

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_box_rebuild_arch_of_A_class, Name: "arbace.box.rebuild$arch_of", Modifiers: 25, Simple: "arch_of", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_arch_of_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_compile_script_A_class, Name: "arbace.box.rebuild$compile_script", Modifiers: 25, Simple: "compile_script", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_compile_script_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_delete_tree_A_class, Name: "arbace.box.rebuild$delete_tree", Modifiers: 25, Simple: "delete_tree", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_delete_tree_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_dir_at_A_class, Name: "arbace.box.rebuild$dir_at", Modifiers: 25, Simple: "dir_at", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_dir_at_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_dir_at_BANG__A_class, Name: "arbace.box.rebuild$dir_at_BANG_", Modifiers: 25, Simple: "dir_at_BANG_", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_dir_at_BANG__A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_class, Name: "arbace.box.rebuild$eval1433000004$loading__1927001464__auto____1433000005", Modifiers: 25, Simple: "loading__1927001464__auto____1433000005", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_eval1433000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_class, Name: "arbace.box.rebuild$eval1433000008$fn__1433000009", Modifiers: 25, Simple: "fn__1433000009", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_eval1433000008_fn__1433000009_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_eval1433000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_fail_A_class, Name: "arbace.box.rebuild$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_fail_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_file_text_A_class, Name: "arbace.box.rebuild$file_text", Modifiers: 25, Simple: "file_text", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_file_text_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_hash_of_A_class, Name: "arbace.box.rebuild$hash_of", Modifiers: 25, Simple: "hash_of", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_hash_of_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_host_run_A_class, Name: "arbace.box.rebuild$host_run", Modifiers: 25, Simple: "host_run", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_host_run_fn__1433000114_A_class, Name: "arbace.box.rebuild$host_run$fn__1433000114", Modifiers: 25, Simple: "fn__1433000114", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_host_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_class, Name: "arbace.box.rebuild$host_run$fn__1433000114$fn__1433000115", Modifiers: 25, Simple: "fn__1433000115", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_host_run_fn__1433000114_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_class, Name: "arbace.box.rebuild$host_run$fn__1433000114$fn__1433000123", Modifiers: 25, Simple: "fn__1433000123", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_host_run_fn__1433000114_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_class, Name: "arbace.box.rebuild$host_run$fn__1433000114$fn__1433000135", Modifiers: 25, Simple: "fn__1433000135", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_host_run_fn__1433000114_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_class, Name: "arbace.box.rebuild$host_run$fn__1433000114$fn__1433000141", Modifiers: 25, Simple: "fn__1433000141", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_host_run_fn__1433000114_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_lay_over_A_class, Name: "arbace.box.rebuild$lay_over", Modifiers: 25, Simple: "lay_over", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_lay_over_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_lay_over_fn__1433000021_A_class, Name: "arbace.box.rebuild$lay_over$fn__1433000021", Modifiers: 25, Simple: "fn__1433000021", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_lay_over_fn__1433000021_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_lay_over_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_namespaces_script_A_class, Name: "arbace.box.rebuild$namespaces_script", Modifiers: 25, Simple: "namespaces_script", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_namespaces_script_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_out_A_class, Name: "arbace.box.rebuild$out", Modifiers: 25, Simple: "out", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_out_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_prepare_script_A_class, Name: "arbace.box.rebuild$prepare_script", Modifiers: 25, Simple: "prepare_script", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_prepare_script_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_put_at_A_class, Name: "arbace.box.rebuild$put_at", Modifiers: 25, Simple: "put_at", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_put_at_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_rebuild_A_class, Name: "arbace.box.rebuild$rebuild", Modifiers: 25, Simple: "rebuild", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_rebuild_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_result_text_A_class, Name: "arbace.box.rebuild$result_text", Modifiers: 25, Simple: "result_text", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_result_text_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_select_tree_A_class, Name: "arbace.box.rebuild$select_tree", Modifiers: 25, Simple: "select_tree", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_select_tree_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_A_class, Name: "arbace.box.rebuild$steps", Modifiers: 25, Simple: "steps", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_fn__1433000063_A_class, Name: "arbace.box.rebuild$steps$fn__1433000063", Modifiers: 25, Simple: "fn__1433000063", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000063_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_fn__1433000065_A_class, Name: "arbace.box.rebuild$steps$fn__1433000065", Modifiers: 25, Simple: "fn__1433000065", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000065_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_fn__1433000068_A_class, Name: "arbace.box.rebuild$steps$fn__1433000068", Modifiers: 25, Simple: "fn__1433000068", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000068_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_fn__1433000093_A_class, Name: "arbace.box.rebuild$steps$fn__1433000093", Modifiers: 25, Simple: "fn__1433000093", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000093_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_fn__1433000095_A_class, Name: "arbace.box.rebuild$steps$fn__1433000095", Modifiers: 25, Simple: "fn__1433000095", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000095_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_class, Name: "arbace.box.rebuild$steps$fn__1433000095$fn__1433000096", Modifiers: 25, Simple: "fn__1433000096", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_fn__1433000095_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_forms__1433000061_A_class, Name: "arbace.box.rebuild$steps$forms__1433000061", Modifiers: 25, Simple: "forms__1433000061", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_forms__1433000061_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_class, Name: "arbace.box.rebuild$steps$iter__1433000073__1433000077", Modifiers: 25, Simple: "iter__1433000073__1433000077", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_class, Name: "arbace.box.rebuild$steps$iter__1433000073__1433000077$fn__1433000078", Modifiers: 25, Simple: "fn__1433000078", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_class, Name: "arbace.box.rebuild$steps$iter__1433000073__1433000077$fn__1433000078$fn__1433000079", Modifiers: 25, Simple: "fn__1433000079", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_run__1433000051_A_class, Name: "arbace.box.rebuild$steps$run__1433000051", Modifiers: 25, Simple: "run__1433000051", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_run__1433000051_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_steps_secs__1433000053_A_class, Name: "arbace.box.rebuild$steps$secs__1433000053", Modifiers: 25, Simple: "secs__1433000053", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_steps_secs__1433000053_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_steps_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_rebuild_version_A_class, Name: "arbace.box.rebuild$version", Modifiers: 25, Simple: "version", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_version_A", Source: "rebuild.ae", Declaring: &A_arbace_box_rebuild_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_box_rebuild_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_A_New()}; return nil }

var A_arbace_box_rebuild_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_rebuild_A_new}

var A_arbace_box_rebuild_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_A"})

func init() { i := A_arbace_box_rebuild_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_A_InstanceOf; i.Init = A_arbace_box_rebuild_A_Init; i.Table = A_arbace_box_rebuild_A_members }

var A_arbace_box_rebuild_arch_of_A_class *jrt.Class

var A_arbace_box_rebuild_compile_script_A_class *jrt.Class

var A_arbace_box_rebuild_delete_tree_A_class *jrt.Class

var A_arbace_box_rebuild_dir_at_A_class *jrt.Class

var A_arbace_box_rebuild_dir_at_BANG__A_class *jrt.Class

func A_arbace_box_rebuild_eval1433000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_eval1433000004_A_New()}; return nil }

var A_arbace_box_rebuild_eval1433000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_rebuild_eval1433000004_A_new}

var A_arbace_box_rebuild_eval1433000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$eval1433000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_rebuild_A_class, Simple: "eval1433000004", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_eval1433000004_A"})

func init() { i := A_arbace_box_rebuild_eval1433000004_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_eval1433000004_A_InstanceOf; i.Table = A_arbace_box_rebuild_eval1433000004_A_members }

var A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_class *jrt.Class

func A_arbace_box_rebuild_eval1433000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild_eval1433000008_A_New()}; return nil }

var A_arbace_box_rebuild_eval1433000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_rebuild_eval1433000008_A_new}

var A_arbace_box_rebuild_eval1433000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild$eval1433000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_rebuild_A_class, Simple: "eval1433000008", Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild_eval1433000008_A"})

func init() { i := A_arbace_box_rebuild_eval1433000008_A_class.Info(); i.IsInstance = A_arbace_box_rebuild_eval1433000008_A_InstanceOf; i.Table = A_arbace_box_rebuild_eval1433000008_A_members }

var A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_class *jrt.Class

var A_arbace_box_rebuild_fail_A_class *jrt.Class

var A_arbace_box_rebuild_file_text_A_class *jrt.Class

var A_arbace_box_rebuild_hash_of_A_class *jrt.Class

var A_arbace_box_rebuild_host_run_A_class *jrt.Class

var A_arbace_box_rebuild_host_run_fn__1433000114_A_class *jrt.Class

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000115_A_class *jrt.Class

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000123_A_class *jrt.Class

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000135_A_class *jrt.Class

var A_arbace_box_rebuild_host_run_fn__1433000114_fn__1433000141_A_class *jrt.Class

var A_arbace_box_rebuild_lay_over_A_class *jrt.Class

var A_arbace_box_rebuild_lay_over_fn__1433000021_A_class *jrt.Class

var A_arbace_box_rebuild_namespaces_script_A_class *jrt.Class

var A_arbace_box_rebuild_out_A_class *jrt.Class

var A_arbace_box_rebuild_prepare_script_A_class *jrt.Class

var A_arbace_box_rebuild_put_at_A_class *jrt.Class

var A_arbace_box_rebuild_rebuild_A_class *jrt.Class

var A_arbace_box_rebuild_result_text_A_class *jrt.Class

var A_arbace_box_rebuild_select_tree_A_class *jrt.Class

var A_arbace_box_rebuild_steps_A_class *jrt.Class

var A_arbace_box_rebuild_steps_fn__1433000063_A_class *jrt.Class

var A_arbace_box_rebuild_steps_fn__1433000065_A_class *jrt.Class

var A_arbace_box_rebuild_steps_fn__1433000068_A_class *jrt.Class

var A_arbace_box_rebuild_steps_fn__1433000093_A_class *jrt.Class

var A_arbace_box_rebuild_steps_fn__1433000095_A_class *jrt.Class

var A_arbace_box_rebuild_steps_fn__1433000095_fn__1433000096_A_class *jrt.Class

var A_arbace_box_rebuild_steps_forms__1433000061_A_class *jrt.Class

var A_arbace_box_rebuild_steps_iter__1433000073__1433000077_A_class *jrt.Class

var A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_A_class *jrt.Class

var A_arbace_box_rebuild_steps_iter__1433000073__1433000077_fn__1433000078_fn__1433000079_A_class *jrt.Class

var A_arbace_box_rebuild_steps_run__1433000051_A_class *jrt.Class

var A_arbace_box_rebuild_steps_secs__1433000053_A_class *jrt.Class

var A_arbace_box_rebuild_version_A_class *jrt.Class

func A_arbace_box_rebuild__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_rebuild__init_A_Load__O()}; return nil }

func A_arbace_box_rebuild__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_rebuild__init_A_New()}; return nil }

var A_arbace_box_rebuild__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_rebuild__init_A_invoke, New: A_arbace_box_rebuild__init_A_new}

var A_arbace_box_rebuild__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.rebuild__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_rebuild.A_arbace_box_rebuild__init_A", Source: "rebuild.ae"})

func init() { i := A_arbace_box_rebuild__init_A_class.Info(); i.IsInstance = A_arbace_box_rebuild__init_A_InstanceOf; i.Init = A_arbace_box_rebuild__init_A_Init; i.Table = A_arbace_box_rebuild__init_A_members }
