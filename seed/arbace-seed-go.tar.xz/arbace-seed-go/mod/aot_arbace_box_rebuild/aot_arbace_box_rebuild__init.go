//line aot_arbace_box_rebuild__init.ae:1
package aot_arbace_box_rebuild

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_box_rebuild__init_A_Unit0__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5, 1); return lang.IFn_Cast(jrt.NN(A_arbace_box_rebuild__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_box_rebuild__init_A_const_1) }
//line :5:1
func A_arbace_box_rebuild__init_A_Unit1__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_box_rebuild__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_2)) }
//line :5:1
func A_arbace_box_rebuild__init_A_Unit2__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5, 1); var tmp1 any = A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_New(); var tmp2 *jrt.Class; A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_Init(); tmp2 = A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :5:1
func A_arbace_box_rebuild__init_A_Unit3__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_box_rebuild__init_A_const_1)).Equals_O__Z(A_arbace_box_rebuild__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_New(); var tmp2 *jrt.Class; A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_Init(); tmp2 = A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :5:1
func A_arbace_box_rebuild__init_A_Load__O() any { A_arbace_box_rebuild__init_A_Init(); A_arbace_box_rebuild__init_A_Unit0__O(); A_arbace_box_rebuild__init_A_Unit1__O(); A_arbace_box_rebuild__init_A_Unit2__O(); A_arbace_box_rebuild__init_A_Unit3__O(); A_arbace_box_rebuild__init_A_Unit4__O(); A_arbace_box_rebuild__init_A_Unit5__O(); A_arbace_box_rebuild__init_A_Unit6__O(); A_arbace_box_rebuild__init_A_Unit7__O(); A_arbace_box_rebuild__init_A_Unit8__O(); A_arbace_box_rebuild__init_A_Unit9__O(); A_arbace_box_rebuild__init_A_Unit10__O(); A_arbace_box_rebuild__init_A_Unit11__O(); A_arbace_box_rebuild__init_A_Unit12__O(); A_arbace_box_rebuild__init_A_Unit13__O(); A_arbace_box_rebuild__init_A_Unit14__O(); A_arbace_box_rebuild__init_A_Unit15__O(); A_arbace_box_rebuild__init_A_Unit16__O(); A_arbace_box_rebuild__init_A_Unit17__O(); A_arbace_box_rebuild__init_A_Unit18__O(); A_arbace_box_rebuild__init_A_Unit19__O(); A_arbace_box_rebuild__init_A_Unit20__O(); A_arbace_box_rebuild__init_A_Unit21__O(); A_arbace_box_rebuild__init_A_Unit22__O(); A_arbace_box_rebuild__init_A_Unit23__O(); A_arbace_box_rebuild__init_A_Unit24__O(); A_arbace_box_rebuild__init_A_Unit25__O(); return nil }



















































func A_arbace_box_rebuild__init_A_Unit4__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(57, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_4; jrt.NN(tmp1).BindRoot_O__V(jrt.Long_ValueOf_J__Long(lang.Numbers_Multiply_J_J__J(lang.Numbers_Multiply_J_J__J(1024, 1024), 1024)).Ref()); var tmp2 *lang.Var = A_arbace_box_rebuild__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_5)); return A_arbace_box_rebuild__init_A_const_4.Ref() }

func A_arbace_box_rebuild__init_A_Unit5__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_6; var tmp2 any = A_arbace_box_rebuild_fail_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_fail_A_Init(); tmp3 = A_arbace_box_rebuild_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_7)); return A_arbace_box_rebuild__init_A_const_6.Ref() }





func A_arbace_box_rebuild__init_A_Unit6__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(65, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_8; var tmp2 any = A_arbace_box_rebuild_hash_of_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_hash_of_A_Init(); tmp3 = A_arbace_box_rebuild_hash_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_9)); return A_arbace_box_rebuild__init_A_const_8.Ref() }






func A_arbace_box_rebuild__init_A_Unit7__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_10; var tmp2 any = A_arbace_box_rebuild_dir_at_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_dir_at_A_Init(); tmp3 = A_arbace_box_rebuild_dir_at_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_11)); return A_arbace_box_rebuild__init_A_const_10.Ref() }





func A_arbace_box_rebuild__init_A_Unit8__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_12; var tmp2 any = A_arbace_box_rebuild_dir_at_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_dir_at_BANG__A_Init(); tmp3 = A_arbace_box_rebuild_dir_at_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_13)); return A_arbace_box_rebuild__init_A_const_12.Ref() }



func A_arbace_box_rebuild__init_A_Unit9__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_14; var tmp2 any = A_arbace_box_rebuild_select_tree_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_select_tree_A_Init(); tmp3 = A_arbace_box_rebuild_select_tree_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_15)); return A_arbace_box_rebuild__init_A_const_14.Ref() }




func A_arbace_box_rebuild__init_A_Unit10__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_16; var tmp2 any = A_arbace_box_rebuild_lay_over_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_lay_over_A_Init(); tmp3 = A_arbace_box_rebuild_lay_over_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_17)); return A_arbace_box_rebuild__init_A_const_16.Ref() }










func A_arbace_box_rebuild__init_A_Unit11__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(98, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_18; var tmp2 any = A_arbace_box_rebuild_put_at_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_put_at_A_Init(); tmp3 = A_arbace_box_rebuild_put_at_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_19)); return A_arbace_box_rebuild__init_A_const_18.Ref() }









func A_arbace_box_rebuild__init_A_Unit12__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_20; var tmp2 any = A_arbace_box_rebuild_file_text_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_file_text_A_Init(); tmp3 = A_arbace_box_rebuild_file_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_21)); return A_arbace_box_rebuild__init_A_const_20.Ref() }






func A_arbace_box_rebuild__init_A_Unit13__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_22; var tmp2 any = A_arbace_box_rebuild_version_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_version_A_Init(); tmp3 = A_arbace_box_rebuild_version_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_23)); return A_arbace_box_rebuild__init_A_const_22.Ref() }














func A_arbace_box_rebuild__init_A_Unit14__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(130, 1); jrt.NN(A_arbace_box_rebuild__init_A_const_24).BindRoot_O__V(A_arbace_box_rebuild__init_A_const_25); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_24; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_26)); return A_arbace_box_rebuild__init_A_const_24.Ref() }



func A_arbace_box_rebuild__init_A_Unit15__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(134, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_27; var tmp2 any = A_arbace_box_rebuild__init_A_const_28.Ref(); var tmp3 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Numbers_Multiply_J_O__Number(12, jrt.NN(A_arbace_box_rebuild__init_A_const_4).GetRawRoot__O()), A_arbace_box_rebuild__init_A_const_29.Ref(), A_arbace_box_rebuild__init_A_const_30)); var tmp4 any = A_arbace_box_rebuild__init_A_const_28.Ref(); var tmp5 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Numbers_Multiply_J_O__Number(12, jrt.NN(A_arbace_box_rebuild__init_A_const_4).GetRawRoot__O()), A_arbace_box_rebuild__init_A_const_29.Ref(), A_arbace_box_rebuild__init_A_const_30)); var tmp6 any = A_arbace_box_rebuild__init_A_const_28.Ref(); var tmp7 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Numbers_Multiply_J_O__Number(6, jrt.NN(A_arbace_box_rebuild__init_A_const_4).GetRawRoot__O()), A_arbace_box_rebuild__init_A_const_29.Ref(), A_arbace_box_rebuild__init_A_const_31)); var tmp8 any = A_arbace_box_rebuild__init_A_const_28.Ref(); var tmp9 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, lang.Numbers_Multiply_J_O__Number(8, jrt.NN(A_arbace_box_rebuild__init_A_const_4).GetRawRoot__O()), A_arbace_box_rebuild__init_A_const_29.Ref(), A_arbace_box_rebuild__init_A_const_31)); var tmp10 any = A_arbace_box_rebuild__init_A_const_28.Ref(); var tmp11 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, lang.Numbers_Multiply_J_O__Number(6, jrt.NN(A_arbace_box_rebuild__init_A_const_4).GetRawRoot__O()), A_arbace_box_rebuild__init_A_const_29.Ref(), A_arbace_box_rebuild__init_A_const_31)); var tmp12 any = A_arbace_box_rebuild__init_A_const_32.Ref(); var tmp13 any = A_arbace_box_rebuild__init_A_const_28.Ref(); jrt.NN(tmp1).BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_374, tmp3, Lit_375, tmp5, Lit_285, tmp7, Lit_376, tmp9, Lit_377, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, lang.Numbers_Multiply_J_O__Number(8, jrt.NN(A_arbace_box_rebuild__init_A_const_4).GetRawRoot__O()), A_arbace_box_rebuild__init_A_const_29.Ref(), A_arbace_box_rebuild__init_A_const_31))))); var tmp14 *lang.Var = A_arbace_box_rebuild__init_A_const_27; jrt.NN(tmp14).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_33)); return A_arbace_box_rebuild__init_A_const_27.Ref() }












func A_arbace_box_rebuild__init_A_Unit16__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(147, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_34; var tmp2 any = A_arbace_box_rebuild_arch_of_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_arch_of_A_Init(); tmp3 = A_arbace_box_rebuild_arch_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_35)); return A_arbace_box_rebuild__init_A_const_34.Ref() }


func A_arbace_box_rebuild__init_A_Unit17__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(150, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_36; var tmp2 any = A_arbace_box_rebuild_out_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_out_A_Init(); tmp3 = A_arbace_box_rebuild_out_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_37)); return A_arbace_box_rebuild__init_A_const_36.Ref() }


func A_arbace_box_rebuild__init_A_Unit18__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(153, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_38; var tmp2 any = A_arbace_box_rebuild_prepare_script_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_prepare_script_A_Init(); tmp3 = A_arbace_box_rebuild_prepare_script_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_39)); return A_arbace_box_rebuild__init_A_const_38.Ref() }





func A_arbace_box_rebuild__init_A_Unit19__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(159, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_40; var tmp2 any = A_arbace_box_rebuild_namespaces_script_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_namespaces_script_A_Init(); tmp3 = A_arbace_box_rebuild_namespaces_script_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_41)); return A_arbace_box_rebuild__init_A_const_40.Ref() }







func A_arbace_box_rebuild__init_A_Unit20__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(167, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_42; var tmp2 any = A_arbace_box_rebuild_compile_script_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_compile_script_A_Init(); tmp3 = A_arbace_box_rebuild_compile_script_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_43)); return A_arbace_box_rebuild__init_A_const_42.Ref() }









func A_arbace_box_rebuild__init_A_Unit21__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(177, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_44; var tmp2 any = A_arbace_box_rebuild_steps_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_steps_A_Init(); tmp3 = A_arbace_box_rebuild_steps_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_45)); return A_arbace_box_rebuild__init_A_const_44.Ref() }































































































































func A_arbace_box_rebuild__init_A_Unit22__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(305, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_46; var tmp2 any = A_arbace_box_rebuild_rebuild_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_rebuild_A_Init(); tmp3 = A_arbace_box_rebuild_rebuild_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_47)); return A_arbace_box_rebuild__init_A_const_46.Ref() }







func A_arbace_box_rebuild__init_A_Unit23__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(313, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_48; var tmp2 any = A_arbace_box_rebuild_result_text_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_result_text_A_Init(); tmp3 = A_arbace_box_rebuild_result_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_49)); return A_arbace_box_rebuild__init_A_const_48.Ref() }


func A_arbace_box_rebuild__init_A_Unit24__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(316, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_50; var tmp2 any = A_arbace_box_rebuild_delete_tree_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_delete_tree_A_Init(); tmp3 = A_arbace_box_rebuild_delete_tree_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_51)); return A_arbace_box_rebuild__init_A_const_50.Ref() }





func A_arbace_box_rebuild__init_A_Unit25__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V(322, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_52; var tmp2 any = A_arbace_box_rebuild_host_run_A_New(); var tmp3 *jrt.Class; A_arbace_box_rebuild_host_run_A_Init(); tmp3 = A_arbace_box_rebuild_host_run_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_53)); return A_arbace_box_rebuild__init_A_const_52.Ref() }



type A_arbace_box_rebuild__init_A struct{ jrt.Object }

var A_arbace_box_rebuild__init_A_const_0 *lang.Var

var A_arbace_box_rebuild__init_A_const_1 any

var A_arbace_box_rebuild__init_A_const_2 any

var A_arbace_box_rebuild__init_A_const_3 any

var A_arbace_box_rebuild__init_A_const_4 *lang.Var

var A_arbace_box_rebuild__init_A_const_5 any

var A_arbace_box_rebuild__init_A_const_6 *lang.Var

var A_arbace_box_rebuild__init_A_const_7 any

var A_arbace_box_rebuild__init_A_const_8 *lang.Var

var A_arbace_box_rebuild__init_A_const_9 any

var A_arbace_box_rebuild__init_A_const_10 *lang.Var

var A_arbace_box_rebuild__init_A_const_11 any

var A_arbace_box_rebuild__init_A_const_12 *lang.Var

var A_arbace_box_rebuild__init_A_const_13 any

var A_arbace_box_rebuild__init_A_const_14 *lang.Var

var A_arbace_box_rebuild__init_A_const_15 any

var A_arbace_box_rebuild__init_A_const_16 *lang.Var

var A_arbace_box_rebuild__init_A_const_17 any

var A_arbace_box_rebuild__init_A_const_18 *lang.Var

var A_arbace_box_rebuild__init_A_const_19 any

var A_arbace_box_rebuild__init_A_const_20 *lang.Var

var A_arbace_box_rebuild__init_A_const_21 any

var A_arbace_box_rebuild__init_A_const_22 *lang.Var

var A_arbace_box_rebuild__init_A_const_23 any

var A_arbace_box_rebuild__init_A_const_24 *lang.Var

var A_arbace_box_rebuild__init_A_const_25 any

var A_arbace_box_rebuild__init_A_const_26 any

var A_arbace_box_rebuild__init_A_const_27 *lang.Var

var A_arbace_box_rebuild__init_A_const_28 *lang.Keyword

var A_arbace_box_rebuild__init_A_const_29 *lang.Keyword

var A_arbace_box_rebuild__init_A_const_30 any

var A_arbace_box_rebuild__init_A_const_31 any

var A_arbace_box_rebuild__init_A_const_32 *lang.Keyword

var A_arbace_box_rebuild__init_A_const_33 any

var A_arbace_box_rebuild__init_A_const_34 *lang.Var

var A_arbace_box_rebuild__init_A_const_35 any

var A_arbace_box_rebuild__init_A_const_36 *lang.Var

var A_arbace_box_rebuild__init_A_const_37 any

var A_arbace_box_rebuild__init_A_const_38 *lang.Var

var A_arbace_box_rebuild__init_A_const_39 any

var A_arbace_box_rebuild__init_A_const_40 *lang.Var

var A_arbace_box_rebuild__init_A_const_41 any

var A_arbace_box_rebuild__init_A_const_42 *lang.Var

var A_arbace_box_rebuild__init_A_const_43 any

var A_arbace_box_rebuild__init_A_const_44 *lang.Var

var A_arbace_box_rebuild__init_A_const_45 any

var A_arbace_box_rebuild__init_A_const_46 *lang.Var

var A_arbace_box_rebuild__init_A_const_47 any

var A_arbace_box_rebuild__init_A_const_48 *lang.Var

var A_arbace_box_rebuild__init_A_const_49 any

var A_arbace_box_rebuild__init_A_const_50 *lang.Var

var A_arbace_box_rebuild__init_A_const_51 any

var A_arbace_box_rebuild__init_A_const_52 *lang.Var

var A_arbace_box_rebuild__init_A_const_53 any

var A_arbace_box_rebuild__init_A_init jrt.ClassInit

func A_arbace_box_rebuild__init_A_Init() { if !A_arbace_box_rebuild__init_A_init.Done() { A_arbace_box_rebuild__init_A_init.Run(A_arbace_box_rebuild__init_A_clinit) } }

func A_arbace_box_rebuild__init_A_clinit() { A_arbace_box_rebuild__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_333); A_arbace_box_rebuild__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_21))); A_arbace_box_rebuild__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_21)); A_arbace_box_rebuild__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_rebuild__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_19, Lit_120); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_box_rebuild__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(57).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_19, Lit_29); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_box_rebuild__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_339).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_340).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(59).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_19, Lit_66); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_box_rebuild__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_341).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_342).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_343, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_19, Lit_35); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_box_rebuild__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_344).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_345)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_346).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_347).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_348, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(72).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_19, Lit_77); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_box_rebuild__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_344).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_345).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_342).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(78).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_19, Lit_122); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_box_rebuild__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_344).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_349).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_350, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_19, Lit_41); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_box_rebuild__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_351).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_352).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_353, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(87).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_19, Lit_49); A_arbace_box_rebuild__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_344).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_345)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_346).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_347).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_354).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_355, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(98).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_19, Lit_54); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_box_rebuild__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_344).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_345).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(108).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_19, Lit_81); A_arbace_box_rebuild__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_356, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_19, Lit_169); A_arbace_box_rebuild__init_A_const_25 = lang.Tuple_Create_O_O_O__IPersistentVector(Lit_357, Lit_358, Lit_359); A_arbace_box_rebuild__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_360)); A_arbace_box_rebuild__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_19, Lit_107); A_arbace_box_rebuild__init_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_119); A_arbace_box_rebuild__init_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_121); A_arbace_box_rebuild__init_A_const_30 = jrt.Long_ValueOf_J__Long(4).Ref(); A_arbace_box_rebuild__init_A_const_31 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_box_rebuild__init_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_83); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_box_rebuild__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(134).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_19, Lit_102); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_box_rebuild__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(147).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_19, Lit_62); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_box_rebuild__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_361).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_342).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(150).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_19, Lit_65); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_box_rebuild__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_362).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_363, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(153).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_19, Lit_124); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_box_rebuild__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_364, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(159).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_19, Lit_127); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_box_rebuild__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_362).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_365, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(167).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_19, Lit_172); A_arbace_box_rebuild__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_366).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_367, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(177).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_19, Lit_173); A_arbace_box_rebuild__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_366).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_368, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(305).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_19, Lit_191); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_box_rebuild__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_369).Ref(), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_175).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(313).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_19, Lit_176); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_334).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_box_rebuild__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_370)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_346).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_371).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(316).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)); A_arbace_box_rebuild__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_19, Lit_372); A_arbace_box_rebuild__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_338).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_369).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_177).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_178).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_179).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_180).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), Lit_373, lang.RT_Keyword_String_String__Keyword(nil, Lit_335).Ref(), jrt.Integer_ValueOf_I__Integer(322).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_336).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), Lit_337)) }

func A_arbace_box_rebuild__init_A_New() *A_arbace_box_rebuild__init_A { A_arbace_box_rebuild__init_A_Init(); t := &A_arbace_box_rebuild__init_A{}; t.Ctor(); return t }

func (t *A_arbace_box_rebuild__init_A) Ctor() {}

func (t *A_arbace_box_rebuild__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_rebuild__init_A) GetClass__Class() *jrt.Class { return A_arbace_box_rebuild__init_A_class }

func (t *A_arbace_box_rebuild__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_rebuild__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_rebuild__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_rebuild__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_rebuild__init_A); return ok }

func A_arbace_box_rebuild__init_A_Cast(x any) *A_arbace_box_rebuild__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_rebuild__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_rebuild__init_A_class)) }; return v }
