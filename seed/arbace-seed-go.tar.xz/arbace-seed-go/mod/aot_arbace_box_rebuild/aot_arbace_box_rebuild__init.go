//line aot_arbace_box_rebuild__init.ae:1
package aot_arbace_box_rebuild

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_box_rebuild__init_A_Unit0__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5, 1); return lang.IFn_Cast(A_arbace_box_rebuild__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_rebuild__init_A_const_1) }
//line :5:1
func A_arbace_box_rebuild__init_A_Unit1__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_box_rebuild__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_2)) }
//line :5:1
func A_arbace_box_rebuild__init_A_Unit2__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, nil); A_arbace_box_rebuild_eval1433000004_loading__1927001464__auto____1433000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :5:1
func A_arbace_box_rebuild__init_A_Unit3__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_box_rebuild__init_A_const_1)).Equals_O__Z(A_arbace_box_rebuild__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, nil); A_arbace_box_rebuild_eval1433000008_fn__1433000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :5:1
func A_arbace_box_rebuild__init_A_Load__O() any { A_arbace_box_rebuild__init_A_Init(); jrt.StartCheck(); A_arbace_box_rebuild__init_A_Unit0__O(); A_arbace_box_rebuild__init_A_Unit1__O(); A_arbace_box_rebuild__init_A_Unit2__O(); A_arbace_box_rebuild__init_A_Unit3__O(); A_arbace_box_rebuild__init_A_Unit4__O(); A_arbace_box_rebuild__init_A_Unit5__O(); A_arbace_box_rebuild__init_A_Unit6__O(); A_arbace_box_rebuild__init_A_Unit7__O(); A_arbace_box_rebuild__init_A_Unit8__O(); A_arbace_box_rebuild__init_A_Unit9__O(); A_arbace_box_rebuild__init_A_Unit10__O(); A_arbace_box_rebuild__init_A_Unit11__O(); A_arbace_box_rebuild__init_A_Unit12__O(); A_arbace_box_rebuild__init_A_Unit13__O(); A_arbace_box_rebuild__init_A_Unit14__O(); A_arbace_box_rebuild__init_A_Unit15__O(); A_arbace_box_rebuild__init_A_Unit16__O(); A_arbace_box_rebuild__init_A_Unit17__O(); A_arbace_box_rebuild__init_A_Unit18__O(); A_arbace_box_rebuild__init_A_Unit19__O(); A_arbace_box_rebuild__init_A_Unit20__O(); A_arbace_box_rebuild__init_A_Unit21__O(); A_arbace_box_rebuild__init_A_Unit22__O(); A_arbace_box_rebuild__init_A_Unit23__O(); A_arbace_box_rebuild__init_A_Unit24__O(); A_arbace_box_rebuild__init_A_Unit25__O(); return nil }
























































func A_arbace_box_rebuild__init_A_Unit4__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_4; tmp1.BindRoot_O__V(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(1024, 1024), 1024)).Ref()); var tmp2 *lang.Var = A_arbace_box_rebuild__init_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_5)); return A_arbace_box_rebuild__init_A_const_4 }

func A_arbace_box_rebuild__init_A_Unit5__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_box_rebuild_fail_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_box_rebuild_fail_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, nil); A_arbace_box_rebuild_fail_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_7)); return A_arbace_box_rebuild__init_A_const_6 }





func A_arbace_box_rebuild__init_A_Unit6__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_box_rebuild_hash_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_box_rebuild_hash_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, nil); A_arbace_box_rebuild_hash_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_9)); return A_arbace_box_rebuild__init_A_const_8 }






func A_arbace_box_rebuild__init_A_Unit7__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_box_rebuild_dir_at_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_box_rebuild_dir_at_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, nil); A_arbace_box_rebuild_dir_at_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_11)); return A_arbace_box_rebuild__init_A_const_10 }





func A_arbace_box_rebuild__init_A_Unit8__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_box_rebuild_dir_at_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_box_rebuild_dir_at_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, nil); A_arbace_box_rebuild_dir_at_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_13)); return A_arbace_box_rebuild__init_A_const_12 }



func A_arbace_box_rebuild__init_A_Unit9__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_box_rebuild_select_tree_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_box_rebuild_select_tree_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, nil); A_arbace_box_rebuild_select_tree_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_15)); return A_arbace_box_rebuild__init_A_const_14 }




func A_arbace_box_rebuild__init_A_Unit10__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_box_rebuild_lay_over_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_box_rebuild_lay_over_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, nil); A_arbace_box_rebuild_lay_over_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_17)); return A_arbace_box_rebuild__init_A_const_16 }










func A_arbace_box_rebuild__init_A_Unit11__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_box_rebuild_put_at_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_box_rebuild_put_at_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, nil); A_arbace_box_rebuild_put_at_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_19)); return A_arbace_box_rebuild__init_A_const_18 }









func A_arbace_box_rebuild__init_A_Unit12__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_box_rebuild_file_text_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_box_rebuild_file_text_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, nil); A_arbace_box_rebuild_file_text_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_21)); return A_arbace_box_rebuild__init_A_const_20 }






func A_arbace_box_rebuild__init_A_Unit13__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_box_rebuild_version_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_box_rebuild_version_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, nil); A_arbace_box_rebuild_version_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_23)); return A_arbace_box_rebuild__init_A_const_22 }














func A_arbace_box_rebuild__init_A_Unit14__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); A_arbace_box_rebuild__init_A_const_24.BindRoot_O__V(A_arbace_box_rebuild__init_A_const_25); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_26)); return A_arbace_box_rebuild__init_A_const_24 }



func A_arbace_box_rebuild__init_A_Unit15__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_27; var tmp2 any = A_arbace_box_rebuild__init_A_const_28; var tmp3 jrt.Number_I; var na_23 int64 = 12; var na_24 any = A_arbace_box_rebuild__init_A_const_4.GetRawRoot__O(); if

	jrt.Long_InstanceOf(na_24) { var n0_25 int64 = na_23; var n1_26 int64 = jrt.NN(jrt.Long_Cast(na_24)).LongValue__J(); var nr_27 int64 = n0_25 * n1_26; var tmp4 bool; var tmp5 bool; var tmp6 bool; var tmp7 bool; tmp7 = n0_25 == -9223372036854775808; if tmp7 { tmp7 = n1_26 < 0 }; tmp6 = tmp7; tmp5 = !tmp6; if tmp5 { var tmp8 bool; tmp8 = n1_26 == 0; if !tmp8 { tmp8 = nr_27/n1_26 == n0_25 }; tmp5 = tmp8 }; tmp4 = tmp5; if tmp4 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_27)) } else { tmp3 = lang.Numbers_Multiply_J_O__Number_NoInit(na_23, na_24) } } else { tmp3 = lang.Numbers_Multiply_J_O__Number_NoInit(na_23, na_24) }; var tmp9 any = /*line :139:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, A_arbace_box_rebuild__init_A_const_29, A_arbace_box_rebuild__init_A_const_30)); var tmp10 any = A_arbace_box_rebuild__init_A_const_28; var tmp11 jrt.Number_I; var na_28 int64 = 12; var na_29 any = A_arbace_box_rebuild__init_A_const_4.GetRawRoot__O(); if


	jrt.Long_InstanceOf(na_29) { var n0_30 int64 = na_28; var n1_31 int64 = jrt.NN(jrt.Long_Cast(na_29)).LongValue__J(); var nr_32 int64 = n0_30 * n1_31; var tmp12 bool; var tmp13 bool; var tmp14 bool; var tmp15 bool; tmp15 = n0_30 == -9223372036854775808; if tmp15 { tmp15 = n1_31 < 0 }; tmp14 = tmp15; tmp13 = !tmp14; if tmp13 { var tmp16 bool; tmp16 = n1_31 == 0; if !tmp16 { tmp16 = nr_32/n1_31 == n0_30 }; tmp13 = tmp16 }; tmp12 = tmp13; if tmp12 { tmp11 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_32)) } else { tmp11 = lang.Numbers_Multiply_J_O__Number_NoInit(na_28, na_29) } } else { tmp11 = lang.Numbers_Multiply_J_O__Number_NoInit(na_28, na_29) }; var tmp17 any = /*line :139:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp11, A_arbace_box_rebuild__init_A_const_29, A_arbace_box_rebuild__init_A_const_30)); var tmp18 any = A_arbace_box_rebuild__init_A_const_28; var tmp19 jrt.Number_I; var na_33 int64 = 6; var na_34 any = A_arbace_box_rebuild__init_A_const_4.GetRawRoot__O(); if



	jrt.Long_InstanceOf(na_34) { var n0_35 int64 = na_33; var n1_36 int64 = jrt.NN(jrt.Long_Cast(na_34)).LongValue__J(); var nr_37 int64 = n0_35 * n1_36; var tmp20 bool; var tmp21 bool; var tmp22 bool; var tmp23 bool; tmp23 = n0_35 == -9223372036854775808; if tmp23 { tmp23 = n1_36 < 0 }; tmp22 = tmp23; tmp21 = !tmp22; if tmp21 { var tmp24 bool; tmp24 = n1_36 == 0; if !tmp24 { tmp24 = nr_37/n1_36 == n0_35 }; tmp21 = tmp24 }; tmp20 = tmp21; if tmp20 { tmp19 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_37)) } else { tmp19 = lang.Numbers_Multiply_J_O__Number_NoInit(na_33, na_34) } } else { tmp19 = lang.Numbers_Multiply_J_O__Number_NoInit(na_33, na_34) }; var tmp25 any = /*line :139:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp19, A_arbace_box_rebuild__init_A_const_29, A_arbace_box_rebuild__init_A_const_31)); var tmp26 any = A_arbace_box_rebuild__init_A_const_28; var tmp27 jrt.Number_I; var na_38 int64 = 8; var na_39 any = A_arbace_box_rebuild__init_A_const_4.GetRawRoot__O(); if








	jrt.Long_InstanceOf(na_39) { var n0_40 int64 = na_38; var n1_41 int64 = jrt.NN(jrt.Long_Cast(na_39)).LongValue__J(); var nr_42 int64 = n0_40 * n1_41; var tmp28 bool; var tmp29 bool; var tmp30 bool; var tmp31 bool; tmp31 = n0_40 == -9223372036854775808; if tmp31 { tmp31 = n1_41 < 0 }; tmp30 = tmp31; tmp29 = !tmp30; if tmp29 { var tmp32 bool; tmp32 = n1_41 == 0; if !tmp32 { tmp32 = nr_42/n1_41 == n0_40 }; tmp29 = tmp32 }; tmp28 = tmp29; if tmp28 { tmp27 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_42)) } else { tmp27 = lang.Numbers_Multiply_J_O__Number_NoInit(na_38, na_39) } } else { tmp27 = lang.Numbers_Multiply_J_O__Number_NoInit(na_38, na_39) }; var tmp33 any = /*line :139:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp27, A_arbace_box_rebuild__init_A_const_29, A_arbace_box_rebuild__init_A_const_31)); var tmp34 any = A_arbace_box_rebuild__init_A_const_28; var tmp35 jrt.Number_I; var na_43 int64 = 6; var na_44 any = A_arbace_box_rebuild__init_A_const_4.GetRawRoot__O(); if









	jrt.Long_InstanceOf(na_44) { var n0_45 int64 = na_43; var n1_46 int64 = jrt.NN(jrt.Long_Cast(na_44)).LongValue__J(); var nr_47 int64 = n0_45 * n1_46; var tmp36 bool; var tmp37 bool; var tmp38 bool; var tmp39 bool; tmp39 = n0_45 == -9223372036854775808; if tmp39 { tmp39 = n1_46 < 0 }; tmp38 = tmp39; tmp37 = !tmp38; if tmp37 { var tmp40 bool; tmp40 = n1_46 == 0; if !tmp40 { tmp40 = nr_47/n1_46 == n0_45 }; tmp37 = tmp40 }; tmp36 = tmp37; if tmp36 { tmp35 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_47)) } else { tmp35 = lang.Numbers_Multiply_J_O__Number_NoInit(na_43, na_44) } } else { tmp35 = lang.Numbers_Multiply_J_O__Number_NoInit(na_43, na_44) }; var tmp41 any = /*line :139:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp35, A_arbace_box_rebuild__init_A_const_29, A_arbace_box_rebuild__init_A_const_31)); var tmp42 any = A_arbace_box_rebuild__init_A_const_32; var tmp43 any = A_arbace_box_rebuild__init_A_const_28; var tmp44 jrt.Number_I; var na_48 int64 = 8; var na_49 any = A_arbace_box_rebuild__init_A_const_4.GetRawRoot__O(); if










	jrt.Long_InstanceOf(na_49) { var n0_50 int64 = na_48; var n1_51 int64 = jrt.NN(jrt.Long_Cast(na_49)).LongValue__J(); var nr_52 int64 = n0_50 * n1_51; var tmp45 bool; var tmp46 bool; var tmp47 bool; var tmp48 bool; tmp48 = n0_50 == -9223372036854775808; if tmp48 { tmp48 = n1_51 < 0 }; tmp47 = tmp48; tmp46 = !tmp47; if tmp46 { var tmp49 bool; tmp49 = n1_51 == 0; if !tmp49 { tmp49 = nr_52/n1_51 == n0_50 }; tmp46 = tmp49 }; tmp45 = tmp46; if tmp45 { tmp44 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_52)) } else { tmp44 = lang.Numbers_Multiply_J_O__Number_NoInit(na_48, na_49) } } else { tmp44 = lang.Numbers_Multiply_J_O__Number_NoInit(na_48, na_49) }; /*line :139:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_148, tmp9, Lit_149, tmp17, Lit_93, tmp25, Lit_150, tmp33, Lit_151, tmp41, tmp42, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp44, A_arbace_box_rebuild__init_A_const_29, A_arbace_box_rebuild__init_A_const_31))))); var tmp50 *lang.Var = A_arbace_box_rebuild__init_A_const_27; tmp50.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_33)); return A_arbace_box_rebuild__init_A_const_27 }












func A_arbace_box_rebuild__init_A_Unit16__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(152, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_box_rebuild_arch_of_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_box_rebuild_arch_of_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, nil); A_arbace_box_rebuild_arch_of_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_35)); return A_arbace_box_rebuild__init_A_const_34 }


func A_arbace_box_rebuild__init_A_Unit17__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(155, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_box_rebuild_out_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_box_rebuild_out_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, nil); A_arbace_box_rebuild_out_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_37)); return A_arbace_box_rebuild__init_A_const_36 }


func A_arbace_box_rebuild__init_A_Unit18__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_box_rebuild_prepare_script_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_box_rebuild_prepare_script_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, nil); A_arbace_box_rebuild_prepare_script_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_39)); return A_arbace_box_rebuild__init_A_const_38 }





func A_arbace_box_rebuild__init_A_Unit19__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_box_rebuild_namespaces_script_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_box_rebuild_namespaces_script_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_155, false, nil); A_arbace_box_rebuild_namespaces_script_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_41)); return A_arbace_box_rebuild__init_A_const_40 }







func A_arbace_box_rebuild__init_A_Unit20__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_box_rebuild_compile_script_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_box_rebuild_compile_script_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, nil); A_arbace_box_rebuild_compile_script_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_43)); return A_arbace_box_rebuild__init_A_const_42 }









func A_arbace_box_rebuild__init_A_Unit21__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_box_rebuild_steps_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_box_rebuild_steps_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, nil); A_arbace_box_rebuild_steps_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_45)); return A_arbace_box_rebuild__init_A_const_44 }







































































































































func A_arbace_box_rebuild__init_A_Unit22__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(318, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_box_rebuild_rebuild_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_box_rebuild_rebuild_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, nil); A_arbace_box_rebuild_rebuild_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_47)); return A_arbace_box_rebuild__init_A_const_46 }







func A_arbace_box_rebuild__init_A_Unit23__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_box_rebuild_result_text_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_box_rebuild_result_text_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, nil); A_arbace_box_rebuild_result_text_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_49)); return A_arbace_box_rebuild__init_A_const_48 }


func A_arbace_box_rebuild__init_A_Unit24__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(329, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_box_rebuild_delete_tree_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_box_rebuild_delete_tree_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, nil); A_arbace_box_rebuild_delete_tree_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_51)); return A_arbace_box_rebuild__init_A_const_50 }





func A_arbace_box_rebuild__init_A_Unit25__O() any { A_arbace_box_rebuild__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(335, 1); var tmp1 *lang.Var = A_arbace_box_rebuild__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_box_rebuild_host_run_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_box_rebuild_host_run_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, nil); A_arbace_box_rebuild_host_run_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_box_rebuild__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_rebuild__init_A_const_53)); return A_arbace_box_rebuild__init_A_const_52 }



type A_arbace_box_rebuild__init_A struct{ jrt.Object }

var A_arbace_box_rebuild__init_A_const_pool *jrt.RefArray

var A_arbace_box_rebuild__init_A_const_0 *lang.Var

var A_arbace_box_rebuild__init_A_const_1 any

var A_arbace_box_rebuild__init_A_const_2 any

var A_arbace_box_rebuild__init_A_const_3 any

var A_arbace_box_rebuild__init_A_const_4 *lang.Var

var A_arbace_box_rebuild__init_A_const_5 any

var A_arbace_box_rebuild__init_A_const_6 *lang.Var

var A_arbace_box_rebuild__init_A_const_7 any

var A_arbace_box_rebuild__init_A_const_8 *lang.Var

var A_arbace_box_rebuild__init_A_const_9 any

var A_arbace_box_rebuild__init_A_const_10 *lang.Var

var A_arbace_box_rebuild__init_A_const_11 any

var A_arbace_box_rebuild__init_A_const_12 *lang.Var

var A_arbace_box_rebuild__init_A_const_13 any

var A_arbace_box_rebuild__init_A_const_14 *lang.Var

var A_arbace_box_rebuild__init_A_const_15 any

var A_arbace_box_rebuild__init_A_const_16 *lang.Var

var A_arbace_box_rebuild__init_A_const_17 any

var A_arbace_box_rebuild__init_A_const_18 *lang.Var

var A_arbace_box_rebuild__init_A_const_19 any

var A_arbace_box_rebuild__init_A_const_20 *lang.Var

var A_arbace_box_rebuild__init_A_const_21 any

var A_arbace_box_rebuild__init_A_const_22 *lang.Var

var A_arbace_box_rebuild__init_A_const_23 any

var A_arbace_box_rebuild__init_A_const_24 *lang.Var

var A_arbace_box_rebuild__init_A_const_25 any

var A_arbace_box_rebuild__init_A_const_26 any

var A_arbace_box_rebuild__init_A_const_27 *lang.Var

var A_arbace_box_rebuild__init_A_const_28 *lang.Keyword

var A_arbace_box_rebuild__init_A_const_29 *lang.Keyword

var A_arbace_box_rebuild__init_A_const_30 any

var A_arbace_box_rebuild__init_A_const_31 any

var A_arbace_box_rebuild__init_A_const_32 *lang.Keyword

var A_arbace_box_rebuild__init_A_const_33 any

var A_arbace_box_rebuild__init_A_const_34 *lang.Var

var A_arbace_box_rebuild__init_A_const_35 any

var A_arbace_box_rebuild__init_A_const_36 *lang.Var

var A_arbace_box_rebuild__init_A_const_37 any

var A_arbace_box_rebuild__init_A_const_38 *lang.Var

var A_arbace_box_rebuild__init_A_const_39 any

var A_arbace_box_rebuild__init_A_const_40 *lang.Var

var A_arbace_box_rebuild__init_A_const_41 any

var A_arbace_box_rebuild__init_A_const_42 *lang.Var

var A_arbace_box_rebuild__init_A_const_43 any

var A_arbace_box_rebuild__init_A_const_44 *lang.Var

var A_arbace_box_rebuild__init_A_const_45 any

var A_arbace_box_rebuild__init_A_const_46 *lang.Var

var A_arbace_box_rebuild__init_A_const_47 any

var A_arbace_box_rebuild__init_A_const_48 *lang.Var

var A_arbace_box_rebuild__init_A_const_49 any

var A_arbace_box_rebuild__init_A_const_50 *lang.Var

var A_arbace_box_rebuild__init_A_const_51 any

var A_arbace_box_rebuild__init_A_const_52 *lang.Var

var A_arbace_box_rebuild__init_A_const_53 any

var A_arbace_box_rebuild__init_A_init jrt.ClassInit

func A_arbace_box_rebuild__init_A_Init() { if !A_arbace_box_rebuild__init_A_init.Done() { A_arbace_box_rebuild__init_A_init.Run(A_arbace_box_rebuild__init_A_clinit) } }

func A_arbace_box_rebuild__init_A_clinit() { A_arbace_box_rebuild__init_A_clinit_p0(); A_arbace_box_rebuild__init_A_clinit_p1(); A_arbace_box_rebuild__init_A_clinit_p2(); A_arbace_box_rebuild__init_A_clinit_p3(); A_arbace_box_rebuild__init_A_clinit_p4() }

func A_arbace_box_rebuild__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_rebuild__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_136, 89); A_arbace_box_rebuild__init_A_const_0 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[35]); A_arbace_box_rebuild__init_A_const_1 = A_arbace_box_rebuild__init_A_const_pool.A[36]; A_arbace_box_rebuild__init_A_const_2 = A_arbace_box_rebuild__init_A_const_pool.A[37]; A_arbace_box_rebuild__init_A_const_3 = A_arbace_box_rebuild__init_A_const_pool.A[38]; A_arbace_box_rebuild__init_A_const_4 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[39]); A_arbace_box_rebuild__init_A_const_5 = A_arbace_box_rebuild__init_A_const_pool.A[40]; A_arbace_box_rebuild__init_A_const_6 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[41]); A_arbace_box_rebuild__init_A_const_7 = A_arbace_box_rebuild__init_A_const_pool.A[42]; A_arbace_box_rebuild__init_A_const_8 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[43]); A_arbace_box_rebuild__init_A_const_9 = A_arbace_box_rebuild__init_A_const_pool.A[44]; A_arbace_box_rebuild__init_A_const_10 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[45]); A_arbace_box_rebuild__init_A_const_11 = A_arbace_box_rebuild__init_A_const_pool.A[46]; A_arbace_box_rebuild__init_A_const_12 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[47]) }

func A_arbace_box_rebuild__init_A_clinit_p1() { A_arbace_box_rebuild__init_A_const_13 = A_arbace_box_rebuild__init_A_const_pool.A[48]; A_arbace_box_rebuild__init_A_const_14 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[49]); A_arbace_box_rebuild__init_A_const_15 = A_arbace_box_rebuild__init_A_const_pool.A[50]; A_arbace_box_rebuild__init_A_const_16 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[51]); A_arbace_box_rebuild__init_A_const_17 = A_arbace_box_rebuild__init_A_const_pool.A[52]; A_arbace_box_rebuild__init_A_const_18 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[53]); A_arbace_box_rebuild__init_A_const_19 = A_arbace_box_rebuild__init_A_const_pool.A[54]; A_arbace_box_rebuild__init_A_const_20 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[55]); A_arbace_box_rebuild__init_A_const_21 = A_arbace_box_rebuild__init_A_const_pool.A[56]; A_arbace_box_rebuild__init_A_const_22 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[57]); A_arbace_box_rebuild__init_A_const_23 = A_arbace_box_rebuild__init_A_const_pool.A[58]; A_arbace_box_rebuild__init_A_const_24 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[59]); A_arbace_box_rebuild__init_A_const_25 = A_arbace_box_rebuild__init_A_const_pool.A[60]; A_arbace_box_rebuild__init_A_const_26 = A_arbace_box_rebuild__init_A_const_pool.A[61] }

func A_arbace_box_rebuild__init_A_clinit_p2() { A_arbace_box_rebuild__init_A_const_27 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[62]); A_arbace_box_rebuild__init_A_const_28 = lang.Keyword_Cast(A_arbace_box_rebuild__init_A_const_pool.A[63]); A_arbace_box_rebuild__init_A_const_29 = lang.Keyword_Cast(A_arbace_box_rebuild__init_A_const_pool.A[64]); A_arbace_box_rebuild__init_A_const_30 = A_arbace_box_rebuild__init_A_const_pool.A[65]; A_arbace_box_rebuild__init_A_const_31 = A_arbace_box_rebuild__init_A_const_pool.A[66]; A_arbace_box_rebuild__init_A_const_32 = lang.Keyword_Cast(A_arbace_box_rebuild__init_A_const_pool.A[67]); A_arbace_box_rebuild__init_A_const_33 = A_arbace_box_rebuild__init_A_const_pool.A[68]; A_arbace_box_rebuild__init_A_const_34 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[69]); A_arbace_box_rebuild__init_A_const_35 = A_arbace_box_rebuild__init_A_const_pool.A[70]; A_arbace_box_rebuild__init_A_const_36 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[71]); A_arbace_box_rebuild__init_A_const_37 = A_arbace_box_rebuild__init_A_const_pool.A[72]; A_arbace_box_rebuild__init_A_const_38 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[73]); A_arbace_box_rebuild__init_A_const_39 = A_arbace_box_rebuild__init_A_const_pool.A[74] }

func A_arbace_box_rebuild__init_A_clinit_p3() { A_arbace_box_rebuild__init_A_const_40 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[75]); A_arbace_box_rebuild__init_A_const_41 = A_arbace_box_rebuild__init_A_const_pool.A[76]; A_arbace_box_rebuild__init_A_const_42 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[77]); A_arbace_box_rebuild__init_A_const_43 = A_arbace_box_rebuild__init_A_const_pool.A[78]; A_arbace_box_rebuild__init_A_const_44 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[79]); A_arbace_box_rebuild__init_A_const_45 = A_arbace_box_rebuild__init_A_const_pool.A[80]; A_arbace_box_rebuild__init_A_const_46 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[81]); A_arbace_box_rebuild__init_A_const_47 = A_arbace_box_rebuild__init_A_const_pool.A[82]; A_arbace_box_rebuild__init_A_const_48 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[83]); A_arbace_box_rebuild__init_A_const_49 = A_arbace_box_rebuild__init_A_const_pool.A[84]; A_arbace_box_rebuild__init_A_const_50 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[85]); A_arbace_box_rebuild__init_A_const_51 = A_arbace_box_rebuild__init_A_const_pool.A[86]; A_arbace_box_rebuild__init_A_const_52 = lang.Var_Cast(A_arbace_box_rebuild__init_A_const_pool.A[87]) }

func A_arbace_box_rebuild__init_A_clinit_p4() { A_arbace_box_rebuild__init_A_const_53 = A_arbace_box_rebuild__init_A_const_pool.A[88] }

func A_arbace_box_rebuild__init_A_New() *A_arbace_box_rebuild__init_A { A_arbace_box_rebuild__init_A_Init(); t := &A_arbace_box_rebuild__init_A{}; t.Ctor(); return t }

func (t *A_arbace_box_rebuild__init_A) Ctor() {}

func (t *A_arbace_box_rebuild__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_rebuild__init_A) GetClass__Class() *jrt.Class { return A_arbace_box_rebuild__init_A_class }

func (t *A_arbace_box_rebuild__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_rebuild__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_rebuild__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_rebuild__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_rebuild__init_A); return ok }

func A_arbace_box_rebuild__init_A_Cast(x any) *A_arbace_box_rebuild__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_rebuild__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_rebuild__init_A_class)) }; return v }
