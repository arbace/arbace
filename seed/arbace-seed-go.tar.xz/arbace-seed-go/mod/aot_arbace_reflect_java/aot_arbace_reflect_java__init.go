//line aot_arbace_reflect_java__init.ae:1
package aot_arbace_reflect_java

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_reflect"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_reflect_java__init_A_Load__O() any { A_arbace_reflect_java__init_A_Init(); jrt.StartCheck(); A_arbace_reflect_java__init_A_Unit0__O(); A_arbace_reflect_java__init_A_Unit1__O(); A_arbace_reflect_java__init_A_Unit2__O(); A_arbace_reflect_java__init_A_Unit3__O(); A_arbace_reflect_java__init_A_Unit4__O(); A_arbace_reflect_java__init_A_Unit5__O(); A_arbace_reflect_java__init_A_Unit6__O(); A_arbace_reflect_java__init_A_Unit7__O(); A_arbace_reflect_java__init_A_Unit8__O(); A_arbace_reflect_java__init_A_Unit9__O(); A_arbace_reflect_java__init_A_Unit10__O(); A_arbace_reflect_java__init_A_Unit11__O(); A_arbace_reflect_java__init_A_Unit12__O(); A_arbace_reflect_java__init_A_Unit13__O(); A_arbace_reflect_java__init_A_Unit14__O(); A_arbace_reflect_java__init_A_Unit15__O(); A_arbace_reflect_java__init_A_Unit16__O(); A_arbace_reflect_java__init_A_Unit17__O(); A_arbace_reflect_java__init_A_Unit18__O(); A_arbace_reflect_java__init_A_Unit19__O(); A_arbace_reflect_java__init_A_Unit20__O(); A_arbace_reflect_java__init_A_Unit21__O(); A_arbace_reflect_java__init_A_Unit22__O(); A_arbace_reflect_java__init_A_Unit23__O(); A_arbace_reflect_java__init_A_Unit24__O(); A_arbace_reflect_java__init_A_Unit25__O(); A_arbace_reflect_java__init_A_Unit26__O(); A_arbace_reflect_java__init_A_Unit27__O(); A_arbace_reflect_java__init_A_Unit28__O(); A_arbace_reflect_java__init_A_Unit29__O(); A_arbace_reflect_java__init_A_Unit30__O(); A_arbace_reflect_java__init_A_Unit31__O(); A_arbace_reflect_java__init_A_Unit32__O(); A_arbace_reflect_java__init_A_Unit33__O(); A_arbace_reflect_java__init_A_Unit34__O(); A_arbace_reflect_java__init_A_Unit35__O(); A_arbace_reflect_java__init_A_Unit36__O(); return nil }




func A_arbace_reflect_java__init_A_Unit0__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(10, 1); return lang.IFn_Cast(A_arbace_reflect_java__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_java__init_A_const_1) }

func A_arbace_reflect_java__init_A_Unit1__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(12, 1); return lang.IFn_Cast(A_arbace_reflect_java__init_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_reflect_java__init_A_const_3, A_arbace_reflect_java__init_A_const_4, A_arbace_reflect_java__init_A_const_5) }


func A_arbace_reflect_java__init_A_Unit2__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }
//line :15:1
func A_arbace_reflect_java__init_A_Unit3__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)).Ref() }


func A_arbace_reflect_java__init_A_Unit4__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); return A_arbace_reflect_java__init_A_const_6.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_reflect_java__init_A_Unit5__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_8; var tmp3 any = A_arbace_reflect_java__init_A_const_9.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_10; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000010_fn__1938000011_A_New(); var tmp6 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000010_fn__1938000011_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); aot_arbace_reflect.A_arbace_reflect_eval1938000010_fn__1938000011_A_fn_class = fncls__7d; tmp6 = fncls__7d } else { tmp6 = fncls__7 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :20:1
func A_arbace_reflect_java__init_A_Unit6__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_11; var tmp3 any = A_arbace_reflect_java__init_A_const_9.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_10; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000014_fn__1938000015_A_New(); var tmp6 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000014_fn__1938000015_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); aot_arbace_reflect.A_arbace_reflect_eval1938000014_fn__1938000015_A_fn_class = fncls__14d; tmp6 = fncls__14d } else { tmp6 = fncls__14 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }












func A_arbace_reflect_java__init_A_Unit7__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_12; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_typesym_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_typesym_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); aot_arbace_reflect.A_arbace_reflect_typesym_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_13)); return A_arbace_reflect_java__init_A_const_12 }










func A_arbace_reflect_java__init_A_Unit8__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_14; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_resource_name_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_resource_name_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); aot_arbace_reflect.A_arbace_reflect_resource_name_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_15)); return A_arbace_reflect_java__init_A_const_14 }







func A_arbace_reflect_java__init_A_Unit9__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_16; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_access_flag_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_access_flag_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); aot_arbace_reflect.A_arbace_reflect_access_flag_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_17)); return A_arbace_reflect_java__init_A_const_16 }



func A_arbace_reflect_java__init_A_Unit10__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_18; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_19)); return A_arbace_reflect_java__init_A_const_18 }








func A_arbace_reflect_java__init_A_Unit11__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_20; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_21)); return A_arbace_reflect_java__init_A_const_20 }







func A_arbace_reflect_java__init_A_Unit12__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_22; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_23)); return A_arbace_reflect_java__init_A_const_22 }










func A_arbace_reflect_java__init_A_Unit13__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_24; var tmp2 any; var root_32 any = A_arbace_reflect_java__init_A_const_25.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_34 lang.IFn; if


	linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any; var root_27 any = A_arbace_reflect_java__init_A_const_26.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_29 lang.IFn; if
	linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = A_arbace_reflect_java__init_A_const_16.GetRawRoot__O(); var arg_31 any = A_arbace_reflect_java__init_A_const_27; if linked_28 == nil { arg_35 = ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { arg_35 = linked_28.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_27, arg_30, arg_31) }; if /*line :87:1*/ linked_33 == nil { tmp2 = ifn_34.Invoke_O__O(arg_35) } else { tmp2 = linked_33.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_32, arg_35) }; /*line :84:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_24; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_28)); return A_arbace_reflect_java__init_A_const_24 }

























func A_arbace_reflect_java__init_A_Unit14__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_29; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_parse_flags_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_parse_flags_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); aot_arbace_reflect.A_arbace_reflect_parse_flags_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_30)); return A_arbace_reflect_java__init_A_const_29 }











func A_arbace_reflect_java__init_A_Unit15__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_33)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_34; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_35)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_32; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_36)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_32; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_New(); var tmp6 *jrt.Class; var fncls__37 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); aot_arbace_reflect.A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_fn_class = fncls__37d; tmp6 = fncls__37d } else { tmp6 = fncls__37 }; tmp4.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var tmp7 *lang.Var = A_arbace_reflect_java__init_A_const_34; tmp7.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_37)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_34; var tmp9 any = aot_arbace_reflect.A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_New(); var tmp10 *jrt.Class; var fncls__38 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); aot_arbace_reflect.A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_fn_class = fncls__38d; tmp10 = fncls__38d } else { tmp10 = fncls__38 }; tmp8.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)); return A_arbace_reflect_java__init_A_const_31 }


func A_arbace_reflect_java__init_A_Unit16__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_38; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_39)); return A_arbace_reflect_java__init_A_const_38 }








func A_arbace_reflect_java__init_A_Unit17__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_40; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_41)); return A_arbace_reflect_java__init_A_const_40 }






func A_arbace_reflect_java__init_A_Unit18__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_44)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_45; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_46)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_43; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_47)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_43; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_New(); var tmp6 *jrt.Class; var fncls__41 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); aot_arbace_reflect.A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_fn_class = fncls__41d; tmp6 = fncls__41d } else { tmp6 = fncls__41 }; tmp4.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var tmp7 *lang.Var = A_arbace_reflect_java__init_A_const_45; tmp7.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_48)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_45; var tmp9 any = aot_arbace_reflect.A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_New(); var tmp10 *jrt.Class; var fncls__42 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); aot_arbace_reflect.A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_fn_class = fncls__42d; tmp10 = fncls__42d } else { tmp10 = fncls__42 }; tmp8.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)); return A_arbace_reflect_java__init_A_const_42 }


func A_arbace_reflect_java__init_A_Unit19__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_49; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_50)); return A_arbace_reflect_java__init_A_const_49 }









func A_arbace_reflect_java__init_A_Unit20__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_51; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_declared_methods_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_declared_methods_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); aot_arbace_reflect.A_arbace_reflect_declared_methods_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_52)); return A_arbace_reflect_java__init_A_const_51 }






func A_arbace_reflect_java__init_A_Unit21__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_55)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_56; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_57)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_54; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_58)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_54; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_New(); var tmp6 *jrt.Class; var fncls__45 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); aot_arbace_reflect.A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_fn_class = fncls__45d; tmp6 = fncls__45d } else { tmp6 = fncls__45 }; tmp4.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var tmp7 *lang.Var = A_arbace_reflect_java__init_A_const_56; tmp7.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_59)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_56; var tmp9 any = aot_arbace_reflect.A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_New(); var tmp10 *jrt.Class; var fncls__46 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); aot_arbace_reflect.A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_fn_class = fncls__46d; tmp10 = fncls__46d } else { tmp10 = fncls__46 }; tmp8.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)); return A_arbace_reflect_java__init_A_const_53 }


func A_arbace_reflect_java__init_A_Unit22__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_60; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_61)); return A_arbace_reflect_java__init_A_const_60 }







func A_arbace_reflect_java__init_A_Unit23__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_62; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_declared_fields_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_declared_fields_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); aot_arbace_reflect.A_arbace_reflect_declared_fields_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_63)); return A_arbace_reflect_java__init_A_const_62 }






func A_arbace_reflect_java__init_A_Unit24__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(179, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_64; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_65)); return A_arbace_reflect_java__init_A_const_64 }





func A_arbace_reflect_java__init_A_Unit25__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_28)); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_67; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_68)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_67; var tmp3 any = aot_arbace_reflect.A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_New(); var tmp4 *jrt.Class; var fncls__50 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); aot_arbace_reflect.A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_fn_class = fncls__50d; tmp4 = fncls__50d } else { tmp4 = fncls__50 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); return A_arbace_reflect_java__init_A_const_66 }









func A_arbace_reflect_java__init_A_Unit26__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(195, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_69; var tmp2 any = jrt.Thread_CurrentThread__Thread(); var tmp3 *jrt.Class = A_arbace_reflect_java__init_A_const_70; tmp1.BindRoot_O__V(aot_arbace_reflect.A_arbace_reflect_JavaReflector_A_New_O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp2, tmp3, Lit_30, jrt.RefArrayOf(jrt.Object_class)))); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_71)); return A_arbace_reflect_java__init_A_const_69 }


func A_arbace_reflect_java__init_A_Unit27__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_73)); v__1927001498__auto____1 = A_arbace_reflect_java__init_A_const_72; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_72; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_74)); A_arbace_reflect_java__init_A_const_72.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_reflect_java__init_A_const_72 } }
//line :198:1
func A_arbace_reflect_java__init_A_Unit28__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); return A_arbace_reflect_java__init_A_const_75 }
//line :198:1
func A_arbace_reflect_java__init_A_Unit29__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_76.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_72; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_reflect_java__init_A_const_77.GetRawRoot__O(), A_arbace_reflect_java__init_A_const_78, nil) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit30__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); return A_arbace_reflect_java__init_A_const_79.Invoke_O_O__O(A_arbace_reflect_java__init_A_const_72, A_arbace_reflect_java__init_A_const_80) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit31__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_72; var tmp3 any = A_arbace_reflect_java__init_A_const_82.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_77.GetRawRoot__O()); var tmp5 any = A_arbace_reflect_java__init_A_const_83; var tmp6 any = A_arbace_reflect_java__init_A_const_84; var tmp7 any = A_arbace_reflect_java__init_A_const_85; var tmp8 any = A_arbace_reflect_java__init_A_const_86; var tmp9 any = A_arbace_reflect_java__init_A_const_72; var tmp10 any = A_arbace_reflect_java__init_A_const_87; var tmp11 any = A_arbace_reflect_java__init_A_const_88; var tmp12 any = A_arbace_reflect_java__init_A_const_89; var tmp13 any; var root_68 any = A_arbace_reflect_java__init_A_const_90.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = A_arbace_reflect_java__init_A_const_91.Get__O(); var arg_72 any; var root_63 any = A_arbace_reflect_java__init_A_const_92.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = A_arbace_reflect_java__init_A_const_93; var arg_67 any; var root_58 any = A_arbace_reflect_java__init_A_const_82.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = A_arbace_reflect_java__init_A_const_94; var arg_62 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect_java__init_A_const_95, A_arbace_reflect_java__init_A_const_72)); if linked_59 == nil { arg_67 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { arg_67 = linked_59.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }; if linked_64 == nil { arg_72 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { arg_72 = linked_64.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; if linked_69 == nil { tmp13 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { tmp13 = linked_69.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }; var tmp14 any = tmp13; var tmp15 any = aot_arbace_reflect.A_arbace_reflect_eval1938000121_fn__1938000122_A_New(); var tmp16 *jrt.Class; var fncls__73 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000121_fn__1938000122_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); aot_arbace_reflect.A_arbace_reflect_eval1938000121_fn__1938000122_A_fn_class = fncls__73d; tmp16 = fncls__73d } else { tmp16 = fncls__73 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil))))) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit32__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var root_92 any = A_arbace_reflect_java__init_A_const_96.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = A_arbace_reflect_java__init_A_const_72.GetRawRoot__O(); if linked_93 == nil { return ifn_94.Invoke_O__O(arg_95) } else { return linked_93.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_92, arg_95) } }
//line :198:1
func A_arbace_reflect_java__init_A_Unit33__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); return A_arbace_reflect_java__init_A_const_97 }



func A_arbace_reflect_java__init_A_Unit34__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_98; var tmp3 any = A_arbace_reflect_java__init_A_const_72.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_99; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000137_fn__1938000138_A_New(); var tmp6 *jrt.Class; var fncls__96 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000137_fn__1938000138_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); aot_arbace_reflect.A_arbace_reflect_eval1938000137_fn__1938000138_A_fn_class = fncls__96d; tmp6 = fncls__96d } else { tmp6 = fncls__96 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :202:1
func A_arbace_reflect_java__init_A_Unit35__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_100; var tmp3 any = A_arbace_reflect_java__init_A_const_72.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_99; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000141_fn__1938000142_A_New(); var tmp6 *jrt.Class; var fncls__103 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000141_fn__1938000142_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); aot_arbace_reflect.A_arbace_reflect_eval1938000141_fn__1938000142_A_fn_class = fncls__103d; tmp6 = fncls__103d } else { tmp6 = fncls__103 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }










func A_arbace_reflect_java__init_A_Unit36__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(213, 1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_34)); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_103)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_102; var tmp3 any = aot_arbace_reflect.A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_New(); var tmp4 *jrt.Class; var fncls__110 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_fn_class; if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); aot_arbace_reflect.A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_fn_class = fncls__110d; tmp4 = fncls__110d } else { tmp4 = fncls__110 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); return A_arbace_reflect_java__init_A_const_101 }






type A_arbace_reflect_java__init_A struct{ jrt.Object }

var A_arbace_reflect_java__init_A_const_pool *jrt.RefArray

var A_arbace_reflect_java__init_A_const_0 *lang.Var

var A_arbace_reflect_java__init_A_const_1 any

var A_arbace_reflect_java__init_A_const_2 *lang.Var

var A_arbace_reflect_java__init_A_const_3 any

var A_arbace_reflect_java__init_A_const_4 any

var A_arbace_reflect_java__init_A_const_5 any

var A_arbace_reflect_java__init_A_const_6 *lang.Var

var A_arbace_reflect_java__init_A_const_7 *lang.Var

var A_arbace_reflect_java__init_A_const_8 *jrt.Class

var A_arbace_reflect_java__init_A_const_9 *lang.Var

var A_arbace_reflect_java__init_A_const_10 *lang.Keyword

var A_arbace_reflect_java__init_A_const_11 *jrt.Class

var A_arbace_reflect_java__init_A_const_12 *lang.Var

var A_arbace_reflect_java__init_A_const_13 any

var A_arbace_reflect_java__init_A_const_14 *lang.Var

var A_arbace_reflect_java__init_A_const_15 any

var A_arbace_reflect_java__init_A_const_16 *lang.Var

var A_arbace_reflect_java__init_A_const_17 any

var A_arbace_reflect_java__init_A_const_18 *lang.Var

var A_arbace_reflect_java__init_A_const_19 any

var A_arbace_reflect_java__init_A_const_20 *lang.Var

var A_arbace_reflect_java__init_A_const_21 any

var A_arbace_reflect_java__init_A_const_22 *lang.Var

var A_arbace_reflect_java__init_A_const_23 any

var A_arbace_reflect_java__init_A_const_24 *lang.Var

var A_arbace_reflect_java__init_A_const_25 *lang.Var

var A_arbace_reflect_java__init_A_const_26 *lang.Var

var A_arbace_reflect_java__init_A_const_27 any

var A_arbace_reflect_java__init_A_const_28 any

var A_arbace_reflect_java__init_A_const_29 *lang.Var

var A_arbace_reflect_java__init_A_const_30 any

var A_arbace_reflect_java__init_A_const_31 *jrt.Class

var A_arbace_reflect_java__init_A_const_32 *lang.Var

var A_arbace_reflect_java__init_A_const_33 any

var A_arbace_reflect_java__init_A_const_34 *lang.Var

var A_arbace_reflect_java__init_A_const_35 any

var A_arbace_reflect_java__init_A_const_36 any

var A_arbace_reflect_java__init_A_const_37 any

var A_arbace_reflect_java__init_A_const_38 *lang.Var

var A_arbace_reflect_java__init_A_const_39 any

var A_arbace_reflect_java__init_A_const_40 *lang.Var

var A_arbace_reflect_java__init_A_const_41 any

var A_arbace_reflect_java__init_A_const_42 *jrt.Class

var A_arbace_reflect_java__init_A_const_43 *lang.Var

var A_arbace_reflect_java__init_A_const_44 any

var A_arbace_reflect_java__init_A_const_45 *lang.Var

var A_arbace_reflect_java__init_A_const_46 any

var A_arbace_reflect_java__init_A_const_47 any

var A_arbace_reflect_java__init_A_const_48 any

var A_arbace_reflect_java__init_A_const_49 *lang.Var

var A_arbace_reflect_java__init_A_const_50 any

var A_arbace_reflect_java__init_A_const_51 *lang.Var

var A_arbace_reflect_java__init_A_const_52 any

var A_arbace_reflect_java__init_A_const_53 *jrt.Class

var A_arbace_reflect_java__init_A_const_54 *lang.Var

var A_arbace_reflect_java__init_A_const_55 any

var A_arbace_reflect_java__init_A_const_56 *lang.Var

var A_arbace_reflect_java__init_A_const_57 any

var A_arbace_reflect_java__init_A_const_58 any

var A_arbace_reflect_java__init_A_const_59 any

var A_arbace_reflect_java__init_A_const_60 *lang.Var

var A_arbace_reflect_java__init_A_const_61 any

var A_arbace_reflect_java__init_A_const_62 *lang.Var

var A_arbace_reflect_java__init_A_const_63 any

var A_arbace_reflect_java__init_A_const_64 *lang.Var

var A_arbace_reflect_java__init_A_const_65 any

var A_arbace_reflect_java__init_A_const_66 *jrt.Class

var A_arbace_reflect_java__init_A_const_67 *lang.Var

var A_arbace_reflect_java__init_A_const_68 any

var A_arbace_reflect_java__init_A_const_69 *lang.Var

var A_arbace_reflect_java__init_A_const_70 *jrt.Class

var A_arbace_reflect_java__init_A_const_71 any

var A_arbace_reflect_java__init_A_const_72 *lang.Var

var A_arbace_reflect_java__init_A_const_73 any

var A_arbace_reflect_java__init_A_const_74 any

var A_arbace_reflect_java__init_A_const_75 *jrt.Class

var A_arbace_reflect_java__init_A_const_76 *lang.Var

var A_arbace_reflect_java__init_A_const_77 *lang.Var

var A_arbace_reflect_java__init_A_const_78 *lang.Keyword

var A_arbace_reflect_java__init_A_const_79 *lang.Var

var A_arbace_reflect_java__init_A_const_80 any

var A_arbace_reflect_java__init_A_const_81 *lang.Var

var A_arbace_reflect_java__init_A_const_82 *lang.Var

var A_arbace_reflect_java__init_A_const_83 any

var A_arbace_reflect_java__init_A_const_84 *lang.Keyword

var A_arbace_reflect_java__init_A_const_85 any

var A_arbace_reflect_java__init_A_const_86 *lang.Keyword

var A_arbace_reflect_java__init_A_const_87 *lang.Keyword

var A_arbace_reflect_java__init_A_const_88 any

var A_arbace_reflect_java__init_A_const_89 *lang.Keyword

var A_arbace_reflect_java__init_A_const_90 *lang.Var

var A_arbace_reflect_java__init_A_const_91 *lang.Var

var A_arbace_reflect_java__init_A_const_92 *lang.Var

var A_arbace_reflect_java__init_A_const_93 any

var A_arbace_reflect_java__init_A_const_94 any

var A_arbace_reflect_java__init_A_const_95 *lang.Keyword

var A_arbace_reflect_java__init_A_const_96 *lang.Var

var A_arbace_reflect_java__init_A_const_97 any

var A_arbace_reflect_java__init_A_const_98 *jrt.Class

var A_arbace_reflect_java__init_A_const_99 *lang.Keyword

var A_arbace_reflect_java__init_A_const_100 *jrt.Class

var A_arbace_reflect_java__init_A_const_101 *jrt.Class

var A_arbace_reflect_java__init_A_const_102 *lang.Var

var A_arbace_reflect_java__init_A_const_103 any

var A_arbace_reflect_java__init_A_init jrt.ClassInit

func A_arbace_reflect_java__init_A_Init() { if !A_arbace_reflect_java__init_A_init.Done() { A_arbace_reflect_java__init_A_init.Run(A_arbace_reflect_java__init_A_clinit) } }

func A_arbace_reflect_java__init_A_clinit() { A_arbace_reflect_java__init_A_clinit_p0(); A_arbace_reflect_java__init_A_clinit_p1(); A_arbace_reflect_java__init_A_clinit_p2(); A_arbace_reflect_java__init_A_clinit_p3(); A_arbace_reflect_java__init_A_clinit_p4(); A_arbace_reflect_java__init_A_clinit_p5(); A_arbace_reflect_java__init_A_clinit_p6(); A_arbace_reflect_java__init_A_clinit_p7(); A_arbace_reflect_java__init_A_clinit_p8() }

func A_arbace_reflect_java__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_reflect_java__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 180); A_arbace_reflect_java__init_A_const_0 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[76]); A_arbace_reflect_java__init_A_const_1 = A_arbace_reflect_java__init_A_const_pool.A[77]; A_arbace_reflect_java__init_A_const_2 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[78]); A_arbace_reflect_java__init_A_const_3 = A_arbace_reflect_java__init_A_const_pool.A[79]; A_arbace_reflect_java__init_A_const_4 = A_arbace_reflect_java__init_A_const_pool.A[80]; A_arbace_reflect_java__init_A_const_5 = A_arbace_reflect_java__init_A_const_pool.A[81]; A_arbace_reflect_java__init_A_const_6 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[82]); A_arbace_reflect_java__init_A_const_7 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[83]); A_arbace_reflect_java__init_A_const_8 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[84]); A_arbace_reflect_java__init_A_const_9 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[85]); A_arbace_reflect_java__init_A_const_10 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[86]); A_arbace_reflect_java__init_A_const_11 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[87]) }

func A_arbace_reflect_java__init_A_clinit_p1() { A_arbace_reflect_java__init_A_const_12 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[88]); A_arbace_reflect_java__init_A_const_13 = A_arbace_reflect_java__init_A_const_pool.A[89]; A_arbace_reflect_java__init_A_const_14 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[90]); A_arbace_reflect_java__init_A_const_15 = A_arbace_reflect_java__init_A_const_pool.A[91]; A_arbace_reflect_java__init_A_const_16 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[92]); A_arbace_reflect_java__init_A_const_17 = A_arbace_reflect_java__init_A_const_pool.A[93]; A_arbace_reflect_java__init_A_const_18 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[94]); A_arbace_reflect_java__init_A_const_19 = A_arbace_reflect_java__init_A_const_pool.A[95]; A_arbace_reflect_java__init_A_const_20 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[96]); A_arbace_reflect_java__init_A_const_21 = A_arbace_reflect_java__init_A_const_pool.A[97]; A_arbace_reflect_java__init_A_const_22 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[98]); A_arbace_reflect_java__init_A_const_23 = A_arbace_reflect_java__init_A_const_pool.A[99]; A_arbace_reflect_java__init_A_const_24 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[100]) }

func A_arbace_reflect_java__init_A_clinit_p2() { A_arbace_reflect_java__init_A_const_25 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[101]); A_arbace_reflect_java__init_A_const_26 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[102]); A_arbace_reflect_java__init_A_const_27 = A_arbace_reflect_java__init_A_const_pool.A[103]; A_arbace_reflect_java__init_A_const_28 = A_arbace_reflect_java__init_A_const_pool.A[104]; A_arbace_reflect_java__init_A_const_29 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[105]); A_arbace_reflect_java__init_A_const_30 = A_arbace_reflect_java__init_A_const_pool.A[106]; A_arbace_reflect_java__init_A_const_31 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[107]); A_arbace_reflect_java__init_A_const_32 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[108]); A_arbace_reflect_java__init_A_const_33 = A_arbace_reflect_java__init_A_const_pool.A[109]; A_arbace_reflect_java__init_A_const_34 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[110]); A_arbace_reflect_java__init_A_const_35 = A_arbace_reflect_java__init_A_const_pool.A[111]; A_arbace_reflect_java__init_A_const_36 = A_arbace_reflect_java__init_A_const_pool.A[112]; A_arbace_reflect_java__init_A_const_37 = A_arbace_reflect_java__init_A_const_pool.A[113] }

func A_arbace_reflect_java__init_A_clinit_p3() { A_arbace_reflect_java__init_A_const_38 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[114]); A_arbace_reflect_java__init_A_const_39 = A_arbace_reflect_java__init_A_const_pool.A[115]; A_arbace_reflect_java__init_A_const_40 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[116]); A_arbace_reflect_java__init_A_const_41 = A_arbace_reflect_java__init_A_const_pool.A[117]; A_arbace_reflect_java__init_A_const_42 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[118]); A_arbace_reflect_java__init_A_const_43 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[119]); A_arbace_reflect_java__init_A_const_44 = A_arbace_reflect_java__init_A_const_pool.A[120]; A_arbace_reflect_java__init_A_const_45 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[121]); A_arbace_reflect_java__init_A_const_46 = A_arbace_reflect_java__init_A_const_pool.A[122]; A_arbace_reflect_java__init_A_const_47 = A_arbace_reflect_java__init_A_const_pool.A[123]; A_arbace_reflect_java__init_A_const_48 = A_arbace_reflect_java__init_A_const_pool.A[124]; A_arbace_reflect_java__init_A_const_49 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[125]); A_arbace_reflect_java__init_A_const_50 = A_arbace_reflect_java__init_A_const_pool.A[126] }

func A_arbace_reflect_java__init_A_clinit_p4() { A_arbace_reflect_java__init_A_const_51 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[127]); A_arbace_reflect_java__init_A_const_52 = A_arbace_reflect_java__init_A_const_pool.A[128]; A_arbace_reflect_java__init_A_const_53 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[129]); A_arbace_reflect_java__init_A_const_54 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[130]); A_arbace_reflect_java__init_A_const_55 = A_arbace_reflect_java__init_A_const_pool.A[131]; A_arbace_reflect_java__init_A_const_56 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[132]); A_arbace_reflect_java__init_A_const_57 = A_arbace_reflect_java__init_A_const_pool.A[133]; A_arbace_reflect_java__init_A_const_58 = A_arbace_reflect_java__init_A_const_pool.A[134]; A_arbace_reflect_java__init_A_const_59 = A_arbace_reflect_java__init_A_const_pool.A[135]; A_arbace_reflect_java__init_A_const_60 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[136]); A_arbace_reflect_java__init_A_const_61 = A_arbace_reflect_java__init_A_const_pool.A[137]; A_arbace_reflect_java__init_A_const_62 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[138]); A_arbace_reflect_java__init_A_const_63 = A_arbace_reflect_java__init_A_const_pool.A[139] }

func A_arbace_reflect_java__init_A_clinit_p5() { A_arbace_reflect_java__init_A_const_64 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[140]); A_arbace_reflect_java__init_A_const_65 = A_arbace_reflect_java__init_A_const_pool.A[141]; A_arbace_reflect_java__init_A_const_66 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[142]); A_arbace_reflect_java__init_A_const_67 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[143]); A_arbace_reflect_java__init_A_const_68 = A_arbace_reflect_java__init_A_const_pool.A[144]; A_arbace_reflect_java__init_A_const_69 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[145]); A_arbace_reflect_java__init_A_const_70 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[146]); A_arbace_reflect_java__init_A_const_71 = A_arbace_reflect_java__init_A_const_pool.A[147]; A_arbace_reflect_java__init_A_const_72 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[148]); A_arbace_reflect_java__init_A_const_73 = A_arbace_reflect_java__init_A_const_pool.A[149]; A_arbace_reflect_java__init_A_const_74 = A_arbace_reflect_java__init_A_const_pool.A[150]; A_arbace_reflect_java__init_A_const_75 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[151]); A_arbace_reflect_java__init_A_const_76 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[152]) }

func A_arbace_reflect_java__init_A_clinit_p6() { A_arbace_reflect_java__init_A_const_77 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[153]); A_arbace_reflect_java__init_A_const_78 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[154]); A_arbace_reflect_java__init_A_const_79 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[155]); A_arbace_reflect_java__init_A_const_80 = A_arbace_reflect_java__init_A_const_pool.A[156]; A_arbace_reflect_java__init_A_const_81 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[157]); A_arbace_reflect_java__init_A_const_82 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[158]); A_arbace_reflect_java__init_A_const_83 = A_arbace_reflect_java__init_A_const_pool.A[159]; A_arbace_reflect_java__init_A_const_84 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[160]); A_arbace_reflect_java__init_A_const_85 = A_arbace_reflect_java__init_A_const_pool.A[161]; A_arbace_reflect_java__init_A_const_86 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[162]); A_arbace_reflect_java__init_A_const_87 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[163]); A_arbace_reflect_java__init_A_const_88 = A_arbace_reflect_java__init_A_const_pool.A[164]; A_arbace_reflect_java__init_A_const_89 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[165]) }

func A_arbace_reflect_java__init_A_clinit_p7() { A_arbace_reflect_java__init_A_const_90 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[166]); A_arbace_reflect_java__init_A_const_91 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[167]); A_arbace_reflect_java__init_A_const_92 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[168]); A_arbace_reflect_java__init_A_const_93 = A_arbace_reflect_java__init_A_const_pool.A[169]; A_arbace_reflect_java__init_A_const_94 = A_arbace_reflect_java__init_A_const_pool.A[170]; A_arbace_reflect_java__init_A_const_95 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[171]); A_arbace_reflect_java__init_A_const_96 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[172]); A_arbace_reflect_java__init_A_const_97 = A_arbace_reflect_java__init_A_const_pool.A[173]; A_arbace_reflect_java__init_A_const_98 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[174]); A_arbace_reflect_java__init_A_const_99 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[175]); A_arbace_reflect_java__init_A_const_100 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[176]); A_arbace_reflect_java__init_A_const_101 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[177]) }

func A_arbace_reflect_java__init_A_clinit_p8() { A_arbace_reflect_java__init_A_const_102 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[178]); A_arbace_reflect_java__init_A_const_103 = A_arbace_reflect_java__init_A_const_pool.A[179] }

func A_arbace_reflect_java__init_A_New() *A_arbace_reflect_java__init_A { A_arbace_reflect_java__init_A_Init(); t := &A_arbace_reflect_java__init_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_java__init_A) Ctor() {}

func (t *A_arbace_reflect_java__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_java__init_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_java__init_A_class }

func (t *A_arbace_reflect_java__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_java__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_java__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_java__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_java__init_A); return ok }

func A_arbace_reflect_java__init_A_Cast(x any) *A_arbace_reflect_java__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_java__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_java__init_A_class)) }; return v }
