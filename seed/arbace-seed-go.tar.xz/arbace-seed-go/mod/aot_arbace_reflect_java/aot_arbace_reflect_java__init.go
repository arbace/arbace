//line aot_arbace_reflect_java__init.ae:1
package aot_arbace_reflect_java

import (
	"arbace/aot_arbace_reflect"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_reflect_java__init_A_Load__O() any { A_arbace_reflect_java__init_A_Init(); A_arbace_reflect_java__init_A_Unit0__O(); A_arbace_reflect_java__init_A_Unit1__O(); A_arbace_reflect_java__init_A_Unit2__O(); A_arbace_reflect_java__init_A_Unit3__O(); A_arbace_reflect_java__init_A_Unit4__O(); A_arbace_reflect_java__init_A_Unit5__O(); A_arbace_reflect_java__init_A_Unit6__O(); A_arbace_reflect_java__init_A_Unit7__O(); A_arbace_reflect_java__init_A_Unit8__O(); A_arbace_reflect_java__init_A_Unit9__O(); A_arbace_reflect_java__init_A_Unit10__O(); A_arbace_reflect_java__init_A_Unit11__O(); A_arbace_reflect_java__init_A_Unit12__O(); A_arbace_reflect_java__init_A_Unit13__O(); A_arbace_reflect_java__init_A_Unit14__O(); A_arbace_reflect_java__init_A_Unit15__O(); A_arbace_reflect_java__init_A_Unit16__O(); A_arbace_reflect_java__init_A_Unit17__O(); A_arbace_reflect_java__init_A_Unit18__O(); A_arbace_reflect_java__init_A_Unit19__O(); A_arbace_reflect_java__init_A_Unit20__O(); A_arbace_reflect_java__init_A_Unit21__O(); A_arbace_reflect_java__init_A_Unit22__O(); A_arbace_reflect_java__init_A_Unit23__O(); A_arbace_reflect_java__init_A_Unit24__O(); A_arbace_reflect_java__init_A_Unit25__O(); A_arbace_reflect_java__init_A_Unit26__O(); A_arbace_reflect_java__init_A_Unit27__O(); A_arbace_reflect_java__init_A_Unit28__O(); A_arbace_reflect_java__init_A_Unit29__O(); A_arbace_reflect_java__init_A_Unit30__O(); A_arbace_reflect_java__init_A_Unit31__O(); A_arbace_reflect_java__init_A_Unit32__O(); A_arbace_reflect_java__init_A_Unit33__O(); A_arbace_reflect_java__init_A_Unit34__O(); A_arbace_reflect_java__init_A_Unit35__O(); A_arbace_reflect_java__init_A_Unit36__O(); return nil }




func A_arbace_reflect_java__init_A_Unit0__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(10, 1); return lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_java__init_A_const_1) }

func A_arbace_reflect_java__init_A_Unit1__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); return lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_2).GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_reflect_java__init_A_const_3, A_arbace_reflect_java__init_A_const_4, A_arbace_reflect_java__init_A_const_5) }


func A_arbace_reflect_java__init_A_Unit2__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_146)); return nil }
//line :15:1
func A_arbace_reflect_java__init_A_Unit3__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_131)); return nil }


func A_arbace_reflect_java__init_A_Unit4__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_6; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }

func A_arbace_reflect_java__init_A_Unit5__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_7).GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_8.Ref(); var tmp3 any = jrt.NN(A_arbace_reflect_java__init_A_const_9).GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_10.Ref(); var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000010_fn__1938000011_A_New(); var tmp6 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000010_fn__1938000011_A_Init(); tmp6 = aot_arbace_reflect.A_arbace_reflect_eval1938000010_fn__1938000011_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :20:1
func A_arbace_reflect_java__init_A_Unit6__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_7).GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_11.Ref(); var tmp3 any = jrt.NN(A_arbace_reflect_java__init_A_const_9).GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_10.Ref(); var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000014_fn__1938000015_A_New(); var tmp6 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000014_fn__1938000015_A_Init(); tmp6 = aot_arbace_reflect.A_arbace_reflect_eval1938000014_fn__1938000015_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }












func A_arbace_reflect_java__init_A_Unit7__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_12; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_typesym_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_typesym_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_typesym_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_13)); return A_arbace_reflect_java__init_A_const_12.Ref() }










func A_arbace_reflect_java__init_A_Unit8__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_14; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_resource_name_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_resource_name_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_resource_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_15)); return A_arbace_reflect_java__init_A_const_14.Ref() }







func A_arbace_reflect_java__init_A_Unit9__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(52, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_16; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_access_flag_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_access_flag_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_access_flag_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_17)); return A_arbace_reflect_java__init_A_const_16.Ref() }



func A_arbace_reflect_java__init_A_Unit10__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(56, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_18; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_19)); return A_arbace_reflect_java__init_A_const_18.Ref() }








func A_arbace_reflect_java__init_A_Unit11__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(65, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_20; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_21)); return A_arbace_reflect_java__init_A_const_20.Ref() }







func A_arbace_reflect_java__init_A_Unit12__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_22; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_23)); return A_arbace_reflect_java__init_A_const_22.Ref() }










func A_arbace_reflect_java__init_A_Unit13__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(84, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_24; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_25).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_27).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_reflect_java__init_A_const_16).GetRawRoot__O(), A_arbace_reflect_java__init_A_const_28))); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_24; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_26)); return A_arbace_reflect_java__init_A_const_24.Ref() }

























func A_arbace_reflect_java__init_A_Unit14__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(110, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_29; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_parse_flags_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_parse_flags_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_parse_flags_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_30)); return A_arbace_reflect_java__init_A_const_29.Ref() }











func A_arbace_reflect_java__init_A_Unit15__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_32; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_33)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_34; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_35)); var tmp3 *lang.Var; lang.RT_Init(); tmp3 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp3).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_75)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_36)); var tmp5 *lang.Var = A_arbace_reflect_java__init_A_const_32; var tmp6 any = aot_arbace_reflect.A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_New(); var tmp7 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_Init(); tmp7 = aot_arbace_reflect.A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_fn_class; jrt.NN(tmp5).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_34; jrt.NN(tmp8).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_37)); var tmp9 *lang.Var = A_arbace_reflect_java__init_A_const_34; var tmp10 any = aot_arbace_reflect.A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_New(); var tmp11 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_Init(); tmp11 = aot_arbace_reflect.A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_fn_class; jrt.NN(tmp9).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)); return A_arbace_reflect_java__init_A_const_31.Ref() }


func A_arbace_reflect_java__init_A_Unit16__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(125, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_38; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_39)); return A_arbace_reflect_java__init_A_const_38.Ref() }








func A_arbace_reflect_java__init_A_Unit17__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(134, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_40; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_41)); return A_arbace_reflect_java__init_A_const_40.Ref() }






func A_arbace_reflect_java__init_A_Unit18__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(141, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_43; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_44)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_45; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_46)); var tmp3 *lang.Var; lang.RT_Init(); tmp3 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp3).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_92)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_47)); var tmp5 *lang.Var = A_arbace_reflect_java__init_A_const_43; var tmp6 any = aot_arbace_reflect.A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_New(); var tmp7 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_Init(); tmp7 = aot_arbace_reflect.A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_fn_class; jrt.NN(tmp5).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_45; jrt.NN(tmp8).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_48)); var tmp9 *lang.Var = A_arbace_reflect_java__init_A_const_45; var tmp10 any = aot_arbace_reflect.A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_New(); var tmp11 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_Init(); tmp11 = aot_arbace_reflect.A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_fn_class; jrt.NN(tmp9).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)); return A_arbace_reflect_java__init_A_const_42.Ref() }


func A_arbace_reflect_java__init_A_Unit19__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(144, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_49; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_50)); return A_arbace_reflect_java__init_A_const_49.Ref() }









func A_arbace_reflect_java__init_A_Unit20__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_51; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_declared_methods_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_declared_methods_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_declared_methods_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_52)); return A_arbace_reflect_java__init_A_const_51.Ref() }






func A_arbace_reflect_java__init_A_Unit21__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_54; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_55)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_56; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_57)); var tmp3 *lang.Var; lang.RT_Init(); tmp3 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp3).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_101)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_58)); var tmp5 *lang.Var = A_arbace_reflect_java__init_A_const_54; var tmp6 any = aot_arbace_reflect.A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_New(); var tmp7 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_Init(); tmp7 = aot_arbace_reflect.A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_fn_class; jrt.NN(tmp5).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_56; jrt.NN(tmp8).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_59)); var tmp9 *lang.Var = A_arbace_reflect_java__init_A_const_56; var tmp10 any = aot_arbace_reflect.A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_New(); var tmp11 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_Init(); tmp11 = aot_arbace_reflect.A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_fn_class; jrt.NN(tmp9).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)); return A_arbace_reflect_java__init_A_const_53.Ref() }


func A_arbace_reflect_java__init_A_Unit22__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(164, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_60; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_61)); return A_arbace_reflect_java__init_A_const_60.Ref() }







func A_arbace_reflect_java__init_A_Unit23__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_62; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_declared_fields_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_declared_fields_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_declared_fields_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_63)); return A_arbace_reflect_java__init_A_const_62.Ref() }






func A_arbace_reflect_java__init_A_Unit24__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(179, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_64; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_New(); var tmp3 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_Init(); tmp3 = aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_65)); return A_arbace_reflect_java__init_A_const_64.Ref() }





func A_arbace_reflect_java__init_A_Unit25__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_113)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_67; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_68)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_67; var tmp4 any = aot_arbace_reflect.A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_New(); var tmp5 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_Init(); tmp5 = aot_arbace_reflect.A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_fn_class; jrt.NN(tmp3).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_reflect_java__init_A_const_66.Ref() }









func A_arbace_reflect_java__init_A_Unit26__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(195, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_69; var tmp2 any = jrt.Thread_CurrentThread__Thread(); var tmp3 *jrt.Class = A_arbace_reflect_java__init_A_const_70; jrt.NN(tmp1).BindRoot_O__V(aot_arbace_reflect.A_arbace_reflect_JavaReflector_A_New_O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp2, tmp3, Lit_147, jrt.RefArrayOf(jrt.Object_class)))); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_69; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_71)); return A_arbace_reflect_java__init_A_const_69.Ref() }


func A_arbace_reflect_java__init_A_Unit27__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_72; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_73)); v__1927001498__auto____1 = A_arbace_reflect_java__init_A_const_72.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_72; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_74)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_72; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_reflect_java__init_A_const_72.Ref() } }
//line :198:1
func A_arbace_reflect_java__init_A_Unit28__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); return A_arbace_reflect_java__init_A_const_75.Ref() }
//line :198:1
func A_arbace_reflect_java__init_A_Unit29__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_76).GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_72.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_reflect_java__init_A_const_77).GetRawRoot__O(), A_arbace_reflect_java__init_A_const_78.Ref(), nil) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit30__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); return Up_Var_IFn(A_arbace_reflect_java__init_A_const_79).Invoke_O_O__O(A_arbace_reflect_java__init_A_const_72.Ref(), A_arbace_reflect_java__init_A_const_80) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit31__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_81).GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_72.Ref(); var tmp3 any = jrt.NN(A_arbace_reflect_java__init_A_const_82).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_77).GetRawRoot__O()); var tmp5 any = A_arbace_reflect_java__init_A_const_83; var tmp6 any = A_arbace_reflect_java__init_A_const_84.Ref(); var tmp7 any = A_arbace_reflect_java__init_A_const_85; var tmp8 any = A_arbace_reflect_java__init_A_const_86.Ref(); var tmp9 any = A_arbace_reflect_java__init_A_const_72.Ref(); var tmp10 any = A_arbace_reflect_java__init_A_const_87.Ref(); var tmp11 any = A_arbace_reflect_java__init_A_const_88; var tmp12 any = A_arbace_reflect_java__init_A_const_89.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_92).GetRawRoot__O()); var tmp14 any = A_arbace_reflect_java__init_A_const_93; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_82).GetRawRoot__O()); var tmp16 any = A_arbace_reflect_java__init_A_const_94; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_90).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_reflect_java__init_A_const_91).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect_java__init_A_const_95.Ref(), A_arbace_reflect_java__init_A_const_72.Ref()))))); var tmp18 any = aot_arbace_reflect.A_arbace_reflect_eval1938000121_fn__1938000122_A_New(); var tmp19 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000121_fn__1938000122_A_Init(); tmp19 = aot_arbace_reflect.A_arbace_reflect_eval1938000121_fn__1938000122_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit32__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); return lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_96).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_reflect_java__init_A_const_72).GetRawRoot__O()) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit33__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); return A_arbace_reflect_java__init_A_const_97 }



func A_arbace_reflect_java__init_A_Unit34__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_7).GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_98.Ref(); var tmp3 any = jrt.NN(A_arbace_reflect_java__init_A_const_72).GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_99.Ref(); var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000137_fn__1938000138_A_New(); var tmp6 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000137_fn__1938000138_A_Init(); tmp6 = aot_arbace_reflect.A_arbace_reflect_eval1938000137_fn__1938000138_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :202:1
func A_arbace_reflect_java__init_A_Unit35__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect_java__init_A_const_7).GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_100.Ref(); var tmp3 any = jrt.NN(A_arbace_reflect_java__init_A_const_72).GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_99.Ref(); var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000141_fn__1938000142_A_New(); var tmp6 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000141_fn__1938000142_A_Init(); tmp6 = aot_arbace_reflect.A_arbace_reflect_eval1938000141_fn__1938000142_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }










func A_arbace_reflect_java__init_A_Unit36__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(213, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_142)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_102; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_103)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_102; var tmp4 any = aot_arbace_reflect.A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_New(); var tmp5 *jrt.Class; aot_arbace_reflect.A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_Init(); tmp5 = aot_arbace_reflect.A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_fn_class; jrt.NN(tmp3).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_reflect_java__init_A_const_101.Ref() }






type A_arbace_reflect_java__init_A struct{ jrt.Object }

var A_arbace_reflect_java__init_A_const_0 *lang.Var

var A_arbace_reflect_java__init_A_const_1 any

var A_arbace_reflect_java__init_A_const_2 *lang.Var

var A_arbace_reflect_java__init_A_const_3 any

var A_arbace_reflect_java__init_A_const_4 any

var A_arbace_reflect_java__init_A_const_5 any

var A_arbace_reflect_java__init_A_const_6 *lang.Var

var A_arbace_reflect_java__init_A_const_7 *lang.Var

var A_arbace_reflect_java__init_A_const_8 *jrt.Class

var A_arbace_reflect_java__init_A_const_9 *lang.Var

var A_arbace_reflect_java__init_A_const_10 *lang.Keyword

var A_arbace_reflect_java__init_A_const_11 *jrt.Class

var A_arbace_reflect_java__init_A_const_12 *lang.Var

var A_arbace_reflect_java__init_A_const_13 any

var A_arbace_reflect_java__init_A_const_14 *lang.Var

var A_arbace_reflect_java__init_A_const_15 any

var A_arbace_reflect_java__init_A_const_16 *lang.Var

var A_arbace_reflect_java__init_A_const_17 any

var A_arbace_reflect_java__init_A_const_18 *lang.Var

var A_arbace_reflect_java__init_A_const_19 any

var A_arbace_reflect_java__init_A_const_20 *lang.Var

var A_arbace_reflect_java__init_A_const_21 any

var A_arbace_reflect_java__init_A_const_22 *lang.Var

var A_arbace_reflect_java__init_A_const_23 any

var A_arbace_reflect_java__init_A_const_24 *lang.Var

var A_arbace_reflect_java__init_A_const_25 *lang.Var

var A_arbace_reflect_java__init_A_const_26 any

var A_arbace_reflect_java__init_A_const_27 *lang.Var

var A_arbace_reflect_java__init_A_const_28 any

var A_arbace_reflect_java__init_A_const_29 *lang.Var

var A_arbace_reflect_java__init_A_const_30 any

var A_arbace_reflect_java__init_A_const_31 *jrt.Class

var A_arbace_reflect_java__init_A_const_32 *lang.Var

var A_arbace_reflect_java__init_A_const_33 any

var A_arbace_reflect_java__init_A_const_34 *lang.Var

var A_arbace_reflect_java__init_A_const_35 any

var A_arbace_reflect_java__init_A_const_36 any

var A_arbace_reflect_java__init_A_const_37 any

var A_arbace_reflect_java__init_A_const_38 *lang.Var

var A_arbace_reflect_java__init_A_const_39 any

var A_arbace_reflect_java__init_A_const_40 *lang.Var

var A_arbace_reflect_java__init_A_const_41 any

var A_arbace_reflect_java__init_A_const_42 *jrt.Class

var A_arbace_reflect_java__init_A_const_43 *lang.Var

var A_arbace_reflect_java__init_A_const_44 any

var A_arbace_reflect_java__init_A_const_45 *lang.Var

var A_arbace_reflect_java__init_A_const_46 any

var A_arbace_reflect_java__init_A_const_47 any

var A_arbace_reflect_java__init_A_const_48 any

var A_arbace_reflect_java__init_A_const_49 *lang.Var

var A_arbace_reflect_java__init_A_const_50 any

var A_arbace_reflect_java__init_A_const_51 *lang.Var

var A_arbace_reflect_java__init_A_const_52 any

var A_arbace_reflect_java__init_A_const_53 *jrt.Class

var A_arbace_reflect_java__init_A_const_54 *lang.Var

var A_arbace_reflect_java__init_A_const_55 any

var A_arbace_reflect_java__init_A_const_56 *lang.Var

var A_arbace_reflect_java__init_A_const_57 any

var A_arbace_reflect_java__init_A_const_58 any

var A_arbace_reflect_java__init_A_const_59 any

var A_arbace_reflect_java__init_A_const_60 *lang.Var

var A_arbace_reflect_java__init_A_const_61 any

var A_arbace_reflect_java__init_A_const_62 *lang.Var

var A_arbace_reflect_java__init_A_const_63 any

var A_arbace_reflect_java__init_A_const_64 *lang.Var

var A_arbace_reflect_java__init_A_const_65 any

var A_arbace_reflect_java__init_A_const_66 *jrt.Class

var A_arbace_reflect_java__init_A_const_67 *lang.Var

var A_arbace_reflect_java__init_A_const_68 any

var A_arbace_reflect_java__init_A_const_69 *lang.Var

var A_arbace_reflect_java__init_A_const_70 *jrt.Class

var A_arbace_reflect_java__init_A_const_71 any

var A_arbace_reflect_java__init_A_const_72 *lang.Var

var A_arbace_reflect_java__init_A_const_73 any

var A_arbace_reflect_java__init_A_const_74 any

var A_arbace_reflect_java__init_A_const_75 *jrt.Class

var A_arbace_reflect_java__init_A_const_76 *lang.Var

var A_arbace_reflect_java__init_A_const_77 *lang.Var

var A_arbace_reflect_java__init_A_const_78 *lang.Keyword

var A_arbace_reflect_java__init_A_const_79 *lang.Var

var A_arbace_reflect_java__init_A_const_80 any

var A_arbace_reflect_java__init_A_const_81 *lang.Var

var A_arbace_reflect_java__init_A_const_82 *lang.Var

var A_arbace_reflect_java__init_A_const_83 any

var A_arbace_reflect_java__init_A_const_84 *lang.Keyword

var A_arbace_reflect_java__init_A_const_85 any

var A_arbace_reflect_java__init_A_const_86 *lang.Keyword

var A_arbace_reflect_java__init_A_const_87 *lang.Keyword

var A_arbace_reflect_java__init_A_const_88 any

var A_arbace_reflect_java__init_A_const_89 *lang.Keyword

var A_arbace_reflect_java__init_A_const_90 *lang.Var

var A_arbace_reflect_java__init_A_const_91 *lang.Var

var A_arbace_reflect_java__init_A_const_92 *lang.Var

var A_arbace_reflect_java__init_A_const_93 any

var A_arbace_reflect_java__init_A_const_94 any

var A_arbace_reflect_java__init_A_const_95 *lang.Keyword

var A_arbace_reflect_java__init_A_const_96 *lang.Var

var A_arbace_reflect_java__init_A_const_97 any

var A_arbace_reflect_java__init_A_const_98 *jrt.Class

var A_arbace_reflect_java__init_A_const_99 *lang.Keyword

var A_arbace_reflect_java__init_A_const_100 *jrt.Class

var A_arbace_reflect_java__init_A_const_101 *jrt.Class

var A_arbace_reflect_java__init_A_const_102 *lang.Var

var A_arbace_reflect_java__init_A_const_103 any

var A_arbace_reflect_java__init_A_init jrt.ClassInit

func A_arbace_reflect_java__init_A_Init() { if !A_arbace_reflect_java__init_A_init.Done() { A_arbace_reflect_java__init_A_init.Run(A_arbace_reflect_java__init_A_clinit) } }

func A_arbace_reflect_java__init_A_clinit() { A_arbace_reflect_java__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_reflect_java__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_2).Ref(); A_arbace_reflect_java__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_reflect_java__init_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref())))); A_arbace_reflect_java__init_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_reflect_java__init_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref()); A_arbace_reflect_java__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_reflect_java__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_reflect_java__init_A_const_8 = lang.RT_ClassForNameNonLoading_String__Class(Lit_16); A_arbace_reflect_java__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_2, Lit_17); A_arbace_reflect_java__init_A_const_10 = lang.RT_Keyword_String_String__Keyword(nil, Lit_18); A_arbace_reflect_java__init_A_const_11 = lang.RT_ClassForNameNonLoading_String__Class(Lit_19); A_arbace_reflect_java__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_2, Lit_20); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_reflect_java__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_25, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_2, Lit_28); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_reflect_java__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_30, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_2, Lit_31); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_reflect_java__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_2, Lit_36); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_reflect_java__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_37)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_40, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(56).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_2, Lit_41); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_reflect_java__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_37)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_43).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(10).Ref())))))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_44, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_2, Lit_45); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_reflect_java__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_43).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(10).Ref())))))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_46, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(73).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_2, Lit_47); A_arbace_reflect_java__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_reflect_java__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_49, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(84).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_reflect_java__init_A_const_28 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Long_ValueOf_J__Long(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Long_ValueOf_J__Long(2).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), jrt.Long_ValueOf_J__Long(4).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_56).Ref(), jrt.Long_ValueOf_J__Long(8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Long_ValueOf_J__Long(16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), jrt.Long_ValueOf_J__Long(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), jrt.Long_ValueOf_J__Long(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), jrt.Long_ValueOf_J__Long(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_61).Ref(), jrt.Long_ValueOf_J__Long(128).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), jrt.Long_ValueOf_J__Long(128).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), jrt.Long_ValueOf_J__Long(256).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Long_ValueOf_J__Long(512).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref()), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Long_ValueOf_J__Long(1024).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_66).Ref(), jrt.Long_ValueOf_J__Long(2048).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_67).Ref(), jrt.Long_ValueOf_J__Long(4096).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_68).Ref(), jrt.Long_ValueOf_J__Long(8192).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref()), lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_69).Ref(), jrt.Long_ValueOf_J__Long(16384).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_70).Ref()))); A_arbace_reflect_java__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_2, Lit_71); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_reflect_java__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_74, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(110).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_31 = lang.RT_ClassForNameNonLoading_String__Class(Lit_75); A_arbace_reflect_java__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_2, Lit_76); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_reflect_java__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_2, Lit_78); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_reflect_java__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_81).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_82, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_84, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_2, Lit_85); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_reflect_java__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_86)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(125).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_2, Lit_88); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_reflect_java__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_89)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(134).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_42 = lang.RT_ClassForNameNonLoading_String__Class(Lit_92); A_arbace_reflect_java__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_2, Lit_93); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_reflect_java__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(141).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_2, Lit_94); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_reflect_java__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(141).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_81).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_96, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(141).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(141).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_2, Lit_98); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_reflect_java__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_54)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(144).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_2, Lit_100); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_reflect_java__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_89)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(154).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_53 = lang.RT_ClassForNameNonLoading_String__Class(Lit_101); A_arbace_reflect_java__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_2, Lit_102); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_reflect_java__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(161).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_2, Lit_103); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_77).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_reflect_java__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(161).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_104).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_105, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(161).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_106, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(161).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_2, Lit_107); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_reflect_java__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_53)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(164).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_2, Lit_109); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_reflect_java__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_89)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_110, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(172).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_2, Lit_111); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_reflect_java__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(179).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_66 = lang.RT_ClassForNameNonLoading_String__Class(Lit_113); A_arbace_reflect_java__init_A_const_67 = lang.RT_Var_String_String__Var(Lit_2, Lit_114); A_arbace_reflect_java__init_A_const_68 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_115, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(185).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_69 = lang.RT_Var_String_String__Var(Lit_2, Lit_116); A_arbace_reflect_java__init_A_const_70 = lang.RT_ClassForNameNonLoading_String__Class(Lit_117); var tmp61 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(); var tmp62 *jrt.Boolean; jrt.Boolean_Init(); tmp62 = jrt.Boolean_TRUE; var tmp63 any = tmp62.Ref(); A_arbace_reflect_java__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp61, tmp63, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(195).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_2, Lit_118); A_arbace_reflect_java__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(198).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_74 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(198).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_reflect_java__init_A_const_75 = lang.RT_ClassForNameNonLoading_String__Class(Lit_119); A_arbace_reflect_java__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_120); A_arbace_reflect_java__init_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_121); A_arbace_reflect_java__init_A_const_78 = lang.RT_Keyword_String_String__Keyword(nil, Lit_24); A_arbace_reflect_java__init_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_122); A_arbace_reflect_java__init_A_const_80 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_123)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_124, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))))))))); A_arbace_reflect_java__init_A_const_81 = lang.RT_Var_String_String__Var(Lit_0, Lit_126); A_arbace_reflect_java__init_A_const_82 = lang.RT_Var_String_String__Var(Lit_0, Lit_127); A_arbace_reflect_java__init_A_const_83 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_128).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_119).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_129).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_119).Ref())); A_arbace_reflect_java__init_A_const_84 = lang.RT_Keyword_String_String__Keyword(nil, Lit_130); A_arbace_reflect_java__init_A_const_85 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_131).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_123)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_124, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_124)))); A_arbace_reflect_java__init_A_const_86 = lang.RT_Keyword_String_String__Keyword(nil, Lit_132); A_arbace_reflect_java__init_A_const_87 = lang.RT_Keyword_String_String__Keyword(nil, Lit_133); A_arbace_reflect_java__init_A_const_88 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_123).Ref())); A_arbace_reflect_java__init_A_const_89 = lang.RT_Keyword_String_String__Keyword(nil, Lit_134); A_arbace_reflect_java__init_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_135); A_arbace_reflect_java__init_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_136); A_arbace_reflect_java__init_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_137); A_arbace_reflect_java__init_A_const_93 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_123)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_124, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref()))))))); A_arbace_reflect_java__init_A_const_94 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_131).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_123)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_124, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_125).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_32).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_124)); A_arbace_reflect_java__init_A_const_95 = lang.RT_Keyword_String_String__Keyword(nil, Lit_138); A_arbace_reflect_java__init_A_const_96 = lang.RT_Var_String_String__Var(Lit_0, Lit_139); A_arbace_reflect_java__init_A_const_97 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_118).Ref(); A_arbace_reflect_java__init_A_const_98 = lang.RT_ClassForNameNonLoading_String__Class(Lit_140); A_arbace_reflect_java__init_A_const_99 = lang.RT_Keyword_String_String__Keyword(nil, Lit_123); A_arbace_reflect_java__init_A_const_100 = lang.RT_ClassForNameNonLoading_String__Class(Lit_141); A_arbace_reflect_java__init_A_const_101 = lang.RT_ClassForNameNonLoading_String__Class(Lit_142); A_arbace_reflect_java__init_A_const_102 = lang.RT_Var_String_String__Var(Lit_2, Lit_143); A_arbace_reflect_java__init_A_const_103 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_24).Ref(), Lit_145, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(213).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)) }

func A_arbace_reflect_java__init_A_New() *A_arbace_reflect_java__init_A { A_arbace_reflect_java__init_A_Init(); t := &A_arbace_reflect_java__init_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_java__init_A) Ctor() {}

func (t *A_arbace_reflect_java__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_java__init_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_java__init_A_class }

func (t *A_arbace_reflect_java__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_java__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_java__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_java__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_java__init_A); return ok }

func A_arbace_reflect_java__init_A_Cast(x any) *A_arbace_reflect_java__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_java__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_java__init_A_class)) }; return v }
