//line aot_arbace_reflect_java__init.ae:1
package aot_arbace_reflect_java

import (
	"arbace/aot_arbace_reflect"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_reflect_java__init_A_Load__O() any { A_arbace_reflect_java__init_A_Init(); A_arbace_reflect_java__init_A_Unit0__O(); A_arbace_reflect_java__init_A_Unit1__O(); A_arbace_reflect_java__init_A_Unit2__O(); A_arbace_reflect_java__init_A_Unit3__O(); A_arbace_reflect_java__init_A_Unit4__O(); A_arbace_reflect_java__init_A_Unit5__O(); A_arbace_reflect_java__init_A_Unit6__O(); A_arbace_reflect_java__init_A_Unit7__O(); A_arbace_reflect_java__init_A_Unit8__O(); A_arbace_reflect_java__init_A_Unit9__O(); A_arbace_reflect_java__init_A_Unit10__O(); A_arbace_reflect_java__init_A_Unit11__O(); A_arbace_reflect_java__init_A_Unit12__O(); A_arbace_reflect_java__init_A_Unit13__O(); A_arbace_reflect_java__init_A_Unit14__O(); A_arbace_reflect_java__init_A_Unit15__O(); A_arbace_reflect_java__init_A_Unit16__O(); A_arbace_reflect_java__init_A_Unit17__O(); A_arbace_reflect_java__init_A_Unit18__O(); A_arbace_reflect_java__init_A_Unit19__O(); A_arbace_reflect_java__init_A_Unit20__O(); A_arbace_reflect_java__init_A_Unit21__O(); A_arbace_reflect_java__init_A_Unit22__O(); A_arbace_reflect_java__init_A_Unit23__O(); A_arbace_reflect_java__init_A_Unit24__O(); A_arbace_reflect_java__init_A_Unit25__O(); A_arbace_reflect_java__init_A_Unit26__O(); A_arbace_reflect_java__init_A_Unit27__O(); A_arbace_reflect_java__init_A_Unit28__O(); A_arbace_reflect_java__init_A_Unit29__O(); A_arbace_reflect_java__init_A_Unit30__O(); A_arbace_reflect_java__init_A_Unit31__O(); A_arbace_reflect_java__init_A_Unit32__O(); A_arbace_reflect_java__init_A_Unit33__O(); A_arbace_reflect_java__init_A_Unit34__O(); A_arbace_reflect_java__init_A_Unit35__O(); A_arbace_reflect_java__init_A_Unit36__O(); return nil }




func A_arbace_reflect_java__init_A_Unit0__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(10, 1); return lang.IFn_Cast(A_arbace_reflect_java__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_java__init_A_const_1) }

func A_arbace_reflect_java__init_A_Unit1__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); return lang.IFn_Cast(A_arbace_reflect_java__init_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_reflect_java__init_A_const_3, A_arbace_reflect_java__init_A_const_4, A_arbace_reflect_java__init_A_const_5) }


func A_arbace_reflect_java__init_A_Unit2__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1)); return nil }
//line :15:1
func A_arbace_reflect_java__init_A_Unit3__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_2)); return nil }


func A_arbace_reflect_java__init_A_Unit4__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_6; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return tmp1.Set_O__O(tmp2.Ref()) }

func A_arbace_reflect_java__init_A_Unit5__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_8; var tmp3 any = A_arbace_reflect_java__init_A_const_9.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_10; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000010_fn__1938000011_A_New(); var tmp6 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000010_fn__1938000011_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); aot_arbace_reflect.A_arbace_reflect_eval1938000010_fn__1938000011_A_fn_class = fncls__1d; tmp6 = fncls__1d } else { tmp6 = fncls__1 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :20:1
func A_arbace_reflect_java__init_A_Unit6__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_11; var tmp3 any = A_arbace_reflect_java__init_A_const_9.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_10; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000014_fn__1938000015_A_New(); var tmp6 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000014_fn__1938000015_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); aot_arbace_reflect.A_arbace_reflect_eval1938000014_fn__1938000015_A_fn_class = fncls__2d; tmp6 = fncls__2d } else { tmp6 = fncls__2 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }












func A_arbace_reflect_java__init_A_Unit7__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_12; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_typesym_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_typesym_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); aot_arbace_reflect.A_arbace_reflect_typesym_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_13)); return A_arbace_reflect_java__init_A_const_12 }










func A_arbace_reflect_java__init_A_Unit8__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_14; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_resource_name_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_resource_name_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); aot_arbace_reflect.A_arbace_reflect_resource_name_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_15)); return A_arbace_reflect_java__init_A_const_14 }







func A_arbace_reflect_java__init_A_Unit9__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(52, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_16; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_access_flag_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_access_flag_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); aot_arbace_reflect.A_arbace_reflect_access_flag_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_17)); return A_arbace_reflect_java__init_A_const_16 }



func A_arbace_reflect_java__init_A_Unit10__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(56, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_18; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_19)); return A_arbace_reflect_java__init_A_const_18 }








func A_arbace_reflect_java__init_A_Unit11__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(65, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_20; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_21)); return A_arbace_reflect_java__init_A_const_20 }







func A_arbace_reflect_java__init_A_Unit12__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(73, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_22; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_23)); return A_arbace_reflect_java__init_A_const_22 }










func A_arbace_reflect_java__init_A_Unit13__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(84, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_24; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_reflect_java__init_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_java__init_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_java__init_A_const_16.GetRawRoot__O(), A_arbace_reflect_java__init_A_const_28))); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_24; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_26)); return A_arbace_reflect_java__init_A_const_24 }

























func A_arbace_reflect_java__init_A_Unit14__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(110, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_29; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_parse_flags_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_parse_flags_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); aot_arbace_reflect.A_arbace_reflect_parse_flags_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_30)); return A_arbace_reflect_java__init_A_const_29 }











func A_arbace_reflect_java__init_A_Unit15__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_33)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_34; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_35)); var tmp3 *lang.Var; lang.RT_Init(); tmp3 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp3).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_12)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_36)); var tmp5 *lang.Var = A_arbace_reflect_java__init_A_const_32; var tmp6 any = aot_arbace_reflect.A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_New(); var tmp7 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); aot_arbace_reflect.A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_fn_class = fncls__10d; tmp7 = fncls__10d } else { tmp7 = fncls__10 }; tmp5.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_34; tmp8.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_37)); var tmp9 *lang.Var = A_arbace_reflect_java__init_A_const_34; var tmp10 any = aot_arbace_reflect.A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_New(); var tmp11 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); aot_arbace_reflect.A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_fn_class = fncls__11d; tmp11 = fncls__11d } else { tmp11 = fncls__11 }; tmp9.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)); return A_arbace_reflect_java__init_A_const_31 }


func A_arbace_reflect_java__init_A_Unit16__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(125, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_38; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_39)); return A_arbace_reflect_java__init_A_const_38 }








func A_arbace_reflect_java__init_A_Unit17__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(134, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_40; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_41)); return A_arbace_reflect_java__init_A_const_40 }






func A_arbace_reflect_java__init_A_Unit18__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(141, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_44)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_45; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_46)); var tmp3 *lang.Var; lang.RT_Init(); tmp3 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp3).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_17)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_47)); var tmp5 *lang.Var = A_arbace_reflect_java__init_A_const_43; var tmp6 any = aot_arbace_reflect.A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_New(); var tmp7 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); aot_arbace_reflect.A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_fn_class = fncls__14d; tmp7 = fncls__14d } else { tmp7 = fncls__14 }; tmp5.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_45; tmp8.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_48)); var tmp9 *lang.Var = A_arbace_reflect_java__init_A_const_45; var tmp10 any = aot_arbace_reflect.A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_New(); var tmp11 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); aot_arbace_reflect.A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_fn_class = fncls__15d; tmp11 = fncls__15d } else { tmp11 = fncls__15 }; tmp9.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)); return A_arbace_reflect_java__init_A_const_42 }


func A_arbace_reflect_java__init_A_Unit19__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(144, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_49; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_50)); return A_arbace_reflect_java__init_A_const_49 }









func A_arbace_reflect_java__init_A_Unit20__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_51; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_declared_methods_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_declared_methods_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); aot_arbace_reflect.A_arbace_reflect_declared_methods_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_52)); return A_arbace_reflect_java__init_A_const_51 }






func A_arbace_reflect_java__init_A_Unit21__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_55)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_56; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_57)); var tmp3 *lang.Var; lang.RT_Init(); tmp3 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp3).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_22)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_58)); var tmp5 *lang.Var = A_arbace_reflect_java__init_A_const_54; var tmp6 any = aot_arbace_reflect.A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_New(); var tmp7 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); aot_arbace_reflect.A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_fn_class = fncls__18d; tmp7 = fncls__18d } else { tmp7 = fncls__18 }; tmp5.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_56; tmp8.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_59)); var tmp9 *lang.Var = A_arbace_reflect_java__init_A_const_56; var tmp10 any = aot_arbace_reflect.A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_New(); var tmp11 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); aot_arbace_reflect.A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_fn_class = fncls__19d; tmp11 = fncls__19d } else { tmp11 = fncls__19 }; tmp9.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)); return A_arbace_reflect_java__init_A_const_53 }


func A_arbace_reflect_java__init_A_Unit22__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(164, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_60; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_61)); return A_arbace_reflect_java__init_A_const_60 }







func A_arbace_reflect_java__init_A_Unit23__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_62; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_declared_fields_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_declared_fields_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); aot_arbace_reflect.A_arbace_reflect_declared_fields_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_63)); return A_arbace_reflect_java__init_A_const_62 }






func A_arbace_reflect_java__init_A_Unit24__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(179, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_64; var tmp2 any = aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_65)); return A_arbace_reflect_java__init_A_const_64 }





func A_arbace_reflect_java__init_A_Unit25__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(185, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_28)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_67; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_68)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_67; var tmp4 any = aot_arbace_reflect.A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_New(); var tmp5 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); aot_arbace_reflect.A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_fn_class = fncls__23d; tmp5 = fncls__23d } else { tmp5 = fncls__23 }; tmp3.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_reflect_java__init_A_const_66 }









func A_arbace_reflect_java__init_A_Unit26__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(195, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_69; var tmp2 any = jrt.Thread_CurrentThread__Thread(); var tmp3 *jrt.Class = A_arbace_reflect_java__init_A_const_70; tmp1.BindRoot_O__V(aot_arbace_reflect.A_arbace_reflect_JavaReflector_A_New_O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp2, tmp3, Lit_30, jrt.RefArrayOf(jrt.Object_class)))); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_71)); return A_arbace_reflect_java__init_A_const_69 }


func A_arbace_reflect_java__init_A_Unit27__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_73)); v__1927001498__auto____1 = A_arbace_reflect_java__init_A_const_72; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_72; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_74)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_72; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_reflect_java__init_A_const_72 } }
//line :198:1
func A_arbace_reflect_java__init_A_Unit28__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); return A_arbace_reflect_java__init_A_const_75 }
//line :198:1
func A_arbace_reflect_java__init_A_Unit29__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_76.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_72; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_reflect_java__init_A_const_77.GetRawRoot__O(), A_arbace_reflect_java__init_A_const_78, nil) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit30__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); return A_arbace_reflect_java__init_A_const_79.Invoke_O_O__O(A_arbace_reflect_java__init_A_const_72, A_arbace_reflect_java__init_A_const_80) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit31__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_72; var tmp3 any = A_arbace_reflect_java__init_A_const_82.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_77.GetRawRoot__O()); var tmp5 any = A_arbace_reflect_java__init_A_const_83; var tmp6 any = A_arbace_reflect_java__init_A_const_84; var tmp7 any = A_arbace_reflect_java__init_A_const_85; var tmp8 any = A_arbace_reflect_java__init_A_const_86; var tmp9 any = A_arbace_reflect_java__init_A_const_72; var tmp10 any = A_arbace_reflect_java__init_A_const_87; var tmp11 any = A_arbace_reflect_java__init_A_const_88; var tmp12 any = A_arbace_reflect_java__init_A_const_89; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_92.GetRawRoot__O()); var tmp14 any = A_arbace_reflect_java__init_A_const_93; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_82.GetRawRoot__O()); var tmp16 any = A_arbace_reflect_java__init_A_const_94; var tmp17 any = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_90.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_java__init_A_const_91.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect_java__init_A_const_95, A_arbace_reflect_java__init_A_const_72))))); var tmp18 any = aot_arbace_reflect.A_arbace_reflect_eval1938000121_fn__1938000122_A_New(); var tmp19 *jrt.Class; var fncls__24 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000121_fn__1938000122_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); aot_arbace_reflect.A_arbace_reflect_eval1938000121_fn__1938000122_A_fn_class = fncls__24d; tmp19 = fncls__24d } else { tmp19 = fncls__24 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit32__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); return lang.IFn_Cast(A_arbace_reflect_java__init_A_const_96.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_java__init_A_const_72.GetRawRoot__O()) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit33__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(198, 1); return A_arbace_reflect_java__init_A_const_97 }



func A_arbace_reflect_java__init_A_Unit34__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_98; var tmp3 any = A_arbace_reflect_java__init_A_const_72.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_99; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000137_fn__1938000138_A_New(); var tmp6 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000137_fn__1938000138_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); aot_arbace_reflect.A_arbace_reflect_eval1938000137_fn__1938000138_A_fn_class = fncls__25d; tmp6 = fncls__25d } else { tmp6 = fncls__25 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :202:1
func A_arbace_reflect_java__init_A_Unit35__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_100; var tmp3 any = A_arbace_reflect_java__init_A_const_72.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_99; var tmp5 any = aot_arbace_reflect.A_arbace_reflect_eval1938000141_fn__1938000142_A_New(); var tmp6 *jrt.Class; var fncls__26 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000141_fn__1938000142_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); aot_arbace_reflect.A_arbace_reflect_eval1938000141_fn__1938000142_A_fn_class = fncls__26d; tmp6 = fncls__26d } else { tmp6 = fncls__26 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }










func A_arbace_reflect_java__init_A_Unit36__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V(213, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_34)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_102; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_103)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_102; var tmp4 any = aot_arbace_reflect.A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_New(); var tmp5 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); aot_arbace_reflect.A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_fn_class = fncls__27d; tmp5 = fncls__27d } else { tmp5 = fncls__27 }; tmp3.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_reflect_java__init_A_const_101 }






type A_arbace_reflect_java__init_A struct{ jrt.Object }

var A_arbace_reflect_java__init_A_const_pool *jrt.RefArray

var A_arbace_reflect_java__init_A_const_0 *lang.Var

var A_arbace_reflect_java__init_A_const_1 any

var A_arbace_reflect_java__init_A_const_2 *lang.Var

var A_arbace_reflect_java__init_A_const_3 any

var A_arbace_reflect_java__init_A_const_4 any

var A_arbace_reflect_java__init_A_const_5 any

var A_arbace_reflect_java__init_A_const_6 *lang.Var

var A_arbace_reflect_java__init_A_const_7 *lang.Var

var A_arbace_reflect_java__init_A_const_8 *jrt.Class

var A_arbace_reflect_java__init_A_const_9 *lang.Var

var A_arbace_reflect_java__init_A_const_10 *lang.Keyword

var A_arbace_reflect_java__init_A_const_11 *jrt.Class

var A_arbace_reflect_java__init_A_const_12 *lang.Var

var A_arbace_reflect_java__init_A_const_13 any

var A_arbace_reflect_java__init_A_const_14 *lang.Var

var A_arbace_reflect_java__init_A_const_15 any

var A_arbace_reflect_java__init_A_const_16 *lang.Var

var A_arbace_reflect_java__init_A_const_17 any

var A_arbace_reflect_java__init_A_const_18 *lang.Var

var A_arbace_reflect_java__init_A_const_19 any

var A_arbace_reflect_java__init_A_const_20 *lang.Var

var A_arbace_reflect_java__init_A_const_21 any

var A_arbace_reflect_java__init_A_const_22 *lang.Var

var A_arbace_reflect_java__init_A_const_23 any

var A_arbace_reflect_java__init_A_const_24 *lang.Var

var A_arbace_reflect_java__init_A_const_25 *lang.Var

var A_arbace_reflect_java__init_A_const_26 any

var A_arbace_reflect_java__init_A_const_27 *lang.Var

var A_arbace_reflect_java__init_A_const_28 any

var A_arbace_reflect_java__init_A_const_29 *lang.Var

var A_arbace_reflect_java__init_A_const_30 any

var A_arbace_reflect_java__init_A_const_31 *jrt.Class

var A_arbace_reflect_java__init_A_const_32 *lang.Var

var A_arbace_reflect_java__init_A_const_33 any

var A_arbace_reflect_java__init_A_const_34 *lang.Var

var A_arbace_reflect_java__init_A_const_35 any

var A_arbace_reflect_java__init_A_const_36 any

var A_arbace_reflect_java__init_A_const_37 any

var A_arbace_reflect_java__init_A_const_38 *lang.Var

var A_arbace_reflect_java__init_A_const_39 any

var A_arbace_reflect_java__init_A_const_40 *lang.Var

var A_arbace_reflect_java__init_A_const_41 any

var A_arbace_reflect_java__init_A_const_42 *jrt.Class

var A_arbace_reflect_java__init_A_const_43 *lang.Var

var A_arbace_reflect_java__init_A_const_44 any

var A_arbace_reflect_java__init_A_const_45 *lang.Var

var A_arbace_reflect_java__init_A_const_46 any

var A_arbace_reflect_java__init_A_const_47 any

var A_arbace_reflect_java__init_A_const_48 any

var A_arbace_reflect_java__init_A_const_49 *lang.Var

var A_arbace_reflect_java__init_A_const_50 any

var A_arbace_reflect_java__init_A_const_51 *lang.Var

var A_arbace_reflect_java__init_A_const_52 any

var A_arbace_reflect_java__init_A_const_53 *jrt.Class

var A_arbace_reflect_java__init_A_const_54 *lang.Var

var A_arbace_reflect_java__init_A_const_55 any

var A_arbace_reflect_java__init_A_const_56 *lang.Var

var A_arbace_reflect_java__init_A_const_57 any

var A_arbace_reflect_java__init_A_const_58 any

var A_arbace_reflect_java__init_A_const_59 any

var A_arbace_reflect_java__init_A_const_60 *lang.Var

var A_arbace_reflect_java__init_A_const_61 any

var A_arbace_reflect_java__init_A_const_62 *lang.Var

var A_arbace_reflect_java__init_A_const_63 any

var A_arbace_reflect_java__init_A_const_64 *lang.Var

var A_arbace_reflect_java__init_A_const_65 any

var A_arbace_reflect_java__init_A_const_66 *jrt.Class

var A_arbace_reflect_java__init_A_const_67 *lang.Var

var A_arbace_reflect_java__init_A_const_68 any

var A_arbace_reflect_java__init_A_const_69 *lang.Var

var A_arbace_reflect_java__init_A_const_70 *jrt.Class

var A_arbace_reflect_java__init_A_const_71 any

var A_arbace_reflect_java__init_A_const_72 *lang.Var

var A_arbace_reflect_java__init_A_const_73 any

var A_arbace_reflect_java__init_A_const_74 any

var A_arbace_reflect_java__init_A_const_75 *jrt.Class

var A_arbace_reflect_java__init_A_const_76 *lang.Var

var A_arbace_reflect_java__init_A_const_77 *lang.Var

var A_arbace_reflect_java__init_A_const_78 *lang.Keyword

var A_arbace_reflect_java__init_A_const_79 *lang.Var

var A_arbace_reflect_java__init_A_const_80 any

var A_arbace_reflect_java__init_A_const_81 *lang.Var

var A_arbace_reflect_java__init_A_const_82 *lang.Var

var A_arbace_reflect_java__init_A_const_83 any

var A_arbace_reflect_java__init_A_const_84 *lang.Keyword

var A_arbace_reflect_java__init_A_const_85 any

var A_arbace_reflect_java__init_A_const_86 *lang.Keyword

var A_arbace_reflect_java__init_A_const_87 *lang.Keyword

var A_arbace_reflect_java__init_A_const_88 any

var A_arbace_reflect_java__init_A_const_89 *lang.Keyword

var A_arbace_reflect_java__init_A_const_90 *lang.Var

var A_arbace_reflect_java__init_A_const_91 *lang.Var

var A_arbace_reflect_java__init_A_const_92 *lang.Var

var A_arbace_reflect_java__init_A_const_93 any

var A_arbace_reflect_java__init_A_const_94 any

var A_arbace_reflect_java__init_A_const_95 *lang.Keyword

var A_arbace_reflect_java__init_A_const_96 *lang.Var

var A_arbace_reflect_java__init_A_const_97 any

var A_arbace_reflect_java__init_A_const_98 *jrt.Class

var A_arbace_reflect_java__init_A_const_99 *lang.Keyword

var A_arbace_reflect_java__init_A_const_100 *jrt.Class

var A_arbace_reflect_java__init_A_const_101 *jrt.Class

var A_arbace_reflect_java__init_A_const_102 *lang.Var

var A_arbace_reflect_java__init_A_const_103 any

var A_arbace_reflect_java__init_A_init jrt.ClassInit

func A_arbace_reflect_java__init_A_Init() { if !A_arbace_reflect_java__init_A_init.Done() { A_arbace_reflect_java__init_A_init.Run(A_arbace_reflect_java__init_A_clinit) } }

func A_arbace_reflect_java__init_A_clinit() { A_arbace_reflect_java__init_A_clinit_p0(); A_arbace_reflect_java__init_A_clinit_p1(); A_arbace_reflect_java__init_A_clinit_p2(); A_arbace_reflect_java__init_A_clinit_p3(); A_arbace_reflect_java__init_A_clinit_p4(); A_arbace_reflect_java__init_A_clinit_p5(); A_arbace_reflect_java__init_A_clinit_p6(); A_arbace_reflect_java__init_A_clinit_p7(); A_arbace_reflect_java__init_A_clinit_p8() }

func A_arbace_reflect_java__init_A_clinit_p0() { A_arbace_reflect_java__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 180); A_arbace_reflect_java__init_A_const_0 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[76]); A_arbace_reflect_java__init_A_const_1 = A_arbace_reflect_java__init_A_const_pool.A[77]; A_arbace_reflect_java__init_A_const_2 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[78]); A_arbace_reflect_java__init_A_const_3 = A_arbace_reflect_java__init_A_const_pool.A[79]; A_arbace_reflect_java__init_A_const_4 = A_arbace_reflect_java__init_A_const_pool.A[80]; A_arbace_reflect_java__init_A_const_5 = A_arbace_reflect_java__init_A_const_pool.A[81]; A_arbace_reflect_java__init_A_const_6 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[82]); A_arbace_reflect_java__init_A_const_7 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[83]); A_arbace_reflect_java__init_A_const_8 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[84]); A_arbace_reflect_java__init_A_const_9 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[85]); A_arbace_reflect_java__init_A_const_10 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[86]); A_arbace_reflect_java__init_A_const_11 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[87]) }

func A_arbace_reflect_java__init_A_clinit_p1() { A_arbace_reflect_java__init_A_const_12 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[88]); A_arbace_reflect_java__init_A_const_13 = A_arbace_reflect_java__init_A_const_pool.A[89]; A_arbace_reflect_java__init_A_const_14 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[90]); A_arbace_reflect_java__init_A_const_15 = A_arbace_reflect_java__init_A_const_pool.A[91]; A_arbace_reflect_java__init_A_const_16 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[92]); A_arbace_reflect_java__init_A_const_17 = A_arbace_reflect_java__init_A_const_pool.A[93]; A_arbace_reflect_java__init_A_const_18 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[94]); A_arbace_reflect_java__init_A_const_19 = A_arbace_reflect_java__init_A_const_pool.A[95]; A_arbace_reflect_java__init_A_const_20 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[96]); A_arbace_reflect_java__init_A_const_21 = A_arbace_reflect_java__init_A_const_pool.A[97]; A_arbace_reflect_java__init_A_const_22 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[98]); A_arbace_reflect_java__init_A_const_23 = A_arbace_reflect_java__init_A_const_pool.A[99]; A_arbace_reflect_java__init_A_const_24 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[100]) }

func A_arbace_reflect_java__init_A_clinit_p2() { A_arbace_reflect_java__init_A_const_25 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[101]); A_arbace_reflect_java__init_A_const_26 = A_arbace_reflect_java__init_A_const_pool.A[102]; A_arbace_reflect_java__init_A_const_27 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[103]); A_arbace_reflect_java__init_A_const_28 = A_arbace_reflect_java__init_A_const_pool.A[104]; A_arbace_reflect_java__init_A_const_29 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[105]); A_arbace_reflect_java__init_A_const_30 = A_arbace_reflect_java__init_A_const_pool.A[106]; A_arbace_reflect_java__init_A_const_31 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[107]); A_arbace_reflect_java__init_A_const_32 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[108]); A_arbace_reflect_java__init_A_const_33 = A_arbace_reflect_java__init_A_const_pool.A[109]; A_arbace_reflect_java__init_A_const_34 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[110]); A_arbace_reflect_java__init_A_const_35 = A_arbace_reflect_java__init_A_const_pool.A[111]; A_arbace_reflect_java__init_A_const_36 = A_arbace_reflect_java__init_A_const_pool.A[112]; A_arbace_reflect_java__init_A_const_37 = A_arbace_reflect_java__init_A_const_pool.A[113] }

func A_arbace_reflect_java__init_A_clinit_p3() { A_arbace_reflect_java__init_A_const_38 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[114]); A_arbace_reflect_java__init_A_const_39 = A_arbace_reflect_java__init_A_const_pool.A[115]; A_arbace_reflect_java__init_A_const_40 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[116]); A_arbace_reflect_java__init_A_const_41 = A_arbace_reflect_java__init_A_const_pool.A[117]; A_arbace_reflect_java__init_A_const_42 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[118]); A_arbace_reflect_java__init_A_const_43 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[119]); A_arbace_reflect_java__init_A_const_44 = A_arbace_reflect_java__init_A_const_pool.A[120]; A_arbace_reflect_java__init_A_const_45 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[121]); A_arbace_reflect_java__init_A_const_46 = A_arbace_reflect_java__init_A_const_pool.A[122]; A_arbace_reflect_java__init_A_const_47 = A_arbace_reflect_java__init_A_const_pool.A[123]; A_arbace_reflect_java__init_A_const_48 = A_arbace_reflect_java__init_A_const_pool.A[124]; A_arbace_reflect_java__init_A_const_49 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[125]); A_arbace_reflect_java__init_A_const_50 = A_arbace_reflect_java__init_A_const_pool.A[126] }

func A_arbace_reflect_java__init_A_clinit_p4() { A_arbace_reflect_java__init_A_const_51 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[127]); A_arbace_reflect_java__init_A_const_52 = A_arbace_reflect_java__init_A_const_pool.A[128]; A_arbace_reflect_java__init_A_const_53 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[129]); A_arbace_reflect_java__init_A_const_54 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[130]); A_arbace_reflect_java__init_A_const_55 = A_arbace_reflect_java__init_A_const_pool.A[131]; A_arbace_reflect_java__init_A_const_56 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[132]); A_arbace_reflect_java__init_A_const_57 = A_arbace_reflect_java__init_A_const_pool.A[133]; A_arbace_reflect_java__init_A_const_58 = A_arbace_reflect_java__init_A_const_pool.A[134]; A_arbace_reflect_java__init_A_const_59 = A_arbace_reflect_java__init_A_const_pool.A[135]; A_arbace_reflect_java__init_A_const_60 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[136]); A_arbace_reflect_java__init_A_const_61 = A_arbace_reflect_java__init_A_const_pool.A[137]; A_arbace_reflect_java__init_A_const_62 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[138]); A_arbace_reflect_java__init_A_const_63 = A_arbace_reflect_java__init_A_const_pool.A[139] }

func A_arbace_reflect_java__init_A_clinit_p5() { A_arbace_reflect_java__init_A_const_64 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[140]); A_arbace_reflect_java__init_A_const_65 = A_arbace_reflect_java__init_A_const_pool.A[141]; A_arbace_reflect_java__init_A_const_66 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[142]); A_arbace_reflect_java__init_A_const_67 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[143]); A_arbace_reflect_java__init_A_const_68 = A_arbace_reflect_java__init_A_const_pool.A[144]; A_arbace_reflect_java__init_A_const_69 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[145]); A_arbace_reflect_java__init_A_const_70 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[146]); A_arbace_reflect_java__init_A_const_71 = A_arbace_reflect_java__init_A_const_pool.A[147]; A_arbace_reflect_java__init_A_const_72 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[148]); A_arbace_reflect_java__init_A_const_73 = A_arbace_reflect_java__init_A_const_pool.A[149]; A_arbace_reflect_java__init_A_const_74 = A_arbace_reflect_java__init_A_const_pool.A[150]; A_arbace_reflect_java__init_A_const_75 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[151]); A_arbace_reflect_java__init_A_const_76 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[152]) }

func A_arbace_reflect_java__init_A_clinit_p6() { A_arbace_reflect_java__init_A_const_77 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[153]); A_arbace_reflect_java__init_A_const_78 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[154]); A_arbace_reflect_java__init_A_const_79 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[155]); A_arbace_reflect_java__init_A_const_80 = A_arbace_reflect_java__init_A_const_pool.A[156]; A_arbace_reflect_java__init_A_const_81 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[157]); A_arbace_reflect_java__init_A_const_82 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[158]); A_arbace_reflect_java__init_A_const_83 = A_arbace_reflect_java__init_A_const_pool.A[159]; A_arbace_reflect_java__init_A_const_84 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[160]); A_arbace_reflect_java__init_A_const_85 = A_arbace_reflect_java__init_A_const_pool.A[161]; A_arbace_reflect_java__init_A_const_86 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[162]); A_arbace_reflect_java__init_A_const_87 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[163]); A_arbace_reflect_java__init_A_const_88 = A_arbace_reflect_java__init_A_const_pool.A[164]; A_arbace_reflect_java__init_A_const_89 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[165]) }

func A_arbace_reflect_java__init_A_clinit_p7() { A_arbace_reflect_java__init_A_const_90 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[166]); A_arbace_reflect_java__init_A_const_91 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[167]); A_arbace_reflect_java__init_A_const_92 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[168]); A_arbace_reflect_java__init_A_const_93 = A_arbace_reflect_java__init_A_const_pool.A[169]; A_arbace_reflect_java__init_A_const_94 = A_arbace_reflect_java__init_A_const_pool.A[170]; A_arbace_reflect_java__init_A_const_95 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[171]); A_arbace_reflect_java__init_A_const_96 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[172]); A_arbace_reflect_java__init_A_const_97 = A_arbace_reflect_java__init_A_const_pool.A[173]; A_arbace_reflect_java__init_A_const_98 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[174]); A_arbace_reflect_java__init_A_const_99 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[175]); A_arbace_reflect_java__init_A_const_100 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[176]); A_arbace_reflect_java__init_A_const_101 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[177]) }

func A_arbace_reflect_java__init_A_clinit_p8() { A_arbace_reflect_java__init_A_const_102 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[178]); A_arbace_reflect_java__init_A_const_103 = A_arbace_reflect_java__init_A_const_pool.A[179] }

func A_arbace_reflect_java__init_A_New() *A_arbace_reflect_java__init_A { A_arbace_reflect_java__init_A_Init(); t := &A_arbace_reflect_java__init_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_java__init_A) Ctor() {}

func (t *A_arbace_reflect_java__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_java__init_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_java__init_A_class }

func (t *A_arbace_reflect_java__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_java__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_java__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_java__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_java__init_A); return ok }

func A_arbace_reflect_java__init_A_Cast(x any) *A_arbace_reflect_java__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_java__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_java__init_A_class)) }; return v }
