//line aot_arbace_reflect_java__init.ae:1
package aot_arbace_reflect_java

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_reflect"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_reflect_java__init_A_Load__O() any { A_arbace_reflect_java__init_A_Init(); jrt.StartCheck(); A_arbace_reflect_java__init_A_Unit0__O(); A_arbace_reflect_java__init_A_Unit1__O(); A_arbace_reflect_java__init_A_Unit2__O(); A_arbace_reflect_java__init_A_Unit3__O(); A_arbace_reflect_java__init_A_Unit4__O(); A_arbace_reflect_java__init_A_Unit5__O(); A_arbace_reflect_java__init_A_Unit6__O(); A_arbace_reflect_java__init_A_Unit7__O(); A_arbace_reflect_java__init_A_Unit8__O(); A_arbace_reflect_java__init_A_Unit9__O(); A_arbace_reflect_java__init_A_Unit10__O(); A_arbace_reflect_java__init_A_Unit11__O(); A_arbace_reflect_java__init_A_Unit12__O(); A_arbace_reflect_java__init_A_Unit13__O(); A_arbace_reflect_java__init_A_Unit14__O(); A_arbace_reflect_java__init_A_Unit15__O(); A_arbace_reflect_java__init_A_Unit16__O(); A_arbace_reflect_java__init_A_Unit17__O(); A_arbace_reflect_java__init_A_Unit18__O(); A_arbace_reflect_java__init_A_Unit19__O(); A_arbace_reflect_java__init_A_Unit20__O(); A_arbace_reflect_java__init_A_Unit21__O(); A_arbace_reflect_java__init_A_Unit22__O(); A_arbace_reflect_java__init_A_Unit23__O(); A_arbace_reflect_java__init_A_Unit24__O(); A_arbace_reflect_java__init_A_Unit25__O(); A_arbace_reflect_java__init_A_Unit26__O(); A_arbace_reflect_java__init_A_Unit27__O(); A_arbace_reflect_java__init_A_Unit28__O(); A_arbace_reflect_java__init_A_Unit29__O(); A_arbace_reflect_java__init_A_Unit30__O(); A_arbace_reflect_java__init_A_Unit31__O(); A_arbace_reflect_java__init_A_Unit32__O(); A_arbace_reflect_java__init_A_Unit33__O(); A_arbace_reflect_java__init_A_Unit34__O(); A_arbace_reflect_java__init_A_Unit35__O(); A_arbace_reflect_java__init_A_Unit36__O(); return nil }




func A_arbace_reflect_java__init_A_Unit0__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(10, 1); return lang.IFn_Cast(A_arbace_reflect_java__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_java__init_A_const_1) }

func A_arbace_reflect_java__init_A_Unit1__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(12, 1); return lang.IFn_Cast(A_arbace_reflect_java__init_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_reflect_java__init_A_const_3, A_arbace_reflect_java__init_A_const_4, A_arbace_reflect_java__init_A_const_5) }


func A_arbace_reflect_java__init_A_Unit2__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }
//line :15:1
func A_arbace_reflect_java__init_A_Unit3__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)).Ref() }


func A_arbace_reflect_java__init_A_Unit4__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); return A_arbace_reflect_java__init_A_const_6.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_reflect_java__init_A_Unit5__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_8; var tmp3 any = A_arbace_reflect_java__init_A_const_9.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_10; var tmp5 *lang.Compiler_AOTFn; var fnbody__14 any = aot_arbace_reflect.A_arbace_reflect_eval1939000010_fn__1939000011_A_New(); var tmp6 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000010_fn__1939000011_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000010_fn__1939000011_A_fn_class = fncls__13d; tmp6 = fncls__13d } else { tmp6 = fncls__13 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :20:1
func A_arbace_reflect_java__init_A_Unit6__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_11; var tmp3 any = A_arbace_reflect_java__init_A_const_9.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_10; var tmp5 *lang.Compiler_AOTFn; var fnbody__22 any = aot_arbace_reflect.A_arbace_reflect_eval1939000014_fn__1939000015_A_New(); var tmp6 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000014_fn__1939000015_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000014_fn__1939000015_A_fn_class = fncls__21d; tmp6 = fncls__21d } else { tmp6 = fncls__21 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }












func A_arbace_reflect_java__init_A_Unit7__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = aot_arbace_reflect.A_arbace_reflect_typesym_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_typesym_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); aot_arbace_reflect.A_arbace_reflect_typesym_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_13)); return A_arbace_reflect_java__init_A_const_12 }










func A_arbace_reflect_java__init_A_Unit8__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = aot_arbace_reflect.A_arbace_reflect_resource_name_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_resource_name_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); aot_arbace_reflect.A_arbace_reflect_resource_name_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_15)); return A_arbace_reflect_java__init_A_const_14 }







func A_arbace_reflect_java__init_A_Unit9__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = aot_arbace_reflect.A_arbace_reflect_access_flag_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_access_flag_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, nil); aot_arbace_reflect.A_arbace_reflect_access_flag_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_17)); return A_arbace_reflect_java__init_A_const_16 }



func A_arbace_reflect_java__init_A_Unit10__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); aot_arbace_reflect.A_arbace_reflect_descriptor_class_name_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_19)); return A_arbace_reflect_java__init_A_const_18 }








func A_arbace_reflect_java__init_A_Unit11__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); aot_arbace_reflect.A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_21)); return A_arbace_reflect_java__init_A_const_20 }







func A_arbace_reflect_java__init_A_Unit12__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); aot_arbace_reflect.A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_23)); return A_arbace_reflect_java__init_A_const_22 }










func A_arbace_reflect_java__init_A_Unit13__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_24; var tmp2 any; var root_35 any = A_arbace_reflect_java__init_A_const_25.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_37 lang.IFn; if


	linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any; var root_39 any = A_arbace_reflect_java__init_A_const_26.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_41 lang.IFn; if
	linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = A_arbace_reflect_java__init_A_const_16.GetRawRoot__O(); var arg_43 any = A_arbace_reflect_java__init_A_const_27; if linked_40 == nil { arg_38 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_38 = linked_40.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; if /*line :87:1*/ linked_36 == nil { tmp2 = ifn_37.Invoke_O__O(arg_38) } else { tmp2 = linked_36.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_35, arg_38) }; /*line :84:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_24; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_28)); return A_arbace_reflect_java__init_A_const_24 }

























func A_arbace_reflect_java__init_A_Unit14__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__45 any = aot_arbace_reflect.A_arbace_reflect_parse_flags_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_parse_flags_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, nil); aot_arbace_reflect.A_arbace_reflect_parse_flags_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__45, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_30)); return A_arbace_reflect_java__init_A_const_29 }











func A_arbace_reflect_java__init_A_Unit15__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_33)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_34; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_35)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_32; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_36)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_32; var tmp5 *lang.Compiler_AOTFn; var fnbody__47 any = aot_arbace_reflect.A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A_New(); var tmp6 *jrt.Class; var fncls__46 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000036___GT_Constructor__1939000052_A_fn_class = fncls__46d; tmp6 = fncls__46d } else { tmp6 = fncls__46 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__47, tmp6, nil); tmp4.BindRoot_O__V(tmp5.Ref()); var tmp7 *lang.Var = A_arbace_reflect_java__init_A_const_34; tmp7.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_37)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_34; var tmp9 *lang.Compiler_AOTFn; var fnbody__49 any = aot_arbace_reflect.A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A_New(); var tmp10 *jrt.Class; var fncls__48 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000036_map__GT_Constructor__1939000054_A_fn_class = fncls__48d; tmp10 = fncls__48d } else { tmp10 = fncls__48 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__49, tmp10, nil); tmp8.BindRoot_O__V(tmp9.Ref()); return A_arbace_reflect_java__init_A_const_31 }


func A_arbace_reflect_java__init_A_Unit16__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__51 any = aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); aot_arbace_reflect.A_arbace_reflect_constructor__GT_map_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__51, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_39)); return A_arbace_reflect_java__init_A_const_38 }








func A_arbace_reflect_java__init_A_Unit17__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__53 any = aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); aot_arbace_reflect.A_arbace_reflect_declared_constructors_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__53, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_41)); return A_arbace_reflect_java__init_A_const_40 }






func A_arbace_reflect_java__init_A_Unit18__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_44)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_45; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_46)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_43; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_47)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_43; var tmp5 *lang.Compiler_AOTFn; var fnbody__55 any = aot_arbace_reflect.A_arbace_reflect_eval1939000060___GT_Method__1939000078_A_New(); var tmp6 *jrt.Class; var fncls__54 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000060___GT_Method__1939000078_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000060___GT_Method__1939000078_A_fn_class = fncls__54d; tmp6 = fncls__54d } else { tmp6 = fncls__54 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__55, tmp6, nil); tmp4.BindRoot_O__V(tmp5.Ref()); var tmp7 *lang.Var = A_arbace_reflect_java__init_A_const_45; tmp7.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_48)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_45; var tmp9 *lang.Compiler_AOTFn; var fnbody__57 any = aot_arbace_reflect.A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A_New(); var tmp10 *jrt.Class; var fncls__56 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000060_map__GT_Method__1939000080_A_fn_class = fncls__56d; tmp10 = fncls__56d } else { tmp10 = fncls__56 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__57, tmp10, nil); tmp8.BindRoot_O__V(tmp9.Ref()); return A_arbace_reflect_java__init_A_const_42 }


func A_arbace_reflect_java__init_A_Unit19__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__59 any = aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); aot_arbace_reflect.A_arbace_reflect_method__GT_map_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__59, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_50)); return A_arbace_reflect_java__init_A_const_49 }









func A_arbace_reflect_java__init_A_Unit20__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__61 any = aot_arbace_reflect.A_arbace_reflect_declared_methods_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_declared_methods_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); aot_arbace_reflect.A_arbace_reflect_declared_methods_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__61, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_52)); return A_arbace_reflect_java__init_A_const_51 }






func A_arbace_reflect_java__init_A_Unit21__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_55)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_56; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_57)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); var tmp3 *lang.Var = A_arbace_reflect_java__init_A_const_54; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_58)); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_54; var tmp5 *lang.Compiler_AOTFn; var fnbody__63 any = aot_arbace_reflect.A_arbace_reflect_eval1939000086___GT_Field__1939000100_A_New(); var tmp6 *jrt.Class; var fncls__62 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000086___GT_Field__1939000100_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000086___GT_Field__1939000100_A_fn_class = fncls__62d; tmp6 = fncls__62d } else { tmp6 = fncls__62 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__63, tmp6, nil); tmp4.BindRoot_O__V(tmp5.Ref()); var tmp7 *lang.Var = A_arbace_reflect_java__init_A_const_56; tmp7.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_59)); var tmp8 *lang.Var = A_arbace_reflect_java__init_A_const_56; var tmp9 *lang.Compiler_AOTFn; var fnbody__65 any = aot_arbace_reflect.A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A_New(); var tmp10 *jrt.Class; var fncls__64 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000086_map__GT_Field__1939000102_A_fn_class = fncls__64d; tmp10 = fncls__64d } else { tmp10 = fncls__64 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__65, tmp10, nil); tmp8.BindRoot_O__V(tmp9.Ref()); return A_arbace_reflect_java__init_A_const_53 }


func A_arbace_reflect_java__init_A_Unit22__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__67 any = aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); aot_arbace_reflect.A_arbace_reflect_field__GT_map_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__67, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_61)); return A_arbace_reflect_java__init_A_const_60 }







func A_arbace_reflect_java__init_A_Unit23__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__69 any = aot_arbace_reflect.A_arbace_reflect_declared_fields_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_declared_fields_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); aot_arbace_reflect.A_arbace_reflect_declared_fields_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_63)); return A_arbace_reflect_java__init_A_const_62 }






func A_arbace_reflect_java__init_A_Unit24__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(179, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__71 any = aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); aot_arbace_reflect.A_arbace_reflect_typeref__GT_class_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__71, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_65)); return A_arbace_reflect_java__init_A_const_64 }





func A_arbace_reflect_java__init_A_Unit25__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_28)); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_67; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_68)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_67; var tmp3 *lang.Compiler_AOTFn; var fnbody__73 any = aot_arbace_reflect.A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A_New(); var tmp4 *jrt.Class; var fncls__72 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000108___GT_JavaReflector__1939000110_A_fn_class = fncls__72d; tmp4 = fncls__72d } else { tmp4 = fncls__72 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__73, tmp4, nil); tmp2.BindRoot_O__V(tmp3.Ref()); return A_arbace_reflect_java__init_A_const_66 }









func A_arbace_reflect_java__init_A_Unit26__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(195, 1); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_69; var tmp2 any = jrt.Thread_CurrentThread__Thread(); var tmp3 *jrt.Class = A_arbace_reflect_java__init_A_const_70; tmp1.BindRoot_O__V(aot_arbace_reflect.A_arbace_reflect_JavaReflector_A_New_O(lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp2, tmp3, Lit_30, jrt.RefArrayOf(jrt.Object_class)))); var tmp4 *lang.Var = A_arbace_reflect_java__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_71)); return A_arbace_reflect_java__init_A_const_69 }


func A_arbace_reflect_java__init_A_Unit27__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_73)); v__1927001498__auto____1 = A_arbace_reflect_java__init_A_const_72; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_72; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_74)); A_arbace_reflect_java__init_A_const_72.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_reflect_java__init_A_const_72 } }
//line :198:1
func A_arbace_reflect_java__init_A_Unit28__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); return A_arbace_reflect_java__init_A_const_75 }
//line :198:1
func A_arbace_reflect_java__init_A_Unit29__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_76.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_72; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_reflect_java__init_A_const_77.GetRawRoot__O(), A_arbace_reflect_java__init_A_const_78, nil) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit30__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); return A_arbace_reflect_java__init_A_const_79.Invoke_O_O__O(A_arbace_reflect_java__init_A_const_72, A_arbace_reflect_java__init_A_const_80) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit31__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_72; var tmp3 any = A_arbace_reflect_java__init_A_const_82.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_77.GetRawRoot__O()); var tmp5 any = A_arbace_reflect_java__init_A_const_83; var tmp6 any = A_arbace_reflect_java__init_A_const_84; var tmp7 any = A_arbace_reflect_java__init_A_const_85; var tmp8 any = A_arbace_reflect_java__init_A_const_86; var tmp9 any = A_arbace_reflect_java__init_A_const_72; var tmp10 any = A_arbace_reflect_java__init_A_const_87; var tmp11 any = A_arbace_reflect_java__init_A_const_88; var tmp12 any = A_arbace_reflect_java__init_A_const_89; var tmp13 any; var root_99 any = A_arbace_reflect_java__init_A_const_90.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = A_arbace_reflect_java__init_A_const_91.Get__O(); var arg_103 any; var root_104 any = A_arbace_reflect_java__init_A_const_92.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = A_arbace_reflect_java__init_A_const_93; var arg_108 any; var root_109 any = A_arbace_reflect_java__init_A_const_82.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = A_arbace_reflect_java__init_A_const_94; var arg_113 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect_java__init_A_const_95, A_arbace_reflect_java__init_A_const_72)); if linked_110 == nil { arg_108 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }; if linked_105 == nil { arg_103 = ifn_106.Invoke_O_O__O(arg_107, arg_108) } else { arg_103 = linked_105.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_104, arg_107, arg_108) }; if linked_100 == nil { tmp13 = ifn_101.Invoke_O_O__O(arg_102, arg_103) } else { tmp13 = linked_100.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_99, arg_102, arg_103) }; var tmp14 any = tmp13; var tmp15 *lang.Compiler_AOTFn; var fnbody__115 any = aot_arbace_reflect.A_arbace_reflect_eval1939000121_fn__1939000122_A_New(); var tmp16 *jrt.Class; var fncls__114 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000121_fn__1939000122_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000121_fn__1939000122_A_fn_class = fncls__114d; tmp16 = fncls__114d } else { tmp16 = fncls__114 }; tmp15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__115, tmp16, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15.Ref())))) }
//line :198:1
func A_arbace_reflect_java__init_A_Unit32__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); var root_116 any = A_arbace_reflect_java__init_A_const_96.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = A_arbace_reflect_java__init_A_const_72.GetRawRoot__O(); if linked_117 == nil { return ifn_118.Invoke_O__O(arg_119) } else { return linked_117.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_116, arg_119) } }
//line :198:1
func A_arbace_reflect_java__init_A_Unit33__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(198, 1); return A_arbace_reflect_java__init_A_const_97 }



func A_arbace_reflect_java__init_A_Unit34__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_98; var tmp3 any = A_arbace_reflect_java__init_A_const_72.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_99; var tmp5 *lang.Compiler_AOTFn; var fnbody__127 any = aot_arbace_reflect.A_arbace_reflect_eval1939000137_fn__1939000138_A_New(); var tmp6 *jrt.Class; var fncls__126 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000137_fn__1939000138_A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000137_fn__1939000138_A_fn_class = fncls__126d; tmp6 = fncls__126d } else { tmp6 = fncls__126 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__127, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }
//line :202:1
func A_arbace_reflect_java__init_A_Unit35__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_java__init_A_const_7.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_java__init_A_const_100; var tmp3 any = A_arbace_reflect_java__init_A_const_72.GetRawRoot__O(); var tmp4 any = A_arbace_reflect_java__init_A_const_99; var tmp5 *lang.Compiler_AOTFn; var fnbody__135 any = aot_arbace_reflect.A_arbace_reflect_eval1939000141_fn__1939000142_A_New(); var tmp6 *jrt.Class; var fncls__134 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000141_fn__1939000142_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000141_fn__1939000142_A_fn_class = fncls__134d; tmp6 = fncls__134d } else { tmp6 = fncls__134 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__135, tmp6, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref()))) }










func A_arbace_reflect_java__init_A_Unit36__O() any { A_arbace_reflect_java__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(213, 1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_34)); var tmp1 *lang.Var = A_arbace_reflect_java__init_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect_java__init_A_const_103)); var tmp2 *lang.Var = A_arbace_reflect_java__init_A_const_102; var tmp3 *lang.Compiler_AOTFn; var fnbody__137 any = aot_arbace_reflect.A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A_New(); var tmp4 *jrt.Class; var fncls__136 *jrt.Class = aot_arbace_reflect.A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); aot_arbace_reflect.A_arbace_reflect_eval1939000145___GT_AsmReflector__1939000147_A_fn_class = fncls__136d; tmp4 = fncls__136d } else { tmp4 = fncls__136 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__137, tmp4, nil); tmp2.BindRoot_O__V(tmp3.Ref()); return A_arbace_reflect_java__init_A_const_101 }






type A_arbace_reflect_java__init_A struct{ jrt.Object }

var A_arbace_reflect_java__init_A_const_pool *jrt.RefArray

var A_arbace_reflect_java__init_A_const_0 *lang.Var

var A_arbace_reflect_java__init_A_const_1 any

var A_arbace_reflect_java__init_A_const_2 *lang.Var

var A_arbace_reflect_java__init_A_const_3 any

var A_arbace_reflect_java__init_A_const_4 any

var A_arbace_reflect_java__init_A_const_5 any

var A_arbace_reflect_java__init_A_const_6 *lang.Var

var A_arbace_reflect_java__init_A_const_7 *lang.Var

var A_arbace_reflect_java__init_A_const_8 *jrt.Class

var A_arbace_reflect_java__init_A_const_9 *lang.Var

var A_arbace_reflect_java__init_A_const_10 *lang.Keyword

var A_arbace_reflect_java__init_A_const_11 *jrt.Class

var A_arbace_reflect_java__init_A_const_12 *lang.Var

var A_arbace_reflect_java__init_A_const_13 any

var A_arbace_reflect_java__init_A_const_14 *lang.Var

var A_arbace_reflect_java__init_A_const_15 any

var A_arbace_reflect_java__init_A_const_16 *lang.Var

var A_arbace_reflect_java__init_A_const_17 any

var A_arbace_reflect_java__init_A_const_18 *lang.Var

var A_arbace_reflect_java__init_A_const_19 any

var A_arbace_reflect_java__init_A_const_20 *lang.Var

var A_arbace_reflect_java__init_A_const_21 any

var A_arbace_reflect_java__init_A_const_22 *lang.Var

var A_arbace_reflect_java__init_A_const_23 any

var A_arbace_reflect_java__init_A_const_24 *lang.Var

var A_arbace_reflect_java__init_A_const_25 *lang.Var

var A_arbace_reflect_java__init_A_const_26 *lang.Var

var A_arbace_reflect_java__init_A_const_27 any

var A_arbace_reflect_java__init_A_const_28 any

var A_arbace_reflect_java__init_A_const_29 *lang.Var

var A_arbace_reflect_java__init_A_const_30 any

var A_arbace_reflect_java__init_A_const_31 *jrt.Class

var A_arbace_reflect_java__init_A_const_32 *lang.Var

var A_arbace_reflect_java__init_A_const_33 any

var A_arbace_reflect_java__init_A_const_34 *lang.Var

var A_arbace_reflect_java__init_A_const_35 any

var A_arbace_reflect_java__init_A_const_36 any

var A_arbace_reflect_java__init_A_const_37 any

var A_arbace_reflect_java__init_A_const_38 *lang.Var

var A_arbace_reflect_java__init_A_const_39 any

var A_arbace_reflect_java__init_A_const_40 *lang.Var

var A_arbace_reflect_java__init_A_const_41 any

var A_arbace_reflect_java__init_A_const_42 *jrt.Class

var A_arbace_reflect_java__init_A_const_43 *lang.Var

var A_arbace_reflect_java__init_A_const_44 any

var A_arbace_reflect_java__init_A_const_45 *lang.Var

var A_arbace_reflect_java__init_A_const_46 any

var A_arbace_reflect_java__init_A_const_47 any

var A_arbace_reflect_java__init_A_const_48 any

var A_arbace_reflect_java__init_A_const_49 *lang.Var

var A_arbace_reflect_java__init_A_const_50 any

var A_arbace_reflect_java__init_A_const_51 *lang.Var

var A_arbace_reflect_java__init_A_const_52 any

var A_arbace_reflect_java__init_A_const_53 *jrt.Class

var A_arbace_reflect_java__init_A_const_54 *lang.Var

var A_arbace_reflect_java__init_A_const_55 any

var A_arbace_reflect_java__init_A_const_56 *lang.Var

var A_arbace_reflect_java__init_A_const_57 any

var A_arbace_reflect_java__init_A_const_58 any

var A_arbace_reflect_java__init_A_const_59 any

var A_arbace_reflect_java__init_A_const_60 *lang.Var

var A_arbace_reflect_java__init_A_const_61 any

var A_arbace_reflect_java__init_A_const_62 *lang.Var

var A_arbace_reflect_java__init_A_const_63 any

var A_arbace_reflect_java__init_A_const_64 *lang.Var

var A_arbace_reflect_java__init_A_const_65 any

var A_arbace_reflect_java__init_A_const_66 *jrt.Class

var A_arbace_reflect_java__init_A_const_67 *lang.Var

var A_arbace_reflect_java__init_A_const_68 any

var A_arbace_reflect_java__init_A_const_69 *lang.Var

var A_arbace_reflect_java__init_A_const_70 *jrt.Class

var A_arbace_reflect_java__init_A_const_71 any

var A_arbace_reflect_java__init_A_const_72 *lang.Var

var A_arbace_reflect_java__init_A_const_73 any

var A_arbace_reflect_java__init_A_const_74 any

var A_arbace_reflect_java__init_A_const_75 *jrt.Class

var A_arbace_reflect_java__init_A_const_76 *lang.Var

var A_arbace_reflect_java__init_A_const_77 *lang.Var

var A_arbace_reflect_java__init_A_const_78 *lang.Keyword

var A_arbace_reflect_java__init_A_const_79 *lang.Var

var A_arbace_reflect_java__init_A_const_80 any

var A_arbace_reflect_java__init_A_const_81 *lang.Var

var A_arbace_reflect_java__init_A_const_82 *lang.Var

var A_arbace_reflect_java__init_A_const_83 any

var A_arbace_reflect_java__init_A_const_84 *lang.Keyword

var A_arbace_reflect_java__init_A_const_85 any

var A_arbace_reflect_java__init_A_const_86 *lang.Keyword

var A_arbace_reflect_java__init_A_const_87 *lang.Keyword

var A_arbace_reflect_java__init_A_const_88 any

var A_arbace_reflect_java__init_A_const_89 *lang.Keyword

var A_arbace_reflect_java__init_A_const_90 *lang.Var

var A_arbace_reflect_java__init_A_const_91 *lang.Var

var A_arbace_reflect_java__init_A_const_92 *lang.Var

var A_arbace_reflect_java__init_A_const_93 any

var A_arbace_reflect_java__init_A_const_94 any

var A_arbace_reflect_java__init_A_const_95 *lang.Keyword

var A_arbace_reflect_java__init_A_const_96 *lang.Var

var A_arbace_reflect_java__init_A_const_97 any

var A_arbace_reflect_java__init_A_const_98 *jrt.Class

var A_arbace_reflect_java__init_A_const_99 *lang.Keyword

var A_arbace_reflect_java__init_A_const_100 *jrt.Class

var A_arbace_reflect_java__init_A_const_101 *jrt.Class

var A_arbace_reflect_java__init_A_const_102 *lang.Var

var A_arbace_reflect_java__init_A_const_103 any

var A_arbace_reflect_java__init_A_init jrt.ClassInit

func A_arbace_reflect_java__init_A_Init() { if !A_arbace_reflect_java__init_A_init.Done() { A_arbace_reflect_java__init_A_init.Run(A_arbace_reflect_java__init_A_clinit) } }

func A_arbace_reflect_java__init_A_clinit() { A_arbace_reflect_java__init_A_clinit_p0(); A_arbace_reflect_java__init_A_clinit_p1(); A_arbace_reflect_java__init_A_clinit_p2(); A_arbace_reflect_java__init_A_clinit_p3(); A_arbace_reflect_java__init_A_clinit_p4(); A_arbace_reflect_java__init_A_clinit_p5(); A_arbace_reflect_java__init_A_clinit_p6(); A_arbace_reflect_java__init_A_clinit_p7(); A_arbace_reflect_java__init_A_clinit_p8() }

func A_arbace_reflect_java__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_reflect_java__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 180); A_arbace_reflect_java__init_A_const_0 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[76]); A_arbace_reflect_java__init_A_const_1 = A_arbace_reflect_java__init_A_const_pool.A[77]; A_arbace_reflect_java__init_A_const_2 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[78]); A_arbace_reflect_java__init_A_const_3 = A_arbace_reflect_java__init_A_const_pool.A[79]; A_arbace_reflect_java__init_A_const_4 = A_arbace_reflect_java__init_A_const_pool.A[80]; A_arbace_reflect_java__init_A_const_5 = A_arbace_reflect_java__init_A_const_pool.A[81]; A_arbace_reflect_java__init_A_const_6 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[82]); A_arbace_reflect_java__init_A_const_7 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[83]); A_arbace_reflect_java__init_A_const_8 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[84]); A_arbace_reflect_java__init_A_const_9 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[85]); A_arbace_reflect_java__init_A_const_10 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[86]); A_arbace_reflect_java__init_A_const_11 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[87]) }

func A_arbace_reflect_java__init_A_clinit_p1() { A_arbace_reflect_java__init_A_const_12 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[88]); A_arbace_reflect_java__init_A_const_13 = A_arbace_reflect_java__init_A_const_pool.A[89]; A_arbace_reflect_java__init_A_const_14 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[90]); A_arbace_reflect_java__init_A_const_15 = A_arbace_reflect_java__init_A_const_pool.A[91]; A_arbace_reflect_java__init_A_const_16 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[92]); A_arbace_reflect_java__init_A_const_17 = A_arbace_reflect_java__init_A_const_pool.A[93]; A_arbace_reflect_java__init_A_const_18 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[94]); A_arbace_reflect_java__init_A_const_19 = A_arbace_reflect_java__init_A_const_pool.A[95]; A_arbace_reflect_java__init_A_const_20 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[96]); A_arbace_reflect_java__init_A_const_21 = A_arbace_reflect_java__init_A_const_pool.A[97]; A_arbace_reflect_java__init_A_const_22 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[98]); A_arbace_reflect_java__init_A_const_23 = A_arbace_reflect_java__init_A_const_pool.A[99]; A_arbace_reflect_java__init_A_const_24 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[100]) }

func A_arbace_reflect_java__init_A_clinit_p2() { A_arbace_reflect_java__init_A_const_25 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[101]); A_arbace_reflect_java__init_A_const_26 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[102]); A_arbace_reflect_java__init_A_const_27 = A_arbace_reflect_java__init_A_const_pool.A[103]; A_arbace_reflect_java__init_A_const_28 = A_arbace_reflect_java__init_A_const_pool.A[104]; A_arbace_reflect_java__init_A_const_29 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[105]); A_arbace_reflect_java__init_A_const_30 = A_arbace_reflect_java__init_A_const_pool.A[106]; A_arbace_reflect_java__init_A_const_31 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[107]); A_arbace_reflect_java__init_A_const_32 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[108]); A_arbace_reflect_java__init_A_const_33 = A_arbace_reflect_java__init_A_const_pool.A[109]; A_arbace_reflect_java__init_A_const_34 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[110]); A_arbace_reflect_java__init_A_const_35 = A_arbace_reflect_java__init_A_const_pool.A[111]; A_arbace_reflect_java__init_A_const_36 = A_arbace_reflect_java__init_A_const_pool.A[112]; A_arbace_reflect_java__init_A_const_37 = A_arbace_reflect_java__init_A_const_pool.A[113] }

func A_arbace_reflect_java__init_A_clinit_p3() { A_arbace_reflect_java__init_A_const_38 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[114]); A_arbace_reflect_java__init_A_const_39 = A_arbace_reflect_java__init_A_const_pool.A[115]; A_arbace_reflect_java__init_A_const_40 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[116]); A_arbace_reflect_java__init_A_const_41 = A_arbace_reflect_java__init_A_const_pool.A[117]; A_arbace_reflect_java__init_A_const_42 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[118]); A_arbace_reflect_java__init_A_const_43 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[119]); A_arbace_reflect_java__init_A_const_44 = A_arbace_reflect_java__init_A_const_pool.A[120]; A_arbace_reflect_java__init_A_const_45 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[121]); A_arbace_reflect_java__init_A_const_46 = A_arbace_reflect_java__init_A_const_pool.A[122]; A_arbace_reflect_java__init_A_const_47 = A_arbace_reflect_java__init_A_const_pool.A[123]; A_arbace_reflect_java__init_A_const_48 = A_arbace_reflect_java__init_A_const_pool.A[124]; A_arbace_reflect_java__init_A_const_49 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[125]); A_arbace_reflect_java__init_A_const_50 = A_arbace_reflect_java__init_A_const_pool.A[126] }

func A_arbace_reflect_java__init_A_clinit_p4() { A_arbace_reflect_java__init_A_const_51 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[127]); A_arbace_reflect_java__init_A_const_52 = A_arbace_reflect_java__init_A_const_pool.A[128]; A_arbace_reflect_java__init_A_const_53 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[129]); A_arbace_reflect_java__init_A_const_54 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[130]); A_arbace_reflect_java__init_A_const_55 = A_arbace_reflect_java__init_A_const_pool.A[131]; A_arbace_reflect_java__init_A_const_56 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[132]); A_arbace_reflect_java__init_A_const_57 = A_arbace_reflect_java__init_A_const_pool.A[133]; A_arbace_reflect_java__init_A_const_58 = A_arbace_reflect_java__init_A_const_pool.A[134]; A_arbace_reflect_java__init_A_const_59 = A_arbace_reflect_java__init_A_const_pool.A[135]; A_arbace_reflect_java__init_A_const_60 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[136]); A_arbace_reflect_java__init_A_const_61 = A_arbace_reflect_java__init_A_const_pool.A[137]; A_arbace_reflect_java__init_A_const_62 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[138]); A_arbace_reflect_java__init_A_const_63 = A_arbace_reflect_java__init_A_const_pool.A[139] }

func A_arbace_reflect_java__init_A_clinit_p5() { A_arbace_reflect_java__init_A_const_64 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[140]); A_arbace_reflect_java__init_A_const_65 = A_arbace_reflect_java__init_A_const_pool.A[141]; A_arbace_reflect_java__init_A_const_66 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[142]); A_arbace_reflect_java__init_A_const_67 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[143]); A_arbace_reflect_java__init_A_const_68 = A_arbace_reflect_java__init_A_const_pool.A[144]; A_arbace_reflect_java__init_A_const_69 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[145]); A_arbace_reflect_java__init_A_const_70 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[146]); A_arbace_reflect_java__init_A_const_71 = A_arbace_reflect_java__init_A_const_pool.A[147]; A_arbace_reflect_java__init_A_const_72 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[148]); A_arbace_reflect_java__init_A_const_73 = A_arbace_reflect_java__init_A_const_pool.A[149]; A_arbace_reflect_java__init_A_const_74 = A_arbace_reflect_java__init_A_const_pool.A[150]; A_arbace_reflect_java__init_A_const_75 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[151]); A_arbace_reflect_java__init_A_const_76 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[152]) }

func A_arbace_reflect_java__init_A_clinit_p6() { A_arbace_reflect_java__init_A_const_77 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[153]); A_arbace_reflect_java__init_A_const_78 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[154]); A_arbace_reflect_java__init_A_const_79 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[155]); A_arbace_reflect_java__init_A_const_80 = A_arbace_reflect_java__init_A_const_pool.A[156]; A_arbace_reflect_java__init_A_const_81 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[157]); A_arbace_reflect_java__init_A_const_82 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[158]); A_arbace_reflect_java__init_A_const_83 = A_arbace_reflect_java__init_A_const_pool.A[159]; A_arbace_reflect_java__init_A_const_84 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[160]); A_arbace_reflect_java__init_A_const_85 = A_arbace_reflect_java__init_A_const_pool.A[161]; A_arbace_reflect_java__init_A_const_86 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[162]); A_arbace_reflect_java__init_A_const_87 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[163]); A_arbace_reflect_java__init_A_const_88 = A_arbace_reflect_java__init_A_const_pool.A[164]; A_arbace_reflect_java__init_A_const_89 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[165]) }

func A_arbace_reflect_java__init_A_clinit_p7() { A_arbace_reflect_java__init_A_const_90 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[166]); A_arbace_reflect_java__init_A_const_91 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[167]); A_arbace_reflect_java__init_A_const_92 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[168]); A_arbace_reflect_java__init_A_const_93 = A_arbace_reflect_java__init_A_const_pool.A[169]; A_arbace_reflect_java__init_A_const_94 = A_arbace_reflect_java__init_A_const_pool.A[170]; A_arbace_reflect_java__init_A_const_95 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[171]); A_arbace_reflect_java__init_A_const_96 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[172]); A_arbace_reflect_java__init_A_const_97 = A_arbace_reflect_java__init_A_const_pool.A[173]; A_arbace_reflect_java__init_A_const_98 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[174]); A_arbace_reflect_java__init_A_const_99 = lang.Keyword_Cast(A_arbace_reflect_java__init_A_const_pool.A[175]); A_arbace_reflect_java__init_A_const_100 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[176]); A_arbace_reflect_java__init_A_const_101 = jrt.Class_Cast(A_arbace_reflect_java__init_A_const_pool.A[177]) }

func A_arbace_reflect_java__init_A_clinit_p8() { A_arbace_reflect_java__init_A_const_102 = lang.Var_Cast(A_arbace_reflect_java__init_A_const_pool.A[178]); A_arbace_reflect_java__init_A_const_103 = A_arbace_reflect_java__init_A_const_pool.A[179] }

func A_arbace_reflect_java__init_A_New() *A_arbace_reflect_java__init_A { A_arbace_reflect_java__init_A_Init(); t := &A_arbace_reflect_java__init_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_java__init_A) Ctor() {}

func (t *A_arbace_reflect_java__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_java__init_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_java__init_A_class }

func (t *A_arbace_reflect_java__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_java__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_java__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_java__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_java__init_A); return ok }

func A_arbace_reflect_java__init_A_Cast(x any) *A_arbace_reflect_java__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_java__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_java__init_A_class)) }; return v }
