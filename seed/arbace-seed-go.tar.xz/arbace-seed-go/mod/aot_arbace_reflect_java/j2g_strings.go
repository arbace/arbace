//line j2g_strings.ae:1
package aot_arbace_reflect_java

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn14,arbace.reflectyn13,arbace.datafykn5,referyn6,datafykn4,linekn6,columnyn10,arbace.setkn2,asyn3,setyn13,arbace.stringyn3,strkn8,typenamekn7,privatekn8,arglistsyn1,tkn3,dockn4,fileyn7,typerefyn4,nameyn4,flagyn1,&yn8,contextskn3,tagyn6,Stringkn3,preyn7,string?yn1,dkn6,publickn5,classkn5,fieldkn6,methodkn9,protectedkn6,statickn5,finalkn12,synchronizedkn8,volatilekn6,bridgekn7,varargskn9,transientkn6,nativekn9,interfacekn8,abstractkn6,strictkn9,synthetickn10,annotationkn4,enumkn5,inneryn5,flagsyn7,contextkn8,declaredyn15,declaring-classyn15,parameter-typesyn15,exception-typesyn20,m__231000174__auto__yn29,java.lang.reflect.Constructoryn5,Classyn11,return-typeyn24,java.lang.reflect.Methodyn4,typeyn23,java.lang.reflect.Fieldyn11,classloaderyn15,java.lang.Classyn4,thiskn2,onyn28,arbace.reflect.ClassResolverkn12,on-interfacekn4,sigskn13,resolve-classyn19,java.io.InputStreamkn4,namekn3,varkn10,method-mapkn15,method-builderskn8,protocolyn13,ClassResolveryn14,class-resolverv11,arbace.core5,in-nsR0,v11,arbace.core7,requireV3,R1,R2,ML1,R3,m4,R4,i12,R5,i33,V3,R6,R7,R8,V3,R9,R7,R10,v11,arbace.core20,*warn-on-reflection*v11,arbace.core6,extendC18,arbace.lang.Symbolv14,arbace.reflect13,TypeReferenceR11,C15,java.lang.Classv14,arbace.reflect7,typesymm12,R12,TR13,L1,V1,R14,R15,s77,Given a typeref, create a legal Clojure symbol version of the\n   type's name.R4,i33,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect13,resource-namem12,R12,TR13,L1,V1,R17,R15,s130,Given a typeref, return implied resource name. Used by Reflectors\n   such as ASM that need to find and read classbytes from files.R4,i44,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect11,access-flagm10,R12,TR13,L1,V1,V4,R18,R19,R20,R21,R4,i52,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect21,descriptor-class-namem12,R12,TR13,L1,V1,Myn1,dm2,R22,R23,R15,s66,Type.getType(d).getClassName() of field descriptor d, without ASM.R4,i56,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect30,field-descriptor->class-symbolm12,R12,TR13,L1,MV1,Myn1,dm2,R22,R23,m2,R24,V1,ML2,R25,R26,m4,R4,i70,R5,i10,R15,s220,Convert a Java field descriptor to a Clojure class symbol. Field\n   descriptors are described in section 4.3.2 of the JVM spec, 2nd ed.:\n   http://java.sun.com/docs/books/jvms/second_edition/html/ClassFile.doc.html#14152R4,i65,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect27,internal-name->class-symbolm12,R12,TR13,L1,MV1,R26,m2,R24,V1,ML2,R25,R26,m4,R4,i80,R5,i10,R15,s256,Convert a Java internal name to a Clojure class symbol. Internal\n   names uses slashes instead of dots, e.g. java/lang/String. See\n   Section 4.2 of the JVM spec, 2nd ed.:\n\n   http://java.sun.com/docs/books/jvms/second_edition/html/ClassFile.doc.html#14757R4,i73,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect16,flag-descriptorsv11,arbace.core3,vecm8,R15,s107,The Java access bitflags, along with their friendly names and\nthe kinds of objects to which they can apply.R4,i84,R5,i1,R16,s22,arbace/reflect/java.aev11,arbace.core3,mapV17,V5,R27,l1,R28,R29,R30,V5,R12,l2,R28,R29,R30,V5,R31,l4,R28,R29,R30,V4,R32,l8,R29,R30,V5,R33,l16,R28,R29,R30,V3,R34,l32,R30,V3,R35,l64,R29,V3,R36,l64,R30,V3,R37,l128,R30,V3,R38,l128,R29,V3,R39,l256,R30,V3,R40,l512,R28,V4,R41,l1024,R28,R30,V3,R42,l2048,R30,V5,R43,l4096,R28,R29,R30,V3,R44,l8192,R28,V5,R45,l16384,R28,R29,R46,v14,arbace.reflect11,parse-flagsm12,R12,TR13,L1,V2,R47,R48,R15,s51,Convert reflection bitflags into a set of keywords.R4,i110,R5,i1,R16,s22,arbace/reflect/java.aeC26,arbace.reflect.Constructorv14,arbace.reflect13,->Constructorm8,R49,TR4,i122,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect16,map->Constructorm8,R49,TR4,i122,R5,i1,R16,s22,arbace/reflect/java.aem10,R13,L1,V5,R18,R50,R51,R52,R47,R15,s65,Positional factory function for class arbace.reflect.Constructor.R4,i122,R5,i1,R16,s22,arbace/reflect/java.aem10,R13,L1,V1,R53,R15,s96,Factory function for class arbace.reflect.Constructor, taking a map of keywords to field values.R4,i122,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect16,constructor->mapm10,R12,TR13,L1,V1,Myn11,constructorm2,R22,R54,R4,i125,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect21,declared-constructorsm12,R12,TR13,L1,V1,Myn3,clsm2,R22,R55,R15,s68,Return a set of the declared constructors of class as a Clojure map.R4,i134,R5,i1,R16,s22,arbace/reflect/java.aeC21,arbace.reflect.Methodv14,arbace.reflect8,->Methodm8,R49,TR4,i141,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect11,map->Methodm8,R49,TR4,i141,R5,i1,R16,s22,arbace/reflect/java.aem10,R13,L1,V6,R18,R56,R50,R51,R52,R47,R15,s60,Positional factory function for class arbace.reflect.Method.R4,i141,R5,i1,R16,s22,arbace/reflect/java.aem10,R13,L1,V1,R53,R15,s91,Factory function for class arbace.reflect.Method, taking a map of keywords to field values.R4,i141,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect11,method->mapm10,R12,TR13,L1,V1,Myn6,methodm2,R22,R57,R4,i144,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect16,declared-methodsm12,R12,TR13,L1,V1,Myn3,clsm2,R22,R55,R15,s68,Return a set of the declared constructors of class as a Clojure map.R4,i154,R5,i1,R16,s22,arbace/reflect/java.aeC20,arbace.reflect.Fieldv14,arbace.reflect7,->Fieldm8,R49,TR4,i161,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect10,map->Fieldm8,R49,TR4,i161,R5,i1,R16,s22,arbace/reflect/java.aem10,R13,L1,V4,R18,R58,R50,R47,R15,s59,Positional factory function for class arbace.reflect.Field.R4,i161,R5,i1,R16,s22,arbace/reflect/java.aem10,R13,L1,V1,R53,R15,s90,Factory function for class arbace.reflect.Field, taking a map of keywords to field values.R4,i161,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect10,field->mapm10,R12,TR13,L1,V1,Myn5,fieldm2,R22,R59,R4,i164,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect15,declared-fieldsm12,R12,TR13,L1,V1,Myn3,clsm2,R22,R55,R15,s62,Return a set of the declared fields of class as a Clojure map.R4,i172,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect14,typeref->classm10,R12,TR13,L1,MV2,R17,R60,m2,R22,R61,R4,i179,R5,i1,R16,s22,arbace/reflect/java.aeC28,arbace.reflect.JavaReflectorv14,arbace.reflect15,->JavaReflectorm10,R13,L1,V1,R60,R15,s67,Positional factory function for class arbace.reflect.JavaReflector.R4,i185,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect17,default-reflectorC16,java.lang.Threadm8,R12,TR4,i195,R5,i1,R16,s22,arbace/reflect/java.aev14,arbace.reflect13,ClassResolverm6,R4,i198,R5,i1,R16,s22,arbace/reflect/java.aem6,R4,i198,R5,i1,R16,s22,arbace/reflect/java.aeC28,arbace.reflect.ClassResolverv11,arbace.core11,alter-meta!v11,arbace.core5,assocR15,v11,arbace.core20,assert-same-protocolL1,Myn13,resolve-classm4,R15,s72,Given a class name, return that typeref's class bytes as an InputStream.R13,L1,V2,R62,R18,v11,arbace.core14,alter-var-rootv11,arbace.core5,mergem4,R63,R64,R65,C28,arbace.reflect.ClassResolverR66,m2,R67,m8,R22,R68,R69,Myn13,resolve-classm4,R15,s72,Given a class name, return that typeref's class bytes as an InputStream.R13,L1,V2,R62,R18,R13,L1,V2,R62,R18,R15,s72,Given a class name, return that typeref's class bytes as an InputStream.R70,R71,m2,R67,R67,R72,v11,arbace.core6,internv11,arbace.core4,*ns*v11,arbace.core9,with-metaMyn13,resolve-classm4,R15,s72,Given a class name, return that typeref's class bytes as an InputStream.R13,L1,V2,R62,R18,m8,R22,R68,R69,Myn13,resolve-classm4,R15,s72,Given a class name, return that typeref's class bytes as an InputStream.R13,L1,V2,R62,R18,R13,L1,V2,R62,R18,R15,s72,Given a class name, return that typeref's class bytes as an InputStream.R73,v11,arbace.core14,-reset-methodsR74,C14,arbace.lang.FnR67,C21,java.lang.ClassLoaderC27,arbace.reflect.AsmReflectorv14,arbace.reflect14,->AsmReflectorm10,R13,L1,V1,R75,R15,s66,Positional factory function for class arbace.reflect.AsmReflector.R4,i213,R5,i1,R16,s22,arbace/reflect/java.ae")

var Lit_1 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_2 *jrt.String = jrt.Intern("java.io.InputStream")

var Lit_3 *jrt.String = jrt.Intern("arbace.reflect$eval1938000010$fn__1938000011")

var Lit_4 *jrt.String = jrt.Intern("arbace.reflect$eval1938000014$fn__1938000015")

var Lit_5 *jrt.String = jrt.Intern("arbace.reflect$typesym")

var Lit_6 *jrt.String = jrt.Intern("arbace.reflect$resource_name")

var Lit_7 *jrt.String = jrt.Intern("arbace.reflect$access_flag")

var Lit_8 *jrt.String = jrt.Intern("arbace.reflect$descriptor_class_name")

var Lit_9 *jrt.String = jrt.Intern("arbace.reflect$field_descriptor__GT_class_symbol")

var Lit_10 *jrt.String = jrt.Intern("arbace.reflect$internal_name__GT_class_symbol")

var Lit_11 *jrt.String = jrt.Intern("arbace.reflect$parse_flags")

var Lit_12 *jrt.String = jrt.Intern("arbace.reflect.Constructor")

var Lit_13 *jrt.String = jrt.Intern("arbace.reflect$eval1938000036$__GT_Constructor__1938000052")

var Lit_14 *jrt.String = jrt.Intern("arbace.reflect$eval1938000036$map__GT_Constructor__1938000054")

var Lit_15 *jrt.String = jrt.Intern("arbace.reflect$constructor__GT_map")

var Lit_16 *jrt.String = jrt.Intern("arbace.reflect$declared_constructors")

var Lit_17 *jrt.String = jrt.Intern("arbace.reflect.Method")

var Lit_18 *jrt.String = jrt.Intern("arbace.reflect$eval1938000060$__GT_Method__1938000078")

var Lit_19 *jrt.String = jrt.Intern("arbace.reflect$eval1938000060$map__GT_Method__1938000080")

var Lit_20 *jrt.String = jrt.Intern("arbace.reflect$method__GT_map")

var Lit_21 *jrt.String = jrt.Intern("arbace.reflect$declared_methods")

var Lit_22 *jrt.String = jrt.Intern("arbace.reflect.Field")

var Lit_23 *jrt.String = jrt.Intern("arbace.reflect$eval1938000086$__GT_Field__1938000100")

var Lit_24 *jrt.String = jrt.Intern("arbace.reflect$eval1938000086$map__GT_Field__1938000102")

var Lit_25 *jrt.String = jrt.Intern("arbace.reflect$field__GT_map")

var Lit_26 *jrt.String = jrt.Intern("arbace.reflect$declared_fields")

var Lit_27 *jrt.String = jrt.Intern("arbace.reflect$typeref__GT_class")

var Lit_28 *jrt.String = jrt.Intern("arbace.reflect.JavaReflector")

var Lit_29 *jrt.String = jrt.Intern("arbace.reflect$eval1938000108$__GT_JavaReflector__1938000110")

var Lit_30 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_31 *jrt.String = jrt.Intern("arbace.reflect$eval1938000121$fn__1938000122")

var Lit_32 *jrt.String = jrt.Intern("arbace.reflect$eval1938000137$fn__1938000138")

var Lit_33 *jrt.String = jrt.Intern("arbace.reflect$eval1938000141$fn__1938000142")

var Lit_34 *jrt.String = jrt.Intern("arbace.reflect.AsmReflector")

var Lit_35 *jrt.String = jrt.Intern("arbace.reflect$eval1938000145$__GT_AsmReflector__1938000147")
