//line a2g_strings.ae:1
package aot_arbace_reflect_java

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("arbace.reflect")

var Lit_3 *jrt.String = jrt.Intern("require")

var Lit_4 *jrt.String = jrt.Intern("arbace.datafy")

var Lit_5 *jrt.String = jrt.Intern("refer")

var Lit_6 *jrt.String = jrt.Intern("datafy")

var Lit_7 *jrt.String = jrt.Intern("line")

var Lit_8 *jrt.String = jrt.Intern("column")

var Lit_9 *jrt.String = jrt.Intern("arbace.set")

var Lit_10 *jrt.String = jrt.Intern("as")

var Lit_11 *jrt.String = jrt.Intern("set")

var Lit_12 *jrt.String = jrt.Intern("arbace.string")

var Lit_13 *jrt.String = jrt.Intern("str")

var Lit_14 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_15 *jrt.String = jrt.Intern("extend")

var Lit_16 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_17 *jrt.String = jrt.Intern("TypeReference")

var Lit_18 *jrt.String = jrt.Intern("typename")

var Lit_19 *jrt.String = jrt.Intern("java.lang.Class")

var Lit_20 *jrt.String = jrt.Intern("typesym")

var Lit_21 *jrt.String = jrt.Intern("private")

var Lit_22 *jrt.String = jrt.Intern("arglists")

var Lit_23 *jrt.String = jrt.Intern("t")

var Lit_24 *jrt.String = jrt.Intern("doc")

var Lit_25 *jrt.String = jrt.Intern("Given a typeref, create a legal Clojure symbol version of the\n   type's name.")

var Lit_26 *jrt.String = jrt.Intern("file")

var Lit_27 *jrt.String = jrt.Intern("arbace/reflect/java.ae")

var Lit_28 *jrt.String = jrt.Intern("resource-name")

var Lit_29 *jrt.String = jrt.Intern("typeref")

var Lit_30 *jrt.String = jrt.Intern("Given a typeref, return implied resource name. Used by Reflectors\n   such as ASM that need to find and read classbytes from files.")

var Lit_31 *jrt.String = jrt.Intern("access-flag")

var Lit_32 *jrt.String = jrt.Intern("name")

var Lit_33 *jrt.String = jrt.Intern("flag")

var Lit_34 *jrt.String = jrt.Intern("&")

var Lit_35 *jrt.String = jrt.Intern("contexts")

var Lit_36 *jrt.String = jrt.Intern("descriptor-class-name")

var Lit_37 *jrt.String = jrt.Intern("d")

var Lit_38 *jrt.String = jrt.Intern("tag")

var Lit_39 *jrt.String = jrt.Intern("String")

var Lit_40 *jrt.String = jrt.Intern("Type.getType(d).getClassName() of field descriptor d, without ASM.")

var Lit_41 *jrt.String = jrt.Intern("field-descriptor->class-symbol")

var Lit_42 *jrt.String = jrt.Intern("pre")

var Lit_43 *jrt.String = jrt.Intern("string?")

var Lit_44 *jrt.String = jrt.Intern("Convert a Java field descriptor to a Clojure class symbol. Field\n   descriptors are described in section 4.3.2 of the JVM spec, 2nd ed.:\n   http://java.sun.com/docs/books/jvms/second_edition/html/ClassFile.doc.html#14152")

var Lit_45 *jrt.String = jrt.Intern("internal-name->class-symbol")

var Lit_46 *jrt.String = jrt.Intern("Convert a Java internal name to a Clojure class symbol. Internal\n   names uses slashes instead of dots, e.g. java/lang/String. See\n   Section 4.2 of the JVM spec, 2nd ed.:\n\n   http://java.sun.com/docs/books/jvms/second_edition/html/ClassFile.doc.html#14757")

var Lit_47 *jrt.String = jrt.Intern("flag-descriptors")

var Lit_48 *jrt.String = jrt.Intern("vec")

var Lit_49 *jrt.String = jrt.Intern("The Java access bitflags, along with their friendly names and\nthe kinds of objects to which they can apply.")

var Lit_50 *jrt.String = jrt.Intern("map")

var Lit_51 *jrt.String = jrt.Intern("public")

var Lit_52 *jrt.String = jrt.Intern("class")

var Lit_53 *jrt.String = jrt.Intern("field")

var Lit_54 *jrt.String = jrt.Intern("method")

var Lit_55 *jrt.String = jrt.Intern("protected")

var Lit_56 *jrt.String = jrt.Intern("static")

var Lit_57 *jrt.String = jrt.Intern("final")

var Lit_58 *jrt.String = jrt.Intern("synchronized")

var Lit_59 *jrt.String = jrt.Intern("volatile")

var Lit_60 *jrt.String = jrt.Intern("bridge")

var Lit_61 *jrt.String = jrt.Intern("varargs")

var Lit_62 *jrt.String = jrt.Intern("transient")

var Lit_63 *jrt.String = jrt.Intern("native")

var Lit_64 *jrt.String = jrt.Intern("interface")

var Lit_65 *jrt.String = jrt.Intern("abstract")

var Lit_66 *jrt.String = jrt.Intern("strict")

var Lit_67 *jrt.String = jrt.Intern("synthetic")

var Lit_68 *jrt.String = jrt.Intern("annotation")

var Lit_69 *jrt.String = jrt.Intern("enum")

var Lit_70 *jrt.String = jrt.Intern("inner")

var Lit_71 *jrt.String = jrt.Intern("parse-flags")

var Lit_72 *jrt.String = jrt.Intern("flags")

var Lit_73 *jrt.String = jrt.Intern("context")

var Lit_74 *jrt.String = jrt.Intern("Convert reflection bitflags into a set of keywords.")

var Lit_75 *jrt.String = jrt.Intern("arbace.reflect.Constructor")

var Lit_76 *jrt.String = jrt.Intern("->Constructor")

var Lit_77 *jrt.String = jrt.Intern("declared")

var Lit_78 *jrt.String = jrt.Intern("map->Constructor")

var Lit_79 *jrt.String = jrt.Intern("declaring-class")

var Lit_80 *jrt.String = jrt.Intern("parameter-types")

var Lit_81 *jrt.String = jrt.Intern("exception-types")

var Lit_82 *jrt.String = jrt.Intern("Positional factory function for class arbace.reflect.Constructor.")

var Lit_83 *jrt.String = jrt.Intern("m__231000174__auto__")

var Lit_84 *jrt.String = jrt.Intern("Factory function for class arbace.reflect.Constructor, taking a map of keywords to field values.")

var Lit_85 *jrt.String = jrt.Intern("constructor->map")

var Lit_86 *jrt.String = jrt.Intern("constructor")

var Lit_87 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_88 *jrt.String = jrt.Intern("declared-constructors")

var Lit_89 *jrt.String = jrt.Intern("cls")

var Lit_90 *jrt.String = jrt.Intern("Class")

var Lit_91 *jrt.String = jrt.Intern("Return a set of the declared constructors of class as a Clojure map.")

var Lit_92 *jrt.String = jrt.Intern("arbace.reflect.Method")

var Lit_93 *jrt.String = jrt.Intern("->Method")

var Lit_94 *jrt.String = jrt.Intern("map->Method")

var Lit_95 *jrt.String = jrt.Intern("return-type")

var Lit_96 *jrt.String = jrt.Intern("Positional factory function for class arbace.reflect.Method.")

var Lit_97 *jrt.String = jrt.Intern("Factory function for class arbace.reflect.Method, taking a map of keywords to field values.")

var Lit_98 *jrt.String = jrt.Intern("method->map")

var Lit_99 *jrt.String = jrt.Intern("java.lang.reflect.Method")

var Lit_100 *jrt.String = jrt.Intern("declared-methods")

var Lit_101 *jrt.String = jrt.Intern("arbace.reflect.Field")

var Lit_102 *jrt.String = jrt.Intern("->Field")

var Lit_103 *jrt.String = jrt.Intern("map->Field")

var Lit_104 *jrt.String = jrt.Intern("type")

var Lit_105 *jrt.String = jrt.Intern("Positional factory function for class arbace.reflect.Field.")

var Lit_106 *jrt.String = jrt.Intern("Factory function for class arbace.reflect.Field, taking a map of keywords to field values.")

var Lit_107 *jrt.String = jrt.Intern("field->map")

var Lit_108 *jrt.String = jrt.Intern("java.lang.reflect.Field")

var Lit_109 *jrt.String = jrt.Intern("declared-fields")

var Lit_110 *jrt.String = jrt.Intern("Return a set of the declared fields of class as a Clojure map.")

var Lit_111 *jrt.String = jrt.Intern("typeref->class")

var Lit_112 *jrt.String = jrt.Intern("classloader")

var Lit_113 *jrt.String = jrt.Intern("arbace.reflect.JavaReflector")

var Lit_114 *jrt.String = jrt.Intern("->JavaReflector")

var Lit_115 *jrt.String = jrt.Intern("Positional factory function for class arbace.reflect.JavaReflector.")

var Lit_116 *jrt.String = jrt.Intern("default-reflector")

var Lit_117 *jrt.String = jrt.Intern("java.lang.Thread")

var Lit_118 *jrt.String = jrt.Intern("ClassResolver")

var Lit_119 *jrt.String = jrt.Intern("arbace.reflect.ClassResolver")

var Lit_120 *jrt.String = jrt.Intern("alter-meta!")

var Lit_121 *jrt.String = jrt.Intern("assoc")

var Lit_122 *jrt.String = jrt.Intern("assert-same-protocol")

var Lit_123 *jrt.String = jrt.Intern("resolve-class")

var Lit_124 *jrt.String = jrt.Intern("Given a class name, return that typeref's class bytes as an InputStream.")

var Lit_125 *jrt.String = jrt.Intern("this")

var Lit_126 *jrt.String = jrt.Intern("alter-var-root")

var Lit_127 *jrt.String = jrt.Intern("merge")

var Lit_128 *jrt.String = jrt.Intern("on")

var Lit_129 *jrt.String = jrt.Intern("on-interface")

var Lit_130 *jrt.String = jrt.Intern("sigs")

var Lit_131 *jrt.String = jrt.Intern("java.io.InputStream")

var Lit_132 *jrt.String = jrt.Intern("var")

var Lit_133 *jrt.String = jrt.Intern("method-map")

var Lit_134 *jrt.String = jrt.Intern("method-builders")

var Lit_135 *jrt.String = jrt.Intern("intern")

var Lit_136 *jrt.String = jrt.Intern("*ns*")

var Lit_137 *jrt.String = jrt.Intern("with-meta")

var Lit_138 *jrt.String = jrt.Intern("protocol")

var Lit_139 *jrt.String = jrt.Intern("-reset-methods")

var Lit_140 *jrt.String = jrt.Intern("arbace.lang.Fn")

var Lit_141 *jrt.String = jrt.Intern("java.lang.ClassLoader")

var Lit_142 *jrt.String = jrt.Intern("arbace.reflect.AsmReflector")

var Lit_143 *jrt.String = jrt.Intern("->AsmReflector")

var Lit_144 *jrt.String = jrt.Intern("class-resolver")

var Lit_145 *jrt.String = jrt.Intern("Positional factory function for class arbace.reflect.AsmReflector.")

var Lit_146 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_147 *jrt.String = jrt.Intern("getContextClassLoader")
