//line j2g_strings.ae:1
package aot_arbace_datafy

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn21,arbace.core.protocolskn2,asyn1,pyn11,arbace.corekn3,docks13,arbace.datafy3,objks13,arbace.datafy5,classkn4,namekn7,publicskn7,importskn7,internsys14,arbace.reflect7,reflectkn7,membersv11,arbace.core7,requireV3,R0,R1,R2,v11,arbace.core5,referR3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn13,arbace.datafym2,R4,s61,Functions to turn objects into data. Alpha, subject to changev21,arbace.core.protocols6,datafyv11,arbace.core9,vary-metav11,arbace.core5,assocR5,R6,v11,arbace.core6,symbolv11,arbace.core5,classv21,arbace.core.protocols3,navv11,arbace.core4,intov11,arbace.core10,sorted-mapv11,arbace.core14,Throwable->mapv11,arbace.core9,with-metaR7,R8,v13,arbace.datafy7,sortmapv11,arbace.core10,ns-publicsR9,v11,arbace.core10,ns-importsR10,v11,arbace.core10,ns-internsv11,arbace.core17,requiring-resolveR11,v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR12,v11,arbace.core8,group-by")

var Lit_1 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,xkn4,linekn6,columnkn4,fileyn4,collyn1,kyn1,vkn7,privateyn1,mkn6,datafyv11,arbace.core5,in-nsMyn13,arbace.datafym2,R0,s61,Functions to turn objects into data. Alpha, subject to changem2,R0,s61,Functions to turn objects into data. Alpha, subject to changeR1,v11,arbace.core20,*warn-on-reflection*v13,arbace.datafy6,datafym10,R2,L1,V1,R3,R0,s313,Attempts to return x as data.\n  datafy will return the value of arbace.core.protocols/datafy. If\n  the value has been transformed and the result supports\n  metadata, :arbace.datafy/obj will be set on the metadata to the\n  original value of x, and :arbace.datafy/class to the name of the\n  class of x, as a symbol.R4,i15,R5,i1,R6,s16,arbace/datafy.aev13,arbace.datafy3,navm10,R2,L1,V3,R7,R8,R9,R0,s308,Returns (possibly transformed) v in the context of coll and k (a\n  key/index or nil). Callers should attempt to provide the key/index\n  context k for Indexed/Associative/ILookup colls if possible, but not\n  to fabricate one e.g. for sequences (pass nil). nav returns the\n  value of arbace.core.protocols/nav.R4,i30,R5,i1,R6,s16,arbace/datafy.aev13,arbace.datafy7,sortmapm10,R10,TR2,L1,V1,R11,R4,i39,R5,i1,R6,s16,arbace/datafy.aev11,arbace.core6,extendC19,java.lang.Throwablev21,arbace.core.protocols10,DatafiableR12,C16,arbace.lang.IRefC21,arbace.lang.NamespaceC15,java.lang.Class")

var Lit_2 *jrt.String = jrt.Intern("arbace.datafy$eval985000004$loading__1927001464__auto____985000005")

var Lit_3 *jrt.String = jrt.Intern("arbace.datafy$eval985000008$fn__985000009")

var Lit_4 *jrt.String = jrt.Intern("arbace.datafy$datafy")

var Lit_5 *jrt.String = jrt.Intern("arbace.datafy$nav")

var Lit_6 *jrt.String = jrt.Intern("arbace.datafy$sortmap")

var Lit_7 *jrt.String = jrt.Intern("arbace.datafy$eval985000017$fn__985000018")

var Lit_8 *jrt.String = jrt.Intern("arbace.datafy$eval985000021$fn__985000022")

var Lit_9 *jrt.String = jrt.Intern("arbace.datafy$eval985000025$fn__985000026")

var Lit_10 *jrt.String = jrt.Intern("arbace.datafy$eval985000029$fn__985000030")
