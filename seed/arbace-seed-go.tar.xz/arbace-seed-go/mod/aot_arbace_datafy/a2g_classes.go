//line a2g_classes.ae:1
package aot_arbace_datafy

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_datafy_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_A_New()}; return nil }

var A_arbace_datafy_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_A_new}

var A_arbace_datafy_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_datafy.A_arbace_datafy_A"})

func init() { i := A_arbace_datafy_A_class.Info(); i.IsInstance = A_arbace_datafy_A_InstanceOf; i.Init = A_arbace_datafy_A_Init; i.Table = A_arbace_datafy_A_members; jrt.RegisterGoType(A_arbace_datafy_A_class, reflect.TypeFor[A_arbace_datafy_A]()) }

func A_arbace_datafy_datafy_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_datafy_datafy_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_datafy_datafy_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_datafy_A_New()}; return nil }

func A_arbace_datafy_datafy_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_datafy_datafy_A_fn_class)}; return nil }

var A_arbace_datafy_datafy_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_datafy_datafy_A_invoke, New: A_arbace_datafy_datafy_A_new, Get: A_arbace_datafy_datafy_A_get}

var A_arbace_datafy_datafy_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$datafy", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_datafy_A_class, Simple: "datafy", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_datafy_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy_datafy_A_class.Info(); i.IsInstance = A_arbace_datafy_datafy_A_InstanceOf; i.Init = A_arbace_datafy_datafy_A_Init; i.Table = A_arbace_datafy_datafy_A_members; jrt.RegisterGoType(A_arbace_datafy_datafy_A_class, reflect.TypeFor[A_arbace_datafy_datafy_A]()) }

func A_arbace_datafy_eval985000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000004_A_New()}; return nil }

var A_arbace_datafy_eval985000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000004_A_new}

var A_arbace_datafy_eval985000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000004", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000004_A"})

func init() { i := A_arbace_datafy_eval985000004_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000004_A_InstanceOf; i.Table = A_arbace_datafy_eval985000004_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000004_A_class, reflect.TypeFor[A_arbace_datafy_eval985000004_A]()) }

func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_New()}; return nil }

func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_fn_class)}; return nil }

var A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_invoke, New: A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_new, Get: A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_get}

var A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000004$loading__1927001464__auto____985000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_datafy_eval985000004_A_class, Simple: "loading__1927001464__auto____985000005", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_InstanceOf; i.Init = A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_Init; i.Table = A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_class, reflect.TypeFor[A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A]()) }

func A_arbace_datafy_eval985000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000008_A_New()}; return nil }

var A_arbace_datafy_eval985000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000008_A_new}

var A_arbace_datafy_eval985000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000008", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000008_A"})

func init() { i := A_arbace_datafy_eval985000008_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000008_A_InstanceOf; i.Table = A_arbace_datafy_eval985000008_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000008_A_class, reflect.TypeFor[A_arbace_datafy_eval985000008_A]()) }

func A_arbace_datafy_eval985000008_fn__985000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_datafy_eval985000008_fn__985000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_datafy_eval985000008_fn__985000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000008_fn__985000009_A_New()}; return nil }

func A_arbace_datafy_eval985000008_fn__985000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_datafy_eval985000008_fn__985000009_A_fn_class)}; return nil }

var A_arbace_datafy_eval985000008_fn__985000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_datafy_eval985000008_fn__985000009_A_invoke, New: A_arbace_datafy_eval985000008_fn__985000009_A_new, Get: A_arbace_datafy_eval985000008_fn__985000009_A_get}

var A_arbace_datafy_eval985000008_fn__985000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000008$fn__985000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_datafy_eval985000008_A_class, Simple: "fn__985000009", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000008_fn__985000009_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy_eval985000008_fn__985000009_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000008_fn__985000009_A_InstanceOf; i.Init = A_arbace_datafy_eval985000008_fn__985000009_A_Init; i.Table = A_arbace_datafy_eval985000008_fn__985000009_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000008_fn__985000009_A_class, reflect.TypeFor[A_arbace_datafy_eval985000008_fn__985000009_A]()) }

func A_arbace_datafy_eval985000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000017_A_New()}; return nil }

var A_arbace_datafy_eval985000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000017_A_new}

var A_arbace_datafy_eval985000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000017", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000017_A"})

func init() { i := A_arbace_datafy_eval985000017_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000017_A_InstanceOf; i.Table = A_arbace_datafy_eval985000017_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000017_A_class, reflect.TypeFor[A_arbace_datafy_eval985000017_A]()) }

func A_arbace_datafy_eval985000017_fn__985000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_datafy_eval985000017_fn__985000018_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_datafy_eval985000017_fn__985000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000017_fn__985000018_A_New()}; return nil }

func A_arbace_datafy_eval985000017_fn__985000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_datafy_eval985000017_fn__985000018_A_fn_class)}; return nil }

var A_arbace_datafy_eval985000017_fn__985000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_datafy_eval985000017_fn__985000018_A_invoke, New: A_arbace_datafy_eval985000017_fn__985000018_A_new, Get: A_arbace_datafy_eval985000017_fn__985000018_A_get}

var A_arbace_datafy_eval985000017_fn__985000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000017$fn__985000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_datafy_eval985000017_A_class, Simple: "fn__985000018", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000017_fn__985000018_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy_eval985000017_fn__985000018_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000017_fn__985000018_A_InstanceOf; i.Init = A_arbace_datafy_eval985000017_fn__985000018_A_Init; i.Table = A_arbace_datafy_eval985000017_fn__985000018_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000017_fn__985000018_A_class, reflect.TypeFor[A_arbace_datafy_eval985000017_fn__985000018_A]()) }

func A_arbace_datafy_eval985000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000021_A_New()}; return nil }

var A_arbace_datafy_eval985000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000021_A_new}

var A_arbace_datafy_eval985000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000021", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000021_A"})

func init() { i := A_arbace_datafy_eval985000021_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000021_A_InstanceOf; i.Table = A_arbace_datafy_eval985000021_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000021_A_class, reflect.TypeFor[A_arbace_datafy_eval985000021_A]()) }

func A_arbace_datafy_eval985000021_fn__985000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_datafy_eval985000021_fn__985000022_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_datafy_eval985000021_fn__985000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000021_fn__985000022_A_New()}; return nil }

func A_arbace_datafy_eval985000021_fn__985000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_datafy_eval985000021_fn__985000022_A_fn_class)}; return nil }

var A_arbace_datafy_eval985000021_fn__985000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_datafy_eval985000021_fn__985000022_A_invoke, New: A_arbace_datafy_eval985000021_fn__985000022_A_new, Get: A_arbace_datafy_eval985000021_fn__985000022_A_get}

var A_arbace_datafy_eval985000021_fn__985000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000021$fn__985000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_datafy_eval985000021_A_class, Simple: "fn__985000022", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000021_fn__985000022_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy_eval985000021_fn__985000022_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000021_fn__985000022_A_InstanceOf; i.Init = A_arbace_datafy_eval985000021_fn__985000022_A_Init; i.Table = A_arbace_datafy_eval985000021_fn__985000022_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000021_fn__985000022_A_class, reflect.TypeFor[A_arbace_datafy_eval985000021_fn__985000022_A]()) }

func A_arbace_datafy_eval985000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000025_A_New()}; return nil }

var A_arbace_datafy_eval985000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000025_A_new}

var A_arbace_datafy_eval985000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000025", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000025_A"})

func init() { i := A_arbace_datafy_eval985000025_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000025_A_InstanceOf; i.Table = A_arbace_datafy_eval985000025_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000025_A_class, reflect.TypeFor[A_arbace_datafy_eval985000025_A]()) }

func A_arbace_datafy_eval985000025_fn__985000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_datafy_eval985000025_fn__985000026_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_datafy_eval985000025_fn__985000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000025_fn__985000026_A_New()}; return nil }

func A_arbace_datafy_eval985000025_fn__985000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_datafy_eval985000025_fn__985000026_A_fn_class)}; return nil }

var A_arbace_datafy_eval985000025_fn__985000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_datafy_eval985000025_fn__985000026_A_invoke, New: A_arbace_datafy_eval985000025_fn__985000026_A_new, Get: A_arbace_datafy_eval985000025_fn__985000026_A_get}

var A_arbace_datafy_eval985000025_fn__985000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000025$fn__985000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_datafy_eval985000025_A_class, Simple: "fn__985000026", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000025_fn__985000026_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy_eval985000025_fn__985000026_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000025_fn__985000026_A_InstanceOf; i.Init = A_arbace_datafy_eval985000025_fn__985000026_A_Init; i.Table = A_arbace_datafy_eval985000025_fn__985000026_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000025_fn__985000026_A_class, reflect.TypeFor[A_arbace_datafy_eval985000025_fn__985000026_A]()) }

func A_arbace_datafy_eval985000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000029_A_New()}; return nil }

var A_arbace_datafy_eval985000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000029_A_new}

var A_arbace_datafy_eval985000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000029", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000029_A"})

func init() { i := A_arbace_datafy_eval985000029_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000029_A_InstanceOf; i.Table = A_arbace_datafy_eval985000029_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000029_A_class, reflect.TypeFor[A_arbace_datafy_eval985000029_A]()) }

func A_arbace_datafy_eval985000029_fn__985000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_datafy_eval985000029_fn__985000030_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_datafy_eval985000029_fn__985000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000029_fn__985000030_A_New()}; return nil }

func A_arbace_datafy_eval985000029_fn__985000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_datafy_eval985000029_fn__985000030_A_fn_class)}; return nil }

var A_arbace_datafy_eval985000029_fn__985000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_datafy_eval985000029_fn__985000030_A_invoke, New: A_arbace_datafy_eval985000029_fn__985000030_A_new, Get: A_arbace_datafy_eval985000029_fn__985000030_A_get}

var A_arbace_datafy_eval985000029_fn__985000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000029$fn__985000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_datafy_eval985000029_A_class, Simple: "fn__985000030", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000029_fn__985000030_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy_eval985000029_fn__985000030_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000029_fn__985000030_A_InstanceOf; i.Init = A_arbace_datafy_eval985000029_fn__985000030_A_Init; i.Table = A_arbace_datafy_eval985000029_fn__985000030_A_members; jrt.RegisterGoType(A_arbace_datafy_eval985000029_fn__985000030_A_class, reflect.TypeFor[A_arbace_datafy_eval985000029_fn__985000030_A]()) }

func A_arbace_datafy_nav_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_datafy_nav_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_datafy_nav_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_nav_A_New()}; return nil }

func A_arbace_datafy_nav_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_datafy_nav_A_fn_class)}; return nil }

var A_arbace_datafy_nav_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_datafy_nav_A_invoke, New: A_arbace_datafy_nav_A_new, Get: A_arbace_datafy_nav_A_get}

var A_arbace_datafy_nav_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$nav", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_datafy_A_class, Simple: "nav", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_nav_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy_nav_A_class.Info(); i.IsInstance = A_arbace_datafy_nav_A_InstanceOf; i.Init = A_arbace_datafy_nav_A_Init; i.Table = A_arbace_datafy_nav_A_members; jrt.RegisterGoType(A_arbace_datafy_nav_A_class, reflect.TypeFor[A_arbace_datafy_nav_A]()) }

func A_arbace_datafy_sortmap_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_datafy_sortmap_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_datafy_sortmap_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_sortmap_A_New()}; return nil }

func A_arbace_datafy_sortmap_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_datafy_sortmap_A_fn_class)}; return nil }

var A_arbace_datafy_sortmap_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_datafy_sortmap_A_invoke, New: A_arbace_datafy_sortmap_A_new, Get: A_arbace_datafy_sortmap_A_get}

var A_arbace_datafy_sortmap_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$sortmap", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_datafy_A_class, Simple: "sortmap", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_sortmap_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy_sortmap_A_class.Info(); i.IsInstance = A_arbace_datafy_sortmap_A_InstanceOf; i.Init = A_arbace_datafy_sortmap_A_Init; i.Table = A_arbace_datafy_sortmap_A_members; jrt.RegisterGoType(A_arbace_datafy_sortmap_A_class, reflect.TypeFor[A_arbace_datafy_sortmap_A]()) }

func A_arbace_datafy__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_datafy__init_A_Load__O(); case 1: return A_arbace_datafy__init_A_Unit0__O(); case 2: return A_arbace_datafy__init_A_Unit1__O(); case 3: return A_arbace_datafy__init_A_Unit10__O(); case 4: return A_arbace_datafy__init_A_Unit11__O(); case 5: return A_arbace_datafy__init_A_Unit2__O(); case 6: return A_arbace_datafy__init_A_Unit3__O(); case 7: return A_arbace_datafy__init_A_Unit4__O(); case 8: return A_arbace_datafy__init_A_Unit5__O(); case 9: return A_arbace_datafy__init_A_Unit6__O(); case 10: return A_arbace_datafy__init_A_Unit7__O(); case 11: return A_arbace_datafy__init_A_Unit8__O(); case 12: return A_arbace_datafy__init_A_Unit9__O()}; return nil }

func A_arbace_datafy__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy__init_A_New()}; return nil }

var A_arbace_datafy__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_datafy__init_A_invoke, New: A_arbace_datafy__init_A_new}

var A_arbace_datafy__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_datafy.A_arbace_datafy__init_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy__init_A_class.Info(); i.IsInstance = A_arbace_datafy__init_A_InstanceOf; i.Init = A_arbace_datafy__init_A_Init; i.Table = A_arbace_datafy__init_A_members; jrt.RegisterGoType(A_arbace_datafy__init_A_class, reflect.TypeFor[A_arbace_datafy__init_A]()) }
