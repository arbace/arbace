//line a2g_classes.ae:1
package aot_arbace_datafy

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_datafy_datafy_A_class, Name: "arbace.datafy$datafy", Modifiers: 25, Simple: "datafy", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_datafy_A", Source: "datafy.ae", Declaring: &A_arbace_datafy_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_class, Name: "arbace.datafy$eval985000004$loading__1927001464__auto____985000005", Modifiers: 25, Simple: "loading__1927001464__auto____985000005", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A", Source: "datafy.ae", Declaring: &A_arbace_datafy_eval985000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_datafy_eval985000008_fn__985000009_A_class, Name: "arbace.datafy$eval985000008$fn__985000009", Modifiers: 25, Simple: "fn__985000009", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000008_fn__985000009_A", Source: "datafy.ae", Declaring: &A_arbace_datafy_eval985000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_datafy_eval985000017_fn__985000018_A_class, Name: "arbace.datafy$eval985000017$fn__985000018", Modifiers: 25, Simple: "fn__985000018", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000017_fn__985000018_A", Source: "datafy.ae", Declaring: &A_arbace_datafy_eval985000017_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_datafy_eval985000021_fn__985000022_A_class, Name: "arbace.datafy$eval985000021$fn__985000022", Modifiers: 25, Simple: "fn__985000022", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000021_fn__985000022_A", Source: "datafy.ae", Declaring: &A_arbace_datafy_eval985000021_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_datafy_eval985000025_fn__985000026_A_class, Name: "arbace.datafy$eval985000025$fn__985000026", Modifiers: 25, Simple: "fn__985000026", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000025_fn__985000026_A", Source: "datafy.ae", Declaring: &A_arbace_datafy_eval985000025_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_datafy_eval985000029_fn__985000030_A_class, Name: "arbace.datafy$eval985000029$fn__985000030", Modifiers: 25, Simple: "fn__985000030", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000029_fn__985000030_A", Source: "datafy.ae", Declaring: &A_arbace_datafy_eval985000029_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_datafy_nav_A_class, Name: "arbace.datafy$nav", Modifiers: 25, Simple: "nav", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_nav_A", Source: "datafy.ae", Declaring: &A_arbace_datafy_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_datafy_sortmap_A_class, Name: "arbace.datafy$sortmap", Modifiers: 25, Simple: "sortmap", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_sortmap_A", Source: "datafy.ae", Declaring: &A_arbace_datafy_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_datafy_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_A_New()}; return nil }

var A_arbace_datafy_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_A_new}

var A_arbace_datafy_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_datafy.A_arbace_datafy_A"})

func init() { i := A_arbace_datafy_A_class.Info(); i.IsInstance = A_arbace_datafy_A_InstanceOf; i.Init = A_arbace_datafy_A_Init; i.Table = A_arbace_datafy_A_members }

var A_arbace_datafy_datafy_A_class *jrt.Class

func A_arbace_datafy_eval985000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000004_A_New()}; return nil }

var A_arbace_datafy_eval985000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000004_A_new}

var A_arbace_datafy_eval985000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000004", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000004_A"})

func init() { i := A_arbace_datafy_eval985000004_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000004_A_InstanceOf; i.Table = A_arbace_datafy_eval985000004_A_members }

var A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_class *jrt.Class

func A_arbace_datafy_eval985000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000008_A_New()}; return nil }

var A_arbace_datafy_eval985000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000008_A_new}

var A_arbace_datafy_eval985000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000008", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000008_A"})

func init() { i := A_arbace_datafy_eval985000008_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000008_A_InstanceOf; i.Table = A_arbace_datafy_eval985000008_A_members }

var A_arbace_datafy_eval985000008_fn__985000009_A_class *jrt.Class

func A_arbace_datafy_eval985000017_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000017_A_New()}; return nil }

var A_arbace_datafy_eval985000017_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000017_A_new}

var A_arbace_datafy_eval985000017_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000017", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000017", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000017_A"})

func init() { i := A_arbace_datafy_eval985000017_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000017_A_InstanceOf; i.Table = A_arbace_datafy_eval985000017_A_members }

var A_arbace_datafy_eval985000017_fn__985000018_A_class *jrt.Class

func A_arbace_datafy_eval985000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000021_A_New()}; return nil }

var A_arbace_datafy_eval985000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000021_A_new}

var A_arbace_datafy_eval985000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000021", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000021_A"})

func init() { i := A_arbace_datafy_eval985000021_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000021_A_InstanceOf; i.Table = A_arbace_datafy_eval985000021_A_members }

var A_arbace_datafy_eval985000021_fn__985000022_A_class *jrt.Class

func A_arbace_datafy_eval985000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000025_A_New()}; return nil }

var A_arbace_datafy_eval985000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000025_A_new}

var A_arbace_datafy_eval985000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000025", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000025_A"})

func init() { i := A_arbace_datafy_eval985000025_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000025_A_InstanceOf; i.Table = A_arbace_datafy_eval985000025_A_members }

var A_arbace_datafy_eval985000025_fn__985000026_A_class *jrt.Class

func A_arbace_datafy_eval985000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy_eval985000029_A_New()}; return nil }

var A_arbace_datafy_eval985000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_datafy_eval985000029_A_new}

var A_arbace_datafy_eval985000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy$eval985000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_datafy_A_class, Simple: "eval985000029", Go: "arbace/aot_arbace_datafy.A_arbace_datafy_eval985000029_A"})

func init() { i := A_arbace_datafy_eval985000029_A_class.Info(); i.IsInstance = A_arbace_datafy_eval985000029_A_InstanceOf; i.Table = A_arbace_datafy_eval985000029_A_members }

var A_arbace_datafy_eval985000029_fn__985000030_A_class *jrt.Class

var A_arbace_datafy_nav_A_class *jrt.Class

var A_arbace_datafy_sortmap_A_class *jrt.Class

func A_arbace_datafy__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_datafy__init_A_Load__O()}; return nil }

func A_arbace_datafy__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_datafy__init_A_New()}; return nil }

var A_arbace_datafy__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_datafy__init_A_invoke, New: A_arbace_datafy__init_A_new}

var A_arbace_datafy__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.datafy__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_datafy.A_arbace_datafy__init_A", Source: "datafy.ae"})

func init() { i := A_arbace_datafy__init_A_class.Info(); i.IsInstance = A_arbace_datafy__init_A_InstanceOf; i.Init = A_arbace_datafy__init_A_Init; i.Table = A_arbace_datafy__init_A_members }
