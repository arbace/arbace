//line a2g_strings.ae:1
package aot_arbace_datafy

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.core.protocols")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("p")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.datafy")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("Functions to turn objects into data. Alpha, subject to change")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("datafy")

var Lit_14 *jrt.String = jrt.Intern("vary-meta")

var Lit_15 *jrt.String = jrt.Intern("assoc")

var Lit_16 *jrt.String = jrt.Intern("obj")

var Lit_17 *jrt.String = jrt.Intern("class")

var Lit_18 *jrt.String = jrt.Intern("symbol")

var Lit_19 *jrt.String = jrt.Intern("nav")

var Lit_20 *jrt.String = jrt.Intern("into")

var Lit_21 *jrt.String = jrt.Intern("sorted-map")

var Lit_22 *jrt.String = jrt.Intern("Throwable->map")

var Lit_23 *jrt.String = jrt.Intern("with-meta")

var Lit_24 *jrt.String = jrt.Intern("name")

var Lit_25 *jrt.String = jrt.Intern("publics")

var Lit_26 *jrt.String = jrt.Intern("sortmap")

var Lit_27 *jrt.String = jrt.Intern("imports")

var Lit_28 *jrt.String = jrt.Intern("interns")

var Lit_29 *jrt.String = jrt.Intern("ns-publics")

var Lit_30 *jrt.String = jrt.Intern("ns-imports")

var Lit_31 *jrt.String = jrt.Intern("ns-interns")

var Lit_32 *jrt.String = jrt.Intern("requiring-resolve")

var Lit_33 *jrt.String = jrt.Intern("next")

var Lit_34 *jrt.String = jrt.Intern("to-array")

var Lit_35 *jrt.String = jrt.Intern("seq")

var Lit_36 *jrt.String = jrt.Intern("first")

var Lit_37 *jrt.String = jrt.Intern("members")

var Lit_38 *jrt.String = jrt.Intern("arbace.reflect")

var Lit_39 *jrt.String = jrt.Intern("reflect")

var Lit_40 *jrt.String = jrt.Intern("group-by")

var Lit_41 *jrt.String = jrt.Intern("arbace.datafy$datafy")

var Lit_42 *jrt.String = jrt.Intern("arbace.datafy$eval985000004$loading__1927001464__auto____985000005")

var Lit_43 *jrt.String = jrt.Intern("arbace.datafy$eval985000008$fn__985000009")

var Lit_44 *jrt.String = jrt.Intern("arbace.datafy$eval985000017$fn__985000018")

var Lit_45 *jrt.String = jrt.Intern("arbace.datafy$eval985000021$fn__985000022")

var Lit_46 *jrt.String = jrt.Intern("arbace.datafy$eval985000025$fn__985000026")

var Lit_47 *jrt.String = jrt.Intern("arbace.datafy$eval985000029$fn__985000030")

var Lit_48 *jrt.String = jrt.Intern("arbace.datafy$nav")

var Lit_49 *jrt.String = jrt.Intern("arbace.datafy$sortmap")

var Lit_50 *jrt.String = jrt.Intern("in-ns")

var Lit_51 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_52 *jrt.String = jrt.Intern("arglists")

var Lit_53 *jrt.String = jrt.Intern("x")

var Lit_54 *jrt.String = jrt.Intern("Attempts to return x as data.\n  datafy will return the value of arbace.core.protocols/datafy. If\n  the value has been transformed and the result supports\n  metadata, :arbace.datafy/obj will be set on the metadata to the\n  original value of x, and :arbace.datafy/class to the name of the\n  class of x, as a symbol.")

var Lit_55 *jrt.String = jrt.Intern("line")

var Lit_56 *jrt.String = jrt.Intern("column")

var Lit_57 *jrt.String = jrt.Intern("file")

var Lit_58 *jrt.String = jrt.Intern("arbace/datafy.ae")

var Lit_59 *jrt.String = jrt.Intern("coll")

var Lit_60 *jrt.String = jrt.Intern("k")

var Lit_61 *jrt.String = jrt.Intern("v")

var Lit_62 *jrt.String = jrt.Intern("Returns (possibly transformed) v in the context of coll and k (a\n  key/index or nil). Callers should attempt to provide the key/index\n  context k for Indexed/Associative/ILookup colls if possible, but not\n  to fabricate one e.g. for sequences (pass nil). nav returns the\n  value of arbace.core.protocols/nav.")

var Lit_63 *jrt.String = jrt.Intern("private")

var Lit_64 *jrt.String = jrt.Intern("m")

var Lit_65 *jrt.String = jrt.Intern("extend")

var Lit_66 *jrt.String = jrt.Intern("java.lang.Throwable")

var Lit_67 *jrt.String = jrt.Intern("Datafiable")

var Lit_68 *jrt.String = jrt.Intern("arbace.lang.IRef")

var Lit_69 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_70 *jrt.String = jrt.Intern("java.lang.Class")
