//line aot_arbace_datafy.ae:1
package aot_arbace_datafy

import (
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_New() *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A { A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_Init(); t := &A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_datafy_A_Init(); tmp4 = A_arbace_datafy_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_datafy_A_Init(); tmp6 = A_arbace_datafy_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_datafy_A_Init(); tmp7 = A_arbace_datafy_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_datafy_A_Init(); tmp9 = A_arbace_datafy_A_const_3; tmp3 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :9:1
func A_arbace_datafy_eval985000008_fn__985000009_A_New() *A_arbace_datafy_eval985000008_fn__985000009_A { A_arbace_datafy_eval985000008_fn__985000009_A_Init(); t := &A_arbace_datafy_eval985000008_fn__985000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_datafy_eval985000008_fn__985000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_datafy_eval985000008_fn__985000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_datafy_A_Init(); tmp1 = A_arbace_datafy_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_datafy_A_Init(); tmp3 = A_arbace_datafy_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_datafy_A_Init(); tmp5 = A_arbace_datafy_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_datafy_A_Init(); tmp7 = A_arbace_datafy_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_datafy_A_Init(); tmp9 = A_arbace_datafy_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }





func A_arbace_datafy_datafy_A_New() *A_arbace_datafy_datafy_A { A_arbace_datafy_datafy_A_Init(); t := &A_arbace_datafy_datafy_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_datafy_datafy_A) Ctor() {}
//line :15:1
func (t *A_arbace_datafy_datafy_A) Invoke_O_O__O(self, x__0 any) any { var v__2 any; var target_1 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 =







	aot_arbace_core_protocols.A_arbace_core_protocols_Datafiable_A_InstanceOf(target_1); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp1 = tmp2; if tmp1 { v__2 = aot_arbace_core_protocols.A_arbace_core_protocols_Datafiable_A_Cast(target_1).Datafy__O() } else { var tmp3 *lang.Var; A_arbace_datafy_A_Init(); tmp3 = A_arbace_datafy_A_const_9; v__2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(target_1) }; if
	lang.Util_Identical_O_O__Z(v__2, x__0) { return v__2 } else {

		if lang.IObj_InstanceOf(v__2) {
			var tmp4 *lang.Var; A_arbace_datafy_A_Init(); tmp4 = A_arbace_datafy_A_const_10; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_datafy_A_Init(); tmp6 = A_arbace_datafy_A_const_11; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 *lang.Keyword; A_arbace_datafy_A_Init(); tmp8 = A_arbace_datafy_A_const_12; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_datafy_A_Init(); tmp10 = A_arbace_datafy_A_const_13; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_datafy_A_Init(); tmp12 = A_arbace_datafy_A_const_14; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_datafy_A_Init(); tmp14 = A_arbace_datafy_A_const_15; return tmp5.Invoke_O_O_O_O_O_O__O(v__2, tmp7, tmp9, x__0, tmp11, tmp13.Invoke_O__O(jrt.NN(jrt.Class_Cast(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(x__0))).GetName__String().Ref())) } else {
//line :26:1
				return v__2 } } }



func A_arbace_datafy_nav_A_New() *A_arbace_datafy_nav_A { A_arbace_datafy_nav_A_Init(); t := &A_arbace_datafy_nav_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_datafy_nav_A) Ctor() {}
//line :30:1
func (t *A_arbace_datafy_nav_A) Invoke_O_O_O_O__O(self, coll__0, k__1, v__2 any) any {






	var target_2 any = coll__0; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_Navigable_A_InstanceOf(target_2); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_2) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_Navigable_A_Cast(target_2).Nav_O_O__O(k__1, v__2) } else { var tmp3 *lang.Var; A_arbace_datafy_A_Init(); tmp3 = A_arbace_datafy_A_const_16; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O__O(target_2, k__1, v__2)
	} }
func A_arbace_datafy_sortmap_A_New() *A_arbace_datafy_sortmap_A { A_arbace_datafy_sortmap_A_Init(); t := &A_arbace_datafy_sortmap_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_datafy_sortmap_A) Ctor() {}
//line :39:1
func (t *A_arbace_datafy_sortmap_A) Invoke_O_O__O(self, m__0 any) any {
	var tmp1 *lang.Var; A_arbace_datafy_A_Init(); tmp1 = A_arbace_datafy_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_datafy_A_Init(); tmp3 = A_arbace_datafy_A_const_18; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke__O(), m__0)
}
func A_arbace_datafy_eval985000017_fn__985000018_A_New() *A_arbace_datafy_eval985000017_fn__985000018_A { A_arbace_datafy_eval985000017_fn__985000018_A_Init(); t := &A_arbace_datafy_eval985000017_fn__985000018_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000017_fn__985000018_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000017_fn__985000018_A) Invoke_O_O__O(self, x__1 any) any {


	var tmp1 *lang.Var; A_arbace_datafy_A_Init(); tmp1 = A_arbace_datafy_A_const_19; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__1) }
//line :42:1
func A_arbace_datafy_eval985000021_fn__985000022_A_New() *A_arbace_datafy_eval985000021_fn__985000022_A { A_arbace_datafy_eval985000021_fn__985000022_A_Init(); t := &A_arbace_datafy_eval985000021_fn__985000022_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000021_fn__985000022_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000021_fn__985000022_A) Invoke_O_O__O(self, r__1 any) any {






	var tmp1 *lang.Var; A_arbace_datafy_A_Init(); tmp1 = A_arbace_datafy_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_datafy_A_Init(); tmp3 = A_arbace_datafy_A_const_5; return tmp2.Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(r__1)), lang.RT_Meta_O__IPersistentMap(r__1)) }
//line :42:1
func A_arbace_datafy_eval985000025_fn__985000026_A_New() *A_arbace_datafy_eval985000025_fn__985000026_A { A_arbace_datafy_eval985000025_fn__985000026_A_Init(); t := &A_arbace_datafy_eval985000025_fn__985000026_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000025_fn__985000026_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000025_fn__985000026_A) Invoke_O_O__O(self, n__1 any) any {










	var tmp1 *lang.Var; A_arbace_datafy_A_Init(); tmp1 = A_arbace_datafy_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_datafy_A_Init(); tmp3 = A_arbace_datafy_A_const_21; var tmp4 any = tmp3.Ref(); var tmp5 any = jrt.NN(lang.Namespace_Cast(n__1)).GetName__Symbol().Ref(); var tmp6 *lang.Keyword; A_arbace_datafy_A_Init(); tmp6 = A_arbace_datafy_A_const_22; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_datafy_A_Init(); tmp8 = A_arbace_datafy_A_const_23; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_datafy_A_Init(); tmp10 = A_arbace_datafy_A_const_26; var tmp11 any = tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(n__1)); var tmp12 *lang.Keyword; A_arbace_datafy_A_Init(); tmp12 = A_arbace_datafy_A_const_24; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Var; A_arbace_datafy_A_Init(); tmp14 = A_arbace_datafy_A_const_23; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_datafy_A_Init(); tmp16 = A_arbace_datafy_A_const_27; var tmp17 any = tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(n__1)); var tmp18 *lang.Keyword; A_arbace_datafy_A_Init(); tmp18 = A_arbace_datafy_A_const_25; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Var; A_arbace_datafy_A_Init(); tmp20 = A_arbace_datafy_A_const_23; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_datafy_A_Init(); tmp22 = A_arbace_datafy_A_const_28; return tmp2.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp7, tmp11, tmp13, tmp17, tmp19, tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(n__1)))), lang.RT_Meta_O__IPersistentMap(n__1)) }
//line :42:1
func A_arbace_datafy_eval985000029_fn__985000030_A_New() *A_arbace_datafy_eval985000029_fn__985000030_A { A_arbace_datafy_eval985000029_fn__985000030_A_Init(); t := &A_arbace_datafy_eval985000029_fn__985000030_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000029_fn__985000030_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000029_fn__985000030_A) Invoke_O_O__O(self, c__1 any) any { var map__985000031__2 any; var tmp1 *lang.Var;


















	A_arbace_datafy_A_Init(); tmp1 = A_arbace_datafy_A_const_29; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_datafy_A_Init(); tmp3 = A_arbace_datafy_A_const_35; map__985000031__2 = lang.IFn_Cast(tmp2.Invoke_O__O(tmp3)).Invoke_O__O(c__1); var map__985000031__3 any; if lang.ISeq_InstanceOf(map__985000031__2) { var tmp4 *lang.Var; A_arbace_datafy_A_Init(); tmp4 = A_arbace_datafy_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__985000031__2)) { var tmp5 *lang.Var; A_arbace_datafy_A_Init(); tmp5 = A_arbace_datafy_A_const_31; map__985000031__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__985000031__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 *lang.Var; A_arbace_datafy_A_Init(); tmp6 = A_arbace_datafy_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(map__985000031__2)) { var tmp7 *lang.Var; A_arbace_datafy_A_Init(); tmp7 = A_arbace_datafy_A_const_33; map__985000031__3 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(map__985000031__2) } else { lang.PersistentArrayMap_Init(); map__985000031__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__985000031__3 = map__985000031__2 }; var ret__4 any = map__985000031__3; var members__5 any; var tmp8 /*line :42:1*/*lang.Keyword;


















	A_arbace_datafy_A_Init(); tmp8 = A_arbace_datafy_A_const_34; members__5 = lang.RT_Get_O_O__O(map__985000031__3, tmp8.Ref()); var tmp9 /*line :62:1*/*lang.Var; A_arbace_datafy_A_Init(); tmp9 = A_arbace_datafy_A_const_11; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_datafy_A_Init(); tmp11 = A_arbace_datafy_A_const_21; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Var; A_arbace_datafy_A_Init(); tmp13 = A_arbace_datafy_A_const_14; var tmp14 any = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()); var tmp15 *lang.Keyword; A_arbace_datafy_A_Init(); tmp15 = A_arbace_datafy_A_const_34; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Var; A_arbace_datafy_A_Init(); tmp17 = A_arbace_datafy_A_const_23; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_datafy_A_Init(); tmp19 = A_arbace_datafy_A_const_36; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_datafy_A_Init(); tmp21 = A_arbace_datafy_A_const_21; return tmp10.Invoke_O_O_O_O_O__O(ret__4, tmp12, tmp14, tmp16, tmp18.Invoke_O__O(tmp20.Invoke_O_O__O(tmp21.Ref(), members__5))) }








type A_arbace_datafy_A struct{ jrt.Object }

var A_arbace_datafy_A_const_0 *lang.Var

var A_arbace_datafy_A_const_1 *lang.Var

var A_arbace_datafy_A_const_2 any

var A_arbace_datafy_A_const_3 any

var A_arbace_datafy_A_const_4 *lang.Var

var A_arbace_datafy_A_const_5 *lang.Var

var A_arbace_datafy_A_const_6 *lang.Var

var A_arbace_datafy_A_const_7 any

var A_arbace_datafy_A_const_8 *lang.Var

var A_arbace_datafy_A_const_9 *lang.Var

var A_arbace_datafy_A_const_10 *lang.Var

var A_arbace_datafy_A_const_11 *lang.Var

var A_arbace_datafy_A_const_12 *lang.Keyword

var A_arbace_datafy_A_const_13 *lang.Keyword

var A_arbace_datafy_A_const_14 *lang.Var

var A_arbace_datafy_A_const_15 *lang.Var

var A_arbace_datafy_A_const_16 *lang.Var

var A_arbace_datafy_A_const_17 *lang.Var

var A_arbace_datafy_A_const_18 *lang.Var

var A_arbace_datafy_A_const_19 *lang.Var

var A_arbace_datafy_A_const_20 *lang.Var

var A_arbace_datafy_A_const_21 *lang.Keyword

var A_arbace_datafy_A_const_22 *lang.Keyword

var A_arbace_datafy_A_const_23 *lang.Var

var A_arbace_datafy_A_const_24 *lang.Keyword

var A_arbace_datafy_A_const_25 *lang.Keyword

var A_arbace_datafy_A_const_26 *lang.Var

var A_arbace_datafy_A_const_27 *lang.Var

var A_arbace_datafy_A_const_28 *lang.Var

var A_arbace_datafy_A_const_29 *lang.Var

var A_arbace_datafy_A_const_30 *lang.Var

var A_arbace_datafy_A_const_31 *lang.Var

var A_arbace_datafy_A_const_32 *lang.Var

var A_arbace_datafy_A_const_33 *lang.Var

var A_arbace_datafy_A_const_34 *lang.Keyword

var A_arbace_datafy_A_const_35 any

var A_arbace_datafy_A_const_36 *lang.Var

var A_arbace_datafy_A_init jrt.ClassInit

func A_arbace_datafy_A_Init() { if !A_arbace_datafy_A_init.Done() { A_arbace_datafy_A_init.Run(A_arbace_datafy_A_clinit) } }

func A_arbace_datafy_A_clinit() { A_arbace_datafy_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_datafy_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_datafy_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_datafy_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_datafy_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_datafy_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_datafy_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_datafy_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_datafy_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_datafy_A_const_9 = lang.RT_Var_String_String__Var(Lit_3, Lit_13); A_arbace_datafy_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_datafy_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_datafy_A_const_12 = lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_16); A_arbace_datafy_A_const_13 = lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_17); A_arbace_datafy_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_datafy_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_datafy_A_const_16 = lang.RT_Var_String_String__Var(Lit_3, Lit_19); A_arbace_datafy_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_datafy_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_datafy_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_datafy_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_datafy_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_24); A_arbace_datafy_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_datafy_A_const_23 = lang.RT_Var_String_String__Var(Lit_9, Lit_26); A_arbace_datafy_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_datafy_A_const_25 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_datafy_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_datafy_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_datafy_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_datafy_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_datafy_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_datafy_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_datafy_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_datafy_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_datafy_A_const_34 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_datafy_A_const_35 = lang.Symbol_Intern_String_String__Symbol(Lit_38, Lit_39).Ref(); A_arbace_datafy_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_40) }

func A_arbace_datafy_A_New() *A_arbace_datafy_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_A) Ctor() {}

func (t *A_arbace_datafy_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_A_class }

func (t *A_arbace_datafy_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_A); return ok }

func A_arbace_datafy_A_Cast(x any) *A_arbace_datafy_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_A_class)) }; return v }



type A_arbace_datafy_datafy_A struct{ jrt.Object }

func (t *A_arbace_datafy_datafy_A) Is_Compiler_AOTF1() {}

var A_arbace_datafy_datafy_A_fn_class *jrt.Class

var A_arbace_datafy_datafy_A_init jrt.ClassInit

func A_arbace_datafy_datafy_A_Init() { if !A_arbace_datafy_datafy_A_init.Done() { A_arbace_datafy_datafy_A_init.Run(A_arbace_datafy_datafy_A_clinit) } }

func A_arbace_datafy_datafy_A_clinit() { A_arbace_datafy_datafy_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_41, lang.Compiler_AOTFn_class) }

func (t *A_arbace_datafy_datafy_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_datafy_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_datafy_A_class }

func (t *A_arbace_datafy_datafy_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_datafy_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_datafy_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_datafy_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_datafy_A); return ok }

func A_arbace_datafy_datafy_A_Cast(x any) *A_arbace_datafy_datafy_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_datafy_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_datafy_A_class)) }; return v }



type A_arbace_datafy_eval985000004_A struct{ jrt.Object }

func A_arbace_datafy_eval985000004_A_New() *A_arbace_datafy_eval985000004_A { t := &A_arbace_datafy_eval985000004_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000004_A) Ctor() {}

func (t *A_arbace_datafy_eval985000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000004_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000004_A_class }

func (t *A_arbace_datafy_eval985000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000004_A); return ok }

func A_arbace_datafy_eval985000004_A_Cast(x any) *A_arbace_datafy_eval985000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000004_A_class)) }; return v }



type A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A struct{ jrt.Object }

func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) Is_Compiler_AOTF0() {}

var A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_fn_class *jrt.Class

var A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_init jrt.ClassInit

func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_Init() { if !A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_init.Done() { A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_init.Run(A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_clinit) } }

func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_clinit() { A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_42, lang.Compiler_AOTFn_class) }

func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_class }

func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A); return ok }

func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_Cast(x any) *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_class)) }; return v }



type A_arbace_datafy_eval985000008_A struct{ jrt.Object }

func A_arbace_datafy_eval985000008_A_New() *A_arbace_datafy_eval985000008_A { t := &A_arbace_datafy_eval985000008_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000008_A) Ctor() {}

func (t *A_arbace_datafy_eval985000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000008_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000008_A_class }

func (t *A_arbace_datafy_eval985000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000008_A); return ok }

func A_arbace_datafy_eval985000008_A_Cast(x any) *A_arbace_datafy_eval985000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000008_A_class)) }; return v }



type A_arbace_datafy_eval985000008_fn__985000009_A struct{ jrt.Object }

func (t *A_arbace_datafy_eval985000008_fn__985000009_A) Is_Compiler_AOTF0() {}

var A_arbace_datafy_eval985000008_fn__985000009_A_fn_class *jrt.Class

var A_arbace_datafy_eval985000008_fn__985000009_A_init jrt.ClassInit

func A_arbace_datafy_eval985000008_fn__985000009_A_Init() { if !A_arbace_datafy_eval985000008_fn__985000009_A_init.Done() { A_arbace_datafy_eval985000008_fn__985000009_A_init.Run(A_arbace_datafy_eval985000008_fn__985000009_A_clinit) } }

func A_arbace_datafy_eval985000008_fn__985000009_A_clinit() { A_arbace_datafy_eval985000008_fn__985000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_43, lang.Compiler_AOTFn_class) }

func (t *A_arbace_datafy_eval985000008_fn__985000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000008_fn__985000009_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000008_fn__985000009_A_class }

func (t *A_arbace_datafy_eval985000008_fn__985000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000008_fn__985000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000008_fn__985000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000008_fn__985000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000008_fn__985000009_A); return ok }

func A_arbace_datafy_eval985000008_fn__985000009_A_Cast(x any) *A_arbace_datafy_eval985000008_fn__985000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000008_fn__985000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000008_fn__985000009_A_class)) }; return v }



type A_arbace_datafy_eval985000017_A struct{ jrt.Object }

func A_arbace_datafy_eval985000017_A_New() *A_arbace_datafy_eval985000017_A { t := &A_arbace_datafy_eval985000017_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000017_A) Ctor() {}

func (t *A_arbace_datafy_eval985000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000017_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000017_A_class }

func (t *A_arbace_datafy_eval985000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000017_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000017_A); return ok }

func A_arbace_datafy_eval985000017_A_Cast(x any) *A_arbace_datafy_eval985000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000017_A_class)) }; return v }



type A_arbace_datafy_eval985000017_fn__985000018_A struct{ jrt.Object }

func (t *A_arbace_datafy_eval985000017_fn__985000018_A) Is_Compiler_AOTF1() {}

var A_arbace_datafy_eval985000017_fn__985000018_A_fn_class *jrt.Class

var A_arbace_datafy_eval985000017_fn__985000018_A_init jrt.ClassInit

func A_arbace_datafy_eval985000017_fn__985000018_A_Init() { if !A_arbace_datafy_eval985000017_fn__985000018_A_init.Done() { A_arbace_datafy_eval985000017_fn__985000018_A_init.Run(A_arbace_datafy_eval985000017_fn__985000018_A_clinit) } }

func A_arbace_datafy_eval985000017_fn__985000018_A_clinit() { A_arbace_datafy_eval985000017_fn__985000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_44, lang.Compiler_AOTFn_class) }

func (t *A_arbace_datafy_eval985000017_fn__985000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000017_fn__985000018_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000017_fn__985000018_A_class }

func (t *A_arbace_datafy_eval985000017_fn__985000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000017_fn__985000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000017_fn__985000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000017_fn__985000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000017_fn__985000018_A); return ok }

func A_arbace_datafy_eval985000017_fn__985000018_A_Cast(x any) *A_arbace_datafy_eval985000017_fn__985000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000017_fn__985000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000017_fn__985000018_A_class)) }; return v }



type A_arbace_datafy_eval985000021_A struct{ jrt.Object }

func A_arbace_datafy_eval985000021_A_New() *A_arbace_datafy_eval985000021_A { t := &A_arbace_datafy_eval985000021_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000021_A) Ctor() {}

func (t *A_arbace_datafy_eval985000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000021_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000021_A_class }

func (t *A_arbace_datafy_eval985000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000021_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000021_A); return ok }

func A_arbace_datafy_eval985000021_A_Cast(x any) *A_arbace_datafy_eval985000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000021_A_class)) }; return v }



type A_arbace_datafy_eval985000021_fn__985000022_A struct{ jrt.Object }

func (t *A_arbace_datafy_eval985000021_fn__985000022_A) Is_Compiler_AOTF1() {}

var A_arbace_datafy_eval985000021_fn__985000022_A_fn_class *jrt.Class

var A_arbace_datafy_eval985000021_fn__985000022_A_init jrt.ClassInit

func A_arbace_datafy_eval985000021_fn__985000022_A_Init() { if !A_arbace_datafy_eval985000021_fn__985000022_A_init.Done() { A_arbace_datafy_eval985000021_fn__985000022_A_init.Run(A_arbace_datafy_eval985000021_fn__985000022_A_clinit) } }

func A_arbace_datafy_eval985000021_fn__985000022_A_clinit() { A_arbace_datafy_eval985000021_fn__985000022_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_45, lang.Compiler_AOTFn_class) }

func (t *A_arbace_datafy_eval985000021_fn__985000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000021_fn__985000022_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000021_fn__985000022_A_class }

func (t *A_arbace_datafy_eval985000021_fn__985000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000021_fn__985000022_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000021_fn__985000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000021_fn__985000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000021_fn__985000022_A); return ok }

func A_arbace_datafy_eval985000021_fn__985000022_A_Cast(x any) *A_arbace_datafy_eval985000021_fn__985000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000021_fn__985000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000021_fn__985000022_A_class)) }; return v }



type A_arbace_datafy_eval985000025_A struct{ jrt.Object }

func A_arbace_datafy_eval985000025_A_New() *A_arbace_datafy_eval985000025_A { t := &A_arbace_datafy_eval985000025_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000025_A) Ctor() {}

func (t *A_arbace_datafy_eval985000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000025_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000025_A_class }

func (t *A_arbace_datafy_eval985000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000025_A); return ok }

func A_arbace_datafy_eval985000025_A_Cast(x any) *A_arbace_datafy_eval985000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000025_A_class)) }; return v }



type A_arbace_datafy_eval985000025_fn__985000026_A struct{ jrt.Object }

func (t *A_arbace_datafy_eval985000025_fn__985000026_A) Is_Compiler_AOTF1() {}

var A_arbace_datafy_eval985000025_fn__985000026_A_fn_class *jrt.Class

var A_arbace_datafy_eval985000025_fn__985000026_A_init jrt.ClassInit

func A_arbace_datafy_eval985000025_fn__985000026_A_Init() { if !A_arbace_datafy_eval985000025_fn__985000026_A_init.Done() { A_arbace_datafy_eval985000025_fn__985000026_A_init.Run(A_arbace_datafy_eval985000025_fn__985000026_A_clinit) } }

func A_arbace_datafy_eval985000025_fn__985000026_A_clinit() { A_arbace_datafy_eval985000025_fn__985000026_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_46, lang.Compiler_AOTFn_class) }

func (t *A_arbace_datafy_eval985000025_fn__985000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000025_fn__985000026_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000025_fn__985000026_A_class }

func (t *A_arbace_datafy_eval985000025_fn__985000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000025_fn__985000026_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000025_fn__985000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000025_fn__985000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000025_fn__985000026_A); return ok }

func A_arbace_datafy_eval985000025_fn__985000026_A_Cast(x any) *A_arbace_datafy_eval985000025_fn__985000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000025_fn__985000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000025_fn__985000026_A_class)) }; return v }



type A_arbace_datafy_eval985000029_A struct{ jrt.Object }

func A_arbace_datafy_eval985000029_A_New() *A_arbace_datafy_eval985000029_A { t := &A_arbace_datafy_eval985000029_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000029_A) Ctor() {}

func (t *A_arbace_datafy_eval985000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000029_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000029_A_class }

func (t *A_arbace_datafy_eval985000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000029_A); return ok }

func A_arbace_datafy_eval985000029_A_Cast(x any) *A_arbace_datafy_eval985000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000029_A_class)) }; return v }



type A_arbace_datafy_eval985000029_fn__985000030_A struct{ jrt.Object }

func (t *A_arbace_datafy_eval985000029_fn__985000030_A) Is_Compiler_AOTF1() {}

var A_arbace_datafy_eval985000029_fn__985000030_A_fn_class *jrt.Class

var A_arbace_datafy_eval985000029_fn__985000030_A_init jrt.ClassInit

func A_arbace_datafy_eval985000029_fn__985000030_A_Init() { if !A_arbace_datafy_eval985000029_fn__985000030_A_init.Done() { A_arbace_datafy_eval985000029_fn__985000030_A_init.Run(A_arbace_datafy_eval985000029_fn__985000030_A_clinit) } }

func A_arbace_datafy_eval985000029_fn__985000030_A_clinit() { A_arbace_datafy_eval985000029_fn__985000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_47, lang.Compiler_AOTFn_class) }

func (t *A_arbace_datafy_eval985000029_fn__985000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000029_fn__985000030_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000029_fn__985000030_A_class }

func (t *A_arbace_datafy_eval985000029_fn__985000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000029_fn__985000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000029_fn__985000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000029_fn__985000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000029_fn__985000030_A); return ok }

func A_arbace_datafy_eval985000029_fn__985000030_A_Cast(x any) *A_arbace_datafy_eval985000029_fn__985000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000029_fn__985000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000029_fn__985000030_A_class)) }; return v }



type A_arbace_datafy_nav_A struct{ jrt.Object }

func (t *A_arbace_datafy_nav_A) Is_Compiler_AOTF3() {}

var A_arbace_datafy_nav_A_fn_class *jrt.Class

var A_arbace_datafy_nav_A_init jrt.ClassInit

func A_arbace_datafy_nav_A_Init() { if !A_arbace_datafy_nav_A_init.Done() { A_arbace_datafy_nav_A_init.Run(A_arbace_datafy_nav_A_clinit) } }

func A_arbace_datafy_nav_A_clinit() { A_arbace_datafy_nav_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_48, lang.Compiler_AOTFn_class) }

func (t *A_arbace_datafy_nav_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_nav_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_nav_A_class }

func (t *A_arbace_datafy_nav_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_nav_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_nav_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_nav_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_nav_A); return ok }

func A_arbace_datafy_nav_A_Cast(x any) *A_arbace_datafy_nav_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_nav_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_nav_A_class)) }; return v }



type A_arbace_datafy_sortmap_A struct{ jrt.Object }

func (t *A_arbace_datafy_sortmap_A) Is_Compiler_AOTF1() {}

var A_arbace_datafy_sortmap_A_fn_class *jrt.Class

var A_arbace_datafy_sortmap_A_init jrt.ClassInit

func A_arbace_datafy_sortmap_A_Init() { if !A_arbace_datafy_sortmap_A_init.Done() { A_arbace_datafy_sortmap_A_init.Run(A_arbace_datafy_sortmap_A_clinit) } }

func A_arbace_datafy_sortmap_A_clinit() { A_arbace_datafy_sortmap_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_49, lang.Compiler_AOTFn_class) }

func (t *A_arbace_datafy_sortmap_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_sortmap_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_sortmap_A_class }

func (t *A_arbace_datafy_sortmap_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_sortmap_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_datafy_sortmap_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_sortmap_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_sortmap_A); return ok }

func A_arbace_datafy_sortmap_A_Cast(x any) *A_arbace_datafy_sortmap_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_sortmap_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_sortmap_A_class)) }; return v }
