//line aot_arbace_datafy.ae:1
package aot_arbace_datafy

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)
func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_New() *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_datafy_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_datafy_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_datafy_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_datafy_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_datafy_eval985000008_fn__985000009_A_New() *A_arbace_datafy_eval985000008_fn__985000009_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000008_fn__985000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_datafy_eval985000008_fn__985000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_datafy_eval985000008_fn__985000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_datafy_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_datafy_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_datafy_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_datafy_A_const_7.GetRawRoot__O(), A_arbace_datafy_A_const_8) }





func A_arbace_datafy_datafy_A_New() *A_arbace_datafy_datafy_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_datafy_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_datafy_datafy_A) Ctor() {}
//line :15:1
func (t *A_arbace_datafy_datafy_A) Invoke_O_O__O(self, x__0 any) any { var v__2 any; var target_19 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 =







	aot_arbace_core_protocols.A_arbace_core_protocols_Datafiable_A_InstanceOf(target_19); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_19) }; tmp1 = tmp2; if tmp1 { v__2 = aot_arbace_core_protocols.A_arbace_core_protocols_Datafiable_A_Cast(target_19).Datafy__O() } else { v__2 = lang.IFn_Cast(A_arbace_datafy_A_const_9.GetRawRoot__O()).Invoke_O__O(target_19) }; if
	lang.Util_Identical_O_O__Z_NoInit(v__2, x__0) { return v__2 } else {

		if lang.IObj_InstanceOf(v__2) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_datafy_A_const_10.GetRawRoot__O()); var tmp4 any = A_arbace_datafy_A_const_11.GetRawRoot__O(); var tmp5 any = A_arbace_datafy_A_const_12; var tmp6 any = A_arbace_datafy_A_const_13; var tmp7 any; var root_24 any = A_arbace_datafy_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var tmp8 any; var root_20 any = A_arbace_datafy_A_const_15.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = x__0; if linked_21 == nil { tmp8 = ifn_22.Invoke_O__O(arg_23) } else { tmp8 = linked_21.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_20, arg_23) }; arg_27 = jrt.NN(jrt.Class_Cast(tmp8)).GetName__String().Ref(); if linked_25 == nil { tmp7 = ifn_26.Invoke_O__O(arg_27) } else { tmp7 = linked_25.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_24, arg_27) }; return tmp3.Invoke_O_O_O_O_O_O__O(v__2, tmp4, tmp5, x__0, tmp6, tmp7) } else {
//line :26:1
				return v__2 } } }



func A_arbace_datafy_nav_A_New() *A_arbace_datafy_nav_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_nav_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_datafy_nav_A) Ctor() {}
//line :30:1
func (t *A_arbace_datafy_nav_A) Invoke_O_O_O_O__O(self, coll__0, k__1, v__2 any) any {






	var target_37 any = coll__0; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_Navigable_A_InstanceOf(target_37); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_37) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_Navigable_A_Cast(target_37).Nav_O_O__O(k__1, v__2) } else { return lang.IFn_Cast(A_arbace_datafy_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(target_37, k__1, v__2)
	} }
func A_arbace_datafy_sortmap_A_New() *A_arbace_datafy_sortmap_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_sortmap_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_datafy_sortmap_A) Ctor() {}
//line :39:1
func (t *A_arbace_datafy_sortmap_A) Invoke_O_O__O(self, m__0 any) any {
	var root_41 any = A_arbace_datafy_A_const_17.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = lang.IFn_Cast(A_arbace_datafy_A_const_18.GetRawRoot__O()).Invoke__O(); var arg_45 any = m__0; if linked_42 == nil { return ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { return linked_42.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_41, arg_44, arg_45)
	} }
func A_arbace_datafy_eval985000017_fn__985000018_A_New() *A_arbace_datafy_eval985000017_fn__985000018_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000017_fn__985000018_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000017_fn__985000018_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000017_fn__985000018_A) Invoke_O_O__O(self, x__1 any) any {


	var root_46 any = A_arbace_datafy_A_const_19.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_Throwable__GT_map_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = x__1; if linked_47 == nil { return ifn_48.Invoke_O__O(arg_49) } else { return linked_47.(*aot_arbace_core.A_arbace_core_Throwable__GT_map_A).Invoke_O_O__O(root_46, arg_49) } }
//line :42:1
func A_arbace_datafy_eval985000021_fn__985000022_A_New() *A_arbace_datafy_eval985000021_fn__985000022_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000021_fn__985000022_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000021_fn__985000022_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000021_fn__985000022_A) Invoke_O_O__O(self, r__1 any) any {






	var root_54 any = A_arbace_datafy_A_const_20.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any; var tmp1 any; var root_50 any = A_arbace_datafy_A_const_5.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = r__1; if linked_51 == nil { tmp1 = ifn_52.Invoke_O__O(arg_53) } else { tmp1 = linked_51.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_50, arg_53) }; arg_57 = lang.Tuple_Create_O__IPersistentVector(tmp1); var arg_58 any = lang.RT_Meta_O__IPersistentMap_NoInit(r__1); if linked_55 == nil { return ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { return linked_55.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_54, arg_57, arg_58) } }
//line :42:1
func A_arbace_datafy_eval985000025_fn__985000026_A_New() *A_arbace_datafy_eval985000025_fn__985000026_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000025_fn__985000026_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000025_fn__985000026_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000025_fn__985000026_A) Invoke_O_O__O(self, n__1 any) any {










	var root_83 any = A_arbace_datafy_A_const_20.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any; var tmp1 any = A_arbace_datafy_A_const_21; var tmp2 any = jrt.NN(lang.Namespace_Cast(n__1)).GetName__Symbol().Ref(); var tmp3 any = A_arbace_datafy_A_const_22; var tmp4 any; var root_63 any = A_arbace_datafy_A_const_23.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, A_arbace_datafy_sortmap_A_fn_class); var ifn_65 lang.IFn
	if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var root_59 any = A_arbace_datafy_A_const_24.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_ns_publics_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = n__1; if linked_60 == nil { arg_66 = ifn_61.Invoke_O__O(arg_62) } else { arg_66 = linked_60.(*aot_arbace_core.A_arbace_core_ns_publics_A).Invoke_O_O__O(root_59, arg_62) }; if linked_64 == nil { tmp4 = ifn_65.Invoke_O__O(arg_66) } else { tmp4 = linked_64.(*A_arbace_datafy_sortmap_A).Invoke_O_O__O(root_63, arg_66) }
//line :53:1
	var tmp5 any = tmp4; var tmp6 any = A_arbace_datafy_A_const_25; var tmp7 any; var root_71 any = A_arbace_datafy_A_const_23.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_datafy_sortmap_A_fn_class); var ifn_73 lang.IFn

	if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any; var root_67 any = A_arbace_datafy_A_const_26.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_ns_imports_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = n__1; if linked_68 == nil { arg_74 = ifn_69.Invoke_O__O(arg_70) } else { arg_74 = linked_68.(*aot_arbace_core.A_arbace_core_ns_imports_A).Invoke_O_O__O(root_67, arg_70) }; if linked_72 == nil { tmp7 = ifn_73.Invoke_O__O(arg_74) } else { tmp7 = linked_72.(*A_arbace_datafy_sortmap_A).Invoke_O_O__O(root_71, arg_74) }
//line :53:1
	var tmp8 any = tmp7; var tmp9 any = A_arbace_datafy_A_const_27; var tmp10 any; var root_79 any = A_arbace_datafy_A_const_23.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, A_arbace_datafy_sortmap_A_fn_class); var ifn_81 lang.IFn


	if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any; var root_75 any = A_arbace_datafy_A_const_28.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_ns_interns_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = n__1; if linked_76 == nil { arg_82 = ifn_77.Invoke_O__O(arg_78) } else { arg_82 = linked_76.(*aot_arbace_core.A_arbace_core_ns_interns_A).Invoke_O_O__O(root_75, arg_78) }; if linked_80 == nil { tmp10 = ifn_81.Invoke_O__O(arg_82) } else { tmp10 = linked_80.(*A_arbace_datafy_sortmap_A).Invoke_O_O__O(root_79, arg_82) }
//line :53:1
	arg_86 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, tmp6, tmp8, tmp9, tmp10)); var arg_87 any = lang.RT_Meta_O__IPersistentMap_NoInit(n__1); if linked_84 == nil { return ifn_85.Invoke_O_O__O(arg_86, arg_87) } else { return linked_84.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_83, arg_86, arg_87) } }
//line :42:1
func A_arbace_datafy_eval985000029_fn__985000030_A_New() *A_arbace_datafy_eval985000029_fn__985000030_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000029_fn__985000030_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000029_fn__985000030_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000029_fn__985000030_A) Invoke_O_O__O(self, c__1 any) any { var map__985000031__2 any; var tmp1 any; var root_88 any = A_arbace_datafy_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_90 lang.IFn; if


















	linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = A_arbace_datafy_A_const_30; if linked_89 == nil { tmp1 = ifn_90.Invoke_O__O(arg_91) } else { tmp1 = linked_89.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_88, arg_91) }; map__985000031__2 = lang.IFn_Cast(tmp1).Invoke_O__O(c__1); var map__985000031__3 any; if lang.ISeq_InstanceOf(map__985000031__2) { var tmp2 any; var root_92 any = A_arbace_datafy_A_const_31.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = map__985000031__2; if linked_93 == nil { tmp2 = ifn_94.Invoke_O__O(arg_95) } else { tmp2 = linked_93.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_92, arg_95) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_96 any = A_arbace_datafy_A_const_32.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = map__985000031__2; if linked_97 == nil { tmp3 = ifn_98.Invoke_O__O(arg_99) } else { tmp3 = linked_97.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_96, arg_99) }; map__985000031__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_100 any = A_arbace_datafy_A_const_33.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = map__985000031__2; if linked_101 == nil { tmp4 = ifn_102.Invoke_O__O(arg_103) } else { tmp4 = linked_101.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_100, arg_103) }; if jrt.J2g_Truth(tmp4) { var root_104 any = A_arbace_datafy_A_const_34.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = map__985000031__2; if linked_105 == nil { map__985000031__3 = ifn_106.Invoke_O__O(arg_107) } else { map__985000031__3 = linked_105.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_104, arg_107) } } else { map__985000031__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__985000031__3 = map__985000031__2 }; var ret__4 any = map__985000031__3; var members__5 any = /*line :42:1*/lang.RT_Get_O_O__O_NoInit(map__985000031__3, A_arbace_datafy_A_const_35); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_datafy_A_const_11.GetRawRoot__O()); var tmp6 any = A_arbace_datafy_A_const_21; var tmp7 any; var root_108 any = A_arbace_datafy_A_const_14.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_110 lang.IFn; if



















	linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref(); if linked_109 == nil { tmp7 = ifn_110.Invoke_O__O(arg_111) } else { tmp7 = linked_109.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_108, arg_111) }; var tmp8 any = tmp7; var tmp9 any = A_arbace_datafy_A_const_35; var tmp10 any; var root_117 any = A_arbace_datafy_A_const_23.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_datafy_sortmap_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any; var root_112 any = A_arbace_datafy_A_const_36.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_datafy_A_const_21; var arg_116 any = members__5; if linked_113 == nil { arg_120 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { arg_120 = linked_113.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) }; if linked_118 == nil { tmp10 = ifn_119.Invoke_O__O(arg_120) } else { tmp10 = linked_118.(*A_arbace_datafy_sortmap_A).Invoke_O_O__O(root_117, arg_120) }; return tmp5.Invoke_O_O_O_O_O__O(ret__4, tmp6, tmp8, tmp9, tmp10) }








type A_arbace_datafy_A struct{ jrt.Object }

var A_arbace_datafy_A_const_pool *jrt.RefArray

var A_arbace_datafy_A_const_0 *lang.Var

var A_arbace_datafy_A_const_1 any

var A_arbace_datafy_A_const_2 *lang.Var

var A_arbace_datafy_A_const_3 any

var A_arbace_datafy_A_const_4 *lang.Var

var A_arbace_datafy_A_const_5 *lang.Var

var A_arbace_datafy_A_const_6 *lang.Var

var A_arbace_datafy_A_const_7 *lang.Var

var A_arbace_datafy_A_const_8 any

var A_arbace_datafy_A_const_9 *lang.Var

var A_arbace_datafy_A_const_10 *lang.Var

var A_arbace_datafy_A_const_11 *lang.Var

var A_arbace_datafy_A_const_12 *lang.Keyword

var A_arbace_datafy_A_const_13 *lang.Keyword

var A_arbace_datafy_A_const_14 *lang.Var

var A_arbace_datafy_A_const_15 *lang.Var

var A_arbace_datafy_A_const_16 *lang.Var

var A_arbace_datafy_A_const_17 *lang.Var

var A_arbace_datafy_A_const_18 *lang.Var

var A_arbace_datafy_A_const_19 *lang.Var

var A_arbace_datafy_A_const_20 *lang.Var

var A_arbace_datafy_A_const_21 *lang.Keyword

var A_arbace_datafy_A_const_22 *lang.Keyword

var A_arbace_datafy_A_const_23 *lang.Var

var A_arbace_datafy_A_const_24 *lang.Var

var A_arbace_datafy_A_const_25 *lang.Keyword

var A_arbace_datafy_A_const_26 *lang.Var

var A_arbace_datafy_A_const_27 *lang.Keyword

var A_arbace_datafy_A_const_28 *lang.Var

var A_arbace_datafy_A_const_29 *lang.Var

var A_arbace_datafy_A_const_30 any

var A_arbace_datafy_A_const_31 *lang.Var

var A_arbace_datafy_A_const_32 *lang.Var

var A_arbace_datafy_A_const_33 *lang.Var

var A_arbace_datafy_A_const_34 *lang.Var

var A_arbace_datafy_A_const_35 *lang.Keyword

var A_arbace_datafy_A_const_36 *lang.Var

var A_arbace_datafy_A_init jrt.ClassInit

func A_arbace_datafy_A_Init() { if !A_arbace_datafy_A_init.Done() { A_arbace_datafy_A_init.Run(A_arbace_datafy_A_clinit) } }

func A_arbace_datafy_A_clinit() { A_arbace_datafy_A_clinit_p0(); A_arbace_datafy_A_clinit_p1(); A_arbace_datafy_A_clinit_p2(); A_arbace_datafy_A_clinit_p3() }

func A_arbace_datafy_A_clinit_p0() { jrt.StartCheck(); A_arbace_datafy_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 50); A_arbace_datafy_A_const_0 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[13]); A_arbace_datafy_A_const_1 = A_arbace_datafy_A_const_pool.A[14]; A_arbace_datafy_A_const_2 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[15]); A_arbace_datafy_A_const_3 = A_arbace_datafy_A_const_pool.A[16]; A_arbace_datafy_A_const_4 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[17]); A_arbace_datafy_A_const_5 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[18]); A_arbace_datafy_A_const_6 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[19]); A_arbace_datafy_A_const_7 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[20]); A_arbace_datafy_A_const_8 = A_arbace_datafy_A_const_pool.A[21]; A_arbace_datafy_A_const_9 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[22]); A_arbace_datafy_A_const_10 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[23]); A_arbace_datafy_A_const_11 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[24]) }

func A_arbace_datafy_A_clinit_p1() { A_arbace_datafy_A_const_12 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[25]); A_arbace_datafy_A_const_13 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[26]); A_arbace_datafy_A_const_14 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[27]); A_arbace_datafy_A_const_15 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[28]); A_arbace_datafy_A_const_16 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[29]); A_arbace_datafy_A_const_17 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[30]); A_arbace_datafy_A_const_18 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[31]); A_arbace_datafy_A_const_19 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[32]); A_arbace_datafy_A_const_20 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[33]); A_arbace_datafy_A_const_21 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[34]); A_arbace_datafy_A_const_22 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[35]); A_arbace_datafy_A_const_23 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[36]) }

func A_arbace_datafy_A_clinit_p2() { A_arbace_datafy_A_const_24 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[37]); A_arbace_datafy_A_const_25 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[38]); A_arbace_datafy_A_const_26 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[39]); A_arbace_datafy_A_const_27 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[40]); A_arbace_datafy_A_const_28 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[41]); A_arbace_datafy_A_const_29 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[42]); A_arbace_datafy_A_const_30 = A_arbace_datafy_A_const_pool.A[43]; A_arbace_datafy_A_const_31 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[44]); A_arbace_datafy_A_const_32 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[45]); A_arbace_datafy_A_const_33 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[46]); A_arbace_datafy_A_const_34 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[47]); A_arbace_datafy_A_const_35 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[48]) }

func A_arbace_datafy_A_clinit_p3() { A_arbace_datafy_A_const_36 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[49]) }

func A_arbace_datafy_A_New() *A_arbace_datafy_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_A) Ctor() {}

func (t *A_arbace_datafy_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_A_class }

func (t *A_arbace_datafy_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_A); return ok }

func A_arbace_datafy_A_Cast(x any) *A_arbace_datafy_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_A_class)) }; return v }



type A_arbace_datafy_datafy_A struct{ j2g_header uint64 }

var A_arbace_datafy_datafy_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000004_A struct{ jrt.Object }

func A_arbace_datafy_eval985000004_A_New() *A_arbace_datafy_eval985000004_A { t := &A_arbace_datafy_eval985000004_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000004_A) Ctor() {}

func (t *A_arbace_datafy_eval985000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000004_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000004_A_class }

func (t *A_arbace_datafy_eval985000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000004_A); return ok }

func A_arbace_datafy_eval985000004_A_Cast(x any) *A_arbace_datafy_eval985000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000004_A_class)) }; return v }



type A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000008_A struct{ jrt.Object }

func A_arbace_datafy_eval985000008_A_New() *A_arbace_datafy_eval985000008_A { t := &A_arbace_datafy_eval985000008_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000008_A) Ctor() {}

func (t *A_arbace_datafy_eval985000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000008_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000008_A_class }

func (t *A_arbace_datafy_eval985000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000008_A); return ok }

func A_arbace_datafy_eval985000008_A_Cast(x any) *A_arbace_datafy_eval985000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000008_A_class)) }; return v }



type A_arbace_datafy_eval985000008_fn__985000009_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000008_fn__985000009_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000017_A struct{ jrt.Object }

func A_arbace_datafy_eval985000017_A_New() *A_arbace_datafy_eval985000017_A { t := &A_arbace_datafy_eval985000017_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000017_A) Ctor() {}

func (t *A_arbace_datafy_eval985000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000017_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000017_A_class }

func (t *A_arbace_datafy_eval985000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000017_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000017_A); return ok }

func A_arbace_datafy_eval985000017_A_Cast(x any) *A_arbace_datafy_eval985000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000017_A_class)) }; return v }



type A_arbace_datafy_eval985000017_fn__985000018_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000017_fn__985000018_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000021_A struct{ jrt.Object }

func A_arbace_datafy_eval985000021_A_New() *A_arbace_datafy_eval985000021_A { t := &A_arbace_datafy_eval985000021_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000021_A) Ctor() {}

func (t *A_arbace_datafy_eval985000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000021_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000021_A_class }

func (t *A_arbace_datafy_eval985000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000021_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000021_A); return ok }

func A_arbace_datafy_eval985000021_A_Cast(x any) *A_arbace_datafy_eval985000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000021_A_class)) }; return v }



type A_arbace_datafy_eval985000021_fn__985000022_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000021_fn__985000022_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000025_A struct{ jrt.Object }

func A_arbace_datafy_eval985000025_A_New() *A_arbace_datafy_eval985000025_A { t := &A_arbace_datafy_eval985000025_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000025_A) Ctor() {}

func (t *A_arbace_datafy_eval985000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000025_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000025_A_class }

func (t *A_arbace_datafy_eval985000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000025_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000025_A); return ok }

func A_arbace_datafy_eval985000025_A_Cast(x any) *A_arbace_datafy_eval985000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000025_A_class)) }; return v }



type A_arbace_datafy_eval985000025_fn__985000026_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000025_fn__985000026_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000029_A struct{ jrt.Object }

func A_arbace_datafy_eval985000029_A_New() *A_arbace_datafy_eval985000029_A { t := &A_arbace_datafy_eval985000029_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000029_A) Ctor() {}

func (t *A_arbace_datafy_eval985000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000029_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000029_A_class }

func (t *A_arbace_datafy_eval985000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000029_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000029_A); return ok }

func A_arbace_datafy_eval985000029_A_Cast(x any) *A_arbace_datafy_eval985000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000029_A_class)) }; return v }



type A_arbace_datafy_eval985000029_fn__985000030_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000029_fn__985000030_A_fn_class *jrt.Class



type A_arbace_datafy_nav_A struct{ j2g_header uint64 }

var A_arbace_datafy_nav_A_fn_class *jrt.Class



type A_arbace_datafy_sortmap_A struct{ j2g_header uint64 }

var A_arbace_datafy_sortmap_A_fn_class *jrt.Class
