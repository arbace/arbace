//line aot_arbace_datafy.ae:1
package aot_arbace_datafy

import (
	"arbace/aot_arbace_core_protocols"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_New() *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_datafy_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_datafy_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_datafy_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_datafy_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_datafy_eval985000008_fn__985000009_A_New() *A_arbace_datafy_eval985000008_fn__985000009_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000008_fn__985000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_datafy_eval985000008_fn__985000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_datafy_eval985000008_fn__985000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_datafy_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_datafy_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_datafy_A_const_8), A_arbace_datafy_A_const_6.GetRawRoot__O(), A_arbace_datafy_A_const_7) }





func A_arbace_datafy_datafy_A_New() *A_arbace_datafy_datafy_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_datafy_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_datafy_datafy_A) Ctor() {}
//line :15:1
func (t *A_arbace_datafy_datafy_A) Invoke_O_O__O(self, x__0 any) any { var v__2 any; var target_1 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 =







	aot_arbace_core_protocols.A_arbace_core_protocols_Datafiable_A_InstanceOf(target_1); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_1) }; tmp1 = tmp2; if tmp1 { v__2 = aot_arbace_core_protocols.A_arbace_core_protocols_Datafiable_A_Cast(target_1).Datafy__O() } else { v__2 = lang.IFn_Cast(A_arbace_datafy_A_const_9.GetRawRoot__O()).Invoke_O__O(target_1) }; if
	lang.Util_Identical_O_O__Z_NoInit(v__2, x__0) { return v__2 } else {

		if lang.IObj_InstanceOf(v__2) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_datafy_A_const_10.GetRawRoot__O()); var tmp4 any = A_arbace_datafy_A_const_11.GetRawRoot__O(); var tmp5 any = A_arbace_datafy_A_const_12; var tmp6 any = A_arbace_datafy_A_const_13; return tmp3.Invoke_O_O_O_O_O_O__O(v__2, tmp4, tmp5, x__0, tmp6, lang.IFn_Cast(A_arbace_datafy_A_const_14.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_datafy_A_const_15.GetRawRoot__O()).Invoke_O__O(x__0))).GetName__String().Ref())) } else {
//line :26:1
				return v__2 } } }



func A_arbace_datafy_nav_A_New() *A_arbace_datafy_nav_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_nav_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_datafy_nav_A) Ctor() {}
//line :30:1
func (t *A_arbace_datafy_nav_A) Invoke_O_O_O_O__O(self, coll__0, k__1, v__2 any) any {






	var target_2 any = coll__0; var tmp1 bool; var tmp2 bool; tmp2 = aot_arbace_core_protocols.A_arbace_core_protocols_Navigable_A_InstanceOf(target_2); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_2) }; tmp1 = tmp2; if tmp1 { return aot_arbace_core_protocols.A_arbace_core_protocols_Navigable_A_Cast(target_2).Nav_O_O__O(k__1, v__2) } else { return lang.IFn_Cast(A_arbace_datafy_A_const_16.GetRawRoot__O()).Invoke_O_O_O__O(target_2, k__1, v__2)
	} }
func A_arbace_datafy_sortmap_A_New() *A_arbace_datafy_sortmap_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_sortmap_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_datafy_sortmap_A) Ctor() {}
//line :39:1
func (t *A_arbace_datafy_sortmap_A) Invoke_O_O__O(self, m__0 any) any {
	return lang.IFn_Cast(A_arbace_datafy_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_datafy_A_const_18.GetRawRoot__O()).Invoke__O(), m__0)
}
func A_arbace_datafy_eval985000017_fn__985000018_A_New() *A_arbace_datafy_eval985000017_fn__985000018_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000017_fn__985000018_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000017_fn__985000018_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000017_fn__985000018_A) Invoke_O_O__O(self, x__1 any) any {


	return lang.IFn_Cast(A_arbace_datafy_A_const_19.GetRawRoot__O()).Invoke_O__O(x__1) }
//line :42:1
func A_arbace_datafy_eval985000021_fn__985000022_A_New() *A_arbace_datafy_eval985000021_fn__985000022_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000021_fn__985000022_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000021_fn__985000022_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000021_fn__985000022_A) Invoke_O_O__O(self, r__1 any) any {






	return lang.IFn_Cast(A_arbace_datafy_A_const_20.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_datafy_A_const_5.GetRawRoot__O()).Invoke_O__O(r__1)), lang.RT_Meta_O__IPersistentMap_NoInit(r__1)) }
//line :42:1
func A_arbace_datafy_eval985000025_fn__985000026_A_New() *A_arbace_datafy_eval985000025_fn__985000026_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000025_fn__985000026_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000025_fn__985000026_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000025_fn__985000026_A) Invoke_O_O__O(self, n__1 any) any {










	var tmp1 any = A_arbace_datafy_A_const_21; var tmp2 any = jrt.NN(lang.Namespace_Cast(n__1)).GetName__Symbol().Ref(); var tmp3 any = A_arbace_datafy_A_const_22; var tmp4 any = lang.IFn_Cast(A_arbace_datafy_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_datafy_A_const_26.GetRawRoot__O()).Invoke_O__O(n__1)); var tmp5 any = A_arbace_datafy_A_const_24; var tmp6 any = lang.IFn_Cast(A_arbace_datafy_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_datafy_A_const_27.GetRawRoot__O()).Invoke_O__O(n__1)); var tmp7 any = A_arbace_datafy_A_const_25; return lang.IFn_Cast(A_arbace_datafy_A_const_20.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, lang.IFn_Cast(A_arbace_datafy_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_datafy_A_const_28.GetRawRoot__O()).Invoke_O__O(n__1)))), lang.RT_Meta_O__IPersistentMap_NoInit(n__1)) }
//line :42:1
func A_arbace_datafy_eval985000029_fn__985000030_A_New() *A_arbace_datafy_eval985000029_fn__985000030_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_eval985000029_fn__985000030_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_datafy_eval985000029_fn__985000030_A) Ctor() {}
//line :42:1
func (t *A_arbace_datafy_eval985000029_fn__985000030_A) Invoke_O_O__O(self, c__1 any) any { var map__985000031__2 any = lang.IFn_Cast(lang.IFn_Cast(A_arbace_datafy_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_datafy_A_const_35)).Invoke_O__O(c__1); var map__985000031__3 any; if


















	lang.ISeq_InstanceOf(map__985000031__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_datafy_A_const_30.GetRawRoot__O()).Invoke_O__O(map__985000031__2)) { map__985000031__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_datafy_A_const_31.GetRawRoot__O()).Invoke_O__O(map__985000031__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_datafy_A_const_32.GetRawRoot__O()).Invoke_O__O(map__985000031__2)) { map__985000031__3 = lang.IFn_Cast(A_arbace_datafy_A_const_33.GetRawRoot__O()).Invoke_O__O(map__985000031__2) } else { map__985000031__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__985000031__3 = map__985000031__2 }; var ret__4 any = map__985000031__3; var members__5 any = /*line :42:1*/lang.RT_Get_O_O__O_NoInit(map__985000031__3, A_arbace_datafy_A_const_34); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_datafy_A_const_11.GetRawRoot__O()); var tmp2 any = A_arbace_datafy_A_const_21; var tmp3 any = lang.IFn_Cast(A_arbace_datafy_A_const_14.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()); var tmp4 any = A_arbace_datafy_A_const_34; return /*line :62:1*/ tmp1.Invoke_O_O_O_O_O__O(ret__4, tmp2, tmp3, tmp4, lang.IFn_Cast(A_arbace_datafy_A_const_23.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_datafy_A_const_36.GetRawRoot__O()).Invoke_O_O__O(A_arbace_datafy_A_const_21, members__5))) }








type A_arbace_datafy_A struct{ jrt.Object }

var A_arbace_datafy_A_const_pool *jrt.RefArray

var A_arbace_datafy_A_const_0 *lang.Var

var A_arbace_datafy_A_const_1 *lang.Var

var A_arbace_datafy_A_const_2 any

var A_arbace_datafy_A_const_3 any

var A_arbace_datafy_A_const_4 *lang.Var

var A_arbace_datafy_A_const_5 *lang.Var

var A_arbace_datafy_A_const_6 *lang.Var

var A_arbace_datafy_A_const_7 any

var A_arbace_datafy_A_const_8 *lang.Var

var A_arbace_datafy_A_const_9 *lang.Var

var A_arbace_datafy_A_const_10 *lang.Var

var A_arbace_datafy_A_const_11 *lang.Var

var A_arbace_datafy_A_const_12 *lang.Keyword

var A_arbace_datafy_A_const_13 *lang.Keyword

var A_arbace_datafy_A_const_14 *lang.Var

var A_arbace_datafy_A_const_15 *lang.Var

var A_arbace_datafy_A_const_16 *lang.Var

var A_arbace_datafy_A_const_17 *lang.Var

var A_arbace_datafy_A_const_18 *lang.Var

var A_arbace_datafy_A_const_19 *lang.Var

var A_arbace_datafy_A_const_20 *lang.Var

var A_arbace_datafy_A_const_21 *lang.Keyword

var A_arbace_datafy_A_const_22 *lang.Keyword

var A_arbace_datafy_A_const_23 *lang.Var

var A_arbace_datafy_A_const_24 *lang.Keyword

var A_arbace_datafy_A_const_25 *lang.Keyword

var A_arbace_datafy_A_const_26 *lang.Var

var A_arbace_datafy_A_const_27 *lang.Var

var A_arbace_datafy_A_const_28 *lang.Var

var A_arbace_datafy_A_const_29 *lang.Var

var A_arbace_datafy_A_const_30 *lang.Var

var A_arbace_datafy_A_const_31 *lang.Var

var A_arbace_datafy_A_const_32 *lang.Var

var A_arbace_datafy_A_const_33 *lang.Var

var A_arbace_datafy_A_const_34 *lang.Keyword

var A_arbace_datafy_A_const_35 any

var A_arbace_datafy_A_const_36 *lang.Var

var A_arbace_datafy_A_init jrt.ClassInit

func A_arbace_datafy_A_Init() { if !A_arbace_datafy_A_init.Done() { A_arbace_datafy_A_init.Run(A_arbace_datafy_A_clinit) } }

func A_arbace_datafy_A_clinit() { A_arbace_datafy_A_clinit_p0(); A_arbace_datafy_A_clinit_p1(); A_arbace_datafy_A_clinit_p2(); A_arbace_datafy_A_clinit_p3() }

func A_arbace_datafy_A_clinit_p0() { jrt.StartCheck(); A_arbace_datafy_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 50); A_arbace_datafy_A_const_0 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[13]); A_arbace_datafy_A_const_1 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[14]); A_arbace_datafy_A_const_2 = A_arbace_datafy_A_const_pool.A[15]; A_arbace_datafy_A_const_3 = A_arbace_datafy_A_const_pool.A[16]; A_arbace_datafy_A_const_4 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[17]); A_arbace_datafy_A_const_5 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[18]); A_arbace_datafy_A_const_6 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[19]); A_arbace_datafy_A_const_7 = A_arbace_datafy_A_const_pool.A[20]; A_arbace_datafy_A_const_8 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[21]); A_arbace_datafy_A_const_9 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[22]); A_arbace_datafy_A_const_10 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[23]); A_arbace_datafy_A_const_11 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[24]) }

func A_arbace_datafy_A_clinit_p1() { A_arbace_datafy_A_const_12 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[25]); A_arbace_datafy_A_const_13 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[26]); A_arbace_datafy_A_const_14 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[27]); A_arbace_datafy_A_const_15 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[28]); A_arbace_datafy_A_const_16 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[29]); A_arbace_datafy_A_const_17 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[30]); A_arbace_datafy_A_const_18 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[31]); A_arbace_datafy_A_const_19 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[32]); A_arbace_datafy_A_const_20 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[33]); A_arbace_datafy_A_const_21 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[34]); A_arbace_datafy_A_const_22 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[35]); A_arbace_datafy_A_const_23 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[36]) }

func A_arbace_datafy_A_clinit_p2() { A_arbace_datafy_A_const_24 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[37]); A_arbace_datafy_A_const_25 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[38]); A_arbace_datafy_A_const_26 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[39]); A_arbace_datafy_A_const_27 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[40]); A_arbace_datafy_A_const_28 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[41]); A_arbace_datafy_A_const_29 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[42]); A_arbace_datafy_A_const_30 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[43]); A_arbace_datafy_A_const_31 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[44]); A_arbace_datafy_A_const_32 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[45]); A_arbace_datafy_A_const_33 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[46]); A_arbace_datafy_A_const_34 = lang.Keyword_Cast(A_arbace_datafy_A_const_pool.A[47]); A_arbace_datafy_A_const_35 = A_arbace_datafy_A_const_pool.A[48] }

func A_arbace_datafy_A_clinit_p3() { A_arbace_datafy_A_const_36 = lang.Var_Cast(A_arbace_datafy_A_const_pool.A[49]) }

func A_arbace_datafy_A_New() *A_arbace_datafy_A { A_arbace_datafy_A_Init(); t := &A_arbace_datafy_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_A) Ctor() {}

func (t *A_arbace_datafy_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_A_class }

func (t *A_arbace_datafy_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_A); return ok }

func A_arbace_datafy_A_Cast(x any) *A_arbace_datafy_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_A_class)) }; return v }



type A_arbace_datafy_datafy_A struct{ j2g_header uint64 }

var A_arbace_datafy_datafy_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000004_A struct{ jrt.Object }

func A_arbace_datafy_eval985000004_A_New() *A_arbace_datafy_eval985000004_A { t := &A_arbace_datafy_eval985000004_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000004_A) Ctor() {}

func (t *A_arbace_datafy_eval985000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000004_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000004_A_class }

func (t *A_arbace_datafy_eval985000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000004_A); return ok }

func A_arbace_datafy_eval985000004_A_Cast(x any) *A_arbace_datafy_eval985000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000004_A_class)) }; return v }



type A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000004_loading__1927001464__auto____985000005_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000008_A struct{ jrt.Object }

func A_arbace_datafy_eval985000008_A_New() *A_arbace_datafy_eval985000008_A { t := &A_arbace_datafy_eval985000008_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000008_A) Ctor() {}

func (t *A_arbace_datafy_eval985000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000008_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000008_A_class }

func (t *A_arbace_datafy_eval985000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000008_A); return ok }

func A_arbace_datafy_eval985000008_A_Cast(x any) *A_arbace_datafy_eval985000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000008_A_class)) }; return v }



type A_arbace_datafy_eval985000008_fn__985000009_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000008_fn__985000009_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000017_A struct{ jrt.Object }

func A_arbace_datafy_eval985000017_A_New() *A_arbace_datafy_eval985000017_A { t := &A_arbace_datafy_eval985000017_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000017_A) Ctor() {}

func (t *A_arbace_datafy_eval985000017_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000017_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000017_A_class }

func (t *A_arbace_datafy_eval985000017_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000017_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000017_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000017_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000017_A); return ok }

func A_arbace_datafy_eval985000017_A_Cast(x any) *A_arbace_datafy_eval985000017_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000017_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000017_A_class)) }; return v }



type A_arbace_datafy_eval985000017_fn__985000018_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000017_fn__985000018_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000021_A struct{ jrt.Object }

func A_arbace_datafy_eval985000021_A_New() *A_arbace_datafy_eval985000021_A { t := &A_arbace_datafy_eval985000021_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000021_A) Ctor() {}

func (t *A_arbace_datafy_eval985000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000021_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000021_A_class }

func (t *A_arbace_datafy_eval985000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000021_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000021_A); return ok }

func A_arbace_datafy_eval985000021_A_Cast(x any) *A_arbace_datafy_eval985000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000021_A_class)) }; return v }



type A_arbace_datafy_eval985000021_fn__985000022_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000021_fn__985000022_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000025_A struct{ jrt.Object }

func A_arbace_datafy_eval985000025_A_New() *A_arbace_datafy_eval985000025_A { t := &A_arbace_datafy_eval985000025_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000025_A) Ctor() {}

func (t *A_arbace_datafy_eval985000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000025_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000025_A_class }

func (t *A_arbace_datafy_eval985000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000025_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000025_A); return ok }

func A_arbace_datafy_eval985000025_A_Cast(x any) *A_arbace_datafy_eval985000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000025_A_class)) }; return v }



type A_arbace_datafy_eval985000025_fn__985000026_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000025_fn__985000026_A_fn_class *jrt.Class



type A_arbace_datafy_eval985000029_A struct{ jrt.Object }

func A_arbace_datafy_eval985000029_A_New() *A_arbace_datafy_eval985000029_A { t := &A_arbace_datafy_eval985000029_A{}; t.Ctor(); return t }

func (t *A_arbace_datafy_eval985000029_A) Ctor() {}

func (t *A_arbace_datafy_eval985000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_datafy_eval985000029_A) GetClass__Class() *jrt.Class { return A_arbace_datafy_eval985000029_A_class }

func (t *A_arbace_datafy_eval985000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_datafy_eval985000029_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_datafy_eval985000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_datafy_eval985000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_datafy_eval985000029_A); return ok }

func A_arbace_datafy_eval985000029_A_Cast(x any) *A_arbace_datafy_eval985000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_datafy_eval985000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_datafy_eval985000029_A_class)) }; return v }



type A_arbace_datafy_eval985000029_fn__985000030_A struct{ j2g_header uint64 }

var A_arbace_datafy_eval985000029_fn__985000030_A_fn_class *jrt.Class



type A_arbace_datafy_nav_A struct{ j2g_header uint64 }

var A_arbace_datafy_nav_A_fn_class *jrt.Class



type A_arbace_datafy_sortmap_A struct{ j2g_header uint64 }

var A_arbace_datafy_sortmap_A_fn_class *jrt.Class
