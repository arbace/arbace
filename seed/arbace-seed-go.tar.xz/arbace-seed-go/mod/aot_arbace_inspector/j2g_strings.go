//line j2g_strings.ae:1
package aot_arbace_inspector

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,dockn6,authorkn5,entrykn7,seqablekn3,seqkn4,elsekn4,atomkn5,nrowskn9,get-valuekn9,get-labelv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.inspectorm4,R1,s55,Graphical object inspector for Clojure data structures.R2,s11,Rich Hickeyv11,arbace.core3,notv11,arbace.core5,coll?v11,arbace.core10,map-entry?R3,R4,v11,arbace.core11,sequential?R5,R6,R7,v16,arbace.inspector14,collection-tagv16,arbace.inspector5,atom?v16,arbace.inspector7,is-leafv11,arbace.core3,valv16,arbace.inspector9,get-childv11,arbace.core3,seqv11,arbace.core10,init-proxyv16,arbace.inspector15,get-child-countl-1,v11,arbace.core5,firstv11,arbace.core4,map?v11,arbace.core4,valsv11,arbace.core8,identityC16,java.lang.Objectv11,arbace.core4,namev11,arbace.core4,keysv11,arbace.core3,strv16,arbace.inspector10,tree-modell400,l600,v16,arbace.inspector15,old-table-modell400,l600,R8,l1,R9,R10,v11,arbace.core5,classv11,arbace.core7,vector?v11,arbace.core3,vecv11,arbace.core4,sortv11,arbace.core3,mapv11,arbace.core6,vectorl0,v11,arbace.core4,nextv11,arbace.core8,to-arrayl400,l400,v16,arbace.inspector10,list-modelv16,arbace.inspector13,list-provider")

var Lit_1 *jrt.String = jrt.Intern("java.awt.BorderLayout")

var Lit_2 *jrt.String = jrt.Intern("java.awt.event.ActionEvent")

var Lit_3 *jrt.String = jrt.Intern("java.awt.event.ActionListener")

var Lit_4 *jrt.String = jrt.Intern("javax.swing.tree.TreeModel")

var Lit_5 *jrt.String = jrt.Intern("javax.swing.table.TableModel")

var Lit_6 *jrt.String = jrt.Intern("javax.swing.table.AbstractTableModel")

var Lit_7 *jrt.String = jrt.Intern("javax.swing.JPanel")

var Lit_8 *jrt.String = jrt.Intern("javax.swing.JTree")

var Lit_9 *jrt.String = jrt.Intern("javax.swing.JTable")

var Lit_10 *jrt.String = jrt.Intern("javax.swing.JScrollPane")

var Lit_11 *jrt.String = jrt.Intern("javax.swing.JFrame")

var Lit_12 *jrt.String = jrt.Intern("javax.swing.JToolBar")

var Lit_13 *jrt.String = jrt.Intern("javax.swing.JButton")

var Lit_14 *jrt.String = jrt.Intern("javax.swing.SwingUtilities")

var Lit_15 *jrt.String = jrt.Intern("arbace.inspector$eval1049000098$fn__1049000099$fn__1049000100")

var Lit_16 *jrt.String = jrt.Intern("arbace.inspector$eval1049000098$fn__1049000099$fn__1049000102")

var Lit_17 *jrt.String = jrt.Intern("arbace.inspector$eval1049000106$fn__1049000107$fn__1049000108")

var Lit_18 *jrt.String = jrt.Intern("arbace.inspector$eval1049000106$fn__1049000107$fn__1049000110")

var Lit_19 *jrt.String = jrt.Intern("arbace.inspector$eval1049000114$fn__1049000115$fn__1049000117")

var Lit_20 *jrt.String = jrt.Intern("arbace.inspector$eval1049000114$fn__1049000115$fn__1049000122")

var Lit_21 *jrt.String = jrt.Intern("arbace.inspector$eval1049000114$fn__1049000115$fn__1049000124")

var Lit_22 *jrt.String = jrt.Intern("proxy of javax.swing.table.AbstractTableModel is not in the Go build")

var Lit_23 *jrt.String = jrt.Intern("Clojure Inspector")

var Lit_24 *jrt.String = jrt.Intern("add")

var Lit_25 *jrt.String = jrt.Intern("Back")

var Lit_26 *jrt.String = jrt.Intern("addSeparator")

var Lit_27 *jrt.String = jrt.Intern("List")

var Lit_28 *jrt.String = jrt.Intern("Table")

var Lit_29 *jrt.String = jrt.Intern("Bean")

var Lit_30 *jrt.String = jrt.Intern("Line")

var Lit_31 *jrt.String = jrt.Intern("Bar")

var Lit_32 *jrt.String = jrt.Intern("Prev")

var Lit_33 *jrt.String = jrt.Intern("Next")

var Lit_34 *jrt.String = jrt.Intern("NORTH")

var Lit_35 *jrt.String = jrt.Intern("setAutoResizeMode")

var Lit_36 *jrt.String = jrt.Intern("AUTO_RESIZE_LAST_COLUMN")

var Lit_37 *jrt.String = jrt.Intern("CENTER")

var Lit_38 *jrt.String = jrt.Intern("setSize")

var Lit_39 *jrt.String = jrt.Intern("setVisible")

var Lit_40 *jrt.String = jrt.Intern("arbace.inspector.proxy$java.lang.Object$TableModel$ab7d0f91")

var Lit_41 *jrt.String = jrt.Intern("addTableModelListener")

var Lit_42 *jrt.String = jrt.Intern("arbace.inspector$old_table_model$fn__1049000075")

var Lit_43 *jrt.String = jrt.Intern("getColumnClass")

var Lit_44 *jrt.String = jrt.Intern("arbace.inspector$old_table_model$fn__1049000077")

var Lit_45 *jrt.String = jrt.Intern("getColumnCount")

var Lit_46 *jrt.String = jrt.Intern("arbace.inspector$old_table_model$fn__1049000079")

var Lit_47 *jrt.String = jrt.Intern("getColumnName")

var Lit_48 *jrt.String = jrt.Intern("arbace.inspector$old_table_model$fn__1049000081")

var Lit_49 *jrt.String = jrt.Intern("getRowCount")

var Lit_50 *jrt.String = jrt.Intern("arbace.inspector$old_table_model$fn__1049000083")

var Lit_51 *jrt.String = jrt.Intern("getValueAt")

var Lit_52 *jrt.String = jrt.Intern("arbace.inspector$old_table_model$fn__1049000085")

var Lit_53 *jrt.String = jrt.Intern("isCellEditable")

var Lit_54 *jrt.String = jrt.Intern("arbace.inspector$old_table_model$fn__1049000087")

var Lit_55 *jrt.String = jrt.Intern("removeTableModelListener")

var Lit_56 *jrt.String = jrt.Intern("arbace.inspector$old_table_model$fn__1049000089")

var Lit_57 *jrt.String = jrt.Intern("arbace.inspector.proxy$java.lang.Object$TreeModel$775afa87")

var Lit_58 *jrt.String = jrt.Intern("getRoot")

var Lit_59 *jrt.String = jrt.Intern("arbace.inspector$tree_model$fn__1049000058")

var Lit_60 *jrt.String = jrt.Intern("addTreeModelListener")

var Lit_61 *jrt.String = jrt.Intern("arbace.inspector$tree_model$fn__1049000060")

var Lit_62 *jrt.String = jrt.Intern("getChild")

var Lit_63 *jrt.String = jrt.Intern("arbace.inspector$tree_model$fn__1049000062")

var Lit_64 *jrt.String = jrt.Intern("getChildCount")

var Lit_65 *jrt.String = jrt.Intern("arbace.inspector$tree_model$fn__1049000064")

var Lit_66 *jrt.String = jrt.Intern("isLeaf")

var Lit_67 *jrt.String = jrt.Intern("arbace.inspector$tree_model$fn__1049000066")

var Lit_68 *jrt.String = jrt.Intern("valueForPathChanged")

var Lit_69 *jrt.String = jrt.Intern("arbace.inspector$tree_model$fn__1049000068")

var Lit_70 *jrt.String = jrt.Intern("getIndexOfChild")

var Lit_71 *jrt.String = jrt.Intern("arbace.inspector$tree_model$fn__1049000070")

var Lit_72 *jrt.String = jrt.Intern("removeTreeModelListener")

var Lit_73 *jrt.String = jrt.Intern("arbace.inspector$tree_model$fn__1049000072")

var Lit_74 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn8,arglistsyn1,xkn4,linekn6,columnkn4,filekn7,defaultkn5,entrykn7,seqableyn4,datakn5,addedyn8,providerv11,arbace.core5,in-nsMyn16,arbace.inspectorm4,R0,s55,Graphical object inspector for Clojure data structures.R1,s11,Rich Hickeym4,R0,s55,Graphical object inspector for Clojure data structures.R1,s11,Rich HickeyR2,v16,arbace.inspector5,atom?m8,R3,L1,V1,R4,R5,i23,R6,i1,R7,s19,arbace/inspector.aev16,arbace.inspector14,collection-tagm8,R3,L1,V1,R4,R5,i26,R6,i1,R7,s19,arbace/inspector.aev16,arbace.inspector7,is-leafm6,R5,i35,R6,i1,R7,s19,arbace/inspector.aev11,arbace.core5,derefR8,v11,arbace.core16,global-hierarchym6,R5,i35,R6,i1,R7,s19,arbace/inspector.aev16,arbace.inspector9,get-childm6,R5,i36,R6,i1,R7,s19,arbace/inspector.aem6,R5,i36,R6,i1,R7,s19,arbace/inspector.aev16,arbace.inspector15,get-child-countm6,R5,i37,R6,i1,R7,s19,arbace/inspector.aem6,R5,i37,R6,i1,R7,s19,arbace/inspector.aeR9,R10,v16,arbace.inspector10,tree-modelm8,R3,L1,V1,R11,R5,i60,R6,i1,R7,s19,arbace/inspector.aev11,arbace.core15,get-proxy-classC16,java.lang.Objectv16,arbace.inspector15,old-table-modelm8,R3,L1,V1,R11,R5,i75,R6,i1,R7,s19,arbace/inspector.aev16,arbace.inspector12,inspect-treem12,R3,L1,V1,R11,R0,s71,creates a graphical (Swing) inspector on the supplied hierarchical dataR12,s3,1.0R5,i94,R6,i1,R7,s19,arbace/inspector.aev16,arbace.inspector13,inspect-tablem12,R3,L1,V1,R11,R0,s148,creates a graphical (Swing) inspector on the supplied regular\n  data, which must be a sequential data structure of data structures\n  of equal lengthR12,s3,1.0R5,i103,R6,i1,R7,s19,arbace/inspector.aev16,arbace.inspector13,list-providerm6,R5,i114,R6,i1,R7,s19,arbace/inspector.aev11,arbace.core5,classm6,R5,i114,R6,i1,R7,s19,arbace/inspector.aeC14,java.util.ListC13,java.util.Mapv16,arbace.inspector10,list-modelm8,R3,L1,V1,R13,R5,i131,R6,i1,R7,s19,arbace/inspector.aev16,arbace.inspector11,table-modelm6,R5,i141,R6,i1,R7,s19,arbace/inspector.aem6,R5,i141,R6,i1,R7,s19,arbace/inspector.aev16,arbace.inspector7,inspectm12,R3,L1,V1,R4,R0,s60,creates a graphical (Swing) inspector on the supplied objectR12,s3,1.0R5,i155,R6,i1,R7,s19,arbace/inspector.ae")

var Lit_75 *jrt.String = jrt.Intern("arbace.inspector$eval1049000004$loading__1927001464__auto____1049000005")

var Lit_76 *jrt.String = jrt.Intern("arbace.inspector$eval1049000008$fn__1049000009")

var Lit_77 *jrt.String = jrt.Intern("arbace.inspector$atom_QMARK_")

var Lit_78 *jrt.String = jrt.Intern("arbace.inspector$collection_tag")

var Lit_79 *jrt.String = jrt.Intern("is-leaf")

var Lit_80 *jrt.String = jrt.Intern("get-child")

var Lit_81 *jrt.String = jrt.Intern("arbace.inspector$eval1049000016$fn__1049000017")

var Lit_82 *jrt.String = jrt.Intern("get-child-count")

var Lit_83 *jrt.String = jrt.Intern("arbace.inspector$eval1049000022$fn__1049000023")

var Lit_84 *jrt.String = jrt.Intern("arbace.inspector$eval1049000026$fn__1049000027")

var Lit_85 *jrt.String = jrt.Intern("arbace.inspector$eval1049000030$fn__1049000031")

var Lit_86 *jrt.String = jrt.Intern("arbace.inspector$eval1049000034$fn__1049000035")

var Lit_87 *jrt.String = jrt.Intern("arbace.inspector$eval1049000038$fn__1049000039")

var Lit_88 *jrt.String = jrt.Intern("arbace.inspector$eval1049000042$fn__1049000043")

var Lit_89 *jrt.String = jrt.Intern("arbace.inspector$eval1049000046$fn__1049000047")

var Lit_90 *jrt.String = jrt.Intern("arbace.inspector$eval1049000050$fn__1049000051")

var Lit_91 *jrt.String = jrt.Intern("arbace.inspector$eval1049000054$fn__1049000055")

var Lit_92 *jrt.String = jrt.Intern("arbace.inspector$tree_model")

var Lit_93 *jrt.String = jrt.Intern("arbace.inspector$old_table_model")

var Lit_94 *jrt.String = jrt.Intern("arbace.inspector$inspect_tree")

var Lit_95 *jrt.String = jrt.Intern("arbace.inspector$inspect_table")

var Lit_96 *jrt.String = jrt.Intern("list-provider")

var Lit_97 *jrt.String = jrt.Intern("arbace.inspector$eval1049000098$fn__1049000099")

var Lit_98 *jrt.String = jrt.Intern("arbace.inspector$eval1049000106$fn__1049000107")

var Lit_99 *jrt.String = jrt.Intern("arbace.inspector$eval1049000114$fn__1049000115")

var Lit_100 *jrt.String = jrt.Intern("arbace.inspector$list_model")

var Lit_101 *jrt.String = jrt.Intern("table-model")

var Lit_102 *jrt.String = jrt.Intern("arbace.inspector$eval1049000133$fn__1049000134")

var Lit_103 *jrt.String = jrt.Intern("arbace.inspector$inspect")
