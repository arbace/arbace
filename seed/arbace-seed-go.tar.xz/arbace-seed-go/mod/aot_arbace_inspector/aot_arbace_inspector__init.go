//line aot_arbace_inspector__init.ae:1
package aot_arbace_inspector

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_inspector__init_A_Load__O() any { A_arbace_inspector__init_A_Init(); jrt.StartCheck(); A_arbace_inspector__init_A_Unit0__O(); A_arbace_inspector__init_A_Unit1__O(); A_arbace_inspector__init_A_Unit2__O(); A_arbace_inspector__init_A_Unit3__O(); A_arbace_inspector__init_A_Unit4__O(); A_arbace_inspector__init_A_Unit5__O(); A_arbace_inspector__init_A_Unit6__O(); A_arbace_inspector__init_A_Unit7__O(); A_arbace_inspector__init_A_Unit8__O(); A_arbace_inspector__init_A_Unit9__O(); A_arbace_inspector__init_A_Unit10__O(); A_arbace_inspector__init_A_Unit11__O(); A_arbace_inspector__init_A_Unit12__O(); A_arbace_inspector__init_A_Unit13__O(); A_arbace_inspector__init_A_Unit14__O(); A_arbace_inspector__init_A_Unit15__O(); A_arbace_inspector__init_A_Unit16__O(); A_arbace_inspector__init_A_Unit17__O(); A_arbace_inspector__init_A_Unit18__O(); A_arbace_inspector__init_A_Unit19__O(); A_arbace_inspector__init_A_Unit20__O(); A_arbace_inspector__init_A_Unit21__O(); A_arbace_inspector__init_A_Unit22__O(); A_arbace_inspector__init_A_Unit23__O(); A_arbace_inspector__init_A_Unit24__O(); A_arbace_inspector__init_A_Unit25__O(); A_arbace_inspector__init_A_Unit26__O(); A_arbace_inspector__init_A_Unit27__O(); A_arbace_inspector__init_A_Unit28__O(); A_arbace_inspector__init_A_Unit29__O(); A_arbace_inspector__init_A_Unit30__O(); return nil }







func A_arbace_inspector__init_A_Unit0__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return lang.IFn_Cast(A_arbace_inspector__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_inspector__init_A_const_1) }
//line :13:1
func A_arbace_inspector__init_A_Unit1__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_inspector__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_2)) }
//line :13:1
func A_arbace_inspector__init_A_Unit2__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 any = A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :13:1
func A_arbace_inspector__init_A_Unit3__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_inspector__init_A_const_1)).Equals_O__Z(A_arbace_inspector__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_inspector_eval1049000008_fn__1049000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_inspector_eval1049000008_fn__1049000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_inspector_eval1049000008_fn__1049000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }









func A_arbace_inspector__init_A_Unit4__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); var tmp1 *lang.Var = A_arbace_inspector__init_A_const_4; var tmp2 any = A_arbace_inspector_atom_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_inspector_atom_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_inspector_atom_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_inspector__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_5)); return A_arbace_inspector__init_A_const_4 }


func A_arbace_inspector__init_A_Unit5__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_inspector__init_A_const_6; var tmp2 any = A_arbace_inspector_collection_tag_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_inspector_collection_tag_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_inspector_collection_tag_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_inspector__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_7)); return A_arbace_inspector__init_A_const_6 }








func A_arbace_inspector__init_A_Unit6__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_inspector__init_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_9)); v__1927000386__auto____1 = A_arbace_inspector__init_A_const_8; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_5 any = A_arbace_inspector__init_A_const_10.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = v__1927000386__auto____1; if linked_6 == nil { tmp3 = ifn_7.Invoke_O__O(arg_8) } else { tmp3 = linked_6.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_5, arg_8) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_inspector__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_13)); var tmp5 *lang.Var = A_arbace_inspector__init_A_const_8; var tmp6 *jrt.String = Lit_79; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_inspector__init_A_const_6.GetRawRoot__O()); var tmp8 any = A_arbace_inspector__init_A_const_11; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp7, tmp8, A_arbace_inspector__init_A_const_12)); return A_arbace_inspector__init_A_const_8 } }
func A_arbace_inspector__init_A_Unit7__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_inspector__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_15)); v__1927000386__auto____1 = A_arbace_inspector__init_A_const_14; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_9 any = A_arbace_inspector__init_A_const_10.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = v__1927000386__auto____1; if linked_10 == nil { tmp3 = ifn_11.Invoke_O__O(arg_12) } else { tmp3 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_inspector__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_16)); var tmp5 *lang.Var = A_arbace_inspector__init_A_const_14; var tmp6 *jrt.String = Lit_80; var tmp7 any = A_arbace_inspector_eval1049000016_fn__1049000017_A_New(); var tmp8 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_inspector_eval1049000016_fn__1049000017_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_inspector_eval1049000016_fn__1049000017_A_fn_class = fncls__13d; tmp8 = fncls__13d } else { tmp8 = fncls__13 }; var tmp9 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_inspector__init_A_const_11; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_inspector__init_A_const_12)); return A_arbace_inspector__init_A_const_14 } }
func A_arbace_inspector__init_A_Unit8__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_inspector__init_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_18)); v__1927000386__auto____1 = A_arbace_inspector__init_A_const_17; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_14 any = A_arbace_inspector__init_A_const_10.GetRawRoot__O(); var linked_15 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_14, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_16 lang.IFn; if linked_15 == nil { ifn_16 = lang.IFn_Cast(root_14) } else { ifn_16 = nil }; var arg_17 any = v__1927000386__auto____1; if linked_15 == nil { tmp3 = ifn_16.Invoke_O__O(arg_17) } else { tmp3 = linked_15.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_14, arg_17) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_inspector__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_19)); var tmp5 *lang.Var = A_arbace_inspector__init_A_const_17; var tmp6 *jrt.String = Lit_82; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_inspector__init_A_const_6.GetRawRoot__O()); var tmp8 any = A_arbace_inspector__init_A_const_11; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp7, tmp8, A_arbace_inspector__init_A_const_12)); return A_arbace_inspector__init_A_const_17 } }

func A_arbace_inspector__init_A_Unit9__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_11; var tmp3 any = A_arbace_inspector_eval1049000022_fn__1049000023_A_New(); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_inspector_eval1049000022_fn__1049000023_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_inspector_eval1049000022_fn__1049000023_A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_inspector__init_A_Unit10__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_11; var tmp3 any = A_arbace_inspector_eval1049000026_fn__1049000027_A_New(); var tmp4 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_inspector_eval1049000026_fn__1049000027_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_inspector_eval1049000026_fn__1049000027_A_fn_class = fncls__19d; tmp4 = fncls__19d } else { tmp4 = fncls__19 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_inspector__init_A_Unit11__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_11; var tmp3 any = A_arbace_inspector_eval1049000030_fn__1049000031_A_New(); var tmp4 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_inspector_eval1049000030_fn__1049000031_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_inspector_eval1049000030_fn__1049000031_A_fn_class = fncls__20d; tmp4 = fncls__20d } else { tmp4 = fncls__20 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_inspector__init_A_Unit12__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_20; var tmp3 any = A_arbace_inspector_eval1049000034_fn__1049000035_A_New(); var tmp4 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_inspector_eval1049000034_fn__1049000035_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_inspector_eval1049000034_fn__1049000035_A_fn_class = fncls__21d; tmp4 = fncls__21d } else { tmp4 = fncls__21 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_inspector__init_A_Unit13__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_20; var tmp3 any = A_arbace_inspector_eval1049000038_fn__1049000039_A_New(); var tmp4 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_inspector_eval1049000038_fn__1049000039_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_inspector_eval1049000038_fn__1049000039_A_fn_class = fncls__22d; tmp4 = fncls__22d } else { tmp4 = fncls__22 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_inspector__init_A_Unit14__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(50, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_20; var tmp3 any = A_arbace_inspector_eval1049000042_fn__1049000043_A_New(); var tmp4 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_inspector_eval1049000042_fn__1049000043_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_inspector_eval1049000042_fn__1049000043_A_fn_class = fncls__23d; tmp4 = fncls__23d } else { tmp4 = fncls__23 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_inspector__init_A_Unit15__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_21; var tmp3 any = A_arbace_inspector_eval1049000046_fn__1049000047_A_New(); var tmp4 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_inspector_eval1049000046_fn__1049000047_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_inspector_eval1049000046_fn__1049000047_A_fn_class = fncls__24d; tmp4 = fncls__24d } else { tmp4 = fncls__24 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_inspector__init_A_Unit16__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_21; var tmp3 any = A_arbace_inspector_eval1049000050_fn__1049000051_A_New(); var tmp4 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_inspector_eval1049000050_fn__1049000051_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_inspector_eval1049000050_fn__1049000051_A_fn_class = fncls__25d; tmp4 = fncls__25d } else { tmp4 = fncls__25 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_inspector__init_A_Unit17__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(57, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_21; var tmp3 any = A_arbace_inspector_eval1049000054_fn__1049000055_A_New(); var tmp4 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_inspector_eval1049000054_fn__1049000055_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_inspector_eval1049000054_fn__1049000055_A_fn_class = fncls__26d; tmp4 = fncls__26d } else { tmp4 = fncls__26 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_inspector__init_A_Unit18__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 any = A_arbace_inspector__init_A_const_25; lang.IFn_Cast(A_arbace_inspector__init_A_const_24.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq_NoInit(tmp1, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4).Ref())))); var tmp2 *lang.Var = A_arbace_inspector__init_A_const_22; var tmp3 any = A_arbace_inspector_tree_model_A_New(); var tmp4 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_inspector_tree_model_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_inspector_tree_model_A_fn_class = fncls__27d; tmp4 = fncls__27d } else { tmp4 = fncls__27 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_inspector__init_A_const_22; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_23)); return A_arbace_inspector__init_A_const_22 }














func A_arbace_inspector__init_A_Unit19__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(75, 1); var tmp1 any = A_arbace_inspector__init_A_const_25; lang.IFn_Cast(A_arbace_inspector__init_A_const_24.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq_NoInit(tmp1, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5).Ref())))); var tmp2 *lang.Var = A_arbace_inspector__init_A_const_26; var tmp3 any = A_arbace_inspector_old_table_model_A_New(); var tmp4 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_inspector_old_table_model_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_inspector_old_table_model_A_fn_class = fncls__28d; tmp4 = fncls__28d } else { tmp4 = fncls__28 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_inspector__init_A_const_26; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_27)); return A_arbace_inspector__init_A_const_26 }


















func A_arbace_inspector__init_A_Unit20__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); var tmp1 *lang.Var = A_arbace_inspector__init_A_const_28; var tmp2 any = A_arbace_inspector_inspect_tree_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_inspector_inspect_tree_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_inspector_inspect_tree_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_inspector__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_29)); return A_arbace_inspector__init_A_const_28 }








func A_arbace_inspector__init_A_Unit21__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_inspector__init_A_const_30; var tmp2 any = A_arbace_inspector_inspect_table_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_inspector_inspect_table_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_inspector_inspect_table_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_inspector__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_31)); return A_arbace_inspector__init_A_const_30 }










func A_arbace_inspector__init_A_Unit22__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_inspector__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_33)); v__1927000386__auto____1 = A_arbace_inspector__init_A_const_32; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_31 any = A_arbace_inspector__init_A_const_10.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = v__1927000386__auto____1; if linked_32 == nil { tmp3 = ifn_33.Invoke_O__O(arg_34) } else { tmp3 = linked_32.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_31, arg_34) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_inspector__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_35)); var tmp5 *lang.Var = A_arbace_inspector__init_A_const_32; var tmp6 *jrt.String = Lit_96; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_inspector__init_A_const_34.GetRawRoot__O()); var tmp8 any = A_arbace_inspector__init_A_const_11; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp7, tmp8, A_arbace_inspector__init_A_const_12)); return A_arbace_inspector__init_A_const_32 } }

func A_arbace_inspector__init_A_Unit23__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_32.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_11; var tmp3 any = A_arbace_inspector_eval1049000098_fn__1049000099_A_New(); var tmp4 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_inspector_eval1049000098_fn__1049000099_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_inspector_eval1049000098_fn__1049000099_A_fn_class = fncls__35d; tmp4 = fncls__35d } else { tmp4 = fncls__35 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_inspector__init_A_Unit24__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(119, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_32.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_36; var tmp3 any = A_arbace_inspector_eval1049000106_fn__1049000107_A_New(); var tmp4 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_inspector_eval1049000106_fn__1049000107_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_inspector_eval1049000106_fn__1049000107_A_fn_class = fncls__36d; tmp4 = fncls__36d } else { tmp4 = fncls__36 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_inspector__init_A_Unit25__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_32.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_37; var tmp3 any = A_arbace_inspector_eval1049000114_fn__1049000115_A_New(); var tmp4 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_inspector_eval1049000114_fn__1049000115_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_inspector_eval1049000114_fn__1049000115_A_fn_class = fncls__37d; tmp4 = fncls__37d } else { tmp4 = fncls__37 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_inspector__init_A_Unit26__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(131, 1); var tmp1 *lang.Var = A_arbace_inspector__init_A_const_38; var tmp2 any = A_arbace_inspector_list_model_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_inspector_list_model_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_inspector_list_model_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_inspector__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_39)); return A_arbace_inspector__init_A_const_38 }









func A_arbace_inspector__init_A_Unit27__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_inspector__init_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_41)); v__1927000386__auto____1 = A_arbace_inspector__init_A_const_40; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_39 any = A_arbace_inspector__init_A_const_10.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = v__1927000386__auto____1; if linked_40 == nil { tmp3 = ifn_41.Invoke_O__O(arg_42) } else { tmp3 = linked_40.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_39, arg_42) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_inspector__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_42)); var tmp5 *lang.Var = A_arbace_inspector__init_A_const_40; var tmp6 *jrt.String = Lit_101; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_inspector__init_A_const_34.GetRawRoot__O()); var tmp8 any = A_arbace_inspector__init_A_const_11; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp7, tmp8, A_arbace_inspector__init_A_const_12)); return A_arbace_inspector__init_A_const_40 } }

func A_arbace_inspector__init_A_Unit28__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_inspector__init_A_const_40.GetRawRoot__O()); var tmp2 any = A_arbace_inspector__init_A_const_11; var tmp3 any = A_arbace_inspector_eval1049000133_fn__1049000134_A_New(); var tmp4 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_inspector_eval1049000133_fn__1049000134_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_inspector_eval1049000133_fn__1049000134_A_fn_class = fncls__43d; tmp4 = fncls__43d } else { tmp4 = fncls__43 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }











func A_arbace_inspector__init_A_Unit29__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(155, 1); var tmp1 *lang.Var = A_arbace_inspector__init_A_const_43; var tmp2 any = A_arbace_inspector_inspect_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_inspector_inspect_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_inspector_inspect_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_inspector__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_inspector__init_A_const_44)); return A_arbace_inspector__init_A_const_43 }


























func A_arbace_inspector__init_A_Unit30__O() any { A_arbace_inspector__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); return nil }



type A_arbace_inspector__init_A struct{ jrt.Object }

var A_arbace_inspector__init_A_const_pool *jrt.RefArray

var A_arbace_inspector__init_A_const_0 *lang.Var

var A_arbace_inspector__init_A_const_1 any

var A_arbace_inspector__init_A_const_2 any

var A_arbace_inspector__init_A_const_3 any

var A_arbace_inspector__init_A_const_4 *lang.Var

var A_arbace_inspector__init_A_const_5 any

var A_arbace_inspector__init_A_const_6 *lang.Var

var A_arbace_inspector__init_A_const_7 any

var A_arbace_inspector__init_A_const_8 *lang.Var

var A_arbace_inspector__init_A_const_9 any

var A_arbace_inspector__init_A_const_10 *lang.Var

var A_arbace_inspector__init_A_const_11 *lang.Keyword

var A_arbace_inspector__init_A_const_12 *lang.Var

var A_arbace_inspector__init_A_const_13 any

var A_arbace_inspector__init_A_const_14 *lang.Var

var A_arbace_inspector__init_A_const_15 any

var A_arbace_inspector__init_A_const_16 any

var A_arbace_inspector__init_A_const_17 *lang.Var

var A_arbace_inspector__init_A_const_18 any

var A_arbace_inspector__init_A_const_19 any

var A_arbace_inspector__init_A_const_20 *lang.Keyword

var A_arbace_inspector__init_A_const_21 *lang.Keyword

var A_arbace_inspector__init_A_const_22 *lang.Var

var A_arbace_inspector__init_A_const_23 any

var A_arbace_inspector__init_A_const_24 *lang.Var

var A_arbace_inspector__init_A_const_25 *jrt.Class

var A_arbace_inspector__init_A_const_26 *lang.Var

var A_arbace_inspector__init_A_const_27 any

var A_arbace_inspector__init_A_const_28 *lang.Var

var A_arbace_inspector__init_A_const_29 any

var A_arbace_inspector__init_A_const_30 *lang.Var

var A_arbace_inspector__init_A_const_31 any

var A_arbace_inspector__init_A_const_32 *lang.Var

var A_arbace_inspector__init_A_const_33 any

var A_arbace_inspector__init_A_const_34 *lang.Var

var A_arbace_inspector__init_A_const_35 any

var A_arbace_inspector__init_A_const_36 *jrt.Class

var A_arbace_inspector__init_A_const_37 *jrt.Class

var A_arbace_inspector__init_A_const_38 *lang.Var

var A_arbace_inspector__init_A_const_39 any

var A_arbace_inspector__init_A_const_40 *lang.Var

var A_arbace_inspector__init_A_const_41 any

var A_arbace_inspector__init_A_const_42 any

var A_arbace_inspector__init_A_const_43 *lang.Var

var A_arbace_inspector__init_A_const_44 any

var A_arbace_inspector__init_A_init jrt.ClassInit

func A_arbace_inspector__init_A_Init() { if !A_arbace_inspector__init_A_init.Done() { A_arbace_inspector__init_A_init.Run(A_arbace_inspector__init_A_clinit) } }

func A_arbace_inspector__init_A_clinit() { A_arbace_inspector__init_A_clinit_p0(); A_arbace_inspector__init_A_clinit_p1(); A_arbace_inspector__init_A_clinit_p2(); A_arbace_inspector__init_A_clinit_p3() }

func A_arbace_inspector__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_inspector__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_74, 59); A_arbace_inspector__init_A_const_0 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[14]); A_arbace_inspector__init_A_const_1 = A_arbace_inspector__init_A_const_pool.A[15]; A_arbace_inspector__init_A_const_2 = A_arbace_inspector__init_A_const_pool.A[16]; A_arbace_inspector__init_A_const_3 = A_arbace_inspector__init_A_const_pool.A[17]; A_arbace_inspector__init_A_const_4 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[18]); A_arbace_inspector__init_A_const_5 = A_arbace_inspector__init_A_const_pool.A[19]; A_arbace_inspector__init_A_const_6 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[20]); A_arbace_inspector__init_A_const_7 = A_arbace_inspector__init_A_const_pool.A[21]; A_arbace_inspector__init_A_const_8 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[22]); A_arbace_inspector__init_A_const_9 = A_arbace_inspector__init_A_const_pool.A[23]; A_arbace_inspector__init_A_const_10 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[24]); A_arbace_inspector__init_A_const_11 = lang.Keyword_Cast(A_arbace_inspector__init_A_const_pool.A[25]) }

func A_arbace_inspector__init_A_clinit_p1() { A_arbace_inspector__init_A_const_12 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[26]); A_arbace_inspector__init_A_const_13 = A_arbace_inspector__init_A_const_pool.A[27]; A_arbace_inspector__init_A_const_14 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[28]); A_arbace_inspector__init_A_const_15 = A_arbace_inspector__init_A_const_pool.A[29]; A_arbace_inspector__init_A_const_16 = A_arbace_inspector__init_A_const_pool.A[30]; A_arbace_inspector__init_A_const_17 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[31]); A_arbace_inspector__init_A_const_18 = A_arbace_inspector__init_A_const_pool.A[32]; A_arbace_inspector__init_A_const_19 = A_arbace_inspector__init_A_const_pool.A[33]; A_arbace_inspector__init_A_const_20 = lang.Keyword_Cast(A_arbace_inspector__init_A_const_pool.A[34]); A_arbace_inspector__init_A_const_21 = lang.Keyword_Cast(A_arbace_inspector__init_A_const_pool.A[35]); A_arbace_inspector__init_A_const_22 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[36]); A_arbace_inspector__init_A_const_23 = A_arbace_inspector__init_A_const_pool.A[37]; A_arbace_inspector__init_A_const_24 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[38]) }

func A_arbace_inspector__init_A_clinit_p2() { A_arbace_inspector__init_A_const_25 = jrt.Class_Cast(A_arbace_inspector__init_A_const_pool.A[39]); A_arbace_inspector__init_A_const_26 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[40]); A_arbace_inspector__init_A_const_27 = A_arbace_inspector__init_A_const_pool.A[41]; A_arbace_inspector__init_A_const_28 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[42]); A_arbace_inspector__init_A_const_29 = A_arbace_inspector__init_A_const_pool.A[43]; A_arbace_inspector__init_A_const_30 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[44]); A_arbace_inspector__init_A_const_31 = A_arbace_inspector__init_A_const_pool.A[45]; A_arbace_inspector__init_A_const_32 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[46]); A_arbace_inspector__init_A_const_33 = A_arbace_inspector__init_A_const_pool.A[47]; A_arbace_inspector__init_A_const_34 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[48]); A_arbace_inspector__init_A_const_35 = A_arbace_inspector__init_A_const_pool.A[49]; A_arbace_inspector__init_A_const_36 = jrt.Class_Cast(A_arbace_inspector__init_A_const_pool.A[50]); A_arbace_inspector__init_A_const_37 = jrt.Class_Cast(A_arbace_inspector__init_A_const_pool.A[51]) }

func A_arbace_inspector__init_A_clinit_p3() { A_arbace_inspector__init_A_const_38 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[52]); A_arbace_inspector__init_A_const_39 = A_arbace_inspector__init_A_const_pool.A[53]; A_arbace_inspector__init_A_const_40 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[54]); A_arbace_inspector__init_A_const_41 = A_arbace_inspector__init_A_const_pool.A[55]; A_arbace_inspector__init_A_const_42 = A_arbace_inspector__init_A_const_pool.A[56]; A_arbace_inspector__init_A_const_43 = lang.Var_Cast(A_arbace_inspector__init_A_const_pool.A[57]); A_arbace_inspector__init_A_const_44 = A_arbace_inspector__init_A_const_pool.A[58] }

func A_arbace_inspector__init_A_New() *A_arbace_inspector__init_A { A_arbace_inspector__init_A_Init(); t := &A_arbace_inspector__init_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector__init_A) Ctor() {}

func (t *A_arbace_inspector__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector__init_A) GetClass__Class() *jrt.Class { return A_arbace_inspector__init_A_class }

func (t *A_arbace_inspector__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector__init_A); return ok }

func A_arbace_inspector__init_A_Cast(x any) *A_arbace_inspector__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector__init_A_class)) }; return v }
