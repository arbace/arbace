//line aot_arbace_inspector.ae:1
package aot_arbace_inspector

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)





func A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A_New() *A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A) Ctor() {}
//line :13:1
func (t *A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_inspector_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_inspector_A_const_1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :13:1
func A_arbace_inspector_eval1049000008_fn__1049000009_A_New() *A_arbace_inspector_eval1049000008_fn__1049000009_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000008_fn__1049000009_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_inspector_eval1049000008_fn__1049000009_A) Ctor() {}
//line :13:1
func (t *A_arbace_inspector_eval1049000008_fn__1049000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_inspector_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_inspector_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_inspector_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_inspector_A_const_5.GetRawRoot__O(), A_arbace_inspector_A_const_6) }









func A_arbace_inspector_atom_QMARK__A_New() *A_arbace_inspector_atom_QMARK__A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_atom_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_inspector_atom_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_inspector_atom_QMARK__A) Invoke_O_O__O(self, x__0 any) any {
	var root_15 any = A_arbace_inspector_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var root_19 any = A_arbace_inspector_A_const_8.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_coll_QMARK__A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = x__0; if linked_20 == nil { arg_18 = ifn_21.Invoke_O__O(arg_22) } else { arg_18 = linked_20.(*aot_arbace_core.A_arbace_core_coll_QMARK__A).Invoke_O_O__O(root_19, arg_22) }; if linked_16 == nil { return ifn_17.Invoke_O__O(arg_18) } else { return linked_16.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_15, arg_18)
	} }
func A_arbace_inspector_collection_tag_A_New() *A_arbace_inspector_collection_tag_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_collection_tag_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_inspector_collection_tag_A) Ctor() {}
//line :26:1
func (t *A_arbace_inspector_collection_tag_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var root_23 any = A_arbace_inspector_A_const_9.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_map_entry_QMARK__A_fn_class); var ifn_25 lang.IFn
	if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = x__0; if linked_24 == nil { tmp1 = ifn_25.Invoke_O__O(arg_26) } else { tmp1 = linked_24.(*aot_arbace_core.A_arbace_core_map_entry_QMARK__A).Invoke_O_O__O(root_23, arg_26) }
//line :27:1
	if jrt.J2g_Truth(tmp1) { return A_arbace_inspector_A_const_10 } else { if jrt.Map_InstanceOf(x__0) { return A_arbace_inspector_A_const_11 } else { if jrt.Set_InstanceOf(x__0) { return A_arbace_inspector_A_const_11 } else { var tmp2 any; var root_27 any = A_arbace_inspector_A_const_12.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_29 lang.IFn



		if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = x__0; if linked_28 == nil { tmp2 = ifn_29.Invoke_O__O(arg_30) } else { tmp2 = linked_28.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_27, arg_30) }
//line :27:1
		if jrt.J2g_Truth(tmp2) { return A_arbace_inspector_A_const_13 } else { if lang.Seqable_InstanceOf(x__0) { return A_arbace_inspector_A_const_11 } else { if A_arbace_inspector_A_const_14 != nil { return A_arbace_inspector_A_const_15 } else { return nil
		}
		}
		}
	}
	}
	}
}

func A_arbace_inspector_eval1049000016_fn__1049000017_A_New() *A_arbace_inspector_eval1049000016_fn__1049000017_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000016_fn__1049000017_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_inspector_eval1049000016_fn__1049000017_A) Ctor() {}
//line :36:1
func (t *A_arbace_inspector_eval1049000016_fn__1049000017_A) Invoke_O_O_O__O(self, parent__1, index__2 any) any { var root_31 any = A_arbace_inspector_A_const_16.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, A_arbace_inspector_collection_tag_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = parent__1; if linked_32 == nil { return ifn_33.Invoke_O__O(arg_34) } else { return linked_32.(*A_arbace_inspector_collection_tag_A).Invoke_O_O__O(root_31, arg_34) } }


func A_arbace_inspector_eval1049000022_fn__1049000023_A_New() *A_arbace_inspector_eval1049000022_fn__1049000023_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000022_fn__1049000023_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_inspector_eval1049000022_fn__1049000023_A) Ctor() {}
//line :39:1
func (t *A_arbace_inspector_eval1049000022_fn__1049000023_A) Invoke_O_O__O(self, node__1 any) any {
	var root_35 any = A_arbace_inspector_A_const_17.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, A_arbace_inspector_atom_QMARK__A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = node__1; if linked_36 == nil { return ifn_37.Invoke_O__O(arg_38) } else { return linked_36.(*A_arbace_inspector_atom_QMARK__A).Invoke_O_O__O(root_35, arg_38) } }
func A_arbace_inspector_eval1049000026_fn__1049000027_A_New() *A_arbace_inspector_eval1049000026_fn__1049000027_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000026_fn__1049000027_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_inspector_eval1049000026_fn__1049000027_A) Ctor() {}
//line :41:1
func (t *A_arbace_inspector_eval1049000026_fn__1049000027_A) Invoke_O_O_O__O(self, parent__1, index__2 any) any {
	return lang.RT_Nth_O_I__O_NoInit(parent__1, lang.RT_IntCast_O__I_NoInit(index__2)) }
func A_arbace_inspector_eval1049000030_fn__1049000031_A_New() *A_arbace_inspector_eval1049000030_fn__1049000031_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000030_fn__1049000031_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_inspector_eval1049000030_fn__1049000031_A) Ctor() {}
//line :43:1
func (t *A_arbace_inspector_eval1049000030_fn__1049000031_A) Invoke_O_O__O(self, parent__1 any) any {
	return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(parent__1)).Ref()
}
func A_arbace_inspector_eval1049000034_fn__1049000035_A_New() *A_arbace_inspector_eval1049000034_fn__1049000035_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000034_fn__1049000035_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_inspector_eval1049000034_fn__1049000035_A) Ctor() {}
//line :46:1
func (t *A_arbace_inspector_eval1049000034_fn__1049000035_A) Invoke_O_O__O(self, e__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_inspector_A_const_18.GetRawRoot__O()); var tmp2 any; var root_39 any = A_arbace_inspector_A_const_19.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = e__1; if linked_40 == nil { tmp2 = ifn_41.Invoke_O__O(arg_42) } else { tmp2 = linked_40.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_39, arg_42) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_inspector_eval1049000038_fn__1049000039_A_New() *A_arbace_inspector_eval1049000038_fn__1049000039_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000038_fn__1049000039_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_inspector_eval1049000038_fn__1049000039_A) Ctor() {}
//line :48:1
func (t *A_arbace_inspector_eval1049000038_fn__1049000039_A) Invoke_O_O_O__O(self, e__1, index__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_inspector_A_const_20.GetRawRoot__O()); var tmp2 any; var root_43 any = A_arbace_inspector_A_const_19.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = e__1; if linked_44 == nil { tmp2 = ifn_45.Invoke_O__O(arg_46) } else { tmp2 = linked_44.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_43, arg_46) }; return tmp1.Invoke_O_O__O(tmp2, index__2) }
func A_arbace_inspector_eval1049000042_fn__1049000043_A_New() *A_arbace_inspector_eval1049000042_fn__1049000043_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000042_fn__1049000043_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_inspector_eval1049000042_fn__1049000043_A) Ctor() {}
//line :50:1
func (t *A_arbace_inspector_eval1049000042_fn__1049000043_A) Invoke_O_O__O(self, e__1 any) any {
	var tmp1 any; var root_47 any = A_arbace_inspector_A_const_19.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = e__1; if linked_48 == nil { tmp1 = ifn_49.Invoke_O__O(arg_50) } else { tmp1 = linked_48.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_47, arg_50) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref()
}
func A_arbace_inspector_eval1049000046_fn__1049000047_A_New() *A_arbace_inspector_eval1049000046_fn__1049000047_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000046_fn__1049000047_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_inspector_eval1049000046_fn__1049000047_A) Ctor() {}
//line :53:1
func (t *A_arbace_inspector_eval1049000046_fn__1049000047_A) Invoke_O_O__O(self, parent__1 any) any { return jrt.Boolean_FALSE.Ref() }

func A_arbace_inspector_eval1049000050_fn__1049000051_A_New() *A_arbace_inspector_eval1049000050_fn__1049000051_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000050_fn__1049000051_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_inspector_eval1049000050_fn__1049000051_A) Ctor() {}
//line :55:1
func (t *A_arbace_inspector_eval1049000050_fn__1049000051_A) Invoke_O_O_O__O(self, parent__1, index__2 any) any {
	var tmp1 any; var root_51 any = A_arbace_inspector_A_const_21.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = parent__1; if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_51, arg_54) }; return lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(index__2)) }
func A_arbace_inspector_eval1049000054_fn__1049000055_A_New() *A_arbace_inspector_eval1049000054_fn__1049000055_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000054_fn__1049000055_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_inspector_eval1049000054_fn__1049000055_A) Ctor() {}
//line :57:1
func (t *A_arbace_inspector_eval1049000054_fn__1049000055_A) Invoke_O_O__O(self, parent__1 any) any {
	var tmp1 any; var root_55 any = A_arbace_inspector_A_const_21.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = parent__1; if linked_56 == nil { tmp1 = ifn_57.Invoke_O__O(arg_58) } else { tmp1 = linked_56.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_55, arg_58) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref()
}
func A_arbace_inspector_tree_model_A_New() *A_arbace_inspector_tree_model_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_inspector_tree_model_A) Ctor() {}
//line :60:1
func (t *A_arbace_inspector_tree_model_A) Invoke_O_O__O(self, data__0 any) any { var p__840000142__auto____2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_57), jrt.RefArrayOf(jrt.Object_class)); var root_59 any = A_arbace_inspector_A_const_22.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_61 lang.IFn; if
										linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = p__840000142__auto____2; var arg_63 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__65 any = A_arbace_inspector_tree_model_fn__1049000058_A_New_O(data__0); var tmp2 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000058_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__65); A_arbace_inspector_tree_model_fn__1049000058_A_fn_class = fncls__64d; tmp2 = fncls__64d } else { tmp2 = fncls__64 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__65, tmp2, nil); var tmp3 any = tmp1.Ref(); var tmp4 *lang.Compiler_AOTFn; var fnbody__67 any = A_arbace_inspector_tree_model_fn__1049000060_A_New(); var tmp5 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000060_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, nil); A_arbace_inspector_tree_model_fn__1049000060_A_fn_class = fncls__66d; tmp5 = fncls__66d } else { tmp5 = fncls__66 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__67, tmp5, nil); var tmp6 any = tmp4.Ref(); var tmp7 *lang.Compiler_AOTFn; var fnbody__69 any = A_arbace_inspector_tree_model_fn__1049000062_A_New(); var tmp8 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000062_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_inspector_tree_model_fn__1049000062_A_fn_class = fncls__68d; tmp8 = fncls__68d } else { tmp8 = fncls__68 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp8, nil); var tmp9 any = tmp7.Ref(); var tmp10 *lang.Compiler_AOTFn; var fnbody__71 any = A_arbace_inspector_tree_model_fn__1049000064_A_New(); var tmp11 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000064_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_inspector_tree_model_fn__1049000064_A_fn_class = fncls__70d; tmp11 = fncls__70d } else { tmp11 = fncls__70 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__71, tmp11, nil); var tmp12 any = tmp10.Ref(); var tmp13 *lang.Compiler_AOTFn; var fnbody__73 any = A_arbace_inspector_tree_model_fn__1049000066_A_New(); var tmp14 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000066_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); A_arbace_inspector_tree_model_fn__1049000066_A_fn_class = fncls__72d; tmp14 = fncls__72d } else { tmp14 = fncls__72 }; tmp13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__73, tmp14, nil); var tmp15 any = tmp13.Ref(); var tmp16 *lang.Compiler_AOTFn; var fnbody__75 any = A_arbace_inspector_tree_model_fn__1049000068_A_New(); var tmp17 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000068_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); A_arbace_inspector_tree_model_fn__1049000068_A_fn_class = fncls__74d; tmp17 = fncls__74d } else { tmp17 = fncls__74 }; tmp16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__75, tmp17, nil); var tmp18 any = tmp16.Ref(); var tmp19 *lang.Compiler_AOTFn; var fnbody__77 any = A_arbace_inspector_tree_model_fn__1049000070_A_New(); var tmp20 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000070_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_inspector_tree_model_fn__1049000070_A_fn_class = fncls__76d; tmp20 = fncls__76d } else { tmp20 = fncls__76 }; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__77, tmp20, nil); var tmp21 any = tmp19.Ref(); var tmp22 *lang.Compiler_AOTFn; var fnbody__79 any = A_arbace_inspector_tree_model_fn__1049000072_A_New(); var tmp23 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000072_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_inspector_tree_model_fn__1049000072_A_fn_class = fncls__78d; tmp23 = fncls__78d } else { tmp23 = fncls__78 }; tmp22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp23, nil); arg_63 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_58, tmp3, Lit_60, tmp6, Lit_62, tmp9, Lit_64, tmp12, Lit_66, tmp15, Lit_68, tmp18, Lit_70, tmp21, Lit_72, tmp22.Ref())); if linked_60 == nil { ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { linked_60.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; return p__840000142__auto____2 }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000058_A_New_O(p0 any) *A_arbace_inspector_tree_model_fn__1049000058_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000058_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000058_A) Ctor_O(c__data any) { t.F_data = c__data }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000058_A) Invoke_O_O__O(self, this__1 any) any { return t.F_data }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000060_A_New() *A_arbace_inspector_tree_model_fn__1049000060_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000060_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000060_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000060_A) Invoke_O_O_O__O(self, this__1, treeModelListener__2 any) any { return nil }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000062_A_New() *A_arbace_inspector_tree_model_fn__1049000062_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000062_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000062_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000062_A) Invoke_O_O_O_O__O(self, this__1, parent__2, index__3 any) any {



	return lang.IFn_Cast(A_arbace_inspector_A_const_20.GetRawRoot__O()).Invoke_O_O__O(parent__2, index__3) }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000064_A_New() *A_arbace_inspector_tree_model_fn__1049000064_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000064_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000064_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000064_A) Invoke_O_O_O__O(self, this__1, parent__2 any) any {





	return lang.IFn_Cast(A_arbace_inspector_A_const_23.GetRawRoot__O()).Invoke_O__O(parent__2) }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000066_A_New() *A_arbace_inspector_tree_model_fn__1049000066_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000066_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000066_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000066_A) Invoke_O_O_O__O(self, this__1, node__2 any) any {







	return lang.IFn_Cast(A_arbace_inspector_A_const_18.GetRawRoot__O()).Invoke_O__O(node__2) }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000068_A_New() *A_arbace_inspector_tree_model_fn__1049000068_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000068_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000068_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000068_A) Invoke_O_O_O_O__O(self, this__1, path__2, newValue__3 any) any { return nil }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000070_A_New() *A_arbace_inspector_tree_model_fn__1049000070_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000070_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000070_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000070_A) Invoke_O_O_O_O__O(self, this__1, parent__2, child__3 any) any { return A_arbace_inspector_A_const_24 }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000072_A_New() *A_arbace_inspector_tree_model_fn__1049000072_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000072_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000072_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000072_A) Invoke_O_O_O__O(self, this__1, treeModelListener__2 any) any { return nil }













func A_arbace_inspector_old_table_model_A_New() *A_arbace_inspector_old_table_model_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_inspector_old_table_model_A) Ctor() {}
//line :75:1
func (t *A_arbace_inspector_old_table_model_A) Invoke_O_O__O(self, data__0 any) any { var row1__2 any; var root_80 any = A_arbace_inspector_A_const_25.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_82 lang.IFn; if
											linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = data__0; if linked_81 == nil { row1__2 = ifn_82.Invoke_O__O(arg_83) } else { row1__2 = linked_81.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_80, arg_83) }; var colcnt__3 int32 = /*line :75:1*/lang.RT_Count_O__I_NoInit(row1__2); var cnt__4 int32 = lang.RT_Count_O__I_NoInit(data__0); var vals__5 any; var tmp1 any; var root_84 any = A_arbace_inspector_A_const_26.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_86 lang.IFn; if



	linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = row1__2; if linked_85 == nil { tmp1 = ifn_86.Invoke_O__O(arg_87) } else { tmp1 = linked_85.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_84, arg_87) }; if jrt.J2g_Truth(tmp1) { vals__5 = A_arbace_inspector_A_const_27.GetRawRoot__O() } else { vals__5 = A_arbace_inspector_A_const_28.GetRawRoot__O() }; var p__840000142__auto____6 any = /*line :75:1*/lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_40), jrt.RefArrayOf(jrt.Object_class)); var root_88 any = A_arbace_inspector_A_const_22.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_90 lang.IFn; if




	linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = p__840000142__auto____6; var arg_92 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_inspector_old_table_model_fn__1049000075_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000075_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, nil); A_arbace_inspector_old_table_model_fn__1049000075_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); var tmp4 any = tmp2.Ref(); var tmp5 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_inspector_old_table_model_fn__1049000077_A_New(); var tmp6 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000077_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_inspector_old_table_model_fn__1049000077_A_fn_class = fncls__95d; tmp6 = fncls__95d } else { tmp6 = fncls__95 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp6, nil); var tmp7 any = tmp5.Ref(); var tmp8 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_inspector_old_table_model_fn__1049000079_A_New_I(colcnt__3); var tmp9 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000079_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__98); A_arbace_inspector_old_table_model_fn__1049000079_A_fn_class = fncls__97d; tmp9 = fncls__97d } else { tmp9 = fncls__97 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp9, nil); var tmp10 any = tmp8.Ref(); var tmp11 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_inspector_old_table_model_fn__1049000081_A_New_O(row1__2); var tmp12 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000081_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__116); A_arbace_inspector_old_table_model_fn__1049000081_A_fn_class = fncls__115d; tmp12 = fncls__115d } else { tmp12 = fncls__115 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp12, nil); var tmp13 any = tmp11.Ref(); var tmp14 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_inspector_old_table_model_fn__1049000083_A_New_I(cnt__4); var tmp15 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000083_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__118); A_arbace_inspector_old_table_model_fn__1049000083_A_fn_class = fncls__117d; tmp15 = fncls__117d } else { tmp15 = fncls__117 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp15, nil); var tmp16 any = tmp14.Ref(); var tmp17 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_inspector_old_table_model_fn__1049000085_A_New_O_O(data__0, vals__5); var tmp18 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000085_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__120); A_arbace_inspector_old_table_model_fn__1049000085_A_fn_class = fncls__119d; tmp18 = fncls__119d } else { tmp18 = fncls__119 }; tmp17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp18, nil); var tmp19 any = tmp17.Ref(); var tmp20 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_inspector_old_table_model_fn__1049000087_A_New(); var tmp21 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000087_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_inspector_old_table_model_fn__1049000087_A_fn_class = fncls__121d; tmp21 = fncls__121d } else { tmp21 = fncls__121 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp21, nil); var tmp22 any = tmp20.Ref(); var tmp23 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_inspector_old_table_model_fn__1049000089_A_New(); var tmp24 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000089_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_inspector_old_table_model_fn__1049000089_A_fn_class = fncls__123d; tmp24 = fncls__123d } else { tmp24 = fncls__123 }; tmp23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp24, nil); arg_92 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_41, tmp4, Lit_43, tmp7, Lit_45, tmp10, Lit_47, tmp13, Lit_49, tmp16, Lit_51, tmp19, Lit_53, tmp22, Lit_55, tmp23.Ref())); if linked_89 == nil { ifn_90.Invoke_O_O__O(arg_91, arg_92) } else { linked_89.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_88, arg_91, arg_92) }; return p__840000142__auto____6 }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000075_A_New() *A_arbace_inspector_old_table_model_fn__1049000075_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000075_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000075_A) Ctor() {}
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000075_A) Invoke_O_O_O__O(self, this__1, tableModelListener__2 any) any { return nil }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000077_A_New() *A_arbace_inspector_old_table_model_fn__1049000077_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000077_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000077_A) Ctor() {}
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000077_A) Invoke_O_O_O__O(self, this__1, columnIndex__2 any) any { return A_arbace_inspector_A_const_29 }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000079_A_New_I(p0 int32) *A_arbace_inspector_old_table_model_fn__1049000079_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000079_A{}; t.Ctor_I(p0); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000079_A) Ctor_I(c__colcnt int32) { t.F_colcnt = c__colcnt }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000079_A) Invoke_O_O__O(self, this__1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(t.F_colcnt).Ref() }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000081_A_New_O(p0 any) *A_arbace_inspector_old_table_model_fn__1049000081_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000081_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000081_A) Ctor_O(c__row1 any) { t.F_row1 = c__row1 }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000081_A) Invoke_O_O_O__O(self, this__1, columnIndex__2 any) any {




	var tmp1 any; var root_99 any = A_arbace_inspector_A_const_26.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = t.F_row1; if linked_100 == nil { tmp1 = ifn_101.Invoke_O__O(arg_102) } else { tmp1 = linked_100.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_99, arg_102) }; if jrt.J2g_Truth(tmp1) {
		var root_103 any = A_arbace_inspector_A_const_30.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any; var tmp2 any; var root_107 any = A_arbace_inspector_A_const_31.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = t.F_row1; if linked_108 == nil { tmp2 = ifn_109.Invoke_O__O(arg_110) } else { tmp2 = linked_108.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_107, arg_110) }; arg_106 = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(columnIndex__2)); if linked_104 == nil { return ifn_105.Invoke_O__O(arg_106) } else { return linked_104.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_103, arg_106) } } else {
			var root_111 any = A_arbace_inspector_A_const_32.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = columnIndex__2; if linked_112 == nil { return ifn_113.Invoke_O__O(arg_114) } else { return linked_112.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_111, arg_114) } } }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000083_A_New_I(p0 int32) *A_arbace_inspector_old_table_model_fn__1049000083_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000083_A{}; t.Ctor_I(p0); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000083_A) Ctor_I(c__cnt int32) { t.F_cnt = c__cnt }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000083_A) Invoke_O_O__O(self, this__1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(t.F_cnt).Ref() }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000085_A_New_O_O(p0, p1 any) *A_arbace_inspector_old_table_model_fn__1049000085_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000085_A) Ctor_O_O(c__data, c__vals any) { t.F_data = c__data; t.F_vals = c__vals }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000085_A) Invoke_O_O_O_O__O(self, this__1, rowIndex__2, columnIndex__3 any) any {









	var tmp1 lang.IFn = lang.IFn_Cast(t.F_vals); var tmp2 any = t.F_data; return lang.RT_Nth_O_I__O_NoInit(tmp1.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(rowIndex__2))), lang.RT_IntCast_O__I_NoInit(columnIndex__3)) }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000087_A_New() *A_arbace_inspector_old_table_model_fn__1049000087_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000087_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000087_A) Ctor() {}
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000087_A) Invoke_O_O_O_O__O(self, this__1, rowIndex__2, columnIndex__3 any) any { return jrt.Boolean_FALSE.Ref() }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000089_A_New() *A_arbace_inspector_old_table_model_fn__1049000089_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000089_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000089_A) Ctor() {}
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000089_A) Invoke_O_O_O__O(self, this__1, tableModelListener__2 any) any { return nil }













func A_arbace_inspector_inspect_tree_A_New() *A_arbace_inspector_inspect_tree_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_inspect_tree_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_inspector_inspect_tree_A) Ctor() {}
//line :94:1
func (t *A_arbace_inspector_inspect_tree_A) Invoke_O_O__O(self, data__0 any) any { var G__1049000092__2_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11), jrt.RefArrayOf(jrt.Object_class, Lit_23)); var tmp1 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10); var tmp2 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8); var tmp3 any; var root_125 any = A_arbace_inspector_A_const_33.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, A_arbace_inspector_tree_model_A_fn_class); var ifn_127 lang.IFn; if




	linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = data__0; if linked_126 == nil { tmp3 = ifn_127.Invoke_O__O(arg_128) } else { tmp3 = linked_126.(*A_arbace_inspector_tree_model_A).Invoke_O_O__O(root_125, arg_128) }; lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000092__2_, Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3))))));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000092__2_, Lit_38, jrt.RefArrayOf(jrt.Object_class, A_arbace_inspector_A_const_34, A_arbace_inspector_A_const_35));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000092__2_, Lit_39, jrt.RefArrayOf(jrt.Object_class, jrt.Boolean_TRUE.Ref())); return G__1049000092__2_ }

func A_arbace_inspector_inspect_table_A_New() *A_arbace_inspector_inspect_table_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_inspect_table_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_inspector_inspect_table_A) Ctor() {}
//line :103:1
func (t *A_arbace_inspector_inspect_table_A) Invoke_O_O__O(self, data__0 any) any { var G__1049000094__2_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11), jrt.RefArrayOf(jrt.Object_class, Lit_23)); var tmp1 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10); var tmp2 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9); var tmp3 any; var root_129 any = A_arbace_inspector_A_const_36.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, A_arbace_inspector_old_table_model_A_fn_class); var ifn_131 lang.IFn; if






	linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = data__0; if linked_130 == nil { tmp3 = ifn_131.Invoke_O__O(arg_132) } else { tmp3 = linked_130.(*A_arbace_inspector_old_table_model_A).Invoke_O_O__O(root_129, arg_132) }; lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000094__2_, Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3))))));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000094__2_, Lit_38, jrt.RefArrayOf(jrt.Object_class, A_arbace_inspector_A_const_37, A_arbace_inspector_A_const_38));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000094__2_, Lit_39, jrt.RefArrayOf(jrt.Object_class, jrt.Boolean_TRUE.Ref())); return G__1049000094__2_ }



func A_arbace_inspector_eval1049000098_fn__1049000099_A_New() *A_arbace_inspector_eval1049000098_fn__1049000099_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000098_fn__1049000099_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_A) Ctor() {}
//line :116:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any = A_arbace_inspector_A_const_39; var tmp2 any = A_arbace_inspector_A_const_40; var tmp3 any = A_arbace_inspector_A_const_41; var tmp4 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_New_O(x__1); var tmp5 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_fn_class; if
												fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__134); A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_fn_class = fncls__133d; tmp5 = fncls__133d } else { tmp5 = fncls__133 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp5, nil); var tmp6 any = /*line :116:1*/tmp4.Ref(); var tmp7 any = A_arbace_inspector_A_const_42; var tmp8 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_New_O(x__1); var tmp9 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_fn_class; if
												fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__140); A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_fn_class = fncls__139d; tmp9 = fncls__139d } else { tmp9 = fncls__139 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp9, nil); return /*line :116:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp6, tmp7, tmp8.Ref())) }
func A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_New_O(p0 any) *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :117:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A) Invoke_O_O__O(self, i__1 any) any { return t.F_x }
//line :117:1
func A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_New_O(p0 any) *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :117:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 any; var root_135 any = A_arbace_inspector_A_const_43.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = t.F_x; if linked_136 == nil { tmp1 = ifn_137.Invoke_O__O(arg_138) } else { tmp1 = linked_136.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_135, arg_138) }; return jrt.NN(jrt.Class_Cast(tmp1)).GetName__String().Ref() }

func A_arbace_inspector_eval1049000106_fn__1049000107_A_New() *A_arbace_inspector_eval1049000106_fn__1049000107_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000106_fn__1049000107_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_A) Ctor() {}
//line :119:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_A) Invoke_O_O__O(self, c__1 any) any { var v__2 any; var tmp1 any; var root_141 any = A_arbace_inspector_A_const_44.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_143 lang.IFn; if
												linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = c__1; if linked_142 == nil { tmp1 = ifn_143.Invoke_O__O(arg_144) } else { tmp1 = linked_142.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_141, arg_144) }; if jrt.J2g_Truth(tmp1) { v__2 = c__1 } else { var root_145 any = A_arbace_inspector_A_const_45.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = c__1; if linked_146 == nil { v__2 = ifn_147.Invoke_O__O(arg_148) } else { v__2 = linked_146.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_145, arg_148) } }; var tmp2 any = A_arbace_inspector_A_const_39; var tmp3 any = /*line :119:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__2)).Ref(); var tmp4 any = A_arbace_inspector_A_const_41; var tmp5 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_New_O(v__2); var tmp6 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_fn_class; if


	fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__150); A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_fn_class = fncls__149d; tmp6 = fncls__149d } else { tmp6 = fncls__149 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp6, nil); var tmp7 any = /*line :119:1*/tmp5.Ref(); var tmp8 any = A_arbace_inspector_A_const_42; var tmp9 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_New(); var tmp10 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_fn_class; if



	fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_fn_class = fncls__151d; tmp10 = fncls__151d } else { tmp10 = fncls__151 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp10, nil); return /*line :119:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp7, tmp8, tmp9.Ref())) }


func A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_New_O(p0 any) *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A{}; t.Ctor_O(p0); return t }
//line :122:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :122:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A) Invoke_O_O__O(self, i__1 any) any { return lang.IFn_Cast(t.F_v).Invoke_O__O(i__1) }
func A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_New() *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A) Ctor() {}
//line :123:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A) Invoke_O_O__O(self, i__1 any) any { return i__1 }

func A_arbace_inspector_eval1049000114_fn__1049000115_A_New() *A_arbace_inspector_eval1049000114_fn__1049000115_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000114_fn__1049000115_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_A) Ctor() {}
//line :125:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_A) Invoke_O_O__O(self, c__1 any) any { var v__2 any; var root_153 any = A_arbace_inspector_A_const_45.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_155 lang.IFn; if
												linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any; var root_157 any = A_arbace_inspector_A_const_46.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_161 any = A_arbace_inspector_A_const_47.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any; var fnbody__172 any = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_New(); var tmp1 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_fn_class = fncls__171d; tmp1 = fncls__171d } else { tmp1 = fncls__171 }; arg_164 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__172, tmp1, nil); var arg_165 any = c__1; if linked_162 == nil { arg_160 = ifn_163.Invoke_O_O__O(arg_164, arg_165) } else { arg_160 = linked_162.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_161, arg_164, arg_165) }; if linked_158 == nil { arg_156 = ifn_159.Invoke_O__O(arg_160) } else { arg_156 = linked_158.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_157, arg_160) }; if linked_154 == nil { v__2 = ifn_155.Invoke_O__O(arg_156) } else { v__2 = linked_154.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_153, arg_156) }; var tmp2 any = A_arbace_inspector_A_const_39; var tmp3 any = /*line :125:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__2)).Ref(); var tmp4 any = A_arbace_inspector_A_const_41; var tmp5 *lang.Compiler_AOTFn; var fnbody__174 any = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_New_O(v__2); var tmp6 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_fn_class; if


	fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__174); A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_fn_class = fncls__173d; tmp6 = fncls__173d } else { tmp6 = fncls__173 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__174, tmp6, nil); var tmp7 any = /*line :125:1*/tmp5.Ref(); var tmp8 any = A_arbace_inspector_A_const_42; var tmp9 *lang.Compiler_AOTFn; var fnbody__176 any = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_New_O(v__2); var tmp10 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_fn_class; if



	fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__176); A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_fn_class = fncls__175d; tmp10 = fncls__175d } else { tmp10 = fncls__175 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__176, tmp10, nil); return /*line :125:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp7, tmp8, tmp9.Ref())) }
func A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_New() *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A) Ctor() {}
//line :126:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A) Invoke_O_O__O(self, p__1049000116__1 any) any { var vec__1049000118__2 any = p__1049000116__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1049000118__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1049000118__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_166 any = A_arbace_inspector_A_const_48.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_vector_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = k__3; var arg_170 any = v__4; if linked_167 == nil { return ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { return linked_167.(*aot_arbace_core.A_arbace_core_vector_A).Invoke_O_O_O__O(root_166, arg_169, arg_170) } }

func A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_New_O(p0 any) *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :128:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A) Invoke_O_O__O(self, i__1 any) any { return lang.IFn_Cast(lang.IFn_Cast(t.F_v).Invoke_O__O(i__1)).Invoke_O__O(A_arbace_inspector_A_const_40) }
func A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_New_O(p0 any) *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :129:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A) Invoke_O_O__O(self, i__1 any) any { return lang.IFn_Cast(lang.IFn_Cast(t.F_v).Invoke_O__O(i__1)).Invoke_O__O(A_arbace_inspector_A_const_49) }

func A_arbace_inspector_list_model_A_New() *A_arbace_inspector_list_model_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_list_model_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_inspector_list_model_A) Ctor() {}
//line :131:1
func (t *A_arbace_inspector_list_model_A) Invoke_O_O__O(self, provider__0 any) any { var map__1049000128__2 any = provider__0; var map__1049000128__3 any; if
											lang.ISeq_InstanceOf(map__1049000128__2) { var tmp1 any; var root_177 any = A_arbace_inspector_A_const_50.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = map__1049000128__2; if linked_178 == nil { tmp1 = ifn_179.Invoke_O__O(arg_180) } else { tmp1 = linked_178.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_177, arg_180) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_181 any = A_arbace_inspector_A_const_51.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = map__1049000128__2; if linked_182 == nil { tmp2 = ifn_183.Invoke_O__O(arg_184) } else { tmp2 = linked_182.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_181, arg_184) }; map__1049000128__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_185 any = A_arbace_inspector_A_const_21.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = map__1049000128__2; if linked_186 == nil { tmp3 = ifn_187.Invoke_O__O(arg_188) } else { tmp3 = linked_186.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_185, arg_188) }; if jrt.J2g_Truth(tmp3) { var root_189 any = A_arbace_inspector_A_const_25.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = map__1049000128__2; if linked_190 == nil { map__1049000128__3 = ifn_191.Invoke_O__O(arg_192) } else { map__1049000128__3 = linked_190.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_189, arg_192) } } else { map__1049000128__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1049000128__3 = map__1049000128__2 }; var nrows__4 any = /*line :131:1*/lang.RT_Get_O_O__O_NoInit(map__1049000128__3, A_arbace_inspector_A_const_39); var get_value__5 any = lang.RT_Get_O_O__O_NoInit(map__1049000128__3, A_arbace_inspector_A_const_41); var get_label__6 any = lang.RT_Get_O_O__O_NoInit(map__1049000128__3, A_arbace_inspector_A_const_42); _ = nrows__4; _ = get_value__5; _ = get_label__6; panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(Lit_22))) }











func A_arbace_inspector_eval1049000133_fn__1049000134_A_New() *A_arbace_inspector_eval1049000133_fn__1049000134_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000133_fn__1049000134_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_inspector_eval1049000133_fn__1049000134_A) Ctor() {}
//line :143:1
func (t *A_arbace_inspector_eval1049000133_fn__1049000134_A) Invoke_O_O__O(self, x__1 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(Lit_22))) }











func A_arbace_inspector_inspect_A_New() *A_arbace_inspector_inspect_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_inspect_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_inspector_inspect_A) Ctor() {}
//line :155:1
func (t *A_arbace_inspector_inspect_A) Invoke_O_O__O(self, x__0 any) any { var G__1049000137__2_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11), jrt.RefArrayOf(jrt.Object_class, Lit_23)); var tmp1 any; var G__1049000138__3_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7), jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1), jrt.RefArrayOf(jrt.Object_class)))); var tmp2 any; var G__1049000139__4_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), jrt.RefArrayOf(jrt.Object_class));







	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_25))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_26, jrt.RefArrayOf(jrt.Object_class));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_27))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_28))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_29))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_30))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_31))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_26, jrt.RefArrayOf(jrt.Object_class));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_32))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_33)))); tmp2 = G__1049000139__4_; /*line :162:1*/lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000138__3_, Lit_24, jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Reflector_GetStaticField_Class_String__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1), Lit_34))); var tmp3 /*line :174:1*/*jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10); var tmp4 any; var G__1049000140__4_ any; var tmp5 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9); var tmp6 any; var root_193 any = A_arbace_inspector_A_const_54.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, A_arbace_inspector_list_model_A_fn_class); var ifn_195 lang.IFn; if

	linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = lang.IFn_Cast(A_arbace_inspector_A_const_55.GetRawRoot__O()).Invoke_O__O(x__0); if linked_194 == nil { tmp6 = ifn_195.Invoke_O__O(arg_196) } else { tmp6 = linked_194.(*A_arbace_inspector_list_model_A).Invoke_O_O__O(root_193, arg_196) }; G__1049000140__4_ = /*line :174:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6));


	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000140__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9), Lit_35, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_GetStaticField_Class_String__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9), Lit_36))); tmp4 = G__1049000140__4_; /*line :174:1*/lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000138__3_, Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4)), lang.Reflector_GetStaticField_Class_String__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1), Lit_37))); tmp1 = G__1049000138__3_; /*line :160:1*/lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000137__2_, Lit_24, jrt.RefArrayOf(jrt.Object_class, tmp1));


















	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000137__2_, Lit_38, jrt.RefArrayOf(jrt.Object_class, A_arbace_inspector_A_const_52, A_arbace_inspector_A_const_53));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000137__2_, Lit_39, jrt.RefArrayOf(jrt.Object_class, jrt.Boolean_TRUE.Ref())); return G__1049000137__2_ }



















































































































type A_arbace_inspector_A struct{ jrt.Object }

var A_arbace_inspector_A_const_pool *jrt.RefArray

var A_arbace_inspector_A_const_0 *lang.Var

var A_arbace_inspector_A_const_1 any

var A_arbace_inspector_A_const_2 *lang.Var

var A_arbace_inspector_A_const_3 *lang.Var

var A_arbace_inspector_A_const_4 *lang.Var

var A_arbace_inspector_A_const_5 *lang.Var

var A_arbace_inspector_A_const_6 any

var A_arbace_inspector_A_const_7 *lang.Var

var A_arbace_inspector_A_const_8 *lang.Var

var A_arbace_inspector_A_const_9 *lang.Var

var A_arbace_inspector_A_const_10 *lang.Keyword

var A_arbace_inspector_A_const_11 *lang.Keyword

var A_arbace_inspector_A_const_12 *lang.Var

var A_arbace_inspector_A_const_13 *lang.Keyword

var A_arbace_inspector_A_const_14 *lang.Keyword

var A_arbace_inspector_A_const_15 *lang.Keyword

var A_arbace_inspector_A_const_16 *lang.Var

var A_arbace_inspector_A_const_17 *lang.Var

var A_arbace_inspector_A_const_18 *lang.Var

var A_arbace_inspector_A_const_19 *lang.Var

var A_arbace_inspector_A_const_20 *lang.Var

var A_arbace_inspector_A_const_21 *lang.Var

var A_arbace_inspector_A_const_22 *lang.Var

var A_arbace_inspector_A_const_23 *lang.Var

var A_arbace_inspector_A_const_24 any

var A_arbace_inspector_A_const_25 *lang.Var

var A_arbace_inspector_A_const_26 *lang.Var

var A_arbace_inspector_A_const_27 *lang.Var

var A_arbace_inspector_A_const_28 *lang.Var

var A_arbace_inspector_A_const_29 *jrt.Class

var A_arbace_inspector_A_const_30 *lang.Var

var A_arbace_inspector_A_const_31 *lang.Var

var A_arbace_inspector_A_const_32 *lang.Var

var A_arbace_inspector_A_const_33 *lang.Var

var A_arbace_inspector_A_const_34 any

var A_arbace_inspector_A_const_35 any

var A_arbace_inspector_A_const_36 *lang.Var

var A_arbace_inspector_A_const_37 any

var A_arbace_inspector_A_const_38 any

var A_arbace_inspector_A_const_39 *lang.Keyword

var A_arbace_inspector_A_const_40 any

var A_arbace_inspector_A_const_41 *lang.Keyword

var A_arbace_inspector_A_const_42 *lang.Keyword

var A_arbace_inspector_A_const_43 *lang.Var

var A_arbace_inspector_A_const_44 *lang.Var

var A_arbace_inspector_A_const_45 *lang.Var

var A_arbace_inspector_A_const_46 *lang.Var

var A_arbace_inspector_A_const_47 *lang.Var

var A_arbace_inspector_A_const_48 *lang.Var

var A_arbace_inspector_A_const_49 any

var A_arbace_inspector_A_const_50 *lang.Var

var A_arbace_inspector_A_const_51 *lang.Var

var A_arbace_inspector_A_const_52 any

var A_arbace_inspector_A_const_53 any

var A_arbace_inspector_A_const_54 *lang.Var

var A_arbace_inspector_A_const_55 *lang.Var

var A_arbace_inspector_A_init jrt.ClassInit

func A_arbace_inspector_A_Init() { if !A_arbace_inspector_A_init.Done() { A_arbace_inspector_A_init.Run(A_arbace_inspector_A_clinit) } }

func A_arbace_inspector_A_clinit() { A_arbace_inspector_A_clinit_p0(); A_arbace_inspector_A_clinit_p1(); A_arbace_inspector_A_clinit_p2(); A_arbace_inspector_A_clinit_p3(); A_arbace_inspector_A_clinit_p4() }

func A_arbace_inspector_A_clinit_p0() { jrt.StartCheck(); A_arbace_inspector_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 67); A_arbace_inspector_A_const_0 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[11]); A_arbace_inspector_A_const_1 = A_arbace_inspector_A_const_pool.A[12]; A_arbace_inspector_A_const_2 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[13]); A_arbace_inspector_A_const_3 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[14]); A_arbace_inspector_A_const_4 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[15]); A_arbace_inspector_A_const_5 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[16]); A_arbace_inspector_A_const_6 = A_arbace_inspector_A_const_pool.A[17]; A_arbace_inspector_A_const_7 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[18]); A_arbace_inspector_A_const_8 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[19]); A_arbace_inspector_A_const_9 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[20]); A_arbace_inspector_A_const_10 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[21]) }

func A_arbace_inspector_A_clinit_p1() { A_arbace_inspector_A_const_11 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[22]); A_arbace_inspector_A_const_12 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[23]); A_arbace_inspector_A_const_13 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[24]); A_arbace_inspector_A_const_14 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[25]); A_arbace_inspector_A_const_15 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[26]); A_arbace_inspector_A_const_16 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[27]); A_arbace_inspector_A_const_17 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[28]); A_arbace_inspector_A_const_18 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[29]); A_arbace_inspector_A_const_19 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[30]); A_arbace_inspector_A_const_20 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[31]); A_arbace_inspector_A_const_21 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[32]); A_arbace_inspector_A_const_22 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[33]) }

func A_arbace_inspector_A_clinit_p2() { A_arbace_inspector_A_const_23 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[34]); A_arbace_inspector_A_const_24 = A_arbace_inspector_A_const_pool.A[35]; A_arbace_inspector_A_const_25 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[36]); A_arbace_inspector_A_const_26 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[37]); A_arbace_inspector_A_const_27 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[38]); A_arbace_inspector_A_const_28 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[39]); A_arbace_inspector_A_const_29 = jrt.Class_Cast(A_arbace_inspector_A_const_pool.A[40]); A_arbace_inspector_A_const_30 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[41]); A_arbace_inspector_A_const_31 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[42]); A_arbace_inspector_A_const_32 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[43]); A_arbace_inspector_A_const_33 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[44]); A_arbace_inspector_A_const_34 = A_arbace_inspector_A_const_pool.A[45] }

func A_arbace_inspector_A_clinit_p3() { A_arbace_inspector_A_const_35 = A_arbace_inspector_A_const_pool.A[46]; A_arbace_inspector_A_const_36 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[47]); A_arbace_inspector_A_const_37 = A_arbace_inspector_A_const_pool.A[48]; A_arbace_inspector_A_const_38 = A_arbace_inspector_A_const_pool.A[49]; A_arbace_inspector_A_const_39 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[50]); A_arbace_inspector_A_const_40 = A_arbace_inspector_A_const_pool.A[51]; A_arbace_inspector_A_const_41 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[52]); A_arbace_inspector_A_const_42 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[53]); A_arbace_inspector_A_const_43 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[54]); A_arbace_inspector_A_const_44 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[55]); A_arbace_inspector_A_const_45 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[56]); A_arbace_inspector_A_const_46 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[57]); A_arbace_inspector_A_const_47 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[58]) }

func A_arbace_inspector_A_clinit_p4() { A_arbace_inspector_A_const_48 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[59]); A_arbace_inspector_A_const_49 = A_arbace_inspector_A_const_pool.A[60]; A_arbace_inspector_A_const_50 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[61]); A_arbace_inspector_A_const_51 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[62]); A_arbace_inspector_A_const_52 = A_arbace_inspector_A_const_pool.A[63]; A_arbace_inspector_A_const_53 = A_arbace_inspector_A_const_pool.A[64]; A_arbace_inspector_A_const_54 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[65]); A_arbace_inspector_A_const_55 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[66]) }

func A_arbace_inspector_A_New() *A_arbace_inspector_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_A) Ctor() {}

func (t *A_arbace_inspector_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_A_class }

func (t *A_arbace_inspector_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_A); return ok }

func A_arbace_inspector_A_Cast(x any) *A_arbace_inspector_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_A_class)) }; return v }



type A_arbace_inspector_atom_QMARK__A struct{ j2g_header uint64 }

var A_arbace_inspector_atom_QMARK__A_fn_class *jrt.Class



type A_arbace_inspector_collection_tag_A struct{ j2g_header uint64 }

var A_arbace_inspector_collection_tag_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000004_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000004_A_New() *A_arbace_inspector_eval1049000004_A { t := &A_arbace_inspector_eval1049000004_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000004_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000004_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000004_A_class }

func (t *A_arbace_inspector_eval1049000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000004_A); return ok }

func A_arbace_inspector_eval1049000004_A_Cast(x any) *A_arbace_inspector_eval1049000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000004_A_class)) }; return v }



type A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000008_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000008_A_New() *A_arbace_inspector_eval1049000008_A { t := &A_arbace_inspector_eval1049000008_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000008_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000008_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000008_A_class }

func (t *A_arbace_inspector_eval1049000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000008_A); return ok }

func A_arbace_inspector_eval1049000008_A_Cast(x any) *A_arbace_inspector_eval1049000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000008_A_class)) }; return v }



type A_arbace_inspector_eval1049000008_fn__1049000009_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000008_fn__1049000009_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000016_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000016_A_New() *A_arbace_inspector_eval1049000016_A { t := &A_arbace_inspector_eval1049000016_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000016_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000016_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000016_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000016_A_class }

func (t *A_arbace_inspector_eval1049000016_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000016_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000016_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000016_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000016_A); return ok }

func A_arbace_inspector_eval1049000016_A_Cast(x any) *A_arbace_inspector_eval1049000016_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000016_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000016_A_class)) }; return v }



type A_arbace_inspector_eval1049000016_fn__1049000017_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000016_fn__1049000017_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000022_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000022_A_New() *A_arbace_inspector_eval1049000022_A { t := &A_arbace_inspector_eval1049000022_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000022_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000022_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000022_A_class }

func (t *A_arbace_inspector_eval1049000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000022_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000022_A); return ok }

func A_arbace_inspector_eval1049000022_A_Cast(x any) *A_arbace_inspector_eval1049000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000022_A_class)) }; return v }



type A_arbace_inspector_eval1049000022_fn__1049000023_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000022_fn__1049000023_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000026_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000026_A_New() *A_arbace_inspector_eval1049000026_A { t := &A_arbace_inspector_eval1049000026_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000026_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000026_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000026_A_class }

func (t *A_arbace_inspector_eval1049000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000026_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000026_A); return ok }

func A_arbace_inspector_eval1049000026_A_Cast(x any) *A_arbace_inspector_eval1049000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000026_A_class)) }; return v }



type A_arbace_inspector_eval1049000026_fn__1049000027_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000026_fn__1049000027_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000030_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000030_A_New() *A_arbace_inspector_eval1049000030_A { t := &A_arbace_inspector_eval1049000030_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000030_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000030_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000030_A_class }

func (t *A_arbace_inspector_eval1049000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000030_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000030_A); return ok }

func A_arbace_inspector_eval1049000030_A_Cast(x any) *A_arbace_inspector_eval1049000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000030_A_class)) }; return v }



type A_arbace_inspector_eval1049000030_fn__1049000031_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000030_fn__1049000031_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000034_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000034_A_New() *A_arbace_inspector_eval1049000034_A { t := &A_arbace_inspector_eval1049000034_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000034_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000034_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000034_A_class }

func (t *A_arbace_inspector_eval1049000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000034_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000034_A); return ok }

func A_arbace_inspector_eval1049000034_A_Cast(x any) *A_arbace_inspector_eval1049000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000034_A_class)) }; return v }



type A_arbace_inspector_eval1049000034_fn__1049000035_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000034_fn__1049000035_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000038_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000038_A_New() *A_arbace_inspector_eval1049000038_A { t := &A_arbace_inspector_eval1049000038_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000038_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000038_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000038_A_class }

func (t *A_arbace_inspector_eval1049000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000038_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000038_A); return ok }

func A_arbace_inspector_eval1049000038_A_Cast(x any) *A_arbace_inspector_eval1049000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000038_A_class)) }; return v }



type A_arbace_inspector_eval1049000038_fn__1049000039_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000038_fn__1049000039_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000042_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000042_A_New() *A_arbace_inspector_eval1049000042_A { t := &A_arbace_inspector_eval1049000042_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000042_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000042_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000042_A_class }

func (t *A_arbace_inspector_eval1049000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000042_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000042_A); return ok }

func A_arbace_inspector_eval1049000042_A_Cast(x any) *A_arbace_inspector_eval1049000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000042_A_class)) }; return v }



type A_arbace_inspector_eval1049000042_fn__1049000043_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000042_fn__1049000043_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000046_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000046_A_New() *A_arbace_inspector_eval1049000046_A { t := &A_arbace_inspector_eval1049000046_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000046_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000046_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000046_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000046_A_class }

func (t *A_arbace_inspector_eval1049000046_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000046_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000046_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000046_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000046_A); return ok }

func A_arbace_inspector_eval1049000046_A_Cast(x any) *A_arbace_inspector_eval1049000046_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000046_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000046_A_class)) }; return v }



type A_arbace_inspector_eval1049000046_fn__1049000047_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000046_fn__1049000047_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000050_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000050_A_New() *A_arbace_inspector_eval1049000050_A { t := &A_arbace_inspector_eval1049000050_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000050_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000050_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000050_A_class }

func (t *A_arbace_inspector_eval1049000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000050_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000050_A); return ok }

func A_arbace_inspector_eval1049000050_A_Cast(x any) *A_arbace_inspector_eval1049000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000050_A_class)) }; return v }



type A_arbace_inspector_eval1049000050_fn__1049000051_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000050_fn__1049000051_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000054_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000054_A_New() *A_arbace_inspector_eval1049000054_A { t := &A_arbace_inspector_eval1049000054_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000054_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000054_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000054_A_class }

func (t *A_arbace_inspector_eval1049000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000054_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000054_A); return ok }

func A_arbace_inspector_eval1049000054_A_Cast(x any) *A_arbace_inspector_eval1049000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000054_A_class)) }; return v }



type A_arbace_inspector_eval1049000054_fn__1049000055_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000054_fn__1049000055_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000098_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000098_A_New() *A_arbace_inspector_eval1049000098_A { t := &A_arbace_inspector_eval1049000098_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000098_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000098_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000098_A_class }

func (t *A_arbace_inspector_eval1049000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000098_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000098_A); return ok }

func A_arbace_inspector_eval1049000098_A_Cast(x any) *A_arbace_inspector_eval1049000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000098_A_class)) }; return v }



type A_arbace_inspector_eval1049000098_fn__1049000099_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000098_fn__1049000099_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A struct{ j2g_header uint64; F_x any }

var A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A struct{ j2g_header uint64; F_x any }

var A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000106_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000106_A_New() *A_arbace_inspector_eval1049000106_A { t := &A_arbace_inspector_eval1049000106_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000106_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000106_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000106_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000106_A_class }

func (t *A_arbace_inspector_eval1049000106_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000106_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000106_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000106_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000106_A); return ok }

func A_arbace_inspector_eval1049000106_A_Cast(x any) *A_arbace_inspector_eval1049000106_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000106_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000106_A_class)) }; return v }



type A_arbace_inspector_eval1049000106_fn__1049000107_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000106_fn__1049000107_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A struct{ j2g_header uint64; F_v any }

var A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000114_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000114_A_New() *A_arbace_inspector_eval1049000114_A { t := &A_arbace_inspector_eval1049000114_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000114_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000114_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000114_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000114_A_class }

func (t *A_arbace_inspector_eval1049000114_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000114_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000114_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000114_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000114_A); return ok }

func A_arbace_inspector_eval1049000114_A_Cast(x any) *A_arbace_inspector_eval1049000114_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000114_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000114_A_class)) }; return v }



type A_arbace_inspector_eval1049000114_fn__1049000115_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000114_fn__1049000115_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A struct{ j2g_header uint64; F_v any }

var A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A struct{ j2g_header uint64; F_v any }

var A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000133_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000133_A_New() *A_arbace_inspector_eval1049000133_A { t := &A_arbace_inspector_eval1049000133_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000133_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000133_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000133_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000133_A_class }

func (t *A_arbace_inspector_eval1049000133_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000133_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000133_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000133_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000133_A); return ok }

func A_arbace_inspector_eval1049000133_A_Cast(x any) *A_arbace_inspector_eval1049000133_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000133_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000133_A_class)) }; return v }



type A_arbace_inspector_eval1049000133_fn__1049000134_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000133_fn__1049000134_A_fn_class *jrt.Class



type A_arbace_inspector_inspect_A struct{ j2g_header uint64 }

var A_arbace_inspector_inspect_A_fn_class *jrt.Class



type A_arbace_inspector_inspect_table_A struct{ j2g_header uint64 }

var A_arbace_inspector_inspect_table_A_fn_class *jrt.Class



type A_arbace_inspector_inspect_tree_A struct{ j2g_header uint64 }

var A_arbace_inspector_inspect_tree_A_fn_class *jrt.Class



type A_arbace_inspector_list_model_A struct{ j2g_header uint64 }

var A_arbace_inspector_list_model_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000075_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_fn__1049000075_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000077_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_fn__1049000077_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000079_A struct{ j2g_header uint64; F_colcnt int32 }

var A_arbace_inspector_old_table_model_fn__1049000079_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000081_A struct{ j2g_header uint64; F_row1 any }

var A_arbace_inspector_old_table_model_fn__1049000081_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000083_A struct{ j2g_header uint64; F_cnt int32 }

var A_arbace_inspector_old_table_model_fn__1049000083_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000085_A struct{ j2g_header uint64; F_data, F_vals any }

var A_arbace_inspector_old_table_model_fn__1049000085_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000087_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_fn__1049000087_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000089_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_fn__1049000089_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000058_A struct{ j2g_header uint64; F_data any }

var A_arbace_inspector_tree_model_fn__1049000058_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000060_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000060_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000062_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000062_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000064_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000064_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000066_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000066_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000068_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000068_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000070_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000070_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000072_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000072_A_fn_class *jrt.Class
