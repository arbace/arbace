//line aot_arbace_inspector.ae:1
package aot_arbace_inspector

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)





func A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A_New() *A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A) Ctor() {}
//line :13:1
func (t *A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_inspector_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_inspector_A_const_1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :13:1
func A_arbace_inspector_eval1049000008_fn__1049000009_A_New() *A_arbace_inspector_eval1049000008_fn__1049000009_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000008_fn__1049000009_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_inspector_eval1049000008_fn__1049000009_A) Ctor() {}
//line :13:1
func (t *A_arbace_inspector_eval1049000008_fn__1049000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_inspector_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_inspector_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_inspector_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_inspector_A_const_5.GetRawRoot__O(), A_arbace_inspector_A_const_6) }









func A_arbace_inspector_atom_QMARK__A_New() *A_arbace_inspector_atom_QMARK__A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_atom_QMARK__A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_inspector_atom_QMARK__A) Ctor() {}
//line :23:1
func (t *A_arbace_inspector_atom_QMARK__A) Invoke_O_O__O(self, x__0 any) any {
	var root_15 any = A_arbace_inspector_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; var root_19 any = A_arbace_inspector_A_const_8.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_coll_QMARK__A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = x__0; if linked_20 == nil { arg_18 = ifn_21.Invoke_O__O(arg_22) } else { arg_18 = linked_20.(*aot_arbace_core.A_arbace_core_coll_QMARK__A).Invoke_O_O__O(root_19, arg_22) }; if linked_16 == nil { return ifn_17.Invoke_O__O(arg_18) } else { return linked_16.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_15, arg_18)
	} }
func A_arbace_inspector_collection_tag_A_New() *A_arbace_inspector_collection_tag_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_collection_tag_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_inspector_collection_tag_A) Ctor() {}
//line :26:1
func (t *A_arbace_inspector_collection_tag_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var root_23 any = A_arbace_inspector_A_const_9.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_map_entry_QMARK__A_fn_class); var ifn_25 lang.IFn
	if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = x__0; if linked_24 == nil { tmp1 = ifn_25.Invoke_O__O(arg_26) } else { tmp1 = linked_24.(*aot_arbace_core.A_arbace_core_map_entry_QMARK__A).Invoke_O_O__O(root_23, arg_26) }
//line :27:1
	if jrt.J2g_Truth(tmp1) { return A_arbace_inspector_A_const_10 } else { if jrt.Map_InstanceOf(x__0) { return A_arbace_inspector_A_const_11 } else { if jrt.Set_InstanceOf(x__0) { return A_arbace_inspector_A_const_11 } else { var tmp2 any; var root_27 any = A_arbace_inspector_A_const_12.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_sequential_QMARK__A_fn_class); var ifn_29 lang.IFn



		if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = x__0; if linked_28 == nil { tmp2 = ifn_29.Invoke_O__O(arg_30) } else { tmp2 = linked_28.(*aot_arbace_core.A_arbace_core_sequential_QMARK__A).Invoke_O_O__O(root_27, arg_30) }
//line :27:1
		if jrt.J2g_Truth(tmp2) { return A_arbace_inspector_A_const_13 } else { if lang.Seqable_InstanceOf(x__0) { return A_arbace_inspector_A_const_11 } else { if A_arbace_inspector_A_const_14 != nil { return A_arbace_inspector_A_const_15 } else { return nil
		}
		}
		}
	}
	}
	}
}

func A_arbace_inspector_eval1049000016_fn__1049000017_A_New() *A_arbace_inspector_eval1049000016_fn__1049000017_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000016_fn__1049000017_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_inspector_eval1049000016_fn__1049000017_A) Ctor() {}
//line :36:1
func (t *A_arbace_inspector_eval1049000016_fn__1049000017_A) Invoke_O_O_O__O(self, parent__1, index__2 any) any { var root_31 any = A_arbace_inspector_A_const_16.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, A_arbace_inspector_collection_tag_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = parent__1; if linked_32 == nil { return ifn_33.Invoke_O__O(arg_34) } else { return linked_32.(*A_arbace_inspector_collection_tag_A).Invoke_O_O__O(root_31, arg_34) } }


func A_arbace_inspector_eval1049000022_fn__1049000023_A_New() *A_arbace_inspector_eval1049000022_fn__1049000023_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000022_fn__1049000023_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_inspector_eval1049000022_fn__1049000023_A) Ctor() {}
//line :39:1
func (t *A_arbace_inspector_eval1049000022_fn__1049000023_A) Invoke_O_O__O(self, node__1 any) any {
	var root_35 any = A_arbace_inspector_A_const_17.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, A_arbace_inspector_atom_QMARK__A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = node__1; if linked_36 == nil { return ifn_37.Invoke_O__O(arg_38) } else { return linked_36.(*A_arbace_inspector_atom_QMARK__A).Invoke_O_O__O(root_35, arg_38) } }
func A_arbace_inspector_eval1049000026_fn__1049000027_A_New() *A_arbace_inspector_eval1049000026_fn__1049000027_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000026_fn__1049000027_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_inspector_eval1049000026_fn__1049000027_A) Ctor() {}
//line :41:1
func (t *A_arbace_inspector_eval1049000026_fn__1049000027_A) Invoke_O_O_O__O(self, parent__1, index__2 any) any {
	return lang.RT_Nth_O_I__O_NoInit(parent__1, lang.RT_IntCast_O__I_NoInit(index__2)) }
func A_arbace_inspector_eval1049000030_fn__1049000031_A_New() *A_arbace_inspector_eval1049000030_fn__1049000031_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000030_fn__1049000031_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_inspector_eval1049000030_fn__1049000031_A) Ctor() {}
//line :43:1
func (t *A_arbace_inspector_eval1049000030_fn__1049000031_A) Invoke_O_O__O(self, parent__1 any) any {
	return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(parent__1)).Ref()
}
func A_arbace_inspector_eval1049000034_fn__1049000035_A_New() *A_arbace_inspector_eval1049000034_fn__1049000035_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000034_fn__1049000035_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_inspector_eval1049000034_fn__1049000035_A) Ctor() {}
//line :46:1
func (t *A_arbace_inspector_eval1049000034_fn__1049000035_A) Invoke_O_O__O(self, e__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_inspector_A_const_18.GetRawRoot__O()); var tmp2 any; var root_39 any = A_arbace_inspector_A_const_19.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = e__1; if linked_40 == nil { tmp2 = ifn_41.Invoke_O__O(arg_42) } else { tmp2 = linked_40.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_39, arg_42) }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_inspector_eval1049000038_fn__1049000039_A_New() *A_arbace_inspector_eval1049000038_fn__1049000039_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000038_fn__1049000039_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_inspector_eval1049000038_fn__1049000039_A) Ctor() {}
//line :48:1
func (t *A_arbace_inspector_eval1049000038_fn__1049000039_A) Invoke_O_O_O__O(self, e__1, index__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_inspector_A_const_20.GetRawRoot__O()); var tmp2 any; var root_43 any = A_arbace_inspector_A_const_19.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = e__1; if linked_44 == nil { tmp2 = ifn_45.Invoke_O__O(arg_46) } else { tmp2 = linked_44.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_43, arg_46) }; return tmp1.Invoke_O_O__O(tmp2, index__2) }
func A_arbace_inspector_eval1049000042_fn__1049000043_A_New() *A_arbace_inspector_eval1049000042_fn__1049000043_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000042_fn__1049000043_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_inspector_eval1049000042_fn__1049000043_A) Ctor() {}
//line :50:1
func (t *A_arbace_inspector_eval1049000042_fn__1049000043_A) Invoke_O_O__O(self, e__1 any) any {
	var tmp1 any; var root_47 any = A_arbace_inspector_A_const_19.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = e__1; if linked_48 == nil { tmp1 = ifn_49.Invoke_O__O(arg_50) } else { tmp1 = linked_48.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_47, arg_50) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref()
}
func A_arbace_inspector_eval1049000046_fn__1049000047_A_New() *A_arbace_inspector_eval1049000046_fn__1049000047_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000046_fn__1049000047_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_inspector_eval1049000046_fn__1049000047_A) Ctor() {}
//line :53:1
func (t *A_arbace_inspector_eval1049000046_fn__1049000047_A) Invoke_O_O__O(self, parent__1 any) any { return jrt.Boolean_FALSE.Ref() }

func A_arbace_inspector_eval1049000050_fn__1049000051_A_New() *A_arbace_inspector_eval1049000050_fn__1049000051_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000050_fn__1049000051_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_inspector_eval1049000050_fn__1049000051_A) Ctor() {}
//line :55:1
func (t *A_arbace_inspector_eval1049000050_fn__1049000051_A) Invoke_O_O_O__O(self, parent__1, index__2 any) any {
	var tmp1 any; var root_51 any = A_arbace_inspector_A_const_21.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = parent__1; if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_51, arg_54) }; return lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(index__2)) }
func A_arbace_inspector_eval1049000054_fn__1049000055_A_New() *A_arbace_inspector_eval1049000054_fn__1049000055_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000054_fn__1049000055_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_inspector_eval1049000054_fn__1049000055_A) Ctor() {}
//line :57:1
func (t *A_arbace_inspector_eval1049000054_fn__1049000055_A) Invoke_O_O__O(self, parent__1 any) any {
	var tmp1 any; var root_55 any = A_arbace_inspector_A_const_21.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = parent__1; if linked_56 == nil { tmp1 = ifn_57.Invoke_O__O(arg_58) } else { tmp1 = linked_56.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_55, arg_58) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp1)).Ref()
}
func A_arbace_inspector_tree_model_A_New() *A_arbace_inspector_tree_model_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_inspector_tree_model_A) Ctor() {}
//line :60:1
func (t *A_arbace_inspector_tree_model_A) Invoke_O_O__O(self, data__0 any) any { var p__840000142__auto____2 any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_57), jrt.RefArrayOf(jrt.Object_class)); var root_59 any = A_arbace_inspector_A_const_22.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_61 lang.IFn; if
										linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = p__840000142__auto____2; var arg_63 any; var tmp1 any = A_arbace_inspector_tree_model_fn__1049000058_A_New_O(data__0); var tmp2 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000058_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_inspector_tree_model_fn__1049000058_A_fn_class = fncls__64d; tmp2 = fncls__64d } else { tmp2 = fncls__64 }; var tmp3 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp4 any = A_arbace_inspector_tree_model_fn__1049000060_A_New(); var tmp5 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000060_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_inspector_tree_model_fn__1049000060_A_fn_class = fncls__65d; tmp5 = fncls__65d } else { tmp5 = fncls__65 }; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any = A_arbace_inspector_tree_model_fn__1049000062_A_New(); var tmp8 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000062_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_inspector_tree_model_fn__1049000062_A_fn_class = fncls__66d; tmp8 = fncls__66d } else { tmp8 = fncls__66 }; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_inspector_tree_model_fn__1049000064_A_New(); var tmp11 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000064_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_inspector_tree_model_fn__1049000064_A_fn_class = fncls__67d; tmp11 = fncls__67d } else { tmp11 = fncls__67 }; var tmp12 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var tmp13 any = A_arbace_inspector_tree_model_fn__1049000066_A_New(); var tmp14 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000066_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_inspector_tree_model_fn__1049000066_A_fn_class = fncls__68d; tmp14 = fncls__68d } else { tmp14 = fncls__68 }; var tmp15 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var tmp16 any = A_arbace_inspector_tree_model_fn__1049000068_A_New(); var tmp17 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000068_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_inspector_tree_model_fn__1049000068_A_fn_class = fncls__69d; tmp17 = fncls__69d } else { tmp17 = fncls__69 }; var tmp18 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var tmp19 any = A_arbace_inspector_tree_model_fn__1049000070_A_New(); var tmp20 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000070_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_inspector_tree_model_fn__1049000070_A_fn_class = fncls__70d; tmp20 = fncls__70d } else { tmp20 = fncls__70 }; var tmp21 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var tmp22 any = A_arbace_inspector_tree_model_fn__1049000072_A_New(); var tmp23 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_inspector_tree_model_fn__1049000072_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_inspector_tree_model_fn__1049000072_A_fn_class = fncls__71d; tmp23 = fncls__71d } else { tmp23 = fncls__71 }; arg_63 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_58, tmp3, Lit_60, tmp6, Lit_62, tmp9, Lit_64, tmp12, Lit_66, tmp15, Lit_68, tmp18, Lit_70, tmp21, Lit_72, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil))); if linked_60 == nil { ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { linked_60.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; return p__840000142__auto____2 }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000058_A_New_O(p0 any) *A_arbace_inspector_tree_model_fn__1049000058_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000058_A{}; t.Ctor_O(p0); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000058_A) Ctor_O(c__data any) { t.F_data = c__data }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000058_A) Invoke_O_O__O(self, this__1 any) any { return t.F_data }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000060_A_New() *A_arbace_inspector_tree_model_fn__1049000060_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000060_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000060_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000060_A) Invoke_O_O_O__O(self, this__1, treeModelListener__2 any) any { return nil }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000062_A_New() *A_arbace_inspector_tree_model_fn__1049000062_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000062_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000062_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000062_A) Invoke_O_O_O_O__O(self, this__1, parent__2, index__3 any) any {



	return lang.IFn_Cast(A_arbace_inspector_A_const_20.GetRawRoot__O()).Invoke_O_O__O(parent__2, index__3) }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000064_A_New() *A_arbace_inspector_tree_model_fn__1049000064_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000064_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000064_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000064_A) Invoke_O_O_O__O(self, this__1, parent__2 any) any {





	return lang.IFn_Cast(A_arbace_inspector_A_const_23.GetRawRoot__O()).Invoke_O__O(parent__2) }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000066_A_New() *A_arbace_inspector_tree_model_fn__1049000066_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000066_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000066_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000066_A) Invoke_O_O_O__O(self, this__1, node__2 any) any {







	return lang.IFn_Cast(A_arbace_inspector_A_const_18.GetRawRoot__O()).Invoke_O__O(node__2) }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000068_A_New() *A_arbace_inspector_tree_model_fn__1049000068_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000068_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000068_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000068_A) Invoke_O_O_O_O__O(self, this__1, path__2, newValue__3 any) any { return nil }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000070_A_New() *A_arbace_inspector_tree_model_fn__1049000070_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000070_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000070_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000070_A) Invoke_O_O_O_O__O(self, this__1, parent__2, child__3 any) any { return A_arbace_inspector_A_const_24 }
//line :61:1
func A_arbace_inspector_tree_model_fn__1049000072_A_New() *A_arbace_inspector_tree_model_fn__1049000072_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_tree_model_fn__1049000072_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000072_A) Ctor() {}
//line :61:1
func (t *A_arbace_inspector_tree_model_fn__1049000072_A) Invoke_O_O_O__O(self, this__1, treeModelListener__2 any) any { return nil }













func A_arbace_inspector_old_table_model_A_New() *A_arbace_inspector_old_table_model_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_inspector_old_table_model_A) Ctor() {}
//line :75:1
func (t *A_arbace_inspector_old_table_model_A) Invoke_O_O__O(self, data__0 any) any { var row1__2 any; var root_72 any = A_arbace_inspector_A_const_25.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_74 lang.IFn; if
											linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = data__0; if linked_73 == nil { row1__2 = ifn_74.Invoke_O__O(arg_75) } else { row1__2 = linked_73.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_72, arg_75) }; var colcnt__3 int32 = /*line :75:1*/lang.RT_Count_O__I_NoInit(row1__2); var cnt__4 int32 = lang.RT_Count_O__I_NoInit(data__0); var vals__5 any; var tmp1 any; var root_76 any = A_arbace_inspector_A_const_26.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_78 lang.IFn; if



	linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = row1__2; if linked_77 == nil { tmp1 = ifn_78.Invoke_O__O(arg_79) } else { tmp1 = linked_77.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_76, arg_79) }; if jrt.J2g_Truth(tmp1) { vals__5 = A_arbace_inspector_A_const_27.GetRawRoot__O() } else { vals__5 = A_arbace_inspector_A_const_28.GetRawRoot__O() }; var p__840000142__auto____6 any = /*line :75:1*/lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_40), jrt.RefArrayOf(jrt.Object_class)); var root_80 any = A_arbace_inspector_A_const_22.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_init_proxy_A_fn_class); var ifn_82 lang.IFn; if




	linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = p__840000142__auto____6; var arg_84 any; var tmp2 any = A_arbace_inspector_old_table_model_fn__1049000075_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000075_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_inspector_old_table_model_fn__1049000075_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any = A_arbace_inspector_old_table_model_fn__1049000077_A_New(); var tmp6 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000077_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_inspector_old_table_model_fn__1049000077_A_fn_class = fncls__86d; tmp6 = fncls__86d } else { tmp6 = fncls__86 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_inspector_old_table_model_fn__1049000079_A_New_I(colcnt__3); var tmp9 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000079_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_inspector_old_table_model_fn__1049000079_A_fn_class = fncls__87d; tmp9 = fncls__87d } else { tmp9 = fncls__87 }; var tmp10 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp11 any = A_arbace_inspector_old_table_model_fn__1049000081_A_New_O(row1__2); var tmp12 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000081_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_inspector_old_table_model_fn__1049000081_A_fn_class = fncls__104d; tmp12 = fncls__104d } else { tmp12 = fncls__104 }; var tmp13 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 any = A_arbace_inspector_old_table_model_fn__1049000083_A_New_I(cnt__4); var tmp15 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000083_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_inspector_old_table_model_fn__1049000083_A_fn_class = fncls__105d; tmp15 = fncls__105d } else { tmp15 = fncls__105 }; var tmp16 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp17 any = A_arbace_inspector_old_table_model_fn__1049000085_A_New_O_O(data__0, vals__5); var tmp18 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000085_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_inspector_old_table_model_fn__1049000085_A_fn_class = fncls__106d; tmp18 = fncls__106d } else { tmp18 = fncls__106 }; var tmp19 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var tmp20 any = A_arbace_inspector_old_table_model_fn__1049000087_A_New(); var tmp21 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000087_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_inspector_old_table_model_fn__1049000087_A_fn_class = fncls__107d; tmp21 = fncls__107d } else { tmp21 = fncls__107 }; var tmp22 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp23 any = A_arbace_inspector_old_table_model_fn__1049000089_A_New(); var tmp24 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_inspector_old_table_model_fn__1049000089_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_inspector_old_table_model_fn__1049000089_A_fn_class = fncls__108d; tmp24 = fncls__108d } else { tmp24 = fncls__108 }; arg_84 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_41, tmp4, Lit_43, tmp7, Lit_45, tmp10, Lit_47, tmp13, Lit_49, tmp16, Lit_51, tmp19, Lit_53, tmp22, Lit_55, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil))); if linked_81 == nil { ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { linked_81.(*aot_arbace_core.A_arbace_core_init_proxy_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) }; return p__840000142__auto____6 }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000075_A_New() *A_arbace_inspector_old_table_model_fn__1049000075_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000075_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000075_A) Ctor() {}
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000075_A) Invoke_O_O_O__O(self, this__1, tableModelListener__2 any) any { return nil }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000077_A_New() *A_arbace_inspector_old_table_model_fn__1049000077_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000077_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000077_A) Ctor() {}
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000077_A) Invoke_O_O_O__O(self, this__1, columnIndex__2 any) any { return A_arbace_inspector_A_const_29 }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000079_A_New_I(p0 int32) *A_arbace_inspector_old_table_model_fn__1049000079_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000079_A{}; t.Ctor_I(p0); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000079_A) Ctor_I(c__colcnt int32) { t.F_colcnt = c__colcnt }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000079_A) Invoke_O_O__O(self, this__1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(t.F_colcnt).Ref() }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000081_A_New_O(p0 any) *A_arbace_inspector_old_table_model_fn__1049000081_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000081_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000081_A) Ctor_O(c__row1 any) { t.F_row1 = c__row1 }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000081_A) Invoke_O_O_O__O(self, this__1, columnIndex__2 any) any {




	var tmp1 any; var root_88 any = A_arbace_inspector_A_const_26.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = t.F_row1; if linked_89 == nil { tmp1 = ifn_90.Invoke_O__O(arg_91) } else { tmp1 = linked_89.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_88, arg_91) }; if jrt.J2g_Truth(tmp1) {
		var root_92 any = A_arbace_inspector_A_const_30.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var tmp2 any; var root_96 any = A_arbace_inspector_A_const_31.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = t.F_row1; if linked_97 == nil { tmp2 = ifn_98.Invoke_O__O(arg_99) } else { tmp2 = linked_97.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_96, arg_99) }; arg_95 = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(columnIndex__2)); if linked_93 == nil { return ifn_94.Invoke_O__O(arg_95) } else { return linked_93.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_92, arg_95) } } else {
			var root_100 any = A_arbace_inspector_A_const_32.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = columnIndex__2; if linked_101 == nil { return ifn_102.Invoke_O__O(arg_103) } else { return linked_101.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_100, arg_103) } } }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000083_A_New_I(p0 int32) *A_arbace_inspector_old_table_model_fn__1049000083_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000083_A{}; t.Ctor_I(p0); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000083_A) Ctor_I(c__cnt int32) { t.F_cnt = c__cnt }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000083_A) Invoke_O_O__O(self, this__1 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(t.F_cnt).Ref() }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000085_A_New_O_O(p0, p1 any) *A_arbace_inspector_old_table_model_fn__1049000085_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000085_A) Ctor_O_O(c__data, c__vals any) { t.F_data = c__data; t.F_vals = c__vals }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000085_A) Invoke_O_O_O_O__O(self, this__1, rowIndex__2, columnIndex__3 any) any {









	var tmp1 lang.IFn = lang.IFn_Cast(t.F_vals); var tmp2 any = t.F_data; return lang.RT_Nth_O_I__O_NoInit(tmp1.Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_O__I_NoInit(rowIndex__2))), lang.RT_IntCast_O__I_NoInit(columnIndex__3)) }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000087_A_New() *A_arbace_inspector_old_table_model_fn__1049000087_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000087_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000087_A) Ctor() {}
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000087_A) Invoke_O_O_O_O__O(self, this__1, rowIndex__2, columnIndex__3 any) any { return jrt.Boolean_FALSE.Ref() }
//line :80:1
func A_arbace_inspector_old_table_model_fn__1049000089_A_New() *A_arbace_inspector_old_table_model_fn__1049000089_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_old_table_model_fn__1049000089_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000089_A) Ctor() {}
//line :80:1
func (t *A_arbace_inspector_old_table_model_fn__1049000089_A) Invoke_O_O_O__O(self, this__1, tableModelListener__2 any) any { return nil }













func A_arbace_inspector_inspect_tree_A_New() *A_arbace_inspector_inspect_tree_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_inspect_tree_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_inspector_inspect_tree_A) Ctor() {}
//line :94:1
func (t *A_arbace_inspector_inspect_tree_A) Invoke_O_O__O(self, data__0 any) any { var G__1049000092__2_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11), jrt.RefArrayOf(jrt.Object_class, Lit_23)); var tmp1 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10); var tmp2 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8); var tmp3 any; var root_109 any = A_arbace_inspector_A_const_33.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_inspector_tree_model_A_fn_class); var ifn_111 lang.IFn; if




	linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = data__0; if linked_110 == nil { tmp3 = ifn_111.Invoke_O__O(arg_112) } else { tmp3 = linked_110.(*A_arbace_inspector_tree_model_A).Invoke_O_O__O(root_109, arg_112) }; lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000092__2_, Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3))))));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000092__2_, Lit_38, jrt.RefArrayOf(jrt.Object_class, A_arbace_inspector_A_const_34, A_arbace_inspector_A_const_35));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000092__2_, Lit_39, jrt.RefArrayOf(jrt.Object_class, jrt.Boolean_TRUE.Ref())); return G__1049000092__2_ }

func A_arbace_inspector_inspect_table_A_New() *A_arbace_inspector_inspect_table_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_inspect_table_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_inspector_inspect_table_A) Ctor() {}
//line :103:1
func (t *A_arbace_inspector_inspect_table_A) Invoke_O_O__O(self, data__0 any) any { var G__1049000094__2_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11), jrt.RefArrayOf(jrt.Object_class, Lit_23)); var tmp1 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10); var tmp2 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9); var tmp3 any; var root_113 any = A_arbace_inspector_A_const_36.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_inspector_old_table_model_A_fn_class); var ifn_115 lang.IFn; if






	linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = data__0; if linked_114 == nil { tmp3 = ifn_115.Invoke_O__O(arg_116) } else { tmp3 = linked_114.(*A_arbace_inspector_old_table_model_A).Invoke_O_O__O(root_113, arg_116) }; lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000094__2_, Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3))))));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000094__2_, Lit_38, jrt.RefArrayOf(jrt.Object_class, A_arbace_inspector_A_const_37, A_arbace_inspector_A_const_38));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000094__2_, Lit_39, jrt.RefArrayOf(jrt.Object_class, jrt.Boolean_TRUE.Ref())); return G__1049000094__2_ }



func A_arbace_inspector_eval1049000098_fn__1049000099_A_New() *A_arbace_inspector_eval1049000098_fn__1049000099_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000098_fn__1049000099_A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_A) Ctor() {}
//line :116:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 any = A_arbace_inspector_A_const_39; var tmp2 any = A_arbace_inspector_A_const_40; var tmp3 any = A_arbace_inspector_A_const_41; var tmp4 any = A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_New_O(x__1); var tmp5 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_fn_class; if
												fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_fn_class = fncls__117d; tmp5 = fncls__117d } else { tmp5 = fncls__117 }; var tmp6 any = /*line :116:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any = A_arbace_inspector_A_const_42; var tmp8 any = A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_New_O(x__1); var tmp9 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_fn_class; if
												fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_fn_class = fncls__122d; tmp9 = fncls__122d } else { tmp9 = fncls__122 }; return /*line :116:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp6, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil))) }
func A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_New_O(p0 any) *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :117:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A) Invoke_O_O__O(self, i__1 any) any { return t.F_x }
//line :117:1
func A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_New_O(p0 any) *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :117:1
func (t *A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 any; var root_118 any = A_arbace_inspector_A_const_43.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = t.F_x; if linked_119 == nil { tmp1 = ifn_120.Invoke_O__O(arg_121) } else { tmp1 = linked_119.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_118, arg_121) }; return jrt.NN(jrt.Class_Cast(tmp1)).GetName__String().Ref() }

func A_arbace_inspector_eval1049000106_fn__1049000107_A_New() *A_arbace_inspector_eval1049000106_fn__1049000107_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000106_fn__1049000107_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_A) Ctor() {}
//line :119:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_A) Invoke_O_O__O(self, c__1 any) any { var v__2 any; var tmp1 any; var root_123 any = A_arbace_inspector_A_const_44.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_125 lang.IFn; if
												linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = c__1; if linked_124 == nil { tmp1 = ifn_125.Invoke_O__O(arg_126) } else { tmp1 = linked_124.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_123, arg_126) }; if jrt.J2g_Truth(tmp1) { v__2 = c__1 } else { var root_127 any = A_arbace_inspector_A_const_45.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = c__1; if linked_128 == nil { v__2 = ifn_129.Invoke_O__O(arg_130) } else { v__2 = linked_128.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_127, arg_130) } }; var tmp2 any = A_arbace_inspector_A_const_39; var tmp3 any = /*line :119:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__2)).Ref(); var tmp4 any = A_arbace_inspector_A_const_41; var tmp5 any = A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_New_O(v__2); var tmp6 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_fn_class; if


	fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_fn_class = fncls__131d; tmp6 = fncls__131d } else { tmp6 = fncls__131 }; var tmp7 any = /*line :119:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_inspector_A_const_42; var tmp9 any = A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_New(); var tmp10 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_fn_class; if



	fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_fn_class = fncls__132d; tmp10 = fncls__132d } else { tmp10 = fncls__132 }; return /*line :119:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil))) }


func A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_New_O(p0 any) *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A{}; t.Ctor_O(p0); return t }
//line :122:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :122:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A) Invoke_O_O__O(self, i__1 any) any { return lang.IFn_Cast(t.F_v).Invoke_O__O(i__1) }
func A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_New() *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A) Ctor() {}
//line :123:1
func (t *A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A) Invoke_O_O__O(self, i__1 any) any { return i__1 }

func A_arbace_inspector_eval1049000114_fn__1049000115_A_New() *A_arbace_inspector_eval1049000114_fn__1049000115_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000114_fn__1049000115_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_A) Ctor() {}
//line :125:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_A) Invoke_O_O__O(self, c__1 any) any { var v__2 any; var root_133 any = A_arbace_inspector_A_const_45.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_135 lang.IFn; if
												linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var root_137 any = A_arbace_inspector_A_const_46.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var root_141 any = A_arbace_inspector_A_const_47.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any; var tmp1 any = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_New(); var tmp2 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_fn_class = fncls__151d; tmp2 = fncls__151d } else { tmp2 = fncls__151 }; arg_144 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_145 any = c__1; if linked_142 == nil { arg_140 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { arg_140 = linked_142.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_141, arg_144, arg_145) }; if linked_138 == nil { arg_136 = ifn_139.Invoke_O__O(arg_140) } else { arg_136 = linked_138.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_137, arg_140) }; if linked_134 == nil { v__2 = ifn_135.Invoke_O__O(arg_136) } else { v__2 = linked_134.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_133, arg_136) }; var tmp3 any = A_arbace_inspector_A_const_39; var tmp4 any = /*line :125:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__2)).Ref(); var tmp5 any = A_arbace_inspector_A_const_41; var tmp6 any = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_New_O(v__2); var tmp7 *jrt.Class; var fncls__152 *jrt.Class = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_fn_class; if


	fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_fn_class = fncls__152d; tmp7 = fncls__152d } else { tmp7 = fncls__152 }; var tmp8 any = /*line :125:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_inspector_A_const_42; var tmp10 any = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_New_O(v__2); var tmp11 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_fn_class; if



	fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_fn_class = fncls__153d; tmp11 = fncls__153d } else { tmp11 = fncls__153 }; return /*line :125:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))) }
func A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_New() *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A) Ctor() {}
//line :126:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A) Invoke_O_O__O(self, p__1049000116__1 any) any { var vec__1049000118__2 any = p__1049000116__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1049000118__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1049000118__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_146 any = A_arbace_inspector_A_const_48.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_vector_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = k__3; var arg_150 any = v__4; if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_vector_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } }

func A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_New_O(p0 any) *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :128:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A) Invoke_O_O__O(self, i__1 any) any { return lang.IFn_Cast(lang.IFn_Cast(t.F_v).Invoke_O__O(i__1)).Invoke_O__O(A_arbace_inspector_A_const_40) }
func A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_New_O(p0 any) *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :129:1
func (t *A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A) Invoke_O_O__O(self, i__1 any) any { return lang.IFn_Cast(lang.IFn_Cast(t.F_v).Invoke_O__O(i__1)).Invoke_O__O(A_arbace_inspector_A_const_49) }

func A_arbace_inspector_list_model_A_New() *A_arbace_inspector_list_model_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_list_model_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_inspector_list_model_A) Ctor() {}
//line :131:1
func (t *A_arbace_inspector_list_model_A) Invoke_O_O__O(self, provider__0 any) any { var map__1049000128__2 any = provider__0; var map__1049000128__3 any; if
											lang.ISeq_InstanceOf(map__1049000128__2) { var tmp1 any; var root_154 any = A_arbace_inspector_A_const_50.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = map__1049000128__2; if linked_155 == nil { tmp1 = ifn_156.Invoke_O__O(arg_157) } else { tmp1 = linked_155.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_154, arg_157) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_158 any = A_arbace_inspector_A_const_51.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = map__1049000128__2; if linked_159 == nil { tmp2 = ifn_160.Invoke_O__O(arg_161) } else { tmp2 = linked_159.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_158, arg_161) }; map__1049000128__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_162 any = A_arbace_inspector_A_const_21.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = map__1049000128__2; if linked_163 == nil { tmp3 = ifn_164.Invoke_O__O(arg_165) } else { tmp3 = linked_163.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(tmp3) { var root_166 any = A_arbace_inspector_A_const_25.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = map__1049000128__2; if linked_167 == nil { map__1049000128__3 = ifn_168.Invoke_O__O(arg_169) } else { map__1049000128__3 = linked_167.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_166, arg_169) } } else { map__1049000128__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1049000128__3 = map__1049000128__2 }; var nrows__4 any = /*line :131:1*/lang.RT_Get_O_O__O_NoInit(map__1049000128__3, A_arbace_inspector_A_const_39); var get_value__5 any = lang.RT_Get_O_O__O_NoInit(map__1049000128__3, A_arbace_inspector_A_const_41); var get_label__6 any = lang.RT_Get_O_O__O_NoInit(map__1049000128__3, A_arbace_inspector_A_const_42); _ = nrows__4; _ = get_value__5; _ = get_label__6; panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(Lit_22))) }











func A_arbace_inspector_eval1049000133_fn__1049000134_A_New() *A_arbace_inspector_eval1049000133_fn__1049000134_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_eval1049000133_fn__1049000134_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_inspector_eval1049000133_fn__1049000134_A) Ctor() {}
//line :143:1
func (t *A_arbace_inspector_eval1049000133_fn__1049000134_A) Invoke_O_O__O(self, x__1 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(Lit_22))) }











func A_arbace_inspector_inspect_A_New() *A_arbace_inspector_inspect_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_inspect_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_inspector_inspect_A) Ctor() {}
//line :155:1
func (t *A_arbace_inspector_inspect_A) Invoke_O_O__O(self, x__0 any) any { var G__1049000137__2_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11), jrt.RefArrayOf(jrt.Object_class, Lit_23)); var tmp1 any; var G__1049000138__3_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7), jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1), jrt.RefArrayOf(jrt.Object_class)))); var tmp2 any; var G__1049000139__4_ any = lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), jrt.RefArrayOf(jrt.Object_class));







	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_25))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_26, jrt.RefArrayOf(jrt.Object_class));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_27))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_28))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_29))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_30))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_31))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_26, jrt.RefArrayOf(jrt.Object_class));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_32))));
	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000139__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12), Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13), jrt.RefArrayOf(jrt.Object_class, Lit_33)))); tmp2 = G__1049000139__4_; /*line :162:1*/lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000138__3_, Lit_24, jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Reflector_GetStaticField_Class_String__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1), Lit_34))); var tmp3 /*line :174:1*/*jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10); var tmp4 any; var G__1049000140__4_ any; var tmp5 *jrt.Class = lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9); var tmp6 any; var root_170 any = A_arbace_inspector_A_const_54.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_inspector_list_model_A_fn_class); var ifn_172 lang.IFn; if

	linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = lang.IFn_Cast(A_arbace_inspector_A_const_55.GetRawRoot__O()).Invoke_O__O(x__0); if linked_171 == nil { tmp6 = ifn_172.Invoke_O__O(arg_173) } else { tmp6 = linked_171.(*A_arbace_inspector_list_model_A).Invoke_O_O__O(root_170, arg_173) }; G__1049000140__4_ = /*line :174:1*/lang.Reflector_InvokeConstructor_Class_O1__O(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6));


	lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(G__1049000140__4_, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9), Lit_35, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_GetStaticField_Class_String__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9), Lit_36))); tmp4 = G__1049000140__4_; /*line :174:1*/lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000138__3_, Lit_24, jrt.RefArrayOf(jrt.Object_class, lang.Reflector_InvokeConstructor_Class_O1__O(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4)), lang.Reflector_GetStaticField_Class_String__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1), Lit_37))); tmp1 = G__1049000138__3_; /*line :160:1*/lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000137__2_, Lit_24, jrt.RefArrayOf(jrt.Object_class, tmp1));


















	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000137__2_, Lit_38, jrt.RefArrayOf(jrt.Object_class, A_arbace_inspector_A_const_52, A_arbace_inspector_A_const_53));
	lang.Reflector_InvokeInstanceMethod_O_String_O1__O(G__1049000137__2_, Lit_39, jrt.RefArrayOf(jrt.Object_class, jrt.Boolean_TRUE.Ref())); return G__1049000137__2_ }



















































































































type A_arbace_inspector_A struct{ jrt.Object }

var A_arbace_inspector_A_const_pool *jrt.RefArray

var A_arbace_inspector_A_const_0 *lang.Var

var A_arbace_inspector_A_const_1 any

var A_arbace_inspector_A_const_2 *lang.Var

var A_arbace_inspector_A_const_3 *lang.Var

var A_arbace_inspector_A_const_4 *lang.Var

var A_arbace_inspector_A_const_5 *lang.Var

var A_arbace_inspector_A_const_6 any

var A_arbace_inspector_A_const_7 *lang.Var

var A_arbace_inspector_A_const_8 *lang.Var

var A_arbace_inspector_A_const_9 *lang.Var

var A_arbace_inspector_A_const_10 *lang.Keyword

var A_arbace_inspector_A_const_11 *lang.Keyword

var A_arbace_inspector_A_const_12 *lang.Var

var A_arbace_inspector_A_const_13 *lang.Keyword

var A_arbace_inspector_A_const_14 *lang.Keyword

var A_arbace_inspector_A_const_15 *lang.Keyword

var A_arbace_inspector_A_const_16 *lang.Var

var A_arbace_inspector_A_const_17 *lang.Var

var A_arbace_inspector_A_const_18 *lang.Var

var A_arbace_inspector_A_const_19 *lang.Var

var A_arbace_inspector_A_const_20 *lang.Var

var A_arbace_inspector_A_const_21 *lang.Var

var A_arbace_inspector_A_const_22 *lang.Var

var A_arbace_inspector_A_const_23 *lang.Var

var A_arbace_inspector_A_const_24 any

var A_arbace_inspector_A_const_25 *lang.Var

var A_arbace_inspector_A_const_26 *lang.Var

var A_arbace_inspector_A_const_27 *lang.Var

var A_arbace_inspector_A_const_28 *lang.Var

var A_arbace_inspector_A_const_29 *jrt.Class

var A_arbace_inspector_A_const_30 *lang.Var

var A_arbace_inspector_A_const_31 *lang.Var

var A_arbace_inspector_A_const_32 *lang.Var

var A_arbace_inspector_A_const_33 *lang.Var

var A_arbace_inspector_A_const_34 any

var A_arbace_inspector_A_const_35 any

var A_arbace_inspector_A_const_36 *lang.Var

var A_arbace_inspector_A_const_37 any

var A_arbace_inspector_A_const_38 any

var A_arbace_inspector_A_const_39 *lang.Keyword

var A_arbace_inspector_A_const_40 any

var A_arbace_inspector_A_const_41 *lang.Keyword

var A_arbace_inspector_A_const_42 *lang.Keyword

var A_arbace_inspector_A_const_43 *lang.Var

var A_arbace_inspector_A_const_44 *lang.Var

var A_arbace_inspector_A_const_45 *lang.Var

var A_arbace_inspector_A_const_46 *lang.Var

var A_arbace_inspector_A_const_47 *lang.Var

var A_arbace_inspector_A_const_48 *lang.Var

var A_arbace_inspector_A_const_49 any

var A_arbace_inspector_A_const_50 *lang.Var

var A_arbace_inspector_A_const_51 *lang.Var

var A_arbace_inspector_A_const_52 any

var A_arbace_inspector_A_const_53 any

var A_arbace_inspector_A_const_54 *lang.Var

var A_arbace_inspector_A_const_55 *lang.Var

var A_arbace_inspector_A_init jrt.ClassInit

func A_arbace_inspector_A_Init() { if !A_arbace_inspector_A_init.Done() { A_arbace_inspector_A_init.Run(A_arbace_inspector_A_clinit) } }

func A_arbace_inspector_A_clinit() { A_arbace_inspector_A_clinit_p0(); A_arbace_inspector_A_clinit_p1(); A_arbace_inspector_A_clinit_p2(); A_arbace_inspector_A_clinit_p3(); A_arbace_inspector_A_clinit_p4() }

func A_arbace_inspector_A_clinit_p0() { jrt.StartCheck(); A_arbace_inspector_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 67); A_arbace_inspector_A_const_0 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[11]); A_arbace_inspector_A_const_1 = A_arbace_inspector_A_const_pool.A[12]; A_arbace_inspector_A_const_2 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[13]); A_arbace_inspector_A_const_3 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[14]); A_arbace_inspector_A_const_4 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[15]); A_arbace_inspector_A_const_5 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[16]); A_arbace_inspector_A_const_6 = A_arbace_inspector_A_const_pool.A[17]; A_arbace_inspector_A_const_7 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[18]); A_arbace_inspector_A_const_8 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[19]); A_arbace_inspector_A_const_9 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[20]); A_arbace_inspector_A_const_10 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[21]) }

func A_arbace_inspector_A_clinit_p1() { A_arbace_inspector_A_const_11 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[22]); A_arbace_inspector_A_const_12 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[23]); A_arbace_inspector_A_const_13 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[24]); A_arbace_inspector_A_const_14 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[25]); A_arbace_inspector_A_const_15 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[26]); A_arbace_inspector_A_const_16 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[27]); A_arbace_inspector_A_const_17 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[28]); A_arbace_inspector_A_const_18 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[29]); A_arbace_inspector_A_const_19 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[30]); A_arbace_inspector_A_const_20 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[31]); A_arbace_inspector_A_const_21 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[32]); A_arbace_inspector_A_const_22 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[33]) }

func A_arbace_inspector_A_clinit_p2() { A_arbace_inspector_A_const_23 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[34]); A_arbace_inspector_A_const_24 = A_arbace_inspector_A_const_pool.A[35]; A_arbace_inspector_A_const_25 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[36]); A_arbace_inspector_A_const_26 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[37]); A_arbace_inspector_A_const_27 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[38]); A_arbace_inspector_A_const_28 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[39]); A_arbace_inspector_A_const_29 = jrt.Class_Cast(A_arbace_inspector_A_const_pool.A[40]); A_arbace_inspector_A_const_30 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[41]); A_arbace_inspector_A_const_31 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[42]); A_arbace_inspector_A_const_32 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[43]); A_arbace_inspector_A_const_33 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[44]); A_arbace_inspector_A_const_34 = A_arbace_inspector_A_const_pool.A[45] }

func A_arbace_inspector_A_clinit_p3() { A_arbace_inspector_A_const_35 = A_arbace_inspector_A_const_pool.A[46]; A_arbace_inspector_A_const_36 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[47]); A_arbace_inspector_A_const_37 = A_arbace_inspector_A_const_pool.A[48]; A_arbace_inspector_A_const_38 = A_arbace_inspector_A_const_pool.A[49]; A_arbace_inspector_A_const_39 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[50]); A_arbace_inspector_A_const_40 = A_arbace_inspector_A_const_pool.A[51]; A_arbace_inspector_A_const_41 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[52]); A_arbace_inspector_A_const_42 = lang.Keyword_Cast(A_arbace_inspector_A_const_pool.A[53]); A_arbace_inspector_A_const_43 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[54]); A_arbace_inspector_A_const_44 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[55]); A_arbace_inspector_A_const_45 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[56]); A_arbace_inspector_A_const_46 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[57]); A_arbace_inspector_A_const_47 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[58]) }

func A_arbace_inspector_A_clinit_p4() { A_arbace_inspector_A_const_48 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[59]); A_arbace_inspector_A_const_49 = A_arbace_inspector_A_const_pool.A[60]; A_arbace_inspector_A_const_50 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[61]); A_arbace_inspector_A_const_51 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[62]); A_arbace_inspector_A_const_52 = A_arbace_inspector_A_const_pool.A[63]; A_arbace_inspector_A_const_53 = A_arbace_inspector_A_const_pool.A[64]; A_arbace_inspector_A_const_54 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[65]); A_arbace_inspector_A_const_55 = lang.Var_Cast(A_arbace_inspector_A_const_pool.A[66]) }

func A_arbace_inspector_A_New() *A_arbace_inspector_A { A_arbace_inspector_A_Init(); t := &A_arbace_inspector_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_A) Ctor() {}

func (t *A_arbace_inspector_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_A_class }

func (t *A_arbace_inspector_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_A); return ok }

func A_arbace_inspector_A_Cast(x any) *A_arbace_inspector_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_A_class)) }; return v }



type A_arbace_inspector_atom_QMARK__A struct{ j2g_header uint64 }

var A_arbace_inspector_atom_QMARK__A_fn_class *jrt.Class



type A_arbace_inspector_collection_tag_A struct{ j2g_header uint64 }

var A_arbace_inspector_collection_tag_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000004_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000004_A_New() *A_arbace_inspector_eval1049000004_A { t := &A_arbace_inspector_eval1049000004_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000004_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000004_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000004_A_class }

func (t *A_arbace_inspector_eval1049000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000004_A); return ok }

func A_arbace_inspector_eval1049000004_A_Cast(x any) *A_arbace_inspector_eval1049000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000004_A_class)) }; return v }



type A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000004_loading__1927001464__auto____1049000005_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000008_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000008_A_New() *A_arbace_inspector_eval1049000008_A { t := &A_arbace_inspector_eval1049000008_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000008_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000008_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000008_A_class }

func (t *A_arbace_inspector_eval1049000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000008_A); return ok }

func A_arbace_inspector_eval1049000008_A_Cast(x any) *A_arbace_inspector_eval1049000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000008_A_class)) }; return v }



type A_arbace_inspector_eval1049000008_fn__1049000009_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000008_fn__1049000009_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000016_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000016_A_New() *A_arbace_inspector_eval1049000016_A { t := &A_arbace_inspector_eval1049000016_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000016_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000016_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000016_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000016_A_class }

func (t *A_arbace_inspector_eval1049000016_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000016_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000016_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000016_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000016_A); return ok }

func A_arbace_inspector_eval1049000016_A_Cast(x any) *A_arbace_inspector_eval1049000016_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000016_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000016_A_class)) }; return v }



type A_arbace_inspector_eval1049000016_fn__1049000017_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000016_fn__1049000017_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000022_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000022_A_New() *A_arbace_inspector_eval1049000022_A { t := &A_arbace_inspector_eval1049000022_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000022_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000022_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000022_A_class }

func (t *A_arbace_inspector_eval1049000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000022_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000022_A); return ok }

func A_arbace_inspector_eval1049000022_A_Cast(x any) *A_arbace_inspector_eval1049000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000022_A_class)) }; return v }



type A_arbace_inspector_eval1049000022_fn__1049000023_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000022_fn__1049000023_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000026_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000026_A_New() *A_arbace_inspector_eval1049000026_A { t := &A_arbace_inspector_eval1049000026_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000026_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000026_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000026_A_class }

func (t *A_arbace_inspector_eval1049000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000026_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000026_A); return ok }

func A_arbace_inspector_eval1049000026_A_Cast(x any) *A_arbace_inspector_eval1049000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000026_A_class)) }; return v }



type A_arbace_inspector_eval1049000026_fn__1049000027_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000026_fn__1049000027_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000030_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000030_A_New() *A_arbace_inspector_eval1049000030_A { t := &A_arbace_inspector_eval1049000030_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000030_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000030_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000030_A_class }

func (t *A_arbace_inspector_eval1049000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000030_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000030_A); return ok }

func A_arbace_inspector_eval1049000030_A_Cast(x any) *A_arbace_inspector_eval1049000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000030_A_class)) }; return v }



type A_arbace_inspector_eval1049000030_fn__1049000031_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000030_fn__1049000031_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000034_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000034_A_New() *A_arbace_inspector_eval1049000034_A { t := &A_arbace_inspector_eval1049000034_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000034_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000034_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000034_A_class }

func (t *A_arbace_inspector_eval1049000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000034_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000034_A); return ok }

func A_arbace_inspector_eval1049000034_A_Cast(x any) *A_arbace_inspector_eval1049000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000034_A_class)) }; return v }



type A_arbace_inspector_eval1049000034_fn__1049000035_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000034_fn__1049000035_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000038_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000038_A_New() *A_arbace_inspector_eval1049000038_A { t := &A_arbace_inspector_eval1049000038_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000038_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000038_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000038_A_class }

func (t *A_arbace_inspector_eval1049000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000038_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000038_A); return ok }

func A_arbace_inspector_eval1049000038_A_Cast(x any) *A_arbace_inspector_eval1049000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000038_A_class)) }; return v }



type A_arbace_inspector_eval1049000038_fn__1049000039_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000038_fn__1049000039_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000042_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000042_A_New() *A_arbace_inspector_eval1049000042_A { t := &A_arbace_inspector_eval1049000042_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000042_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000042_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000042_A_class }

func (t *A_arbace_inspector_eval1049000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000042_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000042_A); return ok }

func A_arbace_inspector_eval1049000042_A_Cast(x any) *A_arbace_inspector_eval1049000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000042_A_class)) }; return v }



type A_arbace_inspector_eval1049000042_fn__1049000043_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000042_fn__1049000043_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000046_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000046_A_New() *A_arbace_inspector_eval1049000046_A { t := &A_arbace_inspector_eval1049000046_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000046_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000046_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000046_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000046_A_class }

func (t *A_arbace_inspector_eval1049000046_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000046_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000046_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000046_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000046_A); return ok }

func A_arbace_inspector_eval1049000046_A_Cast(x any) *A_arbace_inspector_eval1049000046_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000046_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000046_A_class)) }; return v }



type A_arbace_inspector_eval1049000046_fn__1049000047_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000046_fn__1049000047_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000050_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000050_A_New() *A_arbace_inspector_eval1049000050_A { t := &A_arbace_inspector_eval1049000050_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000050_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000050_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000050_A_class }

func (t *A_arbace_inspector_eval1049000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000050_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000050_A); return ok }

func A_arbace_inspector_eval1049000050_A_Cast(x any) *A_arbace_inspector_eval1049000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000050_A_class)) }; return v }



type A_arbace_inspector_eval1049000050_fn__1049000051_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000050_fn__1049000051_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000054_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000054_A_New() *A_arbace_inspector_eval1049000054_A { t := &A_arbace_inspector_eval1049000054_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000054_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000054_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000054_A_class }

func (t *A_arbace_inspector_eval1049000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000054_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000054_A); return ok }

func A_arbace_inspector_eval1049000054_A_Cast(x any) *A_arbace_inspector_eval1049000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000054_A_class)) }; return v }



type A_arbace_inspector_eval1049000054_fn__1049000055_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000054_fn__1049000055_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000098_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000098_A_New() *A_arbace_inspector_eval1049000098_A { t := &A_arbace_inspector_eval1049000098_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000098_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000098_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000098_A_class }

func (t *A_arbace_inspector_eval1049000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000098_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000098_A); return ok }

func A_arbace_inspector_eval1049000098_A_Cast(x any) *A_arbace_inspector_eval1049000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000098_A_class)) }; return v }



type A_arbace_inspector_eval1049000098_fn__1049000099_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000098_fn__1049000099_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A struct{ j2g_header uint64; F_x any }

var A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000100_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A struct{ j2g_header uint64; F_x any }

var A_arbace_inspector_eval1049000098_fn__1049000099_fn__1049000102_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000106_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000106_A_New() *A_arbace_inspector_eval1049000106_A { t := &A_arbace_inspector_eval1049000106_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000106_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000106_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000106_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000106_A_class }

func (t *A_arbace_inspector_eval1049000106_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000106_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000106_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000106_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000106_A); return ok }

func A_arbace_inspector_eval1049000106_A_Cast(x any) *A_arbace_inspector_eval1049000106_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000106_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000106_A_class)) }; return v }



type A_arbace_inspector_eval1049000106_fn__1049000107_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000106_fn__1049000107_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A struct{ j2g_header uint64; F_v any }

var A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000108_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000106_fn__1049000107_fn__1049000110_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000114_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000114_A_New() *A_arbace_inspector_eval1049000114_A { t := &A_arbace_inspector_eval1049000114_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000114_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000114_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000114_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000114_A_class }

func (t *A_arbace_inspector_eval1049000114_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000114_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000114_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000114_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000114_A); return ok }

func A_arbace_inspector_eval1049000114_A_Cast(x any) *A_arbace_inspector_eval1049000114_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000114_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000114_A_class)) }; return v }



type A_arbace_inspector_eval1049000114_fn__1049000115_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000114_fn__1049000115_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000117_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A struct{ j2g_header uint64; F_v any }

var A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000122_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A struct{ j2g_header uint64; F_v any }

var A_arbace_inspector_eval1049000114_fn__1049000115_fn__1049000124_A_fn_class *jrt.Class



type A_arbace_inspector_eval1049000133_A struct{ jrt.Object }

func A_arbace_inspector_eval1049000133_A_New() *A_arbace_inspector_eval1049000133_A { t := &A_arbace_inspector_eval1049000133_A{}; t.Ctor(); return t }

func (t *A_arbace_inspector_eval1049000133_A) Ctor() {}

func (t *A_arbace_inspector_eval1049000133_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_inspector_eval1049000133_A) GetClass__Class() *jrt.Class { return A_arbace_inspector_eval1049000133_A_class }

func (t *A_arbace_inspector_eval1049000133_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_inspector_eval1049000133_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_inspector_eval1049000133_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_inspector_eval1049000133_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_inspector_eval1049000133_A); return ok }

func A_arbace_inspector_eval1049000133_A_Cast(x any) *A_arbace_inspector_eval1049000133_A { if x == nil { return nil }; v, ok := x.(*A_arbace_inspector_eval1049000133_A); if !ok { panic(jrt.ClassCast(x, A_arbace_inspector_eval1049000133_A_class)) }; return v }



type A_arbace_inspector_eval1049000133_fn__1049000134_A struct{ j2g_header uint64 }

var A_arbace_inspector_eval1049000133_fn__1049000134_A_fn_class *jrt.Class



type A_arbace_inspector_inspect_A struct{ j2g_header uint64 }

var A_arbace_inspector_inspect_A_fn_class *jrt.Class



type A_arbace_inspector_inspect_table_A struct{ j2g_header uint64 }

var A_arbace_inspector_inspect_table_A_fn_class *jrt.Class



type A_arbace_inspector_inspect_tree_A struct{ j2g_header uint64 }

var A_arbace_inspector_inspect_tree_A_fn_class *jrt.Class



type A_arbace_inspector_list_model_A struct{ j2g_header uint64 }

var A_arbace_inspector_list_model_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000075_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_fn__1049000075_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000077_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_fn__1049000077_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000079_A struct{ j2g_header uint64; F_colcnt int32 }

var A_arbace_inspector_old_table_model_fn__1049000079_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000081_A struct{ j2g_header uint64; F_row1 any }

var A_arbace_inspector_old_table_model_fn__1049000081_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000083_A struct{ j2g_header uint64; F_cnt int32 }

var A_arbace_inspector_old_table_model_fn__1049000083_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000085_A struct{ j2g_header uint64; F_data, F_vals any }

var A_arbace_inspector_old_table_model_fn__1049000085_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000087_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_fn__1049000087_A_fn_class *jrt.Class



type A_arbace_inspector_old_table_model_fn__1049000089_A struct{ j2g_header uint64 }

var A_arbace_inspector_old_table_model_fn__1049000089_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000058_A struct{ j2g_header uint64; F_data any }

var A_arbace_inspector_tree_model_fn__1049000058_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000060_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000060_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000062_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000062_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000064_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000064_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000066_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000066_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000068_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000068_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000070_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000070_A_fn_class *jrt.Class



type A_arbace_inspector_tree_model_fn__1049000072_A struct{ j2g_header uint64 }

var A_arbace_inspector_tree_model_fn__1049000072_A_fn_class *jrt.Class
