//line aot_arbace_g2a_print_text__init.ae:1
package aot_arbace_g2a_print_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print_text__init_A_Unit0__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_g2a_print_text__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_text__init_A_const_1) }
//line :1:1
func A_arbace_g2a_print_text__init_A_Unit1__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_print_text__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_2)) }
//line :1:1
func A_arbace_g2a_print_text__init_A_Unit2__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_Init(); tmp2 = A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_print_text__init_A_Unit3__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_print_text__init_A_const_1)).Equals_O__Z(A_arbace_g2a_print_text__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_print_text_eval190000008_fn__190000009_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_print_text_eval190000008_fn__190000009_A_Init(); tmp2 = A_arbace_g2a_print_text_eval190000008_fn__190000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_g2a_print_text__init_A_Load__O() any { A_arbace_g2a_print_text__init_A_Init(); A_arbace_g2a_print_text__init_A_Unit0__O(); A_arbace_g2a_print_text__init_A_Unit1__O(); A_arbace_g2a_print_text__init_A_Unit2__O(); A_arbace_g2a_print_text__init_A_Unit3__O(); A_arbace_g2a_print_text__init_A_Unit4__O(); A_arbace_g2a_print_text__init_A_Unit5__O(); A_arbace_g2a_print_text__init_A_Unit6__O(); A_arbace_g2a_print_text__init_A_Unit7__O(); A_arbace_g2a_print_text__init_A_Unit8__O(); A_arbace_g2a_print_text__init_A_Unit9__O(); A_arbace_g2a_print_text__init_A_Unit10__O(); A_arbace_g2a_print_text__init_A_Unit11__O(); A_arbace_g2a_print_text__init_A_Unit12__O(); A_arbace_g2a_print_text__init_A_Unit13__O(); A_arbace_g2a_print_text__init_A_Unit14__O(); A_arbace_g2a_print_text__init_A_Unit15__O(); A_arbace_g2a_print_text__init_A_Unit16__O(); A_arbace_g2a_print_text__init_A_Unit17__O(); A_arbace_g2a_print_text__init_A_Unit18__O(); A_arbace_g2a_print_text__init_A_Unit19__O(); A_arbace_g2a_print_text__init_A_Unit20__O(); A_arbace_g2a_print_text__init_A_Unit21__O(); A_arbace_g2a_print_text__init_A_Unit22__O(); A_arbace_g2a_print_text__init_A_Unit23__O(); A_arbace_g2a_print_text__init_A_Unit24__O(); A_arbace_g2a_print_text__init_A_Unit25__O(); A_arbace_g2a_print_text__init_A_Unit26__O(); A_arbace_g2a_print_text__init_A_Unit27__O(); A_arbace_g2a_print_text__init_A_Unit28__O(); return nil }













func A_arbace_g2a_print_text__init_A_Unit4__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_4; jrt.NN(tmp1).BindRoot_O__V(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, jrt.Byte_ValueOf_B__Byte(26).Ref(), jrt.Byte_ValueOf_B__Byte(11).Ref(), jrt.Byte_ValueOf_B__Byte(28).Ref(), jrt.Byte_ValueOf_B__Byte(23).Ref(), jrt.Byte_ValueOf_B__Byte(9).Ref(), jrt.Byte_ValueOf_B__Byte(2).Ref(), jrt.Byte_ValueOf_B__Byte(24).Ref(), jrt.Byte_ValueOf_B__Byte(1).Ref(), jrt.Byte_ValueOf_B__Byte(27).Ref(), jrt.Byte_ValueOf_B__Byte(8).Ref(), jrt.Byte_ValueOf_B__Byte(3).Ref(), jrt.Byte_ValueOf_B__Byte(4).Ref(), jrt.Byte_ValueOf_B__Byte(7).Ref(), jrt.Byte_ValueOf_B__Byte(22).Ref(), jrt.Byte_ValueOf_B__Byte(21).Ref(), jrt.Byte_ValueOf_B__Byte(20).Ref(), jrt.Byte_ValueOf_B__Byte(5).Ref(), jrt.Byte_ValueOf_B__Byte(25).Ref(), jrt.Byte_ValueOf_B__Byte(29).Ref(), jrt.Byte_ValueOf_B__Byte(6).Ref(), jrt.Byte_ValueOf_B__Byte(10).Ref(), jrt.Byte_ValueOf_B__Byte(30).Ref()))); var tmp2 *lang.Var = A_arbace_g2a_print_text__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_5)); return A_arbace_g2a_print_text__init_A_const_4.Ref() }














func A_arbace_g2a_print_text__init_A_Unit5__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_6; var tmp2 any = A_arbace_g2a_print_text_go_printable_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_go_printable_QMARK__A_Init(); tmp3 = A_arbace_g2a_print_text_go_printable_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_7)); return A_arbace_g2a_print_text__init_A_const_6.Ref() }







func A_arbace_g2a_print_text__init_A_Unit6__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_8; var tmp2 any = A_arbace_g2a_print_text_hex_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_hex_A_Init(); tmp3 = A_arbace_g2a_print_text_hex_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_9)); return A_arbace_g2a_print_text__init_A_const_8.Ref() }



func A_arbace_g2a_print_text__init_A_Unit7__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_10; var tmp2 any = A_arbace_g2a_print_text_escape_cp_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_escape_cp_A_Init(); tmp3 = A_arbace_g2a_print_text_escape_cp_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_11)); return A_arbace_g2a_print_text__init_A_const_10.Ref() }











func A_arbace_g2a_print_text__init_A_Unit8__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_12; var tmp2 any = A_arbace_g2a_print_text_code_points_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_code_points_A_Init(); tmp3 = A_arbace_g2a_print_text_code_points_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_13)); return A_arbace_g2a_print_text__init_A_const_12.Ref() }











func A_arbace_g2a_print_text__init_A_Unit9__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_14; var tmp2 any = A_arbace_g2a_print_text_go_string_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_go_string_A_Init(); tmp3 = A_arbace_g2a_print_text_go_string_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_15)); return A_arbace_g2a_print_text__init_A_const_14.Ref() }








func A_arbace_g2a_print_text__init_A_Unit10__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(79, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_16; var tmp2 any = A_arbace_g2a_print_text_raw_string_ok_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_raw_string_ok_QMARK__A_Init(); tmp3 = A_arbace_g2a_print_text_raw_string_ok_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_17)); return A_arbace_g2a_print_text__init_A_const_16.Ref() }







func A_arbace_g2a_print_text__init_A_Unit11__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_18; var tmp2 any = A_arbace_g2a_print_text_go_byte_string_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_go_byte_string_A_Init(); tmp3 = A_arbace_g2a_print_text_go_byte_string_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_19)); return A_arbace_g2a_print_text__init_A_const_18.Ref() }












func A_arbace_g2a_print_text__init_A_Unit12__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_20; var tmp2 any = A_arbace_g2a_print_text_go_rune_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_go_rune_A_Init(); tmp3 = A_arbace_g2a_print_text_go_rune_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_21)); return A_arbace_g2a_print_text__init_A_const_20.Ref() }






func A_arbace_g2a_print_text__init_A_Unit13__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_22; var tmp2 any = A_arbace_g2a_print_text_float_kind_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_float_kind_A_Init(); tmp3 = A_arbace_g2a_print_text_float_kind_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_23)); return A_arbace_g2a_print_text__init_A_const_22.Ref() }





func A_arbace_g2a_print_text__init_A_Unit14__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_24; var tmp2 any = A_arbace_g2a_print_text_pow2_exponent_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_pow2_exponent_A_Init(); tmp3 = A_arbace_g2a_print_text_pow2_exponent_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_25)); return A_arbace_g2a_print_text__init_A_const_24.Ref() }




func A_arbace_g2a_print_text__init_A_Unit15__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(118, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_26; var tmp2 any = A_arbace_g2a_print_text_strip_2_5_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_strip_2_5_A_Init(); tmp3 = A_arbace_g2a_print_text_strip_2_5_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_27)); return A_arbace_g2a_print_text__init_A_const_26.Ref() }









func A_arbace_g2a_print_text__init_A_Unit16__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_28; var tmp2 any = A_arbace_g2a_print_text_go_float_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_go_float_A_Init(); tmp3 = A_arbace_g2a_print_text_go_float_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_29)); return A_arbace_g2a_print_text__init_A_const_28.Ref() }






















func A_arbace_g2a_print_text__init_A_Unit17__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(151, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_30; var tmp2 any = A_arbace_g2a_print_text_negative_number_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_negative_number_QMARK__A_Init(); tmp3 = A_arbace_g2a_print_text_negative_number_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_31)); return A_arbace_g2a_print_text__init_A_const_30.Ref() }









func A_arbace_g2a_print_text__init_A_Unit18__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_32; var tmp2 any = A_arbace_g2a_print_text_go_number_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_go_number_A_Init(); tmp3 = A_arbace_g2a_print_text_go_number_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_33)); return A_arbace_g2a_print_text__init_A_const_32.Ref() }











func A_arbace_g2a_print_text__init_A_Unit19__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_34; var tmp2 any = A_arbace_g2a_print_text_escape_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_escape_A_Init(); tmp3 = A_arbace_g2a_print_text_escape_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_35)); return A_arbace_g2a_print_text__init_A_const_34.Ref() }






func A_arbace_g2a_print_text__init_A_Unit20__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(180, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_36; var tmp2 any = A_arbace_g2a_print_text_unescape_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_unescape_A_Init(); tmp3 = A_arbace_g2a_print_text_unescape_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_37)); return A_arbace_g2a_print_text__init_A_const_36.Ref() }








func A_arbace_g2a_print_text__init_A_Unit21__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(189, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_38; var tmp2 any = A_arbace_g2a_print_text_cell_width_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_cell_width_A_Init(); tmp3 = A_arbace_g2a_print_text_cell_width_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_39)); return A_arbace_g2a_print_text__init_A_const_38.Ref() }

func A_arbace_g2a_print_text__init_A_Unit22__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(191, 1); jrt.NN(A_arbace_g2a_print_text__init_A_const_40).BindRoot_O__V(A_arbace_g2a_print_text__init_A_const_41); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_40; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_42)); return A_arbace_g2a_print_text__init_A_const_40.Ref() }

func A_arbace_g2a_print_text__init_A_Unit23__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(193, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_43; var tmp2 any = A_arbace_g2a_print_text_parse_lines_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_parse_lines_A_Init(); tmp3 = A_arbace_g2a_print_text_parse_lines_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_44)); return A_arbace_g2a_print_text__init_A_const_43.Ref() }


















func A_arbace_g2a_print_text__init_A_Unit24__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(212, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_45; var tmp2 any = A_arbace_g2a_print_text_write_padding_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_write_padding_A_Init(); tmp3 = A_arbace_g2a_print_text_write_padding_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_46)); return A_arbace_g2a_print_text__init_A_const_45.Ref() }






func A_arbace_g2a_print_text__init_A_Unit25__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(219, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_47; var tmp2 any = A_arbace_g2a_print_text_write_lines_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_write_lines_A_Init(); tmp3 = A_arbace_g2a_print_text_write_lines_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_48)); return A_arbace_g2a_print_text__init_A_const_47.Ref() }














func A_arbace_g2a_print_text__init_A_Unit26__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(234, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_49; var tmp2 any = A_arbace_g2a_print_text_format_block_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_format_block_A_Init(); tmp3 = A_arbace_g2a_print_text_format_block_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_50)); return A_arbace_g2a_print_text__init_A_const_49.Ref() }


























func A_arbace_g2a_print_text__init_A_Unit27__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(261, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_51; var tmp2 any = A_arbace_g2a_print_text_align_block_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_align_block_A_Init(); tmp3 = A_arbace_g2a_print_text_align_block_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_52)); return A_arbace_g2a_print_text__init_A_const_51.Ref() }







func A_arbace_g2a_print_text__init_A_Unit28__O() any { A_arbace_g2a_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(269, 1); var tmp1 *lang.Var = A_arbace_g2a_print_text__init_A_const_53; var tmp2 any = A_arbace_g2a_print_text_align_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_print_text_align_A_Init(); tmp3 = A_arbace_g2a_print_text_align_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_print_text__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_print_text__init_A_const_54)); return A_arbace_g2a_print_text__init_A_const_53.Ref() }



type A_arbace_g2a_print_text__init_A struct{ jrt.Object }

var A_arbace_g2a_print_text__init_A_const_0 *lang.Var

var A_arbace_g2a_print_text__init_A_const_1 any

var A_arbace_g2a_print_text__init_A_const_2 any

var A_arbace_g2a_print_text__init_A_const_3 any

var A_arbace_g2a_print_text__init_A_const_4 *lang.Var

var A_arbace_g2a_print_text__init_A_const_5 any

var A_arbace_g2a_print_text__init_A_const_6 *lang.Var

var A_arbace_g2a_print_text__init_A_const_7 any

var A_arbace_g2a_print_text__init_A_const_8 *lang.Var

var A_arbace_g2a_print_text__init_A_const_9 any

var A_arbace_g2a_print_text__init_A_const_10 *lang.Var

var A_arbace_g2a_print_text__init_A_const_11 any

var A_arbace_g2a_print_text__init_A_const_12 *lang.Var

var A_arbace_g2a_print_text__init_A_const_13 any

var A_arbace_g2a_print_text__init_A_const_14 *lang.Var

var A_arbace_g2a_print_text__init_A_const_15 any

var A_arbace_g2a_print_text__init_A_const_16 *lang.Var

var A_arbace_g2a_print_text__init_A_const_17 any

var A_arbace_g2a_print_text__init_A_const_18 *lang.Var

var A_arbace_g2a_print_text__init_A_const_19 any

var A_arbace_g2a_print_text__init_A_const_20 *lang.Var

var A_arbace_g2a_print_text__init_A_const_21 any

var A_arbace_g2a_print_text__init_A_const_22 *lang.Var

var A_arbace_g2a_print_text__init_A_const_23 any

var A_arbace_g2a_print_text__init_A_const_24 *lang.Var

var A_arbace_g2a_print_text__init_A_const_25 any

var A_arbace_g2a_print_text__init_A_const_26 *lang.Var

var A_arbace_g2a_print_text__init_A_const_27 any

var A_arbace_g2a_print_text__init_A_const_28 *lang.Var

var A_arbace_g2a_print_text__init_A_const_29 any

var A_arbace_g2a_print_text__init_A_const_30 *lang.Var

var A_arbace_g2a_print_text__init_A_const_31 any

var A_arbace_g2a_print_text__init_A_const_32 *lang.Var

var A_arbace_g2a_print_text__init_A_const_33 any

var A_arbace_g2a_print_text__init_A_const_34 *lang.Var

var A_arbace_g2a_print_text__init_A_const_35 any

var A_arbace_g2a_print_text__init_A_const_36 *lang.Var

var A_arbace_g2a_print_text__init_A_const_37 any

var A_arbace_g2a_print_text__init_A_const_38 *lang.Var

var A_arbace_g2a_print_text__init_A_const_39 any

var A_arbace_g2a_print_text__init_A_const_40 *lang.Var

var A_arbace_g2a_print_text__init_A_const_41 any

var A_arbace_g2a_print_text__init_A_const_42 any

var A_arbace_g2a_print_text__init_A_const_43 *lang.Var

var A_arbace_g2a_print_text__init_A_const_44 any

var A_arbace_g2a_print_text__init_A_const_45 *lang.Var

var A_arbace_g2a_print_text__init_A_const_46 any

var A_arbace_g2a_print_text__init_A_const_47 *lang.Var

var A_arbace_g2a_print_text__init_A_const_48 any

var A_arbace_g2a_print_text__init_A_const_49 *lang.Var

var A_arbace_g2a_print_text__init_A_const_50 any

var A_arbace_g2a_print_text__init_A_const_51 *lang.Var

var A_arbace_g2a_print_text__init_A_const_52 any

var A_arbace_g2a_print_text__init_A_const_53 *lang.Var

var A_arbace_g2a_print_text__init_A_const_54 any

var A_arbace_g2a_print_text__init_A_init jrt.ClassInit

func A_arbace_g2a_print_text__init_A_Init() { if !A_arbace_g2a_print_text__init_A_init.Done() { A_arbace_g2a_print_text__init_A_init.Run(A_arbace_g2a_print_text__init_A_clinit) } }

func A_arbace_g2a_print_text__init_A_clinit() { A_arbace_g2a_print_text__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_145); A_arbace_g2a_print_text__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_g2a_print_text__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11)); A_arbace_g2a_print_text__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_print_text__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_9, Lit_15); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_g2a_print_text__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_151)); A_arbace_g2a_print_text__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_9, Lit_18); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_g2a_print_text__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_153)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_155).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_156, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_9, Lit_19); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_g2a_print_text__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_157)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_155).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_61)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_155).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_g2a_print_text__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_153)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_155).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_159, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_9, Lit_31); A_arbace_g2a_print_text__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_160)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_162, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_9, Lit_163); A_arbace_g2a_print_text__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_160)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_164, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_9, Lit_165); A_arbace_g2a_print_text__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_160)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_166, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(79).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_9, Lit_167); A_arbace_g2a_print_text__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_168).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_169, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(87).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_9, Lit_170); A_arbace_g2a_print_text__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_153)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_155).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_171, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(100).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_9, Lit_45); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_g2a_print_text__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_160)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_172, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(107).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_9, Lit_49); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_g2a_print_text__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_157)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_173).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_174, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(113).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_9, Lit_48); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_g2a_print_text__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_157)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_173).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_175, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(118).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_9, Lit_54); A_arbace_g2a_print_text__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_176).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_177, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(128).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_9, Lit_178); A_arbace_g2a_print_text__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_176).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_179, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(151).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_9, Lit_180); A_arbace_g2a_print_text__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_176).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_181, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(161).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_9, Lit_182); A_arbace_g2a_print_text__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_160)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_184, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(173).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_9, Lit_76); A_arbace_g2a_print_text__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_160)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_185, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(180).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_9, Lit_62); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_g2a_print_text__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_160)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(189).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_9, Lit_59); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(); var tmp26 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_61).Ref(); var tmp27 any = jrt.Long_ValueOf_J__Long(0).Ref(); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; A_arbace_g2a_print_text__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, Lit_186, tmp26, tmp27, tmp28, tmp29.Ref())); var tmp30 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp31 *jrt.Boolean; jrt.Boolean_Init(); tmp31 = jrt.Boolean_TRUE; var tmp32 any = tmp31.Ref(); A_arbace_g2a_print_text__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp30, tmp32, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(191).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_9, Lit_74); var tmp33 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp34 *jrt.Boolean; jrt.Boolean_Init(); tmp34 = jrt.Boolean_TRUE; var tmp35 any = tmp34.Ref(); A_arbace_g2a_print_text__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp35, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_187, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(193).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_9, Lit_71); var tmp36 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp37 *jrt.Boolean; jrt.Boolean_Init(); tmp37 = jrt.Boolean_TRUE; var tmp38 any = tmp37.Ref(); A_arbace_g2a_print_text__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp36, tmp38, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_188)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_189).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_190)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_155).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_191)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_155).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_192).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(212).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_9, Lit_72); var tmp39 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp40 *jrt.Boolean; jrt.Boolean_Init(); tmp40 = jrt.Boolean_TRUE; var tmp41 any = tmp40.Ref(); A_arbace_g2a_print_text__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp39, tmp41, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_188)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_189).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_193).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_195).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_196).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(219).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_9, Lit_73); var tmp42 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp43 *jrt.Boolean; jrt.Boolean_Init(); tmp43 = jrt.Boolean_TRUE; var tmp44 any = tmp43.Ref(); A_arbace_g2a_print_text__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp42, tmp44, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_188).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_193).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_195).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_196).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_197, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(234).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_9, Lit_78); var tmp45 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(); var tmp46 *jrt.Boolean; jrt.Boolean_Init(); tmp46 = jrt.Boolean_TRUE; var tmp47 any = tmp46.Ref(); A_arbace_g2a_print_text__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp45, tmp47, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_198)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_199, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(261).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)); A_arbace_g2a_print_text__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_9, Lit_200); A_arbace_g2a_print_text__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_152).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_60)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_201, lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(), jrt.Integer_ValueOf_I__Integer(269).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), Lit_150)) }

func A_arbace_g2a_print_text__init_A_New() *A_arbace_g2a_print_text__init_A { A_arbace_g2a_print_text__init_A_Init(); t := &A_arbace_g2a_print_text__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_text__init_A) Ctor() {}

func (t *A_arbace_g2a_print_text__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text__init_A_class }

func (t *A_arbace_g2a_print_text__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text__init_A); return ok }

func A_arbace_g2a_print_text__init_A_Cast(x any) *A_arbace_g2a_print_text__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text__init_A_class)) }; return v }
