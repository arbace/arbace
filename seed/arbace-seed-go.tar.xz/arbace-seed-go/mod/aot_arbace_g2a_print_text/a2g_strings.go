//line a2g_strings.ae:1
package aot_arbace_g2a_print_text

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,strkn3,dockn4,elsekn6,stringkn4,partkn4,runekn5,valuekn4,textkn5,widthkn4,htabv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn21,arbace.g2a.print-textm2,R4,s788,The text level of g2a's printer (doc/go/PRINTER-NOTES.md): Go literal spellings of the Go\n  forms' values (doc/go/SPEC.md §8.1, §12.2) and the column alignment gofmt does with\n  text/tabwriter.\n\n  The alignment is a port of go1.27.1's src/text/tabwriter/tabwriter.go (Writer.format,\n  writeLines, writePadding) for the configuration gofmt uses (go/printer with UseSpaces and\n  TabIndent: minwidth 0, tabwidth 8, padding 1, padchar ' ', DiscardEmptyColumns and\n  TabIndent). Cells end at a tab (indentation, a hard tab) or a vertical tab (an alignment\n  separator); a form feed ends a line and every column block, as in tabwriter. Text that must\n  not be cut into cells (raw strings, comments) is written with the escape characters of\n  `escape`, which `unescape` restores after alignment.v11,arbace.core13,*loaded-libs*v11,arbace.core1,<v11,arbace.core9,contains?l32,l127,v21,arbace.g2a.print-text15,printable-typesv11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core6,repeatc48,v21,arbace.g2a.print-text13,go-printable?v21,arbace.g2a.print-text3,hexR5,l2,l4,l8,v11,arbace.core9,transientv11,arbace.core11,persistent!v11,arbace.core7,ex-infov11,arbace.core6,pr-strR6,v11,arbace.core5,conj!v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv21,arbace.g2a.print-text11,code-pointsv21,arbace.g2a.print-text9,escape-cpc34,v11,arbace.core10,chunk-restv11,arbace.core4,nextv11,arbace.core6,every?v11,arbace.core4,not=l96,l13,v11,arbace.core7,string?v11,arbace.core8,integer?v11,arbace.core2,<=l0,l255,R7,R8,c39,v13,arbace.string9,includes?v11,arbace.core3,notv13,arbace.string10,lower-casev21,arbace.g2a.print-text10,float-kindv11,arbace.core6,ratio?v11,arbace.core10,bigintegerv21,arbace.g2a.print-text9,strip-2-5v21,arbace.g2a.print-text13,pow2-exponentR9,v11,arbace.core9,numeratorv11,arbace.core11,denominatorv11,arbace.core7,number?v21,arbace.g2a.print-text8,go-floatc9,c57344,c10,c57345,c11,c57346,c12,c57347,c57344,c57345,c57346,c57347,v11,arbace.core3,vecv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core4,subsv21,arbace.g2a.print-text14,empty-tab-cellR10,R11,v21,arbace.g2a.print-text10,cell-widthR12,v11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restv13,arbace.string5,splitp2,\\nl-1,c32,v11,arbace.core5,rangev21,arbace.g2a.print-text13,write-paddingv21,arbace.g2a.print-text11,write-linesv21,arbace.g2a.print-text12,format-blockv21,arbace.g2a.print-text11,parse-linesv11,arbace.core3,mapv21,arbace.g2a.print-text8,unescapep2,\\fv21,arbace.g2a.print-text11,align-blockv11,arbace.core6,concatv11,arbace.core4,pmapv11,arbace.core4,mapvv11,arbace.core13,partition-allv13,arbace.string4,join")

var Lit_1 *jrt.String = jrt.Intern("arbace.g2a.print_text$align$fn__190000080")

var Lit_2 *jrt.String = jrt.Intern("\n")

var Lit_3 *jrt.String = jrt.Intern("unpaired surrogate in a Go string: ")

var Lit_4 *jrt.String = jrt.Intern("\\a")

var Lit_5 *jrt.String = jrt.Intern("\\b")

var Lit_6 *jrt.String = jrt.Intern("\\t")

var Lit_7 *jrt.String = jrt.Intern("\\n")

var Lit_8 *jrt.String = jrt.Intern("\\v")

var Lit_9 *jrt.String = jrt.Intern("\\f")

var Lit_10 *jrt.String = jrt.Intern("\\r")

var Lit_11 *jrt.String = jrt.Intern("\\\\")

var Lit_12 *jrt.String = jrt.Intern("\\")

var Lit_13 *jrt.String = jrt.Intern("\\x")

var Lit_14 *jrt.String = jrt.Intern("\\u")

var Lit_15 *jrt.String = jrt.Intern("\\U")

var Lit_16 *jrt.String = jrt.Intern("java.math.BigDecimal")

var Lit_17 *jrt.String = jrt.Intern("java.math.BigInteger")

var Lit_18 *jrt.String = jrt.Intern(".")

var Lit_19 *jrt.String = jrt.Intern("e")

var Lit_20 *jrt.String = jrt.Intern("E")

var Lit_21 *jrt.String = jrt.Intern(".0")

var Lit_22 *jrt.String = jrt.Intern("arbace.g2a.print_text$format_block$fn__190000075")

var Lit_23 *jrt.String = jrt.Intern("\"")

var Lit_24 *jrt.String = jrt.Intern("bad byte-string part ")

var Lit_25 *jrt.String = jrt.Intern("no Go literal for ")

var Lit_26 *jrt.String = jrt.Intern("0x")

var Lit_27 *jrt.String = jrt.Intern("p-")

var Lit_28 *jrt.String = jrt.Intern("the ratio ")

var Lit_29 *jrt.String = jrt.Intern(" has no finite Go float literal")

var Lit_30 *jrt.String = jrt.Intern("not a float value: ")

var Lit_31 *jrt.String = jrt.Intern("not a rune: ")

var Lit_32 *jrt.String = jrt.Intern("'")

var Lit_33 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055")

var Lit_34 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056")

var Lit_35 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000057")

var Lit_36 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000061")

var Lit_37 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000057$fn__190000058")

var Lit_38 *jrt.String = jrt.Intern("arbace.g2a.print_text$raw_string_ok_QMARK_$fn__190000022")

var Lit_39 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistskn3,tagyn4,longyn5,quoteyn6,Stringyn5,partsyn10,BigIntegeryn1,xyn16,java.lang.Stringkn4,textkn5,widthkn4,htabyn13,StringBuilderyn8,use-tabsyn5,linesyn6,widthsyn5,line0yn5,line1yn2,sbv11,arbace.core5,in-nsMyn21,arbace.g2a.print-textm2,R0,s788,The text level of g2a's printer (doc/go/PRINTER-NOTES.md): Go literal spellings of the Go\n  forms' values (doc/go/SPEC.md §8.1, §12.2) and the column alignment gofmt does with\n  text/tabwriter.\n\n  The alignment is a port of go1.27.1's src/text/tabwriter/tabwriter.go (Writer.format,\n  writeLines, writePadding) for the configuration gofmt uses (go/printer with UseSpaces and\n  TabIndent: minwidth 0, tabwidth 8, padding 1, padchar ' ', DiscardEmptyColumns and\n  TabIndent). Cells end at a tab (indentation, a hard tab) or a vertical tab (an alignment\n  separator); a form feed ends a line and every column block, as in tabwriter. Text that must\n  not be cut into cells (raw strings, comments) is written with the escape characters of\n  `escape`, which `unescape` restores after alignment.m2,R0,s788,The text level of g2a's printer (doc/go/PRINTER-NOTES.md): Go literal spellings of the Go\n  forms' values (doc/go/SPEC.md §8.1, §12.2) and the column alignment gofmt does with\n  text/tabwriter.\n\n  The alignment is a port of go1.27.1's src/text/tabwriter/tabwriter.go (Writer.format,\n  writeLines, writePadding) for the configuration gofmt uses (go/printer with UseSpaces and\n  TabIndent: minwidth 0, tabwidth 8, padding 1, padchar ' ', DiscardEmptyColumns and\n  TabIndent). Cells end at a tab (indentation, a hard tab) or a vertical tab (an alignment\n  separator); a form feed ends a line and every column block, as in tabwriter. Text that must\n  not be cut into cells (raw strings, comments) is written with the escape characters of\n  `escape`, which `unescape` restores after alignment.R1,v21,arbace.g2a.print-text15,printable-typesm10,R2,TR3,i19,R4,i1,R5,s24,arbace/g2a/print_text.aeR0,s102,The character types (Character/getType) of go-printable?'s code points: made once, not at\n  each call.v21,arbace.g2a.print-text13,go-printable?m12,R2,TR6,L1,V1,Myn2,cpm2,R7,R8,R0,s107,Go's strconv.IsPrint, for code points: letters, marks, numbers, punctuation, symbols and\n  the ASCII space.R3,i34,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text3,hexm10,R2,TR6,L1,V2,Myn1,nm2,R7,R8,Myn5,widthm2,R7,R8,R3,i42,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text9,escape-cpm12,R2,TR6,L1,V2,Myn2,cpm2,R7,R8,R9,R0,s78,The spelling of one code point inside a Go literal quoted by quote (\\\" or \\').R3,i46,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text11,code-pointsm10,R6,L1,V1,Myn1,sm2,R7,R10,R0,s127,The code points of a Clojure string; throws on an unpaired surrogate, which a Go string\n  in the forms must not contain (§8.1).R3,i58,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text9,go-stringm10,R6,L1,V1,Myn1,sm2,R7,R10,R0,s66,An interpreted Go string literal denoting the UTF-8 encoding of s.R3,i70,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text14,raw-string-ok?m10,R6,L1,V1,Myn1,sm2,R7,R10,R0,s123,Whether s can be a raw string literal: no backquote or carriage return, and only printable\n  characters, tabs and newlines.R3,i79,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text14,go-byte-stringm10,R6,L1,V1,R11,R0,s118,(byte-string part ...): an interpreted string of the parts, strings as their UTF-8 and\n  integers 0-255 as \\x escapes.R3,i87,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text7,go-runem10,R6,L1,V1,Myn2,cpm2,R7,R8,R0,s36,A Go rune literal for code point cp.R3,i100,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text10,float-kindm12,R2,TR6,L1,V1,Myn1,sm2,R7,R10,R0,s103,s with a decimal point when it has neither a point nor an exponent, so that it stays a\n  float literal.R3,i107,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text13,pow2-exponentm12,R2,TR6,L1,V1,Myn1,nm2,R7,R12,R0,s26,k when n is 2^k, else nil.R3,i113,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text9,strip-2-5m12,R2,TR6,L1,V1,Myn1,nm2,R7,R12,R0,s67,[rest a b]: n = rest * 2^a * 5^b with rest not divisible by 2 or 5.R3,i118,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text8,go-floatm10,R6,L1,V1,R13,R0,s216,The Go float literal of a non-negative float value of the forms (§8.1, §12.2): a double as\n  the exact decimal of its shortest representation, a BigDecimal as its decimal, a ratio as a\n  short decimal or a hex float.R3,i128,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text16,negative-number?m10,R6,L1,V1,R13,R0,s131,Whether a numeric literal of the forms is negative (Go: a unary minus on the literal; -0.0\n  counts, as the reader keeps its sign).R3,i151,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text9,go-numberm10,R6,L1,V1,R13,R0,s96,The Go literal of a non-negative number of the forms: integers in decimal, floats by\n  go-float.R3,i161,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text6,escapem10,R6,L1,MV1,Myn1,sm2,R7,R10,m2,R7,R14,R0,s158,s with its tabs, newlines, vertical tabs and form feeds replaced by private characters\n  (U+E000 to U+E003), so that alignment treats it as one piece of text.R3,i173,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text8,unescapem10,R6,L1,MV1,Myn1,sm2,R7,R10,m2,R7,R14,R0,s34,The text escape replaced restored.R3,i180,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text10,cell-widthm10,R2,TR6,L1,V1,Myn1,sm2,R7,R10,R3,i189,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text14,empty-tab-cellm6,R15,s0,R16,l0,R17,Tm8,R2,TR3,i191,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text11,parse-linesm12,R2,TR6,L1,V1,Myn4,textm2,R7,R10,R0,s149,The lines of one block of text (no form feeds): each a vector of cells\n  {:text :width :htab}, the last cell being the text after the last separator.R3,i193,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text13,write-paddingm10,R2,TR6,L1,V4,Myn2,sbm2,R7,R18,Myn5,textwm2,R7,R8,Myn5,cellwm2,R7,R8,R19,R3,i212,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text11,write-linesm10,R2,TR6,L1,V5,Myn2,sbm2,R7,R18,R20,R21,R22,R23,R3,i219,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text12,format-blockm12,R2,TR6,L1,V5,R24,R20,R21,R22,R23,R0,s88,tabwriter's Writer.format over lines [line0, line1) with the column widths found so far.R3,i234,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text11,align-blockm12,R2,TR6,L1,MV1,Myn5,blockm2,R7,R10,m2,R7,R14,R0,s42,One block of text (no form feeds) aligned.R3,i261,R4,i1,R5,s24,arbace/g2a/print_text.aev21,arbace.g2a.print-text5,alignm10,R6,L1,V1,Myn4,textm2,R7,R10,R0,s165,Aligns text as gofmt's tabwriter does and restores escaped text. Form feeds end the\n  alignment sections, so a long text's blocks are aligned in parallel, in groups.R3,i269,R4,i1,R5,s24,arbace/g2a/print_text.ae")

var Lit_40 *jrt.String = jrt.Intern("arbace.g2a.print_text$eval190000004$loading__1927001464__auto____190000005")

var Lit_41 *jrt.String = jrt.Intern("arbace.g2a.print_text$eval190000008$fn__190000009")

var Lit_42 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_printable_QMARK_")

var Lit_43 *jrt.String = jrt.Intern("arbace.g2a.print_text$hex")

var Lit_44 *jrt.String = jrt.Intern("arbace.g2a.print_text$escape_cp")

var Lit_45 *jrt.String = jrt.Intern("arbace.g2a.print_text$code_points")

var Lit_46 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_string")

var Lit_47 *jrt.String = jrt.Intern("arbace.g2a.print_text$raw_string_ok_QMARK_")

var Lit_48 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_byte_string")

var Lit_49 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_rune")

var Lit_50 *jrt.String = jrt.Intern("arbace.g2a.print_text$float_kind")

var Lit_51 *jrt.String = jrt.Intern("arbace.g2a.print_text$pow2_exponent")

var Lit_52 *jrt.String = jrt.Intern("arbace.g2a.print_text$strip_2_5")

var Lit_53 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_float")

var Lit_54 *jrt.String = jrt.Intern("arbace.g2a.print_text$negative_number_QMARK_")

var Lit_55 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_number")

var Lit_56 *jrt.String = jrt.Intern("arbace.g2a.print_text$escape")

var Lit_57 *jrt.String = jrt.Intern("arbace.g2a.print_text$unescape")

var Lit_58 *jrt.String = jrt.Intern("arbace.g2a.print_text$cell_width")

var Lit_59 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines")

var Lit_60 *jrt.String = jrt.Intern("arbace.g2a.print_text$write_padding")

var Lit_61 *jrt.String = jrt.Intern("arbace.g2a.print_text$write_lines")

var Lit_62 *jrt.String = jrt.Intern("arbace.g2a.print_text$format_block")

var Lit_63 *jrt.String = jrt.Intern("arbace.g2a.print_text$align_block")

var Lit_64 *jrt.String = jrt.Intern("arbace.g2a.print_text$align")
