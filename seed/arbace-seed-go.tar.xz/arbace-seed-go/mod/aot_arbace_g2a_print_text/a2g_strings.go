//line a2g_strings.ae:1
package aot_arbace_g2a_print_text

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.g2a.print-text")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("The text level of g2a's printer (doc/go/PRINTER-NOTES.md): Go literal spellings of the Go\n  forms' values (doc/go/SPEC.md §8.1, §12.2) and the column alignment gofmt does with\n  text/tabwriter.\n\n  The alignment is a port of go1.27.1's src/text/tabwriter/tabwriter.go (Writer.format,\n  writeLines, writePadding) for the configuration gofmt uses (go/printer with UseSpaces and\n  TabIndent: minwidth 0, tabwidth 8, padding 1, padchar ' ', DiscardEmptyColumns and\n  TabIndent). Cells end at a tab (indentation, a hard tab) or a vertical tab (an alignment\n  separator); a form feed ends a line and every column block, as in tabwriter. Text that must\n  not be cut into cells (raw strings, comments) is written with the escape characters of\n  `escape`, which `unescape` restores after alignment.")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("<")

var Lit_14 *jrt.String = jrt.Intern("contains?")

var Lit_15 *jrt.String = jrt.Intern("printable-types")

var Lit_16 *jrt.String = jrt.Intern("apply")

var Lit_17 *jrt.String = jrt.Intern("repeat")

var Lit_18 *jrt.String = jrt.Intern("go-printable?")

var Lit_19 *jrt.String = jrt.Intern("hex")

var Lit_20 *jrt.String = jrt.Intern("else")

var Lit_21 *jrt.String = jrt.Intern("transient")

var Lit_22 *jrt.String = jrt.Intern("persistent!")

var Lit_23 *jrt.String = jrt.Intern("ex-info")

var Lit_24 *jrt.String = jrt.Intern("pr-str")

var Lit_25 *jrt.String = jrt.Intern("string")

var Lit_26 *jrt.String = jrt.Intern("conj!")

var Lit_27 *jrt.String = jrt.Intern("seq")

var Lit_28 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_29 *jrt.String = jrt.Intern("chunk-first")

var Lit_30 *jrt.String = jrt.Intern("first")

var Lit_31 *jrt.String = jrt.Intern("code-points")

var Lit_32 *jrt.String = jrt.Intern("escape-cp")

var Lit_33 *jrt.String = jrt.Intern("chunk-rest")

var Lit_34 *jrt.String = jrt.Intern("next")

var Lit_35 *jrt.String = jrt.Intern("every?")

var Lit_36 *jrt.String = jrt.Intern("not=")

var Lit_37 *jrt.String = jrt.Intern("string?")

var Lit_38 *jrt.String = jrt.Intern("integer?")

var Lit_39 *jrt.String = jrt.Intern("<=")

var Lit_40 *jrt.String = jrt.Intern("part")

var Lit_41 *jrt.String = jrt.Intern("rune")

var Lit_42 *jrt.String = jrt.Intern("includes?")

var Lit_43 *jrt.String = jrt.Intern("not")

var Lit_44 *jrt.String = jrt.Intern("lower-case")

var Lit_45 *jrt.String = jrt.Intern("float-kind")

var Lit_46 *jrt.String = jrt.Intern("ratio?")

var Lit_47 *jrt.String = jrt.Intern("biginteger")

var Lit_48 *jrt.String = jrt.Intern("strip-2-5")

var Lit_49 *jrt.String = jrt.Intern("pow2-exponent")

var Lit_50 *jrt.String = jrt.Intern("value")

var Lit_51 *jrt.String = jrt.Intern("numerator")

var Lit_52 *jrt.String = jrt.Intern("denominator")

var Lit_53 *jrt.String = jrt.Intern("number?")

var Lit_54 *jrt.String = jrt.Intern("go-float")

var Lit_55 *jrt.String = jrt.Intern("vec")

var Lit_56 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_57 *jrt.String = jrt.Intern("chunk-append")

var Lit_58 *jrt.String = jrt.Intern("subs")

var Lit_59 *jrt.String = jrt.Intern("empty-tab-cell")

var Lit_60 *jrt.String = jrt.Intern("text")

var Lit_61 *jrt.String = jrt.Intern("width")

var Lit_62 *jrt.String = jrt.Intern("cell-width")

var Lit_63 *jrt.String = jrt.Intern("htab")

var Lit_64 *jrt.String = jrt.Intern("chunk-cons")

var Lit_65 *jrt.String = jrt.Intern("cons")

var Lit_66 *jrt.String = jrt.Intern("chunk")

var Lit_67 *jrt.String = jrt.Intern("rest")

var Lit_68 *jrt.String = jrt.Intern("split")

var Lit_69 *jrt.String = jrt.Intern("\\n")

var Lit_70 *jrt.String = jrt.Intern("range")

var Lit_71 *jrt.String = jrt.Intern("write-padding")

var Lit_72 *jrt.String = jrt.Intern("write-lines")

var Lit_73 *jrt.String = jrt.Intern("format-block")

var Lit_74 *jrt.String = jrt.Intern("parse-lines")

var Lit_75 *jrt.String = jrt.Intern("map")

var Lit_76 *jrt.String = jrt.Intern("unescape")

var Lit_77 *jrt.String = jrt.Intern("\\f")

var Lit_78 *jrt.String = jrt.Intern("align-block")

var Lit_79 *jrt.String = jrt.Intern("concat")

var Lit_80 *jrt.String = jrt.Intern("pmap")

var Lit_81 *jrt.String = jrt.Intern("mapv")

var Lit_82 *jrt.String = jrt.Intern("partition-all")

var Lit_83 *jrt.String = jrt.Intern("join")

var Lit_84 *jrt.String = jrt.Intern("arbace.g2a.print_text$align")

var Lit_85 *jrt.String = jrt.Intern("\n")

var Lit_86 *jrt.String = jrt.Intern("arbace.g2a.print_text$align$fn__190000080")

var Lit_87 *jrt.String = jrt.Intern("arbace.g2a.print_text$align_block")

var Lit_88 *jrt.String = jrt.Intern("arbace.g2a.print_text$cell_width")

var Lit_89 *jrt.String = jrt.Intern("arbace.g2a.print_text$code_points")

var Lit_90 *jrt.String = jrt.Intern("unpaired surrogate in a Go string: ")

var Lit_91 *jrt.String = jrt.Intern("arbace.g2a.print_text$escape")

var Lit_92 *jrt.String = jrt.Intern("arbace.g2a.print_text$escape_cp")

var Lit_93 *jrt.String = jrt.Intern("\\a")

var Lit_94 *jrt.String = jrt.Intern("\\b")

var Lit_95 *jrt.String = jrt.Intern("\\t")

var Lit_96 *jrt.String = jrt.Intern("\\v")

var Lit_97 *jrt.String = jrt.Intern("\\r")

var Lit_98 *jrt.String = jrt.Intern("\\\\")

var Lit_99 *jrt.String = jrt.Intern("\\")

var Lit_100 *jrt.String = jrt.Intern("\\x")

var Lit_101 *jrt.String = jrt.Intern("\\u")

var Lit_102 *jrt.String = jrt.Intern("\\U")

var Lit_103 *jrt.String = jrt.Intern("arbace.g2a.print_text$eval190000004$loading__1927001464__auto____190000005")

var Lit_104 *jrt.String = jrt.Intern("java.math.BigDecimal")

var Lit_105 *jrt.String = jrt.Intern("java.math.BigInteger")

var Lit_106 *jrt.String = jrt.Intern("arbace.g2a.print_text$eval190000008$fn__190000009")

var Lit_107 *jrt.String = jrt.Intern("arbace.g2a.print_text$float_kind")

var Lit_108 *jrt.String = jrt.Intern(".")

var Lit_109 *jrt.String = jrt.Intern("e")

var Lit_110 *jrt.String = jrt.Intern("E")

var Lit_111 *jrt.String = jrt.Intern(".0")

var Lit_112 *jrt.String = jrt.Intern("arbace.g2a.print_text$format_block")

var Lit_113 *jrt.String = jrt.Intern("arbace.g2a.print_text$format_block$fn__190000075")

var Lit_114 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_byte_string")

var Lit_115 *jrt.String = jrt.Intern("\"")

var Lit_116 *jrt.String = jrt.Intern("bad byte-string part ")

var Lit_117 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_float")

var Lit_118 *jrt.String = jrt.Intern("no Go literal for ")

var Lit_119 *jrt.String = jrt.Intern("0x")

var Lit_120 *jrt.String = jrt.Intern("p-")

var Lit_121 *jrt.String = jrt.Intern("the ratio ")

var Lit_122 *jrt.String = jrt.Intern(" has no finite Go float literal")

var Lit_123 *jrt.String = jrt.Intern("not a float value: ")

var Lit_124 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_number")

var Lit_125 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_printable_QMARK_")

var Lit_126 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_rune")

var Lit_127 *jrt.String = jrt.Intern("not a rune: ")

var Lit_128 *jrt.String = jrt.Intern("'")

var Lit_129 *jrt.String = jrt.Intern("arbace.g2a.print_text$go_string")

var Lit_130 *jrt.String = jrt.Intern("arbace.g2a.print_text$hex")

var Lit_131 *jrt.String = jrt.Intern("arbace.g2a.print_text$negative_number_QMARK_")

var Lit_132 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines")

var Lit_133 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055")

var Lit_134 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056")

var Lit_135 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000057")

var Lit_136 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000057$fn__190000058")

var Lit_137 *jrt.String = jrt.Intern("arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000061")

var Lit_138 *jrt.String = jrt.Intern("arbace.g2a.print_text$pow2_exponent")

var Lit_139 *jrt.String = jrt.Intern("arbace.g2a.print_text$raw_string_ok_QMARK_")

var Lit_140 *jrt.String = jrt.Intern("arbace.g2a.print_text$raw_string_ok_QMARK_$fn__190000022")

var Lit_141 *jrt.String = jrt.Intern("arbace.g2a.print_text$strip_2_5")

var Lit_142 *jrt.String = jrt.Intern("arbace.g2a.print_text$unescape")

var Lit_143 *jrt.String = jrt.Intern("arbace.g2a.print_text$write_lines")

var Lit_144 *jrt.String = jrt.Intern("arbace.g2a.print_text$write_padding")

var Lit_145 *jrt.String = jrt.Intern("in-ns")

var Lit_146 *jrt.String = jrt.Intern("private")

var Lit_147 *jrt.String = jrt.Intern("line")

var Lit_148 *jrt.String = jrt.Intern("column")

var Lit_149 *jrt.String = jrt.Intern("file")

var Lit_150 *jrt.String = jrt.Intern("arbace/g2a/print_text.ae")

var Lit_151 *jrt.String = jrt.Intern("The character types (Character/getType) of go-printable?'s code points: made once, not at\n  each call.")

var Lit_152 *jrt.String = jrt.Intern("arglists")

var Lit_153 *jrt.String = jrt.Intern("cp")

var Lit_154 *jrt.String = jrt.Intern("tag")

var Lit_155 *jrt.String = jrt.Intern("long")

var Lit_156 *jrt.String = jrt.Intern("Go's strconv.IsPrint, for code points: letters, marks, numbers, punctuation, symbols and\n  the ASCII space.")

var Lit_157 *jrt.String = jrt.Intern("n")

var Lit_158 *jrt.String = jrt.Intern("quote")

var Lit_159 *jrt.String = jrt.Intern("The spelling of one code point inside a Go literal quoted by quote (\\\" or \\').")

var Lit_160 *jrt.String = jrt.Intern("s")

var Lit_161 *jrt.String = jrt.Intern("String")

var Lit_162 *jrt.String = jrt.Intern("The code points of a Clojure string; throws on an unpaired surrogate, which a Go string\n  in the forms must not contain (§8.1).")

var Lit_163 *jrt.String = jrt.Intern("go-string")

var Lit_164 *jrt.String = jrt.Intern("An interpreted Go string literal denoting the UTF-8 encoding of s.")

var Lit_165 *jrt.String = jrt.Intern("raw-string-ok?")

var Lit_166 *jrt.String = jrt.Intern("Whether s can be a raw string literal: no backquote or carriage return, and only printable\n  characters, tabs and newlines.")

var Lit_167 *jrt.String = jrt.Intern("go-byte-string")

var Lit_168 *jrt.String = jrt.Intern("parts")

var Lit_169 *jrt.String = jrt.Intern("(byte-string part ...): an interpreted string of the parts, strings as their UTF-8 and\n  integers 0-255 as \\x escapes.")

var Lit_170 *jrt.String = jrt.Intern("go-rune")

var Lit_171 *jrt.String = jrt.Intern("A Go rune literal for code point cp.")

var Lit_172 *jrt.String = jrt.Intern("s with a decimal point when it has neither a point nor an exponent, so that it stays a\n  float literal.")

var Lit_173 *jrt.String = jrt.Intern("BigInteger")

var Lit_174 *jrt.String = jrt.Intern("k when n is 2^k, else nil.")

var Lit_175 *jrt.String = jrt.Intern("[rest a b]: n = rest * 2^a * 5^b with rest not divisible by 2 or 5.")

var Lit_176 *jrt.String = jrt.Intern("x")

var Lit_177 *jrt.String = jrt.Intern("The Go float literal of a non-negative float value of the forms (§8.1, §12.2): a double as\n  the exact decimal of its shortest representation, a BigDecimal as its decimal, a ratio as a\n  short decimal or a hex float.")

var Lit_178 *jrt.String = jrt.Intern("negative-number?")

var Lit_179 *jrt.String = jrt.Intern("Whether a numeric literal of the forms is negative (Go: a unary minus on the literal; -0.0\n  counts, as the reader keeps its sign).")

var Lit_180 *jrt.String = jrt.Intern("go-number")

var Lit_181 *jrt.String = jrt.Intern("The Go literal of a non-negative number of the forms: integers in decimal, floats by\n  go-float.")

var Lit_182 *jrt.String = jrt.Intern("escape")

var Lit_183 *jrt.String = jrt.Intern("java.lang.String")

var Lit_184 *jrt.String = jrt.Intern("s with its tabs, newlines, vertical tabs and form feeds replaced by private characters\n  (U+E000 to U+E003), so that alignment treats it as one piece of text.")

var Lit_185 *jrt.String = jrt.Intern("The text escape replaced restored.")

var Lit_186 *jrt.String = jrt.Intern("")

var Lit_187 *jrt.String = jrt.Intern("The lines of one block of text (no form feeds): each a vector of cells\n  {:text :width :htab}, the last cell being the text after the last separator.")

var Lit_188 *jrt.String = jrt.Intern("sb")

var Lit_189 *jrt.String = jrt.Intern("StringBuilder")

var Lit_190 *jrt.String = jrt.Intern("textw")

var Lit_191 *jrt.String = jrt.Intern("cellw")

var Lit_192 *jrt.String = jrt.Intern("use-tabs")

var Lit_193 *jrt.String = jrt.Intern("lines")

var Lit_194 *jrt.String = jrt.Intern("widths")

var Lit_195 *jrt.String = jrt.Intern("line0")

var Lit_196 *jrt.String = jrt.Intern("line1")

var Lit_197 *jrt.String = jrt.Intern("tabwriter's Writer.format over lines [line0, line1) with the column widths found so far.")

var Lit_198 *jrt.String = jrt.Intern("block")

var Lit_199 *jrt.String = jrt.Intern("One block of text (no form feeds) aligned.")

var Lit_200 *jrt.String = jrt.Intern("align")

var Lit_201 *jrt.String = jrt.Intern("Aligns text as gofmt's tabwriter does and restores escaped text. Form feeds end the\n  alignment sections, so a long text's blocks are aligned in parallel, in groups.")
