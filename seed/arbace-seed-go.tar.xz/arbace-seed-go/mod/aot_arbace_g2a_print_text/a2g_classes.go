//line a2g_classes.ae:1
package aot_arbace_g2a_print_text

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_print_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_A_New()}; return nil }

var A_arbace_g2a_print_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_text_A_new}

var A_arbace_g2a_print_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_A"})

func init() { i := A_arbace_g2a_print_text_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_A_InstanceOf; i.Init = A_arbace_g2a_print_text_A_Init; i.Table = A_arbace_g2a_print_text_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_A_class, reflect.TypeFor[A_arbace_g2a_print_text_A]()) }

func A_arbace_g2a_print_text_align_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_align_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_align_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_align_A_New()}; return nil }

func A_arbace_g2a_print_text_align_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_align_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_align_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_align_A_invoke, New: A_arbace_g2a_print_text_align_A_new, Get: A_arbace_g2a_print_text_align_A_get}

var A_arbace_g2a_print_text_align_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$align", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "align", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_align_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_align_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_align_A_InstanceOf; i.Init = A_arbace_g2a_print_text_align_A_Init; i.Table = A_arbace_g2a_print_text_align_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_align_A_class, reflect.TypeFor[A_arbace_g2a_print_text_align_A]()) }

func A_arbace_g2a_print_text_align_fn__190000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_align_fn__190000080_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_align_fn__190000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_align_fn__190000080_A_New()}; return nil }

func A_arbace_g2a_print_text_align_fn__190000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_align_fn__190000080_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_align_fn__190000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_align_fn__190000080_A_invoke, New: A_arbace_g2a_print_text_align_fn__190000080_A_new, Get: A_arbace_g2a_print_text_align_fn__190000080_A_get}

var A_arbace_g2a_print_text_align_fn__190000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$align$fn__190000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_align_A_class, Simple: "fn__190000080", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_align_fn__190000080_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_align_fn__190000080_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_align_fn__190000080_A_InstanceOf; i.Init = A_arbace_g2a_print_text_align_fn__190000080_A_Init; i.Table = A_arbace_g2a_print_text_align_fn__190000080_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_align_fn__190000080_A_class, reflect.TypeFor[A_arbace_g2a_print_text_align_fn__190000080_A]()) }

func A_arbace_g2a_print_text_align_block_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_align_block_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_align_block_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_align_block_A_New()}; return nil }

func A_arbace_g2a_print_text_align_block_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_align_block_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_align_block_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_align_block_A_invoke, New: A_arbace_g2a_print_text_align_block_A_new, Get: A_arbace_g2a_print_text_align_block_A_get}

var A_arbace_g2a_print_text_align_block_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$align_block", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "align_block", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_align_block_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_align_block_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_align_block_A_InstanceOf; i.Init = A_arbace_g2a_print_text_align_block_A_Init; i.Table = A_arbace_g2a_print_text_align_block_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_align_block_A_class, reflect.TypeFor[A_arbace_g2a_print_text_align_block_A]()) }

func A_arbace_g2a_print_text_cell_width_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_cell_width_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_cell_width_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_cell_width_A_New()}; return nil }

func A_arbace_g2a_print_text_cell_width_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_cell_width_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_cell_width_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_cell_width_A_invoke, New: A_arbace_g2a_print_text_cell_width_A_new, Get: A_arbace_g2a_print_text_cell_width_A_get}

var A_arbace_g2a_print_text_cell_width_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$cell_width", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "cell_width", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_cell_width_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_cell_width_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_cell_width_A_InstanceOf; i.Init = A_arbace_g2a_print_text_cell_width_A_Init; i.Table = A_arbace_g2a_print_text_cell_width_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_cell_width_A_class, reflect.TypeFor[A_arbace_g2a_print_text_cell_width_A]()) }

func A_arbace_g2a_print_text_code_points_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_code_points_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_code_points_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_code_points_A_New()}; return nil }

func A_arbace_g2a_print_text_code_points_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_code_points_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_code_points_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_code_points_A_invoke, New: A_arbace_g2a_print_text_code_points_A_new, Get: A_arbace_g2a_print_text_code_points_A_get}

var A_arbace_g2a_print_text_code_points_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$code_points", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "code_points", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_code_points_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_code_points_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_code_points_A_InstanceOf; i.Init = A_arbace_g2a_print_text_code_points_A_Init; i.Table = A_arbace_g2a_print_text_code_points_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_code_points_A_class, reflect.TypeFor[A_arbace_g2a_print_text_code_points_A]()) }

func A_arbace_g2a_print_text_escape_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_escape_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_escape_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_escape_A_New()}; return nil }

func A_arbace_g2a_print_text_escape_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_escape_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_escape_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_escape_A_invoke, New: A_arbace_g2a_print_text_escape_A_new, Get: A_arbace_g2a_print_text_escape_A_get}

var A_arbace_g2a_print_text_escape_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$escape", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "escape", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_escape_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_escape_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_escape_A_InstanceOf; i.Init = A_arbace_g2a_print_text_escape_A_Init; i.Table = A_arbace_g2a_print_text_escape_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_escape_A_class, reflect.TypeFor[A_arbace_g2a_print_text_escape_A]()) }

func A_arbace_g2a_print_text_escape_cp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_escape_cp_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_text_escape_cp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_escape_cp_A_New()}; return nil }

func A_arbace_g2a_print_text_escape_cp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_escape_cp_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_escape_cp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_escape_cp_A_invoke, New: A_arbace_g2a_print_text_escape_cp_A_new, Get: A_arbace_g2a_print_text_escape_cp_A_get}

var A_arbace_g2a_print_text_escape_cp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$escape_cp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "escape_cp", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_escape_cp_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_escape_cp_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_escape_cp_A_InstanceOf; i.Init = A_arbace_g2a_print_text_escape_cp_A_Init; i.Table = A_arbace_g2a_print_text_escape_cp_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_escape_cp_A_class, reflect.TypeFor[A_arbace_g2a_print_text_escape_cp_A]()) }

func A_arbace_g2a_print_text_eval190000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_eval190000004_A_New()}; return nil }

var A_arbace_g2a_print_text_eval190000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_text_eval190000004_A_new}

var A_arbace_g2a_print_text_eval190000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$eval190000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_text_A_class, Simple: "eval190000004", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_eval190000004_A"})

func init() { i := A_arbace_g2a_print_text_eval190000004_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_eval190000004_A_InstanceOf; i.Table = A_arbace_g2a_print_text_eval190000004_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_eval190000004_A_class, reflect.TypeFor[A_arbace_g2a_print_text_eval190000004_A]()) }

func A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_New()}; return nil }

func A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_invoke, New: A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_new, Get: A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_get}

var A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$eval190000004$loading__1927001464__auto____190000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_text_eval190000004_A_class, Simple: "loading__1927001464__auto____190000005", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_InstanceOf; i.Init = A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_Init; i.Table = A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_class, reflect.TypeFor[A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A]()) }

func A_arbace_g2a_print_text_eval190000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_eval190000008_A_New()}; return nil }

var A_arbace_g2a_print_text_eval190000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_text_eval190000008_A_new}

var A_arbace_g2a_print_text_eval190000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$eval190000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_text_A_class, Simple: "eval190000008", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_eval190000008_A"})

func init() { i := A_arbace_g2a_print_text_eval190000008_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_eval190000008_A_InstanceOf; i.Table = A_arbace_g2a_print_text_eval190000008_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_eval190000008_A_class, reflect.TypeFor[A_arbace_g2a_print_text_eval190000008_A]()) }

func A_arbace_g2a_print_text_eval190000008_fn__190000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_eval190000008_fn__190000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_text_eval190000008_fn__190000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_eval190000008_fn__190000009_A_New()}; return nil }

func A_arbace_g2a_print_text_eval190000008_fn__190000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_eval190000008_fn__190000009_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_eval190000008_fn__190000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_eval190000008_fn__190000009_A_invoke, New: A_arbace_g2a_print_text_eval190000008_fn__190000009_A_new, Get: A_arbace_g2a_print_text_eval190000008_fn__190000009_A_get}

var A_arbace_g2a_print_text_eval190000008_fn__190000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$eval190000008$fn__190000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_text_eval190000008_A_class, Simple: "fn__190000009", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_eval190000008_fn__190000009_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_eval190000008_fn__190000009_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_eval190000008_fn__190000009_A_InstanceOf; i.Init = A_arbace_g2a_print_text_eval190000008_fn__190000009_A_Init; i.Table = A_arbace_g2a_print_text_eval190000008_fn__190000009_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_eval190000008_fn__190000009_A_class, reflect.TypeFor[A_arbace_g2a_print_text_eval190000008_fn__190000009_A]()) }

func A_arbace_g2a_print_text_float_kind_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_float_kind_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_float_kind_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_float_kind_A_New()}; return nil }

func A_arbace_g2a_print_text_float_kind_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_float_kind_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_float_kind_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_float_kind_A_invoke, New: A_arbace_g2a_print_text_float_kind_A_new, Get: A_arbace_g2a_print_text_float_kind_A_get}

var A_arbace_g2a_print_text_float_kind_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$float_kind", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "float_kind", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_float_kind_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_float_kind_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_float_kind_A_InstanceOf; i.Init = A_arbace_g2a_print_text_float_kind_A_Init; i.Table = A_arbace_g2a_print_text_float_kind_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_float_kind_A_class, reflect.TypeFor[A_arbace_g2a_print_text_float_kind_A]()) }

func A_arbace_g2a_print_text_format_block_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_format_block_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_g2a_print_text_format_block_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_format_block_A_New()}; return nil }

func A_arbace_g2a_print_text_format_block_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_format_block_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_format_block_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_format_block_A_invoke, New: A_arbace_g2a_print_text_format_block_A_new, Get: A_arbace_g2a_print_text_format_block_A_get}

var A_arbace_g2a_print_text_format_block_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$format_block", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "format_block", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_format_block_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_format_block_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_format_block_A_InstanceOf; i.Init = A_arbace_g2a_print_text_format_block_A_Init; i.Table = A_arbace_g2a_print_text_format_block_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_format_block_A_class, reflect.TypeFor[A_arbace_g2a_print_text_format_block_A]()) }

func A_arbace_g2a_print_text_format_block_fn__190000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_format_block_fn__190000075_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_text_format_block_fn__190000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_format_block_fn__190000075_A_New_I_O_O_O(args[0].(int32), args[1], args[2], args[3])}; return nil }

func A_arbace_g2a_print_text_format_block_fn__190000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_format_block_fn__190000075_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_format_block_fn__190000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_format_block_fn__190000075_A_invoke, New: A_arbace_g2a_print_text_format_block_fn__190000075_A_new, Get: A_arbace_g2a_print_text_format_block_fn__190000075_A_get}

var A_arbace_g2a_print_text_format_block_fn__190000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$format_block$fn__190000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_text_format_block_A_class, Simple: "fn__190000075", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_format_block_fn__190000075_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_format_block_fn__190000075_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_format_block_fn__190000075_A_InstanceOf; i.Init = A_arbace_g2a_print_text_format_block_fn__190000075_A_Init; i.Table = A_arbace_g2a_print_text_format_block_fn__190000075_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_format_block_fn__190000075_A_class, reflect.TypeFor[A_arbace_g2a_print_text_format_block_fn__190000075_A]()) }

func A_arbace_g2a_print_text_go_byte_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_go_byte_string_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_go_byte_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_go_byte_string_A_New()}; return nil }

func A_arbace_g2a_print_text_go_byte_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_go_byte_string_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_go_byte_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_go_byte_string_A_invoke, New: A_arbace_g2a_print_text_go_byte_string_A_new, Get: A_arbace_g2a_print_text_go_byte_string_A_get}

var A_arbace_g2a_print_text_go_byte_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$go_byte_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "go_byte_string", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_byte_string_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_go_byte_string_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_go_byte_string_A_InstanceOf; i.Init = A_arbace_g2a_print_text_go_byte_string_A_Init; i.Table = A_arbace_g2a_print_text_go_byte_string_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_go_byte_string_A_class, reflect.TypeFor[A_arbace_g2a_print_text_go_byte_string_A]()) }

func A_arbace_g2a_print_text_go_float_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_go_float_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_go_float_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_go_float_A_New()}; return nil }

func A_arbace_g2a_print_text_go_float_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_go_float_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_go_float_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_go_float_A_invoke, New: A_arbace_g2a_print_text_go_float_A_new, Get: A_arbace_g2a_print_text_go_float_A_get}

var A_arbace_g2a_print_text_go_float_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$go_float", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "go_float", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_float_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_go_float_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_go_float_A_InstanceOf; i.Init = A_arbace_g2a_print_text_go_float_A_Init; i.Table = A_arbace_g2a_print_text_go_float_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_go_float_A_class, reflect.TypeFor[A_arbace_g2a_print_text_go_float_A]()) }

func A_arbace_g2a_print_text_go_number_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_go_number_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_go_number_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_go_number_A_New()}; return nil }

func A_arbace_g2a_print_text_go_number_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_go_number_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_go_number_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_go_number_A_invoke, New: A_arbace_g2a_print_text_go_number_A_new, Get: A_arbace_g2a_print_text_go_number_A_get}

var A_arbace_g2a_print_text_go_number_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$go_number", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "go_number", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_number_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_go_number_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_go_number_A_InstanceOf; i.Init = A_arbace_g2a_print_text_go_number_A_Init; i.Table = A_arbace_g2a_print_text_go_number_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_go_number_A_class, reflect.TypeFor[A_arbace_g2a_print_text_go_number_A]()) }

func A_arbace_g2a_print_text_go_printable_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_go_printable_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_go_printable_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_go_printable_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_text_go_printable_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_go_printable_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_text_go_printable_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_go_printable_QMARK__A_invoke, New: A_arbace_g2a_print_text_go_printable_QMARK__A_new, Get: A_arbace_g2a_print_text_go_printable_QMARK__A_get}

var A_arbace_g2a_print_text_go_printable_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$go_printable_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "go_printable_QMARK_", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_printable_QMARK__A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_go_printable_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_go_printable_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_text_go_printable_QMARK__A_Init; i.Table = A_arbace_g2a_print_text_go_printable_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_go_printable_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_text_go_printable_QMARK__A]()) }

func A_arbace_g2a_print_text_go_rune_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_go_rune_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_go_rune_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_go_rune_A_New()}; return nil }

func A_arbace_g2a_print_text_go_rune_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_go_rune_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_go_rune_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_go_rune_A_invoke, New: A_arbace_g2a_print_text_go_rune_A_new, Get: A_arbace_g2a_print_text_go_rune_A_get}

var A_arbace_g2a_print_text_go_rune_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$go_rune", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "go_rune", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_rune_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_go_rune_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_go_rune_A_InstanceOf; i.Init = A_arbace_g2a_print_text_go_rune_A_Init; i.Table = A_arbace_g2a_print_text_go_rune_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_go_rune_A_class, reflect.TypeFor[A_arbace_g2a_print_text_go_rune_A]()) }

func A_arbace_g2a_print_text_go_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_go_string_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_go_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_go_string_A_New()}; return nil }

func A_arbace_g2a_print_text_go_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_go_string_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_go_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_go_string_A_invoke, New: A_arbace_g2a_print_text_go_string_A_new, Get: A_arbace_g2a_print_text_go_string_A_get}

var A_arbace_g2a_print_text_go_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$go_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "go_string", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_string_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_go_string_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_go_string_A_InstanceOf; i.Init = A_arbace_g2a_print_text_go_string_A_Init; i.Table = A_arbace_g2a_print_text_go_string_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_go_string_A_class, reflect.TypeFor[A_arbace_g2a_print_text_go_string_A]()) }

func A_arbace_g2a_print_text_hex_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_hex_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_print_text_hex_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_hex_A_New()}; return nil }

func A_arbace_g2a_print_text_hex_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_hex_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_hex_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_hex_A_invoke, New: A_arbace_g2a_print_text_hex_A_new, Get: A_arbace_g2a_print_text_hex_A_get}

var A_arbace_g2a_print_text_hex_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$hex", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "hex", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_hex_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_hex_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_hex_A_InstanceOf; i.Init = A_arbace_g2a_print_text_hex_A_Init; i.Table = A_arbace_g2a_print_text_hex_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_hex_A_class, reflect.TypeFor[A_arbace_g2a_print_text_hex_A]()) }

func A_arbace_g2a_print_text_negative_number_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_negative_number_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_negative_number_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_negative_number_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_text_negative_number_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_negative_number_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_text_negative_number_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_negative_number_QMARK__A_invoke, New: A_arbace_g2a_print_text_negative_number_QMARK__A_new, Get: A_arbace_g2a_print_text_negative_number_QMARK__A_get}

var A_arbace_g2a_print_text_negative_number_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$negative_number_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "negative_number_QMARK_", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_negative_number_QMARK__A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_negative_number_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_negative_number_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_text_negative_number_QMARK__A_Init; i.Table = A_arbace_g2a_print_text_negative_number_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_negative_number_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_text_negative_number_QMARK__A]()) }

func A_arbace_g2a_print_text_parse_lines_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_parse_lines_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_parse_lines_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_parse_lines_A_New()}; return nil }

func A_arbace_g2a_print_text_parse_lines_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_parse_lines_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_parse_lines_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_parse_lines_A_invoke, New: A_arbace_g2a_print_text_parse_lines_A_new, Get: A_arbace_g2a_print_text_parse_lines_A_get}

var A_arbace_g2a_print_text_parse_lines_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$parse_lines", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "parse_lines", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_parse_lines_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_parse_lines_A_InstanceOf; i.Init = A_arbace_g2a_print_text_parse_lines_A_Init; i.Table = A_arbace_g2a_print_text_parse_lines_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_parse_lines_A_class, reflect.TypeFor[A_arbace_g2a_print_text_parse_lines_A]()) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_New()}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_invoke, New: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_new, Get: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_get}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_parse_lines_A_class, Simple: "iter__190000051__190000055", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_InstanceOf; i.Init = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_Init; i.Table = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_class, reflect.TypeFor[A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A]()) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_invoke, New: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_new, Get: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_get}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_class, Simple: "fn__190000056", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_InstanceOf; i.Init = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_Init; i.Table = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class, reflect.TypeFor[A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A]()) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_invoke, New: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_new, Get: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_get}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class, Simple: "fn__190000057", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_InstanceOf; i.Init = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_Init; i.Table = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_class, reflect.TypeFor[A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A]()) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_New_I_O(args[0].(int32), args[1])}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_invoke, New: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_new, Get: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_get}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000057$fn__190000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_class, Simple: "fn__190000058", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_InstanceOf; i.Init = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_Init; i.Table = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_class, reflect.TypeFor[A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A]()) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_New_I_O(args[0].(int32), args[1])}; return nil }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_invoke, New: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_new, Get: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_get}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class, Simple: "fn__190000061", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_InstanceOf; i.Init = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_Init; i.Table = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_class, reflect.TypeFor[A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A]()) }

func A_arbace_g2a_print_text_pow2_exponent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_pow2_exponent_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_pow2_exponent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_pow2_exponent_A_New()}; return nil }

func A_arbace_g2a_print_text_pow2_exponent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_pow2_exponent_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_pow2_exponent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_pow2_exponent_A_invoke, New: A_arbace_g2a_print_text_pow2_exponent_A_new, Get: A_arbace_g2a_print_text_pow2_exponent_A_get}

var A_arbace_g2a_print_text_pow2_exponent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$pow2_exponent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "pow2_exponent", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_pow2_exponent_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_pow2_exponent_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_pow2_exponent_A_InstanceOf; i.Init = A_arbace_g2a_print_text_pow2_exponent_A_Init; i.Table = A_arbace_g2a_print_text_pow2_exponent_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_pow2_exponent_A_class, reflect.TypeFor[A_arbace_g2a_print_text_pow2_exponent_A]()) }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_raw_string_ok_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_raw_string_ok_QMARK__A_New()}; return nil }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_raw_string_ok_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_print_text_raw_string_ok_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_raw_string_ok_QMARK__A_invoke, New: A_arbace_g2a_print_text_raw_string_ok_QMARK__A_new, Get: A_arbace_g2a_print_text_raw_string_ok_QMARK__A_get}

var A_arbace_g2a_print_text_raw_string_ok_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$raw_string_ok_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "raw_string_ok_QMARK_", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_raw_string_ok_QMARK__A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_raw_string_ok_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_raw_string_ok_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_print_text_raw_string_ok_QMARK__A_Init; i.Table = A_arbace_g2a_print_text_raw_string_ok_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_raw_string_ok_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_print_text_raw_string_ok_QMARK__A]()) }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_New()}; return nil }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_invoke, New: A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_new, Get: A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_get}

var A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$raw_string_ok_QMARK_$fn__190000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_raw_string_ok_QMARK__A_class, Simple: "fn__190000022", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_InstanceOf; i.Init = A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_Init; i.Table = A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_class, reflect.TypeFor[A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A]()) }

func A_arbace_g2a_print_text_strip_2_5_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_strip_2_5_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_strip_2_5_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_strip_2_5_A_New()}; return nil }

func A_arbace_g2a_print_text_strip_2_5_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_strip_2_5_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_strip_2_5_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_strip_2_5_A_invoke, New: A_arbace_g2a_print_text_strip_2_5_A_new, Get: A_arbace_g2a_print_text_strip_2_5_A_get}

var A_arbace_g2a_print_text_strip_2_5_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$strip_2_5", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "strip_2_5", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_strip_2_5_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_strip_2_5_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_strip_2_5_A_InstanceOf; i.Init = A_arbace_g2a_print_text_strip_2_5_A_Init; i.Table = A_arbace_g2a_print_text_strip_2_5_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_strip_2_5_A_class, reflect.TypeFor[A_arbace_g2a_print_text_strip_2_5_A]()) }

func A_arbace_g2a_print_text_unescape_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_unescape_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_print_text_unescape_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_unescape_A_New()}; return nil }

func A_arbace_g2a_print_text_unescape_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_unescape_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_unescape_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_unescape_A_invoke, New: A_arbace_g2a_print_text_unescape_A_new, Get: A_arbace_g2a_print_text_unescape_A_get}

var A_arbace_g2a_print_text_unescape_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$unescape", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "unescape", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_unescape_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_unescape_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_unescape_A_InstanceOf; i.Init = A_arbace_g2a_print_text_unescape_A_Init; i.Table = A_arbace_g2a_print_text_unescape_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_unescape_A_class, reflect.TypeFor[A_arbace_g2a_print_text_unescape_A]()) }

func A_arbace_g2a_print_text_write_lines_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_write_lines_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_g2a_print_text_write_lines_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_write_lines_A_New()}; return nil }

func A_arbace_g2a_print_text_write_lines_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_write_lines_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_write_lines_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_write_lines_A_invoke, New: A_arbace_g2a_print_text_write_lines_A_new, Get: A_arbace_g2a_print_text_write_lines_A_get}

var A_arbace_g2a_print_text_write_lines_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$write_lines", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "write_lines", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_write_lines_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_write_lines_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_write_lines_A_InstanceOf; i.Init = A_arbace_g2a_print_text_write_lines_A_Init; i.Table = A_arbace_g2a_print_text_write_lines_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_write_lines_A_class, reflect.TypeFor[A_arbace_g2a_print_text_write_lines_A]()) }

func A_arbace_g2a_print_text_write_padding_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_print_text_write_padding_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_g2a_print_text_write_padding_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_write_padding_A_New()}; return nil }

func A_arbace_g2a_print_text_write_padding_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_print_text_write_padding_A_fn_class)}; return nil }

var A_arbace_g2a_print_text_write_padding_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_print_text_write_padding_A_invoke, New: A_arbace_g2a_print_text_write_padding_A_new, Get: A_arbace_g2a_print_text_write_padding_A_get}

var A_arbace_g2a_print_text_write_padding_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$write_padding", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_g2a_print_text_A_class, Simple: "write_padding", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_write_padding_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text_write_padding_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_write_padding_A_InstanceOf; i.Init = A_arbace_g2a_print_text_write_padding_A_Init; i.Table = A_arbace_g2a_print_text_write_padding_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text_write_padding_A_class, reflect.TypeFor[A_arbace_g2a_print_text_write_padding_A]()) }

func A_arbace_g2a_print_text__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_print_text__init_A_Load__O(); case 1: return A_arbace_g2a_print_text__init_A_Unit0__O(); case 2: return A_arbace_g2a_print_text__init_A_Unit1__O(); case 3: return A_arbace_g2a_print_text__init_A_Unit10__O(); case 4: return A_arbace_g2a_print_text__init_A_Unit11__O(); case 5: return A_arbace_g2a_print_text__init_A_Unit12__O(); case 6: return A_arbace_g2a_print_text__init_A_Unit13__O(); case 7: return A_arbace_g2a_print_text__init_A_Unit14__O(); case 8: return A_arbace_g2a_print_text__init_A_Unit15__O(); case 9: return A_arbace_g2a_print_text__init_A_Unit16__O(); case 10: return A_arbace_g2a_print_text__init_A_Unit17__O(); case 11: return A_arbace_g2a_print_text__init_A_Unit18__O(); case 12: return A_arbace_g2a_print_text__init_A_Unit19__O(); case 13: return A_arbace_g2a_print_text__init_A_Unit2__O(); case 14: return A_arbace_g2a_print_text__init_A_Unit20__O(); case 15: return A_arbace_g2a_print_text__init_A_Unit21__O(); case 16: return A_arbace_g2a_print_text__init_A_Unit22__O(); case 17: return A_arbace_g2a_print_text__init_A_Unit23__O(); case 18: return A_arbace_g2a_print_text__init_A_Unit24__O(); case 19: return A_arbace_g2a_print_text__init_A_Unit25__O(); case 20: return A_arbace_g2a_print_text__init_A_Unit26__O(); case 21: return A_arbace_g2a_print_text__init_A_Unit27__O(); case 22: return A_arbace_g2a_print_text__init_A_Unit28__O(); case 23: return A_arbace_g2a_print_text__init_A_Unit3__O(); case 24: return A_arbace_g2a_print_text__init_A_Unit4__O(); case 25: return A_arbace_g2a_print_text__init_A_Unit5__O(); case 26: return A_arbace_g2a_print_text__init_A_Unit6__O(); case 27: return A_arbace_g2a_print_text__init_A_Unit7__O(); case 28: return A_arbace_g2a_print_text__init_A_Unit8__O(); case 29: return A_arbace_g2a_print_text__init_A_Unit9__O()}; return nil }

func A_arbace_g2a_print_text__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text__init_A_New()}; return nil }

var A_arbace_g2a_print_text__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_print_text__init_A_invoke, New: A_arbace_g2a_print_text__init_A_new}

var A_arbace_g2a_print_text__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text__init_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text__init_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text__init_A_InstanceOf; i.Init = A_arbace_g2a_print_text__init_A_Init; i.Table = A_arbace_g2a_print_text__init_A_members; jrt.RegisterGoType(A_arbace_g2a_print_text__init_A_class, reflect.TypeFor[A_arbace_g2a_print_text__init_A]()) }
