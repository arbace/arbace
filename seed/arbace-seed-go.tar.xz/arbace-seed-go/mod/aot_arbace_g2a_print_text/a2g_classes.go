//line a2g_classes.ae:1
package aot_arbace_g2a_print_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_g2a_print_text_align_A_class, Name: "arbace.g2a.print_text$align", Modifiers: 25, Simple: "align", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_align_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_align_fn__190000080_A_class, Name: "arbace.g2a.print_text$align$fn__190000080", Modifiers: 25, Simple: "fn__190000080", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_align_fn__190000080_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_align_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_align_block_A_class, Name: "arbace.g2a.print_text$align_block", Modifiers: 25, Simple: "align_block", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_align_block_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_cell_width_A_class, Name: "arbace.g2a.print_text$cell_width", Modifiers: 25, Simple: "cell_width", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_cell_width_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_code_points_A_class, Name: "arbace.g2a.print_text$code_points", Modifiers: 25, Simple: "code_points", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_code_points_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_escape_A_class, Name: "arbace.g2a.print_text$escape", Modifiers: 25, Simple: "escape", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_escape_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_escape_cp_A_class, Name: "arbace.g2a.print_text$escape_cp", Modifiers: 25, Simple: "escape_cp", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_escape_cp_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_class, Name: "arbace.g2a.print_text$eval190000004$loading__1927001464__auto____190000005", Modifiers: 25, Simple: "loading__1927001464__auto____190000005", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_eval190000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_eval190000008_fn__190000009_A_class, Name: "arbace.g2a.print_text$eval190000008$fn__190000009", Modifiers: 25, Simple: "fn__190000009", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_eval190000008_fn__190000009_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_eval190000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_float_kind_A_class, Name: "arbace.g2a.print_text$float_kind", Modifiers: 25, Simple: "float_kind", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_float_kind_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_format_block_A_class, Name: "arbace.g2a.print_text$format_block", Modifiers: 25, Simple: "format_block", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_format_block_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_format_block_fn__190000075_A_class, Name: "arbace.g2a.print_text$format_block$fn__190000075", Modifiers: 25, Simple: "fn__190000075", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_format_block_fn__190000075_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_format_block_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_go_byte_string_A_class, Name: "arbace.g2a.print_text$go_byte_string", Modifiers: 25, Simple: "go_byte_string", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_byte_string_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_go_float_A_class, Name: "arbace.g2a.print_text$go_float", Modifiers: 25, Simple: "go_float", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_float_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_go_number_A_class, Name: "arbace.g2a.print_text$go_number", Modifiers: 25, Simple: "go_number", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_number_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_go_printable_QMARK__A_class, Name: "arbace.g2a.print_text$go_printable_QMARK_", Modifiers: 25, Simple: "go_printable_QMARK_", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_printable_QMARK__A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_go_rune_A_class, Name: "arbace.g2a.print_text$go_rune", Modifiers: 25, Simple: "go_rune", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_rune_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_go_string_A_class, Name: "arbace.g2a.print_text$go_string", Modifiers: 25, Simple: "go_string", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_go_string_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_hex_A_class, Name: "arbace.g2a.print_text$hex", Modifiers: 25, Simple: "hex", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_hex_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_negative_number_QMARK__A_class, Name: "arbace.g2a.print_text$negative_number_QMARK_", Modifiers: 25, Simple: "negative_number_QMARK_", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_negative_number_QMARK__A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_parse_lines_A_class, Name: "arbace.g2a.print_text$parse_lines", Modifiers: 25, Simple: "parse_lines", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_class, Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055", Modifiers: 25, Simple: "iter__190000051__190000055", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_parse_lines_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class, Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056", Modifiers: 25, Simple: "fn__190000056", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_class, Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000057", Modifiers: 25, Simple: "fn__190000057", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_class, Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000057$fn__190000058", Modifiers: 25, Simple: "fn__190000058", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_class, Name: "arbace.g2a.print_text$parse_lines$iter__190000051__190000055$fn__190000056$fn__190000061", Modifiers: 25, Simple: "fn__190000061", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_pow2_exponent_A_class, Name: "arbace.g2a.print_text$pow2_exponent", Modifiers: 25, Simple: "pow2_exponent", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_pow2_exponent_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_raw_string_ok_QMARK__A_class, Name: "arbace.g2a.print_text$raw_string_ok_QMARK_", Modifiers: 25, Simple: "raw_string_ok_QMARK_", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_raw_string_ok_QMARK__A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_class, Name: "arbace.g2a.print_text$raw_string_ok_QMARK_$fn__190000022", Modifiers: 25, Simple: "fn__190000022", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_raw_string_ok_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_strip_2_5_A_class, Name: "arbace.g2a.print_text$strip_2_5", Modifiers: 25, Simple: "strip_2_5", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_strip_2_5_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_unescape_A_class, Name: "arbace.g2a.print_text$unescape", Modifiers: 25, Simple: "unescape", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_unescape_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_write_lines_A_class, Name: "arbace.g2a.print_text$write_lines", Modifiers: 25, Simple: "write_lines", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_write_lines_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_g2a_print_text_write_padding_A_class, Name: "arbace.g2a.print_text$write_padding", Modifiers: 25, Simple: "write_padding", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_write_padding_A", Source: "print_text.ae", Declaring: &A_arbace_g2a_print_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_g2a_print_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_A_New()}; return nil }

var A_arbace_g2a_print_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_text_A_new}

var A_arbace_g2a_print_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_A"})

func init() { i := A_arbace_g2a_print_text_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_A_InstanceOf; i.Init = A_arbace_g2a_print_text_A_Init; i.Table = A_arbace_g2a_print_text_A_members }

var A_arbace_g2a_print_text_align_A_class *jrt.Class

var A_arbace_g2a_print_text_align_fn__190000080_A_class *jrt.Class

var A_arbace_g2a_print_text_align_block_A_class *jrt.Class

var A_arbace_g2a_print_text_cell_width_A_class *jrt.Class

var A_arbace_g2a_print_text_code_points_A_class *jrt.Class

var A_arbace_g2a_print_text_escape_A_class *jrt.Class

var A_arbace_g2a_print_text_escape_cp_A_class *jrt.Class

func A_arbace_g2a_print_text_eval190000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_eval190000004_A_New()}; return nil }

var A_arbace_g2a_print_text_eval190000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_text_eval190000004_A_new}

var A_arbace_g2a_print_text_eval190000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$eval190000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_text_A_class, Simple: "eval190000004", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_eval190000004_A"})

func init() { i := A_arbace_g2a_print_text_eval190000004_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_eval190000004_A_InstanceOf; i.Table = A_arbace_g2a_print_text_eval190000004_A_members }

var A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_class *jrt.Class

func A_arbace_g2a_print_text_eval190000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text_eval190000008_A_New()}; return nil }

var A_arbace_g2a_print_text_eval190000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_print_text_eval190000008_A_new}

var A_arbace_g2a_print_text_eval190000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text$eval190000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_print_text_A_class, Simple: "eval190000008", Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text_eval190000008_A"})

func init() { i := A_arbace_g2a_print_text_eval190000008_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text_eval190000008_A_InstanceOf; i.Table = A_arbace_g2a_print_text_eval190000008_A_members }

var A_arbace_g2a_print_text_eval190000008_fn__190000009_A_class *jrt.Class

var A_arbace_g2a_print_text_float_kind_A_class *jrt.Class

var A_arbace_g2a_print_text_format_block_A_class *jrt.Class

var A_arbace_g2a_print_text_format_block_fn__190000075_A_class *jrt.Class

var A_arbace_g2a_print_text_go_byte_string_A_class *jrt.Class

var A_arbace_g2a_print_text_go_float_A_class *jrt.Class

var A_arbace_g2a_print_text_go_number_A_class *jrt.Class

var A_arbace_g2a_print_text_go_printable_QMARK__A_class *jrt.Class

var A_arbace_g2a_print_text_go_rune_A_class *jrt.Class

var A_arbace_g2a_print_text_go_string_A_class *jrt.Class

var A_arbace_g2a_print_text_hex_A_class *jrt.Class

var A_arbace_g2a_print_text_negative_number_QMARK__A_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_A_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_class *jrt.Class

var A_arbace_g2a_print_text_pow2_exponent_A_class *jrt.Class

var A_arbace_g2a_print_text_raw_string_ok_QMARK__A_class *jrt.Class

var A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_class *jrt.Class

var A_arbace_g2a_print_text_strip_2_5_A_class *jrt.Class

var A_arbace_g2a_print_text_unescape_A_class *jrt.Class

var A_arbace_g2a_print_text_write_lines_A_class *jrt.Class

var A_arbace_g2a_print_text_write_padding_A_class *jrt.Class

func A_arbace_g2a_print_text__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_print_text__init_A_Load__O()}; return nil }

func A_arbace_g2a_print_text__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_print_text__init_A_New()}; return nil }

var A_arbace_g2a_print_text__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_print_text__init_A_invoke, New: A_arbace_g2a_print_text__init_A_new}

var A_arbace_g2a_print_text__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.print_text__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_print_text.A_arbace_g2a_print_text__init_A", Source: "print_text.ae"})

func init() { i := A_arbace_g2a_print_text__init_A_class.Info(); i.IsInstance = A_arbace_g2a_print_text__init_A_InstanceOf; i.Init = A_arbace_g2a_print_text__init_A_Init; i.Table = A_arbace_g2a_print_text__init_A_members }
