//line aot_arbace_g2a_print_text.ae:1
package aot_arbace_g2a_print_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_New() *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A { A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_Init(); t := &A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_3; tmp8.Invoke_O__O(tmp9); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_104)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_105)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp12 != nil { panic(tmp12) }; return tmp3 }
//line :1:1
func A_arbace_g2a_print_text_eval190000008_fn__190000009_A_New() *A_arbace_g2a_print_text_eval190000008_fn__190000009_A { A_arbace_g2a_print_text_eval190000008_fn__190000009_A_Init(); t := &A_arbace_g2a_print_text_eval190000008_fn__190000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp5 = A_arbace_g2a_print_text_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }
































func A_arbace_g2a_print_text_go_printable_QMARK__A_New() *A_arbace_g2a_print_text_go_printable_QMARK__A { A_arbace_g2a_print_text_go_printable_QMARK__A_Init(); t := &A_arbace_g2a_print_text_go_printable_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) Invoke_O_O__O(self, p_cp__0 any) any { var cp__0 int64 = lang.RT_LongCast_O__J(p_cp__0); var or__1927000174__auto____2 bool = lang.Numbers_Equiv_J_J__Z(cp__0, 32); if or__1927000174__auto____2 {



	return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var or__1927000174__auto____3 any; var tmp1 *lang.Var
		A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_11; var tmp4 any = tmp3; var tmp5 any = jrt.Long_ValueOf_J__Long(cp__0).Ref(); var tmp6 any; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_12; or__1927000174__auto____3 = tmp2.Invoke_O_O_O__O(tmp4, tmp5, tmp6)
//line :38:1
		if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {

			var tmp7 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_10; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_13; return tmp8.Invoke_O_O__O(jrt.NN(tmp9).GetRawRoot__O(), jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_I__I(jrt.Character_GetType_I__I(lang.RT_IntCast_J__I(cp__0)))).Ref()) } } }

func A_arbace_g2a_print_text_hex_A_New() *A_arbace_g2a_print_text_hex_A { A_arbace_g2a_print_text_hex_A_Init(); t := &A_arbace_g2a_print_text_hex_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_g2a_print_text_hex_A) Ctor() {}
//line :42:1
func (t *A_arbace_g2a_print_text_hex_A) Invoke_O_O_O__O(self, p_n__0, p_width__1 any) any { var n__0 int64 = lang.RT_LongCast_O__J(p_n__0); var width__1 int64 = lang.RT_LongCast_O__J(p_width__1); var s__3 any = jrt.Long_ToHexString_J__String(n__0).Ref(); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 *lang.Var;

	A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_14; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_15; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_16; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(width__1, int64(lang.RT_Count_O__I(s__3)))).Ref(); var tmp9 any; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_17; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(tmp8, tmp9)), s__3)).Ref() }

func A_arbace_g2a_print_text_escape_cp_A_New() *A_arbace_g2a_print_text_escape_cp_A { A_arbace_g2a_print_text_escape_cp_A_Init(); t := &A_arbace_g2a_print_text_escape_cp_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_g2a_print_text_escape_cp_A) Ctor() {}
//line :46:1
func (t *A_arbace_g2a_print_text_escape_cp_A) Invoke_O_O_O__O(self, p_cp__0, quote__1 any) any { var cp__0 int64 = lang.RT_LongCast_O__J(p_cp__0); var G__190000014__3_ int32 = lang.RT_IntCast_J__I(cp__0); switch G__190000014__3_ {


case 7: return Lit_93; case 8: return Lit_94; case 9: return Lit_95; case 10: return Lit_69; case 11: return Lit_96; case 12: return Lit_77; case 13: return Lit_97; case 92: return Lit_98; default:}; if

	lang.Numbers_Equiv_J_J__Z(cp__0, lang.RT_LongCast_I__J(lang.RT_IntCast_O__I(quote__1))) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, nil, quote__1)).Ref() } else {
//line :51:1
			var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_18; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(cp__0).Ref())) { return jrt.String_New_C1(jrt.Character_ToChars_I__C1(lang.RT_IntCast_J__I(cp__0))) } else { if lang.Numbers_Lt_J_J__Z(cp__0, 128) {


				var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_100, nil); var tmp3 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_19; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = jrt.Long_ValueOf_J__Long(cp__0).Ref(); var tmp6 any; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_21; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O_O__O(tmp5, tmp6))).Ref() } else {
//line :51:1
					if lang.Numbers_Lte_J_J__Z(cp__0, 65535) {



						var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_101, nil); var tmp8 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_19; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = jrt.Long_ValueOf_J__Long(cp__0).Ref(); var tmp11 any; A_arbace_g2a_print_text_A_Init(); tmp11 = A_arbace_g2a_print_text_A_const_22; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp9.Invoke_O_O__O(tmp10, tmp11))).Ref() } else {
//line :51:1
							var tmp12 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_20; if tmp12 != nil {




								var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_102, nil); var tmp14 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp14 = A_arbace_g2a_print_text_A_const_19; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any = jrt.Long_ValueOf_J__Long(cp__0).Ref(); var tmp17 any; A_arbace_g2a_print_text_A_Init(); tmp17 = A_arbace_g2a_print_text_A_const_23; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp15.Invoke_O_O__O(tmp16, tmp17))).Ref() } else {
//line :51:1
									return nil } } } } } }






func A_arbace_g2a_print_text_code_points_A_New() *A_arbace_g2a_print_text_code_points_A { A_arbace_g2a_print_text_code_points_A_Init(); t := &A_arbace_g2a_print_text_code_points_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_g2a_print_text_code_points_A) Ctor() {}
//line :58:1
func (t *A_arbace_g2a_print_text_code_points_A) Invoke_O_O__O(self, s__0 any) any { { var i__2 int64 = 0; var acc__3 any; var tmp1 *lang.Var



	A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_24; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; acc__3 = tmp2.Invoke_O__O(tmp3.Ref())
//line :58:1
L1: for {




	if lang.Numbers_Lt_J_J__Z(i__2, int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { var cp__4 int32 = jrt.NN(jrt.String_Cast(s__0)).CodePointAt_I__I(lang.RT_IntCast_J__I(i__2)); var tmp4 bool; var and__1927000168__auto____5 bool = lang.Numbers_Gte_J_J__Z(int64(cp__4), 55296)

		if and__1927000168__auto____5 { tmp4 = lang.Numbers_Lte_J_J__Z(int64(cp__4), 57343) } else { tmp4 = and__1927000168__auto____5 }; if tmp4 { var tmp5 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp5 = A_arbace_g2a_print_text_A_const_26; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_90, nil); var tmp8 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_27; var tmp9 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(s__0))).Ref(); var tmp10 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp10 = A_arbace_g2a_print_text_A_const_28; panic(jrt.Thrown(jrt.Throwable_Cast(tmp6.Invoke_O_O__O(tmp9, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10.Ref(), s__0))))))
		}
		var tmp11 int64 = lang.Numbers_Add_J_J__J(i__2, int64(jrt.Character_CharCount_I__I(cp__4))); var tmp12 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_29; i__2, acc__3 = tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(acc__3, jrt.Integer_ValueOf_I__Integer(cp__4).Ref()); continue L1 } else {
			var tmp13 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp13 = A_arbace_g2a_print_text_A_const_25; return lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(acc__3) } } }; /*line :58:1*/panic("a2g: unreachable") }











func A_arbace_g2a_print_text_go_string_A_New() *A_arbace_g2a_print_text_go_string_A { A_arbace_g2a_print_text_go_string_A_Init(); t := &A_arbace_g2a_print_text_go_string_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_g2a_print_text_go_string_A) Ctor() {}
//line :70:1
func (t *A_arbace_g2a_print_text_go_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_115); var seq_190000017__3 any; var tmp1 *lang.Var;



	A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_30; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_34; seq_190000017__3 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__0)); var chunk_190000018__4 any; var count_190000019__5 int64 = 0; var i_190000020__6 int64 = 0; L1:
//line :70:1
	for {



		if lang.Numbers_Lt_J_J__Z(i_190000020__6, count_190000019__5) { var cp__7 any = lang.Indexed_Cast(chunk_190000018__4).Nth_I__O(lang.RT_IntCast_J__I(i_190000020__6)); var tmp4 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp5 *lang.Var
			A_arbace_g2a_print_text_A_Init(); tmp5 = A_arbace_g2a_print_text_A_const_35; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_36; jrt.NN(tmp4).Append_String__StringBuilder(jrt.String_Cast(tmp6.Invoke_O_O__O(cp__7, tmp7)))
//line :74:1
			seq_190000017__3, chunk_190000018__4, count_190000019__5, i_190000020__6 = seq_190000017__3, chunk_190000018__4, count_190000019__5, lang.Numbers_Unchecked_inc_J__J(i_190000020__6); continue L1 } else { var temp__1927000414__auto____7 any; var tmp8 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_30; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_190000017__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_190000017__8 any = temp__1927000414__auto____7; var tmp9 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_190000017__8)) { var c__1927000678__auto____9 any; var tmp10 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp10 = A_arbace_g2a_print_text_A_const_32; c__1927000678__auto____9 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_190000017__8); var tmp11 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp11 = A_arbace_g2a_print_text_A_const_37; seq_190000017__3, chunk_190000018__4, count_190000019__5, i_190000020__6 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_190000017__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cp__9 any; var tmp12 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_33; cp__9 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_190000017__8)
				var tmp13 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp14 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp14 = A_arbace_g2a_print_text_A_const_35; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any; A_arbace_g2a_print_text_A_Init(); tmp16 = A_arbace_g2a_print_text_A_const_36; jrt.NN(tmp13).Append_String__StringBuilder(jrt.String_Cast(tmp15.Invoke_O_O__O(cp__9, tmp16)))
//line :74:1
				var tmp17 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp17 = A_arbace_g2a_print_text_A_const_38; seq_190000017__3, chunk_190000018__4, count_190000019__5, i_190000020__6 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq_190000017__8), nil, 0, 0; continue L1 } } }
//line :70:1
		break L1 };





	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_115); return /*line :77:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__A_New() *A_arbace_g2a_print_text_raw_string_ok_QMARK__A { A_arbace_g2a_print_text_raw_string_ok_QMARK__A_Init(); t := &A_arbace_g2a_print_text_raw_string_ok_QMARK__A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) Ctor() {}
//line :79:1
func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_39; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_New(); var tmp4 *jrt.Class; A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_Init(); tmp4 = A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_34; return tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(s__0)) }
//line :83:1
func A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_New() *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A { A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_Init(); t := &A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) Ctor() {}
//line :83:1
func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) Invoke_O_O__O(self, cp__1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_40; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_41; and__1927000168__auto____2 = tmp2.Invoke_O_O__O(cp__1, tmp3); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp4 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_40; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_42; and__1927000168__auto____3 = tmp5.Invoke_O_O__O(cp__1, tmp6); if jrt.A2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = lang.Numbers_Equiv_O_J__Z(cp__1, 9)
														if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = lang.Numbers_Equiv_O_J__Z(cp__1, 10); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var tmp7 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_18; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(cp__1) } } } else {
//line :83:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_g2a_print_text_go_byte_string_A_New() *A_arbace_g2a_print_text_go_byte_string_A { A_arbace_g2a_print_text_go_byte_string_A_Init(); t := &A_arbace_g2a_print_text_go_byte_string_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_g2a_print_text_go_byte_string_A) Ctor() {}
//line :87:1
func (t *A_arbace_g2a_print_text_go_byte_string_A) Invoke_O_O__O(self, parts__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_115); var seq_190000025__3 any; var tmp1 *lang.Var;




	A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_30; seq_190000025__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(parts__0); var chunk_190000026__4 any; var count_190000027__5 int64 = 0; var i_190000028__6 int64 = 0; L1:
//line :87:1
	for {




		if lang.Numbers_Lt_J_J__Z(i_190000028__6, count_190000027__5) { var p__7 any = lang.Indexed_Cast(chunk_190000026__4).Nth_I__O(lang.RT_IntCast_J__I(i_190000028__6)); var tmp2 *lang.Var
			A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_43; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(p__7)) { var seq_190000029__8 any; var tmp3 *lang.Var
				A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_30; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp5 = A_arbace_g2a_print_text_A_const_34; seq_190000029__8 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(p__7))
//line :93:1
				var chunk_190000030__9 any; var count_190000031__10 int64 = 0; var i_190000032__11 int64 = 0; L2: for {
					if lang.Numbers_Lt_J_J__Z(i_190000032__11, count_190000031__10) { var cp__12 any = lang.Indexed_Cast(chunk_190000030__9).Nth_I__O(lang.RT_IntCast_J__I(i_190000032__11)); var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp7 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_35; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_36; jrt.NN(tmp6).Append_String__StringBuilder(jrt.String_Cast(tmp8.Invoke_O_O__O(cp__12, tmp9))); seq_190000029__8, chunk_190000030__9, count_190000031__10, i_190000032__11 = seq_190000029__8, chunk_190000030__9, count_190000031__10, lang.Numbers_Unchecked_inc_J__J(i_190000032__11); continue L2 } else { var temp__1927000414__auto____12 any; var tmp10 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp10 = A_arbace_g2a_print_text_A_const_30; temp__1927000414__auto____12 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_190000029__8); if jrt.A2g_Truth(temp__1927000414__auto____12) { var seq_190000029__13 any = temp__1927000414__auto____12; var tmp11 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp11 = A_arbace_g2a_print_text_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_190000029__13)) { var c__1927000678__auto____14 any; var tmp12 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_32; c__1927000678__auto____14 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_190000029__13); var tmp13 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp13 = A_arbace_g2a_print_text_A_const_37; seq_190000029__8, chunk_190000030__9, count_190000031__10, i_190000032__11 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_190000029__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var cp__14 any; var tmp14 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp14 = A_arbace_g2a_print_text_A_const_33; cp__14 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_190000029__13); var tmp15 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp16 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp16 = A_arbace_g2a_print_text_A_const_35; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 any; A_arbace_g2a_print_text_A_Init(); tmp18 = A_arbace_g2a_print_text_A_const_36; jrt.NN(tmp15).Append_String__StringBuilder(jrt.String_Cast(tmp17.Invoke_O_O__O(cp__14, tmp18))); var tmp19 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp19 = A_arbace_g2a_print_text_A_const_38; seq_190000029__8, chunk_190000030__9, count_190000031__10, i_190000032__11 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_190000029__13), nil, 0, 0; continue L2 } } }
//line :93:1
					break L2 } } else { var tmp20 any; var and__1927000168__auto____8 any; var tmp21 *lang.Var

						A_arbace_g2a_print_text_A_Init(); tmp21 = A_arbace_g2a_print_text_A_const_44; and__1927000168__auto____8 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(p__7); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp22 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp22 = A_arbace_g2a_print_text_A_const_45; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 any; A_arbace_g2a_print_text_A_Init(); tmp24 = A_arbace_g2a_print_text_A_const_46; var tmp25 any = tmp24; var tmp26 any; A_arbace_g2a_print_text_A_Init(); tmp26 = A_arbace_g2a_print_text_A_const_47; tmp20 = tmp23.Invoke_O_O_O__O(tmp25, p__7, tmp26) } else { tmp20 = and__1927000168__auto____8 }
//line :93:1
						if jrt.A2g_Truth(tmp20) {

							var tmp27 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp28 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_100, nil); var tmp29 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp29 = A_arbace_g2a_print_text_A_const_19; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(p__7)).Ref(); var tmp32 any; A_arbace_g2a_print_text_A_Init(); tmp32 = A_arbace_g2a_print_text_A_const_21; jrt.NN(tmp27).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp28, jrt.RefArrayOf(jrt.Object_class, nil, tmp30.Invoke_O_O__O(tmp31, tmp32)))) } else {
//line :93:1
								var tmp33 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp33 = A_arbace_g2a_print_text_A_const_20; if tmp33 != nil { var tmp34 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp34 = A_arbace_g2a_print_text_A_const_26; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_116, nil); var tmp37 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp37 = A_arbace_g2a_print_text_A_const_27; var tmp38 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp36, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(p__7))).Ref(); var tmp39 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp39 = A_arbace_g2a_print_text_A_const_48; panic(jrt.Thrown(jrt.Throwable_Cast(tmp35.Invoke_O_O__O(tmp38, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp39.Ref(), p__7)))))) } } }
//line :92:1
			seq_190000025__3, chunk_190000026__4, count_190000027__5, i_190000028__6 = seq_190000025__3, chunk_190000026__4, count_190000027__5, lang.Numbers_Unchecked_inc_J__J(i_190000028__6); continue L1 } else { var temp__1927000414__auto____7 any; var tmp40 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp40 = A_arbace_g2a_print_text_A_const_30; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(seq_190000025__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_190000025__8 any = temp__1927000414__auto____7; var tmp41 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp41 = A_arbace_g2a_print_text_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(seq_190000025__8)) { var c__1927000678__auto____9 any; var tmp42 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp42 = A_arbace_g2a_print_text_A_const_32; c__1927000678__auto____9 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_190000025__8); var tmp43 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp43 = A_arbace_g2a_print_text_A_const_37; seq_190000025__3, chunk_190000026__4, count_190000027__5, i_190000028__6 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(seq_190000025__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var p__9 any; var tmp44 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp44 = A_arbace_g2a_print_text_A_const_33; p__9 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(seq_190000025__8)
				var tmp45 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp45 = A_arbace_g2a_print_text_A_const_43; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(p__9)) { var seq_190000033__10 any; var tmp46 *lang.Var
					A_arbace_g2a_print_text_A_Init(); tmp46 = A_arbace_g2a_print_text_A_const_30; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp48 = A_arbace_g2a_print_text_A_const_34; seq_190000033__10 = tmp47.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O__O(p__9))
//line :93:1
					var chunk_190000034__11 any; var count_190000035__12 int64 = 0; var i_190000036__13 int64 = 0; L3: for {
						if lang.Numbers_Lt_J_J__Z(i_190000036__13, count_190000035__12) { var cp__14_2 any = lang.Indexed_Cast(chunk_190000034__11).Nth_I__O(lang.RT_IntCast_J__I(i_190000036__13)); var tmp49 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp50 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp50 = A_arbace_g2a_print_text_A_const_35; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 any; A_arbace_g2a_print_text_A_Init(); tmp52 = A_arbace_g2a_print_text_A_const_36; jrt.NN(tmp49).Append_String__StringBuilder(jrt.String_Cast(tmp51.Invoke_O_O__O(cp__14_2, tmp52))); seq_190000033__10, chunk_190000034__11, count_190000035__12, i_190000036__13 = seq_190000033__10, chunk_190000034__11, count_190000035__12, lang.Numbers_Unchecked_inc_J__J(i_190000036__13); continue L3 } else { var temp__1927000414__auto____14 any; var tmp53 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp53 = A_arbace_g2a_print_text_A_const_30; temp__1927000414__auto____14 = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(seq_190000033__10); if jrt.A2g_Truth(temp__1927000414__auto____14) { var seq_190000033__15 any = temp__1927000414__auto____14; var tmp54 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp54 = A_arbace_g2a_print_text_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(seq_190000033__15)) { var c__1927000678__auto____16 any; var tmp55 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp55 = A_arbace_g2a_print_text_A_const_32; c__1927000678__auto____16 = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(seq_190000033__15); var tmp56 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp56 = A_arbace_g2a_print_text_A_const_37; seq_190000033__10, chunk_190000034__11, count_190000035__12, i_190000036__13 = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(seq_190000033__15), c__1927000678__auto____16, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var cp__16 any; var tmp57 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp57 = A_arbace_g2a_print_text_A_const_33; cp__16 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(seq_190000033__15); var tmp58 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp59 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp59 = A_arbace_g2a_print_text_A_const_35; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 any; A_arbace_g2a_print_text_A_Init(); tmp61 = A_arbace_g2a_print_text_A_const_36; jrt.NN(tmp58).Append_String__StringBuilder(jrt.String_Cast(tmp60.Invoke_O_O__O(cp__16, tmp61))); var tmp62 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp62 = A_arbace_g2a_print_text_A_const_38; seq_190000033__10, chunk_190000034__11, count_190000035__12, i_190000036__13 = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(seq_190000033__15), nil, 0, 0; continue L3 } } }
//line :93:1
						break L3 } } else { var tmp63 any; var and__1927000168__auto____10 any; var tmp64 *lang.Var

							A_arbace_g2a_print_text_A_Init(); tmp64 = A_arbace_g2a_print_text_A_const_44; and__1927000168__auto____10 = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(p__9); if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp65 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp65 = A_arbace_g2a_print_text_A_const_45; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 any; A_arbace_g2a_print_text_A_Init(); tmp67 = A_arbace_g2a_print_text_A_const_46; var tmp68 any = tmp67; var tmp69 any; A_arbace_g2a_print_text_A_Init(); tmp69 = A_arbace_g2a_print_text_A_const_47; tmp63 = tmp66.Invoke_O_O_O__O(tmp68, p__9, tmp69) } else { tmp63 = and__1927000168__auto____10 }
//line :93:1
							if jrt.A2g_Truth(tmp63) {

								var tmp70 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp71 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_100, nil); var tmp72 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp72 = A_arbace_g2a_print_text_A_const_19; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 any = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(p__9)).Ref(); var tmp75 any; A_arbace_g2a_print_text_A_Init(); tmp75 = A_arbace_g2a_print_text_A_const_21; jrt.NN(tmp70).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp71, jrt.RefArrayOf(jrt.Object_class, nil, tmp73.Invoke_O_O__O(tmp74, tmp75)))) } else {
//line :93:1
									var tmp76 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp76 = A_arbace_g2a_print_text_A_const_20; if tmp76 != nil { var tmp77 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp77 = A_arbace_g2a_print_text_A_const_26; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_116, nil); var tmp80 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp80 = A_arbace_g2a_print_text_A_const_27; var tmp81 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp79, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(p__9))).Ref(); var tmp82 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp82 = A_arbace_g2a_print_text_A_const_48; panic(jrt.Thrown(jrt.Throwable_Cast(tmp78.Invoke_O_O__O(tmp81, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp82.Ref(), p__9)))))) } } }
//line :92:1
				var tmp83 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp83 = A_arbace_g2a_print_text_A_const_38; seq_190000025__3, chunk_190000026__4, count_190000027__5, i_190000028__6 = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()).Invoke_O__O(seq_190000025__8), nil, 0, 0; continue L1 } } }
//line :87:1
		break L1 };









	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_115); return /*line :98:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_g2a_print_text_go_rune_A_New() *A_arbace_g2a_print_text_go_rune_A { A_arbace_g2a_print_text_go_rune_A_Init(); t := &A_arbace_g2a_print_text_go_rune_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_g2a_print_text_go_rune_A) Ctor() {}
//line :100:1
func (t *A_arbace_g2a_print_text_go_rune_A) Invoke_O_O__O(self, p_cp__0 any) any { var cp__0 int64 = lang.RT_LongCast_O__J(p_cp__0); var tmp1 bool; var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_J__Z(cp__0); if or__1927000174__auto____2 {


	tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Numbers_Gt_J_J__Z(cp__0, 1114111); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var and__1927000168__auto____4 bool = lang.Numbers_Gte_J_J__Z(cp__0, 55296); if and__1927000168__auto____4 { tmp1 = lang.Numbers_Lte_J_J__Z(cp__0, 57343) } else { tmp1 = and__1927000168__auto____4 } } }; if tmp1 { var tmp2 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_26; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(cp__0).Ref())).Ref(); var tmp5 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp5 = A_arbace_g2a_print_text_A_const_49; var tmp6 any = tmp5.Ref(); panic(jrt.Thrown(jrt.Throwable_Cast(tmp3.Invoke_O_O__O(tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, jrt.Long_ValueOf_J__Long(cp__0).Ref())))))) }; var tmp7 /*line :105:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_128, nil, Lit_128); var tmp8 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_35; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = jrt.Long_ValueOf_J__Long(cp__0).Ref(); var tmp11 any; A_arbace_g2a_print_text_A_Init(); tmp11 = A_arbace_g2a_print_text_A_const_50; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp9.Invoke_O_O__O(tmp10, tmp11), nil)).Ref() }

func A_arbace_g2a_print_text_float_kind_A_New() *A_arbace_g2a_print_text_float_kind_A { A_arbace_g2a_print_text_float_kind_A_Init(); t := &A_arbace_g2a_print_text_float_kind_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_g2a_print_text_float_kind_A) Ctor() {}
//line :107:1
func (t *A_arbace_g2a_print_text_float_kind_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any; var tmp2 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_51; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_108); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp3 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_51; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_109); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var tmp4 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_51; tmp1 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_110) } }; if jrt.A2g_Truth(tmp1) { return s__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_111), jrt.RefArrayOf(jrt.Object_class, s__0, nil)).Ref()
	} }
func A_arbace_g2a_print_text_pow2_exponent_A_New() *A_arbace_g2a_print_text_pow2_exponent_A { A_arbace_g2a_print_text_pow2_exponent_A_Init(); t := &A_arbace_g2a_print_text_pow2_exponent_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_g2a_print_text_pow2_exponent_A) Ctor() {}
//line :113:1
func (t *A_arbace_g2a_print_text_pow2_exponent_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).Signum__I())); if and__1927000168__auto____2 { tmp1 = lang.Numbers_Equiv_J_J__Z(1, int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitCount__I())) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitLength__I()))).Ref() } else { return nil
	} }
func A_arbace_g2a_print_text_strip_2_5_A_New() *A_arbace_g2a_print_text_strip_2_5_A { A_arbace_g2a_print_text_strip_2_5_A_Init(); t := &A_arbace_g2a_print_text_strip_2_5_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_g2a_print_text_strip_2_5_A) Ctor() {}
//line :118:1
func (t *A_arbace_g2a_print_text_strip_2_5_A) Invoke_O_O__O(self, n__0 any) any { { var five__2 any = jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(); var n__3 any = n__0; var a__4 int64 = 0; var b__5 int64 = 0; L1: for {




	var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_52; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.BigInteger_Cast(n__3)).TestBit_I__Z(lang.RT_IntCast_J__I(0))).Ref())) {
		n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).ShiftRight_I__BigInteger(lang.RT_IntCast_J__I(1)).Ref(), lang.Numbers_Inc_J__J(a__4), b__5; continue L1 } else {
//line :123:1
			if lang.Numbers_IsZero_J__Z(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(n__3)).Mod_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2))).Signum__I())) {

				n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).Divide_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2)).Ref(), a__4, lang.Numbers_Inc_J__J(b__5); continue L1 } else {
//line :123:1
					var tmp2 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_20; if tmp2 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(n__3, jrt.Long_ValueOf_J__Long(a__4).Ref(), jrt.Long_ValueOf_J__Long(b__5).Ref()) } else { return nil } } } } }; /*line :118:1*/panic("a2g: unreachable") }









func A_arbace_g2a_print_text_go_float_A_New() *A_arbace_g2a_print_text_go_float_A { A_arbace_g2a_print_text_go_float_A_Init(); t := &A_arbace_g2a_print_text_go_float_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_g2a_print_text_go_float_A) Ctor() {}
//line :128:1
func (t *A_arbace_g2a_print_text_go_float_A) Invoke_O_O__O(self, x__0 any) any {




	if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D(x__0); var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Double_IsNaN_D__Z(d__2)


		if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = jrt.Double_IsInfinite_D__Z(d__2) }; if tmp1 { var tmp2 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_26; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_118, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Double_ValueOf_D__Double(d__2).Ref())).Ref(); var tmp5 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp5 = A_arbace_g2a_print_text_A_const_59; var tmp6 any = tmp5.Ref(); panic(jrt.Thrown(jrt.Throwable_Cast(tmp3.Invoke_O_O__O(tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, jrt.Double_ValueOf_D__Double(d__2).Ref()))))))
		}
		var tmp7 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_53; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(jrt.Double_ToString_D__String(d__2).Ref()) } else {
//line :133:1
			if jrt.BigDecimal_InstanceOf(x__0) {





				var tmp8 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_54; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp10 = A_arbace_g2a_print_text_A_const_53; return tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigDecimal_Cast(x__0)).ToString__String().Ref())) } else {
//line :133:1
					var tmp11 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp11 = A_arbace_g2a_print_text_A_const_55; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(x__0)) { var n__2 any; var tmp12 *lang.Var







						A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_56; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp14 = A_arbace_g2a_print_text_A_const_60; n__2 = tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(x__0))
//line :133:1
						var d__3 any; var tmp15 *lang.Var







						A_arbace_g2a_print_text_A_Init(); tmp15 = A_arbace_g2a_print_text_A_const_56; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp17 = A_arbace_g2a_print_text_A_const_61; d__3 = tmp16.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(x__0))
//line :133:1
						var vec__190000042__4 any; var tmp18 *lang.Var








						A_arbace_g2a_print_text_A_Init(); tmp18 = A_arbace_g2a_print_text_A_const_57; vec__190000042__4 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(d__3)
//line :133:1
						var rest__5 any = lang.RT_Nth_O_I_O__O(vec__190000042__4, lang.RT_IntCast_J__I(0), nil); var a__6 any = lang.RT_Nth_O_I_O__O(vec__190000042__4, lang.RT_IntCast_J__I(1), nil); var b__7 any = lang.RT_Nth_O_I_O__O(vec__190000042__4, lang.RT_IntCast_J__I(2), nil); var tmp19 bool; var and__1927000168__auto____8 bool; var tmp20 *jrt.BigInteger










						jrt.BigInteger_Init(); tmp20 = jrt.BigInteger_ONE; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z(rest__5, tmp20.Ref()); if and__1927000168__auto____8 { tmp19 = lang.Numbers_Lte_O_J__Z(lang.Numbers_Max_O_O__O(a__6, b__7), 40) } else { tmp19 = and__1927000168__auto____8 }
//line :143:1
						if tmp19 {

							var tmp21 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp21 = A_arbace_g2a_print_text_A_const_54; return lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(n__2)).Divide_BigDecimal__BigDecimal(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(d__3)))).ToPlainString__String().Ref()) } else {
//line :143:1
								var tmp22 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp22 = A_arbace_g2a_print_text_A_const_58; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(d__3)) {



									var tmp23 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_119, nil, Lit_120, nil); var tmp24 any = jrt.NN(jrt.BigInteger_Cast(n__2)).ToString_I__String(lang.RT_IntCast_J__I(16)).Ref(); var tmp25 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp25 = A_arbace_g2a_print_text_A_const_58; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp23, jrt.RefArrayOf(jrt.Object_class, nil, tmp24, nil, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(d__3))).Ref() } else {
//line :143:1
										var tmp26 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp26 = A_arbace_g2a_print_text_A_const_20; if tmp26 != nil { var tmp27 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp27 = A_arbace_g2a_print_text_A_const_26; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_121, nil, Lit_122), jrt.RefArrayOf(jrt.Object_class, nil, x__0, nil)).Ref(); var tmp30 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp30 = A_arbace_g2a_print_text_A_const_59; panic(jrt.Thrown(jrt.Throwable_Cast(tmp28.Invoke_O_O__O(tmp29, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp30.Ref(), x__0)))))) } else { return nil } } } } else {
//line :133:1
											var tmp31 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp31 = A_arbace_g2a_print_text_A_const_20; if tmp31 != nil { var tmp32 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp32 = A_arbace_g2a_print_text_A_const_26; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_123, nil); var tmp35 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp35 = A_arbace_g2a_print_text_A_const_27; var tmp36 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp34, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var tmp37 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp37 = A_arbace_g2a_print_text_A_const_59; panic(jrt.Thrown(jrt.Throwable_Cast(tmp33.Invoke_O_O__O(tmp36, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37.Ref(), x__0)))))) } else { return nil
											}
										}
				}
		}
}












func A_arbace_g2a_print_text_negative_number_QMARK__A_New() *A_arbace_g2a_print_text_negative_number_QMARK__A { A_arbace_g2a_print_text_negative_number_QMARK__A_Init(); t := &A_arbace_g2a_print_text_negative_number_QMARK__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) Ctor() {}
//line :151:1
func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.Double_InstanceOf(x__0) { var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_D__Z(lang.RT_DoubleCast_O__D(x__0))
		if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_J_J__Z(jrt.Double_DoubleToRawLongBits_D__J(lang.RT_DoubleCast_O__D(x__0)), -9223372036854775808)).Ref() } } else {
//line :155:1
			var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_62; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) {


				return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_O__Z(x__0)).Ref() } else {
//line :155:1
					var tmp2 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_20; if tmp2 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
		}
}

func A_arbace_g2a_print_text_go_number_A_New() *A_arbace_g2a_print_text_go_number_A { A_arbace_g2a_print_text_go_number_A_Init(); t := &A_arbace_g2a_print_text_go_number_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_g2a_print_text_go_number_A) Ctor() {}
//line :161:1
func (t *A_arbace_g2a_print_text_go_number_A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.Double_InstanceOf(x__0) {
		var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_63; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Double_ValueOf_D__Double(jrt.Math_Abs_D__D(lang.RT_DoubleCast_O__D(x__0))).Ref()) } else {
//line :165:1
			var tmp2 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_44; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0)) {

				var tmp3 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_15; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :165:1
					var tmp4 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_20; if tmp4 != nil {


						var tmp5 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp5 = A_arbace_g2a_print_text_A_const_63; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :165:1
							return nil
						}
				}
		}
}



func A_arbace_g2a_print_text_escape_A_New() *A_arbace_g2a_print_text_escape_A { A_arbace_g2a_print_text_escape_A_Init(); t := &A_arbace_g2a_print_text_escape_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_g2a_print_text_escape_A) Ctor() {}
//line :173:1
func (t *A_arbace_g2a_print_text_escape_A) Invoke_O_O__O(self, s__0 any) any {




	var tmp1 *jrt.String = jrt.String_Cast(s__0); var tmp2 any; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_64; var tmp3 uint16 = jrt.NN(jrt.Character_Cast(tmp2)).CharValue__C(); var tmp4 any; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_65; var tmp5 *jrt.String = jrt.NN(tmp1).Replace_C_C__String(tmp3, jrt.NN(jrt.Character_Cast(tmp4)).CharValue__C()); var tmp6 any; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_66; var tmp7 uint16 = jrt.NN(jrt.Character_Cast(tmp6)).CharValue__C(); var tmp8 any; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_67; var tmp9 *jrt.String = jrt.NN(tmp5).Replace_C_C__String(tmp7, jrt.NN(jrt.Character_Cast(tmp8)).CharValue__C()); var tmp10 any; A_arbace_g2a_print_text_A_Init(); tmp10 = A_arbace_g2a_print_text_A_const_68; var tmp11 uint16 = jrt.NN(jrt.Character_Cast(tmp10)).CharValue__C(); var tmp12 any; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_69; var tmp13 *jrt.String = jrt.NN(tmp9).Replace_C_C__String(tmp11, jrt.NN(jrt.Character_Cast(tmp12)).CharValue__C()); var tmp14 any; A_arbace_g2a_print_text_A_Init(); tmp14 = A_arbace_g2a_print_text_A_const_70; var tmp15 uint16 = jrt.NN(jrt.Character_Cast(tmp14)).CharValue__C(); var tmp16 any; A_arbace_g2a_print_text_A_Init(); tmp16 = A_arbace_g2a_print_text_A_const_71; return jrt.NN(tmp13).Replace_C_C__String(tmp15, jrt.NN(jrt.Character_Cast(tmp16)).CharValue__C()).Ref()
}
func A_arbace_g2a_print_text_unescape_A_New() *A_arbace_g2a_print_text_unescape_A { A_arbace_g2a_print_text_unescape_A_Init(); t := &A_arbace_g2a_print_text_unescape_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_g2a_print_text_unescape_A) Ctor() {}
//line :180:1
func (t *A_arbace_g2a_print_text_unescape_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 *jrt.String = jrt.String_Cast(s__0); var tmp2 any; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_72; var tmp3 uint16 = jrt.NN(jrt.Character_Cast(tmp2)).CharValue__C(); var tmp4 any; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_64; var tmp5 *jrt.String = jrt.NN(tmp1).Replace_C_C__String(tmp3, jrt.NN(jrt.Character_Cast(tmp4)).CharValue__C()); var tmp6 any; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_73; var tmp7 uint16 = jrt.NN(jrt.Character_Cast(tmp6)).CharValue__C(); var tmp8 any; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_66; var tmp9 *jrt.String = jrt.NN(tmp5).Replace_C_C__String(tmp7, jrt.NN(jrt.Character_Cast(tmp8)).CharValue__C()); var tmp10 any; A_arbace_g2a_print_text_A_Init(); tmp10 = A_arbace_g2a_print_text_A_const_74; var tmp11 uint16 = jrt.NN(jrt.Character_Cast(tmp10)).CharValue__C(); var tmp12 any; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_68; var tmp13 *jrt.String = jrt.NN(tmp9).Replace_C_C__String(tmp11, jrt.NN(jrt.Character_Cast(tmp12)).CharValue__C()); var tmp14 any; A_arbace_g2a_print_text_A_Init(); tmp14 = A_arbace_g2a_print_text_A_const_75; var tmp15 uint16 = jrt.NN(jrt.Character_Cast(tmp14)).CharValue__C(); var tmp16 any; A_arbace_g2a_print_text_A_Init(); tmp16 = A_arbace_g2a_print_text_A_const_70; return jrt.NN(tmp13).Replace_C_C__String(tmp15, jrt.NN(jrt.Character_Cast(tmp16)).CharValue__C()).Ref()
}



func A_arbace_g2a_print_text_cell_width_A_New() *A_arbace_g2a_print_text_cell_width_A { A_arbace_g2a_print_text_cell_width_A_Init(); t := &A_arbace_g2a_print_text_cell_width_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_g2a_print_text_cell_width_A) Ctor() {}
//line :189:1
func (t *A_arbace_g2a_print_text_cell_width_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.String_Cast(s__0)).CodePointCount_I_I__I(lang.RT_IntCast_J__I(0), jrt.NN(jrt.String_Cast(s__0)).Length__I())).Ref() }



func A_arbace_g2a_print_text_parse_lines_A_New() *A_arbace_g2a_print_text_parse_lines_A { A_arbace_g2a_print_text_parse_lines_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_g2a_print_text_parse_lines_A) Ctor() {}
//line :193:1
func (t *A_arbace_g2a_print_text_parse_lines_A) Invoke_O_O__O(self, text__0 any) any {



	var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_76; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var iter__1927001039__auto____2 any; var tmp4 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_New(); var tmp5 *jrt.Class; A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_Init(); tmp5 = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp7 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_89; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_90; var tmp10 any = tmp9; var tmp11 any; A_arbace_g2a_print_text_A_Init(); tmp11 = A_arbace_g2a_print_text_A_const_91; tmp3 = tmp6.Invoke_O__O(tmp8.Invoke_O_O_O__O(text__0, tmp10, tmp11)); return tmp2.Invoke_O__O(tmp3) }
//line :197:1
func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_New() *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) Ctor() {}
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) Invoke_O_O__O(self, s__190000052__1 any) any { var tmp1 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_New_O_O(self, s__190000052__1); var tmp2 *jrt.Class; A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_Init(); tmp2 = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :197:1
func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A{}; t.Ctor_O_O(p0, p1); return t }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) Ctor_O_O(c__iter__190000051, c__s__190000052 any) { t.F_iter__190000051 = c__iter__190000051; t.F_s__190000052 = c__s__190000052 }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) Invoke_O__O(self any) any { { var s__190000052__1 any; var t_ any = t.F_s__190000052; t.F_s__190000052 = nil; s__190000052__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_30; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__190000052__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__190000052__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__190000052__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_32; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__190000052__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__190000054__6 any; var tmp4 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_77; b__190000054__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__190000054__6); var tmp6 *jrt.Class; A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_Init(); tmp6 = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_85; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_87; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__190000054__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__190000051); var tmp12 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_37; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__190000052__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp13 = A_arbace_g2a_print_text_A_const_85; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp15 = A_arbace_g2a_print_text_A_const_87; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__190000054__6), nil) } } else { var line__4 any; var tmp16 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp16 = A_arbace_g2a_print_text_A_const_33; line__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__190000052__3); var tmp17 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp17 = A_arbace_g2a_print_text_A_const_86; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; var n__5 int32 = jrt.NN(jrt.String_Cast(line__4)).Length__I(); var tmp20 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_New_I_O(n__5, line__4); var tmp21 *jrt.Class

	A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_Init(); tmp21 = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_fn_class; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil).Invoke__O()
//line :197:1
	var tmp22 any = tmp19; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__190000051); var tmp24 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp24 = A_arbace_g2a_print_text_A_const_88; return tmp18.Invoke_O_O__O(tmp22, tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(s__190000052__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :197:1
func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__190000054 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__190000054 = c__b__190000054 }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) Invoke_O__O(self any) any { { var i__190000053__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__190000053__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var line__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__190000053__1)); var tmp2 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_78; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__190000054; var tmp5 any; var n__3 int32 = jrt.NN(jrt.String_Cast(line__2)).Length__I(); var tmp6 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_New_I_O(n__3, line__2); var tmp7 *jrt.Class

	A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_Init(); tmp7 = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_fn_class; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :197:1
	tmp3.Invoke_O_O__O(tmp4, tmp5); i__190000053__1 = lang.Numbers_Unchecked_inc_J__J(i__190000053__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_New_I_O(p0 int32, p1 any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any; var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_24; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; cells__3 = tmp2.Invoke_O__O(tmp3.Ref()); L1: for {
																		if lang.Numbers_Lt_J_J__Z(i__1, int64(t.F_n)) { var tmp4 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I(jrt.NN(tmp4).CharAt_I__C(lang.RT_IntCast_J__I(i__1))); var tmp5 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp5 = or__1927000174__auto____5 } else { tmp5 = lang.Numbers_Equiv_J_J__Z(int64(c__4), 11) }; if tmp5 {
			var tmp6 int64 = lang.Numbers_Inc_J__J(i__1); var tmp7 int64 = lang.Numbers_Inc_J__J(i__1); var tmp8 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_29; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; var tmp11 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)
			if and__1927000168__auto____5 { tmp11 = lang.Numbers_Equiv_J_J__Z(start__2, i__1) } else { tmp11 = and__1927000168__auto____5 }; if tmp11 { var tmp12 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_80; tmp10 = jrt.NN(tmp12).GetRawRoot__O() } else { var t__5 any; var tmp13 *lang.Var

				A_arbace_g2a_print_text_A_Init(); tmp13 = A_arbace_g2a_print_text_A_const_79; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = t.F_line; t__5 = tmp14.Invoke_O_O_O__O(tmp15, jrt.Long_ValueOf_J__Long(start__2).Ref(), jrt.Long_ValueOf_J__Long(i__1).Ref())
//line :204:1
				var tmp16 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp16 = A_arbace_g2a_print_text_A_const_81; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp18 = A_arbace_g2a_print_text_A_const_82; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp20 = A_arbace_g2a_print_text_A_const_83; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(t__5); var tmp22 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp22 = A_arbace_g2a_print_text_A_const_84; var tmp23 any = tmp22.Ref(); tmp10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, t__5, tmp19, tmp21, tmp23, jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)).Ref())) }
//line :203:1
			i__1, start__2, cells__3 = tmp6, tmp7, tmp9.Invoke_O_O__O(cells__3, tmp10); continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var t__4 any; var tmp24 *lang.Var








					A_arbace_g2a_print_text_A_Init(); tmp24 = A_arbace_g2a_print_text_A_const_79; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any = t.F_line; t__4 = tmp25.Invoke_O_O__O(tmp26, jrt.Long_ValueOf_J__Long(start__2).Ref())
					var tmp27 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp27 = A_arbace_g2a_print_text_A_const_25; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp29 = A_arbace_g2a_print_text_A_const_29; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp31 = A_arbace_g2a_print_text_A_const_81; var tmp32 any = tmp31.Ref(); var tmp33 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp33 = A_arbace_g2a_print_text_A_const_82; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp35 = A_arbace_g2a_print_text_A_const_83; var tmp36 any = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(t__4); var tmp37 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp37 = A_arbace_g2a_print_text_A_const_84; var tmp38 any = tmp37.Ref(); var tmp39 *jrt.Boolean; jrt.Boolean_Init(); tmp39 = jrt.Boolean_FALSE; return tmp28.Invoke_O__O(tmp30.Invoke_O_O__O(cells__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp32, t__4, tmp34, tmp36, tmp38, tmp39.Ref())))) } } }; /*line :199:1*/panic("a2g: unreachable") }
//line :199:1
func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_New_I_O(p0 int32, p1 any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any; var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_24; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; cells__3 = tmp2.Invoke_O__O(tmp3.Ref()); L1: for {
																	if lang.Numbers_Lt_J_J__Z(i__1, int64(t.F_n)) { var tmp4 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I(jrt.NN(tmp4).CharAt_I__C(lang.RT_IntCast_J__I(i__1))); var tmp5 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp5 = or__1927000174__auto____5 } else { tmp5 = lang.Numbers_Equiv_J_J__Z(int64(c__4), 11) }; if tmp5 {
			var tmp6 int64 = lang.Numbers_Inc_J__J(i__1); var tmp7 int64 = lang.Numbers_Inc_J__J(i__1); var tmp8 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_29; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; var tmp11 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)
			if and__1927000168__auto____5 { tmp11 = lang.Numbers_Equiv_J_J__Z(start__2, i__1) } else { tmp11 = and__1927000168__auto____5 }; if tmp11 { var tmp12 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_80; tmp10 = jrt.NN(tmp12).GetRawRoot__O() } else { var t__5 any; var tmp13 *lang.Var

				A_arbace_g2a_print_text_A_Init(); tmp13 = A_arbace_g2a_print_text_A_const_79; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = t.F_line; t__5 = tmp14.Invoke_O_O_O__O(tmp15, jrt.Long_ValueOf_J__Long(start__2).Ref(), jrt.Long_ValueOf_J__Long(i__1).Ref())
//line :204:1
				var tmp16 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp16 = A_arbace_g2a_print_text_A_const_81; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp18 = A_arbace_g2a_print_text_A_const_82; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp20 = A_arbace_g2a_print_text_A_const_83; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(t__5); var tmp22 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp22 = A_arbace_g2a_print_text_A_const_84; var tmp23 any = tmp22.Ref(); tmp10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, t__5, tmp19, tmp21, tmp23, jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)).Ref())) }
//line :203:1
			i__1, start__2, cells__3 = tmp6, tmp7, tmp9.Invoke_O_O__O(cells__3, tmp10); continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var t__4 any; var tmp24 *lang.Var








					A_arbace_g2a_print_text_A_Init(); tmp24 = A_arbace_g2a_print_text_A_const_79; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any = t.F_line; t__4 = tmp25.Invoke_O_O__O(tmp26, jrt.Long_ValueOf_J__Long(start__2).Ref())
					var tmp27 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp27 = A_arbace_g2a_print_text_A_const_25; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp29 = A_arbace_g2a_print_text_A_const_29; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp31 = A_arbace_g2a_print_text_A_const_81; var tmp32 any = tmp31.Ref(); var tmp33 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp33 = A_arbace_g2a_print_text_A_const_82; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp35 = A_arbace_g2a_print_text_A_const_83; var tmp36 any = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(t__4); var tmp37 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp37 = A_arbace_g2a_print_text_A_const_84; var tmp38 any = tmp37.Ref(); var tmp39 *jrt.Boolean; jrt.Boolean_Init(); tmp39 = jrt.Boolean_FALSE; return tmp28.Invoke_O__O(tmp30.Invoke_O_O__O(cells__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp32, t__4, tmp34, tmp36, tmp38, tmp39.Ref())))) } } }; /*line :199:1*/panic("a2g: unreachable") }












func A_arbace_g2a_print_text_write_padding_A_New() *A_arbace_g2a_print_text_write_padding_A { A_arbace_g2a_print_text_write_padding_A_Init(); t := &A_arbace_g2a_print_text_write_padding_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_g2a_print_text_write_padding_A) Ctor() {}
//line :212:1
func (t *A_arbace_g2a_print_text_write_padding_A) Invoke_O_O_O_O_O__O(self, sb__0, p_textw__1, p_cellw__2, use_tabs__3 any) any { { var textw__1 int64 = lang.RT_LongCast_O__J(p_textw__1); var cellw__2 int64 = lang.RT_LongCast_O__J(p_cellw__2)
																if jrt.A2g_Truth(use_tabs__3) { var cellw__5 int64 = lang.Numbers_Multiply_J_J__J(8, lang.Numbers_Quotient_J_J__J(lang.Numbers_Add_J_J__J(cellw__2, 7), 8)); var n__6 int64 = lang.Numbers_Minus_J_J__J(cellw__5, textw__1); var n__1927000701__auto____7 int64 = lang.RT_LongCast_J__J(lang.Numbers_Quotient_J_J__J(lang.Numbers_Add_J_J__J(n__6, 7), 8)); var ___8 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z(___8, n__1927000701__auto____7) { var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__0); var tmp2 any; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_64; jrt.NN(tmp1).Append_O__StringBuilder(tmp2); ___8 = lang.Numbers_Unchecked_inc_J__J(___8); continue L1 } else { return nil } } } else {
//line :213:1
			var n__1927000701__auto____5 int64 = lang.RT_LongCast_J__J(lang.Numbers_Minus_J_J__J(cellw__2, textw__1)); var ___6 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z(___6, n__1927000701__auto____5) { var tmp3 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__0); var tmp4 any; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_92; jrt.NN(tmp3).Append_O__StringBuilder(tmp4); ___6 = lang.Numbers_Unchecked_inc_J__J(___6); continue L2 } else { return nil } } } }; /*line :212:1*/panic("a2g: unreachable") }






func A_arbace_g2a_print_text_write_lines_A_New() *A_arbace_g2a_print_text_write_lines_A { A_arbace_g2a_print_text_write_lines_A_Init(); t := &A_arbace_g2a_print_text_write_lines_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_g2a_print_text_write_lines_A) Ctor() {}
//line :219:1
func (t *A_arbace_g2a_print_text_write_lines_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var seq_190000067__6 any; var tmp1 *lang.Var
																	A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_30; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_93; seq_190000067__6 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(line0__3, line1__4))
//line :219:1
	var chunk_190000068__7 any; var count_190000069__8 int64 = 0; var i_190000070__9 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_190000070__9, count_190000069__8) { var i__10 any = lang.Indexed_Cast(chunk_190000068__7).Nth_I__O(lang.RT_IntCast_J__I(i_190000070__9)); var line__11 any = lang.RT_Nth_O_I__O(lines__1, lang.RT_IntCast_O__I(i__10)); var nw__12 int32 = lang.RT_Count_O__I(widths__2); var j__13 int64 = 0; var use_tabs__14 any; jrt.Boolean_Init(); use_tabs__14 = jrt.Boolean_TRUE.Ref(); L2: for {



			if lang.Numbers_Lt_J_J__Z(j__13, int64(lang.RT_Count_O__I(line__11))) { var c__15 any = lang.RT_Nth_O_I__O(line__11, lang.RT_IntCast_J__I(j__13)); var tmp4 *lang.Keyword

				A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_81; if lang.Numbers_IsZero_J__Z(int64(lang.RT_Count_O__I(jrt.NN(tmp4).Invoke_O__O(c__15)))) {
					if lang.Numbers_Lt_J_J__Z(j__13, int64(nw__12)) { var tmp5 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp5 = A_arbace_g2a_print_text_A_const_94; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_82; tmp6.Invoke_O_O_O_O__O(sb__0, jrt.NN(tmp7).Invoke_O__O(c__15), lang.RT_Nth_O_I__O(widths__2, lang.RT_IntCast_J__I(j__13)), use_tabs__14) }
					j__13, use_tabs__14 = lang.Numbers_Inc_J__J(j__13), use_tabs__14; continue L2 } else {
						var tmp8 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__0); var tmp9 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_81; jrt.NN(tmp8).Append_String__StringBuilder(jrt.String_Cast(jrt.NN(tmp9).Invoke_O__O(c__15)))
						if lang.Numbers_Lt_J_J__Z(j__13, int64(nw__12)) { var tmp10 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp10 = A_arbace_g2a_print_text_A_const_94; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp12 = A_arbace_g2a_print_text_A_const_82; var tmp13 any = jrt.NN(tmp12).Invoke_O__O(c__15); var tmp14 any = lang.RT_Nth_O_I__O(widths__2, lang.RT_IntCast_J__I(j__13)); var tmp15 *jrt.Boolean; jrt.Boolean_Init(); tmp15 = jrt.Boolean_FALSE; tmp11.Invoke_O_O_O_O__O(sb__0, tmp13, tmp14, tmp15.Ref()) }
						var tmp16 int64 = lang.Numbers_Inc_J__J(j__13); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_FALSE; j__13, use_tabs__14 = tmp16, tmp17.Ref(); continue L2 } }
//line :220:1
			break L2
		}










			if lang.Numbers_Lt_O_J__Z(lang.Numbers_Inc_O__Number(i__10), int64(lang.RT_Count_O__I(lines__1))) { var tmp18 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__0); var tmp19 any; A_arbace_g2a_print_text_A_Init(); tmp19 = A_arbace_g2a_print_text_A_const_66; jrt.NN(tmp18).Append_O__StringBuilder(tmp19) }
//line :220:1
			seq_190000067__6, chunk_190000068__7, count_190000069__8, i_190000070__9 = seq_190000067__6, chunk_190000068__7, count_190000069__8, lang.Numbers_Unchecked_inc_J__J(i_190000070__9); continue L1 } else { var temp__1927000414__auto____10 any; var tmp20 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp20 = A_arbace_g2a_print_text_A_const_30; temp__1927000414__auto____10 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_190000067__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_190000067__11 any = temp__1927000414__auto____10; var tmp21 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp21 = A_arbace_g2a_print_text_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_190000067__11)) { var c__1927000678__auto____12 any; var tmp22 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp22 = A_arbace_g2a_print_text_A_const_32; c__1927000678__auto____12 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_190000067__11); var tmp23 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp23 = A_arbace_g2a_print_text_A_const_37; seq_190000067__6, chunk_190000068__7, count_190000069__8, i_190000070__9 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_190000067__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var i__12 any; var tmp24 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp24 = A_arbace_g2a_print_text_A_const_33; i__12 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_190000067__11); var line__13 any = lang.RT_Nth_O_I__O(lines__1, lang.RT_IntCast_O__I(i__12)); var nw__14 int32 = lang.RT_Count_O__I(widths__2); var j__15 int64 = 0; var use_tabs__16 any; jrt.Boolean_Init(); use_tabs__16 = jrt.Boolean_TRUE.Ref(); L3: for {



				if lang.Numbers_Lt_J_J__Z(j__15, int64(lang.RT_Count_O__I(line__13))) { var c__17 any = lang.RT_Nth_O_I__O(line__13, lang.RT_IntCast_J__I(j__15)); var tmp25 *lang.Keyword

					A_arbace_g2a_print_text_A_Init(); tmp25 = A_arbace_g2a_print_text_A_const_81; if lang.Numbers_IsZero_J__Z(int64(lang.RT_Count_O__I(jrt.NN(tmp25).Invoke_O__O(c__17)))) {
						if lang.Numbers_Lt_J_J__Z(j__15, int64(nw__14)) { var tmp26 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp26 = A_arbace_g2a_print_text_A_const_94; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp28 = A_arbace_g2a_print_text_A_const_82; tmp27.Invoke_O_O_O_O__O(sb__0, jrt.NN(tmp28).Invoke_O__O(c__17), lang.RT_Nth_O_I__O(widths__2, lang.RT_IntCast_J__I(j__15)), use_tabs__16) }
						j__15, use_tabs__16 = lang.Numbers_Inc_J__J(j__15), use_tabs__16; continue L3 } else {
							var tmp29 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__0); var tmp30 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp30 = A_arbace_g2a_print_text_A_const_81; jrt.NN(tmp29).Append_String__StringBuilder(jrt.String_Cast(jrt.NN(tmp30).Invoke_O__O(c__17)))
							if lang.Numbers_Lt_J_J__Z(j__15, int64(nw__14)) { var tmp31 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp31 = A_arbace_g2a_print_text_A_const_94; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp33 = A_arbace_g2a_print_text_A_const_82; var tmp34 any = jrt.NN(tmp33).Invoke_O__O(c__17); var tmp35 any = lang.RT_Nth_O_I__O(widths__2, lang.RT_IntCast_J__I(j__15)); var tmp36 *jrt.Boolean; jrt.Boolean_Init(); tmp36 = jrt.Boolean_FALSE; tmp32.Invoke_O_O_O_O__O(sb__0, tmp34, tmp35, tmp36.Ref()) }
							var tmp37 int64 = lang.Numbers_Inc_J__J(j__15); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_FALSE; j__15, use_tabs__16 = tmp37, tmp38.Ref(); continue L3 } }
//line :220:1
				break L3
			}










				if lang.Numbers_Lt_O_J__Z(lang.Numbers_Inc_O__Number(i__12), int64(lang.RT_Count_O__I(lines__1))) { var tmp39 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__0); var tmp40 any; A_arbace_g2a_print_text_A_Init(); tmp40 = A_arbace_g2a_print_text_A_const_66; jrt.NN(tmp39).Append_O__StringBuilder(tmp40) }
//line :220:1
				var tmp41 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp41 = A_arbace_g2a_print_text_A_const_38; seq_190000067__6, chunk_190000068__7, count_190000069__8, i_190000070__9 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(seq_190000067__11), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :219:1*/panic("a2g: unreachable") }














func A_arbace_g2a_print_text_format_block_A_New() *A_arbace_g2a_print_text_format_block_A { A_arbace_g2a_print_text_format_block_A_Init(); t := &A_arbace_g2a_print_text_format_block_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_g2a_print_text_format_block_A) Ctor() {}
//line :234:1
func (t *A_arbace_g2a_print_text_format_block_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var column__6 int32 = lang.RT_Count_O__I(widths__2); var this__7 any = line0__3; var line0__8 any = line0__3; L1: for {




	if lang.Numbers_Lt_O_O__Z(this__7, line1__4) { var line__9 any = lang.RT_Nth_O_I__O(lines__1, lang.RT_IntCast_O__I(this__7))

		if lang.Numbers_Gte_J_J__Z(int64(column__6), lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(line__9)))) {
			this__7, line0__8 = lang.Numbers_Inc_O__Number(this__7), line0__8; continue L1 } else {

				var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_95; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O_O__O(sb__0, lines__1, widths__2, line0__8, this__7)
//line :241:1
				var line0__10 any = this__7; var vec__190000072__11 any; var tmp2 any = A_arbace_g2a_print_text_format_block_fn__190000075_A_New_I_O_O_O(column__6, this__7, line1__4, lines__1); var tmp3 *jrt.Class





				A_arbace_g2a_print_text_format_block_fn__190000075_A_Init(); tmp3 = A_arbace_g2a_print_text_format_block_fn__190000075_A_fn_class; vec__190000072__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :241:1
				var end__12 any = lang.RT_Nth_O_I_O__O(vec__190000072__11, lang.RT_IntCast_J__I(0), nil); var width__13 any = lang.RT_Nth_O_I_O__O(vec__190000072__11, lang.RT_IntCast_J__I(1), nil); var discardable__14 any = lang.RT_Nth_O_I_O__O(vec__190000072__11, lang.RT_IntCast_J__I(2), nil); var width__15 any














				if jrt.A2g_Truth(discardable__14) { A_arbace_g2a_print_text_A_Init(); width__15 = A_arbace_g2a_print_text_A_const_46 } else { width__15 = width__13 }
				var tmp4 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_96; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_6; tmp5.Invoke_O_O_O_O_O__O(sb__0, lines__1, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(widths__2, width__15), line0__10, end__12)
				this__7, line0__8 = lang.Numbers_Inc_O__Number(end__12), end__12; continue L1 } } else {
					var tmp7 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_95; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O_O_O_O__O(sb__0, lines__1, widths__2, line0__8, line1__4) } } }; /*line :234:1*/panic("a2g: unreachable") }












func A_arbace_g2a_print_text_format_block_fn__190000075_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_g2a_print_text_format_block_fn__190000075_A { A_arbace_g2a_print_text_format_block_fn__190000075_A_Init(); t := &A_arbace_g2a_print_text_format_block_fn__190000075_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :247:1
func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) Ctor_I_O_O_O(c__column int32, c__this, c__line1, c__lines any) { t.F_column = c__column; t.F_this = c__this; t.F_line1 = c__line1; t.F_lines = c__lines }
//line :247:1
func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) Invoke_O__O(self any) any { { var this__1 any; var t_ any = t.F_this; t.F_this = nil; this__1 = t_; var width__2 any = lang.RT_Box_J__Number(0); var discardable__3 any; jrt.Boolean_Init(); discardable__3 = jrt.Boolean_TRUE.Ref(); L1: for {
												if lang.Numbers_Lt_O_O__Z(this__1, t.F_line1) { var tmp1 any = t.F_lines; var line__4 any = lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(this__1)); var tmp2 int64 = int64(t.F_column)

		if lang.Numbers_Gte_J_J__Z(tmp2, lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(line__4)))) { return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } else { var c__5 any = lang.RT_Nth_O_I__O(line__4, t.F_column); var tmp3 any = lang.Numbers_Inc_O__Number(this__1); var tmp4 *lang.Keyword


			A_arbace_g2a_print_text_A_Init(); tmp4 = A_arbace_g2a_print_text_A_const_82; var tmp5 any = lang.Numbers_Max_O_O__O(width__2, lang.Numbers_Inc_O__Number(jrt.NN(tmp4).Invoke_O__O(c__5))); var tmp6 any; var and__1927000168__auto____6 any = discardable__3
			if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool; var tmp7 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp7 = A_arbace_g2a_print_text_A_const_82; and__1927000168__auto____7 = lang.Numbers_IsZero_O__Z(jrt.NN(tmp7).Invoke_O__O(c__5)); if and__1927000168__auto____7 { var tmp8 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_52; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_g2a_print_text_A_Init(); tmp10 = A_arbace_g2a_print_text_A_const_84; tmp6 = tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(c__5)) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } } else { tmp6 = and__1927000168__auto____6 }
//line :253:1
			this__1, width__2, discardable__3 = tmp3, tmp5, tmp6; continue L1 } } else {
//line :248:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } } }; /*line :247:1*/panic("a2g: unreachable") }













func A_arbace_g2a_print_text_align_block_A_New() *A_arbace_g2a_print_text_align_block_A { A_arbace_g2a_print_text_align_block_A_Init(); t := &A_arbace_g2a_print_text_align_block_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_g2a_print_text_align_block_A) Ctor() {}
//line :261:1
func (t *A_arbace_g2a_print_text_align_block_A) Invoke_O_O__O(self, block__0 any) any { var sb__2 any = jrt.StringBuilder_New(); var lines__3 any; var tmp1 *lang.Var;



	A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_97; lines__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(block__0); var tmp2 /*line :266:1*/*lang.Var; A_arbace_g2a_print_text_A_Init(); tmp2 = A_arbace_g2a_print_text_A_const_96; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.PersistentVector; lang.PersistentVector_Init(); tmp4 = lang.PersistentVector_EMPTY; var tmp5 any = tmp4.Ref(); var tmp6 any; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_46; var tmp7 any = tmp6; tmp3.Invoke_O_O_O_O_O__O(sb__2, lines__3, tmp5, tmp7, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lines__3)).Ref()); return /*line :267:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_g2a_print_text_align_A_New() *A_arbace_g2a_print_text_align_A { A_arbace_g2a_print_text_align_A_Init(); t := &A_arbace_g2a_print_text_align_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_g2a_print_text_align_A) Ctor() {}
//line :269:1
func (t *A_arbace_g2a_print_text_align_A) Invoke_O_O__O(self, text__0 any) any { var blocks__2 any; var tmp1 *lang.Var;



	A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_89; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_100; var tmp4 any = tmp3; var tmp5 any; A_arbace_g2a_print_text_A_Init(); tmp5 = A_arbace_g2a_print_text_A_const_91; blocks__2 = tmp2.Invoke_O_O_O__O(text__0, tmp4, tmp5); var n__3 int32 = /*line :269:1*/lang.RT_Count_O__I(blocks__2); var groups__4 int64 = lang.Numbers_Multiply_J_J__J(4, int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())); var aligned__5 any; if






	lang.Numbers_Lt_J_J__Z(int64(n__3), 128) {
		var tmp6 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp6 = A_arbace_g2a_print_text_A_const_98; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp8 = A_arbace_g2a_print_text_A_const_101; aligned__5 = tmp7.Invoke_O_O__O(jrt.NN(tmp8).GetRawRoot__O(), blocks__2) } else {
			var tmp9 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp9 = A_arbace_g2a_print_text_A_const_14; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp11 = A_arbace_g2a_print_text_A_const_102; var tmp12 any = jrt.NN(tmp11).GetRawRoot__O(); var tmp13 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp13 = A_arbace_g2a_print_text_A_const_103; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any = A_arbace_g2a_print_text_align_fn__190000080_A_New(); var tmp16 *jrt.Class; A_arbace_g2a_print_text_align_fn__190000080_A_Init(); tmp16 = A_arbace_g2a_print_text_align_fn__190000080_A_fn_class; var tmp17 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp18 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp18 = A_arbace_g2a_print_text_A_const_105; aligned__5 = tmp10.Invoke_O_O__O(tmp12, tmp14.Invoke_O_O__O(tmp17, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Quotient_J_J__J(lang.Numbers_Add_J_J__J(int64(n__3), lang.Numbers_Dec_J__J(groups__4)), groups__4)).Ref(), blocks__2))) }; var tmp19 /*line :280:1*/*lang.Var; A_arbace_g2a_print_text_A_Init(); tmp19 = A_arbace_g2a_print_text_A_const_99; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp21 = A_arbace_g2a_print_text_A_const_106; return tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(Lit_85, aligned__5)) }
//line :278:1
func A_arbace_g2a_print_text_align_fn__190000080_A_New() *A_arbace_g2a_print_text_align_fn__190000080_A { A_arbace_g2a_print_text_align_fn__190000080_A_Init(); t := &A_arbace_g2a_print_text_align_fn__190000080_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_g2a_print_text_align_fn__190000080_A) Ctor() {}
//line :278:1
func (t *A_arbace_g2a_print_text_align_fn__190000080_A) Invoke_O_O__O(self, p1__190000079_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp1 = A_arbace_g2a_print_text_A_const_104; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_print_text_A_Init(); tmp3 = A_arbace_g2a_print_text_A_const_101; return tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), p1__190000079_SHARP___1) }







type A_arbace_g2a_print_text_A struct{ jrt.Object }

var A_arbace_g2a_print_text_A_const_0 *lang.Var

var A_arbace_g2a_print_text_A_const_1 *lang.Var

var A_arbace_g2a_print_text_A_const_2 any

var A_arbace_g2a_print_text_A_const_3 any

var A_arbace_g2a_print_text_A_const_4 *lang.Var

var A_arbace_g2a_print_text_A_const_5 *lang.Var

var A_arbace_g2a_print_text_A_const_6 *lang.Var

var A_arbace_g2a_print_text_A_const_7 any

var A_arbace_g2a_print_text_A_const_8 *lang.Var

var A_arbace_g2a_print_text_A_const_9 *lang.Var

var A_arbace_g2a_print_text_A_const_10 *lang.Var

var A_arbace_g2a_print_text_A_const_11 any

var A_arbace_g2a_print_text_A_const_12 any

var A_arbace_g2a_print_text_A_const_13 *lang.Var

var A_arbace_g2a_print_text_A_const_14 *lang.Var

var A_arbace_g2a_print_text_A_const_15 *lang.Var

var A_arbace_g2a_print_text_A_const_16 *lang.Var

var A_arbace_g2a_print_text_A_const_17 any

var A_arbace_g2a_print_text_A_const_18 *lang.Var

var A_arbace_g2a_print_text_A_const_19 *lang.Var

var A_arbace_g2a_print_text_A_const_20 *lang.Keyword

var A_arbace_g2a_print_text_A_const_21 any

var A_arbace_g2a_print_text_A_const_22 any

var A_arbace_g2a_print_text_A_const_23 any

var A_arbace_g2a_print_text_A_const_24 *lang.Var

var A_arbace_g2a_print_text_A_const_25 *lang.Var

var A_arbace_g2a_print_text_A_const_26 *lang.Var

var A_arbace_g2a_print_text_A_const_27 *lang.Var

var A_arbace_g2a_print_text_A_const_28 *lang.Keyword

var A_arbace_g2a_print_text_A_const_29 *lang.Var

var A_arbace_g2a_print_text_A_const_30 *lang.Var

var A_arbace_g2a_print_text_A_const_31 *lang.Var

var A_arbace_g2a_print_text_A_const_32 *lang.Var

var A_arbace_g2a_print_text_A_const_33 *lang.Var

var A_arbace_g2a_print_text_A_const_34 *lang.Var

var A_arbace_g2a_print_text_A_const_35 *lang.Var

var A_arbace_g2a_print_text_A_const_36 any

var A_arbace_g2a_print_text_A_const_37 *lang.Var

var A_arbace_g2a_print_text_A_const_38 *lang.Var

var A_arbace_g2a_print_text_A_const_39 *lang.Var

var A_arbace_g2a_print_text_A_const_40 *lang.Var

var A_arbace_g2a_print_text_A_const_41 any

var A_arbace_g2a_print_text_A_const_42 any

var A_arbace_g2a_print_text_A_const_43 *lang.Var

var A_arbace_g2a_print_text_A_const_44 *lang.Var

var A_arbace_g2a_print_text_A_const_45 *lang.Var

var A_arbace_g2a_print_text_A_const_46 any

var A_arbace_g2a_print_text_A_const_47 any

var A_arbace_g2a_print_text_A_const_48 *lang.Keyword

var A_arbace_g2a_print_text_A_const_49 *lang.Keyword

var A_arbace_g2a_print_text_A_const_50 any

var A_arbace_g2a_print_text_A_const_51 *lang.Var

var A_arbace_g2a_print_text_A_const_52 *lang.Var

var A_arbace_g2a_print_text_A_const_53 *lang.Var

var A_arbace_g2a_print_text_A_const_54 *lang.Var

var A_arbace_g2a_print_text_A_const_55 *lang.Var

var A_arbace_g2a_print_text_A_const_56 *lang.Var

var A_arbace_g2a_print_text_A_const_57 *lang.Var

var A_arbace_g2a_print_text_A_const_58 *lang.Var

var A_arbace_g2a_print_text_A_const_59 *lang.Keyword

var A_arbace_g2a_print_text_A_const_60 *lang.Var

var A_arbace_g2a_print_text_A_const_61 *lang.Var

var A_arbace_g2a_print_text_A_const_62 *lang.Var

var A_arbace_g2a_print_text_A_const_63 *lang.Var

var A_arbace_g2a_print_text_A_const_64 any

var A_arbace_g2a_print_text_A_const_65 any

var A_arbace_g2a_print_text_A_const_66 any

var A_arbace_g2a_print_text_A_const_67 any

var A_arbace_g2a_print_text_A_const_68 any

var A_arbace_g2a_print_text_A_const_69 any

var A_arbace_g2a_print_text_A_const_70 any

var A_arbace_g2a_print_text_A_const_71 any

var A_arbace_g2a_print_text_A_const_72 any

var A_arbace_g2a_print_text_A_const_73 any

var A_arbace_g2a_print_text_A_const_74 any

var A_arbace_g2a_print_text_A_const_75 any

var A_arbace_g2a_print_text_A_const_76 *lang.Var

var A_arbace_g2a_print_text_A_const_77 *lang.Var

var A_arbace_g2a_print_text_A_const_78 *lang.Var

var A_arbace_g2a_print_text_A_const_79 *lang.Var

var A_arbace_g2a_print_text_A_const_80 *lang.Var

var A_arbace_g2a_print_text_A_const_81 *lang.Keyword

var A_arbace_g2a_print_text_A_const_82 *lang.Keyword

var A_arbace_g2a_print_text_A_const_83 *lang.Var

var A_arbace_g2a_print_text_A_const_84 *lang.Keyword

var A_arbace_g2a_print_text_A_const_85 *lang.Var

var A_arbace_g2a_print_text_A_const_86 *lang.Var

var A_arbace_g2a_print_text_A_const_87 *lang.Var

var A_arbace_g2a_print_text_A_const_88 *lang.Var

var A_arbace_g2a_print_text_A_const_89 *lang.Var

var A_arbace_g2a_print_text_A_const_90 any

var A_arbace_g2a_print_text_A_const_91 any

var A_arbace_g2a_print_text_A_const_92 any

var A_arbace_g2a_print_text_A_const_93 *lang.Var

var A_arbace_g2a_print_text_A_const_94 *lang.Var

var A_arbace_g2a_print_text_A_const_95 *lang.Var

var A_arbace_g2a_print_text_A_const_96 *lang.Var

var A_arbace_g2a_print_text_A_const_97 *lang.Var

var A_arbace_g2a_print_text_A_const_98 *lang.Var

var A_arbace_g2a_print_text_A_const_99 *lang.Var

var A_arbace_g2a_print_text_A_const_100 any

var A_arbace_g2a_print_text_A_const_101 *lang.Var

var A_arbace_g2a_print_text_A_const_102 *lang.Var

var A_arbace_g2a_print_text_A_const_103 *lang.Var

var A_arbace_g2a_print_text_A_const_104 *lang.Var

var A_arbace_g2a_print_text_A_const_105 *lang.Var

var A_arbace_g2a_print_text_A_const_106 *lang.Var

var A_arbace_g2a_print_text_A_init jrt.ClassInit

func A_arbace_g2a_print_text_A_Init() { if !A_arbace_g2a_print_text_A_init.Done() { A_arbace_g2a_print_text_A_init.Run(A_arbace_g2a_print_text_A_clinit) } }

func A_arbace_g2a_print_text_A_clinit() { A_arbace_g2a_print_text_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_g2a_print_text_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_g2a_print_text_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_print_text_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_g2a_print_text_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_g2a_print_text_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_g2a_print_text_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_g2a_print_text_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_g2a_print_text_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_g2a_print_text_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_g2a_print_text_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_g2a_print_text_A_const_11 = jrt.Long_ValueOf_J__Long(32).Ref(); A_arbace_g2a_print_text_A_const_12 = jrt.Long_ValueOf_J__Long(127).Ref(); A_arbace_g2a_print_text_A_const_13 = lang.RT_Var_String_String__Var(Lit_9, Lit_15); A_arbace_g2a_print_text_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_g2a_print_text_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_g2a_print_text_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_g2a_print_text_A_const_17 = jrt.Character_ValueOf_C__Character(48).Ref(); A_arbace_g2a_print_text_A_const_18 = lang.RT_Var_String_String__Var(Lit_9, Lit_18); A_arbace_g2a_print_text_A_const_19 = lang.RT_Var_String_String__Var(Lit_9, Lit_19); A_arbace_g2a_print_text_A_const_20 = lang.RT_Keyword_String_String__Keyword(nil, Lit_20); A_arbace_g2a_print_text_A_const_21 = jrt.Long_ValueOf_J__Long(2).Ref(); A_arbace_g2a_print_text_A_const_22 = jrt.Long_ValueOf_J__Long(4).Ref(); A_arbace_g2a_print_text_A_const_23 = jrt.Long_ValueOf_J__Long(8).Ref(); A_arbace_g2a_print_text_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_g2a_print_text_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_g2a_print_text_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_g2a_print_text_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_g2a_print_text_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_g2a_print_text_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_g2a_print_text_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_g2a_print_text_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_g2a_print_text_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_g2a_print_text_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_g2a_print_text_A_const_34 = lang.RT_Var_String_String__Var(Lit_9, Lit_31); A_arbace_g2a_print_text_A_const_35 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); A_arbace_g2a_print_text_A_const_36 = jrt.Character_ValueOf_C__Character(34).Ref(); A_arbace_g2a_print_text_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_g2a_print_text_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_g2a_print_text_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_g2a_print_text_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_g2a_print_text_A_const_41 = jrt.Long_ValueOf_J__Long(96).Ref(); A_arbace_g2a_print_text_A_const_42 = jrt.Long_ValueOf_J__Long(13).Ref(); A_arbace_g2a_print_text_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_g2a_print_text_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_g2a_print_text_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_g2a_print_text_A_const_46 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_g2a_print_text_A_const_47 = jrt.Long_ValueOf_J__Long(255).Ref(); A_arbace_g2a_print_text_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_40); A_arbace_g2a_print_text_A_const_49 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); A_arbace_g2a_print_text_A_const_50 = jrt.Character_ValueOf_C__Character(39).Ref(); A_arbace_g2a_print_text_A_const_51 = lang.RT_Var_String_String__Var(Lit_3, Lit_42); A_arbace_g2a_print_text_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_g2a_print_text_A_const_53 = lang.RT_Var_String_String__Var(Lit_3, Lit_44); A_arbace_g2a_print_text_A_const_54 = lang.RT_Var_String_String__Var(Lit_9, Lit_45); A_arbace_g2a_print_text_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_g2a_print_text_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_g2a_print_text_A_const_57 = lang.RT_Var_String_String__Var(Lit_9, Lit_48); A_arbace_g2a_print_text_A_const_58 = lang.RT_Var_String_String__Var(Lit_9, Lit_49); A_arbace_g2a_print_text_A_const_59 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_g2a_print_text_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_g2a_print_text_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_g2a_print_text_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_g2a_print_text_A_const_63 = lang.RT_Var_String_String__Var(Lit_9, Lit_54); A_arbace_g2a_print_text_A_const_64 = jrt.Character_ValueOf_C__Character(9).Ref(); A_arbace_g2a_print_text_A_const_65 = jrt.Character_ValueOf_C__Character(57344).Ref(); A_arbace_g2a_print_text_A_const_66 = jrt.Character_ValueOf_C__Character(10).Ref(); A_arbace_g2a_print_text_A_const_67 = jrt.Character_ValueOf_C__Character(57345).Ref(); A_arbace_g2a_print_text_A_const_68 = jrt.Character_ValueOf_C__Character(11).Ref(); A_arbace_g2a_print_text_A_const_69 = jrt.Character_ValueOf_C__Character(57346).Ref(); A_arbace_g2a_print_text_A_const_70 = jrt.Character_ValueOf_C__Character(12).Ref(); A_arbace_g2a_print_text_A_const_71 = jrt.Character_ValueOf_C__Character(57347).Ref(); A_arbace_g2a_print_text_A_const_72 = jrt.Character_ValueOf_C__Character(57344).Ref(); A_arbace_g2a_print_text_A_const_73 = jrt.Character_ValueOf_C__Character(57345).Ref(); A_arbace_g2a_print_text_A_const_74 = jrt.Character_ValueOf_C__Character(57346).Ref(); A_arbace_g2a_print_text_A_const_75 = jrt.Character_ValueOf_C__Character(57347).Ref(); A_arbace_g2a_print_text_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_g2a_print_text_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_g2a_print_text_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_g2a_print_text_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_g2a_print_text_A_const_80 = lang.RT_Var_String_String__Var(Lit_9, Lit_59); A_arbace_g2a_print_text_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_60); A_arbace_g2a_print_text_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_g2a_print_text_A_const_83 = lang.RT_Var_String_String__Var(Lit_9, Lit_62); A_arbace_g2a_print_text_A_const_84 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_g2a_print_text_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_g2a_print_text_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_g2a_print_text_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_g2a_print_text_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_g2a_print_text_A_const_89 = lang.RT_Var_String_String__Var(Lit_3, Lit_68); A_arbace_g2a_print_text_A_const_90 = jrt.Pattern_Compile_String__Pattern(Lit_69).Ref(); A_arbace_g2a_print_text_A_const_91 = jrt.Long_ValueOf_J__Long(-1).Ref(); A_arbace_g2a_print_text_A_const_92 = jrt.Character_ValueOf_C__Character(32).Ref(); A_arbace_g2a_print_text_A_const_93 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_g2a_print_text_A_const_94 = lang.RT_Var_String_String__Var(Lit_9, Lit_71); A_arbace_g2a_print_text_A_const_95 = lang.RT_Var_String_String__Var(Lit_9, Lit_72); A_arbace_g2a_print_text_A_const_96 = lang.RT_Var_String_String__Var(Lit_9, Lit_73); A_arbace_g2a_print_text_A_const_97 = lang.RT_Var_String_String__Var(Lit_9, Lit_74); A_arbace_g2a_print_text_A_const_98 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_g2a_print_text_A_const_99 = lang.RT_Var_String_String__Var(Lit_9, Lit_76); A_arbace_g2a_print_text_A_const_100 = jrt.Pattern_Compile_String__Pattern(Lit_77).Ref(); A_arbace_g2a_print_text_A_const_101 = lang.RT_Var_String_String__Var(Lit_9, Lit_78); A_arbace_g2a_print_text_A_const_102 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_g2a_print_text_A_const_103 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_g2a_print_text_A_const_104 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_g2a_print_text_A_const_105 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_g2a_print_text_A_const_106 = lang.RT_Var_String_String__Var(Lit_3, Lit_83) }

func A_arbace_g2a_print_text_A_New() *A_arbace_g2a_print_text_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_text_A) Ctor() {}

func (t *A_arbace_g2a_print_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_A_class }

func (t *A_arbace_g2a_print_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_A); return ok }

func A_arbace_g2a_print_text_A_Cast(x any) *A_arbace_g2a_print_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_A_class)) }; return v }



type A_arbace_g2a_print_text_align_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_align_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_align_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_align_A_init jrt.ClassInit

func A_arbace_g2a_print_text_align_A_Init() { if !A_arbace_g2a_print_text_align_A_init.Done() { A_arbace_g2a_print_text_align_A_init.Run(A_arbace_g2a_print_text_align_A_clinit) } }

func A_arbace_g2a_print_text_align_A_clinit() { A_arbace_g2a_print_text_align_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_align_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_align_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_align_A_class }

func (t *A_arbace_g2a_print_text_align_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_align_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_align_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_align_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_align_A); return ok }

func A_arbace_g2a_print_text_align_A_Cast(x any) *A_arbace_g2a_print_text_align_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_align_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_align_A_class)) }; return v }



type A_arbace_g2a_print_text_align_fn__190000080_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_align_fn__190000080_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_align_fn__190000080_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_align_fn__190000080_A_init jrt.ClassInit

func A_arbace_g2a_print_text_align_fn__190000080_A_Init() { if !A_arbace_g2a_print_text_align_fn__190000080_A_init.Done() { A_arbace_g2a_print_text_align_fn__190000080_A_init.Run(A_arbace_g2a_print_text_align_fn__190000080_A_clinit) } }

func A_arbace_g2a_print_text_align_fn__190000080_A_clinit() { A_arbace_g2a_print_text_align_fn__190000080_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_align_fn__190000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_align_fn__190000080_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_align_fn__190000080_A_class }

func (t *A_arbace_g2a_print_text_align_fn__190000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_align_fn__190000080_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_align_fn__190000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_align_fn__190000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_align_fn__190000080_A); return ok }

func A_arbace_g2a_print_text_align_fn__190000080_A_Cast(x any) *A_arbace_g2a_print_text_align_fn__190000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_align_fn__190000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_align_fn__190000080_A_class)) }; return v }



type A_arbace_g2a_print_text_align_block_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_align_block_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_align_block_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_align_block_A_init jrt.ClassInit

func A_arbace_g2a_print_text_align_block_A_Init() { if !A_arbace_g2a_print_text_align_block_A_init.Done() { A_arbace_g2a_print_text_align_block_A_init.Run(A_arbace_g2a_print_text_align_block_A_clinit) } }

func A_arbace_g2a_print_text_align_block_A_clinit() { A_arbace_g2a_print_text_align_block_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_align_block_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_align_block_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_align_block_A_class }

func (t *A_arbace_g2a_print_text_align_block_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_align_block_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_align_block_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_align_block_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_align_block_A); return ok }

func A_arbace_g2a_print_text_align_block_A_Cast(x any) *A_arbace_g2a_print_text_align_block_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_align_block_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_align_block_A_class)) }; return v }



type A_arbace_g2a_print_text_cell_width_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_cell_width_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_cell_width_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_cell_width_A_init jrt.ClassInit

func A_arbace_g2a_print_text_cell_width_A_Init() { if !A_arbace_g2a_print_text_cell_width_A_init.Done() { A_arbace_g2a_print_text_cell_width_A_init.Run(A_arbace_g2a_print_text_cell_width_A_clinit) } }

func A_arbace_g2a_print_text_cell_width_A_clinit() { A_arbace_g2a_print_text_cell_width_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_cell_width_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_cell_width_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_cell_width_A_class }

func (t *A_arbace_g2a_print_text_cell_width_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_cell_width_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_cell_width_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_cell_width_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_cell_width_A); return ok }

func A_arbace_g2a_print_text_cell_width_A_Cast(x any) *A_arbace_g2a_print_text_cell_width_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_cell_width_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_cell_width_A_class)) }; return v }



type A_arbace_g2a_print_text_code_points_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_code_points_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_code_points_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_code_points_A_init jrt.ClassInit

func A_arbace_g2a_print_text_code_points_A_Init() { if !A_arbace_g2a_print_text_code_points_A_init.Done() { A_arbace_g2a_print_text_code_points_A_init.Run(A_arbace_g2a_print_text_code_points_A_clinit) } }

func A_arbace_g2a_print_text_code_points_A_clinit() { A_arbace_g2a_print_text_code_points_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_code_points_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_code_points_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_code_points_A_class }

func (t *A_arbace_g2a_print_text_code_points_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_code_points_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_code_points_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_code_points_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_code_points_A); return ok }

func A_arbace_g2a_print_text_code_points_A_Cast(x any) *A_arbace_g2a_print_text_code_points_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_code_points_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_code_points_A_class)) }; return v }



type A_arbace_g2a_print_text_escape_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_escape_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_escape_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_escape_A_init jrt.ClassInit

func A_arbace_g2a_print_text_escape_A_Init() { if !A_arbace_g2a_print_text_escape_A_init.Done() { A_arbace_g2a_print_text_escape_A_init.Run(A_arbace_g2a_print_text_escape_A_clinit) } }

func A_arbace_g2a_print_text_escape_A_clinit() { A_arbace_g2a_print_text_escape_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_escape_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_escape_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_escape_A_class }

func (t *A_arbace_g2a_print_text_escape_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_escape_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_escape_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_escape_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_escape_A); return ok }

func A_arbace_g2a_print_text_escape_A_Cast(x any) *A_arbace_g2a_print_text_escape_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_escape_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_escape_A_class)) }; return v }



type A_arbace_g2a_print_text_escape_cp_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_escape_cp_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_text_escape_cp_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_escape_cp_A_init jrt.ClassInit

func A_arbace_g2a_print_text_escape_cp_A_Init() { if !A_arbace_g2a_print_text_escape_cp_A_init.Done() { A_arbace_g2a_print_text_escape_cp_A_init.Run(A_arbace_g2a_print_text_escape_cp_A_clinit) } }

func A_arbace_g2a_print_text_escape_cp_A_clinit() { A_arbace_g2a_print_text_escape_cp_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_92, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_escape_cp_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_escape_cp_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_escape_cp_A_class }

func (t *A_arbace_g2a_print_text_escape_cp_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_escape_cp_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_escape_cp_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_escape_cp_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_escape_cp_A); return ok }

func A_arbace_g2a_print_text_escape_cp_A_Cast(x any) *A_arbace_g2a_print_text_escape_cp_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_escape_cp_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_escape_cp_A_class)) }; return v }



type A_arbace_g2a_print_text_eval190000004_A struct{ jrt.Object }

func A_arbace_g2a_print_text_eval190000004_A_New() *A_arbace_g2a_print_text_eval190000004_A { t := &A_arbace_g2a_print_text_eval190000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_text_eval190000004_A) Ctor() {}

func (t *A_arbace_g2a_print_text_eval190000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_eval190000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_eval190000004_A_class }

func (t *A_arbace_g2a_print_text_eval190000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_eval190000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_eval190000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_eval190000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_eval190000004_A); return ok }

func A_arbace_g2a_print_text_eval190000004_A_Cast(x any) *A_arbace_g2a_print_text_eval190000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_eval190000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_eval190000004_A_class)) }; return v }



type A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_init jrt.ClassInit

func A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_Init() { if !A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_init.Done() { A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_init.Run(A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_clinit) } }

func A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_clinit() { A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_class }

func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A); return ok }

func A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_Cast(x any) *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_class)) }; return v }



type A_arbace_g2a_print_text_eval190000008_A struct{ jrt.Object }

func A_arbace_g2a_print_text_eval190000008_A_New() *A_arbace_g2a_print_text_eval190000008_A { t := &A_arbace_g2a_print_text_eval190000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_text_eval190000008_A) Ctor() {}

func (t *A_arbace_g2a_print_text_eval190000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_eval190000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_eval190000008_A_class }

func (t *A_arbace_g2a_print_text_eval190000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_eval190000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_eval190000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_eval190000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_eval190000008_A); return ok }

func A_arbace_g2a_print_text_eval190000008_A_Cast(x any) *A_arbace_g2a_print_text_eval190000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_eval190000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_eval190000008_A_class)) }; return v }



type A_arbace_g2a_print_text_eval190000008_fn__190000009_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_text_eval190000008_fn__190000009_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_eval190000008_fn__190000009_A_init jrt.ClassInit

func A_arbace_g2a_print_text_eval190000008_fn__190000009_A_Init() { if !A_arbace_g2a_print_text_eval190000008_fn__190000009_A_init.Done() { A_arbace_g2a_print_text_eval190000008_fn__190000009_A_init.Run(A_arbace_g2a_print_text_eval190000008_fn__190000009_A_clinit) } }

func A_arbace_g2a_print_text_eval190000008_fn__190000009_A_clinit() { A_arbace_g2a_print_text_eval190000008_fn__190000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_eval190000008_fn__190000009_A_class }

func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_eval190000008_fn__190000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_eval190000008_fn__190000009_A); return ok }

func A_arbace_g2a_print_text_eval190000008_fn__190000009_A_Cast(x any) *A_arbace_g2a_print_text_eval190000008_fn__190000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_eval190000008_fn__190000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_eval190000008_fn__190000009_A_class)) }; return v }



type A_arbace_g2a_print_text_float_kind_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_float_kind_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_float_kind_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_float_kind_A_init jrt.ClassInit

func A_arbace_g2a_print_text_float_kind_A_Init() { if !A_arbace_g2a_print_text_float_kind_A_init.Done() { A_arbace_g2a_print_text_float_kind_A_init.Run(A_arbace_g2a_print_text_float_kind_A_clinit) } }

func A_arbace_g2a_print_text_float_kind_A_clinit() { A_arbace_g2a_print_text_float_kind_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_float_kind_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_float_kind_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_float_kind_A_class }

func (t *A_arbace_g2a_print_text_float_kind_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_float_kind_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_float_kind_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_float_kind_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_float_kind_A); return ok }

func A_arbace_g2a_print_text_float_kind_A_Cast(x any) *A_arbace_g2a_print_text_float_kind_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_float_kind_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_float_kind_A_class)) }; return v }



type A_arbace_g2a_print_text_format_block_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_format_block_A) Is_Compiler_AOTF5() {}

var A_arbace_g2a_print_text_format_block_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_format_block_A_init jrt.ClassInit

func A_arbace_g2a_print_text_format_block_A_Init() { if !A_arbace_g2a_print_text_format_block_A_init.Done() { A_arbace_g2a_print_text_format_block_A_init.Run(A_arbace_g2a_print_text_format_block_A_clinit) } }

func A_arbace_g2a_print_text_format_block_A_clinit() { A_arbace_g2a_print_text_format_block_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_format_block_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_format_block_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_format_block_A_class }

func (t *A_arbace_g2a_print_text_format_block_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_format_block_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_format_block_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_format_block_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_format_block_A); return ok }

func A_arbace_g2a_print_text_format_block_A_Cast(x any) *A_arbace_g2a_print_text_format_block_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_format_block_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_format_block_A_class)) }; return v }



type A_arbace_g2a_print_text_format_block_fn__190000075_A struct{ jrt.Object; F_column int32; F_this, F_line1, F_lines any }

func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_text_format_block_fn__190000075_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_format_block_fn__190000075_A_init jrt.ClassInit

func A_arbace_g2a_print_text_format_block_fn__190000075_A_Init() { if !A_arbace_g2a_print_text_format_block_fn__190000075_A_init.Done() { A_arbace_g2a_print_text_format_block_fn__190000075_A_init.Run(A_arbace_g2a_print_text_format_block_fn__190000075_A_clinit) } }

func A_arbace_g2a_print_text_format_block_fn__190000075_A_clinit() { A_arbace_g2a_print_text_format_block_fn__190000075_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_format_block_fn__190000075_A_class }

func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_format_block_fn__190000075_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_format_block_fn__190000075_A); return ok }

func A_arbace_g2a_print_text_format_block_fn__190000075_A_Cast(x any) *A_arbace_g2a_print_text_format_block_fn__190000075_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_format_block_fn__190000075_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_format_block_fn__190000075_A_class)) }; return v }



type A_arbace_g2a_print_text_go_byte_string_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_go_byte_string_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_go_byte_string_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_go_byte_string_A_init jrt.ClassInit

func A_arbace_g2a_print_text_go_byte_string_A_Init() { if !A_arbace_g2a_print_text_go_byte_string_A_init.Done() { A_arbace_g2a_print_text_go_byte_string_A_init.Run(A_arbace_g2a_print_text_go_byte_string_A_clinit) } }

func A_arbace_g2a_print_text_go_byte_string_A_clinit() { A_arbace_g2a_print_text_go_byte_string_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_go_byte_string_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_go_byte_string_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_go_byte_string_A_class }

func (t *A_arbace_g2a_print_text_go_byte_string_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_go_byte_string_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_go_byte_string_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_go_byte_string_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_go_byte_string_A); return ok }

func A_arbace_g2a_print_text_go_byte_string_A_Cast(x any) *A_arbace_g2a_print_text_go_byte_string_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_go_byte_string_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_go_byte_string_A_class)) }; return v }



type A_arbace_g2a_print_text_go_float_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_go_float_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_go_float_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_go_float_A_init jrt.ClassInit

func A_arbace_g2a_print_text_go_float_A_Init() { if !A_arbace_g2a_print_text_go_float_A_init.Done() { A_arbace_g2a_print_text_go_float_A_init.Run(A_arbace_g2a_print_text_go_float_A_clinit) } }

func A_arbace_g2a_print_text_go_float_A_clinit() { A_arbace_g2a_print_text_go_float_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_go_float_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_go_float_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_go_float_A_class }

func (t *A_arbace_g2a_print_text_go_float_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_go_float_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_go_float_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_go_float_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_go_float_A); return ok }

func A_arbace_g2a_print_text_go_float_A_Cast(x any) *A_arbace_g2a_print_text_go_float_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_go_float_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_go_float_A_class)) }; return v }



type A_arbace_g2a_print_text_go_number_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_go_number_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_go_number_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_go_number_A_init jrt.ClassInit

func A_arbace_g2a_print_text_go_number_A_Init() { if !A_arbace_g2a_print_text_go_number_A_init.Done() { A_arbace_g2a_print_text_go_number_A_init.Run(A_arbace_g2a_print_text_go_number_A_clinit) } }

func A_arbace_g2a_print_text_go_number_A_clinit() { A_arbace_g2a_print_text_go_number_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_go_number_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_go_number_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_go_number_A_class }

func (t *A_arbace_g2a_print_text_go_number_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_go_number_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_go_number_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_go_number_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_go_number_A); return ok }

func A_arbace_g2a_print_text_go_number_A_Cast(x any) *A_arbace_g2a_print_text_go_number_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_go_number_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_go_number_A_class)) }; return v }



type A_arbace_g2a_print_text_go_printable_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_go_printable_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_print_text_go_printable_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_print_text_go_printable_QMARK__A_Init() { if !A_arbace_g2a_print_text_go_printable_QMARK__A_init.Done() { A_arbace_g2a_print_text_go_printable_QMARK__A_init.Run(A_arbace_g2a_print_text_go_printable_QMARK__A_clinit) } }

func A_arbace_g2a_print_text_go_printable_QMARK__A_clinit() { A_arbace_g2a_print_text_go_printable_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_go_printable_QMARK__A_class }

func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_go_printable_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_go_printable_QMARK__A); return ok }

func A_arbace_g2a_print_text_go_printable_QMARK__A_Cast(x any) *A_arbace_g2a_print_text_go_printable_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_go_printable_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_go_printable_QMARK__A_class)) }; return v }



type A_arbace_g2a_print_text_go_rune_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_go_rune_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_go_rune_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_go_rune_A_init jrt.ClassInit

func A_arbace_g2a_print_text_go_rune_A_Init() { if !A_arbace_g2a_print_text_go_rune_A_init.Done() { A_arbace_g2a_print_text_go_rune_A_init.Run(A_arbace_g2a_print_text_go_rune_A_clinit) } }

func A_arbace_g2a_print_text_go_rune_A_clinit() { A_arbace_g2a_print_text_go_rune_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_go_rune_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_go_rune_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_go_rune_A_class }

func (t *A_arbace_g2a_print_text_go_rune_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_go_rune_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_go_rune_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_go_rune_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_go_rune_A); return ok }

func A_arbace_g2a_print_text_go_rune_A_Cast(x any) *A_arbace_g2a_print_text_go_rune_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_go_rune_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_go_rune_A_class)) }; return v }



type A_arbace_g2a_print_text_go_string_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_go_string_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_go_string_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_go_string_A_init jrt.ClassInit

func A_arbace_g2a_print_text_go_string_A_Init() { if !A_arbace_g2a_print_text_go_string_A_init.Done() { A_arbace_g2a_print_text_go_string_A_init.Run(A_arbace_g2a_print_text_go_string_A_clinit) } }

func A_arbace_g2a_print_text_go_string_A_clinit() { A_arbace_g2a_print_text_go_string_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_go_string_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_go_string_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_go_string_A_class }

func (t *A_arbace_g2a_print_text_go_string_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_go_string_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_go_string_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_go_string_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_go_string_A); return ok }

func A_arbace_g2a_print_text_go_string_A_Cast(x any) *A_arbace_g2a_print_text_go_string_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_go_string_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_go_string_A_class)) }; return v }



type A_arbace_g2a_print_text_hex_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_hex_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_print_text_hex_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_hex_A_init jrt.ClassInit

func A_arbace_g2a_print_text_hex_A_Init() { if !A_arbace_g2a_print_text_hex_A_init.Done() { A_arbace_g2a_print_text_hex_A_init.Run(A_arbace_g2a_print_text_hex_A_clinit) } }

func A_arbace_g2a_print_text_hex_A_clinit() { A_arbace_g2a_print_text_hex_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_hex_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_hex_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_hex_A_class }

func (t *A_arbace_g2a_print_text_hex_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_hex_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_hex_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_hex_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_hex_A); return ok }

func A_arbace_g2a_print_text_hex_A_Cast(x any) *A_arbace_g2a_print_text_hex_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_hex_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_hex_A_class)) }; return v }



type A_arbace_g2a_print_text_negative_number_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_negative_number_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_print_text_negative_number_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_print_text_negative_number_QMARK__A_Init() { if !A_arbace_g2a_print_text_negative_number_QMARK__A_init.Done() { A_arbace_g2a_print_text_negative_number_QMARK__A_init.Run(A_arbace_g2a_print_text_negative_number_QMARK__A_clinit) } }

func A_arbace_g2a_print_text_negative_number_QMARK__A_clinit() { A_arbace_g2a_print_text_negative_number_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_negative_number_QMARK__A_class }

func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_negative_number_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_negative_number_QMARK__A); return ok }

func A_arbace_g2a_print_text_negative_number_QMARK__A_Cast(x any) *A_arbace_g2a_print_text_negative_number_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_negative_number_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_negative_number_QMARK__A_class)) }; return v }



type A_arbace_g2a_print_text_parse_lines_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_parse_lines_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_parse_lines_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_A_init jrt.ClassInit

func A_arbace_g2a_print_text_parse_lines_A_Init() { if !A_arbace_g2a_print_text_parse_lines_A_init.Done() { A_arbace_g2a_print_text_parse_lines_A_init.Run(A_arbace_g2a_print_text_parse_lines_A_clinit) } }

func A_arbace_g2a_print_text_parse_lines_A_clinit() { A_arbace_g2a_print_text_parse_lines_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_parse_lines_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_parse_lines_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_parse_lines_A_class }

func (t *A_arbace_g2a_print_text_parse_lines_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_parse_lines_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_parse_lines_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_parse_lines_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_parse_lines_A); return ok }

func A_arbace_g2a_print_text_parse_lines_A_Cast(x any) *A_arbace_g2a_print_text_parse_lines_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_parse_lines_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_parse_lines_A_class)) }; return v }



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_init jrt.ClassInit

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_Init() { if !A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_init.Done() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_init.Run(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_clinit) } }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_clinit() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_class }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A); return ok }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_Cast(x any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_class)) }; return v }



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A struct{ jrt.Object; F_iter__190000051, F_s__190000052 any }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_init jrt.ClassInit

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_Init() { if !A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_init.Done() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_init.Run(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_clinit) } }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_clinit() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A); return ok }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_Cast(x any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_class)) }; return v }



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A struct{ jrt.Object; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__190000054 any }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_init jrt.ClassInit

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_Init() { if !A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_init.Done() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_init.Run(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_clinit) } }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_clinit() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_class }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A); return ok }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_Cast(x any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_class)) }; return v }



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A struct{ jrt.Object; F_n int32; F_line any }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_init jrt.ClassInit

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_Init() { if !A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_init.Done() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_init.Run(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_clinit) } }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_clinit() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_class }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A); return ok }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_Cast(x any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_class)) }; return v }



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A struct{ jrt.Object; F_n int32; F_line any }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_init jrt.ClassInit

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_Init() { if !A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_init.Done() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_init.Run(A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_clinit) } }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_clinit() { A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_class }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A); return ok }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_Cast(x any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_class)) }; return v }



type A_arbace_g2a_print_text_pow2_exponent_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_pow2_exponent_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_pow2_exponent_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_pow2_exponent_A_init jrt.ClassInit

func A_arbace_g2a_print_text_pow2_exponent_A_Init() { if !A_arbace_g2a_print_text_pow2_exponent_A_init.Done() { A_arbace_g2a_print_text_pow2_exponent_A_init.Run(A_arbace_g2a_print_text_pow2_exponent_A_clinit) } }

func A_arbace_g2a_print_text_pow2_exponent_A_clinit() { A_arbace_g2a_print_text_pow2_exponent_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_pow2_exponent_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_pow2_exponent_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_pow2_exponent_A_class }

func (t *A_arbace_g2a_print_text_pow2_exponent_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_pow2_exponent_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_pow2_exponent_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_pow2_exponent_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_pow2_exponent_A); return ok }

func A_arbace_g2a_print_text_pow2_exponent_A_Cast(x any) *A_arbace_g2a_print_text_pow2_exponent_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_pow2_exponent_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_pow2_exponent_A_class)) }; return v }



type A_arbace_g2a_print_text_raw_string_ok_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_raw_string_ok_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_print_text_raw_string_ok_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_print_text_raw_string_ok_QMARK__A_Init() { if !A_arbace_g2a_print_text_raw_string_ok_QMARK__A_init.Done() { A_arbace_g2a_print_text_raw_string_ok_QMARK__A_init.Run(A_arbace_g2a_print_text_raw_string_ok_QMARK__A_clinit) } }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__A_clinit() { A_arbace_g2a_print_text_raw_string_ok_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_raw_string_ok_QMARK__A_class }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_raw_string_ok_QMARK__A); return ok }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__A_Cast(x any) *A_arbace_g2a_print_text_raw_string_ok_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_raw_string_ok_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_raw_string_ok_QMARK__A_class)) }; return v }



type A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_init jrt.ClassInit

func A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_Init() { if !A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_init.Done() { A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_init.Run(A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_clinit) } }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_clinit() { A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_class }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A); return ok }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_Cast(x any) *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_class)) }; return v }



type A_arbace_g2a_print_text_strip_2_5_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_strip_2_5_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_strip_2_5_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_strip_2_5_A_init jrt.ClassInit

func A_arbace_g2a_print_text_strip_2_5_A_Init() { if !A_arbace_g2a_print_text_strip_2_5_A_init.Done() { A_arbace_g2a_print_text_strip_2_5_A_init.Run(A_arbace_g2a_print_text_strip_2_5_A_clinit) } }

func A_arbace_g2a_print_text_strip_2_5_A_clinit() { A_arbace_g2a_print_text_strip_2_5_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_strip_2_5_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_strip_2_5_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_strip_2_5_A_class }

func (t *A_arbace_g2a_print_text_strip_2_5_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_strip_2_5_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_strip_2_5_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_strip_2_5_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_strip_2_5_A); return ok }

func A_arbace_g2a_print_text_strip_2_5_A_Cast(x any) *A_arbace_g2a_print_text_strip_2_5_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_strip_2_5_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_strip_2_5_A_class)) }; return v }



type A_arbace_g2a_print_text_unescape_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_unescape_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_print_text_unescape_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_unescape_A_init jrt.ClassInit

func A_arbace_g2a_print_text_unescape_A_Init() { if !A_arbace_g2a_print_text_unescape_A_init.Done() { A_arbace_g2a_print_text_unescape_A_init.Run(A_arbace_g2a_print_text_unescape_A_clinit) } }

func A_arbace_g2a_print_text_unescape_A_clinit() { A_arbace_g2a_print_text_unescape_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_unescape_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_unescape_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_unescape_A_class }

func (t *A_arbace_g2a_print_text_unescape_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_unescape_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_unescape_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_unescape_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_unescape_A); return ok }

func A_arbace_g2a_print_text_unescape_A_Cast(x any) *A_arbace_g2a_print_text_unescape_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_unescape_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_unescape_A_class)) }; return v }



type A_arbace_g2a_print_text_write_lines_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_write_lines_A) Is_Compiler_AOTF5() {}

var A_arbace_g2a_print_text_write_lines_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_write_lines_A_init jrt.ClassInit

func A_arbace_g2a_print_text_write_lines_A_Init() { if !A_arbace_g2a_print_text_write_lines_A_init.Done() { A_arbace_g2a_print_text_write_lines_A_init.Run(A_arbace_g2a_print_text_write_lines_A_clinit) } }

func A_arbace_g2a_print_text_write_lines_A_clinit() { A_arbace_g2a_print_text_write_lines_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_write_lines_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_write_lines_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_write_lines_A_class }

func (t *A_arbace_g2a_print_text_write_lines_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_write_lines_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_write_lines_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_write_lines_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_write_lines_A); return ok }

func A_arbace_g2a_print_text_write_lines_A_Cast(x any) *A_arbace_g2a_print_text_write_lines_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_write_lines_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_write_lines_A_class)) }; return v }



type A_arbace_g2a_print_text_write_padding_A struct{ jrt.Object }

func (t *A_arbace_g2a_print_text_write_padding_A) Is_Compiler_AOTF4() {}

var A_arbace_g2a_print_text_write_padding_A_fn_class *jrt.Class

var A_arbace_g2a_print_text_write_padding_A_init jrt.ClassInit

func A_arbace_g2a_print_text_write_padding_A_Init() { if !A_arbace_g2a_print_text_write_padding_A_init.Done() { A_arbace_g2a_print_text_write_padding_A_init.Run(A_arbace_g2a_print_text_write_padding_A_clinit) } }

func A_arbace_g2a_print_text_write_padding_A_clinit() { A_arbace_g2a_print_text_write_padding_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_print_text_write_padding_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_write_padding_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_write_padding_A_class }

func (t *A_arbace_g2a_print_text_write_padding_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_write_padding_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_write_padding_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_write_padding_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_write_padding_A); return ok }

func A_arbace_g2a_print_text_write_padding_A_Cast(x any) *A_arbace_g2a_print_text_write_padding_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_write_padding_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_write_padding_A_class)) }; return v }
