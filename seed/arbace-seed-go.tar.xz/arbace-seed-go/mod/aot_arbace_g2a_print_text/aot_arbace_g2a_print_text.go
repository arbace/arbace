//line aot_arbace_g2a_print_text.ae:1
package aot_arbace_g2a_print_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_New() *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_g2a_print_text_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_text_A_const_2); lang.IFn_Cast(A_arbace_g2a_print_text_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_text_A_const_3); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_16)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_17)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp6 != nil { panic(tmp6) }; return tmp3 }
//line :1:1
func A_arbace_g2a_print_text_eval190000008_fn__190000009_A_New() *A_arbace_g2a_print_text_eval190000008_fn__190000009_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_eval190000008_fn__190000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_print_text_eval190000008_fn__190000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_text_A_const_8), A_arbace_g2a_print_text_A_const_6.GetRawRoot__O(), A_arbace_g2a_print_text_A_const_7) }
































func A_arbace_g2a_print_text_go_printable_QMARK__A_New() *A_arbace_g2a_print_text_go_printable_QMARK__A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_go_printable_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_g2a_print_text_go_printable_QMARK__A) Invoke_O_O__O(self, p_cp__0 any) any { var cp__0 int64 = lang.RT_LongCast_O__J(p_cp__0); var or__1927000174__auto____2 bool = lang.Numbers_Equiv_J_J__Z(cp__0, 32); if or__1927000174__auto____2 {



	return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_9.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_text_A_const_11; var or__1927000174__auto____3 any = tmp1.Invoke_O_O_O__O(tmp2, jrt.Long_ValueOf_J__Long(cp__0).Ref(), A_arbace_g2a_print_text_A_const_12); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {

		return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_text_A_const_13.GetRawRoot__O(), jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_I__I(jrt.Character_GetType_I__I(lang.RT_IntCast_J__I(cp__0)))).Ref()) } } }

func A_arbace_g2a_print_text_hex_A_New() *A_arbace_g2a_print_text_hex_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_hex_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_g2a_print_text_hex_A) Ctor() {}
//line :42:1
func (t *A_arbace_g2a_print_text_hex_A) Invoke_O_O_O__O(self, p_n__0, p_width__1 any) any { var n__0 int64 = lang.RT_LongCast_O__J(p_n__0); var width__1 int64 = lang.RT_LongCast_O__J(p_width__1); var s__3 any = jrt.Long_ToHexString_J__String(n__0).Ref(); return /*line :44:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_text_A_const_15.GetRawRoot__O(), lang.IFn_Cast(A_arbace_g2a_print_text_A_const_16.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J_J__J(width__1, int64(lang.RT_Count_O__I(s__3)))).Ref(), A_arbace_g2a_print_text_A_const_17)), s__3)).Ref() }

func A_arbace_g2a_print_text_escape_cp_A_New() *A_arbace_g2a_print_text_escape_cp_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_escape_cp_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_g2a_print_text_escape_cp_A) Ctor() {}
//line :46:1
func (t *A_arbace_g2a_print_text_escape_cp_A) Invoke_O_O_O__O(self, p_cp__0, quote__1 any) any { var cp__0 int64 = lang.RT_LongCast_O__J(p_cp__0); var G__190000014__3_ int32 = lang.RT_IntCast_J__I(cp__0); switch G__190000014__3_ {


case 7: return Lit_4; case 8: return Lit_5; case 9: return Lit_6; case 10: return Lit_7; case 11: return Lit_8; case 12: return Lit_9; case 13: return Lit_10; case 92: return Lit_11; default:}; if

	lang.Numbers_Equiv_J_J__Z(cp__0, lang.RT_LongCast_I__J(lang.RT_IntCast_O__I(quote__1))) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, quote__1)).Ref() } else {
//line :51:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(cp__0).Ref())) { return jrt.String_New_C1(jrt.Character_ToChars_I__C1(lang.RT_IntCast_J__I(cp__0))) } else { if lang.Numbers_Lt_J_J__Z(cp__0, 128) {


				return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(cp__0).Ref(), A_arbace_g2a_print_text_A_const_21))).Ref() } else {
//line :51:1
					if lang.Numbers_Lte_J_J__Z(cp__0, 65535) {



						return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(cp__0).Ref(), A_arbace_g2a_print_text_A_const_22))).Ref() } else {
//line :51:1
							if A_arbace_g2a_print_text_A_const_20 != nil {




								return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(cp__0).Ref(), A_arbace_g2a_print_text_A_const_23))).Ref() } else {
//line :51:1
									return nil } } } } } }






func A_arbace_g2a_print_text_code_points_A_New() *A_arbace_g2a_print_text_code_points_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_code_points_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_g2a_print_text_code_points_A) Ctor() {}
//line :58:1
func (t *A_arbace_g2a_print_text_code_points_A) Invoke_O_O__O(self, s__0 any) any { { var i__2 int64 = 0; var acc__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_24.GetRawRoot__O()); var tmp2 *lang.PersistentVector



	lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; acc__3 = tmp1.Invoke_O__O(tmp2.Ref())
//line :58:1
L1: for {




	if lang.Numbers_Lt_J_J__Z(i__2, int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { var cp__4 int32 = jrt.NN(jrt.String_Cast(s__0)).CodePointAt_I__I(lang.RT_IntCast_J__I(i__2)); var tmp3 bool; var and__1927000168__auto____5 bool = lang.Numbers_Gte_J_J__Z(int64(cp__4), 55296)

		if and__1927000168__auto____5 { tmp3 = lang.Numbers_Lte_J_J__Z(int64(cp__4), 57343) } else { tmp3 = and__1927000168__auto____5 }; if tmp3 { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(s__0))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_text_A_const_28, s__0))))))
		}
		i__2, acc__3 = lang.Numbers_Add_J_J__J(i__2, int64(jrt.Character_CharCount_I__I(cp__4))), lang.IFn_Cast(A_arbace_g2a_print_text_A_const_29.GetRawRoot__O()).Invoke_O_O__O(acc__3, jrt.Integer_ValueOf_I__Integer(cp__4).Ref()); continue L1 } else {
			return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_25.GetRawRoot__O()).Invoke_O__O(acc__3) } } }; /*line :58:1*/panic("a2g: unreachable") }











func A_arbace_g2a_print_text_go_string_A_New() *A_arbace_g2a_print_text_go_string_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_go_string_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_g2a_print_text_go_string_A) Ctor() {}
//line :70:1
func (t *A_arbace_g2a_print_text_go_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_23); var seq_190000017__3 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_34.GetRawRoot__O()).Invoke_O__O(s__0)); var chunk_190000018__4 any; var count_190000019__5 int64 = 0; var i_190000020__6 int64 = 0; L1: for {



	if lang.Numbers_Lt_J_J__Z(i_190000020__6, count_190000019__5) { var cp__7 any = lang.Indexed_Cast(chunk_190000018__4).Nth_I__O(lang.RT_IntCast_J__I(i_190000020__6))
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__7, A_arbace_g2a_print_text_A_const_36)))
//line :74:1
		seq_190000017__3, chunk_190000018__4, count_190000019__5, i_190000020__6 = seq_190000017__3, chunk_190000018__4, count_190000019__5, lang.Numbers_Unchecked_inc_J__J(i_190000020__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_190000017__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_190000017__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_190000017__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_190000017__8); seq_190000017__3, chunk_190000018__4, count_190000019__5, i_190000020__6 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_190000017__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cp__9 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_190000017__8)
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__9, A_arbace_g2a_print_text_A_const_36)))
//line :74:1
			seq_190000017__3, chunk_190000018__4, count_190000019__5, i_190000020__6 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_190000017__8), nil, 0, 0; continue L1 } } }
//line :70:1
	break L1 };





	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_23); return /*line :77:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_g2a_print_text_raw_string_ok_QMARK__A_New() *A_arbace_g2a_print_text_raw_string_ok_QMARK__A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_raw_string_ok_QMARK__A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) Ctor() {}
//line :79:1
func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_g2a_print_text_A_const_34.GetRawRoot__O()).Invoke_O__O(s__0)) }
//line :83:1
func A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_New() *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) Ctor() {}
//line :83:1
func (t *A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A) Invoke_O_O__O(self, cp__1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(cp__1, A_arbace_g2a_print_text_A_const_41); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(cp__1, A_arbace_g2a_print_text_A_const_42); if jrt.A2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = lang.Numbers_Equiv_O_J__Z(cp__1, 9)
														if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool = lang.Numbers_Equiv_O_J__Z(cp__1, 10); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_18.GetRawRoot__O()).Invoke_O__O(cp__1) } } } else {
//line :83:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_g2a_print_text_go_byte_string_A_New() *A_arbace_g2a_print_text_go_byte_string_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_go_byte_string_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_g2a_print_text_go_byte_string_A) Ctor() {}
//line :87:1
func (t *A_arbace_g2a_print_text_go_byte_string_A) Invoke_O_O__O(self, parts__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_23); var seq_190000025__3 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(parts__0); var chunk_190000026__4 any; var count_190000027__5 int64 = 0; var i_190000028__6 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z(i_190000028__6, count_190000027__5) { var p__7 any = lang.Indexed_Cast(chunk_190000026__4).Nth_I__O(lang.RT_IntCast_J__I(i_190000028__6))
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_43.GetRawRoot__O()).Invoke_O__O(p__7)) { var seq_190000029__8 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_34.GetRawRoot__O()).Invoke_O__O(p__7)); var chunk_190000030__9 any; var count_190000031__10 int64 = 0; var i_190000032__11 int64 = 0; L2: for {
			if lang.Numbers_Lt_J_J__Z(i_190000032__11, count_190000031__10) { var cp__12 any = lang.Indexed_Cast(chunk_190000030__9).Nth_I__O(lang.RT_IntCast_J__I(i_190000032__11)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__12, A_arbace_g2a_print_text_A_const_36))); seq_190000029__8, chunk_190000030__9, count_190000031__10, i_190000032__11 = seq_190000029__8, chunk_190000030__9, count_190000031__10, lang.Numbers_Unchecked_inc_J__J(i_190000032__11); continue L2 } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_190000029__8); if jrt.A2g_Truth(temp__1927000414__auto____12) { var seq_190000029__13 any = temp__1927000414__auto____12; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_190000029__13)) { var c__1927000678__auto____14 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_190000029__13); seq_190000029__8, chunk_190000030__9, count_190000031__10, i_190000032__11 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_190000029__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var cp__14 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_190000029__13); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__14, A_arbace_g2a_print_text_A_const_36))); seq_190000029__8, chunk_190000030__9, count_190000031__10, i_190000032__11 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_190000029__13), nil, 0, 0; continue L2 } } }
//line :93:1
			break L2 } } else { var tmp1 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_44.GetRawRoot__O()).Invoke_O__O(p__7)

				if jrt.A2g_Truth(and__1927000168__auto____8) { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_print_text_A_const_46, p__7, A_arbace_g2a_print_text_A_const_47) } else { tmp1 = and__1927000168__auto____8 }
//line :93:1
				if jrt.A2g_Truth(tmp1) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(p__7)).Ref(), A_arbace_g2a_print_text_A_const_21)))) } else {
//line :93:1
						if A_arbace_g2a_print_text_A_const_20 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(p__7))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_text_A_const_48, p__7)))))) } } }
//line :92:1
		seq_190000025__3, chunk_190000026__4, count_190000027__5, i_190000028__6 = seq_190000025__3, chunk_190000026__4, count_190000027__5, lang.Numbers_Unchecked_inc_J__J(i_190000028__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_190000025__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_190000025__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_190000025__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_190000025__8); seq_190000025__3, chunk_190000026__4, count_190000027__5, i_190000028__6 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_190000025__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var p__9 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_190000025__8)
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_43.GetRawRoot__O()).Invoke_O__O(p__9)) { var seq_190000033__10 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_34.GetRawRoot__O()).Invoke_O__O(p__9)); var chunk_190000034__11 any; var count_190000035__12 int64 = 0; var i_190000036__13 int64 = 0; L3: for {
				if lang.Numbers_Lt_J_J__Z(i_190000036__13, count_190000035__12) { var cp__14_2 any = lang.Indexed_Cast(chunk_190000034__11).Nth_I__O(lang.RT_IntCast_J__I(i_190000036__13)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__14_2, A_arbace_g2a_print_text_A_const_36))); seq_190000033__10, chunk_190000034__11, count_190000035__12, i_190000036__13 = seq_190000033__10, chunk_190000034__11, count_190000035__12, lang.Numbers_Unchecked_inc_J__J(i_190000036__13); continue L3 } else { var temp__1927000414__auto____14 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_190000033__10); if jrt.A2g_Truth(temp__1927000414__auto____14) { var seq_190000033__15 any = temp__1927000414__auto____14; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_190000033__15)) { var c__1927000678__auto____16 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_190000033__15); seq_190000033__10, chunk_190000034__11, count_190000035__12, i_190000036__13 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_190000033__15), c__1927000678__auto____16, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var cp__16 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_190000033__15); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__16, A_arbace_g2a_print_text_A_const_36))); seq_190000033__10, chunk_190000034__11, count_190000035__12, i_190000036__13 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_190000033__15), nil, 0, 0; continue L3 } } }
//line :93:1
				break L3 } } else { var tmp2 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_44.GetRawRoot__O()).Invoke_O__O(p__9)

					if jrt.A2g_Truth(and__1927000168__auto____10) { tmp2 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_print_text_A_const_46, p__9, A_arbace_g2a_print_text_A_const_47) } else { tmp2 = and__1927000168__auto____10 }
//line :93:1
					if jrt.A2g_Truth(tmp2) {

						jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(p__9)).Ref(), A_arbace_g2a_print_text_A_const_21)))) } else {
//line :93:1
							if A_arbace_g2a_print_text_A_const_20 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(p__9))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_text_A_const_48, p__9)))))) } } }
//line :92:1
			seq_190000025__3, chunk_190000026__4, count_190000027__5, i_190000028__6 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_190000025__8), nil, 0, 0; continue L1 } } }
//line :87:1
	break L1 };









	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_23); return /*line :98:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_g2a_print_text_go_rune_A_New() *A_arbace_g2a_print_text_go_rune_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_go_rune_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_g2a_print_text_go_rune_A) Ctor() {}
//line :100:1
func (t *A_arbace_g2a_print_text_go_rune_A) Invoke_O_O__O(self, p_cp__0 any) any { var cp__0 int64 = lang.RT_LongCast_O__J(p_cp__0); var tmp1 bool; var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_J__Z(cp__0); if or__1927000174__auto____2 {


	tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Numbers_Gt_J_J__Z(cp__0, 1114111); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var and__1927000168__auto____4 bool = lang.Numbers_Gte_J_J__Z(cp__0, 55296); if and__1927000168__auto____4 { tmp1 = lang.Numbers_Lte_J_J__Z(cp__0, 57343) } else { tmp1 = and__1927000168__auto____4 } } }; if tmp1 { var tmp2 any = A_arbace_g2a_print_text_A_const_49; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long(cp__0).Ref())).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.Long_ValueOf_J__Long(cp__0).Ref())))))) }; return /*line :105:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_32, nil, Lit_32), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(cp__0).Ref(), A_arbace_g2a_print_text_A_const_50), nil)).Ref() }

func A_arbace_g2a_print_text_float_kind_A_New() *A_arbace_g2a_print_text_float_kind_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_float_kind_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_g2a_print_text_float_kind_A) Ctor() {}
//line :107:1
func (t *A_arbace_g2a_print_text_float_kind_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_51.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_18); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_51.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_19); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_51.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_20) } }; if jrt.A2g_Truth(tmp1) { return s__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_21), jrt.RefArrayOf(jrt.Object_class, s__0, nil)).Ref()
	} }
func A_arbace_g2a_print_text_pow2_exponent_A_New() *A_arbace_g2a_print_text_pow2_exponent_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_pow2_exponent_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_g2a_print_text_pow2_exponent_A) Ctor() {}
//line :113:1
func (t *A_arbace_g2a_print_text_pow2_exponent_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).Signum__I())); if and__1927000168__auto____2 { tmp1 = lang.Numbers_Equiv_J_J__Z(1, int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitCount__I())) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitLength__I()))).Ref() } else { return nil
	} }
func A_arbace_g2a_print_text_strip_2_5_A_New() *A_arbace_g2a_print_text_strip_2_5_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_strip_2_5_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_g2a_print_text_strip_2_5_A) Ctor() {}
//line :118:1
func (t *A_arbace_g2a_print_text_strip_2_5_A) Invoke_O_O__O(self, n__0 any) any { { var five__2 any = jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(); var n__3 any = n__0; var a__4 int64 = 0; var b__5 int64 = 0; L1: for {




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_52.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.BigInteger_Cast(n__3)).TestBit_I__Z(lang.RT_IntCast_J__I(0))).Ref())) {
		n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).ShiftRight_I__BigInteger(lang.RT_IntCast_J__I(1)).Ref(), lang.Numbers_Inc_J__J(a__4), b__5; continue L1 } else {
//line :123:1
			if lang.Numbers_IsZero_J__Z(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(n__3)).Mod_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2))).Signum__I())) {

				n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).Divide_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2)).Ref(), a__4, lang.Numbers_Inc_J__J(b__5); continue L1 } else {
//line :123:1
					if A_arbace_g2a_print_text_A_const_20 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(n__3, jrt.Long_ValueOf_J__Long(a__4).Ref(), jrt.Long_ValueOf_J__Long(b__5).Ref()) } else { return nil } } } } }; /*line :118:1*/panic("a2g: unreachable") }









func A_arbace_g2a_print_text_go_float_A_New() *A_arbace_g2a_print_text_go_float_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_go_float_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_g2a_print_text_go_float_A) Ctor() {}
//line :128:1
func (t *A_arbace_g2a_print_text_go_float_A) Invoke_O_O__O(self, x__0 any) any {




	if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D(x__0); var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Double_IsNaN_D__Z(d__2)


		if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = jrt.Double_IsInfinite_D__Z(d__2) }; if tmp1 { var tmp2 any = A_arbace_g2a_print_text_A_const_59; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Double_ValueOf_D__Double(d__2).Ref())).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.Double_ValueOf_D__Double(d__2).Ref()))))))
		}
		return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_53.GetRawRoot__O()).Invoke_O__O(jrt.Double_ToString_D__String(d__2).Ref()) } else {
//line :133:1
			if jrt.BigDecimal_InstanceOf(x__0) {





				return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_53.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigDecimal_Cast(x__0)).ToString__String().Ref())) } else {
//line :133:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_55.GetRawRoot__O()).Invoke_O__O(x__0)) { var n__2 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_60.GetRawRoot__O()).Invoke_O__O(x__0)); var d__3 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_61.GetRawRoot__O()).Invoke_O__O(x__0)); var vec__190000042__4 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_57.GetRawRoot__O()).Invoke_O__O(d__3); var rest__5 any = lang.RT_Nth_O_I_O__O(vec__190000042__4, lang.RT_IntCast_J__I(0), nil); var a__6 any = lang.RT_Nth_O_I_O__O(vec__190000042__4, lang.RT_IntCast_J__I(1), nil); var b__7 any = lang.RT_Nth_O_I_O__O(vec__190000042__4, lang.RT_IntCast_J__I(2), nil); var tmp3 bool; var and__1927000168__auto____8 bool; var tmp4 *jrt.BigInteger










						jrt.BigInteger_Init(); tmp4 = jrt.BigInteger_ONE; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z(rest__5, tmp4.Ref()); if and__1927000168__auto____8 { tmp3 = lang.Numbers_Lte_O_J__Z(lang.Numbers_Max_O_O__O(a__6, b__7), 40) } else { tmp3 = and__1927000168__auto____8 }
//line :143:1
						if tmp3 {

							return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_54.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(n__2)).Divide_BigDecimal__BigDecimal(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(d__3)))).ToPlainString__String().Ref()) } else {
//line :143:1
								if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_58.GetRawRoot__O()).Invoke_O__O(d__3)) {



									return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.BigInteger_Cast(n__2)).ToString_I__String(lang.RT_IntCast_J__I(16)).Ref(), nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_58.GetRawRoot__O()).Invoke_O__O(d__3))).Ref() } else {
//line :143:1
										if A_arbace_g2a_print_text_A_const_20 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, x__0, nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_text_A_const_59, x__0)))))) } else { return nil } } } } else {
//line :133:1
											if A_arbace_g2a_print_text_A_const_20 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_30, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_print_text_A_const_59, x__0)))))) } else { return nil
											}
										}
				}
		}
}












func A_arbace_g2a_print_text_negative_number_QMARK__A_New() *A_arbace_g2a_print_text_negative_number_QMARK__A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_negative_number_QMARK__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) Ctor() {}
//line :151:1
func (t *A_arbace_g2a_print_text_negative_number_QMARK__A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.Double_InstanceOf(x__0) { var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_D__Z(lang.RT_DoubleCast_O__D(x__0))
		if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_J_J__Z(jrt.Double_DoubleToRawLongBits_D__J(lang.RT_DoubleCast_O__D(x__0)), -9223372036854775808)).Ref() } } else {
//line :155:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_62.GetRawRoot__O()).Invoke_O__O(x__0)) {


				return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_O__Z(x__0)).Ref() } else {
//line :155:1
					if A_arbace_g2a_print_text_A_const_20 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
		}
}

func A_arbace_g2a_print_text_go_number_A_New() *A_arbace_g2a_print_text_go_number_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_go_number_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_g2a_print_text_go_number_A) Ctor() {}
//line :161:1
func (t *A_arbace_g2a_print_text_go_number_A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.Double_InstanceOf(x__0) {
		return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_63.GetRawRoot__O()).Invoke_O__O(jrt.Double_ValueOf_D__Double(jrt.Math_Abs_D__D(lang.RT_DoubleCast_O__D(x__0))).Ref()) } else {
//line :165:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_44.GetRawRoot__O()).Invoke_O__O(x__0)) {

				return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_15.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :165:1
					if A_arbace_g2a_print_text_A_const_20 != nil {


						return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_63.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :165:1
							return nil
						}
				}
		}
}



func A_arbace_g2a_print_text_escape_A_New() *A_arbace_g2a_print_text_escape_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_escape_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_g2a_print_text_escape_A) Ctor() {}
//line :173:1
func (t *A_arbace_g2a_print_text_escape_A) Invoke_O_O__O(self, s__0 any) any {




	return jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_64)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_65)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_66)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_67)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_68)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_69)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_70)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_71)).CharValue__C()).Ref()
}
func A_arbace_g2a_print_text_unescape_A_New() *A_arbace_g2a_print_text_unescape_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_unescape_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_g2a_print_text_unescape_A) Ctor() {}
//line :180:1
func (t *A_arbace_g2a_print_text_unescape_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_72)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_64)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_73)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_66)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_74)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_68)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_75)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_g2a_print_text_A_const_70)).CharValue__C()).Ref()
}



func A_arbace_g2a_print_text_cell_width_A_New() *A_arbace_g2a_print_text_cell_width_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_cell_width_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_g2a_print_text_cell_width_A) Ctor() {}
//line :189:1
func (t *A_arbace_g2a_print_text_cell_width_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.String_Cast(s__0)).CodePointCount_I_I__I(lang.RT_IntCast_J__I(0), jrt.NN(jrt.String_Cast(s__0)).Length__I())).Ref() }



func A_arbace_g2a_print_text_parse_lines_A_New() *A_arbace_g2a_print_text_parse_lines_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_g2a_print_text_parse_lines_A) Ctor() {}
//line :193:1
func (t *A_arbace_g2a_print_text_parse_lines_A) Invoke_O_O__O(self, text__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_76.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_New(); var tmp4 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_89.GetRawRoot__O()).Invoke_O_O_O__O(text__0, A_arbace_g2a_print_text_A_const_90, A_arbace_g2a_print_text_A_const_91)); return tmp1.Invoke_O__O(tmp2) }
//line :197:1
func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_New() *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) Ctor() {}
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A) Invoke_O_O__O(self, s__190000052__1 any) any { var tmp1 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_New_O_O(self, s__190000052__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :197:1
func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_New_O_O(p0, p1 any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A{}; t.Ctor_O_O(p0, p1); return t }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) Ctor_O_O(c__iter__190000051, c__s__190000052 any) { t.F_iter__190000051 = c__iter__190000051; t.F_s__190000052 = c__s__190000052 }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A) Invoke_O__O(self any) any { { var s__190000052__1 any; var t_ any = t.F_s__190000052; t.F_s__190000052 = nil; s__190000052__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(s__190000052__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__190000052__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(s__190000052__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(s__190000052__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__190000054__6 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__190000054__6); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__190000051); return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_87.GetRawRoot__O()).Invoke_O__O(b__190000054__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(s__190000052__3))) } else { return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_87.GetRawRoot__O()).Invoke_O__O(b__190000054__6), nil) } } else { var line__4 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(s__190000052__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_86.GetRawRoot__O()); var tmp5 any; var n__5 int32 = jrt.NN(jrt.String_Cast(line__4)).Length__I(); var tmp6 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_New_I_O(n__5, line__4); var tmp7 *jrt.Class
															var fncls__5 /*line :197:1*/*jrt.Class = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_fn_class

	if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_fn_class = fncls__5d; tmp7 = fncls__5d } else { tmp7 = fncls__5 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :197:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__190000051); return tmp4.Invoke_O_O__O(tmp5, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_88.GetRawRoot__O()).Invoke_O__O(s__190000052__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :197:1
func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__190000054 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__190000054 = c__b__190000054 }
//line :197:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A) Invoke_O__O(self any) any { { var i__190000053__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__190000053__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var line__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__190000053__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_78.GetRawRoot__O()); var tmp3 any = t.F_b__190000054; var tmp4 any; var n__3 int32 = jrt.NN(jrt.String_Cast(line__2)).Length__I(); var tmp5 any = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_New_I_O(n__3, line__2); var tmp6 *jrt.Class
																	var fncls__3 /*line :197:1*/*jrt.Class = A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_fn_class

	if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_fn_class = fncls__3d; tmp6 = fncls__3d } else { tmp6 = fncls__3 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :197:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__190000053__1 = lang.Numbers_Unchecked_inc_J__J(i__190000053__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_New_I_O(p0 int32, p1 any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_24.GetRawRoot__O()); var tmp2 *lang.PersistentVector; lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; cells__3 = tmp1.Invoke_O__O(tmp2.Ref()); L1: for {
																		if lang.Numbers_Lt_J_J__Z(i__1, int64(t.F_n)) { var tmp3 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I(jrt.NN(tmp3).CharAt_I__C(lang.RT_IntCast_J__I(i__1))); var tmp4 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp4 = or__1927000174__auto____5 } else { tmp4 = lang.Numbers_Equiv_J_J__Z(int64(c__4), 11) }; if tmp4 {
			var tmp5 int64 = lang.Numbers_Inc_J__J(i__1); var tmp6 int64 = lang.Numbers_Inc_J__J(i__1); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_29.GetRawRoot__O()); var tmp8 any; var tmp9 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)
			if and__1927000168__auto____5 { tmp9 = lang.Numbers_Equiv_J_J__Z(start__2, i__1) } else { tmp9 = and__1927000168__auto____5 }; if tmp9 { tmp8 = A_arbace_g2a_print_text_A_const_80.GetRawRoot__O() } else { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_79.GetRawRoot__O()); var tmp11 any = t.F_line; var t__5 any = tmp10.Invoke_O_O_O__O(tmp11, jrt.Long_ValueOf_J__Long(start__2).Ref(), jrt.Long_ValueOf_J__Long(i__1).Ref()); var tmp12 any = A_arbace_g2a_print_text_A_const_81; var tmp13 any = A_arbace_g2a_print_text_A_const_82; var tmp14 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_83.GetRawRoot__O()).Invoke_O__O(t__5); var tmp15 any = A_arbace_g2a_print_text_A_const_84; tmp8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, t__5, tmp13, tmp14, tmp15, jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)).Ref())) }
//line :203:1
			i__1, start__2, cells__3 = tmp5, tmp6, tmp7.Invoke_O_O__O(cells__3, tmp8); continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_79.GetRawRoot__O()); var tmp17 any = t.F_line; var t__4 any = tmp16.Invoke_O_O__O(tmp17, jrt.Long_ValueOf_J__Long(start__2).Ref()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_25.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_29.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_print_text_A_const_81; var tmp21 any = A_arbace_g2a_print_text_A_const_82; var tmp22 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_83.GetRawRoot__O()).Invoke_O__O(t__4); var tmp23 any = A_arbace_g2a_print_text_A_const_84; var tmp24 *jrt.Boolean









					jrt.Boolean_Init(); tmp24 = jrt.Boolean_FALSE; return tmp18.Invoke_O__O(tmp19.Invoke_O_O__O(cells__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, t__4, tmp21, tmp22, tmp23, tmp24.Ref())))) } } }; /*line :199:1*/panic("a2g: unreachable") }
//line :199:1
func A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_New_I_O(p0 int32, p1 any) *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_24.GetRawRoot__O()); var tmp2 *lang.PersistentVector; lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; cells__3 = tmp1.Invoke_O__O(tmp2.Ref()); L1: for {
																	if lang.Numbers_Lt_J_J__Z(i__1, int64(t.F_n)) { var tmp3 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I(jrt.NN(tmp3).CharAt_I__C(lang.RT_IntCast_J__I(i__1))); var tmp4 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp4 = or__1927000174__auto____5 } else { tmp4 = lang.Numbers_Equiv_J_J__Z(int64(c__4), 11) }; if tmp4 {
			var tmp5 int64 = lang.Numbers_Inc_J__J(i__1); var tmp6 int64 = lang.Numbers_Inc_J__J(i__1); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_29.GetRawRoot__O()); var tmp8 any; var tmp9 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)
			if and__1927000168__auto____5 { tmp9 = lang.Numbers_Equiv_J_J__Z(start__2, i__1) } else { tmp9 = and__1927000168__auto____5 }; if tmp9 { tmp8 = A_arbace_g2a_print_text_A_const_80.GetRawRoot__O() } else { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_79.GetRawRoot__O()); var tmp11 any = t.F_line; var t__5 any = tmp10.Invoke_O_O_O__O(tmp11, jrt.Long_ValueOf_J__Long(start__2).Ref(), jrt.Long_ValueOf_J__Long(i__1).Ref()); var tmp12 any = A_arbace_g2a_print_text_A_const_81; var tmp13 any = A_arbace_g2a_print_text_A_const_82; var tmp14 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_83.GetRawRoot__O()).Invoke_O__O(t__5); var tmp15 any = A_arbace_g2a_print_text_A_const_84; tmp8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, t__5, tmp13, tmp14, tmp15, jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Equiv_J_J__Z(int64(c__4), 9)).Ref())) }
//line :203:1
			i__1, start__2, cells__3 = tmp5, tmp6, tmp7.Invoke_O_O__O(cells__3, tmp8); continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_79.GetRawRoot__O()); var tmp17 any = t.F_line; var t__4 any = tmp16.Invoke_O_O__O(tmp17, jrt.Long_ValueOf_J__Long(start__2).Ref()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_25.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_29.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_print_text_A_const_81; var tmp21 any = A_arbace_g2a_print_text_A_const_82; var tmp22 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_83.GetRawRoot__O()).Invoke_O__O(t__4); var tmp23 any = A_arbace_g2a_print_text_A_const_84; var tmp24 *jrt.Boolean









					jrt.Boolean_Init(); tmp24 = jrt.Boolean_FALSE; return tmp18.Invoke_O__O(tmp19.Invoke_O_O__O(cells__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, t__4, tmp21, tmp22, tmp23, tmp24.Ref())))) } } }; /*line :199:1*/panic("a2g: unreachable") }












func A_arbace_g2a_print_text_write_padding_A_New() *A_arbace_g2a_print_text_write_padding_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_write_padding_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_g2a_print_text_write_padding_A) Ctor() {}
//line :212:1
func (t *A_arbace_g2a_print_text_write_padding_A) Invoke_O_O_O_O_O__O(self, sb__0, p_textw__1, p_cellw__2, use_tabs__3 any) any { { var textw__1 int64 = lang.RT_LongCast_O__J(p_textw__1); var cellw__2 int64 = lang.RT_LongCast_O__J(p_cellw__2)
																if jrt.A2g_Truth(use_tabs__3) { var cellw__5 int64 = lang.Numbers_Multiply_J_J__J(8, lang.Numbers_Quotient_J_J__J(lang.Numbers_Add_J_J__J(cellw__2, 7), 8)); var n__6 int64 = lang.Numbers_Minus_J_J__J(cellw__5, textw__1); var n__1927000701__auto____7 int64 = lang.RT_LongCast_J__J(lang.Numbers_Quotient_J_J__J(lang.Numbers_Add_J_J__J(n__6, 7), 8)); var ___8 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z(___8, n__1927000701__auto____7) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_g2a_print_text_A_const_64); ___8 = lang.Numbers_Unchecked_inc_J__J(___8); continue L1 } else { return nil } } } else {
//line :213:1
			var n__1927000701__auto____5 int64 = lang.RT_LongCast_J__J(lang.Numbers_Minus_J_J__J(cellw__2, textw__1)); var ___6 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z(___6, n__1927000701__auto____5) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_g2a_print_text_A_const_92); ___6 = lang.Numbers_Unchecked_inc_J__J(___6); continue L2 } else { return nil } } } }; /*line :212:1*/panic("a2g: unreachable") }






func A_arbace_g2a_print_text_write_lines_A_New() *A_arbace_g2a_print_text_write_lines_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_write_lines_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_g2a_print_text_write_lines_A) Ctor() {}
//line :219:1
func (t *A_arbace_g2a_print_text_write_lines_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var seq_190000067__6 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_93.GetRawRoot__O()).Invoke_O_O__O(line0__3, line1__4)); var chunk_190000068__7 any; var count_190000069__8 int64 = 0; var i_190000070__9 int64 = 0; L1: for {
																	if lang.Numbers_Lt_J_J__Z(i_190000070__9, count_190000069__8) { var i__10 any = lang.Indexed_Cast(chunk_190000068__7).Nth_I__O(lang.RT_IntCast_J__I(i_190000070__9)); var line__11 any = lang.RT_Nth_O_I__O(lines__1, lang.RT_IntCast_O__I(i__10)); var nw__12 int32 = lang.RT_Count_O__I(widths__2); var j__13 int64 = 0; var use_tabs__14 any; jrt.Boolean_Init(); use_tabs__14 = jrt.Boolean_TRUE.Ref(); L2: for {



		if lang.Numbers_Lt_J_J__Z(j__13, int64(lang.RT_Count_O__I(line__11))) { var c__15 any = lang.RT_Nth_O_I__O(line__11, lang.RT_IntCast_J__I(j__13))

			if lang.Numbers_IsZero_J__Z(int64(lang.RT_Count_O__I(A_arbace_g2a_print_text_A_const_81.Invoke_O__O(c__15)))) {
				if lang.Numbers_Lt_J_J__Z(j__13, int64(nw__12)) { lang.IFn_Cast(A_arbace_g2a_print_text_A_const_94.GetRawRoot__O()).Invoke_O_O_O_O__O(sb__0, A_arbace_g2a_print_text_A_const_82.Invoke_O__O(c__15), lang.RT_Nth_O_I__O(widths__2, lang.RT_IntCast_J__I(j__13)), use_tabs__14) }
				j__13, use_tabs__14 = lang.Numbers_Inc_J__J(j__13), use_tabs__14; continue L2 } else {
					jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_String__StringBuilder(jrt.String_Cast(A_arbace_g2a_print_text_A_const_81.Invoke_O__O(c__15)))
					if lang.Numbers_Lt_J_J__Z(j__13, int64(nw__12)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_94.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_text_A_const_82.Invoke_O__O(c__15); var tmp3 any = lang.RT_Nth_O_I__O(widths__2, lang.RT_IntCast_J__I(j__13)); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O_O_O_O__O(sb__0, tmp2, tmp3, tmp4.Ref()) }
					var tmp5 int64 = lang.Numbers_Inc_J__J(j__13); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_FALSE; j__13, use_tabs__14 = tmp5, tmp6.Ref(); continue L2 } }
//line :220:1
		break L2
	}










		if lang.Numbers_Lt_O_J__Z(lang.Numbers_Inc_O__Number(i__10), int64(lang.RT_Count_O__I(lines__1))) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_g2a_print_text_A_const_66) }
//line :220:1
		seq_190000067__6, chunk_190000068__7, count_190000069__8, i_190000070__9 = seq_190000067__6, chunk_190000068__7, count_190000069__8, lang.Numbers_Unchecked_inc_J__J(i_190000070__9); continue L1 } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_190000067__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_190000067__11 any = temp__1927000414__auto____10; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_190000067__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_190000067__11); seq_190000067__6, chunk_190000068__7, count_190000069__8, i_190000070__9 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_190000067__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var i__12 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_190000067__11); var line__13 any = lang.RT_Nth_O_I__O(lines__1, lang.RT_IntCast_O__I(i__12)); var nw__14 int32 = lang.RT_Count_O__I(widths__2); var j__15 int64 = 0; var use_tabs__16 any; jrt.Boolean_Init(); use_tabs__16 = jrt.Boolean_TRUE.Ref(); L3: for {



			if lang.Numbers_Lt_J_J__Z(j__15, int64(lang.RT_Count_O__I(line__13))) { var c__17 any = lang.RT_Nth_O_I__O(line__13, lang.RT_IntCast_J__I(j__15))

				if lang.Numbers_IsZero_J__Z(int64(lang.RT_Count_O__I(A_arbace_g2a_print_text_A_const_81.Invoke_O__O(c__17)))) {
					if lang.Numbers_Lt_J_J__Z(j__15, int64(nw__14)) { lang.IFn_Cast(A_arbace_g2a_print_text_A_const_94.GetRawRoot__O()).Invoke_O_O_O_O__O(sb__0, A_arbace_g2a_print_text_A_const_82.Invoke_O__O(c__17), lang.RT_Nth_O_I__O(widths__2, lang.RT_IntCast_J__I(j__15)), use_tabs__16) }
					j__15, use_tabs__16 = lang.Numbers_Inc_J__J(j__15), use_tabs__16; continue L3 } else {
						jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_String__StringBuilder(jrt.String_Cast(A_arbace_g2a_print_text_A_const_81.Invoke_O__O(c__17)))
						if lang.Numbers_Lt_J_J__Z(j__15, int64(nw__14)) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_94.GetRawRoot__O()); var tmp8 any = A_arbace_g2a_print_text_A_const_82.Invoke_O__O(c__17); var tmp9 any = lang.RT_Nth_O_I__O(widths__2, lang.RT_IntCast_J__I(j__15)); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_FALSE; tmp7.Invoke_O_O_O_O__O(sb__0, tmp8, tmp9, tmp10.Ref()) }
						var tmp11 int64 = lang.Numbers_Inc_J__J(j__15); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_FALSE; j__15, use_tabs__16 = tmp11, tmp12.Ref(); continue L3 } }
//line :220:1
			break L3
		}










			if lang.Numbers_Lt_O_J__Z(lang.Numbers_Inc_O__Number(i__12), int64(lang.RT_Count_O__I(lines__1))) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_g2a_print_text_A_const_66) }
//line :220:1
			seq_190000067__6, chunk_190000068__7, count_190000069__8, i_190000070__9 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_190000067__11), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :219:1*/panic("a2g: unreachable") }














func A_arbace_g2a_print_text_format_block_A_New() *A_arbace_g2a_print_text_format_block_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_format_block_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_g2a_print_text_format_block_A) Ctor() {}
//line :234:1
func (t *A_arbace_g2a_print_text_format_block_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var column__6 int32 = lang.RT_Count_O__I(widths__2); var this__7 any = line0__3; var line0__8 any = line0__3; L1: for {




	if lang.Numbers_Lt_O_O__Z(this__7, line1__4) { var line__9 any = lang.RT_Nth_O_I__O(lines__1, lang.RT_IntCast_O__I(this__7))

		if lang.Numbers_Gte_J_J__Z(int64(column__6), lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(line__9)))) {
			this__7, line0__8 = lang.Numbers_Inc_O__Number(this__7), line0__8; continue L1 } else {

				lang.IFn_Cast(A_arbace_g2a_print_text_A_const_95.GetRawRoot__O()).Invoke_O_O_O_O_O__O(sb__0, lines__1, widths__2, line0__8, this__7)
//line :241:1
				var line0__10 any = this__7; var vec__190000072__11 any; var tmp1 any = A_arbace_g2a_print_text_format_block_fn__190000075_A_New_I_O_O_O(column__6, this__7, line1__4, lines__1); var tmp2 *jrt.Class
				var fncls__8 /*line :241:1*/*jrt.Class = A_arbace_g2a_print_text_format_block_fn__190000075_A_fn_class





				if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_g2a_print_text_format_block_fn__190000075_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; vec__190000072__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()
//line :241:1
				var end__12 any = lang.RT_Nth_O_I_O__O(vec__190000072__11, lang.RT_IntCast_J__I(0), nil); var width__13 any = lang.RT_Nth_O_I_O__O(vec__190000072__11, lang.RT_IntCast_J__I(1), nil); var discardable__14 any = lang.RT_Nth_O_I_O__O(vec__190000072__11, lang.RT_IntCast_J__I(2), nil); var width__15 any














				if jrt.A2g_Truth(discardable__14) { width__15 = A_arbace_g2a_print_text_A_const_46 } else { width__15 = width__13 }
				lang.IFn_Cast(A_arbace_g2a_print_text_A_const_96.GetRawRoot__O()).Invoke_O_O_O_O_O__O(sb__0, lines__1, lang.IFn_Cast(A_arbace_g2a_print_text_A_const_6.GetRawRoot__O()).Invoke_O_O__O(widths__2, width__15), line0__10, end__12)
				this__7, line0__8 = lang.Numbers_Inc_O__Number(end__12), end__12; continue L1 } } else {
					return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_95.GetRawRoot__O()).Invoke_O_O_O_O_O__O(sb__0, lines__1, widths__2, line0__8, line1__4) } } }; /*line :234:1*/panic("a2g: unreachable") }












func A_arbace_g2a_print_text_format_block_fn__190000075_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_g2a_print_text_format_block_fn__190000075_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_format_block_fn__190000075_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :247:1
func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) Ctor_I_O_O_O(c__column int32, c__this, c__line1, c__lines any) { t.F_column = c__column; t.F_this = c__this; t.F_line1 = c__line1; t.F_lines = c__lines }
//line :247:1
func (t *A_arbace_g2a_print_text_format_block_fn__190000075_A) Invoke_O__O(self any) any { { var this__1 any; var t_ any = t.F_this; t.F_this = nil; this__1 = t_; var width__2 any = lang.RT_Box_J__Number(0); var discardable__3 any; jrt.Boolean_Init(); discardable__3 = jrt.Boolean_TRUE.Ref(); L1: for {
												if lang.Numbers_Lt_O_O__Z(this__1, t.F_line1) { var tmp1 any = t.F_lines; var line__4 any = lang.RT_Nth_O_I__O(tmp1, lang.RT_IntCast_O__I(this__1)); var tmp2 int64 = int64(t.F_column)

		if lang.Numbers_Gte_J_J__Z(tmp2, lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(line__4)))) { return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } else { var c__5 any = lang.RT_Nth_O_I__O(line__4, t.F_column); var tmp3 any = lang.Numbers_Inc_O__Number(this__1); var tmp4 any = lang.Numbers_Max_O_O__O(width__2, lang.Numbers_Inc_O__Number(A_arbace_g2a_print_text_A_const_82.Invoke_O__O(c__5))); var tmp5 any
			var and__1927000168__auto____6 any = discardable__3


			if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool = lang.Numbers_IsZero_O__Z(A_arbace_g2a_print_text_A_const_82.Invoke_O__O(c__5)); if and__1927000168__auto____7 { tmp5 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_print_text_A_const_84.Invoke_O__O(c__5)) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() } } else { tmp5 = and__1927000168__auto____6 }
//line :253:1
			this__1, width__2, discardable__3 = tmp3, tmp4, tmp5; continue L1 } } else {
//line :248:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } } }; /*line :247:1*/panic("a2g: unreachable") }













func A_arbace_g2a_print_text_align_block_A_New() *A_arbace_g2a_print_text_align_block_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_align_block_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_g2a_print_text_align_block_A) Ctor() {}
//line :261:1
func (t *A_arbace_g2a_print_text_align_block_A) Invoke_O_O__O(self, block__0 any) any { var sb__2 any = jrt.StringBuilder_New(); var lines__3 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_97.GetRawRoot__O()).Invoke_O__O(block__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_96.GetRawRoot__O()); var tmp2 *lang.PersistentVector;




	lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any = A_arbace_g2a_print_text_A_const_46; tmp1.Invoke_O_O_O_O_O__O(sb__2, lines__3, tmp3, tmp4, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(lines__3)).Ref()); return /*line :267:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_g2a_print_text_align_A_New() *A_arbace_g2a_print_text_align_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_align_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_g2a_print_text_align_A) Ctor() {}
//line :269:1
func (t *A_arbace_g2a_print_text_align_A) Invoke_O_O__O(self, text__0 any) any { var blocks__2 any = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_89.GetRawRoot__O()).Invoke_O_O_O__O(text__0, A_arbace_g2a_print_text_A_const_100, A_arbace_g2a_print_text_A_const_91); var n__3 int32 = lang.RT_Count_O__I(blocks__2); var groups__4 int64 = lang.Numbers_Multiply_J_J__J(4, int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())); var aligned__5 any; if






	lang.Numbers_Lt_J_J__Z(int64(n__3), 128) {
		aligned__5 = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_98.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_text_A_const_101.GetRawRoot__O(), blocks__2) } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_print_text_A_const_102.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_print_text_A_const_103.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_print_text_align_fn__190000080_A_New(); var tmp5 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_print_text_align_fn__190000080_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_g2a_print_text_align_fn__190000080_A_fn_class = fncls__9d; tmp5 = fncls__9d } else { tmp5 = fncls__9 }; aligned__5 = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_g2a_print_text_A_const_105.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Quotient_J_J__J(lang.Numbers_Add_J_J__J(int64(n__3), lang.Numbers_Dec_J__J(groups__4)), groups__4)).Ref(), blocks__2))) }; return /*line :280:1*/ lang.IFn_Cast(A_arbace_g2a_print_text_A_const_99.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_print_text_A_const_106.GetRawRoot__O()).Invoke_O_O__O(Lit_2, aligned__5)) }
//line :278:1
func A_arbace_g2a_print_text_align_fn__190000080_A_New() *A_arbace_g2a_print_text_align_fn__190000080_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_align_fn__190000080_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_g2a_print_text_align_fn__190000080_A) Ctor() {}
//line :278:1
func (t *A_arbace_g2a_print_text_align_fn__190000080_A) Invoke_O_O__O(self, p1__190000079_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_g2a_print_text_A_const_104.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_print_text_A_const_101.GetRawRoot__O(), p1__190000079_SHARP___1) }







type A_arbace_g2a_print_text_A struct{ jrt.Object }

var A_arbace_g2a_print_text_A_const_pool *jrt.RefArray

var A_arbace_g2a_print_text_A_const_0 *lang.Var

var A_arbace_g2a_print_text_A_const_1 *lang.Var

var A_arbace_g2a_print_text_A_const_2 any

var A_arbace_g2a_print_text_A_const_3 any

var A_arbace_g2a_print_text_A_const_4 *lang.Var

var A_arbace_g2a_print_text_A_const_5 *lang.Var

var A_arbace_g2a_print_text_A_const_6 *lang.Var

var A_arbace_g2a_print_text_A_const_7 any

var A_arbace_g2a_print_text_A_const_8 *lang.Var

var A_arbace_g2a_print_text_A_const_9 *lang.Var

var A_arbace_g2a_print_text_A_const_10 *lang.Var

var A_arbace_g2a_print_text_A_const_11 any

var A_arbace_g2a_print_text_A_const_12 any

var A_arbace_g2a_print_text_A_const_13 *lang.Var

var A_arbace_g2a_print_text_A_const_14 *lang.Var

var A_arbace_g2a_print_text_A_const_15 *lang.Var

var A_arbace_g2a_print_text_A_const_16 *lang.Var

var A_arbace_g2a_print_text_A_const_17 any

var A_arbace_g2a_print_text_A_const_18 *lang.Var

var A_arbace_g2a_print_text_A_const_19 *lang.Var

var A_arbace_g2a_print_text_A_const_20 *lang.Keyword

var A_arbace_g2a_print_text_A_const_21 any

var A_arbace_g2a_print_text_A_const_22 any

var A_arbace_g2a_print_text_A_const_23 any

var A_arbace_g2a_print_text_A_const_24 *lang.Var

var A_arbace_g2a_print_text_A_const_25 *lang.Var

var A_arbace_g2a_print_text_A_const_26 *lang.Var

var A_arbace_g2a_print_text_A_const_27 *lang.Var

var A_arbace_g2a_print_text_A_const_28 *lang.Keyword

var A_arbace_g2a_print_text_A_const_29 *lang.Var

var A_arbace_g2a_print_text_A_const_30 *lang.Var

var A_arbace_g2a_print_text_A_const_31 *lang.Var

var A_arbace_g2a_print_text_A_const_32 *lang.Var

var A_arbace_g2a_print_text_A_const_33 *lang.Var

var A_arbace_g2a_print_text_A_const_34 *lang.Var

var A_arbace_g2a_print_text_A_const_35 *lang.Var

var A_arbace_g2a_print_text_A_const_36 any

var A_arbace_g2a_print_text_A_const_37 *lang.Var

var A_arbace_g2a_print_text_A_const_38 *lang.Var

var A_arbace_g2a_print_text_A_const_39 *lang.Var

var A_arbace_g2a_print_text_A_const_40 *lang.Var

var A_arbace_g2a_print_text_A_const_41 any

var A_arbace_g2a_print_text_A_const_42 any

var A_arbace_g2a_print_text_A_const_43 *lang.Var

var A_arbace_g2a_print_text_A_const_44 *lang.Var

var A_arbace_g2a_print_text_A_const_45 *lang.Var

var A_arbace_g2a_print_text_A_const_46 any

var A_arbace_g2a_print_text_A_const_47 any

var A_arbace_g2a_print_text_A_const_48 *lang.Keyword

var A_arbace_g2a_print_text_A_const_49 *lang.Keyword

var A_arbace_g2a_print_text_A_const_50 any

var A_arbace_g2a_print_text_A_const_51 *lang.Var

var A_arbace_g2a_print_text_A_const_52 *lang.Var

var A_arbace_g2a_print_text_A_const_53 *lang.Var

var A_arbace_g2a_print_text_A_const_54 *lang.Var

var A_arbace_g2a_print_text_A_const_55 *lang.Var

var A_arbace_g2a_print_text_A_const_56 *lang.Var

var A_arbace_g2a_print_text_A_const_57 *lang.Var

var A_arbace_g2a_print_text_A_const_58 *lang.Var

var A_arbace_g2a_print_text_A_const_59 *lang.Keyword

var A_arbace_g2a_print_text_A_const_60 *lang.Var

var A_arbace_g2a_print_text_A_const_61 *lang.Var

var A_arbace_g2a_print_text_A_const_62 *lang.Var

var A_arbace_g2a_print_text_A_const_63 *lang.Var

var A_arbace_g2a_print_text_A_const_64 any

var A_arbace_g2a_print_text_A_const_65 any

var A_arbace_g2a_print_text_A_const_66 any

var A_arbace_g2a_print_text_A_const_67 any

var A_arbace_g2a_print_text_A_const_68 any

var A_arbace_g2a_print_text_A_const_69 any

var A_arbace_g2a_print_text_A_const_70 any

var A_arbace_g2a_print_text_A_const_71 any

var A_arbace_g2a_print_text_A_const_72 any

var A_arbace_g2a_print_text_A_const_73 any

var A_arbace_g2a_print_text_A_const_74 any

var A_arbace_g2a_print_text_A_const_75 any

var A_arbace_g2a_print_text_A_const_76 *lang.Var

var A_arbace_g2a_print_text_A_const_77 *lang.Var

var A_arbace_g2a_print_text_A_const_78 *lang.Var

var A_arbace_g2a_print_text_A_const_79 *lang.Var

var A_arbace_g2a_print_text_A_const_80 *lang.Var

var A_arbace_g2a_print_text_A_const_81 *lang.Keyword

var A_arbace_g2a_print_text_A_const_82 *lang.Keyword

var A_arbace_g2a_print_text_A_const_83 *lang.Var

var A_arbace_g2a_print_text_A_const_84 *lang.Keyword

var A_arbace_g2a_print_text_A_const_85 *lang.Var

var A_arbace_g2a_print_text_A_const_86 *lang.Var

var A_arbace_g2a_print_text_A_const_87 *lang.Var

var A_arbace_g2a_print_text_A_const_88 *lang.Var

var A_arbace_g2a_print_text_A_const_89 *lang.Var

var A_arbace_g2a_print_text_A_const_90 any

var A_arbace_g2a_print_text_A_const_91 any

var A_arbace_g2a_print_text_A_const_92 any

var A_arbace_g2a_print_text_A_const_93 *lang.Var

var A_arbace_g2a_print_text_A_const_94 *lang.Var

var A_arbace_g2a_print_text_A_const_95 *lang.Var

var A_arbace_g2a_print_text_A_const_96 *lang.Var

var A_arbace_g2a_print_text_A_const_97 *lang.Var

var A_arbace_g2a_print_text_A_const_98 *lang.Var

var A_arbace_g2a_print_text_A_const_99 *lang.Var

var A_arbace_g2a_print_text_A_const_100 any

var A_arbace_g2a_print_text_A_const_101 *lang.Var

var A_arbace_g2a_print_text_A_const_102 *lang.Var

var A_arbace_g2a_print_text_A_const_103 *lang.Var

var A_arbace_g2a_print_text_A_const_104 *lang.Var

var A_arbace_g2a_print_text_A_const_105 *lang.Var

var A_arbace_g2a_print_text_A_const_106 *lang.Var

var A_arbace_g2a_print_text_A_init jrt.ClassInit

func A_arbace_g2a_print_text_A_Init() { if !A_arbace_g2a_print_text_A_init.Done() { A_arbace_g2a_print_text_A_init.Run(A_arbace_g2a_print_text_A_clinit) } }

func A_arbace_g2a_print_text_A_clinit() { A_arbace_g2a_print_text_A_clinit_p0(); A_arbace_g2a_print_text_A_clinit_p1(); A_arbace_g2a_print_text_A_clinit_p2(); A_arbace_g2a_print_text_A_clinit_p3(); A_arbace_g2a_print_text_A_clinit_p4(); A_arbace_g2a_print_text_A_clinit_p5(); A_arbace_g2a_print_text_A_clinit_p6(); A_arbace_g2a_print_text_A_clinit_p7(); A_arbace_g2a_print_text_A_clinit_p8() }

func A_arbace_g2a_print_text_A_clinit_p0() { A_arbace_g2a_print_text_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 120); A_arbace_g2a_print_text_A_const_0 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[13]); A_arbace_g2a_print_text_A_const_1 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[14]); A_arbace_g2a_print_text_A_const_2 = A_arbace_g2a_print_text_A_const_pool.A[15]; A_arbace_g2a_print_text_A_const_3 = A_arbace_g2a_print_text_A_const_pool.A[16]; A_arbace_g2a_print_text_A_const_4 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[17]); A_arbace_g2a_print_text_A_const_5 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[18]); A_arbace_g2a_print_text_A_const_6 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[19]); A_arbace_g2a_print_text_A_const_7 = A_arbace_g2a_print_text_A_const_pool.A[20]; A_arbace_g2a_print_text_A_const_8 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[21]); A_arbace_g2a_print_text_A_const_9 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[22]); A_arbace_g2a_print_text_A_const_10 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[23]); A_arbace_g2a_print_text_A_const_11 = A_arbace_g2a_print_text_A_const_pool.A[24] }

func A_arbace_g2a_print_text_A_clinit_p1() { A_arbace_g2a_print_text_A_const_12 = A_arbace_g2a_print_text_A_const_pool.A[25]; A_arbace_g2a_print_text_A_const_13 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[26]); A_arbace_g2a_print_text_A_const_14 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[27]); A_arbace_g2a_print_text_A_const_15 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[28]); A_arbace_g2a_print_text_A_const_16 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[29]); A_arbace_g2a_print_text_A_const_17 = A_arbace_g2a_print_text_A_const_pool.A[30]; A_arbace_g2a_print_text_A_const_18 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[31]); A_arbace_g2a_print_text_A_const_19 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[32]); A_arbace_g2a_print_text_A_const_20 = lang.Keyword_Cast(A_arbace_g2a_print_text_A_const_pool.A[33]); A_arbace_g2a_print_text_A_const_21 = A_arbace_g2a_print_text_A_const_pool.A[34]; A_arbace_g2a_print_text_A_const_22 = A_arbace_g2a_print_text_A_const_pool.A[35]; A_arbace_g2a_print_text_A_const_23 = A_arbace_g2a_print_text_A_const_pool.A[36]; A_arbace_g2a_print_text_A_const_24 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[37]) }

func A_arbace_g2a_print_text_A_clinit_p2() { A_arbace_g2a_print_text_A_const_25 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[38]); A_arbace_g2a_print_text_A_const_26 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[39]); A_arbace_g2a_print_text_A_const_27 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[40]); A_arbace_g2a_print_text_A_const_28 = lang.Keyword_Cast(A_arbace_g2a_print_text_A_const_pool.A[41]); A_arbace_g2a_print_text_A_const_29 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[42]); A_arbace_g2a_print_text_A_const_30 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[43]); A_arbace_g2a_print_text_A_const_31 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[44]); A_arbace_g2a_print_text_A_const_32 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[45]); A_arbace_g2a_print_text_A_const_33 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[46]); A_arbace_g2a_print_text_A_const_34 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[47]); A_arbace_g2a_print_text_A_const_35 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[48]); A_arbace_g2a_print_text_A_const_36 = A_arbace_g2a_print_text_A_const_pool.A[49] }

func A_arbace_g2a_print_text_A_clinit_p3() { A_arbace_g2a_print_text_A_const_37 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[50]); A_arbace_g2a_print_text_A_const_38 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[51]); A_arbace_g2a_print_text_A_const_39 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[52]); A_arbace_g2a_print_text_A_const_40 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[53]); A_arbace_g2a_print_text_A_const_41 = A_arbace_g2a_print_text_A_const_pool.A[54]; A_arbace_g2a_print_text_A_const_42 = A_arbace_g2a_print_text_A_const_pool.A[55]; A_arbace_g2a_print_text_A_const_43 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[56]); A_arbace_g2a_print_text_A_const_44 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[57]); A_arbace_g2a_print_text_A_const_45 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[58]); A_arbace_g2a_print_text_A_const_46 = A_arbace_g2a_print_text_A_const_pool.A[59]; A_arbace_g2a_print_text_A_const_47 = A_arbace_g2a_print_text_A_const_pool.A[60]; A_arbace_g2a_print_text_A_const_48 = lang.Keyword_Cast(A_arbace_g2a_print_text_A_const_pool.A[61]); A_arbace_g2a_print_text_A_const_49 = lang.Keyword_Cast(A_arbace_g2a_print_text_A_const_pool.A[62]) }

func A_arbace_g2a_print_text_A_clinit_p4() { A_arbace_g2a_print_text_A_const_50 = A_arbace_g2a_print_text_A_const_pool.A[63]; A_arbace_g2a_print_text_A_const_51 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[64]); A_arbace_g2a_print_text_A_const_52 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[65]); A_arbace_g2a_print_text_A_const_53 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[66]); A_arbace_g2a_print_text_A_const_54 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[67]); A_arbace_g2a_print_text_A_const_55 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[68]); A_arbace_g2a_print_text_A_const_56 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[69]); A_arbace_g2a_print_text_A_const_57 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[70]); A_arbace_g2a_print_text_A_const_58 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[71]); A_arbace_g2a_print_text_A_const_59 = lang.Keyword_Cast(A_arbace_g2a_print_text_A_const_pool.A[72]); A_arbace_g2a_print_text_A_const_60 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[73]); A_arbace_g2a_print_text_A_const_61 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[74]) }

func A_arbace_g2a_print_text_A_clinit_p5() { A_arbace_g2a_print_text_A_const_62 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[75]); A_arbace_g2a_print_text_A_const_63 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[76]); A_arbace_g2a_print_text_A_const_64 = A_arbace_g2a_print_text_A_const_pool.A[77]; A_arbace_g2a_print_text_A_const_65 = A_arbace_g2a_print_text_A_const_pool.A[78]; A_arbace_g2a_print_text_A_const_66 = A_arbace_g2a_print_text_A_const_pool.A[79]; A_arbace_g2a_print_text_A_const_67 = A_arbace_g2a_print_text_A_const_pool.A[80]; A_arbace_g2a_print_text_A_const_68 = A_arbace_g2a_print_text_A_const_pool.A[81]; A_arbace_g2a_print_text_A_const_69 = A_arbace_g2a_print_text_A_const_pool.A[82]; A_arbace_g2a_print_text_A_const_70 = A_arbace_g2a_print_text_A_const_pool.A[83]; A_arbace_g2a_print_text_A_const_71 = A_arbace_g2a_print_text_A_const_pool.A[84]; A_arbace_g2a_print_text_A_const_72 = A_arbace_g2a_print_text_A_const_pool.A[85]; A_arbace_g2a_print_text_A_const_73 = A_arbace_g2a_print_text_A_const_pool.A[86]; A_arbace_g2a_print_text_A_const_74 = A_arbace_g2a_print_text_A_const_pool.A[87]; A_arbace_g2a_print_text_A_const_75 = A_arbace_g2a_print_text_A_const_pool.A[88]; A_arbace_g2a_print_text_A_const_76 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[89]) }

func A_arbace_g2a_print_text_A_clinit_p6() { A_arbace_g2a_print_text_A_const_77 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[90]); A_arbace_g2a_print_text_A_const_78 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[91]); A_arbace_g2a_print_text_A_const_79 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[92]); A_arbace_g2a_print_text_A_const_80 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[93]); A_arbace_g2a_print_text_A_const_81 = lang.Keyword_Cast(A_arbace_g2a_print_text_A_const_pool.A[94]); A_arbace_g2a_print_text_A_const_82 = lang.Keyword_Cast(A_arbace_g2a_print_text_A_const_pool.A[95]); A_arbace_g2a_print_text_A_const_83 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[96]); A_arbace_g2a_print_text_A_const_84 = lang.Keyword_Cast(A_arbace_g2a_print_text_A_const_pool.A[97]); A_arbace_g2a_print_text_A_const_85 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[98]); A_arbace_g2a_print_text_A_const_86 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[99]); A_arbace_g2a_print_text_A_const_87 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[100]); A_arbace_g2a_print_text_A_const_88 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[101]) }

func A_arbace_g2a_print_text_A_clinit_p7() { A_arbace_g2a_print_text_A_const_89 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[102]); A_arbace_g2a_print_text_A_const_90 = A_arbace_g2a_print_text_A_const_pool.A[103]; A_arbace_g2a_print_text_A_const_91 = A_arbace_g2a_print_text_A_const_pool.A[104]; A_arbace_g2a_print_text_A_const_92 = A_arbace_g2a_print_text_A_const_pool.A[105]; A_arbace_g2a_print_text_A_const_93 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[106]); A_arbace_g2a_print_text_A_const_94 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[107]); A_arbace_g2a_print_text_A_const_95 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[108]); A_arbace_g2a_print_text_A_const_96 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[109]); A_arbace_g2a_print_text_A_const_97 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[110]); A_arbace_g2a_print_text_A_const_98 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[111]); A_arbace_g2a_print_text_A_const_99 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[112]); A_arbace_g2a_print_text_A_const_100 = A_arbace_g2a_print_text_A_const_pool.A[113]; A_arbace_g2a_print_text_A_const_101 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[114]) }

func A_arbace_g2a_print_text_A_clinit_p8() { A_arbace_g2a_print_text_A_const_102 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[115]); A_arbace_g2a_print_text_A_const_103 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[116]); A_arbace_g2a_print_text_A_const_104 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[117]); A_arbace_g2a_print_text_A_const_105 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[118]); A_arbace_g2a_print_text_A_const_106 = lang.Var_Cast(A_arbace_g2a_print_text_A_const_pool.A[119]) }

func A_arbace_g2a_print_text_A_New() *A_arbace_g2a_print_text_A { A_arbace_g2a_print_text_A_Init(); t := &A_arbace_g2a_print_text_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_text_A) Ctor() {}

func (t *A_arbace_g2a_print_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_A_class }

func (t *A_arbace_g2a_print_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_A); return ok }

func A_arbace_g2a_print_text_A_Cast(x any) *A_arbace_g2a_print_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_A_class)) }; return v }



type A_arbace_g2a_print_text_align_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_align_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_align_fn__190000080_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_align_fn__190000080_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_align_block_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_align_block_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_cell_width_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_cell_width_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_code_points_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_code_points_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_escape_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_escape_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_escape_cp_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_escape_cp_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_eval190000004_A struct{ jrt.Object }

func A_arbace_g2a_print_text_eval190000004_A_New() *A_arbace_g2a_print_text_eval190000004_A { t := &A_arbace_g2a_print_text_eval190000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_text_eval190000004_A) Ctor() {}

func (t *A_arbace_g2a_print_text_eval190000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_eval190000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_eval190000004_A_class }

func (t *A_arbace_g2a_print_text_eval190000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_eval190000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_eval190000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_eval190000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_eval190000004_A); return ok }

func A_arbace_g2a_print_text_eval190000004_A_Cast(x any) *A_arbace_g2a_print_text_eval190000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_eval190000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_eval190000004_A_class)) }; return v }



type A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_eval190000004_loading__1927001464__auto____190000005_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_eval190000008_A struct{ jrt.Object }

func A_arbace_g2a_print_text_eval190000008_A_New() *A_arbace_g2a_print_text_eval190000008_A { t := &A_arbace_g2a_print_text_eval190000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_print_text_eval190000008_A) Ctor() {}

func (t *A_arbace_g2a_print_text_eval190000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_print_text_eval190000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_print_text_eval190000008_A_class }

func (t *A_arbace_g2a_print_text_eval190000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_print_text_eval190000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_print_text_eval190000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_print_text_eval190000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_print_text_eval190000008_A); return ok }

func A_arbace_g2a_print_text_eval190000008_A_Cast(x any) *A_arbace_g2a_print_text_eval190000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_print_text_eval190000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_print_text_eval190000008_A_class)) }; return v }



type A_arbace_g2a_print_text_eval190000008_fn__190000009_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_eval190000008_fn__190000009_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_float_kind_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_float_kind_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_format_block_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_format_block_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_format_block_fn__190000075_A struct{ a2g_header uint64; F_column int32; F_this, F_line1, F_lines any }

var A_arbace_g2a_print_text_format_block_fn__190000075_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_go_byte_string_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_go_byte_string_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_go_float_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_go_float_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_go_number_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_go_number_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_go_printable_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_go_printable_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_text_go_rune_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_go_rune_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_go_string_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_go_string_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_hex_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_hex_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_negative_number_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_negative_number_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_text_parse_lines_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_parse_lines_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A struct{ a2g_header uint64; F_iter__190000051, F_s__190000052 any }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__190000054 any }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A struct{ a2g_header uint64; F_n int32; F_line any }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000057_fn__190000058_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A struct{ a2g_header uint64; F_n int32; F_line any }

var A_arbace_g2a_print_text_parse_lines_iter__190000051__190000055_fn__190000056_fn__190000061_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_pow2_exponent_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_pow2_exponent_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_raw_string_ok_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_raw_string_ok_QMARK__A_fn_class *jrt.Class



type A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_raw_string_ok_QMARK__fn__190000022_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_strip_2_5_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_strip_2_5_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_unescape_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_unescape_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_write_lines_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_write_lines_A_fn_class *jrt.Class



type A_arbace_g2a_print_text_write_padding_A struct{ a2g_header uint64 }

var A_arbace_g2a_print_text_write_padding_A_fn_class *jrt.Class
