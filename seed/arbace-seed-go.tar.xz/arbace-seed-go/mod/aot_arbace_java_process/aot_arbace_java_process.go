//line aot_arbace_java_process.ae:1
package aot_arbace_java_process

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_New() *A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_process_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_process_A_const_2); lang.IFn_Cast(A_arbace_java_process_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_java_process_A_const_3); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_2)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_3)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_4)); var tmp8 *lang.Var; lang.RT_Init(); tmp8 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp8).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_5)); var tmp9 *lang.Var; lang.RT_Init(); tmp9 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp9).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_6)); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_7)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_8)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_9)); var tmp13 *lang.Var; lang.RT_Init(); tmp13 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp13).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_10)); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_11)); var tmp15 *lang.Var; lang.RT_Init(); tmp15 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp15).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_12)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp16 != nil { panic(tmp16) }; return tmp3 }
//line :9:1
func A_arbace_java_process_eval1620000008_fn__1620000009_A_New() *A_arbace_java_process_eval1620000008_fn__1620000009_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_eval1620000008_fn__1620000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_process_eval1620000008_fn__1620000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_process_eval1620000008_fn__1620000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_java_process_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_java_process_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_java_process_A_const_8), A_arbace_java_process_A_const_6.GetRawRoot__O(), A_arbace_java_process_A_const_7) }




















func A_arbace_java_process_fn__1620000014_A_New() *A_arbace_java_process_fn__1620000014_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_fn__1620000014_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_java_process_fn__1620000014_A) Ctor() {}
//line :30:1
func (t *A_arbace_java_process_fn__1620000014_A) Invoke_O__O(self any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_process_A_const_9.GetRawRoot__O()); var tmp2 *jrt.String
	if jrt.NN(jrt.System_GetProperty_String__String(Lit_16)).StartsWith_String__Z(Lit_17) { tmp2 = Lit_18 } else { tmp2 = Lit_19 }
//line :31:1
	return tmp1.Invoke_O__O(tmp2.Ref())
}



func A_arbace_java_process_to_file_A_New() *A_arbace_java_process_to_file_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_to_file_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_java_process_to_file_A) Ctor() {}
//line :36:1
func (t *A_arbace_java_process_to_file_A) DoInvoke_O_O_O__O(self, f__0, p__1620000016__1 any) any { var map__1620000017__3 any = p__1620000016__1; var map__1620000017__4 any; if lang.ISeq_InstanceOf(map__1620000017__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_java_process_A_const_10.GetRawRoot__O()).Invoke_O__O(map__1620000017__3)) { map__1620000017__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_java_process_A_const_11.GetRawRoot__O()).Invoke_O__O(map__1620000017__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_java_process_A_const_12.GetRawRoot__O()).Invoke_O__O(map__1620000017__3)) { map__1620000017__4 = lang.IFn_Cast(A_arbace_java_process_A_const_13.GetRawRoot__O()).Invoke_O__O(map__1620000017__3) } else { lang.PersistentArrayMap_Init(); map__1620000017__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1620000017__4 = map__1620000017__3 }; var opts__5 any = map__1620000017__4; var append__6 any = lang.RT_Get_O_O__O(map__1620000017__4, A_arbace_java_process_A_const_14); var fo__7 any = lang.IFn_Cast(A_arbace_java_process_A_const_9.GetRawRoot__O()).Invoke_O__O(f__0); _ = opts__5; if





	jrt.J2g_Truth(append__6) {
		return jrt.ProcessBuilder_Redirect_AppendTo_File__ProcessBuilder_Redirect(jrt.File_Cast(fo__7)) } else {
			return jrt.ProcessBuilder_Redirect_To_File__ProcessBuilder_Redirect(jrt.File_Cast(fo__7)) } }

func A_arbace_java_process_from_file_A_New() *A_arbace_java_process_from_file_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_from_file_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_java_process_from_file_A) Ctor() {}
//line :46:1
func (t *A_arbace_java_process_from_file_A) Invoke_O_O__O(self, f__0 any) any {




	return jrt.ProcessBuilder_Redirect_From_File__ProcessBuilder_Redirect(jrt.File_Cast(lang.IFn_Cast(A_arbace_java_process_A_const_9.GetRawRoot__O()).Invoke_O__O(f__0)))
}
func A_arbace_java_process_start_A_New() *A_arbace_java_process_start_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_start_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_java_process_start_A) Ctor() {}
//line :53:1
func (t *A_arbace_java_process_start_A) DoInvoke_O_O__O(self, opts_PLUS_args__0 any) any { var vec__1620000021__2 any; if















	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_java_process_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_process_A_const_13.GetRawRoot__O()).Invoke_O__O(opts_PLUS_args__0))) { vec__1620000021__2 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_java_process_A_const_13.GetRawRoot__O()).Invoke_O__O(opts_PLUS_args__0), lang.IFn_Cast(A_arbace_java_process_A_const_26.GetRawRoot__O()).Invoke_O__O(opts_PLUS_args__0)) } else { var tmp1 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp1 = lang.PersistentArrayMap_EMPTY; vec__1620000021__2 = lang.Tuple_Create_O_O__IPersistentVector(tmp1.Ref(), opts_PLUS_args__0) }; var opts__3 any = /*line :53:1*/lang.RT_Nth_O_I_O__O(vec__1620000021__2, lang.RT_IntCast_J__I(0), nil); var command__4 any = lang.RT_Nth_O_I_O__O(vec__1620000021__2, lang.RT_IntCast_J__I(1), nil); var default__1620000026__5 any = A_arbace_java_process_A_const_16; var default__1620000027__6 any = A_arbace_java_process_A_const_16; var default__1620000028__7 any = A_arbace_java_process_A_const_16; var default__1620000029__8 any = Lit_20; var map__1620000024__9 any = opts__3; var map__1620000024__10 any; if















	lang.ISeq_InstanceOf(map__1620000024__9) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_java_process_A_const_10.GetRawRoot__O()).Invoke_O__O(map__1620000024__9)) { map__1620000024__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_java_process_A_const_11.GetRawRoot__O()).Invoke_O__O(map__1620000024__9), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_java_process_A_const_12.GetRawRoot__O()).Invoke_O__O(map__1620000024__9)) { map__1620000024__10 = lang.IFn_Cast(A_arbace_java_process_A_const_13.GetRawRoot__O()).Invoke_O__O(map__1620000024__9) } else { lang.PersistentArrayMap_Init(); map__1620000024__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1620000024__10 = map__1620000024__9 }; var in__11 any = /*line :53:1*/lang.RT_Get_O_O_O__O(map__1620000024__10, A_arbace_java_process_A_const_17, default__1620000026__5); var out__12 any = lang.RT_Get_O_O_O__O(map__1620000024__10, A_arbace_java_process_A_const_18, default__1620000027__6); var err__13 any = lang.RT_Get_O_O_O__O(map__1620000024__10, A_arbace_java_process_A_const_19, default__1620000028__7); var dir__14 any = lang.RT_Get_O_O_O__O(map__1620000024__10, A_arbace_java_process_A_const_20, default__1620000029__8); var env__15 any = lang.RT_Get_O_O__O(map__1620000024__10, A_arbace_java_process_A_const_21); var clear_env__16 any = lang.RT_Get_O_O__O(map__1620000024__10, A_arbace_java_process_A_const_22); var pb__17 any = jrt.ProcessBuilder_New_List(jrt.List_Cast(command__4)); var to_redirect__18 any; var tmp2 any = A_arbace_java_process_start_to_redirect__1620000031_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_java_process_start_to_redirect__1620000031_A_fn_class; if





















	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_java_process_start_to_redirect__1620000031_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; to_redirect__18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil);







	jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).Directory_File__ProcessBuilder(jrt.File_Cast(lang.IFn_Cast(A_arbace_java_process_A_const_9.GetRawRoot__O()).Invoke_O__O(dir__14)));
	jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).RedirectInput_ProcessBuilder_Redirect__ProcessBuilder(jrt.ProcessBuilder_Redirect_Cast(lang.IFn_Cast(to_redirect__18).Invoke_O__O(in__11)));
	jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).RedirectOutput_ProcessBuilder_Redirect__ProcessBuilder(jrt.ProcessBuilder_Redirect_Cast(lang.IFn_Cast(to_redirect__18).Invoke_O__O(out__12))); if
	lang.Util_Equiv_O_O__Z(err__13, A_arbace_java_process_A_const_27) {
		var tmp4 *jrt.ProcessBuilder = jrt.ProcessBuilder_Cast(pb__17); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; jrt.NN(tmp4).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(tmp5).BooleanValue__Z()) } else {
			jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).RedirectError_ProcessBuilder_Redirect__ProcessBuilder(jrt.ProcessBuilder_Redirect_Cast(lang.IFn_Cast(to_redirect__18).Invoke_O__O(err__13))) }; if
	jrt.J2g_Truth(clear_env__16) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).Environment__Map().Clear__V() }; if
	jrt.J2g_Truth(env__15) { var pb_env__19 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).Environment__Map(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_java_process_A_const_28.GetRawRoot__O()); var tmp7 any = A_arbace_java_process_start_fn__1620000035_A_New_O(pb_env__19); var tmp8 *jrt.Class
		var fncls__3 /*line :91:1*/*jrt.Class = A_arbace_java_process_start_fn__1620000035_A_fn_class

		if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_java_process_start_fn__1620000035_A_fn_class = fncls__3d; tmp8 = fncls__3d } else { tmp8 = fncls__3 }; tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), env__15) }; return /*line :94:1*/ jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).Start__Process() }
//line :75:1
func A_arbace_java_process_start_to_redirect__1620000031_A_New() *A_arbace_java_process_start_to_redirect__1620000031_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_start_to_redirect__1620000031_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_java_process_start_to_redirect__1620000031_A) Ctor() {}
//line :75:1
func (t *A_arbace_java_process_start_to_redirect__1620000031_A) Invoke_O_O__O(self, x__1 any) any { var G__1620000032__2_ any = x__1; switch

	lang.Util_Hash_O__I(G__1620000032__2_) >> 1 & 3 { case 1: if any(G__1620000032__2_) == any(A_arbace_java_process_A_const_16) { jrt.ProcessBuilder_Redirect_Init(); return jrt.ProcessBuilder_Redirect_PIPE }; case 2: if any(G__1620000032__2_) == any(A_arbace_java_process_A_const_23) { jrt.ProcessBuilder_Redirect_Init(); return jrt.ProcessBuilder_Redirect_INHERIT }; case 3: if any(G__1620000032__2_) == any(A_arbace_java_process_A_const_24) {


		return jrt.ProcessBuilder_Redirect_To_File__ProcessBuilder_Redirect(jrt.File_Cast(lang.IFn_Cast(A_arbace_java_process_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_java_process_A_const_25.GetRawRoot__O()))) }
//line :77:1
	default:}; return x__1 }















func A_arbace_java_process_start_fn__1620000035_A_New_O(p0 any) *A_arbace_java_process_start_fn__1620000035_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_start_fn__1620000035_A{}; t.Ctor_O(p0); return t }
//line :93:1
func (t *A_arbace_java_process_start_fn__1620000035_A) Ctor_O(c__pb_env any) { t.F_pb_env = c__pb_env }
//line :93:1
func (t *A_arbace_java_process_start_fn__1620000035_A) Invoke_O_O__O(self, p__1620000034__1 any) any { var vec__1620000036__2 any = p__1620000034__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1620000036__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1620000036__2, lang.RT_IntCast_J__I(1), nil); return jrt.Map_Cast(t.F_pb_env).Put_O_O__O(k__3, v__4) }


func A_arbace_java_process_stdin_A_New() *A_arbace_java_process_stdin_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_stdin_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_java_process_stdin_A) Ctor() {}
//line :96:1
func (t *A_arbace_java_process_stdin_A) Invoke_O_O__O(self, process__0 any) any {



	return jrt.Process_Cast(process__0).GetOutputStream__OutputStream()
}
func A_arbace_java_process_stdout_A_New() *A_arbace_java_process_stdout_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_stdout_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_java_process_stdout_A) Ctor() {}
//line :102:1
func (t *A_arbace_java_process_stdout_A) Invoke_O_O__O(self, process__0 any) any {



	return jrt.Process_Cast(process__0).GetInputStream__InputStream()
}
func A_arbace_java_process_stderr_A_New() *A_arbace_java_process_stderr_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_stderr_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_java_process_stderr_A) Ctor() {}
//line :108:1
func (t *A_arbace_java_process_stderr_A) Invoke_O_O__O(self, process__0 any) any {



	return jrt.Process_Cast(process__0).GetErrorStream__InputStream()
}
func A_arbace_java_process_exit_ref_A_New() *A_arbace_java_process_exit_ref_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_exit_ref_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_java_process_exit_ref_A) Ctor() {}
//line :114:1
func (t *A_arbace_java_process_exit_ref_A) Invoke_O_O__O(self, process__0 any) any {




	return A_arbace_java_process_exit_ref_reify__1620000044_A_New_IPersistentMap_O(nil, process__0) }
//line :119:1
func A_arbace_java_process_exit_ref_reify__1620000044_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_java_process_exit_ref_reify__1620000044_A { t := &A_arbace_java_process_exit_ref_reify__1620000044_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__process any) { t.F___meta = meta__; t.F_process = c__process }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Deref_J_O__O(timeout_ms__1 int64, timeout_val__2 any) any {





	var tmp1 jrt.Process_I = jrt.Process_Cast(t.F_process); var tmp2 *jrt.TimeUnit; jrt.TimeUnit_Init(); tmp2 = jrt.TimeUnit_MILLISECONDS; if tmp1.WaitFor_J_TimeUnit__Z(timeout_ms__1, tmp2) {
		return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_I__J(jrt.Process_Cast(t.F_process).ExitValue__I())).Ref() } else {
//line :125:1
			return timeout_val__2 } }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Deref__O() any {

	return jrt.Long_ValueOf_J__Long(lang.RT_LongCast_I__J(jrt.Process_Cast(t.F_process).WaitFor__I())).Ref() }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_java_process_exit_ref_reify__1620000044_A_New_IPersistentMap_O(m, t.F_process) }












func A_arbace_java_process_eval1620000047_reify__1620000048_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_java_process_eval1620000047_reify__1620000048_A { t := &A_arbace_java_process_eval1620000047_reify__1620000048_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :132:1
func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__counter any) { t.F___meta = meta__; t.F_counter = c__counter }
//line :132:1
func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) NewThread_Runnable__Thread(r__1 jrt.Runnable) jrt.Thread_I { var tmp1 any; var G__1620000049__2_ any = jrt.Thread_New_Runnable(r__1); var tmp2 jrt.Thread_I = jrt.Thread_Cast(G__1620000049__2_); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp4 *lang.Var;


	A_arbace_java_process_A_Init(); tmp4 = A_arbace_java_process_A_const_29; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = t.F_counter; var tmp7 *lang.Var; A_arbace_java_process_A_Init(); tmp7 = A_arbace_java_process_A_const_30; tmp2.SetName_String__V(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5.Invoke_O_O__O(tmp6, jrt.NN(tmp7).GetRawRoot__O())))); var tmp8 jrt.Thread_I =
	jrt.Thread_Cast(G__1620000049__2_); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; tmp8.SetDaemon_Z__V(jrt.NN(tmp9).BooleanValue__Z()); tmp1 = G__1620000049__2_; return /*line :132:1*/ jrt.Thread_Cast(tmp1) }
//line :132:1
func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :132:1
func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_java_process_eval1620000047_reify__1620000048_A_New_IPersistentMap_O(m, t.F_counter) }









func A_arbace_java_process_io_task_A_New() *A_arbace_java_process_io_task_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_io_task_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_java_process_io_task_A) Ctor() {}
//line :142:1
func (t *A_arbace_java_process_io_task_A) Invoke_O_O__O(self, f__0 any) any { var f__2 any = lang.IFn_Cast(A_arbace_java_process_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0); var fut__3 any = jrt.ExecutorService_Cast(A_arbace_java_process_A_const_32.GetRawRoot__O()).Submit_Callable__Future(jrt.Callable_Cast(f__2)); return /*line :147:1*/ A_arbace_java_process_io_task_reify__1620000054_A_New_IPersistentMap_O(nil, fut__3) }
//line :147:1
func A_arbace_java_process_io_task_reify__1620000054_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_java_process_io_task_reify__1620000054_A { t := &A_arbace_java_process_io_task_reify__1620000054_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__fut any) { t.F___meta = meta__; t.F_fut = c__fut }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Cancel_Z__Z(interrupt_QMARK___1 bool) bool {













	return jrt.Future_Cast(t.F_fut).Cancel_Z__Z(interrupt_QMARK___1) }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) IsDone__Z() bool {












	return jrt.Future_Cast(t.F_fut).IsDone__Z() }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) IsCancelled__Z() bool {











	return jrt.Future_Cast(t.F_fut).IsCancelled__Z() }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Get_J_TimeUnit__O(timeout__1 int64, unit__2 *jrt.TimeUnit) any {










	var tmp1 jrt.Future = jrt.Future_Cast(t.F_fut); return tmp1.Get_J_TimeUnit__O(timeout__1, unit__2) }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Get__O() any {









	return jrt.Future_Cast(t.F_fut).Get__O() }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) IsRealized__Z() bool {







	return jrt.Future_Cast(t.F_fut).IsDone__Z() }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Deref_J_O__O(timeout_ms__1 int64, timeout_val__2 any) any {





	var tmp1 *lang.Var; A_arbace_java_process_A_Init(); tmp1 = A_arbace_java_process_A_const_33; var tmp2 lang.IFn = Up_Var_IFn(tmp1); var tmp3 any = t.F_fut; return tmp2.Invoke_O_O_O__O(tmp3, jrt.Long_ValueOf_J__Long(timeout_ms__1).Ref(), timeout_val__2) }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Deref__O() any {

	var tmp1 *lang.Var; A_arbace_java_process_A_Init(); tmp1 = A_arbace_java_process_A_const_33; return Up_Var_IFn(tmp1).Invoke_O__O(t.F_fut) }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_java_process_io_task_reify__1620000054_A_New_IPersistentMap_O(m, t.F_fut) }















func A_arbace_java_process_exec_A_New() *A_arbace_java_process_exec_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_exec_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_java_process_exec_A) Ctor() {}
//line :163:1
func (t *A_arbace_java_process_exec_A) DoInvoke_O_O__O(self, opts_PLUS_args__0 any) any { var vec__1620000057__2 any; if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_java_process_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_process_A_const_13.GetRawRoot__O()).Invoke_O__O(opts_PLUS_args__0))) { vec__1620000057__2 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_java_process_A_const_13.GetRawRoot__O()).Invoke_O__O(opts_PLUS_args__0), lang.IFn_Cast(A_arbace_java_process_A_const_26.GetRawRoot__O()).Invoke_O__O(opts_PLUS_args__0)) } else { var tmp1 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp1 = lang.PersistentArrayMap_EMPTY; vec__1620000057__2 = lang.Tuple_Create_O_O__IPersistentVector(tmp1.Ref(), opts_PLUS_args__0) }; var opts__3 any = /*line :163:1*/lang.RT_Nth_O_I_O__O(vec__1620000057__2, lang.RT_IntCast_J__I(0), nil); var command__4 any = lang.RT_Nth_O_I_O__O(vec__1620000057__2, lang.RT_IntCast_J__I(1), nil); var opts__5 any = lang.IFn_Cast(A_arbace_java_process_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_process_A_const_37, opts__3); var proc__6 any = lang.IFn_Cast(A_arbace_java_process_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_java_process_A_const_38.GetRawRoot__O(), opts__5, command__4); var captured__7 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_java_process_A_const_36.GetRawRoot__O()); var tmp3 any = A_arbace_java_process_exec_fn__1620000060_A_New_O(proc__6); var tmp4 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_java_process_exec_fn__1620000060_A_fn_class; if










	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_java_process_exec_fn__1620000060_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }; captured__7 = tmp2.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var exit__8 any = /*line :163:1*/lang.IFn_Cast(A_arbace_java_process_A_const_5.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_process_A_const_41.GetRawRoot__O()).Invoke_O__O(proc__6)); if












	lang.Numbers_IsZero_O__Z(exit__8) { return lang.IFn_Cast(A_arbace_java_process_A_const_5.GetRawRoot__O()).Invoke_O__O(captured__7) } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, exit__8))))) } }
//line :174:1
func A_arbace_java_process_exec_fn__1620000060_A_New_O(p0 any) *A_arbace_java_process_exec_fn__1620000060_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_exec_fn__1620000060_A{}; t.Ctor_O(p0); return t }
//line :174:1
func (t *A_arbace_java_process_exec_fn__1620000060_A) Ctor_O(c__proc any) { t.F_proc = c__proc }
//line :174:1
func (t *A_arbace_java_process_exec_fn__1620000060_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_java_process_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_process_A_const_40.GetRawRoot__O()).Invoke_O__O(t.F_proc)) }














type A_arbace_java_process_A struct{ jrt.Object }

var A_arbace_java_process_A_const_pool *jrt.RefArray

var A_arbace_java_process_A_const_0 *lang.Var

var A_arbace_java_process_A_const_1 *lang.Var

var A_arbace_java_process_A_const_2 any

var A_arbace_java_process_A_const_3 any

var A_arbace_java_process_A_const_4 *lang.Var

var A_arbace_java_process_A_const_5 *lang.Var

var A_arbace_java_process_A_const_6 *lang.Var

var A_arbace_java_process_A_const_7 any

var A_arbace_java_process_A_const_8 *lang.Var

var A_arbace_java_process_A_const_9 *lang.Var

var A_arbace_java_process_A_const_10 *lang.Var

var A_arbace_java_process_A_const_11 *lang.Var

var A_arbace_java_process_A_const_12 *lang.Var

var A_arbace_java_process_A_const_13 *lang.Var

var A_arbace_java_process_A_const_14 *lang.Keyword

var A_arbace_java_process_A_const_15 *lang.Var

var A_arbace_java_process_A_const_16 *lang.Keyword

var A_arbace_java_process_A_const_17 *lang.Keyword

var A_arbace_java_process_A_const_18 *lang.Keyword

var A_arbace_java_process_A_const_19 *lang.Keyword

var A_arbace_java_process_A_const_20 *lang.Keyword

var A_arbace_java_process_A_const_21 *lang.Keyword

var A_arbace_java_process_A_const_22 *lang.Keyword

var A_arbace_java_process_A_const_23 *lang.Keyword

var A_arbace_java_process_A_const_24 *lang.Keyword

var A_arbace_java_process_A_const_25 *lang.Var

var A_arbace_java_process_A_const_26 *lang.Var

var A_arbace_java_process_A_const_27 *lang.Keyword

var A_arbace_java_process_A_const_28 *lang.Var

var A_arbace_java_process_A_const_29 *lang.Var

var A_arbace_java_process_A_const_30 *lang.Var

var A_arbace_java_process_A_const_31 *lang.Var

var A_arbace_java_process_A_const_32 *lang.Var

var A_arbace_java_process_A_const_33 *lang.Var

var A_arbace_java_process_A_const_34 *lang.Var

var A_arbace_java_process_A_const_35 *lang.Var

var A_arbace_java_process_A_const_36 *lang.Var

var A_arbace_java_process_A_const_37 any

var A_arbace_java_process_A_const_38 *lang.Var

var A_arbace_java_process_A_const_39 *lang.Var

var A_arbace_java_process_A_const_40 *lang.Var

var A_arbace_java_process_A_const_41 *lang.Var

var A_arbace_java_process_A_init jrt.ClassInit

func A_arbace_java_process_A_Init() { if !A_arbace_java_process_A_init.Done() { A_arbace_java_process_A_init.Run(A_arbace_java_process_A_clinit) } }

func A_arbace_java_process_A_clinit() { A_arbace_java_process_A_clinit_p0(); A_arbace_java_process_A_clinit_p1(); A_arbace_java_process_A_clinit_p2(); A_arbace_java_process_A_clinit_p3() }

func A_arbace_java_process_A_clinit_p0() { A_arbace_java_process_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 58); A_arbace_java_process_A_const_0 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[16]); A_arbace_java_process_A_const_1 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[17]); A_arbace_java_process_A_const_2 = A_arbace_java_process_A_const_pool.A[18]; A_arbace_java_process_A_const_3 = A_arbace_java_process_A_const_pool.A[19]; A_arbace_java_process_A_const_4 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[20]); A_arbace_java_process_A_const_5 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[21]); A_arbace_java_process_A_const_6 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[22]); A_arbace_java_process_A_const_7 = A_arbace_java_process_A_const_pool.A[23]; A_arbace_java_process_A_const_8 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[24]); A_arbace_java_process_A_const_9 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[25]); A_arbace_java_process_A_const_10 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[26]); A_arbace_java_process_A_const_11 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[27]) }

func A_arbace_java_process_A_clinit_p1() { A_arbace_java_process_A_const_12 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[28]); A_arbace_java_process_A_const_13 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[29]); A_arbace_java_process_A_const_14 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[30]); A_arbace_java_process_A_const_15 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[31]); A_arbace_java_process_A_const_16 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[32]); A_arbace_java_process_A_const_17 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[33]); A_arbace_java_process_A_const_18 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[34]); A_arbace_java_process_A_const_19 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[35]); A_arbace_java_process_A_const_20 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[36]); A_arbace_java_process_A_const_21 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[37]); A_arbace_java_process_A_const_22 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[38]); A_arbace_java_process_A_const_23 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[39]) }

func A_arbace_java_process_A_clinit_p2() { A_arbace_java_process_A_const_24 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[40]); A_arbace_java_process_A_const_25 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[41]); A_arbace_java_process_A_const_26 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[42]); A_arbace_java_process_A_const_27 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[43]); A_arbace_java_process_A_const_28 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[44]); A_arbace_java_process_A_const_29 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[45]); A_arbace_java_process_A_const_30 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[46]); A_arbace_java_process_A_const_31 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[47]); A_arbace_java_process_A_const_32 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[48]); A_arbace_java_process_A_const_33 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[49]); A_arbace_java_process_A_const_34 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[50]); A_arbace_java_process_A_const_35 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[51]) }

func A_arbace_java_process_A_clinit_p3() { A_arbace_java_process_A_const_36 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[52]); A_arbace_java_process_A_const_37 = A_arbace_java_process_A_const_pool.A[53]; A_arbace_java_process_A_const_38 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[54]); A_arbace_java_process_A_const_39 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[55]); A_arbace_java_process_A_const_40 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[56]); A_arbace_java_process_A_const_41 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[57]) }

func A_arbace_java_process_A_New() *A_arbace_java_process_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process_A) Ctor() {}

func (t *A_arbace_java_process_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_A_class }

func (t *A_arbace_java_process_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_A); return ok }

func A_arbace_java_process_A_Cast(x any) *A_arbace_java_process_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_A_class)) }; return v }



type A_arbace_java_process_eval1620000004_A struct{ jrt.Object }

func A_arbace_java_process_eval1620000004_A_New() *A_arbace_java_process_eval1620000004_A { t := &A_arbace_java_process_eval1620000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process_eval1620000004_A) Ctor() {}

func (t *A_arbace_java_process_eval1620000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_eval1620000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_eval1620000004_A_class }

func (t *A_arbace_java_process_eval1620000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_eval1620000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_eval1620000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_eval1620000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_eval1620000004_A); return ok }

func A_arbace_java_process_eval1620000004_A_Cast(x any) *A_arbace_java_process_eval1620000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_eval1620000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_eval1620000004_A_class)) }; return v }



type A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A struct{ j2g_header uint64 }

var A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_fn_class *jrt.Class



type A_arbace_java_process_eval1620000008_A struct{ jrt.Object }

func A_arbace_java_process_eval1620000008_A_New() *A_arbace_java_process_eval1620000008_A { t := &A_arbace_java_process_eval1620000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process_eval1620000008_A) Ctor() {}

func (t *A_arbace_java_process_eval1620000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_eval1620000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_eval1620000008_A_class }

func (t *A_arbace_java_process_eval1620000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_eval1620000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_eval1620000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_eval1620000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_eval1620000008_A); return ok }

func A_arbace_java_process_eval1620000008_A_Cast(x any) *A_arbace_java_process_eval1620000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_eval1620000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_eval1620000008_A_class)) }; return v }



type A_arbace_java_process_eval1620000008_fn__1620000009_A struct{ j2g_header uint64 }

var A_arbace_java_process_eval1620000008_fn__1620000009_A_fn_class *jrt.Class



type A_arbace_java_process_eval1620000047_A struct{ jrt.Object }

func A_arbace_java_process_eval1620000047_A_New() *A_arbace_java_process_eval1620000047_A { t := &A_arbace_java_process_eval1620000047_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process_eval1620000047_A) Ctor() {}

func (t *A_arbace_java_process_eval1620000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_eval1620000047_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_eval1620000047_A_class }

func (t *A_arbace_java_process_eval1620000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_eval1620000047_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_eval1620000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_eval1620000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_eval1620000047_A); return ok }

func A_arbace_java_process_eval1620000047_A_Cast(x any) *A_arbace_java_process_eval1620000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_eval1620000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_eval1620000047_A_class)) }; return v }



type A_arbace_java_process_eval1620000047_reify__1620000048_A struct{ jrt.Object; F_counter any; F___meta lang.IPersistentMap }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Is_ThreadFactory() {}

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Is_IObj() {}

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Is_IMeta() {}

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_eval1620000047_reify__1620000048_A_class }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_eval1620000047_reify__1620000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_eval1620000047_reify__1620000048_A); return ok }

func A_arbace_java_process_eval1620000047_reify__1620000048_A_Cast(x any) *A_arbace_java_process_eval1620000047_reify__1620000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_eval1620000047_reify__1620000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_eval1620000047_reify__1620000048_A_class)) }; return v }



type A_arbace_java_process_exec_A struct{ j2g_header uint64 }

var A_arbace_java_process_exec_A_fn_class *jrt.Class



type A_arbace_java_process_exec_fn__1620000060_A struct{ j2g_header uint64; F_proc any }

var A_arbace_java_process_exec_fn__1620000060_A_fn_class *jrt.Class



type A_arbace_java_process_exit_ref_A struct{ j2g_header uint64 }

var A_arbace_java_process_exit_ref_A_fn_class *jrt.Class



type A_arbace_java_process_exit_ref_reify__1620000044_A struct{ jrt.Object; F_process any; F___meta lang.IPersistentMap }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IBlockingDeref() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IDeref() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IObj() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_Supplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_BooleanSupplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IntSupplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_LongSupplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_DoubleSupplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IMeta() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Get__O() any { return lang.IDeref_Get__O(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetAsBoolean__Z() bool { return lang.IDeref_GetAsBoolean__Z(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetAsLong__J() int64 { return lang.IDeref_GetAsLong__J(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetAsInt__I() int32 { return lang.IDeref_GetAsInt__I(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetAsDouble__D() float64 { return lang.IDeref_GetAsDouble__D(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_exit_ref_reify__1620000044_A_class }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_exit_ref_reify__1620000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_exit_ref_reify__1620000044_A); return ok }

func A_arbace_java_process_exit_ref_reify__1620000044_A_Cast(x any) *A_arbace_java_process_exit_ref_reify__1620000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_exit_ref_reify__1620000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_exit_ref_reify__1620000044_A_class)) }; return v }



type A_arbace_java_process_fn__1620000014_A struct{ j2g_header uint64 }

var A_arbace_java_process_fn__1620000014_A_fn_class *jrt.Class



type A_arbace_java_process_from_file_A struct{ j2g_header uint64 }

var A_arbace_java_process_from_file_A_fn_class *jrt.Class



type A_arbace_java_process_io_task_A struct{ j2g_header uint64 }

var A_arbace_java_process_io_task_A_fn_class *jrt.Class



type A_arbace_java_process_io_task_reify__1620000054_A struct{ jrt.Object; F_fut any; F___meta lang.IPersistentMap }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_Future() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IBlockingDeref() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IDeref() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IPending() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IObj() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_Supplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_BooleanSupplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IntSupplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_LongSupplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_DoubleSupplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IMeta() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) State__Future_State() *jrt.Future_State { return jrt.Future_State__Future_State(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) ExceptionNow__Throwable() jrt.Throwable_I { return jrt.Future_ExceptionNow__Throwable(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetAsBoolean__Z() bool { return lang.IDeref_GetAsBoolean__Z(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetAsLong__J() int64 { return lang.IDeref_GetAsLong__J(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetAsInt__I() int32 { return lang.IDeref_GetAsInt__I(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) ResultNow__O() any { return jrt.Future_ResultNow__O(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetAsDouble__D() float64 { return lang.IDeref_GetAsDouble__D(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_io_task_reify__1620000054_A_class }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_io_task_reify__1620000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_io_task_reify__1620000054_A); return ok }

func A_arbace_java_process_io_task_reify__1620000054_A_Cast(x any) *A_arbace_java_process_io_task_reify__1620000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_io_task_reify__1620000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_io_task_reify__1620000054_A_class)) }; return v }



type A_arbace_java_process_start_A struct{ j2g_header uint64 }

var A_arbace_java_process_start_A_fn_class *jrt.Class



type A_arbace_java_process_start_fn__1620000035_A struct{ j2g_header uint64; F_pb_env any }

var A_arbace_java_process_start_fn__1620000035_A_fn_class *jrt.Class



type A_arbace_java_process_start_to_redirect__1620000031_A struct{ j2g_header uint64 }

var A_arbace_java_process_start_to_redirect__1620000031_A_fn_class *jrt.Class



type A_arbace_java_process_stderr_A struct{ j2g_header uint64 }

var A_arbace_java_process_stderr_A_fn_class *jrt.Class



type A_arbace_java_process_stdin_A struct{ j2g_header uint64 }

var A_arbace_java_process_stdin_A_fn_class *jrt.Class



type A_arbace_java_process_stdout_A struct{ j2g_header uint64 }

var A_arbace_java_process_stdout_A_fn_class *jrt.Class



type A_arbace_java_process_to_file_A struct{ j2g_header uint64 }

var A_arbace_java_process_to_file_A_fn_class *jrt.Class
