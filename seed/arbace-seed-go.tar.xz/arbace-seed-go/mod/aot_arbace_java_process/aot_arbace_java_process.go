//line aot_arbace_java_process.ae:1
package aot_arbace_java_process

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/jrt"
	"arbace/lang"
)
func A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_New() *A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_process_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_process_A_const_1); lang.IFn_Cast(A_arbace_java_process_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_java_process_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_java_process_eval1620000008_fn__1620000009_A_New() *A_arbace_java_process_eval1620000008_fn__1620000009_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_eval1620000008_fn__1620000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_process_eval1620000008_fn__1620000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_process_eval1620000008_fn__1620000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_process_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_java_process_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_java_process_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_process_A_const_7.GetRawRoot__O(), A_arbace_java_process_A_const_8) }




















func A_arbace_java_process_fn__1620000014_A_New() *A_arbace_java_process_fn__1620000014_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_fn__1620000014_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_java_process_fn__1620000014_A) Ctor() {}
//line :30:1
func (t *A_arbace_java_process_fn__1620000014_A) Invoke_O__O(self any) any {
	var root_19 any = A_arbace_java_process_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any
	if jrt.NN(jrt.System_GetProperty_String__String(Lit_16)).StartsWith_String__Z(Lit_17) { arg_22 = Lit_18 } else { arg_22 = Lit_19 }
//line :31:1
	if linked_20 == nil { return ifn_21.Invoke_O__O(arg_22) } else { return linked_20.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_19, arg_22)
	}
}


func A_arbace_java_process_to_file_A_New() *A_arbace_java_process_to_file_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_to_file_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_java_process_to_file_A) Ctor() {}
//line :36:1
func (t *A_arbace_java_process_to_file_A) DoInvoke_O_O_O__O(self, f__0, p__1620000016__1 any) any { var map__1620000017__3 any = p__1620000016__1; var map__1620000017__4 any; if lang.ISeq_InstanceOf(map__1620000017__3) { var tmp1 any; var root_23 any = A_arbace_java_process_A_const_10.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = map__1620000017__3; if linked_24 == nil { tmp1 = ifn_25.Invoke_O__O(arg_26) } else { tmp1 = linked_24.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_23, arg_26) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_27 any = A_arbace_java_process_A_const_11.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = map__1620000017__3; if linked_28 == nil { tmp2 = ifn_29.Invoke_O__O(arg_30) } else { tmp2 = linked_28.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_27, arg_30) }; map__1620000017__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_31 any = A_arbace_java_process_A_const_12.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = map__1620000017__3; if linked_32 == nil { tmp3 = ifn_33.Invoke_O__O(arg_34) } else { tmp3 = linked_32.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_31, arg_34) }; if jrt.J2g_Truth(tmp3) { var root_35 any = A_arbace_java_process_A_const_13.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = map__1620000017__3; if linked_36 == nil { map__1620000017__4 = ifn_37.Invoke_O__O(arg_38) } else { map__1620000017__4 = linked_36.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_35, arg_38) } } else { map__1620000017__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1620000017__4 = map__1620000017__3 }; var opts__5 any = map__1620000017__4; var append__6 any = lang.RT_Get_O_O__O_NoInit(map__1620000017__4, A_arbace_java_process_A_const_14); var fo__7 any; var root_39 any = A_arbace_java_process_A_const_9.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_39, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_41 lang.IFn; _ = opts__5; if




	linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = f__0; if linked_40 == nil { fo__7 = ifn_41.Invoke_O__O(arg_42) } else { fo__7 = linked_40.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_39, arg_42) }; if
	jrt.J2g_Truth(append__6) {
		return jrt.ProcessBuilder_Redirect_AppendTo_File__ProcessBuilder_Redirect(jrt.File_Cast(fo__7)) } else {
			return jrt.ProcessBuilder_Redirect_To_File__ProcessBuilder_Redirect(jrt.File_Cast(fo__7)) } }

func A_arbace_java_process_from_file_A_New() *A_arbace_java_process_from_file_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_from_file_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_java_process_from_file_A) Ctor() {}
//line :46:1
func (t *A_arbace_java_process_from_file_A) Invoke_O_O__O(self, f__0 any) any {




	var tmp1 any; var root_43 any = A_arbace_java_process_A_const_9.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_43, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = f__0; if linked_44 == nil { tmp1 = ifn_45.Invoke_O__O(arg_46) } else { tmp1 = linked_44.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_43, arg_46) }; return jrt.ProcessBuilder_Redirect_From_File__ProcessBuilder_Redirect(jrt.File_Cast(tmp1))
}
func A_arbace_java_process_start_A_New() *A_arbace_java_process_start_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_start_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_java_process_start_A) Ctor() {}
//line :53:1
func (t *A_arbace_java_process_start_A) DoInvoke_O_O__O(self, opts_PLUS_args__0 any) any { var vec__1620000021__2 any; var tmp1 any; var root_51 any = A_arbace_java_process_A_const_15.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_53 lang.IFn; if















	linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any; var root_47 any = A_arbace_java_process_A_const_13.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = opts_PLUS_args__0; if linked_48 == nil { arg_54 = ifn_49.Invoke_O__O(arg_50) } else { arg_54 = linked_48.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_47, arg_50) }; if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_51, arg_54) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_77 any = A_arbace_java_process_A_const_13.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_79 lang.IFn
		if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = opts_PLUS_args__0; if linked_78 == nil { tmp2 = ifn_79.Invoke_O__O(arg_80) } else { tmp2 = linked_78.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_77, arg_80) }
//line :69:1
		var tmp3 any = tmp2; var tmp4 any; var root_81 any = A_arbace_java_process_A_const_26.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_83 lang.IFn
		if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = opts_PLUS_args__0; if linked_82 == nil { tmp4 = ifn_83.Invoke_O__O(arg_84) } else { tmp4 = linked_82.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_81, arg_84) }
//line :69:1
		vec__1620000021__2 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { vec__1620000021__2 = lang.Tuple_Create_O_O__IPersistentVector(lang.PersistentArrayMap_EMPTY.Ref(), opts_PLUS_args__0) }; var opts__3 any = /*line :53:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1620000021__2, lang.RT_IntCast_J__I_NoInit(0), nil); var command__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1620000021__2, lang.RT_IntCast_J__I_NoInit(1), nil); var default__1620000026__5 any = A_arbace_java_process_A_const_16; var default__1620000027__6 any = A_arbace_java_process_A_const_16; var default__1620000028__7 any = A_arbace_java_process_A_const_16; var default__1620000029__8 any = Lit_20; var map__1620000024__9 any = opts__3; var map__1620000024__10 any; if















	lang.ISeq_InstanceOf(map__1620000024__9) { var tmp5 any; var root_55 any = A_arbace_java_process_A_const_10.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = map__1620000024__9; if linked_56 == nil { tmp5 = ifn_57.Invoke_O__O(arg_58) } else { tmp5 = linked_56.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_55, arg_58) }; if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_59 any = A_arbace_java_process_A_const_11.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = map__1620000024__9; if linked_60 == nil { tmp6 = ifn_61.Invoke_O__O(arg_62) } else { tmp6 = linked_60.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_59, arg_62) }; map__1620000024__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp6, jrt.Object_class.ArrayClass())).Ref() } else { var tmp7 any; var root_63 any = A_arbace_java_process_A_const_12.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = map__1620000024__9; if linked_64 == nil { tmp7 = ifn_65.Invoke_O__O(arg_66) } else { tmp7 = linked_64.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_63, arg_66) }; if jrt.J2g_Truth(tmp7) { var root_67 any = A_arbace_java_process_A_const_13.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = map__1620000024__9; if linked_68 == nil { map__1620000024__10 = ifn_69.Invoke_O__O(arg_70) } else { map__1620000024__10 = linked_68.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_67, arg_70) } } else { map__1620000024__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1620000024__10 = map__1620000024__9 }; var in__11 any = /*line :53:1*/lang.RT_Get_O_O_O__O_NoInit(map__1620000024__10, A_arbace_java_process_A_const_17, default__1620000026__5); var out__12 any = lang.RT_Get_O_O_O__O_NoInit(map__1620000024__10, A_arbace_java_process_A_const_18, default__1620000027__6); var err__13 any = lang.RT_Get_O_O_O__O_NoInit(map__1620000024__10, A_arbace_java_process_A_const_19, default__1620000028__7); var dir__14 any = lang.RT_Get_O_O_O__O_NoInit(map__1620000024__10, A_arbace_java_process_A_const_20, default__1620000029__8); var env__15 any = lang.RT_Get_O_O__O_NoInit(map__1620000024__10, A_arbace_java_process_A_const_21); var clear_env__16 any = lang.RT_Get_O_O__O_NoInit(map__1620000024__10, A_arbace_java_process_A_const_22); var pb__17 any = jrt.ProcessBuilder_New_List(jrt.List_Cast(command__4)); var to_redirect__18 any; var tmp8 any = A_arbace_java_process_start_to_redirect__1620000031_A_New(); var tmp9 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_java_process_start_to_redirect__1620000031_A_fn_class; if





















	fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_java_process_start_to_redirect__1620000031_A_fn_class = fncls__76d; tmp9 = fncls__76d } else { tmp9 = fncls__76 }; to_redirect__18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 /*line :83:1*/*jrt.ProcessBuilder = jrt.ProcessBuilder_Cast(pb__17); var tmp11 any; var root_85 any = A_arbace_java_process_A_const_9.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_85, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = dir__14; if linked_86 == nil { tmp11 = ifn_87.Invoke_O__O(arg_88) } else { tmp11 = linked_86.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_85, arg_88) }; jrt.NN(tmp10).Directory_File__ProcessBuilder(jrt.File_Cast(tmp11));
	jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).RedirectInput_ProcessBuilder_Redirect__ProcessBuilder(jrt.ProcessBuilder_Redirect_Cast(lang.IFn_Cast(to_redirect__18).Invoke_O__O(in__11)));
	jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).RedirectOutput_ProcessBuilder_Redirect__ProcessBuilder(jrt.ProcessBuilder_Redirect_Cast(lang.IFn_Cast(to_redirect__18).Invoke_O__O(out__12))); if
	lang.Util_Equiv_O_O__Z_NoInit(err__13, A_arbace_java_process_A_const_27) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z()) } else {
			jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).RedirectError_ProcessBuilder_Redirect__ProcessBuilder(jrt.ProcessBuilder_Redirect_Cast(lang.IFn_Cast(to_redirect__18).Invoke_O__O(err__13))) }; if
	jrt.J2g_Truth(clear_env__16) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).Environment__Map().Clear__V() }; if
	jrt.J2g_Truth(env__15) { var pb_env__19 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).Environment__Map(); var root_90 any = A_arbace_java_process_A_const_28.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_92 lang.IFn

		if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any; var tmp12 any = A_arbace_java_process_start_fn__1620000035_A_New_O(pb_env__19); var tmp13 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_java_process_start_fn__1620000035_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_java_process_start_fn__1620000035_A_fn_class = fncls__89d; tmp13 = fncls__89d } else { tmp13 = fncls__89 }; arg_93 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_94 any = env__15; if linked_91 == nil { ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { linked_91.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_90, arg_93, arg_94) } }; return /*line :94:1*/ jrt.NN(jrt.ProcessBuilder_Cast(pb__17)).Start__Process() }
//line :75:1
func A_arbace_java_process_start_to_redirect__1620000031_A_New() *A_arbace_java_process_start_to_redirect__1620000031_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_start_to_redirect__1620000031_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_java_process_start_to_redirect__1620000031_A) Ctor() {}
//line :75:1
func (t *A_arbace_java_process_start_to_redirect__1620000031_A) Invoke_O_O__O(self, x__1 any) any { var G__1620000032__2_ any = x__1; switch

	lang.Util_Hash_O__I_NoInit(G__1620000032__2_) >> 1 & 3 { case 1: if any(G__1620000032__2_) == any(A_arbace_java_process_A_const_16) { jrt.ProcessBuilder_Redirect_Init(); return jrt.ProcessBuilder_Redirect_PIPE }; case 2: if any(G__1620000032__2_) == any(A_arbace_java_process_A_const_23) { jrt.ProcessBuilder_Redirect_Init(); return jrt.ProcessBuilder_Redirect_INHERIT }; case 3: if any(G__1620000032__2_) == any(A_arbace_java_process_A_const_24) {


		var tmp1 any; var root_72 any = A_arbace_java_process_A_const_5.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = A_arbace_java_process_A_const_25.GetRawRoot__O(); if linked_73 == nil { tmp1 = ifn_74.Invoke_O__O(arg_75) } else { tmp1 = linked_73.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_72, arg_75) }; return jrt.ProcessBuilder_Redirect_To_File__ProcessBuilder_Redirect(jrt.File_Cast(tmp1)) }
//line :77:1
	default:}; return x__1 }















func A_arbace_java_process_start_fn__1620000035_A_New_O(p0 any) *A_arbace_java_process_start_fn__1620000035_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_start_fn__1620000035_A{}; t.Ctor_O(p0); return t }
//line :93:1
func (t *A_arbace_java_process_start_fn__1620000035_A) Ctor_O(c__pb_env any) { t.F_pb_env = c__pb_env }
//line :93:1
func (t *A_arbace_java_process_start_fn__1620000035_A) Invoke_O_O__O(self, p__1620000034__1 any) any { var vec__1620000036__2 any = p__1620000034__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1620000036__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1620000036__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Map_Cast(t.F_pb_env).Put_O_O__O(k__3, v__4) }


func A_arbace_java_process_stdin_A_New() *A_arbace_java_process_stdin_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_stdin_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_java_process_stdin_A) Ctor() {}
//line :96:1
func (t *A_arbace_java_process_stdin_A) Invoke_O_O__O(self, process__0 any) any {



	return jrt.Process_Cast(process__0).GetOutputStream__OutputStream()
}
func A_arbace_java_process_stdout_A_New() *A_arbace_java_process_stdout_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_stdout_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_java_process_stdout_A) Ctor() {}
//line :102:1
func (t *A_arbace_java_process_stdout_A) Invoke_O_O__O(self, process__0 any) any {



	return jrt.Process_Cast(process__0).GetInputStream__InputStream()
}
func A_arbace_java_process_stderr_A_New() *A_arbace_java_process_stderr_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_stderr_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_java_process_stderr_A) Ctor() {}
//line :108:1
func (t *A_arbace_java_process_stderr_A) Invoke_O_O__O(self, process__0 any) any {



	return jrt.Process_Cast(process__0).GetErrorStream__InputStream()
}
func A_arbace_java_process_exit_ref_A_New() *A_arbace_java_process_exit_ref_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_exit_ref_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_java_process_exit_ref_A) Ctor() {}
//line :114:1
func (t *A_arbace_java_process_exit_ref_A) Invoke_O_O__O(self, process__0 any) any {




	return A_arbace_java_process_exit_ref_reify__1620000044_A_New_IPersistentMap_O(nil, process__0) }
//line :119:1
func A_arbace_java_process_exit_ref_reify__1620000044_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_java_process_exit_ref_reify__1620000044_A { t := &A_arbace_java_process_exit_ref_reify__1620000044_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__process any) { t.F___meta = meta__; t.F_process = c__process }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Deref_J_O__O(timeout_ms__1 int64, timeout_val__2 any) any {





	var tmp1 jrt.Process_I = jrt.Process_Cast(t.F_process); if tmp1.WaitFor_J_TimeUnit__Z(timeout_ms__1, jrt.TimeUnit_MILLISECONDS) {
		return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(jrt.Process_Cast(t.F_process).ExitValue__I())).Ref() } else {
//line :125:1
			return timeout_val__2 } }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Deref__O() any {

	return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(jrt.Process_Cast(t.F_process).WaitFor__I())).Ref() }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :119:1
func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_java_process_exit_ref_reify__1620000044_A_New_IPersistentMap_O(m, t.F_process) }












func A_arbace_java_process_eval1620000047_reify__1620000048_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_java_process_eval1620000047_reify__1620000048_A { t := &A_arbace_java_process_eval1620000047_reify__1620000048_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :132:1
func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__counter any) { t.F___meta = meta__; t.F_counter = c__counter }
//line :132:1
func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) NewThread_Runnable__Thread(r__1 jrt.Runnable) jrt.Thread_I { var tmp1 any; var G__1620000049__2_ any = jrt.Thread_New_Runnable(r__1); var tmp2 jrt.Thread_I = jrt.Thread_Cast(G__1620000049__2_); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp4 any; var root_95 any; var tmp5 *lang.Var;


	A_arbace_java_process_A_Init(); tmp5 = A_arbace_java_process_A_const_29; root_95 = jrt.NN(tmp5).GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = t.F_counter; var arg_99 any; var tmp6 *lang.Var; A_arbace_java_process_A_Init(); tmp6 = A_arbace_java_process_A_const_30; arg_99 = jrt.NN(tmp6).GetRawRoot__O(); if linked_96 == nil { tmp4 = ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { tmp4 = linked_96.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_95, arg_98, arg_99) }; tmp2.SetName_String__V(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp4)));
	jrt.Thread_Cast(G__1620000049__2_).SetDaemon_Z__V(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z()); tmp1 = G__1620000049__2_; return /*line :132:1*/ jrt.Thread_Cast(tmp1) }
//line :132:1
func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :132:1
func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_java_process_eval1620000047_reify__1620000048_A_New_IPersistentMap_O(m, t.F_counter) }









func A_arbace_java_process_io_task_A_New() *A_arbace_java_process_io_task_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_io_task_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_java_process_io_task_A) Ctor() {}
//line :142:1
func (t *A_arbace_java_process_io_task_A) Invoke_O_O__O(self, f__0 any) any { var f__2 any; var root_100 any = A_arbace_java_process_A_const_31.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_bound_fn_STAR__A_fn_class); var ifn_102 lang.IFn; if


	linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = f__0; if linked_101 == nil { f__2 = ifn_102.Invoke_O__O(arg_103) } else { f__2 = linked_101.(*aot_arbace_core.A_arbace_core_bound_fn_STAR__A).Invoke_O_O__O(root_100, arg_103) }; var fut__3 any = /*line :142:1*/jrt.ExecutorService_Cast(A_arbace_java_process_A_const_32.GetRawRoot__O()).Submit_Callable__Future(jrt.Callable_Cast(f__2)); return /*line :147:1*/ A_arbace_java_process_io_task_reify__1620000054_A_New_IPersistentMap_O(nil, fut__3) }
//line :147:1
func A_arbace_java_process_io_task_reify__1620000054_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_java_process_io_task_reify__1620000054_A { t := &A_arbace_java_process_io_task_reify__1620000054_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__fut any) { t.F___meta = meta__; t.F_fut = c__fut }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Cancel_Z__Z(interrupt_QMARK___1 bool) bool {













	return jrt.Future_Cast(t.F_fut).Cancel_Z__Z(interrupt_QMARK___1) }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) IsDone__Z() bool {












	return jrt.Future_Cast(t.F_fut).IsDone__Z() }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) IsCancelled__Z() bool {











	return jrt.Future_Cast(t.F_fut).IsCancelled__Z() }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Get_J_TimeUnit__O(timeout__1 int64, unit__2 *jrt.TimeUnit) any {










	var tmp1 jrt.Future = jrt.Future_Cast(t.F_fut); return tmp1.Get_J_TimeUnit__O(timeout__1, unit__2) }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Get__O() any {









	return jrt.Future_Cast(t.F_fut).Get__O() }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) IsRealized__Z() bool {







	return jrt.Future_Cast(t.F_fut).IsDone__Z() }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Deref_J_O__O(timeout_ms__1 int64, timeout_val__2 any) any {





	var tmp1 *lang.Var; A_arbace_java_process_A_Init(); tmp1 = A_arbace_java_process_A_const_33; var tmp2 lang.IFn = Up_Var_IFn(tmp1); var tmp3 any = t.F_fut; return tmp2.Invoke_O_O_O__O(tmp3, jrt.Long_ValueOf_J__Long_NoInit(timeout_ms__1).Ref(), timeout_val__2) }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Deref__O() any {

	var tmp1 *lang.Var; A_arbace_java_process_A_Init(); tmp1 = A_arbace_java_process_A_const_33; return Up_Var_IFn(tmp1).Invoke_O__O(t.F_fut) }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :147:1
func (t *A_arbace_java_process_io_task_reify__1620000054_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_java_process_io_task_reify__1620000054_A_New_IPersistentMap_O(m, t.F_fut) }















func A_arbace_java_process_exec_A_New() *A_arbace_java_process_exec_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_exec_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_java_process_exec_A) Ctor() {}
//line :163:1
func (t *A_arbace_java_process_exec_A) DoInvoke_O_O__O(self, opts_PLUS_args__0 any) any { var vec__1620000057__2 any; var tmp1 any; var root_108 any = A_arbace_java_process_A_const_15.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_110 lang.IFn; if





	linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any; var root_104 any = A_arbace_java_process_A_const_13.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = opts_PLUS_args__0; if linked_105 == nil { arg_111 = ifn_106.Invoke_O__O(arg_107) } else { arg_111 = linked_105.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_104, arg_107) }; if linked_109 == nil { tmp1 = ifn_110.Invoke_O__O(arg_111) } else { tmp1 = linked_109.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_108, arg_111) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_150 any = A_arbace_java_process_A_const_13.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_152 lang.IFn
		if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = opts_PLUS_args__0; if linked_151 == nil { tmp2 = ifn_152.Invoke_O__O(arg_153) } else { tmp2 = linked_151.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_150, arg_153) }
//line :169:1
		var tmp3 any = tmp2; var tmp4 any; var root_154 any = A_arbace_java_process_A_const_26.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_156 lang.IFn
		if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = opts_PLUS_args__0; if linked_155 == nil { tmp4 = ifn_156.Invoke_O__O(arg_157) } else { tmp4 = linked_155.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_154, arg_157) }
//line :169:1
		vec__1620000057__2 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { vec__1620000057__2 = lang.Tuple_Create_O_O__IPersistentVector(lang.PersistentArrayMap_EMPTY.Ref(), opts_PLUS_args__0) }; var opts__3 any = /*line :163:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1620000057__2, lang.RT_IntCast_J__I_NoInit(0), nil); var command__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1620000057__2, lang.RT_IntCast_J__I_NoInit(1), nil); var opts__5 any; var root_112 any = A_arbace_java_process_A_const_34.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_114 lang.IFn; if








	linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_java_process_A_const_35; var arg_116 any = opts__3; if linked_113 == nil { opts__5 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { opts__5 = linked_113.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) }; var proc__6 any; var root_117 any = /*line :163:1*/A_arbace_java_process_A_const_36.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_119 lang.IFn; if









	linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = A_arbace_java_process_A_const_37.GetRawRoot__O(); var arg_121 any = opts__5; var arg_122 any = command__4; if linked_118 == nil { proc__6 = ifn_119.Invoke_O_O_O__O(arg_120, arg_121, arg_122) } else { proc__6 = linked_118.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_117, arg_120, arg_121, arg_122) }; var captured__7 any; var root_132 any = /*line :163:1*/A_arbace_java_process_A_const_38.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, A_arbace_java_process_io_task_A_fn_class); var ifn_134 lang.IFn; if










	linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any; var tmp5 any = A_arbace_java_process_exec_fn__1620000060_A_New_O(proc__6); var tmp6 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_java_process_exec_fn__1620000060_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_java_process_exec_fn__1620000060_A_fn_class = fncls__131d; tmp6 = fncls__131d } else { tmp6 = fncls__131 }; arg_135 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_133 == nil { captured__7 = ifn_134.Invoke_O__O(arg_135) } else { captured__7 = linked_133.(*A_arbace_java_process_io_task_A).Invoke_O_O__O(root_132, arg_135) }; var exit__8 any; var root_140 any = /*line :163:1*/A_arbace_java_process_A_const_5.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_142 lang.IFn; if











	linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any; var root_136 any = A_arbace_java_process_A_const_41.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, A_arbace_java_process_exit_ref_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = proc__6; if linked_137 == nil { arg_143 = ifn_138.Invoke_O__O(arg_139) } else { arg_143 = linked_137.(*A_arbace_java_process_exit_ref_A).Invoke_O_O__O(root_136, arg_139) }; if linked_141 == nil { exit__8 = ifn_142.Invoke_O__O(arg_143) } else { exit__8 = linked_141.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_140, arg_143) }; var tmp7 bool; var na_144 any = exit__8; if
	jrt.Long_InstanceOf(na_144) { var n0_145 int64 = jrt.NN(jrt.Long_Cast(na_144)).LongValue__J(); tmp7 = n0_145 == 0 } else { if jrt.Double_InstanceOf(na_144) { var n0_145_2 float64 = jrt.NN(jrt.Double_Cast(na_144)).DoubleValue__D(); tmp7 = n0_145_2 == 0.0 } else { tmp7 = lang.Numbers_IsZero_O__Z_NoInit(na_144) } }; if tmp7 { var root_146 any = A_arbace_java_process_A_const_5.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = captured__7; if linked_147 == nil { return ifn_148.Invoke_O__O(arg_149) } else { return linked_147.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_146, arg_149) } } else { panic(jrt.Thrown(jrt.RuntimeException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, exit__8))))) } }
//line :174:1
func A_arbace_java_process_exec_fn__1620000060_A_New_O(p0 any) *A_arbace_java_process_exec_fn__1620000060_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_exec_fn__1620000060_A{}; t.Ctor_O(p0); return t }
//line :174:1
func (t *A_arbace_java_process_exec_fn__1620000060_A) Ctor_O(c__proc any) { t.F_proc = c__proc }
//line :174:1
func (t *A_arbace_java_process_exec_fn__1620000060_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_process_A_const_39.GetRawRoot__O()); var tmp2 any; var root_123 any = A_arbace_java_process_A_const_40.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, A_arbace_java_process_stdout_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = t.F_proc; if linked_124 == nil { tmp2 = ifn_125.Invoke_O__O(arg_126) } else { tmp2 = linked_124.(*A_arbace_java_process_stdout_A).Invoke_O_O__O(root_123, arg_126) }; return tmp1.Invoke_O__O(tmp2) }














type A_arbace_java_process_A struct{ jrt.Object }

var A_arbace_java_process_A_const_pool *jrt.RefArray

var A_arbace_java_process_A_const_0 *lang.Var

var A_arbace_java_process_A_const_1 any

var A_arbace_java_process_A_const_2 *lang.Var

var A_arbace_java_process_A_const_3 any

var A_arbace_java_process_A_const_4 *lang.Var

var A_arbace_java_process_A_const_5 *lang.Var

var A_arbace_java_process_A_const_6 *lang.Var

var A_arbace_java_process_A_const_7 *lang.Var

var A_arbace_java_process_A_const_8 any

var A_arbace_java_process_A_const_9 *lang.Var

var A_arbace_java_process_A_const_10 *lang.Var

var A_arbace_java_process_A_const_11 *lang.Var

var A_arbace_java_process_A_const_12 *lang.Var

var A_arbace_java_process_A_const_13 *lang.Var

var A_arbace_java_process_A_const_14 *lang.Keyword

var A_arbace_java_process_A_const_15 *lang.Var

var A_arbace_java_process_A_const_16 *lang.Keyword

var A_arbace_java_process_A_const_17 *lang.Keyword

var A_arbace_java_process_A_const_18 *lang.Keyword

var A_arbace_java_process_A_const_19 *lang.Keyword

var A_arbace_java_process_A_const_20 *lang.Keyword

var A_arbace_java_process_A_const_21 *lang.Keyword

var A_arbace_java_process_A_const_22 *lang.Keyword

var A_arbace_java_process_A_const_23 *lang.Keyword

var A_arbace_java_process_A_const_24 *lang.Keyword

var A_arbace_java_process_A_const_25 *lang.Var

var A_arbace_java_process_A_const_26 *lang.Var

var A_arbace_java_process_A_const_27 *lang.Keyword

var A_arbace_java_process_A_const_28 *lang.Var

var A_arbace_java_process_A_const_29 *lang.Var

var A_arbace_java_process_A_const_30 *lang.Var

var A_arbace_java_process_A_const_31 *lang.Var

var A_arbace_java_process_A_const_32 *lang.Var

var A_arbace_java_process_A_const_33 *lang.Var

var A_arbace_java_process_A_const_34 *lang.Var

var A_arbace_java_process_A_const_35 any

var A_arbace_java_process_A_const_36 *lang.Var

var A_arbace_java_process_A_const_37 *lang.Var

var A_arbace_java_process_A_const_38 *lang.Var

var A_arbace_java_process_A_const_39 *lang.Var

var A_arbace_java_process_A_const_40 *lang.Var

var A_arbace_java_process_A_const_41 *lang.Var

var A_arbace_java_process_A_init jrt.ClassInit

func A_arbace_java_process_A_Init() { if !A_arbace_java_process_A_init.Done() { A_arbace_java_process_A_init.Run(A_arbace_java_process_A_clinit) } }

func A_arbace_java_process_A_clinit() { A_arbace_java_process_A_clinit_p0(); A_arbace_java_process_A_clinit_p1(); A_arbace_java_process_A_clinit_p2(); A_arbace_java_process_A_clinit_p3() }

func A_arbace_java_process_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_process_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 58); A_arbace_java_process_A_const_0 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[16]); A_arbace_java_process_A_const_1 = A_arbace_java_process_A_const_pool.A[17]; A_arbace_java_process_A_const_2 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[18]); A_arbace_java_process_A_const_3 = A_arbace_java_process_A_const_pool.A[19]; A_arbace_java_process_A_const_4 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[20]); A_arbace_java_process_A_const_5 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[21]); A_arbace_java_process_A_const_6 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[22]); A_arbace_java_process_A_const_7 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[23]); A_arbace_java_process_A_const_8 = A_arbace_java_process_A_const_pool.A[24]; A_arbace_java_process_A_const_9 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[25]); A_arbace_java_process_A_const_10 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[26]); A_arbace_java_process_A_const_11 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[27]) }

func A_arbace_java_process_A_clinit_p1() { A_arbace_java_process_A_const_12 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[28]); A_arbace_java_process_A_const_13 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[29]); A_arbace_java_process_A_const_14 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[30]); A_arbace_java_process_A_const_15 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[31]); A_arbace_java_process_A_const_16 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[32]); A_arbace_java_process_A_const_17 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[33]); A_arbace_java_process_A_const_18 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[34]); A_arbace_java_process_A_const_19 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[35]); A_arbace_java_process_A_const_20 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[36]); A_arbace_java_process_A_const_21 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[37]); A_arbace_java_process_A_const_22 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[38]); A_arbace_java_process_A_const_23 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[39]) }

func A_arbace_java_process_A_clinit_p2() { A_arbace_java_process_A_const_24 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[40]); A_arbace_java_process_A_const_25 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[41]); A_arbace_java_process_A_const_26 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[42]); A_arbace_java_process_A_const_27 = lang.Keyword_Cast(A_arbace_java_process_A_const_pool.A[43]); A_arbace_java_process_A_const_28 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[44]); A_arbace_java_process_A_const_29 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[45]); A_arbace_java_process_A_const_30 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[46]); A_arbace_java_process_A_const_31 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[47]); A_arbace_java_process_A_const_32 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[48]); A_arbace_java_process_A_const_33 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[49]); A_arbace_java_process_A_const_34 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[50]); A_arbace_java_process_A_const_35 = A_arbace_java_process_A_const_pool.A[51] }

func A_arbace_java_process_A_clinit_p3() { A_arbace_java_process_A_const_36 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[52]); A_arbace_java_process_A_const_37 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[53]); A_arbace_java_process_A_const_38 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[54]); A_arbace_java_process_A_const_39 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[55]); A_arbace_java_process_A_const_40 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[56]); A_arbace_java_process_A_const_41 = lang.Var_Cast(A_arbace_java_process_A_const_pool.A[57]) }

func A_arbace_java_process_A_New() *A_arbace_java_process_A { A_arbace_java_process_A_Init(); t := &A_arbace_java_process_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process_A) Ctor() {}

func (t *A_arbace_java_process_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_A_class }

func (t *A_arbace_java_process_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_A); return ok }

func A_arbace_java_process_A_Cast(x any) *A_arbace_java_process_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_A_class)) }; return v }



type A_arbace_java_process_eval1620000004_A struct{ jrt.Object }

func A_arbace_java_process_eval1620000004_A_New() *A_arbace_java_process_eval1620000004_A { t := &A_arbace_java_process_eval1620000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process_eval1620000004_A) Ctor() {}

func (t *A_arbace_java_process_eval1620000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_eval1620000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_eval1620000004_A_class }

func (t *A_arbace_java_process_eval1620000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_eval1620000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_eval1620000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_eval1620000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_eval1620000004_A); return ok }

func A_arbace_java_process_eval1620000004_A_Cast(x any) *A_arbace_java_process_eval1620000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_eval1620000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_eval1620000004_A_class)) }; return v }



type A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A struct{ j2g_header uint64 }

var A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_fn_class *jrt.Class



type A_arbace_java_process_eval1620000008_A struct{ jrt.Object }

func A_arbace_java_process_eval1620000008_A_New() *A_arbace_java_process_eval1620000008_A { t := &A_arbace_java_process_eval1620000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process_eval1620000008_A) Ctor() {}

func (t *A_arbace_java_process_eval1620000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_eval1620000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_eval1620000008_A_class }

func (t *A_arbace_java_process_eval1620000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_eval1620000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_eval1620000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_eval1620000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_eval1620000008_A); return ok }

func A_arbace_java_process_eval1620000008_A_Cast(x any) *A_arbace_java_process_eval1620000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_eval1620000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_eval1620000008_A_class)) }; return v }



type A_arbace_java_process_eval1620000008_fn__1620000009_A struct{ j2g_header uint64 }

var A_arbace_java_process_eval1620000008_fn__1620000009_A_fn_class *jrt.Class



type A_arbace_java_process_eval1620000047_A struct{ jrt.Object }

func A_arbace_java_process_eval1620000047_A_New() *A_arbace_java_process_eval1620000047_A { t := &A_arbace_java_process_eval1620000047_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process_eval1620000047_A) Ctor() {}

func (t *A_arbace_java_process_eval1620000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_eval1620000047_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_eval1620000047_A_class }

func (t *A_arbace_java_process_eval1620000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_eval1620000047_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_eval1620000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_eval1620000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_eval1620000047_A); return ok }

func A_arbace_java_process_eval1620000047_A_Cast(x any) *A_arbace_java_process_eval1620000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_eval1620000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_eval1620000047_A_class)) }; return v }



type A_arbace_java_process_eval1620000047_reify__1620000048_A struct{ jrt.Object; F_counter any; F___meta lang.IPersistentMap }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Is_ThreadFactory() {}

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Is_IObj() {}

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Is_IMeta() {}

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_eval1620000047_reify__1620000048_A_class }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_eval1620000047_reify__1620000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_eval1620000047_reify__1620000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_eval1620000047_reify__1620000048_A); return ok }

func A_arbace_java_process_eval1620000047_reify__1620000048_A_Cast(x any) *A_arbace_java_process_eval1620000047_reify__1620000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_eval1620000047_reify__1620000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_eval1620000047_reify__1620000048_A_class)) }; return v }



type A_arbace_java_process_exec_A struct{ j2g_header uint64 }

var A_arbace_java_process_exec_A_fn_class *jrt.Class



type A_arbace_java_process_exec_fn__1620000060_A struct{ j2g_header uint64; F_proc any }

var A_arbace_java_process_exec_fn__1620000060_A_fn_class *jrt.Class



type A_arbace_java_process_exit_ref_A struct{ j2g_header uint64 }

var A_arbace_java_process_exit_ref_A_fn_class *jrt.Class



type A_arbace_java_process_exit_ref_reify__1620000044_A struct{ jrt.Object; F_process any; F___meta lang.IPersistentMap }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IBlockingDeref() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IDeref() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IObj() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_Supplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_BooleanSupplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IntSupplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_LongSupplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_DoubleSupplier() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Is_IMeta() {}

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Get__O() any { return lang.IDeref_Get__O(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetAsBoolean__Z() bool { return lang.IDeref_GetAsBoolean__Z(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetAsLong__J() int64 { return lang.IDeref_GetAsLong__J(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetAsInt__I() int32 { return lang.IDeref_GetAsInt__I(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetAsDouble__D() float64 { return lang.IDeref_GetAsDouble__D(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_exit_ref_reify__1620000044_A_class }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_exit_ref_reify__1620000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_exit_ref_reify__1620000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_exit_ref_reify__1620000044_A); return ok }

func A_arbace_java_process_exit_ref_reify__1620000044_A_Cast(x any) *A_arbace_java_process_exit_ref_reify__1620000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_exit_ref_reify__1620000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_exit_ref_reify__1620000044_A_class)) }; return v }



type A_arbace_java_process_fn__1620000014_A struct{ j2g_header uint64 }

var A_arbace_java_process_fn__1620000014_A_fn_class *jrt.Class



type A_arbace_java_process_from_file_A struct{ j2g_header uint64 }

var A_arbace_java_process_from_file_A_fn_class *jrt.Class



type A_arbace_java_process_io_task_A struct{ j2g_header uint64 }

var A_arbace_java_process_io_task_A_fn_class *jrt.Class



type A_arbace_java_process_io_task_reify__1620000054_A struct{ jrt.Object; F_fut any; F___meta lang.IPersistentMap }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_Future() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IBlockingDeref() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IDeref() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IPending() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IObj() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_Supplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_BooleanSupplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IntSupplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_LongSupplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_DoubleSupplier() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Is_IMeta() {}

func (t *A_arbace_java_process_io_task_reify__1620000054_A) State__Future_State() *jrt.Future_State { return jrt.Future_State__Future_State(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) ExceptionNow__Throwable() jrt.Throwable_I { return jrt.Future_ExceptionNow__Throwable(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetAsBoolean__Z() bool { return lang.IDeref_GetAsBoolean__Z(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetAsLong__J() int64 { return lang.IDeref_GetAsLong__J(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetAsInt__I() int32 { return lang.IDeref_GetAsInt__I(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) ResultNow__O() any { return jrt.Future_ResultNow__O(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetAsDouble__D() float64 { return lang.IDeref_GetAsDouble__D(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) GetClass__Class() *jrt.Class { return A_arbace_java_process_io_task_reify__1620000054_A_class }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process_io_task_reify__1620000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process_io_task_reify__1620000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process_io_task_reify__1620000054_A); return ok }

func A_arbace_java_process_io_task_reify__1620000054_A_Cast(x any) *A_arbace_java_process_io_task_reify__1620000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process_io_task_reify__1620000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process_io_task_reify__1620000054_A_class)) }; return v }



type A_arbace_java_process_start_A struct{ j2g_header uint64 }

var A_arbace_java_process_start_A_fn_class *jrt.Class



type A_arbace_java_process_start_fn__1620000035_A struct{ j2g_header uint64; F_pb_env any }

var A_arbace_java_process_start_fn__1620000035_A_fn_class *jrt.Class



type A_arbace_java_process_start_to_redirect__1620000031_A struct{ j2g_header uint64 }

var A_arbace_java_process_start_to_redirect__1620000031_A_fn_class *jrt.Class



type A_arbace_java_process_stderr_A struct{ j2g_header uint64 }

var A_arbace_java_process_stderr_A_fn_class *jrt.Class



type A_arbace_java_process_stdin_A struct{ j2g_header uint64 }

var A_arbace_java_process_stdin_A_fn_class *jrt.Class



type A_arbace_java_process_stdout_A struct{ j2g_header uint64 }

var A_arbace_java_process_stdout_A_fn_class *jrt.Class



type A_arbace_java_process_to_file_A struct{ j2g_header uint64 }

var A_arbace_java_process_to_file_A_fn_class *jrt.Class
