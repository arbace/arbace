//line j2g_strings.ae:1
package aot_arbace_java_process

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.java.iokn2,asyn3,jiokn3,dockn6,appendkn4,pipekn2,inkn3,outkn3,errkn3,dirkn3,envkn9,clear-envkn7,inheritkn7,discardkn6,stdoutv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn19,arbace.java.processm2,R4,s431,A process invocation API wrapping the Java process API.\n\n   The primary function is 'start' which starts a process and handles the\n   streams as directed. It returns the Process object. Use 'exit-ref' to wait\n   for completion and receive the exit value, and ‘stdout', 'stderr', 'stdin'\n   to access the process streams. The 'exec' function handles the common case\n   to 'start' a process, wait for process exit, and return stdout.v11,arbace.core13,*loaded-libs*v14,arbace.java.io4,filev11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR5,v11,arbace.core4,map?R6,R7,R8,R9,R10,R11,R12,R13,R14,v19,arbace.java.process9,null-filev11,arbace.core4,restR15,v11,arbace.core4,run!v11,arbace.core5,swap!v11,arbace.core3,incv11,arbace.core9,bound-fn*v19,arbace.java.process11,io-executorv11,arbace.core12,deref-futurev11,arbace.core5,mergev11,arbace.core5,applyv19,arbace.java.process7,io-taskm2,R9,R13,v19,arbace.java.process5,startv11,arbace.core5,slurpv19,arbace.java.process6,stdoutv19,arbace.java.process8,exit-ref")

var Lit_1 *jrt.String = jrt.Intern("java.io.File")

var Lit_2 *jrt.String = jrt.Intern("java.io.InputStream")

var Lit_3 *jrt.String = jrt.Intern("java.io.OutputStream")

var Lit_4 *jrt.String = jrt.Intern("java.lang.ProcessBuilder")

var Lit_5 *jrt.String = jrt.Intern("java.lang.ProcessBuilder$Redirect")

var Lit_6 *jrt.String = jrt.Intern("java.lang.Process")

var Lit_7 *jrt.String = jrt.Intern("java.util.List")

var Lit_8 *jrt.String = jrt.Intern("arbace.lang.IDeref")

var Lit_9 *jrt.String = jrt.Intern("arbace.lang.IBlockingDeref")

var Lit_10 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_11 *jrt.String = jrt.Intern("java.util.concurrent.ExecutorService")

var Lit_12 *jrt.String = jrt.Intern("java.util.concurrent.ThreadFactory")

var Lit_13 *jrt.String = jrt.Intern("Arbace Process IO ")

var Lit_14 *jrt.String = jrt.Intern("arbace.java.process$exec$fn__1620000060")

var Lit_15 *jrt.String = jrt.Intern("Process failed with exit=")

var Lit_16 *jrt.String = jrt.Intern("os.name")

var Lit_17 *jrt.String = jrt.Intern("Windows")

var Lit_18 *jrt.String = jrt.Intern("NUL")

var Lit_19 *jrt.String = jrt.Intern("/dev/null")

var Lit_20 *jrt.String = jrt.Intern(".")

var Lit_21 *jrt.String = jrt.Intern("arbace.java.process$start$to_redirect__1620000031")

var Lit_22 *jrt.String = jrt.Intern("arbace.java.process$start$fn__1620000035")

var Lit_23 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn3,tagkn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,fyn1,&kn4,keysyn6,appendkn2,asyn4,optsyn33,java.lang.ProcessBuilder$Redirectkn5,addedyn9,opts+argsyn17,java.lang.Processyn7,Processyn20,java.io.OutputStreamyn19,java.io.InputStreamyn8,Runnablekn9,skip-wikiv11,arbace.core5,in-nsMyn19,arbace.java.processm2,R0,s431,A process invocation API wrapping the Java process API.\n\n   The primary function is 'start' which starts a process and handles the\n   streams as directed. It returns the Process object. Use 'exit-ref' to wait\n   for completion and receive the exit value, and ‘stdout', 'stderr', 'stdin'\n   to access the process streams. The 'exec' function handles the common case\n   to 'start' a process, wait for process exit, and return stdout.m2,R0,s431,A process invocation API wrapping the Java process API.\n\n   The primary function is 'start' which starts a process and handles the\n   streams as directed. It returns the Process object. Use 'exit-ref' to wait\n   for completion and receive the exit value, and ‘stdout', 'stderr', 'stdin'\n   to access the process streams. The 'exec' function handles the common case\n   to 'start' a process, wait for process exit, and return stdout.R1,v11,arbace.core20,*warn-on-reflection*v19,arbace.java.process9,null-filem10,R2,C12,java.io.FileR3,TR4,i29,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process7,to-filem12,R7,L1,MV3,R8,R9,m4,R10,V1,R11,R12,R13,m2,R2,R14,R0,s182,Coerce f to a file per arbace.java.io/file and return a ProcessBuilder.Redirect writing to the file.\n  Set ':append' in opts to append. This can be passed to 'start' in :out or :err.R15,s4,1.12R4,i36,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process9,from-filem12,R7,L1,MV1,R8,m2,R2,R14,R0,s142,Coerce f to a file per arbace.java.io/file and return a ProcessBuilder.Redirect reading from the file.\n  This can be passed to 'start' in :in.R15,s4,1.12R4,i46,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process5,startm12,R7,L1,MV2,R9,R16,m2,R2,R17,R0,s661,Start an external command, defined in args.\n  The process environment vars are inherited from the parent by\n  default (use :clear-env to clear them).\n\n  If needed, provide options in map as first arg:\n    :in - a ProcessBuilder.Redirect (default = :pipe) or :inherit\n    :out - a ProcessBuilder.Redirect (default = :pipe) or :inherit :discard\n    :err - a ProcessBuilder.Redirect (default = :pipe) or :inherit :discard :stdout\n    :dir - current directory when the process runs (default=\".\")\n    :clear-env - if true, remove all inherited parent env vars\n    :env - {env-var value} of environment variables to set (all strings)\n\n  Returns the java.lang.Process.R15,s4,1.12R4,i53,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process5,stdinm12,R7,L1,MV1,Myn7,processm2,R2,R18,m2,R2,R19,R0,s75,Given a process, return the stdin of the external process (an OutputStream)R15,s4,1.12R4,i96,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process6,stdoutm12,R7,L1,MV1,Myn7,processm2,R2,R18,m2,R2,R20,R0,s75,Given a process, return the stdout of the external process (an InputStream)R15,s4,1.12R4,i102,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process6,stderrm12,R7,L1,MV1,Myn7,processm2,R2,R18,m2,R2,R20,R0,s75,Given a process, return the stderr of the external process (an InputStream)R15,s4,1.12R4,i108,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process8,exit-refm12,R7,L1,V1,Myn7,processm2,R2,R18,R0,s138,Given a Process (the output of 'start'), return a reference that can be\n  used to wait for process completion then returns the exit value.R15,s4,1.12R4,i114,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process17,io-thread-factorym8,R3,TR4,i130,R5,i1,R6,s22,arbace/java/process.aev11,arbace.core4,atomm8,R3,TR4,i130,R5,i1,R6,s22,arbace/java/process.ael0,v19,arbace.java.process11,io-executorm8,R3,TR4,i139,R5,i1,R6,s22,arbace/java/process.aem8,R3,TR4,i139,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process7,io-taskm10,R7,L1,V1,Myn1,fm2,R2,R21,R22,TR4,i142,R5,i1,R6,s22,arbace/java/process.aev19,arbace.java.process4,execm12,R7,L1,V2,R9,R16,R0,s193,Execute a command and on successful exit, return the captured output,\n  else throw RuntimeException. Args are the same as 'start' and options\n  if supplied override the default 'exec' settings.R15,s4,1.12R4,i163,R5,i1,R6,s22,arbace/java/process.ae")

var Lit_24 *jrt.String = jrt.Intern("arbace.java.process$eval1620000004$loading__1927001464__auto____1620000005")

var Lit_25 *jrt.String = jrt.Intern("arbace.java.process$eval1620000008$fn__1620000009")

var Lit_26 *jrt.String = jrt.Intern("arbace.java.process$fn__1620000014")

var Lit_27 *jrt.String = jrt.Intern("arbace.java.process$to_file")

var Lit_28 *jrt.String = jrt.Intern("arbace.java.process$from_file")

var Lit_29 *jrt.String = jrt.Intern("arbace.java.process$start")

var Lit_30 *jrt.String = jrt.Intern("arbace.java.process$stdin")

var Lit_31 *jrt.String = jrt.Intern("arbace.java.process$stdout")

var Lit_32 *jrt.String = jrt.Intern("arbace.java.process$stderr")

var Lit_33 *jrt.String = jrt.Intern("arbace.java.process$exit_ref")

var Lit_34 *jrt.String = jrt.Intern("arbace.java.process$io_task")

var Lit_35 *jrt.String = jrt.Intern("arbace.java.process$exec")
