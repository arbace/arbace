//line a2g_classes.ae:1
package aot_arbace_java_process

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_class, Name: "arbace.java.process$eval1620000004$loading__1927001464__auto____1620000005", Modifiers: 25, Simple: "loading__1927001464__auto____1620000005", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A", Source: "process.ae", Declaring: &A_arbace_java_process_eval1620000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_eval1620000008_fn__1620000009_A_class, Name: "arbace.java.process$eval1620000008$fn__1620000009", Modifiers: 25, Simple: "fn__1620000009", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_eval1620000008_fn__1620000009_A", Source: "process.ae", Declaring: &A_arbace_java_process_eval1620000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_exec_A_class, Name: "arbace.java.process$exec", Modifiers: 25, Simple: "exec", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_exec_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_exec_fn__1620000060_A_class, Name: "arbace.java.process$exec$fn__1620000060", Modifiers: 25, Simple: "fn__1620000060", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_exec_fn__1620000060_A", Source: "process.ae", Declaring: &A_arbace_java_process_exec_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_exit_ref_A_class, Name: "arbace.java.process$exit_ref", Modifiers: 25, Simple: "exit_ref", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_exit_ref_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_fn__1620000014_A_class, Name: "arbace.java.process$fn__1620000014", Modifiers: 25, Simple: "fn__1620000014", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_fn__1620000014_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_from_file_A_class, Name: "arbace.java.process$from_file", Modifiers: 25, Simple: "from_file", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_from_file_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_io_task_A_class, Name: "arbace.java.process$io_task", Modifiers: 25, Simple: "io_task", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_io_task_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_start_A_class, Name: "arbace.java.process$start", Modifiers: 25, Simple: "start", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_start_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_start_fn__1620000035_A_class, Name: "arbace.java.process$start$fn__1620000035", Modifiers: 25, Simple: "fn__1620000035", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_start_fn__1620000035_A", Source: "process.ae", Declaring: &A_arbace_java_process_start_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_start_to_redirect__1620000031_A_class, Name: "arbace.java.process$start$to_redirect__1620000031", Modifiers: 25, Simple: "to_redirect__1620000031", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_start_to_redirect__1620000031_A", Source: "process.ae", Declaring: &A_arbace_java_process_start_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_stderr_A_class, Name: "arbace.java.process$stderr", Modifiers: 25, Simple: "stderr", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_stderr_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_stdin_A_class, Name: "arbace.java.process$stdin", Modifiers: 25, Simple: "stdin", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_stdin_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_stdout_A_class, Name: "arbace.java.process$stdout", Modifiers: 25, Simple: "stdout", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_stdout_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_process_to_file_A_class, Name: "arbace.java.process$to_file", Modifiers: 25, Simple: "to_file", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_to_file_A", Source: "process.ae", Declaring: &A_arbace_java_process_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_java_process_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_process_A_New()}; return nil }

var A_arbace_java_process_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_process_A_new}

var A_arbace_java_process_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.process", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_process.A_arbace_java_process_A"})

func init() { i := A_arbace_java_process_A_class.Info(); i.IsInstance = A_arbace_java_process_A_InstanceOf; i.Init = A_arbace_java_process_A_Init; i.Table = A_arbace_java_process_A_members }

func A_arbace_java_process_eval1620000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_process_eval1620000004_A_New()}; return nil }

var A_arbace_java_process_eval1620000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_process_eval1620000004_A_new}

var A_arbace_java_process_eval1620000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.process$eval1620000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_process_A_class, Simple: "eval1620000004", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_eval1620000004_A"})

func init() { i := A_arbace_java_process_eval1620000004_A_class.Info(); i.IsInstance = A_arbace_java_process_eval1620000004_A_InstanceOf; i.Table = A_arbace_java_process_eval1620000004_A_members }

var A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_class *jrt.Class

func A_arbace_java_process_eval1620000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_process_eval1620000008_A_New()}; return nil }

var A_arbace_java_process_eval1620000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_process_eval1620000008_A_new}

var A_arbace_java_process_eval1620000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.process$eval1620000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_process_A_class, Simple: "eval1620000008", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_eval1620000008_A"})

func init() { i := A_arbace_java_process_eval1620000008_A_class.Info(); i.IsInstance = A_arbace_java_process_eval1620000008_A_InstanceOf; i.Table = A_arbace_java_process_eval1620000008_A_members }

var A_arbace_java_process_eval1620000008_fn__1620000009_A_class *jrt.Class

func A_arbace_java_process_eval1620000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_process_eval1620000047_A_New()}; return nil }

var A_arbace_java_process_eval1620000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_process_eval1620000047_A_new}

var A_arbace_java_process_eval1620000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.process$eval1620000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_process_A_class, Simple: "eval1620000047", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_eval1620000047_A"})

func init() { i := A_arbace_java_process_eval1620000047_A_class.Info(); i.IsInstance = A_arbace_java_process_eval1620000047_A_InstanceOf; i.Table = A_arbace_java_process_eval1620000047_A_members }

func A_arbace_java_process_eval1620000047_reify__1620000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_process_eval1620000047_reify__1620000048_A).Meta__IPersistentMap(); case 1: return this.(*A_arbace_java_process_eval1620000047_reify__1620000048_A).NewThread_Runnable__Thread(jrt.As[jrt.Runnable](args[0])); case 2: return this.(*A_arbace_java_process_eval1620000047_reify__1620000048_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_java_process_eval1620000047_reify__1620000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_process_eval1620000047_reify__1620000048_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_java_process_eval1620000047_reify__1620000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 meta ()Larbace.lang.IPersistentMap;\nM1 newThread (Ljava.lang.Runnable;)Ljava.lang.Thread;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_java_process_eval1620000047_reify__1620000048_A_invoke, New: A_arbace_java_process_eval1620000047_reify__1620000048_A_new}

var A_arbace_java_process_eval1620000047_reify__1620000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.process$eval1620000047$reify__1620000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{jrt.ThreadFactory_class, lang.IObj_class}, Declaring: A_arbace_java_process_eval1620000047_A_class, Simple: "reify__1620000048", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_eval1620000047_reify__1620000048_A", Source: "process.ae"})

func init() { i := A_arbace_java_process_eval1620000047_reify__1620000048_A_class.Info(); i.IsInstance = A_arbace_java_process_eval1620000047_reify__1620000048_A_InstanceOf; i.Table = A_arbace_java_process_eval1620000047_reify__1620000048_A_members }

var A_arbace_java_process_exec_A_class *jrt.Class

var A_arbace_java_process_exec_fn__1620000060_A_class *jrt.Class

var A_arbace_java_process_exit_ref_A_class *jrt.Class

func A_arbace_java_process_exit_ref_reify__1620000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_process_exit_ref_reify__1620000044_A).Deref__O(); case 1: return this.(*A_arbace_java_process_exit_ref_reify__1620000044_A).Deref_J_O__O(args[0].(int64), args[1]); case 2: return this.(*A_arbace_java_process_exit_ref_reify__1620000044_A).Meta__IPersistentMap(); case 3: return this.(*A_arbace_java_process_exit_ref_reify__1620000044_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_java_process_exit_ref_reify__1620000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_process_exit_ref_reify__1620000044_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_java_process_exit_ref_reify__1620000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 deref ()Ljava.lang.Object;\nM1 deref (JLjava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_java_process_exit_ref_reify__1620000044_A_invoke, New: A_arbace_java_process_exit_ref_reify__1620000044_A_new}

var A_arbace_java_process_exit_ref_reify__1620000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.process$exit_ref$reify__1620000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.IBlockingDeref_class, lang.IDeref_class, lang.IObj_class}, Declaring: A_arbace_java_process_exit_ref_A_class, Simple: "reify__1620000044", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_exit_ref_reify__1620000044_A", Source: "process.ae"})

func init() { i := A_arbace_java_process_exit_ref_reify__1620000044_A_class.Info(); i.IsInstance = A_arbace_java_process_exit_ref_reify__1620000044_A_InstanceOf; i.Table = A_arbace_java_process_exit_ref_reify__1620000044_A_members }

var A_arbace_java_process_fn__1620000014_A_class *jrt.Class

var A_arbace_java_process_from_file_A_class *jrt.Class

var A_arbace_java_process_io_task_A_class *jrt.Class

func A_arbace_java_process_io_task_reify__1620000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).Cancel_Z__Z(args[0].(bool)); case 1: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).Deref__O(); case 2: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).Deref_J_O__O(args[0].(int64), args[1]); case 3: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).Get__O(); case 4: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).Get_J_TimeUnit__O(args[0].(int64), jrt.As[*jrt.TimeUnit](args[1])); case 5: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).IsCancelled__Z(); case 6: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).IsDone__Z(); case 7: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).IsRealized__Z(); case 8: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).Meta__IPersistentMap(); case 9: return this.(*A_arbace_java_process_io_task_reify__1620000054_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_java_process_io_task_reify__1620000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_process_io_task_reify__1620000054_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_java_process_io_task_reify__1620000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 cancel (Z)Z\nM1 deref ()Ljava.lang.Object;\nM1 deref (JLjava.lang.Object;)Ljava.lang.Object;\nM1 get ()Ljava.lang.Object;\nM1 get (JLjava.util.concurrent.TimeUnit;)Ljava.lang.Object;\nM1 isCancelled ()Z\nM1 isDone ()Z\nM1 isRealized ()Z\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_java_process_io_task_reify__1620000054_A_invoke, New: A_arbace_java_process_io_task_reify__1620000054_A_new}

var A_arbace_java_process_io_task_reify__1620000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.process$io_task$reify__1620000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{jrt.Future_class, lang.IBlockingDeref_class, lang.IDeref_class, lang.IPending_class, lang.IObj_class}, Declaring: A_arbace_java_process_io_task_A_class, Simple: "reify__1620000054", Go: "arbace/aot_arbace_java_process.A_arbace_java_process_io_task_reify__1620000054_A", Source: "process.ae"})

func init() { i := A_arbace_java_process_io_task_reify__1620000054_A_class.Info(); i.IsInstance = A_arbace_java_process_io_task_reify__1620000054_A_InstanceOf; i.Table = A_arbace_java_process_io_task_reify__1620000054_A_members }

var A_arbace_java_process_start_A_class *jrt.Class

var A_arbace_java_process_start_fn__1620000035_A_class *jrt.Class

var A_arbace_java_process_start_to_redirect__1620000031_A_class *jrt.Class

var A_arbace_java_process_stderr_A_class *jrt.Class

var A_arbace_java_process_stdin_A_class *jrt.Class

var A_arbace_java_process_stdout_A_class *jrt.Class

var A_arbace_java_process_to_file_A_class *jrt.Class

func A_arbace_java_process__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_java_process__init_A_Load__O()}; return nil }

func A_arbace_java_process__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_process__init_A_New()}; return nil }

var A_arbace_java_process__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_java_process__init_A_invoke, New: A_arbace_java_process__init_A_new}

var A_arbace_java_process__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.process__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_process.A_arbace_java_process__init_A", Source: "process.ae"})

func init() { i := A_arbace_java_process__init_A_class.Info(); i.IsInstance = A_arbace_java_process__init_A_InstanceOf; i.Init = A_arbace_java_process__init_A_Init; i.Table = A_arbace_java_process__init_A_members }
