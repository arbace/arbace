//line a2g_strings.ae:1
package aot_arbace_java_process

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("jio")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.java.process")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("A process invocation API wrapping the Java process API.\n\n   The primary function is 'start' which starts a process and handles the\n   streams as directed. It returns the Process object. Use 'exit-ref' to wait\n   for completion and receive the exit value, and ‘stdout', 'stderr', 'stdin'\n   to access the process streams. The 'exec' function handles the common case\n   to 'start' a process, wait for process exit, and return stdout.")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("file")

var Lit_14 *jrt.String = jrt.Intern("next")

var Lit_15 *jrt.String = jrt.Intern("to-array")

var Lit_16 *jrt.String = jrt.Intern("seq")

var Lit_17 *jrt.String = jrt.Intern("first")

var Lit_18 *jrt.String = jrt.Intern("append")

var Lit_19 *jrt.String = jrt.Intern("map?")

var Lit_20 *jrt.String = jrt.Intern("pipe")

var Lit_21 *jrt.String = jrt.Intern("in")

var Lit_22 *jrt.String = jrt.Intern("out")

var Lit_23 *jrt.String = jrt.Intern("err")

var Lit_24 *jrt.String = jrt.Intern("dir")

var Lit_25 *jrt.String = jrt.Intern("env")

var Lit_26 *jrt.String = jrt.Intern("clear-env")

var Lit_27 *jrt.String = jrt.Intern("inherit")

var Lit_28 *jrt.String = jrt.Intern("discard")

var Lit_29 *jrt.String = jrt.Intern("null-file")

var Lit_30 *jrt.String = jrt.Intern("rest")

var Lit_31 *jrt.String = jrt.Intern("stdout")

var Lit_32 *jrt.String = jrt.Intern("run!")

var Lit_33 *jrt.String = jrt.Intern("swap!")

var Lit_34 *jrt.String = jrt.Intern("inc")

var Lit_35 *jrt.String = jrt.Intern("bound-fn*")

var Lit_36 *jrt.String = jrt.Intern("io-executor")

var Lit_37 *jrt.String = jrt.Intern("deref-future")

var Lit_38 *jrt.String = jrt.Intern("merge")

var Lit_39 *jrt.String = jrt.Intern("apply")

var Lit_40 *jrt.String = jrt.Intern("io-task")

var Lit_41 *jrt.String = jrt.Intern("start")

var Lit_42 *jrt.String = jrt.Intern("slurp")

var Lit_43 *jrt.String = jrt.Intern("exit-ref")

var Lit_44 *jrt.String = jrt.Intern("arbace.java.process$eval1620000004$loading__1927001464__auto____1620000005")

var Lit_45 *jrt.String = jrt.Intern("java.io.File")

var Lit_46 *jrt.String = jrt.Intern("java.io.InputStream")

var Lit_47 *jrt.String = jrt.Intern("java.io.OutputStream")

var Lit_48 *jrt.String = jrt.Intern("java.lang.ProcessBuilder")

var Lit_49 *jrt.String = jrt.Intern("java.lang.ProcessBuilder$Redirect")

var Lit_50 *jrt.String = jrt.Intern("java.lang.Process")

var Lit_51 *jrt.String = jrt.Intern("java.util.List")

var Lit_52 *jrt.String = jrt.Intern("arbace.lang.IDeref")

var Lit_53 *jrt.String = jrt.Intern("arbace.lang.IBlockingDeref")

var Lit_54 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_55 *jrt.String = jrt.Intern("java.util.concurrent.ExecutorService")

var Lit_56 *jrt.String = jrt.Intern("java.util.concurrent.ThreadFactory")

var Lit_57 *jrt.String = jrt.Intern("arbace.java.process$eval1620000008$fn__1620000009")

var Lit_58 *jrt.String = jrt.Intern("Arbace Process IO ")

var Lit_59 *jrt.String = jrt.Intern("arbace.java.process$exec")

var Lit_60 *jrt.String = jrt.Intern("Process failed with exit=")

var Lit_61 *jrt.String = jrt.Intern("arbace.java.process$exec$fn__1620000060")

var Lit_62 *jrt.String = jrt.Intern("arbace.java.process$exit_ref")

var Lit_63 *jrt.String = jrt.Intern("arbace.java.process$fn__1620000014")

var Lit_64 *jrt.String = jrt.Intern("os.name")

var Lit_65 *jrt.String = jrt.Intern("Windows")

var Lit_66 *jrt.String = jrt.Intern("NUL")

var Lit_67 *jrt.String = jrt.Intern("/dev/null")

var Lit_68 *jrt.String = jrt.Intern("arbace.java.process$from_file")

var Lit_69 *jrt.String = jrt.Intern("arbace.java.process$io_task")

var Lit_70 *jrt.String = jrt.Intern("arbace.java.process$start")

var Lit_71 *jrt.String = jrt.Intern(".")

var Lit_72 *jrt.String = jrt.Intern("arbace.java.process$start$fn__1620000035")

var Lit_73 *jrt.String = jrt.Intern("arbace.java.process$start$to_redirect__1620000031")

var Lit_74 *jrt.String = jrt.Intern("arbace.java.process$stderr")

var Lit_75 *jrt.String = jrt.Intern("arbace.java.process$stdin")

var Lit_76 *jrt.String = jrt.Intern("arbace.java.process$stdout")

var Lit_77 *jrt.String = jrt.Intern("arbace.java.process$to_file")

var Lit_78 *jrt.String = jrt.Intern("in-ns")

var Lit_79 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_80 *jrt.String = jrt.Intern("tag")

var Lit_81 *jrt.String = jrt.Intern("private")

var Lit_82 *jrt.String = jrt.Intern("line")

var Lit_83 *jrt.String = jrt.Intern("column")

var Lit_84 *jrt.String = jrt.Intern("arbace/java/process.ae")

var Lit_85 *jrt.String = jrt.Intern("to-file")

var Lit_86 *jrt.String = jrt.Intern("arglists")

var Lit_87 *jrt.String = jrt.Intern("f")

var Lit_88 *jrt.String = jrt.Intern("&")

var Lit_89 *jrt.String = jrt.Intern("keys")

var Lit_90 *jrt.String = jrt.Intern("opts")

var Lit_91 *jrt.String = jrt.Intern("Coerce f to a file per arbace.java.io/file and return a ProcessBuilder.Redirect writing to the file.\n  Set ':append' in opts to append. This can be passed to 'start' in :out or :err.")

var Lit_92 *jrt.String = jrt.Intern("added")

var Lit_93 *jrt.String = jrt.Intern("1.12")

var Lit_94 *jrt.String = jrt.Intern("from-file")

var Lit_95 *jrt.String = jrt.Intern("Coerce f to a file per arbace.java.io/file and return a ProcessBuilder.Redirect reading from the file.\n  This can be passed to 'start' in :in.")

var Lit_96 *jrt.String = jrt.Intern("opts+args")

var Lit_97 *jrt.String = jrt.Intern("Start an external command, defined in args.\n  The process environment vars are inherited from the parent by\n  default (use :clear-env to clear them).\n\n  If needed, provide options in map as first arg:\n    :in - a ProcessBuilder.Redirect (default = :pipe) or :inherit\n    :out - a ProcessBuilder.Redirect (default = :pipe) or :inherit :discard\n    :err - a ProcessBuilder.Redirect (default = :pipe) or :inherit :discard :stdout\n    :dir - current directory when the process runs (default=\".\")\n    :clear-env - if true, remove all inherited parent env vars\n    :env - {env-var value} of environment variables to set (all strings)\n\n  Returns the java.lang.Process.")

var Lit_98 *jrt.String = jrt.Intern("stdin")

var Lit_99 *jrt.String = jrt.Intern("process")

var Lit_100 *jrt.String = jrt.Intern("Process")

var Lit_101 *jrt.String = jrt.Intern("Given a process, return the stdin of the external process (an OutputStream)")

var Lit_102 *jrt.String = jrt.Intern("Given a process, return the stdout of the external process (an InputStream)")

var Lit_103 *jrt.String = jrt.Intern("stderr")

var Lit_104 *jrt.String = jrt.Intern("Given a process, return the stderr of the external process (an InputStream)")

var Lit_105 *jrt.String = jrt.Intern("Given a Process (the output of 'start'), return a reference that can be\n  used to wait for process completion then returns the exit value.")

var Lit_106 *jrt.String = jrt.Intern("io-thread-factory")

var Lit_107 *jrt.String = jrt.Intern("atom")

var Lit_108 *jrt.String = jrt.Intern("Runnable")

var Lit_109 *jrt.String = jrt.Intern("skip-wiki")

var Lit_110 *jrt.String = jrt.Intern("exec")

var Lit_111 *jrt.String = jrt.Intern("Execute a command and on successful exit, return the captured output,\n  else throw RuntimeException. Args are the same as 'start' and options\n  if supplied override the default 'exec' settings.")
