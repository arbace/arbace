//line aot_arbace_java_process__init.ae:1
package aot_arbace_java_process

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_java_process__init_A_Load__O() any { A_arbace_java_process__init_A_Init(); jrt.StartCheck(); A_arbace_java_process__init_A_Unit0__O(); A_arbace_java_process__init_A_Unit1__O(); A_arbace_java_process__init_A_Unit2__O(); A_arbace_java_process__init_A_Unit3__O(); A_arbace_java_process__init_A_Unit4__O(); A_arbace_java_process__init_A_Unit5__O(); A_arbace_java_process__init_A_Unit6__O(); A_arbace_java_process__init_A_Unit7__O(); A_arbace_java_process__init_A_Unit8__O(); A_arbace_java_process__init_A_Unit9__O(); A_arbace_java_process__init_A_Unit10__O(); A_arbace_java_process__init_A_Unit11__O(); A_arbace_java_process__init_A_Unit12__O(); A_arbace_java_process__init_A_Unit13__O(); A_arbace_java_process__init_A_Unit14__O(); A_arbace_java_process__init_A_Unit15__O(); A_arbace_java_process__init_A_Unit16__O(); A_arbace_java_process__init_A_Unit17__O(); return nil }



func A_arbace_java_process__init_A_Unit0__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_java_process__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_process__init_A_const_1) }
//line :9:1
func A_arbace_java_process__init_A_Unit1__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_java_process__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_2)) }
//line :9:1
func A_arbace_java_process__init_A_Unit2__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 any = A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_java_process__init_A_Unit3__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_java_process__init_A_const_1)).Equals_O__Z(A_arbace_java_process__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_java_process_eval1620000008_fn__1620000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_java_process_eval1620000008_fn__1620000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_java_process_eval1620000008_fn__1620000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
















func A_arbace_java_process__init_A_Unit4__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); return A_arbace_java_process__init_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }


func A_arbace_java_process__init_A_Unit5__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_5; var tmp2 any = A_arbace_java_process_fn__1620000014_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_java_process_fn__1620000014_A_fn_class; if
							fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_java_process_fn__1620000014_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; /*line :29:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_6)); return A_arbace_java_process__init_A_const_5 }






func A_arbace_java_process__init_A_Unit6__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_7; var tmp2 any = A_arbace_java_process_to_file_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_java_process_to_file_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, true); A_arbace_java_process_to_file_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_8)); return A_arbace_java_process__init_A_const_7 }









func A_arbace_java_process__init_A_Unit7__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_9; var tmp2 any = A_arbace_java_process_from_file_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_java_process_from_file_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_java_process_from_file_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_10)); return A_arbace_java_process__init_A_const_9 }






func A_arbace_java_process__init_A_Unit8__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_11; var tmp2 any = A_arbace_java_process_start_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_java_process_start_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, true); A_arbace_java_process_start_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_12)); return A_arbace_java_process__init_A_const_11 }










































func A_arbace_java_process__init_A_Unit9__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_13; var tmp2 any = A_arbace_java_process_stdin_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_java_process_stdin_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_java_process_stdin_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_14)); return A_arbace_java_process__init_A_const_13 }





func A_arbace_java_process__init_A_Unit10__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_15; var tmp2 any = A_arbace_java_process_stdout_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_java_process_stdout_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_java_process_stdout_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_16)); return A_arbace_java_process__init_A_const_15 }





func A_arbace_java_process__init_A_Unit11__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(108, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_17; var tmp2 any = A_arbace_java_process_stderr_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_java_process_stderr_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_java_process_stderr_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_18)); return A_arbace_java_process__init_A_const_17 }





func A_arbace_java_process__init_A_Unit12__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_19; var tmp2 any = A_arbace_java_process_exit_ref_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_java_process_exit_ref_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_java_process_exit_ref_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_20)); return A_arbace_java_process__init_A_const_19 }















func A_arbace_java_process__init_A_Unit13__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_process__init_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_22)); v__1927001498__auto____1 = A_arbace_java_process__init_A_const_21; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_process__init_A_const_21; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_24)); var tmp3 *lang.Var = A_arbace_java_process__init_A_const_21; var tmp4 *A_arbace_java_process_eval1620000047_reify__1620000048_A; var counter__2 any = lang.IFn_Cast(A_arbace_java_process__init_A_const_23.GetRawRoot__O()).Invoke_O__O(A_arbace_java_process__init_A_const_25)

	tmp4 = A_arbace_java_process_eval1620000047_reify__1620000048_A_New_IPersistentMap_O(nil, counter__2)
//line :130:1
	tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_java_process__init_A_const_21 } }








func A_arbace_java_process__init_A_Unit14__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_process__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_27)); v__1927001498__auto____1 = A_arbace_java_process__init_A_const_26; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_process__init_A_const_26; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_28)); var tmp3 *lang.Var = A_arbace_java_process__init_A_const_26; tmp3.BindRoot_O__V(jrt.Executors_NewCachedThreadPool_ThreadFactory__ExecutorService(jrt.ThreadFactory_Cast(A_arbace_java_process__init_A_const_21.GetRawRoot__O()))); return A_arbace_java_process__init_A_const_26 } }


func A_arbace_java_process__init_A_Unit15__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(142, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_29; var tmp2 any = A_arbace_java_process_io_task_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_java_process_io_task_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_java_process_io_task_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_30)); return A_arbace_java_process__init_A_const_29 }




















func A_arbace_java_process__init_A_Unit16__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(163, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_31; var tmp2 any = A_arbace_java_process_exec_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_java_process_exec_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, true); A_arbace_java_process_exec_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_32)); return A_arbace_java_process__init_A_const_31 }
















func A_arbace_java_process__init_A_Unit17__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(180, 1); return nil }



type A_arbace_java_process__init_A struct{ jrt.Object }

var A_arbace_java_process__init_A_const_pool *jrt.RefArray

var A_arbace_java_process__init_A_const_0 *lang.Var

var A_arbace_java_process__init_A_const_1 any

var A_arbace_java_process__init_A_const_2 any

var A_arbace_java_process__init_A_const_3 any

var A_arbace_java_process__init_A_const_4 *lang.Var

var A_arbace_java_process__init_A_const_5 *lang.Var

var A_arbace_java_process__init_A_const_6 any

var A_arbace_java_process__init_A_const_7 *lang.Var

var A_arbace_java_process__init_A_const_8 any

var A_arbace_java_process__init_A_const_9 *lang.Var

var A_arbace_java_process__init_A_const_10 any

var A_arbace_java_process__init_A_const_11 *lang.Var

var A_arbace_java_process__init_A_const_12 any

var A_arbace_java_process__init_A_const_13 *lang.Var

var A_arbace_java_process__init_A_const_14 any

var A_arbace_java_process__init_A_const_15 *lang.Var

var A_arbace_java_process__init_A_const_16 any

var A_arbace_java_process__init_A_const_17 *lang.Var

var A_arbace_java_process__init_A_const_18 any

var A_arbace_java_process__init_A_const_19 *lang.Var

var A_arbace_java_process__init_A_const_20 any

var A_arbace_java_process__init_A_const_21 *lang.Var

var A_arbace_java_process__init_A_const_22 any

var A_arbace_java_process__init_A_const_23 *lang.Var

var A_arbace_java_process__init_A_const_24 any

var A_arbace_java_process__init_A_const_25 any

var A_arbace_java_process__init_A_const_26 *lang.Var

var A_arbace_java_process__init_A_const_27 any

var A_arbace_java_process__init_A_const_28 any

var A_arbace_java_process__init_A_const_29 *lang.Var

var A_arbace_java_process__init_A_const_30 any

var A_arbace_java_process__init_A_const_31 *lang.Var

var A_arbace_java_process__init_A_const_32 any

var A_arbace_java_process__init_A_init jrt.ClassInit

func A_arbace_java_process__init_A_Init() { if !A_arbace_java_process__init_A_init.Done() { A_arbace_java_process__init_A_init.Run(A_arbace_java_process__init_A_clinit) } }

func A_arbace_java_process__init_A_clinit() { A_arbace_java_process__init_A_clinit_p0(); A_arbace_java_process__init_A_clinit_p1(); A_arbace_java_process__init_A_clinit_p2() }

func A_arbace_java_process__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_process__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_23, 56); A_arbace_java_process__init_A_const_0 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[23]); A_arbace_java_process__init_A_const_1 = A_arbace_java_process__init_A_const_pool.A[24]; A_arbace_java_process__init_A_const_2 = A_arbace_java_process__init_A_const_pool.A[25]; A_arbace_java_process__init_A_const_3 = A_arbace_java_process__init_A_const_pool.A[26]; A_arbace_java_process__init_A_const_4 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[27]); A_arbace_java_process__init_A_const_5 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[28]); A_arbace_java_process__init_A_const_6 = A_arbace_java_process__init_A_const_pool.A[29]; A_arbace_java_process__init_A_const_7 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[30]); A_arbace_java_process__init_A_const_8 = A_arbace_java_process__init_A_const_pool.A[31]; A_arbace_java_process__init_A_const_9 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[32]); A_arbace_java_process__init_A_const_10 = A_arbace_java_process__init_A_const_pool.A[33]; A_arbace_java_process__init_A_const_11 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[34]); A_arbace_java_process__init_A_const_12 = A_arbace_java_process__init_A_const_pool.A[35] }

func A_arbace_java_process__init_A_clinit_p1() { A_arbace_java_process__init_A_const_13 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[36]); A_arbace_java_process__init_A_const_14 = A_arbace_java_process__init_A_const_pool.A[37]; A_arbace_java_process__init_A_const_15 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[38]); A_arbace_java_process__init_A_const_16 = A_arbace_java_process__init_A_const_pool.A[39]; A_arbace_java_process__init_A_const_17 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[40]); A_arbace_java_process__init_A_const_18 = A_arbace_java_process__init_A_const_pool.A[41]; A_arbace_java_process__init_A_const_19 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[42]); A_arbace_java_process__init_A_const_20 = A_arbace_java_process__init_A_const_pool.A[43]; A_arbace_java_process__init_A_const_21 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[44]); A_arbace_java_process__init_A_const_22 = A_arbace_java_process__init_A_const_pool.A[45]; A_arbace_java_process__init_A_const_23 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[46]); A_arbace_java_process__init_A_const_24 = A_arbace_java_process__init_A_const_pool.A[47]; A_arbace_java_process__init_A_const_25 = A_arbace_java_process__init_A_const_pool.A[48] }

func A_arbace_java_process__init_A_clinit_p2() { A_arbace_java_process__init_A_const_26 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[49]); A_arbace_java_process__init_A_const_27 = A_arbace_java_process__init_A_const_pool.A[50]; A_arbace_java_process__init_A_const_28 = A_arbace_java_process__init_A_const_pool.A[51]; A_arbace_java_process__init_A_const_29 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[52]); A_arbace_java_process__init_A_const_30 = A_arbace_java_process__init_A_const_pool.A[53]; A_arbace_java_process__init_A_const_31 = lang.Var_Cast(A_arbace_java_process__init_A_const_pool.A[54]); A_arbace_java_process__init_A_const_32 = A_arbace_java_process__init_A_const_pool.A[55] }

func A_arbace_java_process__init_A_New() *A_arbace_java_process__init_A { A_arbace_java_process__init_A_Init(); t := &A_arbace_java_process__init_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process__init_A) Ctor() {}

func (t *A_arbace_java_process__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process__init_A) GetClass__Class() *jrt.Class { return A_arbace_java_process__init_A_class }

func (t *A_arbace_java_process__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_process__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process__init_A); return ok }

func A_arbace_java_process__init_A_Cast(x any) *A_arbace_java_process__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process__init_A_class)) }; return v }
