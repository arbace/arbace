//line aot_arbace_java_process__init.ae:1
package aot_arbace_java_process

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_java_process__init_A_Load__O() any { A_arbace_java_process__init_A_Init(); A_arbace_java_process__init_A_Unit0__O(); A_arbace_java_process__init_A_Unit1__O(); A_arbace_java_process__init_A_Unit2__O(); A_arbace_java_process__init_A_Unit3__O(); A_arbace_java_process__init_A_Unit4__O(); A_arbace_java_process__init_A_Unit5__O(); A_arbace_java_process__init_A_Unit6__O(); A_arbace_java_process__init_A_Unit7__O(); A_arbace_java_process__init_A_Unit8__O(); A_arbace_java_process__init_A_Unit9__O(); A_arbace_java_process__init_A_Unit10__O(); A_arbace_java_process__init_A_Unit11__O(); A_arbace_java_process__init_A_Unit12__O(); A_arbace_java_process__init_A_Unit13__O(); A_arbace_java_process__init_A_Unit14__O(); A_arbace_java_process__init_A_Unit15__O(); A_arbace_java_process__init_A_Unit16__O(); A_arbace_java_process__init_A_Unit17__O(); return nil }



func A_arbace_java_process__init_A_Unit0__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_java_process__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_java_process__init_A_const_1) }
//line :9:1
func A_arbace_java_process__init_A_Unit1__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_java_process__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_2)) }
//line :9:1
func A_arbace_java_process__init_A_Unit2__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_New(); var tmp2 *jrt.Class; A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_Init(); tmp2 = A_arbace_java_process_eval1620000004_loading__1927001464__auto____1620000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_java_process__init_A_Unit3__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_java_process__init_A_const_1)).Equals_O__Z(A_arbace_java_process__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_java_process_eval1620000008_fn__1620000009_A_New(); var tmp2 *jrt.Class; A_arbace_java_process_eval1620000008_fn__1620000009_A_Init(); tmp2 = A_arbace_java_process_eval1620000008_fn__1620000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
















func A_arbace_java_process__init_A_Unit4__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_4; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; return jrt.NN(tmp1).Set_O__O(tmp2.Ref()) }


func A_arbace_java_process__init_A_Unit5__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_5; var tmp2 any = A_arbace_java_process_fn__1620000014_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_fn__1620000014_A_Init(); tmp3 = A_arbace_java_process_fn__1620000014_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_5; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_6)); return A_arbace_java_process__init_A_const_5.Ref() }






func A_arbace_java_process__init_A_Unit6__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_7; var tmp2 any = A_arbace_java_process_to_file_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_to_file_A_Init(); tmp3 = A_arbace_java_process_to_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_7; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_8)); return A_arbace_java_process__init_A_const_7.Ref() }









func A_arbace_java_process__init_A_Unit7__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_9; var tmp2 any = A_arbace_java_process_from_file_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_from_file_A_Init(); tmp3 = A_arbace_java_process_from_file_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_10)); return A_arbace_java_process__init_A_const_9.Ref() }






func A_arbace_java_process__init_A_Unit8__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_11; var tmp2 any = A_arbace_java_process_start_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_start_A_Init(); tmp3 = A_arbace_java_process_start_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_12)); return A_arbace_java_process__init_A_const_11.Ref() }










































func A_arbace_java_process__init_A_Unit9__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(96, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_13; var tmp2 any = A_arbace_java_process_stdin_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_stdin_A_Init(); tmp3 = A_arbace_java_process_stdin_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_14)); return A_arbace_java_process__init_A_const_13.Ref() }





func A_arbace_java_process__init_A_Unit10__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(102, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_15; var tmp2 any = A_arbace_java_process_stdout_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_stdout_A_Init(); tmp3 = A_arbace_java_process_stdout_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_16)); return A_arbace_java_process__init_A_const_15.Ref() }





func A_arbace_java_process__init_A_Unit11__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_17; var tmp2 any = A_arbace_java_process_stderr_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_stderr_A_Init(); tmp3 = A_arbace_java_process_stderr_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_18)); return A_arbace_java_process__init_A_const_17.Ref() }





func A_arbace_java_process__init_A_Unit12__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(114, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_19; var tmp2 any = A_arbace_java_process_exit_ref_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_exit_ref_A_Init(); tmp3 = A_arbace_java_process_exit_ref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_20)); return A_arbace_java_process__init_A_const_19.Ref() }















func A_arbace_java_process__init_A_Unit13__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(130, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_process__init_A_const_21; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_22)); v__1927001498__auto____1 = A_arbace_java_process__init_A_const_21.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_process__init_A_const_21; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_24)); var tmp3 *lang.Var = A_arbace_java_process__init_A_const_21; var tmp4 *A_arbace_java_process_eval1620000047_reify__1620000048_A; var counter__2 any = lang.IFn_Cast(jrt.NN(A_arbace_java_process__init_A_const_23).GetRawRoot__O()).Invoke_O__O(A_arbace_java_process__init_A_const_25)

	tmp4 = A_arbace_java_process_eval1620000047_reify__1620000048_A_New_IPersistentMap_O(nil, counter__2)
//line :130:1
	jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_java_process__init_A_const_21.Ref() } }








func A_arbace_java_process__init_A_Unit14__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(139, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_process__init_A_const_26; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_27)); v__1927001498__auto____1 = A_arbace_java_process__init_A_const_26.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_process__init_A_const_26; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_28)); var tmp3 *lang.Var = A_arbace_java_process__init_A_const_26; jrt.NN(tmp3).BindRoot_O__V(jrt.Executors_NewCachedThreadPool_ThreadFactory__ExecutorService(jrt.ThreadFactory_Cast(jrt.NN(A_arbace_java_process__init_A_const_21).GetRawRoot__O()))); return A_arbace_java_process__init_A_const_26.Ref() } }


func A_arbace_java_process__init_A_Unit15__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(142, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_29; var tmp2 any = A_arbace_java_process_io_task_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_io_task_A_Init(); tmp3 = A_arbace_java_process_io_task_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_30)); return A_arbace_java_process__init_A_const_29.Ref() }




















func A_arbace_java_process__init_A_Unit16__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.Var = A_arbace_java_process__init_A_const_31; var tmp2 any = A_arbace_java_process_exec_A_New(); var tmp3 *jrt.Class; A_arbace_java_process_exec_A_Init(); tmp3 = A_arbace_java_process_exec_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_java_process__init_A_const_31; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_process__init_A_const_32)); return A_arbace_java_process__init_A_const_31.Ref() }
















func A_arbace_java_process__init_A_Unit17__O() any { A_arbace_java_process__init_A_Init(); lang.Compiler_AOT_At_I_I__V(180, 1); return nil }



type A_arbace_java_process__init_A struct{ jrt.Object }

var A_arbace_java_process__init_A_const_0 *lang.Var

var A_arbace_java_process__init_A_const_1 any

var A_arbace_java_process__init_A_const_2 any

var A_arbace_java_process__init_A_const_3 any

var A_arbace_java_process__init_A_const_4 *lang.Var

var A_arbace_java_process__init_A_const_5 *lang.Var

var A_arbace_java_process__init_A_const_6 any

var A_arbace_java_process__init_A_const_7 *lang.Var

var A_arbace_java_process__init_A_const_8 any

var A_arbace_java_process__init_A_const_9 *lang.Var

var A_arbace_java_process__init_A_const_10 any

var A_arbace_java_process__init_A_const_11 *lang.Var

var A_arbace_java_process__init_A_const_12 any

var A_arbace_java_process__init_A_const_13 *lang.Var

var A_arbace_java_process__init_A_const_14 any

var A_arbace_java_process__init_A_const_15 *lang.Var

var A_arbace_java_process__init_A_const_16 any

var A_arbace_java_process__init_A_const_17 *lang.Var

var A_arbace_java_process__init_A_const_18 any

var A_arbace_java_process__init_A_const_19 *lang.Var

var A_arbace_java_process__init_A_const_20 any

var A_arbace_java_process__init_A_const_21 *lang.Var

var A_arbace_java_process__init_A_const_22 any

var A_arbace_java_process__init_A_const_23 *lang.Var

var A_arbace_java_process__init_A_const_24 any

var A_arbace_java_process__init_A_const_25 any

var A_arbace_java_process__init_A_const_26 *lang.Var

var A_arbace_java_process__init_A_const_27 any

var A_arbace_java_process__init_A_const_28 any

var A_arbace_java_process__init_A_const_29 *lang.Var

var A_arbace_java_process__init_A_const_30 any

var A_arbace_java_process__init_A_const_31 *lang.Var

var A_arbace_java_process__init_A_const_32 any

var A_arbace_java_process__init_A_init jrt.ClassInit

func A_arbace_java_process__init_A_Init() { if !A_arbace_java_process__init_A_init.Done() { A_arbace_java_process__init_A_init.Run(A_arbace_java_process__init_A_clinit) } }

func A_arbace_java_process__init_A_clinit() { A_arbace_java_process__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_java_process__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_java_process__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11)); A_arbace_java_process__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_java_process__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_java_process__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_9, Lit_29); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(); var tmp2 any = lang.RT_ClassForNameNonLoading_String__Class(Lit_45).Ref(); var tmp3 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; var tmp5 any = tmp4.Ref(); A_arbace_java_process__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp5, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_9, Lit_85); A_arbace_java_process__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_89).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref()), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_49).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_9, Lit_94); A_arbace_java_process__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_49).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_95, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_9, Lit_41); A_arbace_java_process__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref())).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_9, Lit_98); A_arbace_java_process__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_101, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_9, Lit_31); A_arbace_java_process__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_46).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(102).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_9, Lit_103); A_arbace_java_process__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_46).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_104, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(108).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_9, Lit_43); A_arbace_java_process__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_105, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(114).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_9, Lit_106); var tmp6 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; var tmp8 any = tmp7.Ref(); A_arbace_java_process__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); var tmp9 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(); var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; var tmp11 any = tmp10.Ref(); A_arbace_java_process__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp11, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_25 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_java_process__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_9, Lit_36); var tmp12 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(); var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; var tmp14 any = tmp13.Ref(); A_arbace_java_process__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp14, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(139).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); var tmp15 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(); var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; var tmp17 any = tmp16.Ref(); A_arbace_java_process__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp17, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(139).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_9, Lit_40); var tmp18 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(); var tmp19 any = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_87)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_108).Ref()))))))); var tmp20 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(); var tmp21 *jrt.Boolean; jrt.Boolean_Init(); tmp21 = jrt.Boolean_TRUE; var tmp22 any = tmp21.Ref(); A_arbace_java_process__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp19, tmp20, tmp22, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(142).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)); A_arbace_java_process__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_9, Lit_110); A_arbace_java_process__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_86).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_111, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), jrt.Integer_ValueOf_I__Integer(163).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_83).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_84)) }

func A_arbace_java_process__init_A_New() *A_arbace_java_process__init_A { A_arbace_java_process__init_A_Init(); t := &A_arbace_java_process__init_A{}; t.Ctor(); return t }

func (t *A_arbace_java_process__init_A) Ctor() {}

func (t *A_arbace_java_process__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_process__init_A) GetClass__Class() *jrt.Class { return A_arbace_java_process__init_A_class }

func (t *A_arbace_java_process__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_process__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_process__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_process__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_process__init_A); return ok }

func A_arbace_java_process__init_A_Cast(x any) *A_arbace_java_process__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_process__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_process__init_A_class)) }; return v }
