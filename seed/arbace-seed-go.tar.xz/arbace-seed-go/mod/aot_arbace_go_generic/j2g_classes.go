//line j2g_classes.ae:1
package aot_arbace_go_generic

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_generic_arg_form_A_class, Name: "arbace.go.generic$arg_form", Modifiers: 25, Simple: "arg_form", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_arg_form_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_callee_name_A_class, Name: "arbace.go.generic$callee_name", Modifiers: 25, Simple: "callee_name", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_callee_name_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_check_errors_BANG__A_class, Name: "arbace.go.generic$check_errors_BANG_", Modifiers: 25, Simple: "check_errors_BANG_", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_check_errors_BANG__A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_class, Name: "arbace.go.generic$check_errors_BANG_$iter__278000018__278000022", Modifiers: 25, Simple: "iter__278000018__278000022", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_check_errors_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_class, Name: "arbace.go.generic$check_errors_BANG_$iter__278000018__278000022$fn__278000023", Modifiers: 25, Simple: "fn__278000023", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_class, Name: "arbace.go.generic$check_errors_BANG_$iter__278000018__278000022$fn__278000023$fn__278000024", Modifiers: 25, Simple: "fn__278000024", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_class, Name: "arbace.go.generic$check_errors_BANG_$iter__278000028__278000032", Modifiers: 25, Simple: "iter__278000028__278000032", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_check_errors_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_class, Name: "arbace.go.generic$check_errors_BANG_$iter__278000028__278000032$fn__278000033", Modifiers: 25, Simple: "fn__278000033", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_class, Name: "arbace.go.generic$check_errors_BANG_$iter__278000028__278000032$fn__278000033$fn__278000034", Modifiers: 25, Simple: "fn__278000034", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_desc__GT_type_A_class, Name: "arbace.go.generic$desc__GT_type", Modifiers: 25, Simple: "desc__GT_type", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_desc__GT_type_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_desc__GT_type_fn__278000058_A_class, Name: "arbace.go.generic$desc__GT_type$fn__278000058", Modifiers: 25, Simple: "fn__278000058", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_desc__GT_type_fn__278000058_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_desc__GT_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_desc__GT_type_sub__278000052_A_class, Name: "arbace.go.generic$desc__GT_type$sub__278000052", Modifiers: 25, Simple: "sub__278000052", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_desc__GT_type_sub__278000052_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_desc__GT_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_desc__GT_type_unknown__278000054_A_class, Name: "arbace.go.generic$desc__GT_type$unknown__278000054", Modifiers: 25, Simple: "unknown__278000054", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_desc__GT_type_unknown__278000054_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_desc__GT_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_error_BANG__A_class, Name: "arbace.go.generic$error_BANG_", Modifiers: 25, Simple: "error_BANG_", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_error_BANG__A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A_class, Name: "arbace.go.generic$eval278000004$loading__1927001464__auto____278000005", Modifiers: 25, Simple: "loading__1927001464__auto____278000005", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_eval278000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_eval278000008_fn__278000009_A_class, Name: "arbace.go.generic$eval278000008$fn__278000009", Modifiers: 25, Simple: "fn__278000009", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_eval278000008_fn__278000009_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_eval278000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_generic_fn_A_class, Name: "arbace.go.generic$generic_fn", Modifiers: 25, Simple: "generic_fn", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_generic_fn_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class, &lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_infer_targs_A_class, Name: "arbace.go.generic$infer_targs", Modifiers: 25, Simple: "infer_targs", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_infer_targs_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF6_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_infer_targs_fn__278000082_A_class, Name: "arbace.go.generic$infer_targs$fn__278000082", Modifiers: 25, Simple: "fn__278000082", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_infer_targs_fn__278000082_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_infer_targs_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_instance_fn_A_class, Name: "arbace.go.generic$instance_fn", Modifiers: 25, Simple: "instance_fn", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_instance_fn_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_instantiate_A_class, Name: "arbace.go.generic$instantiate", Modifiers: 25, Simple: "instantiate", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_instantiate_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_instantiate_fn__278000104_A_class, Name: "arbace.go.generic$instantiate$fn__278000104", Modifiers: 25, Simple: "fn__278000104", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_instantiate_fn__278000104_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_instantiate_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_instantiate_fn__278000106_A_class, Name: "arbace.go.generic$instantiate$fn__278000106", Modifiers: 25, Simple: "fn__278000106", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_instantiate_fn__278000106_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_instantiate_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_operand_A_class, Name: "arbace.go.generic$operand", Modifiers: 25, Simple: "operand", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_operand_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_params_for_A_class, Name: "arbace.go.generic$params_for", Modifiers: 25, Simple: "params_for", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_params_for_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_params_for_fn__278000074_A_class, Name: "arbace.go.generic$params_for$fn__278000074", Modifiers: 25, Simple: "fn__278000074", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_params_for_fn__278000074_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_params_for_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_params_for_fn__278000076_A_class, Name: "arbace.go.generic$params_for$fn__278000076", Modifiers: 25, Simple: "fn__278000076", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_params_for_fn__278000076_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_params_for_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_receiver_targs_A_class, Name: "arbace.go.generic$receiver_targs", Modifiers: 25, Simple: "receiver_targs", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_receiver_targs_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_rehome_A_class, Name: "arbace.go.generic$rehome", Modifiers: 25, Simple: "rehome", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_rehome_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_rehome_fn__278000045_A_class, Name: "arbace.go.generic$rehome$fn__278000045", Modifiers: 25, Simple: "fn__278000045", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_rehome_fn__278000045_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_rehome_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_rehome_r__278000042_A_class, Name: "arbace.go.generic$rehome$r__278000042", Modifiers: 25, Simple: "r__278000042", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_rehome_r__278000042_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_rehome_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_resolve_instance_A_class, Name: "arbace.go.generic$resolve_instance", Modifiers: 25, Simple: "resolve_instance", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_resolve_instance_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_resolve_instance_fn__278000095_A_class, Name: "arbace.go.generic$resolve_instance$fn__278000095", Modifiers: 25, Simple: "fn__278000095", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_resolve_instance_fn__278000095_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_resolve_instance_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_resolve_instance_fn__278000097_A_class, Name: "arbace.go.generic$resolve_instance$fn__278000097", Modifiers: 25, Simple: "fn__278000097", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_resolve_instance_fn__278000097_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_resolve_instance_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_tparams_of_A_class, Name: "arbace.go.generic$tparams_of", Modifiers: 25, Simple: "tparams_of", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_tparams_of_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_type_instance_A_class, Name: "arbace.go.generic$type_instance", Modifiers: 25, Simple: "type_instance", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_type_instance_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_type_instance_fn__278000110_A_class, Name: "arbace.go.generic$type_instance$fn__278000110", Modifiers: 25, Simple: "fn__278000110", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_type_instance_fn__278000110_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_type_instance_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_type_instance_fn__278000112_A_class, Name: "arbace.go.generic$type_instance$fn__278000112", Modifiers: 25, Simple: "fn__278000112", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_type_instance_fn__278000112_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_type_instance_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_type_summary_A_class, Name: "arbace.go.generic$type_summary", Modifiers: 25, Simple: "type_summary", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_type_summary_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_generic_with_checker_A_class, Name: "arbace.go.generic$with_checker", Modifiers: 25, Simple: "with_checker", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_with_checker_A", Source: "generic.ae", Declaring: &A_arbace_go_generic_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_generic_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_generic_A_New()}; return nil }

var A_arbace_go_generic_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_generic_A_new}

var A_arbace_go_generic_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.generic", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_A"})

func init() { i := A_arbace_go_generic_A_class.Info(); i.IsInstance = A_arbace_go_generic_A_InstanceOf; i.Init = A_arbace_go_generic_A_Init; i.Table = A_arbace_go_generic_A_members }

var A_arbace_go_generic_arg_form_A_class *jrt.Class

var A_arbace_go_generic_callee_name_A_class *jrt.Class

var A_arbace_go_generic_check_errors_BANG__A_class *jrt.Class

var A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_class *jrt.Class

var A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_class *jrt.Class

var A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_class *jrt.Class

var A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_class *jrt.Class

var A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_class *jrt.Class

var A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_class *jrt.Class

var A_arbace_go_generic_desc__GT_type_A_class *jrt.Class

var A_arbace_go_generic_desc__GT_type_fn__278000058_A_class *jrt.Class

var A_arbace_go_generic_desc__GT_type_sub__278000052_A_class *jrt.Class

var A_arbace_go_generic_desc__GT_type_unknown__278000054_A_class *jrt.Class

var A_arbace_go_generic_error_BANG__A_class *jrt.Class

func A_arbace_go_generic_eval278000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_generic_eval278000004_A_New()}; return nil }

var A_arbace_go_generic_eval278000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_generic_eval278000004_A_new}

var A_arbace_go_generic_eval278000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.generic$eval278000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_generic_A_class, Simple: "eval278000004", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_eval278000004_A"})

func init() { i := A_arbace_go_generic_eval278000004_A_class.Info(); i.IsInstance = A_arbace_go_generic_eval278000004_A_InstanceOf; i.Table = A_arbace_go_generic_eval278000004_A_members }

var A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A_class *jrt.Class

func A_arbace_go_generic_eval278000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_generic_eval278000008_A_New()}; return nil }

var A_arbace_go_generic_eval278000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_generic_eval278000008_A_new}

var A_arbace_go_generic_eval278000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.generic$eval278000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_generic_A_class, Simple: "eval278000008", Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic_eval278000008_A"})

func init() { i := A_arbace_go_generic_eval278000008_A_class.Info(); i.IsInstance = A_arbace_go_generic_eval278000008_A_InstanceOf; i.Table = A_arbace_go_generic_eval278000008_A_members }

var A_arbace_go_generic_eval278000008_fn__278000009_A_class *jrt.Class

var A_arbace_go_generic_generic_fn_A_class *jrt.Class

var A_arbace_go_generic_infer_targs_A_class *jrt.Class

var A_arbace_go_generic_infer_targs_fn__278000082_A_class *jrt.Class

var A_arbace_go_generic_instance_fn_A_class *jrt.Class

var A_arbace_go_generic_instantiate_A_class *jrt.Class

var A_arbace_go_generic_instantiate_fn__278000104_A_class *jrt.Class

var A_arbace_go_generic_instantiate_fn__278000106_A_class *jrt.Class

var A_arbace_go_generic_operand_A_class *jrt.Class

var A_arbace_go_generic_params_for_A_class *jrt.Class

var A_arbace_go_generic_params_for_fn__278000074_A_class *jrt.Class

var A_arbace_go_generic_params_for_fn__278000076_A_class *jrt.Class

var A_arbace_go_generic_receiver_targs_A_class *jrt.Class

var A_arbace_go_generic_rehome_A_class *jrt.Class

var A_arbace_go_generic_rehome_fn__278000045_A_class *jrt.Class

var A_arbace_go_generic_rehome_r__278000042_A_class *jrt.Class

var A_arbace_go_generic_resolve_instance_A_class *jrt.Class

var A_arbace_go_generic_resolve_instance_fn__278000095_A_class *jrt.Class

var A_arbace_go_generic_resolve_instance_fn__278000097_A_class *jrt.Class

var A_arbace_go_generic_tparams_of_A_class *jrt.Class

var A_arbace_go_generic_type_instance_A_class *jrt.Class

var A_arbace_go_generic_type_instance_fn__278000110_A_class *jrt.Class

var A_arbace_go_generic_type_instance_fn__278000112_A_class *jrt.Class

var A_arbace_go_generic_type_summary_A_class *jrt.Class

var A_arbace_go_generic_with_checker_A_class *jrt.Class

func A_arbace_go_generic__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go_generic__init_A_Load__O()}; return nil }

func A_arbace_go_generic__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_generic__init_A_New()}; return nil }

var A_arbace_go_generic__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go_generic__init_A_invoke, New: A_arbace_go_generic__init_A_new}

var A_arbace_go_generic__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.generic__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_generic.A_arbace_go_generic__init_A", Source: "generic.ae"})

func init() { i := A_arbace_go_generic__init_A_class.Info(); i.IsInstance = A_arbace_go_generic__init_A_InstanceOf; i.Init = A_arbace_go_generic__init_A_Init; i.Table = A_arbace_go_generic__init_A_members }
