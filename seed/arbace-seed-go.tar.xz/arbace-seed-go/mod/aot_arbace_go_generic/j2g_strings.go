//line j2g_strings.ae:1
package aot_arbace_go_generic

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn19,arbace.go.check.envyn1,eyn21,arbace.go.check.typesyn1,tyn20,arbace.go.check.codeyn4,codeyn20,arbace.go.check.declyn4,declyn15,arbace.go.buildyn1,bkn3,docys11,arbace.core7,bindingys15,arbace.go.build5,*ctx*ys19,arbace.go.check.env8,*errors*ys11,arbace.core9,volatile!ys19,arbace.go.check.env6,*decl*ys19,arbace.go.check.env6,*line*ys21,arbace.go.check.types12,*method-obj*ys15,arbace.go.build11,method-datays21,arbace.go.check.types14,*subst-method*ys20,arbace.go.check.decl12,subst-methodys21,arbace.go.check.types15,*resolve-named*ys15,arbace.go.build18,complete-instance!ys20,arbace.go.check.code7,*subst*ys20,arbace.go.check.decl5,substys20,arbace.go.check.code13,*instantiate*ys20,arbace.go.check.decl11,instantiateys20,arbace.go.check.code14,*verify-later*ys11,arbace.core2,fnyn1,&yn20,___278000012__auto__kn3,msgks2,go6,errorskn4,filekn13,GoGenericCallkn5,targskn6,originkn3,pkgkn5,localkn4,elsekn5,namedkn3,mapkn5,slicekn5,arraykn4,chankn4,namekn5,tuplekn4,funckn7,pointerkn6,structkn4,typeks3,goi11,unsupportedkn14,unsafe-pointerkn9,interfacekn8,embeddedkn4,recvkn4,sendkn4,bothkn12,untyped-runekn13,untyped-floatkn12,untyped-boolkn14,untyped-stringkn11,untyped-intkn2,fnkn11,untyped-nilkn4,modekn5,valuekn4,formkn8,constantkn3,valkn3,anykn4,collkn8,rtparamskn7,tparamskn6,methodkn10,recv-namedkn8,pkg-namekn3,objkn6,ptargskn3,envkn6,ctx-ofkn5,instskn7,invalidv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn17,arbace.go.genericm2,R14,s1191,goi's generic functions at the REPL (doc/go/GOI-SPEC.md \"As built: GR9d\"; GR9-SURVEY.md\n  §4; GC34 (b), GC72-GC74): the var of a generic function (and of a generic type's method T.M,\n  its receiver first) holds an arbace.lang.GoGenericFn. A call keys its arguments by their\n  types (GoGenericFn/keyOf: a Go value its descriptor, an Arbace scalar its untyped kind, a fn\n  or a collection none); on the first call of a key, resolve here types them as the checker's\n  operands (an Arbace scalar an untyped constant of its kind, a Go value its Go type: GC72 (a)),\n  runs the checker's infer with the explicit type arguments (go/inst, GC73), verifies the\n  constraints, and makes the instance's GoFn over the builder's instance-cell (shared with the\n  instances interpreted code makes); the GoGenericFn keeps it by the key (GC74 (a)).\n\n  A Go value's type is the checker's type of its descriptor (GoInterp/typeInfo): an interpreted\n  named type's the builder's registry (arbace.go.build/desc-types) gives, taken to its\n  package's last check (rehome: a named type of an older check is the same type as the\n  generic declaration's), a compiled named type's the digest's, composites by their parts.v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR15,v11,arbace.core5,applyv11,arbace.core6,vectorR16,R17,R18,R19,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,v19,arbace.go.check.env8,*errors*v11,arbace.core7,ex-infov13,arbace.string4,joinv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR35,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core4,takel10,R36,v11,arbace.core3,vecv11,arbace.core5,assocR37,v19,arbace.go.check.env6,error!R38,v17,arbace.go.generic6,rehomev11,arbace.core8,keyword?v21,arbace.go.check.types6,named?v21,arbace.go.check.types4,infoR39,v11,arbace.core4,mapvR40,v20,arbace.go.check.decl11,instantiateR41,R42,R43,R44,v21,arbace.go.check.types7,tparam?R45,R46,R47,R48,R49,R50,v11,arbace.core4,intoV1,R50,v11,arbace.core3,mapR51,R52,R53,v11,arbace.core6,updateR54,v17,arbace.go.generic10,desc->typem2,R55,s24,inference from this typev15,arbace.go.build10,desc-typesv11,arbace.core9,contains?v17,arbace.go.generic11,basic-kindsv11,arbace.core7,keywordR56,v19,arbace.go.check.env10,error-typeR57,R58,R59,R60,R61,S5,R62,R63,R64,R65,R66,v11,arbace.core6,symbolv17,arbace.go.generic8,arg-formR67,R68,R69,R70,R71,R64,R72,R73,v11,arbace.core5,char?R66,R62,R65,R63,R74,R75,v19,arbace.go.check.env1,oR76,R77,R78,R79,R80,v11,arbace.core4,lastv13,arbace.string5,splitv11,arbace.core3,strp1,/S3,R62,R63,R66,v21,arbace.go.check.types8,type-strv11,arbace.core6,repeatv11,arbace.core4,peekv17,arbace.go.generic6,error!v11,arbace.core6,formatv17,arbace.go.generic12,type-summaryv11,arbace.core11,map-indexedv20,arbace.go.check.code14,rename-tparamsV1,R50,v20,arbace.go.check.code5,inferv11,arbace.core6,empty?v20,arbace.go.check.decl7,verify!v17,arbace.go.generic11,callee-namev15,arbace.go.build7,rt-namev15,arbace.go.build17,instance-callablev21,arbace.go.check.types10,deref-typev11,arbace.core4,nextv11,arbace.core8,to-arrayR81,R82,R83,R84,v17,arbace.go.generic7,operandv11,arbace.core6,subvecl0,v17,arbace.go.generic14,receiver-targsv20,arbace.go.check.decl5,substv11,arbace.core6,zipmapv17,arbace.go.generic10,params-forv17,arbace.go.generic11,infer-targsv11,arbace.core4,dropv17,arbace.go.generic11,instance-fnv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv15,arbace.go.build5,*ctx*v11,arbace.core9,volatile!v19,arbace.go.check.env6,*decl*v19,arbace.go.check.env6,*line*v21,arbace.go.check.types12,*method-obj*v15,arbace.go.build11,method-datav21,arbace.go.check.types14,*subst-method*v20,arbace.go.check.decl12,subst-methodv21,arbace.go.check.types15,*resolve-named*v15,arbace.go.build18,complete-instance!v20,arbace.go.check.code7,*subst*v20,arbace.go.check.code13,*instantiate*v20,arbace.go.check.code14,*verify-later*v17,arbace.go.generic13,check-errors!R85,v11,arbace.core4,atomv17,arbace.go.generic16,resolve-instancev17,arbace.go.generic10,generic-fnv17,arbace.go.generic10,tparams-ofv15,arbace.go.build4,descR86,")

var Lit_1 *jrt.String = jrt.Intern("argument ")

var Lit_2 *jrt.String = jrt.Intern(".")

var Lit_3 *jrt.String = jrt.Intern("Go check errors:\n")

var Lit_4 *jrt.String = jrt.Intern("\n")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.generic$check_errors_BANG_$iter__278000018__278000022")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.generic$check_errors_BANG_$iter__278000028__278000032")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.generic$check_errors_BANG_$iter__278000018__278000022$fn__278000023")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.generic$check_errors_BANG_$iter__278000018__278000022$fn__278000023$fn__278000024")

var Lit_9 *jrt.String = jrt.Intern("REPL: ")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.generic$check_errors_BANG_$iter__278000028__278000032$fn__278000033")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.generic$check_errors_BANG_$iter__278000028__278000032$fn__278000033$fn__278000034")

var Lit_12 *jrt.String = jrt.Intern("REPL")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.generic$desc__GT_type$sub__278000052")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.generic$desc__GT_type$unknown__278000054")

var Lit_15 *jrt.String = jrt.Intern("interp")

var Lit_16 *jrt.String = jrt.Intern("compiled")

var Lit_17 *jrt.String = jrt.Intern("unsafe.Pointer")

var Lit_18 *jrt.String = jrt.Intern("func")

var Lit_19 *jrt.String = jrt.Intern("slice")

var Lit_20 *jrt.String = jrt.Intern("interface")

var Lit_21 *jrt.String = jrt.Intern("error")

var Lit_22 *jrt.String = jrt.Intern("array")

var Lit_23 *jrt.String = jrt.Intern("struct")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.generic$desc__GT_type$fn__278000058")

var Lit_25 *jrt.String = jrt.Intern("chan")

var Lit_26 *jrt.String = jrt.Intern("map")

var Lit_27 *jrt.String = jrt.Intern("ptr")

var Lit_28 *jrt.String = jrt.Intern("goi: a Go value of type ")

var Lit_29 *jrt.String = jrt.Intern(" cannot be typed for a generic function's inference")

var Lit_30 *jrt.String = jrt.Intern("arbace.lang.GoInterp")

var Lit_31 *jrt.String = jrt.Intern("arbace.lang.GoFn")

var Lit_32 *jrt.String = jrt.Intern("arbace.lang.GoGenericFn")

var Lit_33 *jrt.String = jrt.Intern("arbace.lang.GoType")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.generic$infer_targs$fn__278000082")

var Lit_35 *jrt.String = jrt.Intern("in call to ")

var Lit_36 *jrt.String = jrt.Intern(", ")

var Lit_37 *jrt.String = jrt.Intern("[")

var Lit_38 *jrt.String = jrt.Intern("]")

var Lit_39 *jrt.String = jrt.Intern(",")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.generic$instantiate$fn__278000104")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.generic$instantiate$fn__278000106")

var Lit_42 *jrt.String = jrt.Intern("got %d type arguments but %s has %d type parameters")

var Lit_43 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_44 *jrt.String = jrt.Intern("%s arguments in call to %s\n\thave (%s)\n\twant (%s)")

var Lit_45 *jrt.String = jrt.Intern("not enough")

var Lit_46 *jrt.String = jrt.Intern("too many")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.generic$params_for$fn__278000074")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.generic$params_for$fn__278000076")

var Lit_49 *jrt.String = jrt.Intern("...")

var Lit_50 *jrt.String = jrt.Intern("in call to %s, the receiver (%s) is not of type %s")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.generic$rehome$r__278000042")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.generic$rehome$fn__278000045")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.generic$resolve_instance$fn__278000095")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.generic$resolve_instance$fn__278000097")

var Lit_55 *jrt.String = jrt.Intern("not enough arguments in call to ")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.generic$type_instance$fn__278000110")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.generic$type_instance$fn__278000112")

var Lit_58 *jrt.String = jrt.Intern("number")

var Lit_59 *jrt.String = jrt.Intern("string")

var Lit_60 *jrt.String = jrt.Intern("bool")

var Lit_61 *jrt.String = jrt.Intern("nil")

var Lit_62 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,ctxyn1,&yn4,bodykn4,linekn6,columnkn4,fileyn3,msgyn2,tyyn3,envyn1,dyn1,kyn1,vyn1,iyn1,xyn5,cnameyn1,_yn2,psyn8,variadicyn3,opsyn3,tpsyn5,knownyn6,paramsyn5,extrayn5,targsyn2,rtyn2,opkn3,tagyn11,GoGenericFnyn7,objectsyn4,fullyn6,ptargsyn1,gv11,arbace.core5,in-nsMyn17,arbace.go.genericm2,R0,s1191,goi's generic functions at the REPL (doc/go/GOI-SPEC.md \"As built: GR9d\"; GR9-SURVEY.md\n  §4; GC34 (b), GC72-GC74): the var of a generic function (and of a generic type's method T.M,\n  its receiver first) holds an arbace.lang.GoGenericFn. A call keys its arguments by their\n  types (GoGenericFn/keyOf: a Go value its descriptor, an Arbace scalar its untyped kind, a fn\n  or a collection none); on the first call of a key, resolve here types them as the checker's\n  operands (an Arbace scalar an untyped constant of its kind, a Go value its Go type: GC72 (a)),\n  runs the checker's infer with the explicit type arguments (go/inst, GC73), verifies the\n  constraints, and makes the instance's GoFn over the builder's instance-cell (shared with the\n  instances interpreted code makes); the GoGenericFn keeps it by the key (GC74 (a)).\n\n  A Go value's type is the checker's type of its descriptor (GoInterp/typeInfo): an interpreted\n  named type's the builder's registry (arbace.go.build/desc-types) gives, taken to its\n  package's last check (rehome: a named type of an older check is the same type as the\n  generic declaration's), a compiled named type's the digest's, composites by their parts.m2,R0,s1191,goi's generic functions at the REPL (doc/go/GOI-SPEC.md \"As built: GR9d\"; GR9-SURVEY.md\n  §4; GC34 (b), GC72-GC74): the var of a generic function (and of a generic type's method T.M,\n  its receiver first) holds an arbace.lang.GoGenericFn. A call keys its arguments by their\n  types (GoGenericFn/keyOf: a Go value its descriptor, an Arbace scalar its untyped kind, a fn\n  or a collection none); on the first call of a key, resolve here types them as the checker's\n  operands (an Arbace scalar an untyped constant of its kind, a Go value its Go type: GC72 (a)),\n  runs the checker's infer with the explicit type arguments (go/inst, GC73), verifies the\n  constraints, and makes the instance's GoFn over the builder's instance-cell (shared with the\n  instances interpreted code makes); the GoGenericFn keeps it by the key (GC74 (a)).\n\n  A Go value's type is the checker's type of its descriptor (GoInterp/typeInfo): an interpreted\n  named type's the builder's registry (arbace.go.build/desc-types) gives, taken to its\n  package's last check (rehome: a named type of an older check is the same type as the\n  generic declaration's), a compiled named type's the digest's, composites by their parts.R1,v17,arbace.go.generic12,with-checkerm12,R2,TR3,L1,V3,R4,R5,R6,R0,s160,Runs body with the checker's hooks bound as the builder binds them (define!), errors\n  collected; ctx is the build context of the generic declaration's package.R7,i26,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic13,check-errors!m12,R2,TR3,L1,V0,R0,s85,Throws the errors collected (as the REPL's check errors: their messages, :go/errors).R7,i42,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic6,error!m12,R2,TR3,L1,V1,R10,R0,s39,Records a check error with message msg.R7,i49,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic6,rehomem10,R3,L1,V2,R11,R12,R0,s171,Type ty with its interpreted named types taken to their packages' last check (env's :named:\n  path, name -> the type, or nil), its instances instantiated again from those.R7,i56,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic11,basic-kindsS17,s5,int16s3,ints6,strings7,float32s7,float64s4,uints5,int32s6,uint16s7,uintptrs6,uint32s5,int64s10,complex128s6,uint64s4,bools5,uint8s4,int8s9,complex64m8,R2,TR7,i84,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic10,desc->typem10,R3,L1,V2,R13,R12,R0,s89,The checker's type of descriptor d (a Go value's, GoInterp/valueType), in env's universe.R7,i88,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic8,arg-formm12,R2,TR3,L1,V3,R14,R15,R16,R0,s84,The form an argument is named by in messages: a scalar its literal, else argument N.R7,i120,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic7,operandm10,R3,L1,V4,R14,R15,R16,R12,R0,s86,Argument v (its key element k, index i) as the checker's operand for inference (§4.3).R7,i127,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic10,tparams-ofm10,R2,TR3,L1,V1,R17,R7,i142,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic11,callee-namem12,R2,TR3,L1,V1,R17,R0,s65,The generic function's name in messages: pkg.F, T.M for a method.R7,i144,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic12,type-summarym10,R2,TR3,L1,V1,R11,R7,i151,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic10,params-form12,R2,TR3,L1,V3,R18,V4,R19,R20,R19,R21,R22,R0,s115,Signature sig's parameters for nargs arguments (a variadic one's elements expanded), or nil\n  after an arity error.R7,i159,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic11,infer-targsm12,R2,TR3,L1,V6,R18,R23,R24,R25,R22,R26,R0,s200,The type arguments of tps (known: those given, nil the unknown) from operands ops for the\n  parameters params, verified against their constraints (extra: a method's receiver's), or nil\n  after errors.R7,i174,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic11,instance-fnm12,R2,TR3,L1,V3,R17,R27,R28,R0,s85,The GoFn of generic x's instance for targs (rt: a method's receiver's instance type).R7,i186,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic14,receiver-targsm12,R2,TR3,L1,V3,R17,R18,R29,R0,s110,The type arguments of method x's receiver's generic type from the receiver's operand, or nil\n  after an error.R7,i193,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic16,resolve-instancem10,R3,L1,V3,Myn1,gm2,R30,R31,Myn1,km2,R30,R32,Myn4,argsm2,R30,R32,R0,s93,GoGenericFn's resolve: the instance's GoFn for a call's key k and arguments args (§4.2-§4.4).R7,i207,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic10,generic-fnm10,R3,L2,V3,R17,R33,R12,V4,R17,R33,R12,R34,R0,s176,The GoGenericFn of generic function or method object x, named full (pkg.F, pkg.T.M), its\n  explicit type arguments ptargs (go/inst's, partial; nil: none), env {:ctx-of :named}.R7,i244,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic11,instantiatem10,R3,L1,V2,Myn1,gm2,R30,R31,R27,R0,s207,(go/inst g T...) of GoGenericFn g with the checker types targs (resolved): every type\n  argument given, the instance's GoFn (a method's: its receiver first); fewer, a GoGenericFn\n  inferring the rest (§4.5).R7,i251,R8,i1,R9,s20,arbace/go/generic.aev17,arbace.go.generic13,type-instancem10,R3,L1,V3,R35,R27,R12,R0,s137,(go/inst T A...) of generic named type g (the checker's, its package's last check) with the\n  checker types targs: the instance's GoType.R7,i274,R8,i1,R9,s20,arbace/go/generic.ae")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.generic$eval278000004$loading__1927001464__auto____278000005")

var Lit_64 *jrt.String = jrt.Intern("arbace.go.generic$eval278000008$fn__278000009")

var Lit_65 *jrt.String = jrt.Intern("arbace.go.generic$with_checker")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.generic$check_errors_BANG_")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.generic$error_BANG_")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.generic$rehome")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.generic$desc__GT_type")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.generic$arg_form")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.generic$operand")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.generic$tparams_of")

var Lit_73 *jrt.String = jrt.Intern("arbace.go.generic$callee_name")

var Lit_74 *jrt.String = jrt.Intern("arbace.go.generic$type_summary")

var Lit_75 *jrt.String = jrt.Intern("arbace.go.generic$params_for")

var Lit_76 *jrt.String = jrt.Intern("arbace.go.generic$infer_targs")

var Lit_77 *jrt.String = jrt.Intern("arbace.go.generic$instance_fn")

var Lit_78 *jrt.String = jrt.Intern("arbace.go.generic$receiver_targs")

var Lit_79 *jrt.String = jrt.Intern("arbace.go.generic$resolve_instance")

var Lit_80 *jrt.String = jrt.Intern("arbace.go.generic$generic_fn")

var Lit_81 *jrt.String = jrt.Intern("arbace.go.generic$instantiate")

var Lit_82 *jrt.String = jrt.Intern("arbace.go.generic$type_instance")
