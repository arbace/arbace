//line aot_arbace_go_generic.ae:1
package aot_arbace_go_generic

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_build"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A_New() *A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_generic_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_1); lang.IFn_Cast(A_arbace_go_generic_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_go_generic_A_const_3, A_arbace_go_generic_A_const_4, A_arbace_go_generic_A_const_5, A_arbace_go_generic_A_const_6, A_arbace_go_generic_A_const_7, A_arbace_go_generic_A_const_8); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_31)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_32)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_generic_eval278000008_fn__278000009_A_New() *A_arbace_go_generic_eval278000008_fn__278000009_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_eval278000008_fn__278000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_generic_eval278000008_fn__278000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_generic_eval278000008_fn__278000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_9.GetRawRoot__O()); var tmp2 any; var root_20 any = A_arbace_go_generic_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_go_generic_A_const_11; if linked_21 == nil { tmp2 = ifn_22.Invoke_O__O(arg_23) } else { tmp2 = linked_21.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_20, arg_23) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_generic_A_const_12.GetRawRoot__O(), A_arbace_go_generic_A_const_13) }
























func A_arbace_go_generic_with_checker_A_New() *A_arbace_go_generic_with_checker_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_with_checker_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_go_generic_with_checker_A) Ctor() {}
//line :26:1
func (t *A_arbace_go_generic_with_checker_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ctx__2, body__3 any) any { var root_24 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_15.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_17); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp4 any; var root_34 any = A_arbace_go_generic_A_const_18.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = A_arbace_go_generic_A_const_19.GetRawRoot__O(); var arg_38 any; var root_39 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_15.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_20); var tmp7 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(ctx__2); var tmp8 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_21); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp10 any; var root_66 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var root_70 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_22); var arg_74 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp12 any; var root_75 any = A_arbace_go_generic_A_const_18.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = A_arbace_go_generic_A_const_19.GetRawRoot__O(); var arg_79 any; var root_80 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var root_84 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; if linked_85 == nil { arg_83 = ifn_86.Invoke__O() } else { arg_83 = linked_85.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_84) }; if linked_81 == nil { arg_79 = ifn_82.Invoke_O__O(arg_83) } else { arg_79 = linked_81.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_80, arg_83) }; if linked_76 == nil { tmp12 = ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { tmp12 = linked_76.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_75, arg_78, arg_79) }; arg_74 = tmp11.Invoke_O__O(tmp12); if linked_71 == nil { arg_69 = ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) }; if linked_67 == nil { tmp10 = ifn_68.Invoke_O__O(arg_69) } else { tmp10 = linked_67.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_66, arg_69) }; var tmp13 any = tmp9.Invoke_O__O(tmp10); var tmp14 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_23); var tmp15 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(nil); var tmp16 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_24); var tmp17 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(nil); var tmp18 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_25); var tmp19 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_26); var tmp20 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_27); var tmp21 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_28); var tmp22 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_29); var tmp23 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_30); var tmp24 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_31); var tmp25 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_32); var tmp26 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_33); var tmp27 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_34); var tmp28 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_35); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp30 any; var root_87 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_15.GetRawRoot__O()); var tmp32 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_36); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp34 any; var root_97 any = A_arbace_go_generic_A_const_18.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = A_arbace_go_generic_A_const_19.GetRawRoot__O(); var arg_101 any; var root_102 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any; var root_106 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_37); var arg_110 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_38); if linked_107 == nil { arg_105 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { arg_105 = linked_107.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_106, arg_109, arg_110) }; if linked_103 == nil { arg_101 = ifn_104.Invoke_O__O(arg_105) } else { arg_101 = linked_103.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_102, arg_105) }; if linked_98 == nil { tmp34 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { tmp34 = linked_98.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }; arg_90 = tmp31.Invoke_O_O_O__O(tmp32, tmp33.Invoke_O__O(tmp34), lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(nil)); if linked_88 == nil { tmp30 = ifn_89.Invoke_O__O(arg_90) } else { tmp30 = linked_88.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_87, arg_90) }; arg_42 = tmp5.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp6, tmp7, tmp8, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29.Invoke_O__O(tmp30)); if linked_40 == nil { arg_38 = ifn_41.Invoke_O__O(arg_42) } else { arg_38 = linked_40.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_39, arg_42) }; if linked_35 == nil { tmp4 = ifn_36.Invoke_O_O__O(arg_37, arg_38) } else { tmp4 = linked_35.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_34, arg_37, arg_38) }; arg_27 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), body__3); if linked_25 == nil { return ifn_26.Invoke_O__O(arg_27) } else { return linked_25.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_24, arg_27) } }















func A_arbace_go_generic_check_errors_BANG__A_New() *A_arbace_go_generic_check_errors_BANG__A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_go_generic_check_errors_BANG__A) Ctor() {}
//line :42:1
func (t *A_arbace_go_generic_check_errors_BANG__A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any; var root_111 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_113 lang.IFn; if


	linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var root_115 any = A_arbace_go_generic_A_const_10.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = A_arbace_go_generic_A_const_39.Get__O(); if linked_116 == nil { arg_114 = ifn_117.Invoke_O__O(arg_118) } else { arg_114 = linked_116.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_115, arg_118) }; if linked_112 == nil { temp__1927000414__auto____1 = ifn_113.Invoke_O__O(arg_114) } else { temp__1927000414__auto____1 = linked_112.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_111, arg_114) }; if jrt.J2g_Truth(temp__1927000414__auto____1) { var errs__2 any = temp__1927000414__auto____1; var tmp1 any; var root_119 any = A_arbace_go_generic_A_const_40.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_121 lang.IFn
		if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_3, nil); var tmp3 any; var root_124 any = A_arbace_go_generic_A_const_41.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = Lit_4; var arg_128 any; var iter__1927001039__auto____5 any; var tmp4 any = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_New(); var tmp5 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_fn_class; if fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_fn_class = fncls__187d; tmp5 = fncls__187d } else { tmp5 = fncls__187 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp7 any; var root_188 any = A_arbace_go_generic_A_const_53.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = A_arbace_go_generic_A_const_54; var arg_192 any = errs__2; if linked_189 == nil { tmp7 = ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { tmp7 = linked_189.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_188, arg_191, arg_192) }; arg_128 = tmp6.Invoke_O__O(tmp7); if linked_125 == nil { tmp3 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { tmp3 = linked_125.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) }; arg_122 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_123 any; var tmp8 any = A_arbace_go_generic_A_const_55; var tmp9 any; var root_193 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_195 lang.IFn
		if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any; var iter__1927001039__auto____3 any; var tmp10 any = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_New(); var tmp11 *jrt.Class; var fncls__267 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_fn_class; if fncls__267 == nil { var fncls__267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_fn_class = fncls__267d; tmp11 = fncls__267d } else { tmp11 = fncls__267 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); arg_196 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(errs__2); if linked_194 == nil { tmp9 = ifn_195.Invoke_O__O(arg_196) } else { tmp9 = linked_194.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_193, arg_196) }
//line :46:1
		arg_123 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9)); if linked_120 == nil { tmp1 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { tmp1 = linked_120.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }
//line :45:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } else { return nil } }
func A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_New() *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A) Ctor() {}
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A) Invoke_O_O__O(self, s__278000019__1 any) any { var tmp1 any = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_New_O_O(self, s__278000019__1); var tmp2 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_fn_class = fncls__186d; tmp2 = fncls__186d } else { tmp2 = fncls__186 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :46:1
func A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_New_O_O(p0, p1 any) *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A{}; t.Ctor_O_O(p0, p1); return t }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A) Ctor_O_O(c__iter__278000018, c__s__278000019 any) { t.F_iter__278000018 = c__iter__278000018; t.F_s__278000019 = c__s__278000019 }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A) Invoke_O__O(self any) any { { var s__278000019__1 any; var t_ any = t.F_s__278000019; t.F_s__278000019 = nil; s__278000019__1 = t_; for { var temp__1927000414__auto____2 any; var root_129 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = s__278000019__1; if linked_130 == nil { temp__1927000414__auto____2 = ifn_131.Invoke_O__O(arg_132) } else { temp__1927000414__auto____2 = linked_130.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_129, arg_132) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__278000019__3 any = temp__1927000414__auto____2; var tmp1 any; var root_133 any = A_arbace_go_generic_A_const_42.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = s__278000019__3; if linked_134 == nil { tmp1 = ifn_135.Invoke_O__O(arg_136) } else { tmp1 = linked_134.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_133, arg_136) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_137 any = A_arbace_go_generic_A_const_43.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = s__278000019__3; if linked_138 == nil { c__1927001037__auto____4 = ifn_139.Invoke_O__O(arg_140) } else { c__1927001037__auto____4 = linked_138.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_137, arg_140) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__278000021__6 any; var root_141 any = A_arbace_go_generic_A_const_44.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_142 == nil { b__278000021__6 = ifn_143.Invoke_O__O(arg_144) } else { b__278000021__6 = linked_142.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_141, arg_144) }; var tmp2 any = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_New_O_I_O(b__278000021__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_fn_class = fncls__150d; tmp3 = fncls__150d } else { tmp3 = fncls__150 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_151 any = A_arbace_go_generic_A_const_47.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any; var root_156 any = A_arbace_go_generic_A_const_48.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = b__278000021__6; if linked_157 == nil { arg_154 = ifn_158.Invoke_O__O(arg_159) } else { arg_154 = linked_157.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_156, arg_159) }; var arg_155 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__278000018); var tmp5 any; var root_160 any = A_arbace_go_generic_A_const_49.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = s__278000019__3; if linked_161 == nil { tmp5 = ifn_162.Invoke_O__O(arg_163) } else { tmp5 = linked_161.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_160, arg_163) }; arg_155 = tmp4.Invoke_O__O(tmp5); if linked_152 == nil { return ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { return linked_152.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) } } else { var root_164 any = A_arbace_go_generic_A_const_47.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any; var root_169 any = A_arbace_go_generic_A_const_48.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = b__278000021__6; if linked_170 == nil { arg_167 = ifn_171.Invoke_O__O(arg_172) } else { arg_167 = linked_170.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_169, arg_172) }; var arg_168 any; if linked_165 == nil { return ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { return linked_165.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) } } } else { var er__4 any; var root_173 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = s__278000019__3; if linked_174 == nil { er__4 = ifn_175.Invoke_O__O(arg_176) } else { er__4 = linked_174.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_173, arg_176) }; var root_177 any = A_arbace_go_generic_A_const_51.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_generic_A_const_46.Invoke_O__O(er__4))).Ref(); var arg_181 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__278000018); var tmp7 any; var root_182 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = s__278000019__3; if linked_183 == nil { tmp7 = ifn_184.Invoke_O__O(arg_185) } else { tmp7 = linked_183.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_182, arg_185) }; arg_181 = tmp6.Invoke_O__O(tmp7); if linked_178 == nil { return ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { return linked_178.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :46:1
func A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A) Ctor_O_I_O(c__b__278000021 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__278000021 = c__b__278000021; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A) Invoke_O__O(self any) any { { var i__278000020__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__278000020__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var er__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__278000020__1)); var root_145 any = A_arbace_go_generic_A_const_45.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = t.F_b__278000021; var arg_149 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_generic_A_const_46.Invoke_O__O(er__2))).Ref(); if linked_146 == nil { ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { linked_146.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }; i__278000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__278000020__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_New() *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A) Ctor() {}
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A) Invoke_O_O__O(self, s__278000029__1 any) any { var tmp1 any = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_New_O_O(self, s__278000029__1); var tmp2 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_fn_class = fncls__266d; tmp2 = fncls__266d } else { tmp2 = fncls__266 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :47:1
func A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_New_O_O(p0, p1 any) *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A{}; t.Ctor_O_O(p0, p1); return t }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A) Ctor_O_O(c__iter__278000028, c__s__278000029 any) { t.F_iter__278000028 = c__iter__278000028; t.F_s__278000029 = c__s__278000029 }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A) Invoke_O__O(self any) any { { var s__278000029__1 any; var t_ any = t.F_s__278000029; t.F_s__278000029 = nil; s__278000029__1 = t_; for { var temp__1927000414__auto____2 any; var root_197 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = s__278000029__1; if linked_198 == nil { temp__1927000414__auto____2 = ifn_199.Invoke_O__O(arg_200) } else { temp__1927000414__auto____2 = linked_198.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_197, arg_200) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__278000029__3 any = temp__1927000414__auto____2; var tmp1 any; var root_201 any = A_arbace_go_generic_A_const_42.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = s__278000029__3; if linked_202 == nil { tmp1 = ifn_203.Invoke_O__O(arg_204) } else { tmp1 = linked_202.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_201, arg_204) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_205 any = A_arbace_go_generic_A_const_43.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = s__278000029__3; if linked_206 == nil { c__1927001037__auto____4 = ifn_207.Invoke_O__O(arg_208) } else { c__1927001037__auto____4 = linked_206.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_205, arg_208) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__278000031__6 any; var root_209 any = A_arbace_go_generic_A_const_44.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_210 == nil { b__278000031__6 = ifn_211.Invoke_O__O(arg_212) } else { b__278000031__6 = linked_210.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_209, arg_212) }; var tmp2 any = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_New_O_I_O(b__278000031__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__224 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_fn_class; if fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_fn_class = fncls__224d; tmp3 = fncls__224d } else { tmp3 = fncls__224 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_225 any = A_arbace_go_generic_A_const_47.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any; var root_230 any = A_arbace_go_generic_A_const_48.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = b__278000031__6; if linked_231 == nil { arg_228 = ifn_232.Invoke_O__O(arg_233) } else { arg_228 = linked_231.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_230, arg_233) }; var arg_229 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__278000028); var tmp5 any; var root_234 any = A_arbace_go_generic_A_const_49.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = s__278000029__3; if linked_235 == nil { tmp5 = ifn_236.Invoke_O__O(arg_237) } else { tmp5 = linked_235.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_234, arg_237) }; arg_229 = tmp4.Invoke_O__O(tmp5); if linked_226 == nil { return ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { return linked_226.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) } } else { var root_238 any = A_arbace_go_generic_A_const_47.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var root_243 any = A_arbace_go_generic_A_const_48.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = b__278000031__6; if linked_244 == nil { arg_241 = ifn_245.Invoke_O__O(arg_246) } else { arg_241 = linked_244.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_243, arg_246) }; var arg_242 any; if linked_239 == nil { return ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { return linked_239.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_238, arg_241, arg_242) } } } else { var er__4 any; var root_247 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = s__278000029__3; if linked_248 == nil { er__4 = ifn_249.Invoke_O__O(arg_250) } else { er__4 = linked_248.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_247, arg_250) }; var root_251 any = A_arbace_go_generic_A_const_51.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any; var root_256 any = A_arbace_go_generic_A_const_57.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = er__4; var arg_260 any = A_arbace_go_generic_A_const_58; var arg_261 any = Lit_12; if linked_257 == nil { arg_254 = ifn_258.Invoke_O_O_O__O(arg_259, arg_260, arg_261) } else { arg_254 = linked_257.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_256, arg_259, arg_260, arg_261) }; var arg_255 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__278000028); var tmp7 any; var root_262 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = s__278000029__3; if linked_263 == nil { tmp7 = ifn_264.Invoke_O__O(arg_265) } else { tmp7 = linked_263.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_262, arg_265) }; arg_255 = tmp6.Invoke_O__O(tmp7); if linked_252 == nil { return ifn_253.Invoke_O_O__O(arg_254, arg_255) } else { return linked_252.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_251, arg_254, arg_255) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :47:1
func A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A) Ctor_O_I_O(c__b__278000031 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__278000031 = c__b__278000031; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A) Invoke_O__O(self any) any { { var i__278000030__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__278000030__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var er__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__278000030__1)); var root_213 any = A_arbace_go_generic_A_const_45.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = t.F_b__278000031; var arg_217 any; var root_218 any = A_arbace_go_generic_A_const_57.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = er__2; var arg_222 any = A_arbace_go_generic_A_const_58; var arg_223 any = Lit_12; if linked_219 == nil { arg_217 = ifn_220.Invoke_O_O_O__O(arg_221, arg_222, arg_223) } else { arg_217 = linked_219.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_218, arg_221, arg_222, arg_223) }; if linked_214 == nil { ifn_215.Invoke_O_O__O(arg_216, arg_217) } else { linked_214.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_213, arg_216, arg_217) }; i__278000030__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__278000030__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_generic_error_BANG__A_New() *A_arbace_go_generic_error_BANG__A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_error_BANG__A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_go_generic_error_BANG__A) Ctor() {}
//line :49:1
func (t *A_arbace_go_generic_error_BANG__A) Invoke_O_O__O(self, msg__0 any) any {


	var root_268 any = A_arbace_go_generic_A_const_59.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = Lit_12; var arg_272 any; var arg_273 any = A_arbace_go_generic_A_const_60; var arg_274 any = msg__0; if linked_269 == nil { return ifn_270.Invoke_O_O_O_O__O(arg_271, arg_272, arg_273, arg_274) } else { return linked_269.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_268, arg_271, arg_272, arg_273, arg_274)
	}
}

func A_arbace_go_generic_rehome_A_New() *A_arbace_go_generic_rehome_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_rehome_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_generic_rehome_A) Ctor() {}
//line :56:1
func (t *A_arbace_go_generic_rehome_A) Invoke_O_O_O__O(self, ty__0, env__1 any) any { var r__3 any; var tmp1 any = A_arbace_go_generic_rehome_r__278000042_A_New_O(env__1); var tmp2 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_go_generic_rehome_r__278000042_A_fn_class; if



	fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_generic_rehome_r__278000042_A_fn_class = fncls__280d; tmp2 = fncls__280d } else { tmp2 = fncls__280 }; r__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any; var root_281 any =
	A_arbace_go_generic_A_const_62.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_283 lang.IFn; if
	linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = ty__0; if linked_282 == nil { tmp3 = ifn_283.Invoke_O__O(arg_284) } else { tmp3 = linked_282.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_281, arg_284) }; if /*line :61:1*/ jrt.J2g_Truth(tmp3) { return ty__0 } else { var tmp4 any; var root_285 any = A_arbace_go_generic_A_const_63.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_287 lang.IFn

		if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = ty__0; if linked_286 == nil { tmp4 = ifn_287.Invoke_O__O(arg_288) } else { tmp4 = linked_286.(*aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_285, arg_288) }
//line :61:1
		if jrt.J2g_Truth(tmp4) { var i__4 any; var root_289 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_291 lang.IFn


			if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = ty__0; if linked_290 == nil { i__4 = ifn_291.Invoke_O__O(arg_292) } else { i__4 = linked_290.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_289, arg_292) }
			var tmp5 any; var root_293 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_295 lang.IFn
			if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = A_arbace_go_generic_A_const_65.Invoke_O__O(i__4); if linked_294 == nil { tmp5 = ifn_295.Invoke_O__O(arg_296) } else { tmp5 = linked_294.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_293, arg_296) }
//line :65:1
			if jrt.J2g_Truth(tmp5) { var o__5 any = lang.IFn_Cast(r__3).Invoke_O__O(A_arbace_go_generic_A_const_67.Invoke_O__O(i__4)); var ts__6 any; var root_297 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_299 lang.IFn

				if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = r__3; var arg_301 any = A_arbace_go_generic_A_const_65.Invoke_O__O(i__4); if linked_298 == nil { ts__6 = ifn_299.Invoke_O_O__O(arg_300, arg_301) } else { ts__6 = linked_298.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_297, arg_300, arg_301) }
				var tmp6 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(o__5, A_arbace_go_generic_A_const_67.Invoke_O__O(i__4)); if and__1927000168__auto____7 { tmp6 = lang.Util_Equiv_O_O__Z_NoInit(ts__6, A_arbace_go_generic_A_const_65.Invoke_O__O(i__4)) } else { tmp6 = and__1927000168__auto____7 }; if tmp6 { return ty__0 } else { var root_302 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var arg_306 any = o__5; var arg_307 any = ts__6; if linked_303 == nil { return ifn_304.Invoke_O_O_O__O(arg_305, arg_306, arg_307) } else { return linked_303.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A).Invoke_O_O_O_O__O(root_302, arg_305, arg_306, arg_307) } } } else {
//line :65:1
					var tmp7 any; var or__1927000174__auto____5 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_generic_A_const_69.Invoke_O__O(i__4), nil)



					if or__1927000174__auto____5 { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { tmp7 = A_arbace_go_generic_A_const_70.Invoke_O__O(i__4) }
//line :65:1
					if jrt.J2g_Truth(tmp7) { return ty__0 } else { if A_arbace_go_generic_A_const_71 != nil { var or__1927000174__auto____5_2 any = lang.IFn_Cast(A_arbace_go_generic_A_const_72.Invoke_O__O(env__1)).Invoke_O_O__O(A_arbace_go_generic_A_const_69.Invoke_O__O(i__4), A_arbace_go_generic_A_const_78.Invoke_O__O(i__4))




						if jrt.J2g_Truth(or__1927000174__auto____5_2) { return or__1927000174__auto____5_2 } else { return ty__0 } } else {
//line :65:1
							return nil } } } } else {
//line :61:1
								var tmp8 any; var root_308 any = A_arbace_go_generic_A_const_73.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_go_check_types.A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_310 lang.IFn









								if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = ty__0; if linked_309 == nil { tmp8 = ifn_310.Invoke_O__O(arg_311) } else { tmp8 = linked_309.(*aot_arbace_go_check_types.A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_308, arg_311) }
//line :61:1
								if jrt.J2g_Truth(tmp8) { return ty__0 } else { if A_arbace_go_generic_A_const_71 != nil { var G__278000044__4_ any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(0))











									switch lang.Util_Hash_O__I_NoInit(G__278000044__4_) >> 2 & 15 { case 1: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_74) { var tmp9 any = A_arbace_go_generic_A_const_74; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1))), lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)))) }; case 2: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_75) { var tmp10 any = A_arbace_go_generic_A_const_75; return lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)))) }; case 3: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_76) { var tmp11 any = A_arbace_go_generic_A_const_76; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)), lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)))) }; case 6: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_77) { var tmp12 any = A_arbace_go_generic_A_const_77; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp12, lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)), lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)))) }; case 7: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_79) {







										var root_313 any = A_arbace_go_generic_A_const_80.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = A_arbace_go_generic_A_const_81; var arg_317 any; var root_318 any = A_arbace_go_generic_A_const_82.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = r__3; var arg_322 any; var root_323 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = ty__0; if linked_324 == nil { arg_322 = ifn_325.Invoke_O__O(arg_326) } else { arg_322 = linked_324.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_323, arg_326) }; if linked_319 == nil { arg_317 = ifn_320.Invoke_O_O__O(arg_321, arg_322) } else { arg_317 = linked_319.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_318, arg_321, arg_322) }; if linked_314 == nil { return ifn_315.Invoke_O_O__O(arg_316, arg_317) } else { return linked_314.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_313, arg_316, arg_317) } }
//line :73:1
									case 9: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_83) { var tmp13 any = A_arbace_go_generic_A_const_83; var tmp14 any; var root_327 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_329 lang.IFn





										if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = r__3; var arg_331 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_328 == nil { tmp14 = ifn_329.Invoke_O_O__O(arg_330, arg_331) } else { tmp14 = linked_328.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_327, arg_330, arg_331) }
//line :73:1
										var tmp15 any = tmp14; var tmp16 any; var root_332 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_334 lang.IFn





										if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = r__3; var arg_336 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_333 == nil { tmp16 = ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { tmp16 = linked_333.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_332, arg_335, arg_336) }
//line :73:1
										return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp13, tmp15, tmp16, lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 11: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_84) { var tmp17 any = A_arbace_go_generic_A_const_84; return lang.Tuple_Create_O_O__IPersistentVector(tmp17, lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)))) }; case 13: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_85) { var tmp18 any = A_arbace_go_generic_A_const_85; var tmp19 any; var root_337 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_339 lang.IFn






											if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any; var tmp20 any = A_arbace_go_generic_rehome_fn__278000045_A_New_O(r__3); var tmp21 *jrt.Class; var fncls__348 *jrt.Class = A_arbace_go_generic_rehome_fn__278000045_A_fn_class; if fncls__348 == nil { var fncls__348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_go_generic_rehome_fn__278000045_A_fn_class = fncls__348d; tmp21 = fncls__348d } else { tmp21 = fncls__348 }; arg_340 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var arg_341 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_338 == nil { tmp19 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { tmp19 = linked_338.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }
//line :73:1
											return lang.Tuple_Create_O_O__IPersistentVector(tmp18, tmp19) }; default:}; return ty__0 } else {
//line :61:1
												return nil } } } } }
//line :60:1
func A_arbace_go_generic_rehome_r__278000042_A_New_O(p0 any) *A_arbace_go_generic_rehome_r__278000042_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_rehome_r__278000042_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_go_generic_rehome_r__278000042_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :60:1
func (t *A_arbace_go_generic_rehome_r__278000042_A) Invoke_O_O__O(self, p1__278000040_SHARP___1 any) any { var root_275 any = A_arbace_go_generic_A_const_61.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, A_arbace_go_generic_rehome_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = p1__278000040_SHARP___1; var arg_279 any = t.F_env; if linked_276 == nil { return ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { return linked_276.(*A_arbace_go_generic_rehome_A).Invoke_O_O_O__O(root_275, arg_278, arg_279) } }



















func A_arbace_go_generic_rehome_fn__278000045_A_New_O(p0 any) *A_arbace_go_generic_rehome_fn__278000045_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_rehome_fn__278000045_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_go_generic_rehome_fn__278000045_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :80:1
func (t *A_arbace_go_generic_rehome_fn__278000045_A) Invoke_O_O__O(self, p1__278000041_SHARP___1 any) any { var root_342 any = A_arbace_go_generic_A_const_86.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = p1__278000041_SHARP___1; var arg_346 any = A_arbace_go_generic_A_const_87; var arg_347 any = t.F_r; if linked_343 == nil { return ifn_344.Invoke_O_O_O__O(arg_345, arg_346, arg_347) } else { return linked_343.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_342, arg_345, arg_346, arg_347) } }







func A_arbace_go_generic_desc__GT_type_A_New() *A_arbace_go_generic_desc__GT_type_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_desc__GT_type_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_go_generic_desc__GT_type_A) Ctor() {}
//line :88:1
func (t *A_arbace_go_generic_desc__GT_type_A) Invoke_O_O_O__O(self, d__0, env__1 any) any { var vec__278000049__3 any; var root_349 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_351 lang.IFn; if


	linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = lang.GoInterp_TypeInfo_O__O1(d__0).Ref(); if linked_350 == nil { vec__278000049__3 = ifn_351.Invoke_O__O(arg_352) } else { vec__278000049__3 = linked_350.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_349, arg_352) }; var kind__4 any = /*line :88:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(0), nil); var named__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(1), nil); var nm__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(2), nil); var pkg__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(3), nil); var elem__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(4), nil); var key__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(5), nil); var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(6), nil); var ins__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(7), nil); var outs__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(8), nil); var variadic__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(9), nil); var dir__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(10), nil); var fnames__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(11), nil); var ftypes__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(12), nil); var femb__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(13), nil); var fpkgs__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(14), nil); var nmeth__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(15), nil); var sub__20 any; var tmp1 any = A_arbace_go_generic_desc__GT_type_sub__278000052_A_New_O(env__1); var tmp2 *jrt.Class; var fncls__358 *jrt.Class = A_arbace_go_generic_desc__GT_type_sub__278000052_A_fn_class; if


	fncls__358 == nil { var fncls__358d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_go_generic_desc__GT_type_sub__278000052_A_fn_class = fncls__358d; tmp2 = fncls__358d } else { tmp2 = fncls__358 }; sub__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var unknown__21 any; var tmp3 any = /*line :88:1*/A_arbace_go_generic_desc__GT_type_unknown__278000054_A_New_O(d__0); var tmp4 *jrt.Class; var fncls__364 *jrt.Class = A_arbace_go_generic_desc__GT_type_unknown__278000054_A_fn_class; if




	fncls__364 == nil { var fncls__364d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_go_generic_desc__GT_type_unknown__278000054_A_fn_class = fncls__364d; tmp4 = fncls__364d } else { tmp4 = fncls__364 }; unknown__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var G__278000056__22_ any = named__5; switch


	lang.Util_Hash_O__I_NoInit(G__278000056__22_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__278000056__22_, Lit_15) { var temp__1927000408__auto____23 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_generic_A_const_90.GetRawRoot__O())).Get_O__O(d__0)
		if jrt.J2g_Truth(temp__1927000408__auto____23) { var ty__24 any = temp__1927000408__auto____23; var root_366 any = A_arbace_go_generic_A_const_61.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, A_arbace_go_generic_rehome_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = ty__24; var arg_370 any = env__1; if linked_367 == nil { return ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { return linked_367.(*A_arbace_go_generic_rehome_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) } } else { return lang.IFn_Cast(unknown__21).Invoke__O() } }
//line :96:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__278000056__22_, Lit_16) { var or__1927000174__auto____23 any = lang.IFn_Cast(A_arbace_go_generic_A_const_72.Invoke_O__O(env__1)).Invoke_O_O__O(pkg__7, nm__6)

		if jrt.J2g_Truth(or__1927000174__auto____23) { return or__1927000174__auto____23 } else { return lang.IFn_Cast(unknown__21).Invoke__O() } }
//line :96:1
	default:}; var tmp5 any; var root_371 any =


	A_arbace_go_generic_A_const_91.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_373 lang.IFn; if
	linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = A_arbace_go_generic_A_const_92.GetRawRoot__O(); var arg_375 any = kind__4; if linked_372 == nil { tmp5 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { tmp5 = linked_372.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }; if /*line :99:1*/ jrt.J2g_Truth(tmp5) {
		var root_376 any = A_arbace_go_generic_A_const_93.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = kind__4; if linked_377 == nil { return ifn_378.Invoke_O__O(arg_379) } else { return linked_377.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_376, arg_379) } } else {
//line :99:1
			if lang.Util_Equiv_O_O__Z_NoInit(Lit_17, kind__4) { return A_arbace_go_generic_A_const_94 } else { if A_arbace_go_generic_A_const_71 != nil { var G__278000057__23_ any = kind__4



				switch lang.Util_Hash_O__I_NoInit(G__278000057__23_) >> 12 & 15 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_18) { var tmp6 any = A_arbace_go_generic_A_const_83; var tmp7 any; var root_381 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_383 lang.IFn





					if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = sub__20; var arg_385 any = ins__11; if linked_382 == nil { tmp7 = ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { tmp7 = linked_382.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_381, arg_384, arg_385) }
//line :103:1
					var tmp8 any = tmp7; var tmp9 any; var root_386 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_388 lang.IFn





					if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = sub__20; var arg_390 any = outs__12; if linked_387 == nil { tmp9 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { tmp9 = linked_387.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }
//line :103:1
					return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp6, tmp8, tmp9, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(variadic__13)).Ref()) }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_19) { var tmp10 any = A_arbace_go_generic_A_const_75; return lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_20) {











						if lang.Util_Equiv_O_O__Z_NoInit(Lit_21, nm__6) { return A_arbace_go_generic_A_const_95.GetRawRoot__O() } else { if lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(nmeth__19)) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_generic_A_const_96, lang.PersistentVector_EMPTY.Ref(), nil) } else { if A_arbace_go_generic_A_const_71 != nil {

							return lang.IFn_Cast(unknown__21).Invoke__O() } else {
//line :115:1
								return nil } } } }
//line :103:1
				case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_22) { var tmp11 any = A_arbace_go_generic_A_const_76; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(n__10)).Ref(), lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_23) { var tmp12 any = A_arbace_go_generic_A_const_85; var tmp13 any; var root_391 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_393 lang.IFn






					if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_82.GetRawRoot__O()); var tmp15 any = A_arbace_go_generic_desc__GT_type_fn__278000058_A_New_O(sub__20); var tmp16 *jrt.Class; var fncls__419 *jrt.Class = A_arbace_go_generic_desc__GT_type_fn__278000058_A_fn_class; if fncls__419 == nil { var fncls__419d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_go_generic_desc__GT_type_fn__278000058_A_fn_class = fncls__419d; tmp16 = fncls__419d } else { tmp16 = fncls__419 }; arg_394 = tmp14.Invoke_O_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), fnames__15, ftypes__16, femb__17, fpkgs__18); if linked_392 == nil { tmp13 = ifn_393.Invoke_O__O(arg_394) } else { tmp13 = linked_392.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_391, arg_394) }
//line :103:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13) }; case 9: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_25) { var tmp17 any = A_arbace_go_generic_A_const_77; var tmp18 *lang.Keyword; var G__278000061__24_ int64 = lang.RT_LongCast_O__J_NoInit(dir__14)




					L3: switch { default: switch int32(G__278000061__24_) { case 1: if 1 == G__278000061__24_ { tmp18 = A_arbace_go_generic_A_const_98; break L3 }; case 2: if 2 == G__278000061__24_ { tmp18 = A_arbace_go_generic_A_const_99; break L3 }; default:}; tmp18 = A_arbace_go_generic_A_const_100}
//line :103:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp17, tmp18.Ref(), lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; case 10: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_26) { var tmp19 any = A_arbace_go_generic_A_const_74; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp19, lang.IFn_Cast(sub__20).Invoke_O__O(key__9), lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_27) { var tmp20 any = A_arbace_go_generic_A_const_84; return lang.Tuple_Create_O_O__IPersistentVector(tmp20, lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; default:
				}













				return lang.IFn_Cast(unknown__21).Invoke__O() } else {
//line :99:1
					return nil } } } }
//line :91:1
func A_arbace_go_generic_desc__GT_type_sub__278000052_A_New_O(p0 any) *A_arbace_go_generic_desc__GT_type_sub__278000052_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_desc__GT_type_sub__278000052_A{}; t.Ctor_O(p0); return t }
//line :91:1
func (t *A_arbace_go_generic_desc__GT_type_sub__278000052_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :91:1
func (t *A_arbace_go_generic_desc__GT_type_sub__278000052_A) Invoke_O_O__O(self, p1__278000048_SHARP___1 any) any {
	var root_353 any = A_arbace_go_generic_A_const_88.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, A_arbace_go_generic_desc__GT_type_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = p1__278000048_SHARP___1; var arg_357 any = t.F_env; if linked_354 == nil { return ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { return linked_354.(*A_arbace_go_generic_desc__GT_type_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } }
func A_arbace_go_generic_desc__GT_type_unknown__278000054_A_New_O(p0 any) *A_arbace_go_generic_desc__GT_type_unknown__278000054_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_desc__GT_type_unknown__278000054_A{}; t.Ctor_O(p0); return t }
//line :93:1
func (t *A_arbace_go_generic_desc__GT_type_unknown__278000054_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :93:1
func (t *A_arbace_go_generic_desc__GT_type_unknown__278000054_A) Invoke_O__O(self any) any { var tmp1 any; var root_359 any = A_arbace_go_generic_A_const_40.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, lang.GoInterp_TypeName_O__String(t.F_d).Ref(), nil)).Ref(); var arg_363 any = A_arbace_go_generic_A_const_89; if linked_360 == nil { tmp1 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp1 = linked_360.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }
















func A_arbace_go_generic_desc__GT_type_fn__278000058_A_New_O(p0 any) *A_arbace_go_generic_desc__GT_type_fn__278000058_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_desc__GT_type_fn__278000058_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_go_generic_desc__GT_type_fn__278000058_A) Ctor_O(c__sub any) { t.F_sub = c__sub }
//line :110:1
func (t *A_arbace_go_generic_desc__GT_type_fn__278000058_A) Invoke_O_O_O_O_O__O(self, fnm__1, fty__2, emb__3, fp__4 any) any { var tmp1 any = A_arbace_go_generic_A_const_78; var tmp2 any = A_arbace_go_generic_A_const_87; var G__278000059__5_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, fnm__1, tmp2, lang.IFn_Cast(t.F_sub).Invoke_O__O(fty__2))); var G__278000059__6_ any; if
																jrt.J2g_Truth(emb__3) {
																	var root_403 any = A_arbace_go_generic_A_const_57.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = G__278000059__5_; var arg_407 any = A_arbace_go_generic_A_const_97; var arg_408 any = jrt.Boolean_TRUE.Ref(); if linked_404 == nil { G__278000059__6_ = ifn_405.Invoke_O_O_O__O(arg_406, arg_407, arg_408) } else { G__278000059__6_ = linked_404.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_403, arg_406, arg_407, arg_408) } } else {
//line :111:1
			G__278000059__6_ = G__278000059__5_ }; var tmp3 any; var root_409 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_411 lang.IFn; if

	linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = fp__4; if linked_410 == nil { tmp3 = ifn_411.Invoke_O__O(arg_412) } else { tmp3 = linked_410.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_409, arg_412) }; if /*line :111:1*/ jrt.J2g_Truth(tmp3) {

		var root_413 any = A_arbace_go_generic_A_const_57.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = G__278000059__6_; var arg_417 any = A_arbace_go_generic_A_const_69; var arg_418 any = fp__4; if linked_414 == nil { return ifn_415.Invoke_O_O_O__O(arg_416, arg_417, arg_418) } else { return linked_414.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_413, arg_416, arg_417, arg_418) } } else {
//line :111:1
			return G__278000059__6_ } }








func A_arbace_go_generic_arg_form_A_New() *A_arbace_go_generic_arg_form_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_arg_form_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_go_generic_arg_form_A) Ctor() {}
//line :120:1
func (t *A_arbace_go_generic_arg_form_A) Invoke_O_O_O_O__O(self, k__0, v__1, i__2 any) any { if jrt.Long_InstanceOf(i__2) { return t.InvokeSpec_O_O_O_J_O__O(self, k__0, v__1, jrt.NN(jrt.Long_Cast(i__2)).LongValue__J(), i__2) } else {


	var tmp1 any; var and__1927000168__auto____4 any; var root_421 any = A_arbace_go_generic_A_const_62.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = k__0; if linked_422 == nil { and__1927000168__auto____4 = ifn_423.Invoke_O__O(arg_424) } else { and__1927000168__auto____4 = linked_422.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_421, arg_424) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.IFn_Cast(A_arbace_go_generic_A_const_101).Invoke_O__O(k__0) } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return v__1 } else {

		var root_425 any = A_arbace_go_generic_A_const_102.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp3 jrt.Number_I; var na_429 any = i__2; if jrt.Long_InstanceOf(na_429) { var n0_430 int64 = jrt.NN(jrt.Long_Cast(na_429)).LongValue__J(); if n0_430 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_429) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_430 + 1)) } } else { if jrt.Double_InstanceOf(na_429) { var n0_430_2 float64 = jrt.NN(jrt.Double_Cast(na_429)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_430_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_429) } }; arg_428 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if linked_426 == nil { return ifn_427.Invoke_O__O(arg_428) } else { return linked_426.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_425, arg_428) } } } }
//line :120:1
func (t *A_arbace_go_generic_arg_form_A) InvokeSpec_O_O_O_J_O__O(self, k__0, v__1 any, i__2_l int64, i__2_b any) any {


	var tmp1 any; var and__1927000168__auto____4 any; var root_431 any = A_arbace_go_generic_A_const_62.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = k__0; if linked_432 == nil { and__1927000168__auto____4 = ifn_433.Invoke_O__O(arg_434) } else { and__1927000168__auto____4 = linked_432.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_431, arg_434) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.IFn_Cast(A_arbace_go_generic_A_const_101).Invoke_O__O(k__0) } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return v__1 } else {

		var root_435 any = A_arbace_go_generic_A_const_102.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp3 jrt.Number_I; var n0_439 int64 = i__2_l; if n0_439 == 9223372036854775807 { var tmp4 any; if i__2_b == nil { i__2_b = jrt.Long_ValueOf_J__Long_NoInit(i__2_l).Ref(); tmp4 = i__2_b } else { tmp4 = i__2_b }; tmp3 = lang.Numbers_Inc_O__Number_NoInit(tmp4) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_439 + 1)) }; arg_438 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if linked_436 == nil { return ifn_437.Invoke_O__O(arg_438) } else { return linked_436.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_435, arg_438)
		} } }
func A_arbace_go_generic_operand_A_New() *A_arbace_go_generic_operand_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_operand_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_go_generic_operand_A) Ctor() {}
//line :127:1
func (t *A_arbace_go_generic_operand_A) Invoke_O_O_O_O_O__O(self, k__0, v__1, i__2, env__3 any) any { var f__5 any; var root_440 any = A_arbace_go_generic_A_const_103.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_440, A_arbace_go_generic_arg_form_A_fn_class); var ifn_442 lang.IFn; if


	linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = k__0; var arg_444 any = v__1; var arg_445 any = i__2; if linked_441 == nil { f__5 = ifn_442.Invoke_O_O_O__O(arg_443, arg_444, arg_445) } else { if jrt.Long_InstanceOf(arg_445) { f__5 = linked_441.(*A_arbace_go_generic_arg_form_A).InvokeSpec_O_O_O_J_O__O(root_440, arg_443, arg_444, jrt.NN(jrt.Long_Cast(arg_445)).LongValue__J(), arg_445) } else { f__5 = linked_441.(*A_arbace_go_generic_arg_form_A).Invoke_O_O_O_O__O(root_440, arg_443, arg_444, arg_445) } }; var tmp1 any; var root_446 any =
	A_arbace_go_generic_A_const_62.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = k__0; if linked_447 == nil { tmp1 = ifn_448.Invoke_O__O(arg_449) } else { tmp1 = linked_447.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_446, arg_449) }; if jrt.J2g_Truth(tmp1) { var G__278000064__6_ any = k__0
		switch lang.Util_Hash_O__I_NoInit(G__278000064__6_) >> 12 & 15 { case 1: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_104) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_generic_A_const_87, A_arbace_go_generic_A_const_105, A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) }; case 2: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_109) { var tmp2 any = A_arbace_go_generic_A_const_87; var tmp3 any = A_arbace_go_generic_A_const_106; var tmp4 any = A_arbace_go_generic_A_const_110; var tmp5 any = A_arbace_go_generic_A_const_111; var tmp6 any; var tmp7 any; var root_451 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_453 lang.IFn

			if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = v__1; if linked_452 == nil { tmp7 = ifn_453.Invoke_O__O(arg_454) } else { tmp7 = linked_452.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_451, arg_454) }; if jrt.J2g_Truth(tmp7) { tmp6 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp6 = v__1 }
//line :132:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, k__0, tmp3, tmp4, tmp5, tmp6, A_arbace_go_generic_A_const_108, f__5)) }; case 4: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_113) { var tmp8 any = A_arbace_go_generic_A_const_87; var tmp9 any = A_arbace_go_generic_A_const_106; var tmp10 any = A_arbace_go_generic_A_const_110; var tmp11 any = A_arbace_go_generic_A_const_111; var tmp12 any; var tmp13 any; var root_455 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_457 lang.IFn

				if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = v__1; if linked_456 == nil { tmp13 = ifn_457.Invoke_O__O(arg_458) } else { tmp13 = linked_456.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_455, arg_458) }; if jrt.J2g_Truth(tmp13) { tmp12 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp12 = v__1 }
//line :132:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, k__0, tmp9, tmp10, tmp11, tmp12, A_arbace_go_generic_A_const_108, f__5)) }; case 6: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_114) { var tmp14 any = A_arbace_go_generic_A_const_87; var tmp15 any = A_arbace_go_generic_A_const_106; var tmp16 any = A_arbace_go_generic_A_const_110; var tmp17 any = A_arbace_go_generic_A_const_111; var tmp18 any; var tmp19 any; var root_459 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_461 lang.IFn

					if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = v__1; if linked_460 == nil { tmp19 = ifn_461.Invoke_O__O(arg_462) } else { tmp19 = linked_460.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_459, arg_462) }; if jrt.J2g_Truth(tmp19) { tmp18 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp18 = v__1 }
//line :132:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, k__0, tmp15, tmp16, tmp17, tmp18, A_arbace_go_generic_A_const_108, f__5)) }; case 7: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_115) { var tmp20 any = A_arbace_go_generic_A_const_87; var tmp21 any = A_arbace_go_generic_A_const_106; var tmp22 any = A_arbace_go_generic_A_const_110; var tmp23 any = A_arbace_go_generic_A_const_111; var tmp24 any; var tmp25 any; var root_468 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_470 lang.IFn

						if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = v__1; if linked_469 == nil { tmp25 = ifn_470.Invoke_O__O(arg_471) } else { tmp25 = linked_469.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_468, arg_471) }; if jrt.J2g_Truth(tmp25) { tmp24 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp24 = v__1 }
//line :132:1
						return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, k__0, tmp21, tmp22, tmp23, tmp24, A_arbace_go_generic_A_const_108, f__5)) }; case 9: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_116) { var tmp26 any = A_arbace_go_generic_A_const_87; var tmp27 any = A_arbace_go_generic_A_const_106; var tmp28 any = A_arbace_go_generic_A_const_110; var tmp29 any = A_arbace_go_generic_A_const_111; var tmp30 any; var tmp31 any; var root_472 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_474 lang.IFn

							if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = v__1; if linked_473 == nil { tmp31 = ifn_474.Invoke_O__O(arg_475) } else { tmp31 = linked_473.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_472, arg_475) }; if jrt.J2g_Truth(tmp31) { tmp30 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp30 = v__1 }
//line :132:1
							return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp26, k__0, tmp27, tmp28, tmp29, tmp30, A_arbace_go_generic_A_const_108, f__5)) }; case 10: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_117) { var tmp32 any = A_arbace_go_generic_A_const_87; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp32, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_generic_A_const_96, lang.PersistentVector_EMPTY.Ref(), nil), A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) }; case 11: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_105) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_generic_A_const_87, A_arbace_go_generic_A_const_105, A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) }; case 12: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_118) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_generic_A_const_87, A_arbace_go_generic_A_const_105, A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__278000064__6_))))) } else {
//line :131:1
								var tmp33 any = A_arbace_go_generic_A_const_87; var tmp34 any; var root_463 any = A_arbace_go_generic_A_const_88.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, A_arbace_go_generic_desc__GT_type_A_fn_class); var ifn_465 lang.IFn






								if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = k__0; var arg_467 any = env__3; if linked_464 == nil { tmp34 = ifn_465.Invoke_O_O__O(arg_466, arg_467) } else { tmp34 = linked_464.(*A_arbace_go_generic_desc__GT_type_A).Invoke_O_O_O__O(root_463, arg_466, arg_467) }
//line :131:1
								return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34, A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) } }










func A_arbace_go_generic_tparams_of_A_New() *A_arbace_go_generic_tparams_of_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_tparams_of_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_go_generic_tparams_of_A) Ctor() {}
//line :142:1
func (t *A_arbace_go_generic_tparams_of_A) Invoke_O_O__O(self, x__0 any) any { var root_476 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var root_480 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any; var root_485 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = x__0; var arg_489 any = A_arbace_go_generic_A_const_120; if linked_486 == nil { arg_483 = ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { arg_483 = linked_486.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) }; var arg_484 any; var root_490 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = x__0; var arg_494 any = A_arbace_go_generic_A_const_121; if linked_491 == nil { arg_484 = ifn_492.Invoke_O_O__O(arg_493, arg_494) } else { arg_484 = linked_491.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_490, arg_493, arg_494) }; if linked_481 == nil { arg_479 = ifn_482.Invoke_O_O__O(arg_483, arg_484) } else { arg_479 = linked_481.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_480, arg_483, arg_484) }; if linked_477 == nil { return ifn_478.Invoke_O__O(arg_479) } else { return linked_477.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_476, arg_479) } }

func A_arbace_go_generic_callee_name_A_New() *A_arbace_go_generic_callee_name_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_callee_name_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_go_generic_callee_name_A) Ctor() {}
//line :144:1
func (t *A_arbace_go_generic_callee_name_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_495 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = x__0; var arg_499 any = A_arbace_go_generic_A_const_122; if linked_496 == nil { tmp1 = ifn_497.Invoke_O_O__O(arg_498, arg_499) } else { tmp1 = linked_496.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_495, arg_498, arg_499) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp3 *lang.Keyword = A_arbace_go_generic_A_const_78; var tmp4 any; var root_500 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any; var root_504 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = x__0; var arg_508 any = A_arbace_go_generic_A_const_123; if linked_505 == nil { arg_503 = ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { arg_503 = linked_505.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) }; if linked_501 == nil { tmp4 = ifn_502.Invoke_O__O(arg_503) } else { tmp4 = linked_501.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_500, arg_503) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 any; var root_509 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = x__0; var arg_513 any = A_arbace_go_generic_A_const_78; if linked_510 == nil { tmp6 = ifn_511.Invoke_O_O__O(arg_512, arg_513) } else { tmp6 = linked_510.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_509, arg_512, arg_513) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp5, nil, tmp6)).Ref() } else {
			var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp8 any; var or__1927000174__auto____5 any; var root_514 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = x__0; var arg_518 any = A_arbace_go_generic_A_const_124; if linked_515 == nil { or__1927000174__auto____5 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { or__1927000174__auto____5 = linked_515.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { var root_519 any = A_arbace_go_generic_A_const_125.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any; var root_523 any = A_arbace_go_generic_A_const_126.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var root_528 any = A_arbace_go_generic_A_const_127.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any; var root_532 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = x__0; var arg_536 any = A_arbace_go_generic_A_const_69; if linked_533 == nil { arg_531 = ifn_534.Invoke_O_O__O(arg_535, arg_536) } else { arg_531 = linked_533.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_532, arg_535, arg_536) }; if linked_529 == nil { arg_526 = ifn_530.Invoke_O__O(arg_531) } else { arg_526 = linked_529.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_528, arg_531) }; var arg_527 any = A_arbace_go_generic_A_const_128; if linked_524 == nil { arg_522 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { arg_522 = linked_524.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; if linked_520 == nil { tmp8 = ifn_521.Invoke_O__O(arg_522) } else { tmp8 = linked_520.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_519, arg_522) } }; var tmp9 any = tmp8; var tmp10 any; var root_537 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = x__0; var arg_541 any = A_arbace_go_generic_A_const_78; if linked_538 == nil { tmp10 = ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { tmp10 = linked_538.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_537, arg_540, arg_541) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)).Ref()
		} }
func A_arbace_go_generic_type_summary_A_New() *A_arbace_go_generic_type_summary_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_type_summary_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_generic_type_summary_A) Ctor() {}
//line :151:1
func (t *A_arbace_go_generic_type_summary_A) Invoke_O_O__O(self, ty__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_go_generic_A_const_129).Invoke_O__O(ty__0)) { return Lit_58 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_115, ty__0) { return Lit_59 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_109, ty__0) { return Lit_60 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_105, ty__0) { return Lit_61 } else { if A_arbace_go_generic_A_const_71 != nil {




		var root_542 any = A_arbace_go_generic_A_const_130.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = ty__0; if linked_543 == nil { return ifn_544.Invoke_O__O(arg_545) } else { return linked_543.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_542, arg_545) } } else {
//line :152:1
			return nil
		}
	}
	}
	}
	}
}
func A_arbace_go_generic_params_for_A_New() *A_arbace_go_generic_params_for_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_params_for_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_go_generic_params_for_A) Ctor() {}
//line :159:1
func (t *A_arbace_go_generic_params_for_A) Invoke_O_O_O_O__O(self, cname__0, p__278000070__1, ops__2 any) any { var vec__278000071__4 any = p__278000070__1; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000071__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000071__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000071__4, lang.RT_IntCast_J__I_NoInit(2), nil); var variadic__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000071__4, lang.RT_IntCast_J__I_NoInit(3), nil); var np__9 int32 = lang.RT_Count_O__I_NoInit(ps__6); var na__10 int32 = lang.RT_Count_O__I_NoInit(ops__2); var tmp1 any; var or__1927000174__auto____11 any; var and__1927000168__auto____11 any = variadic__8; _ = ___5; _ = ___7; if




	jrt.J2g_Truth(and__1927000168__auto____11) { or__1927000174__auto____11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gte_J_J__Z_NoInit(int64(na__10), lang.Numbers_Dec_J__J_NoInit(int64(np__9)))).Ref() } else { or__1927000174__auto____11 = and__1927000168__auto____11 }; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp1 = or__1927000174__auto____11 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(int64(na__10), int64(np__9))).Ref() }; if jrt.J2g_Truth(tmp1) {
		if jrt.J2g_Truth(variadic__8) {
			var root_546 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any; var root_550 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any; var root_555 any = A_arbace_go_generic_A_const_53.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(np__9))).Ref(); var arg_559 any = ps__6; if linked_556 == nil { arg_553 = ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { arg_553 = linked_556.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_555, arg_558, arg_559) }; var arg_554 any; var root_560 any = A_arbace_go_generic_A_const_131.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(na__10), lang.Numbers_Dec_J__J_NoInit(int64(np__9)))).Ref(); var arg_564 any; var tmp2 any; var root_565 any = A_arbace_go_generic_A_const_132.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = ps__6; if linked_566 == nil { tmp2 = ifn_567.Invoke_O__O(arg_568) } else { tmp2 = linked_566.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_565, arg_568) }; arg_564 = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(1)); if linked_561 == nil { arg_554 = ifn_562.Invoke_O_O__O(arg_563, arg_564) } else { arg_554 = linked_561.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_560, arg_563, arg_564) }; if linked_551 == nil { arg_549 = ifn_552.Invoke_O_O__O(arg_553, arg_554) } else { arg_549 = linked_551.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_550, arg_553, arg_554) }; if linked_547 == nil { return ifn_548.Invoke_O__O(arg_549) } else { return linked_547.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_546, arg_549) } } else {
				var root_569 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = ps__6; if linked_570 == nil { return ifn_571.Invoke_O__O(arg_572) } else { return linked_570.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_569, arg_572) } } } else {
					var root_573 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_134.GetRawRoot__O()); var tmp4 *jrt.String
					if lang.Numbers_Lt_J_J__Z_NoInit(int64(na__10), int64(np__9)) { tmp4 = Lit_45 } else { tmp4 = Lit_46 }
//line :168:1
					var tmp5 any = tmp4.Ref(); var tmp6 any; var root_585 any = A_arbace_go_generic_A_const_41.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_587 lang.IFn

					if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = Lit_36; var arg_589 any; var root_590 any = A_arbace_go_generic_A_const_82.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any; var tmp7 any = A_arbace_go_generic_params_for_fn__278000074_A_New(); var tmp8 *jrt.Class; var fncls__599 *jrt.Class = A_arbace_go_generic_params_for_fn__278000074_A_fn_class; if fncls__599 == nil { var fncls__599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_go_generic_params_for_fn__278000074_A_fn_class = fncls__599d; tmp8 = fncls__599d } else { tmp8 = fncls__599 }; arg_593 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_594 any = ops__2; if linked_591 == nil { arg_589 = ifn_592.Invoke_O_O__O(arg_593, arg_594) } else { arg_589 = linked_591.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_590, arg_593, arg_594) }; if linked_586 == nil { tmp6 = ifn_587.Invoke_O_O__O(arg_588, arg_589) } else { tmp6 = linked_586.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_585, arg_588, arg_589) }
//line :168:1
					var tmp9 any = tmp6; var tmp10 any; var root_600 any = A_arbace_go_generic_A_const_41.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_602 lang.IFn


					if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = Lit_36; var arg_604 any; var root_605 any = A_arbace_go_generic_A_const_136.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any; var tmp11 any = A_arbace_go_generic_params_for_fn__278000076_A_New_O_I(variadic__8, np__9); var tmp12 *jrt.Class; var fncls__618 *jrt.Class = A_arbace_go_generic_params_for_fn__278000076_A_fn_class; if fncls__618 == nil { var fncls__618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_generic_params_for_fn__278000076_A_fn_class = fncls__618d; tmp12 = fncls__618d } else { tmp12 = fncls__618 }; arg_608 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_609 any = ps__6; if linked_606 == nil { arg_604 = ifn_607.Invoke_O_O__O(arg_608, arg_609) } else { arg_604 = linked_606.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_605, arg_608, arg_609) }; if linked_601 == nil { tmp10 = ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { tmp10 = linked_601.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_600, arg_603, arg_604) }
//line :168:1
					arg_576 = tmp3.Invoke_O_O_O_O_O__O(Lit_44, tmp5, cname__0, tmp9, tmp10); if linked_574 == nil { ifn_575.Invoke_O__O(arg_576) } else { linked_574.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_573, arg_576) }
//line :164:1
					return nil } }





func A_arbace_go_generic_params_for_fn__278000074_A_New() *A_arbace_go_generic_params_for_fn__278000074_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_params_for_fn__278000074_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_go_generic_params_for_fn__278000074_A) Ctor() {}
//line :170:1
func (t *A_arbace_go_generic_params_for_fn__278000074_A) Invoke_O_O__O(self, p1__278000069_SHARP___1 any) any { var root_595 any = A_arbace_go_generic_A_const_135.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, A_arbace_go_generic_type_summary_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = A_arbace_go_generic_A_const_87.Invoke_O__O(p1__278000069_SHARP___1); if linked_596 == nil { return ifn_597.Invoke_O__O(arg_598) } else { return linked_596.(*A_arbace_go_generic_type_summary_A).Invoke_O_O__O(root_595, arg_598) } }
func A_arbace_go_generic_params_for_fn__278000076_A_New_O_I(p0 any, p1 int32) *A_arbace_go_generic_params_for_fn__278000076_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_params_for_fn__278000076_A{}; t.Ctor_O_I(p0, p1); return t }
//line :171:1
func (t *A_arbace_go_generic_params_for_fn__278000076_A) Ctor_O_I(c__variadic any, c__np int32) { t.F_variadic = c__variadic; t.F_np = c__np }
//line :171:1
func (t *A_arbace_go_generic_params_for_fn__278000076_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(t.F_np)))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_49, nil); var tmp3 any; var root_610 any = A_arbace_go_generic_A_const_130.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = lang.RT_Nth_O_I__O_NoInit(p__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_611 == nil { tmp3 = ifn_612.Invoke_O__O(arg_613) } else { tmp3 = linked_611.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_610, arg_613) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else { var root_614 any = A_arbace_go_generic_A_const_130.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = p__2; if linked_615 == nil { return ifn_616.Invoke_O__O(arg_617) } else { return linked_615.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_614, arg_617) } } }


func A_arbace_go_generic_infer_targs_A_New() *A_arbace_go_generic_infer_targs_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_infer_targs_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_go_generic_infer_targs_A) Ctor() {}
//line :174:1
func (t *A_arbace_go_generic_infer_targs_A) Invoke_O_O_O_O_O_O_O__O(self, cname__0, tps__1, known__2, params__3, ops__4, extra__5 any) any { var vec__278000079__7 any; var root_619 any = A_arbace_go_generic_A_const_137.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_go_check_code.A_arbace_go_check_code_rename_tparams_A_fn_class); var ifn_621 lang.IFn; if




	linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = tps__1; var arg_623 any; var root_624 any = A_arbace_go_generic_A_const_80.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = A_arbace_go_generic_A_const_138; var arg_628 any = params__3; if linked_625 == nil { arg_623 = ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { arg_623 = linked_625.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) }; if linked_620 == nil { vec__278000079__7 = ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { vec__278000079__7 = linked_620.(*aot_arbace_go_check_code.A_arbace_go_check_code_rename_tparams_A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }; var tps2__8 any = /*line :174:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__278000079__7, lang.RT_IntCast_J__I_NoInit(0), nil); var sp__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000079__7, lang.RT_IntCast_J__I_NoInit(1), nil); var targs__10 any; var root_629 any = A_arbace_go_generic_A_const_139.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_go_check_code.A_arbace_go_check_code_infer_A_fn_class); var ifn_631 lang.IFn; if





	linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = tps2__8; var arg_633 any; var root_638 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = known__2; if linked_639 == nil { arg_633 = ifn_640.Invoke_O__O(arg_641) } else { arg_633 = linked_639.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_638, arg_641) }; var arg_634 any; var root_642 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any; var root_646 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = sp__9; if linked_647 == nil { arg_645 = ifn_648.Invoke_O__O(arg_649) } else { arg_645 = linked_647.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_646, arg_649) }; if linked_643 == nil { arg_634 = ifn_644.Invoke_O__O(arg_645) } else { arg_634 = linked_643.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_642, arg_645) }; var arg_635 any = ops__4; var arg_636 any = jrt.Boolean_FALSE.Ref(); var arg_637 any; var tmp1 any = A_arbace_go_generic_infer_targs_fn__278000082_A_New_O(cname__0); var tmp2 *jrt.Class; var fncls__654 *jrt.Class = A_arbace_go_generic_infer_targs_fn__278000082_A_fn_class; if
	fncls__654 == nil { var fncls__654d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_generic_infer_targs_fn__278000082_A_fn_class = fncls__654d; tmp2 = fncls__654d } else { tmp2 = fncls__654 }; arg_637 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if /*line :180:1*/ linked_630 == nil { targs__10 = ifn_631.Invoke_O_O_O_O_O_O__O(arg_632, arg_633, arg_634, arg_635, arg_636, arg_637) } else { targs__10 = linked_630.(*aot_arbace_go_check_code.A_arbace_go_check_code_infer_A).Invoke_O_O_O_O_O_O_O__O(root_629, arg_632, arg_633, arg_634, arg_635, arg_636, arg_637) }; if

	jrt.J2g_Truth(targs__10) {
		var root_663 any = A_arbace_go_generic_A_const_141.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any; var arg_667 any = tps__1; var arg_668 any = targs__10; var arg_669 any = extra__5; if linked_664 == nil { ifn_665.Invoke_O_O_O_O__O(arg_666, arg_667, arg_668, arg_669) } else { linked_664.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A).Invoke_O_O_O_O_O__O(root_663, arg_666, arg_667, arg_668, arg_669) }
		var tmp3 any; var root_655 any = A_arbace_go_generic_A_const_140.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any; var root_659 any = A_arbace_go_generic_A_const_10.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = A_arbace_go_generic_A_const_39.Get__O(); if linked_660 == nil { arg_658 = ifn_661.Invoke_O__O(arg_662) } else { arg_658 = linked_660.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_659, arg_662) }; if linked_656 == nil { tmp3 = ifn_657.Invoke_O__O(arg_658) } else { tmp3 = linked_656.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_655, arg_658) }; if jrt.J2g_Truth(tmp3) { return targs__10 } else { return nil } } else {
//line :182:1
			return nil } }
//line :181:1
func A_arbace_go_generic_infer_targs_fn__278000082_A_New_O(p0 any) *A_arbace_go_generic_infer_targs_fn__278000082_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_infer_targs_fn__278000082_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_go_generic_infer_targs_fn__278000082_A) Ctor_O(c__cname any) { t.F_cname = c__cname }
//line :181:1
func (t *A_arbace_go_generic_infer_targs_fn__278000082_A) Invoke_O_O_O__O(self, ___1, msg__2 any) any { var root_650 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_35, nil, Lit_36, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_cname, nil, msg__2)).Ref(); if linked_651 == nil { return ifn_652.Invoke_O__O(arg_653) } else { return linked_651.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_650, arg_653) } }




func A_arbace_go_generic_instance_fn_A_New() *A_arbace_go_generic_instance_fn_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_instance_fn_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_go_generic_instance_fn_A) Ctor() {}
//line :186:1
func (t *A_arbace_go_generic_instance_fn_A) Invoke_O_O_O_O__O(self, x__0, targs__1, rt__2 any) any { var nm__4 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_37, nil, Lit_38); var tmp2 any; var root_670 any = A_arbace_go_generic_A_const_142.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, A_arbace_go_generic_callee_name_A_fn_class); var ifn_672 lang.IFn; if


	linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = x__0; if linked_671 == nil { tmp2 = ifn_672.Invoke_O__O(arg_673) } else { tmp2 = linked_671.(*A_arbace_go_generic_callee_name_A).Invoke_O_O__O(root_670, arg_673) }; var tmp3 any = tmp2; var tmp4 any; var root_674 any = A_arbace_go_generic_A_const_41.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = Lit_39; var arg_678 any; var root_679 any = A_arbace_go_generic_A_const_82.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = A_arbace_go_generic_A_const_143.GetRawRoot__O(); var arg_683 any = targs__1; if linked_680 == nil { arg_678 = ifn_681.Invoke_O_O__O(arg_682, arg_683) } else { arg_678 = linked_680.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_679, arg_682, arg_683) }; if linked_675 == nil { tmp4 = ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { tmp4 = linked_675.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) }; nm__4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref(); var vec__278000085__5 any; var root_684 any = /*line :186:1*/A_arbace_go_generic_A_const_144.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_go_build.A_arbace_go_build_instance_callable_A_fn_class); var ifn_686 lang.IFn; if



	linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = x__0; var arg_688 any = targs__1; var arg_689 any = rt__2; var arg_690 any = nm__4; if linked_685 == nil { vec__278000085__5 = ifn_686.Invoke_O_O_O_O__O(arg_687, arg_688, arg_689, arg_690) } else { vec__278000085__5 = linked_685.(*aot_arbace_go_build.A_arbace_go_build_instance_callable_A).Invoke_O_O_O_O_O__O(root_684, arg_687, arg_688, arg_689, arg_690) }; var c__6 any = /*line :186:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__278000085__5, lang.RT_IntCast_J__I_NoInit(0), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000085__5, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___7; return lang.GoFn_New_O_String(c__6, jrt.String_Cast(nm__4)) }






func A_arbace_go_generic_receiver_targs_A_New() *A_arbace_go_generic_receiver_targs_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_receiver_targs_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_go_generic_receiver_targs_A) Ctor() {}
//line :193:1
func (t *A_arbace_go_generic_receiver_targs_A) Invoke_O_O_O_O__O(self, x__0, cname__1, op__2 any) any { var g__4 any; var root_691 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_693 lang.IFn; if



	linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = x__0; var arg_695 any = A_arbace_go_generic_A_const_123; if linked_692 == nil { g__4 = ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { g__4 = linked_692.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }; var gi__5 any; var root_696 any = /*line :193:1*/A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_698 lang.IFn; if




	linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = g__4; if linked_697 == nil { gi__5 = ifn_698.Invoke_O__O(arg_699) } else { gi__5 = linked_697.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_696, arg_699) }; var vec__278000089__6 any; var root_700 any = /*line :193:1*/A_arbace_go_generic_A_const_145.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_go_check_types.A_arbace_go_check_types_deref_type_A_fn_class); var ifn_702 lang.IFn; if





	linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = A_arbace_go_generic_A_const_87.Invoke_O__O(op__2); if linked_701 == nil { vec__278000089__6 = ifn_702.Invoke_O__O(arg_703) } else { vec__278000089__6 = linked_701.(*aot_arbace_go_check_types.A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_700, arg_703) }; var ty__7 any = /*line :193:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__278000089__6, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var and__1927000168__auto____8 any; var root_704 any = A_arbace_go_generic_A_const_63.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_706 lang.IFn; if






	linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = ty__7; if linked_705 == nil { and__1927000168__auto____8 = ifn_706.Invoke_O__O(arg_707) } else { and__1927000168__auto____8 = linked_705.(*aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_704, arg_707) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_708 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any; var tmp2 *lang.Keyword = A_arbace_go_generic_A_const_65; var tmp3 any; var root_712 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = ty__7; if linked_713 == nil { tmp3 = ifn_714.Invoke_O__O(arg_715) } else { tmp3 = linked_713.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_712, arg_715) }; arg_711 = tmp2.Invoke_O__O(tmp3); if linked_709 == nil { and__1927000168__auto____9 = ifn_710.Invoke_O__O(arg_711) } else { and__1927000168__auto____9 = linked_709.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_708, arg_711) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var o__10 any; var root_716 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_718 lang.IFn
		if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any; var tmp4 *lang.Keyword = A_arbace_go_generic_A_const_67; var tmp5 any; var root_720 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = ty__7; if linked_721 == nil { tmp5 = ifn_722.Invoke_O__O(arg_723) } else { tmp5 = linked_721.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_720, arg_723) }; arg_719 = tmp4.Invoke_O__O(tmp5); if linked_717 == nil { o__10 = ifn_718.Invoke_O__O(arg_719) } else { o__10 = linked_717.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_716, arg_719) }
//line :200:1
		var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_69.Invoke_O__O(o__10), A_arbace_go_generic_A_const_69.Invoke_O__O(gi__5))
		if and__1927000168__auto____11 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_78.Invoke_O__O(o__10), A_arbace_go_generic_A_const_78.Invoke_O__O(gi__5))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else {
//line :200:1
			tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {

				var tmp6 *lang.Keyword = A_arbace_go_generic_A_const_65; var tmp7 any; var root_724 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = ty__7; if linked_725 == nil { tmp7 = ifn_726.Invoke_O__O(arg_727) } else { tmp7 = linked_725.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_724, arg_727) }; return tmp6.Invoke_O__O(tmp7) } else {
					var root_728 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_134.GetRawRoot__O()); var tmp9 any; var root_739 any = A_arbace_go_generic_A_const_135.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, A_arbace_go_generic_type_summary_A_fn_class); var ifn_741 lang.IFn
					if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = A_arbace_go_generic_A_const_87.Invoke_O__O(op__2); if linked_740 == nil { tmp9 = ifn_741.Invoke_O__O(arg_742) } else { tmp9 = linked_740.(*A_arbace_go_generic_type_summary_A).Invoke_O_O__O(root_739, arg_742) }
//line :203:1
					var tmp10 any = tmp9; var tmp11 any; var root_743 any = A_arbace_go_generic_A_const_130.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_745 lang.IFn
					if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = g__4; if linked_744 == nil { tmp11 = ifn_745.Invoke_O__O(arg_746) } else { tmp11 = linked_744.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_743, arg_746) }
//line :203:1
					arg_731 = tmp8.Invoke_O_O_O_O__O(Lit_50, cname__1, tmp10, tmp11); if linked_729 == nil { ifn_730.Invoke_O__O(arg_731) } else { linked_729.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_728, arg_731) }
//line :200:1
					return nil } }






func A_arbace_go_generic_resolve_instance_A_New() *A_arbace_go_generic_resolve_instance_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_resolve_instance_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_go_generic_resolve_instance_A) Ctor() {}
//line :207:1
func (t *A_arbace_go_generic_resolve_instance_A) Invoke_O_O_O_O__O(self, g__0, k__1, args__2 any) any { var map__278000093__4 any = lang.GoGenericFn_Cast(g__0).F_data; var map__278000093__5 any; if


	lang.ISeq_InstanceOf(map__278000093__4) { var tmp1 any; var root_747 any = A_arbace_go_generic_A_const_146.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = map__278000093__4; if linked_748 == nil { tmp1 = ifn_749.Invoke_O__O(arg_750) } else { tmp1 = linked_748.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_747, arg_750) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_751 any = A_arbace_go_generic_A_const_147.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = map__278000093__4; if linked_752 == nil { tmp2 = ifn_753.Invoke_O__O(arg_754) } else { tmp2 = linked_752.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_751, arg_754) }; map__278000093__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_755 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = map__278000093__4; if linked_756 == nil { tmp3 = ifn_757.Invoke_O__O(arg_758) } else { tmp3 = linked_756.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_755, arg_758) }; if jrt.J2g_Truth(tmp3) { var root_759 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = map__278000093__4; if linked_760 == nil { map__278000093__5 = ifn_761.Invoke_O__O(arg_762) } else { map__278000093__5 = linked_760.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_759, arg_762) } } else { map__278000093__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__278000093__5 = map__278000093__4 }; var obj__6 any = /*line :207:1*/lang.RT_Get_O_O__O_NoInit(map__278000093__5, A_arbace_go_generic_A_const_148); var ptargs__7 any = lang.RT_Get_O_O__O_NoInit(map__278000093__5, A_arbace_go_generic_A_const_149); var env__8 any = lang.RT_Get_O_O__O_NoInit(map__278000093__5, A_arbace_go_generic_A_const_150); var x__9 any = obj__6; var ctx__10 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_151.Invoke_O__O(env__8)); var tmp5 any; var root_942 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_944 lang.IFn; if




	linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = x__9; var arg_946 any = A_arbace_go_generic_A_const_69; if linked_943 == nil { tmp5 = ifn_944.Invoke_O_O__O(arg_945, arg_946) } else { tmp5 = linked_943.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_942, arg_945, arg_946) }; ctx__10 = tmp4.Invoke_O__O(tmp5); var cname__11 any; var root_763 any = /*line :207:1*/A_arbace_go_generic_A_const_142.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, A_arbace_go_generic_callee_name_A_fn_class); var ifn_765 lang.IFn; if





	linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = x__9; if linked_764 == nil { cname__11 = ifn_765.Invoke_O__O(arg_766) } else { cname__11 = linked_764.(*A_arbace_go_generic_callee_name_A).Invoke_O_O__O(root_763, arg_766) }; var root_947 any =
	A_arbace_go_generic_A_const_163.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_164.GetRawRoot__O()); var tmp7 any = A_arbace_go_generic_A_const_165; var tmp8 any = A_arbace_go_generic_A_const_39; var tmp9 any; var root_974 any = A_arbace_go_generic_A_const_166.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_976 lang.IFn; if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = lang.PersistentVector_EMPTY.Ref(); if linked_975 == nil { tmp9 = ifn_976.Invoke_O__O(arg_977) } else { tmp9 = linked_975.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_974, arg_977) }; var tmp10 any = tmp9; var tmp11 any = A_arbace_go_generic_A_const_167; var tmp12 any = A_arbace_go_generic_A_const_168; var tmp13 any = A_arbace_go_generic_A_const_169; var tmp14 any = A_arbace_go_generic_A_const_170.GetRawRoot__O(); var tmp15 any = A_arbace_go_generic_A_const_171; var tmp16 any = A_arbace_go_generic_A_const_172.GetRawRoot__O(); var tmp17 any = A_arbace_go_generic_A_const_173; var tmp18 any = A_arbace_go_generic_A_const_174.GetRawRoot__O(); var tmp19 any = A_arbace_go_generic_A_const_175; var tmp20 any = A_arbace_go_generic_A_const_156.GetRawRoot__O(); var tmp21 any = A_arbace_go_generic_A_const_176; var tmp22 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var tmp23 any = A_arbace_go_generic_A_const_177; var tmp24 any = A_arbace_go_generic_resolve_instance_fn__278000095_A_New(); var tmp25 *jrt.Class; var fncls__978 *jrt.Class = A_arbace_go_generic_resolve_instance_fn__278000095_A_fn_class; if fncls__978 == nil { var fncls__978d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, true); A_arbace_go_generic_resolve_instance_fn__278000095_A_fn_class = fncls__978d; tmp25 = fncls__978d } else { tmp25 = fncls__978 }; arg_950 = tmp6.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp7, ctx__10, tmp8, tmp10, tmp11, nil, tmp12, nil, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp24, tmp25, nil, 0)); if linked_948 == nil { ifn_949.Invoke_O__O(arg_950) } else { linked_948.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_947, arg_950) }; var tmp26 any; tmp32 := /*line :207:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var ops__14 any; var root_767 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_769 lang.IFn







		if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any; var root_771 any = A_arbace_go_generic_A_const_136.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_773 lang.IFn; if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any; var tmp27 any = A_arbace_go_generic_resolve_instance_fn__278000097_A_New_O_O(env__8, k__1); var tmp28 *jrt.Class; var fncls__783 *jrt.Class = A_arbace_go_generic_resolve_instance_fn__278000097_A_fn_class; if fncls__783 == nil { var fncls__783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_generic_resolve_instance_fn__278000097_A_fn_class = fncls__783d; tmp28 = fncls__783d } else { tmp28 = fncls__783 }; arg_774 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var arg_775 any = args__2; if linked_772 == nil { arg_770 = ifn_773.Invoke_O_O__O(arg_774, arg_775) } else { arg_770 = linked_772.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_771, arg_774, arg_775) }; if linked_768 == nil { ops__14 = ifn_769.Invoke_O__O(arg_770) } else { ops__14 = linked_768.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_767, arg_770) }
//line :207:1
		var sig__15 any; var root_784 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_786 lang.IFn








		if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = x__9; var arg_788 any = A_arbace_go_generic_A_const_87; if linked_785 == nil { sig__15 = ifn_786.Invoke_O_O__O(arg_787, arg_788) } else { sig__15 = linked_785.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_784, arg_787, arg_788) }
//line :207:1
		var r__16 any; var tmp29 any; var root_789 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_791 lang.IFn









		if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = x__9; var arg_793 any = A_arbace_go_generic_A_const_122; if linked_790 == nil { tmp29 = ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { tmp29 = linked_790.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_789, arg_792, arg_793) }; if jrt.J2g_Truth(tmp29) { var rtps__16 any; var root_794 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_796 lang.IFn


			if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any; var root_798 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = x__9; var arg_802 any = A_arbace_go_generic_A_const_120; if linked_799 == nil { arg_797 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { arg_797 = linked_799.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }; if linked_795 == nil { rtps__16 = ifn_796.Invoke_O__O(arg_797) } else { rtps__16 = linked_795.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_794, arg_797) }
//line :217:1
			var mtps__17 any; var root_803 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_805 lang.IFn



			if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any; var root_807 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = x__9; var arg_811 any = A_arbace_go_generic_A_const_121; if linked_808 == nil { arg_806 = ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { arg_806 = linked_808.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) }; if linked_804 == nil { mtps__17 = ifn_805.Invoke_O__O(arg_806) } else { mtps__17 = linked_804.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_803, arg_806) }
//line :217:1
			var given__18 any; var root_812 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_814 lang.IFn




			if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = ptargs__7; if linked_813 == nil { given__18 = ifn_814.Invoke_O__O(arg_815) } else { given__18 = linked_813.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_812, arg_815) }
//line :217:1
			var rtargs__19 any





			if lang.Numbers_Gte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(given__18)), int64(lang.RT_Count_O__I_NoInit(rtps__16))) {
				var root_816 any = A_arbace_go_generic_A_const_153.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = given__18; var arg_820 any = A_arbace_go_generic_A_const_154; var arg_821 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rtps__16)).Ref(); if linked_817 == nil { rtargs__19 = ifn_818.Invoke_O_O_O__O(arg_819, arg_820, arg_821) } else { rtargs__19 = linked_817.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_816, arg_819, arg_820, arg_821) } } else {
//line :223:1
					var tmp30 any; var root_822 any = A_arbace_go_generic_A_const_140.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_824 lang.IFn

					if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = ops__14; if linked_823 == nil { tmp30 = ifn_824.Invoke_O__O(arg_825) } else { tmp30 = linked_823.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_822, arg_825) }
//line :223:1
					if jrt.J2g_Truth(tmp30) {

						var root_979 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, cname__11)).Ref(); if linked_980 == nil { ifn_981.Invoke_O__O(arg_982) } else { linked_980.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_979, arg_982) }
//line :223:1
						rtargs__19 = nil } else { if A_arbace_go_generic_A_const_71 != nil {


							var root_826 any = A_arbace_go_generic_A_const_155.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, A_arbace_go_generic_receiver_targs_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = x__9; var arg_830 any = cname__11; var arg_831 any; var root_832 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = ops__14; if linked_833 == nil { arg_831 = ifn_834.Invoke_O__O(arg_835) } else { arg_831 = linked_833.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_832, arg_835) }; if linked_827 == nil { rtargs__19 = ifn_828.Invoke_O_O_O__O(arg_829, arg_830, arg_831) } else { rtargs__19 = linked_827.(*A_arbace_go_generic_receiver_targs_A).Invoke_O_O_O_O__O(root_826, arg_829, arg_830, arg_831) } } else {
//line :223:1
								rtargs__19 = nil
							}
						}
				}
			if jrt.J2g_Truth(rtargs__19) { var rt__20 any; var root_836 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A_fn_class); var ifn_838 lang.IFn
				if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any; var arg_840 any; var root_842 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = x__9; var arg_846 any = A_arbace_go_generic_A_const_123; if linked_843 == nil { arg_840 = ifn_844.Invoke_O_O__O(arg_845, arg_846) } else { arg_840 = linked_843.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_842, arg_845, arg_846) }; var arg_841 any = rtargs__19; if linked_837 == nil { rt__20 = ifn_838.Invoke_O_O_O__O(arg_839, arg_840, arg_841) } else { rt__20 = linked_837.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A).Invoke_O_O_O_O__O(root_836, arg_839, arg_840, arg_841) }
//line :227:1
				var msig__21 any; var root_847 any = A_arbace_go_generic_A_const_156.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, aot_arbace_go_check_decl.A_arbace_go_check_decl_subst_A_fn_class); var ifn_849 lang.IFn

				if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = sig__15; var arg_851 any; var root_852 any = A_arbace_go_generic_A_const_157.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = rtps__16; var arg_856 any = rtargs__19; if linked_853 == nil { arg_851 = ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { arg_851 = linked_853.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) }; if linked_848 == nil { msig__21 = ifn_849.Invoke_O_O__O(arg_850, arg_851) } else { msig__21 = linked_848.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_subst_A).Invoke_O_O_O__O(root_847, arg_850, arg_851) }
//line :227:1
				var rest_ops__22 any; var root_857 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_859 lang.IFn


				if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_861 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = ops__14; if linked_862 == nil { arg_860 = ifn_863.Invoke_O__O(arg_864) } else { arg_860 = linked_862.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_861, arg_864) }; if linked_858 == nil { rest_ops__22 = ifn_859.Invoke_O__O(arg_860) } else { rest_ops__22 = linked_858.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_857, arg_860) }
//line :227:1
				var mtargs__23 any; var tmp31 any; var root_865 any = A_arbace_go_generic_A_const_140.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_867 lang.IFn



				if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = mtps__17; if linked_866 == nil { tmp31 = ifn_867.Invoke_O__O(arg_868) } else { tmp31 = linked_866.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_865, arg_868) }; if jrt.J2g_Truth(tmp31) { mtargs__23 = lang.PersistentVector_EMPTY.Ref() } else { var temp__1927000414__auto____23 any; var root_869 any = A_arbace_go_generic_A_const_158.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, A_arbace_go_generic_params_for_A_fn_class); var ifn_871 lang.IFn

					if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = cname__11; var arg_873 any = msig__21; var arg_874 any = rest_ops__22; if linked_870 == nil { temp__1927000414__auto____23 = ifn_871.Invoke_O_O_O__O(arg_872, arg_873, arg_874) } else { temp__1927000414__auto____23 = linked_870.(*A_arbace_go_generic_params_for_A).Invoke_O_O_O_O__O(root_869, arg_872, arg_873, arg_874) }; if jrt.J2g_Truth(temp__1927000414__auto____23) { var ps__24 any = temp__1927000414__auto____23; var root_875 any = A_arbace_go_generic_A_const_159.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, A_arbace_go_generic_infer_targs_A_fn_class); var ifn_877 lang.IFn
						if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = cname__11; var arg_879 any = mtps__17; var arg_880 any; var root_884 any = A_arbace_go_generic_A_const_160.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_884, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rtps__16)).Ref(); var arg_888 any = given__18; if linked_885 == nil { arg_880 = ifn_886.Invoke_O_O__O(arg_887, arg_888) } else { if jrt.Long_InstanceOf(arg_887) { arg_880 = linked_885.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_884, jrt.NN(jrt.Long_Cast(arg_887)).LongValue__J(), arg_887, arg_888) } else { arg_880 = linked_885.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_884, arg_887, arg_888) } }; var arg_881 any = ps__24; var arg_882 any = rest_ops__22; var arg_883 any; var root_889 any = A_arbace_go_generic_A_const_157.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = rtps__16; var arg_893 any = rtargs__19; if linked_890 == nil { arg_883 = ifn_891.Invoke_O_O__O(arg_892, arg_893) } else { arg_883 = linked_890.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_889, arg_892, arg_893) }; if linked_876 == nil { mtargs__23 = ifn_877.Invoke_O_O_O_O_O_O__O(arg_878, arg_879, arg_880, arg_881, arg_882, arg_883) } else { mtargs__23 = linked_876.(*A_arbace_go_generic_infer_targs_A).Invoke_O_O_O_O_O_O_O__O(root_875, arg_878, arg_879, arg_880, arg_881, arg_882, arg_883) } } else {
//line :233:1
							mtargs__23 = nil
						} }
				if jrt.J2g_Truth(mtargs__23) {
					var root_894 any = A_arbace_go_generic_A_const_161.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, A_arbace_go_generic_instance_fn_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = x__9; var arg_898 any; var root_900 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any; var root_904 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = rtargs__19; var arg_908 any = mtargs__23; if linked_905 == nil { arg_903 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { arg_903 = linked_905.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }; if linked_901 == nil { arg_898 = ifn_902.Invoke_O__O(arg_903) } else { arg_898 = linked_901.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_900, arg_903) }; var arg_899 any = rt__20; if linked_895 == nil { r__16 = ifn_896.Invoke_O_O_O__O(arg_897, arg_898, arg_899) } else { r__16 = linked_895.(*A_arbace_go_generic_instance_fn_A).Invoke_O_O_O_O__O(root_894, arg_897, arg_898, arg_899) } } else {
//line :235:1
						r__16 = nil } } else {
//line :227:1
							r__16 = nil } } else {
//line :217:1
								var tps__16 any; var root_909 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_911 lang.IFn



















								if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any; var root_913 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any = x__9; var arg_917 any = A_arbace_go_generic_A_const_121; if linked_914 == nil { arg_912 = ifn_915.Invoke_O_O__O(arg_916, arg_917) } else { arg_912 = linked_914.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_913, arg_916, arg_917) }; if linked_910 == nil { tps__16 = ifn_911.Invoke_O__O(arg_912) } else { tps__16 = linked_910.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_909, arg_912) }
//line :217:1
								var temp__1927000414__auto____17 any; var root_918 any = A_arbace_go_generic_A_const_158.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, A_arbace_go_generic_params_for_A_fn_class); var ifn_920 lang.IFn




















								if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = cname__11; var arg_922 any = sig__15; var arg_923 any = ops__14; if linked_919 == nil { temp__1927000414__auto____17 = ifn_920.Invoke_O_O_O__O(arg_921, arg_922, arg_923) } else { temp__1927000414__auto____17 = linked_919.(*A_arbace_go_generic_params_for_A).Invoke_O_O_O_O__O(root_918, arg_921, arg_922, arg_923) }; if jrt.J2g_Truth(temp__1927000414__auto____17) { var ps__18 any = temp__1927000414__auto____17; var temp__1927000414__auto____19 any; var root_924 any = A_arbace_go_generic_A_const_159.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, A_arbace_go_generic_infer_targs_A_fn_class); var ifn_926 lang.IFn
									if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = cname__11; var arg_928 any = tps__16; var arg_929 any = ptargs__7; var arg_930 any = ps__18; var arg_931 any = ops__14; var arg_932 any; if linked_925 == nil { temp__1927000414__auto____19 = ifn_926.Invoke_O_O_O_O_O_O__O(arg_927, arg_928, arg_929, arg_930, arg_931, arg_932) } else { temp__1927000414__auto____19 = linked_925.(*A_arbace_go_generic_infer_targs_A).Invoke_O_O_O_O_O_O_O__O(root_924, arg_927, arg_928, arg_929, arg_930, arg_931, arg_932) }; if jrt.J2g_Truth(temp__1927000414__auto____19) { var targs__20 any = temp__1927000414__auto____19; var root_933 any = A_arbace_go_generic_A_const_161.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, A_arbace_go_generic_instance_fn_A_fn_class); var ifn_935 lang.IFn
										if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = x__9; var arg_937 any = targs__20; var arg_938 any; if linked_934 == nil { r__16 = ifn_935.Invoke_O_O_O__O(arg_936, arg_937, arg_938) } else { r__16 = linked_934.(*A_arbace_go_generic_instance_fn_A).Invoke_O_O_O_O__O(root_933, arg_936, arg_937, arg_938) } } else {
//line :239:1
											r__16 = nil } } else {
//line :238:1
												r__16 = nil
											}
							}
		var root_983 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; if linked_984 == nil { ifn_985.Invoke__O() } else { linked_984.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_983) }
//line :207:1
		tmp26 = r__16 }; return nil }(); var root_939 any = A_arbace_go_generic_A_const_162.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_941 lang.IFn; if






	linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; if linked_940 == nil { ifn_941.Invoke__O() } else { linked_940.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_939) }; if /*line :207:1*/ tmp32 != nil { panic(tmp32) }; return tmp26 }






func A_arbace_go_generic_resolve_instance_fn__278000095_A_New() *A_arbace_go_generic_resolve_instance_fn__278000095_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_resolve_instance_fn__278000095_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_generic_resolve_instance_fn__278000095_A) Ctor() {}
//line :214:1
func (t *A_arbace_go_generic_resolve_instance_fn__278000095_A) DoInvoke_O_O__O(self, ___278000012__auto____1 any) any { return nil }
func A_arbace_go_generic_resolve_instance_fn__278000097_A_New_O_O(p0, p1 any) *A_arbace_go_generic_resolve_instance_fn__278000097_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_resolve_instance_fn__278000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :215:1
func (t *A_arbace_go_generic_resolve_instance_fn__278000097_A) Ctor_O_O(c__env, c__k any) { t.F_env = c__env; t.F_k = c__k }
//line :215:1
func (t *A_arbace_go_generic_resolve_instance_fn__278000097_A) Invoke_O_O_O__O(self, i__1, v__2 any) any { var root_776 any = A_arbace_go_generic_A_const_152.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, A_arbace_go_generic_operand_A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var tmp1 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](t.F_k, jrt.Object_class.ArrayClass()); var arg_779 any = lang.RT_Aget_O1_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(i__1)); var arg_780 any = v__2; var arg_781 any = i__1; var arg_782 any = t.F_env; if linked_777 == nil { return ifn_778.Invoke_O_O_O_O__O(arg_779, arg_780, arg_781, arg_782) } else { return linked_777.(*A_arbace_go_generic_operand_A).Invoke_O_O_O_O_O__O(root_776, arg_779, arg_780, arg_781, arg_782) } }




























func A_arbace_go_generic_generic_fn_A_New() *A_arbace_go_generic_generic_fn_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_generic_fn_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_go_generic_generic_fn_A) Ctor() {}
//line :244:1
func (t *A_arbace_go_generic_generic_fn_A) Invoke_O_O_O_O_O__O(self, x__0, full__1, env__2, ptargs__3 any) any { var tmp1 *jrt.String = jrt.String_Cast(full__1); var tmp2 any = A_arbace_go_generic_A_const_148; var tmp3 any = A_arbace_go_generic_A_const_149; var tmp4 any = A_arbace_go_generic_A_const_150; var tmp5 any = A_arbace_go_generic_A_const_179; var tmp6 any; var root_986 any = A_arbace_go_generic_A_const_180.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_988 lang.IFn; if




	linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_987 == nil { tmp6 = ifn_988.Invoke_O__O(arg_989) } else { tmp6 = linked_987.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_986, arg_989) }; return /*line :244:1*/ lang.GoGenericFn_New_String_O_IFn(tmp1, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, x__0, tmp3, ptargs__3, tmp4, env__2, tmp5, tmp6)), lang.IFn_Cast(A_arbace_go_generic_A_const_181.GetRawRoot__O())) }
//line :244:1
func (t *A_arbace_go_generic_generic_fn_A) Invoke_O_O_O_O__O(self, x__0, full__1, env__2 any) any {


	var root_990 any = A_arbace_go_generic_A_const_182.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, A_arbace_go_generic_generic_fn_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = x__0; var arg_994 any = full__1; var arg_995 any = env__2; var arg_996 any; if linked_991 == nil { return ifn_992.Invoke_O_O_O_O__O(arg_993, arg_994, arg_995, arg_996) } else { return linked_991.(*A_arbace_go_generic_generic_fn_A).Invoke_O_O_O_O_O__O(root_990, arg_993, arg_994, arg_995, arg_996)
	}
}

func A_arbace_go_generic_instantiate_A_New() *A_arbace_go_generic_instantiate_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_instantiate_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_go_generic_instantiate_A) Ctor() {}
//line :251:1
func (t *A_arbace_go_generic_instantiate_A) Invoke_O_O_O__O(self, g__0, targs__1 any) any { var map__278000102__3 any = lang.GoGenericFn_Cast(g__0).F_data; var map__278000102__4 any; if




	lang.ISeq_InstanceOf(map__278000102__3) { var tmp1 any; var root_997 any = A_arbace_go_generic_A_const_146.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = map__278000102__3; if linked_998 == nil { tmp1 = ifn_999.Invoke_O__O(arg_1000) } else { tmp1 = linked_998.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_997, arg_1000) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1001 any = A_arbace_go_generic_A_const_147.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = map__278000102__3; if linked_1002 == nil { tmp2 = ifn_1003.Invoke_O__O(arg_1004) } else { tmp2 = linked_1002.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1001, arg_1004) }; map__278000102__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1005 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = map__278000102__3; if linked_1006 == nil { tmp3 = ifn_1007.Invoke_O__O(arg_1008) } else { tmp3 = linked_1006.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1005, arg_1008) }; if jrt.J2g_Truth(tmp3) { var root_1009 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = map__278000102__3; if linked_1010 == nil { map__278000102__4 = ifn_1011.Invoke_O__O(arg_1012) } else { map__278000102__4 = linked_1010.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1009, arg_1012) } } else { map__278000102__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__278000102__4 = map__278000102__3 }; var obj__5 any = /*line :251:1*/lang.RT_Get_O_O__O_NoInit(map__278000102__4, A_arbace_go_generic_A_const_148); var env__6 any = lang.RT_Get_O_O__O_NoInit(map__278000102__4, A_arbace_go_generic_A_const_150); var ptargs__7 any = lang.RT_Get_O_O__O_NoInit(map__278000102__4, A_arbace_go_generic_A_const_149); var x__8 any = obj__5; var all__9 any; var root_1013 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1015 lang.IFn; if






	linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any; var root_1017 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = ptargs__7; var arg_1021 any = targs__1; if linked_1018 == nil { arg_1016 = ifn_1019.Invoke_O_O__O(arg_1020, arg_1021) } else { arg_1016 = linked_1018.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1017, arg_1020, arg_1021) }; if linked_1014 == nil { all__9 = ifn_1015.Invoke_O__O(arg_1016) } else { all__9 = linked_1014.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1013, arg_1016) }; var tps__10 any; var root_1022 any = /*line :251:1*/A_arbace_go_generic_A_const_183.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, A_arbace_go_generic_tparams_of_A_fn_class); var ifn_1024 lang.IFn; if







	linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = x__8; if linked_1023 == nil { tps__10 = ifn_1024.Invoke_O__O(arg_1025) } else { tps__10 = linked_1023.(*A_arbace_go_generic_tparams_of_A).Invoke_O_O__O(root_1022, arg_1025) }; var cname__11 any; var root_1026 any = /*line :251:1*/A_arbace_go_generic_A_const_142.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, A_arbace_go_generic_callee_name_A_fn_class); var ifn_1028 lang.IFn; if








	linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = x__8; if linked_1027 == nil { cname__11 = ifn_1028.Invoke_O__O(arg_1029) } else { cname__11 = linked_1027.(*A_arbace_go_generic_callee_name_A).Invoke_O_O__O(root_1026, arg_1029) }; var root_1091 any =
	A_arbace_go_generic_A_const_163.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1093 lang.IFn; if linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_164.GetRawRoot__O()); var tmp5 any = A_arbace_go_generic_A_const_165; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_151.Invoke_O__O(env__6)); var tmp7 any; var root_1118 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1118, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any = x__8; var arg_1122 any = A_arbace_go_generic_A_const_69; if linked_1119 == nil { tmp7 = ifn_1120.Invoke_O_O__O(arg_1121, arg_1122) } else { tmp7 = linked_1119.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1118, arg_1121, arg_1122) }; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 any = A_arbace_go_generic_A_const_39; var tmp10 any; var root_1123 any = A_arbace_go_generic_A_const_166.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = lang.PersistentVector_EMPTY.Ref(); if linked_1124 == nil { tmp10 = ifn_1125.Invoke_O__O(arg_1126) } else { tmp10 = linked_1124.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1123, arg_1126) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_generic_A_const_167; var tmp13 any = A_arbace_go_generic_A_const_168; var tmp14 any = A_arbace_go_generic_A_const_169; var tmp15 any = A_arbace_go_generic_A_const_170.GetRawRoot__O(); var tmp16 any = A_arbace_go_generic_A_const_171; var tmp17 any = A_arbace_go_generic_A_const_172.GetRawRoot__O(); var tmp18 any = A_arbace_go_generic_A_const_173; var tmp19 any = A_arbace_go_generic_A_const_174.GetRawRoot__O(); var tmp20 any = A_arbace_go_generic_A_const_175; var tmp21 any = A_arbace_go_generic_A_const_156.GetRawRoot__O(); var tmp22 any = A_arbace_go_generic_A_const_176; var tmp23 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var tmp24 any = A_arbace_go_generic_A_const_177; var tmp25 any = A_arbace_go_generic_instantiate_fn__278000104_A_New(); var tmp26 *jrt.Class; var fncls__1127 *jrt.Class = A_arbace_go_generic_instantiate_fn__278000104_A_fn_class; if fncls__1127 == nil { var fncls__1127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, true); A_arbace_go_generic_instantiate_fn__278000104_A_fn_class = fncls__1127d; tmp26 = fncls__1127d } else { tmp26 = fncls__1127 }; arg_1094 = tmp4.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp5, tmp8, tmp9, tmp11, tmp12, nil, tmp13, nil, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp25, tmp26, nil, 0)); if linked_1092 == nil { ifn_1093.Invoke_O__O(arg_1094) } else { linked_1092.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1091, arg_1094) }; var tmp27 any; tmp31 := /*line :251:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var all__14 any; var root_1030 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1032 lang.IFn










		if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var arg_1033 any; var tmp28 any = A_arbace_go_generic_instantiate_fn__278000106_A_New_O(env__6); var tmp29 *jrt.Class; var fncls__1040 *jrt.Class = A_arbace_go_generic_instantiate_fn__278000106_A_fn_class; if fncls__1040 == nil { var fncls__1040d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_go_generic_instantiate_fn__278000106_A_fn_class = fncls__1040d; tmp29 = fncls__1040d } else { tmp29 = fncls__1040 }; arg_1033 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_1034 any = all__9; if linked_1031 == nil { all__14 = ifn_1032.Invoke_O_O__O(arg_1033, arg_1034) } else { all__14 = linked_1031.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1030, arg_1033, arg_1034) }
		if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(all__14)), int64(lang.RT_Count_O__I_NoInit(tps__10))) {

			var root_1128 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = lang.IFn_Cast(A_arbace_go_generic_A_const_134.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_42, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(all__14)).Ref(), cname__11, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tps__10)).Ref()); if linked_1129 == nil { ifn_1130.Invoke_O__O(arg_1131) } else { linked_1129.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_1128, arg_1131) }
			var root_1041 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; if linked_1042 == nil { tmp27 = ifn_1043.Invoke__O() } else { tmp27 = linked_1042.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_1041) } } else {
//line :263:1
				if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(all__14)), int64(lang.RT_Count_O__I_NoInit(tps__10))) { var rtps__15 any; var root_1044 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1046 lang.IFn




					if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any; var root_1048 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = x__8; var arg_1052 any = A_arbace_go_generic_A_const_120; if linked_1049 == nil { arg_1047 = ifn_1050.Invoke_O_O__O(arg_1051, arg_1052) } else { arg_1047 = linked_1049.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1048, arg_1051, arg_1052) }; if linked_1045 == nil { rtps__15 = ifn_1046.Invoke_O__O(arg_1047) } else { rtps__15 = linked_1045.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1044, arg_1047) }
					var root_1139 any = A_arbace_go_generic_A_const_141.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any; var arg_1143 any = tps__10; var arg_1144 any = all__14; var arg_1145 any; if linked_1140 == nil { ifn_1141.Invoke_O_O_O_O__O(arg_1142, arg_1143, arg_1144, arg_1145) } else { linked_1140.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A).Invoke_O_O_O_O_O__O(root_1139, arg_1142, arg_1143, arg_1144, arg_1145) }
					var root_1146 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; if linked_1147 == nil { ifn_1148.Invoke__O() } else { linked_1147.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_1146) }
					var root_1053 any = A_arbace_go_generic_A_const_161.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, A_arbace_go_generic_instance_fn_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = x__8; var arg_1057 any = all__14; var arg_1058 any; var tmp30 any; var root_1059 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1061 lang.IFn; if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = x__8; var arg_1063 any = A_arbace_go_generic_A_const_122; if linked_1060 == nil { tmp30 = ifn_1061.Invoke_O_O__O(arg_1062, arg_1063) } else { tmp30 = linked_1060.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1059, arg_1062, arg_1063) }; if jrt.J2g_Truth(tmp30) { var root_1064 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any; var arg_1068 any; var root_1070 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = x__8; var arg_1074 any = A_arbace_go_generic_A_const_123; if linked_1071 == nil { arg_1068 = ifn_1072.Invoke_O_O__O(arg_1073, arg_1074) } else { arg_1068 = linked_1071.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1070, arg_1073, arg_1074) }; var arg_1069 any; var root_1075 any = A_arbace_go_generic_A_const_153.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = all__14; var arg_1079 any = A_arbace_go_generic_A_const_154; var arg_1080 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rtps__15)).Ref(); if linked_1076 == nil { arg_1069 = ifn_1077.Invoke_O_O_O__O(arg_1078, arg_1079, arg_1080) } else { arg_1069 = linked_1076.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_1075, arg_1078, arg_1079, arg_1080) }; if linked_1065 == nil { arg_1058 = ifn_1066.Invoke_O_O_O__O(arg_1067, arg_1068, arg_1069) } else { arg_1058 = linked_1065.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A).Invoke_O_O_O_O__O(root_1064, arg_1067, arg_1068, arg_1069) } } else { arg_1058 = nil }; if linked_1054 == nil { tmp27 = ifn_1055.Invoke_O_O_O__O(arg_1056, arg_1057, arg_1058) } else { tmp27 = linked_1054.(*A_arbace_go_generic_instance_fn_A).Invoke_O_O_O_O__O(root_1053, arg_1056, arg_1057, arg_1058) } } else {
//line :263:1
						if A_arbace_go_generic_A_const_71 != nil {








							var root_1081 any = A_arbace_go_generic_A_const_182.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, A_arbace_go_generic_generic_fn_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = x__8; var arg_1085 any = lang.GoGenericFn_Cast(g__0).F_name.Ref(); var arg_1086 any = env__6; var arg_1087 any = all__14; if linked_1082 == nil { tmp27 = ifn_1083.Invoke_O_O_O_O__O(arg_1084, arg_1085, arg_1086, arg_1087) } else { tmp27 = linked_1082.(*A_arbace_go_generic_generic_fn_A).Invoke_O_O_O_O_O__O(root_1081, arg_1084, arg_1085, arg_1086, arg_1087) } } else {
//line :263:1
								tmp27 = nil } } } }; return nil }(); var root_1088 any = /*line :251:1*/A_arbace_go_generic_A_const_162.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1090 lang.IFn; if









	linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; if linked_1089 == nil { ifn_1090.Invoke__O() } else { linked_1089.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1088) }; if /*line :251:1*/ tmp31 != nil { panic(tmp31) }; return tmp27 }









func A_arbace_go_generic_instantiate_fn__278000104_A_New() *A_arbace_go_generic_instantiate_fn__278000104_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_instantiate_fn__278000104_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_go_generic_instantiate_fn__278000104_A) Ctor() {}
//line :261:1
func (t *A_arbace_go_generic_instantiate_fn__278000104_A) DoInvoke_O_O__O(self, ___278000012__auto____1 any) any { return nil }
func A_arbace_go_generic_instantiate_fn__278000106_A_New_O(p0 any) *A_arbace_go_generic_instantiate_fn__278000106_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_instantiate_fn__278000106_A{}; t.Ctor_O(p0); return t }
//line :262:1
func (t *A_arbace_go_generic_instantiate_fn__278000106_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :262:1
func (t *A_arbace_go_generic_instantiate_fn__278000106_A) Invoke_O_O__O(self, p1__278000101_SHARP___1 any) any { var root_1035 any = A_arbace_go_generic_A_const_61.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, A_arbace_go_generic_rehome_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = p1__278000101_SHARP___1; var arg_1039 any = t.F_env; if linked_1036 == nil { return ifn_1037.Invoke_O_O__O(arg_1038, arg_1039) } else { return linked_1036.(*A_arbace_go_generic_rehome_A).Invoke_O_O_O__O(root_1035, arg_1038, arg_1039) } }











func A_arbace_go_generic_type_instance_A_New() *A_arbace_go_generic_type_instance_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_type_instance_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_go_generic_type_instance_A) Ctor() {}
//line :274:1
func (t *A_arbace_go_generic_type_instance_A) Invoke_O_O_O_O__O(self, g__0, targs__1, env__2 any) any { var i__4 any; var root_1149 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1151 lang.IFn; if



	linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = g__0; if linked_1150 == nil { i__4 = ifn_1151.Invoke_O__O(arg_1152) } else { i__4 = linked_1150.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1149, arg_1152) }; var root_1177 any =
	A_arbace_go_generic_A_const_163.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_164.GetRawRoot__O()); var tmp2 any = A_arbace_go_generic_A_const_165; var tmp3 any = lang.IFn_Cast(A_arbace_go_generic_A_const_151.Invoke_O__O(env__2)).Invoke_O__O(A_arbace_go_generic_A_const_69.Invoke_O__O(i__4)); var tmp4 any = A_arbace_go_generic_A_const_39; var tmp5 any; var root_1204 any = A_arbace_go_generic_A_const_166.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = lang.PersistentVector_EMPTY.Ref(); if linked_1205 == nil { tmp5 = ifn_1206.Invoke_O__O(arg_1207) } else { tmp5 = linked_1205.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1204, arg_1207) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_go_generic_A_const_167; var tmp8 any = A_arbace_go_generic_A_const_168; var tmp9 any = A_arbace_go_generic_A_const_169; var tmp10 any = A_arbace_go_generic_A_const_170.GetRawRoot__O(); var tmp11 any = A_arbace_go_generic_A_const_171; var tmp12 any = A_arbace_go_generic_A_const_172.GetRawRoot__O(); var tmp13 any = A_arbace_go_generic_A_const_173; var tmp14 any = A_arbace_go_generic_A_const_174.GetRawRoot__O(); var tmp15 any = A_arbace_go_generic_A_const_175; var tmp16 any = A_arbace_go_generic_A_const_156.GetRawRoot__O(); var tmp17 any = A_arbace_go_generic_A_const_176; var tmp18 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var tmp19 any = A_arbace_go_generic_A_const_177; var tmp20 any = A_arbace_go_generic_type_instance_fn__278000110_A_New(); var tmp21 *jrt.Class; var fncls__1208 *jrt.Class = A_arbace_go_generic_type_instance_fn__278000110_A_fn_class; if fncls__1208 == nil { var fncls__1208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, true); A_arbace_go_generic_type_instance_fn__278000110_A_fn_class = fncls__1208d; tmp21 = fncls__1208d } else { tmp21 = fncls__1208 }; arg_1180 = tmp1.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp6, tmp7, nil, tmp8, nil, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp20, tmp21, nil, 0)); if linked_1178 == nil { ifn_1179.Invoke_O__O(arg_1180) } else { linked_1178.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1177, arg_1180) }; var tmp22 any; tmp26 := /*line :274:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var targs__7 any; var root_1153 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1155 lang.IFn





		if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any; var tmp23 any = A_arbace_go_generic_type_instance_fn__278000112_A_New_O(env__2); var tmp24 *jrt.Class; var fncls__1163 *jrt.Class = A_arbace_go_generic_type_instance_fn__278000112_A_fn_class; if fncls__1163 == nil { var fncls__1163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_go_generic_type_instance_fn__278000112_A_fn_class = fncls__1163d; tmp24 = fncls__1163d } else { tmp24 = fncls__1163 }; arg_1156 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var arg_1157 any = targs__1; if linked_1154 == nil { targs__7 = ifn_1155.Invoke_O_O__O(arg_1156, arg_1157) } else { targs__7 = linked_1154.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1153, arg_1156, arg_1157) }
//line :274:1
		var inst__8 any; var root_1164 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A_fn_class); var ifn_1166 lang.IFn






		if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any; var arg_1168 any = g__0; var arg_1169 any = targs__7; if linked_1165 == nil { inst__8 = ifn_1166.Invoke_O_O_O__O(arg_1167, arg_1168, arg_1169) } else { inst__8 = linked_1165.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A).Invoke_O_O_O_O__O(root_1164, arg_1167, arg_1168, arg_1169) }
		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_185, inst__8) { var root_1209 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; if linked_1210 == nil { ifn_1211.Invoke__O() } else { linked_1210.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_1209) } }
		var root_1212 any = A_arbace_go_generic_A_const_141.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any; var arg_1216 any = A_arbace_go_generic_A_const_121.Invoke_O__O(i__4); var arg_1217 any = targs__7; var arg_1218 any; if linked_1213 == nil { ifn_1214.Invoke_O_O_O_O__O(arg_1215, arg_1216, arg_1217, arg_1218) } else { linked_1213.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A).Invoke_O_O_O_O_O__O(root_1212, arg_1215, arg_1216, arg_1217, arg_1218) }
		var root_1219 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; if linked_1220 == nil { ifn_1221.Invoke__O() } else { linked_1220.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_1219) }
//line :274:1
		var tmp25 any; var root_1170 any = A_arbace_go_generic_A_const_184.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_1172 lang.IFn










		if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = inst__8; if linked_1171 == nil { tmp25 = ifn_1172.Invoke_O__O(arg_1173) } else { tmp25 = linked_1171.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_1170, arg_1173) }
//line :274:1
		tmp22 = lang.GoType_New_O(tmp25) }; return nil }(); var root_1174 any = A_arbace_go_generic_A_const_162.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1176 lang.IFn; if




	linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; if linked_1175 == nil { ifn_1176.Invoke__O() } else { linked_1175.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1174) }; if /*line :274:1*/ tmp26 != nil { panic(tmp26) }; return tmp22 }




func A_arbace_go_generic_type_instance_fn__278000110_A_New() *A_arbace_go_generic_type_instance_fn__278000110_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_type_instance_fn__278000110_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_go_generic_type_instance_fn__278000110_A) Ctor() {}
//line :279:1
func (t *A_arbace_go_generic_type_instance_fn__278000110_A) DoInvoke_O_O__O(self, ___278000012__auto____1 any) any { return nil }
func A_arbace_go_generic_type_instance_fn__278000112_A_New_O(p0 any) *A_arbace_go_generic_type_instance_fn__278000112_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_type_instance_fn__278000112_A{}; t.Ctor_O(p0); return t }
//line :280:1
func (t *A_arbace_go_generic_type_instance_fn__278000112_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :280:1
func (t *A_arbace_go_generic_type_instance_fn__278000112_A) Invoke_O_O__O(self, p1__278000109_SHARP___1 any) any { var root_1158 any = A_arbace_go_generic_A_const_61.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, A_arbace_go_generic_rehome_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = p1__278000109_SHARP___1; var arg_1162 any = t.F_env; if linked_1159 == nil { return ifn_1160.Invoke_O_O__O(arg_1161, arg_1162) } else { return linked_1159.(*A_arbace_go_generic_rehome_A).Invoke_O_O_O__O(root_1158, arg_1161, arg_1162) } }












type A_arbace_go_generic_A struct{ jrt.Object }

var A_arbace_go_generic_A_const_pool *jrt.RefArray

var A_arbace_go_generic_A_const_0 *lang.Var

var A_arbace_go_generic_A_const_1 any

var A_arbace_go_generic_A_const_2 *lang.Var

var A_arbace_go_generic_A_const_3 any

var A_arbace_go_generic_A_const_4 any

var A_arbace_go_generic_A_const_5 any

var A_arbace_go_generic_A_const_6 any

var A_arbace_go_generic_A_const_7 any

var A_arbace_go_generic_A_const_8 any

var A_arbace_go_generic_A_const_9 *lang.Var

var A_arbace_go_generic_A_const_10 *lang.Var

var A_arbace_go_generic_A_const_11 *lang.Var

var A_arbace_go_generic_A_const_12 *lang.Var

var A_arbace_go_generic_A_const_13 any

var A_arbace_go_generic_A_const_14 *lang.Var

var A_arbace_go_generic_A_const_15 *lang.Var

var A_arbace_go_generic_A_const_16 *lang.Var

var A_arbace_go_generic_A_const_17 any

var A_arbace_go_generic_A_const_18 *lang.Var

var A_arbace_go_generic_A_const_19 *lang.Var

var A_arbace_go_generic_A_const_20 any

var A_arbace_go_generic_A_const_21 any

var A_arbace_go_generic_A_const_22 any

var A_arbace_go_generic_A_const_23 any

var A_arbace_go_generic_A_const_24 any

var A_arbace_go_generic_A_const_25 any

var A_arbace_go_generic_A_const_26 any

var A_arbace_go_generic_A_const_27 any

var A_arbace_go_generic_A_const_28 any

var A_arbace_go_generic_A_const_29 any

var A_arbace_go_generic_A_const_30 any

var A_arbace_go_generic_A_const_31 any

var A_arbace_go_generic_A_const_32 any

var A_arbace_go_generic_A_const_33 any

var A_arbace_go_generic_A_const_34 any

var A_arbace_go_generic_A_const_35 any

var A_arbace_go_generic_A_const_36 any

var A_arbace_go_generic_A_const_37 any

var A_arbace_go_generic_A_const_38 any

var A_arbace_go_generic_A_const_39 *lang.Var

var A_arbace_go_generic_A_const_40 *lang.Var

var A_arbace_go_generic_A_const_41 *lang.Var

var A_arbace_go_generic_A_const_42 *lang.Var

var A_arbace_go_generic_A_const_43 *lang.Var

var A_arbace_go_generic_A_const_44 *lang.Var

var A_arbace_go_generic_A_const_45 *lang.Var

var A_arbace_go_generic_A_const_46 *lang.Keyword

var A_arbace_go_generic_A_const_47 *lang.Var

var A_arbace_go_generic_A_const_48 *lang.Var

var A_arbace_go_generic_A_const_49 *lang.Var

var A_arbace_go_generic_A_const_50 *lang.Var

var A_arbace_go_generic_A_const_51 *lang.Var

var A_arbace_go_generic_A_const_52 *lang.Var

var A_arbace_go_generic_A_const_53 *lang.Var

var A_arbace_go_generic_A_const_54 any

var A_arbace_go_generic_A_const_55 *lang.Keyword

var A_arbace_go_generic_A_const_56 *lang.Var

var A_arbace_go_generic_A_const_57 *lang.Var

var A_arbace_go_generic_A_const_58 *lang.Keyword

var A_arbace_go_generic_A_const_59 *lang.Var

var A_arbace_go_generic_A_const_60 *lang.Keyword

var A_arbace_go_generic_A_const_61 *lang.Var

var A_arbace_go_generic_A_const_62 *lang.Var

var A_arbace_go_generic_A_const_63 *lang.Var

var A_arbace_go_generic_A_const_64 *lang.Var

var A_arbace_go_generic_A_const_65 *lang.Keyword

var A_arbace_go_generic_A_const_66 *lang.Var

var A_arbace_go_generic_A_const_67 *lang.Keyword

var A_arbace_go_generic_A_const_68 *lang.Var

var A_arbace_go_generic_A_const_69 *lang.Keyword

var A_arbace_go_generic_A_const_70 *lang.Keyword

var A_arbace_go_generic_A_const_71 *lang.Keyword

var A_arbace_go_generic_A_const_72 *lang.Keyword

var A_arbace_go_generic_A_const_73 *lang.Var

var A_arbace_go_generic_A_const_74 *lang.Keyword

var A_arbace_go_generic_A_const_75 *lang.Keyword

var A_arbace_go_generic_A_const_76 *lang.Keyword

var A_arbace_go_generic_A_const_77 *lang.Keyword

var A_arbace_go_generic_A_const_78 *lang.Keyword

var A_arbace_go_generic_A_const_79 *lang.Keyword

var A_arbace_go_generic_A_const_80 *lang.Var

var A_arbace_go_generic_A_const_81 any

var A_arbace_go_generic_A_const_82 *lang.Var

var A_arbace_go_generic_A_const_83 *lang.Keyword

var A_arbace_go_generic_A_const_84 *lang.Keyword

var A_arbace_go_generic_A_const_85 *lang.Keyword

var A_arbace_go_generic_A_const_86 *lang.Var

var A_arbace_go_generic_A_const_87 *lang.Keyword

var A_arbace_go_generic_A_const_88 *lang.Var

var A_arbace_go_generic_A_const_89 any

var A_arbace_go_generic_A_const_90 *lang.Var

var A_arbace_go_generic_A_const_91 *lang.Var

var A_arbace_go_generic_A_const_92 *lang.Var

var A_arbace_go_generic_A_const_93 *lang.Var

var A_arbace_go_generic_A_const_94 *lang.Keyword

var A_arbace_go_generic_A_const_95 *lang.Var

var A_arbace_go_generic_A_const_96 *lang.Keyword

var A_arbace_go_generic_A_const_97 *lang.Keyword

var A_arbace_go_generic_A_const_98 *lang.Keyword

var A_arbace_go_generic_A_const_99 *lang.Keyword

var A_arbace_go_generic_A_const_100 *lang.Keyword

var A_arbace_go_generic_A_const_101 any

var A_arbace_go_generic_A_const_102 *lang.Var

var A_arbace_go_generic_A_const_103 *lang.Var

var A_arbace_go_generic_A_const_104 *lang.Keyword

var A_arbace_go_generic_A_const_105 *lang.Keyword

var A_arbace_go_generic_A_const_106 *lang.Keyword

var A_arbace_go_generic_A_const_107 *lang.Keyword

var A_arbace_go_generic_A_const_108 *lang.Keyword

var A_arbace_go_generic_A_const_109 *lang.Keyword

var A_arbace_go_generic_A_const_110 *lang.Keyword

var A_arbace_go_generic_A_const_111 *lang.Keyword

var A_arbace_go_generic_A_const_112 *lang.Var

var A_arbace_go_generic_A_const_113 *lang.Keyword

var A_arbace_go_generic_A_const_114 *lang.Keyword

var A_arbace_go_generic_A_const_115 *lang.Keyword

var A_arbace_go_generic_A_const_116 *lang.Keyword

var A_arbace_go_generic_A_const_117 *lang.Keyword

var A_arbace_go_generic_A_const_118 *lang.Keyword

var A_arbace_go_generic_A_const_119 *lang.Var

var A_arbace_go_generic_A_const_120 *lang.Keyword

var A_arbace_go_generic_A_const_121 *lang.Keyword

var A_arbace_go_generic_A_const_122 *lang.Keyword

var A_arbace_go_generic_A_const_123 *lang.Keyword

var A_arbace_go_generic_A_const_124 *lang.Keyword

var A_arbace_go_generic_A_const_125 *lang.Var

var A_arbace_go_generic_A_const_126 *lang.Var

var A_arbace_go_generic_A_const_127 *lang.Var

var A_arbace_go_generic_A_const_128 any

var A_arbace_go_generic_A_const_129 any

var A_arbace_go_generic_A_const_130 *lang.Var

var A_arbace_go_generic_A_const_131 *lang.Var

var A_arbace_go_generic_A_const_132 *lang.Var

var A_arbace_go_generic_A_const_133 *lang.Var

var A_arbace_go_generic_A_const_134 *lang.Var

var A_arbace_go_generic_A_const_135 *lang.Var

var A_arbace_go_generic_A_const_136 *lang.Var

var A_arbace_go_generic_A_const_137 *lang.Var

var A_arbace_go_generic_A_const_138 any

var A_arbace_go_generic_A_const_139 *lang.Var

var A_arbace_go_generic_A_const_140 *lang.Var

var A_arbace_go_generic_A_const_141 *lang.Var

var A_arbace_go_generic_A_const_142 *lang.Var

var A_arbace_go_generic_A_const_143 *lang.Var

var A_arbace_go_generic_A_const_144 *lang.Var

var A_arbace_go_generic_A_const_145 *lang.Var

var A_arbace_go_generic_A_const_146 *lang.Var

var A_arbace_go_generic_A_const_147 *lang.Var

var A_arbace_go_generic_A_const_148 *lang.Keyword

var A_arbace_go_generic_A_const_149 *lang.Keyword

var A_arbace_go_generic_A_const_150 *lang.Keyword

var A_arbace_go_generic_A_const_151 *lang.Keyword

var A_arbace_go_generic_A_const_152 *lang.Var

var A_arbace_go_generic_A_const_153 *lang.Var

var A_arbace_go_generic_A_const_154 any

var A_arbace_go_generic_A_const_155 *lang.Var

var A_arbace_go_generic_A_const_156 *lang.Var

var A_arbace_go_generic_A_const_157 *lang.Var

var A_arbace_go_generic_A_const_158 *lang.Var

var A_arbace_go_generic_A_const_159 *lang.Var

var A_arbace_go_generic_A_const_160 *lang.Var

var A_arbace_go_generic_A_const_161 *lang.Var

var A_arbace_go_generic_A_const_162 *lang.Var

var A_arbace_go_generic_A_const_163 *lang.Var

var A_arbace_go_generic_A_const_164 *lang.Var

var A_arbace_go_generic_A_const_165 *lang.Var

var A_arbace_go_generic_A_const_166 *lang.Var

var A_arbace_go_generic_A_const_167 *lang.Var

var A_arbace_go_generic_A_const_168 *lang.Var

var A_arbace_go_generic_A_const_169 *lang.Var

var A_arbace_go_generic_A_const_170 *lang.Var

var A_arbace_go_generic_A_const_171 *lang.Var

var A_arbace_go_generic_A_const_172 *lang.Var

var A_arbace_go_generic_A_const_173 *lang.Var

var A_arbace_go_generic_A_const_174 *lang.Var

var A_arbace_go_generic_A_const_175 *lang.Var

var A_arbace_go_generic_A_const_176 *lang.Var

var A_arbace_go_generic_A_const_177 *lang.Var

var A_arbace_go_generic_A_const_178 *lang.Var

var A_arbace_go_generic_A_const_179 *lang.Keyword

var A_arbace_go_generic_A_const_180 *lang.Var

var A_arbace_go_generic_A_const_181 *lang.Var

var A_arbace_go_generic_A_const_182 *lang.Var

var A_arbace_go_generic_A_const_183 *lang.Var

var A_arbace_go_generic_A_const_184 *lang.Var

var A_arbace_go_generic_A_const_185 *lang.Keyword

var A_arbace_go_generic_A_init jrt.ClassInit

func A_arbace_go_generic_A_Init() { if !A_arbace_go_generic_A_init.Done() { A_arbace_go_generic_A_init.Run(A_arbace_go_generic_A_clinit) } }

func A_arbace_go_generic_A_clinit() { A_arbace_go_generic_A_clinit_p0(); A_arbace_go_generic_A_clinit_p1(); A_arbace_go_generic_A_clinit_p2(); A_arbace_go_generic_A_clinit_p3(); A_arbace_go_generic_A_clinit_p4(); A_arbace_go_generic_A_clinit_p5(); A_arbace_go_generic_A_clinit_p6(); A_arbace_go_generic_A_clinit_p7(); A_arbace_go_generic_A_clinit_p8(); A_arbace_go_generic_A_clinit_p9(); A_arbace_go_generic_A_clinit_p10(); A_arbace_go_generic_A_clinit_p11(); A_arbace_go_generic_A_clinit_p12(); A_arbace_go_generic_A_clinit_p13(); A_arbace_go_generic_A_clinit_p14() }

func A_arbace_go_generic_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_generic_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 273); A_arbace_go_generic_A_const_0 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[87]); A_arbace_go_generic_A_const_1 = A_arbace_go_generic_A_const_pool.A[88]; A_arbace_go_generic_A_const_2 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[89]); A_arbace_go_generic_A_const_3 = A_arbace_go_generic_A_const_pool.A[90]; A_arbace_go_generic_A_const_4 = A_arbace_go_generic_A_const_pool.A[91]; A_arbace_go_generic_A_const_5 = A_arbace_go_generic_A_const_pool.A[92]; A_arbace_go_generic_A_const_6 = A_arbace_go_generic_A_const_pool.A[93]; A_arbace_go_generic_A_const_7 = A_arbace_go_generic_A_const_pool.A[94]; A_arbace_go_generic_A_const_8 = A_arbace_go_generic_A_const_pool.A[95]; A_arbace_go_generic_A_const_9 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[96]); A_arbace_go_generic_A_const_10 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[97]); A_arbace_go_generic_A_const_11 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[98]); A_arbace_go_generic_A_const_12 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[99]) }

func A_arbace_go_generic_A_clinit_p1() { A_arbace_go_generic_A_const_13 = A_arbace_go_generic_A_const_pool.A[100]; A_arbace_go_generic_A_const_14 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[101]); A_arbace_go_generic_A_const_15 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[102]); A_arbace_go_generic_A_const_16 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[103]); A_arbace_go_generic_A_const_17 = A_arbace_go_generic_A_const_pool.A[104]; A_arbace_go_generic_A_const_18 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[105]); A_arbace_go_generic_A_const_19 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[106]); A_arbace_go_generic_A_const_20 = A_arbace_go_generic_A_const_pool.A[107]; A_arbace_go_generic_A_const_21 = A_arbace_go_generic_A_const_pool.A[108]; A_arbace_go_generic_A_const_22 = A_arbace_go_generic_A_const_pool.A[109]; A_arbace_go_generic_A_const_23 = A_arbace_go_generic_A_const_pool.A[110]; A_arbace_go_generic_A_const_24 = A_arbace_go_generic_A_const_pool.A[111]; A_arbace_go_generic_A_const_25 = A_arbace_go_generic_A_const_pool.A[112]; A_arbace_go_generic_A_const_26 = A_arbace_go_generic_A_const_pool.A[113] }

func A_arbace_go_generic_A_clinit_p2() { A_arbace_go_generic_A_const_27 = A_arbace_go_generic_A_const_pool.A[114]; A_arbace_go_generic_A_const_28 = A_arbace_go_generic_A_const_pool.A[115]; A_arbace_go_generic_A_const_29 = A_arbace_go_generic_A_const_pool.A[116]; A_arbace_go_generic_A_const_30 = A_arbace_go_generic_A_const_pool.A[117]; A_arbace_go_generic_A_const_31 = A_arbace_go_generic_A_const_pool.A[118]; A_arbace_go_generic_A_const_32 = A_arbace_go_generic_A_const_pool.A[119]; A_arbace_go_generic_A_const_33 = A_arbace_go_generic_A_const_pool.A[120]; A_arbace_go_generic_A_const_34 = A_arbace_go_generic_A_const_pool.A[121]; A_arbace_go_generic_A_const_35 = A_arbace_go_generic_A_const_pool.A[122]; A_arbace_go_generic_A_const_36 = A_arbace_go_generic_A_const_pool.A[123]; A_arbace_go_generic_A_const_37 = A_arbace_go_generic_A_const_pool.A[124]; A_arbace_go_generic_A_const_38 = A_arbace_go_generic_A_const_pool.A[125]; A_arbace_go_generic_A_const_39 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[126]); A_arbace_go_generic_A_const_40 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[127]); A_arbace_go_generic_A_const_41 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[128]) }

func A_arbace_go_generic_A_clinit_p3() { A_arbace_go_generic_A_const_42 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[129]); A_arbace_go_generic_A_const_43 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[130]); A_arbace_go_generic_A_const_44 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[131]); A_arbace_go_generic_A_const_45 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[132]); A_arbace_go_generic_A_const_46 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[133]); A_arbace_go_generic_A_const_47 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[134]); A_arbace_go_generic_A_const_48 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[135]); A_arbace_go_generic_A_const_49 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[136]); A_arbace_go_generic_A_const_50 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[137]); A_arbace_go_generic_A_const_51 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[138]); A_arbace_go_generic_A_const_52 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[139]); A_arbace_go_generic_A_const_53 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[140]) }

func A_arbace_go_generic_A_clinit_p4() { A_arbace_go_generic_A_const_54 = A_arbace_go_generic_A_const_pool.A[141]; A_arbace_go_generic_A_const_55 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[142]); A_arbace_go_generic_A_const_56 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[143]); A_arbace_go_generic_A_const_57 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[144]); A_arbace_go_generic_A_const_58 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[145]); A_arbace_go_generic_A_const_59 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[146]); A_arbace_go_generic_A_const_60 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[147]); A_arbace_go_generic_A_const_61 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[148]); A_arbace_go_generic_A_const_62 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[149]); A_arbace_go_generic_A_const_63 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[150]); A_arbace_go_generic_A_const_64 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[151]); A_arbace_go_generic_A_const_65 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[152]) }

func A_arbace_go_generic_A_clinit_p5() { A_arbace_go_generic_A_const_66 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[153]); A_arbace_go_generic_A_const_67 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[154]); A_arbace_go_generic_A_const_68 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[155]); A_arbace_go_generic_A_const_69 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[156]); A_arbace_go_generic_A_const_70 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[157]); A_arbace_go_generic_A_const_71 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[158]); A_arbace_go_generic_A_const_72 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[159]); A_arbace_go_generic_A_const_73 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[160]); A_arbace_go_generic_A_const_74 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[161]); A_arbace_go_generic_A_const_75 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[162]); A_arbace_go_generic_A_const_76 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[163]); A_arbace_go_generic_A_const_77 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[164]) }

func A_arbace_go_generic_A_clinit_p6() { A_arbace_go_generic_A_const_78 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[165]); A_arbace_go_generic_A_const_79 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[166]); A_arbace_go_generic_A_const_80 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[167]); A_arbace_go_generic_A_const_81 = A_arbace_go_generic_A_const_pool.A[168]; A_arbace_go_generic_A_const_82 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[169]); A_arbace_go_generic_A_const_83 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[170]); A_arbace_go_generic_A_const_84 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[171]); A_arbace_go_generic_A_const_85 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[172]); A_arbace_go_generic_A_const_86 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[173]); A_arbace_go_generic_A_const_87 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[174]); A_arbace_go_generic_A_const_88 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[175]); A_arbace_go_generic_A_const_89 = A_arbace_go_generic_A_const_pool.A[176] }

func A_arbace_go_generic_A_clinit_p7() { A_arbace_go_generic_A_const_90 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[177]); A_arbace_go_generic_A_const_91 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[178]); A_arbace_go_generic_A_const_92 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[179]); A_arbace_go_generic_A_const_93 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[180]); A_arbace_go_generic_A_const_94 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[181]); A_arbace_go_generic_A_const_95 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[182]); A_arbace_go_generic_A_const_96 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[183]); A_arbace_go_generic_A_const_97 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[184]); A_arbace_go_generic_A_const_98 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[185]); A_arbace_go_generic_A_const_99 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[186]); A_arbace_go_generic_A_const_100 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[187]); A_arbace_go_generic_A_const_101 = A_arbace_go_generic_A_const_pool.A[188] }

func A_arbace_go_generic_A_clinit_p8() { A_arbace_go_generic_A_const_102 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[189]); A_arbace_go_generic_A_const_103 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[190]); A_arbace_go_generic_A_const_104 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[191]); A_arbace_go_generic_A_const_105 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[192]); A_arbace_go_generic_A_const_106 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[193]); A_arbace_go_generic_A_const_107 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[194]); A_arbace_go_generic_A_const_108 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[195]); A_arbace_go_generic_A_const_109 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[196]); A_arbace_go_generic_A_const_110 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[197]); A_arbace_go_generic_A_const_111 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[198]); A_arbace_go_generic_A_const_112 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[199]); A_arbace_go_generic_A_const_113 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[200]) }

func A_arbace_go_generic_A_clinit_p9() { A_arbace_go_generic_A_const_114 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[201]); A_arbace_go_generic_A_const_115 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[202]); A_arbace_go_generic_A_const_116 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[203]); A_arbace_go_generic_A_const_117 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[204]); A_arbace_go_generic_A_const_118 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[205]); A_arbace_go_generic_A_const_119 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[206]); A_arbace_go_generic_A_const_120 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[207]); A_arbace_go_generic_A_const_121 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[208]); A_arbace_go_generic_A_const_122 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[209]); A_arbace_go_generic_A_const_123 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[210]); A_arbace_go_generic_A_const_124 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[211]); A_arbace_go_generic_A_const_125 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[212]) }

func A_arbace_go_generic_A_clinit_p10() { A_arbace_go_generic_A_const_126 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[213]); A_arbace_go_generic_A_const_127 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[214]); A_arbace_go_generic_A_const_128 = A_arbace_go_generic_A_const_pool.A[215]; A_arbace_go_generic_A_const_129 = A_arbace_go_generic_A_const_pool.A[216]; A_arbace_go_generic_A_const_130 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[217]); A_arbace_go_generic_A_const_131 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[218]); A_arbace_go_generic_A_const_132 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[219]); A_arbace_go_generic_A_const_133 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[220]); A_arbace_go_generic_A_const_134 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[221]); A_arbace_go_generic_A_const_135 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[222]); A_arbace_go_generic_A_const_136 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[223]); A_arbace_go_generic_A_const_137 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[224]) }

func A_arbace_go_generic_A_clinit_p11() { A_arbace_go_generic_A_const_138 = A_arbace_go_generic_A_const_pool.A[225]; A_arbace_go_generic_A_const_139 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[226]); A_arbace_go_generic_A_const_140 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[227]); A_arbace_go_generic_A_const_141 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[228]); A_arbace_go_generic_A_const_142 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[229]); A_arbace_go_generic_A_const_143 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[230]); A_arbace_go_generic_A_const_144 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[231]); A_arbace_go_generic_A_const_145 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[232]); A_arbace_go_generic_A_const_146 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[233]); A_arbace_go_generic_A_const_147 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[234]); A_arbace_go_generic_A_const_148 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[235]); A_arbace_go_generic_A_const_149 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[236]) }

func A_arbace_go_generic_A_clinit_p12() { A_arbace_go_generic_A_const_150 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[237]); A_arbace_go_generic_A_const_151 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[238]); A_arbace_go_generic_A_const_152 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[239]); A_arbace_go_generic_A_const_153 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[240]); A_arbace_go_generic_A_const_154 = A_arbace_go_generic_A_const_pool.A[241]; A_arbace_go_generic_A_const_155 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[242]); A_arbace_go_generic_A_const_156 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[243]); A_arbace_go_generic_A_const_157 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[244]); A_arbace_go_generic_A_const_158 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[245]); A_arbace_go_generic_A_const_159 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[246]); A_arbace_go_generic_A_const_160 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[247]); A_arbace_go_generic_A_const_161 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[248]) }

func A_arbace_go_generic_A_clinit_p13() { A_arbace_go_generic_A_const_162 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[249]); A_arbace_go_generic_A_const_163 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[250]); A_arbace_go_generic_A_const_164 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[251]); A_arbace_go_generic_A_const_165 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[252]); A_arbace_go_generic_A_const_166 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[253]); A_arbace_go_generic_A_const_167 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[254]); A_arbace_go_generic_A_const_168 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[255]); A_arbace_go_generic_A_const_169 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[256]); A_arbace_go_generic_A_const_170 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[257]); A_arbace_go_generic_A_const_171 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[258]); A_arbace_go_generic_A_const_172 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[259]); A_arbace_go_generic_A_const_173 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[260]) }

func A_arbace_go_generic_A_clinit_p14() { A_arbace_go_generic_A_const_174 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[261]); A_arbace_go_generic_A_const_175 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[262]); A_arbace_go_generic_A_const_176 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[263]); A_arbace_go_generic_A_const_177 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[264]); A_arbace_go_generic_A_const_178 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[265]); A_arbace_go_generic_A_const_179 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[266]); A_arbace_go_generic_A_const_180 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[267]); A_arbace_go_generic_A_const_181 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[268]); A_arbace_go_generic_A_const_182 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[269]); A_arbace_go_generic_A_const_183 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[270]); A_arbace_go_generic_A_const_184 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[271]); A_arbace_go_generic_A_const_185 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[272]) }

func A_arbace_go_generic_A_New() *A_arbace_go_generic_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_A{}; t.Ctor(); return t }

func (t *A_arbace_go_generic_A) Ctor() {}

func (t *A_arbace_go_generic_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_generic_A) GetClass__Class() *jrt.Class { return A_arbace_go_generic_A_class }

func (t *A_arbace_go_generic_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_generic_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_generic_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_generic_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_generic_A); return ok }

func A_arbace_go_generic_A_Cast(x any) *A_arbace_go_generic_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_generic_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_generic_A_class)) }; return v }



type A_arbace_go_generic_arg_form_A struct{ j2g_header uint64 }

var A_arbace_go_generic_arg_form_A_fn_class *jrt.Class



type A_arbace_go_generic_callee_name_A struct{ j2g_header uint64 }

var A_arbace_go_generic_callee_name_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_generic_check_errors_BANG__A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A struct{ j2g_header uint64 }

var A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A struct{ j2g_header uint64; F_iter__278000018, F_s__278000019 any }

var A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A struct{ j2g_header uint64; F_b__278000021 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A struct{ j2g_header uint64 }

var A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A struct{ j2g_header uint64; F_iter__278000028, F_s__278000029 any }

var A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A struct{ j2g_header uint64; F_b__278000031 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_fn_class *jrt.Class



type A_arbace_go_generic_desc__GT_type_A struct{ j2g_header uint64 }

var A_arbace_go_generic_desc__GT_type_A_fn_class *jrt.Class



type A_arbace_go_generic_desc__GT_type_fn__278000058_A struct{ j2g_header uint64; F_sub any }

var A_arbace_go_generic_desc__GT_type_fn__278000058_A_fn_class *jrt.Class



type A_arbace_go_generic_desc__GT_type_sub__278000052_A struct{ j2g_header uint64; F_env any }

var A_arbace_go_generic_desc__GT_type_sub__278000052_A_fn_class *jrt.Class



type A_arbace_go_generic_desc__GT_type_unknown__278000054_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_generic_desc__GT_type_unknown__278000054_A_fn_class *jrt.Class



type A_arbace_go_generic_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_generic_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_generic_eval278000004_A struct{ jrt.Object }

func A_arbace_go_generic_eval278000004_A_New() *A_arbace_go_generic_eval278000004_A { t := &A_arbace_go_generic_eval278000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_generic_eval278000004_A) Ctor() {}

func (t *A_arbace_go_generic_eval278000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_generic_eval278000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_generic_eval278000004_A_class }

func (t *A_arbace_go_generic_eval278000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_generic_eval278000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_generic_eval278000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_generic_eval278000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_generic_eval278000004_A); return ok }

func A_arbace_go_generic_eval278000004_A_Cast(x any) *A_arbace_go_generic_eval278000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_generic_eval278000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_generic_eval278000004_A_class)) }; return v }



type A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A struct{ j2g_header uint64 }

var A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A_fn_class *jrt.Class



type A_arbace_go_generic_eval278000008_A struct{ jrt.Object }

func A_arbace_go_generic_eval278000008_A_New() *A_arbace_go_generic_eval278000008_A { t := &A_arbace_go_generic_eval278000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_generic_eval278000008_A) Ctor() {}

func (t *A_arbace_go_generic_eval278000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_generic_eval278000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_generic_eval278000008_A_class }

func (t *A_arbace_go_generic_eval278000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_generic_eval278000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_generic_eval278000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_generic_eval278000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_generic_eval278000008_A); return ok }

func A_arbace_go_generic_eval278000008_A_Cast(x any) *A_arbace_go_generic_eval278000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_generic_eval278000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_generic_eval278000008_A_class)) }; return v }



type A_arbace_go_generic_eval278000008_fn__278000009_A struct{ j2g_header uint64 }

var A_arbace_go_generic_eval278000008_fn__278000009_A_fn_class *jrt.Class



type A_arbace_go_generic_generic_fn_A struct{ j2g_header uint64 }

var A_arbace_go_generic_generic_fn_A_fn_class *jrt.Class



type A_arbace_go_generic_infer_targs_A struct{ j2g_header uint64 }

var A_arbace_go_generic_infer_targs_A_fn_class *jrt.Class



type A_arbace_go_generic_infer_targs_fn__278000082_A struct{ j2g_header uint64; F_cname any }

var A_arbace_go_generic_infer_targs_fn__278000082_A_fn_class *jrt.Class



type A_arbace_go_generic_instance_fn_A struct{ j2g_header uint64 }

var A_arbace_go_generic_instance_fn_A_fn_class *jrt.Class



type A_arbace_go_generic_instantiate_A struct{ j2g_header uint64 }

var A_arbace_go_generic_instantiate_A_fn_class *jrt.Class



type A_arbace_go_generic_instantiate_fn__278000104_A struct{ j2g_header uint64 }

var A_arbace_go_generic_instantiate_fn__278000104_A_fn_class *jrt.Class



type A_arbace_go_generic_instantiate_fn__278000106_A struct{ j2g_header uint64; F_env any }

var A_arbace_go_generic_instantiate_fn__278000106_A_fn_class *jrt.Class



type A_arbace_go_generic_operand_A struct{ j2g_header uint64 }

var A_arbace_go_generic_operand_A_fn_class *jrt.Class



type A_arbace_go_generic_params_for_A struct{ j2g_header uint64 }

var A_arbace_go_generic_params_for_A_fn_class *jrt.Class



type A_arbace_go_generic_params_for_fn__278000074_A struct{ j2g_header uint64 }

var A_arbace_go_generic_params_for_fn__278000074_A_fn_class *jrt.Class



type A_arbace_go_generic_params_for_fn__278000076_A struct{ j2g_header uint64; F_variadic any; F_np int32 }

var A_arbace_go_generic_params_for_fn__278000076_A_fn_class *jrt.Class



type A_arbace_go_generic_receiver_targs_A struct{ j2g_header uint64 }

var A_arbace_go_generic_receiver_targs_A_fn_class *jrt.Class



type A_arbace_go_generic_rehome_A struct{ j2g_header uint64 }

var A_arbace_go_generic_rehome_A_fn_class *jrt.Class



type A_arbace_go_generic_rehome_fn__278000045_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_generic_rehome_fn__278000045_A_fn_class *jrt.Class



type A_arbace_go_generic_rehome_r__278000042_A struct{ j2g_header uint64; F_env any }

var A_arbace_go_generic_rehome_r__278000042_A_fn_class *jrt.Class



type A_arbace_go_generic_resolve_instance_A struct{ j2g_header uint64 }

var A_arbace_go_generic_resolve_instance_A_fn_class *jrt.Class



type A_arbace_go_generic_resolve_instance_fn__278000095_A struct{ j2g_header uint64 }

var A_arbace_go_generic_resolve_instance_fn__278000095_A_fn_class *jrt.Class



type A_arbace_go_generic_resolve_instance_fn__278000097_A struct{ j2g_header uint64; F_env, F_k any }

var A_arbace_go_generic_resolve_instance_fn__278000097_A_fn_class *jrt.Class



type A_arbace_go_generic_tparams_of_A struct{ j2g_header uint64 }

var A_arbace_go_generic_tparams_of_A_fn_class *jrt.Class



type A_arbace_go_generic_type_instance_A struct{ j2g_header uint64 }

var A_arbace_go_generic_type_instance_A_fn_class *jrt.Class



type A_arbace_go_generic_type_instance_fn__278000110_A struct{ j2g_header uint64 }

var A_arbace_go_generic_type_instance_fn__278000110_A_fn_class *jrt.Class



type A_arbace_go_generic_type_instance_fn__278000112_A struct{ j2g_header uint64; F_env any }

var A_arbace_go_generic_type_instance_fn__278000112_A_fn_class *jrt.Class



type A_arbace_go_generic_type_summary_A struct{ j2g_header uint64 }

var A_arbace_go_generic_type_summary_A_fn_class *jrt.Class



type A_arbace_go_generic_with_checker_A struct{ j2g_header uint64 }

var A_arbace_go_generic_with_checker_A_fn_class *jrt.Class
