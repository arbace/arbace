//line aot_arbace_go_generic.ae:1
package aot_arbace_go_generic

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_build"
	"arbace/aot_arbace_go_check_code"
	"arbace/aot_arbace_go_check_decl"
	"arbace/aot_arbace_go_check_env"
	"arbace/aot_arbace_go_check_types"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A_New() *A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_generic_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_1); lang.IFn_Cast(A_arbace_go_generic_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_go_generic_A_const_3, A_arbace_go_generic_A_const_4, A_arbace_go_generic_A_const_5, A_arbace_go_generic_A_const_6, A_arbace_go_generic_A_const_7, A_arbace_go_generic_A_const_8); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_31)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_32)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_generic_eval278000008_fn__278000009_A_New() *A_arbace_go_generic_eval278000008_fn__278000009_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_eval278000008_fn__278000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_generic_eval278000008_fn__278000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_generic_eval278000008_fn__278000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_9.GetRawRoot__O()); var tmp2 any; var root_20 any = A_arbace_go_generic_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_go_generic_A_const_11; if linked_21 == nil { tmp2 = ifn_22.Invoke_O__O(arg_23) } else { tmp2 = linked_21.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_20, arg_23) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_generic_A_const_12.GetRawRoot__O(), A_arbace_go_generic_A_const_13) }
























func A_arbace_go_generic_with_checker_A_New() *A_arbace_go_generic_with_checker_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_with_checker_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_go_generic_with_checker_A) Ctor() {}
//line :26:1
func (t *A_arbace_go_generic_with_checker_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, ctx__2, body__3 any) any { var root_24 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_15.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_17); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp4 any; var root_34 any = A_arbace_go_generic_A_const_18.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = A_arbace_go_generic_A_const_19.GetRawRoot__O(); var arg_38 any; var root_39 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_15.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_20); var tmp7 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(ctx__2); var tmp8 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_21); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp10 any; var root_66 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var root_70 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_22); var arg_74 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp12 any; var root_75 any = A_arbace_go_generic_A_const_18.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = A_arbace_go_generic_A_const_19.GetRawRoot__O(); var arg_79 any; var root_80 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var root_84 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; if linked_85 == nil { arg_83 = ifn_86.Invoke__O() } else { arg_83 = linked_85.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O__O(root_84) }; if linked_81 == nil { arg_79 = ifn_82.Invoke_O__O(arg_83) } else { arg_79 = linked_81.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_80, arg_83) }; if linked_76 == nil { tmp12 = ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { tmp12 = linked_76.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_75, arg_78, arg_79) }; arg_74 = tmp11.Invoke_O__O(tmp12); if linked_71 == nil { arg_69 = ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) }; if linked_67 == nil { tmp10 = ifn_68.Invoke_O__O(arg_69) } else { tmp10 = linked_67.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_66, arg_69) }; var tmp13 any = tmp9.Invoke_O__O(tmp10); var tmp14 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_23); var tmp15 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(nil); var tmp16 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_24); var tmp17 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(nil); var tmp18 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_25); var tmp19 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_26); var tmp20 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_27); var tmp21 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_28); var tmp22 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_29); var tmp23 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_30); var tmp24 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_31); var tmp25 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_32); var tmp26 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_33); var tmp27 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_34); var tmp28 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_35); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp30 any; var root_87 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_15.GetRawRoot__O()); var tmp32 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_36); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()); var tmp34 any; var root_97 any = A_arbace_go_generic_A_const_18.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = A_arbace_go_generic_A_const_19.GetRawRoot__O(); var arg_101 any; var root_102 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any; var root_106 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_37); var arg_110 any = lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(A_arbace_go_generic_A_const_38); if linked_107 == nil { arg_105 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { arg_105 = linked_107.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_106, arg_109, arg_110) }; if linked_103 == nil { arg_101 = ifn_104.Invoke_O__O(arg_105) } else { arg_101 = linked_103.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_102, arg_105) }; if linked_98 == nil { tmp34 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { tmp34 = linked_98.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }; arg_90 = tmp31.Invoke_O_O_O__O(tmp32, tmp33.Invoke_O__O(tmp34), lang.IFn_Cast(A_arbace_go_generic_A_const_16.GetRawRoot__O()).Invoke_O__O(nil)); if linked_88 == nil { tmp30 = ifn_89.Invoke_O__O(arg_90) } else { tmp30 = linked_88.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_87, arg_90) }; arg_42 = tmp5.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp6, tmp7, tmp8, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29.Invoke_O__O(tmp30)); if linked_40 == nil { arg_38 = ifn_41.Invoke_O__O(arg_42) } else { arg_38 = linked_40.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_39, arg_42) }; if linked_35 == nil { tmp4 = ifn_36.Invoke_O_O__O(arg_37, arg_38) } else { tmp4 = linked_35.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_34, arg_37, arg_38) }; arg_27 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), body__3); if linked_25 == nil { return ifn_26.Invoke_O__O(arg_27) } else { return linked_25.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_24, arg_27) } }















func A_arbace_go_generic_check_errors_BANG__A_New() *A_arbace_go_generic_check_errors_BANG__A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_go_generic_check_errors_BANG__A) Ctor() {}
//line :42:1
func (t *A_arbace_go_generic_check_errors_BANG__A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any; var root_111 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_113 lang.IFn; if


	linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var root_115 any = A_arbace_go_generic_A_const_10.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = A_arbace_go_generic_A_const_39.Get__O(); if linked_116 == nil { arg_114 = ifn_117.Invoke_O__O(arg_118) } else { arg_114 = linked_116.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_115, arg_118) }; if linked_112 == nil { temp__1927000414__auto____1 = ifn_113.Invoke_O__O(arg_114) } else { temp__1927000414__auto____1 = linked_112.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_111, arg_114) }; if jrt.J2g_Truth(temp__1927000414__auto____1) { var errs__2 any = temp__1927000414__auto____1; var tmp1 any; var root_119 any = A_arbace_go_generic_A_const_40.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_121 lang.IFn
		if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_3, nil); var tmp3 any; var root_124 any = A_arbace_go_generic_A_const_41.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = Lit_4; var arg_128 any; var iter__1927001039__auto____5 any; var fnbody__190 any = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_New(); var tmp4 *jrt.Class; var fncls__189 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_fn_class; if fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_fn_class = fncls__189d; tmp4 = fncls__189d } else { tmp4 = fncls__189 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__190, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp6 any; var root_191 any = A_arbace_go_generic_A_const_53.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = A_arbace_go_generic_A_const_54; var arg_195 any = errs__2; if linked_192 == nil { tmp6 = ifn_193.Invoke_O_O__O(arg_194, arg_195) } else { tmp6 = linked_192.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_191, arg_194, arg_195) }; arg_128 = tmp5.Invoke_O__O(tmp6); if linked_125 == nil { tmp3 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { tmp3 = linked_125.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) }; arg_122 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_123 any; var tmp7 any = A_arbace_go_generic_A_const_55; var tmp8 any; var root_196 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_198 lang.IFn
		if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any; var iter__1927001039__auto____3 any; var fnbody__273 any = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_New(); var tmp9 *jrt.Class; var fncls__272 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_fn_class; if fncls__272 == nil { var fncls__272d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_fn_class = fncls__272d; tmp9 = fncls__272d } else { tmp9 = fncls__272 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__273, tmp9, nil); arg_199 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(errs__2); if linked_197 == nil { tmp8 = ifn_198.Invoke_O__O(arg_199) } else { tmp8 = linked_197.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_196, arg_199) }
//line :46:1
		arg_123 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)); if linked_120 == nil { tmp1 = ifn_121.Invoke_O_O__O(arg_122, arg_123) } else { tmp1 = linked_120.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_119, arg_122, arg_123) }
//line :45:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } else { return nil } }
func A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_New() *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A) Ctor() {}
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A) Invoke_O_O__O(self, s__278000019__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__188 any = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_New_O_O(self, s__278000019__1); var tmp2 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_fn_class; if fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__188); A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_fn_class = fncls__187d; tmp2 = fncls__187d } else { tmp2 = fncls__187 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__188, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :46:1
func A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_New_O_O(p0, p1 any) *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A{}; t.Ctor_O_O(p0, p1); return t }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A) Ctor_O_O(c__iter__278000018, c__s__278000019 any) { t.F_iter__278000018 = c__iter__278000018; t.F_s__278000019 = c__s__278000019 }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A) Invoke_O__O(self any) any { { var s__278000019__1 any; var t_ any = t.F_s__278000019; t.F_s__278000019 = nil; s__278000019__1 = t_; for { var temp__1927000414__auto____2 any; var root_129 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = s__278000019__1; if linked_130 == nil { temp__1927000414__auto____2 = ifn_131.Invoke_O__O(arg_132) } else { temp__1927000414__auto____2 = linked_130.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_129, arg_132) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__278000019__3 any = temp__1927000414__auto____2; var tmp1 any; var root_133 any = A_arbace_go_generic_A_const_42.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = s__278000019__3; if linked_134 == nil { tmp1 = ifn_135.Invoke_O__O(arg_136) } else { tmp1 = linked_134.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_133, arg_136) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_137 any = A_arbace_go_generic_A_const_43.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = s__278000019__3; if linked_138 == nil { c__1927001037__auto____4 = ifn_139.Invoke_O__O(arg_140) } else { c__1927001037__auto____4 = linked_138.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_137, arg_140) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__278000021__6 any; var root_141 any = A_arbace_go_generic_A_const_44.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_142 == nil { b__278000021__6 = ifn_143.Invoke_O__O(arg_144) } else { b__278000021__6 = linked_142.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_141, arg_144) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__151 any = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_New_O_I_O(b__278000021__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__151); A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_fn_class = fncls__150d; tmp3 = fncls__150d } else { tmp3 = fncls__150 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__151, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_152 any = A_arbace_go_generic_A_const_47.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any; var root_157 any = A_arbace_go_generic_A_const_48.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = b__278000021__6; if linked_158 == nil { arg_155 = ifn_159.Invoke_O__O(arg_160) } else { arg_155 = linked_158.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_157, arg_160) }; var arg_156 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__278000018); var tmp5 any; var root_161 any = A_arbace_go_generic_A_const_49.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = s__278000019__3; if linked_162 == nil { tmp5 = ifn_163.Invoke_O__O(arg_164) } else { tmp5 = linked_162.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_161, arg_164) }; arg_156 = tmp4.Invoke_O__O(tmp5); if linked_153 == nil { return ifn_154.Invoke_O_O__O(arg_155, arg_156) } else { return linked_153.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_152, arg_155, arg_156) } } else { var root_165 any = A_arbace_go_generic_A_const_47.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any; var root_170 any = A_arbace_go_generic_A_const_48.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = b__278000021__6; if linked_171 == nil { arg_168 = ifn_172.Invoke_O__O(arg_173) } else { arg_168 = linked_171.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_170, arg_173) }; var arg_169 any; if linked_166 == nil { return ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { return linked_166.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) } } } else { var er__4 any; var root_174 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = s__278000019__3; if linked_175 == nil { er__4 = ifn_176.Invoke_O__O(arg_177) } else { er__4 = linked_175.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_174, arg_177) }; var root_178 any = A_arbace_go_generic_A_const_51.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_generic_A_const_46.Invoke_O__O(er__4))).Ref(); var arg_182 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__278000018); var tmp7 any; var root_183 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = s__278000019__3; if linked_184 == nil { tmp7 = ifn_185.Invoke_O__O(arg_186) } else { tmp7 = linked_184.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_183, arg_186) }; arg_182 = tmp6.Invoke_O__O(tmp7); if linked_179 == nil { return ifn_180.Invoke_O_O__O(arg_181, arg_182) } else { return linked_179.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_178, arg_181, arg_182) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :46:1
func A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A) Ctor_O_I_O(c__b__278000021 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__278000021 = c__b__278000021; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :46:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A) Invoke_O__O(self any) any { { var i__278000020__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__278000020__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var er__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__278000020__1)); var root_145 any = A_arbace_go_generic_A_const_45.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = t.F_b__278000021; var arg_149 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_go_generic_A_const_46.Invoke_O__O(er__2))).Ref(); if linked_146 == nil { ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { linked_146.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }; i__278000020__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__278000020__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_New() *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A) Ctor() {}
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A) Invoke_O_O__O(self, s__278000029__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__271 any = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_New_O_O(self, s__278000029__1); var tmp2 *jrt.Class; var fncls__270 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_fn_class; if fncls__270 == nil { var fncls__270d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__271); A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_fn_class = fncls__270d; tmp2 = fncls__270d } else { tmp2 = fncls__270 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__271, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :47:1
func A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_New_O_O(p0, p1 any) *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A{}; t.Ctor_O_O(p0, p1); return t }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A) Ctor_O_O(c__iter__278000028, c__s__278000029 any) { t.F_iter__278000028 = c__iter__278000028; t.F_s__278000029 = c__s__278000029 }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A) Invoke_O__O(self any) any { { var s__278000029__1 any; var t_ any = t.F_s__278000029; t.F_s__278000029 = nil; s__278000029__1 = t_; for { var temp__1927000414__auto____2 any; var root_200 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = s__278000029__1; if linked_201 == nil { temp__1927000414__auto____2 = ifn_202.Invoke_O__O(arg_203) } else { temp__1927000414__auto____2 = linked_201.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_200, arg_203) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__278000029__3 any = temp__1927000414__auto____2; var tmp1 any; var root_204 any = A_arbace_go_generic_A_const_42.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = s__278000029__3; if linked_205 == nil { tmp1 = ifn_206.Invoke_O__O(arg_207) } else { tmp1 = linked_205.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_204, arg_207) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_208 any = A_arbace_go_generic_A_const_43.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = s__278000029__3; if linked_209 == nil { c__1927001037__auto____4 = ifn_210.Invoke_O__O(arg_211) } else { c__1927001037__auto____4 = linked_209.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_208, arg_211) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__278000031__6 any; var root_212 any = A_arbace_go_generic_A_const_44.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_213 == nil { b__278000031__6 = ifn_214.Invoke_O__O(arg_215) } else { b__278000031__6 = linked_213.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_212, arg_215) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__228 any = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_New_O_I_O(b__278000031__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__228); A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_fn_class = fncls__227d; tmp3 = fncls__227d } else { tmp3 = fncls__227 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__228, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_229 any = A_arbace_go_generic_A_const_47.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any; var root_234 any = A_arbace_go_generic_A_const_48.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = b__278000031__6; if linked_235 == nil { arg_232 = ifn_236.Invoke_O__O(arg_237) } else { arg_232 = linked_235.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_234, arg_237) }; var arg_233 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__278000028); var tmp5 any; var root_238 any = A_arbace_go_generic_A_const_49.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = s__278000029__3; if linked_239 == nil { tmp5 = ifn_240.Invoke_O__O(arg_241) } else { tmp5 = linked_239.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_238, arg_241) }; arg_233 = tmp4.Invoke_O__O(tmp5); if linked_230 == nil { return ifn_231.Invoke_O_O__O(arg_232, arg_233) } else { return linked_230.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_229, arg_232, arg_233) } } else { var root_242 any = A_arbace_go_generic_A_const_47.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any; var root_247 any = A_arbace_go_generic_A_const_48.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = b__278000031__6; if linked_248 == nil { arg_245 = ifn_249.Invoke_O__O(arg_250) } else { arg_245 = linked_248.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_247, arg_250) }; var arg_246 any; if linked_243 == nil { return ifn_244.Invoke_O_O__O(arg_245, arg_246) } else { return linked_243.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_242, arg_245, arg_246) } } } else { var er__4 any; var root_251 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = s__278000029__3; if linked_252 == nil { er__4 = ifn_253.Invoke_O__O(arg_254) } else { er__4 = linked_252.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_251, arg_254) }; var root_255 any = A_arbace_go_generic_A_const_51.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any; var root_260 any = A_arbace_go_generic_A_const_57.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = er__4; var arg_264 any = A_arbace_go_generic_A_const_58; var arg_265 any = Lit_12; if linked_261 == nil { arg_258 = ifn_262.Invoke_O_O_O__O(arg_263, arg_264, arg_265) } else { arg_258 = linked_261.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_260, arg_263, arg_264, arg_265) }; var arg_259 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__278000028); var tmp7 any; var root_266 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = s__278000029__3; if linked_267 == nil { tmp7 = ifn_268.Invoke_O__O(arg_269) } else { tmp7 = linked_267.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_266, arg_269) }; arg_259 = tmp6.Invoke_O__O(tmp7); if linked_256 == nil { return ifn_257.Invoke_O_O__O(arg_258, arg_259) } else { return linked_256.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_255, arg_258, arg_259) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :47:1
func A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A) Ctor_O_I_O(c__b__278000031 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__278000031 = c__b__278000031; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :47:1
func (t *A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A) Invoke_O__O(self any) any { { var i__278000030__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__278000030__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var er__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__278000030__1)); var root_216 any = A_arbace_go_generic_A_const_45.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = t.F_b__278000031; var arg_220 any; var root_221 any = A_arbace_go_generic_A_const_57.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = er__2; var arg_225 any = A_arbace_go_generic_A_const_58; var arg_226 any = Lit_12; if linked_222 == nil { arg_220 = ifn_223.Invoke_O_O_O__O(arg_224, arg_225, arg_226) } else { arg_220 = linked_222.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_221, arg_224, arg_225, arg_226) }; if linked_217 == nil { ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { linked_217.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }; i__278000030__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__278000030__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_generic_error_BANG__A_New() *A_arbace_go_generic_error_BANG__A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_error_BANG__A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_go_generic_error_BANG__A) Ctor() {}
//line :49:1
func (t *A_arbace_go_generic_error_BANG__A) Invoke_O_O__O(self, msg__0 any) any {


	var root_274 any = A_arbace_go_generic_A_const_59.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = Lit_12; var arg_278 any; var arg_279 any = A_arbace_go_generic_A_const_60; var arg_280 any = msg__0; if linked_275 == nil { return ifn_276.Invoke_O_O_O_O__O(arg_277, arg_278, arg_279, arg_280) } else { return linked_275.(*aot_arbace_go_check_env.A_arbace_go_check_env_error_BANG__A).Invoke_O_O_O_O_O__O(root_274, arg_277, arg_278, arg_279, arg_280)
	}
}

func A_arbace_go_generic_rehome_A_New() *A_arbace_go_generic_rehome_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_rehome_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_generic_rehome_A) Ctor() {}
//line :56:1
func (t *A_arbace_go_generic_rehome_A) Invoke_O_O_O__O(self, ty__0, env__1 any) any { var r__3 any; var fnbody__287 any = A_arbace_go_generic_rehome_r__278000042_A_New_O(env__1); var tmp1 *jrt.Class; var fncls__286 *jrt.Class = A_arbace_go_generic_rehome_r__278000042_A_fn_class; if



	fncls__286 == nil { var fncls__286d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__287); A_arbace_go_generic_rehome_r__278000042_A_fn_class = fncls__286d; tmp1 = fncls__286d } else { tmp1 = fncls__286 }; r__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__287, tmp1, nil); var tmp2 any; var root_288 any =
	A_arbace_go_generic_A_const_62.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_290 lang.IFn; if
	linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = ty__0; if linked_289 == nil { tmp2 = ifn_290.Invoke_O__O(arg_291) } else { tmp2 = linked_289.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_288, arg_291) }; if /*line :61:1*/ jrt.J2g_Truth(tmp2) { return ty__0 } else { var tmp3 any; var root_292 any = A_arbace_go_generic_A_const_63.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_294 lang.IFn

		if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = ty__0; if linked_293 == nil { tmp3 = ifn_294.Invoke_O__O(arg_295) } else { tmp3 = linked_293.(*aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_292, arg_295) }
//line :61:1
		if jrt.J2g_Truth(tmp3) { var i__4 any; var root_296 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_298 lang.IFn


			if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = ty__0; if linked_297 == nil { i__4 = ifn_298.Invoke_O__O(arg_299) } else { i__4 = linked_297.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_296, arg_299) }
			var tmp4 any; var root_300 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_302 lang.IFn
			if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = A_arbace_go_generic_A_const_65.Invoke_O__O(i__4); if linked_301 == nil { tmp4 = ifn_302.Invoke_O__O(arg_303) } else { tmp4 = linked_301.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_300, arg_303) }
//line :65:1
			if jrt.J2g_Truth(tmp4) { var o__5 any = lang.IFn_Cast(r__3).Invoke_O__O(A_arbace_go_generic_A_const_67.Invoke_O__O(i__4)); var ts__6 any; var root_304 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_306 lang.IFn

				if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = r__3; var arg_308 any = A_arbace_go_generic_A_const_65.Invoke_O__O(i__4); if linked_305 == nil { ts__6 = ifn_306.Invoke_O_O__O(arg_307, arg_308) } else { ts__6 = linked_305.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_304, arg_307, arg_308) }
				var tmp5 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(o__5, A_arbace_go_generic_A_const_67.Invoke_O__O(i__4)); if and__1927000168__auto____7 { tmp5 = lang.Util_Equiv_O_O__Z_NoInit(ts__6, A_arbace_go_generic_A_const_65.Invoke_O__O(i__4)) } else { tmp5 = and__1927000168__auto____7 }; if tmp5 { return ty__0 } else { var root_309 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any; var arg_313 any = o__5; var arg_314 any = ts__6; if linked_310 == nil { return ifn_311.Invoke_O_O_O__O(arg_312, arg_313, arg_314) } else { return linked_310.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A).Invoke_O_O_O_O__O(root_309, arg_312, arg_313, arg_314) } } } else {
//line :65:1
					var tmp6 any; var or__1927000174__auto____5 bool = lang.Util_Identical_O_O__Z_NoInit(A_arbace_go_generic_A_const_69.Invoke_O__O(i__4), nil)



					if or__1927000174__auto____5 { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { tmp6 = A_arbace_go_generic_A_const_70.Invoke_O__O(i__4) }
//line :65:1
					if jrt.J2g_Truth(tmp6) { return ty__0 } else { if A_arbace_go_generic_A_const_71 != nil { var or__1927000174__auto____5_2 any = lang.IFn_Cast(A_arbace_go_generic_A_const_72.Invoke_O__O(env__1)).Invoke_O_O__O(A_arbace_go_generic_A_const_69.Invoke_O__O(i__4), A_arbace_go_generic_A_const_78.Invoke_O__O(i__4))




						if jrt.J2g_Truth(or__1927000174__auto____5_2) { return or__1927000174__auto____5_2 } else { return ty__0 } } else {
//line :65:1
							return nil } } } } else {
//line :61:1
								var tmp7 any; var root_315 any = A_arbace_go_generic_A_const_73.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_go_check_types.A_arbace_go_check_types_tparam_QMARK__A_fn_class); var ifn_317 lang.IFn









								if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = ty__0; if linked_316 == nil { tmp7 = ifn_317.Invoke_O__O(arg_318) } else { tmp7 = linked_316.(*aot_arbace_go_check_types.A_arbace_go_check_types_tparam_QMARK__A).Invoke_O_O__O(root_315, arg_318) }
//line :61:1
								if jrt.J2g_Truth(tmp7) { return ty__0 } else { if A_arbace_go_generic_A_const_71 != nil { var G__278000044__4_ any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(0))











									switch lang.Util_Hash_O__I_NoInit(G__278000044__4_) >> 2 & 15 { case 1: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_74) { var tmp8 any = A_arbace_go_generic_A_const_74; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1))), lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)))) }; case 2: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_75) { var tmp9 any = A_arbace_go_generic_A_const_75; return lang.Tuple_Create_O_O__IPersistentVector(tmp9, lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)))) }; case 3: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_76) { var tmp10 any = A_arbace_go_generic_A_const_76; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp10, lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)), lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)))) }; case 6: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_77) { var tmp11 any = A_arbace_go_generic_A_const_77; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)), lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)))) }; case 7: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_79) {







										var root_320 any = A_arbace_go_generic_A_const_80.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = A_arbace_go_generic_A_const_81; var arg_324 any; var root_325 any = A_arbace_go_generic_A_const_82.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = r__3; var arg_329 any; var root_330 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = ty__0; if linked_331 == nil { arg_329 = ifn_332.Invoke_O__O(arg_333) } else { arg_329 = linked_331.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_330, arg_333) }; if linked_326 == nil { arg_324 = ifn_327.Invoke_O_O__O(arg_328, arg_329) } else { arg_324 = linked_326.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_325, arg_328, arg_329) }; if linked_321 == nil { return ifn_322.Invoke_O_O__O(arg_323, arg_324) } else { return linked_321.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_320, arg_323, arg_324) } }
//line :73:1
									case 9: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_83) { var tmp12 any = A_arbace_go_generic_A_const_83; var tmp13 any; var root_334 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_336 lang.IFn





										if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = r__3; var arg_338 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_335 == nil { tmp13 = ifn_336.Invoke_O_O__O(arg_337, arg_338) } else { tmp13 = linked_335.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_334, arg_337, arg_338) }
//line :73:1
										var tmp14 any = tmp13; var tmp15 any; var root_339 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_341 lang.IFn





										if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = r__3; var arg_343 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(2)); if linked_340 == nil { tmp15 = ifn_341.Invoke_O_O__O(arg_342, arg_343) } else { tmp15 = linked_340.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_339, arg_342, arg_343) }
//line :73:1
										return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp12, tmp14, tmp15, lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(3))) }; case 11: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_84) { var tmp16 any = A_arbace_go_generic_A_const_84; return lang.Tuple_Create_O_O__IPersistentVector(tmp16, lang.IFn_Cast(r__3).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)))) }; case 13: if any(G__278000044__4_) == any(A_arbace_go_generic_A_const_85) { var tmp17 any = A_arbace_go_generic_A_const_85; var tmp18 any; var root_344 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_346 lang.IFn






											if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any; var fnbody__356 any = A_arbace_go_generic_rehome_fn__278000045_A_New_O(r__3); var tmp19 *jrt.Class; var fncls__355 *jrt.Class = A_arbace_go_generic_rehome_fn__278000045_A_fn_class; if fncls__355 == nil { var fncls__355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__356); A_arbace_go_generic_rehome_fn__278000045_A_fn_class = fncls__355d; tmp19 = fncls__355d } else { tmp19 = fncls__355 }; arg_347 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__356, tmp19, nil); var arg_348 any = lang.RT_Nth_O_I__O_NoInit(ty__0, lang.RT_IntCast_J__I_NoInit(1)); if linked_345 == nil { tmp18 = ifn_346.Invoke_O_O__O(arg_347, arg_348) } else { tmp18 = linked_345.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_344, arg_347, arg_348) }
//line :73:1
											return lang.Tuple_Create_O_O__IPersistentVector(tmp17, tmp18) }; default:}; return ty__0 } else {
//line :61:1
												return nil } } } } }
//line :60:1
func A_arbace_go_generic_rehome_r__278000042_A_New_O(p0 any) *A_arbace_go_generic_rehome_r__278000042_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_rehome_r__278000042_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_go_generic_rehome_r__278000042_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :60:1
func (t *A_arbace_go_generic_rehome_r__278000042_A) Invoke_O_O__O(self, p1__278000040_SHARP___1 any) any { var root_281 any = A_arbace_go_generic_A_const_61.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, A_arbace_go_generic_rehome_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = p1__278000040_SHARP___1; var arg_285 any = t.F_env; if linked_282 == nil { return ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { return linked_282.(*A_arbace_go_generic_rehome_A).Invoke_O_O_O__O(root_281, arg_284, arg_285) } }



















func A_arbace_go_generic_rehome_fn__278000045_A_New_O(p0 any) *A_arbace_go_generic_rehome_fn__278000045_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_rehome_fn__278000045_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_go_generic_rehome_fn__278000045_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :80:1
func (t *A_arbace_go_generic_rehome_fn__278000045_A) Invoke_O_O__O(self, p1__278000041_SHARP___1 any) any { var root_349 any = A_arbace_go_generic_A_const_86.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = p1__278000041_SHARP___1; var arg_353 any = A_arbace_go_generic_A_const_87; var arg_354 any = t.F_r; if linked_350 == nil { return ifn_351.Invoke_O_O_O__O(arg_352, arg_353, arg_354) } else { return linked_350.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_349, arg_352, arg_353, arg_354) } }







func A_arbace_go_generic_desc__GT_type_A_New() *A_arbace_go_generic_desc__GT_type_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_desc__GT_type_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_go_generic_desc__GT_type_A) Ctor() {}
//line :88:1
func (t *A_arbace_go_generic_desc__GT_type_A) Invoke_O_O_O__O(self, d__0, env__1 any) any { var vec__278000049__3 any; var root_357 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_359 lang.IFn; if


	linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = lang.GoInterp_TypeInfo_O__O1(d__0).Ref(); if linked_358 == nil { vec__278000049__3 = ifn_359.Invoke_O__O(arg_360) } else { vec__278000049__3 = linked_358.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_357, arg_360) }; var kind__4 any = /*line :88:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(0), nil); var named__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(1), nil); var nm__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(2), nil); var pkg__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(3), nil); var elem__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(4), nil); var key__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(5), nil); var n__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(6), nil); var ins__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(7), nil); var outs__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(8), nil); var variadic__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(9), nil); var dir__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(10), nil); var fnames__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(11), nil); var ftypes__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(12), nil); var femb__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(13), nil); var fpkgs__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(14), nil); var nmeth__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000049__3, lang.RT_IntCast_J__I_NoInit(15), nil); var sub__20 any; var fnbody__367 any = A_arbace_go_generic_desc__GT_type_sub__278000052_A_New_O(env__1); var tmp1 *jrt.Class; var fncls__366 *jrt.Class = A_arbace_go_generic_desc__GT_type_sub__278000052_A_fn_class; if


	fncls__366 == nil { var fncls__366d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__367); A_arbace_go_generic_desc__GT_type_sub__278000052_A_fn_class = fncls__366d; tmp1 = fncls__366d } else { tmp1 = fncls__366 }; sub__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__367, tmp1, nil); var unknown__21 any; var fnbody__374 any = /*line :88:1*/A_arbace_go_generic_desc__GT_type_unknown__278000054_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__373 *jrt.Class = A_arbace_go_generic_desc__GT_type_unknown__278000054_A_fn_class; if




	fncls__373 == nil { var fncls__373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__374); A_arbace_go_generic_desc__GT_type_unknown__278000054_A_fn_class = fncls__373d; tmp2 = fncls__373d } else { tmp2 = fncls__373 }; unknown__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__374, tmp2, nil); var G__278000056__22_ any = named__5; switch


	lang.Util_Hash_O__I_NoInit(G__278000056__22_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__278000056__22_, Lit_15) { var temp__1927000408__auto____23 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_go_generic_A_const_90.GetRawRoot__O())).Get_O__O(d__0)
		if jrt.J2g_Truth(temp__1927000408__auto____23) { var ty__24 any = temp__1927000408__auto____23; var root_376 any = A_arbace_go_generic_A_const_61.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, A_arbace_go_generic_rehome_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = ty__24; var arg_380 any = env__1; if linked_377 == nil { return ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { return linked_377.(*A_arbace_go_generic_rehome_A).Invoke_O_O_O__O(root_376, arg_379, arg_380) } } else { return lang.IFn_Cast(unknown__21).Invoke__O() } }
//line :96:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__278000056__22_, Lit_16) { var or__1927000174__auto____23 any = lang.IFn_Cast(A_arbace_go_generic_A_const_72.Invoke_O__O(env__1)).Invoke_O_O__O(pkg__7, nm__6)

		if jrt.J2g_Truth(or__1927000174__auto____23) { return or__1927000174__auto____23 } else { return lang.IFn_Cast(unknown__21).Invoke__O() } }
//line :96:1
	default:}; var tmp3 any; var root_381 any =


	A_arbace_go_generic_A_const_91.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_383 lang.IFn; if
	linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any = A_arbace_go_generic_A_const_92.GetRawRoot__O(); var arg_385 any = kind__4; if linked_382 == nil { tmp3 = ifn_383.Invoke_O_O__O(arg_384, arg_385) } else { tmp3 = linked_382.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_381, arg_384, arg_385) }; if /*line :99:1*/ jrt.J2g_Truth(tmp3) {
		var root_386 any = A_arbace_go_generic_A_const_93.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = kind__4; if linked_387 == nil { return ifn_388.Invoke_O__O(arg_389) } else { return linked_387.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_386, arg_389) } } else {
//line :99:1
			if lang.Util_Equiv_O_O__Z_NoInit(Lit_17, kind__4) { return A_arbace_go_generic_A_const_94 } else { if A_arbace_go_generic_A_const_71 != nil { var G__278000057__23_ any = kind__4



				switch lang.Util_Hash_O__I_NoInit(G__278000057__23_) >> 12 & 15 { case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_18) { var tmp4 any = A_arbace_go_generic_A_const_83; var tmp5 any; var root_391 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_393 lang.IFn





					if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = sub__20; var arg_395 any = ins__11; if linked_392 == nil { tmp5 = ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { tmp5 = linked_392.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) }
//line :103:1
					var tmp6 any = tmp5; var tmp7 any; var root_396 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_398 lang.IFn





					if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = sub__20; var arg_400 any = outs__12; if linked_397 == nil { tmp7 = ifn_398.Invoke_O_O__O(arg_399, arg_400) } else { tmp7 = linked_397.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_396, arg_399, arg_400) }
//line :103:1
					return lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp4, tmp6, tmp7, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(variadic__13)).Ref()) }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_19) { var tmp8 any = A_arbace_go_generic_A_const_75; return lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_20) {











						if lang.Util_Equiv_O_O__Z_NoInit(Lit_21, nm__6) { return A_arbace_go_generic_A_const_95.GetRawRoot__O() } else { if lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(nmeth__19)) { return lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_generic_A_const_96, lang.PersistentVector_EMPTY.Ref(), nil) } else { if A_arbace_go_generic_A_const_71 != nil {

							return lang.IFn_Cast(unknown__21).Invoke__O() } else {
//line :115:1
								return nil } } } }
//line :103:1
				case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_22) { var tmp9 any = A_arbace_go_generic_A_const_76; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp9, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(n__10)).Ref(), lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_23) { var tmp10 any = A_arbace_go_generic_A_const_85; var tmp11 any; var root_401 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_403 lang.IFn






					if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_82.GetRawRoot__O()); var tmp13 *lang.Compiler_AOTFn; var fnbody__430 any = A_arbace_go_generic_desc__GT_type_fn__278000058_A_New_O(sub__20); var tmp14 *jrt.Class; var fncls__429 *jrt.Class = A_arbace_go_generic_desc__GT_type_fn__278000058_A_fn_class; if fncls__429 == nil { var fncls__429d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__430); A_arbace_go_generic_desc__GT_type_fn__278000058_A_fn_class = fncls__429d; tmp14 = fncls__429d } else { tmp14 = fncls__429 }; tmp13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__430, tmp14, nil); arg_404 = tmp12.Invoke_O_O_O_O_O__O(tmp13.Ref(), fnames__15, ftypes__16, femb__17, fpkgs__18); if linked_402 == nil { tmp11 = ifn_403.Invoke_O__O(arg_404) } else { tmp11 = linked_402.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_401, arg_404) }
//line :103:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11) }; case 9: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_25) { var tmp15 any = A_arbace_go_generic_A_const_77; var tmp16 *lang.Keyword; var G__278000061__24_ int64 = lang.RT_LongCast_O__J_NoInit(dir__14)




					L3: switch { default: switch int32(G__278000061__24_) { case 1: if 1 == G__278000061__24_ { tmp16 = A_arbace_go_generic_A_const_98; break L3 }; case 2: if 2 == G__278000061__24_ { tmp16 = A_arbace_go_generic_A_const_99; break L3 }; default:}; tmp16 = A_arbace_go_generic_A_const_100}
//line :103:1
						return lang.Tuple_Create_O_O_O__IPersistentVector(tmp15, tmp16.Ref(), lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; case 10: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_26) { var tmp17 any = A_arbace_go_generic_A_const_74; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp17, lang.IFn_Cast(sub__20).Invoke_O__O(key__9), lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__278000057__23_, Lit_27) { var tmp18 any = A_arbace_go_generic_A_const_84; return lang.Tuple_Create_O_O__IPersistentVector(tmp18, lang.IFn_Cast(sub__20).Invoke_O__O(elem__8)) }; default:
				}













				return lang.IFn_Cast(unknown__21).Invoke__O() } else {
//line :99:1
					return nil } } } }
//line :91:1
func A_arbace_go_generic_desc__GT_type_sub__278000052_A_New_O(p0 any) *A_arbace_go_generic_desc__GT_type_sub__278000052_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_desc__GT_type_sub__278000052_A{}; t.Ctor_O(p0); return t }
//line :91:1
func (t *A_arbace_go_generic_desc__GT_type_sub__278000052_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :91:1
func (t *A_arbace_go_generic_desc__GT_type_sub__278000052_A) Invoke_O_O__O(self, p1__278000048_SHARP___1 any) any {
	var root_361 any = A_arbace_go_generic_A_const_88.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, A_arbace_go_generic_desc__GT_type_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = p1__278000048_SHARP___1; var arg_365 any = t.F_env; if linked_362 == nil { return ifn_363.Invoke_O_O__O(arg_364, arg_365) } else { return linked_362.(*A_arbace_go_generic_desc__GT_type_A).Invoke_O_O_O__O(root_361, arg_364, arg_365) } }
func A_arbace_go_generic_desc__GT_type_unknown__278000054_A_New_O(p0 any) *A_arbace_go_generic_desc__GT_type_unknown__278000054_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_desc__GT_type_unknown__278000054_A{}; t.Ctor_O(p0); return t }
//line :93:1
func (t *A_arbace_go_generic_desc__GT_type_unknown__278000054_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :93:1
func (t *A_arbace_go_generic_desc__GT_type_unknown__278000054_A) Invoke_O__O(self any) any { var tmp1 any; var root_368 any = A_arbace_go_generic_A_const_40.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, lang.GoInterp_TypeName_O__String(t.F_d).Ref(), nil)).Ref(); var arg_372 any = A_arbace_go_generic_A_const_89; if linked_369 == nil { tmp1 = ifn_370.Invoke_O_O__O(arg_371, arg_372) } else { tmp1 = linked_369.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_368, arg_371, arg_372) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }
















func A_arbace_go_generic_desc__GT_type_fn__278000058_A_New_O(p0 any) *A_arbace_go_generic_desc__GT_type_fn__278000058_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_desc__GT_type_fn__278000058_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_go_generic_desc__GT_type_fn__278000058_A) Ctor_O(c__sub any) { t.F_sub = c__sub }
//line :110:1
func (t *A_arbace_go_generic_desc__GT_type_fn__278000058_A) Invoke_O_O_O_O_O__O(self, fnm__1, fty__2, emb__3, fp__4 any) any { var tmp1 any = A_arbace_go_generic_A_const_78; var tmp2 any = A_arbace_go_generic_A_const_87; var G__278000059__5_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, fnm__1, tmp2, lang.IFn_Cast(t.F_sub).Invoke_O__O(fty__2))); var G__278000059__6_ any; if
																jrt.J2g_Truth(emb__3) {
																	var root_413 any = A_arbace_go_generic_A_const_57.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = G__278000059__5_; var arg_417 any = A_arbace_go_generic_A_const_97; var arg_418 any = jrt.Boolean_TRUE.Ref(); if linked_414 == nil { G__278000059__6_ = ifn_415.Invoke_O_O_O__O(arg_416, arg_417, arg_418) } else { G__278000059__6_ = linked_414.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_413, arg_416, arg_417, arg_418) } } else {
//line :111:1
			G__278000059__6_ = G__278000059__5_ }; var tmp3 any; var root_419 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_421 lang.IFn; if

	linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = fp__4; if linked_420 == nil { tmp3 = ifn_421.Invoke_O__O(arg_422) } else { tmp3 = linked_420.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_419, arg_422) }; if /*line :111:1*/ jrt.J2g_Truth(tmp3) {

		var root_423 any = A_arbace_go_generic_A_const_57.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = G__278000059__6_; var arg_427 any = A_arbace_go_generic_A_const_69; var arg_428 any = fp__4; if linked_424 == nil { return ifn_425.Invoke_O_O_O__O(arg_426, arg_427, arg_428) } else { return linked_424.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_423, arg_426, arg_427, arg_428) } } else {
//line :111:1
			return G__278000059__6_ } }








func A_arbace_go_generic_arg_form_A_New() *A_arbace_go_generic_arg_form_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_arg_form_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_go_generic_arg_form_A) Ctor() {}
//line :120:1
func (t *A_arbace_go_generic_arg_form_A) Invoke_O_O_O_O__O(self, k__0, v__1, i__2 any) any { if jrt.Long_InstanceOf(i__2) { return t.InvokeSpec_O_O_O_J_O__O(self, k__0, v__1, jrt.NN(jrt.Long_Cast(i__2)).LongValue__J(), i__2) } else {


	var tmp1 any; var and__1927000168__auto____4 any; var root_432 any = A_arbace_go_generic_A_const_62.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = k__0; if linked_433 == nil { and__1927000168__auto____4 = ifn_434.Invoke_O__O(arg_435) } else { and__1927000168__auto____4 = linked_433.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_432, arg_435) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.IFn_Cast(A_arbace_go_generic_A_const_101).Invoke_O__O(k__0) } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return v__1 } else {

		var root_436 any = A_arbace_go_generic_A_const_102.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp3 jrt.Number_I; var na_440 any = i__2; if jrt.Long_InstanceOf(na_440) { var n0_441 int64 = jrt.NN(jrt.Long_Cast(na_440)).LongValue__J(); if n0_441 == 9223372036854775807 { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_440) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_441 + 1)) } } else { if jrt.Double_InstanceOf(na_440) { var n0_441_2 float64 = jrt.NN(jrt.Double_Cast(na_440)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_441_2 + 1.0)) } else { tmp3 = lang.Numbers_Inc_O__Number_NoInit(na_440) } }; arg_439 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if linked_437 == nil { return ifn_438.Invoke_O__O(arg_439) } else { return linked_437.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_436, arg_439) } } } }
//line :120:1
func (t *A_arbace_go_generic_arg_form_A) InvokeSpec_O_O_O_J_O__O(self, k__0, v__1 any, i__2_l int64, i__2_b any) any {


	var tmp1 any; var and__1927000168__auto____4 any; var root_442 any = A_arbace_go_generic_A_const_62.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = k__0; if linked_443 == nil { and__1927000168__auto____4 = ifn_444.Invoke_O__O(arg_445) } else { and__1927000168__auto____4 = linked_443.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_442, arg_445) }; if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.IFn_Cast(A_arbace_go_generic_A_const_101).Invoke_O__O(k__0) } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return v__1 } else {

		var root_446 any = A_arbace_go_generic_A_const_102.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp3 jrt.Number_I; var n0_450 int64 = i__2_l; if n0_450 == 9223372036854775807 { var tmp4 any; if i__2_b == nil { i__2_b = jrt.Long_ValueOf_J__Long_NoInit(i__2_l).Ref(); tmp4 = i__2_b } else { tmp4 = i__2_b }; tmp3 = lang.Numbers_Inc_O__Number_NoInit(tmp4) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_450 + 1)) }; arg_449 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); if linked_447 == nil { return ifn_448.Invoke_O__O(arg_449) } else { return linked_447.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_446, arg_449)
		} } }
func A_arbace_go_generic_operand_A_New() *A_arbace_go_generic_operand_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_operand_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_go_generic_operand_A) Ctor() {}
//line :127:1
func (t *A_arbace_go_generic_operand_A) Invoke_O_O_O_O_O__O(self, k__0, v__1, i__2, env__3 any) any { var f__5 any; var root_451 any = A_arbace_go_generic_A_const_103.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_451, A_arbace_go_generic_arg_form_A_fn_class); var ifn_453 lang.IFn; if


	linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = k__0; var arg_455 any = v__1; var arg_456 any = i__2; if linked_452 == nil { f__5 = ifn_453.Invoke_O_O_O__O(arg_454, arg_455, arg_456) } else { if jrt.Long_InstanceOf(arg_456) { f__5 = linked_452.(*A_arbace_go_generic_arg_form_A).InvokeSpec_O_O_O_J_O__O(root_451, arg_454, arg_455, jrt.NN(jrt.Long_Cast(arg_456)).LongValue__J(), arg_456) } else { f__5 = linked_452.(*A_arbace_go_generic_arg_form_A).Invoke_O_O_O_O__O(root_451, arg_454, arg_455, arg_456) } }; var tmp1 any; var root_457 any =
	A_arbace_go_generic_A_const_62.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = k__0; if linked_458 == nil { tmp1 = ifn_459.Invoke_O__O(arg_460) } else { tmp1 = linked_458.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_457, arg_460) }; if jrt.J2g_Truth(tmp1) { var G__278000064__6_ any = k__0
		switch lang.Util_Hash_O__I_NoInit(G__278000064__6_) >> 12 & 15 { case 1: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_104) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_generic_A_const_87, A_arbace_go_generic_A_const_105, A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) }; case 2: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_109) { var tmp2 any = A_arbace_go_generic_A_const_87; var tmp3 any = A_arbace_go_generic_A_const_106; var tmp4 any = A_arbace_go_generic_A_const_110; var tmp5 any = A_arbace_go_generic_A_const_111; var tmp6 any; var tmp7 any; var root_462 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_464 lang.IFn

			if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = v__1; if linked_463 == nil { tmp7 = ifn_464.Invoke_O__O(arg_465) } else { tmp7 = linked_463.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_462, arg_465) }; if jrt.J2g_Truth(tmp7) { tmp6 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp6 = v__1 }
//line :132:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, k__0, tmp3, tmp4, tmp5, tmp6, A_arbace_go_generic_A_const_108, f__5)) }; case 4: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_113) { var tmp8 any = A_arbace_go_generic_A_const_87; var tmp9 any = A_arbace_go_generic_A_const_106; var tmp10 any = A_arbace_go_generic_A_const_110; var tmp11 any = A_arbace_go_generic_A_const_111; var tmp12 any; var tmp13 any; var root_466 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_468 lang.IFn

				if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = v__1; if linked_467 == nil { tmp13 = ifn_468.Invoke_O__O(arg_469) } else { tmp13 = linked_467.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_466, arg_469) }; if jrt.J2g_Truth(tmp13) { tmp12 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp12 = v__1 }
//line :132:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, k__0, tmp9, tmp10, tmp11, tmp12, A_arbace_go_generic_A_const_108, f__5)) }; case 6: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_114) { var tmp14 any = A_arbace_go_generic_A_const_87; var tmp15 any = A_arbace_go_generic_A_const_106; var tmp16 any = A_arbace_go_generic_A_const_110; var tmp17 any = A_arbace_go_generic_A_const_111; var tmp18 any; var tmp19 any; var root_470 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_472 lang.IFn

					if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = v__1; if linked_471 == nil { tmp19 = ifn_472.Invoke_O__O(arg_473) } else { tmp19 = linked_471.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_470, arg_473) }; if jrt.J2g_Truth(tmp19) { tmp18 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp18 = v__1 }
//line :132:1
					return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, k__0, tmp15, tmp16, tmp17, tmp18, A_arbace_go_generic_A_const_108, f__5)) }; case 7: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_115) { var tmp20 any = A_arbace_go_generic_A_const_87; var tmp21 any = A_arbace_go_generic_A_const_106; var tmp22 any = A_arbace_go_generic_A_const_110; var tmp23 any = A_arbace_go_generic_A_const_111; var tmp24 any; var tmp25 any; var root_479 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_481 lang.IFn

						if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = v__1; if linked_480 == nil { tmp25 = ifn_481.Invoke_O__O(arg_482) } else { tmp25 = linked_480.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_479, arg_482) }; if jrt.J2g_Truth(tmp25) { tmp24 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp24 = v__1 }
//line :132:1
						return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, k__0, tmp21, tmp22, tmp23, tmp24, A_arbace_go_generic_A_const_108, f__5)) }; case 9: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_116) { var tmp26 any = A_arbace_go_generic_A_const_87; var tmp27 any = A_arbace_go_generic_A_const_106; var tmp28 any = A_arbace_go_generic_A_const_110; var tmp29 any = A_arbace_go_generic_A_const_111; var tmp30 any; var tmp31 any; var root_483 any = A_arbace_go_generic_A_const_112.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_485 lang.IFn

							if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = v__1; if linked_484 == nil { tmp31 = ifn_485.Invoke_O__O(arg_486) } else { tmp31 = linked_484.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_483, arg_486) }; if jrt.J2g_Truth(tmp31) { tmp30 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() } else { tmp30 = v__1 }
//line :132:1
							return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp26, k__0, tmp27, tmp28, tmp29, tmp30, A_arbace_go_generic_A_const_108, f__5)) }; case 10: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_117) { var tmp32 any = A_arbace_go_generic_A_const_87; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp32, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_go_generic_A_const_96, lang.PersistentVector_EMPTY.Ref(), nil), A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) }; case 11: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_105) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_generic_A_const_87, A_arbace_go_generic_A_const_105, A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) }; case 12: if any(G__278000064__6_) == any(A_arbace_go_generic_A_const_118) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_go_generic_A_const_87, A_arbace_go_generic_A_const_105, A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__278000064__6_))))) } else {
//line :131:1
								var tmp33 any = A_arbace_go_generic_A_const_87; var tmp34 any; var root_474 any = A_arbace_go_generic_A_const_88.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, A_arbace_go_generic_desc__GT_type_A_fn_class); var ifn_476 lang.IFn






								if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = k__0; var arg_478 any = env__3; if linked_475 == nil { tmp34 = ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { tmp34 = linked_475.(*A_arbace_go_generic_desc__GT_type_A).Invoke_O_O_O__O(root_474, arg_477, arg_478) }
//line :131:1
								return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34, A_arbace_go_generic_A_const_106, A_arbace_go_generic_A_const_107, A_arbace_go_generic_A_const_108, f__5)) } }










func A_arbace_go_generic_tparams_of_A_New() *A_arbace_go_generic_tparams_of_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_tparams_of_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_go_generic_tparams_of_A) Ctor() {}
//line :142:1
func (t *A_arbace_go_generic_tparams_of_A) Invoke_O_O__O(self, x__0 any) any { var root_487 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any; var root_491 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any; var root_496 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = x__0; var arg_500 any = A_arbace_go_generic_A_const_120; if linked_497 == nil { arg_494 = ifn_498.Invoke_O_O__O(arg_499, arg_500) } else { arg_494 = linked_497.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_496, arg_499, arg_500) }; var arg_495 any; var root_501 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = x__0; var arg_505 any = A_arbace_go_generic_A_const_121; if linked_502 == nil { arg_495 = ifn_503.Invoke_O_O__O(arg_504, arg_505) } else { arg_495 = linked_502.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_501, arg_504, arg_505) }; if linked_492 == nil { arg_490 = ifn_493.Invoke_O_O__O(arg_494, arg_495) } else { arg_490 = linked_492.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_491, arg_494, arg_495) }; if linked_488 == nil { return ifn_489.Invoke_O__O(arg_490) } else { return linked_488.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_487, arg_490) } }

func A_arbace_go_generic_callee_name_A_New() *A_arbace_go_generic_callee_name_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_callee_name_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_go_generic_callee_name_A) Ctor() {}
//line :144:1
func (t *A_arbace_go_generic_callee_name_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_506 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = x__0; var arg_510 any = A_arbace_go_generic_A_const_122; if linked_507 == nil { tmp1 = ifn_508.Invoke_O_O__O(arg_509, arg_510) } else { tmp1 = linked_507.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_506, arg_509, arg_510) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp3 *lang.Keyword = A_arbace_go_generic_A_const_78; var tmp4 any; var root_511 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var root_515 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_517 lang.IFn; if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = x__0; var arg_519 any = A_arbace_go_generic_A_const_123; if linked_516 == nil { arg_514 = ifn_517.Invoke_O_O__O(arg_518, arg_519) } else { arg_514 = linked_516.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_515, arg_518, arg_519) }; if linked_512 == nil { tmp4 = ifn_513.Invoke_O__O(arg_514) } else { tmp4 = linked_512.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_511, arg_514) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 any; var root_520 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = x__0; var arg_524 any = A_arbace_go_generic_A_const_78; if linked_521 == nil { tmp6 = ifn_522.Invoke_O_O__O(arg_523, arg_524) } else { tmp6 = linked_521.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_520, arg_523, arg_524) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp5, nil, tmp6)).Ref() } else {
			var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp8 any; var or__1927000174__auto____5 any; var root_525 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = x__0; var arg_529 any = A_arbace_go_generic_A_const_124; if linked_526 == nil { or__1927000174__auto____5 = ifn_527.Invoke_O_O__O(arg_528, arg_529) } else { or__1927000174__auto____5 = linked_526.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_525, arg_528, arg_529) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp8 = or__1927000174__auto____5 } else { var root_530 any = A_arbace_go_generic_A_const_125.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any; var root_534 any = A_arbace_go_generic_A_const_126.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any; var root_539 any = A_arbace_go_generic_A_const_127.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var root_543 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = x__0; var arg_547 any = A_arbace_go_generic_A_const_69; if linked_544 == nil { arg_542 = ifn_545.Invoke_O_O__O(arg_546, arg_547) } else { arg_542 = linked_544.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_543, arg_546, arg_547) }; if linked_540 == nil { arg_537 = ifn_541.Invoke_O__O(arg_542) } else { arg_537 = linked_540.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_539, arg_542) }; var arg_538 any = A_arbace_go_generic_A_const_128; if linked_535 == nil { arg_533 = ifn_536.Invoke_O_O__O(arg_537, arg_538) } else { arg_533 = linked_535.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_534, arg_537, arg_538) }; if linked_531 == nil { tmp8 = ifn_532.Invoke_O__O(arg_533) } else { tmp8 = linked_531.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_530, arg_533) } }; var tmp9 any = tmp8; var tmp10 any; var root_548 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = x__0; var arg_552 any = A_arbace_go_generic_A_const_78; if linked_549 == nil { tmp10 = ifn_550.Invoke_O_O__O(arg_551, arg_552) } else { tmp10 = linked_549.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_548, arg_551, arg_552) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp9, nil, tmp10)).Ref()
		} }
func A_arbace_go_generic_type_summary_A_New() *A_arbace_go_generic_type_summary_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_type_summary_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_go_generic_type_summary_A) Ctor() {}
//line :151:1
func (t *A_arbace_go_generic_type_summary_A) Invoke_O_O__O(self, ty__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_go_generic_A_const_129).Invoke_O__O(ty__0)) { return Lit_58 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_115, ty__0) { return Lit_59 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_109, ty__0) { return Lit_60 } else { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_105, ty__0) { return Lit_61 } else { if A_arbace_go_generic_A_const_71 != nil {




		var root_553 any = A_arbace_go_generic_A_const_130.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = ty__0; if linked_554 == nil { return ifn_555.Invoke_O__O(arg_556) } else { return linked_554.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_553, arg_556) } } else {
//line :152:1
			return nil
		}
	}
	}
	}
	}
}
func A_arbace_go_generic_params_for_A_New() *A_arbace_go_generic_params_for_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_params_for_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_go_generic_params_for_A) Ctor() {}
//line :159:1
func (t *A_arbace_go_generic_params_for_A) Invoke_O_O_O_O__O(self, cname__0, p__278000070__1, ops__2 any) any { var vec__278000071__4 any = p__278000070__1; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000071__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000071__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000071__4, lang.RT_IntCast_J__I_NoInit(2), nil); var variadic__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000071__4, lang.RT_IntCast_J__I_NoInit(3), nil); var np__9 int32 = lang.RT_Count_O__I_NoInit(ps__6); var na__10 int32 = lang.RT_Count_O__I_NoInit(ops__2); var tmp1 any; var or__1927000174__auto____11 any; var and__1927000168__auto____11 any = variadic__8; _ = ___5; _ = ___7; if




	jrt.J2g_Truth(and__1927000168__auto____11) { or__1927000174__auto____11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Gte_J_J__Z_NoInit(int64(na__10), lang.Numbers_Dec_J__J_NoInit(int64(np__9)))).Ref() } else { or__1927000174__auto____11 = and__1927000168__auto____11 }; if jrt.J2g_Truth(or__1927000174__auto____11) { tmp1 = or__1927000174__auto____11 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_J_J__Z_NoInit(int64(na__10), int64(np__9))).Ref() }; if jrt.J2g_Truth(tmp1) {
		if jrt.J2g_Truth(variadic__8) {
			var root_557 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any; var root_561 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any; var root_566 any = A_arbace_go_generic_A_const_53.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(np__9))).Ref(); var arg_570 any = ps__6; if linked_567 == nil { arg_564 = ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { arg_564 = linked_567.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_566, arg_569, arg_570) }; var arg_565 any; var root_571 any = A_arbace_go_generic_A_const_131.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(na__10), lang.Numbers_Dec_J__J_NoInit(int64(np__9)))).Ref(); var arg_575 any; var tmp2 any; var root_576 any = A_arbace_go_generic_A_const_132.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = ps__6; if linked_577 == nil { tmp2 = ifn_578.Invoke_O__O(arg_579) } else { tmp2 = linked_577.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_576, arg_579) }; arg_575 = lang.RT_Nth_O_I__O_NoInit(tmp2, lang.RT_IntCast_J__I_NoInit(1)); if linked_572 == nil { arg_565 = ifn_573.Invoke_O_O__O(arg_574, arg_575) } else { arg_565 = linked_572.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_571, arg_574, arg_575) }; if linked_562 == nil { arg_560 = ifn_563.Invoke_O_O__O(arg_564, arg_565) } else { arg_560 = linked_562.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_561, arg_564, arg_565) }; if linked_558 == nil { return ifn_559.Invoke_O__O(arg_560) } else { return linked_558.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_557, arg_560) } } else {
				var root_580 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = ps__6; if linked_581 == nil { return ifn_582.Invoke_O__O(arg_583) } else { return linked_581.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_580, arg_583) } } } else {
					var root_584 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_134.GetRawRoot__O()); var tmp4 *jrt.String
					if lang.Numbers_Lt_J_J__Z_NoInit(int64(na__10), int64(np__9)) { tmp4 = Lit_45 } else { tmp4 = Lit_46 }
//line :168:1
					var tmp5 any = tmp4.Ref(); var tmp6 any; var root_596 any = A_arbace_go_generic_A_const_41.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_598 lang.IFn

					if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = Lit_36; var arg_600 any; var root_601 any = A_arbace_go_generic_A_const_82.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any; var fnbody__611 any = A_arbace_go_generic_params_for_fn__278000074_A_New(); var tmp7 *jrt.Class; var fncls__610 *jrt.Class = A_arbace_go_generic_params_for_fn__278000074_A_fn_class; if fncls__610 == nil { var fncls__610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_go_generic_params_for_fn__278000074_A_fn_class = fncls__610d; tmp7 = fncls__610d } else { tmp7 = fncls__610 }; arg_604 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__611, tmp7, nil); var arg_605 any = ops__2; if linked_602 == nil { arg_600 = ifn_603.Invoke_O_O__O(arg_604, arg_605) } else { arg_600 = linked_602.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_601, arg_604, arg_605) }; if linked_597 == nil { tmp6 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { tmp6 = linked_597.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }
//line :168:1
					var tmp8 any = tmp6; var tmp9 any; var root_612 any = A_arbace_go_generic_A_const_41.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_614 lang.IFn


					if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = Lit_36; var arg_616 any; var root_617 any = A_arbace_go_generic_A_const_136.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any; var fnbody__631 any = A_arbace_go_generic_params_for_fn__278000076_A_New_O_I(variadic__8, np__9); var tmp10 *jrt.Class; var fncls__630 *jrt.Class = A_arbace_go_generic_params_for_fn__278000076_A_fn_class; if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__631); A_arbace_go_generic_params_for_fn__278000076_A_fn_class = fncls__630d; tmp10 = fncls__630d } else { tmp10 = fncls__630 }; arg_620 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__631, tmp10, nil); var arg_621 any = ps__6; if linked_618 == nil { arg_616 = ifn_619.Invoke_O_O__O(arg_620, arg_621) } else { arg_616 = linked_618.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_617, arg_620, arg_621) }; if linked_613 == nil { tmp9 = ifn_614.Invoke_O_O__O(arg_615, arg_616) } else { tmp9 = linked_613.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_612, arg_615, arg_616) }
//line :168:1
					arg_587 = tmp3.Invoke_O_O_O_O_O__O(Lit_44, tmp5, cname__0, tmp8, tmp9); if linked_585 == nil { ifn_586.Invoke_O__O(arg_587) } else { linked_585.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_584, arg_587) }
//line :164:1
					return nil } }





func A_arbace_go_generic_params_for_fn__278000074_A_New() *A_arbace_go_generic_params_for_fn__278000074_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_params_for_fn__278000074_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_go_generic_params_for_fn__278000074_A) Ctor() {}
//line :170:1
func (t *A_arbace_go_generic_params_for_fn__278000074_A) Invoke_O_O__O(self, p1__278000069_SHARP___1 any) any { var root_606 any = A_arbace_go_generic_A_const_135.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, A_arbace_go_generic_type_summary_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = A_arbace_go_generic_A_const_87.Invoke_O__O(p1__278000069_SHARP___1); if linked_607 == nil { return ifn_608.Invoke_O__O(arg_609) } else { return linked_607.(*A_arbace_go_generic_type_summary_A).Invoke_O_O__O(root_606, arg_609) } }
func A_arbace_go_generic_params_for_fn__278000076_A_New_O_I(p0 any, p1 int32) *A_arbace_go_generic_params_for_fn__278000076_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_params_for_fn__278000076_A{}; t.Ctor_O_I(p0, p1); return t }
//line :171:1
func (t *A_arbace_go_generic_params_for_fn__278000076_A) Ctor_O_I(c__variadic any, c__np int32) { t.F_variadic = c__variadic; t.F_np = c__np }
//line :171:1
func (t *A_arbace_go_generic_params_for_fn__278000076_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_J__Z_NoInit(i__1, lang.Numbers_Dec_J__J_NoInit(int64(t.F_np)))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_49, nil); var tmp3 any; var root_622 any = A_arbace_go_generic_A_const_130.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = lang.RT_Nth_O_I__O_NoInit(p__2, lang.RT_IntCast_J__I_NoInit(1)); if linked_623 == nil { tmp3 = ifn_624.Invoke_O__O(arg_625) } else { tmp3 = linked_623.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_622, arg_625) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else { var root_626 any = A_arbace_go_generic_A_const_130.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = p__2; if linked_627 == nil { return ifn_628.Invoke_O__O(arg_629) } else { return linked_627.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_626, arg_629) } } }


func A_arbace_go_generic_infer_targs_A_New() *A_arbace_go_generic_infer_targs_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_infer_targs_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_go_generic_infer_targs_A) Ctor() {}
//line :174:1
func (t *A_arbace_go_generic_infer_targs_A) Invoke_O_O_O_O_O_O_O__O(self, cname__0, tps__1, known__2, params__3, ops__4, extra__5 any) any { var vec__278000079__7 any; var root_632 any = A_arbace_go_generic_A_const_137.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_go_check_code.A_arbace_go_check_code_rename_tparams_A_fn_class); var ifn_634 lang.IFn; if




	linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = tps__1; var arg_636 any; var root_637 any = A_arbace_go_generic_A_const_80.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = A_arbace_go_generic_A_const_138; var arg_641 any = params__3; if linked_638 == nil { arg_636 = ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { arg_636 = linked_638.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) }; if linked_633 == nil { vec__278000079__7 = ifn_634.Invoke_O_O__O(arg_635, arg_636) } else { vec__278000079__7 = linked_633.(*aot_arbace_go_check_code.A_arbace_go_check_code_rename_tparams_A).Invoke_O_O_O__O(root_632, arg_635, arg_636) }; var tps2__8 any = /*line :174:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__278000079__7, lang.RT_IntCast_J__I_NoInit(0), nil); var sp__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000079__7, lang.RT_IntCast_J__I_NoInit(1), nil); var targs__10 any; var root_642 any = A_arbace_go_generic_A_const_139.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_go_check_code.A_arbace_go_check_code_infer_A_fn_class); var ifn_644 lang.IFn; if





	linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = tps2__8; var arg_646 any; var root_651 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = known__2; if linked_652 == nil { arg_646 = ifn_653.Invoke_O__O(arg_654) } else { arg_646 = linked_652.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_651, arg_654) }; var arg_647 any; var root_655 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any; var root_659 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_661 lang.IFn; if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = sp__9; if linked_660 == nil { arg_658 = ifn_661.Invoke_O__O(arg_662) } else { arg_658 = linked_660.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_659, arg_662) }; if linked_656 == nil { arg_647 = ifn_657.Invoke_O__O(arg_658) } else { arg_647 = linked_656.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_655, arg_658) }; var arg_648 any = ops__4; var arg_649 any = jrt.Boolean_FALSE.Ref(); var arg_650 any; var fnbody__668 any = A_arbace_go_generic_infer_targs_fn__278000082_A_New_O(cname__0); var tmp1 *jrt.Class; var fncls__667 *jrt.Class = A_arbace_go_generic_infer_targs_fn__278000082_A_fn_class; if
	fncls__667 == nil { var fncls__667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__668); A_arbace_go_generic_infer_targs_fn__278000082_A_fn_class = fncls__667d; tmp1 = fncls__667d } else { tmp1 = fncls__667 }; arg_650 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__668, tmp1, nil); if /*line :180:1*/ linked_643 == nil { targs__10 = ifn_644.Invoke_O_O_O_O_O_O__O(arg_645, arg_646, arg_647, arg_648, arg_649, arg_650) } else { targs__10 = linked_643.(*aot_arbace_go_check_code.A_arbace_go_check_code_infer_A).Invoke_O_O_O_O_O_O_O__O(root_642, arg_645, arg_646, arg_647, arg_648, arg_649, arg_650) }; if

	jrt.J2g_Truth(targs__10) {
		var root_677 any = A_arbace_go_generic_A_const_141.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any; var arg_681 any = tps__1; var arg_682 any = targs__10; var arg_683 any = extra__5; if linked_678 == nil { ifn_679.Invoke_O_O_O_O__O(arg_680, arg_681, arg_682, arg_683) } else { linked_678.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A).Invoke_O_O_O_O_O__O(root_677, arg_680, arg_681, arg_682, arg_683) }
		var tmp2 any; var root_669 any = A_arbace_go_generic_A_const_140.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any; var root_673 any = A_arbace_go_generic_A_const_10.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = A_arbace_go_generic_A_const_39.Get__O(); if linked_674 == nil { arg_672 = ifn_675.Invoke_O__O(arg_676) } else { arg_672 = linked_674.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_673, arg_676) }; if linked_670 == nil { tmp2 = ifn_671.Invoke_O__O(arg_672) } else { tmp2 = linked_670.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_669, arg_672) }; if jrt.J2g_Truth(tmp2) { return targs__10 } else { return nil } } else {
//line :182:1
			return nil } }
//line :181:1
func A_arbace_go_generic_infer_targs_fn__278000082_A_New_O(p0 any) *A_arbace_go_generic_infer_targs_fn__278000082_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_infer_targs_fn__278000082_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_go_generic_infer_targs_fn__278000082_A) Ctor_O(c__cname any) { t.F_cname = c__cname }
//line :181:1
func (t *A_arbace_go_generic_infer_targs_fn__278000082_A) Invoke_O_O_O__O(self, ___1, msg__2 any) any { var root_663 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_35, nil, Lit_36, nil), jrt.RefArrayOf(jrt.Object_class, nil, t.F_cname, nil, msg__2)).Ref(); if linked_664 == nil { return ifn_665.Invoke_O__O(arg_666) } else { return linked_664.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_663, arg_666) } }




func A_arbace_go_generic_instance_fn_A_New() *A_arbace_go_generic_instance_fn_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_instance_fn_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_go_generic_instance_fn_A) Ctor() {}
//line :186:1
func (t *A_arbace_go_generic_instance_fn_A) Invoke_O_O_O_O__O(self, x__0, targs__1, rt__2 any) any { var nm__4 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_37, nil, Lit_38); var tmp2 any; var root_684 any = A_arbace_go_generic_A_const_142.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, A_arbace_go_generic_callee_name_A_fn_class); var ifn_686 lang.IFn; if


	linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = x__0; if linked_685 == nil { tmp2 = ifn_686.Invoke_O__O(arg_687) } else { tmp2 = linked_685.(*A_arbace_go_generic_callee_name_A).Invoke_O_O__O(root_684, arg_687) }; var tmp3 any = tmp2; var tmp4 any; var root_688 any = A_arbace_go_generic_A_const_41.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = Lit_39; var arg_692 any; var root_693 any = A_arbace_go_generic_A_const_82.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = A_arbace_go_generic_A_const_143.GetRawRoot__O(); var arg_697 any = targs__1; if linked_694 == nil { arg_692 = ifn_695.Invoke_O_O__O(arg_696, arg_697) } else { arg_692 = linked_694.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_693, arg_696, arg_697) }; if linked_689 == nil { tmp4 = ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { tmp4 = linked_689.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) }; nm__4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4, nil)).Ref(); var vec__278000085__5 any; var root_698 any = /*line :186:1*/A_arbace_go_generic_A_const_144.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_go_build.A_arbace_go_build_instance_callable_A_fn_class); var ifn_700 lang.IFn; if



	linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = x__0; var arg_702 any = targs__1; var arg_703 any = rt__2; var arg_704 any = nm__4; if linked_699 == nil { vec__278000085__5 = ifn_700.Invoke_O_O_O_O__O(arg_701, arg_702, arg_703, arg_704) } else { vec__278000085__5 = linked_699.(*aot_arbace_go_build.A_arbace_go_build_instance_callable_A).Invoke_O_O_O_O_O__O(root_698, arg_701, arg_702, arg_703, arg_704) }; var c__6 any = /*line :186:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__278000085__5, lang.RT_IntCast_J__I_NoInit(0), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__278000085__5, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___7; return lang.GoFn_New_O_String(c__6, jrt.String_Cast(nm__4)) }






func A_arbace_go_generic_receiver_targs_A_New() *A_arbace_go_generic_receiver_targs_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_receiver_targs_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_go_generic_receiver_targs_A) Ctor() {}
//line :193:1
func (t *A_arbace_go_generic_receiver_targs_A) Invoke_O_O_O_O__O(self, x__0, cname__1, op__2 any) any { var g__4 any; var root_705 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_707 lang.IFn; if



	linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = x__0; var arg_709 any = A_arbace_go_generic_A_const_123; if linked_706 == nil { g__4 = ifn_707.Invoke_O_O__O(arg_708, arg_709) } else { g__4 = linked_706.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_705, arg_708, arg_709) }; var gi__5 any; var root_710 any = /*line :193:1*/A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_712 lang.IFn; if




	linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = g__4; if linked_711 == nil { gi__5 = ifn_712.Invoke_O__O(arg_713) } else { gi__5 = linked_711.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_710, arg_713) }; var vec__278000089__6 any; var root_714 any = /*line :193:1*/A_arbace_go_generic_A_const_145.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_go_check_types.A_arbace_go_check_types_deref_type_A_fn_class); var ifn_716 lang.IFn; if





	linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = A_arbace_go_generic_A_const_87.Invoke_O__O(op__2); if linked_715 == nil { vec__278000089__6 = ifn_716.Invoke_O__O(arg_717) } else { vec__278000089__6 = linked_715.(*aot_arbace_go_check_types.A_arbace_go_check_types_deref_type_A).Invoke_O_O__O(root_714, arg_717) }; var ty__7 any = /*line :193:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__278000089__6, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var and__1927000168__auto____8 any; var root_718 any = A_arbace_go_generic_A_const_63.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A_fn_class); var ifn_720 lang.IFn; if






	linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = ty__7; if linked_719 == nil { and__1927000168__auto____8 = ifn_720.Invoke_O__O(arg_721) } else { and__1927000168__auto____8 = linked_719.(*aot_arbace_go_check_types.A_arbace_go_check_types_named_QMARK__A).Invoke_O_O__O(root_718, arg_721) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var root_722 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any; var tmp2 *lang.Keyword = A_arbace_go_generic_A_const_65; var tmp3 any; var root_726 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = ty__7; if linked_727 == nil { tmp3 = ifn_728.Invoke_O__O(arg_729) } else { tmp3 = linked_727.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_726, arg_729) }; arg_725 = tmp2.Invoke_O__O(tmp3); if linked_723 == nil { and__1927000168__auto____9 = ifn_724.Invoke_O__O(arg_725) } else { and__1927000168__auto____9 = linked_723.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_722, arg_725) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var o__10 any; var root_730 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_732 lang.IFn
		if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any; var tmp4 *lang.Keyword = A_arbace_go_generic_A_const_67; var tmp5 any; var root_734 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = ty__7; if linked_735 == nil { tmp5 = ifn_736.Invoke_O__O(arg_737) } else { tmp5 = linked_735.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_734, arg_737) }; arg_733 = tmp4.Invoke_O__O(tmp5); if linked_731 == nil { o__10 = ifn_732.Invoke_O__O(arg_733) } else { o__10 = linked_731.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_730, arg_733) }
//line :200:1
		var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_69.Invoke_O__O(o__10), A_arbace_go_generic_A_const_69.Invoke_O__O(gi__5))
		if and__1927000168__auto____11 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_78.Invoke_O__O(o__10), A_arbace_go_generic_A_const_78.Invoke_O__O(gi__5))).Ref() } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else {
//line :200:1
			tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) {

				var tmp6 *lang.Keyword = A_arbace_go_generic_A_const_65; var tmp7 any; var root_738 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = ty__7; if linked_739 == nil { tmp7 = ifn_740.Invoke_O__O(arg_741) } else { tmp7 = linked_739.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_738, arg_741) }; return tmp6.Invoke_O__O(tmp7) } else {
					var root_742 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_134.GetRawRoot__O()); var tmp9 any; var root_753 any = A_arbace_go_generic_A_const_135.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, A_arbace_go_generic_type_summary_A_fn_class); var ifn_755 lang.IFn
					if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = A_arbace_go_generic_A_const_87.Invoke_O__O(op__2); if linked_754 == nil { tmp9 = ifn_755.Invoke_O__O(arg_756) } else { tmp9 = linked_754.(*A_arbace_go_generic_type_summary_A).Invoke_O_O__O(root_753, arg_756) }
//line :203:1
					var tmp10 any = tmp9; var tmp11 any; var root_757 any = A_arbace_go_generic_A_const_130.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A_fn_class); var ifn_759 lang.IFn
					if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = g__4; if linked_758 == nil { tmp11 = ifn_759.Invoke_O__O(arg_760) } else { tmp11 = linked_758.(*aot_arbace_go_check_types.A_arbace_go_check_types_type_str_A).Invoke_O_O__O(root_757, arg_760) }
//line :203:1
					arg_745 = tmp8.Invoke_O_O_O_O__O(Lit_50, cname__1, tmp10, tmp11); if linked_743 == nil { ifn_744.Invoke_O__O(arg_745) } else { linked_743.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_742, arg_745) }
//line :200:1
					return nil } }






func A_arbace_go_generic_resolve_instance_A_New() *A_arbace_go_generic_resolve_instance_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_resolve_instance_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_go_generic_resolve_instance_A) Ctor() {}
//line :207:1
func (t *A_arbace_go_generic_resolve_instance_A) Invoke_O_O_O_O__O(self, g__0, k__1, args__2 any) any { var map__278000093__4 any = lang.GoGenericFn_Cast(g__0).F_data; var map__278000093__5 any; if


	lang.ISeq_InstanceOf(map__278000093__4) { var tmp1 any; var root_761 any = A_arbace_go_generic_A_const_146.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any = map__278000093__4; if linked_762 == nil { tmp1 = ifn_763.Invoke_O__O(arg_764) } else { tmp1 = linked_762.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_761, arg_764) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_765 any = A_arbace_go_generic_A_const_147.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = map__278000093__4; if linked_766 == nil { tmp2 = ifn_767.Invoke_O__O(arg_768) } else { tmp2 = linked_766.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_765, arg_768) }; map__278000093__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_769 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = map__278000093__4; if linked_770 == nil { tmp3 = ifn_771.Invoke_O__O(arg_772) } else { tmp3 = linked_770.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_769, arg_772) }; if jrt.J2g_Truth(tmp3) { var root_773 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = map__278000093__4; if linked_774 == nil { map__278000093__5 = ifn_775.Invoke_O__O(arg_776) } else { map__278000093__5 = linked_774.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_773, arg_776) } } else { map__278000093__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__278000093__5 = map__278000093__4 }; var obj__6 any = /*line :207:1*/lang.RT_Get_O_O__O_NoInit(map__278000093__5, A_arbace_go_generic_A_const_148); var ptargs__7 any = lang.RT_Get_O_O__O_NoInit(map__278000093__5, A_arbace_go_generic_A_const_149); var env__8 any = lang.RT_Get_O_O__O_NoInit(map__278000093__5, A_arbace_go_generic_A_const_150); var x__9 any = obj__6; var ctx__10 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_151.Invoke_O__O(env__8)); var tmp5 any; var root_957 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_959 lang.IFn; if




	linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = x__9; var arg_961 any = A_arbace_go_generic_A_const_69; if linked_958 == nil { tmp5 = ifn_959.Invoke_O_O__O(arg_960, arg_961) } else { tmp5 = linked_958.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_957, arg_960, arg_961) }; ctx__10 = tmp4.Invoke_O__O(tmp5); var cname__11 any; var root_777 any = /*line :207:1*/A_arbace_go_generic_A_const_142.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, A_arbace_go_generic_callee_name_A_fn_class); var ifn_779 lang.IFn; if





	linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = x__9; if linked_778 == nil { cname__11 = ifn_779.Invoke_O__O(arg_780) } else { cname__11 = linked_778.(*A_arbace_go_generic_callee_name_A).Invoke_O_O__O(root_777, arg_780) }; var root_962 any =
	A_arbace_go_generic_A_const_163.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_164.GetRawRoot__O()); var tmp7 any = A_arbace_go_generic_A_const_165; var tmp8 any = A_arbace_go_generic_A_const_39; var tmp9 any; var root_989 any = A_arbace_go_generic_A_const_166.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = lang.PersistentVector_EMPTY.Ref(); if linked_990 == nil { tmp9 = ifn_991.Invoke_O__O(arg_992) } else { tmp9 = linked_990.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_989, arg_992) }; var tmp10 any = tmp9; var tmp11 any = A_arbace_go_generic_A_const_167; var tmp12 any = A_arbace_go_generic_A_const_168; var tmp13 any = A_arbace_go_generic_A_const_169; var tmp14 any = A_arbace_go_generic_A_const_170.GetRawRoot__O(); var tmp15 any = A_arbace_go_generic_A_const_171; var tmp16 any = A_arbace_go_generic_A_const_172.GetRawRoot__O(); var tmp17 any = A_arbace_go_generic_A_const_173; var tmp18 any = A_arbace_go_generic_A_const_174.GetRawRoot__O(); var tmp19 any = A_arbace_go_generic_A_const_175; var tmp20 any = A_arbace_go_generic_A_const_156.GetRawRoot__O(); var tmp21 any = A_arbace_go_generic_A_const_176; var tmp22 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var tmp23 any = A_arbace_go_generic_A_const_177; var tmp24 *lang.Compiler_AOTRestFn; var fnbody__994 any = A_arbace_go_generic_resolve_instance_fn__278000095_A_New(); var tmp25 *jrt.Class; var fncls__993 *jrt.Class = A_arbace_go_generic_resolve_instance_fn__278000095_A_fn_class; if fncls__993 == nil { var fncls__993d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, true, nil); A_arbace_go_generic_resolve_instance_fn__278000095_A_fn_class = fncls__993d; tmp25 = fncls__993d } else { tmp25 = fncls__993 }; tmp24 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__994, tmp25, nil, 0); arg_965 = tmp6.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp7, ctx__10, tmp8, tmp10, tmp11, nil, tmp12, nil, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24.Ref()); if linked_963 == nil { ifn_964.Invoke_O__O(arg_965) } else { linked_963.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_962, arg_965) }; var tmp26 any; tmp31 := /*line :207:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var ops__14 any; var root_781 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_783 lang.IFn







		if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any; var root_785 any = A_arbace_go_generic_A_const_136.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any; var fnbody__798 any = A_arbace_go_generic_resolve_instance_fn__278000097_A_New_O_O(env__8, k__1); var tmp27 *jrt.Class; var fncls__797 *jrt.Class = A_arbace_go_generic_resolve_instance_fn__278000097_A_fn_class; if fncls__797 == nil { var fncls__797d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__798); A_arbace_go_generic_resolve_instance_fn__278000097_A_fn_class = fncls__797d; tmp27 = fncls__797d } else { tmp27 = fncls__797 }; arg_788 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__798, tmp27, nil); var arg_789 any = args__2; if linked_786 == nil { arg_784 = ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { arg_784 = linked_786.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }; if linked_782 == nil { ops__14 = ifn_783.Invoke_O__O(arg_784) } else { ops__14 = linked_782.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_781, arg_784) }
//line :207:1
		var sig__15 any; var root_799 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_801 lang.IFn








		if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = x__9; var arg_803 any = A_arbace_go_generic_A_const_87; if linked_800 == nil { sig__15 = ifn_801.Invoke_O_O__O(arg_802, arg_803) } else { sig__15 = linked_800.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_799, arg_802, arg_803) }
//line :207:1
		var r__16 any; var tmp28 any; var root_804 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_806 lang.IFn









		if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = x__9; var arg_808 any = A_arbace_go_generic_A_const_122; if linked_805 == nil { tmp28 = ifn_806.Invoke_O_O__O(arg_807, arg_808) } else { tmp28 = linked_805.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_804, arg_807, arg_808) }; if jrt.J2g_Truth(tmp28) { var rtps__16 any; var root_809 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_811 lang.IFn


			if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any; var root_813 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_813, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = x__9; var arg_817 any = A_arbace_go_generic_A_const_120; if linked_814 == nil { arg_812 = ifn_815.Invoke_O_O__O(arg_816, arg_817) } else { arg_812 = linked_814.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_813, arg_816, arg_817) }; if linked_810 == nil { rtps__16 = ifn_811.Invoke_O__O(arg_812) } else { rtps__16 = linked_810.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_809, arg_812) }
//line :217:1
			var mtps__17 any; var root_818 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_820 lang.IFn



			if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any; var root_822 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = x__9; var arg_826 any = A_arbace_go_generic_A_const_121; if linked_823 == nil { arg_821 = ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { arg_821 = linked_823.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_822, arg_825, arg_826) }; if linked_819 == nil { mtps__17 = ifn_820.Invoke_O__O(arg_821) } else { mtps__17 = linked_819.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_818, arg_821) }
//line :217:1
			var given__18 any; var root_827 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_829 lang.IFn




			if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = ptargs__7; if linked_828 == nil { given__18 = ifn_829.Invoke_O__O(arg_830) } else { given__18 = linked_828.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_827, arg_830) }
//line :217:1
			var rtargs__19 any





			if lang.Numbers_Gte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(given__18)), int64(lang.RT_Count_O__I_NoInit(rtps__16))) {
				var root_831 any = A_arbace_go_generic_A_const_153.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = given__18; var arg_835 any = A_arbace_go_generic_A_const_154; var arg_836 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rtps__16)).Ref(); if linked_832 == nil { rtargs__19 = ifn_833.Invoke_O_O_O__O(arg_834, arg_835, arg_836) } else { rtargs__19 = linked_832.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_831, arg_834, arg_835, arg_836) } } else {
//line :223:1
					var tmp29 any; var root_837 any = A_arbace_go_generic_A_const_140.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_839 lang.IFn

					if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = ops__14; if linked_838 == nil { tmp29 = ifn_839.Invoke_O__O(arg_840) } else { tmp29 = linked_838.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_837, arg_840) }
//line :223:1
					if jrt.J2g_Truth(tmp29) {

						var root_995 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, cname__11)).Ref(); if linked_996 == nil { ifn_997.Invoke_O__O(arg_998) } else { linked_996.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_995, arg_998) }
//line :223:1
						rtargs__19 = nil } else { if A_arbace_go_generic_A_const_71 != nil {


							var root_841 any = A_arbace_go_generic_A_const_155.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, A_arbace_go_generic_receiver_targs_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any = x__9; var arg_845 any = cname__11; var arg_846 any; var root_847 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_849 lang.IFn; if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = ops__14; if linked_848 == nil { arg_846 = ifn_849.Invoke_O__O(arg_850) } else { arg_846 = linked_848.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_847, arg_850) }; if linked_842 == nil { rtargs__19 = ifn_843.Invoke_O_O_O__O(arg_844, arg_845, arg_846) } else { rtargs__19 = linked_842.(*A_arbace_go_generic_receiver_targs_A).Invoke_O_O_O_O__O(root_841, arg_844, arg_845, arg_846) } } else {
//line :223:1
								rtargs__19 = nil
							}
						}
				}
			if jrt.J2g_Truth(rtargs__19) { var rt__20 any; var root_851 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A_fn_class); var ifn_853 lang.IFn
				if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any; var arg_855 any; var root_857 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = x__9; var arg_861 any = A_arbace_go_generic_A_const_123; if linked_858 == nil { arg_855 = ifn_859.Invoke_O_O__O(arg_860, arg_861) } else { arg_855 = linked_858.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_857, arg_860, arg_861) }; var arg_856 any = rtargs__19; if linked_852 == nil { rt__20 = ifn_853.Invoke_O_O_O__O(arg_854, arg_855, arg_856) } else { rt__20 = linked_852.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A).Invoke_O_O_O_O__O(root_851, arg_854, arg_855, arg_856) }
//line :227:1
				var msig__21 any; var root_862 any = A_arbace_go_generic_A_const_156.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_862, aot_arbace_go_check_decl.A_arbace_go_check_decl_subst_A_fn_class); var ifn_864 lang.IFn

				if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = sig__15; var arg_866 any; var root_867 any = A_arbace_go_generic_A_const_157.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = rtps__16; var arg_871 any = rtargs__19; if linked_868 == nil { arg_866 = ifn_869.Invoke_O_O__O(arg_870, arg_871) } else { arg_866 = linked_868.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_867, arg_870, arg_871) }; if linked_863 == nil { msig__21 = ifn_864.Invoke_O_O__O(arg_865, arg_866) } else { msig__21 = linked_863.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_subst_A).Invoke_O_O_O__O(root_862, arg_865, arg_866) }
//line :227:1
				var rest_ops__22 any; var root_872 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_874 lang.IFn


				if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any; var root_876 any = A_arbace_go_generic_A_const_52.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = ops__14; if linked_877 == nil { arg_875 = ifn_878.Invoke_O__O(arg_879) } else { arg_875 = linked_877.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_876, arg_879) }; if linked_873 == nil { rest_ops__22 = ifn_874.Invoke_O__O(arg_875) } else { rest_ops__22 = linked_873.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_872, arg_875) }
//line :227:1
				var mtargs__23 any; var tmp30 any; var root_880 any = A_arbace_go_generic_A_const_140.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_882 lang.IFn



				if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = mtps__17; if linked_881 == nil { tmp30 = ifn_882.Invoke_O__O(arg_883) } else { tmp30 = linked_881.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_880, arg_883) }; if jrt.J2g_Truth(tmp30) { mtargs__23 = lang.PersistentVector_EMPTY.Ref() } else { var temp__1927000414__auto____23 any; var root_884 any = A_arbace_go_generic_A_const_158.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, A_arbace_go_generic_params_for_A_fn_class); var ifn_886 lang.IFn

					if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = cname__11; var arg_888 any = msig__21; var arg_889 any = rest_ops__22; if linked_885 == nil { temp__1927000414__auto____23 = ifn_886.Invoke_O_O_O__O(arg_887, arg_888, arg_889) } else { temp__1927000414__auto____23 = linked_885.(*A_arbace_go_generic_params_for_A).Invoke_O_O_O_O__O(root_884, arg_887, arg_888, arg_889) }; if jrt.J2g_Truth(temp__1927000414__auto____23) { var ps__24 any = temp__1927000414__auto____23; var root_890 any = A_arbace_go_generic_A_const_159.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, A_arbace_go_generic_infer_targs_A_fn_class); var ifn_892 lang.IFn
						if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = cname__11; var arg_894 any = mtps__17; var arg_895 any; var root_899 any = A_arbace_go_generic_A_const_160.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_899, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rtps__16)).Ref(); var arg_903 any = given__18; if linked_900 == nil { arg_895 = ifn_901.Invoke_O_O__O(arg_902, arg_903) } else { if jrt.Long_InstanceOf(arg_902) { arg_895 = linked_900.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_899, jrt.NN(jrt.Long_Cast(arg_902)).LongValue__J(), arg_902, arg_903) } else { arg_895 = linked_900.(*aot_arbace_core.A_arbace_core_drop_A).Invoke_O_O_O__O(root_899, arg_902, arg_903) } }; var arg_896 any = ps__24; var arg_897 any = rest_ops__22; var arg_898 any; var root_904 any = A_arbace_go_generic_A_const_157.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = rtps__16; var arg_908 any = rtargs__19; if linked_905 == nil { arg_898 = ifn_906.Invoke_O_O__O(arg_907, arg_908) } else { arg_898 = linked_905.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_904, arg_907, arg_908) }; if linked_891 == nil { mtargs__23 = ifn_892.Invoke_O_O_O_O_O_O__O(arg_893, arg_894, arg_895, arg_896, arg_897, arg_898) } else { mtargs__23 = linked_891.(*A_arbace_go_generic_infer_targs_A).Invoke_O_O_O_O_O_O_O__O(root_890, arg_893, arg_894, arg_895, arg_896, arg_897, arg_898) } } else {
//line :233:1
							mtargs__23 = nil
						} }
				if jrt.J2g_Truth(mtargs__23) {
					var root_909 any = A_arbace_go_generic_A_const_161.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, A_arbace_go_generic_instance_fn_A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = x__9; var arg_913 any; var root_915 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any; var root_919 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = rtargs__19; var arg_923 any = mtargs__23; if linked_920 == nil { arg_918 = ifn_921.Invoke_O_O__O(arg_922, arg_923) } else { arg_918 = linked_920.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_919, arg_922, arg_923) }; if linked_916 == nil { arg_913 = ifn_917.Invoke_O__O(arg_918) } else { arg_913 = linked_916.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_915, arg_918) }; var arg_914 any = rt__20; if linked_910 == nil { r__16 = ifn_911.Invoke_O_O_O__O(arg_912, arg_913, arg_914) } else { r__16 = linked_910.(*A_arbace_go_generic_instance_fn_A).Invoke_O_O_O_O__O(root_909, arg_912, arg_913, arg_914) } } else {
//line :235:1
						r__16 = nil } } else {
//line :227:1
							r__16 = nil } } else {
//line :217:1
								var tps__16 any; var root_924 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_926 lang.IFn



















								if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any; var root_928 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = x__9; var arg_932 any = A_arbace_go_generic_A_const_121; if linked_929 == nil { arg_927 = ifn_930.Invoke_O_O__O(arg_931, arg_932) } else { arg_927 = linked_929.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_928, arg_931, arg_932) }; if linked_925 == nil { tps__16 = ifn_926.Invoke_O__O(arg_927) } else { tps__16 = linked_925.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_924, arg_927) }
//line :217:1
								var temp__1927000414__auto____17 any; var root_933 any = A_arbace_go_generic_A_const_158.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, A_arbace_go_generic_params_for_A_fn_class); var ifn_935 lang.IFn




















								if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = cname__11; var arg_937 any = sig__15; var arg_938 any = ops__14; if linked_934 == nil { temp__1927000414__auto____17 = ifn_935.Invoke_O_O_O__O(arg_936, arg_937, arg_938) } else { temp__1927000414__auto____17 = linked_934.(*A_arbace_go_generic_params_for_A).Invoke_O_O_O_O__O(root_933, arg_936, arg_937, arg_938) }; if jrt.J2g_Truth(temp__1927000414__auto____17) { var ps__18 any = temp__1927000414__auto____17; var temp__1927000414__auto____19 any; var root_939 any = A_arbace_go_generic_A_const_159.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, A_arbace_go_generic_infer_targs_A_fn_class); var ifn_941 lang.IFn
									if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = cname__11; var arg_943 any = tps__16; var arg_944 any = ptargs__7; var arg_945 any = ps__18; var arg_946 any = ops__14; var arg_947 any; if linked_940 == nil { temp__1927000414__auto____19 = ifn_941.Invoke_O_O_O_O_O_O__O(arg_942, arg_943, arg_944, arg_945, arg_946, arg_947) } else { temp__1927000414__auto____19 = linked_940.(*A_arbace_go_generic_infer_targs_A).Invoke_O_O_O_O_O_O_O__O(root_939, arg_942, arg_943, arg_944, arg_945, arg_946, arg_947) }; if jrt.J2g_Truth(temp__1927000414__auto____19) { var targs__20 any = temp__1927000414__auto____19; var root_948 any = A_arbace_go_generic_A_const_161.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, A_arbace_go_generic_instance_fn_A_fn_class); var ifn_950 lang.IFn
										if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = x__9; var arg_952 any = targs__20; var arg_953 any; if linked_949 == nil { r__16 = ifn_950.Invoke_O_O_O__O(arg_951, arg_952, arg_953) } else { r__16 = linked_949.(*A_arbace_go_generic_instance_fn_A).Invoke_O_O_O_O__O(root_948, arg_951, arg_952, arg_953) } } else {
//line :239:1
											r__16 = nil } } else {
//line :238:1
												r__16 = nil
											}
							}
		var root_999 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; if linked_1000 == nil { ifn_1001.Invoke__O() } else { linked_1000.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_999) }
//line :207:1
		tmp26 = r__16 }; return nil }(); var root_954 any = A_arbace_go_generic_A_const_162.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_956 lang.IFn; if






	linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; if linked_955 == nil { ifn_956.Invoke__O() } else { linked_955.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_954) }; if /*line :207:1*/ tmp31 != nil { panic(tmp31) }; return tmp26 }






func A_arbace_go_generic_resolve_instance_fn__278000095_A_New() *A_arbace_go_generic_resolve_instance_fn__278000095_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_resolve_instance_fn__278000095_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_go_generic_resolve_instance_fn__278000095_A) Ctor() {}
//line :214:1
func (t *A_arbace_go_generic_resolve_instance_fn__278000095_A) DoInvoke_O_O__O(self, ___278000012__auto____1 any) any { return nil }
func A_arbace_go_generic_resolve_instance_fn__278000097_A_New_O_O(p0, p1 any) *A_arbace_go_generic_resolve_instance_fn__278000097_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_resolve_instance_fn__278000097_A{}; t.Ctor_O_O(p0, p1); return t }
//line :215:1
func (t *A_arbace_go_generic_resolve_instance_fn__278000097_A) Ctor_O_O(c__env, c__k any) { t.F_env = c__env; t.F_k = c__k }
//line :215:1
func (t *A_arbace_go_generic_resolve_instance_fn__278000097_A) Invoke_O_O_O__O(self, i__1, v__2 any) any { var root_790 any = A_arbace_go_generic_A_const_152.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, A_arbace_go_generic_operand_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var tmp1 *jrt.RefArray = jrt.ObjectArray_Cast(t.F_k); var arg_793 any = lang.RT_Aget_O1_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(i__1)); var arg_794 any = v__2; var arg_795 any = i__1; var arg_796 any = t.F_env; if linked_791 == nil { return ifn_792.Invoke_O_O_O_O__O(arg_793, arg_794, arg_795, arg_796) } else { return linked_791.(*A_arbace_go_generic_operand_A).Invoke_O_O_O_O_O__O(root_790, arg_793, arg_794, arg_795, arg_796) } }




























func A_arbace_go_generic_generic_fn_A_New() *A_arbace_go_generic_generic_fn_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_generic_fn_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_go_generic_generic_fn_A) Ctor() {}
//line :244:1
func (t *A_arbace_go_generic_generic_fn_A) Invoke_O_O_O_O_O__O(self, x__0, full__1, env__2, ptargs__3 any) any { var tmp1 *jrt.String = jrt.String_Cast(full__1); var tmp2 any = A_arbace_go_generic_A_const_148; var tmp3 any = A_arbace_go_generic_A_const_149; var tmp4 any = A_arbace_go_generic_A_const_150; var tmp5 any = A_arbace_go_generic_A_const_179; var tmp6 any; var root_1002 any = A_arbace_go_generic_A_const_180.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1004 lang.IFn; if




	linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1003 == nil { tmp6 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp6 = linked_1003.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1002, arg_1005) }; return /*line :244:1*/ lang.GoGenericFn_New_String_O_IFn(tmp1, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, x__0, tmp3, ptargs__3, tmp4, env__2, tmp5, tmp6)), lang.IFn_Cast(A_arbace_go_generic_A_const_181.GetRawRoot__O())) }
//line :244:1
func (t *A_arbace_go_generic_generic_fn_A) Invoke_O_O_O_O__O(self, x__0, full__1, env__2 any) any {


	var root_1006 any = A_arbace_go_generic_A_const_182.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, A_arbace_go_generic_generic_fn_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = x__0; var arg_1010 any = full__1; var arg_1011 any = env__2; var arg_1012 any; if linked_1007 == nil { return ifn_1008.Invoke_O_O_O_O__O(arg_1009, arg_1010, arg_1011, arg_1012) } else { return linked_1007.(*A_arbace_go_generic_generic_fn_A).Invoke_O_O_O_O_O__O(root_1006, arg_1009, arg_1010, arg_1011, arg_1012)
	}
}

func A_arbace_go_generic_instantiate_A_New() *A_arbace_go_generic_instantiate_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_instantiate_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_go_generic_instantiate_A) Ctor() {}
//line :251:1
func (t *A_arbace_go_generic_instantiate_A) Invoke_O_O_O__O(self, g__0, targs__1 any) any { var map__278000102__3 any = lang.GoGenericFn_Cast(g__0).F_data; var map__278000102__4 any; if




	lang.ISeq_InstanceOf(map__278000102__3) { var tmp1 any; var root_1013 any = A_arbace_go_generic_A_const_146.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = map__278000102__3; if linked_1014 == nil { tmp1 = ifn_1015.Invoke_O__O(arg_1016) } else { tmp1 = linked_1014.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1013, arg_1016) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1017 any = A_arbace_go_generic_A_const_147.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = map__278000102__3; if linked_1018 == nil { tmp2 = ifn_1019.Invoke_O__O(arg_1020) } else { tmp2 = linked_1018.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1017, arg_1020) }; map__278000102__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1021 any = A_arbace_go_generic_A_const_14.GetRawRoot__O(); var linked_1022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1021, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1023 lang.IFn; if linked_1022 == nil { ifn_1023 = lang.IFn_Cast(root_1021) } else { ifn_1023 = nil }; var arg_1024 any = map__278000102__3; if linked_1022 == nil { tmp3 = ifn_1023.Invoke_O__O(arg_1024) } else { tmp3 = linked_1022.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1021, arg_1024) }; if jrt.J2g_Truth(tmp3) { var root_1025 any = A_arbace_go_generic_A_const_50.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = map__278000102__3; if linked_1026 == nil { map__278000102__4 = ifn_1027.Invoke_O__O(arg_1028) } else { map__278000102__4 = linked_1026.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1025, arg_1028) } } else { map__278000102__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__278000102__4 = map__278000102__3 }; var obj__5 any = /*line :251:1*/lang.RT_Get_O_O__O_NoInit(map__278000102__4, A_arbace_go_generic_A_const_148); var env__6 any = lang.RT_Get_O_O__O_NoInit(map__278000102__4, A_arbace_go_generic_A_const_150); var ptargs__7 any = lang.RT_Get_O_O__O_NoInit(map__278000102__4, A_arbace_go_generic_A_const_149); var x__8 any = obj__5; var all__9 any; var root_1029 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1031 lang.IFn; if






	linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any; var root_1033 any = A_arbace_go_generic_A_const_15.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = ptargs__7; var arg_1037 any = targs__1; if linked_1034 == nil { arg_1032 = ifn_1035.Invoke_O_O__O(arg_1036, arg_1037) } else { arg_1032 = linked_1034.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1033, arg_1036, arg_1037) }; if linked_1030 == nil { all__9 = ifn_1031.Invoke_O__O(arg_1032) } else { all__9 = linked_1030.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1029, arg_1032) }; var tps__10 any; var root_1038 any = /*line :251:1*/A_arbace_go_generic_A_const_183.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, A_arbace_go_generic_tparams_of_A_fn_class); var ifn_1040 lang.IFn; if







	linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = x__8; if linked_1039 == nil { tps__10 = ifn_1040.Invoke_O__O(arg_1041) } else { tps__10 = linked_1039.(*A_arbace_go_generic_tparams_of_A).Invoke_O_O__O(root_1038, arg_1041) }; var cname__11 any; var root_1042 any = /*line :251:1*/A_arbace_go_generic_A_const_142.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_go_generic_callee_name_A_fn_class); var ifn_1044 lang.IFn; if








	linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = x__8; if linked_1043 == nil { cname__11 = ifn_1044.Invoke_O__O(arg_1045) } else { cname__11 = linked_1043.(*A_arbace_go_generic_callee_name_A).Invoke_O_O__O(root_1042, arg_1045) }; var root_1108 any =
	A_arbace_go_generic_A_const_163.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_164.GetRawRoot__O()); var tmp5 any = A_arbace_go_generic_A_const_165; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_151.Invoke_O__O(env__6)); var tmp7 any; var root_1135 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = x__8; var arg_1139 any = A_arbace_go_generic_A_const_69; if linked_1136 == nil { tmp7 = ifn_1137.Invoke_O_O__O(arg_1138, arg_1139) } else { tmp7 = linked_1136.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1135, arg_1138, arg_1139) }; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 any = A_arbace_go_generic_A_const_39; var tmp10 any; var root_1140 any = A_arbace_go_generic_A_const_166.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = lang.PersistentVector_EMPTY.Ref(); if linked_1141 == nil { tmp10 = ifn_1142.Invoke_O__O(arg_1143) } else { tmp10 = linked_1141.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1140, arg_1143) }; var tmp11 any = tmp10; var tmp12 any = A_arbace_go_generic_A_const_167; var tmp13 any = A_arbace_go_generic_A_const_168; var tmp14 any = A_arbace_go_generic_A_const_169; var tmp15 any = A_arbace_go_generic_A_const_170.GetRawRoot__O(); var tmp16 any = A_arbace_go_generic_A_const_171; var tmp17 any = A_arbace_go_generic_A_const_172.GetRawRoot__O(); var tmp18 any = A_arbace_go_generic_A_const_173; var tmp19 any = A_arbace_go_generic_A_const_174.GetRawRoot__O(); var tmp20 any = A_arbace_go_generic_A_const_175; var tmp21 any = A_arbace_go_generic_A_const_156.GetRawRoot__O(); var tmp22 any = A_arbace_go_generic_A_const_176; var tmp23 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var tmp24 any = A_arbace_go_generic_A_const_177; var tmp25 *lang.Compiler_AOTRestFn; var fnbody__1145 any = A_arbace_go_generic_instantiate_fn__278000104_A_New(); var tmp26 *jrt.Class; var fncls__1144 *jrt.Class = A_arbace_go_generic_instantiate_fn__278000104_A_fn_class; if fncls__1144 == nil { var fncls__1144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, true, nil); A_arbace_go_generic_instantiate_fn__278000104_A_fn_class = fncls__1144d; tmp26 = fncls__1144d } else { tmp26 = fncls__1144 }; tmp25 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__1145, tmp26, nil, 0); arg_1111 = tmp4.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp5, tmp8, tmp9, tmp11, tmp12, nil, tmp13, nil, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25.Ref()); if linked_1109 == nil { ifn_1110.Invoke_O__O(arg_1111) } else { linked_1109.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1108, arg_1111) }; var tmp27 any; tmp30 := /*line :251:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var all__14 any; var root_1046 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1048 lang.IFn










		if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any; var fnbody__1057 any = A_arbace_go_generic_instantiate_fn__278000106_A_New_O(env__6); var tmp28 *jrt.Class; var fncls__1056 *jrt.Class = A_arbace_go_generic_instantiate_fn__278000106_A_fn_class; if fncls__1056 == nil { var fncls__1056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__1057); A_arbace_go_generic_instantiate_fn__278000106_A_fn_class = fncls__1056d; tmp28 = fncls__1056d } else { tmp28 = fncls__1056 }; arg_1049 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1057, tmp28, nil); var arg_1050 any = all__9; if linked_1047 == nil { all__14 = ifn_1048.Invoke_O_O__O(arg_1049, arg_1050) } else { all__14 = linked_1047.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1046, arg_1049, arg_1050) }
		if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(all__14)), int64(lang.RT_Count_O__I_NoInit(tps__10))) {

			var root_1146 any = A_arbace_go_generic_A_const_133.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, A_arbace_go_generic_error_BANG__A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = lang.IFn_Cast(A_arbace_go_generic_A_const_134.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_42, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(all__14)).Ref(), cname__11, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tps__10)).Ref()); if linked_1147 == nil { ifn_1148.Invoke_O__O(arg_1149) } else { linked_1147.(*A_arbace_go_generic_error_BANG__A).Invoke_O_O__O(root_1146, arg_1149) }
			var root_1058 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; if linked_1059 == nil { tmp27 = ifn_1060.Invoke__O() } else { tmp27 = linked_1059.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_1058) } } else {
//line :263:1
				if lang.Util_Equiv_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(all__14)), int64(lang.RT_Count_O__I_NoInit(tps__10))) { var rtps__15 any; var root_1061 any = A_arbace_go_generic_A_const_56.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1063 lang.IFn




					if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any; var root_1065 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = x__8; var arg_1069 any = A_arbace_go_generic_A_const_120; if linked_1066 == nil { arg_1064 = ifn_1067.Invoke_O_O__O(arg_1068, arg_1069) } else { arg_1064 = linked_1066.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1065, arg_1068, arg_1069) }; if linked_1062 == nil { rtps__15 = ifn_1063.Invoke_O__O(arg_1064) } else { rtps__15 = linked_1062.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1061, arg_1064) }
					var root_1157 any = A_arbace_go_generic_A_const_141.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any; var arg_1161 any = tps__10; var arg_1162 any = all__14; var arg_1163 any; if linked_1158 == nil { ifn_1159.Invoke_O_O_O_O__O(arg_1160, arg_1161, arg_1162, arg_1163) } else { linked_1158.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A).Invoke_O_O_O_O_O__O(root_1157, arg_1160, arg_1161, arg_1162, arg_1163) }
					var root_1164 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; if linked_1165 == nil { ifn_1166.Invoke__O() } else { linked_1165.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_1164) }
					var root_1070 any = A_arbace_go_generic_A_const_161.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, A_arbace_go_generic_instance_fn_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = x__8; var arg_1074 any = all__14; var arg_1075 any; var tmp29 any; var root_1076 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = x__8; var arg_1080 any = A_arbace_go_generic_A_const_122; if linked_1077 == nil { tmp29 = ifn_1078.Invoke_O_O__O(arg_1079, arg_1080) } else { tmp29 = linked_1077.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1076, arg_1079, arg_1080) }; if jrt.J2g_Truth(tmp29) { var root_1081 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any; var arg_1085 any; var root_1087 any = A_arbace_go_generic_A_const_119.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_go_check_env.A_arbace_go_check_env_o_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = x__8; var arg_1091 any = A_arbace_go_generic_A_const_123; if linked_1088 == nil { arg_1085 = ifn_1089.Invoke_O_O__O(arg_1090, arg_1091) } else { arg_1085 = linked_1088.(*aot_arbace_go_check_env.A_arbace_go_check_env_o_A).Invoke_O_O_O__O(root_1087, arg_1090, arg_1091) }; var arg_1086 any; var root_1092 any = A_arbace_go_generic_A_const_153.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_subvec_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = all__14; var arg_1096 any = A_arbace_go_generic_A_const_154; var arg_1097 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rtps__15)).Ref(); if linked_1093 == nil { arg_1086 = ifn_1094.Invoke_O_O_O__O(arg_1095, arg_1096, arg_1097) } else { arg_1086 = linked_1093.(*aot_arbace_core.A_arbace_core_subvec_A).Invoke_O_O_O_O__O(root_1092, arg_1095, arg_1096, arg_1097) }; if linked_1082 == nil { arg_1075 = ifn_1083.Invoke_O_O_O__O(arg_1084, arg_1085, arg_1086) } else { arg_1075 = linked_1082.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A).Invoke_O_O_O_O__O(root_1081, arg_1084, arg_1085, arg_1086) } } else { arg_1075 = nil }; if linked_1071 == nil { tmp27 = ifn_1072.Invoke_O_O_O__O(arg_1073, arg_1074, arg_1075) } else { tmp27 = linked_1071.(*A_arbace_go_generic_instance_fn_A).Invoke_O_O_O_O__O(root_1070, arg_1073, arg_1074, arg_1075) } } else {
//line :263:1
						if A_arbace_go_generic_A_const_71 != nil {








							var root_1098 any = A_arbace_go_generic_A_const_182.GetRawRoot__O(); var linked_1099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1098, A_arbace_go_generic_generic_fn_A_fn_class); var ifn_1100 lang.IFn; if linked_1099 == nil { ifn_1100 = lang.IFn_Cast(root_1098) } else { ifn_1100 = nil }; var arg_1101 any = x__8; var arg_1102 any = lang.GoGenericFn_Cast(g__0).F_name.Ref(); var arg_1103 any = env__6; var arg_1104 any = all__14; if linked_1099 == nil { tmp27 = ifn_1100.Invoke_O_O_O_O__O(arg_1101, arg_1102, arg_1103, arg_1104) } else { tmp27 = linked_1099.(*A_arbace_go_generic_generic_fn_A).Invoke_O_O_O_O_O__O(root_1098, arg_1101, arg_1102, arg_1103, arg_1104) } } else {
//line :263:1
								tmp27 = nil } } } }; return nil }(); var root_1105 any = /*line :251:1*/A_arbace_go_generic_A_const_162.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1107 lang.IFn; if









	linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; if linked_1106 == nil { ifn_1107.Invoke__O() } else { linked_1106.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1105) }; if /*line :251:1*/ tmp30 != nil { panic(tmp30) }; return tmp27 }









func A_arbace_go_generic_instantiate_fn__278000104_A_New() *A_arbace_go_generic_instantiate_fn__278000104_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_instantiate_fn__278000104_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_go_generic_instantiate_fn__278000104_A) Ctor() {}
//line :261:1
func (t *A_arbace_go_generic_instantiate_fn__278000104_A) DoInvoke_O_O__O(self, ___278000012__auto____1 any) any { return nil }
func A_arbace_go_generic_instantiate_fn__278000106_A_New_O(p0 any) *A_arbace_go_generic_instantiate_fn__278000106_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_instantiate_fn__278000106_A{}; t.Ctor_O(p0); return t }
//line :262:1
func (t *A_arbace_go_generic_instantiate_fn__278000106_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :262:1
func (t *A_arbace_go_generic_instantiate_fn__278000106_A) Invoke_O_O__O(self, p1__278000101_SHARP___1 any) any { var root_1051 any = A_arbace_go_generic_A_const_61.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, A_arbace_go_generic_rehome_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = p1__278000101_SHARP___1; var arg_1055 any = t.F_env; if linked_1052 == nil { return ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { return linked_1052.(*A_arbace_go_generic_rehome_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) } }











func A_arbace_go_generic_type_instance_A_New() *A_arbace_go_generic_type_instance_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_type_instance_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_go_generic_type_instance_A) Ctor() {}
//line :274:1
func (t *A_arbace_go_generic_type_instance_A) Invoke_O_O_O_O__O(self, g__0, targs__1, env__2 any) any { var i__4 any; var root_1167 any = A_arbace_go_generic_A_const_64.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_go_check_types.A_arbace_go_check_types_info_A_fn_class); var ifn_1169 lang.IFn; if



	linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = g__0; if linked_1168 == nil { i__4 = ifn_1169.Invoke_O__O(arg_1170) } else { i__4 = linked_1168.(*aot_arbace_go_check_types.A_arbace_go_check_types_info_A).Invoke_O_O__O(root_1167, arg_1170) }; var root_1196 any =
	A_arbace_go_generic_A_const_163.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_generic_A_const_164.GetRawRoot__O()); var tmp2 any = A_arbace_go_generic_A_const_165; var tmp3 any = lang.IFn_Cast(A_arbace_go_generic_A_const_151.Invoke_O__O(env__2)).Invoke_O__O(A_arbace_go_generic_A_const_69.Invoke_O__O(i__4)); var tmp4 any = A_arbace_go_generic_A_const_39; var tmp5 any; var root_1223 any = A_arbace_go_generic_A_const_166.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_1225 lang.IFn; if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any = lang.PersistentVector_EMPTY.Ref(); if linked_1224 == nil { tmp5 = ifn_1225.Invoke_O__O(arg_1226) } else { tmp5 = linked_1224.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_1223, arg_1226) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_go_generic_A_const_167; var tmp8 any = A_arbace_go_generic_A_const_168; var tmp9 any = A_arbace_go_generic_A_const_169; var tmp10 any = A_arbace_go_generic_A_const_170.GetRawRoot__O(); var tmp11 any = A_arbace_go_generic_A_const_171; var tmp12 any = A_arbace_go_generic_A_const_172.GetRawRoot__O(); var tmp13 any = A_arbace_go_generic_A_const_173; var tmp14 any = A_arbace_go_generic_A_const_174.GetRawRoot__O(); var tmp15 any = A_arbace_go_generic_A_const_175; var tmp16 any = A_arbace_go_generic_A_const_156.GetRawRoot__O(); var tmp17 any = A_arbace_go_generic_A_const_176; var tmp18 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var tmp19 any = A_arbace_go_generic_A_const_177; var tmp20 *lang.Compiler_AOTRestFn; var fnbody__1228 any = A_arbace_go_generic_type_instance_fn__278000110_A_New(); var tmp21 *jrt.Class; var fncls__1227 *jrt.Class = A_arbace_go_generic_type_instance_fn__278000110_A_fn_class; if fncls__1227 == nil { var fncls__1227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, true, nil); A_arbace_go_generic_type_instance_fn__278000110_A_fn_class = fncls__1227d; tmp21 = fncls__1227d } else { tmp21 = fncls__1227 }; tmp20 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__1228, tmp21, nil, 0); arg_1199 = tmp1.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp6, tmp7, nil, tmp8, nil, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20.Ref()); if linked_1197 == nil { ifn_1198.Invoke_O__O(arg_1199) } else { linked_1197.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1196, arg_1199) }; var tmp22 any; tmp25 := /*line :274:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var targs__7 any; var root_1171 any = A_arbace_go_generic_A_const_66.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1173 lang.IFn





		if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any; var fnbody__1182 any = A_arbace_go_generic_type_instance_fn__278000112_A_New_O(env__2); var tmp23 *jrt.Class; var fncls__1181 *jrt.Class = A_arbace_go_generic_type_instance_fn__278000112_A_fn_class; if fncls__1181 == nil { var fncls__1181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__1182); A_arbace_go_generic_type_instance_fn__278000112_A_fn_class = fncls__1181d; tmp23 = fncls__1181d } else { tmp23 = fncls__1181 }; arg_1174 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1182, tmp23, nil); var arg_1175 any = targs__1; if linked_1172 == nil { targs__7 = ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { targs__7 = linked_1172.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }
//line :274:1
		var inst__8 any; var root_1183 any = A_arbace_go_generic_A_const_68.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A_fn_class); var ifn_1185 lang.IFn






		if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any; var arg_1187 any = g__0; var arg_1188 any = targs__7; if linked_1184 == nil { inst__8 = ifn_1185.Invoke_O_O_O__O(arg_1186, arg_1187, arg_1188) } else { inst__8 = linked_1184.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_instantiate_A).Invoke_O_O_O_O__O(root_1183, arg_1186, arg_1187, arg_1188) }
		if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_go_generic_A_const_185, inst__8) { var root_1229 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; if linked_1230 == nil { ifn_1231.Invoke__O() } else { linked_1230.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_1229) } }
		var root_1232 any = A_arbace_go_generic_A_const_141.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any; var arg_1236 any = A_arbace_go_generic_A_const_121.Invoke_O__O(i__4); var arg_1237 any = targs__7; var arg_1238 any; if linked_1233 == nil { ifn_1234.Invoke_O_O_O_O__O(arg_1235, arg_1236, arg_1237, arg_1238) } else { linked_1233.(*aot_arbace_go_check_decl.A_arbace_go_check_decl_verify_BANG__A).Invoke_O_O_O_O_O__O(root_1232, arg_1235, arg_1236, arg_1237, arg_1238) }
		var root_1239 any = A_arbace_go_generic_A_const_178.GetRawRoot__O(); var linked_1240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1239, A_arbace_go_generic_check_errors_BANG__A_fn_class); var ifn_1241 lang.IFn; if linked_1240 == nil { ifn_1241 = lang.IFn_Cast(root_1239) } else { ifn_1241 = nil }; if linked_1240 == nil { ifn_1241.Invoke__O() } else { linked_1240.(*A_arbace_go_generic_check_errors_BANG__A).Invoke_O__O(root_1239) }
//line :274:1
		var tmp24 any; var root_1189 any = A_arbace_go_generic_A_const_184.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_go_build.A_arbace_go_build_desc_A_fn_class); var ifn_1191 lang.IFn










		if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = inst__8; if linked_1190 == nil { tmp24 = ifn_1191.Invoke_O__O(arg_1192) } else { tmp24 = linked_1190.(*aot_arbace_go_build.A_arbace_go_build_desc_A).Invoke_O_O__O(root_1189, arg_1192) }
//line :274:1
		tmp22 = lang.GoType_New_O(tmp24) }; return nil }(); var root_1193 any = A_arbace_go_generic_A_const_162.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1195 lang.IFn; if




	linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; if linked_1194 == nil { ifn_1195.Invoke__O() } else { linked_1194.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1193) }; if /*line :274:1*/ tmp25 != nil { panic(tmp25) }; return tmp22 }




func A_arbace_go_generic_type_instance_fn__278000110_A_New() *A_arbace_go_generic_type_instance_fn__278000110_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_type_instance_fn__278000110_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_go_generic_type_instance_fn__278000110_A) Ctor() {}
//line :279:1
func (t *A_arbace_go_generic_type_instance_fn__278000110_A) DoInvoke_O_O__O(self, ___278000012__auto____1 any) any { return nil }
func A_arbace_go_generic_type_instance_fn__278000112_A_New_O(p0 any) *A_arbace_go_generic_type_instance_fn__278000112_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_type_instance_fn__278000112_A{}; t.Ctor_O(p0); return t }
//line :280:1
func (t *A_arbace_go_generic_type_instance_fn__278000112_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :280:1
func (t *A_arbace_go_generic_type_instance_fn__278000112_A) Invoke_O_O__O(self, p1__278000109_SHARP___1 any) any { var root_1176 any = A_arbace_go_generic_A_const_61.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, A_arbace_go_generic_rehome_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = p1__278000109_SHARP___1; var arg_1180 any = t.F_env; if linked_1177 == nil { return ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { return linked_1177.(*A_arbace_go_generic_rehome_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) } }












type A_arbace_go_generic_A struct{ jrt.Object }

var A_arbace_go_generic_A_const_pool *jrt.RefArray

var A_arbace_go_generic_A_const_0 *lang.Var

var A_arbace_go_generic_A_const_1 any

var A_arbace_go_generic_A_const_2 *lang.Var

var A_arbace_go_generic_A_const_3 any

var A_arbace_go_generic_A_const_4 any

var A_arbace_go_generic_A_const_5 any

var A_arbace_go_generic_A_const_6 any

var A_arbace_go_generic_A_const_7 any

var A_arbace_go_generic_A_const_8 any

var A_arbace_go_generic_A_const_9 *lang.Var

var A_arbace_go_generic_A_const_10 *lang.Var

var A_arbace_go_generic_A_const_11 *lang.Var

var A_arbace_go_generic_A_const_12 *lang.Var

var A_arbace_go_generic_A_const_13 any

var A_arbace_go_generic_A_const_14 *lang.Var

var A_arbace_go_generic_A_const_15 *lang.Var

var A_arbace_go_generic_A_const_16 *lang.Var

var A_arbace_go_generic_A_const_17 any

var A_arbace_go_generic_A_const_18 *lang.Var

var A_arbace_go_generic_A_const_19 *lang.Var

var A_arbace_go_generic_A_const_20 any

var A_arbace_go_generic_A_const_21 any

var A_arbace_go_generic_A_const_22 any

var A_arbace_go_generic_A_const_23 any

var A_arbace_go_generic_A_const_24 any

var A_arbace_go_generic_A_const_25 any

var A_arbace_go_generic_A_const_26 any

var A_arbace_go_generic_A_const_27 any

var A_arbace_go_generic_A_const_28 any

var A_arbace_go_generic_A_const_29 any

var A_arbace_go_generic_A_const_30 any

var A_arbace_go_generic_A_const_31 any

var A_arbace_go_generic_A_const_32 any

var A_arbace_go_generic_A_const_33 any

var A_arbace_go_generic_A_const_34 any

var A_arbace_go_generic_A_const_35 any

var A_arbace_go_generic_A_const_36 any

var A_arbace_go_generic_A_const_37 any

var A_arbace_go_generic_A_const_38 any

var A_arbace_go_generic_A_const_39 *lang.Var

var A_arbace_go_generic_A_const_40 *lang.Var

var A_arbace_go_generic_A_const_41 *lang.Var

var A_arbace_go_generic_A_const_42 *lang.Var

var A_arbace_go_generic_A_const_43 *lang.Var

var A_arbace_go_generic_A_const_44 *lang.Var

var A_arbace_go_generic_A_const_45 *lang.Var

var A_arbace_go_generic_A_const_46 *lang.Keyword

var A_arbace_go_generic_A_const_47 *lang.Var

var A_arbace_go_generic_A_const_48 *lang.Var

var A_arbace_go_generic_A_const_49 *lang.Var

var A_arbace_go_generic_A_const_50 *lang.Var

var A_arbace_go_generic_A_const_51 *lang.Var

var A_arbace_go_generic_A_const_52 *lang.Var

var A_arbace_go_generic_A_const_53 *lang.Var

var A_arbace_go_generic_A_const_54 any

var A_arbace_go_generic_A_const_55 *lang.Keyword

var A_arbace_go_generic_A_const_56 *lang.Var

var A_arbace_go_generic_A_const_57 *lang.Var

var A_arbace_go_generic_A_const_58 *lang.Keyword

var A_arbace_go_generic_A_const_59 *lang.Var

var A_arbace_go_generic_A_const_60 *lang.Keyword

var A_arbace_go_generic_A_const_61 *lang.Var

var A_arbace_go_generic_A_const_62 *lang.Var

var A_arbace_go_generic_A_const_63 *lang.Var

var A_arbace_go_generic_A_const_64 *lang.Var

var A_arbace_go_generic_A_const_65 *lang.Keyword

var A_arbace_go_generic_A_const_66 *lang.Var

var A_arbace_go_generic_A_const_67 *lang.Keyword

var A_arbace_go_generic_A_const_68 *lang.Var

var A_arbace_go_generic_A_const_69 *lang.Keyword

var A_arbace_go_generic_A_const_70 *lang.Keyword

var A_arbace_go_generic_A_const_71 *lang.Keyword

var A_arbace_go_generic_A_const_72 *lang.Keyword

var A_arbace_go_generic_A_const_73 *lang.Var

var A_arbace_go_generic_A_const_74 *lang.Keyword

var A_arbace_go_generic_A_const_75 *lang.Keyword

var A_arbace_go_generic_A_const_76 *lang.Keyword

var A_arbace_go_generic_A_const_77 *lang.Keyword

var A_arbace_go_generic_A_const_78 *lang.Keyword

var A_arbace_go_generic_A_const_79 *lang.Keyword

var A_arbace_go_generic_A_const_80 *lang.Var

var A_arbace_go_generic_A_const_81 any

var A_arbace_go_generic_A_const_82 *lang.Var

var A_arbace_go_generic_A_const_83 *lang.Keyword

var A_arbace_go_generic_A_const_84 *lang.Keyword

var A_arbace_go_generic_A_const_85 *lang.Keyword

var A_arbace_go_generic_A_const_86 *lang.Var

var A_arbace_go_generic_A_const_87 *lang.Keyword

var A_arbace_go_generic_A_const_88 *lang.Var

var A_arbace_go_generic_A_const_89 any

var A_arbace_go_generic_A_const_90 *lang.Var

var A_arbace_go_generic_A_const_91 *lang.Var

var A_arbace_go_generic_A_const_92 *lang.Var

var A_arbace_go_generic_A_const_93 *lang.Var

var A_arbace_go_generic_A_const_94 *lang.Keyword

var A_arbace_go_generic_A_const_95 *lang.Var

var A_arbace_go_generic_A_const_96 *lang.Keyword

var A_arbace_go_generic_A_const_97 *lang.Keyword

var A_arbace_go_generic_A_const_98 *lang.Keyword

var A_arbace_go_generic_A_const_99 *lang.Keyword

var A_arbace_go_generic_A_const_100 *lang.Keyword

var A_arbace_go_generic_A_const_101 any

var A_arbace_go_generic_A_const_102 *lang.Var

var A_arbace_go_generic_A_const_103 *lang.Var

var A_arbace_go_generic_A_const_104 *lang.Keyword

var A_arbace_go_generic_A_const_105 *lang.Keyword

var A_arbace_go_generic_A_const_106 *lang.Keyword

var A_arbace_go_generic_A_const_107 *lang.Keyword

var A_arbace_go_generic_A_const_108 *lang.Keyword

var A_arbace_go_generic_A_const_109 *lang.Keyword

var A_arbace_go_generic_A_const_110 *lang.Keyword

var A_arbace_go_generic_A_const_111 *lang.Keyword

var A_arbace_go_generic_A_const_112 *lang.Var

var A_arbace_go_generic_A_const_113 *lang.Keyword

var A_arbace_go_generic_A_const_114 *lang.Keyword

var A_arbace_go_generic_A_const_115 *lang.Keyword

var A_arbace_go_generic_A_const_116 *lang.Keyword

var A_arbace_go_generic_A_const_117 *lang.Keyword

var A_arbace_go_generic_A_const_118 *lang.Keyword

var A_arbace_go_generic_A_const_119 *lang.Var

var A_arbace_go_generic_A_const_120 *lang.Keyword

var A_arbace_go_generic_A_const_121 *lang.Keyword

var A_arbace_go_generic_A_const_122 *lang.Keyword

var A_arbace_go_generic_A_const_123 *lang.Keyword

var A_arbace_go_generic_A_const_124 *lang.Keyword

var A_arbace_go_generic_A_const_125 *lang.Var

var A_arbace_go_generic_A_const_126 *lang.Var

var A_arbace_go_generic_A_const_127 *lang.Var

var A_arbace_go_generic_A_const_128 any

var A_arbace_go_generic_A_const_129 any

var A_arbace_go_generic_A_const_130 *lang.Var

var A_arbace_go_generic_A_const_131 *lang.Var

var A_arbace_go_generic_A_const_132 *lang.Var

var A_arbace_go_generic_A_const_133 *lang.Var

var A_arbace_go_generic_A_const_134 *lang.Var

var A_arbace_go_generic_A_const_135 *lang.Var

var A_arbace_go_generic_A_const_136 *lang.Var

var A_arbace_go_generic_A_const_137 *lang.Var

var A_arbace_go_generic_A_const_138 any

var A_arbace_go_generic_A_const_139 *lang.Var

var A_arbace_go_generic_A_const_140 *lang.Var

var A_arbace_go_generic_A_const_141 *lang.Var

var A_arbace_go_generic_A_const_142 *lang.Var

var A_arbace_go_generic_A_const_143 *lang.Var

var A_arbace_go_generic_A_const_144 *lang.Var

var A_arbace_go_generic_A_const_145 *lang.Var

var A_arbace_go_generic_A_const_146 *lang.Var

var A_arbace_go_generic_A_const_147 *lang.Var

var A_arbace_go_generic_A_const_148 *lang.Keyword

var A_arbace_go_generic_A_const_149 *lang.Keyword

var A_arbace_go_generic_A_const_150 *lang.Keyword

var A_arbace_go_generic_A_const_151 *lang.Keyword

var A_arbace_go_generic_A_const_152 *lang.Var

var A_arbace_go_generic_A_const_153 *lang.Var

var A_arbace_go_generic_A_const_154 any

var A_arbace_go_generic_A_const_155 *lang.Var

var A_arbace_go_generic_A_const_156 *lang.Var

var A_arbace_go_generic_A_const_157 *lang.Var

var A_arbace_go_generic_A_const_158 *lang.Var

var A_arbace_go_generic_A_const_159 *lang.Var

var A_arbace_go_generic_A_const_160 *lang.Var

var A_arbace_go_generic_A_const_161 *lang.Var

var A_arbace_go_generic_A_const_162 *lang.Var

var A_arbace_go_generic_A_const_163 *lang.Var

var A_arbace_go_generic_A_const_164 *lang.Var

var A_arbace_go_generic_A_const_165 *lang.Var

var A_arbace_go_generic_A_const_166 *lang.Var

var A_arbace_go_generic_A_const_167 *lang.Var

var A_arbace_go_generic_A_const_168 *lang.Var

var A_arbace_go_generic_A_const_169 *lang.Var

var A_arbace_go_generic_A_const_170 *lang.Var

var A_arbace_go_generic_A_const_171 *lang.Var

var A_arbace_go_generic_A_const_172 *lang.Var

var A_arbace_go_generic_A_const_173 *lang.Var

var A_arbace_go_generic_A_const_174 *lang.Var

var A_arbace_go_generic_A_const_175 *lang.Var

var A_arbace_go_generic_A_const_176 *lang.Var

var A_arbace_go_generic_A_const_177 *lang.Var

var A_arbace_go_generic_A_const_178 *lang.Var

var A_arbace_go_generic_A_const_179 *lang.Keyword

var A_arbace_go_generic_A_const_180 *lang.Var

var A_arbace_go_generic_A_const_181 *lang.Var

var A_arbace_go_generic_A_const_182 *lang.Var

var A_arbace_go_generic_A_const_183 *lang.Var

var A_arbace_go_generic_A_const_184 *lang.Var

var A_arbace_go_generic_A_const_185 *lang.Keyword

var A_arbace_go_generic_A_init jrt.ClassInit

func A_arbace_go_generic_A_Init() { if !A_arbace_go_generic_A_init.Done() { A_arbace_go_generic_A_init.Run(A_arbace_go_generic_A_clinit) } }

func A_arbace_go_generic_A_clinit() { A_arbace_go_generic_A_clinit_p0(); A_arbace_go_generic_A_clinit_p1(); A_arbace_go_generic_A_clinit_p2(); A_arbace_go_generic_A_clinit_p3(); A_arbace_go_generic_A_clinit_p4(); A_arbace_go_generic_A_clinit_p5(); A_arbace_go_generic_A_clinit_p6(); A_arbace_go_generic_A_clinit_p7(); A_arbace_go_generic_A_clinit_p8(); A_arbace_go_generic_A_clinit_p9(); A_arbace_go_generic_A_clinit_p10(); A_arbace_go_generic_A_clinit_p11(); A_arbace_go_generic_A_clinit_p12(); A_arbace_go_generic_A_clinit_p13(); A_arbace_go_generic_A_clinit_p14() }

func A_arbace_go_generic_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_generic_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 273); A_arbace_go_generic_A_const_0 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[87]); A_arbace_go_generic_A_const_1 = A_arbace_go_generic_A_const_pool.A[88]; A_arbace_go_generic_A_const_2 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[89]); A_arbace_go_generic_A_const_3 = A_arbace_go_generic_A_const_pool.A[90]; A_arbace_go_generic_A_const_4 = A_arbace_go_generic_A_const_pool.A[91]; A_arbace_go_generic_A_const_5 = A_arbace_go_generic_A_const_pool.A[92]; A_arbace_go_generic_A_const_6 = A_arbace_go_generic_A_const_pool.A[93]; A_arbace_go_generic_A_const_7 = A_arbace_go_generic_A_const_pool.A[94]; A_arbace_go_generic_A_const_8 = A_arbace_go_generic_A_const_pool.A[95]; A_arbace_go_generic_A_const_9 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[96]); A_arbace_go_generic_A_const_10 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[97]); A_arbace_go_generic_A_const_11 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[98]); A_arbace_go_generic_A_const_12 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[99]) }

func A_arbace_go_generic_A_clinit_p1() { A_arbace_go_generic_A_const_13 = A_arbace_go_generic_A_const_pool.A[100]; A_arbace_go_generic_A_const_14 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[101]); A_arbace_go_generic_A_const_15 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[102]); A_arbace_go_generic_A_const_16 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[103]); A_arbace_go_generic_A_const_17 = A_arbace_go_generic_A_const_pool.A[104]; A_arbace_go_generic_A_const_18 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[105]); A_arbace_go_generic_A_const_19 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[106]); A_arbace_go_generic_A_const_20 = A_arbace_go_generic_A_const_pool.A[107]; A_arbace_go_generic_A_const_21 = A_arbace_go_generic_A_const_pool.A[108]; A_arbace_go_generic_A_const_22 = A_arbace_go_generic_A_const_pool.A[109]; A_arbace_go_generic_A_const_23 = A_arbace_go_generic_A_const_pool.A[110]; A_arbace_go_generic_A_const_24 = A_arbace_go_generic_A_const_pool.A[111]; A_arbace_go_generic_A_const_25 = A_arbace_go_generic_A_const_pool.A[112]; A_arbace_go_generic_A_const_26 = A_arbace_go_generic_A_const_pool.A[113] }

func A_arbace_go_generic_A_clinit_p2() { A_arbace_go_generic_A_const_27 = A_arbace_go_generic_A_const_pool.A[114]; A_arbace_go_generic_A_const_28 = A_arbace_go_generic_A_const_pool.A[115]; A_arbace_go_generic_A_const_29 = A_arbace_go_generic_A_const_pool.A[116]; A_arbace_go_generic_A_const_30 = A_arbace_go_generic_A_const_pool.A[117]; A_arbace_go_generic_A_const_31 = A_arbace_go_generic_A_const_pool.A[118]; A_arbace_go_generic_A_const_32 = A_arbace_go_generic_A_const_pool.A[119]; A_arbace_go_generic_A_const_33 = A_arbace_go_generic_A_const_pool.A[120]; A_arbace_go_generic_A_const_34 = A_arbace_go_generic_A_const_pool.A[121]; A_arbace_go_generic_A_const_35 = A_arbace_go_generic_A_const_pool.A[122]; A_arbace_go_generic_A_const_36 = A_arbace_go_generic_A_const_pool.A[123]; A_arbace_go_generic_A_const_37 = A_arbace_go_generic_A_const_pool.A[124]; A_arbace_go_generic_A_const_38 = A_arbace_go_generic_A_const_pool.A[125]; A_arbace_go_generic_A_const_39 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[126]); A_arbace_go_generic_A_const_40 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[127]); A_arbace_go_generic_A_const_41 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[128]) }

func A_arbace_go_generic_A_clinit_p3() { A_arbace_go_generic_A_const_42 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[129]); A_arbace_go_generic_A_const_43 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[130]); A_arbace_go_generic_A_const_44 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[131]); A_arbace_go_generic_A_const_45 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[132]); A_arbace_go_generic_A_const_46 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[133]); A_arbace_go_generic_A_const_47 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[134]); A_arbace_go_generic_A_const_48 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[135]); A_arbace_go_generic_A_const_49 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[136]); A_arbace_go_generic_A_const_50 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[137]); A_arbace_go_generic_A_const_51 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[138]); A_arbace_go_generic_A_const_52 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[139]); A_arbace_go_generic_A_const_53 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[140]) }

func A_arbace_go_generic_A_clinit_p4() { A_arbace_go_generic_A_const_54 = A_arbace_go_generic_A_const_pool.A[141]; A_arbace_go_generic_A_const_55 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[142]); A_arbace_go_generic_A_const_56 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[143]); A_arbace_go_generic_A_const_57 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[144]); A_arbace_go_generic_A_const_58 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[145]); A_arbace_go_generic_A_const_59 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[146]); A_arbace_go_generic_A_const_60 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[147]); A_arbace_go_generic_A_const_61 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[148]); A_arbace_go_generic_A_const_62 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[149]); A_arbace_go_generic_A_const_63 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[150]); A_arbace_go_generic_A_const_64 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[151]); A_arbace_go_generic_A_const_65 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[152]) }

func A_arbace_go_generic_A_clinit_p5() { A_arbace_go_generic_A_const_66 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[153]); A_arbace_go_generic_A_const_67 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[154]); A_arbace_go_generic_A_const_68 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[155]); A_arbace_go_generic_A_const_69 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[156]); A_arbace_go_generic_A_const_70 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[157]); A_arbace_go_generic_A_const_71 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[158]); A_arbace_go_generic_A_const_72 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[159]); A_arbace_go_generic_A_const_73 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[160]); A_arbace_go_generic_A_const_74 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[161]); A_arbace_go_generic_A_const_75 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[162]); A_arbace_go_generic_A_const_76 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[163]); A_arbace_go_generic_A_const_77 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[164]) }

func A_arbace_go_generic_A_clinit_p6() { A_arbace_go_generic_A_const_78 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[165]); A_arbace_go_generic_A_const_79 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[166]); A_arbace_go_generic_A_const_80 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[167]); A_arbace_go_generic_A_const_81 = A_arbace_go_generic_A_const_pool.A[168]; A_arbace_go_generic_A_const_82 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[169]); A_arbace_go_generic_A_const_83 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[170]); A_arbace_go_generic_A_const_84 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[171]); A_arbace_go_generic_A_const_85 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[172]); A_arbace_go_generic_A_const_86 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[173]); A_arbace_go_generic_A_const_87 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[174]); A_arbace_go_generic_A_const_88 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[175]); A_arbace_go_generic_A_const_89 = A_arbace_go_generic_A_const_pool.A[176] }

func A_arbace_go_generic_A_clinit_p7() { A_arbace_go_generic_A_const_90 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[177]); A_arbace_go_generic_A_const_91 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[178]); A_arbace_go_generic_A_const_92 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[179]); A_arbace_go_generic_A_const_93 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[180]); A_arbace_go_generic_A_const_94 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[181]); A_arbace_go_generic_A_const_95 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[182]); A_arbace_go_generic_A_const_96 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[183]); A_arbace_go_generic_A_const_97 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[184]); A_arbace_go_generic_A_const_98 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[185]); A_arbace_go_generic_A_const_99 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[186]); A_arbace_go_generic_A_const_100 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[187]); A_arbace_go_generic_A_const_101 = A_arbace_go_generic_A_const_pool.A[188] }

func A_arbace_go_generic_A_clinit_p8() { A_arbace_go_generic_A_const_102 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[189]); A_arbace_go_generic_A_const_103 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[190]); A_arbace_go_generic_A_const_104 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[191]); A_arbace_go_generic_A_const_105 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[192]); A_arbace_go_generic_A_const_106 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[193]); A_arbace_go_generic_A_const_107 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[194]); A_arbace_go_generic_A_const_108 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[195]); A_arbace_go_generic_A_const_109 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[196]); A_arbace_go_generic_A_const_110 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[197]); A_arbace_go_generic_A_const_111 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[198]); A_arbace_go_generic_A_const_112 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[199]); A_arbace_go_generic_A_const_113 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[200]) }

func A_arbace_go_generic_A_clinit_p9() { A_arbace_go_generic_A_const_114 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[201]); A_arbace_go_generic_A_const_115 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[202]); A_arbace_go_generic_A_const_116 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[203]); A_arbace_go_generic_A_const_117 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[204]); A_arbace_go_generic_A_const_118 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[205]); A_arbace_go_generic_A_const_119 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[206]); A_arbace_go_generic_A_const_120 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[207]); A_arbace_go_generic_A_const_121 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[208]); A_arbace_go_generic_A_const_122 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[209]); A_arbace_go_generic_A_const_123 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[210]); A_arbace_go_generic_A_const_124 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[211]); A_arbace_go_generic_A_const_125 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[212]) }

func A_arbace_go_generic_A_clinit_p10() { A_arbace_go_generic_A_const_126 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[213]); A_arbace_go_generic_A_const_127 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[214]); A_arbace_go_generic_A_const_128 = A_arbace_go_generic_A_const_pool.A[215]; A_arbace_go_generic_A_const_129 = A_arbace_go_generic_A_const_pool.A[216]; A_arbace_go_generic_A_const_130 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[217]); A_arbace_go_generic_A_const_131 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[218]); A_arbace_go_generic_A_const_132 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[219]); A_arbace_go_generic_A_const_133 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[220]); A_arbace_go_generic_A_const_134 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[221]); A_arbace_go_generic_A_const_135 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[222]); A_arbace_go_generic_A_const_136 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[223]); A_arbace_go_generic_A_const_137 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[224]) }

func A_arbace_go_generic_A_clinit_p11() { A_arbace_go_generic_A_const_138 = A_arbace_go_generic_A_const_pool.A[225]; A_arbace_go_generic_A_const_139 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[226]); A_arbace_go_generic_A_const_140 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[227]); A_arbace_go_generic_A_const_141 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[228]); A_arbace_go_generic_A_const_142 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[229]); A_arbace_go_generic_A_const_143 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[230]); A_arbace_go_generic_A_const_144 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[231]); A_arbace_go_generic_A_const_145 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[232]); A_arbace_go_generic_A_const_146 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[233]); A_arbace_go_generic_A_const_147 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[234]); A_arbace_go_generic_A_const_148 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[235]); A_arbace_go_generic_A_const_149 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[236]) }

func A_arbace_go_generic_A_clinit_p12() { A_arbace_go_generic_A_const_150 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[237]); A_arbace_go_generic_A_const_151 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[238]); A_arbace_go_generic_A_const_152 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[239]); A_arbace_go_generic_A_const_153 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[240]); A_arbace_go_generic_A_const_154 = A_arbace_go_generic_A_const_pool.A[241]; A_arbace_go_generic_A_const_155 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[242]); A_arbace_go_generic_A_const_156 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[243]); A_arbace_go_generic_A_const_157 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[244]); A_arbace_go_generic_A_const_158 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[245]); A_arbace_go_generic_A_const_159 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[246]); A_arbace_go_generic_A_const_160 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[247]); A_arbace_go_generic_A_const_161 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[248]) }

func A_arbace_go_generic_A_clinit_p13() { A_arbace_go_generic_A_const_162 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[249]); A_arbace_go_generic_A_const_163 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[250]); A_arbace_go_generic_A_const_164 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[251]); A_arbace_go_generic_A_const_165 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[252]); A_arbace_go_generic_A_const_166 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[253]); A_arbace_go_generic_A_const_167 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[254]); A_arbace_go_generic_A_const_168 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[255]); A_arbace_go_generic_A_const_169 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[256]); A_arbace_go_generic_A_const_170 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[257]); A_arbace_go_generic_A_const_171 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[258]); A_arbace_go_generic_A_const_172 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[259]); A_arbace_go_generic_A_const_173 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[260]) }

func A_arbace_go_generic_A_clinit_p14() { A_arbace_go_generic_A_const_174 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[261]); A_arbace_go_generic_A_const_175 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[262]); A_arbace_go_generic_A_const_176 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[263]); A_arbace_go_generic_A_const_177 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[264]); A_arbace_go_generic_A_const_178 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[265]); A_arbace_go_generic_A_const_179 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[266]); A_arbace_go_generic_A_const_180 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[267]); A_arbace_go_generic_A_const_181 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[268]); A_arbace_go_generic_A_const_182 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[269]); A_arbace_go_generic_A_const_183 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[270]); A_arbace_go_generic_A_const_184 = lang.Var_Cast(A_arbace_go_generic_A_const_pool.A[271]); A_arbace_go_generic_A_const_185 = lang.Keyword_Cast(A_arbace_go_generic_A_const_pool.A[272]) }

func A_arbace_go_generic_A_New() *A_arbace_go_generic_A { A_arbace_go_generic_A_Init(); t := &A_arbace_go_generic_A{}; t.Ctor(); return t }

func (t *A_arbace_go_generic_A) Ctor() {}

func (t *A_arbace_go_generic_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_generic_A) GetClass__Class() *jrt.Class { return A_arbace_go_generic_A_class }

func (t *A_arbace_go_generic_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_generic_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_generic_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_generic_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_generic_A); return ok }

func A_arbace_go_generic_A_Cast(x any) *A_arbace_go_generic_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_generic_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_generic_A_class)) }; return v }



type A_arbace_go_generic_arg_form_A struct{ j2g_header uint64 }

var A_arbace_go_generic_arg_form_A_fn_class *jrt.Class



type A_arbace_go_generic_callee_name_A struct{ j2g_header uint64 }

var A_arbace_go_generic_callee_name_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_generic_check_errors_BANG__A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A struct{ j2g_header uint64 }

var A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A struct{ j2g_header uint64; F_iter__278000018, F_s__278000019 any }

var A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A struct{ j2g_header uint64; F_b__278000021 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_generic_check_errors_BANG__iter__278000018__278000022_fn__278000023_fn__278000024_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A struct{ j2g_header uint64 }

var A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A struct{ j2g_header uint64; F_iter__278000028, F_s__278000029 any }

var A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_A_fn_class *jrt.Class



type A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A struct{ j2g_header uint64; F_b__278000031 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_generic_check_errors_BANG__iter__278000028__278000032_fn__278000033_fn__278000034_A_fn_class *jrt.Class



type A_arbace_go_generic_desc__GT_type_A struct{ j2g_header uint64 }

var A_arbace_go_generic_desc__GT_type_A_fn_class *jrt.Class



type A_arbace_go_generic_desc__GT_type_fn__278000058_A struct{ j2g_header uint64; F_sub any }

var A_arbace_go_generic_desc__GT_type_fn__278000058_A_fn_class *jrt.Class



type A_arbace_go_generic_desc__GT_type_sub__278000052_A struct{ j2g_header uint64; F_env any }

var A_arbace_go_generic_desc__GT_type_sub__278000052_A_fn_class *jrt.Class



type A_arbace_go_generic_desc__GT_type_unknown__278000054_A struct{ j2g_header uint64; F_d any }

var A_arbace_go_generic_desc__GT_type_unknown__278000054_A_fn_class *jrt.Class



type A_arbace_go_generic_error_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_generic_error_BANG__A_fn_class *jrt.Class



type A_arbace_go_generic_eval278000004_A struct{ jrt.Object }

func A_arbace_go_generic_eval278000004_A_New() *A_arbace_go_generic_eval278000004_A { t := &A_arbace_go_generic_eval278000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_generic_eval278000004_A) Ctor() {}

func (t *A_arbace_go_generic_eval278000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_generic_eval278000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_generic_eval278000004_A_class }

func (t *A_arbace_go_generic_eval278000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_generic_eval278000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_generic_eval278000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_generic_eval278000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_generic_eval278000004_A); return ok }

func A_arbace_go_generic_eval278000004_A_Cast(x any) *A_arbace_go_generic_eval278000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_generic_eval278000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_generic_eval278000004_A_class)) }; return v }



type A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A struct{ j2g_header uint64 }

var A_arbace_go_generic_eval278000004_loading__1927001464__auto____278000005_A_fn_class *jrt.Class



type A_arbace_go_generic_eval278000008_A struct{ jrt.Object }

func A_arbace_go_generic_eval278000008_A_New() *A_arbace_go_generic_eval278000008_A { t := &A_arbace_go_generic_eval278000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_generic_eval278000008_A) Ctor() {}

func (t *A_arbace_go_generic_eval278000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_generic_eval278000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_generic_eval278000008_A_class }

func (t *A_arbace_go_generic_eval278000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_generic_eval278000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_generic_eval278000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_generic_eval278000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_generic_eval278000008_A); return ok }

func A_arbace_go_generic_eval278000008_A_Cast(x any) *A_arbace_go_generic_eval278000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_generic_eval278000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_generic_eval278000008_A_class)) }; return v }



type A_arbace_go_generic_eval278000008_fn__278000009_A struct{ j2g_header uint64 }

var A_arbace_go_generic_eval278000008_fn__278000009_A_fn_class *jrt.Class



type A_arbace_go_generic_generic_fn_A struct{ j2g_header uint64 }

var A_arbace_go_generic_generic_fn_A_fn_class *jrt.Class



type A_arbace_go_generic_infer_targs_A struct{ j2g_header uint64 }

var A_arbace_go_generic_infer_targs_A_fn_class *jrt.Class



type A_arbace_go_generic_infer_targs_fn__278000082_A struct{ j2g_header uint64; F_cname any }

var A_arbace_go_generic_infer_targs_fn__278000082_A_fn_class *jrt.Class



type A_arbace_go_generic_instance_fn_A struct{ j2g_header uint64 }

var A_arbace_go_generic_instance_fn_A_fn_class *jrt.Class



type A_arbace_go_generic_instantiate_A struct{ j2g_header uint64 }

var A_arbace_go_generic_instantiate_A_fn_class *jrt.Class



type A_arbace_go_generic_instantiate_fn__278000104_A struct{ j2g_header uint64 }

var A_arbace_go_generic_instantiate_fn__278000104_A_fn_class *jrt.Class



type A_arbace_go_generic_instantiate_fn__278000106_A struct{ j2g_header uint64; F_env any }

var A_arbace_go_generic_instantiate_fn__278000106_A_fn_class *jrt.Class



type A_arbace_go_generic_operand_A struct{ j2g_header uint64 }

var A_arbace_go_generic_operand_A_fn_class *jrt.Class



type A_arbace_go_generic_params_for_A struct{ j2g_header uint64 }

var A_arbace_go_generic_params_for_A_fn_class *jrt.Class



type A_arbace_go_generic_params_for_fn__278000074_A struct{ j2g_header uint64 }

var A_arbace_go_generic_params_for_fn__278000074_A_fn_class *jrt.Class



type A_arbace_go_generic_params_for_fn__278000076_A struct{ j2g_header uint64; F_variadic any; F_np int32 }

var A_arbace_go_generic_params_for_fn__278000076_A_fn_class *jrt.Class



type A_arbace_go_generic_receiver_targs_A struct{ j2g_header uint64 }

var A_arbace_go_generic_receiver_targs_A_fn_class *jrt.Class



type A_arbace_go_generic_rehome_A struct{ j2g_header uint64 }

var A_arbace_go_generic_rehome_A_fn_class *jrt.Class



type A_arbace_go_generic_rehome_fn__278000045_A struct{ j2g_header uint64; F_r any }

var A_arbace_go_generic_rehome_fn__278000045_A_fn_class *jrt.Class



type A_arbace_go_generic_rehome_r__278000042_A struct{ j2g_header uint64; F_env any }

var A_arbace_go_generic_rehome_r__278000042_A_fn_class *jrt.Class



type A_arbace_go_generic_resolve_instance_A struct{ j2g_header uint64 }

var A_arbace_go_generic_resolve_instance_A_fn_class *jrt.Class



type A_arbace_go_generic_resolve_instance_fn__278000095_A struct{ j2g_header uint64 }

var A_arbace_go_generic_resolve_instance_fn__278000095_A_fn_class *jrt.Class



type A_arbace_go_generic_resolve_instance_fn__278000097_A struct{ j2g_header uint64; F_env, F_k any }

var A_arbace_go_generic_resolve_instance_fn__278000097_A_fn_class *jrt.Class



type A_arbace_go_generic_tparams_of_A struct{ j2g_header uint64 }

var A_arbace_go_generic_tparams_of_A_fn_class *jrt.Class



type A_arbace_go_generic_type_instance_A struct{ j2g_header uint64 }

var A_arbace_go_generic_type_instance_A_fn_class *jrt.Class



type A_arbace_go_generic_type_instance_fn__278000110_A struct{ j2g_header uint64 }

var A_arbace_go_generic_type_instance_fn__278000110_A_fn_class *jrt.Class



type A_arbace_go_generic_type_instance_fn__278000112_A struct{ j2g_header uint64; F_env any }

var A_arbace_go_generic_type_instance_fn__278000112_A_fn_class *jrt.Class



type A_arbace_go_generic_type_summary_A struct{ j2g_header uint64 }

var A_arbace_go_generic_type_summary_A_fn_class *jrt.Class



type A_arbace_go_generic_with_checker_A struct{ j2g_header uint64 }

var A_arbace_go_generic_with_checker_A_fn_class *jrt.Class
