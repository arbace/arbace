//line j2g_classes.ae:1
package aot_arbace_c_cinterp

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A_class, Name: "arbace.c.cinterp$eval1029000004$loading__1927001464__auto____1029000005", Modifiers: 25, Simple: "loading__1927001464__auto____1029000005", Go: "arbace/aot_arbace_c_cinterp.A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A", Source: "cinterp.ae", Declaring: &A_arbace_c_cinterp_eval1029000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_cinterp_eval1029000008_fn__1029000009_A_class, Name: "arbace.c.cinterp$eval1029000008$fn__1029000009", Modifiers: 25, Simple: "fn__1029000009", Go: "arbace/aot_arbace_c_cinterp.A_arbace_c_cinterp_eval1029000008_fn__1029000009_A", Source: "cinterp.ae", Declaring: &A_arbace_c_cinterp_eval1029000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_cinterp_run_nodes_A_class, Name: "arbace.c.cinterp$run_nodes", Modifiers: 25, Simple: "run_nodes", Go: "arbace/aot_arbace_c_cinterp.A_arbace_c_cinterp_run_nodes_A", Source: "cinterp.ae", Declaring: &A_arbace_c_cinterp_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_c_cinterp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_cinterp_A_New()}; return nil }

var A_arbace_c_cinterp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_cinterp_A_new}

var A_arbace_c_cinterp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.cinterp", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_cinterp.A_arbace_c_cinterp_A"})

func init() { i := A_arbace_c_cinterp_A_class.Info(); i.IsInstance = A_arbace_c_cinterp_A_InstanceOf; i.Init = A_arbace_c_cinterp_A_Init; i.Table = A_arbace_c_cinterp_A_members }

func A_arbace_c_cinterp_eval1029000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_cinterp_eval1029000004_A_New()}; return nil }

var A_arbace_c_cinterp_eval1029000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_cinterp_eval1029000004_A_new}

var A_arbace_c_cinterp_eval1029000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.cinterp$eval1029000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_cinterp_A_class, Simple: "eval1029000004", Go: "arbace/aot_arbace_c_cinterp.A_arbace_c_cinterp_eval1029000004_A"})

func init() { i := A_arbace_c_cinterp_eval1029000004_A_class.Info(); i.IsInstance = A_arbace_c_cinterp_eval1029000004_A_InstanceOf; i.Table = A_arbace_c_cinterp_eval1029000004_A_members }

var A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A_class *jrt.Class

func A_arbace_c_cinterp_eval1029000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_cinterp_eval1029000008_A_New()}; return nil }

var A_arbace_c_cinterp_eval1029000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_cinterp_eval1029000008_A_new}

var A_arbace_c_cinterp_eval1029000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.cinterp$eval1029000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_cinterp_A_class, Simple: "eval1029000008", Go: "arbace/aot_arbace_c_cinterp.A_arbace_c_cinterp_eval1029000008_A"})

func init() { i := A_arbace_c_cinterp_eval1029000008_A_class.Info(); i.IsInstance = A_arbace_c_cinterp_eval1029000008_A_InstanceOf; i.Table = A_arbace_c_cinterp_eval1029000008_A_members }

var A_arbace_c_cinterp_eval1029000008_fn__1029000009_A_class *jrt.Class

var A_arbace_c_cinterp_run_nodes_A_class *jrt.Class

func A_arbace_c_cinterp__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c_cinterp__init_A_Load__O()}; return nil }

func A_arbace_c_cinterp__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_cinterp__init_A_New()}; return nil }

var A_arbace_c_cinterp__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c_cinterp__init_A_invoke, New: A_arbace_c_cinterp__init_A_new}

var A_arbace_c_cinterp__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.cinterp__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_cinterp.A_arbace_c_cinterp__init_A", Source: "cinterp.ae"})

func init() { i := A_arbace_c_cinterp__init_A_class.Info(); i.IsInstance = A_arbace_c_cinterp__init_A_InstanceOf; i.Init = A_arbace_c_cinterp__init_A_Init; i.Table = A_arbace_c_cinterp__init_A_members }
