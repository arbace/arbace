//line j2g_strings.ae:1
package aot_arbace_c_cinterp

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,docv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.c.cinterpm2,R1,s504,ci's in-process back end (doc/C23-SURVEY.md, CS103 (c), \"As built: C9 (preparation)\"): the node program's text run by\n  arbace.lang.CInterp, whose Go side is go/arbace/cinterp over ci and crt, in the executable's own process. The namespace needs\n  the class, which only an executable built with ci has: on stage 0 (and on any executable of the runtime before C9) loading\n  it fails, and arbace.c.repl keeps the light path's back end, tools/cirun as a process. arbace.c.repl requires it at load, in a try.v11,arbace.core10,into-arrayC16,java.lang.Stringv11,arbace.core3,mapv11,arbace.core3,str")

var Lit_1 *jrt.String = jrt.Intern("arbace.lang.CInterp")

var Lit_2 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn6,Stringyn4,argvkn4,linekn6,columnkn4,filev11,arbace.core5,in-nsMyn16,arbace.c.cinterpm2,R0,s504,ci's in-process back end (doc/C23-SURVEY.md, CS103 (c), \"As built: C9 (preparation)\"): the node program's text run by\n  arbace.lang.CInterp, whose Go side is go/arbace/cinterp over ci and crt, in the executable's own process. The namespace needs\n  the class, which only an executable built with ci has: on stage 0 (and on any executable of the runtime before C9) loading\n  it fails, and arbace.c.repl keeps the light path's back end, tools/cirun as a process. arbace.c.repl requires it at load, in a try.m2,R0,s504,ci's in-process back end (doc/C23-SURVEY.md, CS103 (c), \"As built: C9 (preparation)\"): the node program's text run by\n  arbace.lang.CInterp, whose Go side is go/arbace/cinterp over ci and crt, in the executable's own process. The namespace needs\n  the class, which only an executable built with ci has: on stage 0 (and on any executable of the runtime before C9) loading\n  it fails, and arbace.c.repl keeps the light path's back end, tools/cirun as a process. arbace.c.repl requires it at load, in a try.R1,v11,arbace.core20,*warn-on-reflection*v16,arbace.c.cinterp9,run-nodesm10,R2,L1,V2,Myn4,textm2,R3,R4,R5,R0,s236,The node program `text` run with `argv` (argv[0] the program's name) on the process's standard streams: its status\n  (128 + a signal's number); a fault is reported on the standard error as \"cirun: fault: ...\", as tools/cirun reports it.R6,i10,R7,i1,R8,s19,arbace/c/cinterp.ae")

var Lit_3 *jrt.String = jrt.Intern("arbace.c.cinterp$eval1029000004$loading__1927001464__auto____1029000005")

var Lit_4 *jrt.String = jrt.Intern("arbace.c.cinterp$eval1029000008$fn__1029000009")

var Lit_5 *jrt.String = jrt.Intern("arbace.c.cinterp$run_nodes")
