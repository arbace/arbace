//line aot_arbace_c_cinterp.ae:1
package aot_arbace_c_cinterp

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A_New() *A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A { A_arbace_c_cinterp_A_Init(); t := &A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_cinterp_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_cinterp_A_const_1); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c_cinterp_eval1029000008_fn__1029000009_A_New() *A_arbace_c_cinterp_eval1029000008_fn__1029000009_A { A_arbace_c_cinterp_A_Init(); t := &A_arbace_c_cinterp_eval1029000008_fn__1029000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_cinterp_eval1029000008_fn__1029000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_cinterp_eval1029000008_fn__1029000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_cinterp_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_c_cinterp_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_c_cinterp_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_cinterp_A_const_5.GetRawRoot__O(), A_arbace_c_cinterp_A_const_6) }








func A_arbace_c_cinterp_run_nodes_A_New() *A_arbace_c_cinterp_run_nodes_A { A_arbace_c_cinterp_A_Init(); t := &A_arbace_c_cinterp_run_nodes_A{}; t.Ctor(); return t }
//line :10:1
func (t *A_arbace_c_cinterp_run_nodes_A) Ctor() {}
//line :10:1
func (t *A_arbace_c_cinterp_run_nodes_A) Invoke_O_O_O__O(self, text__0, argv__1 any) any {



	var tmp1 *jrt.String = jrt.String_Cast(text__0); var tmp2 any; var root_15 any = A_arbace_c_cinterp_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_c_cinterp_A_const_8; var arg_19 any; var root_20 any = A_arbace_c_cinterp_A_const_9.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_c_cinterp_A_const_10.GetRawRoot__O(); var arg_24 any = argv__1; if linked_21 == nil { arg_19 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { arg_19 = linked_21.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; if linked_16 == nil { tmp2 = ifn_17.Invoke_O_O__O(arg_18, arg_19) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_15, arg_18, arg_19) }; return jrt.Integer_ValueOf_I__Integer_NoInit(lang.CInterp_RunNodes_String_String1__I(tmp1, jrt.RefArray_Cast(tmp2, jrt.String_class))).Ref()
}










type A_arbace_c_cinterp_A struct{ jrt.Object }

var A_arbace_c_cinterp_A_const_pool *jrt.RefArray

var A_arbace_c_cinterp_A_const_0 *lang.Var

var A_arbace_c_cinterp_A_const_1 any

var A_arbace_c_cinterp_A_const_2 *lang.Var

var A_arbace_c_cinterp_A_const_3 *lang.Var

var A_arbace_c_cinterp_A_const_4 *lang.Var

var A_arbace_c_cinterp_A_const_5 *lang.Var

var A_arbace_c_cinterp_A_const_6 any

var A_arbace_c_cinterp_A_const_7 *lang.Var

var A_arbace_c_cinterp_A_const_8 *jrt.Class

var A_arbace_c_cinterp_A_const_9 *lang.Var

var A_arbace_c_cinterp_A_const_10 *lang.Var

var A_arbace_c_cinterp_A_init jrt.ClassInit

func A_arbace_c_cinterp_A_Init() { if !A_arbace_c_cinterp_A_init.Done() { A_arbace_c_cinterp_A_init.Run(A_arbace_c_cinterp_A_clinit) } }

func A_arbace_c_cinterp_A_clinit() { jrt.StartCheck(); A_arbace_c_cinterp_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 13); A_arbace_c_cinterp_A_const_0 = lang.Var_Cast(A_arbace_c_cinterp_A_const_pool.A[2]); A_arbace_c_cinterp_A_const_1 = A_arbace_c_cinterp_A_const_pool.A[3]; A_arbace_c_cinterp_A_const_2 = lang.Var_Cast(A_arbace_c_cinterp_A_const_pool.A[4]); A_arbace_c_cinterp_A_const_3 = lang.Var_Cast(A_arbace_c_cinterp_A_const_pool.A[5]); A_arbace_c_cinterp_A_const_4 = lang.Var_Cast(A_arbace_c_cinterp_A_const_pool.A[6]); A_arbace_c_cinterp_A_const_5 = lang.Var_Cast(A_arbace_c_cinterp_A_const_pool.A[7]); A_arbace_c_cinterp_A_const_6 = A_arbace_c_cinterp_A_const_pool.A[8]; A_arbace_c_cinterp_A_const_7 = lang.Var_Cast(A_arbace_c_cinterp_A_const_pool.A[9]); A_arbace_c_cinterp_A_const_8 = jrt.Class_Cast(A_arbace_c_cinterp_A_const_pool.A[10]); A_arbace_c_cinterp_A_const_9 = lang.Var_Cast(A_arbace_c_cinterp_A_const_pool.A[11]); A_arbace_c_cinterp_A_const_10 = lang.Var_Cast(A_arbace_c_cinterp_A_const_pool.A[12]) }

func A_arbace_c_cinterp_A_New() *A_arbace_c_cinterp_A { A_arbace_c_cinterp_A_Init(); t := &A_arbace_c_cinterp_A{}; t.Ctor(); return t }

func (t *A_arbace_c_cinterp_A) Ctor() {}

func (t *A_arbace_c_cinterp_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_cinterp_A) GetClass__Class() *jrt.Class { return A_arbace_c_cinterp_A_class }

func (t *A_arbace_c_cinterp_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_cinterp_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_cinterp_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_cinterp_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_cinterp_A); return ok }

func A_arbace_c_cinterp_A_Cast(x any) *A_arbace_c_cinterp_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_cinterp_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_cinterp_A_class)) }; return v }



type A_arbace_c_cinterp_eval1029000004_A struct{ jrt.Object }

func A_arbace_c_cinterp_eval1029000004_A_New() *A_arbace_c_cinterp_eval1029000004_A { t := &A_arbace_c_cinterp_eval1029000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c_cinterp_eval1029000004_A) Ctor() {}

func (t *A_arbace_c_cinterp_eval1029000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_cinterp_eval1029000004_A) GetClass__Class() *jrt.Class { return A_arbace_c_cinterp_eval1029000004_A_class }

func (t *A_arbace_c_cinterp_eval1029000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_cinterp_eval1029000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_cinterp_eval1029000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_cinterp_eval1029000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_cinterp_eval1029000004_A); return ok }

func A_arbace_c_cinterp_eval1029000004_A_Cast(x any) *A_arbace_c_cinterp_eval1029000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_cinterp_eval1029000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_cinterp_eval1029000004_A_class)) }; return v }



type A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A struct{ j2g_header uint64 }

var A_arbace_c_cinterp_eval1029000004_loading__1927001464__auto____1029000005_A_fn_class *jrt.Class



type A_arbace_c_cinterp_eval1029000008_A struct{ jrt.Object }

func A_arbace_c_cinterp_eval1029000008_A_New() *A_arbace_c_cinterp_eval1029000008_A { t := &A_arbace_c_cinterp_eval1029000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c_cinterp_eval1029000008_A) Ctor() {}

func (t *A_arbace_c_cinterp_eval1029000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_cinterp_eval1029000008_A) GetClass__Class() *jrt.Class { return A_arbace_c_cinterp_eval1029000008_A_class }

func (t *A_arbace_c_cinterp_eval1029000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_cinterp_eval1029000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_cinterp_eval1029000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_cinterp_eval1029000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_cinterp_eval1029000008_A); return ok }

func A_arbace_c_cinterp_eval1029000008_A_Cast(x any) *A_arbace_c_cinterp_eval1029000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_cinterp_eval1029000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_cinterp_eval1029000008_A_class)) }; return v }



type A_arbace_c_cinterp_eval1029000008_fn__1029000009_A struct{ j2g_header uint64 }

var A_arbace_c_cinterp_eval1029000008_fn__1029000009_A_fn_class *jrt.Class



type A_arbace_c_cinterp_run_nodes_A struct{ j2g_header uint64 }

var A_arbace_c_cinterp_run_nodes_A_fn_class *jrt.Class
