//line a2g_strings.ae:1
package aot_arbace_a2g_names

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("a2g's names (doc/go/A2G-SPEC.md §4.2, §4.4): Go packages of Java classes, Go identifiers of\n  classes, members and locals, the descriptor codes of mangled method names, and the Go type of\n  a Java type (§5.1) given the class facts of the closed world.")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("subs")

var Lit_16 *jrt.String = jrt.Intern("starts-with?")

var Lit_17 *jrt.String = jrt.Intern("jrt")

var Lit_18 *jrt.String = jrt.Intern("else")

var Lit_19 *jrt.String = jrt.Intern("top-of")

var Lit_20 *jrt.String = jrt.Intern("keyword")

var Lit_21 *jrt.String = jrt.Intern("lang")

var Lit_22 *jrt.String = jrt.Intern("compiled-packages")

var Lit_23 *jrt.String = jrt.Intern("not")

var Lit_24 *jrt.String = jrt.Intern("name")

var Lit_25 *jrt.String = jrt.Intern("replace")

var Lit_26 *jrt.String = jrt.Intern("apply")

var Lit_27 *jrt.String = jrt.Intern("munge")

var Lit_28 *jrt.String = jrt.Intern("map")

var Lit_29 *jrt.String = jrt.Intern("munge-name")

var Lit_30 *jrt.String = jrt.Intern("blank?")

var Lit_31 *jrt.String = jrt.Intern("go-keywords")

var Lit_32 *jrt.String = jrt.Intern("go-predeclared")

var Lit_33 *jrt.String = jrt.Intern("reserved-locals")

var Lit_34 *jrt.String = jrt.Intern("re-matches")

var Lit_35 *jrt.String = jrt.Intern("tmp\\d+.*")

var Lit_36 *jrt.String = jrt.Intern("[lL]\\d+")

var Lit_37 *jrt.String = jrt.Intern("renames")

var Lit_38 *jrt.String = jrt.Intern("compiled-class?")

var Lit_39 *jrt.String = jrt.Intern("seq")

var Lit_40 *jrt.String = jrt.Intern("empty?")

var Lit_41 *jrt.String = jrt.Intern("array?")

var Lit_42 *jrt.String = jrt.Intern("array-dims")

var Lit_43 *jrt.String = jrt.Intern("desc-code")

var Lit_44 *jrt.String = jrt.Intern("class-desc?")

var Lit_45 *jrt.String = jrt.Intern("go-class-name")

var Lit_46 *jrt.String = jrt.Intern("desc->internal")

var Lit_47 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_48 *jrt.String = jrt.Intern("capitalize")

var Lit_49 *jrt.String = jrt.Intern("method-base")

var Lit_50 *jrt.String = jrt.Intern("arbace.a2g.names$capitalize")

var Lit_51 *jrt.String = jrt.Intern("arbace.a2g.names$compiled_class_QMARK_")

var Lit_52 *jrt.String = jrt.Intern("arbace/")

var Lit_53 *jrt.String = jrt.Intern("arbace/lang/")

var Lit_54 *jrt.String = jrt.Intern("arbace/java/api/")

var Lit_55 *jrt.String = jrt.Intern("arbace.a2g.names$compiled_pkg_QMARK_")

var Lit_56 *jrt.String = jrt.Intern("arbace.a2g.names$ctor_base")

var Lit_57 *jrt.String = jrt.Intern("Ctor")

var Lit_58 *jrt.String = jrt.Intern("arbace.a2g.names$ctor_base$fn__593000037")

var Lit_59 *jrt.String = jrt.Intern("_")

var Lit_60 *jrt.String = jrt.Intern("arbace.a2g.names$desc_code")

var Lit_61 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_62 *jrt.String = jrt.Intern("O")

var Lit_63 *jrt.String = jrt.Intern("arbace.a2g.names$eval593000004$loading__1927001464__auto____593000005")

var Lit_64 *jrt.String = jrt.Intern("arbace.a2g.names$eval593000008$fn__593000009")

var Lit_65 *jrt.String = jrt.Intern("arbace.a2g.names$field_name")

var Lit_66 *jrt.String = jrt.Intern("F_")

var Lit_67 *jrt.String = jrt.Intern("arbace.a2g.names$go_class_name")

var Lit_68 *jrt.String = jrt.Intern("A_")

var Lit_69 *jrt.String = jrt.Intern("_A")

var Lit_70 *jrt.String = jrt.Intern("/")

var Lit_71 *jrt.String = jrt.Intern("X")

var Lit_72 *jrt.String = jrt.Intern("arbace.a2g.names$impl_name")

var Lit_73 *jrt.String = jrt.Intern("Impl_")

var Lit_74 *jrt.String = jrt.Intern("arbace.a2g.names$local_name")

var Lit_75 *jrt.String = jrt.Intern("x")

var Lit_76 *jrt.String = jrt.Intern("a2g_")

var Lit_77 *jrt.String = jrt.Intern("arbace.a2g.names$method_base")

var Lit_78 *jrt.String = jrt.Intern("__")

var Lit_79 *jrt.String = jrt.Intern("arbace.a2g.names$method_base$fn__593000030")

var Lit_80 *jrt.String = jrt.Intern("arbace.a2g.names$munge_name")

var Lit_81 *jrt.String = jrt.Intern("$")

var Lit_82 *jrt.String = jrt.Intern("arbace.a2g.names$munge_name$fn__593000018")

var Lit_83 *jrt.String = jrt.Intern("arbace.a2g.names$new_name")

var Lit_84 *jrt.String = jrt.Intern("_New")

var Lit_85 *jrt.String = jrt.Intern("arbace.a2g.names$new_name$fn__593000044")

var Lit_86 *jrt.String = jrt.Intern("arbace.a2g.names$pkg_name")

var Lit_87 *jrt.String = jrt.Intern("arbace.a2g.names$pkg_ns")

var Lit_88 *jrt.String = jrt.Intern("go.arbace.")

var Lit_89 *jrt.String = jrt.Intern("arbace.a2g.names$pkg_of")

var Lit_90 *jrt.String = jrt.Intern("java/")

var Lit_91 *jrt.String = jrt.Intern("jdk/")

var Lit_92 *jrt.String = jrt.Intern("sun/")

var Lit_93 *jrt.String = jrt.Intern("javax/")

var Lit_94 *jrt.String = jrt.Intern("com/sun/")

var Lit_95 *jrt.String = jrt.Intern("arbace.a2g.names$pkg_path")

var Lit_96 *jrt.String = jrt.Intern("arbace.a2g.names$static_field_name")

var Lit_97 *jrt.String = jrt.Intern("arbace.a2g.names$static_method_name")

var Lit_98 *jrt.String = jrt.Intern("arbace.a2g.names$top_of")

var Lit_99 *jrt.String = jrt.Intern("in-ns")

var Lit_100 *jrt.String = jrt.Intern("atom")

var Lit_101 *jrt.String = jrt.Intern("line")

var Lit_102 *jrt.String = jrt.Intern("column")

var Lit_103 *jrt.String = jrt.Intern("file")

var Lit_104 *jrt.String = jrt.Intern("arbace/a2g/names.ae")

var Lit_105 *jrt.String = jrt.Intern("The Go packages of compiled namespaces' classes (standalone S6, SA142): top-level class\n  (internal name) → package name, from the packages.edn of the inputs (arbace.aot's tree);\n  set once by a2g's run, before any translation.")

var Lit_106 *jrt.String = jrt.Intern("private")

var Lit_107 *jrt.String = jrt.Intern("arglists")

var Lit_108 *jrt.String = jrt.Intern("n")

var Lit_109 *jrt.String = jrt.Intern("tag")

var Lit_110 *jrt.String = jrt.Intern("String")

var Lit_111 *jrt.String = jrt.Intern("pkg-of")

var Lit_112 *jrt.String = jrt.Intern("internal")

var Lit_113 *jrt.String = jrt.Intern("The Go package of a class (internal name): :jrt for the JDK's packages (java, javax, jdk,\n  sun, and com.sun since the SunJCE provider: amendment SC3), a compiled namespace's own\n  (compiled-packages: a keyword of its package name), else :lang for Arbace's.")

var Lit_114 *jrt.String = jrt.Intern("compiled-pkg?")

var Lit_115 *jrt.String = jrt.Intern("pkg")

var Lit_116 *jrt.String = jrt.Intern("pkg-name")

var Lit_117 *jrt.String = jrt.Intern("pkg-path")

var Lit_118 *jrt.String = jrt.Intern("pkg-ns")

var Lit_119 *jrt.String = jrt.Intern("Names a2g's generated code uses for itself (receivers, imports, temporaries).")

var Lit_120 *jrt.String = jrt.Intern("s")

var Lit_121 *jrt.String = jrt.Intern("A Java or Clojure name as a Go identifier fragment: Clojure's munge, $ as _.")

var Lit_122 *jrt.String = jrt.Intern("local-name")

var Lit_123 *jrt.String = jrt.Intern("sym")

var Lit_124 *jrt.String = jrt.Intern("The Go name of a Java local or parameter (§4.4): munged, with _ appended when it would be a\n  Go keyword, a predeclared or reserved name, or would start with an upper-case letter (which\n  could shadow a type of the package).")

var Lit_125 *jrt.String = jrt.Intern("The rename table (§4.4, Collisions): classes whose Go name would collide with another of the\n  closed world's or with jrt's own names.")

var Lit_126 *jrt.String = jrt.Intern("Is class `internal` one of a namespace compiled to class forms (standalone S6, arbace.aot):\n  Arbace's but not the runtime's (arbace/lang, the Java API)?")

var Lit_127 *jrt.String = jrt.Intern("The Go type name of a class: its binary name after the package, $ as _; X prepended when it\n  does not start with an upper-case letter. A compiled namespace's class (S6), in package lang\n  with the runtime's, is named by its whole binary name between A_ and _A (arbace.core.Vec is\n  A_arbace_core_Vec_A, the fn arbace.walk$walk A_arbace_walk_walk_A).")

var Lit_128 *jrt.String = jrt.Intern("d")

var Lit_129 *jrt.String = jrt.Intern("The code of a parameter or return descriptor in a mangled name.")

var Lit_130 *jrt.String = jrt.Intern("desc")

var Lit_131 *jrt.String = jrt.Intern("The mangled method name without a class prefix: M_P1_..._Pn__R.")

var Lit_132 *jrt.String = jrt.Intern("ctor-base")

var Lit_133 *jrt.String = jrt.Intern("Ctor_P1_..._Pn, or Ctor; desc is the constructor's full descriptor (implicit parameters\n  included).")

var Lit_134 *jrt.String = jrt.Intern("new-name")

var Lit_135 *jrt.String = jrt.Intern("cls-go")

var Lit_136 *jrt.String = jrt.Intern("C_New_P1_..._Pn, or C_New.")

var Lit_137 *jrt.String = jrt.Intern("field-name")

var Lit_138 *jrt.String = jrt.Intern("fname")

var Lit_139 *jrt.String = jrt.Intern("static-field-name")

var Lit_140 *jrt.String = jrt.Intern("static-method-name")

var Lit_141 *jrt.String = jrt.Intern("impl-name")

var Lit_142 *jrt.String = jrt.Intern("mbase")
