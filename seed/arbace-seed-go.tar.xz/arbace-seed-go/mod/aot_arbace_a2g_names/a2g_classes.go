//line a2g_classes.ae:1
package aot_arbace_a2g_names

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_names_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_A_New()}; return nil }

var A_arbace_a2g_names_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_names_A_new}

var A_arbace_a2g_names_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_A"})

func init() { i := A_arbace_a2g_names_A_class.Info(); i.IsInstance = A_arbace_a2g_names_A_InstanceOf; i.Init = A_arbace_a2g_names_A_Init; i.Table = A_arbace_a2g_names_A_members; jrt.RegisterGoType(A_arbace_a2g_names_A_class, reflect.TypeFor[A_arbace_a2g_names_A]()) }

func A_arbace_a2g_names_capitalize_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_capitalize_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_capitalize_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_capitalize_A_New()}; return nil }

func A_arbace_a2g_names_capitalize_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_capitalize_A_fn_class)}; return nil }

var A_arbace_a2g_names_capitalize_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_capitalize_A_invoke, New: A_arbace_a2g_names_capitalize_A_new, Get: A_arbace_a2g_names_capitalize_A_get}

var A_arbace_a2g_names_capitalize_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$capitalize", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "capitalize", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_capitalize_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_capitalize_A_class.Info(); i.IsInstance = A_arbace_a2g_names_capitalize_A_InstanceOf; i.Init = A_arbace_a2g_names_capitalize_A_Init; i.Table = A_arbace_a2g_names_capitalize_A_members; jrt.RegisterGoType(A_arbace_a2g_names_capitalize_A_class, reflect.TypeFor[A_arbace_a2g_names_capitalize_A]()) }

func A_arbace_a2g_names_compiled_class_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_compiled_class_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_compiled_class_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_compiled_class_QMARK__A_New()}; return nil }

func A_arbace_a2g_names_compiled_class_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_compiled_class_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_names_compiled_class_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_compiled_class_QMARK__A_invoke, New: A_arbace_a2g_names_compiled_class_QMARK__A_new, Get: A_arbace_a2g_names_compiled_class_QMARK__A_get}

var A_arbace_a2g_names_compiled_class_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$compiled_class_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "compiled_class_QMARK_", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_compiled_class_QMARK__A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_compiled_class_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_names_compiled_class_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_names_compiled_class_QMARK__A_Init; i.Table = A_arbace_a2g_names_compiled_class_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_names_compiled_class_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_names_compiled_class_QMARK__A]()) }

func A_arbace_a2g_names_compiled_pkg_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_compiled_pkg_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_compiled_pkg_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_compiled_pkg_QMARK__A_New()}; return nil }

func A_arbace_a2g_names_compiled_pkg_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_compiled_pkg_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_names_compiled_pkg_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_compiled_pkg_QMARK__A_invoke, New: A_arbace_a2g_names_compiled_pkg_QMARK__A_new, Get: A_arbace_a2g_names_compiled_pkg_QMARK__A_get}

var A_arbace_a2g_names_compiled_pkg_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$compiled_pkg_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "compiled_pkg_QMARK_", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_compiled_pkg_QMARK__A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_compiled_pkg_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_names_compiled_pkg_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_names_compiled_pkg_QMARK__A_Init; i.Table = A_arbace_a2g_names_compiled_pkg_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_names_compiled_pkg_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_names_compiled_pkg_QMARK__A]()) }

func A_arbace_a2g_names_ctor_base_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_ctor_base_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_ctor_base_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_ctor_base_A_New()}; return nil }

func A_arbace_a2g_names_ctor_base_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_ctor_base_A_fn_class)}; return nil }

var A_arbace_a2g_names_ctor_base_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_ctor_base_A_invoke, New: A_arbace_a2g_names_ctor_base_A_new, Get: A_arbace_a2g_names_ctor_base_A_get}

var A_arbace_a2g_names_ctor_base_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$ctor_base", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "ctor_base", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_ctor_base_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_ctor_base_A_class.Info(); i.IsInstance = A_arbace_a2g_names_ctor_base_A_InstanceOf; i.Init = A_arbace_a2g_names_ctor_base_A_Init; i.Table = A_arbace_a2g_names_ctor_base_A_members; jrt.RegisterGoType(A_arbace_a2g_names_ctor_base_A_class, reflect.TypeFor[A_arbace_a2g_names_ctor_base_A]()) }

func A_arbace_a2g_names_ctor_base_fn__593000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_ctor_base_fn__593000037_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_ctor_base_fn__593000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_ctor_base_fn__593000037_A_New()}; return nil }

func A_arbace_a2g_names_ctor_base_fn__593000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_ctor_base_fn__593000037_A_fn_class)}; return nil }

var A_arbace_a2g_names_ctor_base_fn__593000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_ctor_base_fn__593000037_A_invoke, New: A_arbace_a2g_names_ctor_base_fn__593000037_A_new, Get: A_arbace_a2g_names_ctor_base_fn__593000037_A_get}

var A_arbace_a2g_names_ctor_base_fn__593000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$ctor_base$fn__593000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_ctor_base_A_class, Simple: "fn__593000037", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_ctor_base_fn__593000037_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_ctor_base_fn__593000037_A_class.Info(); i.IsInstance = A_arbace_a2g_names_ctor_base_fn__593000037_A_InstanceOf; i.Init = A_arbace_a2g_names_ctor_base_fn__593000037_A_Init; i.Table = A_arbace_a2g_names_ctor_base_fn__593000037_A_members; jrt.RegisterGoType(A_arbace_a2g_names_ctor_base_fn__593000037_A_class, reflect.TypeFor[A_arbace_a2g_names_ctor_base_fn__593000037_A]()) }

func A_arbace_a2g_names_desc_code_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_desc_code_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_desc_code_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_desc_code_A_New()}; return nil }

func A_arbace_a2g_names_desc_code_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_desc_code_A_fn_class)}; return nil }

var A_arbace_a2g_names_desc_code_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_desc_code_A_invoke, New: A_arbace_a2g_names_desc_code_A_new, Get: A_arbace_a2g_names_desc_code_A_get}

var A_arbace_a2g_names_desc_code_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$desc_code", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "desc_code", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_desc_code_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_desc_code_A_class.Info(); i.IsInstance = A_arbace_a2g_names_desc_code_A_InstanceOf; i.Init = A_arbace_a2g_names_desc_code_A_Init; i.Table = A_arbace_a2g_names_desc_code_A_members; jrt.RegisterGoType(A_arbace_a2g_names_desc_code_A_class, reflect.TypeFor[A_arbace_a2g_names_desc_code_A]()) }

func A_arbace_a2g_names_eval593000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_eval593000004_A_New()}; return nil }

var A_arbace_a2g_names_eval593000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_names_eval593000004_A_new}

var A_arbace_a2g_names_eval593000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$eval593000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_names_A_class, Simple: "eval593000004", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_eval593000004_A"})

func init() { i := A_arbace_a2g_names_eval593000004_A_class.Info(); i.IsInstance = A_arbace_a2g_names_eval593000004_A_InstanceOf; i.Table = A_arbace_a2g_names_eval593000004_A_members; jrt.RegisterGoType(A_arbace_a2g_names_eval593000004_A_class, reflect.TypeFor[A_arbace_a2g_names_eval593000004_A]()) }

func A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_New()}; return nil }

func A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_fn_class)}; return nil }

var A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_invoke, New: A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_new, Get: A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_get}

var A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$eval593000004$loading__1927001464__auto____593000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_names_eval593000004_A_class, Simple: "loading__1927001464__auto____593000005", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_class.Info(); i.IsInstance = A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_InstanceOf; i.Init = A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_Init; i.Table = A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_members; jrt.RegisterGoType(A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_class, reflect.TypeFor[A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A]()) }

func A_arbace_a2g_names_eval593000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_eval593000008_A_New()}; return nil }

var A_arbace_a2g_names_eval593000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_names_eval593000008_A_new}

var A_arbace_a2g_names_eval593000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$eval593000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_names_A_class, Simple: "eval593000008", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_eval593000008_A"})

func init() { i := A_arbace_a2g_names_eval593000008_A_class.Info(); i.IsInstance = A_arbace_a2g_names_eval593000008_A_InstanceOf; i.Table = A_arbace_a2g_names_eval593000008_A_members; jrt.RegisterGoType(A_arbace_a2g_names_eval593000008_A_class, reflect.TypeFor[A_arbace_a2g_names_eval593000008_A]()) }

func A_arbace_a2g_names_eval593000008_fn__593000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_eval593000008_fn__593000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_names_eval593000008_fn__593000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_eval593000008_fn__593000009_A_New()}; return nil }

func A_arbace_a2g_names_eval593000008_fn__593000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_eval593000008_fn__593000009_A_fn_class)}; return nil }

var A_arbace_a2g_names_eval593000008_fn__593000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_eval593000008_fn__593000009_A_invoke, New: A_arbace_a2g_names_eval593000008_fn__593000009_A_new, Get: A_arbace_a2g_names_eval593000008_fn__593000009_A_get}

var A_arbace_a2g_names_eval593000008_fn__593000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$eval593000008$fn__593000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_names_eval593000008_A_class, Simple: "fn__593000009", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_eval593000008_fn__593000009_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_eval593000008_fn__593000009_A_class.Info(); i.IsInstance = A_arbace_a2g_names_eval593000008_fn__593000009_A_InstanceOf; i.Init = A_arbace_a2g_names_eval593000008_fn__593000009_A_Init; i.Table = A_arbace_a2g_names_eval593000008_fn__593000009_A_members; jrt.RegisterGoType(A_arbace_a2g_names_eval593000008_fn__593000009_A_class, reflect.TypeFor[A_arbace_a2g_names_eval593000008_fn__593000009_A]()) }

func A_arbace_a2g_names_field_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_field_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_field_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_field_name_A_New()}; return nil }

func A_arbace_a2g_names_field_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_field_name_A_fn_class)}; return nil }

var A_arbace_a2g_names_field_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_field_name_A_invoke, New: A_arbace_a2g_names_field_name_A_new, Get: A_arbace_a2g_names_field_name_A_get}

var A_arbace_a2g_names_field_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$field_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "field_name", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_field_name_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_field_name_A_class.Info(); i.IsInstance = A_arbace_a2g_names_field_name_A_InstanceOf; i.Init = A_arbace_a2g_names_field_name_A_Init; i.Table = A_arbace_a2g_names_field_name_A_members; jrt.RegisterGoType(A_arbace_a2g_names_field_name_A_class, reflect.TypeFor[A_arbace_a2g_names_field_name_A]()) }

func A_arbace_a2g_names_go_class_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_go_class_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_go_class_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_go_class_name_A_New()}; return nil }

func A_arbace_a2g_names_go_class_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_go_class_name_A_fn_class)}; return nil }

var A_arbace_a2g_names_go_class_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_go_class_name_A_invoke, New: A_arbace_a2g_names_go_class_name_A_new, Get: A_arbace_a2g_names_go_class_name_A_get}

var A_arbace_a2g_names_go_class_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$go_class_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "go_class_name", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_go_class_name_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_go_class_name_A_class.Info(); i.IsInstance = A_arbace_a2g_names_go_class_name_A_InstanceOf; i.Init = A_arbace_a2g_names_go_class_name_A_Init; i.Table = A_arbace_a2g_names_go_class_name_A_members; jrt.RegisterGoType(A_arbace_a2g_names_go_class_name_A_class, reflect.TypeFor[A_arbace_a2g_names_go_class_name_A]()) }

func A_arbace_a2g_names_impl_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_impl_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_impl_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_impl_name_A_New()}; return nil }

func A_arbace_a2g_names_impl_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_impl_name_A_fn_class)}; return nil }

var A_arbace_a2g_names_impl_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_impl_name_A_invoke, New: A_arbace_a2g_names_impl_name_A_new, Get: A_arbace_a2g_names_impl_name_A_get}

var A_arbace_a2g_names_impl_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$impl_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "impl_name", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_impl_name_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_impl_name_A_class.Info(); i.IsInstance = A_arbace_a2g_names_impl_name_A_InstanceOf; i.Init = A_arbace_a2g_names_impl_name_A_Init; i.Table = A_arbace_a2g_names_impl_name_A_members; jrt.RegisterGoType(A_arbace_a2g_names_impl_name_A_class, reflect.TypeFor[A_arbace_a2g_names_impl_name_A]()) }

func A_arbace_a2g_names_local_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_local_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_local_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_local_name_A_New()}; return nil }

func A_arbace_a2g_names_local_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_local_name_A_fn_class)}; return nil }

var A_arbace_a2g_names_local_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_local_name_A_invoke, New: A_arbace_a2g_names_local_name_A_new, Get: A_arbace_a2g_names_local_name_A_get}

var A_arbace_a2g_names_local_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$local_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "local_name", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_local_name_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_local_name_A_class.Info(); i.IsInstance = A_arbace_a2g_names_local_name_A_InstanceOf; i.Init = A_arbace_a2g_names_local_name_A_Init; i.Table = A_arbace_a2g_names_local_name_A_members; jrt.RegisterGoType(A_arbace_a2g_names_local_name_A_class, reflect.TypeFor[A_arbace_a2g_names_local_name_A]()) }

func A_arbace_a2g_names_method_base_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_method_base_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_names_method_base_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_method_base_A_New()}; return nil }

func A_arbace_a2g_names_method_base_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_method_base_A_fn_class)}; return nil }

var A_arbace_a2g_names_method_base_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_method_base_A_invoke, New: A_arbace_a2g_names_method_base_A_new, Get: A_arbace_a2g_names_method_base_A_get}

var A_arbace_a2g_names_method_base_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$method_base", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "method_base", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_method_base_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_method_base_A_class.Info(); i.IsInstance = A_arbace_a2g_names_method_base_A_InstanceOf; i.Init = A_arbace_a2g_names_method_base_A_Init; i.Table = A_arbace_a2g_names_method_base_A_members; jrt.RegisterGoType(A_arbace_a2g_names_method_base_A_class, reflect.TypeFor[A_arbace_a2g_names_method_base_A]()) }

func A_arbace_a2g_names_method_base_fn__593000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_method_base_fn__593000030_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_method_base_fn__593000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_method_base_fn__593000030_A_New()}; return nil }

func A_arbace_a2g_names_method_base_fn__593000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_method_base_fn__593000030_A_fn_class)}; return nil }

var A_arbace_a2g_names_method_base_fn__593000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_method_base_fn__593000030_A_invoke, New: A_arbace_a2g_names_method_base_fn__593000030_A_new, Get: A_arbace_a2g_names_method_base_fn__593000030_A_get}

var A_arbace_a2g_names_method_base_fn__593000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$method_base$fn__593000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_method_base_A_class, Simple: "fn__593000030", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_method_base_fn__593000030_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_method_base_fn__593000030_A_class.Info(); i.IsInstance = A_arbace_a2g_names_method_base_fn__593000030_A_InstanceOf; i.Init = A_arbace_a2g_names_method_base_fn__593000030_A_Init; i.Table = A_arbace_a2g_names_method_base_fn__593000030_A_members; jrt.RegisterGoType(A_arbace_a2g_names_method_base_fn__593000030_A_class, reflect.TypeFor[A_arbace_a2g_names_method_base_fn__593000030_A]()) }

func A_arbace_a2g_names_munge_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_munge_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_munge_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_munge_name_A_New()}; return nil }

func A_arbace_a2g_names_munge_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_munge_name_A_fn_class)}; return nil }

var A_arbace_a2g_names_munge_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_munge_name_A_invoke, New: A_arbace_a2g_names_munge_name_A_new, Get: A_arbace_a2g_names_munge_name_A_get}

var A_arbace_a2g_names_munge_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$munge_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "munge_name", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_munge_name_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_munge_name_A_class.Info(); i.IsInstance = A_arbace_a2g_names_munge_name_A_InstanceOf; i.Init = A_arbace_a2g_names_munge_name_A_Init; i.Table = A_arbace_a2g_names_munge_name_A_members; jrt.RegisterGoType(A_arbace_a2g_names_munge_name_A_class, reflect.TypeFor[A_arbace_a2g_names_munge_name_A]()) }

func A_arbace_a2g_names_munge_name_fn__593000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_munge_name_fn__593000018_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_munge_name_fn__593000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_munge_name_fn__593000018_A_New()}; return nil }

func A_arbace_a2g_names_munge_name_fn__593000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_munge_name_fn__593000018_A_fn_class)}; return nil }

var A_arbace_a2g_names_munge_name_fn__593000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_munge_name_fn__593000018_A_invoke, New: A_arbace_a2g_names_munge_name_fn__593000018_A_new, Get: A_arbace_a2g_names_munge_name_fn__593000018_A_get}

var A_arbace_a2g_names_munge_name_fn__593000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$munge_name$fn__593000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_munge_name_A_class, Simple: "fn__593000018", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_munge_name_fn__593000018_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_munge_name_fn__593000018_A_class.Info(); i.IsInstance = A_arbace_a2g_names_munge_name_fn__593000018_A_InstanceOf; i.Init = A_arbace_a2g_names_munge_name_fn__593000018_A_Init; i.Table = A_arbace_a2g_names_munge_name_fn__593000018_A_members; jrt.RegisterGoType(A_arbace_a2g_names_munge_name_fn__593000018_A_class, reflect.TypeFor[A_arbace_a2g_names_munge_name_fn__593000018_A]()) }

func A_arbace_a2g_names_new_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_new_name_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_names_new_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_new_name_A_New()}; return nil }

func A_arbace_a2g_names_new_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_new_name_A_fn_class)}; return nil }

var A_arbace_a2g_names_new_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_new_name_A_invoke, New: A_arbace_a2g_names_new_name_A_new, Get: A_arbace_a2g_names_new_name_A_get}

var A_arbace_a2g_names_new_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$new_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "new_name", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_new_name_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_new_name_A_class.Info(); i.IsInstance = A_arbace_a2g_names_new_name_A_InstanceOf; i.Init = A_arbace_a2g_names_new_name_A_Init; i.Table = A_arbace_a2g_names_new_name_A_members; jrt.RegisterGoType(A_arbace_a2g_names_new_name_A_class, reflect.TypeFor[A_arbace_a2g_names_new_name_A]()) }

func A_arbace_a2g_names_new_name_fn__593000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_new_name_fn__593000044_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_new_name_fn__593000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_new_name_fn__593000044_A_New()}; return nil }

func A_arbace_a2g_names_new_name_fn__593000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_new_name_fn__593000044_A_fn_class)}; return nil }

var A_arbace_a2g_names_new_name_fn__593000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_new_name_fn__593000044_A_invoke, New: A_arbace_a2g_names_new_name_fn__593000044_A_new, Get: A_arbace_a2g_names_new_name_fn__593000044_A_get}

var A_arbace_a2g_names_new_name_fn__593000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$new_name$fn__593000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_new_name_A_class, Simple: "fn__593000044", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_new_name_fn__593000044_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_new_name_fn__593000044_A_class.Info(); i.IsInstance = A_arbace_a2g_names_new_name_fn__593000044_A_InstanceOf; i.Init = A_arbace_a2g_names_new_name_fn__593000044_A_Init; i.Table = A_arbace_a2g_names_new_name_fn__593000044_A_members; jrt.RegisterGoType(A_arbace_a2g_names_new_name_fn__593000044_A_class, reflect.TypeFor[A_arbace_a2g_names_new_name_fn__593000044_A]()) }

func A_arbace_a2g_names_pkg_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_pkg_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_pkg_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_pkg_name_A_New()}; return nil }

func A_arbace_a2g_names_pkg_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_pkg_name_A_fn_class)}; return nil }

var A_arbace_a2g_names_pkg_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_pkg_name_A_invoke, New: A_arbace_a2g_names_pkg_name_A_new, Get: A_arbace_a2g_names_pkg_name_A_get}

var A_arbace_a2g_names_pkg_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$pkg_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "pkg_name", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_pkg_name_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_pkg_name_A_class.Info(); i.IsInstance = A_arbace_a2g_names_pkg_name_A_InstanceOf; i.Init = A_arbace_a2g_names_pkg_name_A_Init; i.Table = A_arbace_a2g_names_pkg_name_A_members; jrt.RegisterGoType(A_arbace_a2g_names_pkg_name_A_class, reflect.TypeFor[A_arbace_a2g_names_pkg_name_A]()) }

func A_arbace_a2g_names_pkg_ns_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_pkg_ns_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_pkg_ns_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_pkg_ns_A_New()}; return nil }

func A_arbace_a2g_names_pkg_ns_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_pkg_ns_A_fn_class)}; return nil }

var A_arbace_a2g_names_pkg_ns_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_pkg_ns_A_invoke, New: A_arbace_a2g_names_pkg_ns_A_new, Get: A_arbace_a2g_names_pkg_ns_A_get}

var A_arbace_a2g_names_pkg_ns_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$pkg_ns", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "pkg_ns", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_pkg_ns_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_pkg_ns_A_class.Info(); i.IsInstance = A_arbace_a2g_names_pkg_ns_A_InstanceOf; i.Init = A_arbace_a2g_names_pkg_ns_A_Init; i.Table = A_arbace_a2g_names_pkg_ns_A_members; jrt.RegisterGoType(A_arbace_a2g_names_pkg_ns_A_class, reflect.TypeFor[A_arbace_a2g_names_pkg_ns_A]()) }

func A_arbace_a2g_names_pkg_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_pkg_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_pkg_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_pkg_of_A_New()}; return nil }

func A_arbace_a2g_names_pkg_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_pkg_of_A_fn_class)}; return nil }

var A_arbace_a2g_names_pkg_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_pkg_of_A_invoke, New: A_arbace_a2g_names_pkg_of_A_new, Get: A_arbace_a2g_names_pkg_of_A_get}

var A_arbace_a2g_names_pkg_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$pkg_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "pkg_of", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_pkg_of_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_pkg_of_A_class.Info(); i.IsInstance = A_arbace_a2g_names_pkg_of_A_InstanceOf; i.Init = A_arbace_a2g_names_pkg_of_A_Init; i.Table = A_arbace_a2g_names_pkg_of_A_members; jrt.RegisterGoType(A_arbace_a2g_names_pkg_of_A_class, reflect.TypeFor[A_arbace_a2g_names_pkg_of_A]()) }

func A_arbace_a2g_names_pkg_path_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_pkg_path_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_pkg_path_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_pkg_path_A_New()}; return nil }

func A_arbace_a2g_names_pkg_path_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_pkg_path_A_fn_class)}; return nil }

var A_arbace_a2g_names_pkg_path_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_pkg_path_A_invoke, New: A_arbace_a2g_names_pkg_path_A_new, Get: A_arbace_a2g_names_pkg_path_A_get}

var A_arbace_a2g_names_pkg_path_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$pkg_path", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "pkg_path", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_pkg_path_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_pkg_path_A_class.Info(); i.IsInstance = A_arbace_a2g_names_pkg_path_A_InstanceOf; i.Init = A_arbace_a2g_names_pkg_path_A_Init; i.Table = A_arbace_a2g_names_pkg_path_A_members; jrt.RegisterGoType(A_arbace_a2g_names_pkg_path_A_class, reflect.TypeFor[A_arbace_a2g_names_pkg_path_A]()) }

func A_arbace_a2g_names_static_field_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_static_field_name_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_names_static_field_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_static_field_name_A_New()}; return nil }

func A_arbace_a2g_names_static_field_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_static_field_name_A_fn_class)}; return nil }

var A_arbace_a2g_names_static_field_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_static_field_name_A_invoke, New: A_arbace_a2g_names_static_field_name_A_new, Get: A_arbace_a2g_names_static_field_name_A_get}

var A_arbace_a2g_names_static_field_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$static_field_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "static_field_name", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_static_field_name_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_static_field_name_A_class.Info(); i.IsInstance = A_arbace_a2g_names_static_field_name_A_InstanceOf; i.Init = A_arbace_a2g_names_static_field_name_A_Init; i.Table = A_arbace_a2g_names_static_field_name_A_members; jrt.RegisterGoType(A_arbace_a2g_names_static_field_name_A_class, reflect.TypeFor[A_arbace_a2g_names_static_field_name_A]()) }

func A_arbace_a2g_names_static_method_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_static_method_name_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_names_static_method_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_static_method_name_A_New()}; return nil }

func A_arbace_a2g_names_static_method_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_static_method_name_A_fn_class)}; return nil }

var A_arbace_a2g_names_static_method_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_static_method_name_A_invoke, New: A_arbace_a2g_names_static_method_name_A_new, Get: A_arbace_a2g_names_static_method_name_A_get}

var A_arbace_a2g_names_static_method_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$static_method_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "static_method_name", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_static_method_name_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_static_method_name_A_class.Info(); i.IsInstance = A_arbace_a2g_names_static_method_name_A_InstanceOf; i.Init = A_arbace_a2g_names_static_method_name_A_Init; i.Table = A_arbace_a2g_names_static_method_name_A_members; jrt.RegisterGoType(A_arbace_a2g_names_static_method_name_A_class, reflect.TypeFor[A_arbace_a2g_names_static_method_name_A]()) }

func A_arbace_a2g_names_top_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_names_top_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_names_top_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names_top_of_A_New()}; return nil }

func A_arbace_a2g_names_top_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_names_top_of_A_fn_class)}; return nil }

var A_arbace_a2g_names_top_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_names_top_of_A_invoke, New: A_arbace_a2g_names_top_of_A_new, Get: A_arbace_a2g_names_top_of_A_get}

var A_arbace_a2g_names_top_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names$top_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_names_A_class, Simple: "top_of", Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names_top_of_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names_top_of_A_class.Info(); i.IsInstance = A_arbace_a2g_names_top_of_A_InstanceOf; i.Init = A_arbace_a2g_names_top_of_A_Init; i.Table = A_arbace_a2g_names_top_of_A_members; jrt.RegisterGoType(A_arbace_a2g_names_top_of_A_class, reflect.TypeFor[A_arbace_a2g_names_top_of_A]()) }

func A_arbace_a2g_names__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_names__init_A_Load__O(); case 1: return A_arbace_a2g_names__init_A_Unit0__O(); case 2: return A_arbace_a2g_names__init_A_Unit1__O(); case 3: return A_arbace_a2g_names__init_A_Unit10__O(); case 4: return A_arbace_a2g_names__init_A_Unit11__O(); case 5: return A_arbace_a2g_names__init_A_Unit12__O(); case 6: return A_arbace_a2g_names__init_A_Unit13__O(); case 7: return A_arbace_a2g_names__init_A_Unit14__O(); case 8: return A_arbace_a2g_names__init_A_Unit15__O(); case 9: return A_arbace_a2g_names__init_A_Unit16__O(); case 10: return A_arbace_a2g_names__init_A_Unit17__O(); case 11: return A_arbace_a2g_names__init_A_Unit18__O(); case 12: return A_arbace_a2g_names__init_A_Unit19__O(); case 13: return A_arbace_a2g_names__init_A_Unit2__O(); case 14: return A_arbace_a2g_names__init_A_Unit20__O(); case 15: return A_arbace_a2g_names__init_A_Unit21__O(); case 16: return A_arbace_a2g_names__init_A_Unit22__O(); case 17: return A_arbace_a2g_names__init_A_Unit23__O(); case 18: return A_arbace_a2g_names__init_A_Unit24__O(); case 19: return A_arbace_a2g_names__init_A_Unit25__O(); case 20: return A_arbace_a2g_names__init_A_Unit26__O(); case 21: return A_arbace_a2g_names__init_A_Unit27__O(); case 22: return A_arbace_a2g_names__init_A_Unit3__O(); case 23: return A_arbace_a2g_names__init_A_Unit4__O(); case 24: return A_arbace_a2g_names__init_A_Unit5__O(); case 25: return A_arbace_a2g_names__init_A_Unit6__O(); case 26: return A_arbace_a2g_names__init_A_Unit7__O(); case 27: return A_arbace_a2g_names__init_A_Unit8__O(); case 28: return A_arbace_a2g_names__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_names__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_names__init_A_New()}; return nil }

var A_arbace_a2g_names__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_names__init_A_invoke, New: A_arbace_a2g_names__init_A_new}

var A_arbace_a2g_names__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.names__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_names.A_arbace_a2g_names__init_A", Source: "names.ae"})

func init() { i := A_arbace_a2g_names__init_A_class.Info(); i.IsInstance = A_arbace_a2g_names__init_A_InstanceOf; i.Init = A_arbace_a2g_names__init_A_Init; i.Table = A_arbace_a2g_names__init_A_members; jrt.RegisterGoType(A_arbace_a2g_names__init_A_class, reflect.TypeFor[A_arbace_a2g_names__init_A]()) }
