//line aot_arbace_a2g_names.ae:1
package aot_arbace_a2g_names

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_New() *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A { A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_Init(); t := &A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_names_A_Init(); tmp4 = A_arbace_a2g_names_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_names_A_Init(); tmp6 = A_arbace_a2g_names_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_names_A_Init(); tmp9 = A_arbace_a2g_names_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_names_A_Init(); tmp11 = A_arbace_a2g_names_A_const_4; tmp3 = tmp8.Invoke_O_O__O(tmp10, tmp11) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp12 != nil { panic(tmp12) }; return tmp3 }
//line :1:1
func A_arbace_a2g_names_eval593000008_fn__593000009_A_New() *A_arbace_a2g_names_eval593000008_fn__593000009_A { A_arbace_a2g_names_eval593000008_fn__593000009_A_Init(); t := &A_arbace_a2g_names_eval593000008_fn__593000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_5; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_names_A_Init(); tmp3 = A_arbace_a2g_names_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_names_A_Init(); tmp5 = A_arbace_a2g_names_A_const_9; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_7; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_names_A_Init(); tmp9 = A_arbace_a2g_names_A_const_8; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }















func A_arbace_a2g_names_top_of_A_New() *A_arbace_a2g_names_top_of_A { A_arbace_a2g_names_top_of_A_Init(); t := &A_arbace_a2g_names_top_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_a2g_names_top_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_a2g_names_top_of_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_81); if lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__0 } else { var tmp1 *lang.Var; A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_a2g_names_A_Init(); tmp3 = A_arbace_a2g_names_A_const_11; var tmp4 any = tmp3; return tmp2.Invoke_O_O_O__O(n__0, tmp4, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }

func A_arbace_a2g_names_pkg_of_A_New() *A_arbace_a2g_names_pkg_of_A { A_arbace_a2g_names_pkg_of_A_Init(); t := &A_arbace_a2g_names_pkg_of_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_a2g_names_pkg_of_A) Ctor() {}
//line :19:1
func (t *A_arbace_a2g_names_pkg_of_A) Invoke_O_O__O(self, internal__0 any) any {




	var tmp1 any; var or__1927000174__auto____2 any; var tmp2 *lang.Var
	A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_12; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_90); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp3 *lang.Var; A_arbace_a2g_names_A_Init(); tmp3 = A_arbace_a2g_names_A_const_12; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_91); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any; var tmp4 *lang.Var
		A_arbace_a2g_names_A_Init(); tmp4 = A_arbace_a2g_names_A_const_12; or__1927000174__auto____4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_92)
//line :25:1
		if jrt.A2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var tmp5 *lang.Var
			A_arbace_a2g_names_A_Init(); tmp5 = A_arbace_a2g_names_A_const_12; or__1927000174__auto____5 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_93)
//line :25:1
			if jrt.A2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else {

				var tmp6 *lang.Var; A_arbace_a2g_names_A_Init(); tmp6 = A_arbace_a2g_names_A_const_12; tmp1 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_94) } } } }
//line :24:1
	if jrt.A2g_Truth(tmp1) { A_arbace_a2g_names_A_Init(); return A_arbace_a2g_names_A_const_13.Ref() } else { var tmp7 *lang.Keyword; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_14; if tmp7 != nil { var temp__1927000408__auto____2 any; var tmp8 *lang.Var



		A_arbace_a2g_names_A_Init(); tmp8 = A_arbace_a2g_names_A_const_6; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_names_A_Init(); tmp10 = A_arbace_a2g_names_A_const_18; var tmp11 any = tmp9.Invoke_O__O(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_a2g_names_A_Init(); tmp12 = A_arbace_a2g_names_A_const_15; temp__1927000408__auto____2 = lang.RT_Get_O_O__O(tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(internal__0)); if jrt.A2g_Truth(temp__1927000408__auto____2) { var p__3 any = temp__1927000408__auto____2; var tmp13 *lang.Var; A_arbace_a2g_names_A_Init(); tmp13 = A_arbace_a2g_names_A_const_16; return lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(p__3) } else { A_arbace_a2g_names_A_Init(); return A_arbace_a2g_names_A_const_17.Ref() } } else {
//line :24:1
			return nil
		}
	}
}


func A_arbace_a2g_names_compiled_pkg_QMARK__A_New() *A_arbace_a2g_names_compiled_pkg_QMARK__A { A_arbace_a2g_names_compiled_pkg_QMARK__A_Init(); t := &A_arbace_a2g_names_compiled_pkg_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_a2g_names_A_Init(); tmp3 = A_arbace_a2g_names_A_const_20; return tmp2.Invoke_O__O(lang.IFn_Cast(tmp3).Invoke_O__O(pkg__0)) }

func A_arbace_a2g_names_pkg_name_A_New() *A_arbace_a2g_names_pkg_name_A { A_arbace_a2g_names_pkg_name_A_Init(); t := &A_arbace_a2g_names_pkg_name_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_a2g_names_pkg_name_A) Ctor() {}
//line :32:1
func (t *A_arbace_a2g_names_pkg_name_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_21; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(pkg__0) }
func A_arbace_a2g_names_pkg_path_A_New() *A_arbace_a2g_names_pkg_path_A { A_arbace_a2g_names_pkg_path_A_Init(); t := &A_arbace_a2g_names_pkg_path_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_a2g_names_pkg_path_A) Ctor() {}
//line :33:1
func (t *A_arbace_a2g_names_pkg_path_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_52, nil); var tmp2 *lang.Var; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_21; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(pkg__0))).Ref() }
func A_arbace_a2g_names_pkg_ns_A_New() *A_arbace_a2g_names_pkg_ns_A { A_arbace_a2g_names_pkg_ns_A_Init(); t := &A_arbace_a2g_names_pkg_ns_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_a2g_names_pkg_ns_A) Ctor() {}
//line :34:1
func (t *A_arbace_a2g_names_pkg_ns_A) Invoke_O_O__O(self, pkg__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_88, nil); var tmp2 *lang.Var; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_21; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(pkg__0))).Ref() }



















func A_arbace_a2g_names_munge_name_A_New() *A_arbace_a2g_names_munge_name_A { A_arbace_a2g_names_munge_name_A_Init(); t := &A_arbace_a2g_names_munge_name_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_names_munge_name_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_names_munge_name_A) Invoke_O_O__O(self, s__0 any) any { var m__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_names_A_Init(); tmp3 = A_arbace_a2g_names_A_const_24; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_names_A_Init(); tmp5 = A_arbace_a2g_names_A_const_25; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_24; m__2 = tmp2.Invoke_O_O_O__O(tmp4.Invoke_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(s__0))), Lit_81, Lit_59); var tmp8 /*line :60:1*/*lang.Var; A_arbace_a2g_names_A_Init(); tmp8 = A_arbace_a2g_names_A_const_23; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_a2g_names_A_Init(); tmp10 = A_arbace_a2g_names_A_const_24; var tmp11 any = jrt.NN(tmp10).GetRawRoot__O(); var tmp12 *lang.Var; A_arbace_a2g_names_A_Init(); tmp12 = A_arbace_a2g_names_A_const_26; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = A_arbace_a2g_names_munge_name_fn__593000018_A_New(); var tmp15 *jrt.Class; A_arbace_a2g_names_munge_name_fn__593000018_A_Init(); tmp15 = A_arbace_a2g_names_munge_name_fn__593000018_A_fn_class; return tmp9.Invoke_O_O__O(tmp11, tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), m__2)) }
//line :60:1
func A_arbace_a2g_names_munge_name_fn__593000018_A_New() *A_arbace_a2g_names_munge_name_fn__593000018_A { A_arbace_a2g_names_munge_name_fn__593000018_A_Init(); t := &A_arbace_a2g_names_munge_name_fn__593000018_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_a2g_names_munge_name_fn__593000018_A) Ctor() {}
//line :60:1
func (t *A_arbace_a2g_names_munge_name_fn__593000018_A) Invoke_O_O__O(self, c__1 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z(lang.RT_CharCast_O__C(c__1)); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { var tmp2 any; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_27; tmp1 = lang.Util_Equiv_O_O__Z(c__1, tmp2) }; if tmp1 { return c__1 } else { A_arbace_a2g_names_A_Init(); return A_arbace_a2g_names_A_const_27 } }

func A_arbace_a2g_names_local_name_A_New() *A_arbace_a2g_names_local_name_A { A_arbace_a2g_names_local_name_A_Init(); t := &A_arbace_a2g_names_local_name_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_a2g_names_local_name_A) Ctor() {}
//line :62:1
func (t *A_arbace_a2g_names_local_name_A) Invoke_O_O__O(self, sym__0 any) any { var s__2 any; var tmp1 *lang.Var;




	A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_28; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_names_A_Init(); tmp3 = A_arbace_a2g_names_A_const_21; s__2 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(sym__0)); var s__3 any; var tmp4 /*line :62:1*/*lang.Var;





	A_arbace_a2g_names_A_Init(); tmp4 = A_arbace_a2g_names_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(s__2)) { s__3 = Lit_75 } else { s__3 = s__2 }; var tmp5 any; var or__1927000174__auto____4 any; var tmp6 /*line :69:1*/*lang.Var; A_arbace_a2g_names_A_Init(); tmp6 = A_arbace_a2g_names_A_const_30; or__1927000174__auto____4 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(s__3); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any; var tmp7 *lang.Var; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_31; or__1927000174__auto____5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(s__3); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var tmp8 *lang.Var; A_arbace_a2g_names_A_Init(); tmp8 = A_arbace_a2g_names_A_const_32; or__1927000174__auto____6 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(s__3); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp5 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 bool = jrt.Character_IsUpperCase_C__Z(jrt.NN(jrt.String_Cast(s__3)).CharAt_I__C(lang.RT_IntCast_J__I(0))); if or__1927000174__auto____7 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 any; var tmp9 *lang.Var

		A_arbace_a2g_names_A_Init(); tmp9 = A_arbace_a2g_names_A_const_12; or__1927000174__auto____8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O__O(s__3, Lit_76)
//line :69:1
		if jrt.A2g_Truth(or__1927000174__auto____8) { tmp5 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any; var tmp10 *lang.Var

			A_arbace_a2g_names_A_Init(); tmp10 = A_arbace_a2g_names_A_const_33; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_a2g_names_A_Init(); tmp12 = A_arbace_a2g_names_A_const_34; or__1927000174__auto____9 = tmp11.Invoke_O_O__O(tmp12, s__3)
//line :69:1
			if jrt.A2g_Truth(or__1927000174__auto____9) { tmp5 = or__1927000174__auto____9 } else {

				var tmp13 *lang.Var; A_arbace_a2g_names_A_Init(); tmp13 = A_arbace_a2g_names_A_const_33; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; A_arbace_a2g_names_A_Init(); tmp15 = A_arbace_a2g_names_A_const_35; tmp5 = tmp14.Invoke_O_O__O(tmp15, s__3) } } } } } }; if /*line :69:1*/ jrt.A2g_Truth(tmp5) {


					return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, s__3, nil)).Ref() } else {
//line :69:1
						return s__3 } }








































func A_arbace_a2g_names_compiled_class_QMARK__A_New() *A_arbace_a2g_names_compiled_class_QMARK__A { A_arbace_a2g_names_compiled_class_QMARK__A_Init(); t := &A_arbace_a2g_names_compiled_class_QMARK__A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_a2g_names_compiled_class_QMARK__A) Ctor() {}
//line :110:1
func (t *A_arbace_a2g_names_compiled_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;



	A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_12; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_52); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_19; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_names_A_Init(); tmp4 = A_arbace_a2g_names_A_const_12; and__1927000168__auto____3 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_53)); if jrt.A2g_Truth(and__1927000168__auto____3) {
		var tmp5 *lang.Var; A_arbace_a2g_names_A_Init(); tmp5 = A_arbace_a2g_names_A_const_19; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_12; return tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_54)) } else {
//line :114:1
			return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }


func A_arbace_a2g_names_go_class_name_A_New() *A_arbace_a2g_names_go_class_name_A { A_arbace_a2g_names_go_class_name_A_Init(); t := &A_arbace_a2g_names_go_class_name_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_a2g_names_go_class_name_A) Ctor() {}
//line :117:1
func (t *A_arbace_a2g_names_go_class_name_A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Var;





	A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_36; or__1927000174__auto____2 = lang.RT_Get_O_O__O(jrt.NN(tmp1).GetRawRoot__O(), internal__0); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp2 *lang.Var
		A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(internal__0)) {

			var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil, Lit_69); var tmp4 *lang.Var; A_arbace_a2g_names_A_Init(); tmp4 = A_arbace_a2g_names_A_const_28; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_names_A_Init(); tmp6 = A_arbace_a2g_names_A_const_22; or__1927000174__auto____3 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(internal__0, Lit_70, Lit_59)), nil)).Ref() } else {
//line :124:1
				or__1927000174__auto____3 = nil }
//line :123:1
		if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var s__4 any; var tmp7 *lang.Var



			A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_10; s__4 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(internal__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_70)))).Ref())
//line :123:1
			var s__5 any; var tmp8 *lang.Var




			A_arbace_a2g_names_A_Init(); tmp8 = A_arbace_a2g_names_A_const_28; s__5 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(s__4)
			var tmp9 any; var and__1927000168__auto____6 any; var tmp10 *lang.Var; A_arbace_a2g_names_A_Init(); tmp10 = A_arbace_a2g_names_A_const_38; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(s__5); if jrt.A2g_Truth(and__1927000168__auto____6) { tmp9 = jrt.Boolean_ValueOf_Z__Boolean(jrt.Character_IsUpperCase_C__Z(jrt.NN(jrt.String_Cast(s__5)).CharAt_I__C(lang.RT_IntCast_J__I(0)))).Ref() } else { tmp9 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp9) { return s__5 } else {

				return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__5)).Ref() } } } }

func A_arbace_a2g_names_capitalize_A_New() *A_arbace_a2g_names_capitalize_A { A_arbace_a2g_names_capitalize_A_Init(); t := &A_arbace_a2g_names_capitalize_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_a2g_names_capitalize_A) Ctor() {}
//line :133:1
func (t *A_arbace_a2g_names_capitalize_A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_39; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0)) { return s__0 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp3 any = jrt.Character_ValueOf_C__Character(jrt.Character_ToUpperCase_C__C(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(0)))).Ref(); var tmp4 *lang.Var; A_arbace_a2g_names_A_Init(); tmp4 = A_arbace_a2g_names_A_const_10; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_names_A_Init(); tmp6 = A_arbace_a2g_names_A_const_40; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5.Invoke_O_O__O(s__0, tmp6))).Ref()
	}
}


func A_arbace_a2g_names_desc_code_A_New() *A_arbace_a2g_names_desc_code_A { A_arbace_a2g_names_desc_code_A_Init(); t := &A_arbace_a2g_names_desc_code_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_a2g_names_desc_code_A) Ctor() {}
//line :139:1
func (t *A_arbace_a2g_names_desc_code_A) Invoke_O_O__O(self, d__0 any) any {


	var tmp1 *lang.Var; A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_41; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0)) { var n__2 any; var tmp2 *lang.Var
		A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_42; n__2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(d__0)
//line :142:1
		var e__3 any; var tmp3 *lang.Var

		A_arbace_a2g_names_A_Init(); tmp3 = A_arbace_a2g_names_A_const_10; e__3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(d__0, n__2)
		var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp5 *lang.Var; A_arbace_a2g_names_A_Init(); tmp5 = A_arbace_a2g_names_A_const_43; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(e__3), n__2)).Ref() } else {
//line :142:1
			if lang.Util_Equiv_O_O__Z(d__0, Lit_61) { return Lit_62 } else { var tmp6 *lang.Var; A_arbace_a2g_names_A_Init(); tmp6 = A_arbace_a2g_names_A_const_44; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(d__0)) {




				var tmp7 *lang.Var; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_45; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_names_A_Init(); tmp9 = A_arbace_a2g_names_A_const_46; return tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(d__0)) } else {
//line :142:1
					var tmp10 *lang.Keyword; A_arbace_a2g_names_A_Init(); tmp10 = A_arbace_a2g_names_A_const_14; if tmp10 != nil { return d__0 } else { return nil
					}
				}
			}
		}
}


func A_arbace_a2g_names_method_base_A_New() *A_arbace_a2g_names_method_base_A { A_arbace_a2g_names_method_base_A_Init(); t := &A_arbace_a2g_names_method_base_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_a2g_names_method_base_A) Ctor() {}
//line :150:1
func (t *A_arbace_a2g_names_method_base_A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var vec__593000027__3 any; var tmp1 *lang.Var;


	A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_47; vec__593000027__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(desc__1); var ps__4 any = /*line :150:1*/lang.RT_Nth_O_I_O__O(vec__593000027__3, lang.RT_IntCast_J__I(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O(vec__593000027__3, lang.RT_IntCast_J__I(1), nil); var m__6 any; var tmp2 *lang.Var;



	A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_48; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_names_A_Init(); tmp4 = A_arbace_a2g_names_A_const_28; m__6 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(name__0)); var m__7 any; var tmp5 /*line :150:1*/*lang.Var;




	A_arbace_a2g_names_A_Init(); tmp5 = A_arbace_a2g_names_A_const_12; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(m__6, Lit_59)) { m__7 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_71, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__6)).Ref() } else { m__7 = m__6 }; var tmp6 /*line :156:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_78, nil); var tmp7 *lang.Var; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_23; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_names_A_Init(); tmp9 = A_arbace_a2g_names_A_const_24; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Var; A_arbace_a2g_names_A_Init(); tmp11 = A_arbace_a2g_names_A_const_26; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any = A_arbace_a2g_names_method_base_fn__593000030_A_New(); var tmp14 *jrt.Class; A_arbace_a2g_names_method_base_fn__593000030_A_Init(); tmp14 = A_arbace_a2g_names_method_base_fn__593000030_A_fn_class; var tmp15 any = tmp8.Invoke_O_O__O(tmp10, tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), ps__4)); var tmp16 *lang.Var; A_arbace_a2g_names_A_Init(); tmp16 = A_arbace_a2g_names_A_const_43; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, m__7, tmp15, nil, lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(r__5))).Ref() }
//line :156:1
func A_arbace_a2g_names_method_base_fn__593000030_A_New() *A_arbace_a2g_names_method_base_fn__593000030_A { A_arbace_a2g_names_method_base_fn__593000030_A_Init(); t := &A_arbace_a2g_names_method_base_fn__593000030_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_a2g_names_method_base_fn__593000030_A) Ctor() {}
//line :156:1
func (t *A_arbace_a2g_names_method_base_fn__593000030_A) Invoke_O_O__O(self, p1__593000026_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil); var tmp2 *lang.Var; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_43; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(p1__593000026_SHARP___1))).Ref() }

func A_arbace_a2g_names_ctor_base_A_New() *A_arbace_a2g_names_ctor_base_A { A_arbace_a2g_names_ctor_base_A_Init(); t := &A_arbace_a2g_names_ctor_base_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_a2g_names_ctor_base_A) Ctor() {}
//line :158:1
func (t *A_arbace_a2g_names_ctor_base_A) Invoke_O_O__O(self, desc__0 any) any { var vec__593000034__2 any; var tmp1 *lang.Var;



	A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_47; vec__593000034__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(desc__0); var ps__3 any = /*line :158:1*/lang.RT_Nth_O_I_O__O(vec__593000034__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__593000034__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_57, nil); var tmp3 *lang.Var; _ = ___4;




	A_arbace_a2g_names_A_Init(); tmp3 = A_arbace_a2g_names_A_const_23; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_names_A_Init(); tmp5 = A_arbace_a2g_names_A_const_24; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_26; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = A_arbace_a2g_names_ctor_base_fn__593000037_A_New(); var tmp10 *jrt.Class; A_arbace_a2g_names_ctor_base_fn__593000037_A_Init(); tmp10 = A_arbace_a2g_names_ctor_base_fn__593000037_A_fn_class; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O_O__O(tmp6, tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), ps__3)))).Ref() }
//line :163:1
func A_arbace_a2g_names_ctor_base_fn__593000037_A_New() *A_arbace_a2g_names_ctor_base_fn__593000037_A { A_arbace_a2g_names_ctor_base_fn__593000037_A_Init(); t := &A_arbace_a2g_names_ctor_base_fn__593000037_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_a2g_names_ctor_base_fn__593000037_A) Ctor() {}
//line :163:1
func (t *A_arbace_a2g_names_ctor_base_fn__593000037_A) Invoke_O_O__O(self, p1__593000033_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil); var tmp2 *lang.Var; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_43; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(p1__593000033_SHARP___1))).Ref() }

func A_arbace_a2g_names_new_name_A_New() *A_arbace_a2g_names_new_name_A { A_arbace_a2g_names_new_name_A_Init(); t := &A_arbace_a2g_names_new_name_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_a2g_names_new_name_A) Ctor() {}
//line :165:1
func (t *A_arbace_a2g_names_new_name_A) Invoke_O_O_O__O(self, cls_go__0, desc__1 any) any { var vec__593000041__3 any; var tmp1 *lang.Var;


	A_arbace_a2g_names_A_Init(); tmp1 = A_arbace_a2g_names_A_const_47; vec__593000041__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(desc__1); var ps__4 any = /*line :165:1*/lang.RT_Nth_O_I_O__O(vec__593000041__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__593000041__3, lang.RT_IntCast_J__I(1), nil); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_84, nil); var tmp3 *lang.Var; _ = ___5;



	A_arbace_a2g_names_A_Init(); tmp3 = A_arbace_a2g_names_A_const_23; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_names_A_Init(); tmp5 = A_arbace_a2g_names_A_const_24; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_a2g_names_A_Init(); tmp7 = A_arbace_a2g_names_A_const_26; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = A_arbace_a2g_names_new_name_fn__593000044_A_New(); var tmp10 *jrt.Class; A_arbace_a2g_names_new_name_fn__593000044_A_Init(); tmp10 = A_arbace_a2g_names_new_name_fn__593000044_A_fn_class; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp4.Invoke_O_O__O(tmp6, tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), ps__4)))).Ref() }
//line :169:1
func A_arbace_a2g_names_new_name_fn__593000044_A_New() *A_arbace_a2g_names_new_name_fn__593000044_A { A_arbace_a2g_names_new_name_fn__593000044_A_Init(); t := &A_arbace_a2g_names_new_name_fn__593000044_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_a2g_names_new_name_fn__593000044_A) Ctor() {}
//line :169:1
func (t *A_arbace_a2g_names_new_name_fn__593000044_A) Invoke_O_O__O(self, p1__593000040_SHARP___1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_59, nil); var tmp2 *lang.Var; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_43; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(p1__593000040_SHARP___1))).Ref() }

func A_arbace_a2g_names_field_name_A_New() *A_arbace_a2g_names_field_name_A { A_arbace_a2g_names_field_name_A_Init(); t := &A_arbace_a2g_names_field_name_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_a2g_names_field_name_A) Ctor() {}
//line :171:1
func (t *A_arbace_a2g_names_field_name_A) Invoke_O_O__O(self, fname__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_66, nil); var tmp2 *lang.Var; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_28; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(fname__0))).Ref() }

func A_arbace_a2g_names_static_field_name_A_New() *A_arbace_a2g_names_static_field_name_A { A_arbace_a2g_names_static_field_name_A_Init(); t := &A_arbace_a2g_names_static_field_name_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_a2g_names_static_field_name_A) Ctor() {}
//line :173:1
func (t *A_arbace_a2g_names_static_field_name_A) Invoke_O_O_O__O(self, cls_go__0, fname__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_59, nil); var tmp2 *lang.Var; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_28; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(fname__1))).Ref() }

func A_arbace_a2g_names_static_method_name_A_New() *A_arbace_a2g_names_static_method_name_A { A_arbace_a2g_names_static_method_name_A_Init(); t := &A_arbace_a2g_names_static_method_name_A{}; t.Ctor(); return t }
//line :175:1
func (t *A_arbace_a2g_names_static_method_name_A) Ctor() {}
//line :175:1
func (t *A_arbace_a2g_names_static_method_name_A) Invoke_O_O_O_O__O(self, cls_go__0, name__1, desc__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_59, nil); var tmp2 *lang.Var; A_arbace_a2g_names_A_Init(); tmp2 = A_arbace_a2g_names_A_const_49; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(name__1, desc__2))).Ref() }

func A_arbace_a2g_names_impl_name_A_New() *A_arbace_a2g_names_impl_name_A { A_arbace_a2g_names_impl_name_A_Init(); t := &A_arbace_a2g_names_impl_name_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_a2g_names_impl_name_A) Ctor() {}
//line :177:1
func (t *A_arbace_a2g_names_impl_name_A) Invoke_O_O__O(self, mbase__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, nil, mbase__0)).Ref() }


































type A_arbace_a2g_names_A struct{ jrt.Object }

var A_arbace_a2g_names_A_const_0 *lang.Var

var A_arbace_a2g_names_A_const_1 *lang.Var

var A_arbace_a2g_names_A_const_2 any

var A_arbace_a2g_names_A_const_3 any

var A_arbace_a2g_names_A_const_4 any

var A_arbace_a2g_names_A_const_5 *lang.Var

var A_arbace_a2g_names_A_const_6 *lang.Var

var A_arbace_a2g_names_A_const_7 *lang.Var

var A_arbace_a2g_names_A_const_8 any

var A_arbace_a2g_names_A_const_9 *lang.Var

var A_arbace_a2g_names_A_const_10 *lang.Var

var A_arbace_a2g_names_A_const_11 any

var A_arbace_a2g_names_A_const_12 *lang.Var

var A_arbace_a2g_names_A_const_13 *lang.Keyword

var A_arbace_a2g_names_A_const_14 *lang.Keyword

var A_arbace_a2g_names_A_const_15 *lang.Var

var A_arbace_a2g_names_A_const_16 *lang.Var

var A_arbace_a2g_names_A_const_17 *lang.Keyword

var A_arbace_a2g_names_A_const_18 *lang.Var

var A_arbace_a2g_names_A_const_19 *lang.Var

var A_arbace_a2g_names_A_const_20 any

var A_arbace_a2g_names_A_const_21 *lang.Var

var A_arbace_a2g_names_A_const_22 *lang.Var

var A_arbace_a2g_names_A_const_23 *lang.Var

var A_arbace_a2g_names_A_const_24 *lang.Var

var A_arbace_a2g_names_A_const_25 *lang.Var

var A_arbace_a2g_names_A_const_26 *lang.Var

var A_arbace_a2g_names_A_const_27 any

var A_arbace_a2g_names_A_const_28 *lang.Var

var A_arbace_a2g_names_A_const_29 *lang.Var

var A_arbace_a2g_names_A_const_30 *lang.Var

var A_arbace_a2g_names_A_const_31 *lang.Var

var A_arbace_a2g_names_A_const_32 *lang.Var

var A_arbace_a2g_names_A_const_33 *lang.Var

var A_arbace_a2g_names_A_const_34 any

var A_arbace_a2g_names_A_const_35 any

var A_arbace_a2g_names_A_const_36 *lang.Var

var A_arbace_a2g_names_A_const_37 *lang.Var

var A_arbace_a2g_names_A_const_38 *lang.Var

var A_arbace_a2g_names_A_const_39 *lang.Var

var A_arbace_a2g_names_A_const_40 any

var A_arbace_a2g_names_A_const_41 *lang.Var

var A_arbace_a2g_names_A_const_42 *lang.Var

var A_arbace_a2g_names_A_const_43 *lang.Var

var A_arbace_a2g_names_A_const_44 *lang.Var

var A_arbace_a2g_names_A_const_45 *lang.Var

var A_arbace_a2g_names_A_const_46 *lang.Var

var A_arbace_a2g_names_A_const_47 *lang.Var

var A_arbace_a2g_names_A_const_48 *lang.Var

var A_arbace_a2g_names_A_const_49 *lang.Var

var A_arbace_a2g_names_A_init jrt.ClassInit

func A_arbace_a2g_names_A_Init() { if !A_arbace_a2g_names_A_init.Done() { A_arbace_a2g_names_A_init.Run(A_arbace_a2g_names_A_clinit) } }

func A_arbace_a2g_names_A_clinit() { A_arbace_a2g_names_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_names_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_names_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_names_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_names_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_a2g_names_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_a2g_names_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_a2g_names_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_a2g_names_A_const_8 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_a2g_names_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_a2g_names_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_a2g_names_A_const_11 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_a2g_names_A_const_12 = lang.RT_Var_String_String__Var(Lit_3, Lit_16); A_arbace_a2g_names_A_const_13 = lang.RT_Keyword_String_String__Keyword(nil, Lit_17); A_arbace_a2g_names_A_const_14 = lang.RT_Keyword_String_String__Keyword(nil, Lit_18); A_arbace_a2g_names_A_const_15 = lang.RT_Var_String_String__Var(Lit_11, Lit_19); A_arbace_a2g_names_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_a2g_names_A_const_17 = lang.RT_Keyword_String_String__Keyword(nil, Lit_21); A_arbace_a2g_names_A_const_18 = lang.RT_Var_String_String__Var(Lit_11, Lit_22); A_arbace_a2g_names_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_a2g_names_A_const_20 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref())).Ref(); A_arbace_a2g_names_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_a2g_names_A_const_22 = lang.RT_Var_String_String__Var(Lit_3, Lit_25); A_arbace_a2g_names_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_a2g_names_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_a2g_names_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_a2g_names_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_a2g_names_A_const_27 = jrt.Character_ValueOf_C__Character(95).Ref(); A_arbace_a2g_names_A_const_28 = lang.RT_Var_String_String__Var(Lit_11, Lit_29); A_arbace_a2g_names_A_const_29 = lang.RT_Var_String_String__Var(Lit_3, Lit_30); A_arbace_a2g_names_A_const_30 = lang.RT_Var_String_String__Var(Lit_11, Lit_31); A_arbace_a2g_names_A_const_31 = lang.RT_Var_String_String__Var(Lit_11, Lit_32); A_arbace_a2g_names_A_const_32 = lang.RT_Var_String_String__Var(Lit_11, Lit_33); A_arbace_a2g_names_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_a2g_names_A_const_34 = jrt.Pattern_Compile_String__Pattern(Lit_35).Ref(); A_arbace_a2g_names_A_const_35 = jrt.Pattern_Compile_String__Pattern(Lit_36).Ref(); A_arbace_a2g_names_A_const_36 = lang.RT_Var_String_String__Var(Lit_11, Lit_37); A_arbace_a2g_names_A_const_37 = lang.RT_Var_String_String__Var(Lit_11, Lit_38); A_arbace_a2g_names_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_a2g_names_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_a2g_names_A_const_40 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_a2g_names_A_const_41 = lang.RT_Var_String_String__Var(Lit_6, Lit_41); A_arbace_a2g_names_A_const_42 = lang.RT_Var_String_String__Var(Lit_6, Lit_42); A_arbace_a2g_names_A_const_43 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); A_arbace_a2g_names_A_const_44 = lang.RT_Var_String_String__Var(Lit_6, Lit_44); A_arbace_a2g_names_A_const_45 = lang.RT_Var_String_String__Var(Lit_11, Lit_45); A_arbace_a2g_names_A_const_46 = lang.RT_Var_String_String__Var(Lit_6, Lit_46); A_arbace_a2g_names_A_const_47 = lang.RT_Var_String_String__Var(Lit_6, Lit_47); A_arbace_a2g_names_A_const_48 = lang.RT_Var_String_String__Var(Lit_11, Lit_48); A_arbace_a2g_names_A_const_49 = lang.RT_Var_String_String__Var(Lit_11, Lit_49) }

func A_arbace_a2g_names_A_New() *A_arbace_a2g_names_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_names_A) Ctor() {}

func (t *A_arbace_a2g_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_A_class }

func (t *A_arbace_a2g_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_A); return ok }

func A_arbace_a2g_names_A_Cast(x any) *A_arbace_a2g_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_A_class)) }; return v }



type A_arbace_a2g_names_capitalize_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_capitalize_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_capitalize_A_fn_class *jrt.Class

var A_arbace_a2g_names_capitalize_A_init jrt.ClassInit

func A_arbace_a2g_names_capitalize_A_Init() { if !A_arbace_a2g_names_capitalize_A_init.Done() { A_arbace_a2g_names_capitalize_A_init.Run(A_arbace_a2g_names_capitalize_A_clinit) } }

func A_arbace_a2g_names_capitalize_A_clinit() { A_arbace_a2g_names_capitalize_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_50, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_capitalize_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_capitalize_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_capitalize_A_class }

func (t *A_arbace_a2g_names_capitalize_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_capitalize_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_capitalize_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_capitalize_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_capitalize_A); return ok }

func A_arbace_a2g_names_capitalize_A_Cast(x any) *A_arbace_a2g_names_capitalize_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_capitalize_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_capitalize_A_class)) }; return v }



type A_arbace_a2g_names_compiled_class_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_names_compiled_class_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_compiled_class_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_names_compiled_class_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_names_compiled_class_QMARK__A_Init() { if !A_arbace_a2g_names_compiled_class_QMARK__A_init.Done() { A_arbace_a2g_names_compiled_class_QMARK__A_init.Run(A_arbace_a2g_names_compiled_class_QMARK__A_clinit) } }

func A_arbace_a2g_names_compiled_class_QMARK__A_clinit() { A_arbace_a2g_names_compiled_class_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_51, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_compiled_class_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_compiled_class_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_compiled_class_QMARK__A_class }

func (t *A_arbace_a2g_names_compiled_class_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_compiled_class_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_compiled_class_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_compiled_class_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_compiled_class_QMARK__A); return ok }

func A_arbace_a2g_names_compiled_class_QMARK__A_Cast(x any) *A_arbace_a2g_names_compiled_class_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_compiled_class_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_compiled_class_QMARK__A_class)) }; return v }



type A_arbace_a2g_names_compiled_pkg_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_compiled_pkg_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_names_compiled_pkg_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_names_compiled_pkg_QMARK__A_Init() { if !A_arbace_a2g_names_compiled_pkg_QMARK__A_init.Done() { A_arbace_a2g_names_compiled_pkg_QMARK__A_init.Run(A_arbace_a2g_names_compiled_pkg_QMARK__A_clinit) } }

func A_arbace_a2g_names_compiled_pkg_QMARK__A_clinit() { A_arbace_a2g_names_compiled_pkg_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_55, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_compiled_pkg_QMARK__A_class }

func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_compiled_pkg_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_compiled_pkg_QMARK__A); return ok }

func A_arbace_a2g_names_compiled_pkg_QMARK__A_Cast(x any) *A_arbace_a2g_names_compiled_pkg_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_compiled_pkg_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_compiled_pkg_QMARK__A_class)) }; return v }



type A_arbace_a2g_names_ctor_base_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_ctor_base_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_ctor_base_A_fn_class *jrt.Class

var A_arbace_a2g_names_ctor_base_A_init jrt.ClassInit

func A_arbace_a2g_names_ctor_base_A_Init() { if !A_arbace_a2g_names_ctor_base_A_init.Done() { A_arbace_a2g_names_ctor_base_A_init.Run(A_arbace_a2g_names_ctor_base_A_clinit) } }

func A_arbace_a2g_names_ctor_base_A_clinit() { A_arbace_a2g_names_ctor_base_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_ctor_base_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_ctor_base_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_ctor_base_A_class }

func (t *A_arbace_a2g_names_ctor_base_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_ctor_base_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_ctor_base_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_ctor_base_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_ctor_base_A); return ok }

func A_arbace_a2g_names_ctor_base_A_Cast(x any) *A_arbace_a2g_names_ctor_base_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_ctor_base_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_ctor_base_A_class)) }; return v }



type A_arbace_a2g_names_ctor_base_fn__593000037_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_ctor_base_fn__593000037_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_ctor_base_fn__593000037_A_fn_class *jrt.Class

var A_arbace_a2g_names_ctor_base_fn__593000037_A_init jrt.ClassInit

func A_arbace_a2g_names_ctor_base_fn__593000037_A_Init() { if !A_arbace_a2g_names_ctor_base_fn__593000037_A_init.Done() { A_arbace_a2g_names_ctor_base_fn__593000037_A_init.Run(A_arbace_a2g_names_ctor_base_fn__593000037_A_clinit) } }

func A_arbace_a2g_names_ctor_base_fn__593000037_A_clinit() { A_arbace_a2g_names_ctor_base_fn__593000037_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_ctor_base_fn__593000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_ctor_base_fn__593000037_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_ctor_base_fn__593000037_A_class }

func (t *A_arbace_a2g_names_ctor_base_fn__593000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_ctor_base_fn__593000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_ctor_base_fn__593000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_ctor_base_fn__593000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_ctor_base_fn__593000037_A); return ok }

func A_arbace_a2g_names_ctor_base_fn__593000037_A_Cast(x any) *A_arbace_a2g_names_ctor_base_fn__593000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_ctor_base_fn__593000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_ctor_base_fn__593000037_A_class)) }; return v }



type A_arbace_a2g_names_desc_code_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_desc_code_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_desc_code_A_fn_class *jrt.Class

var A_arbace_a2g_names_desc_code_A_init jrt.ClassInit

func A_arbace_a2g_names_desc_code_A_Init() { if !A_arbace_a2g_names_desc_code_A_init.Done() { A_arbace_a2g_names_desc_code_A_init.Run(A_arbace_a2g_names_desc_code_A_clinit) } }

func A_arbace_a2g_names_desc_code_A_clinit() { A_arbace_a2g_names_desc_code_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_desc_code_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_desc_code_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_desc_code_A_class }

func (t *A_arbace_a2g_names_desc_code_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_desc_code_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_desc_code_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_desc_code_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_desc_code_A); return ok }

func A_arbace_a2g_names_desc_code_A_Cast(x any) *A_arbace_a2g_names_desc_code_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_desc_code_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_desc_code_A_class)) }; return v }



type A_arbace_a2g_names_eval593000004_A struct{ jrt.Object }

func A_arbace_a2g_names_eval593000004_A_New() *A_arbace_a2g_names_eval593000004_A { t := &A_arbace_a2g_names_eval593000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_names_eval593000004_A) Ctor() {}

func (t *A_arbace_a2g_names_eval593000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_eval593000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_eval593000004_A_class }

func (t *A_arbace_a2g_names_eval593000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_eval593000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_eval593000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_eval593000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_eval593000004_A); return ok }

func A_arbace_a2g_names_eval593000004_A_Cast(x any) *A_arbace_a2g_names_eval593000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_eval593000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_eval593000004_A_class)) }; return v }



type A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_fn_class *jrt.Class

var A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_init jrt.ClassInit

func A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_Init() { if !A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_init.Done() { A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_init.Run(A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_clinit) } }

func A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_clinit() { A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_class }

func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A); return ok }

func A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_Cast(x any) *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_class)) }; return v }



type A_arbace_a2g_names_eval593000008_A struct{ jrt.Object }

func A_arbace_a2g_names_eval593000008_A_New() *A_arbace_a2g_names_eval593000008_A { t := &A_arbace_a2g_names_eval593000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_names_eval593000008_A) Ctor() {}

func (t *A_arbace_a2g_names_eval593000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_eval593000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_eval593000008_A_class }

func (t *A_arbace_a2g_names_eval593000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_eval593000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_eval593000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_eval593000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_eval593000008_A); return ok }

func A_arbace_a2g_names_eval593000008_A_Cast(x any) *A_arbace_a2g_names_eval593000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_eval593000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_eval593000008_A_class)) }; return v }



type A_arbace_a2g_names_eval593000008_fn__593000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_names_eval593000008_fn__593000009_A_fn_class *jrt.Class

var A_arbace_a2g_names_eval593000008_fn__593000009_A_init jrt.ClassInit

func A_arbace_a2g_names_eval593000008_fn__593000009_A_Init() { if !A_arbace_a2g_names_eval593000008_fn__593000009_A_init.Done() { A_arbace_a2g_names_eval593000008_fn__593000009_A_init.Run(A_arbace_a2g_names_eval593000008_fn__593000009_A_clinit) } }

func A_arbace_a2g_names_eval593000008_fn__593000009_A_clinit() { A_arbace_a2g_names_eval593000008_fn__593000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_64, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_eval593000008_fn__593000009_A_class }

func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_eval593000008_fn__593000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_eval593000008_fn__593000009_A); return ok }

func A_arbace_a2g_names_eval593000008_fn__593000009_A_Cast(x any) *A_arbace_a2g_names_eval593000008_fn__593000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_eval593000008_fn__593000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_eval593000008_fn__593000009_A_class)) }; return v }



type A_arbace_a2g_names_field_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_field_name_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_field_name_A_fn_class *jrt.Class

var A_arbace_a2g_names_field_name_A_init jrt.ClassInit

func A_arbace_a2g_names_field_name_A_Init() { if !A_arbace_a2g_names_field_name_A_init.Done() { A_arbace_a2g_names_field_name_A_init.Run(A_arbace_a2g_names_field_name_A_clinit) } }

func A_arbace_a2g_names_field_name_A_clinit() { A_arbace_a2g_names_field_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_field_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_field_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_field_name_A_class }

func (t *A_arbace_a2g_names_field_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_field_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_field_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_field_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_field_name_A); return ok }

func A_arbace_a2g_names_field_name_A_Cast(x any) *A_arbace_a2g_names_field_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_field_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_field_name_A_class)) }; return v }



type A_arbace_a2g_names_go_class_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_go_class_name_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_go_class_name_A_fn_class *jrt.Class

var A_arbace_a2g_names_go_class_name_A_init jrt.ClassInit

func A_arbace_a2g_names_go_class_name_A_Init() { if !A_arbace_a2g_names_go_class_name_A_init.Done() { A_arbace_a2g_names_go_class_name_A_init.Run(A_arbace_a2g_names_go_class_name_A_clinit) } }

func A_arbace_a2g_names_go_class_name_A_clinit() { A_arbace_a2g_names_go_class_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_go_class_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_go_class_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_go_class_name_A_class }

func (t *A_arbace_a2g_names_go_class_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_go_class_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_go_class_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_go_class_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_go_class_name_A); return ok }

func A_arbace_a2g_names_go_class_name_A_Cast(x any) *A_arbace_a2g_names_go_class_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_go_class_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_go_class_name_A_class)) }; return v }



type A_arbace_a2g_names_impl_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_impl_name_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_impl_name_A_fn_class *jrt.Class

var A_arbace_a2g_names_impl_name_A_init jrt.ClassInit

func A_arbace_a2g_names_impl_name_A_Init() { if !A_arbace_a2g_names_impl_name_A_init.Done() { A_arbace_a2g_names_impl_name_A_init.Run(A_arbace_a2g_names_impl_name_A_clinit) } }

func A_arbace_a2g_names_impl_name_A_clinit() { A_arbace_a2g_names_impl_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_impl_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_impl_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_impl_name_A_class }

func (t *A_arbace_a2g_names_impl_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_impl_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_impl_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_impl_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_impl_name_A); return ok }

func A_arbace_a2g_names_impl_name_A_Cast(x any) *A_arbace_a2g_names_impl_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_impl_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_impl_name_A_class)) }; return v }



type A_arbace_a2g_names_local_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_local_name_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_local_name_A_fn_class *jrt.Class

var A_arbace_a2g_names_local_name_A_init jrt.ClassInit

func A_arbace_a2g_names_local_name_A_Init() { if !A_arbace_a2g_names_local_name_A_init.Done() { A_arbace_a2g_names_local_name_A_init.Run(A_arbace_a2g_names_local_name_A_clinit) } }

func A_arbace_a2g_names_local_name_A_clinit() { A_arbace_a2g_names_local_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_local_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_local_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_local_name_A_class }

func (t *A_arbace_a2g_names_local_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_local_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_local_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_local_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_local_name_A); return ok }

func A_arbace_a2g_names_local_name_A_Cast(x any) *A_arbace_a2g_names_local_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_local_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_local_name_A_class)) }; return v }



type A_arbace_a2g_names_method_base_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_method_base_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_names_method_base_A_fn_class *jrt.Class

var A_arbace_a2g_names_method_base_A_init jrt.ClassInit

func A_arbace_a2g_names_method_base_A_Init() { if !A_arbace_a2g_names_method_base_A_init.Done() { A_arbace_a2g_names_method_base_A_init.Run(A_arbace_a2g_names_method_base_A_clinit) } }

func A_arbace_a2g_names_method_base_A_clinit() { A_arbace_a2g_names_method_base_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_method_base_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_method_base_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_method_base_A_class }

func (t *A_arbace_a2g_names_method_base_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_method_base_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_method_base_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_method_base_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_method_base_A); return ok }

func A_arbace_a2g_names_method_base_A_Cast(x any) *A_arbace_a2g_names_method_base_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_method_base_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_method_base_A_class)) }; return v }



type A_arbace_a2g_names_method_base_fn__593000030_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_method_base_fn__593000030_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_method_base_fn__593000030_A_fn_class *jrt.Class

var A_arbace_a2g_names_method_base_fn__593000030_A_init jrt.ClassInit

func A_arbace_a2g_names_method_base_fn__593000030_A_Init() { if !A_arbace_a2g_names_method_base_fn__593000030_A_init.Done() { A_arbace_a2g_names_method_base_fn__593000030_A_init.Run(A_arbace_a2g_names_method_base_fn__593000030_A_clinit) } }

func A_arbace_a2g_names_method_base_fn__593000030_A_clinit() { A_arbace_a2g_names_method_base_fn__593000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_method_base_fn__593000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_method_base_fn__593000030_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_method_base_fn__593000030_A_class }

func (t *A_arbace_a2g_names_method_base_fn__593000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_method_base_fn__593000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_method_base_fn__593000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_method_base_fn__593000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_method_base_fn__593000030_A); return ok }

func A_arbace_a2g_names_method_base_fn__593000030_A_Cast(x any) *A_arbace_a2g_names_method_base_fn__593000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_method_base_fn__593000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_method_base_fn__593000030_A_class)) }; return v }



type A_arbace_a2g_names_munge_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_munge_name_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_munge_name_A_fn_class *jrt.Class

var A_arbace_a2g_names_munge_name_A_init jrt.ClassInit

func A_arbace_a2g_names_munge_name_A_Init() { if !A_arbace_a2g_names_munge_name_A_init.Done() { A_arbace_a2g_names_munge_name_A_init.Run(A_arbace_a2g_names_munge_name_A_clinit) } }

func A_arbace_a2g_names_munge_name_A_clinit() { A_arbace_a2g_names_munge_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_munge_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_munge_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_munge_name_A_class }

func (t *A_arbace_a2g_names_munge_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_munge_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_munge_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_munge_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_munge_name_A); return ok }

func A_arbace_a2g_names_munge_name_A_Cast(x any) *A_arbace_a2g_names_munge_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_munge_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_munge_name_A_class)) }; return v }



type A_arbace_a2g_names_munge_name_fn__593000018_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_munge_name_fn__593000018_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_munge_name_fn__593000018_A_fn_class *jrt.Class

var A_arbace_a2g_names_munge_name_fn__593000018_A_init jrt.ClassInit

func A_arbace_a2g_names_munge_name_fn__593000018_A_Init() { if !A_arbace_a2g_names_munge_name_fn__593000018_A_init.Done() { A_arbace_a2g_names_munge_name_fn__593000018_A_init.Run(A_arbace_a2g_names_munge_name_fn__593000018_A_clinit) } }

func A_arbace_a2g_names_munge_name_fn__593000018_A_clinit() { A_arbace_a2g_names_munge_name_fn__593000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_munge_name_fn__593000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_munge_name_fn__593000018_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_munge_name_fn__593000018_A_class }

func (t *A_arbace_a2g_names_munge_name_fn__593000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_munge_name_fn__593000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_munge_name_fn__593000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_munge_name_fn__593000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_munge_name_fn__593000018_A); return ok }

func A_arbace_a2g_names_munge_name_fn__593000018_A_Cast(x any) *A_arbace_a2g_names_munge_name_fn__593000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_munge_name_fn__593000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_munge_name_fn__593000018_A_class)) }; return v }



type A_arbace_a2g_names_new_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_new_name_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_names_new_name_A_fn_class *jrt.Class

var A_arbace_a2g_names_new_name_A_init jrt.ClassInit

func A_arbace_a2g_names_new_name_A_Init() { if !A_arbace_a2g_names_new_name_A_init.Done() { A_arbace_a2g_names_new_name_A_init.Run(A_arbace_a2g_names_new_name_A_clinit) } }

func A_arbace_a2g_names_new_name_A_clinit() { A_arbace_a2g_names_new_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_new_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_new_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_new_name_A_class }

func (t *A_arbace_a2g_names_new_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_new_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_new_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_new_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_new_name_A); return ok }

func A_arbace_a2g_names_new_name_A_Cast(x any) *A_arbace_a2g_names_new_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_new_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_new_name_A_class)) }; return v }



type A_arbace_a2g_names_new_name_fn__593000044_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_new_name_fn__593000044_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_new_name_fn__593000044_A_fn_class *jrt.Class

var A_arbace_a2g_names_new_name_fn__593000044_A_init jrt.ClassInit

func A_arbace_a2g_names_new_name_fn__593000044_A_Init() { if !A_arbace_a2g_names_new_name_fn__593000044_A_init.Done() { A_arbace_a2g_names_new_name_fn__593000044_A_init.Run(A_arbace_a2g_names_new_name_fn__593000044_A_clinit) } }

func A_arbace_a2g_names_new_name_fn__593000044_A_clinit() { A_arbace_a2g_names_new_name_fn__593000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_new_name_fn__593000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_new_name_fn__593000044_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_new_name_fn__593000044_A_class }

func (t *A_arbace_a2g_names_new_name_fn__593000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_new_name_fn__593000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_new_name_fn__593000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_new_name_fn__593000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_new_name_fn__593000044_A); return ok }

func A_arbace_a2g_names_new_name_fn__593000044_A_Cast(x any) *A_arbace_a2g_names_new_name_fn__593000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_new_name_fn__593000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_new_name_fn__593000044_A_class)) }; return v }



type A_arbace_a2g_names_pkg_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_pkg_name_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_pkg_name_A_fn_class *jrt.Class

var A_arbace_a2g_names_pkg_name_A_init jrt.ClassInit

func A_arbace_a2g_names_pkg_name_A_Init() { if !A_arbace_a2g_names_pkg_name_A_init.Done() { A_arbace_a2g_names_pkg_name_A_init.Run(A_arbace_a2g_names_pkg_name_A_clinit) } }

func A_arbace_a2g_names_pkg_name_A_clinit() { A_arbace_a2g_names_pkg_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_pkg_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_pkg_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_pkg_name_A_class }

func (t *A_arbace_a2g_names_pkg_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_pkg_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_pkg_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_pkg_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_pkg_name_A); return ok }

func A_arbace_a2g_names_pkg_name_A_Cast(x any) *A_arbace_a2g_names_pkg_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_pkg_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_pkg_name_A_class)) }; return v }



type A_arbace_a2g_names_pkg_ns_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_pkg_ns_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_pkg_ns_A_fn_class *jrt.Class

var A_arbace_a2g_names_pkg_ns_A_init jrt.ClassInit

func A_arbace_a2g_names_pkg_ns_A_Init() { if !A_arbace_a2g_names_pkg_ns_A_init.Done() { A_arbace_a2g_names_pkg_ns_A_init.Run(A_arbace_a2g_names_pkg_ns_A_clinit) } }

func A_arbace_a2g_names_pkg_ns_A_clinit() { A_arbace_a2g_names_pkg_ns_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_pkg_ns_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_pkg_ns_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_pkg_ns_A_class }

func (t *A_arbace_a2g_names_pkg_ns_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_pkg_ns_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_pkg_ns_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_pkg_ns_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_pkg_ns_A); return ok }

func A_arbace_a2g_names_pkg_ns_A_Cast(x any) *A_arbace_a2g_names_pkg_ns_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_pkg_ns_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_pkg_ns_A_class)) }; return v }



type A_arbace_a2g_names_pkg_of_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_pkg_of_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_pkg_of_A_fn_class *jrt.Class

var A_arbace_a2g_names_pkg_of_A_init jrt.ClassInit

func A_arbace_a2g_names_pkg_of_A_Init() { if !A_arbace_a2g_names_pkg_of_A_init.Done() { A_arbace_a2g_names_pkg_of_A_init.Run(A_arbace_a2g_names_pkg_of_A_clinit) } }

func A_arbace_a2g_names_pkg_of_A_clinit() { A_arbace_a2g_names_pkg_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_pkg_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_pkg_of_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_pkg_of_A_class }

func (t *A_arbace_a2g_names_pkg_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_pkg_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_pkg_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_pkg_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_pkg_of_A); return ok }

func A_arbace_a2g_names_pkg_of_A_Cast(x any) *A_arbace_a2g_names_pkg_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_pkg_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_pkg_of_A_class)) }; return v }



type A_arbace_a2g_names_pkg_path_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_pkg_path_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_pkg_path_A_fn_class *jrt.Class

var A_arbace_a2g_names_pkg_path_A_init jrt.ClassInit

func A_arbace_a2g_names_pkg_path_A_Init() { if !A_arbace_a2g_names_pkg_path_A_init.Done() { A_arbace_a2g_names_pkg_path_A_init.Run(A_arbace_a2g_names_pkg_path_A_clinit) } }

func A_arbace_a2g_names_pkg_path_A_clinit() { A_arbace_a2g_names_pkg_path_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_95, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_pkg_path_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_pkg_path_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_pkg_path_A_class }

func (t *A_arbace_a2g_names_pkg_path_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_pkg_path_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_pkg_path_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_pkg_path_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_pkg_path_A); return ok }

func A_arbace_a2g_names_pkg_path_A_Cast(x any) *A_arbace_a2g_names_pkg_path_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_pkg_path_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_pkg_path_A_class)) }; return v }



type A_arbace_a2g_names_static_field_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_static_field_name_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_names_static_field_name_A_fn_class *jrt.Class

var A_arbace_a2g_names_static_field_name_A_init jrt.ClassInit

func A_arbace_a2g_names_static_field_name_A_Init() { if !A_arbace_a2g_names_static_field_name_A_init.Done() { A_arbace_a2g_names_static_field_name_A_init.Run(A_arbace_a2g_names_static_field_name_A_clinit) } }

func A_arbace_a2g_names_static_field_name_A_clinit() { A_arbace_a2g_names_static_field_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_96, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_static_field_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_static_field_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_static_field_name_A_class }

func (t *A_arbace_a2g_names_static_field_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_static_field_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_static_field_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_static_field_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_static_field_name_A); return ok }

func A_arbace_a2g_names_static_field_name_A_Cast(x any) *A_arbace_a2g_names_static_field_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_static_field_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_static_field_name_A_class)) }; return v }



type A_arbace_a2g_names_static_method_name_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_static_method_name_A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_names_static_method_name_A_fn_class *jrt.Class

var A_arbace_a2g_names_static_method_name_A_init jrt.ClassInit

func A_arbace_a2g_names_static_method_name_A_Init() { if !A_arbace_a2g_names_static_method_name_A_init.Done() { A_arbace_a2g_names_static_method_name_A_init.Run(A_arbace_a2g_names_static_method_name_A_clinit) } }

func A_arbace_a2g_names_static_method_name_A_clinit() { A_arbace_a2g_names_static_method_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_97, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_static_method_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_static_method_name_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_static_method_name_A_class }

func (t *A_arbace_a2g_names_static_method_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_static_method_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_static_method_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_static_method_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_static_method_name_A); return ok }

func A_arbace_a2g_names_static_method_name_A_Cast(x any) *A_arbace_a2g_names_static_method_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_static_method_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_static_method_name_A_class)) }; return v }



type A_arbace_a2g_names_top_of_A struct{ jrt.Object }

func (t *A_arbace_a2g_names_top_of_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_names_top_of_A_fn_class *jrt.Class

var A_arbace_a2g_names_top_of_A_init jrt.ClassInit

func A_arbace_a2g_names_top_of_A_Init() { if !A_arbace_a2g_names_top_of_A_init.Done() { A_arbace_a2g_names_top_of_A_init.Run(A_arbace_a2g_names_top_of_A_clinit) } }

func A_arbace_a2g_names_top_of_A_clinit() { A_arbace_a2g_names_top_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_98, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_names_top_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_top_of_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_top_of_A_class }

func (t *A_arbace_a2g_names_top_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_top_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_top_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_top_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_top_of_A); return ok }

func A_arbace_a2g_names_top_of_A_Cast(x any) *A_arbace_a2g_names_top_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_top_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_top_of_A_class)) }; return v }
