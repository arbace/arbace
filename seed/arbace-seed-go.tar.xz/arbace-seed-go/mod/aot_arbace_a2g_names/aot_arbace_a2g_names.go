//line aot_arbace_a2g_names.ae:1
package aot_arbace_a2g_names

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_New() *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_a2g_names_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_names_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_a2g_names_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_names_A_const_3, A_arbace_a2g_names_A_const_4); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_a2g_names_eval593000008_fn__593000009_A_New() *A_arbace_a2g_names_eval593000008_fn__593000009_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_eval593000008_fn__593000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_names_eval593000008_fn__593000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_names_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_names_A_const_9), A_arbace_a2g_names_A_const_7.GetRawRoot__O(), A_arbace_a2g_names_A_const_8) }















func A_arbace_a2g_names_top_of_A_New() *A_arbace_a2g_names_top_of_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_top_of_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_a2g_names_top_of_A) Ctor() {}
//line :17:1
func (t *A_arbace_a2g_names_top_of_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_10); if lang.Numbers_IsNeg_J__Z(int64(i__2)) { return n__0 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_names_A_const_10.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_names_A_const_11; return tmp1.Invoke_O_O_O__O(n__0, tmp2, jrt.Integer_ValueOf_I__Integer(i__2).Ref()) } }

func A_arbace_a2g_names_pkg_of_A_New() *A_arbace_a2g_names_pkg_of_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_pkg_of_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_a2g_names_pkg_of_A) Ctor() {}
//line :19:1
func (t *A_arbace_a2g_names_pkg_of_A) Invoke_O_O__O(self, internal__0 any) any {




	var tmp1 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_25)
	if jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_26); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_27); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_28); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else {

		tmp1 = lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_29) } } } }
//line :24:1
	if jrt.A2g_Truth(tmp1) { return A_arbace_a2g_names_A_const_13 } else { if A_arbace_a2g_names_A_const_14 != nil { var temp__1927000408__auto____2 any = lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_names_A_const_18.GetRawRoot__O()), lang.IFn_Cast(A_arbace_a2g_names_A_const_15.GetRawRoot__O()).Invoke_O__O(internal__0))



		if jrt.A2g_Truth(temp__1927000408__auto____2) { var p__3 any = temp__1927000408__auto____2; return lang.IFn_Cast(A_arbace_a2g_names_A_const_16.GetRawRoot__O()).Invoke_O__O(p__3) } else { return A_arbace_a2g_names_A_const_17 } } else {
//line :24:1
			return nil
		}
	}
}


func A_arbace_a2g_names_compiled_pkg_QMARK__A_New() *A_arbace_a2g_names_compiled_pkg_QMARK__A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_compiled_pkg_QMARK__A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) Ctor() {}
//line :30:1
func (t *A_arbace_a2g_names_compiled_pkg_QMARK__A) Invoke_O_O__O(self, pkg__0 any) any { return lang.IFn_Cast(A_arbace_a2g_names_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_20).Invoke_O__O(pkg__0)) }

func A_arbace_a2g_names_pkg_name_A_New() *A_arbace_a2g_names_pkg_name_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_pkg_name_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_a2g_names_pkg_name_A) Ctor() {}
//line :32:1
func (t *A_arbace_a2g_names_pkg_name_A) Invoke_O_O__O(self, pkg__0 any) any { return lang.IFn_Cast(A_arbace_a2g_names_A_const_21.GetRawRoot__O()).Invoke_O__O(pkg__0) }
func A_arbace_a2g_names_pkg_path_A_New() *A_arbace_a2g_names_pkg_path_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_pkg_path_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_a2g_names_pkg_path_A) Ctor() {}
//line :33:1
func (t *A_arbace_a2g_names_pkg_path_A) Invoke_O_O__O(self, pkg__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_21.GetRawRoot__O()).Invoke_O__O(pkg__0))).Ref() }
func A_arbace_a2g_names_pkg_ns_A_New() *A_arbace_a2g_names_pkg_ns_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_pkg_ns_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_a2g_names_pkg_ns_A) Ctor() {}
//line :34:1
func (t *A_arbace_a2g_names_pkg_ns_A) Invoke_O_O__O(self, pkg__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_21.GetRawRoot__O()).Invoke_O__O(pkg__0))).Ref() }



















func A_arbace_a2g_names_memo_str_A_New() *A_arbace_a2g_names_memo_str_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_memo_str_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_a2g_names_memo_str_A) Ctor() {}
//line :54:1
func (t *A_arbace_a2g_names_memo_str_A) Invoke_O_O__O(self, f__0 any) any { var cache__2 any = jrt.ConcurrentHashMap_New(); var tmp1 any = A_arbace_a2g_names_memo_str_fn__593000018_A_New_O_O(cache__2, f__0); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_a2g_names_memo_str_fn__593000018_A_fn_class; if




	fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_a2g_names_memo_str_fn__593000018_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :59:1
func A_arbace_a2g_names_memo_str_fn__593000018_A_New_O_O(p0, p1 any) *A_arbace_a2g_names_memo_str_fn__593000018_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_memo_str_fn__593000018_A{}; t.Ctor_O_O(p0, p1); return t }
//line :59:1
func (t *A_arbace_a2g_names_memo_str_fn__593000018_A) Ctor_O_O(c__cache, c__f any) { t.F_cache = c__cache; t.F_f = c__f }
//line :59:1
func (t *A_arbace_a2g_names_memo_str_fn__593000018_A) Invoke_O_O__O(self, k__1 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Get_O__O(k__1); if
											jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var v__3 any = lang.IFn_Cast(t.F_f).Invoke_O__O(k__1)

		jrt.NN(jrt.ConcurrentHashMap_Cast(t.F_cache)).Put_O_O__O(k__1, v__3)
//line :60:1
		return v__3 } }






func A_arbace_a2g_names_fn__593000021_A_New() *A_arbace_a2g_names_fn__593000021_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_fn__593000021_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_a2g_names_fn__593000021_A) Ctor() {}
//line :67:1
func (t *A_arbace_a2g_names_fn__593000021_A) Invoke_O_O__O(self, s__0 any) any { var m__2 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_25.GetRawRoot__O()).Invoke_O__O(s__0)), Lit_10, Lit_6); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_names_A_const_23.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_names_A_const_24.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_names_A_const_26.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_names_fn__593000021_fn__593000022_A_New(); var tmp5 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_names_fn__593000021_fn__593000022_A_fn_class; if



	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_a2g_names_fn__593000021_fn__593000022_A_fn_class = fncls__2d; tmp5 = fncls__2d } else { tmp5 = fncls__2 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), m__2)) }
//line :71:1
func A_arbace_a2g_names_fn__593000021_fn__593000022_A_New() *A_arbace_a2g_names_fn__593000021_fn__593000022_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_fn__593000021_fn__593000022_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_a2g_names_fn__593000021_fn__593000022_A) Ctor() {}
//line :71:1
func (t *A_arbace_a2g_names_fn__593000021_fn__593000022_A) Invoke_O_O__O(self, c__1 any) any { var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Character_IsLetterOrDigit_C__Z(lang.RT_CharCast_O__C(c__1)); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z(c__1, A_arbace_a2g_names_A_const_27) }; if tmp1 { return c__1 } else { return A_arbace_a2g_names_A_const_27 } }

func A_arbace_a2g_names_munge_name_A_New() *A_arbace_a2g_names_munge_name_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_munge_name_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_a2g_names_munge_name_A) Ctor() {}
//line :73:1
func (t *A_arbace_a2g_names_munge_name_A) Invoke_O_O__O(self, s__0 any) any {


	return lang.IFn_Cast(A_arbace_a2g_names_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_24.GetRawRoot__O()).Invoke_O__O(s__0))
}
func A_arbace_a2g_names_local_name_A_New() *A_arbace_a2g_names_local_name_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_local_name_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_a2g_names_local_name_A) Ctor() {}
//line :78:1
func (t *A_arbace_a2g_names_local_name_A) Invoke_O_O__O(self, sym__0 any) any { var s__2 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_21.GetRawRoot__O()).Invoke_O__O(sym__0)); var s__3 any; if





	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_names_A_const_30.GetRawRoot__O()).Invoke_O__O(s__2)) { s__3 = Lit_17 } else { s__3 = s__2 }; var tmp1 any; var or__1927000174__auto____4 any =
	lang.IFn_Cast(A_arbace_a2g_names_A_const_31.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_32.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_33.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { var or__1927000174__auto____7 bool = jrt.Character_IsUpperCase_C__Z(jrt.NN(jrt.String_Cast(s__3)).CharAt_I__C(lang.RT_IntCast_J__I(0))); if or__1927000174__auto____7 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(s__3, Lit_18); if jrt.A2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var or__1927000174__auto____9 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_names_A_const_35, s__3); if jrt.A2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else {

		tmp1 = lang.IFn_Cast(A_arbace_a2g_names_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_names_A_const_36, s__3) } } } } } }; if /*line :85:1*/ jrt.A2g_Truth(tmp1) {


			return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, s__3, nil)).Ref() } else {
//line :85:1
				return s__3 } }








































func A_arbace_a2g_names_compiled_class_QMARK__A_New() *A_arbace_a2g_names_compiled_class_QMARK__A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_compiled_class_QMARK__A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_a2g_names_compiled_class_QMARK__A) Ctor() {}
//line :126:1
func (t *A_arbace_a2g_names_compiled_class_QMARK__A) Invoke_O_O__O(self, internal__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_1); if



	jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_2)); if jrt.A2g_Truth(and__1927000168__auto____3) {
		return lang.IFn_Cast(A_arbace_a2g_names_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(internal__0, Lit_3)) } else {
//line :130:1
			return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }




func A_arbace_a2g_names_go_class_name_A_New() *A_arbace_a2g_names_go_class_name_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_go_class_name_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_a2g_names_go_class_name_A) Ctor() {}
//line :135:1
func (t *A_arbace_a2g_names_go_class_name_A) Invoke_O_O__O(self, internal__0 any) any {





	return lang.IFn_Cast(A_arbace_a2g_names_A_const_37.GetRawRoot__O()).Invoke_O__O(internal__0)
}
func A_arbace_a2g_names_go_class_name_STAR__STAR__A_New() *A_arbace_a2g_names_go_class_name_STAR__STAR__A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_go_class_name_STAR__STAR__A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_a2g_names_go_class_name_STAR__STAR__A) Ctor() {}
//line :143:1
func (t *A_arbace_a2g_names_go_class_name_STAR__STAR__A) Invoke_O_O__O(self, internal__0 any) any { var or__1927000174__auto____2 any = lang.RT_Get_O_O__O(A_arbace_a2g_names_A_const_38.GetRawRoot__O(), internal__0); if
													jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any
														if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_names_A_const_39.GetRawRoot__O()).Invoke_O__O(internal__0)) {

			or__1927000174__auto____3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_13), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(internal__0, Lit_14, Lit_6)), nil)).Ref() } else {
//line :145:1
				or__1927000174__auto____3 = nil }
//line :144:1
		if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var s__4 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_10.GetRawRoot__O()).Invoke_O_O__O(internal__0, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(internal__0)).LastIndexOf_String__I(Lit_14)))).Ref()); var s__5 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_29.GetRawRoot__O()).Invoke_O__O(s__4); var tmp1 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_40.GetRawRoot__O()).Invoke_O__O(s__5)





			if jrt.A2g_Truth(and__1927000168__auto____6) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(jrt.Character_IsUpperCase_C__Z(jrt.NN(jrt.String_Cast(s__5)).CharAt_I__C(lang.RT_IntCast_J__I(0)))).Ref() } else { tmp1 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp1) { return s__5 } else {

				return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__5)).Ref() } } } }



func A_arbace_a2g_names_capitalize_A_New() *A_arbace_a2g_names_capitalize_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_capitalize_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_a2g_names_capitalize_A) Ctor() {}
//line :156:1
func (t *A_arbace_a2g_names_capitalize_A) Invoke_O_O__O(self, s__0 any) any {
	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_names_A_const_41.GetRawRoot__O()).Invoke_O__O(s__0)) { return s__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, jrt.Character_ValueOf_C__Character(jrt.Character_ToUpperCase_C__C(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_J__I(0)))).Ref(), lang.IFn_Cast(A_arbace_a2g_names_A_const_10.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_a2g_names_A_const_42))).Ref()
	}
}






func A_arbace_a2g_names_desc_code_A_New() *A_arbace_a2g_names_desc_code_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_desc_code_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_a2g_names_desc_code_A) Ctor() {}
//line :166:1
func (t *A_arbace_a2g_names_desc_code_A) Invoke_O_O__O(self, d__0 any) any {


	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_names_A_const_43.GetRawRoot__O()).Invoke_O__O(d__0)) { var n__2 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_44.GetRawRoot__O()).Invoke_O__O(d__0); var e__3 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_10.GetRawRoot__O()).Invoke_O_O__O(d__0, n__2)


		return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_a2g_names_A_const_45.GetRawRoot__O()).Invoke_O__O(e__3), n__2)).Ref() } else {
//line :169:1
			if lang.Util_Equiv_O_O__Z(d__0, Lit_7) { return Lit_8 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_names_A_const_46.GetRawRoot__O()).Invoke_O__O(d__0)) {




				return lang.IFn_Cast(A_arbace_a2g_names_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_48.GetRawRoot__O()).Invoke_O__O(d__0)) } else {
//line :169:1
					if A_arbace_a2g_names_A_const_14 != nil { return d__0 } else { return nil
					}
				}
			}
		}
}




func A_arbace_a2g_names_method_base_A_New() *A_arbace_a2g_names_method_base_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_method_base_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_a2g_names_method_base_A) Ctor() {}
//line :179:1
func (t *A_arbace_a2g_names_method_base_A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var c__3 any = A_arbace_a2g_names_A_const_49.GetRawRoot__O(); var k__4 any = lang.Tuple_Create_O_O__IPersistentVector(name__0, desc__1); var or__1927000174__auto____5 any = jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Get_O__O(k__4); if




	jrt.A2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var v__6 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_50.GetRawRoot__O()).Invoke_O_O__O(name__0, desc__1)

		jrt.NN(jrt.ConcurrentHashMap_Cast(c__3)).Put_O_O__O(k__4, v__6)
//line :184:1
		return v__6 } }




func A_arbace_a2g_names_method_base_STAR__A_New() *A_arbace_a2g_names_method_base_STAR__A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_method_base_STAR__A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_a2g_names_method_base_STAR__A) Ctor() {}
//line :189:1
func (t *A_arbace_a2g_names_method_base_STAR__A) Invoke_O_O_O__O(self, name__0, desc__1 any) any { var vec__593000034__3 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_51.GetRawRoot__O()).Invoke_O__O(desc__1); var ps__4 any = lang.RT_Nth_O_I_O__O(vec__593000034__3, lang.RT_IntCast_J__I(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O(vec__593000034__3, lang.RT_IntCast_J__I(1), nil); var m__6 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_names_A_const_29.GetRawRoot__O()).Invoke_O__O(name__0)); var m__7 any; if


	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_names_A_const_12.GetRawRoot__O()).Invoke_O_O__O(m__6, Lit_6)) { m__7 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__6)).Ref() } else { m__7 = m__6 }; var tmp1 /*line :193:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_20, nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_names_A_const_23.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_names_A_const_24.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_names_A_const_26.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_names_method_base_STAR__fn__593000037_A_New(); var tmp6 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_a2g_names_method_base_STAR__fn__593000037_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_a2g_names_method_base_STAR__fn__593000037_A_fn_class = fncls__3d; tmp6 = fncls__3d } else { tmp6 = fncls__3 }; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, m__7, tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ps__4)), nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_45.GetRawRoot__O()).Invoke_O__O(r__5))).Ref() }
//line :193:1
func A_arbace_a2g_names_method_base_STAR__fn__593000037_A_New() *A_arbace_a2g_names_method_base_STAR__fn__593000037_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_method_base_STAR__fn__593000037_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_a2g_names_method_base_STAR__fn__593000037_A) Ctor() {}
//line :193:1
func (t *A_arbace_a2g_names_method_base_STAR__fn__593000037_A) Invoke_O_O__O(self, p1__593000033_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_45.GetRawRoot__O()).Invoke_O__O(p1__593000033_SHARP___1))).Ref() }

func A_arbace_a2g_names_ctor_base_A_New() *A_arbace_a2g_names_ctor_base_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_ctor_base_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_a2g_names_ctor_base_A) Ctor() {}
//line :195:1
func (t *A_arbace_a2g_names_ctor_base_A) Invoke_O_O__O(self, desc__0 any) any { var vec__593000041__2 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_51.GetRawRoot__O()).Invoke_O__O(desc__0); var ps__3 any = lang.RT_Nth_O_I_O__O(vec__593000041__2, lang.RT_IntCast_J__I(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O(vec__593000041__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_names_A_const_23.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_names_A_const_24.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_names_A_const_26.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_names_ctor_base_fn__593000044_A_New(); var tmp6 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_names_ctor_base_fn__593000044_A_fn_class; _ = ___4; if




	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_a2g_names_ctor_base_fn__593000044_A_fn_class = fncls__4d; tmp6 = fncls__4d } else { tmp6 = fncls__4 }; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ps__3)))).Ref() }
//line :200:1
func A_arbace_a2g_names_ctor_base_fn__593000044_A_New() *A_arbace_a2g_names_ctor_base_fn__593000044_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_ctor_base_fn__593000044_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_a2g_names_ctor_base_fn__593000044_A) Ctor() {}
//line :200:1
func (t *A_arbace_a2g_names_ctor_base_fn__593000044_A) Invoke_O_O__O(self, p1__593000040_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_45.GetRawRoot__O()).Invoke_O__O(p1__593000040_SHARP___1))).Ref() }

func A_arbace_a2g_names_new_name_A_New() *A_arbace_a2g_names_new_name_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_new_name_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_a2g_names_new_name_A) Ctor() {}
//line :202:1
func (t *A_arbace_a2g_names_new_name_A) Invoke_O_O_O__O(self, cls_go__0, desc__1 any) any { var vec__593000048__3 any = lang.IFn_Cast(A_arbace_a2g_names_A_const_51.GetRawRoot__O()).Invoke_O__O(desc__1); var ps__4 any = lang.RT_Nth_O_I_O__O(vec__593000048__3, lang.RT_IntCast_J__I(0), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__593000048__3, lang.RT_IntCast_J__I(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_names_A_const_23.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_names_A_const_24.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_names_A_const_26.GetRawRoot__O()); var tmp5 any = A_arbace_a2g_names_new_name_fn__593000051_A_New(); var tmp6 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_a2g_names_new_name_fn__593000051_A_fn_class; _ = ___5; if



	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_a2g_names_new_name_fn__593000051_A_fn_class = fncls__5d; tmp6 = fncls__5d } else { tmp6 = fncls__5 }; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ps__4)))).Ref() }
//line :206:1
func A_arbace_a2g_names_new_name_fn__593000051_A_New() *A_arbace_a2g_names_new_name_fn__593000051_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_new_name_fn__593000051_A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_a2g_names_new_name_fn__593000051_A) Ctor() {}
//line :206:1
func (t *A_arbace_a2g_names_new_name_fn__593000051_A) Invoke_O_O__O(self, p1__593000047_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_45.GetRawRoot__O()).Invoke_O__O(p1__593000047_SHARP___1))).Ref() }

func A_arbace_a2g_names_field_name_A_New() *A_arbace_a2g_names_field_name_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_field_name_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_a2g_names_field_name_A) Ctor() {}
//line :208:1
func (t *A_arbace_a2g_names_field_name_A) Invoke_O_O__O(self, fname__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_29.GetRawRoot__O()).Invoke_O__O(fname__0))).Ref() }

func A_arbace_a2g_names_static_field_name_A_New() *A_arbace_a2g_names_static_field_name_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_static_field_name_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_a2g_names_static_field_name_A) Ctor() {}
//line :210:1
func (t *A_arbace_a2g_names_static_field_name_A) Invoke_O_O_O__O(self, cls_go__0, fname__1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_29.GetRawRoot__O()).Invoke_O__O(fname__1))).Ref() }

func A_arbace_a2g_names_static_method_name_A_New() *A_arbace_a2g_names_static_method_name_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_static_method_name_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_a2g_names_static_method_name_A) Ctor() {}
//line :212:1
func (t *A_arbace_a2g_names_static_method_name_A) Invoke_O_O_O_O__O(self, cls_go__0, name__1, desc__2 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, cls_go__0, nil, lang.IFn_Cast(A_arbace_a2g_names_A_const_53.GetRawRoot__O()).Invoke_O_O__O(name__1, desc__2))).Ref() }

func A_arbace_a2g_names_impl_name_A_New() *A_arbace_a2g_names_impl_name_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_impl_name_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_a2g_names_impl_name_A) Ctor() {}
//line :214:1
func (t *A_arbace_a2g_names_impl_name_A) Invoke_O_O__O(self, mbase__0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, mbase__0)).Ref() }




































type A_arbace_a2g_names_A struct{ jrt.Object }

var A_arbace_a2g_names_A_const_pool *jrt.RefArray

var A_arbace_a2g_names_A_const_0 *lang.Var

var A_arbace_a2g_names_A_const_1 *lang.Var

var A_arbace_a2g_names_A_const_2 any

var A_arbace_a2g_names_A_const_3 any

var A_arbace_a2g_names_A_const_4 any

var A_arbace_a2g_names_A_const_5 *lang.Var

var A_arbace_a2g_names_A_const_6 *lang.Var

var A_arbace_a2g_names_A_const_7 *lang.Var

var A_arbace_a2g_names_A_const_8 any

var A_arbace_a2g_names_A_const_9 *lang.Var

var A_arbace_a2g_names_A_const_10 *lang.Var

var A_arbace_a2g_names_A_const_11 any

var A_arbace_a2g_names_A_const_12 *lang.Var

var A_arbace_a2g_names_A_const_13 *lang.Keyword

var A_arbace_a2g_names_A_const_14 *lang.Keyword

var A_arbace_a2g_names_A_const_15 *lang.Var

var A_arbace_a2g_names_A_const_16 *lang.Var

var A_arbace_a2g_names_A_const_17 *lang.Keyword

var A_arbace_a2g_names_A_const_18 *lang.Var

var A_arbace_a2g_names_A_const_19 *lang.Var

var A_arbace_a2g_names_A_const_20 any

var A_arbace_a2g_names_A_const_21 *lang.Var

var A_arbace_a2g_names_A_const_22 *lang.Var

var A_arbace_a2g_names_A_const_23 *lang.Var

var A_arbace_a2g_names_A_const_24 *lang.Var

var A_arbace_a2g_names_A_const_25 *lang.Var

var A_arbace_a2g_names_A_const_26 *lang.Var

var A_arbace_a2g_names_A_const_27 any

var A_arbace_a2g_names_A_const_28 *lang.Var

var A_arbace_a2g_names_A_const_29 *lang.Var

var A_arbace_a2g_names_A_const_30 *lang.Var

var A_arbace_a2g_names_A_const_31 *lang.Var

var A_arbace_a2g_names_A_const_32 *lang.Var

var A_arbace_a2g_names_A_const_33 *lang.Var

var A_arbace_a2g_names_A_const_34 *lang.Var

var A_arbace_a2g_names_A_const_35 any

var A_arbace_a2g_names_A_const_36 any

var A_arbace_a2g_names_A_const_37 *lang.Var

var A_arbace_a2g_names_A_const_38 *lang.Var

var A_arbace_a2g_names_A_const_39 *lang.Var

var A_arbace_a2g_names_A_const_40 *lang.Var

var A_arbace_a2g_names_A_const_41 *lang.Var

var A_arbace_a2g_names_A_const_42 any

var A_arbace_a2g_names_A_const_43 *lang.Var

var A_arbace_a2g_names_A_const_44 *lang.Var

var A_arbace_a2g_names_A_const_45 *lang.Var

var A_arbace_a2g_names_A_const_46 *lang.Var

var A_arbace_a2g_names_A_const_47 *lang.Var

var A_arbace_a2g_names_A_const_48 *lang.Var

var A_arbace_a2g_names_A_const_49 *lang.Var

var A_arbace_a2g_names_A_const_50 *lang.Var

var A_arbace_a2g_names_A_const_51 *lang.Var

var A_arbace_a2g_names_A_const_52 *lang.Var

var A_arbace_a2g_names_A_const_53 *lang.Var

var A_arbace_a2g_names_A_init jrt.ClassInit

func A_arbace_a2g_names_A_Init() { if !A_arbace_a2g_names_A_init.Done() { A_arbace_a2g_names_A_init.Run(A_arbace_a2g_names_A_clinit) } }

func A_arbace_a2g_names_A_clinit() { A_arbace_a2g_names_A_clinit_p0(); A_arbace_a2g_names_A_clinit_p1(); A_arbace_a2g_names_A_clinit_p2(); A_arbace_a2g_names_A_clinit_p3(); A_arbace_a2g_names_A_clinit_p4() }

func A_arbace_a2g_names_A_clinit_p0() { A_arbace_a2g_names_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 64); A_arbace_a2g_names_A_const_0 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[10]); A_arbace_a2g_names_A_const_1 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[11]); A_arbace_a2g_names_A_const_2 = A_arbace_a2g_names_A_const_pool.A[12]; A_arbace_a2g_names_A_const_3 = A_arbace_a2g_names_A_const_pool.A[13]; A_arbace_a2g_names_A_const_4 = A_arbace_a2g_names_A_const_pool.A[14]; A_arbace_a2g_names_A_const_5 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[15]); A_arbace_a2g_names_A_const_6 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[16]); A_arbace_a2g_names_A_const_7 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[17]); A_arbace_a2g_names_A_const_8 = A_arbace_a2g_names_A_const_pool.A[18]; A_arbace_a2g_names_A_const_9 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[19]); A_arbace_a2g_names_A_const_10 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[20]); A_arbace_a2g_names_A_const_11 = A_arbace_a2g_names_A_const_pool.A[21] }

func A_arbace_a2g_names_A_clinit_p1() { A_arbace_a2g_names_A_const_12 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[22]); A_arbace_a2g_names_A_const_13 = lang.Keyword_Cast(A_arbace_a2g_names_A_const_pool.A[23]); A_arbace_a2g_names_A_const_14 = lang.Keyword_Cast(A_arbace_a2g_names_A_const_pool.A[24]); A_arbace_a2g_names_A_const_15 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[25]); A_arbace_a2g_names_A_const_16 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[26]); A_arbace_a2g_names_A_const_17 = lang.Keyword_Cast(A_arbace_a2g_names_A_const_pool.A[27]); A_arbace_a2g_names_A_const_18 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[28]); A_arbace_a2g_names_A_const_19 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[29]); A_arbace_a2g_names_A_const_20 = A_arbace_a2g_names_A_const_pool.A[30]; A_arbace_a2g_names_A_const_21 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[31]); A_arbace_a2g_names_A_const_22 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[32]); A_arbace_a2g_names_A_const_23 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[33]) }

func A_arbace_a2g_names_A_clinit_p2() { A_arbace_a2g_names_A_const_24 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[34]); A_arbace_a2g_names_A_const_25 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[35]); A_arbace_a2g_names_A_const_26 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[36]); A_arbace_a2g_names_A_const_27 = A_arbace_a2g_names_A_const_pool.A[37]; A_arbace_a2g_names_A_const_28 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[38]); A_arbace_a2g_names_A_const_29 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[39]); A_arbace_a2g_names_A_const_30 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[40]); A_arbace_a2g_names_A_const_31 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[41]); A_arbace_a2g_names_A_const_32 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[42]); A_arbace_a2g_names_A_const_33 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[43]); A_arbace_a2g_names_A_const_34 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[44]); A_arbace_a2g_names_A_const_35 = A_arbace_a2g_names_A_const_pool.A[45] }

func A_arbace_a2g_names_A_clinit_p3() { A_arbace_a2g_names_A_const_36 = A_arbace_a2g_names_A_const_pool.A[46]; A_arbace_a2g_names_A_const_37 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[47]); A_arbace_a2g_names_A_const_38 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[48]); A_arbace_a2g_names_A_const_39 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[49]); A_arbace_a2g_names_A_const_40 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[50]); A_arbace_a2g_names_A_const_41 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[51]); A_arbace_a2g_names_A_const_42 = A_arbace_a2g_names_A_const_pool.A[52]; A_arbace_a2g_names_A_const_43 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[53]); A_arbace_a2g_names_A_const_44 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[54]); A_arbace_a2g_names_A_const_45 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[55]); A_arbace_a2g_names_A_const_46 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[56]); A_arbace_a2g_names_A_const_47 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[57]) }

func A_arbace_a2g_names_A_clinit_p4() { A_arbace_a2g_names_A_const_48 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[58]); A_arbace_a2g_names_A_const_49 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[59]); A_arbace_a2g_names_A_const_50 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[60]); A_arbace_a2g_names_A_const_51 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[61]); A_arbace_a2g_names_A_const_52 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[62]); A_arbace_a2g_names_A_const_53 = lang.Var_Cast(A_arbace_a2g_names_A_const_pool.A[63]) }

func A_arbace_a2g_names_A_New() *A_arbace_a2g_names_A { A_arbace_a2g_names_A_Init(); t := &A_arbace_a2g_names_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_names_A) Ctor() {}

func (t *A_arbace_a2g_names_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_A_class }

func (t *A_arbace_a2g_names_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_A); return ok }

func A_arbace_a2g_names_A_Cast(x any) *A_arbace_a2g_names_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_A_class)) }; return v }



type A_arbace_a2g_names_capitalize_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_capitalize_A_fn_class *jrt.Class



type A_arbace_a2g_names_compiled_class_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_names_compiled_class_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_names_compiled_pkg_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_names_compiled_pkg_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_names_ctor_base_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_ctor_base_A_fn_class *jrt.Class



type A_arbace_a2g_names_ctor_base_fn__593000044_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_ctor_base_fn__593000044_A_fn_class *jrt.Class



type A_arbace_a2g_names_desc_code_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_desc_code_A_fn_class *jrt.Class



type A_arbace_a2g_names_eval593000004_A struct{ jrt.Object }

func A_arbace_a2g_names_eval593000004_A_New() *A_arbace_a2g_names_eval593000004_A { t := &A_arbace_a2g_names_eval593000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_names_eval593000004_A) Ctor() {}

func (t *A_arbace_a2g_names_eval593000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_eval593000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_eval593000004_A_class }

func (t *A_arbace_a2g_names_eval593000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_eval593000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_eval593000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_eval593000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_eval593000004_A); return ok }

func A_arbace_a2g_names_eval593000004_A_Cast(x any) *A_arbace_a2g_names_eval593000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_eval593000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_eval593000004_A_class)) }; return v }



type A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_fn_class *jrt.Class



type A_arbace_a2g_names_eval593000008_A struct{ jrt.Object }

func A_arbace_a2g_names_eval593000008_A_New() *A_arbace_a2g_names_eval593000008_A { t := &A_arbace_a2g_names_eval593000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_names_eval593000008_A) Ctor() {}

func (t *A_arbace_a2g_names_eval593000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names_eval593000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names_eval593000008_A_class }

func (t *A_arbace_a2g_names_eval593000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names_eval593000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names_eval593000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names_eval593000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names_eval593000008_A); return ok }

func A_arbace_a2g_names_eval593000008_A_Cast(x any) *A_arbace_a2g_names_eval593000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names_eval593000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names_eval593000008_A_class)) }; return v }



type A_arbace_a2g_names_eval593000008_fn__593000009_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_eval593000008_fn__593000009_A_fn_class *jrt.Class



type A_arbace_a2g_names_field_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_field_name_A_fn_class *jrt.Class



type A_arbace_a2g_names_fn__593000021_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_fn__593000021_A_fn_class *jrt.Class



type A_arbace_a2g_names_fn__593000021_fn__593000022_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_fn__593000021_fn__593000022_A_fn_class *jrt.Class



type A_arbace_a2g_names_go_class_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_go_class_name_A_fn_class *jrt.Class



type A_arbace_a2g_names_go_class_name_STAR__STAR__A struct{ a2g_header uint64 }

var A_arbace_a2g_names_go_class_name_STAR__STAR__A_fn_class *jrt.Class



type A_arbace_a2g_names_impl_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_impl_name_A_fn_class *jrt.Class



type A_arbace_a2g_names_local_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_local_name_A_fn_class *jrt.Class



type A_arbace_a2g_names_memo_str_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_memo_str_A_fn_class *jrt.Class



type A_arbace_a2g_names_memo_str_fn__593000018_A struct{ a2g_header uint64; F_cache, F_f any }

var A_arbace_a2g_names_memo_str_fn__593000018_A_fn_class *jrt.Class



type A_arbace_a2g_names_method_base_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_method_base_A_fn_class *jrt.Class



type A_arbace_a2g_names_method_base_STAR__A struct{ a2g_header uint64 }

var A_arbace_a2g_names_method_base_STAR__A_fn_class *jrt.Class



type A_arbace_a2g_names_method_base_STAR__fn__593000037_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_method_base_STAR__fn__593000037_A_fn_class *jrt.Class



type A_arbace_a2g_names_munge_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_munge_name_A_fn_class *jrt.Class



type A_arbace_a2g_names_new_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_new_name_A_fn_class *jrt.Class



type A_arbace_a2g_names_new_name_fn__593000051_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_new_name_fn__593000051_A_fn_class *jrt.Class



type A_arbace_a2g_names_pkg_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_pkg_name_A_fn_class *jrt.Class



type A_arbace_a2g_names_pkg_ns_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_pkg_ns_A_fn_class *jrt.Class



type A_arbace_a2g_names_pkg_of_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_pkg_of_A_fn_class *jrt.Class



type A_arbace_a2g_names_pkg_path_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_pkg_path_A_fn_class *jrt.Class



type A_arbace_a2g_names_static_field_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_static_field_name_A_fn_class *jrt.Class



type A_arbace_a2g_names_static_method_name_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_static_method_name_A_fn_class *jrt.Class



type A_arbace_a2g_names_top_of_A struct{ a2g_header uint64 }

var A_arbace_a2g_names_top_of_A_fn_class *jrt.Class
