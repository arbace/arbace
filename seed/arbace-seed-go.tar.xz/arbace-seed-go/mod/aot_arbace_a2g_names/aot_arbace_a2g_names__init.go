//line aot_arbace_a2g_names__init.ae:1
package aot_arbace_a2g_names

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_names__init_A_Unit0__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_names__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_names__init_A_const_1) }
//line :1:1
func A_arbace_a2g_names__init_A_Unit1__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_names__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_names__init_A_Unit2__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_Init(); tmp2 = A_arbace_a2g_names_eval593000004_loading__1927001464__auto____593000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_names__init_A_Unit3__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_names__init_A_const_1)).Equals_O__Z(A_arbace_a2g_names__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_names_eval593000008_fn__593000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_names_eval593000008_fn__593000009_A_Init(); tmp2 = A_arbace_a2g_names_eval593000008_fn__593000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_names__init_A_Load__O() any { A_arbace_a2g_names__init_A_Init(); A_arbace_a2g_names__init_A_Unit0__O(); A_arbace_a2g_names__init_A_Unit1__O(); A_arbace_a2g_names__init_A_Unit2__O(); A_arbace_a2g_names__init_A_Unit3__O(); A_arbace_a2g_names__init_A_Unit4__O(); A_arbace_a2g_names__init_A_Unit5__O(); A_arbace_a2g_names__init_A_Unit6__O(); A_arbace_a2g_names__init_A_Unit7__O(); A_arbace_a2g_names__init_A_Unit8__O(); A_arbace_a2g_names__init_A_Unit9__O(); A_arbace_a2g_names__init_A_Unit10__O(); A_arbace_a2g_names__init_A_Unit11__O(); A_arbace_a2g_names__init_A_Unit12__O(); A_arbace_a2g_names__init_A_Unit13__O(); A_arbace_a2g_names__init_A_Unit14__O(); A_arbace_a2g_names__init_A_Unit15__O(); A_arbace_a2g_names__init_A_Unit16__O(); A_arbace_a2g_names__init_A_Unit17__O(); A_arbace_a2g_names__init_A_Unit18__O(); A_arbace_a2g_names__init_A_Unit19__O(); A_arbace_a2g_names__init_A_Unit20__O(); A_arbace_a2g_names__init_A_Unit21__O(); A_arbace_a2g_names__init_A_Unit22__O(); A_arbace_a2g_names__init_A_Unit23__O(); A_arbace_a2g_names__init_A_Unit24__O(); A_arbace_a2g_names__init_A_Unit25__O(); A_arbace_a2g_names__init_A_Unit26__O(); A_arbace_a2g_names__init_A_Unit27__O(); return nil }





func A_arbace_a2g_names__init_A_Unit4__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_a2g_names__init_A_const_5).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp1).BindRoot_O__V(tmp2.Invoke_O__O(tmp3.Ref())); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_6)); return A_arbace_a2g_names__init_A_const_4.Ref() }





func A_arbace_a2g_names__init_A_Unit5__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_7; var tmp2 any = A_arbace_a2g_names_top_of_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_top_of_A_Init(); tmp3 = A_arbace_a2g_names_top_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_7; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_8)); return A_arbace_a2g_names__init_A_const_7.Ref() }

func A_arbace_a2g_names__init_A_Unit6__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_9; var tmp2 any = A_arbace_a2g_names_pkg_of_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_pkg_of_A_Init(); tmp3 = A_arbace_a2g_names_pkg_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_10)); return A_arbace_a2g_names__init_A_const_9.Ref() }










func A_arbace_a2g_names__init_A_Unit7__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_11; var tmp2 any = A_arbace_a2g_names_compiled_pkg_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_compiled_pkg_QMARK__A_Init(); tmp3 = A_arbace_a2g_names_compiled_pkg_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_12)); return A_arbace_a2g_names__init_A_const_11.Ref() }

func A_arbace_a2g_names__init_A_Unit8__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_13; var tmp2 any = A_arbace_a2g_names_pkg_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_pkg_name_A_Init(); tmp3 = A_arbace_a2g_names_pkg_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_14)); return A_arbace_a2g_names__init_A_const_13.Ref() }
func A_arbace_a2g_names__init_A_Unit9__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_15; var tmp2 any = A_arbace_a2g_names_pkg_path_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_pkg_path_A_Init(); tmp3 = A_arbace_a2g_names_pkg_path_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_16)); return A_arbace_a2g_names__init_A_const_15.Ref() }
func A_arbace_a2g_names__init_A_Unit10__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_17; var tmp2 any = A_arbace_a2g_names_pkg_ns_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_pkg_ns_A_Init(); tmp3 = A_arbace_a2g_names_pkg_ns_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_18)); return A_arbace_a2g_names__init_A_const_17.Ref() }




func A_arbace_a2g_names__init_A_Unit11__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); jrt.NN(A_arbace_a2g_names__init_A_const_19).BindRoot_O__V(A_arbace_a2g_names__init_A_const_20); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_19; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_21)); return A_arbace_a2g_names__init_A_const_19.Ref() }




func A_arbace_a2g_names__init_A_Unit12__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); jrt.NN(A_arbace_a2g_names__init_A_const_22).BindRoot_O__V(A_arbace_a2g_names__init_A_const_23); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_22; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_24)); return A_arbace_a2g_names__init_A_const_22.Ref() }





func A_arbace_a2g_names__init_A_Unit13__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(50, 1); jrt.NN(A_arbace_a2g_names__init_A_const_25).BindRoot_O__V(A_arbace_a2g_names__init_A_const_26); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_25; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_27)); return A_arbace_a2g_names__init_A_const_25.Ref() }



func A_arbace_a2g_names__init_A_Unit14__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(54, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_28; var tmp2 any = A_arbace_a2g_names_munge_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_munge_name_A_Init(); tmp3 = A_arbace_a2g_names_munge_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_29)); return A_arbace_a2g_names__init_A_const_28.Ref() }







func A_arbace_a2g_names__init_A_Unit15__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_30; var tmp2 any = A_arbace_a2g_names_local_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_local_name_A_Init(); tmp3 = A_arbace_a2g_names_local_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_31)); return A_arbace_a2g_names__init_A_const_30.Ref() }















func A_arbace_a2g_names__init_A_Unit16__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); jrt.NN(A_arbace_a2g_names__init_A_const_32).BindRoot_O__V(A_arbace_a2g_names__init_A_const_33); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_32; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_34)); return A_arbace_a2g_names__init_A_const_32.Ref() }































func A_arbace_a2g_names__init_A_Unit17__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(110, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_35; var tmp2 any = A_arbace_a2g_names_compiled_class_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_compiled_class_QMARK__A_Init(); tmp3 = A_arbace_a2g_names_compiled_class_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_36)); return A_arbace_a2g_names__init_A_const_35.Ref() }






func A_arbace_a2g_names__init_A_Unit18__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(117, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_37; var tmp2 any = A_arbace_a2g_names_go_class_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_go_class_name_A_Init(); tmp3 = A_arbace_a2g_names_go_class_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_38)); return A_arbace_a2g_names__init_A_const_37.Ref() }















func A_arbace_a2g_names__init_A_Unit19__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(133, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_39; var tmp2 any = A_arbace_a2g_names_capitalize_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_capitalize_A_Init(); tmp3 = A_arbace_a2g_names_capitalize_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_40)); return A_arbace_a2g_names__init_A_const_39.Ref() }





func A_arbace_a2g_names__init_A_Unit20__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(139, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_41; var tmp2 any = A_arbace_a2g_names_desc_code_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_desc_code_A_Init(); tmp3 = A_arbace_a2g_names_desc_code_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_42)); return A_arbace_a2g_names__init_A_const_41.Ref() }










func A_arbace_a2g_names__init_A_Unit21__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(150, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_43; var tmp2 any = A_arbace_a2g_names_method_base_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_method_base_A_Init(); tmp3 = A_arbace_a2g_names_method_base_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_44)); return A_arbace_a2g_names__init_A_const_43.Ref() }







func A_arbace_a2g_names__init_A_Unit22__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_45; var tmp2 any = A_arbace_a2g_names_ctor_base_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_ctor_base_A_Init(); tmp3 = A_arbace_a2g_names_ctor_base_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_46)); return A_arbace_a2g_names__init_A_const_45.Ref() }






func A_arbace_a2g_names__init_A_Unit23__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(165, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_47; var tmp2 any = A_arbace_a2g_names_new_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_new_name_A_Init(); tmp3 = A_arbace_a2g_names_new_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_47; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_48)); return A_arbace_a2g_names__init_A_const_47.Ref() }





func A_arbace_a2g_names__init_A_Unit24__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(171, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_49; var tmp2 any = A_arbace_a2g_names_field_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_field_name_A_Init(); tmp3 = A_arbace_a2g_names_field_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_49; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_50)); return A_arbace_a2g_names__init_A_const_49.Ref() }

func A_arbace_a2g_names__init_A_Unit25__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_51; var tmp2 any = A_arbace_a2g_names_static_field_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_static_field_name_A_Init(); tmp3 = A_arbace_a2g_names_static_field_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_51; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_52)); return A_arbace_a2g_names__init_A_const_51.Ref() }

func A_arbace_a2g_names__init_A_Unit26__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(175, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_53; var tmp2 any = A_arbace_a2g_names_static_method_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_static_method_name_A_Init(); tmp3 = A_arbace_a2g_names_static_method_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_53; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_54)); return A_arbace_a2g_names__init_A_const_53.Ref() }

func A_arbace_a2g_names__init_A_Unit27__O() any { A_arbace_a2g_names__init_A_Init(); lang.Compiler_AOT_At_I_I__V(177, 1); var tmp1 *lang.Var = A_arbace_a2g_names__init_A_const_55; var tmp2 any = A_arbace_a2g_names_impl_name_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_names_impl_name_A_Init(); tmp3 = A_arbace_a2g_names_impl_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_names__init_A_const_55; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_names__init_A_const_56)); return A_arbace_a2g_names__init_A_const_55.Ref() }



type A_arbace_a2g_names__init_A struct{ jrt.Object }

var A_arbace_a2g_names__init_A_const_0 *lang.Var

var A_arbace_a2g_names__init_A_const_1 any

var A_arbace_a2g_names__init_A_const_2 any

var A_arbace_a2g_names__init_A_const_3 any

var A_arbace_a2g_names__init_A_const_4 *lang.Var

var A_arbace_a2g_names__init_A_const_5 *lang.Var

var A_arbace_a2g_names__init_A_const_6 any

var A_arbace_a2g_names__init_A_const_7 *lang.Var

var A_arbace_a2g_names__init_A_const_8 any

var A_arbace_a2g_names__init_A_const_9 *lang.Var

var A_arbace_a2g_names__init_A_const_10 any

var A_arbace_a2g_names__init_A_const_11 *lang.Var

var A_arbace_a2g_names__init_A_const_12 any

var A_arbace_a2g_names__init_A_const_13 *lang.Var

var A_arbace_a2g_names__init_A_const_14 any

var A_arbace_a2g_names__init_A_const_15 *lang.Var

var A_arbace_a2g_names__init_A_const_16 any

var A_arbace_a2g_names__init_A_const_17 *lang.Var

var A_arbace_a2g_names__init_A_const_18 any

var A_arbace_a2g_names__init_A_const_19 *lang.Var

var A_arbace_a2g_names__init_A_const_20 any

var A_arbace_a2g_names__init_A_const_21 any

var A_arbace_a2g_names__init_A_const_22 *lang.Var

var A_arbace_a2g_names__init_A_const_23 any

var A_arbace_a2g_names__init_A_const_24 any

var A_arbace_a2g_names__init_A_const_25 *lang.Var

var A_arbace_a2g_names__init_A_const_26 any

var A_arbace_a2g_names__init_A_const_27 any

var A_arbace_a2g_names__init_A_const_28 *lang.Var

var A_arbace_a2g_names__init_A_const_29 any

var A_arbace_a2g_names__init_A_const_30 *lang.Var

var A_arbace_a2g_names__init_A_const_31 any

var A_arbace_a2g_names__init_A_const_32 *lang.Var

var A_arbace_a2g_names__init_A_const_33 any

var A_arbace_a2g_names__init_A_const_34 any

var A_arbace_a2g_names__init_A_const_35 *lang.Var

var A_arbace_a2g_names__init_A_const_36 any

var A_arbace_a2g_names__init_A_const_37 *lang.Var

var A_arbace_a2g_names__init_A_const_38 any

var A_arbace_a2g_names__init_A_const_39 *lang.Var

var A_arbace_a2g_names__init_A_const_40 any

var A_arbace_a2g_names__init_A_const_41 *lang.Var

var A_arbace_a2g_names__init_A_const_42 any

var A_arbace_a2g_names__init_A_const_43 *lang.Var

var A_arbace_a2g_names__init_A_const_44 any

var A_arbace_a2g_names__init_A_const_45 *lang.Var

var A_arbace_a2g_names__init_A_const_46 any

var A_arbace_a2g_names__init_A_const_47 *lang.Var

var A_arbace_a2g_names__init_A_const_48 any

var A_arbace_a2g_names__init_A_const_49 *lang.Var

var A_arbace_a2g_names__init_A_const_50 any

var A_arbace_a2g_names__init_A_const_51 *lang.Var

var A_arbace_a2g_names__init_A_const_52 any

var A_arbace_a2g_names__init_A_const_53 *lang.Var

var A_arbace_a2g_names__init_A_const_54 any

var A_arbace_a2g_names__init_A_const_55 *lang.Var

var A_arbace_a2g_names__init_A_const_56 any

var A_arbace_a2g_names__init_A_init jrt.ClassInit

func A_arbace_a2g_names__init_A_Init() { if !A_arbace_a2g_names__init_A_init.Done() { A_arbace_a2g_names__init_A_init.Run(A_arbace_a2g_names__init_A_clinit) } }

func A_arbace_a2g_names__init_A_clinit() { A_arbace_a2g_names__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_99); A_arbace_a2g_names__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_a2g_names__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_a2g_names__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_names__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_22); A_arbace_a2g_names__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_a2g_names__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(11).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_105)); A_arbace_a2g_names__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_11, Lit_19); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_106).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_names__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_108)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_110).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_11, Lit_111); A_arbace_a2g_names__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_113, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_11, Lit_114); A_arbace_a2g_names__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_11, Lit_116); A_arbace_a2g_names__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_11, Lit_117); A_arbace_a2g_names__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_11, Lit_118); A_arbace_a2g_names__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_11, Lit_31); A_arbace_a2g_names__init_A_const_20 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,25,s4:elses4:funcs3:maps5:ranges4:chans7:packages9:interfaces5:defers3:vars6:returns3:fors11:fallthroughs2:ifs6:imports2:gos6:switchs5:consts6:selects4:cases5:breaks8:continues4:types6:structs7:defaults4:goto", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_a2g_names__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_11, Lit_32); A_arbace_a2g_names__init_A_const_23 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,44,s5:int16s7:recovers3:ints3:mins5:panics10:comparables6:strings4:runes7:float32s4:copys7:float64s4:uints5:int32s6:uint16s6:deletes7:uintptrs6:uint32s5:int64s4:iotas3:maxs3:news5:errors4:imags10:complex128s3:anys5:falses4:reals6:uint64s4:makes7:printlns4:bools5:uint8s4:trues5:closes4:int8s6:appends5:prints3:lens5:clears3:nils3:caps7:complexs9:complex64s4:byte", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_a2g_names__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_11, Lit_33); A_arbace_a2g_names__init_A_const_26 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,12,s4:langs4:thiss2:rvs3:jrts7:reflects6:unsafes3:excs4:maths3:ctls1:_s1:ts6:atomic", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_a2g_names__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(50).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_119)); A_arbace_a2g_names__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_11, Lit_29); A_arbace_a2g_names__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_120).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_121, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(54).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_11, Lit_122); A_arbace_a2g_names__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_124, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_11, Lit_37); A_arbace_a2g_names__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.ConstRefArray("[0,26,s20:java/text/Annotations15:Text_Annotations32:sun/net/www/protocol/jar/Handlers11:Jar_Handlers19:sun/text/Normalizers14:Sun_Normalizers34:sun/net/www/protocol/https/Handlers13:Https_Handlers34:sun/security/provider/SecureRandoms16:Sun_SecureRandoms14:java/net/Proxys9:Net_Proxys21:sun/util/calendar/Eras12:Calendar_Eras25:java/util/stream/Tripwires15:Stream_Tripwires13:java/sql/Dates8:Sql_Dates25:sun/net/www/URLConnections17:Www_URLConnections33:sun/net/www/protocol/http/Handlers12:Http_Handlers33:sun/net/www/protocol/file/Handlers12:File_Handlers27:jdk/internal/util/ByteArrays13:Jdk_ByteArray", []*jrt.Class{jrt.Object_class})); A_arbace_a2g_names__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(78).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_125)); A_arbace_a2g_names__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_11, Lit_38); A_arbace_a2g_names__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_110).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_126, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(110).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_11, Lit_45); A_arbace_a2g_names__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_127, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(117).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_11, Lit_48); A_arbace_a2g_names__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_120)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_109).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_110).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(133).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); A_arbace_a2g_names__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_128).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_129, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(139).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_11, Lit_49); A_arbace_a2g_names__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_131, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(150).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_11, Lit_132); A_arbace_a2g_names__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_133, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(158).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_11, Lit_134); A_arbace_a2g_names__init_A_const_48 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_136, lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(165).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_49 = lang.RT_Var_String_String__Var(Lit_11, Lit_137); A_arbace_a2g_names__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_138).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(171).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_11, Lit_139); A_arbace_a2g_names__init_A_const_52 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_138).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(173).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_53 = lang.RT_Var_String_String__Var(Lit_11, Lit_140); A_arbace_a2g_names__init_A_const_54 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_24).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(175).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)); A_arbace_a2g_names__init_A_const_55 = lang.RT_Var_String_String__Var(Lit_11, Lit_141); A_arbace_a2g_names__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_107).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_142).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_101).Ref(), jrt.Integer_ValueOf_I__Integer(177).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_102).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), Lit_104)) }

func A_arbace_a2g_names__init_A_New() *A_arbace_a2g_names__init_A { A_arbace_a2g_names__init_A_Init(); t := &A_arbace_a2g_names__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_names__init_A) Ctor() {}

func (t *A_arbace_a2g_names__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_names__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_names__init_A_class }

func (t *A_arbace_a2g_names__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_names__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_names__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_names__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_names__init_A); return ok }

func A_arbace_a2g_names__init_A_Cast(x any) *A_arbace_a2g_names__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_names__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_names__init_A_class)) }; return v }
