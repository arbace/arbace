//line aot_arbace_j2g_main__init.ae:1
package aot_arbace_j2g_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_main__init_A_Unit0__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_main__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_main__init_A_const_1) }
//line :1:1
func A_arbace_j2g_main__init_A_Unit1__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_main__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_main__init_A_Unit2__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_main_eval798000004_loading__1927001464__auto____798000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_main_eval798000004_loading__1927001464__auto____798000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_543, false, nil); A_arbace_j2g_main_eval798000004_loading__1927001464__auto____798000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_main__init_A_Unit3__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_main__init_A_const_1)).Equals_O__Z(A_arbace_j2g_main__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_main_eval798000008_fn__798000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_main_eval798000008_fn__798000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_544, false, nil); A_arbace_j2g_main_eval798000008_fn__798000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_j2g_main__init_A_Load__O() any { A_arbace_j2g_main__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_main__init_A_Unit0__O(); A_arbace_j2g_main__init_A_Unit1__O(); A_arbace_j2g_main__init_A_Unit2__O(); A_arbace_j2g_main__init_A_Unit3__O(); A_arbace_j2g_main__init_A_Unit4__O(); A_arbace_j2g_main__init_A_Unit5__O(); A_arbace_j2g_main__init_A_Unit6__O(); A_arbace_j2g_main__init_A_Unit7__O(); A_arbace_j2g_main__init_A_Unit8__O(); A_arbace_j2g_main__init_A_Unit9__O(); A_arbace_j2g_main__init_A_Unit10__O(); A_arbace_j2g_main__init_A_Unit11__O(); A_arbace_j2g_main__init_A_Unit12__O(); A_arbace_j2g_main__init_A_Unit13__O(); A_arbace_j2g_main__init_A_Unit14__O(); A_arbace_j2g_main__init_A_Unit15__O(); A_arbace_j2g_main__init_A_Unit16__O(); A_arbace_j2g_main__init_A_Unit17__O(); A_arbace_j2g_main__init_A_Unit18__O(); A_arbace_j2g_main__init_A_Unit19__O(); A_arbace_j2g_main__init_A_Unit20__O(); A_arbace_j2g_main__init_A_Unit21__O(); A_arbace_j2g_main__init_A_Unit22__O(); A_arbace_j2g_main__init_A_Unit23__O(); A_arbace_j2g_main__init_A_Unit24__O(); A_arbace_j2g_main__init_A_Unit25__O(); A_arbace_j2g_main__init_A_Unit26__O(); A_arbace_j2g_main__init_A_Unit27__O(); A_arbace_j2g_main__init_A_Unit28__O(); A_arbace_j2g_main__init_A_Unit29__O(); A_arbace_j2g_main__init_A_Unit30__O(); A_arbace_j2g_main__init_A_Unit31__O(); A_arbace_j2g_main__init_A_Unit32__O(); A_arbace_j2g_main__init_A_Unit33__O(); A_arbace_j2g_main__init_A_Unit34__O(); A_arbace_j2g_main__init_A_Unit35__O(); A_arbace_j2g_main__init_A_Unit36__O(); A_arbace_j2g_main__init_A_Unit37__O(); A_arbace_j2g_main__init_A_Unit38__O(); A_arbace_j2g_main__init_A_Unit39__O(); A_arbace_j2g_main__init_A_Unit40__O(); A_arbace_j2g_main__init_A_Unit41__O(); A_arbace_j2g_main__init_A_Unit42__O(); A_arbace_j2g_main__init_A_Unit43__O(); A_arbace_j2g_main__init_A_Unit44__O(); A_arbace_j2g_main__init_A_Unit45__O(); A_arbace_j2g_main__init_A_Unit46__O(); A_arbace_j2g_main__init_A_Unit47__O(); A_arbace_j2g_main__init_A_Unit48__O(); A_arbace_j2g_main__init_A_Unit49__O(); A_arbace_j2g_main__init_A_Unit50__O(); A_arbace_j2g_main__init_A_Unit51__O(); return nil }























































































func A_arbace_j2g_main__init_A_Unit4__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_main_now_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_main_now_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_545, false, nil); A_arbace_j2g_main_now_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_5)); return A_arbace_j2g_main__init_A_const_4 }
func A_arbace_j2g_main__init_A_Unit5__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_main_secs_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_main_secs_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_546, false, nil); A_arbace_j2g_main_secs_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_7)); return A_arbace_j2g_main__init_A_const_6 }

func A_arbace_j2g_main__init_A_Unit6__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_main_parse_args_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_main_parse_args_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_547, false, nil); A_arbace_j2g_main_parse_args_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_9)); return A_arbace_j2g_main__init_A_const_8 }














































func A_arbace_j2g_main__init_A_Unit7__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_main_internal_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_main_internal_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_548, false, nil); A_arbace_j2g_main_internal_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_11)); return A_arbace_j2g_main__init_A_const_10 }

func A_arbace_j2g_main__init_A_Unit8__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(145, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_main_manifest_classes_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_main_manifest_classes_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_549, false, nil); A_arbace_j2g_main_manifest_classes_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_13)); return A_arbace_j2g_main__init_A_const_12 }







func A_arbace_j2g_main__init_A_Unit9__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(153, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_main_jrt_classes_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_main_jrt_classes_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_550, false, nil); A_arbace_j2g_main_jrt_classes_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_15)); return A_arbace_j2g_main__init_A_const_14 }







func A_arbace_j2g_main__init_A_Unit10__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); A_arbace_j2g_main__init_A_const_16.BindRoot_O__V(Lit_551); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_17)); return A_arbace_j2g_main__init_A_const_16 }

func A_arbace_j2g_main__init_A_Unit11__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(163, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_main_fn__798000058_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_main_fn__798000058_A_fn_class; if



	fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_552, false, nil); A_arbace_j2g_main_fn__798000058_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); /*line :163:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_19)); return A_arbace_j2g_main__init_A_const_18 }










func A_arbace_j2g_main__init_A_Unit12__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_main_repl_visible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_main_repl_visible_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_553, false, nil); A_arbace_j2g_main_repl_visible_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_21)); return A_arbace_j2g_main__init_A_const_20 }

















func A_arbace_j2g_main__init_A_Unit13__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_main_bundle_roots_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_main_bundle_roots_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_554, false, nil); A_arbace_j2g_main_bundle_roots_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_23)); return A_arbace_j2g_main__init_A_const_22 }
















func A_arbace_j2g_main__init_A_Unit14__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_main_root_keys_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_main_root_keys_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_555, false, nil); A_arbace_j2g_main_root_keys_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_25)); return A_arbace_j2g_main__init_A_const_24 }






















func A_arbace_j2g_main__init_A_Unit15__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); A_arbace_j2g_main__init_A_const_26.BindRoot_O__V(A_arbace_j2g_main__init_A_const_27); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_28)); return A_arbace_j2g_main__init_A_const_26 }






func A_arbace_j2g_main__init_A_Unit16__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(239, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_main_standin_roots_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_main_standin_roots_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_556, false, nil); A_arbace_j2g_main_standin_roots_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_30)); return A_arbace_j2g_main__init_A_const_29 }























func A_arbace_j2g_main__init_A_Unit17__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(263, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_j2g_main_form_names_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_main_form_names_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_557, false, nil); A_arbace_j2g_main_form_names_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_32)); return A_arbace_j2g_main__init_A_const_31 }










func A_arbace_j2g_main__init_A_Unit18__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_main_method_recv_type_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_main_method_recv_type_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_558, false, nil); A_arbace_j2g_main_method_recv_type_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_34)); return A_arbace_j2g_main__init_A_const_33 }







func A_arbace_j2g_main__init_A_Unit19__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(282, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_main_mentions_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_main_mentions_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_559, false, nil); A_arbace_j2g_main_mentions_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_36)); return A_arbace_j2g_main__init_A_const_35 }








func A_arbace_j2g_main__init_A_Unit20__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(291, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_main_filter_init_body_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_main_filter_init_body_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_560, false, nil); A_arbace_j2g_main_filter_init_body_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_38)); return A_arbace_j2g_main__init_A_const_37 }



func A_arbace_j2g_main__init_A_Unit21__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_j2g_main_filter_standins_STAR__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_main_filter_standins_STAR__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_561, false, nil); A_arbace_j2g_main_filter_standins_STAR__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_40)); return A_arbace_j2g_main__init_A_const_39 }






























func A_arbace_j2g_main__init_A_Unit22__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_j2g_main_write_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_main_write_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_562, false, nil); A_arbace_j2g_main_write_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_42)); return A_arbace_j2g_main__init_A_const_41 }



func A_arbace_j2g_main__init_A_Unit23__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_j2g_main_copy_file_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_main_copy_file_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_563, false, nil); A_arbace_j2g_main_copy_file_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_44)); return A_arbace_j2g_main__init_A_const_43 }



func A_arbace_j2g_main__init_A_Unit24__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_j2g_main_resource_file_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_main_resource_file_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_564, false, nil); A_arbace_j2g_main_resource_file_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_46)); return A_arbace_j2g_main__init_A_const_45 }







func A_arbace_j2g_main__init_A_Unit25__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(342, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_j2g_main_write_resources_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_main_write_resources_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_565, false, nil); A_arbace_j2g_main_write_resources_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_48)); return A_arbace_j2g_main__init_A_const_47 }











func A_arbace_j2g_main__init_A_Unit26__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(354, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_j2g_main_top_of_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_main_top_of_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_566, false, nil); A_arbace_j2g_main_top_of_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_50)); return A_arbace_j2g_main__init_A_const_49 }

func A_arbace_j2g_main__init_A_Unit27__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(356, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_j2g_main_program_package_forms_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_main_program_package_forms_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_567, false, nil); A_arbace_j2g_main_program_package_forms_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_52)); return A_arbace_j2g_main__init_A_const_51 }











func A_arbace_j2g_main__init_A_Unit28__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(368, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_j2g_main_property_forms_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_main_property_forms_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_568, false, nil); A_arbace_j2g_main_property_forms_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_54)); return A_arbace_j2g_main__init_A_const_53 }







func A_arbace_j2g_main__init_A_Unit29__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(376, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_j2g_main_program_entry_main_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_main_program_entry_main_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_569, false, nil); A_arbace_j2g_main_program_entry_main_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_56)); return A_arbace_j2g_main__init_A_const_55 }






























func A_arbace_j2g_main__init_A_Unit30__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(407, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_57; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__54 any = A_arbace_j2g_main_program_main_forms_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_main_program_main_forms_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_570, true, nil); A_arbace_j2g_main_program_main_forms_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__54, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_58)); return A_arbace_j2g_main__init_A_const_57 }













































func A_arbace_j2g_main__init_A_Unit31__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(453, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_j2g_main_source_top_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_main_source_top_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_571, false, nil); A_arbace_j2g_main_source_top_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_60)); return A_arbace_j2g_main__init_A_const_59 }












func A_arbace_j2g_main__init_A_Unit32__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(466, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_j2g_main_apart_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_main_apart_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_572, false, nil); A_arbace_j2g_main_apart_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_62)); return A_arbace_j2g_main__init_A_const_61 }

























func A_arbace_j2g_main__init_A_Unit33__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(492, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_j2g_main_merge_apart_BANG__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_main_merge_apart_BANG__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_573, false, nil); A_arbace_j2g_main_merge_apart_BANG__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_64)); return A_arbace_j2g_main__init_A_const_63 }























func A_arbace_j2g_main__init_A_Unit34__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(516, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_j2g_main_translate_classes_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_j2g_main_translate_classes_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_574, false, nil); A_arbace_j2g_main_translate_classes_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_66)); return A_arbace_j2g_main__init_A_const_65 }

























func A_arbace_j2g_main__init_A_Unit35__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(542, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_j2g_main_merge_registrations_BANG__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_main_merge_registrations_BANG__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_575, false, nil); A_arbace_j2g_main_merge_registrations_BANG__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_68)); return A_arbace_j2g_main__init_A_const_67 }





func A_arbace_j2g_main__init_A_Unit36__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(548, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_j2g_main_registration_forms_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_main_registration_forms_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_576, false, nil); A_arbace_j2g_main_registration_forms_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_70)); return A_arbace_j2g_main__init_A_const_69 }















func A_arbace_j2g_main__init_A_Unit37__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(564, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_j2g_main_registrations_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_j2g_main_registrations_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_577, false, nil); A_arbace_j2g_main_registrations_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_72)); return A_arbace_j2g_main__init_A_const_71 }













func A_arbace_j2g_main__init_A_Unit38__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(578, 1); A_arbace_j2g_main__init_A_const_73.BindRoot_O__V(Lit_578); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_73; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_74)); return A_arbace_j2g_main__init_A_const_73 }

func A_arbace_j2g_main__init_A_Unit39__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(580, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_j2g_main_report_str_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_main_report_str_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_579, false, nil); A_arbace_j2g_main_report_str_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_76)); return A_arbace_j2g_main__init_A_const_75 }













func A_arbace_j2g_main__init_A_Unit40__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(594, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_j2g_main_world_scan_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_main_world_scan_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_580, false, nil); A_arbace_j2g_main_world_scan_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_78)); return A_arbace_j2g_main__init_A_const_77 }





































































func A_arbace_j2g_main__init_A_Unit41__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(664, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_79; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_80)); return A_arbace_j2g_main__init_A_const_79 }

func A_arbace_j2g_main__init_A_Unit42__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(666, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_j2g_main_meta_roots_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_main_meta_roots_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_581, false, nil); A_arbace_j2g_main_meta_roots_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_82)); return A_arbace_j2g_main__init_A_const_81 }






















func A_arbace_j2g_main__init_A_Unit43__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(689, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_j2g_main_analysis_report_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_j2g_main_analysis_report_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_582, false, nil); A_arbace_j2g_main_analysis_report_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_84)); return A_arbace_j2g_main__init_A_const_83 }


























































func A_arbace_j2g_main__init_A_Unit44__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(748, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_j2g_main_program_meta_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_j2g_main_program_meta_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_583, false, nil); A_arbace_j2g_main_program_meta_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_86)); return A_arbace_j2g_main__init_A_const_85 }
















func A_arbace_j2g_main__init_A_Unit45__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(765, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_j2g_main_write_meta_resources_BANG__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_main_write_meta_resources_BANG__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_584, false, nil); A_arbace_j2g_main_write_meta_resources_BANG__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_88)); return A_arbace_j2g_main__init_A_const_87 }






















func A_arbace_j2g_main__init_A_Unit46__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(788, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_j2g_main_meta_report_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_j2g_main_meta_report_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_585, false, nil); A_arbace_j2g_main_meta_report_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_89)); return A_arbace_j2g_main__init_A_const_79 }










func A_arbace_j2g_main__init_A_Unit47__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(799, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_j2g_main_run_STAR__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_j2g_main_run_STAR__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_586, false, nil); A_arbace_j2g_main_run_STAR__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_91)); return A_arbace_j2g_main__init_A_const_90 }
































































































































































































































































































































































































































































































































































































func A_arbace_j2g_main__init_A_Unit48__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1376, 1); A_arbace_j2g_main__init_A_const_92.BindRoot_O__V(A_arbace_j2g_main__init_A_const_93); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_92; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_94)); return A_arbace_j2g_main__init_A_const_92 }








func A_arbace_j2g_main__init_A_Unit49__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1385, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_j2g_main_advance_ids_BANG__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_main_advance_ids_BANG__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_587, false, nil); A_arbace_j2g_main_advance_ids_BANG__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_96)); return A_arbace_j2g_main__init_A_const_95 }








func A_arbace_j2g_main__init_A_Unit50__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1394, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_j2g_main_run_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_j2g_main_run_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_588, false, nil); A_arbace_j2g_main_run_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_98)); return A_arbace_j2g_main__init_A_const_97 }


































func A_arbace_j2g_main__init_A_Unit51__O() any { A_arbace_j2g_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1429, 1); var tmp1 *lang.Var = A_arbace_j2g_main__init_A_const_99; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__90 any = A_arbace_j2g_main__main_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_main__main_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_589, true, nil); A_arbace_j2g_main__main_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__90, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_main__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_main__init_A_const_100)); return A_arbace_j2g_main__init_A_const_99 }



type A_arbace_j2g_main__init_A struct{ jrt.Object }

var A_arbace_j2g_main__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_main__init_A_const_0 *lang.Var

var A_arbace_j2g_main__init_A_const_1 any

var A_arbace_j2g_main__init_A_const_2 any

var A_arbace_j2g_main__init_A_const_3 any

var A_arbace_j2g_main__init_A_const_4 *lang.Var

var A_arbace_j2g_main__init_A_const_5 any

var A_arbace_j2g_main__init_A_const_6 *lang.Var

var A_arbace_j2g_main__init_A_const_7 any

var A_arbace_j2g_main__init_A_const_8 *lang.Var

var A_arbace_j2g_main__init_A_const_9 any

var A_arbace_j2g_main__init_A_const_10 *lang.Var

var A_arbace_j2g_main__init_A_const_11 any

var A_arbace_j2g_main__init_A_const_12 *lang.Var

var A_arbace_j2g_main__init_A_const_13 any

var A_arbace_j2g_main__init_A_const_14 *lang.Var

var A_arbace_j2g_main__init_A_const_15 any

var A_arbace_j2g_main__init_A_const_16 *lang.Var

var A_arbace_j2g_main__init_A_const_17 any

var A_arbace_j2g_main__init_A_const_18 *lang.Var

var A_arbace_j2g_main__init_A_const_19 any

var A_arbace_j2g_main__init_A_const_20 *lang.Var

var A_arbace_j2g_main__init_A_const_21 any

var A_arbace_j2g_main__init_A_const_22 *lang.Var

var A_arbace_j2g_main__init_A_const_23 any

var A_arbace_j2g_main__init_A_const_24 *lang.Var

var A_arbace_j2g_main__init_A_const_25 any

var A_arbace_j2g_main__init_A_const_26 *lang.Var

var A_arbace_j2g_main__init_A_const_27 any

var A_arbace_j2g_main__init_A_const_28 any

var A_arbace_j2g_main__init_A_const_29 *lang.Var

var A_arbace_j2g_main__init_A_const_30 any

var A_arbace_j2g_main__init_A_const_31 *lang.Var

var A_arbace_j2g_main__init_A_const_32 any

var A_arbace_j2g_main__init_A_const_33 *lang.Var

var A_arbace_j2g_main__init_A_const_34 any

var A_arbace_j2g_main__init_A_const_35 *lang.Var

var A_arbace_j2g_main__init_A_const_36 any

var A_arbace_j2g_main__init_A_const_37 *lang.Var

var A_arbace_j2g_main__init_A_const_38 any

var A_arbace_j2g_main__init_A_const_39 *lang.Var

var A_arbace_j2g_main__init_A_const_40 any

var A_arbace_j2g_main__init_A_const_41 *lang.Var

var A_arbace_j2g_main__init_A_const_42 any

var A_arbace_j2g_main__init_A_const_43 *lang.Var

var A_arbace_j2g_main__init_A_const_44 any

var A_arbace_j2g_main__init_A_const_45 *lang.Var

var A_arbace_j2g_main__init_A_const_46 any

var A_arbace_j2g_main__init_A_const_47 *lang.Var

var A_arbace_j2g_main__init_A_const_48 any

var A_arbace_j2g_main__init_A_const_49 *lang.Var

var A_arbace_j2g_main__init_A_const_50 any

var A_arbace_j2g_main__init_A_const_51 *lang.Var

var A_arbace_j2g_main__init_A_const_52 any

var A_arbace_j2g_main__init_A_const_53 *lang.Var

var A_arbace_j2g_main__init_A_const_54 any

var A_arbace_j2g_main__init_A_const_55 *lang.Var

var A_arbace_j2g_main__init_A_const_56 any

var A_arbace_j2g_main__init_A_const_57 *lang.Var

var A_arbace_j2g_main__init_A_const_58 any

var A_arbace_j2g_main__init_A_const_59 *lang.Var

var A_arbace_j2g_main__init_A_const_60 any

var A_arbace_j2g_main__init_A_const_61 *lang.Var

var A_arbace_j2g_main__init_A_const_62 any

var A_arbace_j2g_main__init_A_const_63 *lang.Var

var A_arbace_j2g_main__init_A_const_64 any

var A_arbace_j2g_main__init_A_const_65 *lang.Var

var A_arbace_j2g_main__init_A_const_66 any

var A_arbace_j2g_main__init_A_const_67 *lang.Var

var A_arbace_j2g_main__init_A_const_68 any

var A_arbace_j2g_main__init_A_const_69 *lang.Var

var A_arbace_j2g_main__init_A_const_70 any

var A_arbace_j2g_main__init_A_const_71 *lang.Var

var A_arbace_j2g_main__init_A_const_72 any

var A_arbace_j2g_main__init_A_const_73 *lang.Var

var A_arbace_j2g_main__init_A_const_74 any

var A_arbace_j2g_main__init_A_const_75 *lang.Var

var A_arbace_j2g_main__init_A_const_76 any

var A_arbace_j2g_main__init_A_const_77 *lang.Var

var A_arbace_j2g_main__init_A_const_78 any

var A_arbace_j2g_main__init_A_const_79 *lang.Var

var A_arbace_j2g_main__init_A_const_80 any

var A_arbace_j2g_main__init_A_const_81 *lang.Var

var A_arbace_j2g_main__init_A_const_82 any

var A_arbace_j2g_main__init_A_const_83 *lang.Var

var A_arbace_j2g_main__init_A_const_84 any

var A_arbace_j2g_main__init_A_const_85 *lang.Var

var A_arbace_j2g_main__init_A_const_86 any

var A_arbace_j2g_main__init_A_const_87 *lang.Var

var A_arbace_j2g_main__init_A_const_88 any

var A_arbace_j2g_main__init_A_const_89 any

var A_arbace_j2g_main__init_A_const_90 *lang.Var

var A_arbace_j2g_main__init_A_const_91 any

var A_arbace_j2g_main__init_A_const_92 *lang.Var

var A_arbace_j2g_main__init_A_const_93 any

var A_arbace_j2g_main__init_A_const_94 any

var A_arbace_j2g_main__init_A_const_95 *lang.Var

var A_arbace_j2g_main__init_A_const_96 any

var A_arbace_j2g_main__init_A_const_97 *lang.Var

var A_arbace_j2g_main__init_A_const_98 any

var A_arbace_j2g_main__init_A_const_99 *lang.Var

var A_arbace_j2g_main__init_A_const_100 any

var A_arbace_j2g_main__init_A_init jrt.ClassInit

func A_arbace_j2g_main__init_A_Init() { if !A_arbace_j2g_main__init_A_init.Done() { A_arbace_j2g_main__init_A_init.Run(A_arbace_j2g_main__init_A_clinit) } }

func A_arbace_j2g_main__init_A_clinit() { A_arbace_j2g_main__init_A_clinit_p0(); A_arbace_j2g_main__init_A_clinit_p1(); A_arbace_j2g_main__init_A_clinit_p2(); A_arbace_j2g_main__init_A_clinit_p3(); A_arbace_j2g_main__init_A_clinit_p4(); A_arbace_j2g_main__init_A_clinit_p5(); A_arbace_j2g_main__init_A_clinit_p6(); A_arbace_j2g_main__init_A_clinit_p7() }

func A_arbace_j2g_main__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_main__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_542, 162); A_arbace_j2g_main__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[61]); A_arbace_j2g_main__init_A_const_1 = A_arbace_j2g_main__init_A_const_pool.A[62]; A_arbace_j2g_main__init_A_const_2 = A_arbace_j2g_main__init_A_const_pool.A[63]; A_arbace_j2g_main__init_A_const_3 = A_arbace_j2g_main__init_A_const_pool.A[64]; A_arbace_j2g_main__init_A_const_4 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[65]); A_arbace_j2g_main__init_A_const_5 = A_arbace_j2g_main__init_A_const_pool.A[66]; A_arbace_j2g_main__init_A_const_6 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[67]); A_arbace_j2g_main__init_A_const_7 = A_arbace_j2g_main__init_A_const_pool.A[68]; A_arbace_j2g_main__init_A_const_8 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[69]); A_arbace_j2g_main__init_A_const_9 = A_arbace_j2g_main__init_A_const_pool.A[70]; A_arbace_j2g_main__init_A_const_10 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[71]); A_arbace_j2g_main__init_A_const_11 = A_arbace_j2g_main__init_A_const_pool.A[72]; A_arbace_j2g_main__init_A_const_12 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[73]) }

func A_arbace_j2g_main__init_A_clinit_p1() { A_arbace_j2g_main__init_A_const_13 = A_arbace_j2g_main__init_A_const_pool.A[74]; A_arbace_j2g_main__init_A_const_14 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[75]); A_arbace_j2g_main__init_A_const_15 = A_arbace_j2g_main__init_A_const_pool.A[76]; A_arbace_j2g_main__init_A_const_16 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[77]); A_arbace_j2g_main__init_A_const_17 = A_arbace_j2g_main__init_A_const_pool.A[78]; A_arbace_j2g_main__init_A_const_18 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[79]); A_arbace_j2g_main__init_A_const_19 = A_arbace_j2g_main__init_A_const_pool.A[80]; A_arbace_j2g_main__init_A_const_20 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[81]); A_arbace_j2g_main__init_A_const_21 = A_arbace_j2g_main__init_A_const_pool.A[82]; A_arbace_j2g_main__init_A_const_22 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[83]); A_arbace_j2g_main__init_A_const_23 = A_arbace_j2g_main__init_A_const_pool.A[84]; A_arbace_j2g_main__init_A_const_24 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[85]); A_arbace_j2g_main__init_A_const_25 = A_arbace_j2g_main__init_A_const_pool.A[86] }

func A_arbace_j2g_main__init_A_clinit_p2() { A_arbace_j2g_main__init_A_const_26 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[87]); A_arbace_j2g_main__init_A_const_27 = A_arbace_j2g_main__init_A_const_pool.A[88]; A_arbace_j2g_main__init_A_const_28 = A_arbace_j2g_main__init_A_const_pool.A[89]; A_arbace_j2g_main__init_A_const_29 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[90]); A_arbace_j2g_main__init_A_const_30 = A_arbace_j2g_main__init_A_const_pool.A[91]; A_arbace_j2g_main__init_A_const_31 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[92]); A_arbace_j2g_main__init_A_const_32 = A_arbace_j2g_main__init_A_const_pool.A[93]; A_arbace_j2g_main__init_A_const_33 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[94]); A_arbace_j2g_main__init_A_const_34 = A_arbace_j2g_main__init_A_const_pool.A[95]; A_arbace_j2g_main__init_A_const_35 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[96]); A_arbace_j2g_main__init_A_const_36 = A_arbace_j2g_main__init_A_const_pool.A[97]; A_arbace_j2g_main__init_A_const_37 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[98]); A_arbace_j2g_main__init_A_const_38 = A_arbace_j2g_main__init_A_const_pool.A[99] }

func A_arbace_j2g_main__init_A_clinit_p3() { A_arbace_j2g_main__init_A_const_39 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[100]); A_arbace_j2g_main__init_A_const_40 = A_arbace_j2g_main__init_A_const_pool.A[101]; A_arbace_j2g_main__init_A_const_41 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[102]); A_arbace_j2g_main__init_A_const_42 = A_arbace_j2g_main__init_A_const_pool.A[103]; A_arbace_j2g_main__init_A_const_43 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[104]); A_arbace_j2g_main__init_A_const_44 = A_arbace_j2g_main__init_A_const_pool.A[105]; A_arbace_j2g_main__init_A_const_45 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[106]); A_arbace_j2g_main__init_A_const_46 = A_arbace_j2g_main__init_A_const_pool.A[107]; A_arbace_j2g_main__init_A_const_47 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[108]); A_arbace_j2g_main__init_A_const_48 = A_arbace_j2g_main__init_A_const_pool.A[109]; A_arbace_j2g_main__init_A_const_49 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[110]); A_arbace_j2g_main__init_A_const_50 = A_arbace_j2g_main__init_A_const_pool.A[111]; A_arbace_j2g_main__init_A_const_51 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[112]) }

func A_arbace_j2g_main__init_A_clinit_p4() { A_arbace_j2g_main__init_A_const_52 = A_arbace_j2g_main__init_A_const_pool.A[113]; A_arbace_j2g_main__init_A_const_53 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[114]); A_arbace_j2g_main__init_A_const_54 = A_arbace_j2g_main__init_A_const_pool.A[115]; A_arbace_j2g_main__init_A_const_55 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[116]); A_arbace_j2g_main__init_A_const_56 = A_arbace_j2g_main__init_A_const_pool.A[117]; A_arbace_j2g_main__init_A_const_57 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[118]); A_arbace_j2g_main__init_A_const_58 = A_arbace_j2g_main__init_A_const_pool.A[119]; A_arbace_j2g_main__init_A_const_59 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[120]); A_arbace_j2g_main__init_A_const_60 = A_arbace_j2g_main__init_A_const_pool.A[121]; A_arbace_j2g_main__init_A_const_61 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[122]); A_arbace_j2g_main__init_A_const_62 = A_arbace_j2g_main__init_A_const_pool.A[123]; A_arbace_j2g_main__init_A_const_63 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[124]); A_arbace_j2g_main__init_A_const_64 = A_arbace_j2g_main__init_A_const_pool.A[125] }

func A_arbace_j2g_main__init_A_clinit_p5() { A_arbace_j2g_main__init_A_const_65 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[126]); A_arbace_j2g_main__init_A_const_66 = A_arbace_j2g_main__init_A_const_pool.A[127]; A_arbace_j2g_main__init_A_const_67 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[128]); A_arbace_j2g_main__init_A_const_68 = A_arbace_j2g_main__init_A_const_pool.A[129]; A_arbace_j2g_main__init_A_const_69 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[130]); A_arbace_j2g_main__init_A_const_70 = A_arbace_j2g_main__init_A_const_pool.A[131]; A_arbace_j2g_main__init_A_const_71 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[132]); A_arbace_j2g_main__init_A_const_72 = A_arbace_j2g_main__init_A_const_pool.A[133]; A_arbace_j2g_main__init_A_const_73 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[134]); A_arbace_j2g_main__init_A_const_74 = A_arbace_j2g_main__init_A_const_pool.A[135]; A_arbace_j2g_main__init_A_const_75 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[136]); A_arbace_j2g_main__init_A_const_76 = A_arbace_j2g_main__init_A_const_pool.A[137]; A_arbace_j2g_main__init_A_const_77 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[138]) }

func A_arbace_j2g_main__init_A_clinit_p6() { A_arbace_j2g_main__init_A_const_78 = A_arbace_j2g_main__init_A_const_pool.A[139]; A_arbace_j2g_main__init_A_const_79 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[140]); A_arbace_j2g_main__init_A_const_80 = A_arbace_j2g_main__init_A_const_pool.A[141]; A_arbace_j2g_main__init_A_const_81 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[142]); A_arbace_j2g_main__init_A_const_82 = A_arbace_j2g_main__init_A_const_pool.A[143]; A_arbace_j2g_main__init_A_const_83 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[144]); A_arbace_j2g_main__init_A_const_84 = A_arbace_j2g_main__init_A_const_pool.A[145]; A_arbace_j2g_main__init_A_const_85 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[146]); A_arbace_j2g_main__init_A_const_86 = A_arbace_j2g_main__init_A_const_pool.A[147]; A_arbace_j2g_main__init_A_const_87 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[148]); A_arbace_j2g_main__init_A_const_88 = A_arbace_j2g_main__init_A_const_pool.A[149]; A_arbace_j2g_main__init_A_const_89 = A_arbace_j2g_main__init_A_const_pool.A[150]; A_arbace_j2g_main__init_A_const_90 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[151]); A_arbace_j2g_main__init_A_const_91 = A_arbace_j2g_main__init_A_const_pool.A[152] }

func A_arbace_j2g_main__init_A_clinit_p7() { A_arbace_j2g_main__init_A_const_92 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[153]); A_arbace_j2g_main__init_A_const_93 = A_arbace_j2g_main__init_A_const_pool.A[154]; A_arbace_j2g_main__init_A_const_94 = A_arbace_j2g_main__init_A_const_pool.A[155]; A_arbace_j2g_main__init_A_const_95 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[156]); A_arbace_j2g_main__init_A_const_96 = A_arbace_j2g_main__init_A_const_pool.A[157]; A_arbace_j2g_main__init_A_const_97 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[158]); A_arbace_j2g_main__init_A_const_98 = A_arbace_j2g_main__init_A_const_pool.A[159]; A_arbace_j2g_main__init_A_const_99 = lang.Var_Cast(A_arbace_j2g_main__init_A_const_pool.A[160]); A_arbace_j2g_main__init_A_const_100 = A_arbace_j2g_main__init_A_const_pool.A[161] }

func A_arbace_j2g_main__init_A_New() *A_arbace_j2g_main__init_A { A_arbace_j2g_main__init_A_Init(); t := &A_arbace_j2g_main__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_main__init_A) Ctor() {}

func (t *A_arbace_j2g_main__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_main__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_main__init_A_class }

func (t *A_arbace_j2g_main__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_main__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_main__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_main__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_main__init_A); return ok }

func A_arbace_j2g_main__init_A_Cast(x any) *A_arbace_j2g_main__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_main__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_main__init_A_class)) }; return v }
