//line j2g_strings.ae:1
package aot_arbace_j2g_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.worldyn1,wyn14,arbace.j2g.jrtyn3,jrtyn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn16,arbace.j2g.reachyn1,ryn17,arbace.j2g.accessyn3,accyn15,arbace.j2g.codeyn1,cyn13,arbace.j2g.vhyn2,vhyn16,arbace.j2g.declsyn1,dyn14,arbace.j2g.outyn3,outyn14,arbace.j2g.dynyn3,dynyn16,arbace.j2g.dyncfyn5,dyncfyn17,arbace.j2g.fromfnyn6,fromfnyn17,arbace.j2g.checksyn3,chkyn16,arbace.j2g.embedyn5,embedyn15,arbace.j2g.edgeyn4,edgeyn15,arbace.j2g.zlibyn4,zlibyn20,arbace.repr.go.printyn2,gpyn11,arbace.corekn3,dockn3,outkn5,slicekn5,rootskn6,inputskn11,record-edgekn12,variant-dirskn7,gotablekn5,mainskn5,edgeskn14,jvm-reflectionkn5,testskn4,langkn7,qualifykn5,awaitkn3,jdkkn7,programkn2,gokn3,varkn7,standinkn4,filekn7,classeskn10,unexportedys14,arbace.j2g.jvm11,unexported?kn4,elsekn5,superkn5,flagskn4,namekn4,desckn7,methodskn5,orderkn11,jrt-classeskn5,fileskn5,funcskn3,tagyn1,*yn4,inityn2,nsyn20,go.arbace.cmd.arbacekn7,requireyn9,arbace.goyn2,gokn4,linekn6,columnyn4,loadys2,go7,packageyn4,mainkn4,pathkn11,embed-filesys2,go3,varks2,go5,embedys5,embed2,FSyn6,stringys2,go4,funcyn10,execRlwrapyn4,whenyn2,!=yn13,arbaceVersionys3,jrt40,System_SetProperty_String_String__Stringys3,jrt3,Stryn3,letyn6,valuesyn3,subyn3,errys2,fs3,Subyn9,resourcesyn2,==ys3,jrt7,SetHostys3,jrt11,ProgramHostyn10,setupImageyn9,imageDatayn4,argsys3,jrt11,NewRefArrayys3,jrt12,String_classyn4,convyn5,int32yn1,-yn3,lenys2,os4,Argsyn5,rangeyn1,iyn8,subsliceyn4,asetyn3,.-Ayn6,statusys3,jrt7,RunMainyn2,fnys4,lang20,Main_Main_String1__Vyn11,finishImageys2,os4,Exitys2,go4,filekn7,importsyn2,fsyn2,osyn4,langyn1,_kn3,jrtkn9,source-ofkn4,litskn10,lit-prefixkn3,upskn7,lambdaskn4,cutskn5,formskn5,errorkn5,raceskn4,secskn6,simplekn7,effectsys3,j2g9,code-declyn7,j2gCodeyn5,sliceyn3,lityn14,j2gCodeDefinedyn4,boolkn8,embeddedkn14,cut-candidateskn13,embedded-datakn4,rootkn4,dirskn4,treekn13,variant-fileskn11,late-inputskn4,waitkn8,variantskn8,replacedkn3,cutkn5,addedkn11,compile-setkn6,failedkn4,varskn1,Tkn14,vmethods-cachekn13,trivial-cachekn6,erasedkn2,vhkn7,handleskn6,fieldskn7,root-fnkn6,slice?kn5,statekn3,fiskn14,subclass-indexkn7,reachedkn11,unavailablekn3,pkgkn7,sourceskn6,methodkn9,hidden-bykn5,worldkn4,unitkn26,methods-with-missing-partskn10,translatedkn17,replaced-standinskn7,missingkn17,analysis-failureskn6,errorskn15,race-candidateskn25,package-private-overrideskn5,timesks15,arbace.j2g.main5,timeskn11,from-sourcekn3,dynkn6,fromfnkn8,adapterskn13,registrationskn5,typeskn8,packageskn10,collisionskn9,overrideskn6,checkskn5,textskn9,generatedkn12,hand-writtenyn13,go.arbace.jrtkn10,test-fileskn5,afterkn9,resourceskn11,image-typeskn8,prog-dirkn3,reskn4,loadkn5,reachkn9,translatekn5,writekn5,stepsv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,V3,R17,R1,R18,V3,R19,R1,R20,V3,R21,R1,R22,V3,R23,R1,R24,V3,R25,R1,R26,V3,R27,R1,R28,V3,R29,R1,R30,V3,R31,R1,R32,V3,R33,R1,R34,V3,R35,R1,R36,V3,R37,R1,R38,V3,R39,R1,R40,V3,R41,R1,R42,V3,R43,R1,R44,V3,R45,R1,R46,v11,arbace.core5,referR47,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.j2g.mainm2,R48,s2981,bin/j2g: Java forms to Go forms (doc/go/J2G-SPEC.md, doc/go/J2G-NOTES.md).\n\n  bin/j2g [OPTIONS]\n    --out DIR          output directory (default .tmp/j2g/out): DIR/gen/go/... the generated\n                       forms (J2G-SPEC §4.3: the files j2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/build-go; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of Java forms files (test fixtures; a tree with a\n                       packages.edn: the compiled namespaces, arbace.c2j, entered in the second\n                       round of the load, w/load-world)\n    --await DIR        --input DIR, read once DIR/aot.edn exists (j2g meanwhile loads and\n                       starts analyzing the other inputs; bin/arbace-go starts j2g while the\n                       host compiles the namespaces into DIR); the output is --input DIR's\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (J2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       j2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/build-go --line-file DIR/prog\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): j2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/j2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)v11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,nextR49,R50,R51,R52,v11,arbace.core7,ex-infov11,arbace.core4,restv11,arbace.core5,assocR53,v11,arbace.core6,updateR54,v11,arbace.core4,fnilR55,R56,R57,R58,R59,R60,R61,R62,R63,R64,v11,arbace.core10,re-patternv13,arbace.string7,replacev14,arbace.java.io4,filev11,arbace.core3,setv11,arbace.core3,mapv15,arbace.j2g.main8,internalv11,arbace.core3,strv11,arbace.core4,keysv16,arbace.j2g.world10,read-formsv11,arbace.core5,mergev11,arbace.core4,intov11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR65,v16,arbace.j2g.names13,go-class-nameR66,R67,R68,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consR69,v11,arbace.core4,subsl0,c47,c46,v11,arbace.core3,notv15,arbace.j2g.edge4,jvm?R70,v11,arbace.core17,requiring-resolveR71,R72,R73,v22,arbace.classes.analyze4,declv11,arbace.core4,not=v16,arbace.j2g.model4,has?R74,l512,l1024,v11,arbace.core4,someR75,R76,l1,R77,v11,arbace.core4,sortR78,v22,arbace.classes.analyze6,*unit*v13,arbace.string10,ends-with?v11,arbace.core6,mapcatv15,arbace.j2g.main9,root-keysv11,arbace.core6,filterv13,arbace.string12,starts-with?v11,arbace.core7,re-findp4,\\$\\dv13,arbace.string5,splitp1,#l2,v11,arbace.core6,concatR79,v16,arbace.j2g.model3,*w*v16,arbace.j2g.model7,go-namev11,arbace.core6,get-inR80,R81,v16,arbace.j2g.names8,new-namev22,arbace.classes.analyze14,ctor-real-descv16,arbace.j2g.model7,static?v16,arbace.j2g.names11,method-basev11,arbace.core9,contains?v11,arbace.core4,seq?v11,arbace.core7,symbol?v11,arbace.core4,namev11,arbace.core6,secondv11,arbace.core7,vector?v11,arbace.core4,dropR82,R83,v11,arbace.core9,volatile!v11,arbace.core10,re-matchesv11,arbace.core7,vreset!v11,arbace.core5,coll?v11,arbace.core4,run!v11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core6,removev15,arbace.j2g.main9,mentions?v11,arbace.core6,empty?v13,arbace.string4,joinv11,arbace.core5,some?v15,arbace.j2g.main16,method-recv-typeS4,s4,funcs3,vars5,consts4,typev15,arbace.j2g.main10,form-namesS3,s3,vars5,consts4,typev11,arbace.core7,string?v11,arbace.core3,vecR84,v15,arbace.j2g.main16,filter-init-bodyv11,arbace.core4,spitv14,arbace.java.io12,make-parentsv14,arbace.java.io4,copyv15,arbace.j2g.zlib7,deflatev16,arbace.j2g.model8,par-mapvv16,arbace.j2g.model4,jobsv15,arbace.j2g.main13,resource-filev11,arbace.core5,doallML3,R85,R86,ML2,R87,V3,R88,R1,R89,m4,R90,i290,R91,i30,m4,R90,i290,R91,i5,ML2,R92,s12,arbace/imagem4,R90,i293,R91,i5,ML2,R92,s18,arbace/image_typesm4,R90,i294,R91,i5,ML2,R92,s11,arbace/mainm4,R90,i295,R91,i5,ML2,R92,s19,arbace/rlwrap_linuxm4,R90,i296,R91,i5,ML2,R92,s19,arbace/rlwrap_otherm4,R90,i297,R91,i5,R93,R94,R95,V5,s8,image.gos14,image_types.gos7,main.gos15,rlwrap_linux.gos15,rlwrap_other.goR96,V2,s9,image.binnML2,R97,Myn9,resourcesm6,R98,V1,s3,resR82,R99,R48,s80,resources are the namespaces' sources RT.load reads (EVAL-NOTES.md, \"Loading\").\nm4,R90,i313,R91,i5,ML2,R97,Myn9,imageDatam6,R98,V1,s9,image.binR82,R100,R48,s118,imageData is the image of prepared namespaces (EXEC-NOTES.md; image.go): empty until bin/arbace-go --build writes it.\nm4,R90,i316,R91,i5,ML2,R97,Myn13,arbaceVersionm4,R82,R100,R48,s205,arbaceVersion is Arbace's version, the map *arbace-version* reads from the system property arbace.version: empty in j2g's output, set by bin/arbace-go's link (go build -ldflags -X main.arbaceVersion=...).\nm4,R90,i319,R91,i5,ML8,R101,R94,V0,ML1,R102,m4,R90,i323,R91,i7,ML3,R103,ML3,R104,R105,s0,m4,R90,i324,R91,i13,ML3,R106,ML2,R107,s14,arbace.versionm4,R90,i325,R91,i55,ML2,R107,R105,m4,R90,i325,R91,i82,m4,R90,i325,R91,i9,m4,R90,i324,R91,i7,ML3,R108,V2,ML3,R109,R110,R111,m4,R90,i326,R91,i13,ML3,R112,R113,s3,resm4,R90,i326,R91,i30,ML3,R103,ML3,R114,R111,nm4,R90,i327,R91,i15,ML2,R115,ML2,R116,R110,m4,R90,i328,R91,i24,m4,R90,i328,R91,i11,m4,R90,i327,R91,i9,m4,R90,i326,R91,i7,ML2,R117,R118,m4,R90,i329,R91,i7,ML4,R108,V2,R119,ML3,R120,R121,ML3,R122,R123,ML3,R124,ML2,R125,R126,m4,R90,i330,R91,i67,l1,m4,R90,i330,R91,i64,m4,R90,i330,R91,i52,m4,R90,i330,R91,i18,ML3,R127,V3,R128,R10,ML3,R129,R126,l1,m4,R90,i331,R91,i21,ML4,R130,ML2,R131,R119,m4,R90,i332,R91,i17,R128,ML2,R107,R10,m4,R90,i332,R91,i30,m4,R90,i332,R91,i11,m4,R90,i331,R91,i9,ML4,R108,V2,R132,ML2,R133,ML3,R134,V0,ML2,R135,R119,m4,R90,i333,R91,i42,m4,R90,i333,R91,i35,m4,R90,i333,R91,i22,ML1,R136,m4,R90,i334,R91,i11,ML2,R137,R132,m4,R90,i335,R91,i11,m4,R90,i333,R91,i9,m4,R90,i330,R91,i7,m4,R90,i322,R91,i5,R138,R139,V5,V2,R40,s5,embedV2,R140,s5,io/fsV2,R141,s2,osV2,R14,s10,arbace/jrtV2,R142,s11,arbace/langV1,V2,R143,s14,arbace/gotableR143,v16,arbace.j2g.names8,pkg-pathv11,arbace.core7,keywordv11,arbace.core8,distinctv11,arbace.core4,valsv16,arbace.j2g.names17,compiled-packagesR144,R145,v15,arbace.j2g.main3,nowR146,v11,arbace.core4,atomR147,R148,R149,R150,R151,v11,arbace.core19,pop-thread-bindingsR152,v11,arbace.core7,printlnR153,R154,v15,arbace.j2g.main4,secsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv15,arbace.j2g.code10,*pkgstate*v15,arbace.j2g.code7,*races*v11,arbace.core5,*out*v15,arbace.j2g.code11,*node-memo*R155,R156,v11,arbace.core5,swap!v11,arbace.core6,reducev11,arbace.core6,symbolv11,arbace.core7,sort-byv11,arbace.core3,valv11,arbace.core5,printv15,arbace.j2g.main5,apartv16,arbace.j2g.model10,reflected?v16,arbace.j2g.decls15,reflected-formsv16,arbace.j2g.decls11,class-formsv11,arbace.core11,map-indexedv11,arbace.core6,vectorv11,arbace.core5,rangev11,arbace.core4,takel25,v11,arbace.core4,compv11,arbace.core1,-v15,arbace.j2g.main12,merge-apart!R157,v16,arbace.j2g.model7,jrt-symR97,v11,arbace.core9,with-metaR158,R159,R160,R159,R97,R161,m2,R82,R162,R158,R101,R84,R158,v14,arbace.j2g.out18,class-registrationv11,arbace.core8,group-byv11,arbace.core4,mapvv15,arbace.j2g.main18,registration-formsv11,arbace.core6,pr-strv11,arbace.core4,map?v16,arbace.j2g.embed7,sourcesR163,R164,v16,arbace.j2g.embed14,cut-candidatesR165,v16,arbace.j2g.embed4,datav11,arbace.core6,reset!v11,arbace.core11,read-stringv11,arbace.core5,slurpR166,R167,V2,s4,langs8,java/apiV1,s4,langR168,R169,v16,arbace.j2g.world10,load-worldR170,R171,R172,R173,R174,R175,R176,R177,v14,arbace.j2g.jrt4,scanv15,arbace.j2g.main16,manifest-classesv15,arbace.j2g.main11,jrt-classesV2,s31,String_Format_String_O1__Strings38,String_Format_Locale_String_O1__Stringv11,arbace.core9,update-inV2,R77,s6,StringV2,R77,s6,StringV2,R77,s5,ClassV2,R77,s6,StringR178,V3,s9,System_ins10,System_outs10,System_errV3,s27,System_SetIn_InputStream__Vs28,System_SetOut_PrintStream__Vs28,System_SetErr_PrintStream__VV2,R77,s6,Stringv14,arbace.j2g.out20,string-regex-methodsV2,R77,s12,ForkJoinPoolv14,arbace.j2g.out19,fjp-support-methodsR179,R180,R181,R182,R183,v13,arbace.j2g.vh7,handlesR184,R185,R186,v15,arbace.j2g.main13,repl-visible?v16,arbace.j2g.names15,compiled-class?v13,arbace.string9,includes?v14,arbace.j2g.dyn9,api-classv14,arbace.j2g.dyn5,rootsv14,arbace.j2g.dyn11,proxy-rootsv17,arbace.j2g.fromfn5,rootsV1,V3,s28,java/io/ByteArrayInputStreams6,<init>s5,([B)VV3,V3,s32,jdk/internal/jrt/StandardStreamss2,ins23,()Ljava/io/InputStream;V3,s32,jdk/internal/jrt/StandardStreamss3,outs23,()Ljava/io/PrintStream;V3,s32,jdk/internal/jrt/StandardStreamss3,errs23,()Ljava/io/PrintStream;V6,V3,s23,java/util/regex/Patterns7,compiles45,(Ljava/lang/String;)Ljava/util/regex/Pattern;V3,s23,java/util/regex/Patterns5,splits46,(Ljava/lang/CharSequence;I)[Ljava/lang/String;V3,s23,java/util/regex/Patterns7,matchers51,(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;V3,s23,java/util/regex/Patterns7,matchess45,(Ljava/lang/String;Ljava/lang/CharSequence;)ZV3,s23,java/util/regex/Matchers10,replaceAlls38,(Ljava/lang/String;)Ljava/lang/String;V3,s23,java/util/regex/Matchers12,replaceFirsts38,(Ljava/lang/String;)Ljava/lang/String;V1,V3,s42,jdk/internal/jrt/CaseInsensitiveComparators8,<clinit>s3,()VV6,s39,(Ljava/lang/String;)Ljava/lang/Process;s58,(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s72,(Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;s40,([Ljava/lang/String;)Ljava/lang/Process;s59,([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s73,([Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;v14,arbace.j2g.out15,fjp-support-keyv15,arbace.j2g.main12,bundle-rootsV1,V3,s18,java/util/Optionals2,ofs40,(Ljava/lang/Object;)Ljava/util/Optional;V3,V3,s19,java/util/ArrayLists6,<init>s3,()VV3,s19,java/util/ArrayLists3,adds21,(Ljava/lang/Object;)ZV3,s20,java/util/Collections6,streams27,()Ljava/util/stream/Stream;V1,V3,s19,java/io/PrintWriters5,prints21,(Ljava/lang/String;)VV1,V3,s19,java/io/PrintStreams5,prints21,(Ljava/lang/String;)VV3,V3,s17,java/util/HashMaps6,<init>s3,()VV3,s17,java/util/HashMaps3,puts56,(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;V3,s21,java/util/Collectionss15,unmodifiableMaps32,(Ljava/util/Map;)Ljava/util/Map;V4,V3,s19,java/util/Formatters6,<init>s3,()VV3,s19,java/util/Formatters6,<init>s21,(Ljava/util/Locale;)VV3,s19,java/util/Formatters6,formats60,(Ljava/lang/String;[Ljava/lang/Object;)Ljava/util/Formatter;V3,s19,java/util/Formatters8,toStrings20,()Ljava/lang/String;v15,arbace.j2g.main6,top-ofv16,arbace.j2g.model13,translatable?v16,arbace.j2g.reach3,runR187,v15,arbace.j2g.main13,standin-rootsR188,R189,v17,arbace.j2g.fromfn3,fisR190,v16,arbace.j2g.model19,make-subclass-indexR191,R192,v16,arbace.j2g.model3,pkgV2,R144,R60,v16,arbace.j2g.names13,compiled-pkg?v17,arbace.j2g.checks10,collisionsR193,R194,v17,arbace.j2g.checks25,package-private-overridesR195,R196,v17,arbace.j2g.checks11,race-reportR197,v11,arbace.core11,frequenciesR198,R199,R200,R201,v11,arbace.core10,sorted-mapR202,R203,R204,R205,R206,R207,v11,arbace.core11,future-callv15,arbace.j2g.main10,report-strR208,v11,arbace.core7,reversev11,arbace.core8,file-seqv14,arbace.java.io11,delete-filev14,arbace.j2g.out9,file-textv16,arbace.j2g.names8,pkg-namev15,arbace.j2g.main6,write!v11,arbace.core6,every?v15,arbace.j2g.main16,filter-standins*v20,arbace.repr.go.print10,read-formsv14,arbace.j2g.out9,form-textv15,arbace.j2g.main10,copy-file!v16,arbace.j2g.names18,qualified-prefixesv14,arbace.j2g.out17,fjp-support-classv18,arbace.classes.env13,*compile-set*v18,arbace.classes.env13,*from-source*R209,v14,arbace.j2g.out16,*absent-members*v16,arbace.j2g.decls9,*reached*v15,arbace.j2g.main17,translate-classesv14,arbace.j2g.out12,go-file-namev15,arbace.j2g.main10,source-topv11,arbace.core7,memoizev14,arbace.j2g.dyn8,enabled?V2,R60,s10,j2g_dyn.gov14,arbace.j2g.dyn5,formsv16,arbace.j2g.dyncf8,enabled?V2,R60,s9,j2g_cf.gov16,arbace.j2g.dyncf5,formsV2,R60,s13,j2g_fromfn.gov17,arbace.j2g.fromfn5,formsv15,arbace.j2g.main13,registrationsR210,R211,v14,arbace.j2g.out13,adapter-formsR212,v15,arbace.j2g.main20,merge-registrations!R213,v14,arbace.j2g.out9,ups-formsv14,arbace.j2g.out19,support-table-formsv14,arbace.j2g.out12,frames-formsv14,arbace.j2g.out11,start-formsv16,arbace.j2g.model13,start-classesv14,arbace.j2g.out13,support-formsR214,v16,arbace.j2g.embed17,with-member-typesv16,arbace.j2g.model9,in-world?v16,arbace.j2g.model13,hand-written?v14,arbace.j2g.out9,cut-formsv14,arbace.j2g.out15,cut-table-formsv16,arbace.j2g.model13,trivial-init?v15,arbace.j2g.main13,lazy-standinsR101,R84,v14,arbace.j2g.out13,strings-formsR215,R216,R217,R218,v14,arbace.j2g.out9,*renames*R219,R220,R221,ML3,R85,R222,ML2,R87,V3,R88,R1,R89,m4,R90,i891,R91,i60,m4,R90,i891,R91,i42,R93,R14,R223,R92,R224,R85,v16,arbace.j2g.names6,pkg-nsML2,R87,V3,R88,R1,R89,m4,R90,i902,R91,i79,R93,R92,ML2,R87,V3,R88,R1,R89,m4,R90,i902,R91,i79,p14,(?m)^\\(ns( |$)v15,arbace.j2g.main16,write-resources!v16,arbace.j2g.dyncf13,generics-textv15,arbace.j2g.main21,program-package-formsv15,arbace.j2g.main18,program-main-formsv16,arbace.j2g.embed11,image-formsv16,arbace.j2g.embed12,rlwrap-formsv16,arbace.j2g.embed16,image-type-formsR225,R226,R227,R228,R229,R230,R231,R232,R233,v11,arbace.core1,+v11,arbace.core5,countv15,arbace.j2g.main8,id-floorv15,arbace.j2g.main4,run*v15,arbace.j2g.edge9,read-edgev15,arbace.j2g.main12,advance-ids!v18,arbace.classes.env10,*recorded*v15,arbace.j2g.edge11,*recording*v15,arbace.j2g.edge11,write-edge!v15,arbace.j2g.edge13,recorded-edgev15,arbace.j2g.main12,default-edgev18,arbace.classes.env10,*declared*v15,arbace.j2g.edge6,*edge*v22,arbace.classes.analyze15,*source-lookup*v15,arbace.j2g.main10,parse-argsv15,arbace.j2g.main3,runv11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("j2g: the runtime's id counter (")

var Lit_2 *jrt.String = jrt.Intern(") is at j2g's id-floor (")

var Lit_3 *jrt.String = jrt.Intern(") already: raise it (j2g's output then names its temporaries afresh)")

var Lit_4 *jrt.String = jrt.Intern("Lit?")

var Lit_5 *jrt.String = jrt.Intern("_")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.main$apart$fn__797000217")

var Lit_7 *jrt.String = jrt.Intern("j2g: error in")

var Lit_8 *jrt.String = jrt.Intern(":")

var Lit_9 *jrt.String = jrt.Intern("J2G_TRACE")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$bundle_QMARK___797000062")

var Lit_11 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__797000064__797000068")

var Lit_12 *jrt.String = jrt.Intern("java/util/ResourceBundle")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__797000064__797000068$fn__797000069")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__797000064__797000068$fn__797000069$fn__797000070")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__797000064__797000068$fn__797000069$fn__797000074")

var Lit_16 *jrt.String = jrt.Intern("<init>")

var Lit_17 *jrt.String = jrt.Intern("()V")

var Lit_18 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__797000064__797000068$fn__797000069$fn__797000070$fn__797000071")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.main$filter_init_body$fn__797000133")

var Lit_20 *jrt.String = jrt.Intern("|")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$fn__797000137")

var Lit_22 *jrt.String = jrt.Intern("(")

var Lit_23 *jrt.String = jrt.Intern(")(_[A-Za-z0-9_]*)?")

var Lit_24 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$drop_QMARK___797000139")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$group__797000142")

var Lit_26 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$iter__797000152__797000156")

var Lit_27 *jrt.String = jrt.Intern("method")

var Lit_28 *jrt.String = jrt.Intern("init")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$group__797000142$fn__797000149")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$iter__797000152__797000156$fn__797000157")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$iter__797000152__797000156$fn__797000157$fn__797000158")

var Lit_32 *jrt.String = jrt.Intern("func")

var Lit_33 *jrt.String = jrt.Intern("type")

var Lit_34 *jrt.String = jrt.Intern("var")

var Lit_35 *jrt.String = jrt.Intern(".")

var Lit_36 *jrt.String = jrt.Intern("/")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__797000031__797000035")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__797000041__797000045")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__797000031__797000035$fn__797000036")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__797000031__797000035$fn__797000036$fn__797000037")

var Lit_41 *jrt.String = jrt.Intern("_class")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__797000041__797000045$fn__797000046")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__797000041__797000045$fn__797000046$fn__797000047")

var Lit_44 *jrt.String = jrt.Intern("manifest.edn")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.main$manifest_classes$fn__797000028")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.main$mentions_QMARK_$w__797000126")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_$conj_all__797000222")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_$fn__797000227")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_$fn__797000232")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_$conj_all__797000222$fn__797000223")

var Lit_51 *jrt.String = jrt.Intern("Lit_")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.main$merge_registrations_BANG_$fn__797000268")

var Lit_53 *jrt.String = jrt.Intern(".tmp/j2g/out")

var Lit_54 *jrt.String = jrt.Intern("--record-edge")

var Lit_55 *jrt.String = jrt.Intern("--input")

var Lit_56 *jrt.String = jrt.Intern("--variants")

var Lit_57 *jrt.String = jrt.Intern("--gotable")

var Lit_58 *jrt.String = jrt.Intern("--main")

var Lit_59 *jrt.String = jrt.Intern("--edge")

var Lit_60 *jrt.String = jrt.Intern("--jvm-reflection")

var Lit_61 *jrt.String = jrt.Intern("--tests")

var Lit_62 *jrt.String = jrt.Intern("--root")

var Lit_63 *jrt.String = jrt.Intern("--lang")

var Lit_64 *jrt.String = jrt.Intern("--qualify")

var Lit_65 *jrt.String = jrt.Intern("--out")

var Lit_66 *jrt.String = jrt.Intern("--await")

var Lit_67 *jrt.String = jrt.Intern("--jdk")

var Lit_68 *jrt.String = jrt.Intern("--program")

var Lit_69 *jrt.String = jrt.Intern("arbace.lang.Main#main")

var Lit_70 *jrt.String = jrt.Intern("--slice")

var Lit_71 *jrt.String = jrt.Intern("j2g: unknown option ")

var Lit_72 *jrt.String = jrt.Intern("main.go")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.main$program_main_forms$iter__797000205__797000209")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.main$program_main_forms$iter__797000205__797000209$fn__797000210")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.main$program_main_forms$iter__797000205__797000209$fn__797000210$fn__797000211")

var Lit_76 *jrt.String = jrt.Intern("arbace/cmd/arbace")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.main$program_package_forms$iter__797000194__797000198")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.main$program_package_forms$iter__797000194__797000198$fn__797000199")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.main$program_package_forms$iter__797000194__797000198$fn__797000199$fn__797000200")

var Lit_80 *jrt.String = jrt.Intern("res/")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.main$registration_forms$code_QMARK___797000272")

var Lit_82 *jrt.String = jrt.Intern("CodeDecl")

var Lit_83 *jrt.String = jrt.Intern("DefineCode")

var Lit_84 *jrt.String = jrt.Intern("LinkCode")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__797000275__797000281")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$fn__797000301")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$fn__797000309")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__797000314__797000318")

var Lit_89 *jrt.String = jrt.Intern("r")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$fn__797000301$fn__797000305")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__797000275__797000281$fn__797000282")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__797000275__797000281$fn__797000282$iter__797000277__797000286")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__797000275__797000281$fn__797000282$iter__797000277__797000286$fn__797000287")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__797000275__797000281$fn__797000282$iter__797000277__797000286$fn__797000287$fn__797000288")

var Lit_95 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__797000314__797000318$fn__797000319")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__797000314__797000318$fn__797000319$fn__797000320")

var Lit_97 *jrt.String = jrt.Intern("arbace.j2g.main$repl_visible_QMARK_$fn__797000058")

var Lit_98 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$big_QMARK___797000332")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$val_str__797000334")

var Lit_100 *jrt.String = jrt.Intern("{")

var Lit_101 *jrt.String = jrt.Intern("}\n")

var Lit_102 *jrt.String = jrt.Intern(",\n ")

var Lit_103 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$iter__797000352__797000356")

var Lit_104 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$iter__797000352__797000356$fn__797000357")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$iter__797000352__797000356$fn__797000357$fn__797000358")

var Lit_106 *jrt.String = jrt.Intern(" ")

var Lit_107 *jrt.String = jrt.Intern("}")

var Lit_108 *jrt.String = jrt.Intern(",\n  ")

var Lit_109 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$val_str__797000334$iter__797000335__797000339")

var Lit_110 *jrt.String = jrt.Intern("[")

var Lit_111 *jrt.String = jrt.Intern("]")

var Lit_112 *jrt.String = jrt.Intern("\n  ")

var Lit_113 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$val_str__797000334$iter__797000335__797000339$fn__797000340")

var Lit_114 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$val_str__797000334$iter__797000335__797000339$fn__797000340$fn__797000341")

var Lit_115 *jrt.String = jrt.Intern(".z")

var Lit_116 *jrt.String = jrt.Intern("$*")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys$fn__797000080")

var Lit_118 *jrt.String = jrt.Intern("j2g: root class not found: ")

var Lit_119 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys$iter__797000085__797000089")

var Lit_120 *jrt.String = jrt.Intern("<clinit>")

var Lit_121 *jrt.String = jrt.Intern("$")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys$iter__797000085__797000089$fn__797000090")

var Lit_123 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys$iter__797000085__797000089$fn__797000090$fn__797000091")

var Lit_124 *jrt.String = jrt.Intern("arbace.j2g.main$run$fn__797001037")

var Lit_125 *jrt.String = jrt.Intern("j2g: the edge of this run in ")

var Lit_126 *jrt.String = jrt.Intern(": ")

var Lit_127 *jrt.String = jrt.Intern(" classes")

var Lit_128 *jrt.String = jrt.Intern("arbace.j2g.main$run$fn__797001043")

var Lit_129 *jrt.String = jrt.Intern(" + ")

var Lit_130 *jrt.String = jrt.Intern("j2g: no edge ")

var Lit_131 *jrt.String = jrt.Intern(" (bin/j2g-edge update, or --jvm-reflection)")

var Lit_132 *jrt.String = jrt.Intern("JRT_CONV")

var Lit_133 *jrt.String = jrt.Intern("jdk/forms")

var Lit_134 *jrt.String = jrt.Intern("/data")

var Lit_135 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$late_QMARK___797000388")

var Lit_136 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$compiled_packages_BANG___797000390")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$wait__797000402")

var Lit_138 *jrt.String = jrt.Intern("arbace")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000404__797000408")

var Lit_140 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000414__797000418")

var Lit_141 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$clj_files__797000424")

var Lit_142 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000428")

var Lit_143 *jrt.String = jrt.Intern("arbace/lang/go")

var Lit_144 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000430")

var Lit_145 *jrt.String = jrt.Intern("overlay/jdk/variants")

var Lit_146 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000436")

var Lit_147 *jrt.String = jrt.Intern(", ")

var Lit_148 *jrt.String = jrt.Intern(" failures")

var Lit_149 *jrt.String = jrt.Intern("go/arbace/jrt")

var Lit_150 *jrt.String = jrt.Intern("java/util/Formatter")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000444")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$in_slice_QMARK___797000446")

var Lit_153 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$jrt_java_QMARK___797000450")

var Lit_154 *jrt.String = jrt.Intern("jdk/internal/jrt/StandardStreams")

var Lit_155 *jrt.String = jrt.Intern("jdk/internal/jrt/CaseInsensitiveComparator")

var Lit_156 *jrt.String = jrt.Intern("java/util/regex/Pattern")

var Lit_157 *jrt.String = jrt.Intern("java/util/concurrent/ExecutorService")

var Lit_158 *jrt.String = jrt.Intern("Formatted_O1__String")

var Lit_159 *jrt.String = jrt.Intern("java/lang/Iterable")

var Lit_160 *jrt.String = jrt.Intern("String_Join_CharSequence_Iterable__String")

var Lit_161 *jrt.String = jrt.Intern("java/util/Optional")

var Lit_162 *jrt.String = jrt.Intern("DescribeConstable__Optional")

var Lit_163 *jrt.String = jrt.Intern("java/io/ByteArrayInputStream")

var Lit_164 *jrt.String = jrt.Intern("GetResourceAsStream_String__InputStream")

var Lit_165 *jrt.String = jrt.Intern("java/util/stream/Stream")

var Lit_166 *jrt.String = jrt.Intern("Lines__Stream")

var Lit_167 *jrt.String = jrt.Intern("String_CASE_INSENSITIVE_ORDER")

var Lit_168 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000454")

var Lit_169 *jrt.String = jrt.Intern("j2g: ")

var Lit_170 *jrt.String = jrt.Intern(" constant VarHandles, on ")

var Lit_171 *jrt.String = jrt.Intern(" fields")

var Lit_172 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000459")

var Lit_173 *jrt.String = jrt.Intern("arbace/lang/RT")

var Lit_174 *jrt.String = jrt.Intern("jdk/internal/jrt/RuntimeExec")

var Lit_175 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000461__797000465")

var Lit_176 *jrt.String = jrt.Intern("java/io/PrintWriter")

var Lit_177 *jrt.String = jrt.Intern("java/io/PrintStream")

var Lit_178 *jrt.String = jrt.Intern("java/util/HashMap")

var Lit_179 *jrt.String = jrt.Intern("java/util/Collections")

var Lit_180 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$slice_QMARK___797000471")

var Lit_181 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000473__797000477")

var Lit_182 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000489")

var Lit_183 *jrt.String = jrt.Intern("/gen")

var Lit_184 *jrt.String = jrt.Intern("/prog")

var Lit_185 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000499__797000503")

var Lit_186 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000509")

var Lit_187 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000511")

var Lit_188 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000513")

var Lit_189 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000515")

var Lit_190 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000517")

var Lit_191 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000519")

var Lit_192 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000521")

var Lit_193 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000523__797000529")

var Lit_194 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000546")

var Lit_195 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000548")

var Lit_196 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000550__797000554")

var Lit_197 *jrt.String = jrt.Intern("j2g_classes.go")

var Lit_198 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000574")

var Lit_199 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000576")

var Lit_200 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000582")

var Lit_201 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000584")

var Lit_202 *jrt.String = jrt.Intern("j2g_cut.go")

var Lit_203 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000586")

var Lit_204 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000588")

var Lit_205 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000590__797000594")

var Lit_206 *jrt.String = jrt.Intern("j2g_init.go")

var Lit_207 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000600__797000604")

var Lit_208 *jrt.String = jrt.Intern("j2g_strings.go")

var Lit_209 *jrt.String = jrt.Intern("j2g_up.go")

var Lit_210 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000610")

var Lit_211 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000612")

var Lit_212 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000618")

var Lit_213 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000620")

var Lit_214 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000622")

var Lit_215 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000624")

var Lit_216 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000626__797000630")

var Lit_217 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000636__797000640")

var Lit_218 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000650")

var Lit_219 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000656")

var Lit_220 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000658__797000662")

var Lit_221 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__797000668")

var Lit_222 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000704")

var Lit_223 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000710")

var Lit_224 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000712__797000716")

var Lit_225 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000734")

var Lit_226 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000744__797000748")

var Lit_227 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000770")

var Lit_228 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000772")

var Lit_229 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000774__797000778")

var Lit_230 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000798__797000802")

var Lit_231 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000812")

var Lit_232 *jrt.String = jrt.Intern("go/arbace/goi.ae")

var Lit_233 *jrt.String = jrt.Intern("/go/arbace/goi.ae")

var Lit_234 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000818")

var Lit_235 *jrt.String = jrt.Intern("go/arbace.ae")

var Lit_236 *jrt.String = jrt.Intern("/go/arbace.ae")

var Lit_237 *jrt.String = jrt.Intern("go/arbace/api.ae")

var Lit_238 *jrt.String = jrt.Intern("/go/arbace/api.ae")

var Lit_239 *jrt.String = jrt.Intern("go/arbace/gotable.ae")

var Lit_240 *jrt.String = jrt.Intern("/go/arbace/gotable.ae")

var Lit_241 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000824")

var Lit_242 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000826__797000830")

var Lit_243 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000842__797000846")

var Lit_244 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000862")

var Lit_245 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000870")

var Lit_246 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$go_names__797000872")

var Lit_247 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000876")

var Lit_248 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000878")

var Lit_249 *jrt.String = jrt.Intern("/go/arbace/jrt.ae")

var Lit_250 *jrt.String = jrt.Intern("arbace/jrt")

var Lit_251 *jrt.String = jrt.Intern("\n")

var Lit_252 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000880__797000884")

var Lit_253 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000894__797000898")

var Lit_254 *jrt.String = jrt.Intern("/go/arbace/")

var Lit_255 *jrt.String = jrt.Intern(".ae")

var Lit_256 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000910__797000914")

var Lit_257 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000920__797000924")

var Lit_258 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000936__797000940")

var Lit_259 *jrt.String = jrt.Intern("/program.edn")

var Lit_260 *jrt.String = jrt.Intern("{:module \"arbace\" :go \"1.27\"}\n")

var Lit_261 *jrt.String = jrt.Intern("/namespaces.txt")

var Lit_262 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000946__797000950")

var Lit_263 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/res")

var Lit_264 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000962__797000966")

var Lit_265 *jrt.String = jrt.Intern("arbace/classes/generics.edn")

var Lit_266 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000983__797000987")

var Lit_267 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace.ae")

var Lit_268 *jrt.String = jrt.Intern(";; Generated by j2g --program (J2G-SPEC §10.6): the program's main package.\n")

var Lit_269 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/res/.build-go-data")

var Lit_270 *jrt.String = jrt.Intern("The main package's embedded sources (j2g --program): data, not Go forms.\n")

var Lit_271 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/main.ae")

var Lit_272 *jrt.String = jrt.Intern(";; Generated by j2g --program (J2G-SPEC §10.6).\n(in-ns 'go.arbace.cmd.arbace)\n\n")

var Lit_273 *jrt.String = jrt.Intern("\n\n")

var Lit_274 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image.ae")

var Lit_275 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/")

var Lit_276 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image_types.ae")

var Lit_277 *jrt.String = jrt.Intern(";; Generated by j2g --program: the program's struct types, by name (EXEC-NOTES.md).\n")

var Lit_278 *jrt.String = jrt.Intern("(in-ns 'go.arbace.cmd.arbace)\n\n")

var Lit_279 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image.bin")

var Lit_280 *jrt.String = jrt.Intern("")

var Lit_281 *jrt.String = jrt.Intern("/report.edn")

var Lit_282 *jrt.String = jrt.Intern("j2g: steps (s): ")

var Lit_283 *jrt.String = jrt.Intern(" (")

var Lit_284 *jrt.String = jrt.Intern(" jobs)")

var Lit_285 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797001019__797001023")

var Lit_286 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$clj_files__797000424$fn__797000425")

var Lit_287 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$compiled_packages_BANG___797000390$iter__797000391__797000395")

var Lit_288 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$compiled_packages_BANG___797000390$iter__797000391__797000395$fn__797000396")

var Lit_289 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$compiled_packages_BANG___797000390$iter__797000391__797000395$fn__797000396$fn__797000397")

var Lit_290 *jrt.String = jrt.Intern("packages.edn")

var Lit_291 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000489$fn__797000490")

var Lit_292 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000489$fn__797000492")

var Lit_293 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000489$fn__797000494")

var Lit_294 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000489$fn__797000494$fn__797000495")

var Lit_295 *jrt.String = jrt.Intern("j2g_lambdas.go")

var Lit_296 *jrt.String = jrt.Intern("j2g_frames.go")

var Lit_297 *jrt.String = jrt.Intern("j2g_start.go")

var Lit_298 *jrt.String = jrt.Intern("j2g_support.go")

var Lit_299 *jrt.String = jrt.Intern("reflect_tables_j2g.go")

var Lit_300 *jrt.String = jrt.Intern("Go name ")

var Lit_301 *jrt.String = jrt.Intern("declared more than once in ")

var Lit_302 *jrt.String = jrt.Intern("j2g: error: Go name ")

var Lit_303 *jrt.String = jrt.Intern(" declared more than once in package ")

var Lit_304 *jrt.String = jrt.Intern("package-private, redeclared by ")

var Lit_305 *jrt.String = jrt.Intern(" in another package (J2G-SPEC §4.4: rename table)")

var Lit_306 *jrt.String = jrt.Intern("j2g: error: package-private ")

var Lit_307 *jrt.String = jrt.Intern(" is redeclared by ")

var Lit_308 *jrt.String = jrt.Intern(" in another Java package; Go would override it")

var Lit_309 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000734$fn__797000736")

var Lit_310 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__797000734$fn__797000741")

var Lit_311 *jrt.String = jrt.Intern("/go/arbace/jrt/")

var Lit_312 *jrt.String = jrt.Intern("go/arbace/goi")

var Lit_313 *jrt.String = jrt.Intern("/go/arbace/goi/")

var Lit_314 *jrt.String = jrt.Intern("go/arbace/gotable")

var Lit_315 *jrt.String = jrt.Intern("/go/arbace/gotable/")

var Lit_316 *jrt.String = jrt.Intern("_test")

var Lit_317 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$go_names__797000872$fn__797000873")

var Lit_318 *jrt.String = jrt.Intern(".go")

var Lit_319 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$in_slice_QMARK___797000446$fn__797000447")

var Lit_320 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000404__797000408$fn__797000409")

var Lit_321 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000404__797000408$fn__797000409$fn__797000410")

var Lit_322 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000414__797000418$fn__797000419")

var Lit_323 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000414__797000418$fn__797000419$fn__797000420")

var Lit_324 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000461__797000465$fn__797000466")

var Lit_325 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000461__797000465$fn__797000466$fn__797000467")

var Lit_326 *jrt.String = jrt.Intern("exec")

var Lit_327 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000473__797000477$fn__797000478")

var Lit_328 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000473__797000477$fn__797000478$fn__797000479")

var Lit_329 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000499__797000503$fn__797000504")

var Lit_330 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000499__797000503$fn__797000504$fn__797000505")

var Lit_331 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000523__797000529$fn__797000530")

var Lit_332 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000523__797000529$fn__797000530$iter__797000525__797000534")

var Lit_333 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000523__797000529$fn__797000530$iter__797000525__797000534$fn__797000535")

var Lit_334 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000523__797000529$fn__797000530$iter__797000525__797000534$fn__797000535$fn__797000536")

var Lit_335 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000550__797000554$fn__797000555")

var Lit_336 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000550__797000554$fn__797000555$fn__797000556")

var Lit_337 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000590__797000594$fn__797000595")

var Lit_338 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000590__797000594$fn__797000595$fn__797000596")

var Lit_339 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000600__797000604$fn__797000605")

var Lit_340 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000600__797000604$fn__797000605$fn__797000606")

var Lit_341 *jrt.String = jrt.Intern("_Init")

var Lit_342 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000626__797000630$fn__797000631")

var Lit_343 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000626__797000630$fn__797000631$fn__797000632")

var Lit_344 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000636__797000640$fn__797000641")

var Lit_345 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000636__797000640$fn__797000641$fn__797000642")

var Lit_346 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000658__797000662$fn__797000663")

var Lit_347 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000658__797000662$fn__797000663$fn__797000664")

var Lit_348 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000712__797000716$fn__797000717")

var Lit_349 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000712__797000716$fn__797000717$fn__797000718")

var Lit_350 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000744__797000748$fn__797000749")

var Lit_351 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000744__797000748$fn__797000749$fn__797000750")

var Lit_352 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000774__797000778$fn__797000779")

var Lit_353 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000774__797000778$fn__797000779$fn__797000780")

var Lit_354 *jrt.String = jrt.Intern("standin_")

var Lit_355 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000774__797000778$fn__797000779$fn__797000792")

var Lit_356 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000774__797000778$fn__797000779$fn__797000780$fn__797000784")

var Lit_357 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000774__797000778$fn__797000779$fn__797000780$fn__797000784$fn__797000785")

var Lit_358 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000774__797000778$fn__797000779$fn__797000792$fn__797000793")

var Lit_359 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000798__797000802$fn__797000803")

var Lit_360 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000798__797000802$fn__797000803$fn__797000804")

var Lit_361 *jrt.String = jrt.Intern("_test.ae")

var Lit_362 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000826__797000830$fn__797000831")

var Lit_363 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000826__797000830$fn__797000831$fn__797000832")

var Lit_364 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000842__797000846$fn__797000847")

var Lit_365 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000842__797000846$fn__797000847$fn__797000848")

var Lit_366 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000880__797000884$fn__797000885")

var Lit_367 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000880__797000884$fn__797000885$fn__797000886")

var Lit_368 *jrt.String = jrt.Intern("jrt/")

var Lit_369 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000894__797000898$fn__797000899")

var Lit_370 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000894__797000898$fn__797000899$fn__797000900")

var Lit_371 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000910__797000914$fn__797000915")

var Lit_372 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000910__797000914$fn__797000915$fn__797000916")

var Lit_373 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000920__797000924$fn__797000925")

var Lit_374 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000920__797000924$fn__797000925$fn__797000926")

var Lit_375 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000936__797000940$fn__797000941")

var Lit_376 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000936__797000940$fn__797000941$fn__797000942")

var Lit_377 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000946__797000950$fn__797000951")

var Lit_378 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000946__797000950$fn__797000951$fn__797000952")

var Lit_379 *jrt.String = jrt.Intern("arbace/")

var Lit_380 *jrt.String = jrt.Intern("-")

var Lit_381 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000962__797000966$fn__797000967")

var Lit_382 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000962__797000966$fn__797000967$fn__797000968")

var Lit_383 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000962__797000966$fn__797000967$fn__797000978")

var Lit_384 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000962__797000966$fn__797000967$fn__797000968$fn__797000972")

var Lit_385 *jrt.String = jrt.Intern("UTF-8")

var Lit_386 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000983__797000987$fn__797000988")

var Lit_387 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000983__797000987$fn__797000988$fn__797000989")

var Lit_388 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000983__797000987$fn__797000988$fn__797000999")

var Lit_389 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797000983__797000987$fn__797000988$fn__797000989$fn__797000993")

var Lit_390 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797001019__797001023$fn__797001024")

var Lit_391 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__797001019__797001023$fn__797001024$fn__797001025")

var Lit_392 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__797000668$fn__797000669")

var Lit_393 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__797000668$iter__797000671__797000675")

var Lit_394 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__797000668$iter__797000687__797000691")

var Lit_395 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__797000668$iter__797000671__797000675$fn__797000676")

var Lit_396 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__797000668$iter__797000671__797000675$fn__797000676$fn__797000677")

var Lit_397 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__797000668$iter__797000687__797000691$fn__797000692")

var Lit_398 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__797000668$iter__797000687__797000691$fn__797000692$fn__797000693")

var Lit_399 *jrt.String = jrt.Intern("aot.edn")

var Lit_400 *jrt.String = jrt.Intern(" ready after ")

var Lit_401 *jrt.String = jrt.Intern(" s")

var Lit_402 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__797000096__797000100")

var Lit_403 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__797000106__797000112")

var Lit_404 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__797000096__797000100$fn__797000101")

var Lit_405 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__797000096__797000100$fn__797000101$fn__797000102")

var Lit_406 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__797000106__797000112$fn__797000113")

var Lit_407 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__797000106__797000112$fn__797000113$iter__797000108__797000114")

var Lit_408 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__797000106__797000112$fn__797000113$iter__797000108__797000114$fn__797000115")

var Lit_409 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__797000106__797000112$fn__797000113$iter__797000108__797000114$fn__797000115$fn__797000116")

var Lit_410 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__797000237")

var Lit_411 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__797000244")

var Lit_412 *jrt.String = jrt.Intern("J2G_CLASS_TIMES")

var Lit_413 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__797000250")

var Lit_414 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__797000259")

var Lit_415 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__797000237$fn__797000241")

var Lit_416 *jrt.String = jrt.Intern("j2g: class time")

var Lit_417 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$fn__797000167")

var Lit_418 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__797000172__797000176")

var Lit_419 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__797000172__797000176$fn__797000177")

var Lit_420 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__797000172__797000176$fn__797000177$fn__797000178")

var Lit_421 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__797000172__797000176$fn__797000177$fn__797000188")

var Lit_422 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__797000172__797000176$fn__797000177$fn__797000178$fn__797000182")

var Lit_423 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn4,linekn6,columnkn4,fileyn2,t0yn4,argsyn1,syn3,diryn4,scanyn8,manifestkn3,tagyn6,Stringyn4,specyn1,Tyn1,fyn4,formyn8,names-reyn6,own-reyn5,formsyn2,gsyn4,textyn4,fromyn2,toyn1,pyn5,bytesyn2,psyn8,embeddedyn8,gotable?yn5,worldyn3,pkgyn3,topyn3,tagyn1,iyn1,nyn6,catch?yn1,ryn7,renamesyn2,nsyn7,file-ofyn7,cost-ofyn9,pkgstatesyn5,filesyn6,errorsyn2,rsyn11,pkg-classesyn6,reportyn4,optsyn1,&v11,arbace.core5,in-nsMyn15,arbace.j2g.mainm2,R0,s2981,bin/j2g: Java forms to Go forms (doc/go/J2G-SPEC.md, doc/go/J2G-NOTES.md).\n\n  bin/j2g [OPTIONS]\n    --out DIR          output directory (default .tmp/j2g/out): DIR/gen/go/... the generated\n                       forms (J2G-SPEC §4.3: the files j2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/build-go; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of Java forms files (test fixtures; a tree with a\n                       packages.edn: the compiled namespaces, arbace.c2j, entered in the second\n                       round of the load, w/load-world)\n    --await DIR        --input DIR, read once DIR/aot.edn exists (j2g meanwhile loads and\n                       starts analyzing the other inputs; bin/arbace-go starts j2g while the\n                       host compiles the namespaces into DIR); the output is --input DIR's\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (J2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       j2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/build-go --line-file DIR/prog\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): j2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/j2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)m2,R0,s2981,bin/j2g: Java forms to Go forms (doc/go/J2G-SPEC.md, doc/go/J2G-NOTES.md).\n\n  bin/j2g [OPTIONS]\n    --out DIR          output directory (default .tmp/j2g/out): DIR/gen/go/... the generated\n                       forms (J2G-SPEC §4.3: the files j2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/build-go; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of Java forms files (test fixtures; a tree with a\n                       packages.edn: the compiled namespaces, arbace.c2j, entered in the second\n                       round of the load, w/load-world)\n    --await DIR        --input DIR, read once DIR/aot.edn exists (j2g meanwhile loads and\n                       starts analyzing the other inputs; bin/arbace-go starts j2g while the\n                       host compiles the namespaces into DIR); the output is --input DIR's\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (J2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       j2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/build-go --line-file DIR/prog\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): j2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/j2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)R1,v15,arbace.j2g.main3,nowm10,R2,TR3,L1,V0,R4,i64,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main4,secsm10,R2,TR3,L1,V1,R7,R4,i65,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,parse-argsm8,R3,L1,V1,R8,R4,i67,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main8,internalm10,R2,TR3,L1,V1,R9,R4,i96,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,manifest-classesm10,R3,L1,V1,R10,R0,s55,The classes the jrt manifest declares (internal names).R4,i98,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main11,jrt-classesm10,R3,L1,V2,R11,R12,R0,s81,jrt's classes: those its forms register (Define) and those its manifest declares.R4,i106,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main13,repl-visible?m12,R2,TR3,L1,V1,Myn1,nm2,R13,R14,R0,s443,Can the REPL name class n's public members (internal name)? Not when n is in a JDK module's\n  package that the module does not export (jdk.internal.misc, sun.nio.cs ...): the JVM refuses\n  such access from Clojure code (IllegalAccessError), so the Go build's REPL world does not root\n  them (J2G-SPEC §10.6; JRT-NOTES.md, \"The JDK's resource data\", amendment RD2). Classes of no\n  JDK module (Arbace's, jrt's own jdk.internal.jrt) are visible.R4,i114,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main12,bundle-rootsm12,R2,TR3,L1,V0,R0,s251,The public no-argument constructors of the world's concrete ResourceBundle subclasses:\n  ResourceBundle.getBundle makes its bundles by reflection (overlay/jdk's ResourceBundle;\n  javac's messages, doc/classes/JAVA-FRONTEND-SURVEY.md, \"As built: JN2\").R4,i126,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main9,root-keysm12,R2,TR3,L1,V1,R15,R0,s115,Method keys of a root spec. CLASS$* is the class and every named class nested in it (the\n  whole of Compiler, say).R4,i143,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main13,lazy-standinsS2,s16,java/util/Locales25,java/util/Locale$Categorym8,R4,i163,R5,i1,R6,s18,arbace/j2g/main.aeR0,s335,Replaced stand-ins initialized on first use like any translated class, not eagerly: jrt's\n  hand-written code (but its tests) reads none of their statics, and their initialization needs\n  much of the program initialized first (Locale's: its constants, the default locale from the\n  system properties; JRT-NOTES.md, \"Text and locales\").v15,arbace.j2g.main13,standin-rootsm10,R3,L1,V2,R11,R16,R0,s153,Roots for the translated classes that replace jrt's stand-ins: their static initializer\n  and the members the stand-in defined (jrt's code may use them).R4,i170,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,form-namesm12,R2,TR3,L1,V1,R17,R0,s41,Go identifiers a top-level form declares.R4,i194,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,method-recv-typem10,R2,TR3,L1,V1,R17,R4,i205,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main9,mentions?m10,R2,TR3,L1,V2,R18,R19,R4,i213,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,filter-init-bodym10,R2,TR3,L1,V2,R17,R20,R4,i222,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,filter-standins*m8,R3,L1,V2,R21,R22,R4,i226,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main6,write!m10,R2,TR3,L1,V2,R17,R23,R4,i257,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,copy-file!m10,R2,TR3,L1,V2,R24,R25,R4,i261,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main13,resource-filem12,R2,TR3,L1,V2,R26,Myn1,bm2,R13,R27,R0,s253,The embedded resource p (bytes b) as it is written: as p.z, zlib-compressed, when that saves\n  a quarter or more (the sources, generics.edn, tzdb.dat), else as it is; jrt's OSHost.Resource\n  inflates a p.z when asked for p (amendment SZ2). [name bytes].R4,i265,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,write-resources!m12,R2,TR3,L1,V2,R10,R28,R0,s157,Writes the embedded resources ps ([path bytes-fn] in order) under dir, compressed in\n  parallel (resource-file), written in order. Returns the names written.R4,i273,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main6,top-ofm10,R2,TR3,L1,V1,Myn1,nm2,R13,R14,R4,i285,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main21,program-package-formsm12,R2,TR3,L1,V1,R29,R0,s87,The main package: main.go and the embedded sources (res/..., EVAL-NOTES.md, \"Loading\").R4,i287,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main18,program-main-formsm12,R2,TR3,L1,V1,R30,R0,s568,main: first rlwrap for an interactive REPL (execRlwrap, which replaces the process when it\n  applies), then the system property arbace.version from arbaceVersion (when the link set it),\n  then jrt's host for the build's system (jrt.ProgramHost: OSHost, or the box's on TamaGo,\n  doc/go/BOX-NOTES.md),\n  then the command line as a String[], then arbace.lang.Main.main inside jrt.RunMain\n  (the thread main, uncaught exceptions printed as the JVM prints them, status 1), its status\n  the process's. With gotable?, the main package imports goi's table (its registration).R4,i299,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,source-topm12,R2,TR3,L1,V3,R31,R32,R33,R0,s228,The name a Go file is named after (§4.3): in arbace/lang the Java forms file of top-level\n  class top (FxClasses for the classes of FxClasses.ae, so that --line-file positions name\n  it), in jrt the class (its Java source path).R4,i337,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main5,apartm12,R2,TR3,L1,V5,R34,R35,R36,R17,R37,R0,s456,Runs f (forms of class n, the i-th of its kind, tag naming the kind) on its own, with the\n  effects the sequential run has on the package's state recorded rather than applied: its\n  literals named apart (Lit?<tag><i>_k, in first-use order), what it conj'ed into the\n  package's ups, lambdas and cuts and into the races, in order, and its printed output. With\n  catch?, an exception is the result's :error [n message] (a translation's), else it is\n  thrown.R4,i350,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main12,merge-apart!m12,R2,TR3,L1,V3,R38,R28,R39,R0,s354,Applies to the package state ps (and c/*races*) what result r of apart recorded, as the\n  sequential run would have done it: its printed output, its conj's replayed one by one, its\n  literals named in the package's pool (Lit_n, numbered in order of first use; one an earlier\n  class used keeps its name). Returns renames with r's literals' renames added.R4,i376,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main17,translate-classesm10,R3,L1,V6,R40,R41,R42,R43,R44,R45,R0,s441,Translates the classes ns (in order) in parallel (jobs threads), each apart, and merges what\n  each did, in their order, as the sequential translation would have done it class after\n  class (merge-apart!): the forms into files ([pkg go-file] -> forms; file-of gives a\n  class's), its errors into errors. cost-of estimates a class's translation time (the\n  costliest start first). Returns the renames of the classes' literals (out/*renames*).R4,i400,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main20,merge-registrations!m12,R2,TR3,L1,V2,R46,R28,R0,s132,Merges the registrations' results rs, in order, into the package state ps (as\n  translate-classes). Returns their literals' renames.R4,i426,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main18,registration-formsm12,R2,TR3,L1,V2,R32,R46,R0,s78,The forms of j2g_classes.go of package pkg from its classes' registrations rs.R4,i432,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main13,registrationsm10,R3,L1,V1,R47,R0,s307,The forms of j2g_classes.go of each package pkg of pkg-classes ([pkg classes], in order;\n  out/class-registration of each class, in order), the classes of all the packages in\n  parallel, each apart. Returns [pkg forms results], whose results merge-registrations! merges\n  into the package's state, in order.R4,i448,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main12,default-edgem6,R4,i462,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,report-strm12,R2,TR3,L1,V1,R48,R0,s243,report.edn's text: the map a key per line, a map or vector with more than one element an\n  element per line, the rest as pr-str prints it (arbace.pprint took half a minute on the\n  program's report, on the critical path at the end of the run).R4,i464,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main4,run*m10,R3,L1,V1,R49,R0,s46,j2g's run, in the class environment run binds.R4,i478,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main8,id-floorl100000,m8,R4,i971,R5,i1,R6,s18,arbace/j2g/main.aeR0,s483,Where the runtime's id counter (RT/nextID, gensym's) stands when j2g's run starts. The\n  analyzer and the translator name temporaries by it (arr_100417), so j2g first advances it to\n  this fixed value: its output then depends on its inputs, not on how much code the running\n  Arbace compiled before (j2g's own namespaces load from source, and on the Go executable in\n  other amounts than on the JVM). A round value well above what loading j2g takes\n  (doc/STANDALONE-NOTES.md, SA13).v15,arbace.j2g.main12,advance-ids!m12,R2,TR3,L1,V0,R0,s84,Advances the runtime's id counter to id-floor (an error when it is past it already).R4,i980,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main3,runm10,R3,L1,V1,R49,R0,s369,j2g's run (bin/j2g's options as parse-args gives them). The classes outside the forms come\n  from the edge (--edge, default jdk/edge.edn: doc/STANDALONE-NOTES.md, S2), without the JVM's\n  reflection or ASM; --record-edge FILE: from the JVM's reflection, writing the edge of what\n  this run asked into FILE; --jvm-reflection: from the JVM's reflection (the edge unused).R4,i989,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main5,-mainm8,R3,L1,V2,R50,R8,R4,i1023,R5,i1,R6,s18,arbace/j2g/main.ae")

var Lit_424 *jrt.String = jrt.Intern("arbace.j2g.main$eval797000004$loading__1927001464__auto____797000005")

var Lit_425 *jrt.String = jrt.Intern("arbace.j2g.main$eval797000008$fn__797000009")

var Lit_426 *jrt.String = jrt.Intern("arbace.j2g.main$now")

var Lit_427 *jrt.String = jrt.Intern("arbace.j2g.main$secs")

var Lit_428 *jrt.String = jrt.Intern("arbace.j2g.main$parse_args")

var Lit_429 *jrt.String = jrt.Intern("arbace.j2g.main$internal")

var Lit_430 *jrt.String = jrt.Intern("arbace.j2g.main$manifest_classes")

var Lit_431 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes")

var Lit_432 *jrt.String = jrt.Intern("arbace.j2g.main$repl_visible_QMARK_")

var Lit_433 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots")

var Lit_434 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys")

var Lit_435 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots")

var Lit_436 *jrt.String = jrt.Intern("arbace.j2g.main$form_names")

var Lit_437 *jrt.String = jrt.Intern("arbace.j2g.main$method_recv_type")

var Lit_438 *jrt.String = jrt.Intern("arbace.j2g.main$mentions_QMARK_")

var Lit_439 *jrt.String = jrt.Intern("arbace.j2g.main$filter_init_body")

var Lit_440 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_")

var Lit_441 *jrt.String = jrt.Intern("arbace.j2g.main$write_BANG_")

var Lit_442 *jrt.String = jrt.Intern("arbace.j2g.main$copy_file_BANG_")

var Lit_443 *jrt.String = jrt.Intern("arbace.j2g.main$resource_file")

var Lit_444 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_")

var Lit_445 *jrt.String = jrt.Intern("arbace.j2g.main$top_of")

var Lit_446 *jrt.String = jrt.Intern("arbace.j2g.main$program_package_forms")

var Lit_447 *jrt.String = jrt.Intern("arbace.j2g.main$program_main_forms")

var Lit_448 *jrt.String = jrt.Intern("arbace.j2g.main$source_top")

var Lit_449 *jrt.String = jrt.Intern("arbace.j2g.main$apart")

var Lit_450 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_")

var Lit_451 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes")

var Lit_452 *jrt.String = jrt.Intern("arbace.j2g.main$merge_registrations_BANG_")

var Lit_453 *jrt.String = jrt.Intern("arbace.j2g.main$registration_forms")

var Lit_454 *jrt.String = jrt.Intern("arbace.j2g.main$registrations")

var Lit_455 *jrt.String = jrt.Intern("jdk/edge.edn")

var Lit_456 *jrt.String = jrt.Intern("arbace.j2g.main$report_str")

var Lit_457 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_")

var Lit_458 *jrt.String = jrt.Intern("arbace.j2g.main$advance_ids_BANG_")

var Lit_459 *jrt.String = jrt.Intern("arbace.j2g.main$run")

var Lit_460 *jrt.String = jrt.Intern("arbace.j2g.main$_main")
