//line j2g_strings.ae:1
package aot_arbace_j2g_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.worldyn1,wyn14,arbace.j2g.jrtyn3,jrtyn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn16,arbace.j2g.reachyn1,ryn17,arbace.j2g.accessyn3,accyn15,arbace.j2g.codeyn1,cyn13,arbace.j2g.vhyn2,vhyn16,arbace.j2g.declsyn1,dyn14,arbace.j2g.outyn3,outyn14,arbace.j2g.dynyn3,dynyn16,arbace.j2g.dyncfyn5,dyncfyn17,arbace.j2g.fromfnyn6,fromfnyn17,arbace.j2g.checksyn3,chkyn16,arbace.j2g.embedyn5,embedyn15,arbace.j2g.edgeyn4,edgeyn15,arbace.j2g.zlibyn4,zlibyn15,arbace.j2g.metayn4,metayn20,arbace.repr.go.printyn2,gpyn11,arbace.corekn3,dockn3,outkn5,slicekn5,rootskn6,inputskn11,record-edgekn12,variant-dirskn7,gotablekn14,jvm-reflectionkn5,testskn9,resourceskn3,jdkkn5,entrykn10,entry-argskn7,programkn9,own-rootskn12,analyze-onlykn5,embedkn5,mainskn5,edgeskn15,java-namespaceskn10,propertieskn4,langkn8,provideskn7,qualifykn5,awaitkn2,gokn3,varkn7,standinkn4,filekn7,classeskn10,unexportedys14,arbace.j2g.jvm11,unexported?kn4,elsekn5,superkn5,flagskn4,namekn4,desckn7,methodskn5,orderkn11,jrt-classeskn5,fileskn5,funcskn3,tagyn1,*yn4,inityn2,nsyn20,go.arbace.cmd.arbacekn7,requireyn9,arbace.goyn2,gokn4,linekn6,columnyn4,loadys2,go7,packageyn4,mainkn4,pathkn11,embed-filesys3,jrt40,System_SetProperty_String_String__Stringys3,jrt3,Strys2,go4,funcyn4,whenyn2,!=yn13,arbaceVersionyn3,letyn6,valuesyn3,subyn3,errys2,fs3,Subyn9,resourcesyn2,==ys3,jrt7,SetHostys3,jrt11,ProgramHostyn10,setupImageyn9,imageDatayn4,argsys3,jrt11,NewRefArrayys3,jrt12,String_classyn4,convyn5,int32yn1,+yn1,-yn3,lenys2,os4,Argsyn4,asetyn3,.-Ayn5,rangeyn1,iyn8,subsliceyn11,finishImageys2,os4,Exityn6,statusys3,jrt7,RunMainyn2,fnys2,go3,varks2,go5,embedys5,embed2,FSyn6,stringyn10,execRlwrapys4,lang20,Main_Main_String1__Vys2,go4,filekn7,importsyn2,fsyn2,osyn4,langyn1,_kn3,jrtkn9,source-ofkn4,litskn10,lit-prefixkn3,upskn7,lambdaskn4,cutskn5,formskn5,errorkn5,raceskn4,secskn6,simplekn7,effectsys3,j2g9,code-declyn7,j2gCodeyn5,sliceyn3,lityn14,j2gCodeDefinedyn4,boolkn11,compile-setkn4,varskn4,scankn9,in-slice?kn9,jrt-java?kn10,formatter?kn8,streams?kn9,ci-order?kn6,regex?kn12,fjp-support?kn12,program-metakn8,metadatakn6,rootedkn8,serviceskn11,conditionalkn5,siteskn6,absentkn6,failedkn10,meta-rootskn9,root-keyskn17,analysis-failureskn8,variantskn5,timeskn4,loadkn2,opkn5,statekn6,bodieskn6,clinitkn4,initkn1,Tkn14,vmethods-cachekn13,trivial-cachekn6,erasedkn7,missingkn4,unitkn11,from-sourcekn12,bad-serviceskn3,badkn15,metadata-errorskn6,errorskn11,user-ownerskn18,services-bad-lineskn14,metadata-rootskn16,reflective-siteskn12,roots-absentkn8,embeddedkn14,cut-candidateskn13,embedded-datakn4,rootkn4,dirskn4,treekn13,variant-fileskn11,late-inputskn4,waitkn8,replacedkn3,cutkn5,addedkn2,vhkn7,handleskn6,fieldskn7,root-fnkn6,slice?kn3,fiskn4,instkn14,subclass-indexkn7,reachedkn11,unavailablekn3,pkgkn7,sourceskn6,methodkn9,hidden-bykn5,worldkn26,methods-with-missing-partskn10,translatedkn17,replaced-standinskn7,refusedkn14,failed-classeskn15,race-candidateskn25,package-private-overridesks15,arbace.j2g.main5,timeskn3,dynkn6,fromfnkn8,adapterskn13,registrationskn5,typeskn8,packageskn10,collisionskn9,overrideskn6,checkskn5,textskn9,generatedkn12,hand-writtenyn13,go.arbace.jrtkn10,test-fileskn5,afterkn11,image-typeskn8,prog-dirkn3,reskn5,reachkn9,translatekn5,writekn5,stepsv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,V3,R17,R1,R18,V3,R19,R1,R20,V3,R21,R1,R22,V3,R23,R1,R24,V3,R25,R1,R26,V3,R27,R1,R28,V3,R29,R1,R30,V3,R31,R1,R32,V3,R33,R1,R34,V3,R35,R1,R36,V3,R37,R1,R38,V3,R39,R1,R40,V3,R41,R1,R42,V3,R43,R1,R44,V3,R45,R1,R46,V3,R47,R1,R48,v11,arbace.core5,referR49,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.j2g.mainm2,R50,s5362,bin/j2g: Java forms to Go forms (doc/go/J2G-SPEC.md, doc/go/J2G-NOTES.md).\n\n  bin/j2g [OPTIONS]\n    --out DIR          output directory (default .tmp/j2g/out): DIR/gen/go/... the generated\n                       forms (J2G-SPEC §4.3: the files j2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/build-go; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of Java forms files (test fixtures; a tree with a\n                       packages.edn: the compiled namespaces, arbace.c2j, entered in the second\n                       round of the load, w/load-world)\n    --await DIR        --input DIR, read once DIR/aot.edn exists (j2g meanwhile loads and\n                       starts analyzing the other inputs; bin/arbace-go starts j2g while the\n                       host compiles the namespaces into DIR); the output is --input DIR's\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (J2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       j2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/build-go --line-file DIR/prog\n    --entry CLASS      with --program, the main package's main calls CLASS's static\n                       main(String[]) (a root) in place of arbace.lang.Main's: a Java forms\n                       program (bin/arbace-go --build-program, REAP7); no rlwrap\n    --entry-arg ARG    with --program, ARG put before the command line's arguments\n                       (repeated, in order): -m NS for a namespace's -main; no rlwrap\n    --property K=V     with --program, the system property K set to V at the start, before\n                       any class of the program is initialized (repeated, in order; a later\n                       K wins): a program's properties as data (program.edn :properties,\n                       A13 of the Ghidra case study's G1 plan, J2G-SPEC §10.6)\n    --resources DIR[=PREFIX]\n                       with --program, every file under DIR embedded too, at its path relative\n                       to DIR (after PREFIX/ when given), as a directory of the class path: a\n                       user's namespaces (.ae, .clj, .cljc) join the embedded sources, other\n                       files the resource data (bin/arbace-go --build-program, REAP7)\n    --own-roots all|entry\n                       with --program, the program's own classes (nm/own-class?: a user's Java\n                       forms) rooted every member (all, the default: the REPL's world) or only\n                       from the entry, the services, the metadata and the constant reflective\n                       sites (entry; J2G-SPEC §4.1, Roots from a program's metadata)\n    --provides FILE    the world's module provides (default jdk/provides.txt beside --jdk's\n                       forms: bin/jrt provides), the service registry's first providers\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): j2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/j2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)\n    --analyze-only     the world loaded and analyzed (w/load-world), nothing reached,\n                       translated or written but DIR/report.edn: :analyze-only true, :files,\n                       :classes (analyzed), :analysis-failures (as a translation's report has\n                       them), :variants, :times {:load s}; each failure printed (j2g: analysis\n                       failure CLASS: MSG). No --program embedding. The day's light measurement\n                       of what the analysis refuses (J2G-SPEC §4.1, The analysis alone;\n                       JCS265 (b)): jdk/forms and a batch of tests within 2 GiBv11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,nextR51,R52,R53,R54,v11,arbace.core7,ex-infov11,arbace.core4,restv11,arbace.core5,assocR55,v11,arbace.core6,updateR56,v11,arbace.core4,fnilR57,R58,R59,R60,R61,R62,R63,R64,R65,v11,arbace.core7,keywordR66,R67,R68,R69,R70,v11,arbace.core6,pr-strR71,v11,arbace.core4,subsl0,R72,R73,R74,R75,v11,arbace.core10,re-patternv13,arbace.string7,replacev14,arbace.java.io4,filev11,arbace.core3,setv11,arbace.core3,mapv15,arbace.j2g.main8,internalv11,arbace.core3,strv11,arbace.core4,keysv16,arbace.j2g.world10,read-formsv11,arbace.core5,mergev11,arbace.core4,intov11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR76,v16,arbace.j2g.names13,go-class-nameR77,R78,R79,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consR80,v15,arbace.j2g.main17,repl-exports-filev13,arbace.string4,trimp4,#.*$p7,^[^/]*/v13,arbace.string11,split-linesv11,arbace.core5,slurpc47,c46,v16,arbace.j2g.names10,qualified?v11,arbace.core9,contains?v15,arbace.j2g.main13,repl-exportedv11,arbace.core3,notv15,arbace.j2g.edge4,jvm?R81,v11,arbace.core17,requiring-resolveR82,R83,R84,v22,arbace.classes.analyze4,declv11,arbace.core4,not=v16,arbace.j2g.model4,has?R85,l512,l1024,v11,arbace.core4,someR86,R87,l1,R88,v11,arbace.core4,sortR89,v22,arbace.classes.analyze6,*unit*v13,arbace.string10,ends-with?v11,arbace.core6,mapcatv15,arbace.j2g.main9,root-keysv11,arbace.core6,filterv13,arbace.string12,starts-with?v11,arbace.core7,re-findp4,\\$\\dv13,arbace.string5,splitp1,#l2,v11,arbace.core6,concatl4,l8,v16,arbace.j2g.names10,own-class?R90,v16,arbace.j2g.model3,*w*v16,arbace.j2g.model7,go-namev11,arbace.core6,get-inR91,R92,v16,arbace.j2g.names8,new-namev22,arbace.classes.analyze14,ctor-real-descv16,arbace.j2g.model7,static?v16,arbace.j2g.names11,method-basev11,arbace.core4,seq?v11,arbace.core7,symbol?v11,arbace.core4,namev11,arbace.core6,secondv11,arbace.core7,vector?v11,arbace.core4,dropR93,R94,v11,arbace.core9,volatile!v11,arbace.core10,re-matchesv11,arbace.core7,vreset!v11,arbace.core5,coll?v11,arbace.core4,run!v11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core6,removev15,arbace.j2g.main9,mentions?v11,arbace.core6,empty?v13,arbace.string4,joinv11,arbace.core5,some?v15,arbace.j2g.main16,method-recv-typeS4,s4,funcs3,vars5,consts4,typev15,arbace.j2g.main10,form-namesS3,s3,vars5,consts4,typev11,arbace.core7,string?v11,arbace.core3,vecR95,v15,arbace.j2g.main16,filter-init-bodyv11,arbace.core4,spitv14,arbace.java.io12,make-parentsv14,arbace.java.io4,copyv15,arbace.j2g.zlib7,deflatev16,arbace.j2g.model8,par-mapvv16,arbace.j2g.model4,jobsv15,arbace.j2g.main13,resource-filev11,arbace.core5,doallML3,R96,R97,ML2,R98,V3,R99,R1,R100,m4,R101,i359,R102,i30,m4,R101,i359,R102,i5,ML2,R103,s12,arbace/imagem4,R101,i362,R102,i5,ML2,R103,s18,arbace/image_typesm4,R101,i363,R102,i5,ML2,R103,s11,arbace/mainm4,R101,i364,R102,i5,ML2,R103,s19,arbace/rlwrap_linuxm4,R101,i365,R102,i5,ML2,R103,s19,arbace/rlwrap_otherm4,R101,i366,R102,i5,R104,R105,R106,V5,s8,image.gos14,image_types.gos7,main.gos15,rlwrap_linux.gos15,rlwrap_other.goR107,V2,s9,image.binnR108,R109,R109,v16,arbace.j2g.names6,pkg-ofv11,arbace.core6,symbolv16,arbace.j2g.names18,static-method-nameR110,R105,ML3,R111,ML3,R112,R113,s0,m4,R101,i389,R102,i18,ML3,R108,ML2,R109,s14,arbace.versionm4,R101,i390,R102,i60,ML2,R109,R113,m4,R101,i390,R102,i87,m4,R101,i390,R102,i14,m4,R101,i389,R102,i12,v15,arbace.j2g.main14,property-formsML3,R114,V2,ML3,R115,R116,R117,m4,R101,i393,R102,i18,ML3,R118,R119,s3,resm4,R101,i393,R102,i35,ML3,R111,ML3,R120,R117,nm4,R101,i394,R102,i20,ML2,R121,ML2,R122,R116,m4,R101,i395,R102,i29,m4,R101,i395,R102,i16,m4,R101,i394,R102,i14,m4,R101,i393,R102,i12,ML2,R123,R124,m4,R101,i396,R102,i12,R114,R125,R126,R127,R128,R129,R130,ML3,R131,ML2,R132,R133,m4,R101,i398,R102,i106,l1,m4,R101,i398,R102,i103,R134,ML2,R135,R125,m4,R101,i400,R102,i28,R109,ML2,R135,R125,m4,R101,i400,R102,i28,v11,arbace.core11,map-indexedv11,arbace.core6,vectorR136,V3,R137,R10,ML3,R138,R133,l1,m4,R101,i401,R102,i33,R134,ML2,R135,R125,m4,R101,i402,R102,i33,ML2,R109,R10,m4,R101,i402,R102,i60,R130,R137,R114,ML1,R139,m4,R101,i404,R102,i21,ML2,R140,R141,m4,R101,i405,R102,i21,R141,R142,R143,R125,ML2,R144,Myn9,resourcesm6,R145,V1,s3,resR93,R146,R50,s80,resources are the namespaces' sources RT.load reads (EVAL-NOTES.md, \"Loading\").\nm4,R101,i425,R102,i5,ML2,R144,Myn9,imageDatam6,R145,V1,s9,image.binR93,R147,R50,s118,imageData is the image of prepared namespaces (EXEC-NOTES.md; image.go): empty until bin/arbace-go --build writes it.\nm4,R101,i428,R102,i5,ML2,R144,Myn13,arbaceVersionm4,R93,R147,R50,s205,arbaceVersion is Arbace's version, the map *arbace-version* reads from the system property arbace.version: empty in j2g's output, set by bin/arbace-go's link (go build -ldflags -X main.arbaceVersion=...).\nm4,R101,i431,R102,i5,v15,arbace.j2g.main18,program-entry-mainML8,R110,R105,V0,ML1,R148,m4,R101,i438,R102,i15,ML3,R111,ML3,R112,R113,s0,m4,R101,i439,R102,i21,ML3,R108,ML2,R109,s14,arbace.versionm4,R101,i440,R102,i63,ML2,R109,R113,m4,R101,i440,R102,i90,m4,R101,i440,R102,i17,m4,R101,i439,R102,i15,ML3,R114,V2,ML3,R115,R116,R117,m4,R101,i441,R102,i21,ML3,R118,R119,s3,resm4,R101,i441,R102,i38,ML3,R111,ML3,R120,R117,nm4,R101,i442,R102,i23,ML2,R121,ML2,R122,R116,m4,R101,i443,R102,i32,m4,R101,i443,R102,i19,m4,R101,i442,R102,i17,m4,R101,i441,R102,i15,ML2,R123,R124,m4,R101,i444,R102,i15,ML4,R114,V2,R125,ML3,R126,R127,ML3,R128,R129,ML3,R131,ML2,R132,R133,m4,R101,i445,R102,i75,l1,m4,R101,i445,R102,i72,m4,R101,i445,R102,i60,m4,R101,i445,R102,i26,ML3,R136,V3,R137,R10,ML3,R138,R133,l1,m4,R101,i446,R102,i29,ML4,R134,ML2,R135,R125,m4,R101,i447,R102,i25,R137,ML2,R109,R10,m4,R101,i447,R102,i38,m4,R101,i447,R102,i19,m4,R101,i446,R102,i17,ML4,R114,V2,R141,ML2,R142,ML3,R143,V0,ML2,R149,R125,m4,R101,i448,R102,i50,m4,R101,i448,R102,i43,m4,R101,i448,R102,i30,ML1,R139,m4,R101,i449,R102,i19,ML2,R140,R141,m4,R101,i450,R102,i19,m4,R101,i448,R102,i17,m4,R101,i445,R102,i15,m4,R101,i437,R102,i13,R150,R151,V5,V2,R40,s5,embedV2,R152,s5,io/fsV2,R153,s2,osV2,R14,s10,arbace/jrtV2,R154,s11,arbace/langV1,V2,R155,s14,arbace/gotableR155,v16,arbace.j2g.names8,pkg-pathv11,arbace.core8,distinctv11,arbace.core4,valsv16,arbace.j2g.names17,compiled-packagesR156,R157,v15,arbace.j2g.main3,nowR158,v11,arbace.core4,atomR159,R160,R161,R162,R163,v11,arbace.core19,pop-thread-bindingsR164,v11,arbace.core7,printlnR165,R166,v15,arbace.j2g.main4,secsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv15,arbace.j2g.code10,*pkgstate*v15,arbace.j2g.code7,*races*v11,arbace.core5,*out*v15,arbace.j2g.code11,*node-memo*R167,R168,v11,arbace.core5,swap!v11,arbace.core6,reducev11,arbace.core7,sort-byv11,arbace.core3,valv11,arbace.core5,printv15,arbace.j2g.main5,apartv16,arbace.j2g.model10,reflected?v16,arbace.j2g.decls15,reflected-formsv16,arbace.j2g.decls11,class-formsv11,arbace.core5,rangev11,arbace.core4,takel25,v11,arbace.core4,compv11,arbace.core1,-v15,arbace.j2g.main12,merge-apart!R169,v16,arbace.j2g.model7,jrt-symR144,v11,arbace.core9,with-metaR170,R171,R172,R171,R144,R173,m2,R93,R174,R170,R110,R95,R170,v14,arbace.j2g.out18,class-registrationv11,arbace.core8,group-byv11,arbace.core4,mapvv15,arbace.j2g.main18,registration-formsv11,arbace.core4,map?R175,V2,s31,String_Format_String_O1__Strings38,String_Format_Locale_String_O1__Stringv11,arbace.core9,update-inV2,R88,s6,StringV2,R88,s6,StringV2,R88,s15,Runtime_VersionV3,s13,Pre__Optionals15,Build__Optionals18,Optional__OptionalV2,R88,s15,Runtime_VersionV2,R88,s5,ClassV2,R88,s5,ClassV2,R88,s6,ModuleV2,R88,s6,ModuleV2,R88,s6,StringV4,s5,Classs6,Methods11,Constructors5,FieldV2,s6,Methods11,Constructorv14,arbace.j2g.out23,type-annotation-methodsR176,V3,s9,System_ins10,System_outs10,System_errV3,s27,System_SetIn_InputStream__Vs28,System_SetOut_PrintStream__Vs28,System_SetErr_PrintStream__VV2,R88,s6,Stringv14,arbace.j2g.out20,string-regex-methodsV2,R88,s12,ForkJoinPoolv14,arbace.j2g.out19,fjp-support-methodsR177,R178,R179,R180,R181,R182,R183,R184,v14,arbace.j2g.out17,fjp-support-classR185,v15,arbace.j2g.meta16,reflective-sitesv11,arbace.core4,nil?R186,R187,v15,arbace.j2g.meta13,present-specsv15,arbace.j2g.meta13,service-rootsR188,v15,arbace.j2g.meta8,internalR189,R190,R191,R192,v15,arbace.j2g.main10,meta-rootsv15,arbace.j2g.main11,meta-reportR193,R194,R195,R196,R197,R198,v11,arbace.core9,not-emptyv15,arbace.j2g.main10,world-scanv14,arbace.j2g.jrt4,scanv15,arbace.j2g.main11,jrt-classesv15,arbace.j2g.main16,manifest-classesR199,v15,arbace.j2g.code14,missing-reasonv11,arbace.core8,tree-seqv11,arbace.core7,some-fnR200,R201,R202,R203,R204,R205,R206,R207,R208,v18,arbace.classes.env13,*compile-set*R209,v18,arbace.classes.env13,*from-source*R210,p3,\\s+v15,arbace.j2g.main6,write!v15,arbace.j2g.main10,report-strv15,arbace.j2g.meta14,services-path?v15,arbace.j2g.meta14,metadata-path?v15,arbace.j2g.meta13,read-providesv15,arbace.j2g.meta8,servicesv15,arbace.j2g.meta19,data-metadata-rootsR211,R212,R213,R214,v15,arbace.j2g.meta16,roots-index-textv16,arbace.j2g.embed18,resource-dir-namesv15,arbace.j2g.meta17,services-resourcev15,arbace.j2g.meta13,services-textv15,arbace.j2g.meta14,roots-resourcev15,arbace.j2g.meta18,classpath-resourcev15,arbace.j2g.meta15,owners-resourcev15,arbace.j2g.meta20,classpath-index-textv15,arbace.j2g.meta11,owners-textR215,v11,arbace.core10,sorted-mapR216,R217,R218,R219,v11,arbace.core8,not-any?v15,arbace.j2g.meta18,classpath-propertyv16,arbace.j2g.embed7,sourcesv16,arbace.j2g.embed4,datav16,arbace.j2g.embed9,generatedv16,arbace.j2g.embed14,user-resourcesv16,arbace.j2g.embed15,package-loadersv15,arbace.j2g.main12,program-metaR220,R221,v16,arbace.j2g.embed14,cut-candidatesR222,v15,arbace.j2g.main21,write-meta-resources!v11,arbace.core6,reset!v11,arbace.core11,read-stringR223,R224,V2,s4,langs8,java/apiV1,s4,langR225,R226,v16,arbace.j2g.world10,load-worldR227,R228,R229,R230,R231,v15,arbace.j2g.main15,analysis-reportv11,arbace.core8,to-arrayR232,v13,arbace.j2g.vh7,handlesR233,R234,R235,v15,arbace.j2g.main13,repl-visible?v16,arbace.j2g.names15,compiled-class?v13,arbace.string9,includes?v14,arbace.j2g.dyn9,api-classv14,arbace.j2g.dyn5,rootsv14,arbace.j2g.dyn11,proxy-rootsv15,arbace.j2g.code14,serial-lambdasv17,arbace.j2g.fromfn5,rootsv16,arbace.j2g.model13,hand-written?v16,arbace.j2g.model28,class-loader-resource-ready?v16,arbace.j2g.model28,class-loader-resource-targetV1,V3,s28,java/io/ByteArrayInputStreams6,<init>s5,([B)Vv14,arbace.j2g.out18,access-flags-rootsv14,arbace.j2g.out16,parameters-rootsv14,arbace.j2g.out21,type-annotation-rootsV2,V3,s17,java/util/HashSets6,<init>s3,()VV3,s17,java/util/HashSets3,adds21,(Ljava/lang/Object;)ZV3,V3,s32,jdk/internal/jrt/StandardStreamss2,ins23,()Ljava/io/InputStream;V3,s32,jdk/internal/jrt/StandardStreamss3,outs23,()Ljava/io/PrintStream;V3,s32,jdk/internal/jrt/StandardStreamss3,errs23,()Ljava/io/PrintStream;V6,V3,s23,java/util/regex/Patterns7,compiles45,(Ljava/lang/String;)Ljava/util/regex/Pattern;V3,s23,java/util/regex/Patterns5,splits46,(Ljava/lang/CharSequence;I)[Ljava/lang/String;V3,s23,java/util/regex/Patterns7,matchers51,(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;V3,s23,java/util/regex/Patterns7,matchess45,(Ljava/lang/String;Ljava/lang/CharSequence;)ZV3,s23,java/util/regex/Matchers10,replaceAlls38,(Ljava/lang/String;)Ljava/lang/String;V3,s23,java/util/regex/Matchers12,replaceFirsts38,(Ljava/lang/String;)Ljava/lang/String;V1,V3,s42,jdk/internal/jrt/CaseInsensitiveComparators8,<clinit>s3,()Vv14,arbace.j2g.out15,fjp-support-keyV2,V3,s38,java/nio/channels/spi/SelectorProviders8,providers42,()Ljava/nio/channels/spi/SelectorProvider;V3,s38,java/nio/channels/spi/SelectorProviders16,inheritedChannels29,()Ljava/nio/channels/Channel;V2,V3,s17,java/time/Instants12,ofEpochMillis22,(J)Ljava/time/Instant;V3,s17,java/time/Instants12,toEpochMillis3,()JV1,V3,s18,java/sql/Timestamps9,toInstants21,()Ljava/time/Instant;v15,arbace.j2g.main12,bundle-rootsV3,V3,s18,java/util/Optionals2,ofs40,(Ljava/lang/Object;)Ljava/util/Optional;V3,s18,java/util/Optionals5,emptys22,()Ljava/util/Optional;V3,s17,java/lang/Integers7,valueOfs22,(I)Ljava/lang/Integer;V2,V3,s17,java/util/HashMaps6,<init>s3,()VV3,s17,java/util/HashMaps3,puts56,(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;V1,V3,s14,java/util/Lists2,ofs37,([Ljava/lang/Object;)Ljava/util/List;V3,V3,s19,java/util/ArrayLists6,<init>s3,()VV3,s19,java/util/ArrayLists3,adds21,(Ljava/lang/Object;)ZV3,s20,java/util/Collections6,streams27,()Ljava/util/stream/Stream;V1,V3,s19,java/io/PrintWriters5,prints21,(Ljava/lang/String;)VV1,V3,s19,java/io/PrintStreams5,prints21,(Ljava/lang/String;)VV3,V3,s17,java/util/HashMaps6,<init>s3,()VV3,s17,java/util/HashMaps3,puts56,(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;V3,s21,java/util/Collectionss15,unmodifiableMaps32,(Ljava/util/Map;)Ljava/util/Map;V4,V3,s19,java/util/Formatters6,<init>s3,()VV3,s19,java/util/Formatters6,<init>s21,(Ljava/util/Locale;)VV3,s19,java/util/Formatters6,formats60,(Ljava/lang/String;[Ljava/lang/Object;)Ljava/util/Formatter;V3,s19,java/util/Formatters8,toStrings20,()Ljava/lang/String;v15,arbace.j2g.code22,serial-lambdas-methodsv16,arbace.j2g.model29,class-loader-resource-helpersV6,s39,(Ljava/lang/String;)Ljava/lang/Process;s58,(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s72,(Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;s40,([Ljava/lang/String;)Ljava/lang/Process;s59,([Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/Process;s73,([Ljava/lang/String;[Ljava/lang/String;Ljava/io/File;)Ljava/lang/Process;v15,arbace.j2g.main6,top-ofv16,arbace.j2g.model13,translatable?v16,arbace.j2g.reach3,runR236,v15,arbace.j2g.main13,standin-rootsR237,v17,arbace.j2g.fromfn3,fisR238,R239,v16,arbace.j2g.model19,make-subclass-indexR240,R241,v16,arbace.j2g.model3,pkgV2,R156,R72,v16,arbace.j2g.names13,compiled-pkg?v17,arbace.j2g.checks10,collisionsR242,R243,v17,arbace.j2g.checks25,package-private-overridesR244,R245,v17,arbace.j2g.checks11,race-reportR246,v11,arbace.core11,frequenciesR247,R248,R249,R250,v15,arbace.j2g.meta8,refusalsR251,R252,R253,v11,arbace.core11,future-callv16,arbace.j2g.model6,run-fnR254,v11,arbace.core7,reversev11,arbace.core8,file-seqv14,arbace.java.io11,delete-filev14,arbace.j2g.out9,file-textv16,arbace.j2g.names8,pkg-namev11,arbace.core6,every?v15,arbace.j2g.main16,filter-standins*v20,arbace.repr.go.print10,read-formsv14,arbace.j2g.out9,form-textv15,arbace.j2g.main10,copy-file!V8,s3,crts2,cis7,cinterps3,scms9,scminterps2,ois4,libms2,pyv16,arbace.j2g.names18,qualified-prefixesv14,arbace.j2g.out16,*absent-members*v16,arbace.j2g.decls9,*reached*v15,arbace.j2g.main17,translate-classesv14,arbace.j2g.out12,go-file-namev15,arbace.j2g.main10,source-topv11,arbace.core7,memoizev14,arbace.j2g.dyn8,enabled?V2,R72,s10,j2g_dyn.gov14,arbace.j2g.dyn5,formsv16,arbace.j2g.dyncf8,enabled?V2,R72,s9,j2g_cf.gov16,arbace.j2g.dyncf5,formsV2,R72,s13,j2g_fromfn.gov17,arbace.j2g.fromfn5,formsv15,arbace.j2g.main13,registrationsR255,R256,v14,arbace.j2g.out13,adapter-formsR257,v15,arbace.j2g.main20,merge-registrations!R258,v14,arbace.j2g.out9,ups-formsv14,arbace.j2g.out19,support-table-formsv14,arbace.j2g.out12,frames-formsv14,arbace.j2g.out11,start-formsv16,arbace.j2g.model13,start-classesv14,arbace.j2g.out13,support-formsR259,v16,arbace.j2g.embed17,with-member-typesv16,arbace.j2g.model9,in-world?v14,arbace.j2g.out9,cut-formsv14,arbace.j2g.out15,cut-table-formsv16,arbace.j2g.model13,trivial-init?v15,arbace.j2g.main13,lazy-standinsR110,R95,v14,arbace.j2g.out13,strings-formsR260,R261,R262,R263,v14,arbace.j2g.out9,*renames*R264,R265,R266,ML3,R96,R267,ML2,R98,V3,R99,R1,R100,m4,R101,i1295,R102,i60,m4,R101,i1295,R102,i42,R104,R14,R268,R103,R269,R96,v16,arbace.j2g.names6,pkg-nsML2,R98,V3,R99,R1,R100,m4,R101,i1306,R102,i79,R104,R103,ML2,R98,V3,R99,R1,R100,m4,R101,i1306,R102,i79,p14,(?m)^\\(ns( |$)v15,arbace.j2g.main16,write-resources!v16,arbace.j2g.dyncf13,generics-textv11,arbace.core6,bytes?v15,arbace.j2g.main21,program-package-formsv15,arbace.j2g.main18,program-main-formsv16,arbace.j2g.embed11,image-formsv16,arbace.j2g.embed12,rlwrap-formsv16,arbace.j2g.embed16,image-type-formsR270,R271,R272,R273,R274,R275,R276,v11,arbace.core1,+v11,arbace.core5,countv15,arbace.j2g.main8,id-floorv15,arbace.j2g.main4,run*v15,arbace.j2g.edge9,read-edgev15,arbace.j2g.main12,advance-ids!v16,arbace.j2g.model5,*run*v18,arbace.classes.env10,*recorded*v15,arbace.j2g.edge11,*recording*v15,arbace.j2g.edge11,write-edge!v15,arbace.j2g.edge13,recorded-edgev15,arbace.j2g.main12,default-edgev18,arbace.classes.env10,*declared*v15,arbace.j2g.edge6,*edge*v22,arbace.classes.analyze15,*source-lookup*v15,arbace.j2g.main10,parse-argsv15,arbace.j2g.main3,runv11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("j2g: the runtime's id counter (")

var Lit_2 *jrt.String = jrt.Intern(") is at j2g's id-floor (")

var Lit_3 *jrt.String = jrt.Intern(") already: raise it (j2g's output then names its temporaries afresh)")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000528")

var Lit_5 *jrt.String = jrt.Intern("j2g: analysis failure ")

var Lit_6 *jrt.String = jrt.Intern(": ")

var Lit_7 *jrt.String = jrt.Intern(" ")

var Lit_8 *jrt.String = jrt.Intern("J2G_MISSING")

var Lit_9 *jrt.String = jrt.Intern("go/arbace/jrt")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000541")

var Lit_11 *jrt.String = jrt.Intern("j2g: missing in ")

var Lit_12 *jrt.String = jrt.Intern("/report.edn")

var Lit_13 *jrt.String = jrt.Intern("j2g: --analyze-only: ")

var Lit_14 *jrt.String = jrt.Intern(" analysis failures; ")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000541$iter__798000542__798000548")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000541$iter__798000542__798000548$fn__798000549")

var Lit_17 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000541$iter__798000542__798000548$fn__798000549$iter__798000544__798000550")

var Lit_18 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000541$iter__798000542__798000548$fn__798000549$fn__798000560")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000541$iter__798000542__798000548$fn__798000549$iter__798000544__798000550$fn__798000551")

var Lit_20 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000541$iter__798000542__798000548$fn__798000549$iter__798000544__798000550$fn__798000551$fn__798000552")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000541$iter__798000542__798000548$fn__798000549$iter__798000544__798000550$fn__798000551$fn__798000556")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report$fn__798000541$iter__798000542__798000548$fn__798000549$iter__798000544__798000550$fn__798000551$fn__798000552$fn__798000553")

var Lit_23 *jrt.String = jrt.Intern("Lit?")

var Lit_24 *jrt.String = jrt.Intern("_")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.main$apart$fn__798000270")

var Lit_26 *jrt.String = jrt.Intern("j2g: error in")

var Lit_27 *jrt.String = jrt.Intern(":")

var Lit_28 *jrt.String = jrt.Intern("J2G_TRACE")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$bundle_QMARK___798000074")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__798000076__798000080")

var Lit_31 *jrt.String = jrt.Intern("java/util/ResourceBundle")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__798000076__798000080$fn__798000081")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__798000076__798000080$fn__798000081$fn__798000082")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__798000076__798000080$fn__798000081$fn__798000086")

var Lit_35 *jrt.String = jrt.Intern("<init>")

var Lit_36 *jrt.String = jrt.Intern("()V")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots$iter__798000076__798000080$fn__798000081$fn__798000082$fn__798000083")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.main$filter_init_body$fn__798000145")

var Lit_39 *jrt.String = jrt.Intern("|")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$fn__798000149")

var Lit_41 *jrt.String = jrt.Intern("(")

var Lit_42 *jrt.String = jrt.Intern(")(_[A-Za-z0-9_]*)?")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$drop_QMARK___798000151")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$group__798000154")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$iter__798000164__798000168")

var Lit_46 *jrt.String = jrt.Intern("method")

var Lit_47 *jrt.String = jrt.Intern("init")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$group__798000154$fn__798000161")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$iter__798000164__798000168$fn__798000169")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_$iter__798000164__798000168$fn__798000169$fn__798000170")

var Lit_51 *jrt.String = jrt.Intern("func")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.main$fn__798000058$iter__798000059__798000063")

var Lit_53 *jrt.String = jrt.Intern("arbace.j2g.main$fn__798000058$iter__798000059__798000063$fn__798000064")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.main$fn__798000058$iter__798000059__798000063$fn__798000064$fn__798000065")

var Lit_55 *jrt.String = jrt.Intern("")

var Lit_56 *jrt.String = jrt.Intern("type")

var Lit_57 *jrt.String = jrt.Intern("var")

var Lit_58 *jrt.String = jrt.Intern(".")

var Lit_59 *jrt.String = jrt.Intern("/")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__798000031__798000035")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__798000041__798000045")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__798000031__798000035$fn__798000036")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__798000031__798000035$fn__798000036$fn__798000037")

var Lit_64 *jrt.String = jrt.Intern("_class")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__798000041__798000045$fn__798000046")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes$iter__798000041__798000045$fn__798000046$fn__798000047")

var Lit_67 *jrt.String = jrt.Intern("manifest.edn")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.main$manifest_classes$fn__798000028")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.main$mentions_QMARK_$w__798000138")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_$conj_all__798000275")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_$fn__798000280")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_$fn__798000285")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_$conj_all__798000275$fn__798000276")

var Lit_74 *jrt.String = jrt.Intern("Lit_")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.main$merge_registrations_BANG_$fn__798000321")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report$iter__798000598__798000602")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report$iter__798000598__798000602$fn__798000603")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report$iter__798000598__798000602$fn__798000603$fn__798000604")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report$iter__798000598__798000602$fn__798000603$iter__798000628__798000632")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report$iter__798000598__798000602$fn__798000603$fn__798000604$iter__798000608__798000612")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report$iter__798000598__798000602$fn__798000603$fn__798000604$iter__798000608__798000612$fn__798000613")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report$iter__798000598__798000602$fn__798000603$fn__798000604$iter__798000608__798000612$fn__798000613$fn__798000614")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report$iter__798000598__798000602$fn__798000603$iter__798000628__798000632$fn__798000633")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report$iter__798000598__798000602$fn__798000603$iter__798000628__798000632$fn__798000633$fn__798000634")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$iter__798000463__798000467")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$iter__798000479__798000483")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$iter__798000495__798000499")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$fn__798000518")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$iter__798000463__798000467$fn__798000468")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$iter__798000463__798000467$fn__798000468$fn__798000469")

var Lit_91 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$iter__798000479__798000483$fn__798000484")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$iter__798000479__798000483$fn__798000484$fn__798000485")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$iter__798000495__798000499$fn__798000500")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots$iter__798000495__798000499$fn__798000500$fn__798000501")

var Lit_95 *jrt.String = jrt.Intern(".tmp/j2g/out")

var Lit_96 *jrt.String = jrt.Intern("--record-edge")

var Lit_97 *jrt.String = jrt.Intern("--input")

var Lit_98 *jrt.String = jrt.Intern("--variants")

var Lit_99 *jrt.String = jrt.Intern("--gotable")

var Lit_100 *jrt.String = jrt.Intern("--jvm-reflection")

var Lit_101 *jrt.String = jrt.Intern("--tests")

var Lit_102 *jrt.String = jrt.Intern("--root")

var Lit_103 *jrt.String = jrt.Intern("--resources")

var Lit_104 *jrt.String = jrt.Intern("--jdk")

var Lit_105 *jrt.String = jrt.Intern("--entry")

var Lit_106 *jrt.String = jrt.Intern("#main")

var Lit_107 *jrt.String = jrt.Intern("--entry-arg")

var Lit_108 *jrt.String = jrt.Intern("--program")

var Lit_109 *jrt.String = jrt.Intern("arbace.lang.Main#main")

var Lit_110 *jrt.String = jrt.Intern("--own-roots")

var Lit_111 *jrt.String = jrt.Intern("--analyze-only")

var Lit_112 *jrt.String = jrt.Intern("--embed")

var Lit_113 *jrt.String = jrt.Intern("--main")

var Lit_114 *jrt.String = jrt.Intern("--edge")

var Lit_115 *jrt.String = jrt.Intern("--java-namespaces")

var Lit_116 *jrt.String = jrt.Intern("--property")

var Lit_117 *jrt.String = jrt.Intern("=")

var Lit_118 *jrt.String = jrt.Intern("j2g: --property K=V, not ")

var Lit_119 *jrt.String = jrt.Intern("--lang")

var Lit_120 *jrt.String = jrt.Intern("--provides")

var Lit_121 *jrt.String = jrt.Intern("--qualify")

var Lit_122 *jrt.String = jrt.Intern("--out")

var Lit_123 *jrt.String = jrt.Intern("--await")

var Lit_124 *jrt.String = jrt.Intern("--slice")

var Lit_125 *jrt.String = jrt.Intern("j2g: unknown option ")

var Lit_126 *jrt.String = jrt.Intern("arbace.lang.Main")

var Lit_127 *jrt.String = jrt.Intern("j2g: --entry ")

var Lit_128 *jrt.String = jrt.Intern(": not a class of the program's Java forms")

var Lit_129 *jrt.String = jrt.Intern("lang")

var Lit_130 *jrt.String = jrt.Intern("main")

var Lit_131 *jrt.String = jrt.Intern("([Ljava/lang/String;)V")

var Lit_132 *jrt.String = jrt.Intern("arbace.j2g.main$program_entry_main$iter__798000234__798000238")

var Lit_133 *jrt.String = jrt.Intern("arbace.j2g.main$program_entry_main$iter__798000234__798000238$fn__798000239")

var Lit_134 *jrt.String = jrt.Intern("arbace.j2g.main$program_entry_main$iter__798000234__798000238$fn__798000239$fn__798000240")

var Lit_135 *jrt.String = jrt.Intern("main.go")

var Lit_136 *jrt.String = jrt.Intern("arbace.j2g.main$program_main_forms$iter__798000255__798000259")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.main$program_main_forms$iter__798000255__798000259$fn__798000260")

var Lit_138 *jrt.String = jrt.Intern("arbace.j2g.main$program_main_forms$iter__798000255__798000259$fn__798000260$fn__798000261")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.main$program_meta$iter__798000576__798000580")

var Lit_140 *jrt.String = jrt.Intern("/provides.txt")

var Lit_141 *jrt.String = jrt.Intern("arbace.j2g.main$program_meta$iter__798000576__798000580$fn__798000581")

var Lit_142 *jrt.String = jrt.Intern("arbace.j2g.main$program_meta$iter__798000576__798000580$fn__798000581$fn__798000582")

var Lit_143 *jrt.String = jrt.Intern("arbace.j2g.main$program_meta$iter__798000576__798000580$fn__798000581$fn__798000592")

var Lit_144 *jrt.String = jrt.Intern("arbace.j2g.main$program_meta$iter__798000576__798000580$fn__798000581$fn__798000582$fn__798000586")

var Lit_145 *jrt.String = jrt.Intern("arbace/cmd/arbace")

var Lit_146 *jrt.String = jrt.Intern("arbace.j2g.main$program_package_forms$iter__798000206__798000210")

var Lit_147 *jrt.String = jrt.Intern("arbace.j2g.main$program_package_forms$iter__798000206__798000210$fn__798000211")

var Lit_148 *jrt.String = jrt.Intern("arbace.j2g.main$program_package_forms$iter__798000206__798000210$fn__798000211$fn__798000212")

var Lit_149 *jrt.String = jrt.Intern("res/")

var Lit_150 *jrt.String = jrt.Intern("arbace.j2g.main$property_forms$iter__798000217__798000221")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.main$property_forms$iter__798000217__798000221$fn__798000222")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.main$property_forms$iter__798000217__798000221$fn__798000222$fn__798000223")

var Lit_153 *jrt.String = jrt.Intern("arbace.j2g.main$registration_forms$code_QMARK___798000325")

var Lit_154 *jrt.String = jrt.Intern("CodeDecl")

var Lit_155 *jrt.String = jrt.Intern("DefineCode")

var Lit_156 *jrt.String = jrt.Intern("LinkCode")

var Lit_157 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__798000328__798000334")

var Lit_158 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$fn__798000354")

var Lit_159 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$fn__798000362")

var Lit_160 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__798000367__798000371")

var Lit_161 *jrt.String = jrt.Intern("r")

var Lit_162 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$fn__798000354$fn__798000358")

var Lit_163 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__798000328__798000334$fn__798000335")

var Lit_164 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__798000328__798000334$fn__798000335$iter__798000330__798000339")

var Lit_165 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__798000328__798000334$fn__798000335$iter__798000330__798000339$fn__798000340")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__798000328__798000334$fn__798000335$iter__798000330__798000339$fn__798000340$fn__798000341")

var Lit_167 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__798000367__798000371$fn__798000372")

var Lit_168 *jrt.String = jrt.Intern("arbace.j2g.main$registrations$iter__798000367__798000371$fn__798000372$fn__798000373")

var Lit_169 *jrt.String = jrt.Intern("arbace.j2g.main$repl_visible_QMARK_$fn__798000070")

var Lit_170 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$big_QMARK___798000385")

var Lit_171 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$val_str__798000387")

var Lit_172 *jrt.String = jrt.Intern("{")

var Lit_173 *jrt.String = jrt.Intern("}\n")

var Lit_174 *jrt.String = jrt.Intern(",\n ")

var Lit_175 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$iter__798000405__798000409")

var Lit_176 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$iter__798000405__798000409$fn__798000410")

var Lit_177 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$iter__798000405__798000409$fn__798000410$fn__798000411")

var Lit_178 *jrt.String = jrt.Intern("}")

var Lit_179 *jrt.String = jrt.Intern(",\n  ")

var Lit_180 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$val_str__798000387$iter__798000388__798000392")

var Lit_181 *jrt.String = jrt.Intern("[")

var Lit_182 *jrt.String = jrt.Intern("]")

var Lit_183 *jrt.String = jrt.Intern("\n  ")

var Lit_184 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$val_str__798000387$iter__798000388__798000392$fn__798000393")

var Lit_185 *jrt.String = jrt.Intern("arbace.j2g.main$report_str$val_str__798000387$iter__798000388__798000392$fn__798000393$fn__798000394")

var Lit_186 *jrt.String = jrt.Intern(".z")

var Lit_187 *jrt.String = jrt.Intern("$*")

var Lit_188 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys$fn__798000092")

var Lit_189 *jrt.String = jrt.Intern("j2g: root class not found: ")

var Lit_190 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys$iter__798000097__798000101")

var Lit_191 *jrt.String = jrt.Intern("<clinit>")

var Lit_192 *jrt.String = jrt.Intern("$")

var Lit_193 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys$iter__798000097__798000101$fn__798000102")

var Lit_194 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys$iter__798000097__798000101$fn__798000102$fn__798000103")

var Lit_195 *jrt.String = jrt.Intern("arbace.j2g.main$run$fn__798001409")

var Lit_196 *jrt.String = jrt.Intern("j2g: the edge of this run in ")

var Lit_197 *jrt.String = jrt.Intern(" classes")

var Lit_198 *jrt.String = jrt.Intern("arbace.j2g.main$run$fn__798001415")

var Lit_199 *jrt.String = jrt.Intern(" + ")

var Lit_200 *jrt.String = jrt.Intern("j2g: no edge ")

var Lit_201 *jrt.String = jrt.Intern(" (bin/j2g-edge update, or --jvm-reflection)")

var Lit_202 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000666")

var Lit_203 *jrt.String = jrt.Intern("java.class.path")

var Lit_204 *jrt.String = jrt.Intern("JRT_CONV")

var Lit_205 *jrt.String = jrt.Intern("jdk/forms")

var Lit_206 *jrt.String = jrt.Intern("/data")

var Lit_207 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$late_QMARK___798000674")

var Lit_208 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$compiled_packages_BANG___798000676")

var Lit_209 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$wait__798000688")

var Lit_210 *jrt.String = jrt.Intern("arbace")

var Lit_211 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000690__798000694")

var Lit_212 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000700__798000704")

var Lit_213 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$clj_files__798000710")

var Lit_214 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000714")

var Lit_215 *jrt.String = jrt.Intern("arbace/lang/go")

var Lit_216 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000716")

var Lit_217 *jrt.String = jrt.Intern("overlay/jdk/variants")

var Lit_218 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000722")

var Lit_219 *jrt.String = jrt.Intern(", ")

var Lit_220 *jrt.String = jrt.Intern(" failures")

var Lit_221 *jrt.String = jrt.Intern("j2g: ")

var Lit_222 *jrt.String = jrt.Intern(" constant VarHandles, on ")

var Lit_223 *jrt.String = jrt.Intern(" fields")

var Lit_224 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000732")

var Lit_225 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000734__798000738")

var Lit_226 *jrt.String = jrt.Intern("arbace/lang/RT")

var Lit_227 *jrt.String = jrt.Intern("jdk/internal/jrt/ClassPathResources")

var Lit_228 *jrt.String = jrt.Intern("java/lang/ClassLoader")

var Lit_229 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000750__798000754")

var Lit_230 *jrt.String = jrt.Intern("java/io/ByteArrayInputStream")

var Lit_231 *jrt.String = jrt.Intern("java/lang/reflect/AccessFlag")

var Lit_232 *jrt.String = jrt.Intern("jdk/internal/jrt/AccessFlagSupport")

var Lit_233 *jrt.String = jrt.Intern("java/lang/reflect/Parameter")

var Lit_234 *jrt.String = jrt.Intern("sun/reflect/annotation/TypeAnnotationParser")

var Lit_235 *jrt.String = jrt.Intern("jdk/internal/jrt/TypeAnnotationSupport")

var Lit_236 *jrt.String = jrt.Intern("java/util/HashSet")

var Lit_237 *jrt.String = jrt.Intern("jdk/internal/jrt/RuntimeExec")

var Lit_238 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000772__798000776")

var Lit_239 *jrt.String = jrt.Intern("java/nio/channels/spi/SelectorProvider")

var Lit_240 *jrt.String = jrt.Intern("java/time/Instant")

var Lit_241 *jrt.String = jrt.Intern("java/sql/Timestamp")

var Lit_242 *jrt.String = jrt.Intern("java/util/Optional")

var Lit_243 *jrt.String = jrt.Intern("java/util/HashMap")

var Lit_244 *jrt.String = jrt.Intern("java/util/List")

var Lit_245 *jrt.String = jrt.Intern("java/util/stream/Stream")

var Lit_246 *jrt.String = jrt.Intern("java/io/PrintWriter")

var Lit_247 *jrt.String = jrt.Intern("java/io/PrintStream")

var Lit_248 *jrt.String = jrt.Intern("java/util/Collections")

var Lit_249 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$slice_QMARK___798000782")

var Lit_250 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000784__798000788")

var Lit_251 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$cond_roots__798000800")

var Lit_252 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000821")

var Lit_253 *jrt.String = jrt.Intern("/gen")

var Lit_254 *jrt.String = jrt.Intern("/prog")

var Lit_255 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000831__798000835")

var Lit_256 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000841")

var Lit_257 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000843")

var Lit_258 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000845")

var Lit_259 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000847")

var Lit_260 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000849")

var Lit_261 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000851")

var Lit_262 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000853")

var Lit_263 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000855__798000861")

var Lit_264 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000878")

var Lit_265 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000880")

var Lit_266 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000882__798000886")

var Lit_267 *jrt.String = jrt.Intern("j2g_classes.go")

var Lit_268 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000906")

var Lit_269 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000908")

var Lit_270 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000914")

var Lit_271 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000916")

var Lit_272 *jrt.String = jrt.Intern("j2g_cut.go")

var Lit_273 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000918")

var Lit_274 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000920")

var Lit_275 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000922__798000926")

var Lit_276 *jrt.String = jrt.Intern("j2g_init.go")

var Lit_277 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000932__798000936")

var Lit_278 *jrt.String = jrt.Intern("j2g_strings.go")

var Lit_279 *jrt.String = jrt.Intern("j2g_up.go")

var Lit_280 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000942")

var Lit_281 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000944")

var Lit_282 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000950")

var Lit_283 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000952")

var Lit_284 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000954")

var Lit_285 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000956")

var Lit_286 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000958__798000962")

var Lit_287 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000968__798000972")

var Lit_288 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000982")

var Lit_289 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000988")

var Lit_290 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000990__798000994")

var Lit_291 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000")

var Lit_292 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001052")

var Lit_293 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001060")

var Lit_294 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001062__798001066")

var Lit_295 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001084")

var Lit_296 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001094__798001098")

var Lit_297 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001120")

var Lit_298 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001122")

var Lit_299 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001124__798001128")

var Lit_300 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001148__798001152")

var Lit_301 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001162")

var Lit_302 *jrt.String = jrt.Intern("go/arbace/goi.ae")

var Lit_303 *jrt.String = jrt.Intern("/go/arbace/goi.ae")

var Lit_304 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001168")

var Lit_305 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001174")

var Lit_306 *jrt.String = jrt.Intern("go/arbace.ae")

var Lit_307 *jrt.String = jrt.Intern("/go/arbace.ae")

var Lit_308 *jrt.String = jrt.Intern("go/arbace/api.ae")

var Lit_309 *jrt.String = jrt.Intern("/go/arbace/api.ae")

var Lit_310 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001188")

var Lit_311 *jrt.String = jrt.Intern("go/arbace/gotable.ae")

var Lit_312 *jrt.String = jrt.Intern("/go/arbace/gotable.ae")

var Lit_313 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001196")

var Lit_314 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001198__798001202")

var Lit_315 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001214__798001218")

var Lit_316 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001234")

var Lit_317 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001242")

var Lit_318 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$go_names__798001244")

var Lit_319 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001248")

var Lit_320 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001250")

var Lit_321 *jrt.String = jrt.Intern("/go/arbace/jrt.ae")

var Lit_322 *jrt.String = jrt.Intern("arbace/jrt")

var Lit_323 *jrt.String = jrt.Intern("\n")

var Lit_324 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001252__798001256")

var Lit_325 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001266__798001270")

var Lit_326 *jrt.String = jrt.Intern("/go/arbace/")

var Lit_327 *jrt.String = jrt.Intern(".ae")

var Lit_328 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001282__798001286")

var Lit_329 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001292__798001296")

var Lit_330 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001308__798001312")

var Lit_331 *jrt.String = jrt.Intern("/program.edn")

var Lit_332 *jrt.String = jrt.Intern("{:module \"arbace\" :go \"1.27\"}\n")

var Lit_333 *jrt.String = jrt.Intern("/namespaces.txt")

var Lit_334 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001318__798001322")

var Lit_335 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/res")

var Lit_336 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001334__798001338")

var Lit_337 *jrt.String = jrt.Intern("arbace/classes/generics.edn")

var Lit_338 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001355__798001359")

var Lit_339 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace.ae")

var Lit_340 *jrt.String = jrt.Intern(";; Generated by j2g --program (J2G-SPEC §10.6): the program's main package.\n")

var Lit_341 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/res/.build-go-data")

var Lit_342 *jrt.String = jrt.Intern("The main package's embedded sources (j2g --program): data, not Go forms.\n")

var Lit_343 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/main.ae")

var Lit_344 *jrt.String = jrt.Intern(";; Generated by j2g --program (J2G-SPEC §10.6).\n(in-ns 'go.arbace.cmd.arbace)\n\n")

var Lit_345 *jrt.String = jrt.Intern("\n\n")

var Lit_346 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image.ae")

var Lit_347 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/")

var Lit_348 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image_types.ae")

var Lit_349 *jrt.String = jrt.Intern(";; Generated by j2g --program: the program's struct types, by name (EXEC-NOTES.md).\n")

var Lit_350 *jrt.String = jrt.Intern("(in-ns 'go.arbace.cmd.arbace)\n\n")

var Lit_351 *jrt.String = jrt.Intern("/go/arbace/cmd/arbace/image.bin")

var Lit_352 *jrt.String = jrt.Intern("j2g: steps (s): ")

var Lit_353 *jrt.String = jrt.Intern(" (")

var Lit_354 *jrt.String = jrt.Intern(" jobs)")

var Lit_355 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001391__798001395")

var Lit_356 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$clj_files__798000710$fn__798000711")

var Lit_357 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$compiled_packages_BANG___798000676$iter__798000677__798000681")

var Lit_358 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$compiled_packages_BANG___798000676$iter__798000677__798000681$fn__798000682")

var Lit_359 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$compiled_packages_BANG___798000676$iter__798000677__798000681$fn__798000682$fn__798000683")

var Lit_360 *jrt.String = jrt.Intern("packages.edn")

var Lit_361 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$cond_roots__798000800$iter__798000801__798000807")

var Lit_362 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$cond_roots__798000800$iter__798000801__798000807$fn__798000808")

var Lit_363 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$cond_roots__798000800$iter__798000801__798000807$fn__798000808$iter__798000803__798000812")

var Lit_364 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$cond_roots__798000800$iter__798000801__798000807$fn__798000808$iter__798000803__798000812$fn__798000813")

var Lit_365 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$cond_roots__798000800$iter__798000801__798000807$fn__798000808$iter__798000803__798000812$fn__798000813$fn__798000814")

var Lit_366 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000821$fn__798000822")

var Lit_367 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000821$fn__798000824")

var Lit_368 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000821$fn__798000826")

var Lit_369 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798000821$fn__798000826$fn__798000827")

var Lit_370 *jrt.String = jrt.Intern("j2g_lambdas.go")

var Lit_371 *jrt.String = jrt.Intern("j2g_frames.go")

var Lit_372 *jrt.String = jrt.Intern("j2g_start.go")

var Lit_373 *jrt.String = jrt.Intern("j2g_support.go")

var Lit_374 *jrt.String = jrt.Intern("reflect_tables_j2g.go")

var Lit_375 *jrt.String = jrt.Intern("Go name ")

var Lit_376 *jrt.String = jrt.Intern("declared more than once in ")

var Lit_377 *jrt.String = jrt.Intern("j2g: error: Go name ")

var Lit_378 *jrt.String = jrt.Intern(" declared more than once in package ")

var Lit_379 *jrt.String = jrt.Intern("package-private, redeclared by ")

var Lit_380 *jrt.String = jrt.Intern(" in another package (J2G-SPEC §4.4: rename table)")

var Lit_381 *jrt.String = jrt.Intern("j2g: error: package-private ")

var Lit_382 *jrt.String = jrt.Intern(" is redeclared by ")

var Lit_383 *jrt.String = jrt.Intern(" in another Java package; Go would override it")

var Lit_384 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001052$fn__798001053")

var Lit_385 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001084$fn__798001086")

var Lit_386 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001084$fn__798001091")

var Lit_387 *jrt.String = jrt.Intern("/go/arbace/jrt/")

var Lit_388 *jrt.String = jrt.Intern("go/arbace/goi")

var Lit_389 *jrt.String = jrt.Intern("/go/arbace/goi/")

var Lit_390 *jrt.String = jrt.Intern("go/arbace/")

var Lit_391 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$fn__798001188$fn__798001189")

var Lit_392 *jrt.String = jrt.Intern("go/arbace/repr")

var Lit_393 *jrt.String = jrt.Intern("go/arbace/gotable")

var Lit_394 *jrt.String = jrt.Intern("/go/arbace/gotable/")

var Lit_395 *jrt.String = jrt.Intern("_test")

var Lit_396 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$go_names__798001244$fn__798001245")

var Lit_397 *jrt.String = jrt.Intern(".go")

var Lit_398 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000690__798000694$fn__798000695")

var Lit_399 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000690__798000694$fn__798000695$fn__798000696")

var Lit_400 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000700__798000704$fn__798000705")

var Lit_401 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000700__798000704$fn__798000705$fn__798000706")

var Lit_402 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000734__798000738$fn__798000739")

var Lit_403 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000734__798000738$fn__798000739$fn__798000740")

var Lit_404 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000750__798000754$fn__798000755")

var Lit_405 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000750__798000754$fn__798000755$fn__798000756")

var Lit_406 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000772__798000776$fn__798000777")

var Lit_407 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000772__798000776$fn__798000777$fn__798000778")

var Lit_408 *jrt.String = jrt.Intern("exec")

var Lit_409 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000784__798000788$fn__798000789")

var Lit_410 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000784__798000788$fn__798000789$fn__798000790")

var Lit_411 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000831__798000835$fn__798000836")

var Lit_412 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000831__798000835$fn__798000836$fn__798000837")

var Lit_413 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000855__798000861$fn__798000862")

var Lit_414 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000855__798000861$fn__798000862$iter__798000857__798000866")

var Lit_415 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000855__798000861$fn__798000862$iter__798000857__798000866$fn__798000867")

var Lit_416 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000855__798000861$fn__798000862$iter__798000857__798000866$fn__798000867$fn__798000868")

var Lit_417 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000882__798000886$fn__798000887")

var Lit_418 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000882__798000886$fn__798000887$fn__798000888")

var Lit_419 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000922__798000926$fn__798000927")

var Lit_420 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000922__798000926$fn__798000927$fn__798000928")

var Lit_421 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000932__798000936$fn__798000937")

var Lit_422 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000932__798000936$fn__798000937$fn__798000938")

var Lit_423 *jrt.String = jrt.Intern("_Init")

var Lit_424 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000958__798000962$fn__798000963")

var Lit_425 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000958__798000962$fn__798000963$fn__798000964")

var Lit_426 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000968__798000972$fn__798000973")

var Lit_427 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000968__798000972$fn__798000973$fn__798000974")

var Lit_428 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000990__798000994$fn__798000995")

var Lit_429 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798000990__798000994$fn__798000995$fn__798000996")

var Lit_430 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001062__798001066$fn__798001067")

var Lit_431 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001062__798001066$fn__798001067$fn__798001068")

var Lit_432 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001094__798001098$fn__798001099")

var Lit_433 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001094__798001098$fn__798001099$fn__798001100")

var Lit_434 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001124__798001128$fn__798001129")

var Lit_435 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001124__798001128$fn__798001129$fn__798001130")

var Lit_436 *jrt.String = jrt.Intern("standin_")

var Lit_437 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001124__798001128$fn__798001129$fn__798001142")

var Lit_438 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001124__798001128$fn__798001129$fn__798001130$fn__798001134")

var Lit_439 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001124__798001128$fn__798001129$fn__798001130$fn__798001134$fn__798001135")

var Lit_440 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001124__798001128$fn__798001129$fn__798001142$fn__798001143")

var Lit_441 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001148__798001152$fn__798001153")

var Lit_442 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001148__798001152$fn__798001153$fn__798001154")

var Lit_443 *jrt.String = jrt.Intern("_test.ae")

var Lit_444 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001198__798001202$fn__798001203")

var Lit_445 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001198__798001202$fn__798001203$fn__798001204")

var Lit_446 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001214__798001218$fn__798001219")

var Lit_447 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001214__798001218$fn__798001219$fn__798001220")

var Lit_448 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001252__798001256$fn__798001257")

var Lit_449 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001252__798001256$fn__798001257$fn__798001258")

var Lit_450 *jrt.String = jrt.Intern("jrt/")

var Lit_451 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001266__798001270$fn__798001271")

var Lit_452 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001266__798001270$fn__798001271$fn__798001272")

var Lit_453 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001282__798001286$fn__798001287")

var Lit_454 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001282__798001286$fn__798001287$fn__798001288")

var Lit_455 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001292__798001296$fn__798001297")

var Lit_456 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001292__798001296$fn__798001297$fn__798001298")

var Lit_457 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001308__798001312$fn__798001313")

var Lit_458 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001308__798001312$fn__798001313$fn__798001314")

var Lit_459 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001318__798001322$fn__798001323")

var Lit_460 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001318__798001322$fn__798001323$fn__798001324")

var Lit_461 *jrt.String = jrt.Intern("arbace/")

var Lit_462 *jrt.String = jrt.Intern("-")

var Lit_463 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001334__798001338$fn__798001339")

var Lit_464 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001334__798001338$fn__798001339$fn__798001340")

var Lit_465 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001334__798001338$fn__798001339$fn__798001350")

var Lit_466 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001334__798001338$fn__798001339$fn__798001340$fn__798001344")

var Lit_467 *jrt.String = jrt.Intern("UTF-8")

var Lit_468 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001355__798001359$fn__798001360")

var Lit_469 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001355__798001359$fn__798001360$fn__798001361")

var Lit_470 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001355__798001359$fn__798001360$fn__798001371")

var Lit_471 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001355__798001359$fn__798001360$fn__798001361$fn__798001365")

var Lit_472 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001391__798001395$fn__798001396")

var Lit_473 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$iter__798001391__798001395$fn__798001396$fn__798001397")

var Lit_474 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$fn__798001001")

var Lit_475 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$iter__798001003__798001007")

var Lit_476 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$iter__798001019__798001023")

var Lit_477 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$iter__798001035__798001039")

var Lit_478 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$iter__798001003__798001007$fn__798001008")

var Lit_479 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$iter__798001003__798001007$fn__798001008$fn__798001009")

var Lit_480 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$iter__798001019__798001023$fn__798001024")

var Lit_481 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$iter__798001019__798001023$fn__798001024$fn__798001025")

var Lit_482 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$iter__798001035__798001039$fn__798001040")

var Lit_483 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_$report_of__798001000$iter__798001035__798001039$fn__798001040$fn__798001041")

var Lit_484 *jrt.String = jrt.Intern("aot.edn")

var Lit_485 *jrt.String = jrt.Intern(" ready after ")

var Lit_486 *jrt.String = jrt.Intern(" s")

var Lit_487 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__798000108__798000112")

var Lit_488 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__798000118__798000124")

var Lit_489 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__798000108__798000112$fn__798000113")

var Lit_490 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__798000108__798000112$fn__798000113$fn__798000114")

var Lit_491 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__798000118__798000124$fn__798000125")

var Lit_492 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__798000118__798000124$fn__798000125$iter__798000120__798000126")

var Lit_493 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__798000118__798000124$fn__798000125$iter__798000120__798000126$fn__798000127")

var Lit_494 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots$iter__798000118__798000124$fn__798000125$iter__798000120__798000126$fn__798000127$fn__798000128")

var Lit_495 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__798000290")

var Lit_496 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__798000297")

var Lit_497 *jrt.String = jrt.Intern("J2G_CLASS_TIMES")

var Lit_498 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__798000303")

var Lit_499 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__798000312")

var Lit_500 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes$fn__798000290$fn__798000294")

var Lit_501 *jrt.String = jrt.Intern("j2g: class time")

var Lit_502 *jrt.String = jrt.Intern("java/util/Formatter")

var Lit_503 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$fn__798000428")

var Lit_504 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$in_slice_QMARK___798000430")

var Lit_505 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$jrt_java_QMARK___798000434")

var Lit_506 *jrt.String = jrt.Intern("jdk/internal/jrt/StandardStreams")

var Lit_507 *jrt.String = jrt.Intern("jdk/internal/jrt/CaseInsensitiveComparator")

var Lit_508 *jrt.String = jrt.Intern("java/util/regex/Pattern")

var Lit_509 *jrt.String = jrt.Intern("java/util/concurrent/ExecutorService")

var Lit_510 *jrt.String = jrt.Intern("Formatted_O1__String")

var Lit_511 *jrt.String = jrt.Intern("java/lang/Iterable")

var Lit_512 *jrt.String = jrt.Intern("String_Join_CharSequence_Iterable__String")

var Lit_513 *jrt.String = jrt.Intern("DescribeConstable__Optional")

var Lit_514 *jrt.String = jrt.Intern("java/lang/Runtime$Version")

var Lit_515 *jrt.String = jrt.Intern("Version__List")

var Lit_516 *jrt.String = jrt.Intern("GetResourceAsStream_String__InputStream")

var Lit_517 *jrt.String = jrt.Intern("GetResource_String__URL")

var Lit_518 *jrt.String = jrt.Intern("GetPackages__Set")

var Lit_519 *jrt.String = jrt.Intern("Lines__Stream")

var Lit_520 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$fn__798000437")

var Lit_521 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$fn__798000441")

var Lit_522 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$fn__798000445")

var Lit_523 *jrt.String = jrt.Intern("String_CASE_INSENSITIVE_ORDER")

var Lit_524 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$fn__798000454")

var Lit_525 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$fn__798000437$fn__798000438")

var Lit_526 *jrt.String = jrt.Intern("AccessFlags__Set")

var Lit_527 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$fn__798000441$fn__798000442")

var Lit_528 *jrt.String = jrt.Intern("GetParameters__Parameter1")

var Lit_529 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$fn__798000445$fn__798000447")

var Lit_530 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan$in_slice_QMARK___798000430$fn__798000431")

var Lit_531 *jrt.String = jrt.Intern("/meta")

var Lit_532 *jrt.String = jrt.Intern("services")

var Lit_533 *jrt.String = jrt.Intern("roots")

var Lit_534 *jrt.String = jrt.Intern("classpath")

var Lit_535 *jrt.String = jrt.Intern("owners")

var Lit_536 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$fn__798000179")

var Lit_537 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__798000184__798000188")

var Lit_538 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__798000184__798000188$fn__798000189")

var Lit_539 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__798000184__798000188$fn__798000189$fn__798000190")

var Lit_540 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__798000184__798000188$fn__798000189$fn__798000200")

var Lit_541 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_$iter__798000184__798000188$fn__798000189$fn__798000190$fn__798000194")

var Lit_542 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn4,linekn6,columnkn4,fileyn2,t0yn4,argsyn1,syn3,diryn4,scanyn8,manifestkn3,tagyn6,Stringyn4,specyn1,Tyn1,fyn4,formyn8,names-reyn6,own-reyn5,formsyn2,gsyn4,textyn4,fromyn2,toyn1,pyn5,bytesyn2,psyn8,embeddedyn10,propertiesyn5,entryyn10,entry-argsyn8,gotable?yn1,&yn5,worldyn3,pkgyn3,topyn3,tagyn1,iyn1,nyn6,catch?yn1,ryn7,renamesyn2,nsyn7,file-ofyn7,cost-ofyn9,pkgstatesyn5,filesyn6,errorsyn2,rsyn11,pkg-classesyn6,reportyn4,optskn8,declaredyn6,t-loadyn3,jdkyn4,datayn2,pmyn5,sitesyn6,absentv11,arbace.core5,in-nsMyn15,arbace.j2g.mainm2,R0,s5362,bin/j2g: Java forms to Go forms (doc/go/J2G-SPEC.md, doc/go/J2G-NOTES.md).\n\n  bin/j2g [OPTIONS]\n    --out DIR          output directory (default .tmp/j2g/out): DIR/gen/go/... the generated\n                       forms (J2G-SPEC §4.3: the files j2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/build-go; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of Java forms files (test fixtures; a tree with a\n                       packages.edn: the compiled namespaces, arbace.c2j, entered in the second\n                       round of the load, w/load-world)\n    --await DIR        --input DIR, read once DIR/aot.edn exists (j2g meanwhile loads and\n                       starts analyzing the other inputs; bin/arbace-go starts j2g while the\n                       host compiles the namespaces into DIR); the output is --input DIR's\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (J2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       j2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/build-go --line-file DIR/prog\n    --entry CLASS      with --program, the main package's main calls CLASS's static\n                       main(String[]) (a root) in place of arbace.lang.Main's: a Java forms\n                       program (bin/arbace-go --build-program, REAP7); no rlwrap\n    --entry-arg ARG    with --program, ARG put before the command line's arguments\n                       (repeated, in order): -m NS for a namespace's -main; no rlwrap\n    --property K=V     with --program, the system property K set to V at the start, before\n                       any class of the program is initialized (repeated, in order; a later\n                       K wins): a program's properties as data (program.edn :properties,\n                       A13 of the Ghidra case study's G1 plan, J2G-SPEC §10.6)\n    --resources DIR[=PREFIX]\n                       with --program, every file under DIR embedded too, at its path relative\n                       to DIR (after PREFIX/ when given), as a directory of the class path: a\n                       user's namespaces (.ae, .clj, .cljc) join the embedded sources, other\n                       files the resource data (bin/arbace-go --build-program, REAP7)\n    --own-roots all|entry\n                       with --program, the program's own classes (nm/own-class?: a user's Java\n                       forms) rooted every member (all, the default: the REPL's world) or only\n                       from the entry, the services, the metadata and the constant reflective\n                       sites (entry; J2G-SPEC §4.1, Roots from a program's metadata)\n    --provides FILE    the world's module provides (default jdk/provides.txt beside --jdk's\n                       forms: bin/jrt provides), the service registry's first providers\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): j2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/j2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)\n    --analyze-only     the world loaded and analyzed (w/load-world), nothing reached,\n                       translated or written but DIR/report.edn: :analyze-only true, :files,\n                       :classes (analyzed), :analysis-failures (as a translation's report has\n                       them), :variants, :times {:load s}; each failure printed (j2g: analysis\n                       failure CLASS: MSG). No --program embedding. The day's light measurement\n                       of what the analysis refuses (J2G-SPEC §4.1, The analysis alone;\n                       JCS265 (b)): jdk/forms and a batch of tests within 2 GiBm2,R0,s5362,bin/j2g: Java forms to Go forms (doc/go/J2G-SPEC.md, doc/go/J2G-NOTES.md).\n\n  bin/j2g [OPTIONS]\n    --out DIR          output directory (default .tmp/j2g/out): DIR/gen/go/... the generated\n                       forms (J2G-SPEC §4.3: the files j2g writes), DIR/prog/ a program root\n                       merging them with jrt's hand-written forms (stand-ins of translated\n                       classes removed), for bin/build-go; DIR/report.edn\n    --lang             input: Arbace's arbace/lang/*.ae (default: both)\n    --jdk DIR          input: the converted JDK closure (default $JRT_CONV, else jdk/forms:\n                       the committed forms, bin/jrt-convert's output; its resource data in the\n                       directory data beside it, jdk/data)\n    --input DIR        input: an extra tree of Java forms files (test fixtures; a tree with a\n                       packages.edn: the compiled namespaces, arbace.c2j, entered in the second\n                       round of the load, w/load-world)\n    --await DIR        --input DIR, read once DIR/aot.edn exists (j2g meanwhile loads and\n                       starts analyzing the other inputs; bin/arbace-go starts j2g while the\n                       host compiles the namespaces into DIR); the output is --input DIR's\n    --slice REGEX      only classes whose internal names match one of the given regexes\n                       (repeatable) are translated; everything else is outside the closed\n                       world and the operations needing it throw (phase 1's slices)\n    --root SPEC        a reachability root: CLASS (all its public members), CLASS#name (its\n                       members named name), CLASS#<init> (its constructors), CLASS$* (the\n                       class and its named nested classes, all their public members);\n                       internal names with / or binary names with . (repeatable)\n    --tests            also copy jrt's test files into the program\n    --main DIR         a main package's forms tree to add to the program (its go/... files)\n    --program          the whole program (J2G-SPEC §10.6): arbace.lang.Main is a root, and\n                       j2g writes the main package arbace/cmd/arbace, whose main makes the\n                       calling goroutine the thread main (jrt.RunMain) and calls\n                       arbace.lang.Main.main(args) (RT's initialization first); build it with\n                       bin/build-go --line-file DIR/prog\n    --entry CLASS      with --program, the main package's main calls CLASS's static\n                       main(String[]) (a root) in place of arbace.lang.Main's: a Java forms\n                       program (bin/arbace-go --build-program, REAP7); no rlwrap\n    --entry-arg ARG    with --program, ARG put before the command line's arguments\n                       (repeated, in order): -m NS for a namespace's -main; no rlwrap\n    --property K=V     with --program, the system property K set to V at the start, before\n                       any class of the program is initialized (repeated, in order; a later\n                       K wins): a program's properties as data (program.edn :properties,\n                       A13 of the Ghidra case study's G1 plan, J2G-SPEC §10.6)\n    --resources DIR[=PREFIX]\n                       with --program, every file under DIR embedded too, at its path relative\n                       to DIR (after PREFIX/ when given), as a directory of the class path: a\n                       user's namespaces (.ae, .clj, .cljc) join the embedded sources, other\n                       files the resource data (bin/arbace-go --build-program, REAP7)\n    --own-roots all|entry\n                       with --program, the program's own classes (nm/own-class?: a user's Java\n                       forms) rooted every member (all, the default: the REPL's world) or only\n                       from the entry, the services, the metadata and the constant reflective\n                       sites (entry; J2G-SPEC §4.1, Roots from a program's metadata)\n    --provides FILE    the world's module provides (default jdk/provides.txt beside --jdk's\n                       forms: bin/jrt provides), the service registry's first providers\n    --edge FILE        the classes outside the forms, as data (default jdk/edge.edn:\n                       doc/STANDALONE-NOTES.md, S2): j2g loads no class, reflects on none and\n                       runs no ASM\n    --record-edge FILE instead, ask the JVM (reflection, class files) and write what this run\n                       asked into FILE (bin/j2g-edge update merges the builds' runs)\n    --jvm-reflection   instead, ask the JVM, without recording (a world the edge does not\n                       cover)\n    --analyze-only     the world loaded and analyzed (w/load-world), nothing reached,\n                       translated or written but DIR/report.edn: :analyze-only true, :files,\n                       :classes (analyzed), :analysis-failures (as a translation's report has\n                       them), :variants, :times {:load s}; each failure printed (j2g: analysis\n                       failure CLASS: MSG). No --program embedding. The day's light measurement\n                       of what the analysis refuses (J2G-SPEC §4.1, The analysis alone;\n                       JCS265 (b)): jdk/forms and a batch of tests within 2 GiBR1,v15,arbace.j2g.main3,nowm10,R2,TR3,L1,V0,R4,i93,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main4,secsm10,R2,TR3,L1,V1,R7,R4,i94,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,parse-argsm8,R3,L1,V1,R8,R4,i96,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main8,internalm10,R2,TR3,L1,V1,R9,R4,i143,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,manifest-classesm10,R3,L1,V1,R10,R0,s55,The classes the jrt manifest declares (internal names).R4,i145,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main11,jrt-classesm10,R3,L1,V2,R11,R12,R0,s81,jrt's classes: those its forms register (Define) and those its manifest declares.R4,i153,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main17,repl-exports-filem6,R4,i161,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main13,repl-exportedm10,R2,TR4,i163,R5,i1,R6,s18,arbace/j2g/main.aeR0,s320,The packages of JDK modules that the REPL's world makes visible though the module does not export them\n  (JCS136 (a), JCS142 (a): the tests' @modules java.base/PKG; test/java/check.ae reads the file too), one a line\n  in jdk/repl-exports.txt (read from the working directory as jdk/edge.edn is; none when it is missing).v15,arbace.j2g.main13,repl-visible?m12,R2,TR3,L1,V1,Myn1,nm2,R13,R14,R0,s834,Can the REPL name class n's public members (internal name)? Not when n is in a JDK module's\n  package that the module does not export (jdk.internal.misc, sun.nio.cs ...): the JVM refuses\n  such access from Clojure code (IllegalAccessError), so the Go build's REPL world does not root\n  them (J2G-SPEC §10.6; JRT-NOTES.md, \"The JDK's resource data\", amendment RD2). Classes of no\n  JDK module (Arbace's, jrt's own jdk.internal.jrt) are visible, and so are the tool's modules'\n  (nm/qualified?: javac's internal packages, com.sun.tools.javac.*, which repr/java's reader\n  calls on the tool executable; doc/classes/JAVA-FRONTEND-SURVEY.md, JFS17 (a), \"As built:\n  JN4\"): the shipped world holds none of them. And the packages of jdk/repl-exports.txt (the internal\n  packages of the JCA and PKI that jtreg's @modules exports, JCS136 (a)).R4,i174,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main12,bundle-rootsm12,R2,TR3,L1,V0,R0,s251,The public no-argument constructors of the world's concrete ResourceBundle subclasses:\n  ResourceBundle.getBundle makes its bundles by reflection (overlay/jdk's ResourceBundle;\n  javac's messages, doc/classes/JAVA-FRONTEND-SURVEY.md, \"As built: JN2\").R4,i192,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main9,root-keysm12,R2,TR3,L1,V1,R15,R0,s115,Method keys of a root spec. CLASS$* is the class and every named class nested in it (the\n  whole of Compiler, say).R4,i209,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main13,lazy-standinsS2,s16,java/util/Locales25,java/util/Locale$Categorym8,R4,i232,R5,i1,R6,s18,arbace/j2g/main.aeR0,s335,Replaced stand-ins initialized on first use like any translated class, not eagerly: jrt's\n  hand-written code (but its tests) reads none of their statics, and their initialization needs\n  much of the program initialized first (Locale's: its constants, the default locale from the\n  system properties; JRT-NOTES.md, \"Text and locales\").v15,arbace.j2g.main13,standin-rootsm10,R3,L1,V2,R11,R16,R0,s153,Roots for the translated classes that replace jrt's stand-ins: their static initializer\n  and the members the stand-in defined (jrt's code may use them).R4,i239,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,form-namesm12,R2,TR3,L1,V1,R17,R0,s41,Go identifiers a top-level form declares.R4,i263,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,method-recv-typem10,R2,TR3,L1,V1,R17,R4,i274,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main9,mentions?m10,R2,TR3,L1,V2,R18,R19,R4,i282,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,filter-init-bodym10,R2,TR3,L1,V2,R17,R20,R4,i291,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,filter-standins*m8,R3,L1,V2,R21,R22,R4,i295,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main6,write!m10,R2,TR3,L1,V2,R17,R23,R4,i326,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,copy-file!m10,R2,TR3,L1,V2,R24,R25,R4,i330,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main13,resource-filem12,R2,TR3,L1,V2,R26,Myn1,bm2,R13,R27,R0,s253,The embedded resource p (bytes b) as it is written: as p.z, zlib-compressed, when that saves\n  a quarter or more (the sources, generics.edn, tzdb.dat), else as it is; jrt's OSHost.Resource\n  inflates a p.z when asked for p (amendment SZ2). [name bytes].R4,i334,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main16,write-resources!m12,R2,TR3,L1,V2,R10,R28,R0,s157,Writes the embedded resources ps ([path bytes-fn] in order) under dir, compressed in\n  parallel (resource-file), written in order. Returns the names written.R4,i342,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main6,top-ofm10,R2,TR3,L1,V1,Myn1,nm2,R13,R14,R4,i354,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main21,program-package-formsm12,R2,TR3,L1,V1,R29,R0,s87,The main package: main.go and the embedded sources (res/..., EVAL-NOTES.md, \"Loading\").R4,i356,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main14,property-formsm12,R2,TR3,L1,V1,R30,R0,s208,The system properties set at the start (j2g --property, program.edn :properties): one\n  System.setProperty a pair, in order, after arbace.version and before the image, the host and\n  any class of the program.R4,i368,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main18,program-entry-mainm12,R2,TR3,L1,V3,R31,R32,R30,R0,s164,A user's program's main (program-main-forms with an entry): Main's start but rlwrap, the\n  command line after entry-args, entry's main (default arbace.lang.Main's).R4,i376,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main18,program-main-formsm12,R2,TR3,L1,V3,R33,R34,V3,R31,R32,R30,R0,s911,main: first rlwrap for an interactive REPL (execRlwrap, which replaces the process when it\n  applies), then the system property arbace.version from arbaceVersion (when the link set it),\n  then jrt's host for the build's system (jrt.ProgramHost: OSHost, or the box's on TamaGo,\n  doc/go/BOX-NOTES.md),\n  then the command line as a String[], then arbace.lang.Main.main inside jrt.RunMain\n  (the thread main, uncaught exceptions printed as the JVM prints them, status 1), its status\n  the process's. With gotable?, the main package imports goi's table (its registration).\n  With entry (a class's binary name) its static main(String[]) is called in place of Main's,\n  with entry-args (strings) those arguments put before the command line's: a user's program\n  (bin/arbace-go --build-program, REAP7), whose command line is its own (no rlwrap). properties\n  ([K V] pairs, j2g --property) are set after arbace.version.R4,i407,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,source-topm12,R2,TR3,L1,V3,R35,R36,R37,R0,s228,The name a Go file is named after (§4.3): in arbace/lang the Java forms file of top-level\n  class top (FxClasses for the classes of FxClasses.ae, so that --line-file positions name\n  it), in jrt the class (its Java source path).R4,i453,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main5,apartm12,R2,TR3,L1,V5,R38,R39,R40,R17,R41,R0,s456,Runs f (forms of class n, the i-th of its kind, tag naming the kind) on its own, with the\n  effects the sequential run has on the package's state recorded rather than applied: its\n  literals named apart (Lit?<tag><i>_k, in first-use order), what it conj'ed into the\n  package's ups, lambdas and cuts and into the races, in order, and its printed output. With\n  catch?, an exception is the result's :error [n message] (a translation's), else it is\n  thrown.R4,i466,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main12,merge-apart!m12,R2,TR3,L1,V3,R42,R28,R43,R0,s354,Applies to the package state ps (and c/*races*) what result r of apart recorded, as the\n  sequential run would have done it: its printed output, its conj's replayed one by one, its\n  literals named in the package's pool (Lit_n, numbered in order of first use; one an earlier\n  class used keeps its name). Returns renames with r's literals' renames added.R4,i492,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main17,translate-classesm10,R3,L1,V6,R44,R45,R46,R47,R48,R49,R0,s441,Translates the classes ns (in order) in parallel (jobs threads), each apart, and merges what\n  each did, in their order, as the sequential translation would have done it class after\n  class (merge-apart!): the forms into files ([pkg go-file] -> forms; file-of gives a\n  class's), its errors into errors. cost-of estimates a class's translation time (the\n  costliest start first). Returns the renames of the classes' literals (out/*renames*).R4,i516,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main20,merge-registrations!m12,R2,TR3,L1,V2,R50,R28,R0,s132,Merges the registrations' results rs, in order, into the package state ps (as\n  translate-classes). Returns their literals' renames.R4,i542,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main18,registration-formsm12,R2,TR3,L1,V2,R36,R50,R0,s78,The forms of j2g_classes.go of package pkg from its classes' registrations rs.R4,i548,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main13,registrationsm10,R3,L1,V1,R51,R0,s307,The forms of j2g_classes.go of each package pkg of pkg-classes ([pkg classes], in order;\n  out/class-registration of each class, in order), the classes of all the packages in\n  parallel, each apart. Returns [pkg forms results], whose results merge-registrations! merges\n  into the package's state, in order.R4,i564,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main12,default-edgem6,R4,i578,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,report-strm12,R2,TR3,L1,V1,R52,R0,s243,report.edn's text: the map a key per line, a map or vector with more than one element an\n  element per line, the rest as pr-str prints it (arbace.pprint took half a minute on the\n  program's report, on the critical path at the end of the run).R4,i580,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,world-scanm12,R2,TR3,L1,V3,R35,R53,R11,R0,s482,jrt's scan (jrt/scan) with what j2g's support code adds to jrt's hand-written classes in this world: String.format\n  over the translated Formatter, the standard streams, String's regex methods and the rest (run*'s translation; and\n  since F27 the --analyze-only report's J2G_MISSING scan, so that it sees what the translation sees), with the\n  conditions run* writes the support code by: {:scan :slice :in-slice? :jrt-java? :formatter? :streams? :ci-order?\n  :regex? :fjp-support?}.R4,i594,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main11,meta-reportm8,R54,TR4,i664,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main10,meta-rootsm12,R2,TR3,L1,V1,R53,R0,s486,The roots of a program's metadata (opts' :program-meta, program-meta) in the loaded world (a/*unit*\n  bound): {:roots [spec ...] (unconditional: the metadata's entries without a condition and the\n  reflective sites whose names are constants, in the program's own classes) :conditional [[class\n  [spec ...]] ...] (once class is reached: the services' providers, the conditional metadata)\n  :sites (meta/reflective-sites of the own classes) :absent [spec ...] (a class not in the world)}.R4,i666,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main15,analysis-reportm12,R2,TR3,L1,V3,R53,R35,R55,R0,s385,--analyze-only (JCS265 (b), J2G-SPEC §4.1, \"The analysis alone\"): the loaded world's\n  analysis failures, printed a line each and written into OUT/report.edn as a translation's report\n  has them (:analysis-failures, [class message] pairs), with the counts and the load's seconds; no\n  reachability, translation or Go. Returns the report (no :errors: the status is 0 whatever\n  failed).R4,i689,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main12,program-metam10,R3,L1,V3,R53,R56,R57,R0,s568,A program's discovery metadata (arbace.j2g.meta; J2G-SPEC §4.1, \"Roots from a program's metadata\"):\n  the service registry of the world's provides (opts' :provides, default jdk/provides.txt beside the\n  JDK's forms) and of the META-INF/services files among data ({resource-path File}: the JDK's resource\n  data and the program's resources with their root copies), and the roots of the native-image\n  metadata among them. {:services {svc [[provider kind] ...]} :bad-services [[path line] ...]\n  :metadata [[condition [spec ...]] ...] :metadata-errors [[path msg] ...]}.R4,i748,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main21,write-meta-resources!m12,R2,TR3,L1,V3,R53,R58,R57,R0,s269,The generated resources of a program's metadata, written under OUT/meta and returned as\n  {resource-path File} for the embedded data: the service registry (when the world has a\n  ServiceLoader to read it) and the resource roots' index (when a resource has root copies).R4,i765,R5,i1,R6,s18,arbace/j2g/main.aem12,R2,TR3,L1,V3,R58,R59,R60,R0,s145,report.edn's part of a program's metadata: the registry, the metadata's roots, the reflective\n  sites, the specs whose class is not in the world.R4,i788,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main4,run*m10,R3,L1,V1,R53,R0,s46,j2g's run, in the class environment run binds.R4,i799,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main8,id-floorl100000,m8,R4,i1376,R5,i1,R6,s18,arbace/j2g/main.aeR0,s483,Where the runtime's id counter (RT/nextID, gensym's) stands when j2g's run starts. The\n  analyzer and the translator name temporaries by it (arr_100417), so j2g first advances it to\n  this fixed value: its output then depends on its inputs, not on how much code the running\n  Arbace compiled before (j2g's own namespaces load from source, and on the Go executable in\n  other amounts than on the JVM). A round value well above what loading j2g takes\n  (doc/STANDALONE-NOTES.md, SA13).v15,arbace.j2g.main12,advance-ids!m12,R2,TR3,L1,V0,R0,s84,Advances the runtime's id counter to id-floor (an error when it is past it already).R4,i1385,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main3,runm10,R3,L1,V1,R53,R0,s369,j2g's run (bin/j2g's options as parse-args gives them). The classes outside the forms come\n  from the edge (--edge, default jdk/edge.edn: doc/STANDALONE-NOTES.md, S2), without the JVM's\n  reflection or ASM; --record-edge FILE: from the JVM's reflection, writing the edge of what\n  this run asked into FILE; --jvm-reflection: from the JVM's reflection (the edge unused).R4,i1394,R5,i1,R6,s18,arbace/j2g/main.aev15,arbace.j2g.main5,-mainm8,R3,L1,V2,R34,R8,R4,i1429,R5,i1,R6,s18,arbace/j2g/main.ae")

var Lit_543 *jrt.String = jrt.Intern("arbace.j2g.main$eval798000004$loading__1927001464__auto____798000005")

var Lit_544 *jrt.String = jrt.Intern("arbace.j2g.main$eval798000008$fn__798000009")

var Lit_545 *jrt.String = jrt.Intern("arbace.j2g.main$now")

var Lit_546 *jrt.String = jrt.Intern("arbace.j2g.main$secs")

var Lit_547 *jrt.String = jrt.Intern("arbace.j2g.main$parse_args")

var Lit_548 *jrt.String = jrt.Intern("arbace.j2g.main$internal")

var Lit_549 *jrt.String = jrt.Intern("arbace.j2g.main$manifest_classes")

var Lit_550 *jrt.String = jrt.Intern("arbace.j2g.main$jrt_classes")

var Lit_551 *jrt.String = jrt.Intern("jdk/repl-exports.txt")

var Lit_552 *jrt.String = jrt.Intern("arbace.j2g.main$fn__798000058")

var Lit_553 *jrt.String = jrt.Intern("arbace.j2g.main$repl_visible_QMARK_")

var Lit_554 *jrt.String = jrt.Intern("arbace.j2g.main$bundle_roots")

var Lit_555 *jrt.String = jrt.Intern("arbace.j2g.main$root_keys")

var Lit_556 *jrt.String = jrt.Intern("arbace.j2g.main$standin_roots")

var Lit_557 *jrt.String = jrt.Intern("arbace.j2g.main$form_names")

var Lit_558 *jrt.String = jrt.Intern("arbace.j2g.main$method_recv_type")

var Lit_559 *jrt.String = jrt.Intern("arbace.j2g.main$mentions_QMARK_")

var Lit_560 *jrt.String = jrt.Intern("arbace.j2g.main$filter_init_body")

var Lit_561 *jrt.String = jrt.Intern("arbace.j2g.main$filter_standins_STAR_")

var Lit_562 *jrt.String = jrt.Intern("arbace.j2g.main$write_BANG_")

var Lit_563 *jrt.String = jrt.Intern("arbace.j2g.main$copy_file_BANG_")

var Lit_564 *jrt.String = jrt.Intern("arbace.j2g.main$resource_file")

var Lit_565 *jrt.String = jrt.Intern("arbace.j2g.main$write_resources_BANG_")

var Lit_566 *jrt.String = jrt.Intern("arbace.j2g.main$top_of")

var Lit_567 *jrt.String = jrt.Intern("arbace.j2g.main$program_package_forms")

var Lit_568 *jrt.String = jrt.Intern("arbace.j2g.main$property_forms")

var Lit_569 *jrt.String = jrt.Intern("arbace.j2g.main$program_entry_main")

var Lit_570 *jrt.String = jrt.Intern("arbace.j2g.main$program_main_forms")

var Lit_571 *jrt.String = jrt.Intern("arbace.j2g.main$source_top")

var Lit_572 *jrt.String = jrt.Intern("arbace.j2g.main$apart")

var Lit_573 *jrt.String = jrt.Intern("arbace.j2g.main$merge_apart_BANG_")

var Lit_574 *jrt.String = jrt.Intern("arbace.j2g.main$translate_classes")

var Lit_575 *jrt.String = jrt.Intern("arbace.j2g.main$merge_registrations_BANG_")

var Lit_576 *jrt.String = jrt.Intern("arbace.j2g.main$registration_forms")

var Lit_577 *jrt.String = jrt.Intern("arbace.j2g.main$registrations")

var Lit_578 *jrt.String = jrt.Intern("jdk/edge.edn")

var Lit_579 *jrt.String = jrt.Intern("arbace.j2g.main$report_str")

var Lit_580 *jrt.String = jrt.Intern("arbace.j2g.main$world_scan")

var Lit_581 *jrt.String = jrt.Intern("arbace.j2g.main$meta_roots")

var Lit_582 *jrt.String = jrt.Intern("arbace.j2g.main$analysis_report")

var Lit_583 *jrt.String = jrt.Intern("arbace.j2g.main$program_meta")

var Lit_584 *jrt.String = jrt.Intern("arbace.j2g.main$write_meta_resources_BANG_")

var Lit_585 *jrt.String = jrt.Intern("arbace.j2g.main$meta_report")

var Lit_586 *jrt.String = jrt.Intern("arbace.j2g.main$run_STAR_")

var Lit_587 *jrt.String = jrt.Intern("arbace.j2g.main$advance_ids_BANG_")

var Lit_588 *jrt.String = jrt.Intern("arbace.j2g.main$run")

var Lit_589 *jrt.String = jrt.Intern("arbace.j2g.main$_main")
