//line a2g_strings.ae:1
package aot_arbace_pprint_column_writer

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.pprintkn7,privatekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistskn3,tagyn6,Writeryn3,symyn7,new-valyn4,thisyn7,new-maxyn7,Integeryn6,writeryn11,max-columnsv11,arbace.core5,in-nsR0,v13,arbace.pprint20,*default-page-width*l72,m10,R1,TR2,TR3,i22,R4,i1,R5,s30,arbace/pprint/column_writer.aev13,arbace.pprint9,get-fieldm10,R1,TR6,L1,V2,Myn4,thism2,R7,R8,R9,R3,i24,R4,i1,R5,s30,arbace/pprint/column_writer.aev13,arbace.pprint9,set-fieldm10,R1,TR6,L1,V3,Myn4,thism2,R7,R8,R9,R10,R3,i27,R4,i1,R5,s30,arbace/pprint/column_writer.aev13,arbace.pprint10,get-columnm10,R1,TR6,L1,V1,R11,R3,i30,R4,i1,R5,s30,arbace/pprint/column_writer.aev13,arbace.pprint8,get-linem10,R1,TR6,L1,V1,R11,R3,i33,R4,i1,R5,s30,arbace/pprint/column_writer.aev13,arbace.pprint14,get-max-columnm10,R1,TR6,L1,V1,R11,R3,i36,R4,i1,R5,s30,arbace/pprint/column_writer.aev13,arbace.pprint14,set-max-columnm10,R1,TR6,L1,V2,R11,R12,R3,i39,R4,i1,R5,s30,arbace/pprint/column_writer.aev13,arbace.pprint10,get-writerm10,R1,TR6,L1,V1,R11,R3,i43,R4,i1,R5,s30,arbace/pprint/column_writer.aev13,arbace.pprint12,c-write-charm10,R1,TR6,L1,V2,Myn4,thism2,R7,R8,Myn1,cm2,R7,R13,R3,i46,R4,i1,R5,s30,arbace/pprint/column_writer.aev13,arbace.pprint13,column-writerm10,R1,TR6,L2,V1,R14,V2,Myn6,writerm2,R7,R8,R15,R3,i54,R4,i1,R5,s30,arbace/pprint/column_writer.aev11,arbace.core15,get-proxy-classC14,java.io.WriterC18,arbace.lang.IDeref")

var Lit_1 *jrt.String = jrt.Intern("arbace.lang.IDeref")

var Lit_2 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_3 *jrt.String = jrt.Intern("arbace.pprint$get_field")

var Lit_4 *jrt.String = jrt.Intern("arbace.pprint$set_field")

var Lit_5 *jrt.String = jrt.Intern("arbace.pprint$get_column")

var Lit_6 *jrt.String = jrt.Intern("arbace.pprint$get_line")

var Lit_7 *jrt.String = jrt.Intern("arbace.pprint$get_max_column")

var Lit_8 *jrt.String = jrt.Intern("arbace.pprint$set_max_column")

var Lit_9 *jrt.String = jrt.Intern("arbace.pprint$get_writer")

var Lit_10 *jrt.String = jrt.Intern("arbace.pprint$c_write_char")

var Lit_11 *jrt.String = jrt.Intern("arbace.pprint$column_writer")
