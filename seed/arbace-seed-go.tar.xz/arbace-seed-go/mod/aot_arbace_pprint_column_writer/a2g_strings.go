//line a2g_strings.ae:1
package aot_arbace_pprint_column_writer

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("arbace.pprint")

var Lit_3 *jrt.String = jrt.Intern("*default-page-width*")

var Lit_4 *jrt.String = jrt.Intern("private")

var Lit_5 *jrt.String = jrt.Intern("dynamic")

var Lit_6 *jrt.String = jrt.Intern("line")

var Lit_7 *jrt.String = jrt.Intern("column")

var Lit_8 *jrt.String = jrt.Intern("file")

var Lit_9 *jrt.String = jrt.Intern("arbace/pprint/column_writer.ae")

var Lit_10 *jrt.String = jrt.Intern("get-field")

var Lit_11 *jrt.String = jrt.Intern("arglists")

var Lit_12 *jrt.String = jrt.Intern("this")

var Lit_13 *jrt.String = jrt.Intern("tag")

var Lit_14 *jrt.String = jrt.Intern("Writer")

var Lit_15 *jrt.String = jrt.Intern("sym")

var Lit_16 *jrt.String = jrt.Intern("set-field")

var Lit_17 *jrt.String = jrt.Intern("new-val")

var Lit_18 *jrt.String = jrt.Intern("get-column")

var Lit_19 *jrt.String = jrt.Intern("get-line")

var Lit_20 *jrt.String = jrt.Intern("get-max-column")

var Lit_21 *jrt.String = jrt.Intern("set-max-column")

var Lit_22 *jrt.String = jrt.Intern("new-max")

var Lit_23 *jrt.String = jrt.Intern("get-writer")

var Lit_24 *jrt.String = jrt.Intern("c-write-char")

var Lit_25 *jrt.String = jrt.Intern("c")

var Lit_26 *jrt.String = jrt.Intern("Integer")

var Lit_27 *jrt.String = jrt.Intern("column-writer")

var Lit_28 *jrt.String = jrt.Intern("writer")

var Lit_29 *jrt.String = jrt.Intern("max-columns")

var Lit_30 *jrt.String = jrt.Intern("get-proxy-class")

var Lit_31 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_32 *jrt.String = jrt.Intern("arbace.lang.IDeref")
