//line aot_arbace_pprint_column_writer__init.ae:1
package aot_arbace_pprint_column_writer

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_column_writer__init_A_Load__O() any { A_arbace_pprint_column_writer__init_A_Init(); A_arbace_pprint_column_writer__init_A_Unit0__O(); A_arbace_pprint_column_writer__init_A_Unit1__O(); A_arbace_pprint_column_writer__init_A_Unit2__O(); A_arbace_pprint_column_writer__init_A_Unit3__O(); A_arbace_pprint_column_writer__init_A_Unit4__O(); A_arbace_pprint_column_writer__init_A_Unit5__O(); A_arbace_pprint_column_writer__init_A_Unit6__O(); A_arbace_pprint_column_writer__init_A_Unit7__O(); A_arbace_pprint_column_writer__init_A_Unit8__O(); A_arbace_pprint_column_writer__init_A_Unit9__O(); A_arbace_pprint_column_writer__init_A_Unit10__O(); A_arbace_pprint_column_writer__init_A_Unit11__O(); A_arbace_pprint_column_writer__init_A_Unit12__O(); return nil }











func A_arbace_pprint_column_writer__init_A_Unit0__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return lang.IFn_Cast(jrt.NN(A_arbace_pprint_column_writer__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_column_writer__init_A_const_1) }

func A_arbace_pprint_column_writer__init_A_Unit1__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_32)); return nil }
//line :19:1
func A_arbace_pprint_column_writer__init_A_Unit2__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_31)); return nil }


func A_arbace_pprint_column_writer__init_A_Unit3__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); jrt.NN(A_arbace_pprint_column_writer__init_A_const_2).BindRoot_O__V(A_arbace_pprint_column_writer__init_A_const_3); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_2; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_4)); return jrt.NN(A_arbace_pprint_column_writer__init_A_const_2).SetDynamic_Z__Var(true).Ref() }

func A_arbace_pprint_column_writer__init_A_Unit4__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_5; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_field_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_get_field_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_get_field_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_5; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_6)); return A_arbace_pprint_column_writer__init_A_const_5.Ref() }


func A_arbace_pprint_column_writer__init_A_Unit5__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_7; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_field_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_set_field_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_set_field_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_7; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_8)); return A_arbace_pprint_column_writer__init_A_const_7.Ref() }


func A_arbace_pprint_column_writer__init_A_Unit6__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_9; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_column_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_get_column_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_get_column_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_10)); return A_arbace_pprint_column_writer__init_A_const_9.Ref() }


func A_arbace_pprint_column_writer__init_A_Unit7__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_11; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_line_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_get_line_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_get_line_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_12)); return A_arbace_pprint_column_writer__init_A_const_11.Ref() }


func A_arbace_pprint_column_writer__init_A_Unit8__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_13; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_max_column_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_get_max_column_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_get_max_column_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_14)); return A_arbace_pprint_column_writer__init_A_const_13.Ref() }


func A_arbace_pprint_column_writer__init_A_Unit9__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_15; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_max_column_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_set_max_column_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_set_max_column_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_16)); return A_arbace_pprint_column_writer__init_A_const_15.Ref() }



func A_arbace_pprint_column_writer__init_A_Unit10__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(43, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_17; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_writer_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_get_writer_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_get_writer_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_18)); return A_arbace_pprint_column_writer__init_A_const_17.Ref() }


func A_arbace_pprint_column_writer__init_A_Unit11__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_19; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_c_write_char_A_New(); var tmp3 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_c_write_char_A_Init(); tmp3 = aot_arbace_pprint.A_arbace_pprint_c_write_char_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_20)); return A_arbace_pprint_column_writer__init_A_const_19.Ref() }







func A_arbace_pprint_column_writer__init_A_Unit12__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V(54, 1); var tmp1 any = A_arbace_pprint_column_writer__init_A_const_24.Ref(); lang.IFn_Cast(jrt.NN(A_arbace_pprint_column_writer__init_A_const_23).GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq(tmp1, lang.RT_Seq_O__ISeq(jrt.RefArrayOf(jrt.Object_class, A_arbace_pprint_column_writer__init_A_const_25.Ref())))); var tmp2 *lang.Var = A_arbace_pprint_column_writer__init_A_const_21; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_column_writer_A_New(); var tmp4 *jrt.Class; aot_arbace_pprint.A_arbace_pprint_column_writer_A_Init(); tmp4 = aot_arbace_pprint.A_arbace_pprint_column_writer_A_fn_class; jrt.NN(tmp2).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_pprint_column_writer__init_A_const_21; jrt.NN(tmp5).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_22)); return A_arbace_pprint_column_writer__init_A_const_21.Ref() }



type A_arbace_pprint_column_writer__init_A struct{ jrt.Object }

var A_arbace_pprint_column_writer__init_A_const_0 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_1 any

var A_arbace_pprint_column_writer__init_A_const_2 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_3 any

var A_arbace_pprint_column_writer__init_A_const_4 any

var A_arbace_pprint_column_writer__init_A_const_5 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_6 any

var A_arbace_pprint_column_writer__init_A_const_7 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_8 any

var A_arbace_pprint_column_writer__init_A_const_9 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_10 any

var A_arbace_pprint_column_writer__init_A_const_11 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_12 any

var A_arbace_pprint_column_writer__init_A_const_13 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_14 any

var A_arbace_pprint_column_writer__init_A_const_15 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_16 any

var A_arbace_pprint_column_writer__init_A_const_17 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_18 any

var A_arbace_pprint_column_writer__init_A_const_19 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_20 any

var A_arbace_pprint_column_writer__init_A_const_21 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_22 any

var A_arbace_pprint_column_writer__init_A_const_23 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_24 *jrt.Class

var A_arbace_pprint_column_writer__init_A_const_25 *jrt.Class

var A_arbace_pprint_column_writer__init_A_init jrt.ClassInit

func A_arbace_pprint_column_writer__init_A_Init() { if !A_arbace_pprint_column_writer__init_A_init.Done() { A_arbace_pprint_column_writer__init_A_init.Run(A_arbace_pprint_column_writer__init_A_clinit) } }

func A_arbace_pprint_column_writer__init_A_clinit() { A_arbace_pprint_column_writer__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_pprint_column_writer__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_2).Ref(); A_arbace_pprint_column_writer__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_2, Lit_3); A_arbace_pprint_column_writer__init_A_const_3 = jrt.Long_ValueOf_J__Long(72).Ref(); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_5).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_pprint_column_writer__init_A_const_4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_2, Lit_10); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_pprint_column_writer__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_2, Lit_16); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_pprint_column_writer__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_2, Lit_18); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_pprint_column_writer__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_2, Lit_19); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_pprint_column_writer__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_2, Lit_20); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_pprint_column_writer__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_2, Lit_21); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_pprint_column_writer__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_22).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_2, Lit_23); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_pprint_column_writer__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(43).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_2, Lit_24); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_pprint_column_writer__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_26).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_2, Lit_27); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_pprint_column_writer__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref()), lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_28)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(54).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_pprint_column_writer__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_pprint_column_writer__init_A_const_24 = lang.RT_ClassForNameNonLoading_String__Class(Lit_31); A_arbace_pprint_column_writer__init_A_const_25 = lang.RT_ClassForNameNonLoading_String__Class(Lit_32) }

func A_arbace_pprint_column_writer__init_A_New() *A_arbace_pprint_column_writer__init_A { A_arbace_pprint_column_writer__init_A_Init(); t := &A_arbace_pprint_column_writer__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_column_writer__init_A) Ctor() {}

func (t *A_arbace_pprint_column_writer__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_column_writer__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_column_writer__init_A_class }

func (t *A_arbace_pprint_column_writer__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_column_writer__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_pprint_column_writer__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_column_writer__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_column_writer__init_A); return ok }

func A_arbace_pprint_column_writer__init_A_Cast(x any) *A_arbace_pprint_column_writer__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_column_writer__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_column_writer__init_A_class)) }; return v }
