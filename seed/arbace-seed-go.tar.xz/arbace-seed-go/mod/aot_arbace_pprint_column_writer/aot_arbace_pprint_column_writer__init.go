//line aot_arbace_pprint_column_writer__init.ae:1
package aot_arbace_pprint_column_writer

import (
	"arbace/aot_arbace_pprint"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_pprint_column_writer__init_A_Load__O() any { A_arbace_pprint_column_writer__init_A_Init(); jrt.StartCheck(); A_arbace_pprint_column_writer__init_A_Unit0__O(); A_arbace_pprint_column_writer__init_A_Unit1__O(); A_arbace_pprint_column_writer__init_A_Unit2__O(); A_arbace_pprint_column_writer__init_A_Unit3__O(); A_arbace_pprint_column_writer__init_A_Unit4__O(); A_arbace_pprint_column_writer__init_A_Unit5__O(); A_arbace_pprint_column_writer__init_A_Unit6__O(); A_arbace_pprint_column_writer__init_A_Unit7__O(); A_arbace_pprint_column_writer__init_A_Unit8__O(); A_arbace_pprint_column_writer__init_A_Unit9__O(); A_arbace_pprint_column_writer__init_A_Unit10__O(); A_arbace_pprint_column_writer__init_A_Unit11__O(); A_arbace_pprint_column_writer__init_A_Unit12__O(); return nil }











func A_arbace_pprint_column_writer__init_A_Unit0__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); return lang.IFn_Cast(A_arbace_pprint_column_writer__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_pprint_column_writer__init_A_const_1) }

func A_arbace_pprint_column_writer__init_A_Unit1__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_1)).Ref() }
//line :19:1
func A_arbace_pprint_column_writer__init_A_Unit2__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); return jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_2)).Ref() }


func A_arbace_pprint_column_writer__init_A_Unit3__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); A_arbace_pprint_column_writer__init_A_const_2.BindRoot_O__V(A_arbace_pprint_column_writer__init_A_const_3); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_4)); return A_arbace_pprint_column_writer__init_A_const_2.SetDynamic_Z__Var(true).Ref() }

func A_arbace_pprint_column_writer__init_A_Unit4__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_5; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_field_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_field_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); aot_arbace_pprint.A_arbace_pprint_get_field_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_6)); return A_arbace_pprint_column_writer__init_A_const_5 }


func A_arbace_pprint_column_writer__init_A_Unit5__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_7; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_field_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_field_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); aot_arbace_pprint.A_arbace_pprint_set_field_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_8)); return A_arbace_pprint_column_writer__init_A_const_7 }


func A_arbace_pprint_column_writer__init_A_Unit6__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_9; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_column_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_column_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); aot_arbace_pprint.A_arbace_pprint_get_column_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_10)); return A_arbace_pprint_column_writer__init_A_const_9 }


func A_arbace_pprint_column_writer__init_A_Unit7__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_11; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_line_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_line_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); aot_arbace_pprint.A_arbace_pprint_get_line_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_12)); return A_arbace_pprint_column_writer__init_A_const_11 }


func A_arbace_pprint_column_writer__init_A_Unit8__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_13; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_max_column_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_max_column_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); aot_arbace_pprint.A_arbace_pprint_get_max_column_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_14)); return A_arbace_pprint_column_writer__init_A_const_13 }


func A_arbace_pprint_column_writer__init_A_Unit9__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_15; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_set_max_column_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_set_max_column_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); aot_arbace_pprint.A_arbace_pprint_set_max_column_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_16)); return A_arbace_pprint_column_writer__init_A_const_15 }



func A_arbace_pprint_column_writer__init_A_Unit10__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_17; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_get_writer_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_get_writer_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); aot_arbace_pprint.A_arbace_pprint_get_writer_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_18)); return A_arbace_pprint_column_writer__init_A_const_17 }


func A_arbace_pprint_column_writer__init_A_Unit11__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_pprint_column_writer__init_A_const_19; var tmp2 any = aot_arbace_pprint.A_arbace_pprint_c_write_char_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_c_write_char_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); aot_arbace_pprint.A_arbace_pprint_c_write_char_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_pprint_column_writer__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_20)); return A_arbace_pprint_column_writer__init_A_const_19 }







func A_arbace_pprint_column_writer__init_A_Unit12__O() any { A_arbace_pprint_column_writer__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(54, 1); var tmp1 any = A_arbace_pprint_column_writer__init_A_const_24; lang.IFn_Cast(A_arbace_pprint_column_writer__init_A_const_23.GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq_NoInit(tmp1, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_pprint_column_writer__init_A_const_25)))); var tmp2 *lang.Var = A_arbace_pprint_column_writer__init_A_const_21; var tmp3 any = aot_arbace_pprint.A_arbace_pprint_column_writer_A_New(); var tmp4 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_pprint.A_arbace_pprint_column_writer_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); aot_arbace_pprint.A_arbace_pprint_column_writer_A_fn_class = fncls__9d; tmp4 = fncls__9d } else { tmp4 = fncls__9 }; tmp2.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_pprint_column_writer__init_A_const_21; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_pprint_column_writer__init_A_const_22)); return A_arbace_pprint_column_writer__init_A_const_21 }



type A_arbace_pprint_column_writer__init_A struct{ jrt.Object }

var A_arbace_pprint_column_writer__init_A_const_pool *jrt.RefArray

var A_arbace_pprint_column_writer__init_A_const_0 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_1 any

var A_arbace_pprint_column_writer__init_A_const_2 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_3 any

var A_arbace_pprint_column_writer__init_A_const_4 any

var A_arbace_pprint_column_writer__init_A_const_5 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_6 any

var A_arbace_pprint_column_writer__init_A_const_7 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_8 any

var A_arbace_pprint_column_writer__init_A_const_9 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_10 any

var A_arbace_pprint_column_writer__init_A_const_11 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_12 any

var A_arbace_pprint_column_writer__init_A_const_13 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_14 any

var A_arbace_pprint_column_writer__init_A_const_15 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_16 any

var A_arbace_pprint_column_writer__init_A_const_17 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_18 any

var A_arbace_pprint_column_writer__init_A_const_19 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_20 any

var A_arbace_pprint_column_writer__init_A_const_21 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_22 any

var A_arbace_pprint_column_writer__init_A_const_23 *lang.Var

var A_arbace_pprint_column_writer__init_A_const_24 *jrt.Class

var A_arbace_pprint_column_writer__init_A_const_25 *jrt.Class

var A_arbace_pprint_column_writer__init_A_init jrt.ClassInit

func A_arbace_pprint_column_writer__init_A_Init() { if !A_arbace_pprint_column_writer__init_A_init.Done() { A_arbace_pprint_column_writer__init_A_init.Run(A_arbace_pprint_column_writer__init_A_clinit) } }

func A_arbace_pprint_column_writer__init_A_clinit() { jrt.StartCheck(); A_arbace_pprint_column_writer__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 42); A_arbace_pprint_column_writer__init_A_const_0 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[16]); A_arbace_pprint_column_writer__init_A_const_1 = A_arbace_pprint_column_writer__init_A_const_pool.A[17]; A_arbace_pprint_column_writer__init_A_const_2 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[18]); A_arbace_pprint_column_writer__init_A_const_3 = A_arbace_pprint_column_writer__init_A_const_pool.A[19]; A_arbace_pprint_column_writer__init_A_const_4 = A_arbace_pprint_column_writer__init_A_const_pool.A[20]; A_arbace_pprint_column_writer__init_A_const_5 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[21]); A_arbace_pprint_column_writer__init_A_const_6 = A_arbace_pprint_column_writer__init_A_const_pool.A[22]; A_arbace_pprint_column_writer__init_A_const_7 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[23]); A_arbace_pprint_column_writer__init_A_const_8 = A_arbace_pprint_column_writer__init_A_const_pool.A[24]; A_arbace_pprint_column_writer__init_A_const_9 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[25]); A_arbace_pprint_column_writer__init_A_const_10 = A_arbace_pprint_column_writer__init_A_const_pool.A[26]; A_arbace_pprint_column_writer__init_A_const_11 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[27]); A_arbace_pprint_column_writer__init_A_const_12 = A_arbace_pprint_column_writer__init_A_const_pool.A[28]; A_arbace_pprint_column_writer__init_A_const_13 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[29]); A_arbace_pprint_column_writer__init_A_const_14 = A_arbace_pprint_column_writer__init_A_const_pool.A[30]; A_arbace_pprint_column_writer__init_A_const_15 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[31]); A_arbace_pprint_column_writer__init_A_const_16 = A_arbace_pprint_column_writer__init_A_const_pool.A[32]; A_arbace_pprint_column_writer__init_A_const_17 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[33]); A_arbace_pprint_column_writer__init_A_const_18 = A_arbace_pprint_column_writer__init_A_const_pool.A[34]; A_arbace_pprint_column_writer__init_A_const_19 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[35]); A_arbace_pprint_column_writer__init_A_const_20 = A_arbace_pprint_column_writer__init_A_const_pool.A[36]; A_arbace_pprint_column_writer__init_A_const_21 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[37]); A_arbace_pprint_column_writer__init_A_const_22 = A_arbace_pprint_column_writer__init_A_const_pool.A[38]; A_arbace_pprint_column_writer__init_A_const_23 = lang.Var_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[39]); A_arbace_pprint_column_writer__init_A_const_24 = jrt.Class_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[40]); A_arbace_pprint_column_writer__init_A_const_25 = jrt.Class_Cast(A_arbace_pprint_column_writer__init_A_const_pool.A[41]) }

func A_arbace_pprint_column_writer__init_A_New() *A_arbace_pprint_column_writer__init_A { A_arbace_pprint_column_writer__init_A_Init(); t := &A_arbace_pprint_column_writer__init_A{}; t.Ctor(); return t }

func (t *A_arbace_pprint_column_writer__init_A) Ctor() {}

func (t *A_arbace_pprint_column_writer__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_pprint_column_writer__init_A) GetClass__Class() *jrt.Class { return A_arbace_pprint_column_writer__init_A_class }

func (t *A_arbace_pprint_column_writer__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_pprint_column_writer__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_pprint_column_writer__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_pprint_column_writer__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_pprint_column_writer__init_A); return ok }

func A_arbace_pprint_column_writer__init_A_Cast(x any) *A_arbace_pprint_column_writer__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_pprint_column_writer__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_pprint_column_writer__init_A_class)) }; return v }
