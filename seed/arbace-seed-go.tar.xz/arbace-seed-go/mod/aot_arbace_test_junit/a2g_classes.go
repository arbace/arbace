//line a2g_classes.ae:1
package aot_arbace_test_junit

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_test_junit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_A_New()}; return nil }

var A_arbace_test_junit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_A_new}

var A_arbace_test_junit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_A"})

func init() { i := A_arbace_test_junit_A_class.Info(); i.IsInstance = A_arbace_test_junit_A_InstanceOf; i.Init = A_arbace_test_junit_A_Init; i.Table = A_arbace_test_junit_A_members; jrt.RegisterGoType(A_arbace_test_junit_A_class, reflect.TypeFor[A_arbace_test_junit_A]()) }

func A_arbace_test_junit_element_content_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_element_content_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_element_content_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_element_content_A_New()}; return nil }

func A_arbace_test_junit_element_content_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_element_content_A_fn_class)}; return nil }

var A_arbace_test_junit_element_content_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_element_content_A_invoke, New: A_arbace_test_junit_element_content_A_new, Get: A_arbace_test_junit_element_content_A_get}

var A_arbace_test_junit_element_content_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$element_content", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_A_class, Simple: "element_content", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_element_content_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_element_content_A_class.Info(); i.IsInstance = A_arbace_test_junit_element_content_A_InstanceOf; i.Init = A_arbace_test_junit_element_content_A_Init; i.Table = A_arbace_test_junit_element_content_A_members; jrt.RegisterGoType(A_arbace_test_junit_element_content_A_class, reflect.TypeFor[A_arbace_test_junit_element_content_A]()) }

func A_arbace_test_junit_error_el_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_error_el_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_test_junit_error_el_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_error_el_A_New()}; return nil }

func A_arbace_test_junit_error_el_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_error_el_A_fn_class)}; return nil }

var A_arbace_test_junit_error_el_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_error_el_A_invoke, New: A_arbace_test_junit_error_el_A_new, Get: A_arbace_test_junit_error_el_A_get}

var A_arbace_test_junit_error_el_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$error_el", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_test_junit_A_class, Simple: "error_el", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_error_el_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_error_el_A_class.Info(); i.IsInstance = A_arbace_test_junit_error_el_A_InstanceOf; i.Init = A_arbace_test_junit_error_el_A_Init; i.Table = A_arbace_test_junit_error_el_A_members; jrt.RegisterGoType(A_arbace_test_junit_error_el_A_class, reflect.TypeFor[A_arbace_test_junit_error_el_A]()) }

func A_arbace_test_junit_error_el_fn__197000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_error_el_fn__197000055_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_junit_error_el_fn__197000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_error_el_fn__197000055_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_test_junit_error_el_fn__197000055_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_error_el_fn__197000055_A_fn_class)}; return nil }

var A_arbace_test_junit_error_el_fn__197000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_error_el_fn__197000055_A_invoke, New: A_arbace_test_junit_error_el_fn__197000055_A_new, Get: A_arbace_test_junit_error_el_fn__197000055_A_get}

var A_arbace_test_junit_error_el_fn__197000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$error_el$fn__197000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_junit_error_el_A_class, Simple: "fn__197000055", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_error_el_fn__197000055_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_error_el_fn__197000055_A_class.Info(); i.IsInstance = A_arbace_test_junit_error_el_fn__197000055_A_InstanceOf; i.Init = A_arbace_test_junit_error_el_fn__197000055_A_Init; i.Table = A_arbace_test_junit_error_el_fn__197000055_A_members; jrt.RegisterGoType(A_arbace_test_junit_error_el_fn__197000055_A_class, reflect.TypeFor[A_arbace_test_junit_error_el_fn__197000055_A]()) }

func A_arbace_test_junit_escape_xml_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_escape_xml_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_escape_xml_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_escape_xml_A_New()}; return nil }

func A_arbace_test_junit_escape_xml_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_escape_xml_A_fn_class)}; return nil }

var A_arbace_test_junit_escape_xml_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_escape_xml_A_invoke, New: A_arbace_test_junit_escape_xml_A_new, Get: A_arbace_test_junit_escape_xml_A_get}

var A_arbace_test_junit_escape_xml_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$escape_xml", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_A_class, Simple: "escape_xml", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_escape_xml_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_escape_xml_A_class.Info(); i.IsInstance = A_arbace_test_junit_escape_xml_A_InstanceOf; i.Init = A_arbace_test_junit_escape_xml_A_Init; i.Table = A_arbace_test_junit_escape_xml_A_members; jrt.RegisterGoType(A_arbace_test_junit_escape_xml_A_class, reflect.TypeFor[A_arbace_test_junit_escape_xml_A]()) }

func A_arbace_test_junit_escape_xml_fn__197000016_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_escape_xml_fn__197000016_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_escape_xml_fn__197000016_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_escape_xml_fn__197000016_A_New()}; return nil }

func A_arbace_test_junit_escape_xml_fn__197000016_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class)}; return nil }

var A_arbace_test_junit_escape_xml_fn__197000016_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_escape_xml_fn__197000016_A_invoke, New: A_arbace_test_junit_escape_xml_fn__197000016_A_new, Get: A_arbace_test_junit_escape_xml_fn__197000016_A_get}

var A_arbace_test_junit_escape_xml_fn__197000016_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$escape_xml$fn__197000016", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_escape_xml_A_class, Simple: "fn__197000016", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_escape_xml_fn__197000016_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_escape_xml_fn__197000016_A_class.Info(); i.IsInstance = A_arbace_test_junit_escape_xml_fn__197000016_A_InstanceOf; i.Init = A_arbace_test_junit_escape_xml_fn__197000016_A_Init; i.Table = A_arbace_test_junit_escape_xml_fn__197000016_A_members; jrt.RegisterGoType(A_arbace_test_junit_escape_xml_fn__197000016_A_class, reflect.TypeFor[A_arbace_test_junit_escape_xml_fn__197000016_A]()) }

func A_arbace_test_junit_eval197000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000004_A_New()}; return nil }

var A_arbace_test_junit_eval197000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000004_A_new}

var A_arbace_test_junit_eval197000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000004", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000004_A"})

func init() { i := A_arbace_test_junit_eval197000004_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000004_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000004_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000004_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000004_A]()) }

func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_New()}; return nil }

func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_invoke, New: A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_new, Get: A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_get}

var A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000004$loading__1927001464__auto____197000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_junit_eval197000004_A_class, Simple: "loading__1927001464__auto____197000005", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_Init; i.Table = A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A]()) }

func A_arbace_test_junit_eval197000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000008_A_New()}; return nil }

var A_arbace_test_junit_eval197000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000008_A_new}

var A_arbace_test_junit_eval197000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000008", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000008_A"})

func init() { i := A_arbace_test_junit_eval197000008_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000008_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000008_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000008_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000008_A]()) }

func A_arbace_test_junit_eval197000008_fn__197000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000008_fn__197000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_junit_eval197000008_fn__197000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000008_fn__197000009_A_New()}; return nil }

func A_arbace_test_junit_eval197000008_fn__197000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000008_fn__197000009_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000008_fn__197000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000008_fn__197000009_A_invoke, New: A_arbace_test_junit_eval197000008_fn__197000009_A_new, Get: A_arbace_test_junit_eval197000008_fn__197000009_A_get}

var A_arbace_test_junit_eval197000008_fn__197000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000008$fn__197000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_junit_eval197000008_A_class, Simple: "fn__197000009", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000008_fn__197000009_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000008_fn__197000009_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000008_fn__197000009_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000008_fn__197000009_A_Init; i.Table = A_arbace_test_junit_eval197000008_fn__197000009_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000008_fn__197000009_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000008_fn__197000009_A]()) }

func A_arbace_test_junit_eval197000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000060_A_New()}; return nil }

var A_arbace_test_junit_eval197000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000060_A_new}

var A_arbace_test_junit_eval197000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000060", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000060_A"})

func init() { i := A_arbace_test_junit_eval197000060_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000060_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000060_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000060_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000060_A]()) }

func A_arbace_test_junit_eval197000060_fn__197000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000060_fn__197000061_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_eval197000060_fn__197000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000060_fn__197000061_A_New()}; return nil }

func A_arbace_test_junit_eval197000060_fn__197000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000060_fn__197000061_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000060_fn__197000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000060_fn__197000061_A_invoke, New: A_arbace_test_junit_eval197000060_fn__197000061_A_new, Get: A_arbace_test_junit_eval197000060_fn__197000061_A_get}

var A_arbace_test_junit_eval197000060_fn__197000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000060$fn__197000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_eval197000060_A_class, Simple: "fn__197000061", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000060_fn__197000061_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000060_fn__197000061_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000060_fn__197000061_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000060_fn__197000061_A_Init; i.Table = A_arbace_test_junit_eval197000060_fn__197000061_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000060_fn__197000061_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000060_fn__197000061_A]()) }

func A_arbace_test_junit_eval197000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000064_A_New()}; return nil }

var A_arbace_test_junit_eval197000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000064_A_new}

var A_arbace_test_junit_eval197000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000064", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000064_A"})

func init() { i := A_arbace_test_junit_eval197000064_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000064_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000064_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000064_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000064_A]()) }

func A_arbace_test_junit_eval197000064_fn__197000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000064_fn__197000065_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_eval197000064_fn__197000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000064_fn__197000065_A_New()}; return nil }

func A_arbace_test_junit_eval197000064_fn__197000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000064_fn__197000065_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000064_fn__197000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000064_fn__197000065_A_invoke, New: A_arbace_test_junit_eval197000064_fn__197000065_A_new, Get: A_arbace_test_junit_eval197000064_fn__197000065_A_get}

var A_arbace_test_junit_eval197000064_fn__197000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000064$fn__197000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_eval197000064_A_class, Simple: "fn__197000065", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000064_fn__197000065_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000064_fn__197000065_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000064_fn__197000065_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000064_fn__197000065_A_Init; i.Table = A_arbace_test_junit_eval197000064_fn__197000065_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000064_fn__197000065_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000064_fn__197000065_A]()) }

func A_arbace_test_junit_eval197000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000068_A_New()}; return nil }

var A_arbace_test_junit_eval197000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000068_A_new}

var A_arbace_test_junit_eval197000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000068", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000068_A"})

func init() { i := A_arbace_test_junit_eval197000068_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000068_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000068_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000068_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000068_A]()) }

func A_arbace_test_junit_eval197000068_fn__197000069_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000068_fn__197000069_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_eval197000068_fn__197000069_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000068_fn__197000069_A_New()}; return nil }

func A_arbace_test_junit_eval197000068_fn__197000069_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000068_fn__197000069_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000068_fn__197000069_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000068_fn__197000069_A_invoke, New: A_arbace_test_junit_eval197000068_fn__197000069_A_new, Get: A_arbace_test_junit_eval197000068_fn__197000069_A_get}

var A_arbace_test_junit_eval197000068_fn__197000069_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000068$fn__197000069", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_eval197000068_A_class, Simple: "fn__197000069", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000068_fn__197000069_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000068_fn__197000069_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000068_fn__197000069_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000068_fn__197000069_A_Init; i.Table = A_arbace_test_junit_eval197000068_fn__197000069_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000068_fn__197000069_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000068_fn__197000069_A]()) }

func A_arbace_test_junit_eval197000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000072_A_New()}; return nil }

var A_arbace_test_junit_eval197000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000072_A_new}

var A_arbace_test_junit_eval197000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000072", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000072_A"})

func init() { i := A_arbace_test_junit_eval197000072_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000072_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000072_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000072_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000072_A]()) }

func A_arbace_test_junit_eval197000072_fn__197000073_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000072_fn__197000073_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_eval197000072_fn__197000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000072_fn__197000073_A_New()}; return nil }

func A_arbace_test_junit_eval197000072_fn__197000073_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000072_fn__197000073_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000072_fn__197000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000072_fn__197000073_A_invoke, New: A_arbace_test_junit_eval197000072_fn__197000073_A_new, Get: A_arbace_test_junit_eval197000072_fn__197000073_A_get}

var A_arbace_test_junit_eval197000072_fn__197000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000072$fn__197000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_eval197000072_A_class, Simple: "fn__197000073", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000072_fn__197000073_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000072_fn__197000073_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000072_fn__197000073_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000072_fn__197000073_A_Init; i.Table = A_arbace_test_junit_eval197000072_fn__197000073_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000072_fn__197000073_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000072_fn__197000073_A]()) }

func A_arbace_test_junit_eval197000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000076_A_New()}; return nil }

var A_arbace_test_junit_eval197000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000076_A_new}

var A_arbace_test_junit_eval197000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000076", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000076_A"})

func init() { i := A_arbace_test_junit_eval197000076_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000076_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000076_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000076_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000076_A]()) }

func A_arbace_test_junit_eval197000076_fn__197000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000076_fn__197000077_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_eval197000076_fn__197000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000076_fn__197000077_A_New()}; return nil }

func A_arbace_test_junit_eval197000076_fn__197000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000076_fn__197000077_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000076_fn__197000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000076_fn__197000077_A_invoke, New: A_arbace_test_junit_eval197000076_fn__197000077_A_new, Get: A_arbace_test_junit_eval197000076_fn__197000077_A_get}

var A_arbace_test_junit_eval197000076_fn__197000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000076$fn__197000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_eval197000076_A_class, Simple: "fn__197000077", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000076_fn__197000077_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000076_fn__197000077_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000076_fn__197000077_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000076_fn__197000077_A_Init; i.Table = A_arbace_test_junit_eval197000076_fn__197000077_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000076_fn__197000077_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000076_fn__197000077_A]()) }

func A_arbace_test_junit_eval197000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000080_A_New()}; return nil }

var A_arbace_test_junit_eval197000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000080_A_new}

var A_arbace_test_junit_eval197000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000080", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000080_A"})

func init() { i := A_arbace_test_junit_eval197000080_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000080_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000080_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000080_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000080_A]()) }

func A_arbace_test_junit_eval197000080_fn__197000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000080_fn__197000081_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_eval197000080_fn__197000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000080_fn__197000081_A_New()}; return nil }

func A_arbace_test_junit_eval197000080_fn__197000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000080_fn__197000081_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000080_fn__197000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000080_fn__197000081_A_invoke, New: A_arbace_test_junit_eval197000080_fn__197000081_A_new, Get: A_arbace_test_junit_eval197000080_fn__197000081_A_get}

var A_arbace_test_junit_eval197000080_fn__197000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000080$fn__197000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_eval197000080_A_class, Simple: "fn__197000081", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000080_fn__197000081_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000080_fn__197000081_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000080_fn__197000081_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000080_fn__197000081_A_Init; i.Table = A_arbace_test_junit_eval197000080_fn__197000081_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000080_fn__197000081_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000080_fn__197000081_A]()) }

func A_arbace_test_junit_eval197000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000084_A_New()}; return nil }

var A_arbace_test_junit_eval197000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000084_A_new}

var A_arbace_test_junit_eval197000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000084", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000084_A"})

func init() { i := A_arbace_test_junit_eval197000084_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000084_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000084_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000084_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000084_A]()) }

func A_arbace_test_junit_eval197000084_fn__197000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000084_fn__197000085_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_eval197000084_fn__197000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000084_fn__197000085_A_New()}; return nil }

func A_arbace_test_junit_eval197000084_fn__197000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000084_fn__197000085_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000084_fn__197000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000084_fn__197000085_A_invoke, New: A_arbace_test_junit_eval197000084_fn__197000085_A_new, Get: A_arbace_test_junit_eval197000084_fn__197000085_A_get}

var A_arbace_test_junit_eval197000084_fn__197000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000084$fn__197000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_eval197000084_A_class, Simple: "fn__197000085", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000084_fn__197000085_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000084_fn__197000085_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000084_fn__197000085_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000084_fn__197000085_A_Init; i.Table = A_arbace_test_junit_eval197000084_fn__197000085_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000084_fn__197000085_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000084_fn__197000085_A]()) }

func A_arbace_test_junit_eval197000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000088_A_New()}; return nil }

var A_arbace_test_junit_eval197000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000088_A_new}

var A_arbace_test_junit_eval197000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000088", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000088_A"})

func init() { i := A_arbace_test_junit_eval197000088_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000088_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000088_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000088_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000088_A]()) }

func A_arbace_test_junit_eval197000088_fn__197000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_eval197000088_fn__197000089_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_eval197000088_fn__197000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000088_fn__197000089_A_New()}; return nil }

func A_arbace_test_junit_eval197000088_fn__197000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_eval197000088_fn__197000089_A_fn_class)}; return nil }

var A_arbace_test_junit_eval197000088_fn__197000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_eval197000088_fn__197000089_A_invoke, New: A_arbace_test_junit_eval197000088_fn__197000089_A_new, Get: A_arbace_test_junit_eval197000088_fn__197000089_A_get}

var A_arbace_test_junit_eval197000088_fn__197000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000088$fn__197000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_eval197000088_A_class, Simple: "fn__197000089", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000088_fn__197000089_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_eval197000088_fn__197000089_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000088_fn__197000089_A_InstanceOf; i.Init = A_arbace_test_junit_eval197000088_fn__197000089_A_Init; i.Table = A_arbace_test_junit_eval197000088_fn__197000089_A_members; jrt.RegisterGoType(A_arbace_test_junit_eval197000088_fn__197000089_A_class, reflect.TypeFor[A_arbace_test_junit_eval197000088_fn__197000089_A]()) }

func A_arbace_test_junit_failure_el_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_failure_el_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_test_junit_failure_el_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_failure_el_A_New()}; return nil }

func A_arbace_test_junit_failure_el_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_failure_el_A_fn_class)}; return nil }

var A_arbace_test_junit_failure_el_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_failure_el_A_invoke, New: A_arbace_test_junit_failure_el_A_new, Get: A_arbace_test_junit_failure_el_A_get}

var A_arbace_test_junit_failure_el_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$failure_el", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_test_junit_A_class, Simple: "failure_el", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_failure_el_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_failure_el_A_class.Info(); i.IsInstance = A_arbace_test_junit_failure_el_A_InstanceOf; i.Init = A_arbace_test_junit_failure_el_A_Init; i.Table = A_arbace_test_junit_failure_el_A_members; jrt.RegisterGoType(A_arbace_test_junit_failure_el_A_class, reflect.TypeFor[A_arbace_test_junit_failure_el_A]()) }

func A_arbace_test_junit_finish_case_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_finish_case_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_junit_finish_case_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_finish_case_A_New()}; return nil }

func A_arbace_test_junit_finish_case_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_finish_case_A_fn_class)}; return nil }

var A_arbace_test_junit_finish_case_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_finish_case_A_invoke, New: A_arbace_test_junit_finish_case_A_new, Get: A_arbace_test_junit_finish_case_A_get}

var A_arbace_test_junit_finish_case_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$finish_case", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_junit_A_class, Simple: "finish_case", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_finish_case_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_finish_case_A_class.Info(); i.IsInstance = A_arbace_test_junit_finish_case_A_InstanceOf; i.Init = A_arbace_test_junit_finish_case_A_Init; i.Table = A_arbace_test_junit_finish_case_A_members; jrt.RegisterGoType(A_arbace_test_junit_finish_case_A_class, reflect.TypeFor[A_arbace_test_junit_finish_case_A]()) }

func A_arbace_test_junit_finish_element_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_finish_element_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_junit_finish_element_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_finish_element_A_New()}; return nil }

func A_arbace_test_junit_finish_element_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_finish_element_A_fn_class)}; return nil }

var A_arbace_test_junit_finish_element_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_finish_element_A_invoke, New: A_arbace_test_junit_finish_element_A_new, Get: A_arbace_test_junit_finish_element_A_get}

var A_arbace_test_junit_finish_element_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$finish_element", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_junit_A_class, Simple: "finish_element", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_finish_element_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_finish_element_A_class.Info(); i.IsInstance = A_arbace_test_junit_finish_element_A_InstanceOf; i.Init = A_arbace_test_junit_finish_element_A_Init; i.Table = A_arbace_test_junit_finish_element_A_members; jrt.RegisterGoType(A_arbace_test_junit_finish_element_A_class, reflect.TypeFor[A_arbace_test_junit_finish_element_A]()) }

func A_arbace_test_junit_finish_suite_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_finish_suite_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_junit_finish_suite_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_finish_suite_A_New()}; return nil }

func A_arbace_test_junit_finish_suite_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_finish_suite_A_fn_class)}; return nil }

var A_arbace_test_junit_finish_suite_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_finish_suite_A_invoke, New: A_arbace_test_junit_finish_suite_A_new, Get: A_arbace_test_junit_finish_suite_A_get}

var A_arbace_test_junit_finish_suite_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$finish_suite", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_junit_A_class, Simple: "finish_suite", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_finish_suite_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_finish_suite_A_class.Info(); i.IsInstance = A_arbace_test_junit_finish_suite_A_InstanceOf; i.Init = A_arbace_test_junit_finish_suite_A_Init; i.Table = A_arbace_test_junit_finish_suite_A_members; jrt.RegisterGoType(A_arbace_test_junit_finish_suite_A_class, reflect.TypeFor[A_arbace_test_junit_finish_suite_A]()) }

func A_arbace_test_junit_fn__197000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_fn__197000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_fn__197000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_fn__197000013_A_New()}; return nil }

func A_arbace_test_junit_fn__197000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_fn__197000013_A_fn_class)}; return nil }

var A_arbace_test_junit_fn__197000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_fn__197000013_A_invoke, New: A_arbace_test_junit_fn__197000013_A_new, Get: A_arbace_test_junit_fn__197000013_A_get}

var A_arbace_test_junit_fn__197000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$fn__197000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_A_class, Simple: "fn__197000013", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_fn__197000013_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_fn__197000013_A_class.Info(); i.IsInstance = A_arbace_test_junit_fn__197000013_A_InstanceOf; i.Init = A_arbace_test_junit_fn__197000013_A_Init; i.Table = A_arbace_test_junit_fn__197000013_A_members; jrt.RegisterGoType(A_arbace_test_junit_fn__197000013_A_class, reflect.TypeFor[A_arbace_test_junit_fn__197000013_A]()) }

func A_arbace_test_junit_indent_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_indent_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_test_junit_indent_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_indent_A_New()}; return nil }

func A_arbace_test_junit_indent_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_indent_A_fn_class)}; return nil }

var A_arbace_test_junit_indent_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_indent_A_invoke, New: A_arbace_test_junit_indent_A_new, Get: A_arbace_test_junit_indent_A_get}

var A_arbace_test_junit_indent_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$indent", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_test_junit_A_class, Simple: "indent", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_indent_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_indent_A_class.Info(); i.IsInstance = A_arbace_test_junit_indent_A_InstanceOf; i.Init = A_arbace_test_junit_indent_A_Init; i.Table = A_arbace_test_junit_indent_A_members; jrt.RegisterGoType(A_arbace_test_junit_indent_A_class, reflect.TypeFor[A_arbace_test_junit_indent_A]()) }

func A_arbace_test_junit_message_el_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_message_el_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_test_junit_message_el_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_message_el_A_New()}; return nil }

func A_arbace_test_junit_message_el_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_message_el_A_fn_class)}; return nil }

var A_arbace_test_junit_message_el_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_message_el_A_invoke, New: A_arbace_test_junit_message_el_A_new, Get: A_arbace_test_junit_message_el_A_get}

var A_arbace_test_junit_message_el_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$message_el", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_test_junit_A_class, Simple: "message_el", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_message_el_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_message_el_A_class.Info(); i.IsInstance = A_arbace_test_junit_message_el_A_InstanceOf; i.Init = A_arbace_test_junit_message_el_A_Init; i.Table = A_arbace_test_junit_message_el_A_members; jrt.RegisterGoType(A_arbace_test_junit_message_el_A_class, reflect.TypeFor[A_arbace_test_junit_message_el_A]()) }

func A_arbace_test_junit_package_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_package_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_package_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_package_class_A_New()}; return nil }

func A_arbace_test_junit_package_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_package_class_A_fn_class)}; return nil }

var A_arbace_test_junit_package_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_package_class_A_invoke, New: A_arbace_test_junit_package_class_A_new, Get: A_arbace_test_junit_package_class_A_get}

var A_arbace_test_junit_package_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$package_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_A_class, Simple: "package_class", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_package_class_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_package_class_A_class.Info(); i.IsInstance = A_arbace_test_junit_package_class_A_InstanceOf; i.Init = A_arbace_test_junit_package_class_A_Init; i.Table = A_arbace_test_junit_package_class_A_members; jrt.RegisterGoType(A_arbace_test_junit_package_class_A_class, reflect.TypeFor[A_arbace_test_junit_package_class_A]()) }

func A_arbace_test_junit_start_case_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_start_case_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_junit_start_case_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_start_case_A_New()}; return nil }

func A_arbace_test_junit_start_case_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_start_case_A_fn_class)}; return nil }

var A_arbace_test_junit_start_case_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_start_case_A_invoke, New: A_arbace_test_junit_start_case_A_new, Get: A_arbace_test_junit_start_case_A_get}

var A_arbace_test_junit_start_case_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$start_case", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_junit_A_class, Simple: "start_case", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_start_case_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_start_case_A_class.Info(); i.IsInstance = A_arbace_test_junit_start_case_A_InstanceOf; i.Init = A_arbace_test_junit_start_case_A_Init; i.Table = A_arbace_test_junit_start_case_A_members; jrt.RegisterGoType(A_arbace_test_junit_start_case_A_class, reflect.TypeFor[A_arbace_test_junit_start_case_A]()) }

func A_arbace_test_junit_start_element_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_start_element_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_test_junit_start_element_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_start_element_A_New()}; return nil }

func A_arbace_test_junit_start_element_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_start_element_A_fn_class)}; return nil }

var A_arbace_test_junit_start_element_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_start_element_A_invoke, New: A_arbace_test_junit_start_element_A_new, Get: A_arbace_test_junit_start_element_A_get}

var A_arbace_test_junit_start_element_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$start_element", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_test_junit_A_class, Simple: "start_element", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_start_element_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_start_element_A_class.Info(); i.IsInstance = A_arbace_test_junit_start_element_A_InstanceOf; i.Init = A_arbace_test_junit_start_element_A_Init; i.Table = A_arbace_test_junit_start_element_A_members; jrt.RegisterGoType(A_arbace_test_junit_start_element_A_class, reflect.TypeFor[A_arbace_test_junit_start_element_A]()) }

func A_arbace_test_junit_start_suite_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_start_suite_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_start_suite_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_start_suite_A_New()}; return nil }

func A_arbace_test_junit_start_suite_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_start_suite_A_fn_class)}; return nil }

var A_arbace_test_junit_start_suite_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_start_suite_A_invoke, New: A_arbace_test_junit_start_suite_A_new, Get: A_arbace_test_junit_start_suite_A_get}

var A_arbace_test_junit_start_suite_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$start_suite", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_A_class, Simple: "start_suite", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_start_suite_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_start_suite_A_class.Info(); i.IsInstance = A_arbace_test_junit_start_suite_A_InstanceOf; i.Init = A_arbace_test_junit_start_suite_A_Init; i.Table = A_arbace_test_junit_start_suite_A_members; jrt.RegisterGoType(A_arbace_test_junit_start_suite_A_class, reflect.TypeFor[A_arbace_test_junit_start_suite_A]()) }

func A_arbace_test_junit_suite_attrs_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_suite_attrs_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_test_junit_suite_attrs_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_suite_attrs_A_New()}; return nil }

func A_arbace_test_junit_suite_attrs_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_suite_attrs_A_fn_class)}; return nil }

var A_arbace_test_junit_suite_attrs_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_suite_attrs_A_invoke, New: A_arbace_test_junit_suite_attrs_A_new, Get: A_arbace_test_junit_suite_attrs_A_get}

var A_arbace_test_junit_suite_attrs_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$suite_attrs", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_test_junit_A_class, Simple: "suite_attrs", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_suite_attrs_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_suite_attrs_A_class.Info(); i.IsInstance = A_arbace_test_junit_suite_attrs_A_InstanceOf; i.Init = A_arbace_test_junit_suite_attrs_A_Init; i.Table = A_arbace_test_junit_suite_attrs_A_members; jrt.RegisterGoType(A_arbace_test_junit_suite_attrs_A_class, reflect.TypeFor[A_arbace_test_junit_suite_attrs_A]()) }

func A_arbace_test_junit_test_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_test_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_test_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_test_name_A_New()}; return nil }

func A_arbace_test_junit_test_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_test_name_A_fn_class)}; return nil }

var A_arbace_test_junit_test_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_test_name_A_invoke, New: A_arbace_test_junit_test_name_A_new, Get: A_arbace_test_junit_test_name_A_get}

var A_arbace_test_junit_test_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$test_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_A_class, Simple: "test_name", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_test_name_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_test_name_A_class.Info(); i.IsInstance = A_arbace_test_junit_test_name_A_InstanceOf; i.Init = A_arbace_test_junit_test_name_A_Init; i.Table = A_arbace_test_junit_test_name_A_members; jrt.RegisterGoType(A_arbace_test_junit_test_name_A_class, reflect.TypeFor[A_arbace_test_junit_test_name_A]()) }

func A_arbace_test_junit_test_name_fn__197000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_test_name_fn__197000038_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_test_junit_test_name_fn__197000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_test_name_fn__197000038_A_New()}; return nil }

func A_arbace_test_junit_test_name_fn__197000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_test_name_fn__197000038_A_fn_class)}; return nil }

var A_arbace_test_junit_test_name_fn__197000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_test_name_fn__197000038_A_invoke, New: A_arbace_test_junit_test_name_fn__197000038_A_new, Get: A_arbace_test_junit_test_name_fn__197000038_A_get}

var A_arbace_test_junit_test_name_fn__197000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$test_name$fn__197000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_test_junit_test_name_A_class, Simple: "fn__197000038", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_test_name_fn__197000038_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_test_name_fn__197000038_A_class.Info(); i.IsInstance = A_arbace_test_junit_test_name_fn__197000038_A_InstanceOf; i.Init = A_arbace_test_junit_test_name_fn__197000038_A_Init; i.Table = A_arbace_test_junit_test_name_fn__197000038_A_members; jrt.RegisterGoType(A_arbace_test_junit_test_name_fn__197000038_A_class, reflect.TypeFor[A_arbace_test_junit_test_name_fn__197000038_A]()) }

func A_arbace_test_junit_with_junit_output_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_test_junit_with_junit_output_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_test_junit_with_junit_output_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_with_junit_output_A_New()}; return nil }

func A_arbace_test_junit_with_junit_output_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_test_junit_with_junit_output_A_fn_class)}; return nil }

var A_arbace_test_junit_with_junit_output_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_test_junit_with_junit_output_A_invoke, New: A_arbace_test_junit_with_junit_output_A_new, Get: A_arbace_test_junit_with_junit_output_A_get}

var A_arbace_test_junit_with_junit_output_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$with_junit_output", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_test_junit_A_class, Simple: "with_junit_output", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_with_junit_output_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit_with_junit_output_A_class.Info(); i.IsInstance = A_arbace_test_junit_with_junit_output_A_InstanceOf; i.Init = A_arbace_test_junit_with_junit_output_A_Init; i.Table = A_arbace_test_junit_with_junit_output_A_members; jrt.RegisterGoType(A_arbace_test_junit_with_junit_output_A_class, reflect.TypeFor[A_arbace_test_junit_with_junit_output_A]()) }

func A_arbace_test_junit__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_test_junit__init_A_Load__O(); case 1: return A_arbace_test_junit__init_A_Unit0__O(); case 2: return A_arbace_test_junit__init_A_Unit1__O(); case 3: return A_arbace_test_junit__init_A_Unit10__O(); case 4: return A_arbace_test_junit__init_A_Unit11__O(); case 5: return A_arbace_test_junit__init_A_Unit12__O(); case 6: return A_arbace_test_junit__init_A_Unit13__O(); case 7: return A_arbace_test_junit__init_A_Unit14__O(); case 8: return A_arbace_test_junit__init_A_Unit15__O(); case 9: return A_arbace_test_junit__init_A_Unit16__O(); case 10: return A_arbace_test_junit__init_A_Unit17__O(); case 11: return A_arbace_test_junit__init_A_Unit18__O(); case 12: return A_arbace_test_junit__init_A_Unit19__O(); case 13: return A_arbace_test_junit__init_A_Unit2__O(); case 14: return A_arbace_test_junit__init_A_Unit20__O(); case 15: return A_arbace_test_junit__init_A_Unit21__O(); case 16: return A_arbace_test_junit__init_A_Unit22__O(); case 17: return A_arbace_test_junit__init_A_Unit23__O(); case 18: return A_arbace_test_junit__init_A_Unit24__O(); case 19: return A_arbace_test_junit__init_A_Unit25__O(); case 20: return A_arbace_test_junit__init_A_Unit26__O(); case 21: return A_arbace_test_junit__init_A_Unit27__O(); case 22: return A_arbace_test_junit__init_A_Unit28__O(); case 23: return A_arbace_test_junit__init_A_Unit29__O(); case 24: return A_arbace_test_junit__init_A_Unit3__O(); case 25: return A_arbace_test_junit__init_A_Unit30__O(); case 26: return A_arbace_test_junit__init_A_Unit31__O(); case 27: return A_arbace_test_junit__init_A_Unit32__O(); case 28: return A_arbace_test_junit__init_A_Unit33__O(); case 29: return A_arbace_test_junit__init_A_Unit4__O(); case 30: return A_arbace_test_junit__init_A_Unit5__O(); case 31: return A_arbace_test_junit__init_A_Unit6__O(); case 32: return A_arbace_test_junit__init_A_Unit7__O(); case 33: return A_arbace_test_junit__init_A_Unit8__O(); case 34: return A_arbace_test_junit__init_A_Unit9__O()}; return nil }

func A_arbace_test_junit__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit__init_A_New()}; return nil }

var A_arbace_test_junit__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_test_junit__init_A_invoke, New: A_arbace_test_junit__init_A_new}

var A_arbace_test_junit__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit__init_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit__init_A_class.Info(); i.IsInstance = A_arbace_test_junit__init_A_InstanceOf; i.Init = A_arbace_test_junit__init_A_Init; i.Table = A_arbace_test_junit__init_A_members; jrt.RegisterGoType(A_arbace_test_junit__init_A_class, reflect.TypeFor[A_arbace_test_junit__init_A]()) }
