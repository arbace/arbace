//line a2g_classes.ae:1
package aot_arbace_test_junit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_test_junit_element_content_A_class, Name: "arbace.test.junit$element_content", Modifiers: 25, Simple: "element_content", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_element_content_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_error_el_A_class, Name: "arbace.test.junit$error_el", Modifiers: 25, Simple: "error_el", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_error_el_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_error_el_fn__197000055_A_class, Name: "arbace.test.junit$error_el$fn__197000055", Modifiers: 25, Simple: "fn__197000055", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_error_el_fn__197000055_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_error_el_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_escape_xml_A_class, Name: "arbace.test.junit$escape_xml", Modifiers: 25, Simple: "escape_xml", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_escape_xml_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_escape_xml_fn__197000016_A_class, Name: "arbace.test.junit$escape_xml$fn__197000016", Modifiers: 25, Simple: "fn__197000016", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_escape_xml_fn__197000016_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_escape_xml_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_class, Name: "arbace.test.junit$eval197000004$loading__1927001464__auto____197000005", Modifiers: 25, Simple: "loading__1927001464__auto____197000005", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000008_fn__197000009_A_class, Name: "arbace.test.junit$eval197000008$fn__197000009", Modifiers: 25, Simple: "fn__197000009", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000008_fn__197000009_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000060_fn__197000061_A_class, Name: "arbace.test.junit$eval197000060$fn__197000061", Modifiers: 25, Simple: "fn__197000061", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000060_fn__197000061_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000060_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000064_fn__197000065_A_class, Name: "arbace.test.junit$eval197000064$fn__197000065", Modifiers: 25, Simple: "fn__197000065", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000064_fn__197000065_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000064_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000068_fn__197000069_A_class, Name: "arbace.test.junit$eval197000068$fn__197000069", Modifiers: 25, Simple: "fn__197000069", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000068_fn__197000069_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000068_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000072_fn__197000073_A_class, Name: "arbace.test.junit$eval197000072$fn__197000073", Modifiers: 25, Simple: "fn__197000073", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000072_fn__197000073_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000072_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000076_fn__197000077_A_class, Name: "arbace.test.junit$eval197000076$fn__197000077", Modifiers: 25, Simple: "fn__197000077", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000076_fn__197000077_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000076_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000080_fn__197000081_A_class, Name: "arbace.test.junit$eval197000080$fn__197000081", Modifiers: 25, Simple: "fn__197000081", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000080_fn__197000081_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000080_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000084_fn__197000085_A_class, Name: "arbace.test.junit$eval197000084$fn__197000085", Modifiers: 25, Simple: "fn__197000085", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000084_fn__197000085_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000084_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_eval197000088_fn__197000089_A_class, Name: "arbace.test.junit$eval197000088$fn__197000089", Modifiers: 25, Simple: "fn__197000089", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000088_fn__197000089_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_eval197000088_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_failure_el_A_class, Name: "arbace.test.junit$failure_el", Modifiers: 25, Simple: "failure_el", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_failure_el_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_finish_case_A_class, Name: "arbace.test.junit$finish_case", Modifiers: 25, Simple: "finish_case", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_finish_case_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_finish_element_A_class, Name: "arbace.test.junit$finish_element", Modifiers: 25, Simple: "finish_element", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_finish_element_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_finish_suite_A_class, Name: "arbace.test.junit$finish_suite", Modifiers: 25, Simple: "finish_suite", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_finish_suite_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_fn__197000013_A_class, Name: "arbace.test.junit$fn__197000013", Modifiers: 25, Simple: "fn__197000013", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_fn__197000013_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_indent_A_class, Name: "arbace.test.junit$indent", Modifiers: 25, Simple: "indent", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_indent_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_message_el_A_class, Name: "arbace.test.junit$message_el", Modifiers: 25, Simple: "message_el", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_message_el_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_package_class_A_class, Name: "arbace.test.junit$package_class", Modifiers: 25, Simple: "package_class", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_package_class_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_start_case_A_class, Name: "arbace.test.junit$start_case", Modifiers: 25, Simple: "start_case", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_start_case_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_start_element_A_class, Name: "arbace.test.junit$start_element", Modifiers: 25, Simple: "start_element", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_start_element_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_start_suite_A_class, Name: "arbace.test.junit$start_suite", Modifiers: 25, Simple: "start_suite", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_start_suite_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_suite_attrs_A_class, Name: "arbace.test.junit$suite_attrs", Modifiers: 25, Simple: "suite_attrs", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_suite_attrs_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_test_name_A_class, Name: "arbace.test.junit$test_name", Modifiers: 25, Simple: "test_name", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_test_name_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_test_name_fn__197000038_A_class, Name: "arbace.test.junit$test_name$fn__197000038", Modifiers: 25, Simple: "fn__197000038", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_test_name_fn__197000038_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_test_name_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_test_junit_with_junit_output_A_class, Name: "arbace.test.junit$with_junit_output", Modifiers: 25, Simple: "with_junit_output", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_with_junit_output_A", Source: "junit.ae", Declaring: &A_arbace_test_junit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_test_junit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_A_New()}; return nil }

var A_arbace_test_junit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_A_new}

var A_arbace_test_junit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_A"})

func init() { i := A_arbace_test_junit_A_class.Info(); i.IsInstance = A_arbace_test_junit_A_InstanceOf; i.Init = A_arbace_test_junit_A_Init; i.Table = A_arbace_test_junit_A_members }

var A_arbace_test_junit_element_content_A_class *jrt.Class

var A_arbace_test_junit_error_el_A_class *jrt.Class

var A_arbace_test_junit_error_el_fn__197000055_A_class *jrt.Class

var A_arbace_test_junit_escape_xml_A_class *jrt.Class

var A_arbace_test_junit_escape_xml_fn__197000016_A_class *jrt.Class

func A_arbace_test_junit_eval197000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000004_A_New()}; return nil }

var A_arbace_test_junit_eval197000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000004_A_new}

var A_arbace_test_junit_eval197000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000004", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000004_A"})

func init() { i := A_arbace_test_junit_eval197000004_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000004_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000004_A_members }

var A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_class *jrt.Class

func A_arbace_test_junit_eval197000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000008_A_New()}; return nil }

var A_arbace_test_junit_eval197000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000008_A_new}

var A_arbace_test_junit_eval197000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000008", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000008_A"})

func init() { i := A_arbace_test_junit_eval197000008_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000008_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000008_A_members }

var A_arbace_test_junit_eval197000008_fn__197000009_A_class *jrt.Class

func A_arbace_test_junit_eval197000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000060_A_New()}; return nil }

var A_arbace_test_junit_eval197000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000060_A_new}

var A_arbace_test_junit_eval197000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000060", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000060_A"})

func init() { i := A_arbace_test_junit_eval197000060_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000060_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000060_A_members }

var A_arbace_test_junit_eval197000060_fn__197000061_A_class *jrt.Class

func A_arbace_test_junit_eval197000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000064_A_New()}; return nil }

var A_arbace_test_junit_eval197000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000064_A_new}

var A_arbace_test_junit_eval197000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000064", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000064_A"})

func init() { i := A_arbace_test_junit_eval197000064_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000064_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000064_A_members }

var A_arbace_test_junit_eval197000064_fn__197000065_A_class *jrt.Class

func A_arbace_test_junit_eval197000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000068_A_New()}; return nil }

var A_arbace_test_junit_eval197000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000068_A_new}

var A_arbace_test_junit_eval197000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000068", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000068_A"})

func init() { i := A_arbace_test_junit_eval197000068_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000068_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000068_A_members }

var A_arbace_test_junit_eval197000068_fn__197000069_A_class *jrt.Class

func A_arbace_test_junit_eval197000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000072_A_New()}; return nil }

var A_arbace_test_junit_eval197000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000072_A_new}

var A_arbace_test_junit_eval197000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000072", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000072_A"})

func init() { i := A_arbace_test_junit_eval197000072_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000072_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000072_A_members }

var A_arbace_test_junit_eval197000072_fn__197000073_A_class *jrt.Class

func A_arbace_test_junit_eval197000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000076_A_New()}; return nil }

var A_arbace_test_junit_eval197000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000076_A_new}

var A_arbace_test_junit_eval197000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000076", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000076_A"})

func init() { i := A_arbace_test_junit_eval197000076_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000076_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000076_A_members }

var A_arbace_test_junit_eval197000076_fn__197000077_A_class *jrt.Class

func A_arbace_test_junit_eval197000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000080_A_New()}; return nil }

var A_arbace_test_junit_eval197000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000080_A_new}

var A_arbace_test_junit_eval197000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000080", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000080_A"})

func init() { i := A_arbace_test_junit_eval197000080_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000080_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000080_A_members }

var A_arbace_test_junit_eval197000080_fn__197000081_A_class *jrt.Class

func A_arbace_test_junit_eval197000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000084_A_New()}; return nil }

var A_arbace_test_junit_eval197000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000084_A_new}

var A_arbace_test_junit_eval197000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000084", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000084_A"})

func init() { i := A_arbace_test_junit_eval197000084_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000084_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000084_A_members }

var A_arbace_test_junit_eval197000084_fn__197000085_A_class *jrt.Class

func A_arbace_test_junit_eval197000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit_eval197000088_A_New()}; return nil }

var A_arbace_test_junit_eval197000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_test_junit_eval197000088_A_new}

var A_arbace_test_junit_eval197000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit$eval197000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_test_junit_A_class, Simple: "eval197000088", Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit_eval197000088_A"})

func init() { i := A_arbace_test_junit_eval197000088_A_class.Info(); i.IsInstance = A_arbace_test_junit_eval197000088_A_InstanceOf; i.Table = A_arbace_test_junit_eval197000088_A_members }

var A_arbace_test_junit_eval197000088_fn__197000089_A_class *jrt.Class

var A_arbace_test_junit_failure_el_A_class *jrt.Class

var A_arbace_test_junit_finish_case_A_class *jrt.Class

var A_arbace_test_junit_finish_element_A_class *jrt.Class

var A_arbace_test_junit_finish_suite_A_class *jrt.Class

var A_arbace_test_junit_fn__197000013_A_class *jrt.Class

var A_arbace_test_junit_indent_A_class *jrt.Class

var A_arbace_test_junit_message_el_A_class *jrt.Class

var A_arbace_test_junit_package_class_A_class *jrt.Class

var A_arbace_test_junit_start_case_A_class *jrt.Class

var A_arbace_test_junit_start_element_A_class *jrt.Class

var A_arbace_test_junit_start_suite_A_class *jrt.Class

var A_arbace_test_junit_suite_attrs_A_class *jrt.Class

var A_arbace_test_junit_test_name_A_class *jrt.Class

var A_arbace_test_junit_test_name_fn__197000038_A_class *jrt.Class

var A_arbace_test_junit_with_junit_output_A_class *jrt.Class

func A_arbace_test_junit__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_test_junit__init_A_Load__O()}; return nil }

func A_arbace_test_junit__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_test_junit__init_A_New()}; return nil }

var A_arbace_test_junit__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_test_junit__init_A_invoke, New: A_arbace_test_junit__init_A_new}

var A_arbace_test_junit__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.test.junit__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_test_junit.A_arbace_test_junit__init_A", Source: "junit.ae"})

func init() { i := A_arbace_test_junit__init_A_class.Info(); i.IsInstance = A_arbace_test_junit__init_A_InstanceOf; i.Init = A_arbace_test_junit__init_A_Init; i.Table = A_arbace_test_junit__init_A_members }
