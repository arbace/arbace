//line a2g_strings.ae:1
package aot_arbace_test_junit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.stacktrace")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("stack")

var Lit_6 *jrt.String = jrt.Intern("arbace.test")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.test.junit")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("arbace.test extension for JUnit-compatible XML output.\n\n  JUnit (http://junit.org/) is the most popular unit-testing library\n  for Java.  As such, tool support for JUnit output formats is\n  common.  By producing compatible output from tests, this tool\n  support can be exploited.\n\n  To use, wrap any calls to arbace.test/run-tests in the\n  with-junit-output macro, like this:\n\n    (use 'arbace.test)\n    (use 'arbace.test.junit)\n\n    (with-junit-output\n      (run-tests 'my.cool.library))\n\n  To write the output to a file, rebind arbace.test/*test-out* to\n  your own PrintWriter (perhaps opened using\n  arbace.java.io/writer).")

var Lit_14 *jrt.String = jrt.Intern("author")

var Lit_15 *jrt.String = jrt.Intern("Jason Sankey")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("apply")

var Lit_18 *jrt.String = jrt.Intern("str")

var Lit_19 *jrt.String = jrt.Intern("map")

var Lit_20 *jrt.String = jrt.Intern("escape-xml-map")

var Lit_21 *jrt.String = jrt.Intern("*depth*")

var Lit_22 *jrt.String = jrt.Intern("print")

var Lit_23 *jrt.String = jrt.Intern("indent")

var Lit_24 *jrt.String = jrt.Intern("seq")

var Lit_25 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_26 *jrt.String = jrt.Intern("chunk-first")

var Lit_27 *jrt.String = jrt.Intern("first")

var Lit_28 *jrt.String = jrt.Intern("println")

var Lit_29 *jrt.String = jrt.Intern("name")

var Lit_30 *jrt.String = jrt.Intern("escape-xml")

var Lit_31 *jrt.String = jrt.Intern("chunk-rest")

var Lit_32 *jrt.String = jrt.Intern("next")

var Lit_33 *jrt.String = jrt.Intern("interpose")

var Lit_34 *jrt.String = jrt.Intern("reverse")

var Lit_35 *jrt.String = jrt.Intern("start-element")

var Lit_36 *jrt.String = jrt.Intern("testcase")

var Lit_37 *jrt.String = jrt.Intern("classname")

var Lit_38 *jrt.String = jrt.Intern("finish-element")

var Lit_39 *jrt.String = jrt.Intern("assoc")

var Lit_40 *jrt.String = jrt.Intern("package")

var Lit_41 *jrt.String = jrt.Intern("package-class")

var Lit_42 *jrt.String = jrt.Intern("testsuite")

var Lit_43 *jrt.String = jrt.Intern("suite-attrs")

var Lit_44 *jrt.String = jrt.Intern("element-content")

var Lit_45 *jrt.String = jrt.Intern("message")

var Lit_46 *jrt.String = jrt.Intern("file-position")

var Lit_47 *jrt.String = jrt.Intern("message-el")

var Lit_48 *jrt.String = jrt.Intern("failure")

var Lit_49 *jrt.String = jrt.Intern("pr-str")

var Lit_50 *jrt.String = jrt.Intern("error")

var Lit_51 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_52 *jrt.String = jrt.Intern("print-cause-trace")

var Lit_53 *jrt.String = jrt.Intern("*stack-trace-depth*")

var Lit_54 *jrt.String = jrt.Intern("prn")

var Lit_55 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_56 *jrt.String = jrt.Intern("hash-map")

var Lit_57 *jrt.String = jrt.Intern("*out*")

var Lit_58 *jrt.String = jrt.Intern("start-suite")

var Lit_59 *jrt.String = jrt.Intern("*test-out*")

var Lit_60 *jrt.String = jrt.Intern("ns-name")

var Lit_61 *jrt.String = jrt.Intern("ns")

var Lit_62 *jrt.String = jrt.Intern("finish-suite")

var Lit_63 *jrt.String = jrt.Intern("var")

var Lit_64 *jrt.String = jrt.Intern("start-case")

var Lit_65 *jrt.String = jrt.Intern("*var-context*")

var Lit_66 *jrt.String = jrt.Intern("test-name")

var Lit_67 *jrt.String = jrt.Intern("finish-case")

var Lit_68 *jrt.String = jrt.Intern("inc-report-counter")

var Lit_69 *jrt.String = jrt.Intern("pass")

var Lit_70 *jrt.String = jrt.Intern("failure-el")

var Lit_71 *jrt.String = jrt.Intern("fail")

var Lit_72 *jrt.String = jrt.Intern("expected")

var Lit_73 *jrt.String = jrt.Intern("actual")

var Lit_74 *jrt.String = jrt.Intern("error-el")

var Lit_75 *jrt.String = jrt.Intern("concat")

var Lit_76 *jrt.String = jrt.Intern("list")

var Lit_77 *jrt.String = jrt.Intern("binding")

var Lit_78 *jrt.String = jrt.Intern("vector")

var Lit_79 *jrt.String = jrt.Intern("report")

var Lit_80 *jrt.String = jrt.Intern("junit-report")

var Lit_81 *jrt.String = jrt.Intern("with-test-out")

var Lit_82 *jrt.String = jrt.Intern("let")

var Lit_83 *jrt.String = jrt.Intern("result__197000092__auto__")

var Lit_84 *jrt.String = jrt.Intern("do")

var Lit_85 *jrt.String = jrt.Intern("arbace.test.junit$element_content")

var Lit_86 *jrt.String = jrt.Intern("arbace.test.junit$error_el")

var Lit_87 *jrt.String = jrt.Intern("arbace.test.junit$error_el$fn__197000055")

var Lit_88 *jrt.String = jrt.Intern("arbace.test.junit$escape_xml")

var Lit_89 *jrt.String = jrt.Intern("arbace.test.junit$escape_xml$fn__197000016")

var Lit_90 *jrt.String = jrt.Intern("arbace.test.junit$eval197000004$loading__1927001464__auto____197000005")

var Lit_91 *jrt.String = jrt.Intern("arbace.test.junit$eval197000008$fn__197000009")

var Lit_92 *jrt.String = jrt.Intern("arbace.test.junit$eval197000060$fn__197000061")

var Lit_93 *jrt.String = jrt.Intern("arbace.test.junit$eval197000064$fn__197000065")

var Lit_94 *jrt.String = jrt.Intern("arbace.test.junit$eval197000068$fn__197000069")

var Lit_95 *jrt.String = jrt.Intern("arbace.test.junit$eval197000072$fn__197000073")

var Lit_96 *jrt.String = jrt.Intern("arbace.test.junit$eval197000076$fn__197000077")

var Lit_97 *jrt.String = jrt.Intern("arbace.test.junit$eval197000080$fn__197000081")

var Lit_98 *jrt.String = jrt.Intern("arbace.test.junit$eval197000084$fn__197000085")

var Lit_99 *jrt.String = jrt.Intern("arbace.test.junit$eval197000088$fn__197000089")

var Lit_100 *jrt.String = jrt.Intern("arbace.test.junit$failure_el")

var Lit_101 *jrt.String = jrt.Intern("arbace.test.junit$finish_case")

var Lit_102 *jrt.String = jrt.Intern("arbace.test.junit$finish_element")

var Lit_103 *jrt.String = jrt.Intern("</")

var Lit_104 *jrt.String = jrt.Intern(">")

var Lit_105 *jrt.String = jrt.Intern("arbace.test.junit$finish_suite")

var Lit_106 *jrt.String = jrt.Intern("arbace.test.junit$fn__197000013")

var Lit_107 *jrt.String = jrt.Intern("&")

var Lit_108 *jrt.String = jrt.Intern(";")

var Lit_109 *jrt.String = jrt.Intern("arbace.test.junit$indent")

var Lit_110 *jrt.String = jrt.Intern(" ")

var Lit_111 *jrt.String = jrt.Intern("arbace.test.junit$message_el")

var Lit_112 *jrt.String = jrt.Intern("\n")

var Lit_113 *jrt.String = jrt.Intern("expected: ")

var Lit_114 *jrt.String = jrt.Intern("  actual: ")

var Lit_115 *jrt.String = jrt.Intern("      at: ")

var Lit_116 *jrt.String = jrt.Intern(":")

var Lit_117 *jrt.String = jrt.Intern("arbace.test.junit$package_class")

var Lit_118 *jrt.String = jrt.Intern("lastIndexOf")

var Lit_119 *jrt.String = jrt.Intern(".")

var Lit_120 *jrt.String = jrt.Intern("substring")

var Lit_121 *jrt.String = jrt.Intern("arbace.test.junit$start_case")

var Lit_122 *jrt.String = jrt.Intern("arbace.test.junit$start_element")

var Lit_123 *jrt.String = jrt.Intern("<")

var Lit_124 *jrt.String = jrt.Intern("=\"")

var Lit_125 *jrt.String = jrt.Intern("\"")

var Lit_126 *jrt.String = jrt.Intern("arbace.test.junit$start_suite")

var Lit_127 *jrt.String = jrt.Intern("arbace.test.junit$suite_attrs")

var Lit_128 *jrt.String = jrt.Intern("arbace.test.junit$test_name")

var Lit_129 *jrt.String = jrt.Intern("arbace.test.junit$test_name$fn__197000038")

var Lit_130 *jrt.String = jrt.Intern("arbace.test.junit$with_junit_output")

var Lit_131 *jrt.String = jrt.Intern("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")

var Lit_132 *jrt.String = jrt.Intern("<testsuites>")

var Lit_133 *jrt.String = jrt.Intern("</testsuites>")

var Lit_134 *jrt.String = jrt.Intern("in-ns")

var Lit_135 *jrt.String = jrt.Intern("zipmap")

var Lit_136 *jrt.String = jrt.Intern("private")

var Lit_137 *jrt.String = jrt.Intern("line")

var Lit_138 *jrt.String = jrt.Intern("column")

var Lit_139 *jrt.String = jrt.Intern("file")

var Lit_140 *jrt.String = jrt.Intern("arbace/test/junit.ae")

var Lit_141 *jrt.String = jrt.Intern("apos")

var Lit_142 *jrt.String = jrt.Intern("lt")

var Lit_143 *jrt.String = jrt.Intern("gt")

var Lit_144 *jrt.String = jrt.Intern("quot")

var Lit_145 *jrt.String = jrt.Intern("amp")

var Lit_146 *jrt.String = jrt.Intern("arglists")

var Lit_147 *jrt.String = jrt.Intern("text")

var Lit_148 *jrt.String = jrt.Intern("dynamic")

var Lit_149 *jrt.String = jrt.Intern("tag")

var Lit_150 *jrt.String = jrt.Intern("pretty")

var Lit_151 *jrt.String = jrt.Intern("attrs")

var Lit_152 *jrt.String = jrt.Intern("content")

var Lit_153 *jrt.String = jrt.Intern("vars")

var Lit_154 *jrt.String = jrt.Intern("expected-str")

var Lit_155 *jrt.String = jrt.Intern("actual-str")

var Lit_156 *jrt.String = jrt.Intern("type")

var Lit_157 *jrt.String = jrt.Intern("default")

var Lit_158 *jrt.String = jrt.Intern("global-hierarchy")

var Lit_159 *jrt.String = jrt.Intern("begin-test-ns")

var Lit_160 *jrt.String = jrt.Intern("end-test-ns")

var Lit_161 *jrt.String = jrt.Intern("begin-test-var")

var Lit_162 *jrt.String = jrt.Intern("end-test-var")

var Lit_163 *jrt.String = jrt.Intern("with-junit-output")

var Lit_164 *jrt.String = jrt.Intern("body")

var Lit_165 *jrt.String = jrt.Intern("Execute body with modified test-is reporting functions that write\n  JUnit-compatible XML output.")

var Lit_166 *jrt.String = jrt.Intern("added")

var Lit_167 *jrt.String = jrt.Intern("1.1")

var Lit_168 *jrt.String = jrt.Intern("'<>\"&")
