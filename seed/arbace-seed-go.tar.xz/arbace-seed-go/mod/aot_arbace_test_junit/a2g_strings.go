//line a2g_strings.ae:1
package aot_arbace_test_junit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn17,arbace.stacktracekn2,asyn5,stackyn11,arbace.testyn1,tkn3,dockn6,authorkn4,nameyn8,testcasekn9,classnamekn7,packageyn9,testsuitekn7,messageyn7,failureyn5,errorkn2,nskn3,varkn4,passkn4,failkn8,expectedkn6,actualkn5,errorys11,arbace.core7,bindingys11,arbace.test6,reportys17,arbace.test.junit12,junit-reportys17,arbace.test.junit13,*var-context*ys11,arbace.core4,listys17,arbace.test.junit7,*depth*ys11,arbace.test13,with-test-outys11,arbace.core7,printlnys11,arbace.core3,letyn25,result__197000092__auto__yn2,dov11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn17,arbace.test.junitm4,R6,s626,arbace.test extension for JUnit-compatible XML output.\n\n  JUnit (http://junit.org/) is the most popular unit-testing library\n  for Java.  As such, tool support for JUnit output formats is\n  common.  By producing compatible output from tests, this tool\n  support can be exploited.\n\n  To use, wrap any calls to arbace.test/run-tests in the\n  with-junit-output macro, like this:\n\n    (use 'arbace.test)\n    (use 'arbace.test.junit)\n\n    (with-junit-output\n      (run-tests 'my.cool.library))\n\n  To write the output to a file, rebind arbace.test/*test-out* to\n  your own PrintWriter (perhaps opened using\n  arbace.java.io/writer).R7,s12,Jason Sankeyv11,arbace.core13,*loaded-libs*v11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core3,mapv17,arbace.test.junit14,escape-xml-mapv17,arbace.test.junit7,*depth*v11,arbace.core5,printv17,arbace.test.junit6,indentv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core7,printlnv11,arbace.core4,namev17,arbace.test.junit10,escape-xmlv11,arbace.core10,chunk-restv11,arbace.core4,nextv11,arbace.core9,interposev11,arbace.core7,reverseR8,l0,v17,arbace.test.junit13,start-elementR9,R10,v17,arbace.test.junit14,finish-elementR9,v11,arbace.core5,assocR11,v17,arbace.test.junit13,package-classR12,v17,arbace.test.junit11,suite-attrsR12,v17,arbace.test.junit15,element-contentR13,v11,arbace.test13,file-positionl5,v17,arbace.test.junit10,message-elR14,v11,arbace.core6,pr-strR15,v11,arbace.core19,pop-thread-bindingsv17,arbace.stacktrace17,print-cause-tracev11,arbace.test19,*stack-trace-depth*v11,arbace.core3,prnv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v17,arbace.test.junit11,start-suitev11,arbace.test10,*test-out*v11,arbace.core7,ns-nameR16,v17,arbace.test.junit12,finish-suiteR17,v17,arbace.test.junit10,start-casev17,arbace.test.junit13,*var-context*v17,arbace.test.junit9,test-namev17,arbace.test.junit11,finish-casev11,arbace.test18,inc-report-counterR18,v17,arbace.test.junit10,failure-elR19,R20,R21,v17,arbace.test.junit8,error-elR22,v11,arbace.core6,concatv11,arbace.core4,listR23,v11,arbace.core6,vectorR24,R25,R26,R27,R28,l1,R29,R30,R30,R31,R32,R33,R29,R30,")

var Lit_1 *jrt.String = jrt.Intern("arbace.test.junit$error_el$fn__197000055")

var Lit_2 *jrt.String = jrt.Intern("arbace.test.junit$escape_xml$fn__197000016")

var Lit_3 *jrt.String = jrt.Intern("</")

var Lit_4 *jrt.String = jrt.Intern(">")

var Lit_5 *jrt.String = jrt.Intern("&")

var Lit_6 *jrt.String = jrt.Intern(";")

var Lit_7 *jrt.String = jrt.Intern(" ")

var Lit_8 *jrt.String = jrt.Intern("\n")

var Lit_9 *jrt.String = jrt.Intern("expected: ")

var Lit_10 *jrt.String = jrt.Intern("  actual: ")

var Lit_11 *jrt.String = jrt.Intern("      at: ")

var Lit_12 *jrt.String = jrt.Intern(":")

var Lit_13 *jrt.String = jrt.Intern("lastIndexOf")

var Lit_14 *jrt.String = jrt.Intern(".")

var Lit_15 *jrt.String = jrt.Intern("substring")

var Lit_16 *jrt.String = jrt.Intern("<")

var Lit_17 *jrt.String = jrt.Intern("=\"")

var Lit_18 *jrt.String = jrt.Intern("\"")

var Lit_19 *jrt.String = jrt.Intern("arbace.test.junit$test_name$fn__197000038")

var Lit_20 *jrt.String = jrt.Intern("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")

var Lit_21 *jrt.String = jrt.Intern("<testsuites>")

var Lit_22 *jrt.String = jrt.Intern("</testsuites>")

var Lit_23 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn7,privatekn4,linekn6,columnkn4,fileyn4,aposyn2,ltyn2,gtyn4,quotyn3,ampkn8,arglistsyn4,textkn7,dynamicyn3,tagyn6,prettyyn1,&yn5,attrsyn7,contentyn4,varsyn4,nameyn9,classnameyn7,packageyn7,messageyn12,expected-stryn10,actual-stryn8,expectedyn6,actualkn4,typekn7,defaultkn13,begin-test-nskn11,end-test-nskn14,begin-test-varkn12,end-test-varkn4,passkn4,failkn5,erroryn4,bodykn5,addedv11,arbace.core5,in-nsMyn17,arbace.test.junitm4,R0,s626,arbace.test extension for JUnit-compatible XML output.\n\n  JUnit (http://junit.org/) is the most popular unit-testing library\n  for Java.  As such, tool support for JUnit output formats is\n  common.  By producing compatible output from tests, this tool\n  support can be exploited.\n\n  To use, wrap any calls to arbace.test/run-tests in the\n  with-junit-output macro, like this:\n\n    (use 'arbace.test)\n    (use 'arbace.test.junit)\n\n    (with-junit-output\n      (run-tests 'my.cool.library))\n\n  To write the output to a file, rebind arbace.test/*test-out* to\n  your own PrintWriter (perhaps opened using\n  arbace.java.io/writer).R1,s12,Jason Sankeym4,R0,s626,arbace.test extension for JUnit-compatible XML output.\n\n  JUnit (http://junit.org/) is the most popular unit-testing library\n  for Java.  As such, tool support for JUnit output formats is\n  common.  By producing compatible output from tests, this tool\n  support can be exploited.\n\n  To use, wrap any calls to arbace.test/run-tests in the\n  with-junit-output macro, like this:\n\n    (use 'arbace.test)\n    (use 'arbace.test.junit)\n\n    (with-junit-output\n      (run-tests 'my.cool.library))\n\n  To write the output to a file, rebind arbace.test/*test-out* to\n  your own PrintWriter (perhaps opened using\n  arbace.java.io/writer).R1,s12,Jason SankeyR2,v17,arbace.test.junit14,escape-xml-mapv11,arbace.core6,zipmapm8,R3,TR4,i42,R5,i1,R6,s20,arbace/test/junit.aev11,arbace.core3,mapV5,R7,R8,R9,R10,R11,v17,arbace.test.junit10,escape-xmlm10,R3,TR12,L1,V1,R13,R4,i45,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit13,*var-context*m8,R14,TR4,i48,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit7,*depth*m8,R14,TR4,i49,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit6,indentm8,R12,L1,V0,R4,i51,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit13,start-elementm8,R12,L1,V4,R15,R16,R17,V1,R18,R4,i55,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit15,element-contentm8,R12,L1,V1,R19,R4,i66,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit14,finish-elementm8,R12,L1,V2,R15,R16,R4,i70,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit9,test-namem8,R12,L1,V1,R20,R4,i77,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit13,package-classm8,R12,L1,V1,R21,R4,i82,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit10,start-casem8,R12,L1,V2,R21,R22,R4,i89,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit11,finish-casem8,R12,L1,V0,R4,i93,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit11,suite-attrsm8,R12,L1,V2,R23,R22,R4,i97,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit11,start-suitem8,R12,L1,V1,R21,R4,i104,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit12,finish-suitem8,R12,L1,V0,R4,i109,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit10,message-elm8,R12,L1,V4,R15,R24,R25,R26,R4,i113,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit10,failure-elm8,R12,L1,V3,R24,R27,R28,R4,i128,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit8,error-elm8,R12,L1,V3,R24,R27,R28,R4,i132,R5,i1,R6,s20,arbace/test/junit.aev17,arbace.test.junit12,junit-reportm8,R14,TR4,i142,R5,i1,R6,s20,arbace/test/junit.aev11,arbace.core5,derefR29,R30,v11,arbace.core16,global-hierarchym8,R14,TR4,i142,R5,i1,R6,s20,arbace/test/junit.aeR31,R32,R33,R34,R35,R36,R37,v17,arbace.test.junit17,with-junit-outputm12,R12,L1,V2,R17,R38,R0,s96,Execute body with modified test-is reporting functions that write\n  JUnit-compatible XML output.R39,s3,1.1R4,i182,R5,i1,R6,s20,arbace/test/junit.ae")

var Lit_24 *jrt.String = jrt.Intern("arbace.test.junit$eval197000004$loading__1927001464__auto____197000005")

var Lit_25 *jrt.String = jrt.Intern("arbace.test.junit$eval197000008$fn__197000009")

var Lit_26 *jrt.String = jrt.Intern("'<>\"&")

var Lit_27 *jrt.String = jrt.Intern("arbace.test.junit$fn__197000013")

var Lit_28 *jrt.String = jrt.Intern("arbace.test.junit$escape_xml")

var Lit_29 *jrt.String = jrt.Intern("arbace.test.junit$indent")

var Lit_30 *jrt.String = jrt.Intern("arbace.test.junit$start_element")

var Lit_31 *jrt.String = jrt.Intern("arbace.test.junit$element_content")

var Lit_32 *jrt.String = jrt.Intern("arbace.test.junit$finish_element")

var Lit_33 *jrt.String = jrt.Intern("arbace.test.junit$test_name")

var Lit_34 *jrt.String = jrt.Intern("arbace.test.junit$package_class")

var Lit_35 *jrt.String = jrt.Intern("arbace.test.junit$start_case")

var Lit_36 *jrt.String = jrt.Intern("arbace.test.junit$finish_case")

var Lit_37 *jrt.String = jrt.Intern("arbace.test.junit$suite_attrs")

var Lit_38 *jrt.String = jrt.Intern("arbace.test.junit$start_suite")

var Lit_39 *jrt.String = jrt.Intern("arbace.test.junit$finish_suite")

var Lit_40 *jrt.String = jrt.Intern("arbace.test.junit$message_el")

var Lit_41 *jrt.String = jrt.Intern("arbace.test.junit$failure_el")

var Lit_42 *jrt.String = jrt.Intern("arbace.test.junit$error_el")

var Lit_43 *jrt.String = jrt.Intern("junit-report")

var Lit_44 *jrt.String = jrt.Intern("arbace.test.junit$eval197000060$fn__197000061")

var Lit_45 *jrt.String = jrt.Intern("arbace.test.junit$eval197000064$fn__197000065")

var Lit_46 *jrt.String = jrt.Intern("arbace.test.junit$eval197000068$fn__197000069")

var Lit_47 *jrt.String = jrt.Intern("arbace.test.junit$eval197000072$fn__197000073")

var Lit_48 *jrt.String = jrt.Intern("arbace.test.junit$eval197000076$fn__197000077")

var Lit_49 *jrt.String = jrt.Intern("arbace.test.junit$eval197000080$fn__197000081")

var Lit_50 *jrt.String = jrt.Intern("arbace.test.junit$eval197000084$fn__197000085")

var Lit_51 *jrt.String = jrt.Intern("arbace.test.junit$eval197000088$fn__197000089")

var Lit_52 *jrt.String = jrt.Intern("arbace.test.junit$with_junit_output")
