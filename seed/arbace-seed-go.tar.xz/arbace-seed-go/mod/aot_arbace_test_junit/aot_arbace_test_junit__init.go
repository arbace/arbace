//line aot_arbace_test_junit__init.ae:1
package aot_arbace_test_junit

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_test_junit__init_A_Load__O() any { A_arbace_test_junit__init_A_Init(); jrt.StartCheck(); A_arbace_test_junit__init_A_Unit0__O(); A_arbace_test_junit__init_A_Unit1__O(); A_arbace_test_junit__init_A_Unit2__O(); A_arbace_test_junit__init_A_Unit3__O(); A_arbace_test_junit__init_A_Unit4__O(); A_arbace_test_junit__init_A_Unit5__O(); A_arbace_test_junit__init_A_Unit6__O(); A_arbace_test_junit__init_A_Unit7__O(); A_arbace_test_junit__init_A_Unit8__O(); A_arbace_test_junit__init_A_Unit9__O(); A_arbace_test_junit__init_A_Unit10__O(); A_arbace_test_junit__init_A_Unit11__O(); A_arbace_test_junit__init_A_Unit12__O(); A_arbace_test_junit__init_A_Unit13__O(); A_arbace_test_junit__init_A_Unit14__O(); A_arbace_test_junit__init_A_Unit15__O(); A_arbace_test_junit__init_A_Unit16__O(); A_arbace_test_junit__init_A_Unit17__O(); A_arbace_test_junit__init_A_Unit18__O(); A_arbace_test_junit__init_A_Unit19__O(); A_arbace_test_junit__init_A_Unit20__O(); A_arbace_test_junit__init_A_Unit21__O(); A_arbace_test_junit__init_A_Unit22__O(); A_arbace_test_junit__init_A_Unit23__O(); A_arbace_test_junit__init_A_Unit24__O(); A_arbace_test_junit__init_A_Unit25__O(); A_arbace_test_junit__init_A_Unit26__O(); A_arbace_test_junit__init_A_Unit27__O(); A_arbace_test_junit__init_A_Unit28__O(); A_arbace_test_junit__init_A_Unit29__O(); A_arbace_test_junit__init_A_Unit30__O(); A_arbace_test_junit__init_A_Unit31__O(); A_arbace_test_junit__init_A_Unit32__O(); A_arbace_test_junit__init_A_Unit33__O(); return nil }











func A_arbace_test_junit__init_A_Unit0__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); return lang.IFn_Cast(A_arbace_test_junit__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit__init_A_const_1) }
//line :17:1
func A_arbace_test_junit__init_A_Unit1__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_test_junit__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_2)) }
//line :17:1
func A_arbace_test_junit__init_A_Unit2__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); var tmp1 any = A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :17:1
func A_arbace_test_junit__init_A_Unit3__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_test_junit__init_A_const_1)).Equals_O__Z(A_arbace_test_junit__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_test_junit_eval197000008_fn__197000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_test_junit_eval197000008_fn__197000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_test_junit_eval197000008_fn__197000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
























func A_arbace_test_junit__init_A_Unit4__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_4; var tmp2 any; var root_9 any = A_arbace_test_junit__init_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_11 lang.IFn; if

	linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = Lit_26; var arg_13 any; var root_4 any = A_arbace_test_junit__init_A_const_6.GetRawRoot__O(); var linked_5 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_6 lang.IFn; if linked_5 == nil { ifn_6 = lang.IFn_Cast(root_4) } else { ifn_6 = nil }; var arg_7 any; var tmp3 any = A_arbace_test_junit_fn__197000013_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_test_junit_fn__197000013_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_test_junit_fn__197000013_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; arg_7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_8 any = A_arbace_test_junit__init_A_const_7; if linked_5 == nil { arg_13 = ifn_6.Invoke_O_O__O(arg_7, arg_8) } else { arg_13 = linked_5.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4, arg_7, arg_8) }; if linked_10 == nil { tmp2 = ifn_11.Invoke_O_O__O(arg_12, arg_13) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_9, arg_12, arg_13) }; /*line :42:1*/tmp1.BindRoot_O__V(tmp2); var tmp5 *lang.Var = A_arbace_test_junit__init_A_const_4; tmp5.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_8)); return A_arbace_test_junit__init_A_const_4 }


func A_arbace_test_junit__init_A_Unit5__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_9; var tmp2 any = A_arbace_test_junit_escape_xml_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_test_junit_escape_xml_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_test_junit_escape_xml_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_10)); return A_arbace_test_junit__init_A_const_9 }


func A_arbace_test_junit__init_A_Unit6__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_12)); return A_arbace_test_junit__init_A_const_11.SetDynamic_Z__Var(true).Ref() }
func A_arbace_test_junit__init_A_Unit7__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_13; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_14)); return A_arbace_test_junit__init_A_const_13.SetDynamic_Z__Var(true).Ref() }

func A_arbace_test_junit__init_A_Unit8__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_15; var tmp2 any = A_arbace_test_junit_indent_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_test_junit_indent_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_test_junit_indent_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_16)); return A_arbace_test_junit__init_A_const_15 }



func A_arbace_test_junit__init_A_Unit9__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_17; var tmp2 any = A_arbace_test_junit_start_element_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_test_junit_start_element_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, true); A_arbace_test_junit_start_element_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_18)); return A_arbace_test_junit__init_A_const_17 }










func A_arbace_test_junit__init_A_Unit10__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_19; var tmp2 any = A_arbace_test_junit_element_content_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_test_junit_element_content_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_test_junit_element_content_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_20)); return A_arbace_test_junit__init_A_const_19 }



func A_arbace_test_junit__init_A_Unit11__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_21; var tmp2 any = A_arbace_test_junit_finish_element_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_test_junit_finish_element_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_test_junit_finish_element_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_22)); return A_arbace_test_junit__init_A_const_21 }






func A_arbace_test_junit__init_A_Unit12__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_23; var tmp2 any = A_arbace_test_junit_test_name_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_test_junit_test_name_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_test_junit_test_name_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_24)); return A_arbace_test_junit__init_A_const_23 }




func A_arbace_test_junit__init_A_Unit13__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_25; var tmp2 any = A_arbace_test_junit_package_class_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_test_junit_package_class_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_test_junit_package_class_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_26)); return A_arbace_test_junit__init_A_const_25 }






func A_arbace_test_junit__init_A_Unit14__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_27; var tmp2 any = A_arbace_test_junit_start_case_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_test_junit_start_case_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_test_junit_start_case_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_28)); return A_arbace_test_junit__init_A_const_27 }



func A_arbace_test_junit__init_A_Unit15__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(93, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_29; var tmp2 any = A_arbace_test_junit_finish_case_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_test_junit_finish_case_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_test_junit_finish_case_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_30)); return A_arbace_test_junit__init_A_const_29 }



func A_arbace_test_junit__init_A_Unit16__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_31; var tmp2 any = A_arbace_test_junit_suite_attrs_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_test_junit_suite_attrs_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_test_junit_suite_attrs_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_32)); return A_arbace_test_junit__init_A_const_31 }






func A_arbace_test_junit__init_A_Unit17__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(104, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_33; var tmp2 any = A_arbace_test_junit_start_suite_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_test_junit_start_suite_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_test_junit_start_suite_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_34)); return A_arbace_test_junit__init_A_const_33 }




func A_arbace_test_junit__init_A_Unit18__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_35; var tmp2 any = A_arbace_test_junit_finish_suite_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_test_junit_finish_suite_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_test_junit_finish_suite_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_36)); return A_arbace_test_junit__init_A_const_35 }



func A_arbace_test_junit__init_A_Unit19__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_37; var tmp2 any = A_arbace_test_junit_message_el_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_test_junit_message_el_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_test_junit_message_el_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_38)); return A_arbace_test_junit__init_A_const_37 }














func A_arbace_test_junit__init_A_Unit20__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_39; var tmp2 any = A_arbace_test_junit_failure_el_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_test_junit_failure_el_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_test_junit_failure_el_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_40)); return A_arbace_test_junit__init_A_const_39 }



func A_arbace_test_junit__init_A_Unit21__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_41; var tmp2 any = A_arbace_test_junit_error_el_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_test_junit_error_el_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_test_junit_error_el_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_42)); return A_arbace_test_junit__init_A_const_41 }









func A_arbace_test_junit__init_A_Unit22__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(142, 1); var v__1927000386__auto____1 any; A_arbace_test_junit__init_A_const_43.SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_44)); v__1927000386__auto____1 = A_arbace_test_junit__init_A_const_43; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_29 any = A_arbace_test_junit__init_A_const_45.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = v__1927000386__auto____1; if linked_30 == nil { tmp3 = ifn_31.Invoke_O__O(arg_32) } else { tmp3 = linked_30.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_29, arg_32) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { A_arbace_test_junit__init_A_const_43.SetDynamic_Z__Var(true); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_49)); var tmp5 *lang.Var = A_arbace_test_junit__init_A_const_43; var tmp6 *jrt.String = Lit_43; var tmp7 lang.IFn = A_arbace_test_junit__init_A_const_46; var tmp8 any = A_arbace_test_junit__init_A_const_47; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp7, tmp8, A_arbace_test_junit__init_A_const_48)); return A_arbace_test_junit__init_A_const_43 } }

func A_arbace_test_junit__init_A_Unit23__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_junit__init_A_const_43.Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_50; var tmp3 any = A_arbace_test_junit_eval197000060_fn__197000061_A_New(); var tmp4 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_test_junit_eval197000060_fn__197000061_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_test_junit_eval197000060_fn__197000061_A_fn_class = fncls__33d; tmp4 = fncls__33d } else { tmp4 = fncls__33 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_junit__init_A_Unit24__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(148, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_junit__init_A_const_43.Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_51; var tmp3 any = A_arbace_test_junit_eval197000064_fn__197000065_A_New(); var tmp4 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_test_junit_eval197000064_fn__197000065_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_test_junit_eval197000064_fn__197000065_A_fn_class = fncls__34d; tmp4 = fncls__34d } else { tmp4 = fncls__34 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_junit__init_A_Unit25__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(152, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_junit__init_A_const_43.Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_52; var tmp3 any = A_arbace_test_junit_eval197000068_fn__197000069_A_New(); var tmp4 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_test_junit_eval197000068_fn__197000069_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_test_junit_eval197000068_fn__197000069_A_fn_class = fncls__35d; tmp4 = fncls__35d } else { tmp4 = fncls__35 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test_junit__init_A_Unit26__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_junit__init_A_const_43.Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_53; var tmp3 any = A_arbace_test_junit_eval197000072_fn__197000073_A_New(); var tmp4 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_test_junit_eval197000072_fn__197000073_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_test_junit_eval197000072_fn__197000073_A_fn_class = fncls__36d; tmp4 = fncls__36d } else { tmp4 = fncls__36 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_junit__init_A_Unit27__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_junit__init_A_const_43.Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_54; var tmp3 any = A_arbace_test_junit_eval197000076_fn__197000077_A_New(); var tmp4 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_test_junit_eval197000076_fn__197000077_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_test_junit_eval197000076_fn__197000077_A_fn_class = fncls__37d; tmp4 = fncls__37d } else { tmp4 = fncls__37 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_junit__init_A_Unit28__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_junit__init_A_const_43.Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_55; var tmp3 any = A_arbace_test_junit_eval197000080_fn__197000081_A_New(); var tmp4 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_test_junit_eval197000080_fn__197000081_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_test_junit_eval197000080_fn__197000081_A_fn_class = fncls__38d; tmp4 = fncls__38d } else { tmp4 = fncls__38 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_test_junit__init_A_Unit29__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_junit__init_A_const_43.Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_56; var tmp3 any = A_arbace_test_junit_eval197000084_fn__197000085_A_New(); var tmp4 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_test_junit_eval197000084_fn__197000085_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_test_junit_eval197000084_fn__197000085_A_fn_class = fncls__39d; tmp4 = fncls__39d } else { tmp4 = fncls__39 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_test_junit__init_A_Unit30__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(180, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_test_junit__init_A_const_43.Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_47; var tmp3 any = A_arbace_test_junit_eval197000088_fn__197000089_A_New(); var tmp4 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_test_junit_eval197000088_fn__197000089_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_test_junit_eval197000088_fn__197000089_A_fn_class = fncls__40d; tmp4 = fncls__40d } else { tmp4 = fncls__40 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_test_junit__init_A_Unit31__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_57; var tmp2 any = A_arbace_test_junit_with_junit_output_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_test_junit_with_junit_output_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, true); A_arbace_test_junit_with_junit_output_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_58)); return A_arbace_test_junit__init_A_const_57 }
//line :182:1
func A_arbace_test_junit__init_A_Unit32__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); A_arbace_test_junit__init_A_const_57.SetMacro__V(); return nil }
//line :182:1
func A_arbace_test_junit__init_A_Unit33__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); return A_arbace_test_junit__init_A_const_57 }







type A_arbace_test_junit__init_A struct{ jrt.Object }

var A_arbace_test_junit__init_A_const_pool *jrt.RefArray

var A_arbace_test_junit__init_A_const_0 *lang.Var

var A_arbace_test_junit__init_A_const_1 any

var A_arbace_test_junit__init_A_const_2 any

var A_arbace_test_junit__init_A_const_3 any

var A_arbace_test_junit__init_A_const_4 *lang.Var

var A_arbace_test_junit__init_A_const_5 *lang.Var

var A_arbace_test_junit__init_A_const_6 *lang.Var

var A_arbace_test_junit__init_A_const_7 any

var A_arbace_test_junit__init_A_const_8 any

var A_arbace_test_junit__init_A_const_9 *lang.Var

var A_arbace_test_junit__init_A_const_10 any

var A_arbace_test_junit__init_A_const_11 *lang.Var

var A_arbace_test_junit__init_A_const_12 any

var A_arbace_test_junit__init_A_const_13 *lang.Var

var A_arbace_test_junit__init_A_const_14 any

var A_arbace_test_junit__init_A_const_15 *lang.Var

var A_arbace_test_junit__init_A_const_16 any

var A_arbace_test_junit__init_A_const_17 *lang.Var

var A_arbace_test_junit__init_A_const_18 any

var A_arbace_test_junit__init_A_const_19 *lang.Var

var A_arbace_test_junit__init_A_const_20 any

var A_arbace_test_junit__init_A_const_21 *lang.Var

var A_arbace_test_junit__init_A_const_22 any

var A_arbace_test_junit__init_A_const_23 *lang.Var

var A_arbace_test_junit__init_A_const_24 any

var A_arbace_test_junit__init_A_const_25 *lang.Var

var A_arbace_test_junit__init_A_const_26 any

var A_arbace_test_junit__init_A_const_27 *lang.Var

var A_arbace_test_junit__init_A_const_28 any

var A_arbace_test_junit__init_A_const_29 *lang.Var

var A_arbace_test_junit__init_A_const_30 any

var A_arbace_test_junit__init_A_const_31 *lang.Var

var A_arbace_test_junit__init_A_const_32 any

var A_arbace_test_junit__init_A_const_33 *lang.Var

var A_arbace_test_junit__init_A_const_34 any

var A_arbace_test_junit__init_A_const_35 *lang.Var

var A_arbace_test_junit__init_A_const_36 any

var A_arbace_test_junit__init_A_const_37 *lang.Var

var A_arbace_test_junit__init_A_const_38 any

var A_arbace_test_junit__init_A_const_39 *lang.Var

var A_arbace_test_junit__init_A_const_40 any

var A_arbace_test_junit__init_A_const_41 *lang.Var

var A_arbace_test_junit__init_A_const_42 any

var A_arbace_test_junit__init_A_const_43 *lang.Var

var A_arbace_test_junit__init_A_const_44 any

var A_arbace_test_junit__init_A_const_45 *lang.Var

var A_arbace_test_junit__init_A_const_46 *lang.Keyword

var A_arbace_test_junit__init_A_const_47 *lang.Keyword

var A_arbace_test_junit__init_A_const_48 *lang.Var

var A_arbace_test_junit__init_A_const_49 any

var A_arbace_test_junit__init_A_const_50 *lang.Keyword

var A_arbace_test_junit__init_A_const_51 *lang.Keyword

var A_arbace_test_junit__init_A_const_52 *lang.Keyword

var A_arbace_test_junit__init_A_const_53 *lang.Keyword

var A_arbace_test_junit__init_A_const_54 *lang.Keyword

var A_arbace_test_junit__init_A_const_55 *lang.Keyword

var A_arbace_test_junit__init_A_const_56 *lang.Keyword

var A_arbace_test_junit__init_A_const_57 *lang.Var

var A_arbace_test_junit__init_A_const_58 any

var A_arbace_test_junit__init_A_init jrt.ClassInit

func A_arbace_test_junit__init_A_Init() { if !A_arbace_test_junit__init_A_init.Done() { A_arbace_test_junit__init_A_init.Run(A_arbace_test_junit__init_A_clinit) } }

func A_arbace_test_junit__init_A_clinit() { A_arbace_test_junit__init_A_clinit_p0(); A_arbace_test_junit__init_A_clinit_p1(); A_arbace_test_junit__init_A_clinit_p2(); A_arbace_test_junit__init_A_clinit_p3(); A_arbace_test_junit__init_A_clinit_p4() }

func A_arbace_test_junit__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_test_junit__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_23, 99); A_arbace_test_junit__init_A_const_0 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[40]); A_arbace_test_junit__init_A_const_1 = A_arbace_test_junit__init_A_const_pool.A[41]; A_arbace_test_junit__init_A_const_2 = A_arbace_test_junit__init_A_const_pool.A[42]; A_arbace_test_junit__init_A_const_3 = A_arbace_test_junit__init_A_const_pool.A[43]; A_arbace_test_junit__init_A_const_4 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[44]); A_arbace_test_junit__init_A_const_5 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[45]); A_arbace_test_junit__init_A_const_6 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[46]); A_arbace_test_junit__init_A_const_7 = A_arbace_test_junit__init_A_const_pool.A[47]; A_arbace_test_junit__init_A_const_8 = A_arbace_test_junit__init_A_const_pool.A[48]; A_arbace_test_junit__init_A_const_9 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[49]); A_arbace_test_junit__init_A_const_10 = A_arbace_test_junit__init_A_const_pool.A[50]; A_arbace_test_junit__init_A_const_11 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[51]); A_arbace_test_junit__init_A_const_12 = A_arbace_test_junit__init_A_const_pool.A[52] }

func A_arbace_test_junit__init_A_clinit_p1() { A_arbace_test_junit__init_A_const_13 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[53]); A_arbace_test_junit__init_A_const_14 = A_arbace_test_junit__init_A_const_pool.A[54]; A_arbace_test_junit__init_A_const_15 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[55]); A_arbace_test_junit__init_A_const_16 = A_arbace_test_junit__init_A_const_pool.A[56]; A_arbace_test_junit__init_A_const_17 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[57]); A_arbace_test_junit__init_A_const_18 = A_arbace_test_junit__init_A_const_pool.A[58]; A_arbace_test_junit__init_A_const_19 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[59]); A_arbace_test_junit__init_A_const_20 = A_arbace_test_junit__init_A_const_pool.A[60]; A_arbace_test_junit__init_A_const_21 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[61]); A_arbace_test_junit__init_A_const_22 = A_arbace_test_junit__init_A_const_pool.A[62]; A_arbace_test_junit__init_A_const_23 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[63]); A_arbace_test_junit__init_A_const_24 = A_arbace_test_junit__init_A_const_pool.A[64]; A_arbace_test_junit__init_A_const_25 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[65]) }

func A_arbace_test_junit__init_A_clinit_p2() { A_arbace_test_junit__init_A_const_26 = A_arbace_test_junit__init_A_const_pool.A[66]; A_arbace_test_junit__init_A_const_27 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[67]); A_arbace_test_junit__init_A_const_28 = A_arbace_test_junit__init_A_const_pool.A[68]; A_arbace_test_junit__init_A_const_29 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[69]); A_arbace_test_junit__init_A_const_30 = A_arbace_test_junit__init_A_const_pool.A[70]; A_arbace_test_junit__init_A_const_31 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[71]); A_arbace_test_junit__init_A_const_32 = A_arbace_test_junit__init_A_const_pool.A[72]; A_arbace_test_junit__init_A_const_33 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[73]); A_arbace_test_junit__init_A_const_34 = A_arbace_test_junit__init_A_const_pool.A[74]; A_arbace_test_junit__init_A_const_35 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[75]); A_arbace_test_junit__init_A_const_36 = A_arbace_test_junit__init_A_const_pool.A[76]; A_arbace_test_junit__init_A_const_37 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[77]); A_arbace_test_junit__init_A_const_38 = A_arbace_test_junit__init_A_const_pool.A[78] }

func A_arbace_test_junit__init_A_clinit_p3() { A_arbace_test_junit__init_A_const_39 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[79]); A_arbace_test_junit__init_A_const_40 = A_arbace_test_junit__init_A_const_pool.A[80]; A_arbace_test_junit__init_A_const_41 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[81]); A_arbace_test_junit__init_A_const_42 = A_arbace_test_junit__init_A_const_pool.A[82]; A_arbace_test_junit__init_A_const_43 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[83]); A_arbace_test_junit__init_A_const_44 = A_arbace_test_junit__init_A_const_pool.A[84]; A_arbace_test_junit__init_A_const_45 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[85]); A_arbace_test_junit__init_A_const_46 = lang.Keyword_Cast(A_arbace_test_junit__init_A_const_pool.A[86]); A_arbace_test_junit__init_A_const_47 = lang.Keyword_Cast(A_arbace_test_junit__init_A_const_pool.A[87]); A_arbace_test_junit__init_A_const_48 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[88]); A_arbace_test_junit__init_A_const_49 = A_arbace_test_junit__init_A_const_pool.A[89]; A_arbace_test_junit__init_A_const_50 = lang.Keyword_Cast(A_arbace_test_junit__init_A_const_pool.A[90]); A_arbace_test_junit__init_A_const_51 = lang.Keyword_Cast(A_arbace_test_junit__init_A_const_pool.A[91]) }

func A_arbace_test_junit__init_A_clinit_p4() { A_arbace_test_junit__init_A_const_52 = lang.Keyword_Cast(A_arbace_test_junit__init_A_const_pool.A[92]); A_arbace_test_junit__init_A_const_53 = lang.Keyword_Cast(A_arbace_test_junit__init_A_const_pool.A[93]); A_arbace_test_junit__init_A_const_54 = lang.Keyword_Cast(A_arbace_test_junit__init_A_const_pool.A[94]); A_arbace_test_junit__init_A_const_55 = lang.Keyword_Cast(A_arbace_test_junit__init_A_const_pool.A[95]); A_arbace_test_junit__init_A_const_56 = lang.Keyword_Cast(A_arbace_test_junit__init_A_const_pool.A[96]); A_arbace_test_junit__init_A_const_57 = lang.Var_Cast(A_arbace_test_junit__init_A_const_pool.A[97]); A_arbace_test_junit__init_A_const_58 = A_arbace_test_junit__init_A_const_pool.A[98] }

func A_arbace_test_junit__init_A_New() *A_arbace_test_junit__init_A { A_arbace_test_junit__init_A_Init(); t := &A_arbace_test_junit__init_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit__init_A) Ctor() {}

func (t *A_arbace_test_junit__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit__init_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit__init_A_class }

func (t *A_arbace_test_junit__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit__init_A); return ok }

func A_arbace_test_junit__init_A_Cast(x any) *A_arbace_test_junit__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit__init_A_class)) }; return v }
