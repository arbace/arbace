//line aot_arbace_test_junit__init.ae:1
package aot_arbace_test_junit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_test_junit__init_A_Load__O() any { A_arbace_test_junit__init_A_Init(); A_arbace_test_junit__init_A_Unit0__O(); A_arbace_test_junit__init_A_Unit1__O(); A_arbace_test_junit__init_A_Unit2__O(); A_arbace_test_junit__init_A_Unit3__O(); A_arbace_test_junit__init_A_Unit4__O(); A_arbace_test_junit__init_A_Unit5__O(); A_arbace_test_junit__init_A_Unit6__O(); A_arbace_test_junit__init_A_Unit7__O(); A_arbace_test_junit__init_A_Unit8__O(); A_arbace_test_junit__init_A_Unit9__O(); A_arbace_test_junit__init_A_Unit10__O(); A_arbace_test_junit__init_A_Unit11__O(); A_arbace_test_junit__init_A_Unit12__O(); A_arbace_test_junit__init_A_Unit13__O(); A_arbace_test_junit__init_A_Unit14__O(); A_arbace_test_junit__init_A_Unit15__O(); A_arbace_test_junit__init_A_Unit16__O(); A_arbace_test_junit__init_A_Unit17__O(); A_arbace_test_junit__init_A_Unit18__O(); A_arbace_test_junit__init_A_Unit19__O(); A_arbace_test_junit__init_A_Unit20__O(); A_arbace_test_junit__init_A_Unit21__O(); A_arbace_test_junit__init_A_Unit22__O(); A_arbace_test_junit__init_A_Unit23__O(); A_arbace_test_junit__init_A_Unit24__O(); A_arbace_test_junit__init_A_Unit25__O(); A_arbace_test_junit__init_A_Unit26__O(); A_arbace_test_junit__init_A_Unit27__O(); A_arbace_test_junit__init_A_Unit28__O(); A_arbace_test_junit__init_A_Unit29__O(); A_arbace_test_junit__init_A_Unit30__O(); A_arbace_test_junit__init_A_Unit31__O(); A_arbace_test_junit__init_A_Unit32__O(); A_arbace_test_junit__init_A_Unit33__O(); return nil }











func A_arbace_test_junit__init_A_Unit0__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return lang.IFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit__init_A_const_1) }
//line :17:1
func A_arbace_test_junit__init_A_Unit1__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_test_junit__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_2)) }
//line :17:1
func A_arbace_test_junit__init_A_Unit2__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 any = A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_New(); var tmp2 *jrt.Class; A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_Init(); tmp2 = A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :17:1
func A_arbace_test_junit__init_A_Unit3__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_test_junit__init_A_const_1)).Equals_O__Z(A_arbace_test_junit__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_test_junit_eval197000008_fn__197000009_A_New(); var tmp2 *jrt.Class; A_arbace_test_junit_eval197000008_fn__197000009_A_Init(); tmp2 = A_arbace_test_junit_eval197000008_fn__197000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
























func A_arbace_test_junit__init_A_Unit4__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_5).GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_7).GetRawRoot__O()); var tmp4 any = A_arbace_test_junit_fn__197000013_A_New(); var tmp5 *jrt.Class; A_arbace_test_junit_fn__197000013_A_Init(); tmp5 = A_arbace_test_junit_fn__197000013_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(tmp2.Invoke_O_O__O(Lit_168, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), A_arbace_test_junit__init_A_const_8))); var tmp6 *lang.Var = A_arbace_test_junit__init_A_const_4; jrt.NN(tmp6).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_6)); return A_arbace_test_junit__init_A_const_4.Ref() }


func A_arbace_test_junit__init_A_Unit5__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(45, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_9; var tmp2 any = A_arbace_test_junit_escape_xml_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_escape_xml_A_Init(); tmp3 = A_arbace_test_junit_escape_xml_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_10)); return A_arbace_test_junit__init_A_const_9.Ref() }


func A_arbace_test_junit__init_A_Unit6__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_11; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_12)); return jrt.NN(A_arbace_test_junit__init_A_const_11).SetDynamic_Z__Var(true).Ref() }
func A_arbace_test_junit__init_A_Unit7__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_13; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_14)); return jrt.NN(A_arbace_test_junit__init_A_const_13).SetDynamic_Z__Var(true).Ref() }

func A_arbace_test_junit__init_A_Unit8__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_15; var tmp2 any = A_arbace_test_junit_indent_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_indent_A_Init(); tmp3 = A_arbace_test_junit_indent_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_16)); return A_arbace_test_junit__init_A_const_15.Ref() }



func A_arbace_test_junit__init_A_Unit9__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(55, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_17; var tmp2 any = A_arbace_test_junit_start_element_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_start_element_A_Init(); tmp3 = A_arbace_test_junit_start_element_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_18)); return A_arbace_test_junit__init_A_const_17.Ref() }










func A_arbace_test_junit__init_A_Unit10__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_19; var tmp2 any = A_arbace_test_junit_element_content_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_element_content_A_Init(); tmp3 = A_arbace_test_junit_element_content_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_20)); return A_arbace_test_junit__init_A_const_19.Ref() }



func A_arbace_test_junit__init_A_Unit11__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_21; var tmp2 any = A_arbace_test_junit_finish_element_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_finish_element_A_Init(); tmp3 = A_arbace_test_junit_finish_element_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_22)); return A_arbace_test_junit__init_A_const_21.Ref() }






func A_arbace_test_junit__init_A_Unit12__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_23; var tmp2 any = A_arbace_test_junit_test_name_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_test_name_A_Init(); tmp3 = A_arbace_test_junit_test_name_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_24)); return A_arbace_test_junit__init_A_const_23.Ref() }




func A_arbace_test_junit__init_A_Unit13__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_25; var tmp2 any = A_arbace_test_junit_package_class_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_package_class_A_Init(); tmp3 = A_arbace_test_junit_package_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_26)); return A_arbace_test_junit__init_A_const_25.Ref() }






func A_arbace_test_junit__init_A_Unit14__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_27; var tmp2 any = A_arbace_test_junit_start_case_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_start_case_A_Init(); tmp3 = A_arbace_test_junit_start_case_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_27; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_28)); return A_arbace_test_junit__init_A_const_27.Ref() }



func A_arbace_test_junit__init_A_Unit15__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(93, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_29; var tmp2 any = A_arbace_test_junit_finish_case_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_finish_case_A_Init(); tmp3 = A_arbace_test_junit_finish_case_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_30)); return A_arbace_test_junit__init_A_const_29.Ref() }



func A_arbace_test_junit__init_A_Unit16__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_31; var tmp2 any = A_arbace_test_junit_suite_attrs_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_suite_attrs_A_Init(); tmp3 = A_arbace_test_junit_suite_attrs_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_31; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_32)); return A_arbace_test_junit__init_A_const_31.Ref() }






func A_arbace_test_junit__init_A_Unit17__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(104, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_33; var tmp2 any = A_arbace_test_junit_start_suite_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_start_suite_A_Init(); tmp3 = A_arbace_test_junit_start_suite_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_33; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_34)); return A_arbace_test_junit__init_A_const_33.Ref() }




func A_arbace_test_junit__init_A_Unit18__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_35; var tmp2 any = A_arbace_test_junit_finish_suite_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_finish_suite_A_Init(); tmp3 = A_arbace_test_junit_finish_suite_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_36)); return A_arbace_test_junit__init_A_const_35.Ref() }



func A_arbace_test_junit__init_A_Unit19__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_37; var tmp2 any = A_arbace_test_junit_message_el_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_message_el_A_Init(); tmp3 = A_arbace_test_junit_message_el_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_38)); return A_arbace_test_junit__init_A_const_37.Ref() }














func A_arbace_test_junit__init_A_Unit20__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_39; var tmp2 any = A_arbace_test_junit_failure_el_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_failure_el_A_Init(); tmp3 = A_arbace_test_junit_failure_el_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_40)); return A_arbace_test_junit__init_A_const_39.Ref() }



func A_arbace_test_junit__init_A_Unit21__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_41; var tmp2 any = A_arbace_test_junit_error_el_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_error_el_A_Init(); tmp3 = A_arbace_test_junit_error_el_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_41; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_42)); return A_arbace_test_junit__init_A_const_41.Ref() }









func A_arbace_test_junit__init_A_Unit22__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(142, 1); var v__1927000386__auto____1 any; jrt.NN(A_arbace_test_junit__init_A_const_43).SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_43; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_44)); v__1927000386__auto____1 = A_arbace_test_junit__init_A_const_43.Ref(); var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_45).GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { jrt.NN(A_arbace_test_junit__init_A_const_43).SetDynamic_Z__Var(true); var tmp3 *lang.Var = A_arbace_test_junit__init_A_const_43; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_49)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_43; var tmp5 *jrt.String = Lit_80; var tmp6 lang.IFn = Up_Keyword_IFn(A_arbace_test_junit__init_A_const_46); var tmp7 any = A_arbace_test_junit__init_A_const_47.Ref(); jrt.NN(tmp4).BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp6, tmp7, Up_Var_IRef(A_arbace_test_junit__init_A_const_48))); return A_arbace_test_junit__init_A_const_43.Ref() } }

func A_arbace_test_junit__init_A_Unit23__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(144, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_43).Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_50.Ref(); var tmp3 any = A_arbace_test_junit_eval197000060_fn__197000061_A_New(); var tmp4 *jrt.Class; A_arbace_test_junit_eval197000060_fn__197000061_A_Init(); tmp4 = A_arbace_test_junit_eval197000060_fn__197000061_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_junit__init_A_Unit24__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(148, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_43).Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_51.Ref(); var tmp3 any = A_arbace_test_junit_eval197000064_fn__197000065_A_New(); var tmp4 *jrt.Class; A_arbace_test_junit_eval197000064_fn__197000065_A_Init(); tmp4 = A_arbace_test_junit_eval197000064_fn__197000065_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_junit__init_A_Unit25__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(152, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_43).Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_52.Ref(); var tmp3 any = A_arbace_test_junit_eval197000068_fn__197000069_A_New(); var tmp4 *jrt.Class; A_arbace_test_junit_eval197000068_fn__197000069_A_Init(); tmp4 = A_arbace_test_junit_eval197000068_fn__197000069_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_test_junit__init_A_Unit26__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_43).Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_53.Ref(); var tmp3 any = A_arbace_test_junit_eval197000072_fn__197000073_A_New(); var tmp4 *jrt.Class; A_arbace_test_junit_eval197000072_fn__197000073_A_Init(); tmp4 = A_arbace_test_junit_eval197000072_fn__197000073_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_junit__init_A_Unit27__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_43).Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_54.Ref(); var tmp3 any = A_arbace_test_junit_eval197000076_fn__197000077_A_New(); var tmp4 *jrt.Class; A_arbace_test_junit_eval197000076_fn__197000077_A_Init(); tmp4 = A_arbace_test_junit_eval197000076_fn__197000077_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_test_junit__init_A_Unit28__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(166, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_43).Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_55.Ref(); var tmp3 any = A_arbace_test_junit_eval197000080_fn__197000081_A_New(); var tmp4 *jrt.Class; A_arbace_test_junit_eval197000080_fn__197000081_A_Init(); tmp4 = A_arbace_test_junit_eval197000080_fn__197000081_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_test_junit__init_A_Unit29__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_43).Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_56.Ref(); var tmp3 any = A_arbace_test_junit_eval197000084_fn__197000085_A_New(); var tmp4 *jrt.Class; A_arbace_test_junit_eval197000084_fn__197000085_A_Init(); tmp4 = A_arbace_test_junit_eval197000084_fn__197000085_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_test_junit__init_A_Unit30__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(180, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(jrt.NN(A_arbace_test_junit__init_A_const_43).Get__O()); var tmp2 any = A_arbace_test_junit__init_A_const_47.Ref(); var tmp3 any = A_arbace_test_junit_eval197000088_fn__197000089_A_New(); var tmp4 *jrt.Class; A_arbace_test_junit_eval197000088_fn__197000089_A_Init(); tmp4 = A_arbace_test_junit_eval197000088_fn__197000089_A_fn_class; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_test_junit__init_A_Unit31__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(182, 1); var tmp1 *lang.Var = A_arbace_test_junit__init_A_const_57; var tmp2 any = A_arbace_test_junit_with_junit_output_A_New(); var tmp3 *jrt.Class; A_arbace_test_junit_with_junit_output_A_Init(); tmp3 = A_arbace_test_junit_with_junit_output_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_test_junit__init_A_const_57; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_test_junit__init_A_const_58)); return A_arbace_test_junit__init_A_const_57.Ref() }
//line :182:1
func A_arbace_test_junit__init_A_Unit32__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(182, 1); jrt.NN(A_arbace_test_junit__init_A_const_57).SetMacro__V(); return nil }
//line :182:1
func A_arbace_test_junit__init_A_Unit33__O() any { A_arbace_test_junit__init_A_Init(); lang.Compiler_AOT_At_I_I__V(182, 1); return A_arbace_test_junit__init_A_const_57.Ref() }







type A_arbace_test_junit__init_A struct{ jrt.Object }

var A_arbace_test_junit__init_A_const_0 *lang.Var

var A_arbace_test_junit__init_A_const_1 any

var A_arbace_test_junit__init_A_const_2 any

var A_arbace_test_junit__init_A_const_3 any

var A_arbace_test_junit__init_A_const_4 *lang.Var

var A_arbace_test_junit__init_A_const_5 *lang.Var

var A_arbace_test_junit__init_A_const_6 any

var A_arbace_test_junit__init_A_const_7 *lang.Var

var A_arbace_test_junit__init_A_const_8 any

var A_arbace_test_junit__init_A_const_9 *lang.Var

var A_arbace_test_junit__init_A_const_10 any

var A_arbace_test_junit__init_A_const_11 *lang.Var

var A_arbace_test_junit__init_A_const_12 any

var A_arbace_test_junit__init_A_const_13 *lang.Var

var A_arbace_test_junit__init_A_const_14 any

var A_arbace_test_junit__init_A_const_15 *lang.Var

var A_arbace_test_junit__init_A_const_16 any

var A_arbace_test_junit__init_A_const_17 *lang.Var

var A_arbace_test_junit__init_A_const_18 any

var A_arbace_test_junit__init_A_const_19 *lang.Var

var A_arbace_test_junit__init_A_const_20 any

var A_arbace_test_junit__init_A_const_21 *lang.Var

var A_arbace_test_junit__init_A_const_22 any

var A_arbace_test_junit__init_A_const_23 *lang.Var

var A_arbace_test_junit__init_A_const_24 any

var A_arbace_test_junit__init_A_const_25 *lang.Var

var A_arbace_test_junit__init_A_const_26 any

var A_arbace_test_junit__init_A_const_27 *lang.Var

var A_arbace_test_junit__init_A_const_28 any

var A_arbace_test_junit__init_A_const_29 *lang.Var

var A_arbace_test_junit__init_A_const_30 any

var A_arbace_test_junit__init_A_const_31 *lang.Var

var A_arbace_test_junit__init_A_const_32 any

var A_arbace_test_junit__init_A_const_33 *lang.Var

var A_arbace_test_junit__init_A_const_34 any

var A_arbace_test_junit__init_A_const_35 *lang.Var

var A_arbace_test_junit__init_A_const_36 any

var A_arbace_test_junit__init_A_const_37 *lang.Var

var A_arbace_test_junit__init_A_const_38 any

var A_arbace_test_junit__init_A_const_39 *lang.Var

var A_arbace_test_junit__init_A_const_40 any

var A_arbace_test_junit__init_A_const_41 *lang.Var

var A_arbace_test_junit__init_A_const_42 any

var A_arbace_test_junit__init_A_const_43 *lang.Var

var A_arbace_test_junit__init_A_const_44 any

var A_arbace_test_junit__init_A_const_45 *lang.Var

var A_arbace_test_junit__init_A_const_46 *lang.Keyword

var A_arbace_test_junit__init_A_const_47 *lang.Keyword

var A_arbace_test_junit__init_A_const_48 *lang.Var

var A_arbace_test_junit__init_A_const_49 any

var A_arbace_test_junit__init_A_const_50 *lang.Keyword

var A_arbace_test_junit__init_A_const_51 *lang.Keyword

var A_arbace_test_junit__init_A_const_52 *lang.Keyword

var A_arbace_test_junit__init_A_const_53 *lang.Keyword

var A_arbace_test_junit__init_A_const_54 *lang.Keyword

var A_arbace_test_junit__init_A_const_55 *lang.Keyword

var A_arbace_test_junit__init_A_const_56 *lang.Keyword

var A_arbace_test_junit__init_A_const_57 *lang.Var

var A_arbace_test_junit__init_A_const_58 any

var A_arbace_test_junit__init_A_init jrt.ClassInit

func A_arbace_test_junit__init_A_Init() { if !A_arbace_test_junit__init_A_init.Done() { A_arbace_test_junit__init_A_init.Run(A_arbace_test_junit__init_A_clinit) } }

func A_arbace_test_junit__init_A_clinit() { A_arbace_test_junit__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_134); A_arbace_test_junit__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_test_junit__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_test_junit__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_test_junit__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_20); A_arbace_test_junit__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_135); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_test_junit__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_test_junit__init_A_const_8 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_141).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_142).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_145).Ref()); A_arbace_test_junit__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_11, Lit_30); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_test_junit__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_147).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(45).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_11, Lit_65); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_test_junit__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_11, Lit_21); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_test_junit__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_11, Lit_23); A_arbace_test_junit__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(51).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_11, Lit_35); A_arbace_test_junit__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_149).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_150).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_151).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_11, Lit_44); A_arbace_test_junit__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_152).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_11, Lit_38); A_arbace_test_junit__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_149).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_150).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_11, Lit_66); A_arbace_test_junit__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_153).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_11, Lit_41); A_arbace_test_junit__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_11, Lit_64); A_arbace_test_junit__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(89).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_11, Lit_67); A_arbace_test_junit__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(93).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); A_arbace_test_junit__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_11, Lit_58); A_arbace_test_junit__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(104).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_11, Lit_62); A_arbace_test_junit__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_11, Lit_47); A_arbace_test_junit__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_149).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_154).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_155).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(113).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_11, Lit_70); A_arbace_test_junit__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(128).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_11, Lit_74); A_arbace_test_junit__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(132).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_11, Lit_80); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_test_junit__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(142).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_test_junit__init_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_156); A_arbace_test_junit__init_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_157); A_arbace_test_junit__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_158); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_test_junit__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(142).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)); A_arbace_test_junit__init_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_159); A_arbace_test_junit__init_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_160); A_arbace_test_junit__init_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_161); A_arbace_test_junit__init_A_const_53 = lang.RT_Keyword_String_String__Keyword(nil, Lit_162); A_arbace_test_junit__init_A_const_54 = lang.RT_Keyword_String_String__Keyword(nil, Lit_69); A_arbace_test_junit__init_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_71); A_arbace_test_junit__init_A_const_56 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_test_junit__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_11, Lit_163); A_arbace_test_junit__init_A_const_58 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_146).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_164).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_165, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), Lit_167, lang.RT_Keyword_String_String__Keyword(nil, Lit_137).Ref(), jrt.Integer_ValueOf_I__Integer(182).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_138).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_139).Ref(), Lit_140)) }

func A_arbace_test_junit__init_A_New() *A_arbace_test_junit__init_A { A_arbace_test_junit__init_A_Init(); t := &A_arbace_test_junit__init_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit__init_A) Ctor() {}

func (t *A_arbace_test_junit__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit__init_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit__init_A_class }

func (t *A_arbace_test_junit__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit__init_A); return ok }

func A_arbace_test_junit__init_A_Cast(x any) *A_arbace_test_junit__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit__init_A_class)) }; return v }
