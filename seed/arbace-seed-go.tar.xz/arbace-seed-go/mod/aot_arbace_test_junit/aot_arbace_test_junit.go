//line aot_arbace_test_junit.ae:1
package aot_arbace_test_junit

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_stacktrace"
	"arbace/aot_arbace_test"
	"arbace/jrt"
	"arbace/lang"
)







func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_New() *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_test_junit_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_test_junit_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_junit_A_const_1, A_arbace_test_junit_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :17:1
func A_arbace_test_junit_eval197000008_fn__197000009_A_New() *A_arbace_test_junit_eval197000008_fn__197000009_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000008_fn__197000009_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_5.GetRawRoot__O()); var tmp2 any; var root_10 any = A_arbace_test_junit_A_const_6.GetRawRoot__O(); var linked_11 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_10, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_12 lang.IFn; if linked_11 == nil { ifn_12 = lang.IFn_Cast(root_10) } else { ifn_12 = nil }; var arg_13 any = A_arbace_test_junit_A_const_7; if linked_11 == nil { tmp2 = ifn_12.Invoke_O__O(arg_13) } else { tmp2 = linked_11.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_10, arg_13) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_test_junit_A_const_8.GetRawRoot__O(), A_arbace_test_junit_A_const_9) }


























func A_arbace_test_junit_fn__197000013_A_New() *A_arbace_test_junit_fn__197000013_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_fn__197000013_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_test_junit_fn__197000013_A) Ctor() {}
//line :44:1
func (t *A_arbace_test_junit_fn__197000013_A) Invoke_O_O__O(self, p1__197000012_SHARP___0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, nil, p1__197000012_SHARP___0, nil)).Ref() }
func A_arbace_test_junit_escape_xml_A_New() *A_arbace_test_junit_escape_xml_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_escape_xml_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_test_junit_escape_xml_A) Ctor() {}
//line :45:1
func (t *A_arbace_test_junit_escape_xml_A) Invoke_O_O__O(self, text__0 any) any {
	var root_26 any = A_arbace_test_junit_A_const_10.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any = A_arbace_test_junit_A_const_11.GetRawRoot__O(); var arg_30 any; var root_21 any = A_arbace_test_junit_A_const_12.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any; var tmp1 any = A_arbace_test_junit_escape_xml_fn__197000016_A_New(); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; arg_24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_25 any = text__0; if linked_22 == nil { arg_30 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { arg_30 = linked_22.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; if linked_27 == nil { return ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { return linked_27.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) } }
//line :46:1
func A_arbace_test_junit_escape_xml_fn__197000016_A_New() *A_arbace_test_junit_escape_xml_fn__197000016_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_escape_xml_fn__197000016_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) Ctor() {}
//line :46:1
func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) Invoke_O_O__O(self, p1__197000015_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_test_junit_A_const_13.GetRawRoot__O()).Invoke_O_O__O(p1__197000015_SHARP___1, p1__197000015_SHARP___1) }




func A_arbace_test_junit_indent_A_New() *A_arbace_test_junit_indent_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_indent_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_test_junit_indent_A) Ctor() {}
//line :51:1
func (t *A_arbace_test_junit_indent_A) Invoke_O__O(self any) any { { var n__1927000701__auto____1 int64; var tmp1 jrt.Number_I; var na_31 any = A_arbace_test_junit_A_const_14.Get__O()
									var na_32 int64 = 4
									if jrt.Long_InstanceOf(na_31) { var n0_33 int64 = jrt.NN(jrt.Long_Cast(na_31)).LongValue__J(); var n1_34 int64 = na_32; var nr_35 int64 = n0_33 * n1_34; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = n0_33 == -9223372036854775808; if tmp5 { tmp5 = n1_34 < 0 }; tmp4 = tmp5; tmp3 = !tmp4; if tmp3 { var tmp6 bool; tmp6 = n1_34 == 0; if !tmp6 { tmp6 = nr_35/n1_34 == n0_33 }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 { tmp1 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_35)) } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_31, na_32) } } else { tmp1 = lang.Numbers_Multiply_O_J__Number_NoInit(na_31, na_32) }; n__1927000701__auto____1 = lang.RT_LongCast_O__J_NoInit(tmp1)
//line :51:1
	var n__2 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z_NoInit(n__2, n__1927000701__auto____1) { lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(Lit_7); n__2 = lang.Numbers_Unchecked_inc_J__J_NoInit(n__2); continue L1 } else { return nil } } }; /*line :51:1*/panic("j2g: unreachable") }



func A_arbace_test_junit_start_element_A_New() *A_arbace_test_junit_start_element_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_start_element_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_test_junit_start_element_A) Ctor() {}
//line :55:1
func (t *A_arbace_test_junit_start_element_A) DoInvoke_O_O_O_O__O(self, tag__0, pretty__1, p__197000020__2 any) any { var vec__197000021__4 any = p__197000020__2; var attrs__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__197000021__4, lang.RT_IntCast_J__I_NoInit(0), nil); if

	jrt.J2g_Truth(pretty__1) { var root_42 any = A_arbace_test_junit_A_const_16.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, A_arbace_test_junit_indent_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; if linked_43 == nil { ifn_44.Invoke__O() } else { linked_43.(*A_arbace_test_junit_indent_A).Invoke_O__O(root_42) } };
	lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, tag__0)).Ref()); var tmp1 any; var root_49 any =
	A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = attrs__5; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(tmp1) { var seq_197000024__6 any; var root_53 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_55 lang.IFn
		if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = attrs__5; if linked_54 == nil { seq_197000024__6 = ifn_55.Invoke_O__O(arg_56) } else { seq_197000024__6 = linked_54.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_53, arg_56) }
//line :59:1
		var chunk_197000025__7 any; var count_197000026__8 int64 = 0; var i_197000027__9 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_197000027__9, count_197000026__8) { var vec__197000028__10 any = lang.Indexed_Cast(chunk_197000025__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_197000027__9)); var key__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__197000028__10, lang.RT_IntCast_J__I_NoInit(0), nil); var value__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__197000028__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_17, nil, Lit_18); var tmp4 any; var root_80 any = A_arbace_test_junit_A_const_22.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_82 lang.IFn
				if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = key__11; if linked_81 == nil { tmp4 = ifn_82.Invoke_O__O(arg_83) } else { tmp4 = linked_81.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_80, arg_83) }; var tmp5 any = tmp4; var tmp6 any; var root_84 any = A_arbace_test_junit_A_const_23.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, A_arbace_test_junit_escape_xml_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = value__12; if linked_85 == nil { tmp6 = ifn_86.Invoke_O__O(arg_87) } else { tmp6 = linked_85.(*A_arbace_test_junit_escape_xml_A).Invoke_O_O__O(root_84, arg_87) }; tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil, tmp6, nil)).Ref())
//line :60:1
				seq_197000024__6, chunk_197000025__7, count_197000026__8, i_197000027__9 = seq_197000024__6, chunk_197000025__7, count_197000026__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_197000027__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_57 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = seq_197000024__6; if linked_58 == nil { temp__1927000414__auto____10 = ifn_59.Invoke_O__O(arg_60) } else { temp__1927000414__auto____10 = linked_58.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_57, arg_60) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_197000024__11 any = temp__1927000414__auto____10; var tmp7 any; var root_61 any = A_arbace_test_junit_A_const_18.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = seq_197000024__11; if linked_62 == nil { tmp7 = ifn_63.Invoke_O__O(arg_64) } else { tmp7 = linked_62.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_61, arg_64) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____12 any; var root_65 any = A_arbace_test_junit_A_const_19.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = seq_197000024__11; if linked_66 == nil { c__1927000678__auto____12 = ifn_67.Invoke_O__O(arg_68) } else { c__1927000678__auto____12 = linked_66.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_65, arg_68) }; var tmp8 any; var root_92 any = A_arbace_test_junit_A_const_24.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = seq_197000024__11; if linked_93 == nil { tmp8 = ifn_94.Invoke_O__O(arg_95) } else { tmp8 = linked_93.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_92, arg_95) }; seq_197000024__6, chunk_197000025__7, count_197000026__8, i_197000027__9 = tmp8, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__197000031__12 any; var root_69 any = A_arbace_test_junit_A_const_20.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = seq_197000024__11; if linked_70 == nil { vec__197000031__12 = ifn_71.Invoke_O__O(arg_72) } else { vec__197000031__12 = linked_70.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_69, arg_72) }; var key__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__197000031__12, lang.RT_IntCast_J__I_NoInit(0), nil); var value__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__197000031__12, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_17, nil, Lit_18); var tmp11 any; var root_96 any = A_arbace_test_junit_A_const_22.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_98 lang.IFn
					if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = key__13; if linked_97 == nil { tmp11 = ifn_98.Invoke_O__O(arg_99) } else { tmp11 = linked_97.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_96, arg_99) }; var tmp12 any = tmp11; var tmp13 any; var root_100 any = A_arbace_test_junit_A_const_23.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, A_arbace_test_junit_escape_xml_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = value__14; if linked_101 == nil { tmp13 = ifn_102.Invoke_O__O(arg_103) } else { tmp13 = linked_101.(*A_arbace_test_junit_escape_xml_A).Invoke_O_O__O(root_100, arg_103) }; tmp9.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp12, nil, tmp13, nil)).Ref())
//line :60:1
					var tmp14 any; var root_108 any = A_arbace_test_junit_A_const_25.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = seq_197000024__11; if linked_109 == nil { tmp14 = ifn_110.Invoke_O__O(arg_111) } else { tmp14 = linked_109.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_108, arg_111) }; seq_197000024__6, chunk_197000025__7, count_197000026__8, i_197000027__9 = tmp14, nil, 0, 0; continue L1 } } }
//line :59:1
			break L1 } };


	lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(Lit_4); if
	jrt.J2g_Truth(pretty__1) { lang.IFn_Cast(A_arbace_test_junit_A_const_21.GetRawRoot__O()).Invoke__O() }; var tmp15 /*line :55:1*/*lang.Var = A_arbace_test_junit_A_const_14; var tmp16 jrt.Number_I; var na_40 any = A_arbace_test_junit_A_const_14.Get__O(); if








	jrt.Long_InstanceOf(na_40) { var n0_41 int64 = jrt.NN(jrt.Long_Cast(na_40)).LongValue__J(); if n0_41 == 9223372036854775807 { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_40) } else { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_41 + 1)) } } else { if jrt.Double_InstanceOf(na_40) { var n0_41_2 float64 = jrt.NN(jrt.Double_Cast(na_40)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_41_2 + 1.0)) } else { tmp16 = lang.Numbers_Inc_O__Number_NoInit(na_40) } }; return /*line :55:1*/ tmp15.Set_O__O(tmp16) }










func A_arbace_test_junit_element_content_A_New() *A_arbace_test_junit_element_content_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_element_content_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_test_junit_element_content_A) Ctor() {}
//line :66:1
func (t *A_arbace_test_junit_element_content_A) Invoke_O_O__O(self, content__0 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()); var tmp2 any; var root_112 any = A_arbace_test_junit_A_const_23.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_test_junit_escape_xml_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = content__0; if linked_113 == nil { tmp2 = ifn_114.Invoke_O__O(arg_115) } else { tmp2 = linked_113.(*A_arbace_test_junit_escape_xml_A).Invoke_O_O__O(root_112, arg_115) }; return tmp1.Invoke_O__O(tmp2)
}
func A_arbace_test_junit_finish_element_A_New() *A_arbace_test_junit_finish_element_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_finish_element_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_test_junit_finish_element_A) Ctor() {}
//line :70:1
func (t *A_arbace_test_junit_finish_element_A) Invoke_O_O_O__O(self, tag__0, pretty__1 any) any { var tmp1 *lang.Var = A_arbace_test_junit_A_const_14; var tmp2 jrt.Number_I; var na_123 any = A_arbace_test_junit_A_const_14.Get__O(); if

	jrt.Long_InstanceOf(na_123) { var n0_124 int64 = jrt.NN(jrt.Long_Cast(na_123)).LongValue__J(); if n0_124 == -9223372036854775808 { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_123) } else { tmp2 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_124 - 1)) } } else { if jrt.Double_InstanceOf(na_123) { var n0_124_2 float64 = jrt.NN(jrt.Double_Cast(na_123)).DoubleValue__D(); tmp2 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_124_2 - 1.0)) } else { tmp2 = lang.Numbers_Dec_O__Number_NoInit(na_123) } }; /*line :70:1*/tmp1.Set_O__O(tmp2); if


	jrt.J2g_Truth(pretty__1) { var root_125 any = A_arbace_test_junit_A_const_16.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, A_arbace_test_junit_indent_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; if linked_126 == nil { ifn_127.Invoke__O() } else { linked_126.(*A_arbace_test_junit_indent_A).Invoke_O__O(root_125) } };
	lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, tag__0, nil)).Ref()); if
	jrt.J2g_Truth(pretty__1) { return lang.IFn_Cast(A_arbace_test_junit_A_const_21.GetRawRoot__O()).Invoke__O() } else { return nil } }

func A_arbace_test_junit_test_name_A_New() *A_arbace_test_junit_test_name_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_test_name_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_test_junit_test_name_A) Ctor() {}
//line :77:1
func (t *A_arbace_test_junit_test_name_A) Invoke_O_O__O(self, vars__0 any) any {

	var root_147 any = A_arbace_test_junit_A_const_10.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = A_arbace_test_junit_A_const_11.GetRawRoot__O(); var arg_151 any; var root_142 any = A_arbace_test_junit_A_const_26.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = Lit_14; var arg_146 any; var root_138 any = A_arbace_test_junit_A_const_27.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_reverse_A_fn_class); var ifn_140 lang.IFn
	if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any; var root_133 any = A_arbace_test_junit_A_const_12.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var tmp1 any = A_arbace_test_junit_test_name_fn__197000038_A_New(); var tmp2 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_test_junit_test_name_fn__197000038_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_test_junit_test_name_fn__197000038_A_fn_class = fncls__132d; tmp2 = fncls__132d } else { tmp2 = fncls__132 }; arg_136 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_137 any = vars__0; if linked_134 == nil { arg_141 = ifn_135.Invoke_O_O__O(arg_136, arg_137) } else { arg_141 = linked_134.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_133, arg_136, arg_137) }; if linked_139 == nil { arg_146 = ifn_140.Invoke_O__O(arg_141) } else { arg_146 = linked_139.(*aot_arbace_core.A_arbace_core_reverse_A).Invoke_O_O__O(root_138, arg_141) }
//line :79:1
	if linked_143 == nil { arg_151 = ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { arg_151 = linked_143.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) }; if linked_148 == nil { return ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { return linked_148.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) } }
func A_arbace_test_junit_test_name_fn__197000038_A_New() *A_arbace_test_junit_test_name_fn__197000038_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_test_name_fn__197000038_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_test_junit_test_name_fn__197000038_A) Ctor() {}
//line :80:1
func (t *A_arbace_test_junit_test_name_fn__197000038_A) Invoke_O_O__O(self, p1__197000037_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_test_junit_A_const_28; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__197000037_SHARP___1)) }

func A_arbace_test_junit_package_class_A_New() *A_arbace_test_junit_package_class_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_package_class_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_test_junit_package_class_A) Ctor() {}
//line :82:1
func (t *A_arbace_test_junit_package_class_A) Invoke_O_O__O(self, name__0 any) any { var i__2 any = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(name__0, Lit_13, jrt.RefArrayOf(jrt.Object_class, Lit_14)); var tmp1 bool; var na_152 any = i__2; var na_153 int64 = 0; if


	jrt.Long_InstanceOf(na_152) { var n0_154 int64 = jrt.NN(jrt.Long_Cast(na_152)).LongValue__J(); var n1_155 int64 = na_153; tmp1 = n0_154 < n1_155 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_152, na_153) }; if tmp1 { return lang.Tuple_Create_O_O__IPersistentVector(nil, name__0) } else { var tmp2 any = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(name__0, Lit_15, jrt.RefArrayOf(jrt.Object_class, A_arbace_test_junit_A_const_29, i__2)); var tmp3 jrt.Number_I
		var na_157 any = i__2; var na_158 int64 = 1
		if jrt.Long_InstanceOf(na_157) { var n0_159 int64 = jrt.NN(jrt.Long_Cast(na_157)).LongValue__J(); var n1_160 int64 = na_158; var nr_161 int64 = n0_159 + n1_160; if (n0_159^nr_161)&(n1_160^nr_161) >= 0 { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_161)) } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_157, na_158) } } else { tmp3 = lang.Numbers_Add_O_J__Number_NoInit(na_157, na_158) }
//line :85:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.Reflector_InvokeInstanceMethod_O_String_O1__O(name__0, Lit_15, jrt.RefArrayOf(jrt.Object_class, tmp3))) } }



func A_arbace_test_junit_start_case_A_New() *A_arbace_test_junit_start_case_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_start_case_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_test_junit_start_case_A) Ctor() {}
//line :89:1
func (t *A_arbace_test_junit_start_case_A) Invoke_O_O_O__O(self, name__0, classname__1 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_30.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_31; var tmp3 any = jrt.Boolean_TRUE.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_junit_A_const_28, name__0, A_arbace_test_junit_A_const_32, classname__1)))
}
func A_arbace_test_junit_finish_case_A_New() *A_arbace_test_junit_finish_case_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_finish_case_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_test_junit_finish_case_A) Ctor() {}
//line :93:1
func (t *A_arbace_test_junit_finish_case_A) Invoke_O__O(self any) any {

	var root_168 any = A_arbace_test_junit_A_const_33.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_test_junit_finish_element_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = A_arbace_test_junit_A_const_34; var arg_172 any = jrt.Boolean_TRUE.Ref(); if linked_169 == nil { return ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { return linked_169.(*A_arbace_test_junit_finish_element_A).Invoke_O_O_O__O(root_168, arg_171, arg_172)
	} }
func A_arbace_test_junit_suite_attrs_A_New() *A_arbace_test_junit_suite_attrs_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_suite_attrs_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_test_junit_suite_attrs_A) Ctor() {}
//line :97:1
func (t *A_arbace_test_junit_suite_attrs_A) Invoke_O_O_O__O(self, package__0, classname__1 any) any { var attrs__3 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_junit_A_const_28, classname__1)); if


	jrt.J2g_Truth(package__0) {
		var root_173 any = A_arbace_test_junit_A_const_35.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = attrs__3; var arg_177 any = A_arbace_test_junit_A_const_36; var arg_178 any = package__0; if linked_174 == nil { return ifn_175.Invoke_O_O_O__O(arg_176, arg_177, arg_178) } else { return linked_174.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_173, arg_176, arg_177, arg_178) } } else {
//line :100:1
			return attrs__3 } }



func A_arbace_test_junit_start_suite_A_New() *A_arbace_test_junit_start_suite_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_start_suite_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_test_junit_start_suite_A) Ctor() {}
//line :104:1
func (t *A_arbace_test_junit_start_suite_A) Invoke_O_O__O(self, name__0 any) any { var vec__197000045__2 any; var root_179 any = A_arbace_test_junit_A_const_37.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_test_junit_package_class_A_fn_class); var ifn_181 lang.IFn; if

	linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = name__0; if linked_180 == nil { vec__197000045__2 = ifn_181.Invoke_O__O(arg_182) } else { vec__197000045__2 = linked_180.(*A_arbace_test_junit_package_class_A).Invoke_O_O__O(root_179, arg_182) }; var package__3 any = /*line :104:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__197000045__2, lang.RT_IntCast_J__I_NoInit(0), nil); var classname__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__197000045__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_30.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_38; var tmp3 any = jrt.Boolean_TRUE.Ref(); var tmp4 any; var root_183 any = A_arbace_test_junit_A_const_39.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, A_arbace_test_junit_suite_attrs_A_fn_class); var ifn_185 lang.IFn; if


	linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = package__3; var arg_187 any = classname__4; if linked_184 == nil { tmp4 = ifn_185.Invoke_O_O__O(arg_186, arg_187) } else { tmp4 = linked_184.(*A_arbace_test_junit_suite_attrs_A).Invoke_O_O_O__O(root_183, arg_186, arg_187) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }

func A_arbace_test_junit_finish_suite_A_New() *A_arbace_test_junit_finish_suite_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_finish_suite_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_test_junit_finish_suite_A) Ctor() {}
//line :109:1
func (t *A_arbace_test_junit_finish_suite_A) Invoke_O__O(self any) any {

	var root_194 any = A_arbace_test_junit_A_const_33.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, A_arbace_test_junit_finish_element_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = A_arbace_test_junit_A_const_40; var arg_198 any = jrt.Boolean_TRUE.Ref(); if linked_195 == nil { return ifn_196.Invoke_O_O__O(arg_197, arg_198) } else { return linked_195.(*A_arbace_test_junit_finish_element_A).Invoke_O_O_O__O(root_194, arg_197, arg_198)
	} }
func A_arbace_test_junit_message_el_A_New() *A_arbace_test_junit_message_el_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_message_el_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_test_junit_message_el_A) Ctor() {}
//line :113:1
func (t *A_arbace_test_junit_message_el_A) Invoke_O_O_O_O_O__O(self, tag__0, message__1, expected_str__2, actual_str__3 any) any {

	var root_202 any = A_arbace_test_junit_A_const_16.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, A_arbace_test_junit_indent_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; if linked_203 == nil { ifn_204.Invoke__O() } else { linked_203.(*A_arbace_test_junit_indent_A).Invoke_O__O(root_202) }
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_30.GetRawRoot__O()); var tmp2 any = jrt.Boolean_FALSE.Ref(); var tmp3 lang.IPersistentMap; if jrt.J2g_Truth(message__1) { tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_junit_A_const_41, message__1)) } else { tmp3 = Up_PersistentArrayMap_IPersistentMap(lang.PersistentArrayMap_EMPTY) }; tmp1.Invoke_O_O_O__O(tag__0, tmp2, tmp3)
	var root_225 any = A_arbace_test_junit_A_const_42.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, A_arbace_test_junit_element_content_A_fn_class); var ifn_227 lang.IFn; if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any; var vec__197000050__5 any; var root_211 any = A_arbace_test_junit_A_const_43.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_test.A_arbace_test_file_position_A_fn_class); var ifn_213 lang.IFn
	if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = A_arbace_test_junit_A_const_44; if linked_212 == nil { vec__197000050__5 = ifn_213.Invoke_O__O(arg_214) } else { vec__197000050__5 = linked_212.(*aot_arbace_test.A_arbace_test_file_position_A).Invoke_O_O__O(root_211, arg_214) }
//line :117:1
	var file__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__197000050__5, lang.RT_IntCast_J__I_NoInit(0), nil); var line__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__197000050__5, lang.RT_IntCast_J__I_NoInit(1), nil); var detail__8 any; var root_220 any = A_arbace_test_junit_A_const_10.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_222 lang.IFn

	if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = A_arbace_test_junit_A_const_11.GetRawRoot__O(); var arg_224 any; var root_215 any = A_arbace_test_junit_A_const_26.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_interpose_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = Lit_8; var arg_219 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, expected_str__2)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, actual_str__3)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, file__6, nil, line__7)).Ref()); if linked_216 == nil { arg_224 = ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { arg_224 = linked_216.(*aot_arbace_core.A_arbace_core_interpose_A).Invoke_O_O_O__O(root_215, arg_218, arg_219) }; if linked_221 == nil { detail__8 = ifn_222.Invoke_O_O__O(arg_223, arg_224) } else { detail__8 = linked_221.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_220, arg_223, arg_224)
	}



	if jrt.J2g_Truth(message__1) { arg_228 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_8, nil), jrt.RefArrayOf(jrt.Object_class, message__1, nil, detail__8)).Ref() } else { arg_228 = detail__8 }
//line :117:1
	if linked_226 == nil { ifn_227.Invoke_O__O(arg_228) } else { linked_226.(*A_arbace_test_junit_element_content_A).Invoke_O_O__O(root_225, arg_228)
	}






	var root_229 any = A_arbace_test_junit_A_const_33.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, A_arbace_test_junit_finish_element_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = tag__0; var arg_233 any = jrt.Boolean_FALSE.Ref(); if linked_230 == nil { ifn_231.Invoke_O_O__O(arg_232, arg_233) } else { linked_230.(*A_arbace_test_junit_finish_element_A).Invoke_O_O_O__O(root_229, arg_232, arg_233) }
	return lang.IFn_Cast(A_arbace_test_junit_A_const_21.GetRawRoot__O()).Invoke__O()
}
func A_arbace_test_junit_failure_el_A_New() *A_arbace_test_junit_failure_el_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_failure_el_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_test_junit_failure_el_A) Ctor() {}
//line :128:1
func (t *A_arbace_test_junit_failure_el_A) Invoke_O_O_O_O__O(self, message__0, expected__1, actual__2 any) any {

	var root_242 any = A_arbace_test_junit_A_const_45.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_test_junit_message_el_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = A_arbace_test_junit_A_const_46; var arg_246 any = message__0; var arg_247 any = lang.IFn_Cast(A_arbace_test_junit_A_const_47.GetRawRoot__O()).Invoke_O__O(expected__1); var arg_248 any = lang.IFn_Cast(A_arbace_test_junit_A_const_47.GetRawRoot__O()).Invoke_O__O(actual__2); if linked_243 == nil { return ifn_244.Invoke_O_O_O_O__O(arg_245, arg_246, arg_247, arg_248) } else { return linked_243.(*A_arbace_test_junit_message_el_A).Invoke_O_O_O_O_O__O(root_242, arg_245, arg_246, arg_247, arg_248)
	} }
func A_arbace_test_junit_error_el_A_New() *A_arbace_test_junit_error_el_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_error_el_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_test_junit_error_el_A) Ctor() {}
//line :132:1
func (t *A_arbace_test_junit_error_el_A) Invoke_O_O_O_O__O(self, message__0, expected__1, actual__2 any) any {

	var root_279 any = A_arbace_test_junit_A_const_45.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, A_arbace_test_junit_message_el_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = A_arbace_test_junit_A_const_48; var arg_283 any = message__0; var arg_284 any = lang.IFn_Cast(A_arbace_test_junit_A_const_47.GetRawRoot__O()).Invoke_O__O(expected__1); var arg_285 any


	if jrt.Throwable_InstanceOf(actual__2) { var s__1927001093__auto____4 any = jrt.StringWriter_New(); var root_275 any = A_arbace_test_junit_A_const_53.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_277 lang.IFn
		if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_junit_A_const_55, s__1927001093__auto____4); if linked_276 == nil { ifn_277.Invoke_O__O(arg_278) } else { linked_276.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_275, arg_278) }; var tmp1 any = A_arbace_test_junit_error_el_fn__197000055_A_New_O_O(s__1927001093__auto____4, actual__2); var tmp2 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_test_junit_error_el_fn__197000055_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_test_junit_error_el_fn__197000055_A_fn_class = fncls__265d; tmp2 = fncls__265d } else { tmp2 = fncls__265 }; arg_285 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() } else {
			arg_285 = lang.IFn_Cast(A_arbace_test_junit_A_const_52.GetRawRoot__O()).Invoke_O__O(actual__2) }
//line :134:1
	if linked_280 == nil { return ifn_281.Invoke_O_O_O_O__O(arg_282, arg_283, arg_284, arg_285) } else { return linked_280.(*A_arbace_test_junit_message_el_A).Invoke_O_O_O_O_O__O(root_279, arg_282, arg_283, arg_284, arg_285)
	}
}

func A_arbace_test_junit_error_el_fn__197000055_A_New_O_O(p0, p1 any) *A_arbace_test_junit_error_el_fn__197000055_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_error_el_fn__197000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_test_junit_error_el_fn__197000055_A) Ctor_O_O(c__s__1927001093__auto__, c__actual any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_actual = c__actual }
//line :138:1
func (t *A_arbace_test_junit_error_el_fn__197000055_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_260 any = A_arbace_test_junit_A_const_50.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_stacktrace.A_arbace_stacktrace_print_cause_trace_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var t_ any = t.F_actual; t.F_actual = nil; arg_263 = t_; var arg_264 any = A_arbace_test_junit_A_const_51.Get__O(); if linked_261 == nil { ifn_262.Invoke_O_O__O(arg_263, arg_264) } else { linked_261.(*aot_arbace_stacktrace.A_arbace_stacktrace_print_cause_trace_A).Invoke_O_O_O__O(root_260, arg_263, arg_264) }; var root_253 any = A_arbace_test_junit_A_const_11.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_256 = t__2; if linked_254 == nil { tmp1 = ifn_255.Invoke_O__O(arg_256) } else { tmp1 = linked_254.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_253, arg_256) } }; return nil }(); var root_257 any = A_arbace_test_junit_A_const_49.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; if linked_258 == nil { ifn_259.Invoke__O() } else { linked_258.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_257) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_test_junit_eval197000060_fn__197000061_A_New() *A_arbace_test_junit_eval197000060_fn__197000061_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000060_fn__197000061_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) Ctor() {}
//line :144:1
func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) Invoke_O_O__O(self, m__1 any) any {
	var root_306 any = A_arbace_test_junit_A_const_53.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; var arg_309 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_59.Get__O()); if linked_307 == nil { ifn_308.Invoke_O__O(arg_309) } else { linked_307.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_306, arg_309) }
//line :144:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_294 any = A_arbace_test_junit_A_const_56.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, A_arbace_test_junit_start_suite_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any; var root_290 any = A_arbace_test_junit_A_const_22.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any; var root_286 any = A_arbace_test_junit_A_const_57.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = A_arbace_test_junit_A_const_58.Invoke_O__O(m__1); if linked_287 == nil { arg_293 = ifn_288.Invoke_O__O(arg_289) } else { arg_293 = linked_287.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_286, arg_289) }; if linked_291 == nil { arg_297 = ifn_292.Invoke_O__O(arg_293) } else { arg_297 = linked_291.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_290, arg_293) }; if linked_295 == nil { tmp3 = ifn_296.Invoke_O__O(arg_297) } else { tmp3 = linked_295.(*A_arbace_test_junit_start_suite_A).Invoke_O_O__O(root_294, arg_297) } }
//line :144:1
		return nil }(); var root_298 any = A_arbace_test_junit_A_const_49.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_300 lang.IFn
	if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; if linked_299 == nil { ifn_300.Invoke__O() } else { linked_299.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_298) }
//line :144:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_junit_eval197000064_fn__197000065_A_New() *A_arbace_test_junit_eval197000064_fn__197000065_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000064_fn__197000065_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) Ctor() {}
//line :148:1
func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) Invoke_O_O__O(self, ___1 any) any {
	var root_321 any = A_arbace_test_junit_A_const_53.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; var arg_324 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_59.Get__O()); if linked_322 == nil { ifn_323.Invoke_O__O(arg_324) } else { linked_322.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_321, arg_324) }
//line :148:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_310 any = A_arbace_test_junit_A_const_60.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, A_arbace_test_junit_finish_suite_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; if linked_311 == nil { tmp3 = ifn_312.Invoke__O() } else { tmp3 = linked_311.(*A_arbace_test_junit_finish_suite_A).Invoke_O__O(root_310) } }
//line :148:1
		return nil }(); var root_313 any = A_arbace_test_junit_A_const_49.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_315 lang.IFn
	if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; if linked_314 == nil { ifn_315.Invoke__O() } else { linked_314.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_313) }
//line :148:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_junit_eval197000068_fn__197000069_A_New() *A_arbace_test_junit_eval197000068_fn__197000069_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000068_fn__197000069_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) Ctor() {}
//line :152:1
func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) Invoke_O_O__O(self, m__1 any) any {
	var root_353 any = A_arbace_test_junit_A_const_53.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; var arg_356 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_59.Get__O()); if linked_354 == nil { ifn_355.Invoke_O__O(arg_356) } else { linked_354.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_353, arg_356) }
//line :152:1
	var tmp3 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var var__4 any = A_arbace_test_junit_A_const_61.Invoke_O__O(m__1); var root_367 any = A_arbace_test_junit_A_const_53.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_369 lang.IFn


		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp5 any = A_arbace_test_junit_A_const_64; var tmp6 any; var root_357 any = A_arbace_test_junit_A_const_8.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = A_arbace_test_junit_A_const_64.Get__O(); var arg_361 any = var__4; if linked_358 == nil { tmp6 = ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { tmp6 = linked_358.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_357, arg_360, arg_361) }; arg_370 = tmp4.Invoke_O_O__O(tmp5, tmp6); if linked_368 == nil { ifn_369.Invoke_O__O(arg_370) } else { linked_368.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_367, arg_370) }; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			{ var root_337 any = A_arbace_test_junit_A_const_62.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, A_arbace_test_junit_start_case_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any; var root_325 any = A_arbace_test_junit_A_const_63.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, A_arbace_test_junit_test_name_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = A_arbace_test_junit_A_const_64.Get__O(); if linked_326 == nil { arg_340 = ifn_327.Invoke_O__O(arg_328) } else { arg_340 = linked_326.(*A_arbace_test_junit_test_name_A).Invoke_O_O__O(root_325, arg_328) }; var arg_341 any; var root_333 any = A_arbace_test_junit_A_const_22.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any; var root_329 any = A_arbace_test_junit_A_const_57.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_ns_name_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var tmp7 *lang.Keyword = A_arbace_test_junit_A_const_58; var arg_332 any = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(var__4)); if linked_330 == nil { arg_336 = ifn_331.Invoke_O__O(arg_332) } else { arg_336 = linked_330.(*aot_arbace_core.A_arbace_core_ns_name_A).Invoke_O_O__O(root_329, arg_332) }; if linked_334 == nil { arg_341 = ifn_335.Invoke_O__O(arg_336) } else { arg_341 = linked_334.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_333, arg_336) }; if linked_338 == nil { tmp3 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { tmp3 = linked_338.(*A_arbace_test_junit_start_case_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) } }
//line :155:1
			return nil }(); var root_342 any = A_arbace_test_junit_A_const_49.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; if linked_343 == nil { ifn_344.Invoke__O() } else { linked_343.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_342) }
//line :152:1
		if tmp8 != nil { panic(tmp8) } }; return nil }(); var root_345 any = A_arbace_test_junit_A_const_49.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_347 lang.IFn
	if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; if linked_346 == nil { ifn_347.Invoke__O() } else { linked_346.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_345) }
//line :152:1
	if tmp9 != nil { panic(tmp9) }; return tmp3
}




func A_arbace_test_junit_eval197000072_fn__197000073_A_New() *A_arbace_test_junit_eval197000072_fn__197000073_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000072_fn__197000073_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) Ctor() {}
//line :158:1
func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) Invoke_O_O__O(self, m__1 any) any {
	var root_382 any = A_arbace_test_junit_A_const_53.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; var arg_385 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_59.Get__O()); if linked_383 == nil { ifn_384.Invoke_O__O(arg_385) } else { linked_383.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_382, arg_385) }
//line :158:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_371 any = A_arbace_test_junit_A_const_65.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, A_arbace_test_junit_finish_case_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; if linked_372 == nil { tmp3 = ifn_373.Invoke__O() } else { tmp3 = linked_372.(*A_arbace_test_junit_finish_case_A).Invoke_O__O(root_371) } }
//line :158:1
		return nil }(); var root_374 any = A_arbace_test_junit_A_const_49.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_376 lang.IFn
	if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; if linked_375 == nil { ifn_376.Invoke__O() } else { linked_375.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_374) }
//line :158:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_junit_eval197000076_fn__197000077_A_New() *A_arbace_test_junit_eval197000076_fn__197000077_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000076_fn__197000077_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) Ctor() {}
//line :162:1
func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) Invoke_O_O__O(self, m__1 any) any {
	var root_398 any = A_arbace_test_junit_A_const_53.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; var arg_401 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_59.Get__O()); if linked_399 == nil { ifn_400.Invoke_O__O(arg_401) } else { linked_399.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_398, arg_401) }
//line :162:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_386 any = A_arbace_test_junit_A_const_66.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_test.A_arbace_test_inc_report_counter_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = A_arbace_test_junit_A_const_67; if linked_387 == nil { tmp3 = ifn_388.Invoke_O__O(arg_389) } else { tmp3 = linked_387.(*aot_arbace_test.A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_386, arg_389) } }
//line :162:1
		return nil }(); var root_390 any = A_arbace_test_junit_A_const_49.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_392 lang.IFn
	if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; if linked_391 == nil { ifn_392.Invoke__O() } else { linked_391.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_390) }
//line :162:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_junit_eval197000080_fn__197000081_A_New() *A_arbace_test_junit_eval197000080_fn__197000081_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000080_fn__197000081_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) Ctor() {}
//line :166:1
func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) Invoke_O_O__O(self, m__1 any) any {
	var root_416 any = A_arbace_test_junit_A_const_53.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; var arg_419 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_59.Get__O()); if linked_417 == nil { ifn_418.Invoke_O__O(arg_419) } else { linked_417.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_416, arg_419) }
//line :166:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_420 any = A_arbace_test_junit_A_const_66.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_test.A_arbace_test_inc_report_counter_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_test_junit_A_const_71; if linked_421 == nil { ifn_422.Invoke_O__O(arg_423) } else { linked_421.(*aot_arbace_test.A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_420, arg_423) }
			var root_402 any = A_arbace_test_junit_A_const_68.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_402, A_arbace_test_junit_failure_el_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = A_arbace_test_junit_A_const_41.Invoke_O__O(m__1); var arg_406 any = A_arbace_test_junit_A_const_69.Invoke_O__O(m__1); var arg_407 any = A_arbace_test_junit_A_const_70.Invoke_O__O(m__1); if linked_403 == nil { tmp3 = ifn_404.Invoke_O_O_O__O(arg_405, arg_406, arg_407) } else { tmp3 = linked_403.(*A_arbace_test_junit_failure_el_A).Invoke_O_O_O_O__O(root_402, arg_405, arg_406, arg_407) } }
//line :166:1
		return nil }(); var root_408 any = A_arbace_test_junit_A_const_49.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_410 lang.IFn
	if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; if linked_409 == nil { ifn_410.Invoke__O() } else { linked_409.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_408) }
//line :166:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}





func A_arbace_test_junit_eval197000084_fn__197000085_A_New() *A_arbace_test_junit_eval197000084_fn__197000085_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000084_fn__197000085_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) Ctor() {}
//line :173:1
func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) Invoke_O_O__O(self, m__1 any) any {
	var root_438 any = A_arbace_test_junit_A_const_53.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; var arg_441 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_59.Get__O()); if linked_439 == nil { ifn_440.Invoke_O__O(arg_441) } else { linked_439.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_438, arg_441) }
//line :173:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var root_442 any = A_arbace_test_junit_A_const_66.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_test.A_arbace_test_inc_report_counter_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = A_arbace_test_junit_A_const_73; if linked_443 == nil { ifn_444.Invoke_O__O(arg_445) } else { linked_443.(*aot_arbace_test.A_arbace_test_inc_report_counter_A).Invoke_O_O__O(root_442, arg_445) }
			var root_424 any = A_arbace_test_junit_A_const_72.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, A_arbace_test_junit_error_el_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = A_arbace_test_junit_A_const_41.Invoke_O__O(m__1); var arg_428 any = A_arbace_test_junit_A_const_69.Invoke_O__O(m__1); var arg_429 any = A_arbace_test_junit_A_const_70.Invoke_O__O(m__1); if linked_425 == nil { tmp3 = ifn_426.Invoke_O_O_O__O(arg_427, arg_428, arg_429) } else { tmp3 = linked_425.(*A_arbace_test_junit_error_el_A).Invoke_O_O_O_O__O(root_424, arg_427, arg_428, arg_429) } }
//line :173:1
		return nil }(); var root_430 any = A_arbace_test_junit_A_const_49.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_432 lang.IFn
	if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; if linked_431 == nil { ifn_432.Invoke__O() } else { linked_431.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_430) }
//line :173:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}





func A_arbace_test_junit_eval197000088_fn__197000089_A_New() *A_arbace_test_junit_eval197000088_fn__197000089_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000088_fn__197000089_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) Ctor() {}
//line :180:1
func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_test_junit_with_junit_output_A_New() *A_arbace_test_junit_with_junit_output_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_with_junit_output_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_test_junit_with_junit_output_A) Ctor() {}
//line :182:1
func (t *A_arbace_test_junit_with_junit_output_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var root_559 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_76); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp4 any; var root_467 any = A_arbace_test_junit_A_const_10.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = A_arbace_test_junit_A_const_77.GetRawRoot__O(); var arg_471 any; var root_463 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_78); var tmp7 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_79); var tmp8 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_80); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp10 any; var root_450 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var root_446 any = A_arbace_test_junit_A_const_74.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_81); if linked_447 == nil { arg_453 = ifn_448.Invoke_O__O(arg_449) } else { arg_453 = linked_447.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_446, arg_449) }; if linked_451 == nil { tmp10 = ifn_452.Invoke_O__O(arg_453) } else { tmp10 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }; arg_466 = tmp5.Invoke_O_O_O_O_O_O__O(tmp6, tmp7, tmp8, tmp9.Invoke_O__O(tmp10), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_82), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_83)); if linked_464 == nil { arg_471 = ifn_465.Invoke_O__O(arg_466) } else { arg_471 = linked_464.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_463, arg_466) }; if linked_468 == nil { tmp4 = ifn_469.Invoke_O_O__O(arg_470, arg_471) } else { tmp4 = linked_468.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_467, arg_470, arg_471) }; var tmp11 any = tmp3.Invoke_O__O(tmp4); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp13 any; var root_496 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()); var tmp15 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_84); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp17 any; var root_477 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any; var root_472 any = A_arbace_test_junit_A_const_74.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_85); var arg_476 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(Lit_20); if linked_473 == nil { arg_480 = ifn_474.Invoke_O_O__O(arg_475, arg_476) } else { arg_480 = linked_473.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_472, arg_475, arg_476) }; if linked_478 == nil { tmp17 = ifn_479.Invoke_O__O(arg_480) } else { tmp17 = linked_478.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_477, arg_480) }; var tmp18 any = tmp16.Invoke_O__O(tmp17); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp20 any; var root_486 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any; var root_481 any = A_arbace_test_junit_A_const_74.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_86); var arg_485 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(Lit_21); if linked_482 == nil { arg_489 = ifn_483.Invoke_O_O__O(arg_484, arg_485) } else { arg_489 = linked_482.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_481, arg_484, arg_485) }; if linked_487 == nil { tmp20 = ifn_488.Invoke_O__O(arg_489) } else { tmp20 = linked_487.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_486, arg_489) }; arg_499 = tmp14.Invoke_O_O_O__O(tmp15, tmp18, tmp19.Invoke_O__O(tmp20)); if linked_497 == nil { tmp13 = ifn_498.Invoke_O__O(arg_499) } else { tmp13 = linked_497.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_496, arg_499) }; var tmp21 any = tmp12.Invoke_O__O(tmp13); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp23 any; var root_548 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()); var tmp25 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_87); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp27 any; var root_518 any = A_arbace_test_junit_A_const_10.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = A_arbace_test_junit_A_const_77.GetRawRoot__O(); var arg_522 any; var root_514 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any; var root_509 any = A_arbace_test_junit_A_const_74.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_88); var arg_513 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp29 any; var root_505 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any; var root_500 any = A_arbace_test_junit_A_const_74.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_89); var arg_504 any = body__2; if linked_501 == nil { arg_508 = ifn_502.Invoke_O_O__O(arg_503, arg_504) } else { arg_508 = linked_501.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_500, arg_503, arg_504) }; if linked_506 == nil { tmp29 = ifn_507.Invoke_O__O(arg_508) } else { tmp29 = linked_506.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_505, arg_508) }; arg_513 = tmp28.Invoke_O__O(tmp29); if linked_510 == nil { arg_517 = ifn_511.Invoke_O_O__O(arg_512, arg_513) } else { arg_517 = linked_510.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_509, arg_512, arg_513) }; if linked_515 == nil { arg_522 = ifn_516.Invoke_O__O(arg_517) } else { arg_522 = linked_515.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_514, arg_517) }; if linked_519 == nil { tmp27 = ifn_520.Invoke_O_O__O(arg_521, arg_522) } else { tmp27 = linked_519.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_518, arg_521, arg_522) }; var tmp30 any = tmp26.Invoke_O__O(tmp27); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp32 any; var root_537 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any; var root_532 any = A_arbace_test_junit_A_const_74.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_90); var arg_536 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()); var tmp34 any; var root_528 any = A_arbace_test_junit_A_const_17.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any; var root_523 any = A_arbace_test_junit_A_const_74.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_91); var arg_527 any = lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(Lit_22); if linked_524 == nil { arg_531 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { arg_531 = linked_524.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; if linked_529 == nil { tmp34 = ifn_530.Invoke_O__O(arg_531) } else { tmp34 = linked_529.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_528, arg_531) }; arg_536 = tmp33.Invoke_O__O(tmp34); if linked_533 == nil { arg_540 = ifn_534.Invoke_O_O__O(arg_535, arg_536) } else { arg_540 = linked_533.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_532, arg_535, arg_536) }; if linked_538 == nil { tmp32 = ifn_539.Invoke_O__O(arg_540) } else { tmp32 = linked_538.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_537, arg_540) }; arg_551 = tmp24.Invoke_O_O_O_O__O(tmp25, tmp30, tmp31.Invoke_O__O(tmp32), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_88)); if linked_549 == nil { tmp23 = ifn_550.Invoke_O__O(arg_551) } else { tmp23 = linked_549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_548, arg_551) }; arg_562 = tmp1.Invoke_O_O_O_O__O(tmp2, tmp11, tmp21, tmp22.Invoke_O__O(tmp23)); if linked_560 == nil { return ifn_561.Invoke_O__O(arg_562) } else { return linked_560.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_559, arg_562) } }































type A_arbace_test_junit_A struct{ jrt.Object }

var A_arbace_test_junit_A_const_pool *jrt.RefArray

var A_arbace_test_junit_A_const_0 *lang.Var

var A_arbace_test_junit_A_const_1 any

var A_arbace_test_junit_A_const_2 any

var A_arbace_test_junit_A_const_3 *lang.Var

var A_arbace_test_junit_A_const_4 any

var A_arbace_test_junit_A_const_5 *lang.Var

var A_arbace_test_junit_A_const_6 *lang.Var

var A_arbace_test_junit_A_const_7 *lang.Var

var A_arbace_test_junit_A_const_8 *lang.Var

var A_arbace_test_junit_A_const_9 any

var A_arbace_test_junit_A_const_10 *lang.Var

var A_arbace_test_junit_A_const_11 *lang.Var

var A_arbace_test_junit_A_const_12 *lang.Var

var A_arbace_test_junit_A_const_13 *lang.Var

var A_arbace_test_junit_A_const_14 *lang.Var

var A_arbace_test_junit_A_const_15 *lang.Var

var A_arbace_test_junit_A_const_16 *lang.Var

var A_arbace_test_junit_A_const_17 *lang.Var

var A_arbace_test_junit_A_const_18 *lang.Var

var A_arbace_test_junit_A_const_19 *lang.Var

var A_arbace_test_junit_A_const_20 *lang.Var

var A_arbace_test_junit_A_const_21 *lang.Var

var A_arbace_test_junit_A_const_22 *lang.Var

var A_arbace_test_junit_A_const_23 *lang.Var

var A_arbace_test_junit_A_const_24 *lang.Var

var A_arbace_test_junit_A_const_25 *lang.Var

var A_arbace_test_junit_A_const_26 *lang.Var

var A_arbace_test_junit_A_const_27 *lang.Var

var A_arbace_test_junit_A_const_28 *lang.Keyword

var A_arbace_test_junit_A_const_29 any

var A_arbace_test_junit_A_const_30 *lang.Var

var A_arbace_test_junit_A_const_31 any

var A_arbace_test_junit_A_const_32 *lang.Keyword

var A_arbace_test_junit_A_const_33 *lang.Var

var A_arbace_test_junit_A_const_34 any

var A_arbace_test_junit_A_const_35 *lang.Var

var A_arbace_test_junit_A_const_36 *lang.Keyword

var A_arbace_test_junit_A_const_37 *lang.Var

var A_arbace_test_junit_A_const_38 any

var A_arbace_test_junit_A_const_39 *lang.Var

var A_arbace_test_junit_A_const_40 any

var A_arbace_test_junit_A_const_41 *lang.Keyword

var A_arbace_test_junit_A_const_42 *lang.Var

var A_arbace_test_junit_A_const_43 *lang.Var

var A_arbace_test_junit_A_const_44 any

var A_arbace_test_junit_A_const_45 *lang.Var

var A_arbace_test_junit_A_const_46 any

var A_arbace_test_junit_A_const_47 *lang.Var

var A_arbace_test_junit_A_const_48 any

var A_arbace_test_junit_A_const_49 *lang.Var

var A_arbace_test_junit_A_const_50 *lang.Var

var A_arbace_test_junit_A_const_51 *lang.Var

var A_arbace_test_junit_A_const_52 *lang.Var

var A_arbace_test_junit_A_const_53 *lang.Var

var A_arbace_test_junit_A_const_54 *lang.Var

var A_arbace_test_junit_A_const_55 *lang.Var

var A_arbace_test_junit_A_const_56 *lang.Var

var A_arbace_test_junit_A_const_57 *lang.Var

var A_arbace_test_junit_A_const_58 *lang.Keyword

var A_arbace_test_junit_A_const_59 *lang.Var

var A_arbace_test_junit_A_const_60 *lang.Var

var A_arbace_test_junit_A_const_61 *lang.Keyword

var A_arbace_test_junit_A_const_62 *lang.Var

var A_arbace_test_junit_A_const_63 *lang.Var

var A_arbace_test_junit_A_const_64 *lang.Var

var A_arbace_test_junit_A_const_65 *lang.Var

var A_arbace_test_junit_A_const_66 *lang.Var

var A_arbace_test_junit_A_const_67 *lang.Keyword

var A_arbace_test_junit_A_const_68 *lang.Var

var A_arbace_test_junit_A_const_69 *lang.Keyword

var A_arbace_test_junit_A_const_70 *lang.Keyword

var A_arbace_test_junit_A_const_71 *lang.Keyword

var A_arbace_test_junit_A_const_72 *lang.Var

var A_arbace_test_junit_A_const_73 *lang.Keyword

var A_arbace_test_junit_A_const_74 *lang.Var

var A_arbace_test_junit_A_const_75 *lang.Var

var A_arbace_test_junit_A_const_76 any

var A_arbace_test_junit_A_const_77 *lang.Var

var A_arbace_test_junit_A_const_78 any

var A_arbace_test_junit_A_const_79 any

var A_arbace_test_junit_A_const_80 any

var A_arbace_test_junit_A_const_81 any

var A_arbace_test_junit_A_const_82 any

var A_arbace_test_junit_A_const_83 any

var A_arbace_test_junit_A_const_84 any

var A_arbace_test_junit_A_const_85 any

var A_arbace_test_junit_A_const_86 any

var A_arbace_test_junit_A_const_87 any

var A_arbace_test_junit_A_const_88 any

var A_arbace_test_junit_A_const_89 any

var A_arbace_test_junit_A_const_90 any

var A_arbace_test_junit_A_const_91 any

var A_arbace_test_junit_A_init jrt.ClassInit

func A_arbace_test_junit_A_Init() { if !A_arbace_test_junit_A_init.Done() { A_arbace_test_junit_A_init.Run(A_arbace_test_junit_A_clinit) } }

func A_arbace_test_junit_A_clinit() { A_arbace_test_junit_A_clinit_p0(); A_arbace_test_junit_A_clinit_p1(); A_arbace_test_junit_A_clinit_p2(); A_arbace_test_junit_A_clinit_p3(); A_arbace_test_junit_A_clinit_p4(); A_arbace_test_junit_A_clinit_p5(); A_arbace_test_junit_A_clinit_p6(); A_arbace_test_junit_A_clinit_p7() }

func A_arbace_test_junit_A_clinit_p0() { jrt.StartCheck(); A_arbace_test_junit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 126); A_arbace_test_junit_A_const_0 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[34]); A_arbace_test_junit_A_const_1 = A_arbace_test_junit_A_const_pool.A[35]; A_arbace_test_junit_A_const_2 = A_arbace_test_junit_A_const_pool.A[36]; A_arbace_test_junit_A_const_3 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[37]); A_arbace_test_junit_A_const_4 = A_arbace_test_junit_A_const_pool.A[38]; A_arbace_test_junit_A_const_5 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[39]); A_arbace_test_junit_A_const_6 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[40]); A_arbace_test_junit_A_const_7 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[41]); A_arbace_test_junit_A_const_8 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[42]); A_arbace_test_junit_A_const_9 = A_arbace_test_junit_A_const_pool.A[43]; A_arbace_test_junit_A_const_10 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[44]); A_arbace_test_junit_A_const_11 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[45]) }

func A_arbace_test_junit_A_clinit_p1() { A_arbace_test_junit_A_const_12 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[46]); A_arbace_test_junit_A_const_13 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[47]); A_arbace_test_junit_A_const_14 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[48]); A_arbace_test_junit_A_const_15 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[49]); A_arbace_test_junit_A_const_16 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[50]); A_arbace_test_junit_A_const_17 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[51]); A_arbace_test_junit_A_const_18 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[52]); A_arbace_test_junit_A_const_19 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[53]); A_arbace_test_junit_A_const_20 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[54]); A_arbace_test_junit_A_const_21 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[55]); A_arbace_test_junit_A_const_22 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[56]); A_arbace_test_junit_A_const_23 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[57]) }

func A_arbace_test_junit_A_clinit_p2() { A_arbace_test_junit_A_const_24 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[58]); A_arbace_test_junit_A_const_25 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[59]); A_arbace_test_junit_A_const_26 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[60]); A_arbace_test_junit_A_const_27 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[61]); A_arbace_test_junit_A_const_28 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[62]); A_arbace_test_junit_A_const_29 = A_arbace_test_junit_A_const_pool.A[63]; A_arbace_test_junit_A_const_30 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[64]); A_arbace_test_junit_A_const_31 = A_arbace_test_junit_A_const_pool.A[65]; A_arbace_test_junit_A_const_32 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[66]); A_arbace_test_junit_A_const_33 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[67]); A_arbace_test_junit_A_const_34 = A_arbace_test_junit_A_const_pool.A[68]; A_arbace_test_junit_A_const_35 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[69]) }

func A_arbace_test_junit_A_clinit_p3() { A_arbace_test_junit_A_const_36 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[70]); A_arbace_test_junit_A_const_37 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[71]); A_arbace_test_junit_A_const_38 = A_arbace_test_junit_A_const_pool.A[72]; A_arbace_test_junit_A_const_39 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[73]); A_arbace_test_junit_A_const_40 = A_arbace_test_junit_A_const_pool.A[74]; A_arbace_test_junit_A_const_41 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[75]); A_arbace_test_junit_A_const_42 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[76]); A_arbace_test_junit_A_const_43 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[77]); A_arbace_test_junit_A_const_44 = A_arbace_test_junit_A_const_pool.A[78]; A_arbace_test_junit_A_const_45 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[79]); A_arbace_test_junit_A_const_46 = A_arbace_test_junit_A_const_pool.A[80]; A_arbace_test_junit_A_const_47 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[81]); A_arbace_test_junit_A_const_48 = A_arbace_test_junit_A_const_pool.A[82] }

func A_arbace_test_junit_A_clinit_p4() { A_arbace_test_junit_A_const_49 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[83]); A_arbace_test_junit_A_const_50 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[84]); A_arbace_test_junit_A_const_51 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[85]); A_arbace_test_junit_A_const_52 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[86]); A_arbace_test_junit_A_const_53 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[87]); A_arbace_test_junit_A_const_54 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[88]); A_arbace_test_junit_A_const_55 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[89]); A_arbace_test_junit_A_const_56 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[90]); A_arbace_test_junit_A_const_57 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[91]); A_arbace_test_junit_A_const_58 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[92]); A_arbace_test_junit_A_const_59 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[93]); A_arbace_test_junit_A_const_60 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[94]) }

func A_arbace_test_junit_A_clinit_p5() { A_arbace_test_junit_A_const_61 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[95]); A_arbace_test_junit_A_const_62 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[96]); A_arbace_test_junit_A_const_63 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[97]); A_arbace_test_junit_A_const_64 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[98]); A_arbace_test_junit_A_const_65 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[99]); A_arbace_test_junit_A_const_66 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[100]); A_arbace_test_junit_A_const_67 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[101]); A_arbace_test_junit_A_const_68 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[102]); A_arbace_test_junit_A_const_69 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[103]); A_arbace_test_junit_A_const_70 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[104]); A_arbace_test_junit_A_const_71 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[105]); A_arbace_test_junit_A_const_72 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[106]) }

func A_arbace_test_junit_A_clinit_p6() { A_arbace_test_junit_A_const_73 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[107]); A_arbace_test_junit_A_const_74 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[108]); A_arbace_test_junit_A_const_75 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[109]); A_arbace_test_junit_A_const_76 = A_arbace_test_junit_A_const_pool.A[110]; A_arbace_test_junit_A_const_77 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[111]); A_arbace_test_junit_A_const_78 = A_arbace_test_junit_A_const_pool.A[112]; A_arbace_test_junit_A_const_79 = A_arbace_test_junit_A_const_pool.A[113]; A_arbace_test_junit_A_const_80 = A_arbace_test_junit_A_const_pool.A[114]; A_arbace_test_junit_A_const_81 = A_arbace_test_junit_A_const_pool.A[115]; A_arbace_test_junit_A_const_82 = A_arbace_test_junit_A_const_pool.A[116]; A_arbace_test_junit_A_const_83 = A_arbace_test_junit_A_const_pool.A[117]; A_arbace_test_junit_A_const_84 = A_arbace_test_junit_A_const_pool.A[118]; A_arbace_test_junit_A_const_85 = A_arbace_test_junit_A_const_pool.A[119]; A_arbace_test_junit_A_const_86 = A_arbace_test_junit_A_const_pool.A[120] }

func A_arbace_test_junit_A_clinit_p7() { A_arbace_test_junit_A_const_87 = A_arbace_test_junit_A_const_pool.A[121]; A_arbace_test_junit_A_const_88 = A_arbace_test_junit_A_const_pool.A[122]; A_arbace_test_junit_A_const_89 = A_arbace_test_junit_A_const_pool.A[123]; A_arbace_test_junit_A_const_90 = A_arbace_test_junit_A_const_pool.A[124]; A_arbace_test_junit_A_const_91 = A_arbace_test_junit_A_const_pool.A[125] }

func A_arbace_test_junit_A_New() *A_arbace_test_junit_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_A) Ctor() {}

func (t *A_arbace_test_junit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_A_class }

func (t *A_arbace_test_junit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_A); return ok }

func A_arbace_test_junit_A_Cast(x any) *A_arbace_test_junit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_A_class)) }; return v }



type A_arbace_test_junit_element_content_A struct{ j2g_header uint64 }

var A_arbace_test_junit_element_content_A_fn_class *jrt.Class



type A_arbace_test_junit_error_el_A struct{ j2g_header uint64 }

var A_arbace_test_junit_error_el_A_fn_class *jrt.Class



type A_arbace_test_junit_error_el_fn__197000055_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_actual any }

var A_arbace_test_junit_error_el_fn__197000055_A_fn_class *jrt.Class



type A_arbace_test_junit_escape_xml_A struct{ j2g_header uint64 }

var A_arbace_test_junit_escape_xml_A_fn_class *jrt.Class



type A_arbace_test_junit_escape_xml_fn__197000016_A struct{ j2g_header uint64 }

var A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000004_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000004_A_New() *A_arbace_test_junit_eval197000004_A { t := &A_arbace_test_junit_eval197000004_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000004_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000004_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000004_A_class }

func (t *A_arbace_test_junit_eval197000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000004_A); return ok }

func A_arbace_test_junit_eval197000004_A_Cast(x any) *A_arbace_test_junit_eval197000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000004_A_class)) }; return v }



type A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000008_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000008_A_New() *A_arbace_test_junit_eval197000008_A { t := &A_arbace_test_junit_eval197000008_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000008_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000008_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000008_A_class }

func (t *A_arbace_test_junit_eval197000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000008_A); return ok }

func A_arbace_test_junit_eval197000008_A_Cast(x any) *A_arbace_test_junit_eval197000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000008_A_class)) }; return v }



type A_arbace_test_junit_eval197000008_fn__197000009_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000008_fn__197000009_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000060_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000060_A_New() *A_arbace_test_junit_eval197000060_A { t := &A_arbace_test_junit_eval197000060_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000060_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000060_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000060_A_class }

func (t *A_arbace_test_junit_eval197000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000060_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000060_A); return ok }

func A_arbace_test_junit_eval197000060_A_Cast(x any) *A_arbace_test_junit_eval197000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000060_A_class)) }; return v }



type A_arbace_test_junit_eval197000060_fn__197000061_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000060_fn__197000061_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000064_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000064_A_New() *A_arbace_test_junit_eval197000064_A { t := &A_arbace_test_junit_eval197000064_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000064_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000064_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000064_A_class }

func (t *A_arbace_test_junit_eval197000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000064_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000064_A); return ok }

func A_arbace_test_junit_eval197000064_A_Cast(x any) *A_arbace_test_junit_eval197000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000064_A_class)) }; return v }



type A_arbace_test_junit_eval197000064_fn__197000065_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000064_fn__197000065_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000068_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000068_A_New() *A_arbace_test_junit_eval197000068_A { t := &A_arbace_test_junit_eval197000068_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000068_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000068_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000068_A_class }

func (t *A_arbace_test_junit_eval197000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000068_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000068_A); return ok }

func A_arbace_test_junit_eval197000068_A_Cast(x any) *A_arbace_test_junit_eval197000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000068_A_class)) }; return v }



type A_arbace_test_junit_eval197000068_fn__197000069_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000068_fn__197000069_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000072_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000072_A_New() *A_arbace_test_junit_eval197000072_A { t := &A_arbace_test_junit_eval197000072_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000072_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000072_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000072_A_class }

func (t *A_arbace_test_junit_eval197000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000072_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000072_A); return ok }

func A_arbace_test_junit_eval197000072_A_Cast(x any) *A_arbace_test_junit_eval197000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000072_A_class)) }; return v }



type A_arbace_test_junit_eval197000072_fn__197000073_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000072_fn__197000073_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000076_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000076_A_New() *A_arbace_test_junit_eval197000076_A { t := &A_arbace_test_junit_eval197000076_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000076_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000076_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000076_A_class }

func (t *A_arbace_test_junit_eval197000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000076_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000076_A); return ok }

func A_arbace_test_junit_eval197000076_A_Cast(x any) *A_arbace_test_junit_eval197000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000076_A_class)) }; return v }



type A_arbace_test_junit_eval197000076_fn__197000077_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000076_fn__197000077_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000080_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000080_A_New() *A_arbace_test_junit_eval197000080_A { t := &A_arbace_test_junit_eval197000080_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000080_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000080_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000080_A_class }

func (t *A_arbace_test_junit_eval197000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000080_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000080_A); return ok }

func A_arbace_test_junit_eval197000080_A_Cast(x any) *A_arbace_test_junit_eval197000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000080_A_class)) }; return v }



type A_arbace_test_junit_eval197000080_fn__197000081_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000080_fn__197000081_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000084_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000084_A_New() *A_arbace_test_junit_eval197000084_A { t := &A_arbace_test_junit_eval197000084_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000084_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000084_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000084_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000084_A_class }

func (t *A_arbace_test_junit_eval197000084_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000084_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000084_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000084_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000084_A); return ok }

func A_arbace_test_junit_eval197000084_A_Cast(x any) *A_arbace_test_junit_eval197000084_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000084_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000084_A_class)) }; return v }



type A_arbace_test_junit_eval197000084_fn__197000085_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000084_fn__197000085_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000088_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000088_A_New() *A_arbace_test_junit_eval197000088_A { t := &A_arbace_test_junit_eval197000088_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000088_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000088_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000088_A_class }

func (t *A_arbace_test_junit_eval197000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000088_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000088_A); return ok }

func A_arbace_test_junit_eval197000088_A_Cast(x any) *A_arbace_test_junit_eval197000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000088_A_class)) }; return v }



type A_arbace_test_junit_eval197000088_fn__197000089_A struct{ j2g_header uint64 }

var A_arbace_test_junit_eval197000088_fn__197000089_A_fn_class *jrt.Class



type A_arbace_test_junit_failure_el_A struct{ j2g_header uint64 }

var A_arbace_test_junit_failure_el_A_fn_class *jrt.Class



type A_arbace_test_junit_finish_case_A struct{ j2g_header uint64 }

var A_arbace_test_junit_finish_case_A_fn_class *jrt.Class



type A_arbace_test_junit_finish_element_A struct{ j2g_header uint64 }

var A_arbace_test_junit_finish_element_A_fn_class *jrt.Class



type A_arbace_test_junit_finish_suite_A struct{ j2g_header uint64 }

var A_arbace_test_junit_finish_suite_A_fn_class *jrt.Class



type A_arbace_test_junit_fn__197000013_A struct{ j2g_header uint64 }

var A_arbace_test_junit_fn__197000013_A_fn_class *jrt.Class



type A_arbace_test_junit_indent_A struct{ j2g_header uint64 }

var A_arbace_test_junit_indent_A_fn_class *jrt.Class



type A_arbace_test_junit_message_el_A struct{ j2g_header uint64 }

var A_arbace_test_junit_message_el_A_fn_class *jrt.Class



type A_arbace_test_junit_package_class_A struct{ j2g_header uint64 }

var A_arbace_test_junit_package_class_A_fn_class *jrt.Class



type A_arbace_test_junit_start_case_A struct{ j2g_header uint64 }

var A_arbace_test_junit_start_case_A_fn_class *jrt.Class



type A_arbace_test_junit_start_element_A struct{ j2g_header uint64 }

var A_arbace_test_junit_start_element_A_fn_class *jrt.Class



type A_arbace_test_junit_start_suite_A struct{ j2g_header uint64 }

var A_arbace_test_junit_start_suite_A_fn_class *jrt.Class



type A_arbace_test_junit_suite_attrs_A struct{ j2g_header uint64 }

var A_arbace_test_junit_suite_attrs_A_fn_class *jrt.Class



type A_arbace_test_junit_test_name_A struct{ j2g_header uint64 }

var A_arbace_test_junit_test_name_A_fn_class *jrt.Class



type A_arbace_test_junit_test_name_fn__197000038_A struct{ j2g_header uint64 }

var A_arbace_test_junit_test_name_fn__197000038_A_fn_class *jrt.Class



type A_arbace_test_junit_with_junit_output_A struct{ j2g_header uint64 }

var A_arbace_test_junit_with_junit_output_A_fn_class *jrt.Class
