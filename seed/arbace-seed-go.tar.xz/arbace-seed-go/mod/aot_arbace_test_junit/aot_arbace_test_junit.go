//line aot_arbace_test_junit.ae:1
package aot_arbace_test_junit

import (
	"arbace/jrt"
	"arbace/lang"
)










func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_New() *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A { A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_Init(); t := &A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_test_junit_A_Init(); tmp4 = A_arbace_test_junit_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_test_junit_A_Init(); tmp6 = A_arbace_test_junit_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_4; tmp3 = tmp8.Invoke_O_O__O(tmp10, tmp11) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp12 != nil { panic(tmp12) }; return tmp3 }
//line :17:1
func A_arbace_test_junit_eval197000008_fn__197000009_A_New() *A_arbace_test_junit_eval197000008_fn__197000009_A { A_arbace_test_junit_eval197000008_fn__197000009_A_Init(); t := &A_arbace_test_junit_eval197000008_fn__197000009_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_5; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_9; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_7; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_8; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }


























func A_arbace_test_junit_fn__197000013_A_New() *A_arbace_test_junit_fn__197000013_A { A_arbace_test_junit_fn__197000013_A_Init(); t := &A_arbace_test_junit_fn__197000013_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_test_junit_fn__197000013_A) Ctor() {}
//line :44:1
func (t *A_arbace_test_junit_fn__197000013_A) Invoke_O_O__O(self, p1__197000012_SHARP___0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_107, nil, Lit_108), jrt.RefArrayOf(jrt.Object_class, nil, p1__197000012_SHARP___0, nil)).Ref() }
func A_arbace_test_junit_escape_xml_A_New() *A_arbace_test_junit_escape_xml_A { A_arbace_test_junit_escape_xml_A_Init(); t := &A_arbace_test_junit_escape_xml_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_test_junit_escape_xml_A) Ctor() {}
//line :45:1
func (t *A_arbace_test_junit_escape_xml_A) Invoke_O_O__O(self, text__0 any) any {
	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_11; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_12; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_test_junit_escape_xml_fn__197000016_A_New(); var tmp8 *jrt.Class; A_arbace_test_junit_escape_xml_fn__197000016_A_Init(); tmp8 = A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), text__0)) }
//line :46:1
func A_arbace_test_junit_escape_xml_fn__197000016_A_New() *A_arbace_test_junit_escape_xml_fn__197000016_A { A_arbace_test_junit_escape_xml_fn__197000016_A_Init(); t := &A_arbace_test_junit_escape_xml_fn__197000016_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) Ctor() {}
//line :46:1
func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) Invoke_O_O__O(self, p1__197000015_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_13; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__197000015_SHARP___1, p1__197000015_SHARP___1) }




func A_arbace_test_junit_indent_A_New() *A_arbace_test_junit_indent_A { A_arbace_test_junit_indent_A_Init(); t := &A_arbace_test_junit_indent_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_test_junit_indent_A) Ctor() {}
//line :51:1
func (t *A_arbace_test_junit_indent_A) Invoke_O__O(self any) any { { var n__1927000701__auto____1 int64; var tmp1 *lang.Var

	A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_14; n__1927000701__auto____1 = lang.RT_LongCast_O__J(lang.Numbers_Multiply_O_J__Number(jrt.NN(tmp1).Get__O(), 4))
//line :51:1
	var n__2 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z(n__2, n__1927000701__auto____1) { var tmp2 *lang.Var; A_arbace_test_junit_A_Init(); tmp2 = A_arbace_test_junit_A_const_15; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(Lit_110); n__2 = lang.Numbers_Unchecked_inc_J__J(n__2); continue L1 } else { return nil } } }; /*line :51:1*/panic("a2g: unreachable") }



func A_arbace_test_junit_start_element_A_New() *A_arbace_test_junit_start_element_A { A_arbace_test_junit_start_element_A_Init(); t := &A_arbace_test_junit_start_element_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_test_junit_start_element_A) Ctor() {}
//line :55:1
func (t *A_arbace_test_junit_start_element_A) DoInvoke_O_O_O_O__O(self, tag__0, pretty__1, p__197000020__2 any) any { var vec__197000021__4 any = p__197000020__2; var attrs__5 any = lang.RT_Nth_O_I_O__O(vec__197000021__4, lang.RT_IntCast_J__I(0), nil); if

	jrt.A2g_Truth(pretty__1) { var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_16; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O() }; var tmp2 /*line :58:1*/*lang.Var; A_arbace_test_junit_A_Init(); tmp2 = A_arbace_test_junit_A_const_15; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_123, nil), jrt.RefArrayOf(jrt.Object_class, nil, tag__0)).Ref()); var tmp3 /*line :59:1*/*lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(attrs__5)) { var seq_197000024__6 any; var tmp4 *lang.Var
		A_arbace_test_junit_A_Init(); tmp4 = A_arbace_test_junit_A_const_17; seq_197000024__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(attrs__5)
//line :59:1
		var chunk_197000025__7 any; var count_197000026__8 int64 = 0; var i_197000027__9 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z(i_197000027__9, count_197000026__8) { var vec__197000028__10 any = lang.Indexed_Cast(chunk_197000025__7).Nth_I__O(lang.RT_IntCast_J__I(i_197000027__9)); var key__11 any = lang.RT_Nth_O_I_O__O(vec__197000028__10, lang.RT_IntCast_J__I(0), nil); var value__12 any = lang.RT_Nth_O_I_O__O(vec__197000028__10, lang.RT_IntCast_J__I(1), nil); var tmp5 *lang.Var
				A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_15; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_124, nil, Lit_125); var tmp8 *lang.Var; A_arbace_test_junit_A_Init(); tmp8 = A_arbace_test_junit_A_const_22; var tmp9 any = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(key__11); var tmp10 *lang.Var; A_arbace_test_junit_A_Init(); tmp10 = A_arbace_test_junit_A_const_23; tmp6.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(value__12), nil)).Ref())
//line :60:1
				seq_197000024__6, chunk_197000025__7, count_197000026__8, i_197000027__9 = seq_197000024__6, chunk_197000025__7, count_197000026__8, lang.Numbers_Unchecked_inc_J__J(i_197000027__9); continue L1 } else { var temp__1927000414__auto____10 any; var tmp11 *lang.Var; A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_17; temp__1927000414__auto____10 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_197000024__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_197000024__11 any = temp__1927000414__auto____10; var tmp12 *lang.Var; A_arbace_test_junit_A_Init(); tmp12 = A_arbace_test_junit_A_const_18; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_197000024__11)) { var c__1927000678__auto____12 any; var tmp13 *lang.Var; A_arbace_test_junit_A_Init(); tmp13 = A_arbace_test_junit_A_const_19; c__1927000678__auto____12 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_197000024__11); var tmp14 *lang.Var; A_arbace_test_junit_A_Init(); tmp14 = A_arbace_test_junit_A_const_24; seq_197000024__6, chunk_197000025__7, count_197000026__8, i_197000027__9 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_197000024__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__197000031__12 any; var tmp15 *lang.Var; A_arbace_test_junit_A_Init(); tmp15 = A_arbace_test_junit_A_const_20; vec__197000031__12 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_197000024__11); var key__13 any = lang.RT_Nth_O_I_O__O(vec__197000031__12, lang.RT_IntCast_J__I(0), nil); var value__14 any = lang.RT_Nth_O_I_O__O(vec__197000031__12, lang.RT_IntCast_J__I(1), nil); var tmp16 *lang.Var
					A_arbace_test_junit_A_Init(); tmp16 = A_arbace_test_junit_A_const_15; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_110, nil, Lit_124, nil, Lit_125); var tmp19 *lang.Var; A_arbace_test_junit_A_Init(); tmp19 = A_arbace_test_junit_A_const_22; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(key__13); var tmp21 *lang.Var; A_arbace_test_junit_A_Init(); tmp21 = A_arbace_test_junit_A_const_23; tmp17.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, tmp20, nil, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(value__14), nil)).Ref())
//line :60:1
					var tmp22 *lang.Var; A_arbace_test_junit_A_Init(); tmp22 = A_arbace_test_junit_A_const_25; seq_197000024__6, chunk_197000025__7, count_197000026__8, i_197000027__9 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_197000024__11), nil, 0, 0; continue L1 } } }
//line :59:1
			break L1 } }; var tmp23 /*line :62:1*/*lang.Var; A_arbace_test_junit_A_Init(); tmp23 = A_arbace_test_junit_A_const_15; lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(Lit_104); if
	jrt.A2g_Truth(pretty__1) { var tmp24 *lang.Var; A_arbace_test_junit_A_Init(); tmp24 = A_arbace_test_junit_A_const_21; lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke__O() }; var tmp25 /*line :55:1*/*lang.Var; A_arbace_test_junit_A_Init(); tmp25 = A_arbace_test_junit_A_const_14; var tmp26 *lang.Var = tmp25; var tmp27 *lang.Var; A_arbace_test_junit_A_Init(); tmp27 = A_arbace_test_junit_A_const_14; return jrt.NN(tmp26).Set_O__O(lang.Numbers_Inc_O__Number(jrt.NN(tmp27).Get__O())) }










func A_arbace_test_junit_element_content_A_New() *A_arbace_test_junit_element_content_A { A_arbace_test_junit_element_content_A_Init(); t := &A_arbace_test_junit_element_content_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_test_junit_element_content_A) Ctor() {}
//line :66:1
func (t *A_arbace_test_junit_element_content_A) Invoke_O_O__O(self, content__0 any) any {

	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_23; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(content__0))
}
func A_arbace_test_junit_finish_element_A_New() *A_arbace_test_junit_finish_element_A { A_arbace_test_junit_finish_element_A_Init(); t := &A_arbace_test_junit_finish_element_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_test_junit_finish_element_A) Ctor() {}
//line :70:1
func (t *A_arbace_test_junit_finish_element_A) Invoke_O_O_O__O(self, tag__0, pretty__1 any) any { var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_14; var tmp2 *lang.Var = tmp1; var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_14; jrt.NN(tmp2).Set_O__O(lang.Numbers_Dec_O__Number(jrt.NN(tmp3).Get__O())); if


	jrt.A2g_Truth(pretty__1) { var tmp4 *lang.Var; A_arbace_test_junit_A_Init(); tmp4 = A_arbace_test_junit_A_const_16; lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke__O() }; var tmp5 /*line :74:1*/*lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_15; lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_103, nil, Lit_104), jrt.RefArrayOf(jrt.Object_class, nil, tag__0, nil)).Ref()); if
	jrt.A2g_Truth(pretty__1) { var tmp6 *lang.Var; A_arbace_test_junit_A_Init(); tmp6 = A_arbace_test_junit_A_const_21; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O() } else { return nil } }

func A_arbace_test_junit_test_name_A_New() *A_arbace_test_junit_test_name_A { A_arbace_test_junit_test_name_A_Init(); t := &A_arbace_test_junit_test_name_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_test_junit_test_name_A) Ctor() {}
//line :77:1
func (t *A_arbace_test_junit_test_name_A) Invoke_O_O__O(self, vars__0 any) any {

	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_11; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_26; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_27; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_12; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_test_junit_test_name_fn__197000038_A_New(); var tmp12 *jrt.Class; A_arbace_test_junit_test_name_fn__197000038_A_Init(); tmp12 = A_arbace_test_junit_test_name_fn__197000038_A_fn_class; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(Lit_119, tmp8.Invoke_O__O(tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), vars__0)))) }
func A_arbace_test_junit_test_name_fn__197000038_A_New() *A_arbace_test_junit_test_name_fn__197000038_A { A_arbace_test_junit_test_name_fn__197000038_A_Init(); t := &A_arbace_test_junit_test_name_fn__197000038_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_test_junit_test_name_fn__197000038_A) Ctor() {}
//line :80:1
func (t *A_arbace_test_junit_test_name_fn__197000038_A) Invoke_O_O__O(self, p1__197000037_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_28; var tmp2 *lang.Keyword = tmp1; return jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__197000037_SHARP___1)) }

func A_arbace_test_junit_package_class_A_New() *A_arbace_test_junit_package_class_A { A_arbace_test_junit_package_class_A_Init(); t := &A_arbace_test_junit_package_class_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_test_junit_package_class_A) Ctor() {}
//line :82:1
func (t *A_arbace_test_junit_package_class_A) Invoke_O_O__O(self, name__0 any) any { var i__2 any = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(name__0, Lit_118, jrt.RefArrayOf(jrt.Object_class, Lit_119)); if


	lang.Numbers_Lt_O_J__Z(i__2, 0) { return lang.Tuple_Create_O_O__IPersistentVector(nil, name__0) } else { var tmp1 any; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_29; return lang.Tuple_Create_O_O__IPersistentVector(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(name__0, Lit_120, jrt.RefArrayOf(jrt.Object_class, tmp1, i__2)), lang.Reflector_InvokeInstanceMethod_O_String_O1__O(name__0, Lit_120, jrt.RefArrayOf(jrt.Object_class, lang.Numbers_Add_O_J__Number(i__2, 1)))) } }



func A_arbace_test_junit_start_case_A_New() *A_arbace_test_junit_start_case_A { A_arbace_test_junit_start_case_A_Init(); t := &A_arbace_test_junit_start_case_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_test_junit_start_case_A) Ctor() {}
//line :89:1
func (t *A_arbace_test_junit_start_case_A) Invoke_O_O_O__O(self, name__0, classname__1 any) any {

	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_30; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_31; var tmp4 any = tmp3; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_28; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_32; return tmp2.Invoke_O_O_O__O(tmp4, tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, name__0, tmp9.Ref(), classname__1)))
}
func A_arbace_test_junit_finish_case_A_New() *A_arbace_test_junit_finish_case_A { A_arbace_test_junit_finish_case_A_Init(); t := &A_arbace_test_junit_finish_case_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_test_junit_finish_case_A) Ctor() {}
//line :93:1
func (t *A_arbace_test_junit_finish_case_A) Invoke_O__O(self any) any {

	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_33; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_34; var tmp4 any = tmp3; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp2.Invoke_O_O__O(tmp4, tmp5.Ref())
}
func A_arbace_test_junit_suite_attrs_A_New() *A_arbace_test_junit_suite_attrs_A { A_arbace_test_junit_suite_attrs_A_Init(); t := &A_arbace_test_junit_suite_attrs_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_test_junit_suite_attrs_A) Ctor() {}
//line :97:1
func (t *A_arbace_test_junit_suite_attrs_A) Invoke_O_O_O__O(self, package__0, classname__1 any) any { var attrs__3 any; var tmp1 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_28; attrs__3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1.Ref(), classname__1)); if


	jrt.A2g_Truth(package__0) {
		var tmp2 *lang.Var; A_arbace_test_junit_A_Init(); tmp2 = A_arbace_test_junit_A_const_35; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp4 = A_arbace_test_junit_A_const_36; return tmp3.Invoke_O_O_O__O(attrs__3, tmp4.Ref(), package__0) } else {
//line :100:1
			return attrs__3 } }



func A_arbace_test_junit_start_suite_A_New() *A_arbace_test_junit_start_suite_A { A_arbace_test_junit_start_suite_A_Init(); t := &A_arbace_test_junit_start_suite_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_test_junit_start_suite_A) Ctor() {}
//line :104:1
func (t *A_arbace_test_junit_start_suite_A) Invoke_O_O__O(self, name__0 any) any { var vec__197000045__2 any; var tmp1 *lang.Var;

	A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_37; vec__197000045__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(name__0); var package__3 any = /*line :104:1*/lang.RT_Nth_O_I_O__O(vec__197000045__2, lang.RT_IntCast_J__I(0), nil); var classname__4 any = lang.RT_Nth_O_I_O__O(vec__197000045__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var;


	A_arbace_test_junit_A_Init(); tmp2 = A_arbace_test_junit_A_const_30; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_test_junit_A_Init(); tmp4 = A_arbace_test_junit_A_const_38; var tmp5 any = tmp4; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_test_junit_A_Init(); tmp8 = A_arbace_test_junit_A_const_39; return tmp3.Invoke_O_O_O__O(tmp5, tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(package__3, classname__4)) }

func A_arbace_test_junit_finish_suite_A_New() *A_arbace_test_junit_finish_suite_A { A_arbace_test_junit_finish_suite_A_Init(); t := &A_arbace_test_junit_finish_suite_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_test_junit_finish_suite_A) Ctor() {}
//line :109:1
func (t *A_arbace_test_junit_finish_suite_A) Invoke_O__O(self any) any {

	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_33; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_40; var tmp4 any = tmp3; var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; return tmp2.Invoke_O_O__O(tmp4, tmp5.Ref())
}
func A_arbace_test_junit_message_el_A_New() *A_arbace_test_junit_message_el_A { A_arbace_test_junit_message_el_A_Init(); t := &A_arbace_test_junit_message_el_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_test_junit_message_el_A) Ctor() {}
//line :113:1
func (t *A_arbace_test_junit_message_el_A) Invoke_O_O_O_O_O__O(self, tag__0, message__1, expected_str__2, actual_str__3 any) any {

	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_16; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O()
	var tmp2 *lang.Var; A_arbace_test_junit_A_Init(); tmp2 = A_arbace_test_junit_A_const_30; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; var tmp5 any = tmp4.Ref(); var tmp6 lang.IPersistentMap; if jrt.A2g_Truth(message__1) { var tmp7 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_42; tmp6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), message__1)) } else { lang.PersistentArrayMap_Init(); tmp6 = Up_PersistentArrayMap_IPersistentMap(lang.PersistentArrayMap_EMPTY) }; tmp3.Invoke_O_O_O__O(tag__0, tmp5, tmp6)
	var tmp8 *lang.Var; A_arbace_test_junit_A_Init(); tmp8 = A_arbace_test_junit_A_const_41; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; var vec__197000050__5 any; var tmp11 *lang.Var
	A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_43; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_test_junit_A_Init(); tmp13 = A_arbace_test_junit_A_const_44; vec__197000050__5 = tmp12.Invoke_O__O(tmp13)
//line :117:1
	var file__6 any = lang.RT_Nth_O_I_O__O(vec__197000050__5, lang.RT_IntCast_J__I(0), nil); var line__7 any = lang.RT_Nth_O_I_O__O(vec__197000050__5, lang.RT_IntCast_J__I(1), nil); var detail__8 any; var tmp14 *lang.Var

	A_arbace_test_junit_A_Init(); tmp14 = A_arbace_test_junit_A_const_10; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_test_junit_A_Init(); tmp16 = A_arbace_test_junit_A_const_11; var tmp17 any = jrt.NN(tmp16).GetRawRoot__O(); var tmp18 *lang.Var; A_arbace_test_junit_A_Init(); tmp18 = A_arbace_test_junit_A_const_26; detail__8 = tmp15.Invoke_O_O__O(tmp17, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(Lit_112, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, expected_str__2)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, nil, actual_str__3)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_115, nil, Lit_116, nil), jrt.RefArrayOf(jrt.Object_class, nil, file__6, nil, line__7)).Ref())))




	if jrt.A2g_Truth(message__1) { tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil), jrt.RefArrayOf(jrt.Object_class, message__1, nil, detail__8)).Ref() } else { tmp10 = detail__8 }
//line :117:1
	tmp9.Invoke_O__O(tmp10)







	var tmp19 *lang.Var; A_arbace_test_junit_A_Init(); tmp19 = A_arbace_test_junit_A_const_33; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *jrt.Boolean; jrt.Boolean_Init(); tmp21 = jrt.Boolean_FALSE; tmp20.Invoke_O_O__O(tag__0, tmp21.Ref())
	var tmp22 *lang.Var; A_arbace_test_junit_A_Init(); tmp22 = A_arbace_test_junit_A_const_21; return lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke__O()
}
func A_arbace_test_junit_failure_el_A_New() *A_arbace_test_junit_failure_el_A { A_arbace_test_junit_failure_el_A_Init(); t := &A_arbace_test_junit_failure_el_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_test_junit_failure_el_A) Ctor() {}
//line :128:1
func (t *A_arbace_test_junit_failure_el_A) Invoke_O_O_O_O__O(self, message__0, expected__1, actual__2 any) any {

	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_45; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_46; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_47; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(expected__1); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_47; return tmp2.Invoke_O_O_O_O__O(tmp4, message__0, tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(actual__2))
}
func A_arbace_test_junit_error_el_A_New() *A_arbace_test_junit_error_el_A { A_arbace_test_junit_error_el_A_Init(); t := &A_arbace_test_junit_error_el_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_test_junit_error_el_A) Ctor() {}
//line :132:1
func (t *A_arbace_test_junit_error_el_A) Invoke_O_O_O_O__O(self, message__0, expected__1, actual__2 any) any {

	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_45; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_48; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_47; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(expected__1); var tmp7 any


	if jrt.Throwable_InstanceOf(actual__2) { var s__1927001093__auto____4 any = jrt.StringWriter_New(); var tmp8 *lang.Var
		A_arbace_test_junit_A_Init(); tmp8 = A_arbace_test_junit_A_const_53; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_test_junit_A_Init(); tmp10 = A_arbace_test_junit_A_const_54; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_test_junit_A_Init(); tmp12 = A_arbace_test_junit_A_const_55; tmp9.Invoke_O__O(tmp11.Invoke_O_O__O(tmp12.Ref(), s__1927001093__auto____4)); var tmp13 any = A_arbace_test_junit_error_el_fn__197000055_A_New_O_O(s__1927001093__auto____4, actual__2); var tmp14 *jrt.Class; A_arbace_test_junit_error_el_fn__197000055_A_Init(); tmp14 = A_arbace_test_junit_error_el_fn__197000055_A_fn_class; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O() } else {
			var tmp15 *lang.Var; A_arbace_test_junit_A_Init(); tmp15 = A_arbace_test_junit_A_const_52; tmp7 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(actual__2) }
//line :134:1
	return tmp2.Invoke_O_O_O_O__O(tmp4, message__0, tmp6, tmp7)
}


func A_arbace_test_junit_error_el_fn__197000055_A_New_O_O(p0, p1 any) *A_arbace_test_junit_error_el_fn__197000055_A { A_arbace_test_junit_error_el_fn__197000055_A_Init(); t := &A_arbace_test_junit_error_el_fn__197000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_test_junit_error_el_fn__197000055_A) Ctor_O_O(c__s__1927001093__auto__, c__actual any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_actual = c__actual }
//line :138:1
func (t *A_arbace_test_junit_error_el_fn__197000055_A) Invoke_O__O(self any) any { var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_test_junit_A_Init(); tmp2 = A_arbace_test_junit_A_const_50; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_actual; t.F_actual = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 *lang.Var; A_arbace_test_junit_A_Init(); tmp6 = A_arbace_test_junit_A_const_51; tmp3.Invoke_O_O__O(tmp5, jrt.NN(tmp6).Get__O()); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_11; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; tmp9 = t__2; tmp1 = tmp8.Invoke_O__O(tmp9) }; return nil }(); var tmp11 *lang.Var; A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_49; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O(); if tmp10 != nil { panic(tmp10) }; return tmp1 }





func A_arbace_test_junit_eval197000060_fn__197000061_A_New() *A_arbace_test_junit_eval197000060_fn__197000061_A { A_arbace_test_junit_eval197000060_fn__197000061_A_Init(); t := &A_arbace_test_junit_eval197000060_fn__197000061_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) Ctor() {}
//line :144:1
func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_53; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_54; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_55; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_57; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :144:1
	var tmp8 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_56; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_22; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_test_junit_A_Init(); tmp13 = A_arbace_test_junit_A_const_58; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp15 = A_arbace_test_junit_A_const_59; tmp8 = tmp10.Invoke_O__O(tmp12.Invoke_O__O(tmp14.Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(m__1)))) }
//line :144:1
		return nil }(); var tmp17 *lang.Var
	A_arbace_test_junit_A_Init(); tmp17 = A_arbace_test_junit_A_const_49; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke__O()
//line :144:1
	if tmp16 != nil { panic(tmp16) }; return tmp8
}


func A_arbace_test_junit_eval197000064_fn__197000065_A_New() *A_arbace_test_junit_eval197000064_fn__197000065_A { A_arbace_test_junit_eval197000064_fn__197000065_A_Init(); t := &A_arbace_test_junit_eval197000064_fn__197000065_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) Ctor() {}
//line :148:1
func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) Invoke_O_O__O(self, ___1 any) any {
	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_53; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_54; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_55; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_57; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :148:1
	var tmp8 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_60; tmp8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke__O() }
//line :148:1
		return nil }(); var tmp11 *lang.Var
	A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_49; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O()
//line :148:1
	if tmp10 != nil { panic(tmp10) }; return tmp8
}


func A_arbace_test_junit_eval197000068_fn__197000069_A_New() *A_arbace_test_junit_eval197000068_fn__197000069_A { A_arbace_test_junit_eval197000068_fn__197000069_A_Init(); t := &A_arbace_test_junit_eval197000068_fn__197000069_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) Ctor() {}
//line :152:1
func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_53; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_54; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_55; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_57; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :152:1
	var tmp8 any; tmp33 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var var__4 any; var tmp9 *lang.Keyword

		A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_61; var__4 = jrt.NN(tmp9).Invoke_O__O(m__1)
		var tmp10 *lang.Var; A_arbace_test_junit_A_Init(); tmp10 = A_arbace_test_junit_A_const_53; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_test_junit_A_Init(); tmp12 = A_arbace_test_junit_A_const_54; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_test_junit_A_Init(); tmp14 = A_arbace_test_junit_A_const_63; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Var; A_arbace_test_junit_A_Init(); tmp16 = A_arbace_test_junit_A_const_7; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_test_junit_A_Init(); tmp18 = A_arbace_test_junit_A_const_63; tmp11.Invoke_O__O(tmp13.Invoke_O_O__O(tmp15, tmp17.Invoke_O_O__O(jrt.NN(tmp18).Get__O(), var__4))); tmp31 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
			{ var tmp19 *lang.Var; A_arbace_test_junit_A_Init(); tmp19 = A_arbace_test_junit_A_const_62; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_test_junit_A_Init(); tmp21 = A_arbace_test_junit_A_const_64; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_test_junit_A_Init(); tmp23 = A_arbace_test_junit_A_const_63; var tmp24 any = tmp22.Invoke_O__O(jrt.NN(tmp23).Get__O()); var tmp25 *lang.Var; A_arbace_test_junit_A_Init(); tmp25 = A_arbace_test_junit_A_const_22; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_test_junit_A_Init(); tmp27 = A_arbace_test_junit_A_const_58; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp29 = A_arbace_test_junit_A_const_59; var tmp30 *lang.Keyword = tmp29; tmp8 = tmp20.Invoke_O_O__O(tmp24, tmp26.Invoke_O__O(tmp28.Invoke_O__O(jrt.NN(tmp30).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(var__4))))) }
//line :155:1
			return nil }(); var tmp32 *lang.Var; A_arbace_test_junit_A_Init(); tmp32 = A_arbace_test_junit_A_const_49; lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke__O()
//line :152:1
		if tmp31 != nil { panic(tmp31) } }; return nil }(); var tmp34 *lang.Var
	A_arbace_test_junit_A_Init(); tmp34 = A_arbace_test_junit_A_const_49; lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke__O()
//line :152:1
	if tmp33 != nil { panic(tmp33) }; return tmp8
}




func A_arbace_test_junit_eval197000072_fn__197000073_A_New() *A_arbace_test_junit_eval197000072_fn__197000073_A { A_arbace_test_junit_eval197000072_fn__197000073_A_Init(); t := &A_arbace_test_junit_eval197000072_fn__197000073_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) Ctor() {}
//line :158:1
func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_53; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_54; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_55; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_57; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :158:1
	var tmp8 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_65; tmp8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke__O() }
//line :158:1
		return nil }(); var tmp11 *lang.Var
	A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_49; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke__O()
//line :158:1
	if tmp10 != nil { panic(tmp10) }; return tmp8
}


func A_arbace_test_junit_eval197000076_fn__197000077_A_New() *A_arbace_test_junit_eval197000076_fn__197000077_A { A_arbace_test_junit_eval197000076_fn__197000077_A_Init(); t := &A_arbace_test_junit_eval197000076_fn__197000077_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) Ctor() {}
//line :162:1
func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_53; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_54; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_55; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_57; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :162:1
	var tmp8 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_66; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_67; tmp8 = tmp10.Invoke_O__O(tmp11.Ref()) }
//line :162:1
		return nil }(); var tmp13 *lang.Var
	A_arbace_test_junit_A_Init(); tmp13 = A_arbace_test_junit_A_const_49; lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke__O()
//line :162:1
	if tmp12 != nil { panic(tmp12) }; return tmp8
}


func A_arbace_test_junit_eval197000080_fn__197000081_A_New() *A_arbace_test_junit_eval197000080_fn__197000081_A { A_arbace_test_junit_eval197000080_fn__197000081_A_Init(); t := &A_arbace_test_junit_eval197000080_fn__197000081_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) Ctor() {}
//line :166:1
func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_53; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_54; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_55; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_57; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :166:1
	var tmp8 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_66; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_69; tmp10.Invoke_O__O(tmp11.Ref())
			var tmp12 *lang.Var; A_arbace_test_junit_A_Init(); tmp12 = A_arbace_test_junit_A_const_68; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp14 = A_arbace_test_junit_A_const_42; var tmp15 any = jrt.NN(tmp14).Invoke_O__O(m__1); var tmp16 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp16 = A_arbace_test_junit_A_const_70; var tmp17 any = jrt.NN(tmp16).Invoke_O__O(m__1); var tmp18 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp18 = A_arbace_test_junit_A_const_71; tmp8 = tmp13.Invoke_O_O_O__O(tmp15, tmp17, jrt.NN(tmp18).Invoke_O__O(m__1)) }
//line :166:1
		return nil }(); var tmp20 *lang.Var
	A_arbace_test_junit_A_Init(); tmp20 = A_arbace_test_junit_A_const_49; lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke__O()
//line :166:1
	if tmp19 != nil { panic(tmp19) }; return tmp8
}





func A_arbace_test_junit_eval197000084_fn__197000085_A_New() *A_arbace_test_junit_eval197000084_fn__197000085_A { A_arbace_test_junit_eval197000084_fn__197000085_A_Init(); t := &A_arbace_test_junit_eval197000084_fn__197000085_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) Ctor() {}
//line :173:1
func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_53; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_54; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_55; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_57; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, jrt.NN(tmp7).Get__O()))
//line :173:1
	var tmp8 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp9 *lang.Var; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_66; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_73; tmp10.Invoke_O__O(tmp11.Ref())
			var tmp12 *lang.Var; A_arbace_test_junit_A_Init(); tmp12 = A_arbace_test_junit_A_const_72; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp14 = A_arbace_test_junit_A_const_42; var tmp15 any = jrt.NN(tmp14).Invoke_O__O(m__1); var tmp16 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp16 = A_arbace_test_junit_A_const_70; var tmp17 any = jrt.NN(tmp16).Invoke_O__O(m__1); var tmp18 *lang.Keyword; A_arbace_test_junit_A_Init(); tmp18 = A_arbace_test_junit_A_const_71; tmp8 = tmp13.Invoke_O_O_O__O(tmp15, tmp17, jrt.NN(tmp18).Invoke_O__O(m__1)) }
//line :173:1
		return nil }(); var tmp20 *lang.Var
	A_arbace_test_junit_A_Init(); tmp20 = A_arbace_test_junit_A_const_49; lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke__O()
//line :173:1
	if tmp19 != nil { panic(tmp19) }; return tmp8
}





func A_arbace_test_junit_eval197000088_fn__197000089_A_New() *A_arbace_test_junit_eval197000088_fn__197000089_A { A_arbace_test_junit_eval197000088_fn__197000089_A_Init(); t := &A_arbace_test_junit_eval197000088_fn__197000089_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) Ctor() {}
//line :180:1
func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_test_junit_with_junit_output_A_New() *A_arbace_test_junit_with_junit_output_A { A_arbace_test_junit_with_junit_output_A_Init(); t := &A_arbace_test_junit_with_junit_output_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_test_junit_with_junit_output_A) Ctor() {}
//line :182:1
func (t *A_arbace_test_junit_with_junit_output_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var tmp1 *lang.Var; A_arbace_test_junit_A_Init(); tmp1 = A_arbace_test_junit_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_test_junit_A_Init(); tmp3 = A_arbace_test_junit_A_const_74; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_test_junit_A_Init(); tmp5 = A_arbace_test_junit_A_const_75; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_test_junit_A_Init(); tmp7 = A_arbace_test_junit_A_const_76; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_test_junit_A_Init(); tmp9 = A_arbace_test_junit_A_const_75; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_test_junit_A_Init(); tmp11 = A_arbace_test_junit_A_const_10; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_test_junit_A_Init(); tmp13 = A_arbace_test_junit_A_const_77; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_test_junit_A_Init(); tmp15 = A_arbace_test_junit_A_const_17; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_test_junit_A_Init(); tmp17 = A_arbace_test_junit_A_const_74; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_test_junit_A_Init(); tmp19 = A_arbace_test_junit_A_const_75; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_test_junit_A_Init(); tmp21 = A_arbace_test_junit_A_const_78; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_test_junit_A_Init(); tmp23 = A_arbace_test_junit_A_const_75; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; A_arbace_test_junit_A_Init(); tmp25 = A_arbace_test_junit_A_const_79; var tmp26 any = tmp24.Invoke_O__O(tmp25); var tmp27 *lang.Var; A_arbace_test_junit_A_Init(); tmp27 = A_arbace_test_junit_A_const_75; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any; A_arbace_test_junit_A_Init(); tmp29 = A_arbace_test_junit_A_const_80; var tmp30 any = tmp28.Invoke_O__O(tmp29); var tmp31 *lang.Var; A_arbace_test_junit_A_Init(); tmp31 = A_arbace_test_junit_A_const_75; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Var; A_arbace_test_junit_A_Init(); tmp33 = A_arbace_test_junit_A_const_17; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_test_junit_A_Init(); tmp35 = A_arbace_test_junit_A_const_74; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_test_junit_A_Init(); tmp37 = A_arbace_test_junit_A_const_75; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any; A_arbace_test_junit_A_Init(); tmp39 = A_arbace_test_junit_A_const_81; var tmp40 any = tmp32.Invoke_O__O(tmp34.Invoke_O__O(tmp36.Invoke_O__O(tmp38.Invoke_O__O(tmp39)))); var tmp41 *lang.Var; A_arbace_test_junit_A_Init(); tmp41 = A_arbace_test_junit_A_const_75; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 any; A_arbace_test_junit_A_Init(); tmp43 = A_arbace_test_junit_A_const_82; var tmp44 any = tmp42.Invoke_O__O(tmp43); var tmp45 *lang.Var; A_arbace_test_junit_A_Init(); tmp45 = A_arbace_test_junit_A_const_75; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any; A_arbace_test_junit_A_Init(); tmp47 = A_arbace_test_junit_A_const_83; var tmp48 any = tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O_O_O_O_O__O(tmp22, tmp26, tmp30, tmp40, tmp44, tmp46.Invoke_O__O(tmp47))))); var tmp49 *lang.Var; A_arbace_test_junit_A_Init(); tmp49 = A_arbace_test_junit_A_const_75; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_test_junit_A_Init(); tmp51 = A_arbace_test_junit_A_const_17; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Var; A_arbace_test_junit_A_Init(); tmp53 = A_arbace_test_junit_A_const_74; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 *lang.Var; A_arbace_test_junit_A_Init(); tmp55 = A_arbace_test_junit_A_const_75; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 any; A_arbace_test_junit_A_Init(); tmp57 = A_arbace_test_junit_A_const_84; var tmp58 any = tmp56.Invoke_O__O(tmp57); var tmp59 *lang.Var; A_arbace_test_junit_A_Init(); tmp59 = A_arbace_test_junit_A_const_75; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Var; A_arbace_test_junit_A_Init(); tmp61 = A_arbace_test_junit_A_const_17; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 *lang.Var; A_arbace_test_junit_A_Init(); tmp63 = A_arbace_test_junit_A_const_74; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 *lang.Var; A_arbace_test_junit_A_Init(); tmp65 = A_arbace_test_junit_A_const_75; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 any; A_arbace_test_junit_A_Init(); tmp67 = A_arbace_test_junit_A_const_85; var tmp68 any = tmp66.Invoke_O__O(tmp67); var tmp69 *lang.Var; A_arbace_test_junit_A_Init(); tmp69 = A_arbace_test_junit_A_const_75; var tmp70 any = tmp60.Invoke_O__O(tmp62.Invoke_O__O(tmp64.Invoke_O_O__O(tmp68, lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(Lit_131)))); var tmp71 *lang.Var; A_arbace_test_junit_A_Init(); tmp71 = A_arbace_test_junit_A_const_75; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_test_junit_A_Init(); tmp73 = A_arbace_test_junit_A_const_17; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.Var; A_arbace_test_junit_A_Init(); tmp75 = A_arbace_test_junit_A_const_74; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Var; A_arbace_test_junit_A_Init(); tmp77 = A_arbace_test_junit_A_const_75; var tmp78 lang.IFn = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()); var tmp79 any; A_arbace_test_junit_A_Init(); tmp79 = A_arbace_test_junit_A_const_86; var tmp80 any = tmp78.Invoke_O__O(tmp79); var tmp81 *lang.Var; A_arbace_test_junit_A_Init(); tmp81 = A_arbace_test_junit_A_const_75; var tmp82 any = tmp50.Invoke_O__O(tmp52.Invoke_O__O(tmp54.Invoke_O_O_O__O(tmp58, tmp70, tmp72.Invoke_O__O(tmp74.Invoke_O__O(tmp76.Invoke_O_O__O(tmp80, lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke_O__O(Lit_132))))))); var tmp83 *lang.Var; A_arbace_test_junit_A_Init(); tmp83 = A_arbace_test_junit_A_const_75; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 *lang.Var; A_arbace_test_junit_A_Init(); tmp85 = A_arbace_test_junit_A_const_17; var tmp86 lang.IFn = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()); var tmp87 *lang.Var; A_arbace_test_junit_A_Init(); tmp87 = A_arbace_test_junit_A_const_74; var tmp88 lang.IFn = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()); var tmp89 *lang.Var; A_arbace_test_junit_A_Init(); tmp89 = A_arbace_test_junit_A_const_75; var tmp90 lang.IFn = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()); var tmp91 any; A_arbace_test_junit_A_Init(); tmp91 = A_arbace_test_junit_A_const_87; var tmp92 any = tmp90.Invoke_O__O(tmp91); var tmp93 *lang.Var; A_arbace_test_junit_A_Init(); tmp93 = A_arbace_test_junit_A_const_75; var tmp94 lang.IFn = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()); var tmp95 *lang.Var; A_arbace_test_junit_A_Init(); tmp95 = A_arbace_test_junit_A_const_10; var tmp96 lang.IFn = lang.IFn_Cast(jrt.NN(tmp95).GetRawRoot__O()); var tmp97 *lang.Var; A_arbace_test_junit_A_Init(); tmp97 = A_arbace_test_junit_A_const_77; var tmp98 any = jrt.NN(tmp97).GetRawRoot__O(); var tmp99 *lang.Var; A_arbace_test_junit_A_Init(); tmp99 = A_arbace_test_junit_A_const_17; var tmp100 lang.IFn = lang.IFn_Cast(jrt.NN(tmp99).GetRawRoot__O()); var tmp101 *lang.Var; A_arbace_test_junit_A_Init(); tmp101 = A_arbace_test_junit_A_const_74; var tmp102 lang.IFn = lang.IFn_Cast(jrt.NN(tmp101).GetRawRoot__O()); var tmp103 *lang.Var; A_arbace_test_junit_A_Init(); tmp103 = A_arbace_test_junit_A_const_75; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 any; A_arbace_test_junit_A_Init(); tmp105 = A_arbace_test_junit_A_const_88; var tmp106 any = tmp104.Invoke_O__O(tmp105); var tmp107 *lang.Var; A_arbace_test_junit_A_Init(); tmp107 = A_arbace_test_junit_A_const_75; var tmp108 lang.IFn = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()); var tmp109 *lang.Var; A_arbace_test_junit_A_Init(); tmp109 = A_arbace_test_junit_A_const_17; var tmp110 lang.IFn = lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()); var tmp111 *lang.Var; A_arbace_test_junit_A_Init(); tmp111 = A_arbace_test_junit_A_const_74; var tmp112 lang.IFn = lang.IFn_Cast(jrt.NN(tmp111).GetRawRoot__O()); var tmp113 *lang.Var; A_arbace_test_junit_A_Init(); tmp113 = A_arbace_test_junit_A_const_75; var tmp114 lang.IFn = lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()); var tmp115 any; A_arbace_test_junit_A_Init(); tmp115 = A_arbace_test_junit_A_const_89; var tmp116 any = tmp94.Invoke_O__O(tmp96.Invoke_O_O__O(tmp98, tmp100.Invoke_O__O(tmp102.Invoke_O_O__O(tmp106, tmp108.Invoke_O__O(tmp110.Invoke_O__O(tmp112.Invoke_O_O__O(tmp114.Invoke_O__O(tmp115), body__2))))))); var tmp117 *lang.Var; A_arbace_test_junit_A_Init(); tmp117 = A_arbace_test_junit_A_const_75; var tmp118 lang.IFn = lang.IFn_Cast(jrt.NN(tmp117).GetRawRoot__O()); var tmp119 *lang.Var; A_arbace_test_junit_A_Init(); tmp119 = A_arbace_test_junit_A_const_17; var tmp120 lang.IFn = lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()); var tmp121 *lang.Var; A_arbace_test_junit_A_Init(); tmp121 = A_arbace_test_junit_A_const_74; var tmp122 lang.IFn = lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()); var tmp123 *lang.Var; A_arbace_test_junit_A_Init(); tmp123 = A_arbace_test_junit_A_const_75; var tmp124 lang.IFn = lang.IFn_Cast(jrt.NN(tmp123).GetRawRoot__O()); var tmp125 any; A_arbace_test_junit_A_Init(); tmp125 = A_arbace_test_junit_A_const_90; var tmp126 any = tmp124.Invoke_O__O(tmp125); var tmp127 *lang.Var; A_arbace_test_junit_A_Init(); tmp127 = A_arbace_test_junit_A_const_75; var tmp128 lang.IFn = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()); var tmp129 *lang.Var; A_arbace_test_junit_A_Init(); tmp129 = A_arbace_test_junit_A_const_17; var tmp130 lang.IFn = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()); var tmp131 *lang.Var; A_arbace_test_junit_A_Init(); tmp131 = A_arbace_test_junit_A_const_74; var tmp132 lang.IFn = lang.IFn_Cast(jrt.NN(tmp131).GetRawRoot__O()); var tmp133 *lang.Var; A_arbace_test_junit_A_Init(); tmp133 = A_arbace_test_junit_A_const_75; var tmp134 lang.IFn = lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()); var tmp135 any; A_arbace_test_junit_A_Init(); tmp135 = A_arbace_test_junit_A_const_91; var tmp136 any = tmp134.Invoke_O__O(tmp135); var tmp137 *lang.Var; A_arbace_test_junit_A_Init(); tmp137 = A_arbace_test_junit_A_const_75; var tmp138 any = tmp118.Invoke_O__O(tmp120.Invoke_O__O(tmp122.Invoke_O_O__O(tmp126, tmp128.Invoke_O__O(tmp130.Invoke_O__O(tmp132.Invoke_O_O__O(tmp136, lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()).Invoke_O__O(Lit_133))))))); var tmp139 *lang.Var; A_arbace_test_junit_A_Init(); tmp139 = A_arbace_test_junit_A_const_75; var tmp140 lang.IFn = lang.IFn_Cast(jrt.NN(tmp139).GetRawRoot__O()); var tmp141 any; A_arbace_test_junit_A_Init(); tmp141 = A_arbace_test_junit_A_const_88; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O__O(tmp8, tmp48, tmp82, tmp84.Invoke_O__O(tmp86.Invoke_O__O(tmp88.Invoke_O_O_O_O__O(tmp92, tmp116, tmp138, tmp140.Invoke_O__O(tmp141)))))) }































type A_arbace_test_junit_A struct{ jrt.Object }

var A_arbace_test_junit_A_const_0 *lang.Var

var A_arbace_test_junit_A_const_1 *lang.Var

var A_arbace_test_junit_A_const_2 any

var A_arbace_test_junit_A_const_3 any

var A_arbace_test_junit_A_const_4 any

var A_arbace_test_junit_A_const_5 *lang.Var

var A_arbace_test_junit_A_const_6 *lang.Var

var A_arbace_test_junit_A_const_7 *lang.Var

var A_arbace_test_junit_A_const_8 any

var A_arbace_test_junit_A_const_9 *lang.Var

var A_arbace_test_junit_A_const_10 *lang.Var

var A_arbace_test_junit_A_const_11 *lang.Var

var A_arbace_test_junit_A_const_12 *lang.Var

var A_arbace_test_junit_A_const_13 *lang.Var

var A_arbace_test_junit_A_const_14 *lang.Var

var A_arbace_test_junit_A_const_15 *lang.Var

var A_arbace_test_junit_A_const_16 *lang.Var

var A_arbace_test_junit_A_const_17 *lang.Var

var A_arbace_test_junit_A_const_18 *lang.Var

var A_arbace_test_junit_A_const_19 *lang.Var

var A_arbace_test_junit_A_const_20 *lang.Var

var A_arbace_test_junit_A_const_21 *lang.Var

var A_arbace_test_junit_A_const_22 *lang.Var

var A_arbace_test_junit_A_const_23 *lang.Var

var A_arbace_test_junit_A_const_24 *lang.Var

var A_arbace_test_junit_A_const_25 *lang.Var

var A_arbace_test_junit_A_const_26 *lang.Var

var A_arbace_test_junit_A_const_27 *lang.Var

var A_arbace_test_junit_A_const_28 *lang.Keyword

var A_arbace_test_junit_A_const_29 any

var A_arbace_test_junit_A_const_30 *lang.Var

var A_arbace_test_junit_A_const_31 any

var A_arbace_test_junit_A_const_32 *lang.Keyword

var A_arbace_test_junit_A_const_33 *lang.Var

var A_arbace_test_junit_A_const_34 any

var A_arbace_test_junit_A_const_35 *lang.Var

var A_arbace_test_junit_A_const_36 *lang.Keyword

var A_arbace_test_junit_A_const_37 *lang.Var

var A_arbace_test_junit_A_const_38 any

var A_arbace_test_junit_A_const_39 *lang.Var

var A_arbace_test_junit_A_const_40 any

var A_arbace_test_junit_A_const_41 *lang.Var

var A_arbace_test_junit_A_const_42 *lang.Keyword

var A_arbace_test_junit_A_const_43 *lang.Var

var A_arbace_test_junit_A_const_44 any

var A_arbace_test_junit_A_const_45 *lang.Var

var A_arbace_test_junit_A_const_46 any

var A_arbace_test_junit_A_const_47 *lang.Var

var A_arbace_test_junit_A_const_48 any

var A_arbace_test_junit_A_const_49 *lang.Var

var A_arbace_test_junit_A_const_50 *lang.Var

var A_arbace_test_junit_A_const_51 *lang.Var

var A_arbace_test_junit_A_const_52 *lang.Var

var A_arbace_test_junit_A_const_53 *lang.Var

var A_arbace_test_junit_A_const_54 *lang.Var

var A_arbace_test_junit_A_const_55 *lang.Var

var A_arbace_test_junit_A_const_56 *lang.Var

var A_arbace_test_junit_A_const_57 *lang.Var

var A_arbace_test_junit_A_const_58 *lang.Var

var A_arbace_test_junit_A_const_59 *lang.Keyword

var A_arbace_test_junit_A_const_60 *lang.Var

var A_arbace_test_junit_A_const_61 *lang.Keyword

var A_arbace_test_junit_A_const_62 *lang.Var

var A_arbace_test_junit_A_const_63 *lang.Var

var A_arbace_test_junit_A_const_64 *lang.Var

var A_arbace_test_junit_A_const_65 *lang.Var

var A_arbace_test_junit_A_const_66 *lang.Var

var A_arbace_test_junit_A_const_67 *lang.Keyword

var A_arbace_test_junit_A_const_68 *lang.Var

var A_arbace_test_junit_A_const_69 *lang.Keyword

var A_arbace_test_junit_A_const_70 *lang.Keyword

var A_arbace_test_junit_A_const_71 *lang.Keyword

var A_arbace_test_junit_A_const_72 *lang.Var

var A_arbace_test_junit_A_const_73 *lang.Keyword

var A_arbace_test_junit_A_const_74 *lang.Var

var A_arbace_test_junit_A_const_75 *lang.Var

var A_arbace_test_junit_A_const_76 any

var A_arbace_test_junit_A_const_77 *lang.Var

var A_arbace_test_junit_A_const_78 any

var A_arbace_test_junit_A_const_79 any

var A_arbace_test_junit_A_const_80 any

var A_arbace_test_junit_A_const_81 any

var A_arbace_test_junit_A_const_82 any

var A_arbace_test_junit_A_const_83 any

var A_arbace_test_junit_A_const_84 any

var A_arbace_test_junit_A_const_85 any

var A_arbace_test_junit_A_const_86 any

var A_arbace_test_junit_A_const_87 any

var A_arbace_test_junit_A_const_88 any

var A_arbace_test_junit_A_const_89 any

var A_arbace_test_junit_A_const_90 any

var A_arbace_test_junit_A_const_91 any

var A_arbace_test_junit_A_init jrt.ClassInit

func A_arbace_test_junit_A_Init() { if !A_arbace_test_junit_A_init.Done() { A_arbace_test_junit_A_init.Run(A_arbace_test_junit_A_clinit) } }

func A_arbace_test_junit_A_clinit() { A_arbace_test_junit_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_test_junit_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_test_junit_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_test_junit_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_test_junit_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_test_junit_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_test_junit_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_test_junit_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_test_junit_A_const_8 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_test_junit_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_test_junit_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_test_junit_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_test_junit_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_test_junit_A_const_13 = lang.RT_Var_String_String__Var(Lit_11, Lit_20); A_arbace_test_junit_A_const_14 = lang.RT_Var_String_String__Var(Lit_11, Lit_21); A_arbace_test_junit_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_test_junit_A_const_16 = lang.RT_Var_String_String__Var(Lit_11, Lit_23); A_arbace_test_junit_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_test_junit_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_test_junit_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_test_junit_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_test_junit_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_test_junit_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_test_junit_A_const_23 = lang.RT_Var_String_String__Var(Lit_11, Lit_30); A_arbace_test_junit_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_test_junit_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_test_junit_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_test_junit_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_test_junit_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_test_junit_A_const_29 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_test_junit_A_const_30 = lang.RT_Var_String_String__Var(Lit_11, Lit_35); A_arbace_test_junit_A_const_31 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref(); A_arbace_test_junit_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_test_junit_A_const_33 = lang.RT_Var_String_String__Var(Lit_11, Lit_38); A_arbace_test_junit_A_const_34 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_36).Ref(); A_arbace_test_junit_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_test_junit_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_40); A_arbace_test_junit_A_const_37 = lang.RT_Var_String_String__Var(Lit_11, Lit_41); A_arbace_test_junit_A_const_38 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref(); A_arbace_test_junit_A_const_39 = lang.RT_Var_String_String__Var(Lit_11, Lit_43); A_arbace_test_junit_A_const_40 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_42).Ref(); A_arbace_test_junit_A_const_41 = lang.RT_Var_String_String__Var(Lit_11, Lit_44); A_arbace_test_junit_A_const_42 = lang.RT_Keyword_String_String__Keyword(nil, Lit_45); A_arbace_test_junit_A_const_43 = lang.RT_Var_String_String__Var(Lit_6, Lit_46); A_arbace_test_junit_A_const_44 = jrt.Long_ValueOf_J__Long(5).Ref(); A_arbace_test_junit_A_const_45 = lang.RT_Var_String_String__Var(Lit_11, Lit_47); A_arbace_test_junit_A_const_46 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_48).Ref(); A_arbace_test_junit_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_test_junit_A_const_48 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref(); A_arbace_test_junit_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_test_junit_A_const_50 = lang.RT_Var_String_String__Var(Lit_3, Lit_52); A_arbace_test_junit_A_const_51 = lang.RT_Var_String_String__Var(Lit_6, Lit_53); A_arbace_test_junit_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_test_junit_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_test_junit_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_test_junit_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_test_junit_A_const_56 = lang.RT_Var_String_String__Var(Lit_11, Lit_58); A_arbace_test_junit_A_const_57 = lang.RT_Var_String_String__Var(Lit_6, Lit_59); A_arbace_test_junit_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_test_junit_A_const_59 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_test_junit_A_const_60 = lang.RT_Var_String_String__Var(Lit_11, Lit_62); A_arbace_test_junit_A_const_61 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_test_junit_A_const_62 = lang.RT_Var_String_String__Var(Lit_11, Lit_64); A_arbace_test_junit_A_const_63 = lang.RT_Var_String_String__Var(Lit_11, Lit_65); A_arbace_test_junit_A_const_64 = lang.RT_Var_String_String__Var(Lit_11, Lit_66); A_arbace_test_junit_A_const_65 = lang.RT_Var_String_String__Var(Lit_11, Lit_67); A_arbace_test_junit_A_const_66 = lang.RT_Var_String_String__Var(Lit_6, Lit_68); A_arbace_test_junit_A_const_67 = lang.RT_Keyword_String_String__Keyword(nil, Lit_69); A_arbace_test_junit_A_const_68 = lang.RT_Var_String_String__Var(Lit_11, Lit_70); A_arbace_test_junit_A_const_69 = lang.RT_Keyword_String_String__Keyword(nil, Lit_71); A_arbace_test_junit_A_const_70 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_test_junit_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_73); A_arbace_test_junit_A_const_72 = lang.RT_Var_String_String__Var(Lit_11, Lit_74); A_arbace_test_junit_A_const_73 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_test_junit_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_test_junit_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_test_junit_A_const_76 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_77).Ref(); A_arbace_test_junit_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_test_junit_A_const_78 = lang.Symbol_Intern_String_String__Symbol(Lit_6, Lit_79).Ref(); A_arbace_test_junit_A_const_79 = lang.Symbol_Intern_String_String__Symbol(Lit_11, Lit_80).Ref(); A_arbace_test_junit_A_const_80 = lang.Symbol_Intern_String_String__Symbol(Lit_11, Lit_65).Ref(); A_arbace_test_junit_A_const_81 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_76).Ref(); A_arbace_test_junit_A_const_82 = lang.Symbol_Intern_String_String__Symbol(Lit_11, Lit_21).Ref(); A_arbace_test_junit_A_const_83 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_test_junit_A_const_84 = lang.Symbol_Intern_String_String__Symbol(Lit_6, Lit_81).Ref(); A_arbace_test_junit_A_const_85 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_28).Ref(); A_arbace_test_junit_A_const_86 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_28).Ref(); A_arbace_test_junit_A_const_87 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_82).Ref(); A_arbace_test_junit_A_const_88 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(); A_arbace_test_junit_A_const_89 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(); A_arbace_test_junit_A_const_90 = lang.Symbol_Intern_String_String__Symbol(Lit_6, Lit_81).Ref(); A_arbace_test_junit_A_const_91 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_28).Ref() }

func A_arbace_test_junit_A_New() *A_arbace_test_junit_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_A) Ctor() {}

func (t *A_arbace_test_junit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_A_class }

func (t *A_arbace_test_junit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_A); return ok }

func A_arbace_test_junit_A_Cast(x any) *A_arbace_test_junit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_A_class)) }; return v }



type A_arbace_test_junit_element_content_A struct{ jrt.Object }

func (t *A_arbace_test_junit_element_content_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_element_content_A_fn_class *jrt.Class

var A_arbace_test_junit_element_content_A_init jrt.ClassInit

func A_arbace_test_junit_element_content_A_Init() { if !A_arbace_test_junit_element_content_A_init.Done() { A_arbace_test_junit_element_content_A_init.Run(A_arbace_test_junit_element_content_A_clinit) } }

func A_arbace_test_junit_element_content_A_clinit() { A_arbace_test_junit_element_content_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_element_content_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_element_content_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_element_content_A_class }

func (t *A_arbace_test_junit_element_content_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_element_content_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_element_content_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_element_content_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_element_content_A); return ok }

func A_arbace_test_junit_element_content_A_Cast(x any) *A_arbace_test_junit_element_content_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_element_content_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_element_content_A_class)) }; return v }



type A_arbace_test_junit_error_el_A struct{ jrt.Object }

func (t *A_arbace_test_junit_error_el_A) Is_Compiler_AOTF3() {}

var A_arbace_test_junit_error_el_A_fn_class *jrt.Class

var A_arbace_test_junit_error_el_A_init jrt.ClassInit

func A_arbace_test_junit_error_el_A_Init() { if !A_arbace_test_junit_error_el_A_init.Done() { A_arbace_test_junit_error_el_A_init.Run(A_arbace_test_junit_error_el_A_clinit) } }

func A_arbace_test_junit_error_el_A_clinit() { A_arbace_test_junit_error_el_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_error_el_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_error_el_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_error_el_A_class }

func (t *A_arbace_test_junit_error_el_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_error_el_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_error_el_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_error_el_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_error_el_A); return ok }

func A_arbace_test_junit_error_el_A_Cast(x any) *A_arbace_test_junit_error_el_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_error_el_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_error_el_A_class)) }; return v }



type A_arbace_test_junit_error_el_fn__197000055_A struct{ jrt.Object; F_s__1927001093__auto__, F_actual any }

func (t *A_arbace_test_junit_error_el_fn__197000055_A) Is_Compiler_AOTF0() {}

var A_arbace_test_junit_error_el_fn__197000055_A_fn_class *jrt.Class

var A_arbace_test_junit_error_el_fn__197000055_A_init jrt.ClassInit

func A_arbace_test_junit_error_el_fn__197000055_A_Init() { if !A_arbace_test_junit_error_el_fn__197000055_A_init.Done() { A_arbace_test_junit_error_el_fn__197000055_A_init.Run(A_arbace_test_junit_error_el_fn__197000055_A_clinit) } }

func A_arbace_test_junit_error_el_fn__197000055_A_clinit() { A_arbace_test_junit_error_el_fn__197000055_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_error_el_fn__197000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_error_el_fn__197000055_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_error_el_fn__197000055_A_class }

func (t *A_arbace_test_junit_error_el_fn__197000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_error_el_fn__197000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_error_el_fn__197000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_error_el_fn__197000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_error_el_fn__197000055_A); return ok }

func A_arbace_test_junit_error_el_fn__197000055_A_Cast(x any) *A_arbace_test_junit_error_el_fn__197000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_error_el_fn__197000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_error_el_fn__197000055_A_class)) }; return v }



type A_arbace_test_junit_escape_xml_A struct{ jrt.Object }

func (t *A_arbace_test_junit_escape_xml_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_escape_xml_A_fn_class *jrt.Class

var A_arbace_test_junit_escape_xml_A_init jrt.ClassInit

func A_arbace_test_junit_escape_xml_A_Init() { if !A_arbace_test_junit_escape_xml_A_init.Done() { A_arbace_test_junit_escape_xml_A_init.Run(A_arbace_test_junit_escape_xml_A_clinit) } }

func A_arbace_test_junit_escape_xml_A_clinit() { A_arbace_test_junit_escape_xml_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_escape_xml_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_escape_xml_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_escape_xml_A_class }

func (t *A_arbace_test_junit_escape_xml_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_escape_xml_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_escape_xml_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_escape_xml_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_escape_xml_A); return ok }

func A_arbace_test_junit_escape_xml_A_Cast(x any) *A_arbace_test_junit_escape_xml_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_escape_xml_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_escape_xml_A_class)) }; return v }



type A_arbace_test_junit_escape_xml_fn__197000016_A struct{ jrt.Object }

func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class *jrt.Class

var A_arbace_test_junit_escape_xml_fn__197000016_A_init jrt.ClassInit

func A_arbace_test_junit_escape_xml_fn__197000016_A_Init() { if !A_arbace_test_junit_escape_xml_fn__197000016_A_init.Done() { A_arbace_test_junit_escape_xml_fn__197000016_A_init.Run(A_arbace_test_junit_escape_xml_fn__197000016_A_clinit) } }

func A_arbace_test_junit_escape_xml_fn__197000016_A_clinit() { A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_escape_xml_fn__197000016_A_class }

func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_escape_xml_fn__197000016_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_escape_xml_fn__197000016_A); return ok }

func A_arbace_test_junit_escape_xml_fn__197000016_A_Cast(x any) *A_arbace_test_junit_escape_xml_fn__197000016_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_escape_xml_fn__197000016_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_escape_xml_fn__197000016_A_class)) }; return v }



type A_arbace_test_junit_eval197000004_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000004_A_New() *A_arbace_test_junit_eval197000004_A { t := &A_arbace_test_junit_eval197000004_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000004_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000004_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000004_A_class }

func (t *A_arbace_test_junit_eval197000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000004_A); return ok }

func A_arbace_test_junit_eval197000004_A_Cast(x any) *A_arbace_test_junit_eval197000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000004_A_class)) }; return v }



type A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) Is_Compiler_AOTF0() {}

var A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_Init() { if !A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_init.Done() { A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_init.Run(A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_clinit) } }

func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_clinit() { A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_90, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_class }

func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A); return ok }

func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_Cast(x any) *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_class)) }; return v }



type A_arbace_test_junit_eval197000008_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000008_A_New() *A_arbace_test_junit_eval197000008_A { t := &A_arbace_test_junit_eval197000008_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000008_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000008_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000008_A_class }

func (t *A_arbace_test_junit_eval197000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000008_A); return ok }

func A_arbace_test_junit_eval197000008_A_Cast(x any) *A_arbace_test_junit_eval197000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000008_A_class)) }; return v }



type A_arbace_test_junit_eval197000008_fn__197000009_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) Is_Compiler_AOTF0() {}

var A_arbace_test_junit_eval197000008_fn__197000009_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000008_fn__197000009_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000008_fn__197000009_A_Init() { if !A_arbace_test_junit_eval197000008_fn__197000009_A_init.Done() { A_arbace_test_junit_eval197000008_fn__197000009_A_init.Run(A_arbace_test_junit_eval197000008_fn__197000009_A_clinit) } }

func A_arbace_test_junit_eval197000008_fn__197000009_A_clinit() { A_arbace_test_junit_eval197000008_fn__197000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000008_fn__197000009_A_class }

func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000008_fn__197000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000008_fn__197000009_A); return ok }

func A_arbace_test_junit_eval197000008_fn__197000009_A_Cast(x any) *A_arbace_test_junit_eval197000008_fn__197000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000008_fn__197000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000008_fn__197000009_A_class)) }; return v }



type A_arbace_test_junit_eval197000060_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000060_A_New() *A_arbace_test_junit_eval197000060_A { t := &A_arbace_test_junit_eval197000060_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000060_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000060_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000060_A_class }

func (t *A_arbace_test_junit_eval197000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000060_A); return ok }

func A_arbace_test_junit_eval197000060_A_Cast(x any) *A_arbace_test_junit_eval197000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000060_A_class)) }; return v }



type A_arbace_test_junit_eval197000060_fn__197000061_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_eval197000060_fn__197000061_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000060_fn__197000061_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000060_fn__197000061_A_Init() { if !A_arbace_test_junit_eval197000060_fn__197000061_A_init.Done() { A_arbace_test_junit_eval197000060_fn__197000061_A_init.Run(A_arbace_test_junit_eval197000060_fn__197000061_A_clinit) } }

func A_arbace_test_junit_eval197000060_fn__197000061_A_clinit() { A_arbace_test_junit_eval197000060_fn__197000061_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_92, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000060_fn__197000061_A_class }

func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000060_fn__197000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000060_fn__197000061_A); return ok }

func A_arbace_test_junit_eval197000060_fn__197000061_A_Cast(x any) *A_arbace_test_junit_eval197000060_fn__197000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000060_fn__197000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000060_fn__197000061_A_class)) }; return v }



type A_arbace_test_junit_eval197000064_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000064_A_New() *A_arbace_test_junit_eval197000064_A { t := &A_arbace_test_junit_eval197000064_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000064_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000064_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000064_A_class }

func (t *A_arbace_test_junit_eval197000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000064_A); return ok }

func A_arbace_test_junit_eval197000064_A_Cast(x any) *A_arbace_test_junit_eval197000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000064_A_class)) }; return v }



type A_arbace_test_junit_eval197000064_fn__197000065_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_eval197000064_fn__197000065_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000064_fn__197000065_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000064_fn__197000065_A_Init() { if !A_arbace_test_junit_eval197000064_fn__197000065_A_init.Done() { A_arbace_test_junit_eval197000064_fn__197000065_A_init.Run(A_arbace_test_junit_eval197000064_fn__197000065_A_clinit) } }

func A_arbace_test_junit_eval197000064_fn__197000065_A_clinit() { A_arbace_test_junit_eval197000064_fn__197000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_93, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000064_fn__197000065_A_class }

func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000064_fn__197000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000064_fn__197000065_A); return ok }

func A_arbace_test_junit_eval197000064_fn__197000065_A_Cast(x any) *A_arbace_test_junit_eval197000064_fn__197000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000064_fn__197000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000064_fn__197000065_A_class)) }; return v }



type A_arbace_test_junit_eval197000068_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000068_A_New() *A_arbace_test_junit_eval197000068_A { t := &A_arbace_test_junit_eval197000068_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000068_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000068_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000068_A_class }

func (t *A_arbace_test_junit_eval197000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000068_A); return ok }

func A_arbace_test_junit_eval197000068_A_Cast(x any) *A_arbace_test_junit_eval197000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000068_A_class)) }; return v }



type A_arbace_test_junit_eval197000068_fn__197000069_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_eval197000068_fn__197000069_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000068_fn__197000069_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000068_fn__197000069_A_Init() { if !A_arbace_test_junit_eval197000068_fn__197000069_A_init.Done() { A_arbace_test_junit_eval197000068_fn__197000069_A_init.Run(A_arbace_test_junit_eval197000068_fn__197000069_A_clinit) } }

func A_arbace_test_junit_eval197000068_fn__197000069_A_clinit() { A_arbace_test_junit_eval197000068_fn__197000069_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_94, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000068_fn__197000069_A_class }

func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000068_fn__197000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000068_fn__197000069_A); return ok }

func A_arbace_test_junit_eval197000068_fn__197000069_A_Cast(x any) *A_arbace_test_junit_eval197000068_fn__197000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000068_fn__197000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000068_fn__197000069_A_class)) }; return v }



type A_arbace_test_junit_eval197000072_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000072_A_New() *A_arbace_test_junit_eval197000072_A { t := &A_arbace_test_junit_eval197000072_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000072_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000072_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000072_A_class }

func (t *A_arbace_test_junit_eval197000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000072_A); return ok }

func A_arbace_test_junit_eval197000072_A_Cast(x any) *A_arbace_test_junit_eval197000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000072_A_class)) }; return v }



type A_arbace_test_junit_eval197000072_fn__197000073_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_eval197000072_fn__197000073_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000072_fn__197000073_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000072_fn__197000073_A_Init() { if !A_arbace_test_junit_eval197000072_fn__197000073_A_init.Done() { A_arbace_test_junit_eval197000072_fn__197000073_A_init.Run(A_arbace_test_junit_eval197000072_fn__197000073_A_clinit) } }

func A_arbace_test_junit_eval197000072_fn__197000073_A_clinit() { A_arbace_test_junit_eval197000072_fn__197000073_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_95, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000072_fn__197000073_A_class }

func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000072_fn__197000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000072_fn__197000073_A); return ok }

func A_arbace_test_junit_eval197000072_fn__197000073_A_Cast(x any) *A_arbace_test_junit_eval197000072_fn__197000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000072_fn__197000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000072_fn__197000073_A_class)) }; return v }



type A_arbace_test_junit_eval197000076_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000076_A_New() *A_arbace_test_junit_eval197000076_A { t := &A_arbace_test_junit_eval197000076_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000076_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000076_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000076_A_class }

func (t *A_arbace_test_junit_eval197000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000076_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000076_A); return ok }

func A_arbace_test_junit_eval197000076_A_Cast(x any) *A_arbace_test_junit_eval197000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000076_A_class)) }; return v }



type A_arbace_test_junit_eval197000076_fn__197000077_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_eval197000076_fn__197000077_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000076_fn__197000077_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000076_fn__197000077_A_Init() { if !A_arbace_test_junit_eval197000076_fn__197000077_A_init.Done() { A_arbace_test_junit_eval197000076_fn__197000077_A_init.Run(A_arbace_test_junit_eval197000076_fn__197000077_A_clinit) } }

func A_arbace_test_junit_eval197000076_fn__197000077_A_clinit() { A_arbace_test_junit_eval197000076_fn__197000077_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_96, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000076_fn__197000077_A_class }

func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000076_fn__197000077_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000076_fn__197000077_A); return ok }

func A_arbace_test_junit_eval197000076_fn__197000077_A_Cast(x any) *A_arbace_test_junit_eval197000076_fn__197000077_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000076_fn__197000077_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000076_fn__197000077_A_class)) }; return v }



type A_arbace_test_junit_eval197000080_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000080_A_New() *A_arbace_test_junit_eval197000080_A { t := &A_arbace_test_junit_eval197000080_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000080_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000080_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000080_A_class }

func (t *A_arbace_test_junit_eval197000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000080_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000080_A); return ok }

func A_arbace_test_junit_eval197000080_A_Cast(x any) *A_arbace_test_junit_eval197000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000080_A_class)) }; return v }



type A_arbace_test_junit_eval197000080_fn__197000081_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_eval197000080_fn__197000081_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000080_fn__197000081_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000080_fn__197000081_A_Init() { if !A_arbace_test_junit_eval197000080_fn__197000081_A_init.Done() { A_arbace_test_junit_eval197000080_fn__197000081_A_init.Run(A_arbace_test_junit_eval197000080_fn__197000081_A_clinit) } }

func A_arbace_test_junit_eval197000080_fn__197000081_A_clinit() { A_arbace_test_junit_eval197000080_fn__197000081_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_97, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000080_fn__197000081_A_class }

func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000080_fn__197000081_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000080_fn__197000081_A); return ok }

func A_arbace_test_junit_eval197000080_fn__197000081_A_Cast(x any) *A_arbace_test_junit_eval197000080_fn__197000081_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000080_fn__197000081_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000080_fn__197000081_A_class)) }; return v }



type A_arbace_test_junit_eval197000084_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000084_A_New() *A_arbace_test_junit_eval197000084_A { t := &A_arbace_test_junit_eval197000084_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000084_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000084_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000084_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000084_A_class }

func (t *A_arbace_test_junit_eval197000084_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000084_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000084_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000084_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000084_A); return ok }

func A_arbace_test_junit_eval197000084_A_Cast(x any) *A_arbace_test_junit_eval197000084_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000084_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000084_A_class)) }; return v }



type A_arbace_test_junit_eval197000084_fn__197000085_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_eval197000084_fn__197000085_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000084_fn__197000085_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000084_fn__197000085_A_Init() { if !A_arbace_test_junit_eval197000084_fn__197000085_A_init.Done() { A_arbace_test_junit_eval197000084_fn__197000085_A_init.Run(A_arbace_test_junit_eval197000084_fn__197000085_A_clinit) } }

func A_arbace_test_junit_eval197000084_fn__197000085_A_clinit() { A_arbace_test_junit_eval197000084_fn__197000085_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_98, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000084_fn__197000085_A_class }

func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000084_fn__197000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000084_fn__197000085_A); return ok }

func A_arbace_test_junit_eval197000084_fn__197000085_A_Cast(x any) *A_arbace_test_junit_eval197000084_fn__197000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000084_fn__197000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000084_fn__197000085_A_class)) }; return v }



type A_arbace_test_junit_eval197000088_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000088_A_New() *A_arbace_test_junit_eval197000088_A { t := &A_arbace_test_junit_eval197000088_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000088_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000088_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000088_A_class }

func (t *A_arbace_test_junit_eval197000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000088_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000088_A); return ok }

func A_arbace_test_junit_eval197000088_A_Cast(x any) *A_arbace_test_junit_eval197000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000088_A_class)) }; return v }



type A_arbace_test_junit_eval197000088_fn__197000089_A struct{ jrt.Object }

func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_eval197000088_fn__197000089_A_fn_class *jrt.Class

var A_arbace_test_junit_eval197000088_fn__197000089_A_init jrt.ClassInit

func A_arbace_test_junit_eval197000088_fn__197000089_A_Init() { if !A_arbace_test_junit_eval197000088_fn__197000089_A_init.Done() { A_arbace_test_junit_eval197000088_fn__197000089_A_init.Run(A_arbace_test_junit_eval197000088_fn__197000089_A_clinit) } }

func A_arbace_test_junit_eval197000088_fn__197000089_A_clinit() { A_arbace_test_junit_eval197000088_fn__197000089_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_99, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000088_fn__197000089_A_class }

func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000088_fn__197000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000088_fn__197000089_A); return ok }

func A_arbace_test_junit_eval197000088_fn__197000089_A_Cast(x any) *A_arbace_test_junit_eval197000088_fn__197000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000088_fn__197000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000088_fn__197000089_A_class)) }; return v }



type A_arbace_test_junit_failure_el_A struct{ jrt.Object }

func (t *A_arbace_test_junit_failure_el_A) Is_Compiler_AOTF3() {}

var A_arbace_test_junit_failure_el_A_fn_class *jrt.Class

var A_arbace_test_junit_failure_el_A_init jrt.ClassInit

func A_arbace_test_junit_failure_el_A_Init() { if !A_arbace_test_junit_failure_el_A_init.Done() { A_arbace_test_junit_failure_el_A_init.Run(A_arbace_test_junit_failure_el_A_clinit) } }

func A_arbace_test_junit_failure_el_A_clinit() { A_arbace_test_junit_failure_el_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_100, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_failure_el_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_failure_el_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_failure_el_A_class }

func (t *A_arbace_test_junit_failure_el_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_failure_el_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_failure_el_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_failure_el_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_failure_el_A); return ok }

func A_arbace_test_junit_failure_el_A_Cast(x any) *A_arbace_test_junit_failure_el_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_failure_el_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_failure_el_A_class)) }; return v }



type A_arbace_test_junit_finish_case_A struct{ jrt.Object }

func (t *A_arbace_test_junit_finish_case_A) Is_Compiler_AOTF0() {}

var A_arbace_test_junit_finish_case_A_fn_class *jrt.Class

var A_arbace_test_junit_finish_case_A_init jrt.ClassInit

func A_arbace_test_junit_finish_case_A_Init() { if !A_arbace_test_junit_finish_case_A_init.Done() { A_arbace_test_junit_finish_case_A_init.Run(A_arbace_test_junit_finish_case_A_clinit) } }

func A_arbace_test_junit_finish_case_A_clinit() { A_arbace_test_junit_finish_case_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_101, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_finish_case_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_finish_case_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_finish_case_A_class }

func (t *A_arbace_test_junit_finish_case_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_finish_case_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_finish_case_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_finish_case_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_finish_case_A); return ok }

func A_arbace_test_junit_finish_case_A_Cast(x any) *A_arbace_test_junit_finish_case_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_finish_case_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_finish_case_A_class)) }; return v }



type A_arbace_test_junit_finish_element_A struct{ jrt.Object }

func (t *A_arbace_test_junit_finish_element_A) Is_Compiler_AOTF2() {}

var A_arbace_test_junit_finish_element_A_fn_class *jrt.Class

var A_arbace_test_junit_finish_element_A_init jrt.ClassInit

func A_arbace_test_junit_finish_element_A_Init() { if !A_arbace_test_junit_finish_element_A_init.Done() { A_arbace_test_junit_finish_element_A_init.Run(A_arbace_test_junit_finish_element_A_clinit) } }

func A_arbace_test_junit_finish_element_A_clinit() { A_arbace_test_junit_finish_element_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_102, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_finish_element_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_finish_element_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_finish_element_A_class }

func (t *A_arbace_test_junit_finish_element_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_finish_element_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_finish_element_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_finish_element_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_finish_element_A); return ok }

func A_arbace_test_junit_finish_element_A_Cast(x any) *A_arbace_test_junit_finish_element_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_finish_element_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_finish_element_A_class)) }; return v }



type A_arbace_test_junit_finish_suite_A struct{ jrt.Object }

func (t *A_arbace_test_junit_finish_suite_A) Is_Compiler_AOTF0() {}

var A_arbace_test_junit_finish_suite_A_fn_class *jrt.Class

var A_arbace_test_junit_finish_suite_A_init jrt.ClassInit

func A_arbace_test_junit_finish_suite_A_Init() { if !A_arbace_test_junit_finish_suite_A_init.Done() { A_arbace_test_junit_finish_suite_A_init.Run(A_arbace_test_junit_finish_suite_A_clinit) } }

func A_arbace_test_junit_finish_suite_A_clinit() { A_arbace_test_junit_finish_suite_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_105, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_finish_suite_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_finish_suite_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_finish_suite_A_class }

func (t *A_arbace_test_junit_finish_suite_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_finish_suite_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_finish_suite_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_finish_suite_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_finish_suite_A); return ok }

func A_arbace_test_junit_finish_suite_A_Cast(x any) *A_arbace_test_junit_finish_suite_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_finish_suite_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_finish_suite_A_class)) }; return v }



type A_arbace_test_junit_fn__197000013_A struct{ jrt.Object }

func (t *A_arbace_test_junit_fn__197000013_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_fn__197000013_A_fn_class *jrt.Class

var A_arbace_test_junit_fn__197000013_A_init jrt.ClassInit

func A_arbace_test_junit_fn__197000013_A_Init() { if !A_arbace_test_junit_fn__197000013_A_init.Done() { A_arbace_test_junit_fn__197000013_A_init.Run(A_arbace_test_junit_fn__197000013_A_clinit) } }

func A_arbace_test_junit_fn__197000013_A_clinit() { A_arbace_test_junit_fn__197000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_fn__197000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_fn__197000013_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_fn__197000013_A_class }

func (t *A_arbace_test_junit_fn__197000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_fn__197000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_fn__197000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_fn__197000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_fn__197000013_A); return ok }

func A_arbace_test_junit_fn__197000013_A_Cast(x any) *A_arbace_test_junit_fn__197000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_fn__197000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_fn__197000013_A_class)) }; return v }



type A_arbace_test_junit_indent_A struct{ jrt.Object }

func (t *A_arbace_test_junit_indent_A) Is_Compiler_AOTF0() {}

var A_arbace_test_junit_indent_A_fn_class *jrt.Class

var A_arbace_test_junit_indent_A_init jrt.ClassInit

func A_arbace_test_junit_indent_A_Init() { if !A_arbace_test_junit_indent_A_init.Done() { A_arbace_test_junit_indent_A_init.Run(A_arbace_test_junit_indent_A_clinit) } }

func A_arbace_test_junit_indent_A_clinit() { A_arbace_test_junit_indent_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_indent_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_indent_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_indent_A_class }

func (t *A_arbace_test_junit_indent_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_indent_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_indent_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_indent_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_indent_A); return ok }

func A_arbace_test_junit_indent_A_Cast(x any) *A_arbace_test_junit_indent_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_indent_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_indent_A_class)) }; return v }



type A_arbace_test_junit_message_el_A struct{ jrt.Object }

func (t *A_arbace_test_junit_message_el_A) Is_Compiler_AOTF4() {}

var A_arbace_test_junit_message_el_A_fn_class *jrt.Class

var A_arbace_test_junit_message_el_A_init jrt.ClassInit

func A_arbace_test_junit_message_el_A_Init() { if !A_arbace_test_junit_message_el_A_init.Done() { A_arbace_test_junit_message_el_A_init.Run(A_arbace_test_junit_message_el_A_clinit) } }

func A_arbace_test_junit_message_el_A_clinit() { A_arbace_test_junit_message_el_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_message_el_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_message_el_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_message_el_A_class }

func (t *A_arbace_test_junit_message_el_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_message_el_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_message_el_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_message_el_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_message_el_A); return ok }

func A_arbace_test_junit_message_el_A_Cast(x any) *A_arbace_test_junit_message_el_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_message_el_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_message_el_A_class)) }; return v }



type A_arbace_test_junit_package_class_A struct{ jrt.Object }

func (t *A_arbace_test_junit_package_class_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_package_class_A_fn_class *jrt.Class

var A_arbace_test_junit_package_class_A_init jrt.ClassInit

func A_arbace_test_junit_package_class_A_Init() { if !A_arbace_test_junit_package_class_A_init.Done() { A_arbace_test_junit_package_class_A_init.Run(A_arbace_test_junit_package_class_A_clinit) } }

func A_arbace_test_junit_package_class_A_clinit() { A_arbace_test_junit_package_class_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_package_class_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_package_class_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_package_class_A_class }

func (t *A_arbace_test_junit_package_class_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_package_class_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_package_class_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_package_class_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_package_class_A); return ok }

func A_arbace_test_junit_package_class_A_Cast(x any) *A_arbace_test_junit_package_class_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_package_class_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_package_class_A_class)) }; return v }



type A_arbace_test_junit_start_case_A struct{ jrt.Object }

func (t *A_arbace_test_junit_start_case_A) Is_Compiler_AOTF2() {}

var A_arbace_test_junit_start_case_A_fn_class *jrt.Class

var A_arbace_test_junit_start_case_A_init jrt.ClassInit

func A_arbace_test_junit_start_case_A_Init() { if !A_arbace_test_junit_start_case_A_init.Done() { A_arbace_test_junit_start_case_A_init.Run(A_arbace_test_junit_start_case_A_clinit) } }

func A_arbace_test_junit_start_case_A_clinit() { A_arbace_test_junit_start_case_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_start_case_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_start_case_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_start_case_A_class }

func (t *A_arbace_test_junit_start_case_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_start_case_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_start_case_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_start_case_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_start_case_A); return ok }

func A_arbace_test_junit_start_case_A_Cast(x any) *A_arbace_test_junit_start_case_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_start_case_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_start_case_A_class)) }; return v }



type A_arbace_test_junit_start_element_A struct{ jrt.Object }

func (t *A_arbace_test_junit_start_element_A) Is_Compiler_AOTR2() {}

var A_arbace_test_junit_start_element_A_fn_class *jrt.Class

var A_arbace_test_junit_start_element_A_init jrt.ClassInit

func A_arbace_test_junit_start_element_A_Init() { if !A_arbace_test_junit_start_element_A_init.Done() { A_arbace_test_junit_start_element_A_init.Run(A_arbace_test_junit_start_element_A_clinit) } }

func A_arbace_test_junit_start_element_A_clinit() { A_arbace_test_junit_start_element_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_junit_start_element_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_start_element_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_start_element_A_class }

func (t *A_arbace_test_junit_start_element_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_start_element_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_start_element_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_start_element_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_start_element_A); return ok }

func A_arbace_test_junit_start_element_A_Cast(x any) *A_arbace_test_junit_start_element_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_start_element_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_start_element_A_class)) }; return v }



type A_arbace_test_junit_start_suite_A struct{ jrt.Object }

func (t *A_arbace_test_junit_start_suite_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_start_suite_A_fn_class *jrt.Class

var A_arbace_test_junit_start_suite_A_init jrt.ClassInit

func A_arbace_test_junit_start_suite_A_Init() { if !A_arbace_test_junit_start_suite_A_init.Done() { A_arbace_test_junit_start_suite_A_init.Run(A_arbace_test_junit_start_suite_A_clinit) } }

func A_arbace_test_junit_start_suite_A_clinit() { A_arbace_test_junit_start_suite_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_start_suite_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_start_suite_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_start_suite_A_class }

func (t *A_arbace_test_junit_start_suite_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_start_suite_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_start_suite_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_start_suite_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_start_suite_A); return ok }

func A_arbace_test_junit_start_suite_A_Cast(x any) *A_arbace_test_junit_start_suite_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_start_suite_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_start_suite_A_class)) }; return v }



type A_arbace_test_junit_suite_attrs_A struct{ jrt.Object }

func (t *A_arbace_test_junit_suite_attrs_A) Is_Compiler_AOTF2() {}

var A_arbace_test_junit_suite_attrs_A_fn_class *jrt.Class

var A_arbace_test_junit_suite_attrs_A_init jrt.ClassInit

func A_arbace_test_junit_suite_attrs_A_Init() { if !A_arbace_test_junit_suite_attrs_A_init.Done() { A_arbace_test_junit_suite_attrs_A_init.Run(A_arbace_test_junit_suite_attrs_A_clinit) } }

func A_arbace_test_junit_suite_attrs_A_clinit() { A_arbace_test_junit_suite_attrs_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_suite_attrs_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_suite_attrs_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_suite_attrs_A_class }

func (t *A_arbace_test_junit_suite_attrs_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_suite_attrs_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_suite_attrs_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_suite_attrs_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_suite_attrs_A); return ok }

func A_arbace_test_junit_suite_attrs_A_Cast(x any) *A_arbace_test_junit_suite_attrs_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_suite_attrs_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_suite_attrs_A_class)) }; return v }



type A_arbace_test_junit_test_name_A struct{ jrt.Object }

func (t *A_arbace_test_junit_test_name_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_test_name_A_fn_class *jrt.Class

var A_arbace_test_junit_test_name_A_init jrt.ClassInit

func A_arbace_test_junit_test_name_A_Init() { if !A_arbace_test_junit_test_name_A_init.Done() { A_arbace_test_junit_test_name_A_init.Run(A_arbace_test_junit_test_name_A_clinit) } }

func A_arbace_test_junit_test_name_A_clinit() { A_arbace_test_junit_test_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_test_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_test_name_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_test_name_A_class }

func (t *A_arbace_test_junit_test_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_test_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_test_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_test_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_test_name_A); return ok }

func A_arbace_test_junit_test_name_A_Cast(x any) *A_arbace_test_junit_test_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_test_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_test_name_A_class)) }; return v }



type A_arbace_test_junit_test_name_fn__197000038_A struct{ jrt.Object }

func (t *A_arbace_test_junit_test_name_fn__197000038_A) Is_Compiler_AOTF1() {}

var A_arbace_test_junit_test_name_fn__197000038_A_fn_class *jrt.Class

var A_arbace_test_junit_test_name_fn__197000038_A_init jrt.ClassInit

func A_arbace_test_junit_test_name_fn__197000038_A_Init() { if !A_arbace_test_junit_test_name_fn__197000038_A_init.Done() { A_arbace_test_junit_test_name_fn__197000038_A_init.Run(A_arbace_test_junit_test_name_fn__197000038_A_clinit) } }

func A_arbace_test_junit_test_name_fn__197000038_A_clinit() { A_arbace_test_junit_test_name_fn__197000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_test_junit_test_name_fn__197000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_test_name_fn__197000038_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_test_name_fn__197000038_A_class }

func (t *A_arbace_test_junit_test_name_fn__197000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_test_name_fn__197000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_test_name_fn__197000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_test_name_fn__197000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_test_name_fn__197000038_A); return ok }

func A_arbace_test_junit_test_name_fn__197000038_A_Cast(x any) *A_arbace_test_junit_test_name_fn__197000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_test_name_fn__197000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_test_name_fn__197000038_A_class)) }; return v }



type A_arbace_test_junit_with_junit_output_A struct{ jrt.Object }

func (t *A_arbace_test_junit_with_junit_output_A) Is_Compiler_AOTR2() {}

var A_arbace_test_junit_with_junit_output_A_fn_class *jrt.Class

var A_arbace_test_junit_with_junit_output_A_init jrt.ClassInit

func A_arbace_test_junit_with_junit_output_A_Init() { if !A_arbace_test_junit_with_junit_output_A_init.Done() { A_arbace_test_junit_with_junit_output_A_init.Run(A_arbace_test_junit_with_junit_output_A_clinit) } }

func A_arbace_test_junit_with_junit_output_A_clinit() { A_arbace_test_junit_with_junit_output_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_test_junit_with_junit_output_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_with_junit_output_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_with_junit_output_A_class }

func (t *A_arbace_test_junit_with_junit_output_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_with_junit_output_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_with_junit_output_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_with_junit_output_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_with_junit_output_A); return ok }

func A_arbace_test_junit_with_junit_output_A_Cast(x any) *A_arbace_test_junit_with_junit_output_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_with_junit_output_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_with_junit_output_A_class)) }; return v }
