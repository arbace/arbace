//line aot_arbace_test_junit.ae:1
package aot_arbace_test_junit

import (
	"arbace/jrt"
	"arbace/lang"
)










func A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_New() *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_test_junit_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_test_junit_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_junit_A_const_3, A_arbace_test_junit_A_const_4); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :17:1
func A_arbace_test_junit_eval197000008_fn__197000009_A_New() *A_arbace_test_junit_eval197000008_fn__197000009_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000008_fn__197000009_A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) Ctor() {}
//line :17:1
func (t *A_arbace_test_junit_eval197000008_fn__197000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_test_junit_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_9), A_arbace_test_junit_A_const_7.GetRawRoot__O(), A_arbace_test_junit_A_const_8) }


























func A_arbace_test_junit_fn__197000013_A_New() *A_arbace_test_junit_fn__197000013_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_fn__197000013_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_test_junit_fn__197000013_A) Ctor() {}
//line :44:1
func (t *A_arbace_test_junit_fn__197000013_A) Invoke_O_O__O(self, p1__197000012_SHARP___0 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, nil, p1__197000012_SHARP___0, nil)).Ref() }
func A_arbace_test_junit_escape_xml_A_New() *A_arbace_test_junit_escape_xml_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_escape_xml_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_test_junit_escape_xml_A) Ctor() {}
//line :45:1
func (t *A_arbace_test_junit_escape_xml_A) Invoke_O_O__O(self, text__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_10.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_11.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_12.GetRawRoot__O()); var tmp4 any = A_arbace_test_junit_escape_xml_fn__197000016_A_New(); var tmp5 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), text__0)) }
//line :46:1
func A_arbace_test_junit_escape_xml_fn__197000016_A_New() *A_arbace_test_junit_escape_xml_fn__197000016_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_escape_xml_fn__197000016_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) Ctor() {}
//line :46:1
func (t *A_arbace_test_junit_escape_xml_fn__197000016_A) Invoke_O_O__O(self, p1__197000015_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_test_junit_A_const_13.GetRawRoot__O()).Invoke_O_O__O(p1__197000015_SHARP___1, p1__197000015_SHARP___1) }




func A_arbace_test_junit_indent_A_New() *A_arbace_test_junit_indent_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_indent_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_test_junit_indent_A) Ctor() {}
//line :51:1
func (t *A_arbace_test_junit_indent_A) Invoke_O__O(self any) any { { var n__1927000701__auto____1 int64 = lang.RT_LongCast_O__J(lang.Numbers_Multiply_O_J__Number(A_arbace_test_junit_A_const_14.Get__O(), 4)); var n__2 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z(n__2, n__1927000701__auto____1) { lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(Lit_7); n__2 = lang.Numbers_Unchecked_inc_J__J(n__2); continue L1 } else { return nil } } }; /*line :51:1*/panic("a2g: unreachable") }



func A_arbace_test_junit_start_element_A_New() *A_arbace_test_junit_start_element_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_start_element_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_test_junit_start_element_A) Ctor() {}
//line :55:1
func (t *A_arbace_test_junit_start_element_A) DoInvoke_O_O_O_O__O(self, tag__0, pretty__1, p__197000020__2 any) any { var vec__197000021__4 any = p__197000020__2; var attrs__5 any = lang.RT_Nth_O_I_O__O(vec__197000021__4, lang.RT_IntCast_J__I(0), nil); if

	jrt.A2g_Truth(pretty__1) { lang.IFn_Cast(A_arbace_test_junit_A_const_16.GetRawRoot__O()).Invoke__O() };
	lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, tag__0)).Ref()); if
	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(attrs__5)) { var seq_197000024__6 any = lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(attrs__5); var chunk_197000025__7 any; var count_197000026__8 int64 = 0; var i_197000027__9 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_197000027__9, count_197000026__8) { var vec__197000028__10 any = lang.Indexed_Cast(chunk_197000025__7).Nth_I__O(lang.RT_IntCast_J__I(i_197000027__9)); var key__11 any = lang.RT_Nth_O_I_O__O(vec__197000028__10, lang.RT_IntCast_J__I(0), nil); var value__12 any = lang.RT_Nth_O_I_O__O(vec__197000028__10, lang.RT_IntCast_J__I(1), nil)
			lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_17, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_test_junit_A_const_22.GetRawRoot__O()).Invoke_O__O(key__11), nil, lang.IFn_Cast(A_arbace_test_junit_A_const_23.GetRawRoot__O()).Invoke_O__O(value__12), nil)).Ref())
//line :60:1
			seq_197000024__6, chunk_197000025__7, count_197000026__8, i_197000027__9 = seq_197000024__6, chunk_197000025__7, count_197000026__8, lang.Numbers_Unchecked_inc_J__J(i_197000027__9); continue L1 } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(seq_197000024__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_197000024__11 any = temp__1927000414__auto____10; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_test_junit_A_const_18.GetRawRoot__O()).Invoke_O__O(seq_197000024__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_test_junit_A_const_19.GetRawRoot__O()).Invoke_O__O(seq_197000024__11); seq_197000024__6, chunk_197000025__7, count_197000026__8, i_197000027__9 = lang.IFn_Cast(A_arbace_test_junit_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_197000024__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__197000031__12 any = lang.IFn_Cast(A_arbace_test_junit_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_197000024__11); var key__13 any = lang.RT_Nth_O_I_O__O(vec__197000031__12, lang.RT_IntCast_J__I(0), nil); var value__14 any = lang.RT_Nth_O_I_O__O(vec__197000031__12, lang.RT_IntCast_J__I(1), nil)
				lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_7, nil, Lit_17, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_test_junit_A_const_22.GetRawRoot__O()).Invoke_O__O(key__13), nil, lang.IFn_Cast(A_arbace_test_junit_A_const_23.GetRawRoot__O()).Invoke_O__O(value__14), nil)).Ref())
//line :60:1
				seq_197000024__6, chunk_197000025__7, count_197000026__8, i_197000027__9 = lang.IFn_Cast(A_arbace_test_junit_A_const_25.GetRawRoot__O()).Invoke_O__O(seq_197000024__11), nil, 0, 0; continue L1 } } }
//line :59:1
		break L1 } };


	lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(Lit_4); if
	jrt.A2g_Truth(pretty__1) { lang.IFn_Cast(A_arbace_test_junit_A_const_21.GetRawRoot__O()).Invoke__O() }; var tmp1 /*line :55:1*/*lang.Var = A_arbace_test_junit_A_const_14; return tmp1.Set_O__O(lang.Numbers_Inc_O__Number(A_arbace_test_junit_A_const_14.Get__O())) }










func A_arbace_test_junit_element_content_A_New() *A_arbace_test_junit_element_content_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_element_content_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_test_junit_element_content_A) Ctor() {}
//line :66:1
func (t *A_arbace_test_junit_element_content_A) Invoke_O_O__O(self, content__0 any) any {

	return lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_23.GetRawRoot__O()).Invoke_O__O(content__0))
}
func A_arbace_test_junit_finish_element_A_New() *A_arbace_test_junit_finish_element_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_finish_element_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_test_junit_finish_element_A) Ctor() {}
//line :70:1
func (t *A_arbace_test_junit_finish_element_A) Invoke_O_O_O__O(self, tag__0, pretty__1 any) any { var tmp1 *lang.Var = A_arbace_test_junit_A_const_14; tmp1.Set_O__O(lang.Numbers_Dec_O__Number(A_arbace_test_junit_A_const_14.Get__O())); if


	jrt.A2g_Truth(pretty__1) { lang.IFn_Cast(A_arbace_test_junit_A_const_16.GetRawRoot__O()).Invoke__O() };
	lang.IFn_Cast(A_arbace_test_junit_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, tag__0, nil)).Ref()); if
	jrt.A2g_Truth(pretty__1) { return lang.IFn_Cast(A_arbace_test_junit_A_const_21.GetRawRoot__O()).Invoke__O() } else { return nil } }

func A_arbace_test_junit_test_name_A_New() *A_arbace_test_junit_test_name_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_test_name_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_test_junit_test_name_A) Ctor() {}
//line :77:1
func (t *A_arbace_test_junit_test_name_A) Invoke_O_O__O(self, vars__0 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_10.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_11.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_26.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_27.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_12.GetRawRoot__O()); var tmp6 any = A_arbace_test_junit_test_name_fn__197000038_A_New(); var tmp7 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_test_junit_test_name_fn__197000038_A_fn_class
	if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_test_junit_test_name_fn__197000038_A_fn_class = fncls__2d; tmp7 = fncls__2d } else { tmp7 = fncls__2 }
//line :79:1
	return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(Lit_14, tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), vars__0)))) }
func A_arbace_test_junit_test_name_fn__197000038_A_New() *A_arbace_test_junit_test_name_fn__197000038_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_test_name_fn__197000038_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_test_junit_test_name_fn__197000038_A) Ctor() {}
//line :80:1
func (t *A_arbace_test_junit_test_name_fn__197000038_A) Invoke_O_O__O(self, p1__197000037_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_test_junit_A_const_28; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(p1__197000037_SHARP___1)) }

func A_arbace_test_junit_package_class_A_New() *A_arbace_test_junit_package_class_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_package_class_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_test_junit_package_class_A) Ctor() {}
//line :82:1
func (t *A_arbace_test_junit_package_class_A) Invoke_O_O__O(self, name__0 any) any { var i__2 any = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(name__0, Lit_13, jrt.RefArrayOf(jrt.Object_class, Lit_14)); if


	lang.Numbers_Lt_O_J__Z(i__2, 0) { return lang.Tuple_Create_O_O__IPersistentVector(nil, name__0) } else { return lang.Tuple_Create_O_O__IPersistentVector(lang.Reflector_InvokeInstanceMethod_O_String_O1__O(name__0, Lit_15, jrt.RefArrayOf(jrt.Object_class, A_arbace_test_junit_A_const_29, i__2)), lang.Reflector_InvokeInstanceMethod_O_String_O1__O(name__0, Lit_15, jrt.RefArrayOf(jrt.Object_class, lang.Numbers_Add_O_J__Number(i__2, 1)))) } }



func A_arbace_test_junit_start_case_A_New() *A_arbace_test_junit_start_case_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_start_case_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_test_junit_start_case_A) Ctor() {}
//line :89:1
func (t *A_arbace_test_junit_start_case_A) Invoke_O_O_O__O(self, name__0, classname__1 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_30.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_31; var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; var tmp4 any = tmp3.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_junit_A_const_28, name__0, A_arbace_test_junit_A_const_32, classname__1)))
}
func A_arbace_test_junit_finish_case_A_New() *A_arbace_test_junit_finish_case_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_finish_case_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_test_junit_finish_case_A) Ctor() {}
//line :93:1
func (t *A_arbace_test_junit_finish_case_A) Invoke_O__O(self any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_33.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_34; var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(tmp2, tmp3.Ref())
}
func A_arbace_test_junit_suite_attrs_A_New() *A_arbace_test_junit_suite_attrs_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_suite_attrs_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_test_junit_suite_attrs_A) Ctor() {}
//line :97:1
func (t *A_arbace_test_junit_suite_attrs_A) Invoke_O_O_O__O(self, package__0, classname__1 any) any { var attrs__3 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_junit_A_const_28, classname__1)); if


	jrt.A2g_Truth(package__0) {
		return lang.IFn_Cast(A_arbace_test_junit_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(attrs__3, A_arbace_test_junit_A_const_36, package__0) } else {
//line :100:1
			return attrs__3 } }



func A_arbace_test_junit_start_suite_A_New() *A_arbace_test_junit_start_suite_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_start_suite_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_test_junit_start_suite_A) Ctor() {}
//line :104:1
func (t *A_arbace_test_junit_start_suite_A) Invoke_O_O__O(self, name__0 any) any { var vec__197000045__2 any = lang.IFn_Cast(A_arbace_test_junit_A_const_37.GetRawRoot__O()).Invoke_O__O(name__0); var package__3 any = lang.RT_Nth_O_I_O__O(vec__197000045__2, lang.RT_IntCast_J__I(0), nil); var classname__4 any = lang.RT_Nth_O_I_O__O(vec__197000045__2, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_30.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_38; var tmp3 *jrt.Boolean;


	jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; var tmp4 any = tmp3.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp4, lang.IFn_Cast(A_arbace_test_junit_A_const_39.GetRawRoot__O()).Invoke_O_O__O(package__3, classname__4)) }

func A_arbace_test_junit_finish_suite_A_New() *A_arbace_test_junit_finish_suite_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_finish_suite_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_test_junit_finish_suite_A) Ctor() {}
//line :109:1
func (t *A_arbace_test_junit_finish_suite_A) Invoke_O__O(self any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_33.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_40; var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(tmp2, tmp3.Ref())
}
func A_arbace_test_junit_message_el_A_New() *A_arbace_test_junit_message_el_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_message_el_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_test_junit_message_el_A) Ctor() {}
//line :113:1
func (t *A_arbace_test_junit_message_el_A) Invoke_O_O_O_O_O__O(self, tag__0, message__1, expected_str__2, actual_str__3 any) any {

	lang.IFn_Cast(A_arbace_test_junit_A_const_16.GetRawRoot__O()).Invoke__O()
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_30.GetRawRoot__O()); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; var tmp3 any = tmp2.Ref(); var tmp4 lang.IPersistentMap; if jrt.A2g_Truth(message__1) { tmp4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_test_junit_A_const_42, message__1)) } else { lang.PersistentArrayMap_Init(); tmp4 = Up_PersistentArrayMap_IPersistentMap(lang.PersistentArrayMap_EMPTY) }; tmp1.Invoke_O_O_O__O(tag__0, tmp3, tmp4)
	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_41.GetRawRoot__O()); var tmp6 any; var vec__197000050__5 any = lang.IFn_Cast(A_arbace_test_junit_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_44); var file__6 any = lang.RT_Nth_O_I_O__O(vec__197000050__5, lang.RT_IntCast_J__I(0), nil); var line__7 any = lang.RT_Nth_O_I_O__O(vec__197000050__5, lang.RT_IntCast_J__I(1), nil); var detail__8 any = lang.IFn_Cast(A_arbace_test_junit_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_junit_A_const_11.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_junit_A_const_26.GetRawRoot__O()).Invoke_O_O__O(Lit_8, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_9, nil), jrt.RefArrayOf(jrt.Object_class, nil, expected_str__2)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, actual_str__3)).Ref(), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_11, nil, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, file__6, nil, line__7)).Ref())))






	if jrt.A2g_Truth(message__1) { tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_8, nil), jrt.RefArrayOf(jrt.Object_class, message__1, nil, detail__8)).Ref() } else { tmp6 = detail__8 }
//line :117:1
	tmp5.Invoke_O__O(tmp6)







	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_33.GetRawRoot__O()); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_FALSE; tmp7.Invoke_O_O__O(tag__0, tmp8.Ref())
	return lang.IFn_Cast(A_arbace_test_junit_A_const_21.GetRawRoot__O()).Invoke__O()
}
func A_arbace_test_junit_failure_el_A_New() *A_arbace_test_junit_failure_el_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_failure_el_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_test_junit_failure_el_A) Ctor() {}
//line :128:1
func (t *A_arbace_test_junit_failure_el_A) Invoke_O_O_O_O__O(self, message__0, expected__1, actual__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_45.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_46; return tmp1.Invoke_O_O_O_O__O(tmp2, message__0, lang.IFn_Cast(A_arbace_test_junit_A_const_47.GetRawRoot__O()).Invoke_O__O(expected__1), lang.IFn_Cast(A_arbace_test_junit_A_const_47.GetRawRoot__O()).Invoke_O__O(actual__2))
}
func A_arbace_test_junit_error_el_A_New() *A_arbace_test_junit_error_el_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_error_el_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_test_junit_error_el_A) Ctor() {}
//line :132:1
func (t *A_arbace_test_junit_error_el_A) Invoke_O_O_O_O__O(self, message__0, expected__1, actual__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_45.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_48; var tmp3 any = lang.IFn_Cast(A_arbace_test_junit_A_const_47.GetRawRoot__O()).Invoke_O__O(expected__1); var tmp4 any


	if jrt.Throwable_InstanceOf(actual__2) { var s__1927001093__auto____4 any = jrt.StringWriter_New()
		lang.IFn_Cast(A_arbace_test_junit_A_const_53.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_junit_A_const_55, s__1927001093__auto____4)); var tmp5 any = A_arbace_test_junit_error_el_fn__197000055_A_New_O_O(s__1927001093__auto____4, actual__2); var tmp6 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_test_junit_error_el_fn__197000055_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_test_junit_error_el_fn__197000055_A_fn_class = fncls__3d; tmp6 = fncls__3d } else { tmp6 = fncls__3 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O() } else {
			tmp4 = lang.IFn_Cast(A_arbace_test_junit_A_const_52.GetRawRoot__O()).Invoke_O__O(actual__2) }
//line :134:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, message__0, tmp3, tmp4)
}


func A_arbace_test_junit_error_el_fn__197000055_A_New_O_O(p0, p1 any) *A_arbace_test_junit_error_el_fn__197000055_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_error_el_fn__197000055_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_test_junit_error_el_fn__197000055_A) Ctor_O_O(c__s__1927001093__auto__, c__actual any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_actual = c__actual }
//line :138:1
func (t *A_arbace_test_junit_error_el_fn__197000055_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_50.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_actual; t.F_actual = nil; tmp3 = t_; tmp2.Invoke_O_O__O(tmp3, A_arbace_test_junit_A_const_51.Get__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_11.GetRawRoot__O()); var tmp5 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; tmp5 = t__2; tmp1 = tmp4.Invoke_O__O(tmp5) }; return nil }(); lang.IFn_Cast(A_arbace_test_junit_A_const_49.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp1 }





func A_arbace_test_junit_eval197000060_fn__197000061_A_New() *A_arbace_test_junit_eval197000060_fn__197000061_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000060_fn__197000061_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) Ctor() {}
//line :144:1
func (t *A_arbace_test_junit_eval197000060_fn__197000061_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; lang.IFn_Cast(A_arbace_test_junit_A_const_53.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_57.Get__O()))
//line :144:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp3 = lang.IFn_Cast(A_arbace_test_junit_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_58.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_59.Invoke_O__O(m__1))))
//line :144:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_junit_A_const_49.GetRawRoot__O()).Invoke__O()
//line :144:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_junit_eval197000064_fn__197000065_A_New() *A_arbace_test_junit_eval197000064_fn__197000065_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000064_fn__197000065_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) Ctor() {}
//line :148:1
func (t *A_arbace_test_junit_eval197000064_fn__197000065_A) Invoke_O_O__O(self, ___1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; lang.IFn_Cast(A_arbace_test_junit_A_const_53.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_57.Get__O()))
//line :148:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp3 = lang.IFn_Cast(A_arbace_test_junit_A_const_60.GetRawRoot__O()).Invoke__O()
//line :148:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_junit_A_const_49.GetRawRoot__O()).Invoke__O()
//line :148:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_junit_eval197000068_fn__197000069_A_New() *A_arbace_test_junit_eval197000068_fn__197000069_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000068_fn__197000069_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) Ctor() {}
//line :152:1
func (t *A_arbace_test_junit_eval197000068_fn__197000069_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; lang.IFn_Cast(A_arbace_test_junit_A_const_53.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_57.Get__O()))
//line :152:1
	var tmp3 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var var__4 any = A_arbace_test_junit_A_const_61.Invoke_O__O(m__1); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O())
		var tmp5 any = A_arbace_test_junit_A_const_63

		lang.IFn_Cast(A_arbace_test_junit_A_const_53.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_test_junit_A_const_7.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_junit_A_const_63.Get__O(), var__4)))
//line :152:1
		tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



			{ var tmp6 *lang.Keyword = A_arbace_test_junit_A_const_59; tmp3 = lang.IFn_Cast(A_arbace_test_junit_A_const_62.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_64.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_63.Get__O()), lang.IFn_Cast(A_arbace_test_junit_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_58.GetRawRoot__O()).Invoke_O__O(tmp6.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(var__4))))) }
//line :152:1
			return nil
		}()

		lang.IFn_Cast(A_arbace_test_junit_A_const_49.GetRawRoot__O()).Invoke__O()
//line :152:1
		if tmp7 != nil { panic(tmp7) } }; return nil }()
	lang.IFn_Cast(A_arbace_test_junit_A_const_49.GetRawRoot__O()).Invoke__O()
//line :152:1
	if tmp8 != nil { panic(tmp8) }; return tmp3
}




func A_arbace_test_junit_eval197000072_fn__197000073_A_New() *A_arbace_test_junit_eval197000072_fn__197000073_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000072_fn__197000073_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) Ctor() {}
//line :158:1
func (t *A_arbace_test_junit_eval197000072_fn__197000073_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; lang.IFn_Cast(A_arbace_test_junit_A_const_53.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_57.Get__O()))
//line :158:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp3 = lang.IFn_Cast(A_arbace_test_junit_A_const_65.GetRawRoot__O()).Invoke__O()
//line :158:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_junit_A_const_49.GetRawRoot__O()).Invoke__O()
//line :158:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_junit_eval197000076_fn__197000077_A_New() *A_arbace_test_junit_eval197000076_fn__197000077_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000076_fn__197000077_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) Ctor() {}
//line :162:1
func (t *A_arbace_test_junit_eval197000076_fn__197000077_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; lang.IFn_Cast(A_arbace_test_junit_A_const_53.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_57.Get__O()))
//line :162:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		tmp3 = lang.IFn_Cast(A_arbace_test_junit_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_67)
//line :162:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_junit_A_const_49.GetRawRoot__O()).Invoke__O()
//line :162:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}


func A_arbace_test_junit_eval197000080_fn__197000081_A_New() *A_arbace_test_junit_eval197000080_fn__197000081_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000080_fn__197000081_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) Ctor() {}
//line :166:1
func (t *A_arbace_test_junit_eval197000080_fn__197000081_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; lang.IFn_Cast(A_arbace_test_junit_A_const_53.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_57.Get__O()))
//line :166:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		lang.IFn_Cast(A_arbace_test_junit_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_69)
		tmp3 = lang.IFn_Cast(A_arbace_test_junit_A_const_68.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_test_junit_A_const_42.Invoke_O__O(m__1), A_arbace_test_junit_A_const_70.Invoke_O__O(m__1), A_arbace_test_junit_A_const_71.Invoke_O__O(m__1))
//line :166:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_junit_A_const_49.GetRawRoot__O()).Invoke__O()
//line :166:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}





func A_arbace_test_junit_eval197000084_fn__197000085_A_New() *A_arbace_test_junit_eval197000084_fn__197000085_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000084_fn__197000085_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) Ctor() {}
//line :173:1
func (t *A_arbace_test_junit_eval197000084_fn__197000085_A) Invoke_O_O__O(self, m__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_test_junit_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_test_junit_A_const_55; lang.IFn_Cast(A_arbace_test_junit_A_const_53.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_test_junit_A_const_57.Get__O()))
//line :173:1
	var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		lang.IFn_Cast(A_arbace_test_junit_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_73)
		tmp3 = lang.IFn_Cast(A_arbace_test_junit_A_const_72.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_test_junit_A_const_42.Invoke_O__O(m__1), A_arbace_test_junit_A_const_70.Invoke_O__O(m__1), A_arbace_test_junit_A_const_71.Invoke_O__O(m__1))
//line :173:1
		return nil }()
	lang.IFn_Cast(A_arbace_test_junit_A_const_49.GetRawRoot__O()).Invoke__O()
//line :173:1
	if tmp4 != nil { panic(tmp4) }; return tmp3
}





func A_arbace_test_junit_eval197000088_fn__197000089_A_New() *A_arbace_test_junit_eval197000088_fn__197000089_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_eval197000088_fn__197000089_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) Ctor() {}
//line :180:1
func (t *A_arbace_test_junit_eval197000088_fn__197000089_A) Invoke_O_O__O(self, ___1 any) any { return nil }

func A_arbace_test_junit_with_junit_output_A_New() *A_arbace_test_junit_with_junit_output_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_with_junit_output_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_test_junit_with_junit_output_A) Ctor() {}
//line :182:1
func (t *A_arbace_test_junit_with_junit_output_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { return lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_76), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_junit_A_const_77.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_78), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_79), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_80), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_81)))), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_82), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_83))))), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_84), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_85), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(Lit_20)))), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_86), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(Lit_21))))))), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_87), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_test_junit_A_const_77.GetRawRoot__O(), lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_88), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_89), body__2))))))), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_90), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_74.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_91), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(Lit_22))))))), lang.IFn_Cast(A_arbace_test_junit_A_const_75.GetRawRoot__O()).Invoke_O__O(A_arbace_test_junit_A_const_88)))))) }































type A_arbace_test_junit_A struct{ jrt.Object }

var A_arbace_test_junit_A_const_pool *jrt.RefArray

var A_arbace_test_junit_A_const_0 *lang.Var

var A_arbace_test_junit_A_const_1 *lang.Var

var A_arbace_test_junit_A_const_2 any

var A_arbace_test_junit_A_const_3 any

var A_arbace_test_junit_A_const_4 any

var A_arbace_test_junit_A_const_5 *lang.Var

var A_arbace_test_junit_A_const_6 *lang.Var

var A_arbace_test_junit_A_const_7 *lang.Var

var A_arbace_test_junit_A_const_8 any

var A_arbace_test_junit_A_const_9 *lang.Var

var A_arbace_test_junit_A_const_10 *lang.Var

var A_arbace_test_junit_A_const_11 *lang.Var

var A_arbace_test_junit_A_const_12 *lang.Var

var A_arbace_test_junit_A_const_13 *lang.Var

var A_arbace_test_junit_A_const_14 *lang.Var

var A_arbace_test_junit_A_const_15 *lang.Var

var A_arbace_test_junit_A_const_16 *lang.Var

var A_arbace_test_junit_A_const_17 *lang.Var

var A_arbace_test_junit_A_const_18 *lang.Var

var A_arbace_test_junit_A_const_19 *lang.Var

var A_arbace_test_junit_A_const_20 *lang.Var

var A_arbace_test_junit_A_const_21 *lang.Var

var A_arbace_test_junit_A_const_22 *lang.Var

var A_arbace_test_junit_A_const_23 *lang.Var

var A_arbace_test_junit_A_const_24 *lang.Var

var A_arbace_test_junit_A_const_25 *lang.Var

var A_arbace_test_junit_A_const_26 *lang.Var

var A_arbace_test_junit_A_const_27 *lang.Var

var A_arbace_test_junit_A_const_28 *lang.Keyword

var A_arbace_test_junit_A_const_29 any

var A_arbace_test_junit_A_const_30 *lang.Var

var A_arbace_test_junit_A_const_31 any

var A_arbace_test_junit_A_const_32 *lang.Keyword

var A_arbace_test_junit_A_const_33 *lang.Var

var A_arbace_test_junit_A_const_34 any

var A_arbace_test_junit_A_const_35 *lang.Var

var A_arbace_test_junit_A_const_36 *lang.Keyword

var A_arbace_test_junit_A_const_37 *lang.Var

var A_arbace_test_junit_A_const_38 any

var A_arbace_test_junit_A_const_39 *lang.Var

var A_arbace_test_junit_A_const_40 any

var A_arbace_test_junit_A_const_41 *lang.Var

var A_arbace_test_junit_A_const_42 *lang.Keyword

var A_arbace_test_junit_A_const_43 *lang.Var

var A_arbace_test_junit_A_const_44 any

var A_arbace_test_junit_A_const_45 *lang.Var

var A_arbace_test_junit_A_const_46 any

var A_arbace_test_junit_A_const_47 *lang.Var

var A_arbace_test_junit_A_const_48 any

var A_arbace_test_junit_A_const_49 *lang.Var

var A_arbace_test_junit_A_const_50 *lang.Var

var A_arbace_test_junit_A_const_51 *lang.Var

var A_arbace_test_junit_A_const_52 *lang.Var

var A_arbace_test_junit_A_const_53 *lang.Var

var A_arbace_test_junit_A_const_54 *lang.Var

var A_arbace_test_junit_A_const_55 *lang.Var

var A_arbace_test_junit_A_const_56 *lang.Var

var A_arbace_test_junit_A_const_57 *lang.Var

var A_arbace_test_junit_A_const_58 *lang.Var

var A_arbace_test_junit_A_const_59 *lang.Keyword

var A_arbace_test_junit_A_const_60 *lang.Var

var A_arbace_test_junit_A_const_61 *lang.Keyword

var A_arbace_test_junit_A_const_62 *lang.Var

var A_arbace_test_junit_A_const_63 *lang.Var

var A_arbace_test_junit_A_const_64 *lang.Var

var A_arbace_test_junit_A_const_65 *lang.Var

var A_arbace_test_junit_A_const_66 *lang.Var

var A_arbace_test_junit_A_const_67 *lang.Keyword

var A_arbace_test_junit_A_const_68 *lang.Var

var A_arbace_test_junit_A_const_69 *lang.Keyword

var A_arbace_test_junit_A_const_70 *lang.Keyword

var A_arbace_test_junit_A_const_71 *lang.Keyword

var A_arbace_test_junit_A_const_72 *lang.Var

var A_arbace_test_junit_A_const_73 *lang.Keyword

var A_arbace_test_junit_A_const_74 *lang.Var

var A_arbace_test_junit_A_const_75 *lang.Var

var A_arbace_test_junit_A_const_76 any

var A_arbace_test_junit_A_const_77 *lang.Var

var A_arbace_test_junit_A_const_78 any

var A_arbace_test_junit_A_const_79 any

var A_arbace_test_junit_A_const_80 any

var A_arbace_test_junit_A_const_81 any

var A_arbace_test_junit_A_const_82 any

var A_arbace_test_junit_A_const_83 any

var A_arbace_test_junit_A_const_84 any

var A_arbace_test_junit_A_const_85 any

var A_arbace_test_junit_A_const_86 any

var A_arbace_test_junit_A_const_87 any

var A_arbace_test_junit_A_const_88 any

var A_arbace_test_junit_A_const_89 any

var A_arbace_test_junit_A_const_90 any

var A_arbace_test_junit_A_const_91 any

var A_arbace_test_junit_A_init jrt.ClassInit

func A_arbace_test_junit_A_Init() { if !A_arbace_test_junit_A_init.Done() { A_arbace_test_junit_A_init.Run(A_arbace_test_junit_A_clinit) } }

func A_arbace_test_junit_A_clinit() { A_arbace_test_junit_A_clinit_p0(); A_arbace_test_junit_A_clinit_p1(); A_arbace_test_junit_A_clinit_p2(); A_arbace_test_junit_A_clinit_p3(); A_arbace_test_junit_A_clinit_p4(); A_arbace_test_junit_A_clinit_p5(); A_arbace_test_junit_A_clinit_p6(); A_arbace_test_junit_A_clinit_p7() }

func A_arbace_test_junit_A_clinit_p0() { A_arbace_test_junit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 126); A_arbace_test_junit_A_const_0 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[34]); A_arbace_test_junit_A_const_1 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[35]); A_arbace_test_junit_A_const_2 = A_arbace_test_junit_A_const_pool.A[36]; A_arbace_test_junit_A_const_3 = A_arbace_test_junit_A_const_pool.A[37]; A_arbace_test_junit_A_const_4 = A_arbace_test_junit_A_const_pool.A[38]; A_arbace_test_junit_A_const_5 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[39]); A_arbace_test_junit_A_const_6 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[40]); A_arbace_test_junit_A_const_7 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[41]); A_arbace_test_junit_A_const_8 = A_arbace_test_junit_A_const_pool.A[42]; A_arbace_test_junit_A_const_9 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[43]); A_arbace_test_junit_A_const_10 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[44]); A_arbace_test_junit_A_const_11 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[45]) }

func A_arbace_test_junit_A_clinit_p1() { A_arbace_test_junit_A_const_12 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[46]); A_arbace_test_junit_A_const_13 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[47]); A_arbace_test_junit_A_const_14 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[48]); A_arbace_test_junit_A_const_15 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[49]); A_arbace_test_junit_A_const_16 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[50]); A_arbace_test_junit_A_const_17 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[51]); A_arbace_test_junit_A_const_18 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[52]); A_arbace_test_junit_A_const_19 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[53]); A_arbace_test_junit_A_const_20 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[54]); A_arbace_test_junit_A_const_21 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[55]); A_arbace_test_junit_A_const_22 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[56]); A_arbace_test_junit_A_const_23 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[57]) }

func A_arbace_test_junit_A_clinit_p2() { A_arbace_test_junit_A_const_24 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[58]); A_arbace_test_junit_A_const_25 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[59]); A_arbace_test_junit_A_const_26 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[60]); A_arbace_test_junit_A_const_27 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[61]); A_arbace_test_junit_A_const_28 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[62]); A_arbace_test_junit_A_const_29 = A_arbace_test_junit_A_const_pool.A[63]; A_arbace_test_junit_A_const_30 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[64]); A_arbace_test_junit_A_const_31 = A_arbace_test_junit_A_const_pool.A[65]; A_arbace_test_junit_A_const_32 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[66]); A_arbace_test_junit_A_const_33 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[67]); A_arbace_test_junit_A_const_34 = A_arbace_test_junit_A_const_pool.A[68]; A_arbace_test_junit_A_const_35 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[69]) }

func A_arbace_test_junit_A_clinit_p3() { A_arbace_test_junit_A_const_36 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[70]); A_arbace_test_junit_A_const_37 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[71]); A_arbace_test_junit_A_const_38 = A_arbace_test_junit_A_const_pool.A[72]; A_arbace_test_junit_A_const_39 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[73]); A_arbace_test_junit_A_const_40 = A_arbace_test_junit_A_const_pool.A[74]; A_arbace_test_junit_A_const_41 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[75]); A_arbace_test_junit_A_const_42 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[76]); A_arbace_test_junit_A_const_43 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[77]); A_arbace_test_junit_A_const_44 = A_arbace_test_junit_A_const_pool.A[78]; A_arbace_test_junit_A_const_45 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[79]); A_arbace_test_junit_A_const_46 = A_arbace_test_junit_A_const_pool.A[80]; A_arbace_test_junit_A_const_47 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[81]); A_arbace_test_junit_A_const_48 = A_arbace_test_junit_A_const_pool.A[82] }

func A_arbace_test_junit_A_clinit_p4() { A_arbace_test_junit_A_const_49 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[83]); A_arbace_test_junit_A_const_50 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[84]); A_arbace_test_junit_A_const_51 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[85]); A_arbace_test_junit_A_const_52 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[86]); A_arbace_test_junit_A_const_53 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[87]); A_arbace_test_junit_A_const_54 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[88]); A_arbace_test_junit_A_const_55 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[89]); A_arbace_test_junit_A_const_56 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[90]); A_arbace_test_junit_A_const_57 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[91]); A_arbace_test_junit_A_const_58 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[92]); A_arbace_test_junit_A_const_59 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[93]); A_arbace_test_junit_A_const_60 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[94]) }

func A_arbace_test_junit_A_clinit_p5() { A_arbace_test_junit_A_const_61 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[95]); A_arbace_test_junit_A_const_62 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[96]); A_arbace_test_junit_A_const_63 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[97]); A_arbace_test_junit_A_const_64 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[98]); A_arbace_test_junit_A_const_65 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[99]); A_arbace_test_junit_A_const_66 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[100]); A_arbace_test_junit_A_const_67 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[101]); A_arbace_test_junit_A_const_68 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[102]); A_arbace_test_junit_A_const_69 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[103]); A_arbace_test_junit_A_const_70 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[104]); A_arbace_test_junit_A_const_71 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[105]); A_arbace_test_junit_A_const_72 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[106]) }

func A_arbace_test_junit_A_clinit_p6() { A_arbace_test_junit_A_const_73 = lang.Keyword_Cast(A_arbace_test_junit_A_const_pool.A[107]); A_arbace_test_junit_A_const_74 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[108]); A_arbace_test_junit_A_const_75 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[109]); A_arbace_test_junit_A_const_76 = A_arbace_test_junit_A_const_pool.A[110]; A_arbace_test_junit_A_const_77 = lang.Var_Cast(A_arbace_test_junit_A_const_pool.A[111]); A_arbace_test_junit_A_const_78 = A_arbace_test_junit_A_const_pool.A[112]; A_arbace_test_junit_A_const_79 = A_arbace_test_junit_A_const_pool.A[113]; A_arbace_test_junit_A_const_80 = A_arbace_test_junit_A_const_pool.A[114]; A_arbace_test_junit_A_const_81 = A_arbace_test_junit_A_const_pool.A[115]; A_arbace_test_junit_A_const_82 = A_arbace_test_junit_A_const_pool.A[116]; A_arbace_test_junit_A_const_83 = A_arbace_test_junit_A_const_pool.A[117]; A_arbace_test_junit_A_const_84 = A_arbace_test_junit_A_const_pool.A[118]; A_arbace_test_junit_A_const_85 = A_arbace_test_junit_A_const_pool.A[119]; A_arbace_test_junit_A_const_86 = A_arbace_test_junit_A_const_pool.A[120] }

func A_arbace_test_junit_A_clinit_p7() { A_arbace_test_junit_A_const_87 = A_arbace_test_junit_A_const_pool.A[121]; A_arbace_test_junit_A_const_88 = A_arbace_test_junit_A_const_pool.A[122]; A_arbace_test_junit_A_const_89 = A_arbace_test_junit_A_const_pool.A[123]; A_arbace_test_junit_A_const_90 = A_arbace_test_junit_A_const_pool.A[124]; A_arbace_test_junit_A_const_91 = A_arbace_test_junit_A_const_pool.A[125] }

func A_arbace_test_junit_A_New() *A_arbace_test_junit_A { A_arbace_test_junit_A_Init(); t := &A_arbace_test_junit_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_A) Ctor() {}

func (t *A_arbace_test_junit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_A_class }

func (t *A_arbace_test_junit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_A); return ok }

func A_arbace_test_junit_A_Cast(x any) *A_arbace_test_junit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_A_class)) }; return v }



type A_arbace_test_junit_element_content_A struct{ a2g_header uint64 }

var A_arbace_test_junit_element_content_A_fn_class *jrt.Class



type A_arbace_test_junit_error_el_A struct{ a2g_header uint64 }

var A_arbace_test_junit_error_el_A_fn_class *jrt.Class



type A_arbace_test_junit_error_el_fn__197000055_A struct{ a2g_header uint64; F_s__1927001093__auto__, F_actual any }

var A_arbace_test_junit_error_el_fn__197000055_A_fn_class *jrt.Class



type A_arbace_test_junit_escape_xml_A struct{ a2g_header uint64 }

var A_arbace_test_junit_escape_xml_A_fn_class *jrt.Class



type A_arbace_test_junit_escape_xml_fn__197000016_A struct{ a2g_header uint64 }

var A_arbace_test_junit_escape_xml_fn__197000016_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000004_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000004_A_New() *A_arbace_test_junit_eval197000004_A { t := &A_arbace_test_junit_eval197000004_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000004_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000004_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000004_A_class }

func (t *A_arbace_test_junit_eval197000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000004_A); return ok }

func A_arbace_test_junit_eval197000004_A_Cast(x any) *A_arbace_test_junit_eval197000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000004_A_class)) }; return v }



type A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000004_loading__1927001464__auto____197000005_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000008_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000008_A_New() *A_arbace_test_junit_eval197000008_A { t := &A_arbace_test_junit_eval197000008_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000008_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000008_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000008_A_class }

func (t *A_arbace_test_junit_eval197000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000008_A); return ok }

func A_arbace_test_junit_eval197000008_A_Cast(x any) *A_arbace_test_junit_eval197000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000008_A_class)) }; return v }



type A_arbace_test_junit_eval197000008_fn__197000009_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000008_fn__197000009_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000060_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000060_A_New() *A_arbace_test_junit_eval197000060_A { t := &A_arbace_test_junit_eval197000060_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000060_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000060_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000060_A_class }

func (t *A_arbace_test_junit_eval197000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000060_A); return ok }

func A_arbace_test_junit_eval197000060_A_Cast(x any) *A_arbace_test_junit_eval197000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000060_A_class)) }; return v }



type A_arbace_test_junit_eval197000060_fn__197000061_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000060_fn__197000061_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000064_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000064_A_New() *A_arbace_test_junit_eval197000064_A { t := &A_arbace_test_junit_eval197000064_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000064_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000064_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000064_A_class }

func (t *A_arbace_test_junit_eval197000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000064_A); return ok }

func A_arbace_test_junit_eval197000064_A_Cast(x any) *A_arbace_test_junit_eval197000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000064_A_class)) }; return v }



type A_arbace_test_junit_eval197000064_fn__197000065_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000064_fn__197000065_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000068_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000068_A_New() *A_arbace_test_junit_eval197000068_A { t := &A_arbace_test_junit_eval197000068_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000068_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000068_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000068_A_class }

func (t *A_arbace_test_junit_eval197000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000068_A); return ok }

func A_arbace_test_junit_eval197000068_A_Cast(x any) *A_arbace_test_junit_eval197000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000068_A_class)) }; return v }



type A_arbace_test_junit_eval197000068_fn__197000069_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000068_fn__197000069_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000072_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000072_A_New() *A_arbace_test_junit_eval197000072_A { t := &A_arbace_test_junit_eval197000072_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000072_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000072_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000072_A_class }

func (t *A_arbace_test_junit_eval197000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000072_A); return ok }

func A_arbace_test_junit_eval197000072_A_Cast(x any) *A_arbace_test_junit_eval197000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000072_A_class)) }; return v }



type A_arbace_test_junit_eval197000072_fn__197000073_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000072_fn__197000073_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000076_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000076_A_New() *A_arbace_test_junit_eval197000076_A { t := &A_arbace_test_junit_eval197000076_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000076_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000076_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000076_A_class }

func (t *A_arbace_test_junit_eval197000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000076_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000076_A); return ok }

func A_arbace_test_junit_eval197000076_A_Cast(x any) *A_arbace_test_junit_eval197000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000076_A_class)) }; return v }



type A_arbace_test_junit_eval197000076_fn__197000077_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000076_fn__197000077_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000080_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000080_A_New() *A_arbace_test_junit_eval197000080_A { t := &A_arbace_test_junit_eval197000080_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000080_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000080_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000080_A_class }

func (t *A_arbace_test_junit_eval197000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000080_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000080_A); return ok }

func A_arbace_test_junit_eval197000080_A_Cast(x any) *A_arbace_test_junit_eval197000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000080_A_class)) }; return v }



type A_arbace_test_junit_eval197000080_fn__197000081_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000080_fn__197000081_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000084_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000084_A_New() *A_arbace_test_junit_eval197000084_A { t := &A_arbace_test_junit_eval197000084_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000084_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000084_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000084_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000084_A_class }

func (t *A_arbace_test_junit_eval197000084_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000084_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000084_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000084_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000084_A); return ok }

func A_arbace_test_junit_eval197000084_A_Cast(x any) *A_arbace_test_junit_eval197000084_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000084_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000084_A_class)) }; return v }



type A_arbace_test_junit_eval197000084_fn__197000085_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000084_fn__197000085_A_fn_class *jrt.Class



type A_arbace_test_junit_eval197000088_A struct{ jrt.Object }

func A_arbace_test_junit_eval197000088_A_New() *A_arbace_test_junit_eval197000088_A { t := &A_arbace_test_junit_eval197000088_A{}; t.Ctor(); return t }

func (t *A_arbace_test_junit_eval197000088_A) Ctor() {}

func (t *A_arbace_test_junit_eval197000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_test_junit_eval197000088_A) GetClass__Class() *jrt.Class { return A_arbace_test_junit_eval197000088_A_class }

func (t *A_arbace_test_junit_eval197000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_test_junit_eval197000088_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_test_junit_eval197000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_test_junit_eval197000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_test_junit_eval197000088_A); return ok }

func A_arbace_test_junit_eval197000088_A_Cast(x any) *A_arbace_test_junit_eval197000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_test_junit_eval197000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_test_junit_eval197000088_A_class)) }; return v }



type A_arbace_test_junit_eval197000088_fn__197000089_A struct{ a2g_header uint64 }

var A_arbace_test_junit_eval197000088_fn__197000089_A_fn_class *jrt.Class



type A_arbace_test_junit_failure_el_A struct{ a2g_header uint64 }

var A_arbace_test_junit_failure_el_A_fn_class *jrt.Class



type A_arbace_test_junit_finish_case_A struct{ a2g_header uint64 }

var A_arbace_test_junit_finish_case_A_fn_class *jrt.Class



type A_arbace_test_junit_finish_element_A struct{ a2g_header uint64 }

var A_arbace_test_junit_finish_element_A_fn_class *jrt.Class



type A_arbace_test_junit_finish_suite_A struct{ a2g_header uint64 }

var A_arbace_test_junit_finish_suite_A_fn_class *jrt.Class



type A_arbace_test_junit_fn__197000013_A struct{ a2g_header uint64 }

var A_arbace_test_junit_fn__197000013_A_fn_class *jrt.Class



type A_arbace_test_junit_indent_A struct{ a2g_header uint64 }

var A_arbace_test_junit_indent_A_fn_class *jrt.Class



type A_arbace_test_junit_message_el_A struct{ a2g_header uint64 }

var A_arbace_test_junit_message_el_A_fn_class *jrt.Class



type A_arbace_test_junit_package_class_A struct{ a2g_header uint64 }

var A_arbace_test_junit_package_class_A_fn_class *jrt.Class



type A_arbace_test_junit_start_case_A struct{ a2g_header uint64 }

var A_arbace_test_junit_start_case_A_fn_class *jrt.Class



type A_arbace_test_junit_start_element_A struct{ a2g_header uint64 }

var A_arbace_test_junit_start_element_A_fn_class *jrt.Class



type A_arbace_test_junit_start_suite_A struct{ a2g_header uint64 }

var A_arbace_test_junit_start_suite_A_fn_class *jrt.Class



type A_arbace_test_junit_suite_attrs_A struct{ a2g_header uint64 }

var A_arbace_test_junit_suite_attrs_A_fn_class *jrt.Class



type A_arbace_test_junit_test_name_A struct{ a2g_header uint64 }

var A_arbace_test_junit_test_name_A_fn_class *jrt.Class



type A_arbace_test_junit_test_name_fn__197000038_A struct{ a2g_header uint64 }

var A_arbace_test_junit_test_name_fn__197000038_A_fn_class *jrt.Class



type A_arbace_test_junit_with_junit_output_A struct{ a2g_header uint64 }

var A_arbace_test_junit_with_junit_output_A_fn_class *jrt.Class
