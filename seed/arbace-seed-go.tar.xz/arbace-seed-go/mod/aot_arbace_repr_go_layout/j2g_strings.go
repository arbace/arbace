//line j2g_strings.ae:1
package aot_arbace_repr_go_layout

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn18,arbace.repr.go.litkn2,asyn3,lityn13,arbace.stringyn3,strkn3,docks22,arbace.repr.go.convert5,derefkn4,lineks22,arbace.repr.go.convert1,lks22,arbace.repr.go.convert3,rawkn5,lineskn4,elsekn3,brkks21,arbace.repr.go.layout3,brkkn16,layout-late-listkn3,poskn5,spellks2,go5,atextkn6,parensks2,go7,aparenskn5,colonks2,go6,acolonkn4,fullks2,go6,breaksks2,go4,aposks2,go3,endks22,arbace.repr.go.convert3,posks2,go3,posks22,arbace.repr.go.convert4,fullkn3,valkn3,tagkn4,textkn1,xv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn21,arbace.repr.go.layoutm2,R6,s774,Writes Go forms (arbace.repr.go.convert's in-memory forms) as Clojure text (doc/go/SPEC.md §10).\n\n  Mode :lines: every form that begins a Go line is written on that line of the .ae file. A\n  first pass (prepare) decides the breaks: a form whose Go line is after everything written\n  before it starts a new line; it then carries its line as the reader will give it back, a list\n  by itself (the reader's :line), a symbol, vector or @ form by explicit :line metadata, a\n  literal in its parent's :go/breaks (its index, or [index line] when its line is not the one\n  after the last written). Ordinary comments are written as ; comments at the end of\n  their Go line, or as ;; lines. Mode :full writes every node's positions as :go/pos and\n  :go/apos (§10.2) on the same layout.v11,arbace.core13,*loaded-libs*v11,arbace.core8,keyword?v21,arbace.repr.go.layout10,private-nsv11,arbace.core9,namespacev11,arbace.core4,seq?R7,v18,arbace.repr.go.lit4,lit?R8,v21,arbace.repr.go.layout5,iobj?R9,v21,arbace.repr.go.layout7,*stats*v11,arbace.core5,swap!v11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core3,incl0,v11,arbace.core7,vector?R10,v21,arbace.repr.go.layout6,*mode*R11,v11,arbace.core3,seqv11,arbace.core10,sorted-mapv11,arbace.core5,firstv21,arbace.repr.go.layout9,form-linev11,arbace.core5,assocv11,arbace.core9,vary-metaR12,v21,arbace.repr.go.layout4,prepR13,v11,arbace.core3,notv21,arbace.repr.go.layout11,deref-form?R14,v21,arbace.repr.go.layout5,note!R15,v11,arbace.core4,nextR16,v11,arbace.core6,reducev11,arbace.core8,assoc-inV3,V2,R17,R18,V2,R19,R20,V2,R21,R22,v11,arbace.core5,applyR23,v11,arbace.core5,mergev11,arbace.core4,listR24,R25,v11,arbace.core4,intov11,arbace.core3,mapv11,arbace.core9,with-metav21,arbace.repr.go.layout9,key-orderv11,arbace.core7,sort-byv21,arbace.repr.go.layout8,key-rankv11,arbace.core3,strv11,arbace.core6,dissocv11,arbace.core6,removev21,arbace.repr.go.layout8,private?R26,R27,R28,R29,v21,arbace.repr.go.layout11,public-metav21,arbace.repr.go.layout9,sort-keysv11,arbace.core6,filterv11,arbace.core4,keysv11,arbace.core5,true?v11,arbace.core4,not=R30,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core6,empty?V1,R31,v11,arbace.core7,symbol?R31,v11,arbace.core10,chunk-restv13,arbace.string4,joinv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv21,arbace.repr.go.layout4,textv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restR32,v11,arbace.core7,string?v18,arbace.repr.go.lit11,string-textv11,arbace.core5,char?v18,arbace.repr.go.lit9,char-textv11,arbace.core8,integer?v11,arbace.core8,boolean?v11,arbace.core6,ratio?v11,arbace.core7,ex-infov11,arbace.core5,classR33,V4,V2,R16,R25,V2,R17,R18,V2,R19,R20,V2,R21,R22,v11,arbace.core11,map-indexedv11,arbace.core6,vectorv21,arbace.repr.go.layout11,meta-prefixv11,arbace.core4,map?v21,arbace.repr.go.layout9,atom-textv21,arbace.repr.go.layout17,lit-children-metav11,arbace.core6,secondv13,arbace.string12,starts-with?v11,arbace.core4,subsv13,arbace.string4,triml2,v21,arbace.repr.go.layout7,preparev11,arbace.core9,volatile!v21,arbace.repr.go.layout12,comment-textv11,arbace.core6,repeatv11,arbace.core7,vreset!l1,v11,arbace.core3,maxv11,arbace.core9,partition")

var Lit_1 *jrt.String = jrt.Intern("nil")

var Lit_2 *jrt.String = jrt.Intern("N")

var Lit_3 *jrt.String = jrt.Intern("##NaN")

var Lit_4 *jrt.String = jrt.Intern("##Inf")

var Lit_5 *jrt.String = jrt.Intern("##-Inf")

var Lit_6 *jrt.String = jrt.Intern("M")

var Lit_7 *jrt.String = jrt.Intern("can't write ")

var Lit_8 *jrt.String = jrt.Intern("//")

var Lit_9 *jrt.String = jrt.Intern(" ")

var Lit_10 *jrt.String = jrt.Intern("arbace.repr.go.layout$lit_children_meta$fn__1839000085")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.layout$lit_children_meta$fn__1839000085$fn__1839000090")

var Lit_12 *jrt.String = jrt.Intern("arbace.repr.go.layout$lit_children_meta$fn__1839000085$fn__1839000090$fn__1839000094")

var Lit_13 *jrt.String = jrt.Intern("arbace.repr.go.layout$meta_prefix$fn__1839000063")

var Lit_14 *jrt.String = jrt.Intern("arbace.repr.go.layout$meta_prefix$fn__1839000065")

var Lit_15 *jrt.String = jrt.Intern("^")

var Lit_16 *jrt.String = jrt.Intern("^{")

var Lit_17 *jrt.String = jrt.Intern("arbace.repr.go.layout$meta_prefix$iter__1839000071__1839000075")

var Lit_18 *jrt.String = jrt.Intern("} ")

var Lit_19 *jrt.String = jrt.Intern("arbace.repr.go.layout$meta_prefix$iter__1839000071__1839000075$fn__1839000076")

var Lit_20 *jrt.String = jrt.Intern("arbace.repr.go.layout$meta_prefix$iter__1839000071__1839000075$fn__1839000076$fn__1839000077")

var Lit_21 *jrt.String = jrt.Intern("arbace.repr.go.layout$prep$fn__1839000020")

var Lit_22 *jrt.String = jrt.Intern("arbace.repr.go.layout$prep$fn__1839000036")

var Lit_23 *jrt.String = jrt.Intern("arbace.repr.go.layout$prep$fn__1839000020$fn__1839000024")

var Lit_24 *jrt.String = jrt.Intern("arbace.repr.go.layout$prep$fn__1839000020$fn__1839000028")

var Lit_25 *jrt.String = jrt.Intern("arbace.repr.go.layout$public_meta$fn__1839000054")

var Lit_26 *jrt.String = jrt.Intern("arbace.repr.go.layout$sort_keys$fn__1839000050")

var Lit_27 *jrt.String = jrt.Intern("@")

var Lit_28 *jrt.String = jrt.Intern("(")

var Lit_29 *jrt.String = jrt.Intern(")")

var Lit_30 *jrt.String = jrt.Intern("[")

var Lit_31 *jrt.String = jrt.Intern("]")

var Lit_32 *jrt.String = jrt.Intern("{")

var Lit_33 *jrt.String = jrt.Intern("}")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.go.layout$text$iter__1839000099__1839000103")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go.layout$text$iter__1839000099__1839000103$fn__1839000104")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go.layout$text$iter__1839000099__1839000103$fn__1839000104$fn__1839000105")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_file$flush_comments_BANG___1839000117")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_file$newline_to_BANG___1839000119")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_file$emit__1839000121")

var Lit_40 *jrt.String = jrt.Intern("\n")

var Lit_41 *jrt.String = jrt.Intern(" ;")

var Lit_42 *jrt.String = jrt.Intern(";;")

var Lit_43 *jrt.String = jrt.Intern(" ;;")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_package$iter__1839000141__1839000145")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_package$iter__1839000157__1839000161")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_package$iter__1839000141__1839000145$fn__1839000146")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_package$iter__1839000141__1839000145$fn__1839000146$fn__1839000147")

var Lit_48 *jrt.String = jrt.Intern("\n  ")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_package$iter__1839000157__1839000161$fn__1839000162")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_package$iter__1839000157__1839000161$fn__1839000162$fn__1839000163")

var Lit_51 *jrt.String = jrt.Intern("(load ")

var Lit_52 *jrt.String = jrt.Intern(")\n")

var Lit_53 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,kyn1,xkn5,lineskn7,dynamicyn6,cursoryn5,formskn8,declaredkn5,aliaskn6,externkn5,constkn3,varkn6,assignks2,go7,groupedkn3,tagkn3,valkn4,instks2,go3,viaks2,go3,tagyn2,ksyn6,Stringyn8,commentsyn6,ns-symyn8,pkg-formyn5,loadsv11,arbace.core5,in-nsMyn21,arbace.repr.go.layoutm2,R0,s774,Writes Go forms (arbace.repr.go.convert's in-memory forms) as Clojure text (doc/go/SPEC.md §10).\n\n  Mode :lines: every form that begins a Go line is written on that line of the .ae file. A\n  first pass (prepare) decides the breaks: a form whose Go line is after everything written\n  before it starts a new line; it then carries its line as the reader will give it back, a list\n  by itself (the reader's :line), a symbol, vector or @ form by explicit :line metadata, a\n  literal in its parent's :go/breaks (its index, or [index line] when its line is not the one\n  after the last written). Ordinary comments are written as ; comments at the end of\n  their Go line, or as ;; lines. Mode :full writes every node's positions as :go/pos and\n  :go/apos (§10.2) on the same layout.m2,R0,s774,Writes Go forms (arbace.repr.go.convert's in-memory forms) as Clojure text (doc/go/SPEC.md §10).\n\n  Mode :lines: every form that begins a Go line is written on that line of the .ae file. A\n  first pass (prepare) decides the breaks: a form whose Go line is after everything written\n  before it starts a new line; it then carries its line as the reader will give it back, a list\n  by itself (the reader's :line), a symbol, vector or @ form by explicit :line metadata, a\n  literal in its parent's :go/breaks (its index, or [index line] when its line is not the one\n  after the last written). Ordinary comments are written as ; comments at the end of\n  their Go line, or as ;; lines. Mode :full writes every node's positions as :go/pos and\n  :go/apos (§10.2) on the same layout.R1,v21,arbace.repr.go.layout10,private-nsm8,R2,TR3,i15,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout8,private?m10,R2,TR6,L1,V1,R7,R3,i17,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout5,iobj?m10,R2,TR6,L1,V1,R8,R3,i19,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout11,deref-form?m10,R2,TR6,L1,V1,R8,R3,i21,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout9,form-linem10,R6,L1,V1,R8,R0,s41,The Go line a form begins on, when known.R3,i23,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout6,*mode*R9,m8,R10,TR3,i30,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout7,*stats*m8,R10,TR3,i31,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout5,note!m10,R2,TR6,L1,V1,R7,R3,i33,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout4,prepm12,R2,TR6,L1,V2,R8,R11,R0,s84,Returns [x' cursor] for x written with the cursor (the last line written) at cursor.R3,i37,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout7,preparem10,R6,L1,V1,R12,R0,s58,The top-level forms with their breaks, starting at line 1.R3,i83,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout4,textm8,R13,TR3,i98,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout9,key-orderV13,R3,R14,R15,R16,R17,R18,R19,R20,R21,R22,R23,R24,R0,m8,R2,TR3,i100,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout8,key-rankm10,R2,TR6,L1,V1,R7,R3,i103,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout9,sort-keysm10,R2,TR6,L1,V1,R25,R3,i107,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout11,public-metam10,R6,L1,V1,R8,R0,s27,The metadata written for x.R3,i110,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout11,meta-prefixm10,R2,TR6,L1,V1,R8,R3,i123,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout9,atom-textm10,R2,TR6,L1,V1,R8,R3,i141,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout17,lit-children-metam12,R2,TR6,L1,V1,R8,R0,s172,Mode :full: the metadata of a list or vector for its literal children (positions,\n  spellings, parentheses, key colons), for one written in metadata (prep does the others).R3,i161,R4,i1,R5,s24,arbace/repr/go/layout.aem10,R6,L1,V1,R8,R0,s58,x as text on one line (metadata values, the package file).R3,i172,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout12,comment-textm12,R2,TR6,L1,V1,Myn1,tm2,R20,R26,R0,s44,A Go comment line as the text after ; or ;;.R3,i188,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout10,write-filem10,R6,L1,V2,R12,R27,R0,s82,The text of a Go file's forms (prepared here) with its comments {line [text ...]}.R3,i195,R4,i1,R5,s24,arbace/repr/go/layout.aev21,arbace.repr.go.layout13,write-packagem10,R6,L1,V3,R28,R29,R30,R0,s83,The text of a package file: ns, go/package with one option per line, and the loads.R3,i252,R4,i1,R5,s24,arbace/repr/go/layout.ae")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.go.layout$eval1839000004$loading__1927001464__auto____1839000005")

var Lit_55 *jrt.String = jrt.Intern("arbace.repr.go.layout$eval1839000008$fn__1839000009")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.go.convert")

var Lit_57 *jrt.String = jrt.Intern("arbace.repr.go.layout$private_QMARK_")

var Lit_58 *jrt.String = jrt.Intern("arbace.repr.go.layout$iobj_QMARK_")

var Lit_59 *jrt.String = jrt.Intern("arbace.repr.go.layout$deref_form_QMARK_")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.go.layout$form_line")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.go.layout$note_BANG_")

var Lit_62 *jrt.String = jrt.Intern("arbace.repr.go.layout$prep")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.go.layout$prepare")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.layout$key_rank")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.layout$sort_keys")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.layout$public_meta")

var Lit_67 *jrt.String = jrt.Intern("arbace.repr.go.layout$meta_prefix")

var Lit_68 *jrt.String = jrt.Intern("arbace.repr.go.layout$atom_text")

var Lit_69 *jrt.String = jrt.Intern("arbace.repr.go.layout$lit_children_meta")

var Lit_70 *jrt.String = jrt.Intern("arbace.repr.go.layout$text")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.go.layout$comment_text")

var Lit_72 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_file")

var Lit_73 *jrt.String = jrt.Intern("arbace.repr.go.layout$write_package")
