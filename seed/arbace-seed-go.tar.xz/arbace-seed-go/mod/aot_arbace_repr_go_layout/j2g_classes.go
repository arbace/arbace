//line j2g_classes.ae:1
package aot_arbace_repr_go_layout

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_repr_go_layout_atom_text_A_class, Name: "arbace.repr.go.layout$atom_text", Modifiers: 25, Simple: "atom_text", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_atom_text_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_comment_text_A_class, Name: "arbace.repr.go.layout$comment_text", Modifiers: 25, Simple: "comment_text", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_comment_text_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_deref_form_QMARK__A_class, Name: "arbace.repr.go.layout$deref_form_QMARK_", Modifiers: 25, Simple: "deref_form_QMARK_", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_deref_form_QMARK__A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_class, Name: "arbace.repr.go.layout$eval1839000004$loading__1927001464__auto____1839000005", Modifiers: 25, Simple: "loading__1927001464__auto____1839000005", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_eval1839000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_class, Name: "arbace.repr.go.layout$eval1839000008$fn__1839000009", Modifiers: 25, Simple: "fn__1839000009", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_eval1839000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_form_line_A_class, Name: "arbace.repr.go.layout$form_line", Modifiers: 25, Simple: "form_line", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_form_line_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_iobj_QMARK__A_class, Name: "arbace.repr.go.layout$iobj_QMARK_", Modifiers: 25, Simple: "iobj_QMARK_", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_iobj_QMARK__A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_key_rank_A_class, Name: "arbace.repr.go.layout$key_rank", Modifiers: 25, Simple: "key_rank", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_key_rank_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_lit_children_meta_A_class, Name: "arbace.repr.go.layout$lit_children_meta", Modifiers: 25, Simple: "lit_children_meta", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_lit_children_meta_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_class, Name: "arbace.repr.go.layout$lit_children_meta$fn__1839000085", Modifiers: 25, Simple: "fn__1839000085", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_lit_children_meta_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_class, Name: "arbace.repr.go.layout$lit_children_meta$fn__1839000085$fn__1839000090", Modifiers: 25, Simple: "fn__1839000090", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_class, Name: "arbace.repr.go.layout$lit_children_meta$fn__1839000085$fn__1839000090$fn__1839000094", Modifiers: 25, Simple: "fn__1839000094", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_meta_prefix_A_class, Name: "arbace.repr.go.layout$meta_prefix", Modifiers: 25, Simple: "meta_prefix", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_meta_prefix_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_class, Name: "arbace.repr.go.layout$meta_prefix$fn__1839000063", Modifiers: 25, Simple: "fn__1839000063", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_meta_prefix_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_class, Name: "arbace.repr.go.layout$meta_prefix$fn__1839000065", Modifiers: 25, Simple: "fn__1839000065", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_meta_prefix_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_class, Name: "arbace.repr.go.layout$meta_prefix$iter__1839000071__1839000075", Modifiers: 25, Simple: "iter__1839000071__1839000075", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_meta_prefix_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_class, Name: "arbace.repr.go.layout$meta_prefix$iter__1839000071__1839000075$fn__1839000076", Modifiers: 25, Simple: "fn__1839000076", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_class, Name: "arbace.repr.go.layout$meta_prefix$iter__1839000071__1839000075$fn__1839000076$fn__1839000077", Modifiers: 25, Simple: "fn__1839000077", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_note_BANG__A_class, Name: "arbace.repr.go.layout$note_BANG_", Modifiers: 25, Simple: "note_BANG_", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_note_BANG__A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_prep_A_class, Name: "arbace.repr.go.layout$prep", Modifiers: 25, Simple: "prep", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_prep_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_prep_fn__1839000020_A_class, Name: "arbace.repr.go.layout$prep$fn__1839000020", Modifiers: 25, Simple: "fn__1839000020", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_prep_fn__1839000020_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_prep_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_class, Name: "arbace.repr.go.layout$prep$fn__1839000020$fn__1839000024", Modifiers: 25, Simple: "fn__1839000024", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_prep_fn__1839000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_class, Name: "arbace.repr.go.layout$prep$fn__1839000020$fn__1839000028", Modifiers: 25, Simple: "fn__1839000028", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_prep_fn__1839000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_prep_fn__1839000036_A_class, Name: "arbace.repr.go.layout$prep$fn__1839000036", Modifiers: 25, Simple: "fn__1839000036", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_prep_fn__1839000036_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_prep_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_prepare_A_class, Name: "arbace.repr.go.layout$prepare", Modifiers: 25, Simple: "prepare", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_prepare_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_private_QMARK__A_class, Name: "arbace.repr.go.layout$private_QMARK_", Modifiers: 25, Simple: "private_QMARK_", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_private_QMARK__A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_public_meta_A_class, Name: "arbace.repr.go.layout$public_meta", Modifiers: 25, Simple: "public_meta", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_public_meta_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_public_meta_fn__1839000054_A_class, Name: "arbace.repr.go.layout$public_meta$fn__1839000054", Modifiers: 25, Simple: "fn__1839000054", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_public_meta_fn__1839000054_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_public_meta_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_sort_keys_A_class, Name: "arbace.repr.go.layout$sort_keys", Modifiers: 25, Simple: "sort_keys", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_sort_keys_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_class, Name: "arbace.repr.go.layout$sort_keys$fn__1839000050", Modifiers: 25, Simple: "fn__1839000050", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_sort_keys_fn__1839000050_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_sort_keys_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_text_A_class, Name: "arbace.repr.go.layout$text", Modifiers: 25, Simple: "text", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_text_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_class, Name: "arbace.repr.go.layout$text$iter__1839000099__1839000103", Modifiers: 25, Simple: "iter__1839000099__1839000103", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_class, Name: "arbace.repr.go.layout$text$iter__1839000099__1839000103$fn__1839000104", Modifiers: 25, Simple: "fn__1839000104", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_class, Name: "arbace.repr.go.layout$text$iter__1839000099__1839000103$fn__1839000104$fn__1839000105", Modifiers: 25, Simple: "fn__1839000105", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_file_A_class, Name: "arbace.repr.go.layout$write_file", Modifiers: 25, Simple: "write_file", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_file_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_file_emit__1839000121_A_class, Name: "arbace.repr.go.layout$write_file$emit__1839000121", Modifiers: 25, Simple: "emit__1839000121", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_file_emit__1839000121_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_write_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_class, Name: "arbace.repr.go.layout$write_file$flush_comments_BANG___1839000117", Modifiers: 25, Simple: "flush_comments_BANG___1839000117", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_write_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_class, Name: "arbace.repr.go.layout$write_file$newline_to_BANG___1839000119", Modifiers: 25, Simple: "newline_to_BANG___1839000119", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_write_file_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_package_A_class, Name: "arbace.repr.go.layout$write_package", Modifiers: 25, Simple: "write_package", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_package_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_class, Name: "arbace.repr.go.layout$write_package$iter__1839000141__1839000145", Modifiers: 25, Simple: "iter__1839000141__1839000145", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_write_package_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_class, Name: "arbace.repr.go.layout$write_package$iter__1839000141__1839000145$fn__1839000146", Modifiers: 25, Simple: "fn__1839000146", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_class, Name: "arbace.repr.go.layout$write_package$iter__1839000141__1839000145$fn__1839000146$fn__1839000147", Modifiers: 25, Simple: "fn__1839000147", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_class, Name: "arbace.repr.go.layout$write_package$iter__1839000157__1839000161", Modifiers: 25, Simple: "iter__1839000157__1839000161", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_write_package_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_class, Name: "arbace.repr.go.layout$write_package$iter__1839000157__1839000161$fn__1839000162", Modifiers: 25, Simple: "fn__1839000162", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_class, Name: "arbace.repr.go.layout$write_package$iter__1839000157__1839000161$fn__1839000162$fn__1839000163", Modifiers: 25, Simple: "fn__1839000163", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A", Source: "layout.ae", Declaring: &A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_repr_go_layout_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_layout_A_New()}; return nil }

var A_arbace_repr_go_layout_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_layout_A_new}

var A_arbace_repr_go_layout_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.layout", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_A"})

func init() { i := A_arbace_repr_go_layout_A_class.Info(); i.IsInstance = A_arbace_repr_go_layout_A_InstanceOf; i.Init = A_arbace_repr_go_layout_A_Init; i.Table = A_arbace_repr_go_layout_A_members }

var A_arbace_repr_go_layout_atom_text_A_class *jrt.Class

var A_arbace_repr_go_layout_comment_text_A_class *jrt.Class

var A_arbace_repr_go_layout_deref_form_QMARK__A_class *jrt.Class

func A_arbace_repr_go_layout_eval1839000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_layout_eval1839000004_A_New()}; return nil }

var A_arbace_repr_go_layout_eval1839000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_layout_eval1839000004_A_new}

var A_arbace_repr_go_layout_eval1839000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.layout$eval1839000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_layout_A_class, Simple: "eval1839000004", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_eval1839000004_A"})

func init() { i := A_arbace_repr_go_layout_eval1839000004_A_class.Info(); i.IsInstance = A_arbace_repr_go_layout_eval1839000004_A_InstanceOf; i.Table = A_arbace_repr_go_layout_eval1839000004_A_members }

var A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_class *jrt.Class

func A_arbace_repr_go_layout_eval1839000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_layout_eval1839000008_A_New()}; return nil }

var A_arbace_repr_go_layout_eval1839000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_go_layout_eval1839000008_A_new}

var A_arbace_repr_go_layout_eval1839000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.layout$eval1839000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_go_layout_A_class, Simple: "eval1839000008", Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout_eval1839000008_A"})

func init() { i := A_arbace_repr_go_layout_eval1839000008_A_class.Info(); i.IsInstance = A_arbace_repr_go_layout_eval1839000008_A_InstanceOf; i.Table = A_arbace_repr_go_layout_eval1839000008_A_members }

var A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_class *jrt.Class

var A_arbace_repr_go_layout_form_line_A_class *jrt.Class

var A_arbace_repr_go_layout_iobj_QMARK__A_class *jrt.Class

var A_arbace_repr_go_layout_key_rank_A_class *jrt.Class

var A_arbace_repr_go_layout_lit_children_meta_A_class *jrt.Class

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_class *jrt.Class

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_class *jrt.Class

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_class *jrt.Class

var A_arbace_repr_go_layout_meta_prefix_A_class *jrt.Class

var A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_class *jrt.Class

var A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_class *jrt.Class

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_class *jrt.Class

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_class *jrt.Class

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_class *jrt.Class

var A_arbace_repr_go_layout_note_BANG__A_class *jrt.Class

var A_arbace_repr_go_layout_prep_A_class *jrt.Class

var A_arbace_repr_go_layout_prep_fn__1839000020_A_class *jrt.Class

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_class *jrt.Class

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_class *jrt.Class

var A_arbace_repr_go_layout_prep_fn__1839000036_A_class *jrt.Class

var A_arbace_repr_go_layout_prepare_A_class *jrt.Class

var A_arbace_repr_go_layout_private_QMARK__A_class *jrt.Class

var A_arbace_repr_go_layout_public_meta_A_class *jrt.Class

var A_arbace_repr_go_layout_public_meta_fn__1839000054_A_class *jrt.Class

var A_arbace_repr_go_layout_sort_keys_A_class *jrt.Class

var A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_class *jrt.Class

var A_arbace_repr_go_layout_text_A_class *jrt.Class

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_class *jrt.Class

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_class *jrt.Class

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_class *jrt.Class

var A_arbace_repr_go_layout_write_file_A_class *jrt.Class

var A_arbace_repr_go_layout_write_file_emit__1839000121_A_class *jrt.Class

var A_arbace_repr_go_layout_write_file_flush_comments_BANG___1839000117_A_class *jrt.Class

var A_arbace_repr_go_layout_write_file_newline_to_BANG___1839000119_A_class *jrt.Class

var A_arbace_repr_go_layout_write_package_A_class *jrt.Class

var A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_A_class *jrt.Class

var A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_A_class *jrt.Class

var A_arbace_repr_go_layout_write_package_iter__1839000141__1839000145_fn__1839000146_fn__1839000147_A_class *jrt.Class

var A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_A_class *jrt.Class

var A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_A_class *jrt.Class

var A_arbace_repr_go_layout_write_package_iter__1839000157__1839000161_fn__1839000162_fn__1839000163_A_class *jrt.Class

func A_arbace_repr_go_layout__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_repr_go_layout__init_A_Load__O()}; return nil }

func A_arbace_repr_go_layout__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_go_layout__init_A_New()}; return nil }

var A_arbace_repr_go_layout__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_repr_go_layout__init_A_invoke, New: A_arbace_repr_go_layout__init_A_new}

var A_arbace_repr_go_layout__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.go.layout__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_go_layout.A_arbace_repr_go_layout__init_A", Source: "layout.ae"})

func init() { i := A_arbace_repr_go_layout__init_A_class.Info(); i.IsInstance = A_arbace_repr_go_layout__init_A_InstanceOf; i.Init = A_arbace_repr_go_layout__init_A_Init; i.Table = A_arbace_repr_go_layout__init_A_members }
