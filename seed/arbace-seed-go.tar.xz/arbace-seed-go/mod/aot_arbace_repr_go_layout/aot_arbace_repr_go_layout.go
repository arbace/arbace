//line aot_arbace_repr_go_layout.ae:1
package aot_arbace_repr_go_layout

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_lit"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_New() *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_layout_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_1, A_arbace_repr_go_layout_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_New() *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_repr_go_layout_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(), A_arbace_repr_go_layout_A_const_9) }















func A_arbace_repr_go_layout_private_QMARK__A_New() *A_arbace_repr_go_layout_private_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_private_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_repr_go_layout_private_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_repr_go_layout_private_QMARK__A) Invoke_O_O__O(self, k__0 any) any { var and__1927000168__auto____2 any; var root_20 any = A_arbace_repr_go_layout_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = k__0; if linked_21 == nil { and__1927000168__auto____2 = ifn_22.Invoke_O__O(arg_23) } else { and__1927000168__auto____2 = linked_21.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_20, arg_23) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_repr_go_layout_A_const_11.GetRawRoot__O(); var tmp2 any; var root_24 any = A_arbace_repr_go_layout_A_const_12.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = k__0; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_24, arg_27) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_layout_iobj_QMARK__A_New() *A_arbace_repr_go_layout_iobj_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_iobj_QMARK__A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_go_layout_iobj_QMARK__A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_go_layout_iobj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.IObj_InstanceOf(x__0)).Ref() }

func A_arbace_repr_go_layout_deref_form_QMARK__A_New() *A_arbace_repr_go_layout_deref_form_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_deref_form_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_repr_go_layout_deref_form_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_repr_go_layout_deref_form_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_28 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = x__0; if linked_29 == nil { and__1927000168__auto____2 = ifn_30.Invoke_O__O(arg_31) } else { and__1927000168__auto____2 = linked_29.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_28, arg_31) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 *lang.Keyword = A_arbace_repr_go_layout_A_const_14; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_layout_form_line_A_New() *A_arbace_repr_go_layout_form_line_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_form_line_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_repr_go_layout_form_line_A) Ctor() {}
//line :23:1
func (t *A_arbace_repr_go_layout_form_line_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_32 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_34 lang.IFn
	if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = x__0; if linked_33 == nil { tmp1 = ifn_34.Invoke_O__O(arg_35) } else { tmp1 = linked_33.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_32, arg_35) }
//line :26:1
	if jrt.J2g_Truth(tmp1) {
		return A_arbace_repr_go_layout_A_const_16.Invoke_O__O(x__0) } else {
//line :26:1
			var tmp2 any; var root_36 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_38 lang.IFn

			if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = x__0; if linked_37 == nil { tmp2 = ifn_38.Invoke_O__O(arg_39) } else { tmp2 = linked_37.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_36, arg_39) }
//line :26:1
			if jrt.J2g_Truth(tmp2) {

				var tmp3 *lang.Keyword = A_arbace_repr_go_layout_A_const_18; return tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else {
//line :26:1
					return nil
				}
		}
}



func A_arbace_repr_go_layout_note_BANG__A_New() *A_arbace_repr_go_layout_note_BANG__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_note_BANG__A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_repr_go_layout_note_BANG__A) Ctor() {}
//line :33:1
func (t *A_arbace_repr_go_layout_note_BANG__A) Invoke_O_O__O(self, k__0 any) any { if jrt.J2g_Truth(A_arbace_repr_go_layout_A_const_19.Get__O()) { var root_40 any = A_arbace_repr_go_layout_A_const_20.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = A_arbace_repr_go_layout_A_const_19.Get__O(); var arg_44 any = A_arbace_repr_go_layout_A_const_21.GetRawRoot__O(); var arg_45 any = k__0; var arg_46 any; var root_47 any = A_arbace_repr_go_layout_A_const_22.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_repr_go_layout_A_const_23.GetRawRoot__O(); var arg_51 any = A_arbace_repr_go_layout_A_const_24; if linked_48 == nil { arg_46 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { arg_46 = linked_48.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; if linked_41 == nil { return ifn_42.Invoke_O_O_O_O__O(arg_43, arg_44, arg_45, arg_46) } else { return linked_41.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_40, arg_43, arg_44, arg_45, arg_46) } } else { return nil } }



func A_arbace_repr_go_layout_prep_A_New() *A_arbace_repr_go_layout_prep_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_repr_go_layout_prep_A) Ctor() {}
//line :37:1
func (t *A_arbace_repr_go_layout_prep_A) Invoke_O_O_O__O(self, x__0, cursor__1 any) any {


	var tmp1 any; var or__1927000174__auto____3 any; var root_52 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_54 lang.IFn
	if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = x__0; if linked_53 == nil { or__1927000174__auto____3 = ifn_54.Invoke_O__O(arg_55) } else { or__1927000174__auto____3 = linked_53.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_52, arg_55) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_56 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = x__0; if linked_57 == nil { tmp1 = ifn_58.Invoke_O__O(arg_59) } else { tmp1 = linked_57.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_56, arg_59) } }
//line :40:1
	if jrt.J2g_Truth(tmp1) {

		var tmp2 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0))) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { var lines_QMARK___3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_28); var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); var vec__1839000017__5 any; var tmp3 any = A_arbace_repr_go_layout_prep_fn__1839000020_A_New_O_O_Z(cursor__1, x__0, lines_QMARK___3); var tmp4 *jrt.Class
			var fncls__199 /*line :42:1*/*jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class




			if fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class = fncls__199d; tmp4 = fncls__199d } else { tmp4 = fncls__199 }; vec__1839000017__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :42:1
			var kids__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(1), nil); var breaks__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(2), nil); var apos__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(3), nil); var afull__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(4), nil); var x_SINGLEQUOTE___11 any; var tmp5 any; var root_200 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_202 lang.IFn
































			if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = x__0; if linked_201 == nil { tmp5 = ifn_202.Invoke_O__O(arg_203) } else { tmp5 = linked_201.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_200, arg_203) }; if jrt.J2g_Truth(tmp5) { var root_204 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = A_arbace_repr_go_layout_A_const_49.GetRawRoot__O(); var arg_208 any = kids__6; if linked_205 == nil { x_SINGLEQUOTE___11 = ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { x_SINGLEQUOTE___11 = linked_205.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } } else { x_SINGLEQUOTE___11 = kids__6 }
//line :42:1
			var m__12 any; var G__1839000034__12_ any = m__4; var G__1839000034__13_ any; var tmp6 any
			var and__1927000168__auto____13 bool = lines_QMARK___3

































			if and__1927000168__auto____13 { var root_209 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = breaks__8; if linked_210 == nil { tmp6 = ifn_211.Invoke_O__O(arg_212) } else { tmp6 = linked_210.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_209, arg_212) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____13).Ref() }
//line :76:1
			if jrt.J2g_Truth(tmp6) {
				var root_213 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_215 lang.IFn; if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any = G__1839000034__12_; var arg_217 any = A_arbace_repr_go_layout_A_const_50; var arg_218 any = breaks__8; if linked_214 == nil { G__1839000034__13_ = ifn_215.Invoke_O_O_O__O(arg_216, arg_217, arg_218) } else { G__1839000034__13_ = linked_214.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_213, arg_216, arg_217, arg_218) } } else {
//line :76:1
					G__1839000034__13_ = G__1839000034__12_ }
//line :42:1
			var G__1839000034__14_ any; var tmp7 any; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_51)



































			if and__1927000168__auto____14 { var root_219 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = apos__9; if linked_220 == nil { tmp7 = ifn_221.Invoke_O__O(arg_222) } else { tmp7 = linked_220.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_219, arg_222) } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }
//line :76:1
			if jrt.J2g_Truth(tmp7) {

				var root_223 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = G__1839000034__13_; var arg_227 any = A_arbace_repr_go_layout_A_const_52; var arg_228 any = apos__9; if linked_224 == nil { G__1839000034__14_ = ifn_225.Invoke_O_O_O__O(arg_226, arg_227, arg_228) } else { G__1839000034__14_ = linked_224.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_223, arg_226, arg_227, arg_228) } } else {
//line :76:1
					G__1839000034__14_ = G__1839000034__13_ }; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_51) {


						var root_229 any = A_arbace_repr_go_layout_A_const_53.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = G__1839000034__14_; var arg_233 any; var root_234 any = A_arbace_repr_go_layout_A_const_54.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_238 any; var root_240 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var tmp8 any = A_arbace_repr_go_layout_prep_fn__1839000036_A_New(); var tmp9 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class; if fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class = fncls__252d; tmp9 = fncls__252d } else { tmp9 = fncls__252 }; arg_243 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); if linked_241 == nil { arg_238 = ifn_242.Invoke_O__O(arg_243) } else { arg_238 = linked_241.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_240, arg_243) }; var arg_239 any = afull__10; if linked_235 == nil { arg_233 = ifn_236.Invoke_O_O_O__O(arg_237, arg_238, arg_239) } else { arg_233 = linked_235.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_234, arg_237, arg_238, arg_239) }; if linked_230 == nil { m__12 = ifn_231.Invoke_O_O__O(arg_232, arg_233) } else { m__12 = linked_230.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_229, arg_232, arg_233) } } else {
//line :76:1
							m__12 = G__1839000034__14_ }
//line :42:1
			var tmp10 any; var root_253 any = A_arbace_repr_go_layout_A_const_56.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_255 lang.IFn





































			if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = x_SINGLEQUOTE___11; var arg_257 any = m__12; if linked_254 == nil { tmp10 = ifn_255.Invoke_O_O__O(arg_256, arg_257) } else { tmp10 = linked_254.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_253, arg_256, arg_257) }
//line :42:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp10, cursor__7) } } else {
//line :40:1
				if A_arbace_repr_go_layout_A_const_41 != nil { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { return nil
				}
			}
}



func A_arbace_repr_go_layout_prep_fn__1839000020_A_New_O_O_Z(p0, p1 any, p2 bool) *A_arbace_repr_go_layout_prep_fn__1839000020_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_A{}; t.Ctor_O_O_Z(p0, p1, p2); return t }
//line :47:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_A) Ctor_O_O_Z(c__cursor, c__x any, c__lines_QMARK_ bool) { t.F_cursor = c__cursor; t.F_x = c__x; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :47:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var xs__2 any; var root_60 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var t_ any = t.F_x; t.F_x = nil; arg_63 = t_; if linked_61 == nil { xs__2 = ifn_62.Invoke_O__O(arg_63) } else { xs__2 = linked_61.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_60, arg_63) }; var cursor__3 any; var t__2 any = t.F_cursor; t.F_cursor = nil; cursor__3 = t__2; var acc__4 any = lang.PersistentVector_EMPTY.Ref(); var breaks__5 any = lang.PersistentVector_EMPTY.Ref(); var apos__6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O(); var afull__7 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var temp__1927000408__auto____8 any; var root_67 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_69 lang.IFn
											if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = xs__2; if linked_68 == nil { temp__1927000408__auto____8 = ifn_69.Invoke_O__O(arg_70) } else { temp__1927000408__auto____8 = linked_68.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_67, arg_70) }; if jrt.J2g_Truth(temp__1927000408__auto____8) { var c__9 any = temp__1927000408__auto____8; var l__10 any; var root_71 any = A_arbace_repr_go_layout_A_const_32.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_repr_go_layout_form_line_A_fn_class); var ifn_73 lang.IFn
												if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = c__9; if linked_72 == nil { l__10 = ifn_73.Invoke_O__O(arg_74) } else { l__10 = linked_72.(*A_arbace_repr_go_layout_form_line_A).Invoke_O_O__O(root_71, arg_74) }
//line :48:1
		var cursor0__11 any = cursor__3; var brk__12 any
		var and__1927000168__auto____12 any = l__10

		if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp1 bool; var na_75 any = l__10; var na_76 any = cursor__3; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_75); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_76) }; tmp2 = tmp3; if tmp2 { var n0_77 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); var n1_78 int64 = jrt.NN(jrt.Long_Cast(na_76)).LongValue__J(); tmp1 = n0_77 > n1_78 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_75); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_76) }; tmp4 = tmp5; if tmp4 { var n0_77_2 float64 = jrt.NN(jrt.Double_Cast(na_75)).DoubleValue__D(); var n1_78_2 float64 = jrt.NN(jrt.Double_Cast(na_76)).DoubleValue__D(); tmp1 = n1_78_2 < n0_77_2 } else { tmp1 = lang.Numbers_Gt_O_O__Z_NoInit(na_75, na_76) } }; brk__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else { brk__12 = and__1927000168__auto____12 }
//line :48:1
		var c__13 any; var tmp6 any; var root_80 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_82 lang.IFn




		if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = c__9; if linked_81 == nil { tmp6 = ifn_82.Invoke_O__O(arg_83) } else { tmp6 = linked_81.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_80, arg_83) }
//line :52:1
		if jrt.J2g_Truth(tmp6) {
			var root_84 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = c__9; var arg_88 any = A_arbace_repr_go_layout_A_const_34; var arg_89 any = brk__12; if linked_85 == nil { c__13 = ifn_86.Invoke_O_O_O__O(arg_87, arg_88, arg_89) } else { c__13 = linked_85.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_84, arg_87, arg_88, arg_89) } } else {
//line :52:1
				var tmp7 any; var root_90 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_92 lang.IFn

				if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = c__9; if linked_91 == nil { tmp7 = ifn_92.Invoke_O__O(arg_93) } else { tmp7 = linked_91.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_90, arg_93) }
//line :52:1
				if jrt.J2g_Truth(tmp7) {


					var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_35.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_New_O_O_O_O_Z(l__10, brk__12, cursor__3, c__9, t.F_lines_QMARK_); var tmp10 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class = fncls__146d; tmp10 = fncls__146d } else { tmp10 = fncls__146 }; c__13 = tmp8.Invoke_O_O__O(c__9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) } else {
//line :52:1
						if A_arbace_repr_go_layout_A_const_41 != nil { c__13 = c__9 } else { c__13 = nil } } }
//line :48:1
		var cursor__14 any













		if jrt.J2g_Truth(brk__12) { cursor__14 = l__10 } else { cursor__14 = cursor__3 }
//line :48:1
		var vec__1839000021__15 any; var root_147 any = A_arbace_repr_go_layout_A_const_42.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, A_arbace_repr_go_layout_prep_A_fn_class); var ifn_149 lang.IFn














		if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = c__13; var arg_151 any = cursor__14; if linked_148 == nil { vec__1839000021__15 = ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { vec__1839000021__15 = linked_148.(*A_arbace_repr_go_layout_prep_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) }
//line :48:1
		var c__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000021__15, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000021__15, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp12 any; var root_152 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_154 lang.IFn















		if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = xs__2; if linked_153 == nil { tmp12 = ifn_154.Invoke_O__O(arg_155) } else { tmp12 = linked_153.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_152, arg_155) }; var tmp13 any = tmp12; var tmp14 any; var root_156 any = A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = acc__4; var arg_160 any = c__16; if linked_157 == nil { tmp14 = ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { tmp14 = linked_157.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_156, arg_159, arg_160) }; var tmp15 any = tmp14; var tmp16 any; var tmp17 any
		var and__1927000168__auto____18 any = brk__12

		if jrt.J2g_Truth(and__1927000168__auto____18) { var root_161 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = c__16; if linked_162 == nil { tmp17 = ifn_163.Invoke_O__O(arg_164) } else { tmp17 = linked_162.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_161, arg_164) } } else { tmp17 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp17) { var root_165 any = A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = breaks__5; var arg_169 any; var tmp18 jrt.Number_I; var na_170 any = cursor0__11; if jrt.Long_InstanceOf(na_170) { var n0_171 int64 = jrt.NN(jrt.Long_Cast(na_170)).LongValue__J(); if n0_171 == 9223372036854775807 { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_170) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_171 + 1)) } } else { if jrt.Double_InstanceOf(na_170) { var n0_171_2 float64 = jrt.NN(jrt.Double_Cast(na_170)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_171_2 + 1.0)) } else { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_170) } }; if lang.Util_Equiv_O_O__Z_NoInit(l__10, tmp18) { arg_169 = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref() } else { arg_169 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(), l__10) }; if linked_166 == nil { tmp16 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { tmp16 = linked_166.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) } } else { tmp16 = breaks__5 }
//line :64:1
		var tmp19 any = tmp16; var tmp20 any; var tmp21 any; var and__1927000168__auto____18_2 any; var root_172 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_174 lang.IFn



		if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = c__16; if linked_173 == nil { and__1927000168__auto____18_2 = ifn_174.Invoke_O__O(arg_175) } else { and__1927000168__auto____18_2 = linked_173.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_172, arg_175) }; if jrt.J2g_Truth(and__1927000168__auto____18_2) { tmp21 = A_arbace_repr_go_layout_A_const_44.Invoke_O__O(c__16) } else { tmp21 = and__1927000168__auto____18_2 }; if jrt.J2g_Truth(tmp21) { var root_176 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = apos__6; var arg_180 any = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(); var arg_181 any = A_arbace_repr_go_layout_A_const_44.Invoke_O__O(c__16); if linked_177 == nil { tmp20 = ifn_178.Invoke_O_O_O__O(arg_179, arg_180, arg_181) } else { tmp20 = linked_177.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_176, arg_179, arg_180, arg_181) } } else { tmp20 = apos__6 }
//line :64:1
		var tmp22 any = tmp20; var tmp23 any; var tmp24 any; var root_182 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_184 lang.IFn





		if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = c__16; if linked_183 == nil { tmp24 = ifn_184.Invoke_O__O(arg_185) } else { tmp24 = linked_183.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(tmp24) {
			var root_186 any = A_arbace_repr_go_layout_A_const_45.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var tmp25 any = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_New_J_O(i__1, c__16); var tmp26 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class = fncls__198d; tmp26 = fncls__198d } else { tmp26 = fncls__198 }; arg_189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var arg_190 any = afull__7; var arg_191 any = A_arbace_repr_go_layout_A_const_47; if linked_187 == nil { tmp23 = ifn_188.Invoke_O_O_O__O(arg_189, arg_190, arg_191) } else { tmp23 = linked_187.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_186, arg_189, arg_190, arg_191) } } else {
//line :70:1
				tmp23 = afull__7 }
//line :64:1
		i__1, xs__2, cursor__3, acc__4, breaks__5, apos__6, afull__7 = tmp11, tmp13, cursor__17, tmp15, tmp19, tmp22, tmp23; continue L1 } else {
//line :48:1
			return lang.Tuple_Create_O_O_O_O_O__IPersistentVector(acc__4, cursor__3, breaks__5, apos__6, afull__7) } } }; /*line :47:1*/panic("j2g: unreachable") }







func A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_New_O_O_O_O_Z(p0, p1, p2, p3 any, p4 bool) *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A{}; t.Ctor_O_O_O_O_Z(p0, p1, p2, p3, p4); return t }
//line :55:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A) Ctor_O_O_O_O_Z(c__l, c__brk, c__cursor, c__c any, c__lines_QMARK_ bool) { t.F_l = c__l; t.F_brk = c__brk; t.F_cursor = c__cursor; t.F_c = c__c; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :55:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A) Invoke_O_O__O(self, cm__1 any) any { var G__1839000025__2_ any; var root_99 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_101 lang.IFn; if
														linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = cm__1; var arg_103 any = A_arbace_repr_go_layout_A_const_36; var arg_104 any = t.F_brk; if linked_100 == nil { G__1839000025__2_ = ifn_101.Invoke_O_O_O__O(arg_102, arg_103, arg_104) } else { G__1839000025__2_ = linked_100.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_99, arg_102, arg_103, arg_104) }; var G__1839000025__3_ any; var tmp1 any; var and__1927000168__auto____3 bool = /*line :55:1*/t.F_lines_QMARK_; if and__1927000168__auto____3 {

		var and__1927000168__auto____4 any = t.F_brk; if jrt.J2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 any; var root_105 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_109 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = t.F_c; if linked_110 == nil { arg_108 = ifn_111.Invoke_O__O(arg_112) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_109, arg_112) }; if linked_106 == nil { or__1927000174__auto____5 = ifn_107.Invoke_O__O(arg_108) } else { or__1927000174__auto____5 = linked_106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var root_113 any = A_arbace_repr_go_layout_A_const_38.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = t.F_c; if linked_114 == nil { tmp1 = ifn_115.Invoke_O__O(arg_116) } else { tmp1 = linked_114.(*A_arbace_repr_go_layout_deref_form_QMARK__A).Invoke_O_O__O(root_113, arg_116) } } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if /*line :56:1*/ jrt.J2g_Truth(tmp1) {

			var root_117 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = G__1839000025__2_; var arg_121 any = A_arbace_repr_go_layout_A_const_16; var arg_122 any = t.F_l; if linked_118 == nil { G__1839000025__3_ = ifn_119.Invoke_O_O_O__O(arg_120, arg_121, arg_122) } else { G__1839000025__3_ = linked_118.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_117, arg_120, arg_121, arg_122) } } else {
//line :56:1
				G__1839000025__3_ = G__1839000025__2_ }; var tmp2 any; var and__1927000168__auto____4_2 bool = t.F_lines_QMARK_; if and__1927000168__auto____4_2 {


					var and__1927000168__auto____5 any = t.F_l; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_123 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = t.F_brk; if linked_124 == nil { and__1927000168__auto____6 = ifn_125.Invoke_O__O(arg_126) } else { and__1927000168__auto____6 = linked_124.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_123, arg_126) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool; var na_127 any = t.F_l; var na_128 any = t.F_cursor; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_127); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_128) }; tmp3 = tmp4; if tmp3 { var n0_129 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); var n1_130 int64 = jrt.NN(jrt.Long_Cast(na_128)).LongValue__J(); and__1927000168__auto____7 = n0_129 < n1_130 } else { var tmp5 bool; var tmp6 bool; tmp6 = jrt.Double_InstanceOf(na_127); if tmp6 { tmp6 = jrt.Double_InstanceOf(na_128) }; tmp5 = tmp6; if tmp5 { var n0_129_2 float64 = jrt.NN(jrt.Double_Cast(na_127)).DoubleValue__D(); var n1_130_2 float64 = jrt.NN(jrt.Double_Cast(na_128)).DoubleValue__D(); and__1927000168__auto____7 = n0_129_2 < n1_130_2 } else { and__1927000168__auto____7 = lang.Numbers_Lt_O_O__Z_NoInit(na_127, na_128) } }; if and__1927000168__auto____7 { var root_132 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = t.F_c; if linked_133 == nil { tmp2 = ifn_134.Invoke_O__O(arg_135) } else { tmp2 = linked_133.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_132, arg_135) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if /*line :56:1*/ jrt.J2g_Truth(tmp2) { var cm__4 any = G__1839000025__3_; var root_142 any = A_arbace_repr_go_layout_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_repr_go_layout_note_BANG__A_fn_class); var ifn_144 lang.IFn



						if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_repr_go_layout_A_const_40; if linked_143 == nil { ifn_144.Invoke_O__O(arg_145) } else { linked_143.(*A_arbace_repr_go_layout_note_BANG__A).Invoke_O_O__O(root_142, arg_145) }; var root_136 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = cm__4; var arg_140 any = A_arbace_repr_go_layout_A_const_16; var arg_141 any = t.F_l; if linked_137 == nil { return ifn_138.Invoke_O_O_O__O(arg_139, arg_140, arg_141) } else { return linked_137.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_136, arg_139, arg_140, arg_141) } } else {
//line :56:1
							return G__1839000025__3_ } }














func A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_New_J_O(p0 int64, p1 any) *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A{}; t.Ctor_J_O(p0, p1); return t }
//line :71:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A) Ctor_J_O(c__i int64, c__c any) { t.F_i = c__i; t.F_c = c__c }
//line :71:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A) Invoke_O_O_O__O(self, af__1, p__1839000027__2 any) any { var vec__1839000029__3 any = p__1839000027__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000029__3, lang.RT_IntCast_J__I_NoInit(0), nil); var mk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000029__3, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000408__auto____6 any = lang.RT_Get_O_O__O_NoInit(t.F_c, k__4); if jrt.J2g_Truth(temp__1927000408__auto____6) { var v__7 any = temp__1927000408__auto____6; var root_192 any = A_arbace_repr_go_layout_A_const_46.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = af__1; var arg_196 any = lang.Tuple_Create_O_O__IPersistentVector(mk__5, jrt.Long_ValueOf_J__Long_NoInit(t.F_i).Ref()); var arg_197 any = v__7; if linked_193 == nil { return ifn_194.Invoke_O_O_O__O(arg_195, arg_196, arg_197) } else { return linked_193.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_192, arg_195, arg_196, arg_197) } } else { return af__1 } }







func A_arbace_repr_go_layout_prep_fn__1839000036_A_New() *A_arbace_repr_go_layout_prep_fn__1839000036_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000036_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000036_A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000036_A) Invoke_O_O__O(self, p__1839000035__1 any) any { var vec__1839000037__2 any = p__1839000035__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000037__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000037__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_244 any = A_arbace_repr_go_layout_A_const_54.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O(); var arg_248 any = v__4; if linked_245 == nil { tmp1 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { tmp1 = linked_245.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }



func A_arbace_repr_go_layout_prepare_A_New() *A_arbace_repr_go_layout_prepare_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prepare_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_go_layout_prepare_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_go_layout_prepare_A) Invoke_O_O__O(self, forms__0 any) any { { var fs__2 any = forms__0; var cursor__3 any = lang.RT_Box_J__Number_NoInit(1); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var temp__1927000408__auto____5 any; var root_258 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn



	if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = fs__2; if linked_259 == nil { temp__1927000408__auto____5 = ifn_260.Invoke_O__O(arg_261) } else { temp__1927000408__auto____5 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var f__6 any = temp__1927000408__auto____5; var l__7 any; var root_262 any = A_arbace_repr_go_layout_A_const_32.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, A_arbace_repr_go_layout_form_line_A_fn_class); var ifn_264 lang.IFn
		if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = f__6; if linked_263 == nil { l__7 = ifn_264.Invoke_O__O(arg_265) } else { l__7 = linked_263.(*A_arbace_repr_go_layout_form_line_A).Invoke_O_O__O(root_262, arg_265) }
//line :87:1
		var brk__8 any
		var and__1927000168__auto____8 any = l__7
		if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp1 bool; var na_266 any = l__7; var na_267 any = cursor__3; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_266); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_267) }; tmp2 = tmp3; if tmp2 { var n0_268 int64 = jrt.NN(jrt.Long_Cast(na_266)).LongValue__J(); var n1_269 int64 = jrt.NN(jrt.Long_Cast(na_267)).LongValue__J(); tmp1 = n0_268 > n1_269 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_266); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_267) }; tmp4 = tmp5; if tmp4 { var n0_268_2 float64 = jrt.NN(jrt.Double_Cast(na_266)).DoubleValue__D(); var n1_269_2 float64 = jrt.NN(jrt.Double_Cast(na_267)).DoubleValue__D(); tmp1 = n1_269_2 < n0_268_2 } else { tmp1 = lang.Numbers_Gt_O_O__Z_NoInit(na_266, na_267) } }; brk__8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else { brk__8 = and__1927000168__auto____8 }
//line :87:1
		var f__9 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_35.GetRawRoot__O()).Invoke_O_O_O_O__O(f__6, A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(), A_arbace_repr_go_layout_A_const_36, brk__8); var cursor__10 any



		if jrt.J2g_Truth(brk__8) { cursor__10 = l__7 } else { cursor__10 = cursor__3 }
//line :87:1
		var vec__1839000045__11 any; var root_278 any = A_arbace_repr_go_layout_A_const_42.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, A_arbace_repr_go_layout_prep_A_fn_class); var ifn_280 lang.IFn




		if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = f__9; var arg_282 any = cursor__10; if linked_279 == nil { vec__1839000045__11 = ifn_280.Invoke_O_O__O(arg_281, arg_282) } else { vec__1839000045__11 = linked_279.(*A_arbace_repr_go_layout_prep_A).Invoke_O_O_O__O(root_278, arg_281, arg_282) }
//line :87:1
		var f__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000045__11, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000045__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_283 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_285 lang.IFn





		if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = fs__2; if linked_284 == nil { tmp6 = ifn_285.Invoke_O__O(arg_286) } else { tmp6 = linked_284.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_283, arg_286) }; var tmp7 any = tmp6; var tmp8 any; var root_287 any = A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = acc__4; var arg_291 any = f__12; if linked_288 == nil { tmp8 = ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { tmp8 = linked_288.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) }; fs__2, cursor__3, acc__4 = tmp7, cursor__13, tmp8; continue L1 } else {
//line :87:1
			return acc__4 } } }; /*line :83:1*/panic("j2g: unreachable") }



















func A_arbace_repr_go_layout_key_rank_A_New() *A_arbace_repr_go_layout_key_rank_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_key_rank_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_repr_go_layout_key_rank_A) Ctor() {}
//line :103:1
func (t *A_arbace_repr_go_layout_key_rank_A) Invoke_O_O__O(self, k__0 any) any { var i__2 int32 = jrt.List_Cast(A_arbace_repr_go_layout_A_const_57.GetRawRoot__O()).IndexOf_O__I(k__0); if

	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_layout_A_const_57.GetRawRoot__O())).Ref() } else { return jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref() } }

func A_arbace_repr_go_layout_sort_keys_A_New() *A_arbace_repr_go_layout_sort_keys_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_sort_keys_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_layout_sort_keys_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_layout_sort_keys_A) Invoke_O_O__O(self, ks__0 any) any {
	var root_292 any = A_arbace_repr_go_layout_A_const_58.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any; var tmp1 any = A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_New(); var tmp2 *jrt.Class; var fncls__305 *jrt.Class = A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class; if fncls__305 == nil { var fncls__305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class = fncls__305d; tmp2 = fncls__305d } else { tmp2 = fncls__305 }; arg_295 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_296 any = ks__0; if linked_293 == nil { return ifn_294.Invoke_O_O__O(arg_295, arg_296) } else { return linked_293.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_292, arg_295, arg_296) } }
//line :108:1
func A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_New() *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_sort_keys_fn__1839000050_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A) Ctor() {}
//line :108:1
func (t *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 any; var root_297 any = A_arbace_repr_go_layout_A_const_59.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, A_arbace_repr_go_layout_key_rank_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = k__1; if linked_298 == nil { tmp1 = ifn_299.Invoke_O__O(arg_300) } else { tmp1 = linked_298.(*A_arbace_repr_go_layout_key_rank_A).Invoke_O_O__O(root_297, arg_300) }; var tmp2 any = tmp1; var tmp3 any; var root_301 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = k__1; if linked_302 == nil { tmp3 = ifn_303.Invoke_O__O(arg_304) } else { tmp3 = linked_302.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_301, arg_304) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }

func A_arbace_repr_go_layout_public_meta_A_New() *A_arbace_repr_go_layout_public_meta_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_public_meta_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_repr_go_layout_public_meta_A) Ctor() {}
//line :110:1
func (t *A_arbace_repr_go_layout_public_meta_A) Invoke_O_O__O(self, x__0 any) any { var m__2 any; var tmp1 any; var root_306 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_308 lang.IFn; if


	linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = x__0; if linked_307 == nil { tmp1 = ifn_308.Invoke_O__O(arg_309) } else { tmp1 = linked_307.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_306, arg_309) }; if jrt.J2g_Truth(tmp1) { m__2 = lang.RT_Meta_O__IPersistentMap_NoInit(x__0) } else { m__2 = nil }; var lines_QMARK___3 bool = /*line :110:1*/lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_28); var pm__4 any; var root_310 any = A_arbace_repr_go_layout_A_const_54.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_312 lang.IFn; if




	linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_314 any; var root_316 any = A_arbace_repr_go_layout_A_const_61.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any; var tmp2 any = A_arbace_repr_go_layout_public_meta_fn__1839000054_A_New(); var tmp3 *jrt.Class; var fncls__324 *jrt.Class = A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class; if fncls__324 == nil { var fncls__324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class = fncls__324d; tmp3 = fncls__324d } else { tmp3 = fncls__324 }; arg_319 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_317 == nil { arg_314 = ifn_318.Invoke_O__O(arg_319) } else { arg_314 = linked_317.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_316, arg_319) }; var arg_315 any = m__2; if linked_311 == nil { pm__4 = ifn_312.Invoke_O_O_O__O(arg_313, arg_314, arg_315) } else { pm__4 = linked_311.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_310, arg_313, arg_314, arg_315) }; var pm__5 any; if lines_QMARK___3 {
		pm__5 = pm__4 } else { var G__1839000059__5_ any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_63.GetRawRoot__O()).Invoke_O_O_O_O__O(pm__4, A_arbace_repr_go_layout_A_const_16, A_arbace_repr_go_layout_A_const_50, A_arbace_repr_go_layout_A_const_64); var G__1839000059__6_ any; var tmp4 any; var root_332 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_334 lang.IFn


			if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = A_arbace_repr_go_layout_A_const_65.Invoke_O__O(m__2); if linked_333 == nil { tmp4 = ifn_334.Invoke_O__O(arg_335) } else { tmp4 = linked_333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_332, arg_335) }
//line :118:1
			if jrt.J2g_Truth(tmp4) {
				var root_336 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = G__1839000059__5_; var arg_340 any = A_arbace_repr_go_layout_A_const_66; var arg_341 any = A_arbace_repr_go_layout_A_const_65.Invoke_O__O(m__2); if linked_337 == nil { G__1839000059__6_ = ifn_338.Invoke_O_O_O__O(arg_339, arg_340, arg_341) } else { G__1839000059__6_ = linked_337.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_336, arg_339, arg_340, arg_341) } } else {
//line :118:1
					G__1839000059__6_ = G__1839000059__5_ }; var tmp5 any; var root_342 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_344 lang.IFn

			if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = A_arbace_repr_go_layout_A_const_67.Invoke_O__O(m__2); if linked_343 == nil { tmp5 = ifn_344.Invoke_O__O(arg_345) } else { tmp5 = linked_343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_342, arg_345) }
//line :118:1
			if jrt.J2g_Truth(tmp5) {

				var root_346 any = A_arbace_repr_go_layout_A_const_53.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = G__1839000059__6_; var arg_350 any = A_arbace_repr_go_layout_A_const_67.Invoke_O__O(m__2); if linked_347 == nil { pm__5 = ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { pm__5 = linked_347.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_346, arg_349, arg_350) } } else {
//line :118:1
					pm__5 = G__1839000059__6_ } }; return pm__5 }
//line :115:1
func A_arbace_repr_go_layout_public_meta_fn__1839000054_A_New() *A_arbace_repr_go_layout_public_meta_fn__1839000054_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_public_meta_fn__1839000054_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repr_go_layout_public_meta_fn__1839000054_A) Ctor() {}
//line :115:1
func (t *A_arbace_repr_go_layout_public_meta_fn__1839000054_A) Invoke_O_O__O(self, p__1839000053__1 any) any { var vec__1839000055__2 any = p__1839000053__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000055__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000055__2, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____5 any; var root_320 any = A_arbace_repr_go_layout_A_const_62.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, A_arbace_repr_go_layout_private_QMARK__A_fn_class); var ifn_322 lang.IFn; _ = ___4; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = k__3; if linked_321 == nil { or__1927000174__auto____5 = ifn_322.Invoke_O__O(arg_323) } else { or__1927000174__auto____5 = linked_321.(*A_arbace_repr_go_layout_private_QMARK__A).Invoke_O_O__O(root_320, arg_323) }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_layout_A_const_36)).Ref() } }







func A_arbace_repr_go_layout_meta_prefix_A_New() *A_arbace_repr_go_layout_meta_prefix_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_repr_go_layout_meta_prefix_A) Ctor() {}
//line :123:1
func (t *A_arbace_repr_go_layout_meta_prefix_A) Invoke_O_O__O(self, x__0 any) any { var pm__2 any; var root_351 any = A_arbace_repr_go_layout_A_const_68.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, A_arbace_repr_go_layout_public_meta_A_fn_class); var ifn_353 lang.IFn; if
											linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = x__0; if linked_352 == nil { pm__2 = ifn_353.Invoke_O__O(arg_354) } else { pm__2 = linked_352.(*A_arbace_repr_go_layout_public_meta_A).Invoke_O_O__O(root_351, arg_354) }; var tmp1 any; var root_355 any =
											A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = pm__2; if linked_356 == nil { tmp1 = ifn_357.Invoke_O__O(arg_358) } else { tmp1 = linked_356.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_355, arg_358) }; if jrt.J2g_Truth(tmp1) { var ks__3 any; var root_359 any = A_arbace_repr_go_layout_A_const_69.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, A_arbace_repr_go_layout_sort_keys_A_fn_class); var ifn_361 lang.IFn
												if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any; var root_363 any = A_arbace_repr_go_layout_A_const_70.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = pm__2; if linked_364 == nil { arg_362 = ifn_365.Invoke_O__O(arg_366) } else { arg_362 = linked_364.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_363, arg_366) }; if linked_360 == nil { ks__3 = ifn_361.Invoke_O__O(arg_362) } else { ks__3 = linked_360.(*A_arbace_repr_go_layout_sort_keys_A).Invoke_O_O__O(root_359, arg_362) }
//line :125:1
		var flags__4 any; var root_367 any = A_arbace_repr_go_layout_A_const_71.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_369 lang.IFn

		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any; var tmp2 any = A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_New_O(pm__2); var tmp3 *jrt.Class; var fncls__381 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class; if fncls__381 == nil { var fncls__381d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class = fncls__381d; tmp3 = fncls__381d } else { tmp3 = fncls__381 }; arg_370 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_371 any = ks__3; if linked_368 == nil { flags__4 = ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { flags__4 = linked_368.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) }
//line :125:1
		var rest_ks__5 any; var root_382 any = A_arbace_repr_go_layout_A_const_61.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_384 lang.IFn


		if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any; var tmp4 any = A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_New_O(pm__2); var tmp5 *jrt.Class; var fncls__396 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class; if fncls__396 == nil { var fncls__396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class = fncls__396d; tmp5 = fncls__396d } else { tmp5 = fncls__396 }; arg_385 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_386 any = ks__3; if linked_383 == nil { rest_ks__5 = ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { rest_ks__5 = linked_383.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_382, arg_385, arg_386) }
//line :125:1
		var sb__6 any = jrt.StringBuilder_New(); var seq_1839000067__7 any; var root_401 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_403 lang.IFn




		if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = flags__4; if linked_402 == nil { seq_1839000067__7 = ifn_403.Invoke_O__O(arg_404) } else { seq_1839000067__7 = linked_402.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_401, arg_404) }
//line :125:1
		var chunk_1839000068__8 any; var count_1839000069__9 int64 = 0; var i_1839000070__10 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000070__10, count_1839000069__9) { var k__11 any = lang.Indexed_Cast(chunk_1839000068__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000070__10)); jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__11, nil))); seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000070__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_405 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = seq_1839000067__7; if linked_406 == nil { temp__1927000414__auto____11 = ifn_407.Invoke_O__O(arg_408) } else { temp__1927000414__auto____11 = linked_406.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_405, arg_408) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1839000067__12 any = temp__1927000414__auto____11; var tmp6 any; var root_409 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = seq_1839000067__12; if linked_410 == nil { tmp6 = ifn_411.Invoke_O__O(arg_412) } else { tmp6 = linked_410.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_409, arg_412) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____13 any; var root_413 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = seq_1839000067__12; if linked_414 == nil { c__1927000678__auto____13 = ifn_415.Invoke_O__O(arg_416) } else { c__1927000678__auto____13 = linked_414.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_413, arg_416) }; var tmp7 any; var root_437 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = seq_1839000067__12; if linked_438 == nil { tmp7 = ifn_439.Invoke_O__O(arg_440) } else { tmp7 = linked_438.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_437, arg_440) }; seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = tmp7, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__13 any; var root_417 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = seq_1839000067__12; if linked_418 == nil { k__13 = ifn_419.Invoke_O__O(arg_420) } else { k__13 = linked_418.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_417, arg_420) }; jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__13, nil))); var tmp8 any; var root_441 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = seq_1839000067__12; if linked_442 == nil { tmp8 = ifn_443.Invoke_O__O(arg_444) } else { tmp8 = linked_442.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_441, arg_444) }; seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = tmp8, nil, 0, 0; continue L1 } } }
//line :125:1
			break L1
		}




		var tmp9 any; var root_421 any = A_arbace_repr_go_layout_A_const_77.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_423 lang.IFn
		if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = rest_ks__5; if linked_422 == nil { tmp9 = ifn_423.Invoke_O__O(arg_424) } else { tmp9 = linked_422.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_421, arg_424) }
//line :131:1
		if jrt.J2g_Truth(tmp9) { } else { var tmp10 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(rest_ks__5, A_arbace_repr_go_layout_A_const_78)

			if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var root_425 any = A_arbace_repr_go_layout_A_const_79.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2); if linked_426 == nil { and__1927000168__auto____8 = ifn_427.Invoke_O__O(arg_428) } else { and__1927000168__auto____8 = linked_426.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_425, arg_428) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_429 any = A_arbace_repr_go_layout_A_const_77.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any; var root_433 any = A_arbace_repr_go_layout_A_const_68.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_repr_go_layout_public_meta_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2); if linked_434 == nil { arg_432 = ifn_435.Invoke_O__O(arg_436) } else { arg_432 = linked_434.(*A_arbace_repr_go_layout_public_meta_A).Invoke_O_O__O(root_433, arg_436) }; if linked_430 == nil { tmp10 = ifn_431.Invoke_O__O(arg_432) } else { tmp10 = linked_430.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_429, arg_432) } } else { tmp10 = and__1927000168__auto____8 } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :131:1
			if jrt.J2g_Truth(tmp10) {


				jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2), nil))) } else {
//line :131:1
					if A_arbace_repr_go_layout_A_const_41 != nil {




						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_16)
						var tmp11 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__6); var tmp12 any; var root_445 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = Lit_9; var arg_449 any; var iter__1927001039__auto____7 any; var tmp13 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_New_O(pm__2); var tmp14 *jrt.Class; var fncls__516 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class; if fncls__516 == nil { var fncls__516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class = fncls__516d; tmp14 = fncls__516d } else { tmp14 = fncls__516 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); arg_449 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(rest_ks__5); if linked_446 == nil { tmp12 = ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { tmp12 = linked_446.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) }; jrt.NN(tmp11).Append_String__StringBuilder(jrt.String_Cast(tmp12))
						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_18) } } }
		var root_397 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = sb__6; if linked_398 == nil { return ifn_399.Invoke_O__O(arg_400) } else { return linked_398.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_397, arg_400) } } else {
//line :125:1
			return nil } }

func A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :127:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A) Invoke_O_O__O(self, p1__1839000061_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_372 any = A_arbace_repr_go_layout_A_const_72.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_true_QMARK__A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1839000061_SHARP___1); if linked_373 == nil { and__1927000168__auto____2 = ifn_374.Invoke_O__O(arg_375) } else { and__1927000168__auto____2 = linked_373.(*aot_arbace_core.A_arbace_core_true_QMARK__A).Invoke_O_O__O(root_372, arg_375) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_376 any = A_arbace_repr_go_layout_A_const_73.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = p1__1839000061_SHARP___1; var arg_380 any = A_arbace_repr_go_layout_A_const_74; if linked_377 == nil { return ifn_378.Invoke_O_O__O(arg_379, arg_380) } else { return linked_377.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_376, arg_379, arg_380) } } else { return and__1927000168__auto____2 } }
func A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :128:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A) Invoke_O_O__O(self, p1__1839000062_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_387 any = A_arbace_repr_go_layout_A_const_72.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_true_QMARK__A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1839000062_SHARP___1); if linked_388 == nil { and__1927000168__auto____2 = ifn_389.Invoke_O__O(arg_390) } else { and__1927000168__auto____2 = linked_388.(*aot_arbace_core.A_arbace_core_true_QMARK__A).Invoke_O_O__O(root_387, arg_390) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_391 any = A_arbace_repr_go_layout_A_const_73.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = p1__1839000062_SHARP___1; var arg_395 any = A_arbace_repr_go_layout_A_const_74; if linked_392 == nil { return ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { return linked_392.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_391, arg_394, arg_395) } } else { return and__1927000168__auto____2 } }








func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A) Invoke_O_O__O(self, s__1839000072__1 any) any { var tmp1 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_New_O_O_O(s__1839000072__1, t.F_pm, self); var tmp2 *jrt.Class; var fncls__515 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class; if fncls__515 == nil { var fncls__515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class = fncls__515d; tmp2 = fncls__515d } else { tmp2 = fncls__515 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :137:1
func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A) Ctor_O_O_O(c__s__1839000072, c__pm, c__iter__1839000071 any) { t.F_s__1839000072 = c__s__1839000072; t.F_pm = c__pm; t.F_iter__1839000071 = c__iter__1839000071 }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A) Invoke_O__O(self any) any { { var s__1839000072__1 any; var t_ any = t.F_s__1839000072; t.F_s__1839000072 = nil; s__1839000072__1 = t_; for { var temp__1927000414__auto____2 any; var root_450 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = s__1839000072__1; if linked_451 == nil { temp__1927000414__auto____2 = ifn_452.Invoke_O__O(arg_453) } else { temp__1927000414__auto____2 = linked_451.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_450, arg_453) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000072__3 any = temp__1927000414__auto____2; var tmp1 any; var root_454 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = s__1839000072__3; if linked_455 == nil { tmp1 = ifn_456.Invoke_O__O(arg_457) } else { tmp1 = linked_455.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_454, arg_457) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_458 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = s__1839000072__3; if linked_459 == nil { c__1927001037__auto____4 = ifn_460.Invoke_O__O(arg_461) } else { c__1927001037__auto____4 = linked_459.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_458, arg_461) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000074__6 any; var root_462 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_463 == nil { b__1839000074__6 = ifn_464.Invoke_O__O(arg_465) } else { b__1839000074__6 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_462, arg_465) }; var tmp2 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_New_O_O_I_O(b__1839000074__6, t.F_pm, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__475 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class; if fncls__475 == nil { var fncls__475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class = fncls__475d; tmp3 = fncls__475d } else { tmp3 = fncls__475 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_476 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var root_481 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = b__1839000074__6; if linked_482 == nil { arg_479 = ifn_483.Invoke_O__O(arg_484) } else { arg_479 = linked_482.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_481, arg_484) }; var arg_480 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000071); var tmp5 any; var root_485 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = s__1839000072__3; if linked_486 == nil { tmp5 = ifn_487.Invoke_O__O(arg_488) } else { tmp5 = linked_486.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_485, arg_488) }; arg_480 = tmp4.Invoke_O__O(tmp5); if linked_477 == nil { return ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { return linked_477.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_476, arg_479, arg_480) } } else { var root_489 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any; var root_494 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = b__1839000074__6; if linked_495 == nil { arg_492 = ifn_496.Invoke_O__O(arg_497) } else { arg_492 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_494, arg_497) }; var arg_493 any; if linked_490 == nil { return ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { return linked_490.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) } } } else { var k__4 any; var root_498 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = s__1839000072__3; if linked_499 == nil { k__4 = ifn_500.Invoke_O__O(arg_501) } else { k__4 = linked_499.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_498, arg_501) }; var root_502 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp7 any; var root_507 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, A_arbace_repr_go_layout_text_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(k__4); if linked_508 == nil { tmp7 = ifn_509.Invoke_O__O(arg_510) } else { tmp7 = linked_508.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_507, arg_510) }; arg_505 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, k__4, nil, tmp7)).Ref(); var arg_506 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1839000071); var tmp9 any; var root_511 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = s__1839000072__3; if linked_512 == nil { tmp9 = ifn_513.Invoke_O__O(arg_514) } else { tmp9 = linked_512.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_511, arg_514) }; arg_506 = tmp8.Invoke_O__O(tmp9); if linked_503 == nil { return ifn_504.Invoke_O_O__O(arg_505, arg_506) } else { return linked_503.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_502, arg_505, arg_506) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :137:1
func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A) Ctor_O_O_I_O(c__b__1839000074, c__pm any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000074 = c__b__1839000074; t.F_pm = c__pm; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A) Invoke_O__O(self any) any { { var i__1839000073__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000073__1)); var root_466 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = t.F_b__1839000074; var arg_470 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp3 any; var root_471 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, A_arbace_repr_go_layout_text_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(k__2); if linked_472 == nil { tmp3 = ifn_473.Invoke_O__O(arg_474) } else { tmp3 = linked_472.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_471, arg_474) }; arg_470 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, k__2, nil, tmp3)).Ref(); if linked_467 == nil { ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { linked_467.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) }; i__1839000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000073__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_layout_atom_text_A_New() *A_arbace_repr_go_layout_atom_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_atom_text_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_repr_go_layout_atom_text_A) Ctor() {}
//line :141:1
func (t *A_arbace_repr_go_layout_atom_text_A) Invoke_O_O__O(self, x__0 any) any {
	if lang.Util_Identical_O_O__Z_NoInit(x__0, nil) { return Lit_1 } else { var tmp1 any; var root_517 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_519 lang.IFn

		if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = x__0; if linked_518 == nil { tmp1 = ifn_519.Invoke_O__O(arg_520) } else { tmp1 = linked_518.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_517, arg_520) }
//line :142:1
		if jrt.J2g_Truth(tmp1) {

			return A_arbace_repr_go_layout_A_const_90.Invoke_O__O(x__0) } else {
//line :142:1
				var tmp2 any; var root_521 any = A_arbace_repr_go_layout_A_const_79.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_523 lang.IFn


				if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = x__0; if linked_522 == nil { tmp2 = ifn_523.Invoke_O__O(arg_524) } else { tmp2 = linked_522.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_521, arg_524) }
//line :142:1
				if jrt.J2g_Truth(tmp2) {


					var root_525 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = x__0; if linked_526 == nil { return ifn_527.Invoke_O__O(arg_528) } else { return linked_526.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_525, arg_528) } } else {
//line :142:1
						var tmp3 any; var root_529 any = A_arbace_repr_go_layout_A_const_10.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_531 lang.IFn



						if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = x__0; if linked_530 == nil { tmp3 = ifn_531.Invoke_O__O(arg_532) } else { tmp3 = linked_530.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_529, arg_532) }
//line :142:1
						if jrt.J2g_Truth(tmp3) {



							var root_533 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = x__0; if linked_534 == nil { return ifn_535.Invoke_O__O(arg_536) } else { return linked_534.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_533, arg_536) } } else {
//line :142:1
								var tmp4 any; var root_537 any = A_arbace_repr_go_layout_A_const_91.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_539 lang.IFn




								if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = x__0; if linked_538 == nil { tmp4 = ifn_539.Invoke_O__O(arg_540) } else { tmp4 = linked_538.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_537, arg_540) }
//line :142:1
								if jrt.J2g_Truth(tmp4) {




									var root_541 any = A_arbace_repr_go_layout_A_const_92.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = x__0; if linked_542 == nil { return ifn_543.Invoke_O__O(arg_544) } else { return linked_542.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_541, arg_544) } } else {
//line :142:1
										var tmp5 any; var root_545 any = A_arbace_repr_go_layout_A_const_93.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_547 lang.IFn





										if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = x__0; if linked_546 == nil { tmp5 = ifn_547.Invoke_O__O(arg_548) } else { tmp5 = linked_546.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_545, arg_548) }
//line :142:1
										if jrt.J2g_Truth(tmp5) {





											var root_549 any = A_arbace_repr_go_layout_A_const_94.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_char_text_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(x__0)).Ref(); if linked_550 == nil { return ifn_551.Invoke_O__O(arg_552) } else { return linked_550.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_char_text_A).Invoke_O_O__O(root_549, arg_552) } } else {
//line :142:1
												if lang.BigInt_InstanceOf(x__0) {






													return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
														if jrt.BigInteger_InstanceOf(x__0) {







															return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
																var tmp6 any; var root_553 any = A_arbace_repr_go_layout_A_const_95.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_555 lang.IFn








																if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = x__0; if linked_554 == nil { tmp6 = ifn_555.Invoke_O__O(arg_556) } else { tmp6 = linked_554.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_553, arg_556) }
//line :142:1
																if jrt.J2g_Truth(tmp6) {








																	var root_557 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = x__0; if linked_558 == nil { return ifn_559.Invoke_O__O(arg_560) } else { return linked_558.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_557, arg_560) } } else {
//line :142:1
																		var tmp7 any; var root_561 any = A_arbace_repr_go_layout_A_const_96.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_563 lang.IFn









																		if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = x__0; if linked_562 == nil { tmp7 = ifn_563.Invoke_O__O(arg_564) } else { tmp7 = linked_562.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_561, arg_564) }
//line :142:1
																		if jrt.J2g_Truth(tmp7) {









																			var root_565 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = x__0; if linked_566 == nil { return ifn_567.Invoke_O__O(arg_568) } else { return linked_566.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_565, arg_568) } } else {
//line :142:1
																				if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(x__0)











																					if jrt.Double_IsNaN_D__Z_NoInit(d__2) { return Lit_3 } else { if jrt.Double_IsInfinite_D__Z_NoInit(d__2) {
																						if lang.Numbers_IsPos_D__Z_NoInit(d__2) { return Lit_4 } else { return Lit_5 } } else {
//line :154:1
																							if A_arbace_repr_go_layout_A_const_41 != nil {

																								var root_569 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = x__0; if linked_570 == nil { return ifn_571.Invoke_O__O(arg_572) } else { return linked_570.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_569, arg_572) } } else {
//line :154:1
																									return nil } } } } else {
//line :142:1
																										if jrt.BigDecimal_InstanceOf(x__0) {














																											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
																												var tmp8 any; var root_573 any = A_arbace_repr_go_layout_A_const_97.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_575 lang.IFn















																												if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = x__0; if linked_574 == nil { tmp8 = ifn_575.Invoke_O__O(arg_576) } else { tmp8 = linked_574.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_573, arg_576) }
//line :142:1
																												if jrt.J2g_Truth(tmp8) {















																													var root_577 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = x__0; if linked_578 == nil { return ifn_579.Invoke_O__O(arg_580) } else { return linked_578.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_577, arg_580) } } else {
//line :142:1
																														if A_arbace_repr_go_layout_A_const_41 != nil { var tmp9 any; var root_581 any = A_arbace_repr_go_layout_A_const_98.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_583 lang.IFn
















																															if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp11 any; var root_586 any = A_arbace_repr_go_layout_A_const_99.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = x__0; if linked_587 == nil { tmp11 = ifn_588.Invoke_O__O(arg_589) } else { tmp11 = linked_587.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_586, arg_589) }; arg_584 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref(); var arg_585 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_layout_A_const_100, x__0)); if linked_582 == nil { tmp9 = ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { tmp9 = linked_582.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) }
//line :142:1
																															panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) } else { return nil
																															}
																													}
																											}
																									}
																			}
																	}
															}
													}
											}
									}
							}
					}
			}
	}
}



func A_arbace_repr_go_layout_lit_children_meta_A_New() *A_arbace_repr_go_layout_lit_children_meta_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_layout_lit_children_meta_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_layout_lit_children_meta_A) Invoke_O_O__O(self, x__0 any) any {



	var root_590 any = A_arbace_repr_go_layout_A_const_45.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any; var tmp1 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_New(); var tmp2 *jrt.Class; var fncls__623 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class; if fncls__623 == nil { var fncls__623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class = fncls__623d; tmp2 = fncls__623d } else { tmp2 = fncls__623 }; arg_593 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_594 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_595 any; var root_624 any = A_arbace_repr_go_layout_A_const_102.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_626 lang.IFn




	if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = A_arbace_repr_go_layout_A_const_103.GetRawRoot__O(); var arg_628 any = x__0; if linked_625 == nil { arg_595 = ifn_626.Invoke_O_O__O(arg_627, arg_628) } else { arg_595 = linked_625.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_624, arg_627, arg_628) }
//line :165:1
	if linked_591 == nil { return ifn_592.Invoke_O_O_O__O(arg_593, arg_594, arg_595) } else { return linked_591.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_590, arg_593, arg_594, arg_595) } }
//line :165:1
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_New() *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A) Ctor() {}
//line :165:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A) Invoke_O_O_O__O(self, m__1, p__1839000084__2 any) any { var vec__1839000086__3 any = p__1839000084__2; var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000086__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000086__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_596 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_598 lang.IFn; if
																linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = c__5; if linked_597 == nil { tmp1 = ifn_598.Invoke_O__O(arg_599) } else { tmp1 = linked_597.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_596, arg_599) }; if jrt.J2g_Truth(tmp1) {
																	var root_600 any = A_arbace_repr_go_layout_A_const_45.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any; var tmp2 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_New_O_O(i__4, c__5); var tmp3 *jrt.Class; var fncls__622 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class; if fncls__622 == nil { var fncls__622d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class = fncls__622d; tmp3 = fncls__622d } else { tmp3 = fncls__622 }; arg_603 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_604 any = m__1; var arg_605 any = A_arbace_repr_go_layout_A_const_101; if linked_601 == nil { return ifn_602.Invoke_O_O_O__O(arg_603, arg_604, arg_605) } else { return linked_601.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_600, arg_603, arg_604, arg_605) } } else {
//line :166:1
			return m__1 } }
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A) Ctor_O_O(c__i, c__c any) { t.F_i = c__i; t.F_c = c__c }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A) Invoke_O_O_O__O(self, m__1, p__1839000089__2 any) any { var vec__1839000091__3 any = p__1839000089__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000091__3, lang.RT_IntCast_J__I_NoInit(0), nil); var mk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000091__3, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000408__auto____6 any = lang.RT_Get_O_O__O_NoInit(t.F_c, k__4); if jrt.J2g_Truth(temp__1927000408__auto____6) { var v__7 any = temp__1927000408__auto____6; var root_606 any = A_arbace_repr_go_layout_A_const_21.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = m__1; var arg_610 any = mk__5; var arg_611 any; var tmp1 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_New_O_O(t.F_i, v__7); var tmp2 *jrt.Class; var fncls__621 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class; if fncls__621 == nil { var fncls__621d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class = fncls__621d; tmp2 = fncls__621d } else { tmp2 = fncls__621 }; arg_611 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_607 == nil { return ifn_608.Invoke_O_O_O__O(arg_609, arg_610, arg_611) } else { return linked_607.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_606, arg_609, arg_610, arg_611) } } else { return m__1 } }
//line :167:1
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A) Ctor_O_O(c__i, c__v any) { t.F_i = c__i; t.F_v = c__v }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A) Invoke_O_O__O(self, p1__1839000083_SHARP___1 any) any { var root_612 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any; var or__1927000174__auto____2 any = p1__1839000083_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_615 = or__1927000174__auto____2 } else { arg_615 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O() }; var arg_616 any = t.F_i; var arg_617 any = t.F_v; if linked_613 == nil { return ifn_614.Invoke_O_O_O__O(arg_615, arg_616, arg_617) } else { return linked_613.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_612, arg_615, arg_616, arg_617) } }




func A_arbace_repr_go_layout_text_A_New() *A_arbace_repr_go_layout_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repr_go_layout_text_A) Ctor() {}
//line :172:1
func (t *A_arbace_repr_go_layout_text_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_629 any = A_arbace_repr_go_layout_A_const_104.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, A_arbace_repr_go_layout_meta_prefix_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any; var tmp3 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_51); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_633 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = x__0; if linked_634 == nil { or__1927000174__auto____5 = ifn_635.Invoke_O__O(arg_636) } else { or__1927000174__auto____5 = linked_634.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_633, arg_636) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { var root_637 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = x__0; if linked_638 == nil { and__1927000168__auto____5 = ifn_639.Invoke_O__O(arg_640) } else { and__1927000168__auto____5 = linked_638.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_637, arg_640) } }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_641 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var tmp4 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; var arg_644 any = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)); if linked_642 == nil { tmp3 = ifn_643.Invoke_O__O(arg_644) } else { tmp3 = linked_642.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_641, arg_644) } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp3) { var lm__4 any; var root_645 any = A_arbace_repr_go_layout_A_const_105.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, A_arbace_repr_go_layout_lit_children_meta_A_fn_class); var ifn_647 lang.IFn
		if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = x__0; if linked_646 == nil { lm__4 = ifn_647.Invoke_O__O(arg_648) } else { lm__4 = linked_646.(*A_arbace_repr_go_layout_lit_children_meta_A).Invoke_O_O__O(root_645, arg_648) }
		var tmp5 any; var root_649 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = lm__4; if linked_650 == nil { tmp5 = ifn_651.Invoke_O__O(arg_652) } else { tmp5 = linked_650.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_649, arg_652) }; if jrt.J2g_Truth(tmp5) { arg_632 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(x__0, A_arbace_repr_go_layout_A_const_53.GetRawRoot__O(), lm__4) } else { arg_632 = x__0 } } else {
//line :175:1
			arg_632 = x__0 }; if linked_630 == nil { tmp2 = ifn_631.Invoke_O__O(arg_632) } else { tmp2 = linked_630.(*A_arbace_repr_go_layout_meta_prefix_A).Invoke_O_O__O(root_629, arg_632) }; var tmp6 any = tmp2; var tmp7 any; var tmp8 any; var root_659 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_661 lang.IFn




	if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = x__0; if linked_660 == nil { tmp8 = ifn_661.Invoke_O__O(arg_662) } else { tmp8 = linked_660.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_659, arg_662) }
//line :179:1
	if jrt.J2g_Truth(tmp8) {
		tmp7 = A_arbace_repr_go_layout_A_const_90.Invoke_O__O(x__0) } else {
//line :179:1
			var tmp9 any; var and__1927000168__auto____4_2 any; var root_663 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_665 lang.IFn

			if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = x__0; if linked_664 == nil { and__1927000168__auto____4_2 = ifn_665.Invoke_O__O(arg_666) } else { and__1927000168__auto____4_2 = linked_664.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_663, arg_666) }; if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp10 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp9 = tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else { tmp9 = and__1927000168__auto____4_2 }
//line :179:1
			if jrt.J2g_Truth(tmp9) {

				var tmp11 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp7 = tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else {
//line :179:1
					var tmp12 any; var root_667 any = A_arbace_repr_go_layout_A_const_38.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class); var ifn_669 lang.IFn


					if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = x__0; if linked_668 == nil { tmp12 = ifn_669.Invoke_O__O(arg_670) } else { tmp12 = linked_668.(*A_arbace_repr_go_layout_deref_form_QMARK__A).Invoke_O_O__O(root_667, arg_670) }
//line :179:1
					if jrt.J2g_Truth(tmp12) {


						var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil); var tmp14 any; var root_671 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, A_arbace_repr_go_layout_text_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any; var root_675 any = A_arbace_repr_go_layout_A_const_106.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = x__0; if linked_676 == nil { arg_674 = ifn_677.Invoke_O__O(arg_678) } else { arg_674 = linked_676.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_675, arg_678) }; if linked_672 == nil { tmp14 = ifn_673.Invoke_O__O(arg_674) } else { tmp14 = linked_672.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_671, arg_674) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref() } else {
//line :179:1
							var tmp15 any; var root_679 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_681 lang.IFn



							if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = x__0; if linked_680 == nil { tmp15 = ifn_681.Invoke_O__O(arg_682) } else { tmp15 = linked_680.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_679, arg_682) }
//line :179:1
							if jrt.J2g_Truth(tmp15) {



								var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29); var tmp17 any; var root_683 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = Lit_9; var arg_687 any; var root_688 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var arg_692 any = x__0; if linked_689 == nil { arg_687 = ifn_690.Invoke_O_O__O(arg_691, arg_692) } else { arg_687 = linked_689.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_688, arg_691, arg_692) }; if linked_684 == nil { tmp17 = ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { tmp17 = linked_684.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17, nil)).Ref() } else {
//line :179:1
									var tmp18 any; var root_693 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_695 lang.IFn




									if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = x__0; if linked_694 == nil { tmp18 = ifn_695.Invoke_O__O(arg_696) } else { tmp18 = linked_694.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_693, arg_696) }
//line :179:1
									if jrt.J2g_Truth(tmp18) {




										var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31); var tmp20 any; var root_697 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = Lit_9; var arg_701 any; var root_702 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var arg_706 any = x__0; if linked_703 == nil { arg_701 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { arg_701 = linked_703.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; if linked_698 == nil { tmp20 = ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { tmp20 = linked_698.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp20, nil)).Ref() } else {
//line :179:1
											var tmp21 any; var root_707 any = A_arbace_repr_go_layout_A_const_107.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_709 lang.IFn





											if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = x__0; if linked_708 == nil { tmp21 = ifn_709.Invoke_O__O(arg_710) } else { tmp21 = linked_708.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_707, arg_710) }
//line :179:1
											if jrt.J2g_Truth(tmp21) {





												var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil, Lit_33); var tmp23 any; var root_711 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = Lit_9; var arg_715 any; var iter__1927001039__auto____7 any; var tmp24 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_New(); var tmp25 *jrt.Class; var fncls__790 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class; if fncls__790 == nil { var fncls__790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class = fncls__790d; tmp25 = fncls__790d } else { tmp25 = fncls__790 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); arg_715 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(x__0); if linked_712 == nil { tmp23 = ifn_713.Invoke_O_O__O(arg_714, arg_715) } else { tmp23 = linked_712.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_711, arg_714, arg_715) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23, nil)).Ref() } else {
//line :179:1
													if A_arbace_repr_go_layout_A_const_41 != nil {






														var root_791 any = A_arbace_repr_go_layout_A_const_108.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, A_arbace_repr_go_layout_atom_text_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = x__0; if linked_792 == nil { tmp7 = ifn_793.Invoke_O__O(arg_794) } else { tmp7 = linked_792.(*A_arbace_repr_go_layout_atom_text_A).Invoke_O_O__O(root_791, arg_794) } } else {
//line :179:1
															tmp7 = nil } } } } } } }
//line :175:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7)).Ref()
}








func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_New() *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A) Ctor() {}
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A) Invoke_O_O__O(self, s__1839000100__1 any) any { var tmp1 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_New_O_O(s__1839000100__1, self); var tmp2 *jrt.Class; var fncls__789 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class; if fncls__789 == nil { var fncls__789d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class = fncls__789d; tmp2 = fncls__789d } else { tmp2 = fncls__789 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :185:1
func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A) Ctor_O_O(c__s__1839000100, c__iter__1839000099 any) { t.F_s__1839000100 = c__s__1839000100; t.F_iter__1839000099 = c__iter__1839000099 }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A) Invoke_O__O(self any) any { { var s__1839000100__1 any; var t_ any = t.F_s__1839000100; t.F_s__1839000100 = nil; s__1839000100__1 = t_; for { var temp__1927000414__auto____2 any; var root_716 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = s__1839000100__1; if linked_717 == nil { temp__1927000414__auto____2 = ifn_718.Invoke_O__O(arg_719) } else { temp__1927000414__auto____2 = linked_717.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_716, arg_719) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000100__3 any = temp__1927000414__auto____2; var tmp1 any; var root_720 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = s__1839000100__3; if linked_721 == nil { tmp1 = ifn_722.Invoke_O__O(arg_723) } else { tmp1 = linked_721.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_720, arg_723) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_724 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = s__1839000100__3; if linked_725 == nil { c__1927001037__auto____4 = ifn_726.Invoke_O__O(arg_727) } else { c__1927001037__auto____4 = linked_725.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_724, arg_727) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000102__6 any; var root_728 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_730 lang.IFn; if linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_729 == nil { b__1839000102__6 = ifn_730.Invoke_O__O(arg_731) } else { b__1839000102__6 = linked_729.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_728, arg_731) }; var tmp2 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_New_O_I_O(b__1839000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__745 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class; if fncls__745 == nil { var fncls__745d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class = fncls__745d; tmp3 = fncls__745d } else { tmp3 = fncls__745 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_746 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any; var root_751 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = b__1839000102__6; if linked_752 == nil { arg_749 = ifn_753.Invoke_O__O(arg_754) } else { arg_749 = linked_752.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_751, arg_754) }; var arg_750 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000099); var tmp5 any; var root_755 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = s__1839000100__3; if linked_756 == nil { tmp5 = ifn_757.Invoke_O__O(arg_758) } else { tmp5 = linked_756.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_755, arg_758) }; arg_750 = tmp4.Invoke_O__O(tmp5); if linked_747 == nil { return ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { return linked_747.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) } } else { var root_759 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any; var root_764 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = b__1839000102__6; if linked_765 == nil { arg_762 = ifn_766.Invoke_O__O(arg_767) } else { arg_762 = linked_765.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_764, arg_767) }; var arg_763 any; if linked_760 == nil { return ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { return linked_760.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) } } } else { var vec__1839000110__4 any; var root_768 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = s__1839000100__3; if linked_769 == nil { vec__1839000110__4 = ifn_770.Invoke_O__O(arg_771) } else { vec__1839000110__4 = linked_769.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_768, arg_771) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000110__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000110__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_772 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp7 any; var root_777 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, A_arbace_repr_go_layout_text_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = k__5; if linked_778 == nil { tmp7 = ifn_779.Invoke_O__O(arg_780) } else { tmp7 = linked_778.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_777, arg_780) }; var tmp8 any = tmp7; var tmp9 any; var root_781 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, A_arbace_repr_go_layout_text_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = v__6; if linked_782 == nil { tmp9 = ifn_783.Invoke_O__O(arg_784) } else { tmp9 = linked_782.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_781, arg_784) }; arg_775 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_776 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1839000099); var tmp11 any; var root_785 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = s__1839000100__3; if linked_786 == nil { tmp11 = ifn_787.Invoke_O__O(arg_788) } else { tmp11 = linked_786.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_785, arg_788) }; arg_776 = tmp10.Invoke_O__O(tmp11); if linked_773 == nil { return ifn_774.Invoke_O_O__O(arg_775, arg_776) } else { return linked_773.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_772, arg_775, arg_776) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :185:1
func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A) Ctor_O_I_O(c__b__1839000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000102 = c__b__1839000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A) Invoke_O__O(self any) any { { var i__1839000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1839000106__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000101__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000106__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000106__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_732 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = t.F_b__1839000102; var arg_736 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp3 any; var root_737 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, A_arbace_repr_go_layout_text_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = k__3; if linked_738 == nil { tmp3 = ifn_739.Invoke_O__O(arg_740) } else { tmp3 = linked_738.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_737, arg_740) }; var tmp4 any = tmp3; var tmp5 any; var root_741 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, A_arbace_repr_go_layout_text_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = v__4; if linked_742 == nil { tmp5 = ifn_743.Invoke_O__O(arg_744) } else { tmp5 = linked_742.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_741, arg_744) }; arg_736 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_733 == nil { ifn_734.Invoke_O_O__O(arg_735, arg_736) } else { linked_733.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_732, arg_735, arg_736) }; i__1839000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000101__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_layout_comment_text_A_New() *A_arbace_repr_go_layout_comment_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_comment_text_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_repr_go_layout_comment_text_A) Ctor() {}
//line :188:1
func (t *A_arbace_repr_go_layout_comment_text_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_795 any = A_arbace_repr_go_layout_A_const_109.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_797 lang.IFn
	if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = t__0; var arg_799 any = Lit_8; if linked_796 == nil { tmp1 = ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { tmp1 = linked_796.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_795, arg_798, arg_799) }
//line :191:1
	if jrt.J2g_Truth(tmp1) {
		var root_800 any = A_arbace_repr_go_layout_A_const_110.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = t__0; var arg_804 any = A_arbace_repr_go_layout_A_const_111; if linked_801 == nil { return ifn_802.Invoke_O_O__O(arg_803, arg_804) } else { return linked_801.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_800, arg_803, arg_804) } } else {
//line :191:1
			if A_arbace_repr_go_layout_A_const_41 != nil {

				var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp3 any; var root_805 any = A_arbace_repr_go_layout_A_const_112.GetRawRoot__O(); var linked_806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_805, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_807 lang.IFn; if linked_806 == nil { ifn_807 = lang.IFn_Cast(root_805) } else { ifn_807 = nil }; var arg_808 any = t__0; if linked_806 == nil { tmp3 = ifn_807.Invoke_O__O(arg_808) } else { tmp3 = linked_806.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_805, arg_808) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
//line :191:1
					return nil
				}
		}
}


func A_arbace_repr_go_layout_write_file_A_New() *A_arbace_repr_go_layout_write_file_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_layout_write_file_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_layout_write_file_A) Invoke_O_O_O__O(self, forms__0, comments__1 any) any {


	var root_809 any = A_arbace_repr_go_layout_A_const_113.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, A_arbace_repr_go_layout_write_prepared_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any; var root_814 any = A_arbace_repr_go_layout_A_const_114.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, A_arbace_repr_go_layout_prepare_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = forms__0; if linked_815 == nil { arg_812 = ifn_816.Invoke_O__O(arg_817) } else { arg_812 = linked_815.(*A_arbace_repr_go_layout_prepare_A).Invoke_O_O__O(root_814, arg_817) }; var arg_813 any = comments__1; if linked_810 == nil { return ifn_811.Invoke_O_O__O(arg_812, arg_813) } else { return linked_810.(*A_arbace_repr_go_layout_write_prepared_A).Invoke_O_O_O__O(root_809, arg_812, arg_813)
	} }
func A_arbace_repr_go_layout_write_prepared_A_New() *A_arbace_repr_go_layout_write_prepared_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_prepared_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_repr_go_layout_write_prepared_A) Ctor() {}
//line :202:1
func (t *A_arbace_repr_go_layout_write_prepared_A) Invoke_O_O_O__O(self, forms__0, comments__1 any) any { var sb__3 any = jrt.StringBuilder_New(); var line__4 any; var root_818 any = A_arbace_repr_go_layout_A_const_115.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_820 lang.IFn; if



	linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = A_arbace_repr_go_layout_A_const_116; if linked_819 == nil { line__4 = ifn_820.Invoke_O__O(arg_821) } else { line__4 = linked_819.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_818, arg_821) }; var code_QMARK___5 any; var root_822 any = /*line :202:1*/A_arbace_repr_go_layout_A_const_115.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_824 lang.IFn; if




	linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = jrt.Boolean_FALSE.Ref(); if linked_823 == nil { code_QMARK___5 = ifn_824.Invoke_O__O(arg_825) } else { code_QMARK___5 = linked_823.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_822, arg_825) }; var depth__6 any; var root_826 any = /*line :202:1*/A_arbace_repr_go_layout_A_const_115.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_828 lang.IFn; if





	linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = A_arbace_repr_go_layout_A_const_24; if linked_827 == nil { depth__6 = ifn_828.Invoke_O__O(arg_829) } else { depth__6 = linked_827.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_826, arg_829) }; var flush_comments_BANG___7 any; var tmp1 any = /*line :202:1*/A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_New_O_O_O_O_O(sb__3, code_QMARK___5, line__4, comments__1, depth__6); var tmp2 *jrt.Class; var fncls__877 *jrt.Class = A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_fn_class; if







	fncls__877 == nil { var fncls__877d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_fn_class = fncls__877d; tmp2 = fncls__877d } else { tmp2 = fncls__877 }; flush_comments_BANG___7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var newline_to_BANG___8 any; var tmp3 any = /*line :202:1*/A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_New_O_O_O_O_O(sb__3, code_QMARK___5, line__4, flush_comments_BANG___7, depth__6); var tmp4 *jrt.Class; var fncls__913 *jrt.Class = A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_fn_class; if














	fncls__913 == nil { var fncls__913d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_fn_class = fncls__913d; tmp4 = fncls__913d } else { tmp4 = fncls__913 }; newline_to_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var emit__9 any; var tmp5 any = /*line :202:1*/A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_New_O_O_O_O(newline_to_BANG___8, sb__3, code_QMARK___5, depth__6); var tmp6 *jrt.Class; var fncls__999 *jrt.Class = A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_fn_class; if






















	fncls__999 == nil { var fncls__999d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_fn_class = fncls__999d; tmp6 = fncls__999d } else { tmp6 = fncls__999 }; emit__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var seq_1839000124__10 any; var root_1004 any = /*line :202:1*/A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1006 lang.IFn; if














































	linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = forms__0; if linked_1005 == nil { seq_1839000124__10 = ifn_1006.Invoke_O__O(arg_1007) } else { seq_1839000124__10 = linked_1005.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1004, arg_1007) }; var chunk_1839000125__11 any; var count_1839000126__12 int64 = 0; var i_1839000127__13 int64 = 0; L1:
//line :202:1
	for {














































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000127__13, count_1839000126__12) { var f__14 any = lang.Indexed_Cast(chunk_1839000125__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000127__13)); var tmp7 *lang.Keyword = A_arbace_repr_go_layout_A_const_36
			if jrt.J2g_Truth(tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__14))) {
				lang.IFn_Cast(emit__9).Invoke_O__O(f__14) } else {
					var tmp8 any; var root_1037 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = code_QMARK___5; if linked_1038 == nil { tmp8 = ifn_1039.Invoke_O__O(arg_1040) } else { tmp8 = linked_1038.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1037, arg_1040) }; if jrt.J2g_Truth(tmp8) { jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__9).Invoke_O__O(f__14) }
//line :249:1
			seq_1839000124__10, chunk_1839000125__11, count_1839000126__12, i_1839000127__13 = seq_1839000124__10, chunk_1839000125__11, count_1839000126__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000127__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_1008 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = seq_1839000124__10; if linked_1009 == nil { temp__1927000414__auto____14 = ifn_1010.Invoke_O__O(arg_1011) } else { temp__1927000414__auto____14 = linked_1009.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1008, arg_1011) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1839000124__15 any = temp__1927000414__auto____14; var tmp9 any; var root_1012 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1014 lang.IFn; if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = seq_1839000124__15; if linked_1013 == nil { tmp9 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp9 = linked_1013.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1012, arg_1015) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____16 any; var root_1016 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1018 lang.IFn; if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = seq_1839000124__15; if linked_1017 == nil { c__1927000678__auto____16 = ifn_1018.Invoke_O__O(arg_1019) } else { c__1927000678__auto____16 = linked_1017.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1016, arg_1019) }; var tmp10 any; var root_1041 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = seq_1839000124__15; if linked_1042 == nil { tmp10 = ifn_1043.Invoke_O__O(arg_1044) } else { tmp10 = linked_1042.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1041, arg_1044) }; seq_1839000124__10, chunk_1839000125__11, count_1839000126__12, i_1839000127__13 = tmp10, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__16 any; var root_1020 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = seq_1839000124__15; if linked_1021 == nil { f__16 = ifn_1022.Invoke_O__O(arg_1023) } else { f__16 = linked_1021.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1020, arg_1023) }
				var tmp11 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; if jrt.J2g_Truth(tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__16))) {
					lang.IFn_Cast(emit__9).Invoke_O__O(f__16) } else {
						var tmp12 any; var root_1045 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = code_QMARK___5; if linked_1046 == nil { tmp12 = ifn_1047.Invoke_O__O(arg_1048) } else { tmp12 = linked_1046.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1045, arg_1048) }; if jrt.J2g_Truth(tmp12) { jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__9).Invoke_O__O(f__16) }
//line :249:1
				var tmp13 any; var root_1049 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = seq_1839000124__15; if linked_1050 == nil { tmp13 = ifn_1051.Invoke_O__O(arg_1052) } else { tmp13 = linked_1050.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1049, arg_1052) }; seq_1839000124__10, chunk_1839000125__11, count_1839000126__12, i_1839000127__13 = tmp13, nil, 0, 0; continue L1 } } }
//line :202:1
		break L1 }; var last_comment__10 any; var tmp14 any; var root_1024 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1026 lang.IFn; if


















































	linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = comments__1; if linked_1025 == nil { tmp14 = ifn_1026.Invoke_O__O(arg_1027) } else { tmp14 = linked_1025.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1024, arg_1027) }; if jrt.J2g_Truth(tmp14) { var root_1028 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = A_arbace_repr_go_layout_A_const_120.GetRawRoot__O(); var arg_1032 any; var root_1033 any = A_arbace_repr_go_layout_A_const_70.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = comments__1; if linked_1034 == nil { arg_1032 = ifn_1035.Invoke_O__O(arg_1036) } else { arg_1032 = linked_1034.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1033, arg_1036) }; if linked_1029 == nil { last_comment__10 = ifn_1030.Invoke_O_O__O(arg_1031, arg_1032) } else { last_comment__10 = linked_1029.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1028, arg_1031, arg_1032) } } else { last_comment__10 = A_arbace_repr_go_layout_A_const_24 }; var tmp15 bool; var na_1053 any = last_comment__10; var na_1054 any; var root_1055 any =
	A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = line__4; if linked_1056 == nil { na_1054 = ifn_1057.Invoke_O__O(arg_1058) } else { na_1054 = linked_1056.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1055, arg_1058) }; var tmp16 bool; var tmp17 bool; tmp17 = jrt.Long_InstanceOf(na_1053); if tmp17 { tmp17 = jrt.Long_InstanceOf(na_1054) }; tmp16 = tmp17; if tmp16 { var n0_1059 int64 = jrt.NN(jrt.Long_Cast(na_1053)).LongValue__J(); var n1_1060 int64 = jrt.NN(jrt.Long_Cast(na_1054)).LongValue__J(); tmp15 = n0_1059 > n1_1060 } else { var tmp18 bool; var tmp19 bool; tmp19 = jrt.Double_InstanceOf(na_1053); if tmp19 { tmp19 = jrt.Double_InstanceOf(na_1054) }; tmp18 = tmp19; if tmp18 { var n0_1059_2 float64 = jrt.NN(jrt.Double_Cast(na_1053)).DoubleValue__D(); var n1_1060_2 float64 = jrt.NN(jrt.Double_Cast(na_1054)).DoubleValue__D(); tmp15 = n1_1060_2 < n0_1059_2 } else { tmp15 = lang.Numbers_Gt_O_O__Z_NoInit(na_1053, na_1054) } }; if tmp15 {
		var root_1062 any = A_arbace_repr_go_layout_A_const_119.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = depth__6; var arg_1066 any = A_arbace_repr_go_layout_A_const_24; if linked_1063 == nil { ifn_1064.Invoke_O_O__O(arg_1065, arg_1066) } else { linked_1063.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1062, arg_1065, arg_1066) }
		lang.IFn_Cast(newline_to_BANG___8).Invoke_O__O(last_comment__10) };
	lang.IFn_Cast(flush_comments_BANG___7).Invoke__O();
	jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(Lit_49); var root_1000 any =
	A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = sb__3; if linked_1001 == nil { return ifn_1002.Invoke_O__O(arg_1003) } else { return linked_1001.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1000, arg_1003) } }
//line :210:1
func A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :210:1
func (t *A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__comments, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_comments = c__comments; t.F_depth = c__depth }
//line :210:1
func (t *A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any; var tmp1 any = t.F_comments; var tmp2 any; var root_830 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_832 lang.IFn; if
														linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = t.F_line; if linked_831 == nil { tmp2 = ifn_832.Invoke_O__O(arg_833) } else { tmp2 = linked_831.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_830, arg_833) }; temp__1927000414__auto____1 = lang.RT_Get_O_O__O_NoInit(tmp1, tmp2); if jrt.J2g_Truth(temp__1927000414__auto____1) { var cs__2 any = temp__1927000414__auto____1; var tmp3 any; var root_834 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_836 lang.IFn
															if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = t.F_code_QMARK_; if linked_835 == nil { tmp3 = ifn_836.Invoke_O__O(arg_837) } else { tmp3 = linked_835.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_834, arg_837) }; if jrt.J2g_Truth(tmp3) {
																var tmp4 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_50, nil); var tmp6 any; var root_838 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = Lit_50; var arg_842 any; var root_843 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_843, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = A_arbace_repr_go_layout_A_const_117.GetRawRoot__O(); var arg_847 any = cs__2; if linked_844 == nil { arg_842 = ifn_845.Invoke_O_O__O(arg_846, arg_847) } else { arg_842 = linked_844.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_843, arg_846, arg_847) }; if linked_839 == nil { tmp6 = ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { tmp6 = linked_839.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_838, arg_841, arg_842) }; return jrt.NN(tmp4).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))).Ref() } else {
																	var tmp7 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp8 any; var root_858 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_862 any; var root_863 any = A_arbace_repr_go_layout_A_const_118.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_865 lang.IFn; if linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any; var na_868 int64 = 2; var na_869 any; var root_870 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = t.F_depth; if linked_871 == nil { na_869 = ifn_872.Invoke_O__O(arg_873) } else { na_869 = linked_871.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_870, arg_873) }; if jrt.Long_InstanceOf(na_869) { var n0_874 int64 = na_868; var n1_875 int64 = jrt.NN(jrt.Long_Cast(na_869)).LongValue__J(); var nr_876 int64 = n0_874 * n1_875; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = n0_874 == -9223372036854775808; if tmp12 { tmp12 = n1_875 < 0 }; tmp11 = tmp12; tmp10 = !tmp11; if tmp10 { var tmp13 bool; tmp13 = n1_875 == 0; if !tmp13 { tmp13 = nr_876/n1_875 == n0_874 }; tmp10 = tmp13 }; tmp9 = tmp10; if tmp9 { arg_866 = jrt.Long_ValueOf_J__Long_NoInit(nr_876).Ref() } else { arg_866 = lang.Numbers_Multiply_J_O__Number_NoInit(na_868, na_869) } } else { arg_866 = lang.Numbers_Multiply_J_O__Number_NoInit(na_868, na_869) }; var arg_867 any = Lit_9; if linked_864 == nil { arg_862 = ifn_865.Invoke_O_O__O(arg_866, arg_867) } else { arg_862 = linked_864.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_863, arg_866, arg_867) }; if linked_859 == nil { tmp8 = ifn_860.Invoke_O_O__O(arg_861, arg_862) } else { tmp8 = linked_859.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_858, arg_861, arg_862) }; jrt.NN(tmp7).Append_O__StringBuilder(tmp8)
																	var tmp14 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_51, nil); var tmp16 any; var root_848 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = Lit_52; var arg_852 any; var root_853 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = A_arbace_repr_go_layout_A_const_117.GetRawRoot__O(); var arg_857 any = cs__2; if linked_854 == nil { arg_852 = ifn_855.Invoke_O_O__O(arg_856, arg_857) } else { arg_852 = linked_854.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_853, arg_856, arg_857) }; if linked_849 == nil { tmp16 = ifn_850.Invoke_O_O__O(arg_851, arg_852) } else { tmp16 = linked_849.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_848, arg_851, arg_852) }; return jrt.NN(tmp14).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16))).Ref() } } else {
//line :211:1
					return nil } }





func A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :217:1
func (t *A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__flush_comments_BANG_, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_flush_comments_BANG_ = c__flush_comments_BANG_; t.F_depth = c__depth }
//line :217:1
func (t *A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A) Invoke_O_O__O(self, l__1 any) any { L1: for {
	var tmp1 bool; var na_897 any; var root_899 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = t.F_line; if linked_900 == nil { na_897 = ifn_901.Invoke_O__O(arg_902) } else { na_897 = linked_900.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_899, arg_902) }; var na_898 any = l__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_897); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_898) }; tmp2 = tmp3; if tmp2 { var n0_903 int64 = jrt.NN(jrt.Long_Cast(na_897)).LongValue__J(); var n1_904 int64 = jrt.NN(jrt.Long_Cast(na_898)).LongValue__J(); tmp1 = n0_903 < n1_904 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_897); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_898) }; tmp4 = tmp5; if tmp4 { var n0_903_2 float64 = jrt.NN(jrt.Double_Cast(na_897)).DoubleValue__D(); var n1_904_2 float64 = jrt.NN(jrt.Double_Cast(na_898)).DoubleValue__D(); tmp1 = n0_903_2 < n1_904_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_897, na_898) } }; if tmp1 {
		lang.IFn_Cast(t.F_flush_comments_BANG_).Invoke__O()
		var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp6).Append_String__StringBuilder(Lit_49)
		var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_line); var tmp8 jrt.Number_I; var na_906 any = jrt.NN(lang.Volatile_Cast(t.F_line)).Deref__O(); if jrt.Long_InstanceOf(na_906) { var n0_907 int64 = jrt.NN(jrt.Long_Cast(na_906)).LongValue__J(); if n0_907 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_906) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_907 + 1)) } } else { if jrt.Double_InstanceOf(na_906) { var n0_907_2 float64 = jrt.NN(jrt.Double_Cast(na_906)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_907_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_906) } }; jrt.NN(tmp7).Reset_O__O(tmp8)
		var root_908 any = A_arbace_repr_go_layout_A_const_119.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = t.F_code_QMARK_; var arg_912 any = jrt.Boolean_FALSE.Ref(); if linked_909 == nil { ifn_910.Invoke_O_O__O(arg_911, arg_912) } else { linked_909.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_908, arg_911, arg_912) }
//line :218:1
		continue L1 }
//line :217:1
	break L1
}




	var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp10 any; var root_878 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_882 any; var root_883 any = A_arbace_repr_go_layout_A_const_118.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any; var na_888 int64 = 2; var na_889 any; var root_890 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = t.F_depth; if linked_891 == nil { na_889 = ifn_892.Invoke_O__O(arg_893) } else { na_889 = linked_891.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_890, arg_893) }; if jrt.Long_InstanceOf(na_889) { var n0_894 int64 = na_888; var n1_895 int64 = jrt.NN(jrt.Long_Cast(na_889)).LongValue__J(); var nr_896 int64 = n0_894 * n1_895; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool; tmp14 = n0_894 == -9223372036854775808; if tmp14 { tmp14 = n1_895 < 0 }; tmp13 = tmp14; tmp12 = !tmp13; if tmp12 { var tmp15 bool; tmp15 = n1_895 == 0; if !tmp15 { tmp15 = nr_896/n1_895 == n0_894 }; tmp12 = tmp15 }; tmp11 = tmp12; if tmp11 { arg_886 = jrt.Long_ValueOf_J__Long_NoInit(nr_896).Ref() } else { arg_886 = lang.Numbers_Multiply_J_O__Number_NoInit(na_888, na_889) } } else { arg_886 = lang.Numbers_Multiply_J_O__Number_NoInit(na_888, na_889) }; var arg_887 any = Lit_9; if linked_884 == nil { arg_882 = ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { arg_882 = linked_884.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) }; if linked_879 == nil { tmp10 = ifn_880.Invoke_O_O__O(arg_881, arg_882) } else { tmp10 = linked_879.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_878, arg_881, arg_882) }; return jrt.NN(tmp9).Append_O__StringBuilder(tmp10).Ref()
}
func A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_layout_write_prepared_emit__1839000122_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_prepared_emit__1839000122_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :225:1
func (t *A_arbace_repr_go_layout_write_prepared_emit__1839000122_A) Ctor_O_O_O_O(c__newline_to_BANG_, c__sb, c__code_QMARK_, c__depth any) { t.F_newline_to_BANG_ = c__newline_to_BANG_; t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_depth = c__depth }
//line :225:1
func (t *A_arbace_repr_go_layout_write_prepared_emit__1839000122_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var or__1927000174__auto____2 any; var root_938 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = x__1; if linked_939 == nil { or__1927000174__auto____2 = ifn_940.Invoke_O__O(arg_941) } else { or__1927000174__auto____2 = linked_939.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_938, arg_941) }; if jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { var root_942 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = x__1; if linked_943 == nil { and__1927000168__auto____2 = ifn_944.Invoke_O__O(arg_945) } else { and__1927000168__auto____2 = linked_943.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_942, arg_945) } }; if jrt.J2g_Truth(and__1927000168__auto____2) {
		var tmp2 any; var root_946 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = x__1; if linked_947 == nil { tmp2 = ifn_948.Invoke_O__O(arg_949) } else { tmp2 = linked_947.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_946, arg_949) }; if jrt.J2g_Truth(tmp2) { tmp1 = A_arbace_repr_go_layout_A_const_34.Invoke_O__O(x__1) } else { var tmp3 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; tmp1 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)) } } else {
//line :226:1
			tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {

				var tmp4 lang.IFn = lang.IFn_Cast(t.F_newline_to_BANG_); var tmp5 any; var root_959 any = A_arbace_repr_go_layout_A_const_32.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, A_arbace_repr_go_layout_form_line_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = x__1; if linked_960 == nil { tmp5 = ifn_961.Invoke_O__O(arg_962) } else { tmp5 = linked_960.(*A_arbace_repr_go_layout_form_line_A).Invoke_O_O__O(root_959, arg_962) }; tmp4.Invoke_O__O(tmp5) }
	var root_950 any = A_arbace_repr_go_layout_A_const_119.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = t.F_code_QMARK_; var arg_954 any = jrt.Boolean_TRUE.Ref(); if linked_951 == nil { ifn_952.Invoke_O_O__O(arg_953, arg_954) } else { linked_951.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_950, arg_953, arg_954) }
//line :225:1
	var p__2 any; var root_955 any = A_arbace_repr_go_layout_A_const_104.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, A_arbace_repr_go_layout_meta_prefix_A_fn_class); var ifn_957 lang.IFn




	if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = x__1; if linked_956 == nil { p__2 = ifn_957.Invoke_O__O(arg_958) } else { p__2 = linked_956.(*A_arbace_repr_go_layout_meta_prefix_A).Invoke_O_O__O(root_955, arg_958) }
	if jrt.J2g_Truth(p__2) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(p__2) }
	var tmp6 any; var and__1927000168__auto____2_2 any; var root_914 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_916 lang.IFn
	if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = x__1; if linked_915 == nil { and__1927000168__auto____2_2 = ifn_916.Invoke_O__O(arg_917) } else { and__1927000168__auto____2_2 = linked_915.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_914, arg_917) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp7 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)) } else { tmp6 = and__1927000168__auto____2_2 }
//line :232:1
	if jrt.J2g_Truth(tmp6) {
		var tmp8 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp9 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; return jrt.NN(tmp8).Append_String__StringBuilder(jrt.String_Cast(tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)))).Ref() } else {
//line :232:1
			var tmp10 any; var root_918 any = A_arbace_repr_go_layout_A_const_38.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class); var ifn_920 lang.IFn

			if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = x__1; if linked_919 == nil { tmp10 = ifn_920.Invoke_O__O(arg_921) } else { tmp10 = linked_919.(*A_arbace_repr_go_layout_deref_form_QMARK__A).Invoke_O_O__O(root_918, arg_921) }
//line :232:1
			if jrt.J2g_Truth(tmp10) {

				var tmp11 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp11).Append_String__StringBuilder(Lit_27); var tmp12 lang.IFn = lang.IFn_Cast(self); var tmp13 any; var root_963 any = A_arbace_repr_go_layout_A_const_106.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = x__1; if linked_964 == nil { tmp13 = ifn_965.Invoke_O__O(arg_966) } else { tmp13 = linked_964.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_963, arg_966) }; return tmp12.Invoke_O__O(tmp13) } else {
//line :232:1
					var tmp14 any; var or__1927000174__auto____2_2 any; var root_922 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_924 lang.IFn


					if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = x__1; if linked_923 == nil { or__1927000174__auto____2_2 = ifn_924.Invoke_O__O(arg_925) } else { or__1927000174__auto____2_2 = linked_923.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_922, arg_925) }; if jrt.J2g_Truth(or__1927000174__auto____2_2) { tmp14 = or__1927000174__auto____2_2 } else { var root_926 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = x__1; if linked_927 == nil { tmp14 = ifn_928.Invoke_O__O(arg_929) } else { tmp14 = linked_927.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_926, arg_929) } }
//line :232:1
					if jrt.J2g_Truth(tmp14) {



						var tmp15 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp16 *jrt.String; var tmp17 any; var root_967 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = x__1; if linked_968 == nil { tmp17 = ifn_969.Invoke_O__O(arg_970) } else { tmp17 = linked_968.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_967, arg_970) }; if jrt.J2g_Truth(tmp17) { tmp16 = Lit_28 } else { tmp16 = Lit_30 }; jrt.NN(tmp15).Append_String__StringBuilder(tmp16)
						var tmp18 *lang.Volatile = lang.Volatile_Cast(t.F_depth); var tmp19 jrt.Number_I; var na_971 any = jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O(); if jrt.Long_InstanceOf(na_971) { var n0_972 int64 = jrt.NN(jrt.Long_Cast(na_971)).LongValue__J(); if n0_972 == 9223372036854775807 { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_971) } else { tmp19 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_972 + 1)) } } else { if jrt.Double_InstanceOf(na_971) { var n0_972_2 float64 = jrt.NN(jrt.Double_Cast(na_971)).DoubleValue__D(); tmp19 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_972_2 + 1.0)) } else { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_971) } }; jrt.NN(tmp18).Reset_O__O(tmp19)
//line :232:1
						var cs__2 any; var root_973 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_975 lang.IFn





						if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = x__1; if linked_974 == nil { cs__2 = ifn_975.Invoke_O__O(arg_976) } else { cs__2 = linked_974.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_973, arg_976) }
//line :232:1
						var later__3 any = jrt.Boolean_FALSE.Ref(); L1: for {






							if jrt.J2g_Truth(cs__2) { var c__4 any; var root_977 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_979 lang.IFn
								if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = cs__2; if linked_978 == nil { c__4 = ifn_979.Invoke_O__O(arg_980) } else { c__4 = linked_978.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_977, arg_980) }
								var tmp20 any; var and__1927000168__auto____5 any = later__3; if jrt.J2g_Truth(and__1927000168__auto____5) {
									var root_983 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any; var tmp21 any; var root_987 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any = c__4; if linked_988 == nil { tmp21 = ifn_989.Invoke_O__O(arg_990) } else { tmp21 = linked_988.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_987, arg_990) }; if jrt.J2g_Truth(tmp21) { arg_986 = A_arbace_repr_go_layout_A_const_34.Invoke_O__O(c__4) } else { var and__1927000168__auto____6 any; var root_991 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = c__4; if linked_992 == nil { and__1927000168__auto____6 = ifn_993.Invoke_O__O(arg_994) } else { and__1927000168__auto____6 = linked_992.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_991, arg_994) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp22 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; arg_986 = tmp22.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(c__4)) } else { arg_986 = and__1927000168__auto____6 } }; if linked_984 == nil { tmp20 = ifn_985.Invoke_O__O(arg_986) } else { tmp20 = linked_984.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_983, arg_986) } } else {
//line :241:1
										tmp20 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp20) {

											var tmp23 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp23).Append_String__StringBuilder(Lit_9) }
								lang.IFn_Cast(self).Invoke_O__O(c__4)
								var tmp24 any; var root_995 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = cs__2; if linked_996 == nil { tmp24 = ifn_997.Invoke_O__O(arg_998) } else { tmp24 = linked_996.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_995, arg_998) }; cs__2, later__3 = tmp24, jrt.Boolean_TRUE.Ref(); continue L1 }
//line :232:1
							break L1
						}












						var tmp25 *lang.Volatile = lang.Volatile_Cast(t.F_depth); var tmp26 jrt.Number_I; var na_981 any = jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O(); if jrt.Long_InstanceOf(na_981) { var n0_982 int64 = jrt.NN(jrt.Long_Cast(na_981)).LongValue__J(); if n0_982 == -9223372036854775808 { tmp26 = lang.Numbers_Dec_O__Number_NoInit(na_981) } else { tmp26 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_982 - 1)) } } else { if jrt.Double_InstanceOf(na_981) { var n0_982_2 float64 = jrt.NN(jrt.Double_Cast(na_981)).DoubleValue__D(); tmp26 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_982_2 - 1.0)) } else { tmp26 = lang.Numbers_Dec_O__Number_NoInit(na_981) } }; jrt.NN(tmp25).Reset_O__O(tmp26)
						var tmp27 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp28 *jrt.String; var tmp29 any; var root_930 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = x__1; if linked_931 == nil { tmp29 = ifn_932.Invoke_O__O(arg_933) } else { tmp29 = linked_931.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_930, arg_933) }; if jrt.J2g_Truth(tmp29) { tmp28 = Lit_29 } else { tmp28 = Lit_31 }; return jrt.NN(tmp27).Append_String__StringBuilder(tmp28).Ref() } else {
//line :232:1
							if A_arbace_repr_go_layout_A_const_41 != nil {















								var tmp30 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp31 any; var root_934 any = A_arbace_repr_go_layout_A_const_108.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, A_arbace_repr_go_layout_atom_text_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = x__1; if linked_935 == nil { tmp31 = ifn_936.Invoke_O__O(arg_937) } else { tmp31 = linked_935.(*A_arbace_repr_go_layout_atom_text_A).Invoke_O_O__O(root_934, arg_937) }; return jrt.NN(tmp30).Append_String__StringBuilder(jrt.String_Cast(tmp31)).Ref() } else {
//line :232:1
									return nil
								}
						}
				}
		}
}























func A_arbace_repr_go_layout_write_package_A_New() *A_arbace_repr_go_layout_write_package_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_repr_go_layout_write_package_A) Ctor() {}
//line :261:1
func (t *A_arbace_repr_go_layout_write_package_A) Invoke_O_O_O_O__O(self, ns_sym__0, pkg_form__1, loads__2 any) any { var vec__1839000129__4 any = pkg_form__1; var seq__1839000130__5 any; var root_1067 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1069 lang.IFn; if


	linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; var arg_1070 any = vec__1839000129__4; if linked_1068 == nil { seq__1839000130__5 = ifn_1069.Invoke_O__O(arg_1070) } else { seq__1839000130__5 = linked_1068.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1067, arg_1070) }; var first__1839000131__6 any; var root_1071 any = /*line :261:1*/A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1073 lang.IFn; if


	linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = seq__1839000130__5; if linked_1072 == nil { first__1839000131__6 = ifn_1073.Invoke_O__O(arg_1074) } else { first__1839000131__6 = linked_1072.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1071, arg_1074) }; var seq__1839000130__7 any; var root_1075 any = /*line :261:1*/A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1077 lang.IFn; if


	linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = seq__1839000130__5; if linked_1076 == nil { seq__1839000130__7 = ifn_1077.Invoke_O__O(arg_1078) } else { seq__1839000130__7 = linked_1076.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1075, arg_1078) }; var head__8 any = first__1839000131__6; var first__1839000131__9 any; var root_1079 any = /*line :261:1*/A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1081 lang.IFn; if


	linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any = seq__1839000130__7; if linked_1080 == nil { first__1839000131__9 = ifn_1081.Invoke_O__O(arg_1082) } else { first__1839000131__9 = linked_1080.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1079, arg_1082) }; var seq__1839000130__10 any; var root_1083 any = /*line :261:1*/A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1083, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1085 lang.IFn; if


	linked_1084 == nil { ifn_1085 = lang.IFn_Cast(root_1083) } else { ifn_1085 = nil }; var arg_1086 any = seq__1839000130__7; if linked_1084 == nil { seq__1839000130__10 = ifn_1085.Invoke_O__O(arg_1086) } else { seq__1839000130__10 = linked_1084.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1083, arg_1086) }; var nm__11 any = first__1839000131__9; var opts__12 any = seq__1839000130__10; var tmp1 /*line :261:1*/*jrt.RefArray = jrt.ConstRefArray("[0,10,s4:(ns ns35:\n  (:require [arbace.go :as go]))\n\ns1:(ns1: nns3:)\n\nn", []*jrt.Class{jrt.String_class}); var tmp2 any; var root_1087 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1089 lang.IFn; if





	linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_1091 any; var iter__1927001039__auto____23 any; var tmp3 any = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_New(); var tmp4 *jrt.Class; var fncls__1158 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_fn_class; if fncls__1158 == nil { var fncls__1158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_fn_class = fncls__1158d; tmp4 = fncls__1158d } else { tmp4 = fncls__1158 }; iter__1927001039__auto____23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____23); var tmp6 any; var root_1159 any = A_arbace_repr_go_layout_A_const_121.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = A_arbace_repr_go_layout_A_const_111; var arg_1163 any = opts__12; if linked_1160 == nil { tmp6 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { tmp6 = linked_1160.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) }; arg_1091 = tmp5.Invoke_O__O(tmp6); if linked_1088 == nil { tmp2 = ifn_1089.Invoke_O_O__O(arg_1090, arg_1091) } else { tmp2 = linked_1088.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1087, arg_1090, arg_1091) }; var tmp7 any = tmp2; var tmp8 any; var root_1164 any = /*line :265:1*/A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1166 lang.IFn; if



	linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_1168 any; var iter__1927001039__auto____23_2 any; var tmp9 any = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_New(); var tmp10 *jrt.Class; var fncls__1235 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_fn_class; if fncls__1235 == nil { var fncls__1235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_fn_class = fncls__1235d; tmp10 = fncls__1235d } else { tmp10 = fncls__1235 }; iter__1927001039__auto____23_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_1168 = lang.IFn_Cast(iter__1927001039__auto____23_2).Invoke_O__O(loads__2); if linked_1165 == nil { tmp8 = ifn_1166.Invoke_O_O__O(arg_1167, arg_1168) } else { tmp8 = linked_1165.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1164, arg_1167, arg_1168) }; return /*line :265:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, ns_sym__0, nil, nil, head__8, nil, nm__11, tmp7, nil, tmp8)).Ref() }

func A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_New() *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A) Ctor() {}
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A) Invoke_O_O__O(self, s__1839000133__1 any) any { var tmp1 any = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_New_O_O(s__1839000133__1, self); var tmp2 *jrt.Class; var fncls__1157 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_fn_class; if fncls__1157 == nil { var fncls__1157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_fn_class = fncls__1157d; tmp2 = fncls__1157d } else { tmp2 = fncls__1157 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :267:1
func A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A) Ctor_O_O(c__s__1839000133, c__iter__1839000132 any) { t.F_s__1839000133 = c__s__1839000133; t.F_iter__1839000132 = c__iter__1839000132 }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A) Invoke_O__O(self any) any { { var s__1839000133__1 any; var t_ any = t.F_s__1839000133; t.F_s__1839000133 = nil; s__1839000133__1 = t_; for { var temp__1927000414__auto____2 any; var root_1092 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = s__1839000133__1; if linked_1093 == nil { temp__1927000414__auto____2 = ifn_1094.Invoke_O__O(arg_1095) } else { temp__1927000414__auto____2 = linked_1093.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1092, arg_1095) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000133__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1096 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = s__1839000133__3; if linked_1097 == nil { tmp1 = ifn_1098.Invoke_O__O(arg_1099) } else { tmp1 = linked_1097.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1096, arg_1099) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1100 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = s__1839000133__3; if linked_1101 == nil { c__1927001037__auto____4 = ifn_1102.Invoke_O__O(arg_1103) } else { c__1927001037__auto____4 = linked_1101.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1100, arg_1103) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000135__6 any; var root_1104 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1105 == nil { b__1839000135__6 = ifn_1106.Invoke_O__O(arg_1107) } else { b__1839000135__6 = linked_1105.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1104, arg_1107) }; var tmp2 any = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_New_O_I_O(b__1839000135__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1117 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_fn_class; if fncls__1117 == nil { var fncls__1117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_fn_class = fncls__1117d; tmp3 = fncls__1117d } else { tmp3 = fncls__1117 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1118 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any; var root_1123 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = b__1839000135__6; if linked_1124 == nil { arg_1121 = ifn_1125.Invoke_O__O(arg_1126) } else { arg_1121 = linked_1124.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1123, arg_1126) }; var arg_1122 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000132); var tmp5 any; var root_1127 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = s__1839000133__3; if linked_1128 == nil { tmp5 = ifn_1129.Invoke_O__O(arg_1130) } else { tmp5 = linked_1128.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1127, arg_1130) }; arg_1122 = tmp4.Invoke_O__O(tmp5); if linked_1119 == nil { return ifn_1120.Invoke_O_O__O(arg_1121, arg_1122) } else { return linked_1119.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1118, arg_1121, arg_1122) } } else { var root_1131 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any; var root_1136 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1138 lang.IFn; if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = b__1839000135__6; if linked_1137 == nil { arg_1134 = ifn_1138.Invoke_O__O(arg_1139) } else { arg_1134 = linked_1137.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1136, arg_1139) }; var arg_1135 any; if linked_1132 == nil { return ifn_1133.Invoke_O_O__O(arg_1134, arg_1135) } else { return linked_1132.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1131, arg_1134, arg_1135) } } } else { var vec__1839000143__4 any; var root_1140 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = s__1839000133__3; if linked_1141 == nil { vec__1839000143__4 = ifn_1142.Invoke_O__O(arg_1143) } else { vec__1839000143__4 = linked_1141.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1140, arg_1143) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000143__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000143__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1144 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil, Lit_9, nil); var tmp7 any; var root_1149 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, A_arbace_repr_go_layout_text_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = v__6; if linked_1150 == nil { tmp7 = ifn_1151.Invoke_O__O(arg_1152) } else { tmp7 = linked_1150.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_1149, arg_1152) }; arg_1147 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, tmp7)).Ref(); var arg_1148 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1839000132); var tmp9 any; var root_1153 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = s__1839000133__3; if linked_1154 == nil { tmp9 = ifn_1155.Invoke_O__O(arg_1156) } else { tmp9 = linked_1154.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1153, arg_1156) }; arg_1148 = tmp8.Invoke_O__O(tmp9); if linked_1145 == nil { return ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { return linked_1145.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :267:1
func A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A) Ctor_O_I_O(c__b__1839000135 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000135 = c__b__1839000135; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A) Invoke_O__O(self any) any { { var i__1839000134__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1839000139__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000134__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000139__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000139__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1108 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = t.F_b__1839000135; var arg_1112 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil, Lit_9, nil); var tmp3 any; var root_1113 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, A_arbace_repr_go_layout_text_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = v__4; if linked_1114 == nil { tmp3 = ifn_1115.Invoke_O__O(arg_1116) } else { tmp3 = linked_1114.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_1113, arg_1116) }; arg_1112 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, tmp3)).Ref(); if linked_1109 == nil { ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { linked_1109.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) }; i__1839000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000134__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_New() *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A) Ctor() {}
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A) Invoke_O_O__O(self, s__1839000149__1 any) any { var tmp1 any = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_New_O_O(s__1839000149__1, self); var tmp2 *jrt.Class; var fncls__1234 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_fn_class; if fncls__1234 == nil { var fncls__1234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_fn_class = fncls__1234d; tmp2 = fncls__1234d } else { tmp2 = fncls__1234 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :269:1
func A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A{}; t.Ctor_O_O(p0, p1); return t }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A) Ctor_O_O(c__s__1839000149, c__iter__1839000148 any) { t.F_s__1839000149 = c__s__1839000149; t.F_iter__1839000148 = c__iter__1839000148 }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A) Invoke_O__O(self any) any { { var s__1839000149__1 any; var t_ any = t.F_s__1839000149; t.F_s__1839000149 = nil; s__1839000149__1 = t_; for { var temp__1927000414__auto____2 any; var root_1169 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = s__1839000149__1; if linked_1170 == nil { temp__1927000414__auto____2 = ifn_1171.Invoke_O__O(arg_1172) } else { temp__1927000414__auto____2 = linked_1170.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1169, arg_1172) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000149__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1173 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1175 lang.IFn; if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = s__1839000149__3; if linked_1174 == nil { tmp1 = ifn_1175.Invoke_O__O(arg_1176) } else { tmp1 = linked_1174.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1173, arg_1176) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1177 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = s__1839000149__3; if linked_1178 == nil { c__1927001037__auto____4 = ifn_1179.Invoke_O__O(arg_1180) } else { c__1927001037__auto____4 = linked_1178.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1177, arg_1180) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000151__6 any; var root_1181 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1182 == nil { b__1839000151__6 = ifn_1183.Invoke_O__O(arg_1184) } else { b__1839000151__6 = linked_1182.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1181, arg_1184) }; var tmp2 any = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_New_O_I_O(b__1839000151__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1194 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_fn_class; if fncls__1194 == nil { var fncls__1194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_fn_class = fncls__1194d; tmp3 = fncls__1194d } else { tmp3 = fncls__1194 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1195 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1197 lang.IFn; if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any; var root_1200 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = b__1839000151__6; if linked_1201 == nil { arg_1198 = ifn_1202.Invoke_O__O(arg_1203) } else { arg_1198 = linked_1201.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1200, arg_1203) }; var arg_1199 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000148); var tmp5 any; var root_1204 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = s__1839000149__3; if linked_1205 == nil { tmp5 = ifn_1206.Invoke_O__O(arg_1207) } else { tmp5 = linked_1205.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1204, arg_1207) }; arg_1199 = tmp4.Invoke_O__O(tmp5); if linked_1196 == nil { return ifn_1197.Invoke_O_O__O(arg_1198, arg_1199) } else { return linked_1196.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1195, arg_1198, arg_1199) } } else { var root_1208 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any; var root_1213 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = b__1839000151__6; if linked_1214 == nil { arg_1211 = ifn_1215.Invoke_O__O(arg_1216) } else { arg_1211 = linked_1214.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1213, arg_1216) }; var arg_1212 any; if linked_1209 == nil { return ifn_1210.Invoke_O_O__O(arg_1211, arg_1212) } else { return linked_1209.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1208, arg_1211, arg_1212) } } } else { var l__4 any; var root_1217 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = s__1839000149__3; if linked_1218 == nil { l__4 = ifn_1219.Invoke_O__O(arg_1220) } else { l__4 = linked_1218.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1217, arg_1220) }; var root_1221 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_44, nil, Lit_45); var tmp7 any; var root_1226 any = A_arbace_repr_go_layout_A_const_92.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = l__4; if linked_1227 == nil { tmp7 = ifn_1228.Invoke_O__O(arg_1229) } else { tmp7 = linked_1227.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1226, arg_1229) }; arg_1224 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil)).Ref(); var arg_1225 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1839000148); var tmp9 any; var root_1230 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = s__1839000149__3; if linked_1231 == nil { tmp9 = ifn_1232.Invoke_O__O(arg_1233) } else { tmp9 = linked_1231.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1230, arg_1233) }; arg_1225 = tmp8.Invoke_O__O(tmp9); if linked_1222 == nil { return ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { return linked_1222.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :269:1
func A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A) Ctor_O_I_O(c__b__1839000151 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000151 = c__b__1839000151; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A) Invoke_O__O(self any) any { { var i__1839000150__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000150__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000150__1)); var root_1185 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = t.F_b__1839000151; var arg_1189 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_44, nil, Lit_45); var tmp3 any; var root_1190 any = A_arbace_repr_go_layout_A_const_92.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = l__2; if linked_1191 == nil { tmp3 = ifn_1192.Invoke_O__O(arg_1193) } else { tmp3 = linked_1191.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1190, arg_1193) }; arg_1189 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref(); if linked_1186 == nil { ifn_1187.Invoke_O_O__O(arg_1188, arg_1189) } else { linked_1186.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1185, arg_1188, arg_1189) }; i__1839000150__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000150__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



































type A_arbace_repr_go_layout_A struct{ jrt.Object }

var A_arbace_repr_go_layout_A_const_pool *jrt.RefArray

var A_arbace_repr_go_layout_A_const_0 *lang.Var

var A_arbace_repr_go_layout_A_const_1 any

var A_arbace_repr_go_layout_A_const_2 any

var A_arbace_repr_go_layout_A_const_3 *lang.Var

var A_arbace_repr_go_layout_A_const_4 any

var A_arbace_repr_go_layout_A_const_5 *lang.Var

var A_arbace_repr_go_layout_A_const_6 *lang.Var

var A_arbace_repr_go_layout_A_const_7 *lang.Var

var A_arbace_repr_go_layout_A_const_8 *lang.Var

var A_arbace_repr_go_layout_A_const_9 any

var A_arbace_repr_go_layout_A_const_10 *lang.Var

var A_arbace_repr_go_layout_A_const_11 *lang.Var

var A_arbace_repr_go_layout_A_const_12 *lang.Var

var A_arbace_repr_go_layout_A_const_13 *lang.Var

var A_arbace_repr_go_layout_A_const_14 *lang.Keyword

var A_arbace_repr_go_layout_A_const_15 *lang.Var

var A_arbace_repr_go_layout_A_const_16 *lang.Keyword

var A_arbace_repr_go_layout_A_const_17 *lang.Var

var A_arbace_repr_go_layout_A_const_18 *lang.Keyword

var A_arbace_repr_go_layout_A_const_19 *lang.Var

var A_arbace_repr_go_layout_A_const_20 *lang.Var

var A_arbace_repr_go_layout_A_const_21 *lang.Var

var A_arbace_repr_go_layout_A_const_22 *lang.Var

var A_arbace_repr_go_layout_A_const_23 *lang.Var

var A_arbace_repr_go_layout_A_const_24 any

var A_arbace_repr_go_layout_A_const_25 *lang.Var

var A_arbace_repr_go_layout_A_const_26 *lang.Keyword

var A_arbace_repr_go_layout_A_const_27 *lang.Var

var A_arbace_repr_go_layout_A_const_28 *lang.Keyword

var A_arbace_repr_go_layout_A_const_29 *lang.Var

var A_arbace_repr_go_layout_A_const_30 *lang.Var

var A_arbace_repr_go_layout_A_const_31 *lang.Var

var A_arbace_repr_go_layout_A_const_32 *lang.Var

var A_arbace_repr_go_layout_A_const_33 *lang.Var

var A_arbace_repr_go_layout_A_const_34 *lang.Keyword

var A_arbace_repr_go_layout_A_const_35 *lang.Var

var A_arbace_repr_go_layout_A_const_36 *lang.Keyword

var A_arbace_repr_go_layout_A_const_37 *lang.Var

var A_arbace_repr_go_layout_A_const_38 *lang.Var

var A_arbace_repr_go_layout_A_const_39 *lang.Var

var A_arbace_repr_go_layout_A_const_40 *lang.Keyword

var A_arbace_repr_go_layout_A_const_41 *lang.Keyword

var A_arbace_repr_go_layout_A_const_42 *lang.Var

var A_arbace_repr_go_layout_A_const_43 *lang.Var

var A_arbace_repr_go_layout_A_const_44 *lang.Keyword

var A_arbace_repr_go_layout_A_const_45 *lang.Var

var A_arbace_repr_go_layout_A_const_46 *lang.Var

var A_arbace_repr_go_layout_A_const_47 any

var A_arbace_repr_go_layout_A_const_48 *lang.Var

var A_arbace_repr_go_layout_A_const_49 *lang.Var

var A_arbace_repr_go_layout_A_const_50 *lang.Keyword

var A_arbace_repr_go_layout_A_const_51 *lang.Keyword

var A_arbace_repr_go_layout_A_const_52 *lang.Keyword

var A_arbace_repr_go_layout_A_const_53 *lang.Var

var A_arbace_repr_go_layout_A_const_54 *lang.Var

var A_arbace_repr_go_layout_A_const_55 *lang.Var

var A_arbace_repr_go_layout_A_const_56 *lang.Var

var A_arbace_repr_go_layout_A_const_57 *lang.Var

var A_arbace_repr_go_layout_A_const_58 *lang.Var

var A_arbace_repr_go_layout_A_const_59 *lang.Var

var A_arbace_repr_go_layout_A_const_60 *lang.Var

var A_arbace_repr_go_layout_A_const_61 *lang.Var

var A_arbace_repr_go_layout_A_const_62 *lang.Var

var A_arbace_repr_go_layout_A_const_63 *lang.Var

var A_arbace_repr_go_layout_A_const_64 *lang.Keyword

var A_arbace_repr_go_layout_A_const_65 *lang.Keyword

var A_arbace_repr_go_layout_A_const_66 *lang.Keyword

var A_arbace_repr_go_layout_A_const_67 *lang.Keyword

var A_arbace_repr_go_layout_A_const_68 *lang.Var

var A_arbace_repr_go_layout_A_const_69 *lang.Var

var A_arbace_repr_go_layout_A_const_70 *lang.Var

var A_arbace_repr_go_layout_A_const_71 *lang.Var

var A_arbace_repr_go_layout_A_const_72 *lang.Var

var A_arbace_repr_go_layout_A_const_73 *lang.Var

var A_arbace_repr_go_layout_A_const_74 *lang.Keyword

var A_arbace_repr_go_layout_A_const_75 *lang.Var

var A_arbace_repr_go_layout_A_const_76 *lang.Var

var A_arbace_repr_go_layout_A_const_77 *lang.Var

var A_arbace_repr_go_layout_A_const_78 any

var A_arbace_repr_go_layout_A_const_79 *lang.Var

var A_arbace_repr_go_layout_A_const_80 *lang.Keyword

var A_arbace_repr_go_layout_A_const_81 *lang.Var

var A_arbace_repr_go_layout_A_const_82 *lang.Var

var A_arbace_repr_go_layout_A_const_83 *lang.Var

var A_arbace_repr_go_layout_A_const_84 *lang.Var

var A_arbace_repr_go_layout_A_const_85 *lang.Var

var A_arbace_repr_go_layout_A_const_86 *lang.Var

var A_arbace_repr_go_layout_A_const_87 *lang.Var

var A_arbace_repr_go_layout_A_const_88 *lang.Var

var A_arbace_repr_go_layout_A_const_89 *lang.Var

var A_arbace_repr_go_layout_A_const_90 *lang.Keyword

var A_arbace_repr_go_layout_A_const_91 *lang.Var

var A_arbace_repr_go_layout_A_const_92 *lang.Var

var A_arbace_repr_go_layout_A_const_93 *lang.Var

var A_arbace_repr_go_layout_A_const_94 *lang.Var

var A_arbace_repr_go_layout_A_const_95 *lang.Var

var A_arbace_repr_go_layout_A_const_96 *lang.Var

var A_arbace_repr_go_layout_A_const_97 *lang.Var

var A_arbace_repr_go_layout_A_const_98 *lang.Var

var A_arbace_repr_go_layout_A_const_99 *lang.Var

var A_arbace_repr_go_layout_A_const_100 *lang.Keyword

var A_arbace_repr_go_layout_A_const_101 any

var A_arbace_repr_go_layout_A_const_102 *lang.Var

var A_arbace_repr_go_layout_A_const_103 *lang.Var

var A_arbace_repr_go_layout_A_const_104 *lang.Var

var A_arbace_repr_go_layout_A_const_105 *lang.Var

var A_arbace_repr_go_layout_A_const_106 *lang.Var

var A_arbace_repr_go_layout_A_const_107 *lang.Var

var A_arbace_repr_go_layout_A_const_108 *lang.Var

var A_arbace_repr_go_layout_A_const_109 *lang.Var

var A_arbace_repr_go_layout_A_const_110 *lang.Var

var A_arbace_repr_go_layout_A_const_111 any

var A_arbace_repr_go_layout_A_const_112 *lang.Var

var A_arbace_repr_go_layout_A_const_113 *lang.Var

var A_arbace_repr_go_layout_A_const_114 *lang.Var

var A_arbace_repr_go_layout_A_const_115 *lang.Var

var A_arbace_repr_go_layout_A_const_116 any

var A_arbace_repr_go_layout_A_const_117 *lang.Var

var A_arbace_repr_go_layout_A_const_118 *lang.Var

var A_arbace_repr_go_layout_A_const_119 *lang.Var

var A_arbace_repr_go_layout_A_const_120 *lang.Var

var A_arbace_repr_go_layout_A_const_121 *lang.Var

var A_arbace_repr_go_layout_A_init jrt.ClassInit

func A_arbace_repr_go_layout_A_Init() { if !A_arbace_repr_go_layout_A_init.Done() { A_arbace_repr_go_layout_A_init.Run(A_arbace_repr_go_layout_A_clinit) } }

func A_arbace_repr_go_layout_A_clinit() { A_arbace_repr_go_layout_A_clinit_p0(); A_arbace_repr_go_layout_A_clinit_p1(); A_arbace_repr_go_layout_A_clinit_p2(); A_arbace_repr_go_layout_A_clinit_p3(); A_arbace_repr_go_layout_A_clinit_p4(); A_arbace_repr_go_layout_A_clinit_p5(); A_arbace_repr_go_layout_A_clinit_p6(); A_arbace_repr_go_layout_A_clinit_p7(); A_arbace_repr_go_layout_A_clinit_p8(); A_arbace_repr_go_layout_A_clinit_p9(); A_arbace_repr_go_layout_A_clinit_p10() }

func A_arbace_repr_go_layout_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_layout_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 156); A_arbace_repr_go_layout_A_const_0 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[34]); A_arbace_repr_go_layout_A_const_1 = A_arbace_repr_go_layout_A_const_pool.A[35]; A_arbace_repr_go_layout_A_const_2 = A_arbace_repr_go_layout_A_const_pool.A[36]; A_arbace_repr_go_layout_A_const_3 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[37]); A_arbace_repr_go_layout_A_const_4 = A_arbace_repr_go_layout_A_const_pool.A[38]; A_arbace_repr_go_layout_A_const_5 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[39]); A_arbace_repr_go_layout_A_const_6 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[40]); A_arbace_repr_go_layout_A_const_7 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[41]); A_arbace_repr_go_layout_A_const_8 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[42]); A_arbace_repr_go_layout_A_const_9 = A_arbace_repr_go_layout_A_const_pool.A[43]; A_arbace_repr_go_layout_A_const_10 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[44]); A_arbace_repr_go_layout_A_const_11 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[45]) }

func A_arbace_repr_go_layout_A_clinit_p1() { A_arbace_repr_go_layout_A_const_12 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[46]); A_arbace_repr_go_layout_A_const_13 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[47]); A_arbace_repr_go_layout_A_const_14 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[48]); A_arbace_repr_go_layout_A_const_15 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[49]); A_arbace_repr_go_layout_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[50]); A_arbace_repr_go_layout_A_const_17 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[51]); A_arbace_repr_go_layout_A_const_18 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[52]); A_arbace_repr_go_layout_A_const_19 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[53]); A_arbace_repr_go_layout_A_const_20 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[54]); A_arbace_repr_go_layout_A_const_21 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[55]); A_arbace_repr_go_layout_A_const_22 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[56]); A_arbace_repr_go_layout_A_const_23 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[57]) }

func A_arbace_repr_go_layout_A_clinit_p2() { A_arbace_repr_go_layout_A_const_24 = A_arbace_repr_go_layout_A_const_pool.A[58]; A_arbace_repr_go_layout_A_const_25 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[59]); A_arbace_repr_go_layout_A_const_26 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[60]); A_arbace_repr_go_layout_A_const_27 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[61]); A_arbace_repr_go_layout_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[62]); A_arbace_repr_go_layout_A_const_29 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[63]); A_arbace_repr_go_layout_A_const_30 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[64]); A_arbace_repr_go_layout_A_const_31 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[65]); A_arbace_repr_go_layout_A_const_32 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[66]); A_arbace_repr_go_layout_A_const_33 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[67]); A_arbace_repr_go_layout_A_const_34 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[68]); A_arbace_repr_go_layout_A_const_35 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[69]) }

func A_arbace_repr_go_layout_A_clinit_p3() { A_arbace_repr_go_layout_A_const_36 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[70]); A_arbace_repr_go_layout_A_const_37 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[71]); A_arbace_repr_go_layout_A_const_38 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[72]); A_arbace_repr_go_layout_A_const_39 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[73]); A_arbace_repr_go_layout_A_const_40 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[74]); A_arbace_repr_go_layout_A_const_41 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[75]); A_arbace_repr_go_layout_A_const_42 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[76]); A_arbace_repr_go_layout_A_const_43 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[77]); A_arbace_repr_go_layout_A_const_44 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[78]); A_arbace_repr_go_layout_A_const_45 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[79]); A_arbace_repr_go_layout_A_const_46 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[80]); A_arbace_repr_go_layout_A_const_47 = A_arbace_repr_go_layout_A_const_pool.A[81] }

func A_arbace_repr_go_layout_A_clinit_p4() { A_arbace_repr_go_layout_A_const_48 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[82]); A_arbace_repr_go_layout_A_const_49 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[83]); A_arbace_repr_go_layout_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[84]); A_arbace_repr_go_layout_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[85]); A_arbace_repr_go_layout_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[86]); A_arbace_repr_go_layout_A_const_53 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[87]); A_arbace_repr_go_layout_A_const_54 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[88]); A_arbace_repr_go_layout_A_const_55 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[89]); A_arbace_repr_go_layout_A_const_56 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[90]); A_arbace_repr_go_layout_A_const_57 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[91]); A_arbace_repr_go_layout_A_const_58 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[92]); A_arbace_repr_go_layout_A_const_59 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[93]) }

func A_arbace_repr_go_layout_A_clinit_p5() { A_arbace_repr_go_layout_A_const_60 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[94]); A_arbace_repr_go_layout_A_const_61 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[95]); A_arbace_repr_go_layout_A_const_62 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[96]); A_arbace_repr_go_layout_A_const_63 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[97]); A_arbace_repr_go_layout_A_const_64 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[98]); A_arbace_repr_go_layout_A_const_65 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[99]); A_arbace_repr_go_layout_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[100]); A_arbace_repr_go_layout_A_const_67 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[101]); A_arbace_repr_go_layout_A_const_68 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[102]); A_arbace_repr_go_layout_A_const_69 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[103]); A_arbace_repr_go_layout_A_const_70 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[104]); A_arbace_repr_go_layout_A_const_71 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[105]) }

func A_arbace_repr_go_layout_A_clinit_p6() { A_arbace_repr_go_layout_A_const_72 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[106]); A_arbace_repr_go_layout_A_const_73 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[107]); A_arbace_repr_go_layout_A_const_74 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[108]); A_arbace_repr_go_layout_A_const_75 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[109]); A_arbace_repr_go_layout_A_const_76 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[110]); A_arbace_repr_go_layout_A_const_77 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[111]); A_arbace_repr_go_layout_A_const_78 = A_arbace_repr_go_layout_A_const_pool.A[112]; A_arbace_repr_go_layout_A_const_79 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[113]); A_arbace_repr_go_layout_A_const_80 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[114]); A_arbace_repr_go_layout_A_const_81 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[115]); A_arbace_repr_go_layout_A_const_82 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[116]); A_arbace_repr_go_layout_A_const_83 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[117]) }

func A_arbace_repr_go_layout_A_clinit_p7() { A_arbace_repr_go_layout_A_const_84 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[118]); A_arbace_repr_go_layout_A_const_85 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[119]); A_arbace_repr_go_layout_A_const_86 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[120]); A_arbace_repr_go_layout_A_const_87 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[121]); A_arbace_repr_go_layout_A_const_88 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[122]); A_arbace_repr_go_layout_A_const_89 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[123]); A_arbace_repr_go_layout_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[124]); A_arbace_repr_go_layout_A_const_91 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[125]); A_arbace_repr_go_layout_A_const_92 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[126]); A_arbace_repr_go_layout_A_const_93 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[127]); A_arbace_repr_go_layout_A_const_94 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[128]); A_arbace_repr_go_layout_A_const_95 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[129]) }

func A_arbace_repr_go_layout_A_clinit_p8() { A_arbace_repr_go_layout_A_const_96 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[130]); A_arbace_repr_go_layout_A_const_97 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[131]); A_arbace_repr_go_layout_A_const_98 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[132]); A_arbace_repr_go_layout_A_const_99 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[133]); A_arbace_repr_go_layout_A_const_100 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[134]); A_arbace_repr_go_layout_A_const_101 = A_arbace_repr_go_layout_A_const_pool.A[135]; A_arbace_repr_go_layout_A_const_102 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[136]); A_arbace_repr_go_layout_A_const_103 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[137]); A_arbace_repr_go_layout_A_const_104 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[138]); A_arbace_repr_go_layout_A_const_105 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[139]); A_arbace_repr_go_layout_A_const_106 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[140]); A_arbace_repr_go_layout_A_const_107 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[141]) }

func A_arbace_repr_go_layout_A_clinit_p9() { A_arbace_repr_go_layout_A_const_108 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[142]); A_arbace_repr_go_layout_A_const_109 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[143]); A_arbace_repr_go_layout_A_const_110 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[144]); A_arbace_repr_go_layout_A_const_111 = A_arbace_repr_go_layout_A_const_pool.A[145]; A_arbace_repr_go_layout_A_const_112 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[146]); A_arbace_repr_go_layout_A_const_113 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[147]); A_arbace_repr_go_layout_A_const_114 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[148]); A_arbace_repr_go_layout_A_const_115 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[149]); A_arbace_repr_go_layout_A_const_116 = A_arbace_repr_go_layout_A_const_pool.A[150]; A_arbace_repr_go_layout_A_const_117 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[151]); A_arbace_repr_go_layout_A_const_118 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[152]); A_arbace_repr_go_layout_A_const_119 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[153]) }

func A_arbace_repr_go_layout_A_clinit_p10() { A_arbace_repr_go_layout_A_const_120 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[154]); A_arbace_repr_go_layout_A_const_121 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[155]) }

func A_arbace_repr_go_layout_A_New() *A_arbace_repr_go_layout_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_A) Ctor() {}

func (t *A_arbace_repr_go_layout_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_A_class }

func (t *A_arbace_repr_go_layout_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_A); return ok }

func A_arbace_repr_go_layout_A_Cast(x any) *A_arbace_repr_go_layout_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_A_class)) }; return v }



type A_arbace_repr_go_layout_atom_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_atom_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_comment_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_comment_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_deref_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_eval1839000004_A struct{ jrt.Object }

func A_arbace_repr_go_layout_eval1839000004_A_New() *A_arbace_repr_go_layout_eval1839000004_A { t := &A_arbace_repr_go_layout_eval1839000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_eval1839000004_A) Ctor() {}

func (t *A_arbace_repr_go_layout_eval1839000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_eval1839000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_eval1839000004_A_class }

func (t *A_arbace_repr_go_layout_eval1839000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_eval1839000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_eval1839000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_eval1839000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_eval1839000004_A); return ok }

func A_arbace_repr_go_layout_eval1839000004_A_Cast(x any) *A_arbace_repr_go_layout_eval1839000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_eval1839000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_eval1839000004_A_class)) }; return v }



type A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_eval1839000008_A struct{ jrt.Object }

func A_arbace_repr_go_layout_eval1839000008_A_New() *A_arbace_repr_go_layout_eval1839000008_A { t := &A_arbace_repr_go_layout_eval1839000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_eval1839000008_A) Ctor() {}

func (t *A_arbace_repr_go_layout_eval1839000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_eval1839000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_eval1839000008_A_class }

func (t *A_arbace_repr_go_layout_eval1839000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_eval1839000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_eval1839000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_eval1839000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_eval1839000008_A); return ok }

func A_arbace_repr_go_layout_eval1839000008_A_Cast(x any) *A_arbace_repr_go_layout_eval1839000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_eval1839000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_eval1839000008_A_class)) }; return v }



type A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_form_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_form_line_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_iobj_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_iobj_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_key_rank_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_key_rank_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_lit_children_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A struct{ j2g_header uint64; F_i, F_c any }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A struct{ j2g_header uint64; F_i, F_v any }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_meta_prefix_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A struct{ j2g_header uint64; F_s__1839000072, F_pm, F_iter__1839000071 any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A struct{ j2g_header uint64; F_b__1839000074, F_pm any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_note_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_note_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prep_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_A struct{ j2g_header uint64; F_cursor, F_x any; F_lines_QMARK_ bool }

var A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A struct{ j2g_header uint64; F_l, F_brk, F_cursor, F_c any; F_lines_QMARK_ bool }

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A struct{ j2g_header uint64; F_i int64; F_c any }

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000036_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prepare_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prepare_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_private_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_public_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_public_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_public_meta_fn__1839000054_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_sort_keys_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_sort_keys_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_sort_keys_fn__1839000050_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A struct{ j2g_header uint64; F_s__1839000100, F_iter__1839000099 any }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A struct{ j2g_header uint64; F_b__1839000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_file_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A struct{ j2g_header uint64; F_s__1839000133, F_iter__1839000132 any }

var A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A struct{ j2g_header uint64; F_b__1839000135 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A struct{ j2g_header uint64; F_s__1839000149, F_iter__1839000148 any }

var A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A struct{ j2g_header uint64; F_b__1839000151 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_prepared_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_prepared_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_prepared_emit__1839000122_A struct{ j2g_header uint64; F_newline_to_BANG_, F_sb, F_code_QMARK_, F_depth any }

var A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A struct{ j2g_header uint64; F_sb, F_code_QMARK_, F_line, F_comments, F_depth any }

var A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A struct{ j2g_header uint64; F_sb, F_code_QMARK_, F_line, F_flush_comments_BANG_, F_depth any }

var A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_fn_class *jrt.Class
