//line aot_arbace_repr_go_layout.ae:1
package aot_arbace_repr_go_layout

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_lit"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_New() *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_layout_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_layout_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_layout_A_const_1, A_arbace_repr_go_layout_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_New() *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_repr_go_layout_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(), A_arbace_repr_go_layout_A_const_9) }















func A_arbace_repr_go_layout_private_QMARK__A_New() *A_arbace_repr_go_layout_private_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_private_QMARK__A{}; t.Ctor(); return t }
//line :17:1
func (t *A_arbace_repr_go_layout_private_QMARK__A) Ctor() {}
//line :17:1
func (t *A_arbace_repr_go_layout_private_QMARK__A) Invoke_O_O__O(self, k__0 any) any { var and__1927000168__auto____2 any; var root_20 any = A_arbace_repr_go_layout_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = k__0; if linked_21 == nil { and__1927000168__auto____2 = ifn_22.Invoke_O__O(arg_23) } else { and__1927000168__auto____2 = linked_21.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_20, arg_23) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_repr_go_layout_A_const_11.GetRawRoot__O(); var tmp2 any; var root_24 any = A_arbace_repr_go_layout_A_const_12.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = k__0; if linked_25 == nil { tmp2 = ifn_26.Invoke_O__O(arg_27) } else { tmp2 = linked_25.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_24, arg_27) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_layout_iobj_QMARK__A_New() *A_arbace_repr_go_layout_iobj_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_iobj_QMARK__A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_repr_go_layout_iobj_QMARK__A) Ctor() {}
//line :19:1
func (t *A_arbace_repr_go_layout_iobj_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.IObj_InstanceOf(x__0)).Ref() }

func A_arbace_repr_go_layout_deref_form_QMARK__A_New() *A_arbace_repr_go_layout_deref_form_QMARK__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_deref_form_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_repr_go_layout_deref_form_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_repr_go_layout_deref_form_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var root_28 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = x__0; if linked_29 == nil { and__1927000168__auto____2 = ifn_30.Invoke_O__O(arg_31) } else { and__1927000168__auto____2 = linked_29.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_28, arg_31) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 *lang.Keyword = A_arbace_repr_go_layout_A_const_14; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_layout_form_line_A_New() *A_arbace_repr_go_layout_form_line_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_form_line_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_repr_go_layout_form_line_A) Ctor() {}
//line :23:1
func (t *A_arbace_repr_go_layout_form_line_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 any; var root_32 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_34 lang.IFn
	if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = x__0; if linked_33 == nil { tmp1 = ifn_34.Invoke_O__O(arg_35) } else { tmp1 = linked_33.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_32, arg_35) }
//line :26:1
	if jrt.J2g_Truth(tmp1) {
		return A_arbace_repr_go_layout_A_const_16.Invoke_O__O(x__0) } else {
//line :26:1
			var tmp2 any; var root_36 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_38 lang.IFn

			if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = x__0; if linked_37 == nil { tmp2 = ifn_38.Invoke_O__O(arg_39) } else { tmp2 = linked_37.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_36, arg_39) }
//line :26:1
			if jrt.J2g_Truth(tmp2) {

				var tmp3 *lang.Keyword = A_arbace_repr_go_layout_A_const_18; return tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else {
//line :26:1
					return nil
				}
		}
}



func A_arbace_repr_go_layout_note_BANG__A_New() *A_arbace_repr_go_layout_note_BANG__A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_note_BANG__A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_repr_go_layout_note_BANG__A) Ctor() {}
//line :33:1
func (t *A_arbace_repr_go_layout_note_BANG__A) Invoke_O_O__O(self, k__0 any) any { if jrt.J2g_Truth(A_arbace_repr_go_layout_A_const_19.Get__O()) { var root_40 any = A_arbace_repr_go_layout_A_const_20.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = A_arbace_repr_go_layout_A_const_19.Get__O(); var arg_44 any = A_arbace_repr_go_layout_A_const_21.GetRawRoot__O(); var arg_45 any = k__0; var arg_46 any; var root_47 any = A_arbace_repr_go_layout_A_const_22.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_repr_go_layout_A_const_23.GetRawRoot__O(); var arg_51 any = A_arbace_repr_go_layout_A_const_24; if linked_48 == nil { arg_46 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { arg_46 = linked_48.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; if linked_41 == nil { return ifn_42.Invoke_O_O_O_O__O(arg_43, arg_44, arg_45, arg_46) } else { return linked_41.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_40, arg_43, arg_44, arg_45, arg_46) } } else { return nil } }



func A_arbace_repr_go_layout_prep_A_New() *A_arbace_repr_go_layout_prep_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_repr_go_layout_prep_A) Ctor() {}
//line :37:1
func (t *A_arbace_repr_go_layout_prep_A) Invoke_O_O_O__O(self, x__0, cursor__1 any) any {


	var tmp1 any; var or__1927000174__auto____3 any; var root_52 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_54 lang.IFn
	if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = x__0; if linked_53 == nil { or__1927000174__auto____3 = ifn_54.Invoke_O__O(arg_55) } else { or__1927000174__auto____3 = linked_53.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_52, arg_55) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_56 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = x__0; if linked_57 == nil { tmp1 = ifn_58.Invoke_O__O(arg_59) } else { tmp1 = linked_57.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_56, arg_59) } }
//line :40:1
	if jrt.J2g_Truth(tmp1) {

		var tmp2 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0))) { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { var lines_QMARK___3 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_28); var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(x__0); var vec__1839000017__5 any; var tmp3 *lang.Compiler_AOTFn; var fnbody__202 any = A_arbace_repr_go_layout_prep_fn__1839000020_A_New_O_O_Z(cursor__1, x__0, lines_QMARK___3); var tmp4 *jrt.Class
			var fncls__201 /*line :42:1*/*jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class




			if fncls__201 == nil { var fncls__201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__202); A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class = fncls__201d; tmp4 = fncls__201d } else { tmp4 = fncls__201 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__202, tmp4, nil); vec__1839000017__5 = Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()
//line :42:1
			var kids__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(1), nil); var breaks__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(2), nil); var apos__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(3), nil); var afull__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000017__5, lang.RT_IntCast_J__I_NoInit(4), nil); var x_SINGLEQUOTE___11 any; var tmp5 any; var root_203 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_205 lang.IFn
































			if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = x__0; if linked_204 == nil { tmp5 = ifn_205.Invoke_O__O(arg_206) } else { tmp5 = linked_204.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_203, arg_206) }; if jrt.J2g_Truth(tmp5) { var root_207 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = A_arbace_repr_go_layout_A_const_49.GetRawRoot__O(); var arg_211 any = kids__6; if linked_208 == nil { x_SINGLEQUOTE___11 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { x_SINGLEQUOTE___11 = linked_208.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) } } else { x_SINGLEQUOTE___11 = kids__6 }
//line :42:1
			var m__12 any; var G__1839000034__12_ any = m__4; var G__1839000034__13_ any; var tmp6 any
			var and__1927000168__auto____13 bool = lines_QMARK___3

































			if and__1927000168__auto____13 { var root_212 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = breaks__8; if linked_213 == nil { tmp6 = ifn_214.Invoke_O__O(arg_215) } else { tmp6 = linked_213.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_212, arg_215) } } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____13).Ref() }
//line :76:1
			if jrt.J2g_Truth(tmp6) {
				var root_216 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = G__1839000034__12_; var arg_220 any = A_arbace_repr_go_layout_A_const_50; var arg_221 any = breaks__8; if linked_217 == nil { G__1839000034__13_ = ifn_218.Invoke_O_O_O__O(arg_219, arg_220, arg_221) } else { G__1839000034__13_ = linked_217.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_216, arg_219, arg_220, arg_221) } } else {
//line :76:1
					G__1839000034__13_ = G__1839000034__12_ }
//line :42:1
			var G__1839000034__14_ any; var tmp7 any; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_51)



































			if and__1927000168__auto____14 { var root_222 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = apos__9; if linked_223 == nil { tmp7 = ifn_224.Invoke_O__O(arg_225) } else { tmp7 = linked_223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_222, arg_225) } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() }
//line :76:1
			if jrt.J2g_Truth(tmp7) {

				var root_226 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = G__1839000034__13_; var arg_230 any = A_arbace_repr_go_layout_A_const_52; var arg_231 any = apos__9; if linked_227 == nil { G__1839000034__14_ = ifn_228.Invoke_O_O_O__O(arg_229, arg_230, arg_231) } else { G__1839000034__14_ = linked_227.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_226, arg_229, arg_230, arg_231) } } else {
//line :76:1
					G__1839000034__14_ = G__1839000034__13_ }; if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_51) {


						var root_232 any = A_arbace_repr_go_layout_A_const_53.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = G__1839000034__14_; var arg_236 any; var root_237 any = A_arbace_repr_go_layout_A_const_54.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_241 any; var root_243 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any; var fnbody__256 any = A_arbace_repr_go_layout_prep_fn__1839000036_A_New(); var tmp8 *jrt.Class; var fncls__255 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class; if fncls__255 == nil { var fncls__255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class = fncls__255d; tmp8 = fncls__255d } else { tmp8 = fncls__255 }; arg_246 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__256, tmp8, nil); if linked_244 == nil { arg_241 = ifn_245.Invoke_O__O(arg_246) } else { arg_241 = linked_244.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_243, arg_246) }; var arg_242 any = afull__10; if linked_238 == nil { arg_236 = ifn_239.Invoke_O_O_O__O(arg_240, arg_241, arg_242) } else { arg_236 = linked_238.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_237, arg_240, arg_241, arg_242) }; if linked_233 == nil { m__12 = ifn_234.Invoke_O_O__O(arg_235, arg_236) } else { m__12 = linked_233.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_232, arg_235, arg_236) } } else {
//line :76:1
							m__12 = G__1839000034__14_ }
//line :42:1
			var tmp9 any; var root_257 any = A_arbace_repr_go_layout_A_const_56.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_259 lang.IFn





































			if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = x_SINGLEQUOTE___11; var arg_261 any = m__12; if linked_258 == nil { tmp9 = ifn_259.Invoke_O_O__O(arg_260, arg_261) } else { tmp9 = linked_258.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_257, arg_260, arg_261) }
//line :42:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp9, cursor__7) } } else {
//line :40:1
				if A_arbace_repr_go_layout_A_const_41 != nil { return lang.Tuple_Create_O_O__IPersistentVector(x__0, cursor__1) } else { return nil
				}
			}
}



func A_arbace_repr_go_layout_prep_fn__1839000020_A_New_O_O_Z(p0, p1 any, p2 bool) *A_arbace_repr_go_layout_prep_fn__1839000020_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_A{}; t.Ctor_O_O_Z(p0, p1, p2); return t }
//line :47:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_A) Ctor_O_O_Z(c__cursor, c__x any, c__lines_QMARK_ bool) { t.F_cursor = c__cursor; t.F_x = c__x; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :47:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var xs__2 any; var root_60 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var t_ any = t.F_x; t.F_x = nil; arg_63 = t_; if linked_61 == nil { xs__2 = ifn_62.Invoke_O__O(arg_63) } else { xs__2 = linked_61.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_60, arg_63) }; var cursor__3 any; var t__2 any = t.F_cursor; t.F_cursor = nil; cursor__3 = t__2; var acc__4 any = lang.PersistentVector_EMPTY.Ref(); var breaks__5 any = lang.PersistentVector_EMPTY.Ref(); var apos__6 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O(); var afull__7 any = lang.PersistentArrayMap_EMPTY.Ref(); L1: for { var temp__1927000408__auto____8 any; var root_67 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_69 lang.IFn
											if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = xs__2; if linked_68 == nil { temp__1927000408__auto____8 = ifn_69.Invoke_O__O(arg_70) } else { temp__1927000408__auto____8 = linked_68.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_67, arg_70) }; if jrt.J2g_Truth(temp__1927000408__auto____8) { var c__9 any = temp__1927000408__auto____8; var l__10 any; var root_71 any = A_arbace_repr_go_layout_A_const_32.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, A_arbace_repr_go_layout_form_line_A_fn_class); var ifn_73 lang.IFn
												if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = c__9; if linked_72 == nil { l__10 = ifn_73.Invoke_O__O(arg_74) } else { l__10 = linked_72.(*A_arbace_repr_go_layout_form_line_A).Invoke_O_O__O(root_71, arg_74) }
//line :48:1
		var cursor0__11 any = cursor__3; var brk__12 any
		var and__1927000168__auto____12 any = l__10

		if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp1 bool; var na_75 any = l__10; var na_76 any = cursor__3; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_75); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_76) }; tmp2 = tmp3; if tmp2 { var n0_77 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); var n1_78 int64 = jrt.NN(jrt.Long_Cast(na_76)).LongValue__J(); tmp1 = n0_77 > n1_78 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_75); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_76) }; tmp4 = tmp5; if tmp4 { var n0_77_2 float64 = jrt.NN(jrt.Double_Cast(na_75)).DoubleValue__D(); var n1_78_2 float64 = jrt.NN(jrt.Double_Cast(na_76)).DoubleValue__D(); tmp1 = n1_78_2 < n0_77_2 } else { tmp1 = lang.Numbers_Gt_O_O__Z_NoInit(na_75, na_76) } }; brk__12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else { brk__12 = and__1927000168__auto____12 }
//line :48:1
		var c__13 any; var tmp6 any; var root_80 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_82 lang.IFn




		if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = c__9; if linked_81 == nil { tmp6 = ifn_82.Invoke_O__O(arg_83) } else { tmp6 = linked_81.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_80, arg_83) }
//line :52:1
		if jrt.J2g_Truth(tmp6) {
			var root_84 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = c__9; var arg_88 any = A_arbace_repr_go_layout_A_const_34; var arg_89 any = brk__12; if linked_85 == nil { c__13 = ifn_86.Invoke_O_O_O__O(arg_87, arg_88, arg_89) } else { c__13 = linked_85.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_84, arg_87, arg_88, arg_89) } } else {
//line :52:1
				var tmp7 any; var root_90 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_92 lang.IFn

				if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = c__9; if linked_91 == nil { tmp7 = ifn_92.Invoke_O__O(arg_93) } else { tmp7 = linked_91.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_90, arg_93) }
//line :52:1
				if jrt.J2g_Truth(tmp7) {


					var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_35.GetRawRoot__O()); var tmp9 *lang.Compiler_AOTFn; var fnbody__147 any = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_New_O_O_O_O_Z(l__10, brk__12, cursor__3, c__9, t.F_lines_QMARK_); var tmp10 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__147); A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class = fncls__146d; tmp10 = fncls__146d } else { tmp10 = fncls__146 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__147, tmp10, nil); c__13 = tmp8.Invoke_O_O__O(c__9, tmp9.Ref()) } else {
//line :52:1
						if A_arbace_repr_go_layout_A_const_41 != nil { c__13 = c__9 } else { c__13 = nil } } }
//line :48:1
		var cursor__14 any













		if jrt.J2g_Truth(brk__12) { cursor__14 = l__10 } else { cursor__14 = cursor__3 }
//line :48:1
		var vec__1839000021__15 any; var root_148 any = A_arbace_repr_go_layout_A_const_42.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, A_arbace_repr_go_layout_prep_A_fn_class); var ifn_150 lang.IFn














		if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = c__13; var arg_152 any = cursor__14; if linked_149 == nil { vec__1839000021__15 = ifn_150.Invoke_O_O__O(arg_151, arg_152) } else { vec__1839000021__15 = linked_149.(*A_arbace_repr_go_layout_prep_A).Invoke_O_O_O__O(root_148, arg_151, arg_152) }
//line :48:1
		var c__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000021__15, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000021__15, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp11 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp12 any; var root_153 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_155 lang.IFn















		if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = xs__2; if linked_154 == nil { tmp12 = ifn_155.Invoke_O__O(arg_156) } else { tmp12 = linked_154.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_153, arg_156) }; var tmp13 any = tmp12; var tmp14 any; var root_157 any = A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = acc__4; var arg_161 any = c__16; if linked_158 == nil { tmp14 = ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { tmp14 = linked_158.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) }; var tmp15 any = tmp14; var tmp16 any; var tmp17 any
		var and__1927000168__auto____18 any = brk__12

		if jrt.J2g_Truth(and__1927000168__auto____18) { var root_162 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = c__16; if linked_163 == nil { tmp17 = ifn_164.Invoke_O__O(arg_165) } else { tmp17 = linked_163.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_162, arg_165) } } else { tmp17 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp17) { var root_166 any = A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = breaks__5; var arg_170 any; var tmp18 jrt.Number_I; var na_171 any = cursor0__11; if jrt.Long_InstanceOf(na_171) { var n0_172 int64 = jrt.NN(jrt.Long_Cast(na_171)).LongValue__J(); if n0_172 == 9223372036854775807 { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_171) } else { tmp18 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_172 + 1)) } } else { if jrt.Double_InstanceOf(na_171) { var n0_172_2 float64 = jrt.NN(jrt.Double_Cast(na_171)).DoubleValue__D(); tmp18 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_172_2 + 1.0)) } else { tmp18 = lang.Numbers_Inc_O__Number_NoInit(na_171) } }; if lang.Util_Equiv_O_O__Z_NoInit(l__10, tmp18) { arg_170 = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref() } else { arg_170 = lang.Tuple_Create_O_O__IPersistentVector(jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(), l__10) }; if linked_167 == nil { tmp16 = ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { tmp16 = linked_167.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_166, arg_169, arg_170) } } else { tmp16 = breaks__5 }
//line :64:1
		var tmp19 any = tmp16; var tmp20 any; var tmp21 any; var and__1927000168__auto____18_2 any; var root_173 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_175 lang.IFn



		if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = c__16; if linked_174 == nil { and__1927000168__auto____18_2 = ifn_175.Invoke_O__O(arg_176) } else { and__1927000168__auto____18_2 = linked_174.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_173, arg_176) }; if jrt.J2g_Truth(and__1927000168__auto____18_2) { tmp21 = A_arbace_repr_go_layout_A_const_44.Invoke_O__O(c__16) } else { tmp21 = and__1927000168__auto____18_2 }; if jrt.J2g_Truth(tmp21) { var root_177 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = apos__6; var arg_181 any = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(); var arg_182 any = A_arbace_repr_go_layout_A_const_44.Invoke_O__O(c__16); if linked_178 == nil { tmp20 = ifn_179.Invoke_O_O_O__O(arg_180, arg_181, arg_182) } else { tmp20 = linked_178.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_177, arg_180, arg_181, arg_182) } } else { tmp20 = apos__6 }
//line :64:1
		var tmp22 any = tmp20; var tmp23 any; var tmp24 any; var root_183 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_185 lang.IFn





		if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = c__16; if linked_184 == nil { tmp24 = ifn_185.Invoke_O__O(arg_186) } else { tmp24 = linked_184.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_183, arg_186) }; if jrt.J2g_Truth(tmp24) {
			var root_187 any = A_arbace_repr_go_layout_A_const_45.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any; var fnbody__200 any = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_New_J_O(i__1, c__16); var tmp25 *jrt.Class; var fncls__199 *jrt.Class = A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class; if fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__200); A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class = fncls__199d; tmp25 = fncls__199d } else { tmp25 = fncls__199 }; arg_190 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__200, tmp25, nil); var arg_191 any = afull__7; var arg_192 any = A_arbace_repr_go_layout_A_const_47; if linked_188 == nil { tmp23 = ifn_189.Invoke_O_O_O__O(arg_190, arg_191, arg_192) } else { tmp23 = linked_188.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_187, arg_190, arg_191, arg_192) } } else {
//line :70:1
				tmp23 = afull__7 }
//line :64:1
		i__1, xs__2, cursor__3, acc__4, breaks__5, apos__6, afull__7 = tmp11, tmp13, cursor__17, tmp15, tmp19, tmp22, tmp23; continue L1 } else {
//line :48:1
			return lang.Tuple_Create_O_O_O_O_O__IPersistentVector(acc__4, cursor__3, breaks__5, apos__6, afull__7) } } }; /*line :47:1*/panic("j2g: unreachable") }







func A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_New_O_O_O_O_Z(p0, p1, p2, p3 any, p4 bool) *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A{}; t.Ctor_O_O_O_O_Z(p0, p1, p2, p3, p4); return t }
//line :55:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A) Ctor_O_O_O_O_Z(c__l, c__brk, c__cursor, c__c any, c__lines_QMARK_ bool) { t.F_l = c__l; t.F_brk = c__brk; t.F_cursor = c__cursor; t.F_c = c__c; t.F_lines_QMARK_ = c__lines_QMARK_ }
//line :55:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A) Invoke_O_O__O(self, cm__1 any) any { var G__1839000025__2_ any; var root_99 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_101 lang.IFn; if
														linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = cm__1; var arg_103 any = A_arbace_repr_go_layout_A_const_36; var arg_104 any = t.F_brk; if linked_100 == nil { G__1839000025__2_ = ifn_101.Invoke_O_O_O__O(arg_102, arg_103, arg_104) } else { G__1839000025__2_ = linked_100.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_99, arg_102, arg_103, arg_104) }; var G__1839000025__3_ any; var tmp1 any; var and__1927000168__auto____3 bool = /*line :55:1*/t.F_lines_QMARK_; if and__1927000168__auto____3 {

		var and__1927000168__auto____4 any = t.F_brk; if jrt.J2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 any; var root_105 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any; var root_109 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = t.F_c; if linked_110 == nil { arg_108 = ifn_111.Invoke_O__O(arg_112) } else { arg_108 = linked_110.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_109, arg_112) }; if linked_106 == nil { or__1927000174__auto____5 = ifn_107.Invoke_O__O(arg_108) } else { or__1927000174__auto____5 = linked_106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { var root_113 any = A_arbace_repr_go_layout_A_const_38.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = t.F_c; if linked_114 == nil { tmp1 = ifn_115.Invoke_O__O(arg_116) } else { tmp1 = linked_114.(*A_arbace_repr_go_layout_deref_form_QMARK__A).Invoke_O_O__O(root_113, arg_116) } } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if /*line :56:1*/ jrt.J2g_Truth(tmp1) {

			var root_117 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = G__1839000025__2_; var arg_121 any = A_arbace_repr_go_layout_A_const_16; var arg_122 any = t.F_l; if linked_118 == nil { G__1839000025__3_ = ifn_119.Invoke_O_O_O__O(arg_120, arg_121, arg_122) } else { G__1839000025__3_ = linked_118.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_117, arg_120, arg_121, arg_122) } } else {
//line :56:1
				G__1839000025__3_ = G__1839000025__2_ }; var tmp2 any; var and__1927000168__auto____4_2 bool = t.F_lines_QMARK_; if and__1927000168__auto____4_2 {


					var and__1927000168__auto____5 any = t.F_l; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_123 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = t.F_brk; if linked_124 == nil { and__1927000168__auto____6 = ifn_125.Invoke_O__O(arg_126) } else { and__1927000168__auto____6 = linked_124.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_123, arg_126) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool; var na_127 any = t.F_l; var na_128 any = t.F_cursor; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_127); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_128) }; tmp3 = tmp4; if tmp3 { var n0_129 int64 = jrt.NN(jrt.Long_Cast(na_127)).LongValue__J(); var n1_130 int64 = jrt.NN(jrt.Long_Cast(na_128)).LongValue__J(); and__1927000168__auto____7 = n0_129 < n1_130 } else { var tmp5 bool; var tmp6 bool; tmp6 = jrt.Double_InstanceOf(na_127); if tmp6 { tmp6 = jrt.Double_InstanceOf(na_128) }; tmp5 = tmp6; if tmp5 { var n0_129_2 float64 = jrt.NN(jrt.Double_Cast(na_127)).DoubleValue__D(); var n1_130_2 float64 = jrt.NN(jrt.Double_Cast(na_128)).DoubleValue__D(); and__1927000168__auto____7 = n0_129_2 < n1_130_2 } else { and__1927000168__auto____7 = lang.Numbers_Lt_O_O__Z_NoInit(na_127, na_128) } }; if and__1927000168__auto____7 { var root_132 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = t.F_c; if linked_133 == nil { tmp2 = ifn_134.Invoke_O__O(arg_135) } else { tmp2 = linked_133.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_132, arg_135) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4_2).Ref() }; if /*line :56:1*/ jrt.J2g_Truth(tmp2) { var cm__4 any = G__1839000025__3_; var root_142 any = A_arbace_repr_go_layout_A_const_39.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_repr_go_layout_note_BANG__A_fn_class); var ifn_144 lang.IFn



						if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_repr_go_layout_A_const_40; if linked_143 == nil { ifn_144.Invoke_O__O(arg_145) } else { linked_143.(*A_arbace_repr_go_layout_note_BANG__A).Invoke_O_O__O(root_142, arg_145) }; var root_136 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = cm__4; var arg_140 any = A_arbace_repr_go_layout_A_const_16; var arg_141 any = t.F_l; if linked_137 == nil { return ifn_138.Invoke_O_O_O__O(arg_139, arg_140, arg_141) } else { return linked_137.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_136, arg_139, arg_140, arg_141) } } else {
//line :56:1
							return G__1839000025__3_ } }














func A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_New_J_O(p0 int64, p1 any) *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A{}; t.Ctor_J_O(p0, p1); return t }
//line :71:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A) Ctor_J_O(c__i int64, c__c any) { t.F_i = c__i; t.F_c = c__c }
//line :71:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A) Invoke_O_O_O__O(self, af__1, p__1839000027__2 any) any { var vec__1839000029__3 any = p__1839000027__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000029__3, lang.RT_IntCast_J__I_NoInit(0), nil); var mk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000029__3, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000408__auto____6 any = lang.RT_Get_O_O__O_NoInit(t.F_c, k__4); if jrt.J2g_Truth(temp__1927000408__auto____6) { var v__7 any = temp__1927000408__auto____6; var root_193 any = A_arbace_repr_go_layout_A_const_46.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = af__1; var arg_197 any = lang.Tuple_Create_O_O__IPersistentVector(mk__5, jrt.Long_ValueOf_J__Long_NoInit(t.F_i).Ref()); var arg_198 any = v__7; if linked_194 == nil { return ifn_195.Invoke_O_O_O__O(arg_196, arg_197, arg_198) } else { return linked_194.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_193, arg_196, arg_197, arg_198) } } else { return af__1 } }







func A_arbace_repr_go_layout_prep_fn__1839000036_A_New() *A_arbace_repr_go_layout_prep_fn__1839000036_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prep_fn__1839000036_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000036_A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_layout_prep_fn__1839000036_A) Invoke_O_O__O(self, p__1839000035__1 any) any { var vec__1839000037__2 any = p__1839000035__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000037__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000037__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_247 any = A_arbace_repr_go_layout_A_const_54.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O(); var arg_251 any = v__4; if linked_248 == nil { tmp1 = ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { tmp1 = linked_248.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_247, arg_250, arg_251) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }



func A_arbace_repr_go_layout_prepare_A_New() *A_arbace_repr_go_layout_prepare_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_prepare_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_go_layout_prepare_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_go_layout_prepare_A) Invoke_O_O__O(self, forms__0 any) any { { var fs__2 any = forms__0; var cursor__3 any = lang.RT_Box_J__Number_NoInit(1); var acc__4 any = lang.PersistentVector_EMPTY.Ref(); L1: for { var temp__1927000408__auto____5 any; var root_262 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_264 lang.IFn



	if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = fs__2; if linked_263 == nil { temp__1927000408__auto____5 = ifn_264.Invoke_O__O(arg_265) } else { temp__1927000408__auto____5 = linked_263.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_262, arg_265) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var f__6 any = temp__1927000408__auto____5; var l__7 any; var root_266 any = A_arbace_repr_go_layout_A_const_32.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, A_arbace_repr_go_layout_form_line_A_fn_class); var ifn_268 lang.IFn
		if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = f__6; if linked_267 == nil { l__7 = ifn_268.Invoke_O__O(arg_269) } else { l__7 = linked_267.(*A_arbace_repr_go_layout_form_line_A).Invoke_O_O__O(root_266, arg_269) }
//line :87:1
		var brk__8 any
		var and__1927000168__auto____8 any = l__7
		if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp1 bool; var na_270 any = l__7; var na_271 any = cursor__3; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_270); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_271) }; tmp2 = tmp3; if tmp2 { var n0_272 int64 = jrt.NN(jrt.Long_Cast(na_270)).LongValue__J(); var n1_273 int64 = jrt.NN(jrt.Long_Cast(na_271)).LongValue__J(); tmp1 = n0_272 > n1_273 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_270); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_271) }; tmp4 = tmp5; if tmp4 { var n0_272_2 float64 = jrt.NN(jrt.Double_Cast(na_270)).DoubleValue__D(); var n1_273_2 float64 = jrt.NN(jrt.Double_Cast(na_271)).DoubleValue__D(); tmp1 = n1_273_2 < n0_272_2 } else { tmp1 = lang.Numbers_Gt_O_O__Z_NoInit(na_270, na_271) } }; brk__8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else { brk__8 = and__1927000168__auto____8 }
//line :87:1
		var f__9 any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_35.GetRawRoot__O()).Invoke_O_O_O_O__O(f__6, A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(), A_arbace_repr_go_layout_A_const_36, brk__8); var cursor__10 any



		if jrt.J2g_Truth(brk__8) { cursor__10 = l__7 } else { cursor__10 = cursor__3 }
//line :87:1
		var vec__1839000045__11 any; var root_282 any = A_arbace_repr_go_layout_A_const_42.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, A_arbace_repr_go_layout_prep_A_fn_class); var ifn_284 lang.IFn




		if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = f__9; var arg_286 any = cursor__10; if linked_283 == nil { vec__1839000045__11 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { vec__1839000045__11 = linked_283.(*A_arbace_repr_go_layout_prep_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }
//line :87:1
		var f__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000045__11, lang.RT_IntCast_J__I_NoInit(0), nil); var cursor__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000045__11, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_287 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_289 lang.IFn





		if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = fs__2; if linked_288 == nil { tmp6 = ifn_289.Invoke_O__O(arg_290) } else { tmp6 = linked_288.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_287, arg_290) }; var tmp7 any = tmp6; var tmp8 any; var root_291 any = A_arbace_repr_go_layout_A_const_8.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = acc__4; var arg_295 any = f__12; if linked_292 == nil { tmp8 = ifn_293.Invoke_O_O__O(arg_294, arg_295) } else { tmp8 = linked_292.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_291, arg_294, arg_295) }; fs__2, cursor__3, acc__4 = tmp7, cursor__13, tmp8; continue L1 } else {
//line :87:1
			return acc__4 } } }; /*line :83:1*/panic("j2g: unreachable") }



















func A_arbace_repr_go_layout_key_rank_A_New() *A_arbace_repr_go_layout_key_rank_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_key_rank_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_repr_go_layout_key_rank_A) Ctor() {}
//line :103:1
func (t *A_arbace_repr_go_layout_key_rank_A) Invoke_O_O__O(self, k__0 any) any { var i__2 int32 = jrt.List_Cast(A_arbace_repr_go_layout_A_const_57.GetRawRoot__O()).IndexOf_O__I(k__0); if

	lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_layout_A_const_57.GetRawRoot__O())).Ref() } else { return jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref() } }

func A_arbace_repr_go_layout_sort_keys_A_New() *A_arbace_repr_go_layout_sort_keys_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_sort_keys_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_layout_sort_keys_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_layout_sort_keys_A) Invoke_O_O__O(self, ks__0 any) any {
	var root_296 any = A_arbace_repr_go_layout_A_const_58.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any; var fnbody__310 any = A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_New(); var tmp1 *jrt.Class; var fncls__309 *jrt.Class = A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class; if fncls__309 == nil { var fncls__309d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class = fncls__309d; tmp1 = fncls__309d } else { tmp1 = fncls__309 }; arg_299 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__310, tmp1, nil); var arg_300 any = ks__0; if linked_297 == nil { return ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { return linked_297.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) } }
//line :108:1
func A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_New() *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_sort_keys_fn__1839000050_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A) Ctor() {}
//line :108:1
func (t *A_arbace_repr_go_layout_sort_keys_fn__1839000050_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 any; var root_301 any = A_arbace_repr_go_layout_A_const_59.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, A_arbace_repr_go_layout_key_rank_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = k__1; if linked_302 == nil { tmp1 = ifn_303.Invoke_O__O(arg_304) } else { tmp1 = linked_302.(*A_arbace_repr_go_layout_key_rank_A).Invoke_O_O__O(root_301, arg_304) }; var tmp2 any = tmp1; var tmp3 any; var root_305 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = k__1; if linked_306 == nil { tmp3 = ifn_307.Invoke_O__O(arg_308) } else { tmp3 = linked_306.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_305, arg_308) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }

func A_arbace_repr_go_layout_public_meta_A_New() *A_arbace_repr_go_layout_public_meta_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_public_meta_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_repr_go_layout_public_meta_A) Ctor() {}
//line :110:1
func (t *A_arbace_repr_go_layout_public_meta_A) Invoke_O_O__O(self, x__0 any) any { var m__2 any; var tmp1 any; var root_311 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_313 lang.IFn; if


	linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = x__0; if linked_312 == nil { tmp1 = ifn_313.Invoke_O__O(arg_314) } else { tmp1 = linked_312.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_311, arg_314) }; if jrt.J2g_Truth(tmp1) { m__2 = lang.RT_Meta_O__IPersistentMap_NoInit(x__0) } else { m__2 = nil }; var lines_QMARK___3 bool = /*line :110:1*/lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_28); var pm__4 any; var root_315 any = A_arbace_repr_go_layout_A_const_54.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_317 lang.IFn; if




	linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_319 any; var root_321 any = A_arbace_repr_go_layout_A_const_61.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any; var fnbody__330 any = A_arbace_repr_go_layout_public_meta_fn__1839000054_A_New(); var tmp2 *jrt.Class; var fncls__329 *jrt.Class = A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class; if fncls__329 == nil { var fncls__329d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class = fncls__329d; tmp2 = fncls__329d } else { tmp2 = fncls__329 }; arg_324 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__330, tmp2, nil); if linked_322 == nil { arg_319 = ifn_323.Invoke_O__O(arg_324) } else { arg_319 = linked_322.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_321, arg_324) }; var arg_320 any = m__2; if linked_316 == nil { pm__4 = ifn_317.Invoke_O_O_O__O(arg_318, arg_319, arg_320) } else { pm__4 = linked_316.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_315, arg_318, arg_319, arg_320) }; var pm__5 any; if lines_QMARK___3 {
		pm__5 = pm__4 } else { var G__1839000059__5_ any = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_63.GetRawRoot__O()).Invoke_O_O_O_O__O(pm__4, A_arbace_repr_go_layout_A_const_16, A_arbace_repr_go_layout_A_const_50, A_arbace_repr_go_layout_A_const_64); var G__1839000059__6_ any; var tmp3 any; var root_338 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_340 lang.IFn


			if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = A_arbace_repr_go_layout_A_const_65.Invoke_O__O(m__2); if linked_339 == nil { tmp3 = ifn_340.Invoke_O__O(arg_341) } else { tmp3 = linked_339.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_338, arg_341) }
//line :118:1
			if jrt.J2g_Truth(tmp3) {
				var root_342 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = G__1839000059__5_; var arg_346 any = A_arbace_repr_go_layout_A_const_66; var arg_347 any = A_arbace_repr_go_layout_A_const_65.Invoke_O__O(m__2); if linked_343 == nil { G__1839000059__6_ = ifn_344.Invoke_O_O_O__O(arg_345, arg_346, arg_347) } else { G__1839000059__6_ = linked_343.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_342, arg_345, arg_346, arg_347) } } else {
//line :118:1
					G__1839000059__6_ = G__1839000059__5_ }; var tmp4 any; var root_348 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_350 lang.IFn

			if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = A_arbace_repr_go_layout_A_const_67.Invoke_O__O(m__2); if linked_349 == nil { tmp4 = ifn_350.Invoke_O__O(arg_351) } else { tmp4 = linked_349.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_348, arg_351) }
//line :118:1
			if jrt.J2g_Truth(tmp4) {

				var root_352 any = A_arbace_repr_go_layout_A_const_53.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = G__1839000059__6_; var arg_356 any = A_arbace_repr_go_layout_A_const_67.Invoke_O__O(m__2); if linked_353 == nil { pm__5 = ifn_354.Invoke_O_O__O(arg_355, arg_356) } else { pm__5 = linked_353.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_352, arg_355, arg_356) } } else {
//line :118:1
					pm__5 = G__1839000059__6_ } }; return pm__5 }
//line :115:1
func A_arbace_repr_go_layout_public_meta_fn__1839000054_A_New() *A_arbace_repr_go_layout_public_meta_fn__1839000054_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_public_meta_fn__1839000054_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_repr_go_layout_public_meta_fn__1839000054_A) Ctor() {}
//line :115:1
func (t *A_arbace_repr_go_layout_public_meta_fn__1839000054_A) Invoke_O_O__O(self, p__1839000053__1 any) any { var vec__1839000055__2 any = p__1839000053__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000055__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000055__2, lang.RT_IntCast_J__I_NoInit(1), nil); var or__1927000174__auto____5 any; var root_325 any = A_arbace_repr_go_layout_A_const_62.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, A_arbace_repr_go_layout_private_QMARK__A_fn_class); var ifn_327 lang.IFn; _ = ___4; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = k__3; if linked_326 == nil { or__1927000174__auto____5 = ifn_327.Invoke_O__O(arg_328) } else { or__1927000174__auto____5 = linked_326.(*A_arbace_repr_go_layout_private_QMARK__A).Invoke_O_O__O(root_325, arg_328) }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(k__3, A_arbace_repr_go_layout_A_const_36)).Ref() } }







func A_arbace_repr_go_layout_meta_prefix_A_New() *A_arbace_repr_go_layout_meta_prefix_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_repr_go_layout_meta_prefix_A) Ctor() {}
//line :123:1
func (t *A_arbace_repr_go_layout_meta_prefix_A) Invoke_O_O__O(self, x__0 any) any { var pm__2 any; var root_357 any = A_arbace_repr_go_layout_A_const_68.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, A_arbace_repr_go_layout_public_meta_A_fn_class); var ifn_359 lang.IFn; if
											linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = x__0; if linked_358 == nil { pm__2 = ifn_359.Invoke_O__O(arg_360) } else { pm__2 = linked_358.(*A_arbace_repr_go_layout_public_meta_A).Invoke_O_O__O(root_357, arg_360) }; var tmp1 any; var root_361 any =
											A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = pm__2; if linked_362 == nil { tmp1 = ifn_363.Invoke_O__O(arg_364) } else { tmp1 = linked_362.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_361, arg_364) }; if jrt.J2g_Truth(tmp1) { var ks__3 any; var root_365 any = A_arbace_repr_go_layout_A_const_69.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, A_arbace_repr_go_layout_sort_keys_A_fn_class); var ifn_367 lang.IFn
												if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any; var root_369 any = A_arbace_repr_go_layout_A_const_70.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = pm__2; if linked_370 == nil { arg_368 = ifn_371.Invoke_O__O(arg_372) } else { arg_368 = linked_370.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_369, arg_372) }; if linked_366 == nil { ks__3 = ifn_367.Invoke_O__O(arg_368) } else { ks__3 = linked_366.(*A_arbace_repr_go_layout_sort_keys_A).Invoke_O_O__O(root_365, arg_368) }
//line :125:1
		var flags__4 any; var root_373 any = A_arbace_repr_go_layout_A_const_71.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_375 lang.IFn

		if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any; var fnbody__388 any = A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_New_O(pm__2); var tmp2 *jrt.Class; var fncls__387 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class; if fncls__387 == nil { var fncls__387d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__388); A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class = fncls__387d; tmp2 = fncls__387d } else { tmp2 = fncls__387 }; arg_376 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__388, tmp2, nil); var arg_377 any = ks__3; if linked_374 == nil { flags__4 = ifn_375.Invoke_O_O__O(arg_376, arg_377) } else { flags__4 = linked_374.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_373, arg_376, arg_377) }
//line :125:1
		var rest_ks__5 any; var root_389 any = A_arbace_repr_go_layout_A_const_61.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_391 lang.IFn


		if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any; var fnbody__404 any = A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_New_O(pm__2); var tmp3 *jrt.Class; var fncls__403 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class; if fncls__403 == nil { var fncls__403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__404); A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class = fncls__403d; tmp3 = fncls__403d } else { tmp3 = fncls__403 }; arg_392 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__404, tmp3, nil); var arg_393 any = ks__3; if linked_390 == nil { rest_ks__5 = ifn_391.Invoke_O_O__O(arg_392, arg_393) } else { rest_ks__5 = linked_390.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_389, arg_392, arg_393) }
//line :125:1
		var sb__6 any = jrt.StringBuilder_New(); var seq_1839000067__7 any; var root_409 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_411 lang.IFn




		if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = flags__4; if linked_410 == nil { seq_1839000067__7 = ifn_411.Invoke_O__O(arg_412) } else { seq_1839000067__7 = linked_410.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_409, arg_412) }
//line :125:1
		var chunk_1839000068__8 any; var count_1839000069__9 int64 = 0; var i_1839000070__10 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000070__10, count_1839000069__9) { var k__11 any = lang.Indexed_Cast(chunk_1839000068__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000070__10)); jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__11, nil))); seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000070__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_413 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = seq_1839000067__7; if linked_414 == nil { temp__1927000414__auto____11 = ifn_415.Invoke_O__O(arg_416) } else { temp__1927000414__auto____11 = linked_414.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_413, arg_416) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1839000067__12 any = temp__1927000414__auto____11; var tmp4 any; var root_417 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = seq_1839000067__12; if linked_418 == nil { tmp4 = ifn_419.Invoke_O__O(arg_420) } else { tmp4 = linked_418.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_417, arg_420) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____13 any; var root_421 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = seq_1839000067__12; if linked_422 == nil { c__1927000678__auto____13 = ifn_423.Invoke_O__O(arg_424) } else { c__1927000678__auto____13 = linked_422.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_421, arg_424) }; var tmp5 any; var root_445 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = seq_1839000067__12; if linked_446 == nil { tmp5 = ifn_447.Invoke_O__O(arg_448) } else { tmp5 = linked_446.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_445, arg_448) }; seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = tmp5, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__13 any; var root_425 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = seq_1839000067__12; if linked_426 == nil { k__13 = ifn_427.Invoke_O__O(arg_428) } else { k__13 = linked_426.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_425, arg_428) }; jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, k__13, nil))); var tmp6 any; var root_449 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = seq_1839000067__12; if linked_450 == nil { tmp6 = ifn_451.Invoke_O__O(arg_452) } else { tmp6 = linked_450.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_449, arg_452) }; seq_1839000067__7, chunk_1839000068__8, count_1839000069__9, i_1839000070__10 = tmp6, nil, 0, 0; continue L1 } } }
//line :125:1
			break L1
		}




		var tmp7 any; var root_429 any = A_arbace_repr_go_layout_A_const_77.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_431 lang.IFn
		if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = rest_ks__5; if linked_430 == nil { tmp7 = ifn_431.Invoke_O__O(arg_432) } else { tmp7 = linked_430.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_429, arg_432) }
//line :131:1
		if jrt.J2g_Truth(tmp7) { } else { var tmp8 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(rest_ks__5, A_arbace_repr_go_layout_A_const_78)

			if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var root_433 any = A_arbace_repr_go_layout_A_const_79.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2); if linked_434 == nil { and__1927000168__auto____8 = ifn_435.Invoke_O__O(arg_436) } else { and__1927000168__auto____8 = linked_434.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_433, arg_436) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_437 any = A_arbace_repr_go_layout_A_const_77.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any; var root_441 any = A_arbace_repr_go_layout_A_const_68.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_repr_go_layout_public_meta_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2); if linked_442 == nil { arg_440 = ifn_443.Invoke_O__O(arg_444) } else { arg_440 = linked_442.(*A_arbace_repr_go_layout_public_meta_A).Invoke_O_O__O(root_441, arg_444) }; if linked_438 == nil { tmp8 = ifn_439.Invoke_O__O(arg_440) } else { tmp8 = linked_438.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_437, arg_440) } } else { tmp8 = and__1927000168__auto____8 } } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }
//line :131:1
			if jrt.J2g_Truth(tmp8) {


				jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil, Lit_9), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_layout_A_const_80.Invoke_O__O(pm__2), nil))) } else {
//line :131:1
					if A_arbace_repr_go_layout_A_const_41 != nil {




						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_16)
						var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__6); var tmp10 any; var root_453 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = Lit_9; var arg_457 any; var iter__1927001039__auto____7 any; var fnbody__527 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_New_O(pm__2); var tmp11 *jrt.Class; var fncls__526 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class; if fncls__526 == nil { var fncls__526d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__527); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class = fncls__526d; tmp11 = fncls__526d } else { tmp11 = fncls__526 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__527, tmp11, nil); arg_457 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(rest_ks__5); if linked_454 == nil { tmp10 = ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { tmp10 = linked_454.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_453, arg_456, arg_457) }; jrt.NN(tmp9).Append_String__StringBuilder(jrt.String_Cast(tmp10))
						jrt.NN(jrt.StringBuilder_Cast(sb__6)).Append_String__StringBuilder(Lit_18) } } }
		var root_405 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = sb__6; if linked_406 == nil { return ifn_407.Invoke_O__O(arg_408) } else { return linked_406.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_405, arg_408) } } else {
//line :125:1
			return nil } }

func A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :127:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A) Invoke_O_O__O(self, p1__1839000061_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_378 any = A_arbace_repr_go_layout_A_const_72.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_true_QMARK__A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1839000061_SHARP___1); if linked_379 == nil { and__1927000168__auto____2 = ifn_380.Invoke_O__O(arg_381) } else { and__1927000168__auto____2 = linked_379.(*aot_arbace_core.A_arbace_core_true_QMARK__A).Invoke_O_O__O(root_378, arg_381) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_382 any = A_arbace_repr_go_layout_A_const_73.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = p1__1839000061_SHARP___1; var arg_386 any = A_arbace_repr_go_layout_A_const_74; if linked_383 == nil { return ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { return linked_383.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_382, arg_385, arg_386) } } else { return and__1927000168__auto____2 } }
func A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A{}; t.Ctor_O(p0); return t }
//line :128:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :128:1
func (t *A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A) Invoke_O_O__O(self, p1__1839000062_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_394 any = A_arbace_repr_go_layout_A_const_72.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_true_QMARK__A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(p1__1839000062_SHARP___1); if linked_395 == nil { and__1927000168__auto____2 = ifn_396.Invoke_O__O(arg_397) } else { and__1927000168__auto____2 = linked_395.(*aot_arbace_core.A_arbace_core_true_QMARK__A).Invoke_O_O__O(root_394, arg_397) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_398 any = A_arbace_repr_go_layout_A_const_73.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = p1__1839000062_SHARP___1; var arg_402 any = A_arbace_repr_go_layout_A_const_74; if linked_399 == nil { return ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { return linked_399.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_398, arg_401, arg_402) } } else { return and__1927000168__auto____2 } }








func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_New_O(p0 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A{}; t.Ctor_O(p0); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A) Ctor_O(c__pm any) { t.F_pm = c__pm }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A) Invoke_O_O__O(self, s__1839000072__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__525 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_New_O_O_O(s__1839000072__1, t.F_pm, self); var tmp2 *jrt.Class; var fncls__524 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class; if fncls__524 == nil { var fncls__524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__525); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class = fncls__524d; tmp2 = fncls__524d } else { tmp2 = fncls__524 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__525, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :137:1
func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A) Ctor_O_O_O(c__s__1839000072, c__pm, c__iter__1839000071 any) { t.F_s__1839000072 = c__s__1839000072; t.F_pm = c__pm; t.F_iter__1839000071 = c__iter__1839000071 }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A) Invoke_O__O(self any) any { { var s__1839000072__1 any; var t_ any = t.F_s__1839000072; t.F_s__1839000072 = nil; s__1839000072__1 = t_; for { var temp__1927000414__auto____2 any; var root_458 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = s__1839000072__1; if linked_459 == nil { temp__1927000414__auto____2 = ifn_460.Invoke_O__O(arg_461) } else { temp__1927000414__auto____2 = linked_459.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_458, arg_461) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000072__3 any = temp__1927000414__auto____2; var tmp1 any; var root_462 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = s__1839000072__3; if linked_463 == nil { tmp1 = ifn_464.Invoke_O__O(arg_465) } else { tmp1 = linked_463.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_462, arg_465) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_466 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any = s__1839000072__3; if linked_467 == nil { c__1927001037__auto____4 = ifn_468.Invoke_O__O(arg_469) } else { c__1927001037__auto____4 = linked_467.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_466, arg_469) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000074__6 any; var root_470 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_471 == nil { b__1839000074__6 = ifn_472.Invoke_O__O(arg_473) } else { b__1839000074__6 = linked_471.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_470, arg_473) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__484 any = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_New_O_O_I_O(b__1839000074__6, t.F_pm, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__483 *jrt.Class = A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class; if fncls__483 == nil { var fncls__483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__484); A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class = fncls__483d; tmp3 = fncls__483d } else { tmp3 = fncls__483 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__484, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_485 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any; var root_490 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = b__1839000074__6; if linked_491 == nil { arg_488 = ifn_492.Invoke_O__O(arg_493) } else { arg_488 = linked_491.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_490, arg_493) }; var arg_489 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000071); var tmp5 any; var root_494 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = s__1839000072__3; if linked_495 == nil { tmp5 = ifn_496.Invoke_O__O(arg_497) } else { tmp5 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; arg_489 = tmp4.Invoke_O__O(tmp5); if linked_486 == nil { return ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { return linked_486.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) } } else { var root_498 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any; var root_503 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = b__1839000074__6; if linked_504 == nil { arg_501 = ifn_505.Invoke_O__O(arg_506) } else { arg_501 = linked_504.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_503, arg_506) }; var arg_502 any; if linked_499 == nil { return ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { return linked_499.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) } } } else { var k__4 any; var root_507 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = s__1839000072__3; if linked_508 == nil { k__4 = ifn_509.Invoke_O__O(arg_510) } else { k__4 = linked_508.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_507, arg_510) }; var root_511 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp7 any; var root_516 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, A_arbace_repr_go_layout_text_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(k__4); if linked_517 == nil { tmp7 = ifn_518.Invoke_O__O(arg_519) } else { tmp7 = linked_517.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_516, arg_519) }; arg_514 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, k__4, nil, tmp7)).Ref(); var arg_515 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1839000071); var tmp9 any; var root_520 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = s__1839000072__3; if linked_521 == nil { tmp9 = ifn_522.Invoke_O__O(arg_523) } else { tmp9 = linked_521.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_520, arg_523) }; arg_515 = tmp8.Invoke_O__O(tmp9); if linked_512 == nil { return ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { return linked_512.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :137:1
func A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A) Ctor_O_O_I_O(c__b__1839000074, c__pm any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000074 = c__b__1839000074; t.F_pm = c__pm; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :137:1
func (t *A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A) Invoke_O__O(self any) any { { var i__1839000073__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000073__1)); var root_474 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = t.F_b__1839000074; var arg_478 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp3 any; var root_479 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_repr_go_layout_text_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = lang.IFn_Cast(t.F_pm).Invoke_O__O(k__2); if linked_480 == nil { tmp3 = ifn_481.Invoke_O__O(arg_482) } else { tmp3 = linked_480.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_479, arg_482) }; arg_478 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, k__2, nil, tmp3)).Ref(); if linked_475 == nil { ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { linked_475.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_474, arg_477, arg_478) }; i__1839000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000073__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_layout_atom_text_A_New() *A_arbace_repr_go_layout_atom_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_atom_text_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_repr_go_layout_atom_text_A) Ctor() {}
//line :141:1
func (t *A_arbace_repr_go_layout_atom_text_A) Invoke_O_O__O(self, x__0 any) any {
	if lang.Util_Identical_O_O__Z_NoInit(x__0, nil) { return Lit_1 } else { var tmp1 any; var root_528 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_530 lang.IFn

		if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = x__0; if linked_529 == nil { tmp1 = ifn_530.Invoke_O__O(arg_531) } else { tmp1 = linked_529.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_528, arg_531) }
//line :142:1
		if jrt.J2g_Truth(tmp1) {

			return A_arbace_repr_go_layout_A_const_90.Invoke_O__O(x__0) } else {
//line :142:1
				var tmp2 any; var root_532 any = A_arbace_repr_go_layout_A_const_79.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_534 lang.IFn


				if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = x__0; if linked_533 == nil { tmp2 = ifn_534.Invoke_O__O(arg_535) } else { tmp2 = linked_533.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_532, arg_535) }
//line :142:1
				if jrt.J2g_Truth(tmp2) {


					var root_536 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = x__0; if linked_537 == nil { return ifn_538.Invoke_O__O(arg_539) } else { return linked_537.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_536, arg_539) } } else {
//line :142:1
						var tmp3 any; var root_540 any = A_arbace_repr_go_layout_A_const_10.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_542 lang.IFn



						if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = x__0; if linked_541 == nil { tmp3 = ifn_542.Invoke_O__O(arg_543) } else { tmp3 = linked_541.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_540, arg_543) }
//line :142:1
						if jrt.J2g_Truth(tmp3) {



							var root_544 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = x__0; if linked_545 == nil { return ifn_546.Invoke_O__O(arg_547) } else { return linked_545.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_544, arg_547) } } else {
//line :142:1
								var tmp4 any; var root_548 any = A_arbace_repr_go_layout_A_const_91.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_550 lang.IFn




								if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = x__0; if linked_549 == nil { tmp4 = ifn_550.Invoke_O__O(arg_551) } else { tmp4 = linked_549.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_548, arg_551) }
//line :142:1
								if jrt.J2g_Truth(tmp4) {




									var root_552 any = A_arbace_repr_go_layout_A_const_92.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = x__0; if linked_553 == nil { return ifn_554.Invoke_O__O(arg_555) } else { return linked_553.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_552, arg_555) } } else {
//line :142:1
										var tmp5 any; var root_556 any = A_arbace_repr_go_layout_A_const_93.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A_fn_class); var ifn_558 lang.IFn





										if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = x__0; if linked_557 == nil { tmp5 = ifn_558.Invoke_O__O(arg_559) } else { tmp5 = linked_557.(*aot_arbace_core.A_arbace_core_char_QMARK___1927000032_A).Invoke_O_O__O(root_556, arg_559) }
//line :142:1
										if jrt.J2g_Truth(tmp5) {





											var root_560 any = A_arbace_repr_go_layout_A_const_94.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_char_text_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(x__0)).Ref(); if linked_561 == nil { return ifn_562.Invoke_O__O(arg_563) } else { return linked_561.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_char_text_A).Invoke_O_O__O(root_560, arg_563) } } else {
//line :142:1
												if lang.BigInt_InstanceOf(x__0) {






													return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
														if jrt.BigInteger_InstanceOf(x__0) {







															return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_2), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
																var tmp6 any; var root_564 any = A_arbace_repr_go_layout_A_const_95.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_566 lang.IFn








																if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = x__0; if linked_565 == nil { tmp6 = ifn_566.Invoke_O__O(arg_567) } else { tmp6 = linked_565.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_564, arg_567) }
//line :142:1
																if jrt.J2g_Truth(tmp6) {








																	var root_568 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = x__0; if linked_569 == nil { return ifn_570.Invoke_O__O(arg_571) } else { return linked_569.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_568, arg_571) } } else {
//line :142:1
																		var tmp7 any; var root_572 any = A_arbace_repr_go_layout_A_const_96.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_574 lang.IFn









																		if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = x__0; if linked_573 == nil { tmp7 = ifn_574.Invoke_O__O(arg_575) } else { tmp7 = linked_573.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_572, arg_575) }
//line :142:1
																		if jrt.J2g_Truth(tmp7) {









																			var root_576 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = x__0; if linked_577 == nil { return ifn_578.Invoke_O__O(arg_579) } else { return linked_577.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_576, arg_579) } } else {
//line :142:1
																				if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(x__0)











																					if jrt.Double_IsNaN_D__Z_NoInit(d__2) { return Lit_3 } else { if jrt.Double_IsInfinite_D__Z_NoInit(d__2) {
																						if lang.Numbers_IsPos_D__Z_NoInit(d__2) { return Lit_4 } else { return Lit_5 } } else {
//line :154:1
																							if A_arbace_repr_go_layout_A_const_41 != nil {

																								var root_580 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = x__0; if linked_581 == nil { return ifn_582.Invoke_O__O(arg_583) } else { return linked_581.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_580, arg_583) } } else {
//line :154:1
																									return nil } } } } else {
//line :142:1
																										if jrt.BigDecimal_InstanceOf(x__0) {














																											return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, x__0, nil)).Ref() } else {
//line :142:1
																												var tmp8 any; var root_584 any = A_arbace_repr_go_layout_A_const_97.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_586 lang.IFn















																												if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = x__0; if linked_585 == nil { tmp8 = ifn_586.Invoke_O__O(arg_587) } else { tmp8 = linked_585.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_584, arg_587) }
//line :142:1
																												if jrt.J2g_Truth(tmp8) {















																													var root_588 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = x__0; if linked_589 == nil { return ifn_590.Invoke_O__O(arg_591) } else { return linked_589.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_588, arg_591) } } else {
//line :142:1
																														if A_arbace_repr_go_layout_A_const_41 != nil { var tmp9 any; var root_592 any = A_arbace_repr_go_layout_A_const_98.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_594 lang.IFn
















																															if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_7, nil); var tmp11 any; var root_597 any = A_arbace_repr_go_layout_A_const_99.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = x__0; if linked_598 == nil { tmp11 = ifn_599.Invoke_O__O(arg_600) } else { tmp11 = linked_598.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_597, arg_600) }; arg_595 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref(); var arg_596 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_layout_A_const_100, x__0)); if linked_593 == nil { tmp9 = ifn_594.Invoke_O_O__O(arg_595, arg_596) } else { tmp9 = linked_593.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_592, arg_595, arg_596) }
//line :142:1
																															panic(jrt.Thrown(jrt.Throwable_Cast(tmp9))) } else { return nil
																															}
																													}
																											}
																									}
																			}
																	}
															}
													}
											}
									}
							}
					}
			}
	}
}



func A_arbace_repr_go_layout_lit_children_meta_A_New() *A_arbace_repr_go_layout_lit_children_meta_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_layout_lit_children_meta_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_layout_lit_children_meta_A) Invoke_O_O__O(self, x__0 any) any {



	var root_601 any = A_arbace_repr_go_layout_A_const_45.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any; var fnbody__637 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_New(); var tmp1 *jrt.Class; var fncls__636 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class; if fncls__636 == nil { var fncls__636d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class = fncls__636d; tmp1 = fncls__636d } else { tmp1 = fncls__636 }; arg_604 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__637, tmp1, nil); var arg_605 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_606 any; var root_638 any = A_arbace_repr_go_layout_A_const_102.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_640 lang.IFn




	if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = A_arbace_repr_go_layout_A_const_103.GetRawRoot__O(); var arg_642 any = x__0; if linked_639 == nil { arg_606 = ifn_640.Invoke_O_O__O(arg_641, arg_642) } else { arg_606 = linked_639.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_638, arg_641, arg_642) }
//line :165:1
	if linked_602 == nil { return ifn_603.Invoke_O_O_O__O(arg_604, arg_605, arg_606) } else { return linked_602.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_601, arg_604, arg_605, arg_606) } }
//line :165:1
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_New() *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A) Ctor() {}
//line :165:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A) Invoke_O_O_O__O(self, m__1, p__1839000084__2 any) any { var vec__1839000086__3 any = p__1839000084__2; var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000086__3, lang.RT_IntCast_J__I_NoInit(0), nil); var c__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000086__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_607 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_609 lang.IFn; if
																linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = c__5; if linked_608 == nil { tmp1 = ifn_609.Invoke_O__O(arg_610) } else { tmp1 = linked_608.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_607, arg_610) }; if jrt.J2g_Truth(tmp1) {
																	var root_611 any = A_arbace_repr_go_layout_A_const_45.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any; var fnbody__635 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_New_O_O(i__4, c__5); var tmp2 *jrt.Class; var fncls__634 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class; if fncls__634 == nil { var fncls__634d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__635); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class = fncls__634d; tmp2 = fncls__634d } else { tmp2 = fncls__634 }; arg_614 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__635, tmp2, nil); var arg_615 any = m__1; var arg_616 any = A_arbace_repr_go_layout_A_const_101; if linked_612 == nil { return ifn_613.Invoke_O_O_O__O(arg_614, arg_615, arg_616) } else { return linked_612.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_611, arg_614, arg_615, arg_616) } } else {
//line :166:1
			return m__1 } }
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A) Ctor_O_O(c__i, c__c any) { t.F_i = c__i; t.F_c = c__c }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A) Invoke_O_O_O__O(self, m__1, p__1839000089__2 any) any { var vec__1839000091__3 any = p__1839000089__2; var k__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000091__3, lang.RT_IntCast_J__I_NoInit(0), nil); var mk__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000091__3, lang.RT_IntCast_J__I_NoInit(1), nil); var temp__1927000408__auto____6 any = lang.RT_Get_O_O__O_NoInit(t.F_c, k__4); if jrt.J2g_Truth(temp__1927000408__auto____6) { var v__7 any = temp__1927000408__auto____6; var root_617 any = A_arbace_repr_go_layout_A_const_21.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = m__1; var arg_621 any = mk__5; var arg_622 any; var fnbody__633 any = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_New_O_O(t.F_i, v__7); var tmp1 *jrt.Class; var fncls__632 *jrt.Class = A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class; if fncls__632 == nil { var fncls__632d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__633); A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class = fncls__632d; tmp1 = fncls__632d } else { tmp1 = fncls__632 }; arg_622 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__633, tmp1, nil); if linked_618 == nil { return ifn_619.Invoke_O_O_O__O(arg_620, arg_621, arg_622) } else { return linked_618.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_617, arg_620, arg_621, arg_622) } } else { return m__1 } }
//line :167:1
func A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A{}; t.Ctor_O_O(p0, p1); return t }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A) Ctor_O_O(c__i, c__v any) { t.F_i = c__i; t.F_v = c__v }
//line :167:1
func (t *A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A) Invoke_O_O__O(self, p1__1839000083_SHARP___1 any) any { var root_623 any = A_arbace_repr_go_layout_A_const_33.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any; var or__1927000174__auto____2 any = p1__1839000083_SHARP___1; if jrt.J2g_Truth(or__1927000174__auto____2) { arg_626 = or__1927000174__auto____2 } else { arg_626 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_30.GetRawRoot__O()).Invoke__O() }; var arg_627 any = t.F_i; var arg_628 any = t.F_v; if linked_624 == nil { return ifn_625.Invoke_O_O_O__O(arg_626, arg_627, arg_628) } else { return linked_624.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_623, arg_626, arg_627, arg_628) } }




func A_arbace_repr_go_layout_text_A_New() *A_arbace_repr_go_layout_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_repr_go_layout_text_A) Ctor() {}
//line :172:1
func (t *A_arbace_repr_go_layout_text_A) Invoke_O_O__O(self, x__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_643 any = A_arbace_repr_go_layout_A_const_104.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, A_arbace_repr_go_layout_meta_prefix_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any; var tmp3 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_layout_A_const_27.Get__O(), A_arbace_repr_go_layout_A_const_51); if and__1927000168__auto____4 { var and__1927000168__auto____5 any; var or__1927000174__auto____5 any; var root_647 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = x__0; if linked_648 == nil { or__1927000174__auto____5 = ifn_649.Invoke_O__O(arg_650) } else { or__1927000174__auto____5 = linked_648.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_647, arg_650) }; if jrt.J2g_Truth(or__1927000174__auto____5) { and__1927000168__auto____5 = or__1927000174__auto____5 } else { var root_651 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = x__0; if linked_652 == nil { and__1927000168__auto____5 = ifn_653.Invoke_O__O(arg_654) } else { and__1927000168__auto____5 = linked_652.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_651, arg_654) } }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_655 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var tmp4 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; var arg_658 any = tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)); if linked_656 == nil { tmp3 = ifn_657.Invoke_O__O(arg_658) } else { tmp3 = linked_656.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_655, arg_658) } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp3) { var lm__4 any; var root_659 any = A_arbace_repr_go_layout_A_const_105.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, A_arbace_repr_go_layout_lit_children_meta_A_fn_class); var ifn_661 lang.IFn
		if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = x__0; if linked_660 == nil { lm__4 = ifn_661.Invoke_O__O(arg_662) } else { lm__4 = linked_660.(*A_arbace_repr_go_layout_lit_children_meta_A).Invoke_O_O__O(root_659, arg_662) }
		var tmp5 any; var root_663 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = lm__4; if linked_664 == nil { tmp5 = ifn_665.Invoke_O__O(arg_666) } else { tmp5 = linked_664.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_663, arg_666) }; if jrt.J2g_Truth(tmp5) { arg_646 = lang.IFn_Cast(A_arbace_repr_go_layout_A_const_35.GetRawRoot__O()).Invoke_O_O_O__O(x__0, A_arbace_repr_go_layout_A_const_53.GetRawRoot__O(), lm__4) } else { arg_646 = x__0 } } else {
//line :175:1
			arg_646 = x__0 }; if linked_644 == nil { tmp2 = ifn_645.Invoke_O__O(arg_646) } else { tmp2 = linked_644.(*A_arbace_repr_go_layout_meta_prefix_A).Invoke_O_O__O(root_643, arg_646) }; var tmp6 any = tmp2; var tmp7 any; var tmp8 any; var root_673 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_675 lang.IFn




	if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = x__0; if linked_674 == nil { tmp8 = ifn_675.Invoke_O__O(arg_676) } else { tmp8 = linked_674.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_673, arg_676) }
//line :179:1
	if jrt.J2g_Truth(tmp8) {
		tmp7 = A_arbace_repr_go_layout_A_const_90.Invoke_O__O(x__0) } else {
//line :179:1
			var tmp9 any; var and__1927000168__auto____4_2 any; var root_677 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_679 lang.IFn

			if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = x__0; if linked_678 == nil { and__1927000168__auto____4_2 = ifn_679.Invoke_O__O(arg_680) } else { and__1927000168__auto____4_2 = linked_678.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_677, arg_680) }; if jrt.J2g_Truth(and__1927000168__auto____4_2) { var tmp10 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp9 = tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else { tmp9 = and__1927000168__auto____4_2 }
//line :179:1
			if jrt.J2g_Truth(tmp9) {

				var tmp11 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp7 = tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__0)) } else {
//line :179:1
					var tmp12 any; var root_681 any = A_arbace_repr_go_layout_A_const_38.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class); var ifn_683 lang.IFn


					if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = x__0; if linked_682 == nil { tmp12 = ifn_683.Invoke_O__O(arg_684) } else { tmp12 = linked_682.(*A_arbace_repr_go_layout_deref_form_QMARK__A).Invoke_O_O__O(root_681, arg_684) }
//line :179:1
					if jrt.J2g_Truth(tmp12) {


						var tmp13 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil); var tmp14 any; var root_685 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, A_arbace_repr_go_layout_text_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any; var root_689 any = A_arbace_repr_go_layout_A_const_106.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = x__0; if linked_690 == nil { arg_688 = ifn_691.Invoke_O__O(arg_692) } else { arg_688 = linked_690.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_689, arg_692) }; if linked_686 == nil { tmp14 = ifn_687.Invoke_O__O(arg_688) } else { tmp14 = linked_686.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_685, arg_688) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp13, jrt.RefArrayOf(jrt.Object_class, nil, tmp14)).Ref() } else {
//line :179:1
							var tmp15 any; var root_693 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_695 lang.IFn



							if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = x__0; if linked_694 == nil { tmp15 = ifn_695.Invoke_O__O(arg_696) } else { tmp15 = linked_694.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_693, arg_696) }
//line :179:1
							if jrt.J2g_Truth(tmp15) {



								var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29); var tmp17 any; var root_697 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = Lit_9; var arg_701 any; var root_702 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var arg_706 any = x__0; if linked_703 == nil { arg_701 = ifn_704.Invoke_O_O__O(arg_705, arg_706) } else { arg_701 = linked_703.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_702, arg_705, arg_706) }; if linked_698 == nil { tmp17 = ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { tmp17 = linked_698.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17, nil)).Ref() } else {
//line :179:1
									var tmp18 any; var root_707 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_709 lang.IFn




									if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = x__0; if linked_708 == nil { tmp18 = ifn_709.Invoke_O__O(arg_710) } else { tmp18 = linked_708.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_707, arg_710) }
//line :179:1
									if jrt.J2g_Truth(tmp18) {




										var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_30, nil, Lit_31); var tmp20 any; var root_711 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = Lit_9; var arg_715 any; var root_716 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var arg_720 any = x__0; if linked_717 == nil { arg_715 = ifn_718.Invoke_O_O__O(arg_719, arg_720) } else { arg_715 = linked_717.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_716, arg_719, arg_720) }; if linked_712 == nil { tmp20 = ifn_713.Invoke_O_O__O(arg_714, arg_715) } else { tmp20 = linked_712.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_711, arg_714, arg_715) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp20, nil)).Ref() } else {
//line :179:1
											var tmp21 any; var root_721 any = A_arbace_repr_go_layout_A_const_107.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_723 lang.IFn





											if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = x__0; if linked_722 == nil { tmp21 = ifn_723.Invoke_O__O(arg_724) } else { tmp21 = linked_722.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_721, arg_724) }
//line :179:1
											if jrt.J2g_Truth(tmp21) {





												var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil, Lit_33); var tmp23 any; var root_725 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = Lit_9; var arg_729 any; var iter__1927001039__auto____7 any; var fnbody__807 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_New(); var tmp24 *jrt.Class; var fncls__806 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class; if fncls__806 == nil { var fncls__806d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, nil); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class = fncls__806d; tmp24 = fncls__806d } else { tmp24 = fncls__806 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__807, tmp24, nil); arg_729 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(x__0); if linked_726 == nil { tmp23 = ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { tmp23 = linked_726.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_725, arg_728, arg_729) }; tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp23, nil)).Ref() } else {
//line :179:1
													if A_arbace_repr_go_layout_A_const_41 != nil {






														var root_808 any = A_arbace_repr_go_layout_A_const_108.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, A_arbace_repr_go_layout_atom_text_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = x__0; if linked_809 == nil { tmp7 = ifn_810.Invoke_O__O(arg_811) } else { tmp7 = linked_809.(*A_arbace_repr_go_layout_atom_text_A).Invoke_O_O__O(root_808, arg_811) } } else {
//line :179:1
															tmp7 = nil } } } } } } }
//line :175:1
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7)).Ref()
}








func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_New() *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A) Ctor() {}
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A) Invoke_O_O__O(self, s__1839000100__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__805 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_New_O_O(s__1839000100__1, self); var tmp2 *jrt.Class; var fncls__804 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class; if fncls__804 == nil { var fncls__804d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__805); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class = fncls__804d; tmp2 = fncls__804d } else { tmp2 = fncls__804 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__805, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :185:1
func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A) Ctor_O_O(c__s__1839000100, c__iter__1839000099 any) { t.F_s__1839000100 = c__s__1839000100; t.F_iter__1839000099 = c__iter__1839000099 }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A) Invoke_O__O(self any) any { { var s__1839000100__1 any; var t_ any = t.F_s__1839000100; t.F_s__1839000100 = nil; s__1839000100__1 = t_; for { var temp__1927000414__auto____2 any; var root_730 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = s__1839000100__1; if linked_731 == nil { temp__1927000414__auto____2 = ifn_732.Invoke_O__O(arg_733) } else { temp__1927000414__auto____2 = linked_731.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_730, arg_733) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000100__3 any = temp__1927000414__auto____2; var tmp1 any; var root_734 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = s__1839000100__3; if linked_735 == nil { tmp1 = ifn_736.Invoke_O__O(arg_737) } else { tmp1 = linked_735.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_734, arg_737) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_738 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = s__1839000100__3; if linked_739 == nil { c__1927001037__auto____4 = ifn_740.Invoke_O__O(arg_741) } else { c__1927001037__auto____4 = linked_739.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_738, arg_741) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000102__6 any; var root_742 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_743 == nil { b__1839000102__6 = ifn_744.Invoke_O__O(arg_745) } else { b__1839000102__6 = linked_743.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_742, arg_745) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__760 any = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_New_O_I_O(b__1839000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__759 *jrt.Class = A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class; if fncls__759 == nil { var fncls__759d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__760); A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class = fncls__759d; tmp3 = fncls__759d } else { tmp3 = fncls__759 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__760, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_761 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any; var root_766 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = b__1839000102__6; if linked_767 == nil { arg_764 = ifn_768.Invoke_O__O(arg_769) } else { arg_764 = linked_767.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_766, arg_769) }; var arg_765 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000099); var tmp5 any; var root_770 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = s__1839000100__3; if linked_771 == nil { tmp5 = ifn_772.Invoke_O__O(arg_773) } else { tmp5 = linked_771.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_770, arg_773) }; arg_765 = tmp4.Invoke_O__O(tmp5); if linked_762 == nil { return ifn_763.Invoke_O_O__O(arg_764, arg_765) } else { return linked_762.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_761, arg_764, arg_765) } } else { var root_774 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any; var root_779 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = b__1839000102__6; if linked_780 == nil { arg_777 = ifn_781.Invoke_O__O(arg_782) } else { arg_777 = linked_780.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_779, arg_782) }; var arg_778 any; if linked_775 == nil { return ifn_776.Invoke_O_O__O(arg_777, arg_778) } else { return linked_775.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_774, arg_777, arg_778) } } } else { var vec__1839000110__4 any; var root_783 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = s__1839000100__3; if linked_784 == nil { vec__1839000110__4 = ifn_785.Invoke_O__O(arg_786) } else { vec__1839000110__4 = linked_784.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_783, arg_786) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000110__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000110__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_787 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp7 any; var root_792 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, A_arbace_repr_go_layout_text_A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = k__5; if linked_793 == nil { tmp7 = ifn_794.Invoke_O__O(arg_795) } else { tmp7 = linked_793.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_792, arg_795) }; var tmp8 any = tmp7; var tmp9 any; var root_796 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, A_arbace_repr_go_layout_text_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = v__6; if linked_797 == nil { tmp9 = ifn_798.Invoke_O__O(arg_799) } else { tmp9 = linked_797.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_796, arg_799) }; arg_790 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9)).Ref(); var arg_791 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1839000099); var tmp11 any; var root_800 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = s__1839000100__3; if linked_801 == nil { tmp11 = ifn_802.Invoke_O__O(arg_803) } else { tmp11 = linked_801.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_800, arg_803) }; arg_791 = tmp10.Invoke_O__O(tmp11); if linked_788 == nil { return ifn_789.Invoke_O_O__O(arg_790, arg_791) } else { return linked_788.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_787, arg_790, arg_791) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :185:1
func A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A) Ctor_O_I_O(c__b__1839000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000102 = c__b__1839000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :185:1
func (t *A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A) Invoke_O__O(self any) any { { var i__1839000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1839000106__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000101__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000106__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000106__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_746 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = t.F_b__1839000102; var arg_750 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_9, nil); var tmp3 any; var root_751 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_751, A_arbace_repr_go_layout_text_A_fn_class); var ifn_753 lang.IFn; if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = k__3; if linked_752 == nil { tmp3 = ifn_753.Invoke_O__O(arg_754) } else { tmp3 = linked_752.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_751, arg_754) }; var tmp4 any = tmp3; var tmp5 any; var root_755 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, A_arbace_repr_go_layout_text_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = v__4; if linked_756 == nil { tmp5 = ifn_757.Invoke_O__O(arg_758) } else { tmp5 = linked_756.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_755, arg_758) }; arg_750 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5)).Ref(); if linked_747 == nil { ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { linked_747.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) }; i__1839000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000101__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_layout_comment_text_A_New() *A_arbace_repr_go_layout_comment_text_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_comment_text_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_repr_go_layout_comment_text_A) Ctor() {}
//line :188:1
func (t *A_arbace_repr_go_layout_comment_text_A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_812 any = A_arbace_repr_go_layout_A_const_109.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_814 lang.IFn
	if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = t__0; var arg_816 any = Lit_8; if linked_813 == nil { tmp1 = ifn_814.Invoke_O_O__O(arg_815, arg_816) } else { tmp1 = linked_813.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_812, arg_815, arg_816) }
//line :191:1
	if jrt.J2g_Truth(tmp1) {
		var root_817 any = A_arbace_repr_go_layout_A_const_110.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = t__0; var arg_821 any = A_arbace_repr_go_layout_A_const_111; if linked_818 == nil { return ifn_819.Invoke_O_O__O(arg_820, arg_821) } else { return linked_818.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_817, arg_820, arg_821) } } else {
//line :191:1
			if A_arbace_repr_go_layout_A_const_41 != nil {

				var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_9, nil); var tmp3 any; var root_822 any = A_arbace_repr_go_layout_A_const_112.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = t__0; if linked_823 == nil { tmp3 = ifn_824.Invoke_O__O(arg_825) } else { tmp3 = linked_823.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_822, arg_825) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
//line :191:1
					return nil
				}
		}
}


func A_arbace_repr_go_layout_write_file_A_New() *A_arbace_repr_go_layout_write_file_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_file_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_layout_write_file_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_layout_write_file_A) Invoke_O_O_O__O(self, forms__0, comments__1 any) any {


	var root_826 any = A_arbace_repr_go_layout_A_const_113.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, A_arbace_repr_go_layout_write_prepared_A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any; var root_831 any = A_arbace_repr_go_layout_A_const_114.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, A_arbace_repr_go_layout_prepare_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = forms__0; if linked_832 == nil { arg_829 = ifn_833.Invoke_O__O(arg_834) } else { arg_829 = linked_832.(*A_arbace_repr_go_layout_prepare_A).Invoke_O_O__O(root_831, arg_834) }; var arg_830 any = comments__1; if linked_827 == nil { return ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { return linked_827.(*A_arbace_repr_go_layout_write_prepared_A).Invoke_O_O_O__O(root_826, arg_829, arg_830)
	} }
func A_arbace_repr_go_layout_write_prepared_A_New() *A_arbace_repr_go_layout_write_prepared_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_prepared_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_repr_go_layout_write_prepared_A) Ctor() {}
//line :202:1
func (t *A_arbace_repr_go_layout_write_prepared_A) Invoke_O_O_O__O(self, forms__0, comments__1 any) any { var sb__3 any = jrt.StringBuilder_New(); var line__4 any; var root_835 any = A_arbace_repr_go_layout_A_const_115.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_837 lang.IFn; if



	linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = A_arbace_repr_go_layout_A_const_116; if linked_836 == nil { line__4 = ifn_837.Invoke_O__O(arg_838) } else { line__4 = linked_836.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_835, arg_838) }; var code_QMARK___5 any; var root_839 any = /*line :202:1*/A_arbace_repr_go_layout_A_const_115.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_841 lang.IFn; if




	linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any = jrt.Boolean_FALSE.Ref(); if linked_840 == nil { code_QMARK___5 = ifn_841.Invoke_O__O(arg_842) } else { code_QMARK___5 = linked_840.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_839, arg_842) }; var depth__6 any; var root_843 any = /*line :202:1*/A_arbace_repr_go_layout_A_const_115.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_845 lang.IFn; if





	linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = A_arbace_repr_go_layout_A_const_24; if linked_844 == nil { depth__6 = ifn_845.Invoke_O__O(arg_846) } else { depth__6 = linked_844.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_843, arg_846) }; var flush_comments_BANG___7 any; var fnbody__895 any = /*line :202:1*/A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_New_O_O_O_O_O(sb__3, code_QMARK___5, line__4, comments__1, depth__6); var tmp1 *jrt.Class; var fncls__894 *jrt.Class = A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_fn_class; if







	fncls__894 == nil { var fncls__894d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__895); A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_fn_class = fncls__894d; tmp1 = fncls__894d } else { tmp1 = fncls__894 }; flush_comments_BANG___7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__895, tmp1, nil); var newline_to_BANG___8 any; var fnbody__932 any = /*line :202:1*/A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_New_O_O_O_O_O(sb__3, code_QMARK___5, line__4, flush_comments_BANG___7, depth__6); var tmp2 *jrt.Class; var fncls__931 *jrt.Class = A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_fn_class; if














	fncls__931 == nil { var fncls__931d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__932); A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_fn_class = fncls__931d; tmp2 = fncls__931d } else { tmp2 = fncls__931 }; newline_to_BANG___8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__932, tmp2, nil); var emit__9 any; var fnbody__1019 any = /*line :202:1*/A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_New_O_O_O_O(newline_to_BANG___8, sb__3, code_QMARK___5, depth__6); var tmp3 *jrt.Class; var fncls__1018 *jrt.Class = A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_fn_class; if






















	fncls__1018 == nil { var fncls__1018d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1019); A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_fn_class = fncls__1018d; tmp3 = fncls__1018d } else { tmp3 = fncls__1018 }; emit__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1019, tmp3, nil); var seq_1839000124__10 any; var root_1024 any = /*line :202:1*/A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1026 lang.IFn; if














































	linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = forms__0; if linked_1025 == nil { seq_1839000124__10 = ifn_1026.Invoke_O__O(arg_1027) } else { seq_1839000124__10 = linked_1025.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1024, arg_1027) }; var chunk_1839000125__11 any; var count_1839000126__12 int64 = 0; var i_1839000127__13 int64 = 0; L1:
//line :202:1
	for {














































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1839000127__13, count_1839000126__12) { var f__14 any = lang.Indexed_Cast(chunk_1839000125__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1839000127__13)); var tmp4 *lang.Keyword = A_arbace_repr_go_layout_A_const_36
			if jrt.J2g_Truth(tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__14))) {
				lang.IFn_Cast(emit__9).Invoke_O__O(f__14) } else {
					var tmp5 any; var root_1057 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = code_QMARK___5; if linked_1058 == nil { tmp5 = ifn_1059.Invoke_O__O(arg_1060) } else { tmp5 = linked_1058.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1057, arg_1060) }; if jrt.J2g_Truth(tmp5) { jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__9).Invoke_O__O(f__14) }
//line :249:1
			seq_1839000124__10, chunk_1839000125__11, count_1839000126__12, i_1839000127__13 = seq_1839000124__10, chunk_1839000125__11, count_1839000126__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1839000127__13); continue L1 } else { var temp__1927000414__auto____14 any; var root_1028 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = seq_1839000124__10; if linked_1029 == nil { temp__1927000414__auto____14 = ifn_1030.Invoke_O__O(arg_1031) } else { temp__1927000414__auto____14 = linked_1029.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1028, arg_1031) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1839000124__15 any = temp__1927000414__auto____14; var tmp6 any; var root_1032 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = seq_1839000124__15; if linked_1033 == nil { tmp6 = ifn_1034.Invoke_O__O(arg_1035) } else { tmp6 = linked_1033.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1032, arg_1035) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____16 any; var root_1036 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = seq_1839000124__15; if linked_1037 == nil { c__1927000678__auto____16 = ifn_1038.Invoke_O__O(arg_1039) } else { c__1927000678__auto____16 = linked_1037.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1036, arg_1039) }; var tmp7 any; var root_1061 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = seq_1839000124__15; if linked_1062 == nil { tmp7 = ifn_1063.Invoke_O__O(arg_1064) } else { tmp7 = linked_1062.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1061, arg_1064) }; seq_1839000124__10, chunk_1839000125__11, count_1839000126__12, i_1839000127__13 = tmp7, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__16 any; var root_1040 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = seq_1839000124__15; if linked_1041 == nil { f__16 = ifn_1042.Invoke_O__O(arg_1043) } else { f__16 = linked_1041.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1040, arg_1043) }
				var tmp8 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; if jrt.J2g_Truth(tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__16))) {
					lang.IFn_Cast(emit__9).Invoke_O__O(f__16) } else {
						var tmp9 any; var root_1065 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = code_QMARK___5; if linked_1066 == nil { tmp9 = ifn_1067.Invoke_O__O(arg_1068) } else { tmp9 = linked_1066.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1065, arg_1068) }; if jrt.J2g_Truth(tmp9) { jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(Lit_9) }; lang.IFn_Cast(emit__9).Invoke_O__O(f__16) }
//line :249:1
				var tmp10 any; var root_1069 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = seq_1839000124__15; if linked_1070 == nil { tmp10 = ifn_1071.Invoke_O__O(arg_1072) } else { tmp10 = linked_1070.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1069, arg_1072) }; seq_1839000124__10, chunk_1839000125__11, count_1839000126__12, i_1839000127__13 = tmp10, nil, 0, 0; continue L1 } } }
//line :202:1
		break L1 }; var last_comment__10 any; var tmp11 any; var root_1044 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1046 lang.IFn; if


















































	linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = comments__1; if linked_1045 == nil { tmp11 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp11 = linked_1045.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1044, arg_1047) }; if jrt.J2g_Truth(tmp11) { var root_1048 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = A_arbace_repr_go_layout_A_const_120.GetRawRoot__O(); var arg_1052 any; var root_1053 any = A_arbace_repr_go_layout_A_const_70.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = comments__1; if linked_1054 == nil { arg_1052 = ifn_1055.Invoke_O__O(arg_1056) } else { arg_1052 = linked_1054.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1053, arg_1056) }; if linked_1049 == nil { last_comment__10 = ifn_1050.Invoke_O_O__O(arg_1051, arg_1052) } else { last_comment__10 = linked_1049.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1048, arg_1051, arg_1052) } } else { last_comment__10 = A_arbace_repr_go_layout_A_const_24 }; var tmp12 bool; var na_1073 any = last_comment__10; var na_1074 any; var root_1075 any =
	A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = line__4; if linked_1076 == nil { na_1074 = ifn_1077.Invoke_O__O(arg_1078) } else { na_1074 = linked_1076.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1075, arg_1078) }; var tmp13 bool; var tmp14 bool; tmp14 = jrt.Long_InstanceOf(na_1073); if tmp14 { tmp14 = jrt.Long_InstanceOf(na_1074) }; tmp13 = tmp14; if tmp13 { var n0_1079 int64 = jrt.NN(jrt.Long_Cast(na_1073)).LongValue__J(); var n1_1080 int64 = jrt.NN(jrt.Long_Cast(na_1074)).LongValue__J(); tmp12 = n0_1079 > n1_1080 } else { var tmp15 bool; var tmp16 bool; tmp16 = jrt.Double_InstanceOf(na_1073); if tmp16 { tmp16 = jrt.Double_InstanceOf(na_1074) }; tmp15 = tmp16; if tmp15 { var n0_1079_2 float64 = jrt.NN(jrt.Double_Cast(na_1073)).DoubleValue__D(); var n1_1080_2 float64 = jrt.NN(jrt.Double_Cast(na_1074)).DoubleValue__D(); tmp12 = n1_1080_2 < n0_1079_2 } else { tmp12 = lang.Numbers_Gt_O_O__Z_NoInit(na_1073, na_1074) } }; if tmp12 {
		var root_1082 any = A_arbace_repr_go_layout_A_const_119.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = depth__6; var arg_1086 any = A_arbace_repr_go_layout_A_const_24; if linked_1083 == nil { ifn_1084.Invoke_O_O__O(arg_1085, arg_1086) } else { linked_1083.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_1082, arg_1085, arg_1086) }
		lang.IFn_Cast(newline_to_BANG___8).Invoke_O__O(last_comment__10) };
	lang.IFn_Cast(flush_comments_BANG___7).Invoke__O();
	jrt.NN(jrt.StringBuilder_Cast(sb__3)).Append_String__StringBuilder(Lit_49); var root_1020 any =
	A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = sb__3; if linked_1021 == nil { return ifn_1022.Invoke_O__O(arg_1023) } else { return linked_1021.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1020, arg_1023) } }
//line :210:1
func A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :210:1
func (t *A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__comments, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_comments = c__comments; t.F_depth = c__depth }
//line :210:1
func (t *A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A) Invoke_O__O(self any) any { var temp__1927000414__auto____1 any; var tmp1 any = t.F_comments; var tmp2 any; var root_847 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_849 lang.IFn; if
														linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var arg_850 any = t.F_line; if linked_848 == nil { tmp2 = ifn_849.Invoke_O__O(arg_850) } else { tmp2 = linked_848.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_847, arg_850) }; temp__1927000414__auto____1 = lang.RT_Get_O_O__O_NoInit(tmp1, tmp2); if jrt.J2g_Truth(temp__1927000414__auto____1) { var cs__2 any = temp__1927000414__auto____1; var tmp3 any; var root_851 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_853 lang.IFn
															if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = t.F_code_QMARK_; if linked_852 == nil { tmp3 = ifn_853.Invoke_O__O(arg_854) } else { tmp3 = linked_852.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_851, arg_854) }; if jrt.J2g_Truth(tmp3) {
																var tmp4 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_50, nil); var tmp6 any; var root_855 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = Lit_50; var arg_859 any; var root_860 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = A_arbace_repr_go_layout_A_const_117.GetRawRoot__O(); var arg_864 any = cs__2; if linked_861 == nil { arg_859 = ifn_862.Invoke_O_O__O(arg_863, arg_864) } else { arg_859 = linked_861.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_860, arg_863, arg_864) }; if linked_856 == nil { tmp6 = ifn_857.Invoke_O_O__O(arg_858, arg_859) } else { tmp6 = linked_856.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_855, arg_858, arg_859) }; return jrt.NN(tmp4).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp6))).Ref() } else {
																	var tmp7 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp8 any; var root_875 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_879 any; var root_880 any = A_arbace_repr_go_layout_A_const_118.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any; var na_885 int64 = 2; var na_886 any; var root_887 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = t.F_depth; if linked_888 == nil { na_886 = ifn_889.Invoke_O__O(arg_890) } else { na_886 = linked_888.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_887, arg_890) }; if jrt.Long_InstanceOf(na_886) { var n0_891 int64 = na_885; var n1_892 int64 = jrt.NN(jrt.Long_Cast(na_886)).LongValue__J(); var nr_893 int64 = n0_891 * n1_892; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = n0_891 == -9223372036854775808; if tmp12 { tmp12 = n1_892 < 0 }; tmp11 = tmp12; tmp10 = !tmp11; if tmp10 { var tmp13 bool; tmp13 = n1_892 == 0; if !tmp13 { tmp13 = nr_893/n1_892 == n0_891 }; tmp10 = tmp13 }; tmp9 = tmp10; if tmp9 { arg_883 = jrt.Long_ValueOf_J__Long_NoInit(nr_893).Ref() } else { arg_883 = lang.Numbers_Multiply_J_O__Number_NoInit(na_885, na_886) } } else { arg_883 = lang.Numbers_Multiply_J_O__Number_NoInit(na_885, na_886) }; var arg_884 any = Lit_9; if linked_881 == nil { arg_879 = ifn_882.Invoke_O_O__O(arg_883, arg_884) } else { arg_879 = linked_881.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_880, arg_883, arg_884) }; if linked_876 == nil { tmp8 = ifn_877.Invoke_O_O__O(arg_878, arg_879) } else { tmp8 = linked_876.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_875, arg_878, arg_879) }; jrt.NN(tmp7).Append_O__StringBuilder(tmp8)
																	var tmp14 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_51, nil); var tmp16 any; var root_865 any = A_arbace_repr_go_layout_A_const_82.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = Lit_52; var arg_869 any; var root_870 any = A_arbace_repr_go_layout_A_const_55.GetRawRoot__O(); var linked_871 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_870, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_872 lang.IFn; if linked_871 == nil { ifn_872 = lang.IFn_Cast(root_870) } else { ifn_872 = nil }; var arg_873 any = A_arbace_repr_go_layout_A_const_117.GetRawRoot__O(); var arg_874 any = cs__2; if linked_871 == nil { arg_869 = ifn_872.Invoke_O_O__O(arg_873, arg_874) } else { arg_869 = linked_871.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_870, arg_873, arg_874) }; if linked_866 == nil { tmp16 = ifn_867.Invoke_O_O__O(arg_868, arg_869) } else { tmp16 = linked_866.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_865, arg_868, arg_869) }; return jrt.NN(tmp14).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16))).Ref() } } else {
//line :211:1
					return nil } }





func A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :217:1
func (t *A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A) Ctor_O_O_O_O_O(c__sb, c__code_QMARK_, c__line, c__flush_comments_BANG_, c__depth any) { t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_line = c__line; t.F_flush_comments_BANG_ = c__flush_comments_BANG_; t.F_depth = c__depth }
//line :217:1
func (t *A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A) Invoke_O_O__O(self, l__1 any) any { L1: for {
	var tmp1 bool; var na_915 any; var root_917 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = t.F_line; if linked_918 == nil { na_915 = ifn_919.Invoke_O__O(arg_920) } else { na_915 = linked_918.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_917, arg_920) }; var na_916 any = l__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_915); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_916) }; tmp2 = tmp3; if tmp2 { var n0_921 int64 = jrt.NN(jrt.Long_Cast(na_915)).LongValue__J(); var n1_922 int64 = jrt.NN(jrt.Long_Cast(na_916)).LongValue__J(); tmp1 = n0_921 < n1_922 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_915); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_916) }; tmp4 = tmp5; if tmp4 { var n0_921_2 float64 = jrt.NN(jrt.Double_Cast(na_915)).DoubleValue__D(); var n1_922_2 float64 = jrt.NN(jrt.Double_Cast(na_916)).DoubleValue__D(); tmp1 = n0_921_2 < n1_922_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_915, na_916) } }; if tmp1 {
		lang.IFn_Cast(t.F_flush_comments_BANG_).Invoke__O()
		var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp6).Append_String__StringBuilder(Lit_49)
		var tmp7 *lang.Volatile = lang.Volatile_Cast(t.F_line); var tmp8 jrt.Number_I; var na_924 any = jrt.NN(lang.Volatile_Cast(t.F_line)).Deref__O(); if jrt.Long_InstanceOf(na_924) { var n0_925 int64 = jrt.NN(jrt.Long_Cast(na_924)).LongValue__J(); if n0_925 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_924) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_925 + 1)) } } else { if jrt.Double_InstanceOf(na_924) { var n0_925_2 float64 = jrt.NN(jrt.Double_Cast(na_924)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_925_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_924) } }; jrt.NN(tmp7).Reset_O__O(tmp8)
		var root_926 any = A_arbace_repr_go_layout_A_const_119.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = t.F_code_QMARK_; var arg_930 any = jrt.Boolean_FALSE.Ref(); if linked_927 == nil { ifn_928.Invoke_O_O__O(arg_929, arg_930) } else { linked_927.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_926, arg_929, arg_930) }
//line :218:1
		continue L1 }
//line :217:1
	break L1
}




	var tmp9 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp10 any; var root_896 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_900 any; var root_901 any = A_arbace_repr_go_layout_A_const_118.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any; var na_906 int64 = 2; var na_907 any; var root_908 any = A_arbace_repr_go_layout_A_const_6.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = t.F_depth; if linked_909 == nil { na_907 = ifn_910.Invoke_O__O(arg_911) } else { na_907 = linked_909.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_908, arg_911) }; if jrt.Long_InstanceOf(na_907) { var n0_912 int64 = na_906; var n1_913 int64 = jrt.NN(jrt.Long_Cast(na_907)).LongValue__J(); var nr_914 int64 = n0_912 * n1_913; var tmp11 bool; var tmp12 bool; var tmp13 bool; var tmp14 bool; tmp14 = n0_912 == -9223372036854775808; if tmp14 { tmp14 = n1_913 < 0 }; tmp13 = tmp14; tmp12 = !tmp13; if tmp12 { var tmp15 bool; tmp15 = n1_913 == 0; if !tmp15 { tmp15 = nr_914/n1_913 == n0_912 }; tmp12 = tmp15 }; tmp11 = tmp12; if tmp11 { arg_904 = jrt.Long_ValueOf_J__Long_NoInit(nr_914).Ref() } else { arg_904 = lang.Numbers_Multiply_J_O__Number_NoInit(na_906, na_907) } } else { arg_904 = lang.Numbers_Multiply_J_O__Number_NoInit(na_906, na_907) }; var arg_905 any = Lit_9; if linked_902 == nil { arg_900 = ifn_903.Invoke_O_O__O(arg_904, arg_905) } else { arg_900 = linked_902.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_901, arg_904, arg_905) }; if linked_897 == nil { tmp10 = ifn_898.Invoke_O_O__O(arg_899, arg_900) } else { tmp10 = linked_897.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_896, arg_899, arg_900) }; return jrt.NN(tmp9).Append_O__StringBuilder(tmp10).Ref()
}
func A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_layout_write_prepared_emit__1839000122_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_prepared_emit__1839000122_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :225:1
func (t *A_arbace_repr_go_layout_write_prepared_emit__1839000122_A) Ctor_O_O_O_O(c__newline_to_BANG_, c__sb, c__code_QMARK_, c__depth any) { t.F_newline_to_BANG_ = c__newline_to_BANG_; t.F_sb = c__sb; t.F_code_QMARK_ = c__code_QMARK_; t.F_depth = c__depth }
//line :225:1
func (t *A_arbace_repr_go_layout_write_prepared_emit__1839000122_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var or__1927000174__auto____2 any; var root_957 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_959 lang.IFn; if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = x__1; if linked_958 == nil { or__1927000174__auto____2 = ifn_959.Invoke_O__O(arg_960) } else { or__1927000174__auto____2 = linked_958.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_957, arg_960) }; if jrt.J2g_Truth(or__1927000174__auto____2) { and__1927000168__auto____2 = or__1927000174__auto____2 } else { var root_961 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = x__1; if linked_962 == nil { and__1927000168__auto____2 = ifn_963.Invoke_O__O(arg_964) } else { and__1927000168__auto____2 = linked_962.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_961, arg_964) } }; if jrt.J2g_Truth(and__1927000168__auto____2) {
		var tmp2 any; var root_965 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_967 lang.IFn; if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any = x__1; if linked_966 == nil { tmp2 = ifn_967.Invoke_O__O(arg_968) } else { tmp2 = linked_966.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_965, arg_968) }; if jrt.J2g_Truth(tmp2) { tmp1 = A_arbace_repr_go_layout_A_const_34.Invoke_O__O(x__1) } else { var tmp3 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; tmp1 = tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)) } } else {
//line :226:1
			tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {

				var tmp4 lang.IFn = lang.IFn_Cast(t.F_newline_to_BANG_); var tmp5 any; var root_978 any = A_arbace_repr_go_layout_A_const_32.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, A_arbace_repr_go_layout_form_line_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = x__1; if linked_979 == nil { tmp5 = ifn_980.Invoke_O__O(arg_981) } else { tmp5 = linked_979.(*A_arbace_repr_go_layout_form_line_A).Invoke_O_O__O(root_978, arg_981) }; tmp4.Invoke_O__O(tmp5) }
	var root_969 any = A_arbace_repr_go_layout_A_const_119.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_vreset_BANG__A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = t.F_code_QMARK_; var arg_973 any = jrt.Boolean_TRUE.Ref(); if linked_970 == nil { ifn_971.Invoke_O_O__O(arg_972, arg_973) } else { linked_970.(*aot_arbace_core.A_arbace_core_vreset_BANG__A).Invoke_O_O_O__O(root_969, arg_972, arg_973) }
//line :225:1
	var p__2 any; var root_974 any = A_arbace_repr_go_layout_A_const_104.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, A_arbace_repr_go_layout_meta_prefix_A_fn_class); var ifn_976 lang.IFn




	if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = x__1; if linked_975 == nil { p__2 = ifn_976.Invoke_O__O(arg_977) } else { p__2 = linked_975.(*A_arbace_repr_go_layout_meta_prefix_A).Invoke_O_O__O(root_974, arg_977) }
	if jrt.J2g_Truth(p__2) { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(p__2) }
	var tmp6 any; var and__1927000168__auto____2_2 any; var root_933 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_935 lang.IFn
	if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = x__1; if linked_934 == nil { and__1927000168__auto____2_2 = ifn_935.Invoke_O__O(arg_936) } else { and__1927000168__auto____2_2 = linked_934.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_933, arg_936) }; if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp7 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; tmp6 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)) } else { tmp6 = and__1927000168__auto____2_2 }
//line :232:1
	if jrt.J2g_Truth(tmp6) {
		var tmp8 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp9 *lang.Keyword = A_arbace_repr_go_layout_A_const_26; return jrt.NN(tmp8).Append_String__StringBuilder(jrt.String_Cast(tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(x__1)))).Ref() } else {
//line :232:1
			var tmp10 any; var root_937 any = A_arbace_repr_go_layout_A_const_38.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class); var ifn_939 lang.IFn

			if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = x__1; if linked_938 == nil { tmp10 = ifn_939.Invoke_O__O(arg_940) } else { tmp10 = linked_938.(*A_arbace_repr_go_layout_deref_form_QMARK__A).Invoke_O_O__O(root_937, arg_940) }
//line :232:1
			if jrt.J2g_Truth(tmp10) {

				var tmp11 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp11).Append_String__StringBuilder(Lit_27); var tmp12 lang.IFn = lang.IFn_Cast(self); var tmp13 any; var root_982 any = A_arbace_repr_go_layout_A_const_106.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = x__1; if linked_983 == nil { tmp13 = ifn_984.Invoke_O__O(arg_985) } else { tmp13 = linked_983.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_982, arg_985) }; return tmp12.Invoke_O__O(tmp13) } else {
//line :232:1
					var tmp14 any; var or__1927000174__auto____2_2 any; var root_941 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_943 lang.IFn


					if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any = x__1; if linked_942 == nil { or__1927000174__auto____2_2 = ifn_943.Invoke_O__O(arg_944) } else { or__1927000174__auto____2_2 = linked_942.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_941, arg_944) }; if jrt.J2g_Truth(or__1927000174__auto____2_2) { tmp14 = or__1927000174__auto____2_2 } else { var root_945 any = A_arbace_repr_go_layout_A_const_25.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_947 lang.IFn; if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = x__1; if linked_946 == nil { tmp14 = ifn_947.Invoke_O__O(arg_948) } else { tmp14 = linked_946.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_945, arg_948) } }
//line :232:1
					if jrt.J2g_Truth(tmp14) {



						var tmp15 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp16 *jrt.String; var tmp17 any; var root_986 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = x__1; if linked_987 == nil { tmp17 = ifn_988.Invoke_O__O(arg_989) } else { tmp17 = linked_987.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_986, arg_989) }; if jrt.J2g_Truth(tmp17) { tmp16 = Lit_28 } else { tmp16 = Lit_30 }; jrt.NN(tmp15).Append_String__StringBuilder(tmp16)
						var tmp18 *lang.Volatile = lang.Volatile_Cast(t.F_depth); var tmp19 jrt.Number_I; var na_990 any = jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O(); if jrt.Long_InstanceOf(na_990) { var n0_991 int64 = jrt.NN(jrt.Long_Cast(na_990)).LongValue__J(); if n0_991 == 9223372036854775807 { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_990) } else { tmp19 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_991 + 1)) } } else { if jrt.Double_InstanceOf(na_990) { var n0_991_2 float64 = jrt.NN(jrt.Double_Cast(na_990)).DoubleValue__D(); tmp19 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_991_2 + 1.0)) } else { tmp19 = lang.Numbers_Inc_O__Number_NoInit(na_990) } }; jrt.NN(tmp18).Reset_O__O(tmp19)
//line :232:1
						var cs__2 any; var root_992 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_994 lang.IFn





						if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = x__1; if linked_993 == nil { cs__2 = ifn_994.Invoke_O__O(arg_995) } else { cs__2 = linked_993.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_992, arg_995) }
//line :232:1
						var later__3 any = jrt.Boolean_FALSE.Ref(); L1: for {






							if jrt.J2g_Truth(cs__2) { var c__4 any; var root_996 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_998 lang.IFn
								if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = cs__2; if linked_997 == nil { c__4 = ifn_998.Invoke_O__O(arg_999) } else { c__4 = linked_997.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_996, arg_999) }
								var tmp20 any; var and__1927000168__auto____5 any = later__3; if jrt.J2g_Truth(and__1927000168__auto____5) {
									var root_1002 any = A_arbace_repr_go_layout_A_const_37.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any; var tmp21 any; var root_1006 any = A_arbace_repr_go_layout_A_const_15.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = c__4; if linked_1007 == nil { tmp21 = ifn_1008.Invoke_O__O(arg_1009) } else { tmp21 = linked_1007.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_lit_QMARK__A).Invoke_O_O__O(root_1006, arg_1009) }; if jrt.J2g_Truth(tmp21) { arg_1005 = A_arbace_repr_go_layout_A_const_34.Invoke_O__O(c__4) } else { var and__1927000168__auto____6 any; var root_1010 any = A_arbace_repr_go_layout_A_const_17.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, A_arbace_repr_go_layout_iobj_QMARK__A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = c__4; if linked_1011 == nil { and__1927000168__auto____6 = ifn_1012.Invoke_O__O(arg_1013) } else { and__1927000168__auto____6 = linked_1011.(*A_arbace_repr_go_layout_iobj_QMARK__A).Invoke_O_O__O(root_1010, arg_1013) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp22 *lang.Keyword = A_arbace_repr_go_layout_A_const_36; arg_1005 = tmp22.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(c__4)) } else { arg_1005 = and__1927000168__auto____6 } }; if linked_1003 == nil { tmp20 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp20 = linked_1003.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1002, arg_1005) } } else {
//line :241:1
										tmp20 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp20) {

											var tmp23 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp23).Append_String__StringBuilder(Lit_9) }
								lang.IFn_Cast(self).Invoke_O__O(c__4)
								var tmp24 any; var root_1014 any = A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = cs__2; if linked_1015 == nil { tmp24 = ifn_1016.Invoke_O__O(arg_1017) } else { tmp24 = linked_1015.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1014, arg_1017) }; cs__2, later__3 = tmp24, jrt.Boolean_TRUE.Ref(); continue L1 }
//line :232:1
							break L1
						}












						var tmp25 *lang.Volatile = lang.Volatile_Cast(t.F_depth); var tmp26 jrt.Number_I; var na_1000 any = jrt.NN(lang.Volatile_Cast(t.F_depth)).Deref__O(); if jrt.Long_InstanceOf(na_1000) { var n0_1001 int64 = jrt.NN(jrt.Long_Cast(na_1000)).LongValue__J(); if n0_1001 == -9223372036854775808 { tmp26 = lang.Numbers_Dec_O__Number_NoInit(na_1000) } else { tmp26 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1001 - 1)) } } else { if jrt.Double_InstanceOf(na_1000) { var n0_1001_2 float64 = jrt.NN(jrt.Double_Cast(na_1000)).DoubleValue__D(); tmp26 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1001_2 - 1.0)) } else { tmp26 = lang.Numbers_Dec_O__Number_NoInit(na_1000) } }; jrt.NN(tmp25).Reset_O__O(tmp26)
						var tmp27 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp28 *jrt.String; var tmp29 any; var root_949 any = A_arbace_repr_go_layout_A_const_13.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = x__1; if linked_950 == nil { tmp29 = ifn_951.Invoke_O__O(arg_952) } else { tmp29 = linked_950.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_949, arg_952) }; if jrt.J2g_Truth(tmp29) { tmp28 = Lit_29 } else { tmp28 = Lit_31 }; return jrt.NN(tmp27).Append_String__StringBuilder(tmp28).Ref() } else {
//line :232:1
							if A_arbace_repr_go_layout_A_const_41 != nil {















								var tmp30 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp31 any; var root_953 any = A_arbace_repr_go_layout_A_const_108.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, A_arbace_repr_go_layout_atom_text_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = x__1; if linked_954 == nil { tmp31 = ifn_955.Invoke_O__O(arg_956) } else { tmp31 = linked_954.(*A_arbace_repr_go_layout_atom_text_A).Invoke_O_O__O(root_953, arg_956) }; return jrt.NN(tmp30).Append_String__StringBuilder(jrt.String_Cast(tmp31)).Ref() } else {
//line :232:1
									return nil
								}
						}
				}
		}
}























func A_arbace_repr_go_layout_write_package_A_New() *A_arbace_repr_go_layout_write_package_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_repr_go_layout_write_package_A) Ctor() {}
//line :261:1
func (t *A_arbace_repr_go_layout_write_package_A) Invoke_O_O_O_O__O(self, ns_sym__0, pkg_form__1, loads__2 any) any { var vec__1839000129__4 any = pkg_form__1; var seq__1839000130__5 any; var root_1087 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1089 lang.IFn; if


	linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = vec__1839000129__4; if linked_1088 == nil { seq__1839000130__5 = ifn_1089.Invoke_O__O(arg_1090) } else { seq__1839000130__5 = linked_1088.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1087, arg_1090) }; var first__1839000131__6 any; var root_1091 any = /*line :261:1*/A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1091, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1093 lang.IFn; if


	linked_1092 == nil { ifn_1093 = lang.IFn_Cast(root_1091) } else { ifn_1093 = nil }; var arg_1094 any = seq__1839000130__5; if linked_1092 == nil { first__1839000131__6 = ifn_1093.Invoke_O__O(arg_1094) } else { first__1839000131__6 = linked_1092.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1091, arg_1094) }; var seq__1839000130__7 any; var root_1095 any = /*line :261:1*/A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1097 lang.IFn; if


	linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = seq__1839000130__5; if linked_1096 == nil { seq__1839000130__7 = ifn_1097.Invoke_O__O(arg_1098) } else { seq__1839000130__7 = linked_1096.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1095, arg_1098) }; var head__8 any = first__1839000131__6; var first__1839000131__9 any; var root_1099 any = /*line :261:1*/A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1101 lang.IFn; if


	linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = seq__1839000130__7; if linked_1100 == nil { first__1839000131__9 = ifn_1101.Invoke_O__O(arg_1102) } else { first__1839000131__9 = linked_1100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1099, arg_1102) }; var seq__1839000130__10 any; var root_1103 any = /*line :261:1*/A_arbace_repr_go_layout_A_const_43.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1105 lang.IFn; if


	linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any = seq__1839000130__7; if linked_1104 == nil { seq__1839000130__10 = ifn_1105.Invoke_O__O(arg_1106) } else { seq__1839000130__10 = linked_1104.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1103, arg_1106) }; var nm__11 any = first__1839000131__9; var opts__12 any = seq__1839000130__10; var tmp1 /*line :261:1*/*jrt.RefArray = jrt.ConstRefArray("[0,10,s4:(ns ns35:\n  (:require [arbace.go :as go]))\n\ns1:(ns1: nns3:)\n\nn", []*jrt.Class{jrt.String_class}); var tmp2 any; var root_1107 any = A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1109 lang.IFn; if





	linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_1111 any; var iter__1927001039__auto____23 any; var fnbody__1181 any = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_New(); var tmp3 *jrt.Class; var fncls__1180 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_fn_class; if fncls__1180 == nil { var fncls__1180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_fn_class = fncls__1180d; tmp3 = fncls__1180d } else { tmp3 = fncls__1180 }; iter__1927001039__auto____23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1181, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____23); var tmp5 any; var root_1182 any = A_arbace_repr_go_layout_A_const_121.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = A_arbace_repr_go_layout_A_const_111; var arg_1186 any = opts__12; if linked_1183 == nil { tmp5 = ifn_1184.Invoke_O_O__O(arg_1185, arg_1186) } else { tmp5 = linked_1183.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1182, arg_1185, arg_1186) }; arg_1111 = tmp4.Invoke_O__O(tmp5); if linked_1108 == nil { tmp2 = ifn_1109.Invoke_O_O__O(arg_1110, arg_1111) } else { tmp2 = linked_1108.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1107, arg_1110, arg_1111) }; var tmp6 any = tmp2; var tmp7 any; var root_1187 any = /*line :265:1*/A_arbace_repr_go_layout_A_const_48.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1187, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1189 lang.IFn; if



	linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = A_arbace_repr_go_layout_A_const_60.GetRawRoot__O(); var arg_1191 any; var iter__1927001039__auto____23_2 any; var fnbody__1261 any = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_New(); var tmp8 *jrt.Class; var fncls__1260 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_fn_class; if fncls__1260 == nil { var fncls__1260d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_fn_class = fncls__1260d; tmp8 = fncls__1260d } else { tmp8 = fncls__1260 }; iter__1927001039__auto____23_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1261, tmp8, nil); arg_1191 = lang.IFn_Cast(iter__1927001039__auto____23_2).Invoke_O__O(loads__2); if linked_1188 == nil { tmp7 = ifn_1189.Invoke_O_O__O(arg_1190, arg_1191) } else { tmp7 = linked_1188.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1187, arg_1190, arg_1191) }; return /*line :265:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, ns_sym__0, nil, nil, head__8, nil, nm__11, tmp6, nil, tmp7)).Ref() }

func A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_New() *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A) Ctor() {}
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A) Invoke_O_O__O(self, s__1839000133__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1179 any = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_New_O_O(s__1839000133__1, self); var tmp2 *jrt.Class; var fncls__1178 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_fn_class; if fncls__1178 == nil { var fncls__1178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, fnbody__1179); A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_fn_class = fncls__1178d; tmp2 = fncls__1178d } else { tmp2 = fncls__1178 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1179, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :267:1
func A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A{}; t.Ctor_O_O(p0, p1); return t }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A) Ctor_O_O(c__s__1839000133, c__iter__1839000132 any) { t.F_s__1839000133 = c__s__1839000133; t.F_iter__1839000132 = c__iter__1839000132 }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A) Invoke_O__O(self any) any { { var s__1839000133__1 any; var t_ any = t.F_s__1839000133; t.F_s__1839000133 = nil; s__1839000133__1 = t_; for { var temp__1927000414__auto____2 any; var root_1112 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = s__1839000133__1; if linked_1113 == nil { temp__1927000414__auto____2 = ifn_1114.Invoke_O__O(arg_1115) } else { temp__1927000414__auto____2 = linked_1113.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1112, arg_1115) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000133__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1116 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = s__1839000133__3; if linked_1117 == nil { tmp1 = ifn_1118.Invoke_O__O(arg_1119) } else { tmp1 = linked_1117.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1116, arg_1119) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1120 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1122 lang.IFn; if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = s__1839000133__3; if linked_1121 == nil { c__1927001037__auto____4 = ifn_1122.Invoke_O__O(arg_1123) } else { c__1927001037__auto____4 = linked_1121.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1120, arg_1123) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000135__6 any; var root_1124 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_1125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1124, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1126 lang.IFn; if linked_1125 == nil { ifn_1126 = lang.IFn_Cast(root_1124) } else { ifn_1126 = nil }; var arg_1127 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1125 == nil { b__1839000135__6 = ifn_1126.Invoke_O__O(arg_1127) } else { b__1839000135__6 = linked_1125.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1124, arg_1127) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1138 any = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_New_O_I_O(b__1839000135__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1137 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_fn_class; if fncls__1137 == nil { var fncls__1137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1138); A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_fn_class = fncls__1137d; tmp3 = fncls__1137d } else { tmp3 = fncls__1137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1138, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1139 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any; var root_1144 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = b__1839000135__6; if linked_1145 == nil { arg_1142 = ifn_1146.Invoke_O__O(arg_1147) } else { arg_1142 = linked_1145.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1144, arg_1147) }; var arg_1143 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000132); var tmp5 any; var root_1148 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = s__1839000133__3; if linked_1149 == nil { tmp5 = ifn_1150.Invoke_O__O(arg_1151) } else { tmp5 = linked_1149.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1148, arg_1151) }; arg_1143 = tmp4.Invoke_O__O(tmp5); if linked_1140 == nil { return ifn_1141.Invoke_O_O__O(arg_1142, arg_1143) } else { return linked_1140.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1139, arg_1142, arg_1143) } } else { var root_1152 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any; var root_1157 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = b__1839000135__6; if linked_1158 == nil { arg_1155 = ifn_1159.Invoke_O__O(arg_1160) } else { arg_1155 = linked_1158.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1157, arg_1160) }; var arg_1156 any; if linked_1153 == nil { return ifn_1154.Invoke_O_O__O(arg_1155, arg_1156) } else { return linked_1153.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1152, arg_1155, arg_1156) } } } else { var vec__1839000143__4 any; var root_1161 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = s__1839000133__3; if linked_1162 == nil { vec__1839000143__4 = ifn_1163.Invoke_O__O(arg_1164) } else { vec__1839000143__4 = linked_1162.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1161, arg_1164) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000143__4, lang.RT_IntCast_J__I_NoInit(0), nil); var v__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000143__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1165 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil, Lit_9, nil); var tmp7 any; var root_1170 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, A_arbace_repr_go_layout_text_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = v__6; if linked_1171 == nil { tmp7 = ifn_1172.Invoke_O__O(arg_1173) } else { tmp7 = linked_1171.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_1170, arg_1173) }; arg_1168 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, k__5, nil, tmp7)).Ref(); var arg_1169 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1839000132); var tmp9 any; var root_1174 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = s__1839000133__3; if linked_1175 == nil { tmp9 = ifn_1176.Invoke_O__O(arg_1177) } else { tmp9 = linked_1175.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1174, arg_1177) }; arg_1169 = tmp8.Invoke_O__O(tmp9); if linked_1166 == nil { return ifn_1167.Invoke_O_O__O(arg_1168, arg_1169) } else { return linked_1166.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1165, arg_1168, arg_1169) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :267:1
func A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A) Ctor_O_I_O(c__b__1839000135 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000135 = c__b__1839000135; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :267:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A) Invoke_O__O(self any) any { { var i__1839000134__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1839000139__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000134__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000139__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1839000139__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1128 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = t.F_b__1839000135; var arg_1132 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil, Lit_9, nil); var tmp3 any; var root_1133 any = A_arbace_repr_go_layout_A_const_85.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, A_arbace_repr_go_layout_text_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = v__4; if linked_1134 == nil { tmp3 = ifn_1135.Invoke_O__O(arg_1136) } else { tmp3 = linked_1134.(*A_arbace_repr_go_layout_text_A).Invoke_O_O__O(root_1133, arg_1136) }; arg_1132 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, k__3, nil, tmp3)).Ref(); if linked_1129 == nil { ifn_1130.Invoke_O_O__O(arg_1131, arg_1132) } else { linked_1129.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1128, arg_1131, arg_1132) }; i__1839000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000134__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_New() *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A) Ctor() {}
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A) Invoke_O_O__O(self, s__1839000149__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1259 any = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_New_O_O(s__1839000149__1, self); var tmp2 *jrt.Class; var fncls__1258 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_fn_class; if fncls__1258 == nil { var fncls__1258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__1259); A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_fn_class = fncls__1258d; tmp2 = fncls__1258d } else { tmp2 = fncls__1258 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1259, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :269:1
func A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_New_O_O(p0, p1 any) *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A{}; t.Ctor_O_O(p0, p1); return t }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A) Ctor_O_O(c__s__1839000149, c__iter__1839000148 any) { t.F_s__1839000149 = c__s__1839000149; t.F_iter__1839000148 = c__iter__1839000148 }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A) Invoke_O__O(self any) any { { var s__1839000149__1 any; var t_ any = t.F_s__1839000149; t.F_s__1839000149 = nil; s__1839000149__1 = t_; for { var temp__1927000414__auto____2 any; var root_1192 any = A_arbace_repr_go_layout_A_const_29.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = s__1839000149__1; if linked_1193 == nil { temp__1927000414__auto____2 = ifn_1194.Invoke_O__O(arg_1195) } else { temp__1927000414__auto____2 = linked_1193.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1192, arg_1195) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1839000149__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1196 any = A_arbace_repr_go_layout_A_const_75.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = s__1839000149__3; if linked_1197 == nil { tmp1 = ifn_1198.Invoke_O__O(arg_1199) } else { tmp1 = linked_1197.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1196, arg_1199) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1200 any = A_arbace_repr_go_layout_A_const_76.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = s__1839000149__3; if linked_1201 == nil { c__1927001037__auto____4 = ifn_1202.Invoke_O__O(arg_1203) } else { c__1927001037__auto____4 = linked_1201.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1200, arg_1203) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1839000151__6 any; var root_1204 any = A_arbace_repr_go_layout_A_const_83.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1205 == nil { b__1839000151__6 = ifn_1206.Invoke_O__O(arg_1207) } else { b__1839000151__6 = linked_1205.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1204, arg_1207) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1218 any = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_New_O_I_O(b__1839000151__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1217 *jrt.Class = A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_fn_class; if fncls__1217 == nil { var fncls__1217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__1218); A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_fn_class = fncls__1217d; tmp3 = fncls__1217d } else { tmp3 = fncls__1217 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1218, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1219 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any; var root_1224 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = b__1839000151__6; if linked_1225 == nil { arg_1222 = ifn_1226.Invoke_O__O(arg_1227) } else { arg_1222 = linked_1225.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1224, arg_1227) }; var arg_1223 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1839000148); var tmp5 any; var root_1228 any = A_arbace_repr_go_layout_A_const_81.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = s__1839000149__3; if linked_1229 == nil { tmp5 = ifn_1230.Invoke_O__O(arg_1231) } else { tmp5 = linked_1229.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1228, arg_1231) }; arg_1223 = tmp4.Invoke_O__O(tmp5); if linked_1220 == nil { return ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { return linked_1220.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) } } else { var root_1232 any = A_arbace_repr_go_layout_A_const_86.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any; var root_1237 any = A_arbace_repr_go_layout_A_const_87.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = b__1839000151__6; if linked_1238 == nil { arg_1235 = ifn_1239.Invoke_O__O(arg_1240) } else { arg_1235 = linked_1238.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1237, arg_1240) }; var arg_1236 any; if linked_1233 == nil { return ifn_1234.Invoke_O_O__O(arg_1235, arg_1236) } else { return linked_1233.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1232, arg_1235, arg_1236) } } } else { var l__4 any; var root_1241 any = A_arbace_repr_go_layout_A_const_31.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1243 lang.IFn; if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any = s__1839000149__3; if linked_1242 == nil { l__4 = ifn_1243.Invoke_O__O(arg_1244) } else { l__4 = linked_1242.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1241, arg_1244) }; var root_1245 any = A_arbace_repr_go_layout_A_const_88.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_44, nil, Lit_45); var tmp7 any; var root_1250 any = A_arbace_repr_go_layout_A_const_92.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = l__4; if linked_1251 == nil { tmp7 = ifn_1252.Invoke_O__O(arg_1253) } else { tmp7 = linked_1251.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1250, arg_1253) }; arg_1248 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil)).Ref(); var arg_1249 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1839000148); var tmp9 any; var root_1254 any = A_arbace_repr_go_layout_A_const_89.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = s__1839000149__3; if linked_1255 == nil { tmp9 = ifn_1256.Invoke_O__O(arg_1257) } else { tmp9 = linked_1255.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1254, arg_1257) }; arg_1249 = tmp8.Invoke_O__O(tmp9); if linked_1246 == nil { return ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { return linked_1246.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :269:1
func A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A) Ctor_O_I_O(c__b__1839000151 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1839000151 = c__b__1839000151; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :269:1
func (t *A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A) Invoke_O__O(self any) any { { var i__1839000150__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1839000150__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1839000150__1)); var root_1208 any = A_arbace_repr_go_layout_A_const_84.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = t.F_b__1839000151; var arg_1212 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_44, nil, Lit_45); var tmp3 any; var root_1213 any = A_arbace_repr_go_layout_A_const_92.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = l__2; if linked_1214 == nil { tmp3 = ifn_1215.Invoke_O__O(arg_1216) } else { tmp3 = linked_1214.(*aot_arbace_repr_go_lit.A_arbace_repr_go_lit_string_text_A).Invoke_O_O__O(root_1213, arg_1216) }; arg_1212 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref(); if linked_1209 == nil { ifn_1210.Invoke_O_O__O(arg_1211, arg_1212) } else { linked_1209.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1208, arg_1211, arg_1212) }; i__1839000150__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1839000150__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



































type A_arbace_repr_go_layout_A struct{ jrt.Object }

var A_arbace_repr_go_layout_A_const_pool *jrt.RefArray

var A_arbace_repr_go_layout_A_const_0 *lang.Var

var A_arbace_repr_go_layout_A_const_1 any

var A_arbace_repr_go_layout_A_const_2 any

var A_arbace_repr_go_layout_A_const_3 *lang.Var

var A_arbace_repr_go_layout_A_const_4 any

var A_arbace_repr_go_layout_A_const_5 *lang.Var

var A_arbace_repr_go_layout_A_const_6 *lang.Var

var A_arbace_repr_go_layout_A_const_7 *lang.Var

var A_arbace_repr_go_layout_A_const_8 *lang.Var

var A_arbace_repr_go_layout_A_const_9 any

var A_arbace_repr_go_layout_A_const_10 *lang.Var

var A_arbace_repr_go_layout_A_const_11 *lang.Var

var A_arbace_repr_go_layout_A_const_12 *lang.Var

var A_arbace_repr_go_layout_A_const_13 *lang.Var

var A_arbace_repr_go_layout_A_const_14 *lang.Keyword

var A_arbace_repr_go_layout_A_const_15 *lang.Var

var A_arbace_repr_go_layout_A_const_16 *lang.Keyword

var A_arbace_repr_go_layout_A_const_17 *lang.Var

var A_arbace_repr_go_layout_A_const_18 *lang.Keyword

var A_arbace_repr_go_layout_A_const_19 *lang.Var

var A_arbace_repr_go_layout_A_const_20 *lang.Var

var A_arbace_repr_go_layout_A_const_21 *lang.Var

var A_arbace_repr_go_layout_A_const_22 *lang.Var

var A_arbace_repr_go_layout_A_const_23 *lang.Var

var A_arbace_repr_go_layout_A_const_24 any

var A_arbace_repr_go_layout_A_const_25 *lang.Var

var A_arbace_repr_go_layout_A_const_26 *lang.Keyword

var A_arbace_repr_go_layout_A_const_27 *lang.Var

var A_arbace_repr_go_layout_A_const_28 *lang.Keyword

var A_arbace_repr_go_layout_A_const_29 *lang.Var

var A_arbace_repr_go_layout_A_const_30 *lang.Var

var A_arbace_repr_go_layout_A_const_31 *lang.Var

var A_arbace_repr_go_layout_A_const_32 *lang.Var

var A_arbace_repr_go_layout_A_const_33 *lang.Var

var A_arbace_repr_go_layout_A_const_34 *lang.Keyword

var A_arbace_repr_go_layout_A_const_35 *lang.Var

var A_arbace_repr_go_layout_A_const_36 *lang.Keyword

var A_arbace_repr_go_layout_A_const_37 *lang.Var

var A_arbace_repr_go_layout_A_const_38 *lang.Var

var A_arbace_repr_go_layout_A_const_39 *lang.Var

var A_arbace_repr_go_layout_A_const_40 *lang.Keyword

var A_arbace_repr_go_layout_A_const_41 *lang.Keyword

var A_arbace_repr_go_layout_A_const_42 *lang.Var

var A_arbace_repr_go_layout_A_const_43 *lang.Var

var A_arbace_repr_go_layout_A_const_44 *lang.Keyword

var A_arbace_repr_go_layout_A_const_45 *lang.Var

var A_arbace_repr_go_layout_A_const_46 *lang.Var

var A_arbace_repr_go_layout_A_const_47 any

var A_arbace_repr_go_layout_A_const_48 *lang.Var

var A_arbace_repr_go_layout_A_const_49 *lang.Var

var A_arbace_repr_go_layout_A_const_50 *lang.Keyword

var A_arbace_repr_go_layout_A_const_51 *lang.Keyword

var A_arbace_repr_go_layout_A_const_52 *lang.Keyword

var A_arbace_repr_go_layout_A_const_53 *lang.Var

var A_arbace_repr_go_layout_A_const_54 *lang.Var

var A_arbace_repr_go_layout_A_const_55 *lang.Var

var A_arbace_repr_go_layout_A_const_56 *lang.Var

var A_arbace_repr_go_layout_A_const_57 *lang.Var

var A_arbace_repr_go_layout_A_const_58 *lang.Var

var A_arbace_repr_go_layout_A_const_59 *lang.Var

var A_arbace_repr_go_layout_A_const_60 *lang.Var

var A_arbace_repr_go_layout_A_const_61 *lang.Var

var A_arbace_repr_go_layout_A_const_62 *lang.Var

var A_arbace_repr_go_layout_A_const_63 *lang.Var

var A_arbace_repr_go_layout_A_const_64 *lang.Keyword

var A_arbace_repr_go_layout_A_const_65 *lang.Keyword

var A_arbace_repr_go_layout_A_const_66 *lang.Keyword

var A_arbace_repr_go_layout_A_const_67 *lang.Keyword

var A_arbace_repr_go_layout_A_const_68 *lang.Var

var A_arbace_repr_go_layout_A_const_69 *lang.Var

var A_arbace_repr_go_layout_A_const_70 *lang.Var

var A_arbace_repr_go_layout_A_const_71 *lang.Var

var A_arbace_repr_go_layout_A_const_72 *lang.Var

var A_arbace_repr_go_layout_A_const_73 *lang.Var

var A_arbace_repr_go_layout_A_const_74 *lang.Keyword

var A_arbace_repr_go_layout_A_const_75 *lang.Var

var A_arbace_repr_go_layout_A_const_76 *lang.Var

var A_arbace_repr_go_layout_A_const_77 *lang.Var

var A_arbace_repr_go_layout_A_const_78 any

var A_arbace_repr_go_layout_A_const_79 *lang.Var

var A_arbace_repr_go_layout_A_const_80 *lang.Keyword

var A_arbace_repr_go_layout_A_const_81 *lang.Var

var A_arbace_repr_go_layout_A_const_82 *lang.Var

var A_arbace_repr_go_layout_A_const_83 *lang.Var

var A_arbace_repr_go_layout_A_const_84 *lang.Var

var A_arbace_repr_go_layout_A_const_85 *lang.Var

var A_arbace_repr_go_layout_A_const_86 *lang.Var

var A_arbace_repr_go_layout_A_const_87 *lang.Var

var A_arbace_repr_go_layout_A_const_88 *lang.Var

var A_arbace_repr_go_layout_A_const_89 *lang.Var

var A_arbace_repr_go_layout_A_const_90 *lang.Keyword

var A_arbace_repr_go_layout_A_const_91 *lang.Var

var A_arbace_repr_go_layout_A_const_92 *lang.Var

var A_arbace_repr_go_layout_A_const_93 *lang.Var

var A_arbace_repr_go_layout_A_const_94 *lang.Var

var A_arbace_repr_go_layout_A_const_95 *lang.Var

var A_arbace_repr_go_layout_A_const_96 *lang.Var

var A_arbace_repr_go_layout_A_const_97 *lang.Var

var A_arbace_repr_go_layout_A_const_98 *lang.Var

var A_arbace_repr_go_layout_A_const_99 *lang.Var

var A_arbace_repr_go_layout_A_const_100 *lang.Keyword

var A_arbace_repr_go_layout_A_const_101 any

var A_arbace_repr_go_layout_A_const_102 *lang.Var

var A_arbace_repr_go_layout_A_const_103 *lang.Var

var A_arbace_repr_go_layout_A_const_104 *lang.Var

var A_arbace_repr_go_layout_A_const_105 *lang.Var

var A_arbace_repr_go_layout_A_const_106 *lang.Var

var A_arbace_repr_go_layout_A_const_107 *lang.Var

var A_arbace_repr_go_layout_A_const_108 *lang.Var

var A_arbace_repr_go_layout_A_const_109 *lang.Var

var A_arbace_repr_go_layout_A_const_110 *lang.Var

var A_arbace_repr_go_layout_A_const_111 any

var A_arbace_repr_go_layout_A_const_112 *lang.Var

var A_arbace_repr_go_layout_A_const_113 *lang.Var

var A_arbace_repr_go_layout_A_const_114 *lang.Var

var A_arbace_repr_go_layout_A_const_115 *lang.Var

var A_arbace_repr_go_layout_A_const_116 any

var A_arbace_repr_go_layout_A_const_117 *lang.Var

var A_arbace_repr_go_layout_A_const_118 *lang.Var

var A_arbace_repr_go_layout_A_const_119 *lang.Var

var A_arbace_repr_go_layout_A_const_120 *lang.Var

var A_arbace_repr_go_layout_A_const_121 *lang.Var

var A_arbace_repr_go_layout_A_init jrt.ClassInit

func A_arbace_repr_go_layout_A_Init() { if !A_arbace_repr_go_layout_A_init.Done() { A_arbace_repr_go_layout_A_init.Run(A_arbace_repr_go_layout_A_clinit) } }

func A_arbace_repr_go_layout_A_clinit() { A_arbace_repr_go_layout_A_clinit_p0(); A_arbace_repr_go_layout_A_clinit_p1(); A_arbace_repr_go_layout_A_clinit_p2(); A_arbace_repr_go_layout_A_clinit_p3(); A_arbace_repr_go_layout_A_clinit_p4(); A_arbace_repr_go_layout_A_clinit_p5(); A_arbace_repr_go_layout_A_clinit_p6(); A_arbace_repr_go_layout_A_clinit_p7(); A_arbace_repr_go_layout_A_clinit_p8(); A_arbace_repr_go_layout_A_clinit_p9(); A_arbace_repr_go_layout_A_clinit_p10() }

func A_arbace_repr_go_layout_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_layout_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 156); A_arbace_repr_go_layout_A_const_0 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[34]); A_arbace_repr_go_layout_A_const_1 = A_arbace_repr_go_layout_A_const_pool.A[35]; A_arbace_repr_go_layout_A_const_2 = A_arbace_repr_go_layout_A_const_pool.A[36]; A_arbace_repr_go_layout_A_const_3 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[37]); A_arbace_repr_go_layout_A_const_4 = A_arbace_repr_go_layout_A_const_pool.A[38]; A_arbace_repr_go_layout_A_const_5 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[39]); A_arbace_repr_go_layout_A_const_6 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[40]); A_arbace_repr_go_layout_A_const_7 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[41]); A_arbace_repr_go_layout_A_const_8 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[42]); A_arbace_repr_go_layout_A_const_9 = A_arbace_repr_go_layout_A_const_pool.A[43]; A_arbace_repr_go_layout_A_const_10 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[44]); A_arbace_repr_go_layout_A_const_11 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[45]) }

func A_arbace_repr_go_layout_A_clinit_p1() { A_arbace_repr_go_layout_A_const_12 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[46]); A_arbace_repr_go_layout_A_const_13 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[47]); A_arbace_repr_go_layout_A_const_14 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[48]); A_arbace_repr_go_layout_A_const_15 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[49]); A_arbace_repr_go_layout_A_const_16 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[50]); A_arbace_repr_go_layout_A_const_17 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[51]); A_arbace_repr_go_layout_A_const_18 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[52]); A_arbace_repr_go_layout_A_const_19 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[53]); A_arbace_repr_go_layout_A_const_20 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[54]); A_arbace_repr_go_layout_A_const_21 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[55]); A_arbace_repr_go_layout_A_const_22 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[56]); A_arbace_repr_go_layout_A_const_23 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[57]) }

func A_arbace_repr_go_layout_A_clinit_p2() { A_arbace_repr_go_layout_A_const_24 = A_arbace_repr_go_layout_A_const_pool.A[58]; A_arbace_repr_go_layout_A_const_25 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[59]); A_arbace_repr_go_layout_A_const_26 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[60]); A_arbace_repr_go_layout_A_const_27 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[61]); A_arbace_repr_go_layout_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[62]); A_arbace_repr_go_layout_A_const_29 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[63]); A_arbace_repr_go_layout_A_const_30 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[64]); A_arbace_repr_go_layout_A_const_31 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[65]); A_arbace_repr_go_layout_A_const_32 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[66]); A_arbace_repr_go_layout_A_const_33 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[67]); A_arbace_repr_go_layout_A_const_34 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[68]); A_arbace_repr_go_layout_A_const_35 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[69]) }

func A_arbace_repr_go_layout_A_clinit_p3() { A_arbace_repr_go_layout_A_const_36 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[70]); A_arbace_repr_go_layout_A_const_37 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[71]); A_arbace_repr_go_layout_A_const_38 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[72]); A_arbace_repr_go_layout_A_const_39 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[73]); A_arbace_repr_go_layout_A_const_40 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[74]); A_arbace_repr_go_layout_A_const_41 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[75]); A_arbace_repr_go_layout_A_const_42 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[76]); A_arbace_repr_go_layout_A_const_43 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[77]); A_arbace_repr_go_layout_A_const_44 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[78]); A_arbace_repr_go_layout_A_const_45 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[79]); A_arbace_repr_go_layout_A_const_46 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[80]); A_arbace_repr_go_layout_A_const_47 = A_arbace_repr_go_layout_A_const_pool.A[81] }

func A_arbace_repr_go_layout_A_clinit_p4() { A_arbace_repr_go_layout_A_const_48 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[82]); A_arbace_repr_go_layout_A_const_49 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[83]); A_arbace_repr_go_layout_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[84]); A_arbace_repr_go_layout_A_const_51 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[85]); A_arbace_repr_go_layout_A_const_52 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[86]); A_arbace_repr_go_layout_A_const_53 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[87]); A_arbace_repr_go_layout_A_const_54 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[88]); A_arbace_repr_go_layout_A_const_55 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[89]); A_arbace_repr_go_layout_A_const_56 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[90]); A_arbace_repr_go_layout_A_const_57 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[91]); A_arbace_repr_go_layout_A_const_58 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[92]); A_arbace_repr_go_layout_A_const_59 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[93]) }

func A_arbace_repr_go_layout_A_clinit_p5() { A_arbace_repr_go_layout_A_const_60 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[94]); A_arbace_repr_go_layout_A_const_61 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[95]); A_arbace_repr_go_layout_A_const_62 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[96]); A_arbace_repr_go_layout_A_const_63 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[97]); A_arbace_repr_go_layout_A_const_64 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[98]); A_arbace_repr_go_layout_A_const_65 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[99]); A_arbace_repr_go_layout_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[100]); A_arbace_repr_go_layout_A_const_67 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[101]); A_arbace_repr_go_layout_A_const_68 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[102]); A_arbace_repr_go_layout_A_const_69 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[103]); A_arbace_repr_go_layout_A_const_70 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[104]); A_arbace_repr_go_layout_A_const_71 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[105]) }

func A_arbace_repr_go_layout_A_clinit_p6() { A_arbace_repr_go_layout_A_const_72 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[106]); A_arbace_repr_go_layout_A_const_73 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[107]); A_arbace_repr_go_layout_A_const_74 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[108]); A_arbace_repr_go_layout_A_const_75 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[109]); A_arbace_repr_go_layout_A_const_76 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[110]); A_arbace_repr_go_layout_A_const_77 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[111]); A_arbace_repr_go_layout_A_const_78 = A_arbace_repr_go_layout_A_const_pool.A[112]; A_arbace_repr_go_layout_A_const_79 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[113]); A_arbace_repr_go_layout_A_const_80 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[114]); A_arbace_repr_go_layout_A_const_81 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[115]); A_arbace_repr_go_layout_A_const_82 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[116]); A_arbace_repr_go_layout_A_const_83 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[117]) }

func A_arbace_repr_go_layout_A_clinit_p7() { A_arbace_repr_go_layout_A_const_84 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[118]); A_arbace_repr_go_layout_A_const_85 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[119]); A_arbace_repr_go_layout_A_const_86 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[120]); A_arbace_repr_go_layout_A_const_87 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[121]); A_arbace_repr_go_layout_A_const_88 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[122]); A_arbace_repr_go_layout_A_const_89 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[123]); A_arbace_repr_go_layout_A_const_90 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[124]); A_arbace_repr_go_layout_A_const_91 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[125]); A_arbace_repr_go_layout_A_const_92 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[126]); A_arbace_repr_go_layout_A_const_93 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[127]); A_arbace_repr_go_layout_A_const_94 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[128]); A_arbace_repr_go_layout_A_const_95 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[129]) }

func A_arbace_repr_go_layout_A_clinit_p8() { A_arbace_repr_go_layout_A_const_96 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[130]); A_arbace_repr_go_layout_A_const_97 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[131]); A_arbace_repr_go_layout_A_const_98 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[132]); A_arbace_repr_go_layout_A_const_99 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[133]); A_arbace_repr_go_layout_A_const_100 = lang.Keyword_Cast(A_arbace_repr_go_layout_A_const_pool.A[134]); A_arbace_repr_go_layout_A_const_101 = A_arbace_repr_go_layout_A_const_pool.A[135]; A_arbace_repr_go_layout_A_const_102 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[136]); A_arbace_repr_go_layout_A_const_103 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[137]); A_arbace_repr_go_layout_A_const_104 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[138]); A_arbace_repr_go_layout_A_const_105 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[139]); A_arbace_repr_go_layout_A_const_106 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[140]); A_arbace_repr_go_layout_A_const_107 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[141]) }

func A_arbace_repr_go_layout_A_clinit_p9() { A_arbace_repr_go_layout_A_const_108 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[142]); A_arbace_repr_go_layout_A_const_109 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[143]); A_arbace_repr_go_layout_A_const_110 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[144]); A_arbace_repr_go_layout_A_const_111 = A_arbace_repr_go_layout_A_const_pool.A[145]; A_arbace_repr_go_layout_A_const_112 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[146]); A_arbace_repr_go_layout_A_const_113 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[147]); A_arbace_repr_go_layout_A_const_114 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[148]); A_arbace_repr_go_layout_A_const_115 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[149]); A_arbace_repr_go_layout_A_const_116 = A_arbace_repr_go_layout_A_const_pool.A[150]; A_arbace_repr_go_layout_A_const_117 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[151]); A_arbace_repr_go_layout_A_const_118 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[152]); A_arbace_repr_go_layout_A_const_119 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[153]) }

func A_arbace_repr_go_layout_A_clinit_p10() { A_arbace_repr_go_layout_A_const_120 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[154]); A_arbace_repr_go_layout_A_const_121 = lang.Var_Cast(A_arbace_repr_go_layout_A_const_pool.A[155]) }

func A_arbace_repr_go_layout_A_New() *A_arbace_repr_go_layout_A { A_arbace_repr_go_layout_A_Init(); t := &A_arbace_repr_go_layout_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_A) Ctor() {}

func (t *A_arbace_repr_go_layout_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_A_class }

func (t *A_arbace_repr_go_layout_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_A); return ok }

func A_arbace_repr_go_layout_A_Cast(x any) *A_arbace_repr_go_layout_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_A_class)) }; return v }



type A_arbace_repr_go_layout_atom_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_atom_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_comment_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_comment_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_deref_form_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_deref_form_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_eval1839000004_A struct{ jrt.Object }

func A_arbace_repr_go_layout_eval1839000004_A_New() *A_arbace_repr_go_layout_eval1839000004_A { t := &A_arbace_repr_go_layout_eval1839000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_eval1839000004_A) Ctor() {}

func (t *A_arbace_repr_go_layout_eval1839000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_eval1839000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_eval1839000004_A_class }

func (t *A_arbace_repr_go_layout_eval1839000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_eval1839000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_eval1839000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_eval1839000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_eval1839000004_A); return ok }

func A_arbace_repr_go_layout_eval1839000004_A_Cast(x any) *A_arbace_repr_go_layout_eval1839000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_eval1839000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_eval1839000004_A_class)) }; return v }



type A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_eval1839000004_loading__1927001464__auto____1839000005_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_eval1839000008_A struct{ jrt.Object }

func A_arbace_repr_go_layout_eval1839000008_A_New() *A_arbace_repr_go_layout_eval1839000008_A { t := &A_arbace_repr_go_layout_eval1839000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_layout_eval1839000008_A) Ctor() {}

func (t *A_arbace_repr_go_layout_eval1839000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_layout_eval1839000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_layout_eval1839000008_A_class }

func (t *A_arbace_repr_go_layout_eval1839000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_layout_eval1839000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_layout_eval1839000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_layout_eval1839000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_layout_eval1839000008_A); return ok }

func A_arbace_repr_go_layout_eval1839000008_A_Cast(x any) *A_arbace_repr_go_layout_eval1839000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_layout_eval1839000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_layout_eval1839000008_A_class)) }; return v }



type A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_eval1839000008_fn__1839000009_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_form_line_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_form_line_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_iobj_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_iobj_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_key_rank_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_key_rank_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_lit_children_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A struct{ j2g_header uint64; F_i, F_c any }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A struct{ j2g_header uint64; F_i, F_v any }

var A_arbace_repr_go_layout_lit_children_meta_fn__1839000085_fn__1839000090_fn__1839000094_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_meta_prefix_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_fn__1839000063_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_fn__1839000065_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A struct{ j2g_header uint64; F_pm any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A struct{ j2g_header uint64; F_s__1839000072, F_pm, F_iter__1839000071 any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A struct{ j2g_header uint64; F_b__1839000074, F_pm any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_meta_prefix_iter__1839000071__1839000075_fn__1839000076_fn__1839000077_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_note_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_note_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prep_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_A struct{ j2g_header uint64; F_cursor, F_x any; F_lines_QMARK_ bool }

var A_arbace_repr_go_layout_prep_fn__1839000020_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A struct{ j2g_header uint64; F_l, F_brk, F_cursor, F_c any; F_lines_QMARK_ bool }

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000024_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A struct{ j2g_header uint64; F_i int64; F_c any }

var A_arbace_repr_go_layout_prep_fn__1839000020_fn__1839000028_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prep_fn__1839000036_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prep_fn__1839000036_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_prepare_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_prepare_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_private_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_private_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_layout_public_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_public_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_public_meta_fn__1839000054_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_public_meta_fn__1839000054_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_sort_keys_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_sort_keys_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_sort_keys_fn__1839000050_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_sort_keys_fn__1839000050_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_text_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A struct{ j2g_header uint64; F_s__1839000100, F_iter__1839000099 any }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A struct{ j2g_header uint64; F_b__1839000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_text_iter__1839000099__1839000103_fn__1839000104_fn__1839000105_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_file_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A struct{ j2g_header uint64; F_s__1839000133, F_iter__1839000132 any }

var A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A struct{ j2g_header uint64; F_b__1839000135 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_write_package_iter__1839000132__1839000136_fn__1839000137_fn__1839000138_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A struct{ j2g_header uint64; F_s__1839000149, F_iter__1839000148 any }

var A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A struct{ j2g_header uint64; F_b__1839000151 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_layout_write_package_iter__1839000148__1839000152_fn__1839000153_fn__1839000154_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_prepared_A struct{ j2g_header uint64 }

var A_arbace_repr_go_layout_write_prepared_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_prepared_emit__1839000122_A struct{ j2g_header uint64; F_newline_to_BANG_, F_sb, F_code_QMARK_, F_depth any }

var A_arbace_repr_go_layout_write_prepared_emit__1839000122_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A struct{ j2g_header uint64; F_sb, F_code_QMARK_, F_line, F_comments, F_depth any }

var A_arbace_repr_go_layout_write_prepared_flush_comments_BANG___1839000118_A_fn_class *jrt.Class



type A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A struct{ j2g_header uint64; F_sb, F_code_QMARK_, F_line, F_flush_comments_BANG_, F_depth any }

var A_arbace_repr_go_layout_write_prepared_newline_to_BANG___1839000120_A_fn_class *jrt.Class
